"""Unit tests for HTML app surface #48 — repos dashboard renderer.

Surface #48 renders the org-wide connected-repo registry at
`g8://repos/dashboard` (+ `.txt`). HTML sibling to the existing
structured-JSON `g8://repos` resource; complements surface #30
(per-repo detail at `g8://repos/{repo_id}/overview`).

Backend: `GET /repos` → `list[RepoResponse{id, repo_url, repo_name,
provider, default_branch, scan_status, install_status, project_id,
write_key, created_at, updated_at}]`.

Coverage:
- Helpers (clip, display_name, short_url, status_norm, provider_norm,
  scan_complete_count, install_done_count, provider_buckets,
  unique_provider_count, scan_palette, install_palette, stat_card)
- Empty-state (both modes)
- render_repos_dashboard_html (None → unavailable, [] → empty, full)
- render_repos_dashboard_text_fallback (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (non-graph8 tokens)
    - Drill-up points at per-repo templates, not self
    - Overflow capped at _MAX_REPOS_DASHBOARD_RENDERED
    - XSS escape on every user-controlled field
    - Both status axes (scan + install) render independently
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_ACCENT_BORDER,
    _G8_BORDER,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_BG,
    _G8_WARNING_FG,
    _MAX_REPOS_DASHBOARD_NAME_LEN,
    _MAX_REPOS_DASHBOARD_PROVIDER_CHIPS,
    _MAX_REPOS_DASHBOARD_RENDERED,
    _MAX_REPOS_DASHBOARD_URL_DISPLAY_LEN,
    _REPOS_DASHBOARD_INSTALL_DONE,
    _REPOS_DASHBOARD_INSTALL_FAILED,
    _REPOS_DASHBOARD_INSTALL_PENDING,
    _REPOS_DASHBOARD_SCAN_FAILED,
    _REPOS_DASHBOARD_SCAN_PENDING,
    _REPOS_DASHBOARD_SCAN_TERMINAL,
    _render_repos_dashboard_empty_state_html,
    _repos_dashboard_clip,
    _repos_dashboard_display_name,
    _repos_dashboard_install_done_count,
    _repos_dashboard_install_palette,
    _repos_dashboard_provider_buckets,
    _repos_dashboard_provider_norm,
    _repos_dashboard_scan_complete_count,
    _repos_dashboard_scan_palette,
    _repos_dashboard_short_url,
    _repos_dashboard_stat_card,
    _repos_dashboard_status_norm,
    _repos_dashboard_unique_provider_count,
    render_repos_dashboard_html,
    render_repos_dashboard_text_fallback,
)


# graph8 token regressions ---------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",   # pre-graph8 indigo primary
    "#4f46e5",   # pre-graph8 indigo dark
    "#10b981",   # pre-graph8 success green (old palette)
    "#ec4899",   # pre-graph8 pink
    "#dc2626",   # pre-graph8 destructive (old)
    "#16a34a",   # pre-graph8 success (old)
)


# ---------------------------------------------------------------------------
# TestClip
# ---------------------------------------------------------------------------


class TestClip:
    def test_empty_string_returns_empty(self):
        assert _repos_dashboard_clip("", 50) == ""

    def test_whitespace_only_returns_empty(self):
        assert _repos_dashboard_clip("   \t\n", 50) == ""

    def test_none_returns_empty(self):
        assert _repos_dashboard_clip(None, 50) == ""

    def test_non_string_returns_empty(self):
        assert _repos_dashboard_clip(123, 50) == ""
        assert _repos_dashboard_clip(["x"], 50) == ""
        assert _repos_dashboard_clip({"a": 1}, 50) == ""

    def test_short_string_passes_through_escaped(self):
        assert _repos_dashboard_clip("hello", 50) == "hello"

    def test_clips_long_strings_with_ellipsis(self):
        s = "a" * 120
        out = _repos_dashboard_clip(s, 20)
        assert out.endswith("…")
        assert len(out) == 20

    def test_escapes_html(self):
        assert _repos_dashboard_clip("<script>alert(1)</script>", 50) == (
            "&lt;script&gt;alert(1)&lt;/script&gt;"
        )


# ---------------------------------------------------------------------------
# TestDisplayName
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_prefers_repo_name(self):
        r = {"repo_name": "widgets-api", "repo_url": "https://x"}
        assert _repos_dashboard_display_name(r) == "widgets-api"

    def test_falls_back_to_url_when_name_missing(self):
        assert _repos_dashboard_display_name({"repo_url": "https://x/y"}) == (
            "https://x/y"
        )

    def test_falls_back_to_url_when_name_empty_string(self):
        r = {"repo_name": "", "repo_url": "https://x/y"}
        assert _repos_dashboard_display_name(r) == "https://x/y"

    def test_falls_back_to_url_when_name_whitespace(self):
        r = {"repo_name": "   ", "repo_url": "https://x/y"}
        assert _repos_dashboard_display_name(r) == "https://x/y"

    def test_returns_placeholder_when_both_missing(self):
        assert _repos_dashboard_display_name({}) == "(unnamed repo)"

    def test_non_dict_returns_placeholder(self):
        assert _repos_dashboard_display_name("nope") == "(unnamed repo)"
        assert _repos_dashboard_display_name(None) == "(unnamed repo)"
        assert _repos_dashboard_display_name(42) == "(unnamed repo)"

    def test_clips_long_names(self):
        long = "x" * (_MAX_REPOS_DASHBOARD_NAME_LEN + 50)
        out = _repos_dashboard_display_name({"repo_name": long})
        assert out.endswith("…")
        assert len(out) == _MAX_REPOS_DASHBOARD_NAME_LEN

    def test_escapes_html(self):
        r = {"repo_name": "<img src=x>"}
        out = _repos_dashboard_display_name(r)
        assert "<img" not in out
        assert "&lt;img" in out


# ---------------------------------------------------------------------------
# TestShortUrl
# ---------------------------------------------------------------------------


class TestShortUrl:
    def test_empty_returns_empty(self):
        assert _repos_dashboard_short_url("") == ""
        assert _repos_dashboard_short_url("   ") == ""

    def test_none_returns_empty(self):
        assert _repos_dashboard_short_url(None) == ""

    def test_non_string_returns_empty(self):
        assert _repos_dashboard_short_url(42) == ""
        assert _repos_dashboard_short_url(["x"]) == ""

    def test_short_url_passes_through(self):
        assert _repos_dashboard_short_url("https://x/y") == "https://x/y"

    def test_long_url_clipped(self):
        u = "https://x/" + ("a" * 200)
        out = _repos_dashboard_short_url(u)
        assert out.endswith("…")
        assert len(out) == _MAX_REPOS_DASHBOARD_URL_DISPLAY_LEN

    def test_escapes_html(self):
        assert _repos_dashboard_short_url("https://x/?<") == "https://x/?&lt;"


# ---------------------------------------------------------------------------
# TestStatusNorm
# ---------------------------------------------------------------------------


class TestStatusNorm:
    def test_empty(self):
        assert _repos_dashboard_status_norm("") == ""

    def test_whitespace(self):
        assert _repos_dashboard_status_norm("   ") == ""

    def test_none(self):
        assert _repos_dashboard_status_norm(None) == ""

    def test_non_string(self):
        assert _repos_dashboard_status_norm(42) == ""
        assert _repos_dashboard_status_norm(True) == ""

    def test_lowercases_and_strips(self):
        assert _repos_dashboard_status_norm("  COMPLETED  ") == "completed"
        assert _repos_dashboard_status_norm("In_Progress") == "in_progress"


# ---------------------------------------------------------------------------
# TestProviderNorm
# ---------------------------------------------------------------------------


class TestProviderNorm:
    def test_empty_returns_unknown(self):
        assert _repos_dashboard_provider_norm("") == "unknown"

    def test_whitespace_returns_unknown(self):
        assert _repos_dashboard_provider_norm("   ") == "unknown"

    def test_none_returns_unknown(self):
        assert _repos_dashboard_provider_norm(None) == "unknown"

    def test_non_string_returns_unknown(self):
        assert _repos_dashboard_provider_norm(42) == "unknown"

    def test_lowercases_and_strips(self):
        assert _repos_dashboard_provider_norm(" GitHub ") == "github"
        assert _repos_dashboard_provider_norm("GitLab") == "gitlab"


# ---------------------------------------------------------------------------
# TestScanCompleteCount
# ---------------------------------------------------------------------------


class TestScanCompleteCount:
    def test_empty(self):
        assert _repos_dashboard_scan_complete_count([]) == 0

    def test_counts_terminal_states(self):
        repos = [
            {"scan_status": "completed"},
            {"scan_status": "complete"},
            {"scan_status": "done"},
            {"scan_status": "pending"},
        ]
        assert _repos_dashboard_scan_complete_count(repos) == 3

    def test_case_insensitive(self):
        assert _repos_dashboard_scan_complete_count(
            [{"scan_status": "COMPLETED"}]
        ) == 1

    def test_skips_non_dicts(self):
        repos = [{"scan_status": "completed"}, "nope", None, 42]
        assert _repos_dashboard_scan_complete_count(repos) == 1


# ---------------------------------------------------------------------------
# TestInstallDoneCount
# ---------------------------------------------------------------------------


class TestInstallDoneCount:
    def test_empty(self):
        assert _repos_dashboard_install_done_count([]) == 0

    def test_counts_done_states(self):
        repos = [
            {"install_status": "installed"},
            {"install_status": "applied"},
            {"install_status": "complete"},
            {"install_status": "completed"},
            {"install_status": "pending"},
        ]
        assert _repos_dashboard_install_done_count(repos) == 4

    def test_ignores_failed_and_pending(self):
        repos = [
            {"install_status": "failed"},
            {"install_status": "pending"},
            {"install_status": "queued"},
            {"install_status": "not_installed"},
        ]
        assert _repos_dashboard_install_done_count(repos) == 0

    def test_skips_non_dicts(self):
        repos = [{"install_status": "installed"}, "nope"]
        assert _repos_dashboard_install_done_count(repos) == 1


# ---------------------------------------------------------------------------
# TestProviderBuckets
# ---------------------------------------------------------------------------


class TestProviderBuckets:
    def test_empty(self):
        assert _repos_dashboard_provider_buckets([]) == []

    def test_buckets_by_provider(self):
        repos = [
            {"provider": "github"},
            {"provider": "github"},
            {"provider": "gitlab"},
        ]
        out = _repos_dashboard_provider_buckets(repos)
        assert out == [("github", 2), ("gitlab", 1)]

    def test_desc_count_sort(self):
        repos = [
            {"provider": "a"},
            {"provider": "b"},
            {"provider": "b"},
            {"provider": "c"},
            {"provider": "c"},
            {"provider": "c"},
        ]
        out = _repos_dashboard_provider_buckets(repos)
        # c=3, b=2, a=1
        assert [name for name, _ in out] == ["c", "b", "a"]

    def test_alpha_tiebreak_for_equal_counts(self):
        repos = [{"provider": "zzz"}, {"provider": "aaa"}, {"provider": "mmm"}]
        out = _repos_dashboard_provider_buckets(repos)
        # All count=1, alpha-sorted
        assert [name for name, _ in out] == ["aaa", "mmm", "zzz"]

    def test_missing_provider_buckets_to_unknown(self):
        repos = [{"provider": ""}, {}, {"provider": None}]
        out = _repos_dashboard_provider_buckets(repos)
        assert out == [("unknown", 3)]

    def test_skips_non_dicts(self):
        repos = [{"provider": "github"}, "nope", None]
        out = _repos_dashboard_provider_buckets(repos)
        assert out == [("github", 1)]

    def test_unique_count(self):
        repos = [
            {"provider": "github"},
            {"provider": "gitlab"},
            {"provider": "github"},
        ]
        assert _repos_dashboard_unique_provider_count(repos) == 2


# ---------------------------------------------------------------------------
# TestScanPalette
# ---------------------------------------------------------------------------


class TestScanPalette:
    def test_terminal_green(self):
        for status in _REPOS_DASHBOARD_SCAN_TERMINAL:
            bg, fg, label = _repos_dashboard_scan_palette(status)
            assert bg == "#d1fae5"
            assert fg == "#059669"
            assert label == status.upper()

    def test_failed_red(self):
        for status in _REPOS_DASHBOARD_SCAN_FAILED:
            bg, fg, label = _repos_dashboard_scan_palette(status)
            assert bg == "#fee2e2"
            assert fg == "#ca3214"

    def test_pending_yellow(self):
        for status in _REPOS_DASHBOARD_SCAN_PENDING:
            bg, fg, label = _repos_dashboard_scan_palette(status)
            assert bg == _G8_WARNING_BG
            assert fg == _G8_WARNING_FG

    def test_unknown_muted(self):
        bg, fg, label = _repos_dashboard_scan_palette("")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"

    def test_unknown_status_preserves_raw_label(self):
        bg, fg, label = _repos_dashboard_scan_palette("weird_thing")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "WEIRD_THING"


# ---------------------------------------------------------------------------
# TestInstallPalette
# ---------------------------------------------------------------------------


class TestInstallPalette:
    def test_done_green(self):
        for status in _REPOS_DASHBOARD_INSTALL_DONE:
            bg, fg, label = _repos_dashboard_install_palette(status)
            assert bg == "#d1fae5"
            assert fg == "#059669"

    def test_failed_red(self):
        for status in _REPOS_DASHBOARD_INSTALL_FAILED:
            bg, fg, label = _repos_dashboard_install_palette(status)
            assert bg == "#fee2e2"
            assert fg == "#ca3214"

    def test_pending_yellow(self):
        for status in _REPOS_DASHBOARD_INSTALL_PENDING:
            bg, fg, label = _repos_dashboard_install_palette(status)
            assert bg == _G8_WARNING_BG
            assert fg == _G8_WARNING_FG

    def test_unknown_muted(self):
        bg, fg, label = _repos_dashboard_install_palette("")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_returns_html_string(self):
        out = _repos_dashboard_stat_card("Total", "5")
        assert out.startswith("<div")
        assert "Total" in out
        assert "5" in out

    def test_uniform_border_no_single_side_accent(self):
        out = _repos_dashboard_stat_card("Test", "10", accent="primary")
        # must NOT contain single-side accent border (AI-tell)
        assert "border-left:" not in out
        assert "border-right:" not in out
        assert "border-top:" not in out
        assert "border-bottom:" not in out
        # must have uniform border
        assert f"border:1px solid {_G8_BORDER}" in out

    def test_primary_accent(self):
        out = _repos_dashboard_stat_card("x", "1", accent="primary")
        assert _G8_PRIMARY in out

    def test_positive_accent(self):
        out = _repos_dashboard_stat_card("x", "1", accent="positive")
        assert "#059669" in out

    def test_destructive_accent(self):
        out = _repos_dashboard_stat_card("x", "1", accent="destructive")
        assert "#ca3214" in out

    def test_escapes_label_and_value(self):
        out = _repos_dashboard_stat_card("<b>", "<i>")
        assert "<b>" not in out
        assert "<i>" not in out
        assert "&lt;b&gt;" in out
        assert "&lt;i&gt;" in out


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode_mentions_connect(self):
        out = _render_repos_dashboard_empty_state_html(mode="empty")
        assert "No repositories connected" in out
        assert "POST /repos" in out

    def test_unavailable_mode_mentions_check_creds(self):
        out = _render_repos_dashboard_empty_state_html(mode="unavailable")
        assert "not available" in out.lower()
        assert "API credentials" in out

    def test_no_legacy_hexes(self):
        out = _render_repos_dashboard_empty_state_html(mode="empty")
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code not in out.lower()

    def test_no_single_side_borders(self):
        out = _render_repos_dashboard_empty_state_html(mode="empty")
        assert "border-left:" not in out
        assert "border-right:" not in out


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


def _sample_repos() -> list[dict]:
    return [
        {
            "id": "r1",
            "repo_url": "https://github.com/acme/widgets",
            "repo_name": "widgets",
            "provider": "github",
            "default_branch": "main",
            "scan_status": "completed",
            "install_status": "installed",
            "created_at": "2026-04-01T00:00:00Z",
        },
        {
            "id": "r2",
            "repo_url": "https://github.com/acme/gears",
            "repo_name": "gears",
            "provider": "github",
            "default_branch": "main",
            "scan_status": "pending",
            "install_status": "pending",
            "created_at": "2026-04-02T00:00:00Z",
        },
        {
            "id": "r3",
            "repo_url": "https://gitlab.com/acme/bolts",
            "repo_name": "bolts",
            "provider": "gitlab",
            "default_branch": "develop",
            "scan_status": "failed",
            "install_status": "failed",
            "created_at": "2026-04-03T00:00:00Z",
        },
    ]


class TestRenderHtml:
    def test_none_returns_unavailable_empty_state(self):
        out = render_repos_dashboard_html(repos=None)
        assert "not available" in out.lower()

    def test_empty_list_returns_empty_state(self):
        out = render_repos_dashboard_html(repos=[])
        assert "No repositories connected" in out

    def test_full_render_has_all_sections(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        # header
        assert "Repos" in out
        assert "3 TOTAL" in out
        # stat cards
        assert "Total repos" in out
        assert "Scan complete" in out
        assert "Snippet installed" in out
        assert "Providers" in out
        # provider mix section
        assert "Provider mix" in out
        # rows
        assert "widgets" in out
        assert "gears" in out
        assert "bolts" in out
        # manage block
        assert "Manage repos" in out

    def test_stat_values_correct(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        # Among samples: 1 completed, 1 installed, 2 unique providers (github, gitlab)
        # "Scan complete" value box
        assert ">1<" in out  # appears as the stat value at least once

    def test_scan_badges_render(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert "SCAN COMPLETED" in out
        assert "SCAN PENDING" in out
        assert "SCAN FAILED" in out

    def test_install_badges_render(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert "INSTALL INSTALLED" in out
        assert "INSTALL PENDING" in out
        assert "INSTALL FAILED" in out

    def test_provider_chips_render_lowercase(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        # Provider chip content
        assert ">github<" in out
        assert ">gitlab<" in out

    def test_drill_down_points_to_per_repo_templates(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        # Per-repo sub-surfaces in each row
        assert "g8://repos/r1/overview" in out
        assert "g8://repos/r1/scan" in out
        assert "g8://repos/r1/kb" in out
        assert "g8://repos/r1/campaigns" in out

    def test_drill_up_does_NOT_list_self(self):
        """Drill-up should point to siblings, never the current URI."""
        out = render_repos_dashboard_html(repos=_sample_repos())
        # Manage block should not advertise the dashboard URI itself
        # The dashboard URI is g8://repos/dashboard — no mention in manage block
        assert "g8://repos/dashboard" not in out

    def test_manage_block_mentions_templates_with_placeholder(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert "{repo_id}" in out

    def test_no_single_side_accent_borders(self):
        """Regression: no border-left/right/top/bottom accent anywhere."""
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert "border-left:" not in out
        assert "border-right:" not in out
        assert "border-top:" not in out
        assert "border-bottom:" not in out

    def test_no_legacy_accent_hexes(self):
        """Regression: none of the old palette hexes leak through."""
        out = render_repos_dashboard_html(repos=_sample_repos())
        out_lower = out.lower()
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code not in out_lower

    def test_uses_graph8_primary_color(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert _G8_PRIMARY.lower() in out.lower()

    def test_uses_graph8_border(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert _G8_BORDER.lower() in out.lower()

    def test_xss_in_repo_name_escaped(self):
        repos = [{
            "id": "r1",
            "repo_name": "<script>alert(1)</script>",
            "repo_url": "https://x/y",
            "provider": "github",
            "scan_status": "completed",
            "install_status": "installed",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_in_repo_url_escaped(self):
        repos = [{
            "id": "r1",
            "repo_name": "x",
            "repo_url": "https://x?p=<img onerror=alert(1) src=x>",
            "provider": "github",
            "scan_status": "completed",
            "install_status": "installed",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "<img onerror=" not in out
        assert "&lt;img" in out

    def test_xss_in_provider_escaped(self):
        repos = [{
            "id": "r1",
            "repo_name": "x",
            "provider": "<b>evil</b>",
            "scan_status": "completed",
            "install_status": "installed",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "<b>evil</b>" not in out
        assert "&lt;b&gt;evil&lt;/b&gt;" in out

    def test_xss_in_branch_escaped(self):
        repos = [{
            "id": "r1",
            "repo_name": "x",
            "provider": "github",
            "default_branch": "<script>xss</script>",
            "scan_status": "completed",
            "install_status": "installed",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "<script>xss</script>" not in out

    def test_xss_in_created_at_escaped(self):
        repos = [{
            "id": "r1",
            "repo_name": "x",
            "provider": "github",
            "scan_status": "completed",
            "install_status": "installed",
            "created_at": "<b>2026</b>",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "<b>2026</b>" not in out
        assert "&lt;b&gt;2026&lt;/b&gt;" in out

    def test_overflow_beyond_cap(self):
        """Only _MAX_REPOS_DASHBOARD_RENDERED rows shown; rest noted."""
        repos = [
            {
                "id": f"r{i}",
                "repo_name": f"repo-{i}",
                "provider": "github",
                "scan_status": "completed",
                "install_status": "installed",
            }
            for i in range(_MAX_REPOS_DASHBOARD_RENDERED + 20)
        ]
        out = render_repos_dashboard_html(repos=repos)
        # First should render, last (beyond cap) should not
        assert "repo-0" in out
        assert f"repo-{_MAX_REPOS_DASHBOARD_RENDERED + 19}" not in out
        # Overflow note appears
        assert "20 more repos omitted" in out

    def test_filters_non_dict_entries(self):
        repos = [
            {"id": "r1", "repo_name": "x", "provider": "github",
             "scan_status": "completed", "install_status": "installed"},
            "not a dict",
            None,
            42,
        ]
        out = render_repos_dashboard_html(repos=repos)
        assert "x" in out
        # only 1 real row; header reflects total=1
        assert "1 TOTAL" in out

    def test_missing_id_suppresses_drill_down(self):
        repos = [{
            "repo_name": "x",
            "provider": "github",
            "scan_status": "completed",
            "install_status": "installed",
        }]
        out = render_repos_dashboard_html(repos=repos)
        # no id = no per-repo drill pointers
        assert "g8://repos/" not in out or "g8://repos/{repo_id}" in out

    def test_provider_chip_overflow_shows_more(self):
        """When >_MAX_REPOS_DASHBOARD_PROVIDER_CHIPS distinct providers, show +N more."""
        repos = []
        # Create more distinct providers than the chip cap
        for i in range(_MAX_REPOS_DASHBOARD_PROVIDER_CHIPS + 3):
            repos.append({
                "id": f"r{i}",
                "repo_name": f"n{i}",
                "provider": f"provider-{i:02d}",
                "scan_status": "completed",
                "install_status": "installed",
            })
        out = render_repos_dashboard_html(repos=repos)
        assert "3 more providers" in out


# ---------------------------------------------------------------------------
# TestTextFallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_returns_unavailable(self):
        out = render_repos_dashboard_text_fallback(repos=None)
        assert "# Repos" in out
        assert "not available" in out.lower()
        assert "GET /repos" in out

    def test_empty_list_returns_empty_state(self):
        out = render_repos_dashboard_text_fallback(repos=[])
        assert "no repositories connected" in out.lower()
        assert "POST /repos" in out

    def test_full_render_has_sections(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "# Repos" in out
        assert "Total repos: 3" in out
        assert "Scan complete: 1" in out
        assert "Snippet installed: 1" in out
        assert "Providers: 2" in out
        assert "## Provider mix" in out
        assert "github: 2" in out
        assert "gitlab: 1" in out
        assert "## Repos (3 of 3)" in out
        assert "widgets" in out
        assert "gears" in out
        assert "bolts" in out
        assert "## Manage repos" in out

    def test_row_format_includes_status(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "scan: completed" in out
        assert "install: installed" in out
        assert "scan: pending" in out
        assert "scan: failed" in out

    def test_row_format_includes_id(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "id=r1" in out
        assert "id=r2" in out
        assert "id=r3" in out

    def test_includes_url_and_branch(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "url: https://github.com/acme/widgets" in out
        assert "branch: main" in out
        assert "branch: develop" in out

    def test_includes_created_at(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "created: 2026-04-01T00:00:00Z" in out

    def test_manage_block_does_not_list_self(self):
        """Self-URI (g8://repos/dashboard) must not appear in manage block."""
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "g8://repos/dashboard" not in out

    def test_manage_block_lists_per_repo_templates(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert "g8://repos/{repo_id}/overview" in out
        assert "g8://repos/{repo_id}/scan" in out
        assert "g8://repos/{repo_id}/kb" in out
        assert "g8://repos/{repo_id}/campaigns" in out

    def test_provider_overflow(self):
        repos = []
        for i in range(_MAX_REPOS_DASHBOARD_PROVIDER_CHIPS + 2):
            repos.append({
                "id": f"r{i}",
                "repo_name": f"n{i}",
                "provider": f"p-{i:02d}",
                "scan_status": "completed",
                "install_status": "installed",
            })
        out = render_repos_dashboard_text_fallback(repos=repos)
        assert "(+ 2 more providers)" in out

    def test_overflow_note_shows_cap(self):
        repos = [
            {"id": f"r{i}", "repo_name": f"n{i}", "provider": "github",
             "scan_status": "completed", "install_status": "installed"}
            for i in range(_MAX_REPOS_DASHBOARD_RENDERED + 5)
        ]
        out = render_repos_dashboard_text_fallback(repos=repos)
        assert "+ 5 more repos omitted" in out

    def test_missing_fields_are_safe(self):
        repos = [{"id": "r1"}]
        out = render_repos_dashboard_text_fallback(repos=repos)
        assert "(unnamed repo)" in out
        assert "[unknown]" in out
        assert "scan: unknown" in out
        assert "install: unknown" in out

    def test_filters_non_dicts(self):
        repos = [
            {"id": "r1", "repo_name": "x", "provider": "github",
             "scan_status": "completed", "install_status": "installed"},
            "not dict", None, 42,
        ]
        out = render_repos_dashboard_text_fallback(repos=repos)
        assert "Total repos: 1" in out

    def test_trailing_newline(self):
        out = render_repos_dashboard_text_fallback(repos=_sample_repos())
        assert out.endswith("\n")


# ---------------------------------------------------------------------------
# TestSmoke — end-to-end against the canonical RepoResponse shape
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_canonical_single_repo_renders(self):
        """Matches the real dev-api RepoResponse JSON shape."""
        repos = [{
            "id": "550e8400-e29b-41d4-a716-446655440000",
            "repo_url": "https://github.com/acme/site",
            "repo_name": "acme-site",
            "provider": "github",
            "default_branch": "main",
            "scan_status": "completed",
            "install_status": "installed",
            "project_id": "proj_abc",
            "write_key": "wk_xyz",
            "created_at": "2026-04-01T12:00:00Z",
            "updated_at": "2026-04-02T12:00:00Z",
        }]
        out = render_repos_dashboard_html(repos=repos)
        assert "acme-site" in out
        assert "github" in out
        assert "SCAN COMPLETED" in out
        assert "INSTALL INSTALLED" in out

    def test_canonical_single_repo_text(self):
        repos = [{
            "id": "550e8400-e29b-41d4-a716-446655440000",
            "repo_url": "https://github.com/acme/site",
            "repo_name": "acme-site",
            "provider": "github",
            "default_branch": "main",
            "scan_status": "completed",
            "install_status": "installed",
            "created_at": "2026-04-01T12:00:00Z",
        }]
        out = render_repos_dashboard_text_fallback(repos=repos)
        assert "acme-site" in out
        assert "github" in out

    def test_html_has_doctype(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert out.startswith("<!DOCTYPE html>")

    def test_html_has_closing_tags(self):
        out = render_repos_dashboard_html(repos=_sample_repos())
        assert out.rstrip().endswith("</html>")
