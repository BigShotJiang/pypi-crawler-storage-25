"""Unit tests for Surface #87 — g8://tasks/due-today.

TEMPORAL axis-filter applied to TASKS (second temporal surface after #86
activities/today). Distinct from #86: uses ``due_before`` bound (not
``since``), so it catches OVERDUE tasks plus tasks due today plus tasks
completed today — three bands partitioned client-side.

Sibling family under ``g8://tasks/``:
    #12 tasks/dashboard         (2-seg static)
    #67 tasks/{task_id}         (2-seg template)
    #74 tasks/status/{status}   (3-seg template)
    #75 tasks/priority/{priority} (3-seg template)
    #87 tasks/due-today         (2-seg static — THIS surface)

Locked invariants:
- NEW stats signature for this entity:
    Total in window / Overdue / Due today / Completed today
- Three-band partition (overdue / due_today / completed_today) with
  band-specific palettes:
    overdue  → warning amber
    due_today → primary purple
    completed_today → positive green + strike-through
- graph8 design tokens ONLY (no banned Studio hexes).
- Sort order per band:
    overdue → oldest-first (most urgent);
    due_today → priority-ordered (urgent → low);
    completed_today → most-recent-first.
- Cross-entity drill-up to tasks/dashboard, tasks/status/open,
  tasks/priority/urgent, activities/today, copilot/home.
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

TODAY_DATE = "2026-04-21"
YESTERDAY_DATE = "2026-04-20"
TWO_DAYS_AGO_DATE = "2026-04-19"
TOMORROW_DATE = "2026-04-22"


def _today_iso(hour: int = 9, minute: int = 0) -> str:
    return f"{TODAY_DATE}T{hour:02d}:{minute:02d}:00Z"


def _yesterday_iso(hour: int = 9) -> str:
    return f"{YESTERDAY_DATE}T{hour:02d}:00:00Z"


def _open_task(
    due: str, *, title: str = "task", priority: str = "normal", task_id: str | int = "t1"
) -> dict:
    return {
        "id": task_id,
        "title": title,
        "priority": priority,
        "status": "open",
        "due_date": due,
    }


def _completed_task(
    due: str, *, completed_at: str, title: str = "done", task_id: str | int = "c1"
) -> dict:
    return {
        "id": task_id,
        "title": title,
        "priority": "normal",
        "status": "completed",
        "due_date": due,
        "completed_at": completed_at,
    }


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_done_statuses_is_frozenset(self):
        assert isinstance(ar._TASKS_DUE_TODAY_DONE_STATUSES, frozenset)

    def test_done_statuses_cover_common(self):
        for s in ("done", "completed", "complete", "closed", "resolved", "finished"):
            assert s in ar._TASKS_DUE_TODAY_DONE_STATUSES

    def test_priority_labels_exist(self):
        for p in ("urgent", "high", "medium", "normal", "low"):
            assert p in ar._TASKS_DUE_TODAY_PRIORITY_LABELS

    def test_priority_labels_titlecased(self):
        for v in ar._TASKS_DUE_TODAY_PRIORITY_LABELS.values():
            assert isinstance(v, str)
            assert v[0].isupper()

    def test_renderer_functions_exported(self):
        assert callable(ar.render_tasks_due_today_html)
        assert callable(ar.render_tasks_due_today_text_fallback)


# ---------------------------------------------------------------------------
# UTC bound helpers
# ---------------------------------------------------------------------------


class TestTomorrowUtcBound:
    def test_returns_iso_zulu(self):
        out = ar._tasks_due_today_tomorrow_utc_bound()
        assert isinstance(out, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2}T00:00:00Z$", out), out

    def test_is_00_00_00(self):
        out = ar._tasks_due_today_tomorrow_utc_bound()
        assert out.endswith("T00:00:00Z")


class TestTodayUtcBound:
    def test_returns_iso_zulu(self):
        out = ar._tasks_due_today_today_utc_bound()
        assert isinstance(out, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2}T00:00:00Z$", out), out

    def test_is_00_00_00(self):
        out = ar._tasks_due_today_today_utc_bound()
        assert out.endswith("T00:00:00Z")

    def test_tomorrow_is_one_day_after_today(self):
        today = ar._tasks_due_today_today_utc_bound()[:10]
        tomorrow = ar._tasks_due_today_tomorrow_utc_bound()[:10]
        # Lexicographic comparison works for YYYY-MM-DD.
        assert tomorrow > today


# ---------------------------------------------------------------------------
# Date extraction
# ---------------------------------------------------------------------------


class TestDateOnly:
    def test_parses_iso(self):
        assert ar._tasks_due_today_date_only("2026-04-21T10:00:00Z") == "2026-04-21"

    def test_parses_date_only(self):
        assert ar._tasks_due_today_date_only("2026-04-21") == "2026-04-21"

    def test_none(self):
        assert ar._tasks_due_today_date_only(None) is None

    def test_empty(self):
        assert ar._tasks_due_today_date_only("") is None
        assert ar._tasks_due_today_date_only("   ") is None

    def test_short(self):
        assert ar._tasks_due_today_date_only("2026-04") is None

    def test_bad_delimiter(self):
        assert ar._tasks_due_today_date_only("2026/04/21") is None

    def test_non_string(self):
        assert ar._tasks_due_today_date_only(12345) is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Due date extraction (scans priority order)
# ---------------------------------------------------------------------------


class TestGetDueDate:
    def test_prefers_due_date(self):
        t = {"due_date": "2026-04-21", "due_at": "2026-04-22", "due": "2026-04-23"}
        assert ar._tasks_due_today_get_due_date(t) == "2026-04-21"

    def test_falls_through_to_due_at(self):
        t = {"due_at": "2026-04-22T10:00:00Z"}
        assert ar._tasks_due_today_get_due_date(t) == "2026-04-22"

    def test_falls_through_to_due(self):
        t = {"due": "2026-04-23"}
        assert ar._tasks_due_today_get_due_date(t) == "2026-04-23"

    def test_falls_through_to_deadline(self):
        t = {"deadline": "2026-04-24"}
        assert ar._tasks_due_today_get_due_date(t) == "2026-04-24"

    def test_returns_none_for_no_due(self):
        assert ar._tasks_due_today_get_due_date({}) is None

    def test_non_dict(self):
        assert ar._tasks_due_today_get_due_date("x") is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Is done
# ---------------------------------------------------------------------------


class TestIsDone:
    @pytest.mark.parametrize(
        "status", ["done", "completed", "complete", "closed", "resolved", "finished"]
    )
    def test_recognises_done_status(self, status):
        assert ar._tasks_due_today_is_done({"status": status}) is True

    @pytest.mark.parametrize("status", ["open", "in_progress", "pending", "todo"])
    def test_open_statuses(self, status):
        assert ar._tasks_due_today_is_done({"status": status}) is False

    def test_state_field(self):
        assert ar._tasks_due_today_is_done({"state": "completed"}) is True

    def test_case_insensitive(self):
        assert ar._tasks_due_today_is_done({"status": "DONE"}) is True
        assert ar._tasks_due_today_is_done({"status": "  Closed  "}) is True

    def test_no_status(self):
        assert ar._tasks_due_today_is_done({}) is False

    def test_non_dict(self):
        assert ar._tasks_due_today_is_done("x") is False  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Completed today
# ---------------------------------------------------------------------------


class TestCompletedToday:
    def test_detects_completed_at_today(self):
        t = {
            "status": "completed",
            "completed_at": f"{TODAY_DATE}T14:00:00Z",
        }
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is True

    def test_rejects_yesterday_completed(self):
        t = {
            "status": "completed",
            "completed_at": f"{YESTERDAY_DATE}T14:00:00Z",
        }
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is False

    def test_rejects_open_task(self):
        t = {"status": "open", "completed_at": f"{TODAY_DATE}T14:00:00Z"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is False

    def test_closed_at_field(self):
        t = {"status": "closed", "closed_at": f"{TODAY_DATE}T11:00:00Z"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is True

    def test_resolved_at_field(self):
        t = {"status": "resolved", "resolved_at": f"{TODAY_DATE}T11:00:00Z"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is True

    def test_done_at_field(self):
        t = {"status": "done", "done_at": f"{TODAY_DATE}T11:00:00Z"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is True

    def test_updated_at_fallback(self):
        t = {"status": "completed", "updated_at": f"{TODAY_DATE}T11:00:00Z"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is True

    def test_completed_but_no_timestamp(self):
        t = {"status": "completed"}
        assert ar._tasks_due_today_completed_today(t, today_bound_date=TODAY_DATE) is False


# ---------------------------------------------------------------------------
# Bucket
# ---------------------------------------------------------------------------


class TestBucket:
    def test_overdue(self):
        t = _open_task(YESTERDAY_DATE)
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "overdue"

    def test_overdue_two_days_ago(self):
        t = _open_task(TWO_DAYS_AGO_DATE)
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "overdue"

    def test_due_today(self):
        t = _open_task(TODAY_DATE)
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "due_today"

    def test_future_is_other(self):
        t = _open_task(TOMORROW_DATE)
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "other"

    def test_completed_today_takes_precedence_over_due_date(self):
        t = _completed_task(
            YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
        )
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "completed_today"

    def test_completed_yesterday_is_other(self):
        t = _completed_task(
            YESTERDAY_DATE, completed_at=f"{YESTERDAY_DATE}T10:00:00Z"
        )
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "other"

    def test_no_due_date_is_other(self):
        t = {"status": "open"}
        assert ar._tasks_due_today_bucket(t, today_bound_date=TODAY_DATE) == "other"

    def test_non_dict_is_other(self):
        assert ar._tasks_due_today_bucket("x", today_bound_date=TODAY_DATE) == "other"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Partition
# ---------------------------------------------------------------------------


class TestPartition:
    def test_partition_returns_three_keys(self):
        out = ar._tasks_due_today_partition([], today_bound_date=TODAY_DATE)
        assert set(out.keys()) == {"overdue", "due_today", "completed_today"}

    def test_partition_buckets_correctly(self):
        tasks = [
            _open_task(YESTERDAY_DATE, task_id="o1"),
            _open_task(TODAY_DATE, task_id="d1"),
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z", task_id="c1"
            ),
            _open_task(TOMORROW_DATE, task_id="f1"),  # goes into 'other' — dropped
        ]
        out = ar._tasks_due_today_partition(tasks, today_bound_date=TODAY_DATE)
        assert len(out["overdue"]) == 1
        assert out["overdue"][0]["id"] == "o1"
        assert len(out["due_today"]) == 1
        assert out["due_today"][0]["id"] == "d1"
        assert len(out["completed_today"]) == 1
        assert out["completed_today"][0]["id"] == "c1"

    def test_partition_non_list(self):
        out = ar._tasks_due_today_partition(None, today_bound_date=TODAY_DATE)
        assert out == {"overdue": [], "due_today": [], "completed_today": []}

    def test_partition_skips_non_dicts(self):
        out = ar._tasks_due_today_partition(
            [None, "x", _open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )  # type: ignore[list-item]
        assert len(out["due_today"]) == 1


# ---------------------------------------------------------------------------
# Priority label
# ---------------------------------------------------------------------------


class TestPriorityLabel:
    def test_urgent(self):
        assert ar._tasks_due_today_priority_label({"priority": "urgent"}) == "Urgent"

    def test_high(self):
        assert ar._tasks_due_today_priority_label({"priority": "high"}) == "High"

    def test_medium(self):
        assert ar._tasks_due_today_priority_label({"priority": "medium"}) == "Medium"

    def test_normal_default(self):
        assert ar._tasks_due_today_priority_label({}) == "Normal"

    def test_low(self):
        assert ar._tasks_due_today_priority_label({"priority": "low"}) == "Low"

    def test_unknown_title_cased(self):
        assert ar._tasks_due_today_priority_label({"priority": "critical"}) == "Critical"

    def test_case_insensitive_lookup(self):
        assert ar._tasks_due_today_priority_label({"priority": "URGENT"}) == "Urgent"

    def test_non_string(self):
        assert ar._tasks_due_today_priority_label({"priority": 5}) == "Normal"

    def test_non_dict(self):
        assert ar._tasks_due_today_priority_label("x") == "Normal"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Unique assignees
# ---------------------------------------------------------------------------


class TestUniqueAssignees:
    def test_counts_unique(self):
        tasks = [
            {"assignee_id": "u1"}, {"assignee_id": "u2"}, {"assignee_id": "u1"},
        ]
        assert ar._tasks_due_today_unique_assignees(tasks) == 2

    def test_case_insensitive(self):
        tasks = [{"assignee_id": "U1"}, {"assignee_id": "u1"}]
        assert ar._tasks_due_today_unique_assignees(tasks) == 1

    def test_honors_owner_id_fallback(self):
        tasks = [{"owner_id": "u1"}, {"assigned_to": "u2"}]
        assert ar._tasks_due_today_unique_assignees(tasks) == 2

    def test_skips_none_and_zero(self):
        tasks = [{"assignee_id": None}, {"assignee_id": 0}]
        assert ar._tasks_due_today_unique_assignees(tasks) == 0

    def test_empty(self):
        assert ar._tasks_due_today_unique_assignees([]) == 0


# ---------------------------------------------------------------------------
# Sort band
# ---------------------------------------------------------------------------


class TestSortBand:
    def test_overdue_oldest_first(self):
        tasks = [
            _open_task(YESTERDAY_DATE, task_id="a"),
            _open_task(TWO_DAYS_AGO_DATE, task_id="b"),
        ]
        out = ar._tasks_due_today_sort_band(tasks, "overdue")
        assert out[0]["id"] == "b"
        assert out[1]["id"] == "a"

    def test_due_today_priority_ordered(self):
        tasks = [
            _open_task(TODAY_DATE, priority="low", task_id="l"),
            _open_task(TODAY_DATE, priority="urgent", task_id="u"),
            _open_task(TODAY_DATE, priority="medium", task_id="m"),
            _open_task(TODAY_DATE, priority="high", task_id="h"),
        ]
        out = ar._tasks_due_today_sort_band(tasks, "due_today")
        ids = [t["id"] for t in out]
        assert ids == ["u", "h", "m", "l"]

    def test_due_today_unknown_priority_defaults_mid(self):
        tasks = [
            _open_task(TODAY_DATE, priority="urgent", task_id="u"),
            _open_task(TODAY_DATE, priority="weird", task_id="w"),
            _open_task(TODAY_DATE, priority="low", task_id="l"),
        ]
        out = ar._tasks_due_today_sort_band(tasks, "due_today")
        ids = [t["id"] for t in out]
        # 'weird' -> rank 3 (normal), 'low' -> 4, 'urgent' -> 0
        assert ids[0] == "u"
        assert ids[-1] == "l"

    def test_completed_today_most_recent_first(self):
        tasks = [
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T09:00:00Z", task_id="early"
            ),
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T15:00:00Z", task_id="late"
            ),
        ]
        out = ar._tasks_due_today_sort_band(tasks, "completed_today")
        assert out[0]["id"] == "late"
        assert out[1]["id"] == "early"

    def test_unknown_band_passthrough(self):
        tasks = [{"id": "x"}, {"id": "y"}]
        out = ar._tasks_due_today_sort_band(tasks, "whatever")
        assert out == tasks


# ---------------------------------------------------------------------------
# Stats row
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_total_overdue_due_today_completed_today(self):
        """LOCK: the 4-card stats signature for tasks/due-today."""
        partitioned = {
            "overdue": [_open_task(YESTERDAY_DATE)],
            "due_today": [_open_task(TODAY_DATE)],
            "completed_today": [
                _completed_task(
                    YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
                )
            ],
        }
        html_out = ar._tasks_due_today_stats_row_html(partitioned)
        assert "Total in window" in html_out
        assert "Overdue" in html_out
        assert "Due today" in html_out
        assert "Completed today" in html_out

    def test_total_computes_sum(self):
        partitioned = {
            "overdue": [_open_task(YESTERDAY_DATE)] * 2,
            "due_today": [_open_task(TODAY_DATE)] * 3,
            "completed_today": [
                _completed_task(
                    YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
                )
            ],
        }
        html_out = ar._tasks_due_today_stats_row_html(partitioned)
        assert ">6<" in html_out

    def test_empty_shows_zeros(self):
        html_out = ar._tasks_due_today_stats_row_html(
            {"overdue": [], "due_today": [], "completed_today": []}
        )
        assert ">0<" in html_out

    def test_has_4_cards(self):
        html_out = ar._tasks_due_today_stats_row_html(
            {"overdue": [], "due_today": [], "completed_today": []}
        )
        # Four card <div style="flex:1..."> blocks.
        assert html_out.count("flex:1;min-width:140px") == 4

    def test_overdue_accent_uses_warning_fg(self):
        html_out = ar._tasks_due_today_stats_row_html(
            {
                "overdue": [_open_task(YESTERDAY_DATE)],
                "due_today": [],
                "completed_today": [],
            }
        )
        assert ar._G8_WARNING_FG in html_out

    def test_completed_accent_uses_positive_fg(self):
        html_out = ar._tasks_due_today_stats_row_html(
            {
                "overdue": [],
                "due_today": [],
                "completed_today": [
                    _completed_task(
                        YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
                    )
                ],
            }
        )
        assert ar._G8_POSITIVE_FG in html_out


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


class TestHeader:
    def test_singular(self):
        html_out = ar._tasks_due_today_header_html(1)
        assert "1 task" in html_out

    def test_plural(self):
        html_out = ar._tasks_due_today_header_html(5)
        assert "5 tasks" in html_out

    def test_zero_uses_plural(self):
        html_out = ar._tasks_due_today_header_html(0)
        assert "0 tasks" in html_out

    def test_has_temporal_scope_chip(self):
        html_out = ar._tasks_due_today_header_html(3)
        assert "TEMPORAL SCOPE" in html_out

    def test_title_present(self):
        assert "Tasks due today" in ar._tasks_due_today_header_html(0)


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------


class TestRow:
    def test_renders_title(self):
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE, title="Follow up with Acme"), "due_today"
        )
        assert "Follow up with Acme" in row

    def test_renders_priority(self):
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE, priority="urgent"), "due_today"
        )
        assert "Urgent" in row

    def test_renders_due_date(self):
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE), "due_today"
        )
        assert TODAY_DATE in row

    def test_overdue_uses_warning_palette(self):
        row = ar._tasks_due_today_row_html(
            _open_task(YESTERDAY_DATE), "overdue"
        )
        assert ar._G8_WARNING_BG in row
        assert "overdue" in row

    def test_due_today_uses_accent_palette(self):
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE), "due_today"
        )
        assert ar._G8_ACCENT_BG in row

    def test_completed_uses_positive_palette(self):
        row = ar._tasks_due_today_row_html(
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
            ),
            "completed_today",
        )
        assert ar._G8_POSITIVE_BG in row

    def test_completed_has_strike_through(self):
        row = ar._tasks_due_today_row_html(
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
            ),
            "completed_today",
        )
        assert "line-through" in row

    def test_untitled_fallback(self):
        row = ar._tasks_due_today_row_html(
            {"priority": "normal", "status": "open", "due_date": TODAY_DATE},
            "due_today",
        )
        assert "untitled" in row.lower()

    def test_name_field_fallback(self):
        row = ar._tasks_due_today_row_html(
            {"name": "named task", "priority": "normal", "status": "open",
             "due_date": TODAY_DATE},
            "due_today",
        )
        assert "named task" in row

    def test_subject_field_fallback(self):
        row = ar._tasks_due_today_row_html(
            {"subject": "subject task", "priority": "normal", "status": "open",
             "due_date": TODAY_DATE},
            "due_today",
        )
        assert "subject task" in row

    def test_xss_escaped(self):
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE, title="<script>alert(1)</script>"),
            "due_today",
        )
        assert "<script>" not in row
        assert "&lt;script&gt;" in row

    def test_non_dict_returns_empty(self):
        assert ar._tasks_due_today_row_html("x", "due_today") == ""  # type: ignore[arg-type]

    def test_title_capped(self):
        long_title = "x" * 500
        row = ar._tasks_due_today_row_html(
            _open_task(TODAY_DATE, title=long_title), "due_today"
        )
        # Cap at 200 chars.
        assert "x" * 201 not in row


# ---------------------------------------------------------------------------
# Band section
# ---------------------------------------------------------------------------


class TestBandSection:
    def test_renders_items(self):
        items = [_open_task(TODAY_DATE, title="T1"), _open_task(TODAY_DATE, title="T2")]
        out = ar._tasks_due_today_band_section_html("due_today", items)
        assert "T1" in out
        assert "T2" in out

    def test_header_label_overdue(self):
        out = ar._tasks_due_today_band_section_html(
            "overdue", [_open_task(YESTERDAY_DATE)]
        )
        assert "Overdue" in out

    def test_header_label_due_today(self):
        out = ar._tasks_due_today_band_section_html(
            "due_today", [_open_task(TODAY_DATE)]
        )
        assert "Due today" in out

    def test_header_label_completed_today(self):
        out = ar._tasks_due_today_band_section_html(
            "completed_today",
            [_completed_task(YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z")],
        )
        assert "Completed today" in out

    def test_empty_returns_empty_string(self):
        assert ar._tasks_due_today_band_section_html("due_today", []) == ""

    def test_cap_40(self):
        items = [_open_task(TODAY_DATE, task_id=f"t{i}") for i in range(45)]
        out = ar._tasks_due_today_band_section_html("due_today", items, cap=40)
        # Overflow copy must mention the overflow count.
        assert "5 more omitted" in out

    def test_count_badge(self):
        items = [_open_task(TODAY_DATE) for _ in range(7)]
        out = ar._tasks_due_today_band_section_html("due_today", items)
        assert "(7)" in out


# ---------------------------------------------------------------------------
# Drill-up
# ---------------------------------------------------------------------------


class TestDrillUp:
    def test_contains_5_pointers(self):
        out = ar._tasks_due_today_drill_up_html()
        assert "g8://tasks/dashboard" in out
        assert "g8://tasks/status/open" in out
        assert "g8://tasks/priority/urgent" in out
        assert "g8://activities/today" in out
        assert "g8://copilot/home" in out

    def test_related_surfaces_heading(self):
        out = ar._tasks_due_today_drill_up_html()
        assert "Related surfaces" in out


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_renders_zero_message(self):
        out = ar._tasks_due_today_empty_state_html()
        assert "Nothing due today" in out

    def test_mentions_utc_reset(self):
        out = ar._tasks_due_today_empty_state_html()
        assert "UTC" in out

    def test_points_to_dashboard(self):
        out = ar._tasks_due_today_empty_state_html()
        assert "g8://tasks/dashboard" in out


# ---------------------------------------------------------------------------
# render_tasks_due_today_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_renders_total_count(self):
        tasks = [
            _open_task(YESTERDAY_DATE, title="o1", task_id="o1"),
            _open_task(TODAY_DATE, title="d1", task_id="d1"),
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z",
                title="c1", task_id="c1",
            ),
        ]
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "o1" in out
        assert "d1" in out
        assert "c1" in out

    def test_sorts_due_today_by_priority(self):
        """LOCK: due_today band priority-ordered (urgent first)."""
        tasks = [
            _open_task(TODAY_DATE, title="lowP", priority="low", task_id="l"),
            _open_task(TODAY_DATE, title="urgP", priority="urgent", task_id="u"),
        ]
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        # urgP should appear before lowP in the output.
        assert out.index("urgP") < out.index("lowP")

    def test_empty_tasks_shows_empty_state(self):
        out = ar.render_tasks_due_today_html(tasks=[], today_bound_date=TODAY_DATE)
        assert "Nothing due today" in out

    def test_none_tasks_shows_empty_state(self):
        out = ar.render_tasks_due_today_html(tasks=None, today_bound_date=TODAY_DATE)
        assert "Nothing due today" in out

    def test_future_tasks_filtered_out(self):
        tasks = [_open_task(TOMORROW_DATE, title="future_task")]
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        # future tasks are 'other' and dropped from rendering.
        assert "future_task" not in out

    def test_completed_yesterday_filtered_out(self):
        tasks = [
            _completed_task(
                YESTERDAY_DATE, completed_at=f"{YESTERDAY_DATE}T10:00:00Z",
                title="yesterdone",
            )
        ]
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "yesterdone" not in out


# ---------------------------------------------------------------------------
# HTML structure
# ---------------------------------------------------------------------------


class TestRenderHtmlStructure:
    def test_doctype(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert out.startswith("<!doctype html>")

    def test_closed_html(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert out.rstrip().endswith("</html>")

    def test_title(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert "<title>Tasks due today</title>" in out

    def test_includes_header(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )
        assert "Tasks due today" in out

    def test_includes_drill_up(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )
        assert "g8://tasks/dashboard" in out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_has_h1(self):
        out = ar.render_tasks_due_today_text_fallback(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert out.startswith("# Tasks due today")

    def test_empty_state(self):
        out = ar.render_tasks_due_today_text_fallback(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert "Nothing due today" in out

    def test_non_empty_includes_stats(self):
        tasks = [_open_task(TODAY_DATE, title="T")]
        out = ar.render_tasks_due_today_text_fallback(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "Total in window" in out
        assert "Overdue" in out
        assert "Due today" in out
        assert "Completed today" in out

    def test_lists_tasks(self):
        tasks = [_open_task(TODAY_DATE, title="show me")]
        out = ar.render_tasks_due_today_text_fallback(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "show me" in out

    def test_includes_backend_filter_hint(self):
        tasks = [_open_task(TODAY_DATE, title="x")]
        out = ar.render_tasks_due_today_text_fallback(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "due_before" in out

    def test_related_surfaces(self):
        out = ar.render_tasks_due_today_text_fallback(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert "g8://tasks/dashboard" in out
        assert "g8://activities/today" in out
        assert "g8://copilot/home" in out

    def test_none_tasks(self):
        out = ar.render_tasks_due_today_text_fallback(
            tasks=None, today_bound_date=TODAY_DATE
        )
        assert "Nothing due today" in out


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    def test_no_banned_studio_hexes(self):
        out = ar.render_tasks_due_today_html(
            tasks=[
                _open_task(YESTERDAY_DATE),
                _open_task(TODAY_DATE),
                _completed_task(
                    YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
                ),
            ],
            today_bound_date=TODAY_DATE,
        )
        for banned in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert banned not in out, f"banned hex {banned} leaked"

    def test_primary_purple_used(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )
        assert ar._G8_PRIMARY in out

    def test_aeonik_font(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert "Aeonik" in out

    def test_border_token(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert ar._G8_BORDER in out

    def test_warning_bg_used_for_overdue(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(YESTERDAY_DATE)], today_bound_date=TODAY_DATE
        )
        assert ar._G8_WARNING_BG in out

    def test_positive_bg_used_for_completed(self):
        out = ar.render_tasks_due_today_html(
            tasks=[
                _completed_task(
                    YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z"
                )
            ],
            today_bound_date=TODAY_DATE,
        )
        assert ar._G8_POSITIVE_BG in out


# ---------------------------------------------------------------------------
# No JS
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tag(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )
        assert "<script" not in out.lower()

    def test_no_event_handlers(self):
        out = ar.render_tasks_due_today_html(
            tasks=[_open_task(TODAY_DATE)], today_bound_date=TODAY_DATE
        )
        for attr in (" onclick=", " onload=", " onerror=", " onmouseover="):
            assert attr not in out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize(
        "priority", ["urgent", "high", "medium", "normal", "low", "critical", None]
    )
    def test_html_renders_for_each_priority(self, priority):
        task = {"title": f"p-{priority}", "status": "open", "due_date": TODAY_DATE}
        if priority is not None:
            task["priority"] = priority
        out = ar.render_tasks_due_today_html(
            tasks=[task], today_bound_date=TODAY_DATE
        )
        assert f"p-{priority}" in out

    @pytest.mark.parametrize(
        "priority", ["urgent", "high", "medium", "normal", "low", "critical", None]
    )
    def test_text_renders_for_each_priority(self, priority):
        task = {"title": f"p-{priority}", "status": "open", "due_date": TODAY_DATE}
        if priority is not None:
            task["priority"] = priority
        out = ar.render_tasks_due_today_text_fallback(
            tasks=[task], today_bound_date=TODAY_DATE
        )
        assert f"p-{priority}" in out

    def test_handles_full_mix(self):
        tasks = []
        for i in range(15):
            tasks.append(_open_task(YESTERDAY_DATE, task_id=f"o{i}", title=f"over{i}"))
        for i in range(20):
            tasks.append(_open_task(TODAY_DATE, task_id=f"d{i}", title=f"due{i}"))
        for i in range(10):
            tasks.append(
                _completed_task(
                    YESTERDAY_DATE, completed_at=f"{TODAY_DATE}T10:00:00Z",
                    task_id=f"c{i}", title=f"comp{i}",
                )
            )
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        assert "over0" in out
        assert "due0" in out
        assert "comp0" in out

    def test_handles_overflow(self):
        tasks = [
            _open_task(TODAY_DATE, task_id=f"t{i}", title=f"task{i}")
            for i in range(45)
        ]
        out = ar.render_tasks_due_today_html(
            tasks=tasks, today_bound_date=TODAY_DATE
        )
        # Should cap at 40 and show overflow copy.
        assert "5 more omitted" in out


# ---------------------------------------------------------------------------
# Return types
# ---------------------------------------------------------------------------


class TestReturnTypes:
    def test_html_returns_str(self):
        out = ar.render_tasks_due_today_html(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert isinstance(out, str)

    def test_text_returns_str(self):
        out = ar.render_tasks_due_today_text_fallback(
            tasks=[], today_bound_date=TODAY_DATE
        )
        assert isinstance(out, str)

    def test_partition_returns_dict(self):
        out = ar._tasks_due_today_partition([], today_bound_date=TODAY_DATE)
        assert isinstance(out, dict)

    def test_sort_band_returns_list(self):
        out = ar._tasks_due_today_sort_band([], "due_today")
        assert isinstance(out, list)
