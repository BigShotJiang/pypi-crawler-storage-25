"""
Unit tests for Surface #54 — per-repo tracking streams listing renderer.

Surface #54 renders the Flow API stream list available to a single repo at
`g8://repos/{repo_id}/streams` (+ `.txt`). 4-segment template, sibling to
`/overview` (surface #32) and `/install` (surface #49), cousin to the
org-level `/snippet/install` (surface #52).

Backend: `GET /repos/{repo_id}/streams` → list of stream dicts
`{id, name, domains, write_key}`.

Coverage:
- Helpers (_repo_stream_clip, _repo_stream_id_display,
  _repo_stream_name_display, _repo_stream_domains_list,
  _repo_stream_write_key_preview, _repo_stream_has_write_key,
  _repo_stream_stat_card, _repo_stream_status_chip,
  _repo_stream_domain_chip, _repo_stream_write_key_mono)
- Empty-state (unavailable / no_streams modes)
- render_repo_streams_html (None → unavailable, empty list → no_streams,
  full streams list → rich HTML)
- render_repo_streams_text_fallback (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (pre-graph8 palette)
    - Drill-up block points at sibling surfaces, not self
    - Overflow capped at _MAX_REPO_STREAMS_RENDERED
    - Domain chips capped at _MAX_REPO_STREAM_DOMAIN_CHIPS
    - XSS escape on user-controlled fields (name, id, domains, write_key)
    - Status + stat card palette return expected graph8 tokens
    - Manage block does not reference self URI
"""

from __future__ import annotations

import re

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_MUTED_BG,
    _G8_POSITIVE_FG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_FG,
    _MAX_REPO_STREAMS_RENDERED,
    _MAX_REPO_STREAM_DOMAIN_CHIPS,
    _MAX_REPO_STREAM_WRITE_KEY_PREVIEW,
    _render_repo_streams_empty_state_html,
    _repo_stream_clip,
    _repo_stream_domain_chip,
    _repo_stream_domains_list,
    _repo_stream_has_write_key,
    _repo_stream_id_display,
    _repo_stream_name_display,
    _repo_stream_stat_card,
    _repo_stream_status_chip,
    _repo_stream_write_key_mono,
    _repo_stream_write_key_preview,
    render_repo_streams_html,
    render_repo_streams_text_fallback,
)


# -----------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------

REPO_ID = "11111111-2222-3333-4444-555555555555"

SAMPLE_STREAMS = [
    {
        "id": "stream_abc123",
        "name": "graph8.com",
        "domains": ["graph8.com", "www.graph8.com"],
        "write_key": "wk_live_abcdef01234567890abcdef01234567",
    },
    {
        "id": "stream_def456",
        "name": "heyreach-graph8",
        "domains": ["heyreach.graph8.com"],
        "write_key": "wk_live_ZZZZZZZZ",
    },
    {
        "id": "stream_no_key",
        "name": "new-site",
        "domains": ["newsite.example.com"],
        "write_key": None,
    },
]


_LEGACY_ACCENT_HEXES = (
    "#6366f1",
    "#4f46e5",
    "#10b981",
    "#ec4899",
    "#dc2626",
    "#16a34a",
)


# -----------------------------------------------------------------------
# TestClip
# -----------------------------------------------------------------------


class TestClip:
    def test_empty_string_returns_empty(self):
        assert _repo_stream_clip("", 50) == ""

    def test_whitespace_only_returns_empty(self):
        assert _repo_stream_clip("   \t\n", 50) == ""

    def test_none_returns_empty(self):
        assert _repo_stream_clip(None, 50) == ""

    def test_non_string_coerced_to_str(self):
        assert _repo_stream_clip(123, 50) == "123"

    def test_short_passthrough(self):
        assert _repo_stream_clip("hello", 50) == "hello"

    def test_clips_long(self):
        s = "x" * 120
        out = _repo_stream_clip(s, 20)
        assert out.endswith("…")
        assert len(out) == 20


# -----------------------------------------------------------------------
# TestIdDisplay
# -----------------------------------------------------------------------


class TestIdDisplay:
    def test_basic(self):
        assert _repo_stream_id_display("abc") == "abc"

    def test_none_returns_unknown(self):
        assert _repo_stream_id_display(None) == "(unknown)"

    def test_empty_returns_unknown(self):
        assert _repo_stream_id_display("") == "(unknown)"

    def test_whitespace_returns_unknown(self):
        assert _repo_stream_id_display("   ") == "(unknown)"

    def test_long_id_clipped(self):
        out = _repo_stream_id_display("a" * 500)
        assert out.endswith("…")


# -----------------------------------------------------------------------
# TestNameDisplay
# -----------------------------------------------------------------------


class TestNameDisplay:
    def test_explicit_name_wins(self):
        s = {"name": "MainSite", "domains": ["x.com"], "id": "s1"}
        assert _repo_stream_name_display(s) == "MainSite"

    def test_first_domain_when_no_name(self):
        s = {"name": None, "domains": ["one.com", "two.com"], "id": "s1"}
        assert _repo_stream_name_display(s) == "one.com"

    def test_id_when_no_name_no_domains(self):
        s = {"name": None, "domains": [], "id": "fallback_id"}
        assert _repo_stream_name_display(s) == "fallback_id"

    def test_unnamed_when_all_missing(self):
        assert _repo_stream_name_display({}) == "(unnamed)"

    def test_non_dict_returns_unnamed(self):
        assert _repo_stream_name_display(None) == "(unnamed)"
        assert _repo_stream_name_display("not a dict") == "(unnamed)"
        assert _repo_stream_name_display(123) == "(unnamed)"

    def test_whitespace_name_falls_through_to_domain(self):
        s = {"name": "   ", "domains": ["domain.com"]}
        assert _repo_stream_name_display(s) == "domain.com"


# -----------------------------------------------------------------------
# TestDomainsList
# -----------------------------------------------------------------------


class TestDomainsList:
    def test_basic(self):
        out = _repo_stream_domains_list(["a.com", "b.com"])
        assert out == ["a.com", "b.com"]

    def test_dedupe_preserves_order(self):
        out = _repo_stream_domains_list(["a.com", "b.com", "a.com"])
        assert out == ["a.com", "b.com"]

    def test_strips_whitespace(self):
        out = _repo_stream_domains_list(["  a.com  "])
        assert out == ["a.com"]

    def test_drops_empty_and_non_string(self):
        out = _repo_stream_domains_list(["a.com", "", None, 123, "b.com"])
        assert out == ["a.com", "b.com"]

    def test_non_list_returns_empty(self):
        assert _repo_stream_domains_list(None) == []
        assert _repo_stream_domains_list("a.com") == []
        assert _repo_stream_domains_list({"a": 1}) == []

    def test_clips_very_long_domain(self):
        long_d = "x" * 500
        out = _repo_stream_domains_list([long_d])
        assert len(out[0]) <= 100


# -----------------------------------------------------------------------
# TestWriteKeyPreview
# -----------------------------------------------------------------------


class TestWriteKeyPreview:
    def test_short_key_passes_through(self):
        assert _repo_stream_write_key_preview("wk_short") == "wk_short"

    def test_exact_at_threshold_no_ellipsis(self):
        k = "a" * _MAX_REPO_STREAM_WRITE_KEY_PREVIEW
        assert _repo_stream_write_key_preview(k) == k

    def test_long_key_truncated_with_ellipsis(self):
        k = "wk_live_abcdefghijklmnop_supersecret"
        out = _repo_stream_write_key_preview(k)
        assert out.endswith("…")
        assert len(out) == _MAX_REPO_STREAM_WRITE_KEY_PREVIEW + 1

    def test_none_returns_empty(self):
        assert _repo_stream_write_key_preview(None) == ""

    def test_non_str_returns_empty(self):
        assert _repo_stream_write_key_preview(123) == ""
        assert _repo_stream_write_key_preview([]) == ""

    def test_whitespace_returns_empty(self):
        assert _repo_stream_write_key_preview("   ") == ""


# -----------------------------------------------------------------------
# TestHasWriteKey
# -----------------------------------------------------------------------


class TestHasWriteKey:
    def test_present(self):
        assert _repo_stream_has_write_key({"write_key": "wk_abc"}) is True

    def test_none(self):
        assert _repo_stream_has_write_key({"write_key": None}) is False

    def test_empty(self):
        assert _repo_stream_has_write_key({"write_key": ""}) is False

    def test_whitespace(self):
        assert _repo_stream_has_write_key({"write_key": "   "}) is False

    def test_missing(self):
        assert _repo_stream_has_write_key({}) is False

    def test_non_str(self):
        assert _repo_stream_has_write_key({"write_key": 123}) is False

    def test_non_dict(self):
        assert _repo_stream_has_write_key(None) is False
        assert _repo_stream_has_write_key("not a dict") is False


# -----------------------------------------------------------------------
# TestStatCard
# -----------------------------------------------------------------------


class TestStatCard:
    def test_text_accent_default(self):
        out = _repo_stream_stat_card("Streams", "3")
        assert "Streams" in out
        assert ">3<" in out
        assert _G8_TEXT in out

    def test_primary_accent(self):
        out = _repo_stream_stat_card("Total", "5", accent="primary")
        assert _G8_PRIMARY in out

    def test_positive_accent(self):
        out = _repo_stream_stat_card("With key", "2", accent="positive")
        assert _G8_POSITIVE_FG in out

    def test_warning_accent(self):
        out = _repo_stream_stat_card("Missing", "1", accent="warning")
        assert _G8_WARNING_FG in out

    def test_unknown_accent_falls_back_to_text(self):
        out = _repo_stream_stat_card("X", "0", accent="bogus")
        assert _G8_TEXT in out

    def test_escapes_label_and_value(self):
        out = _repo_stream_stat_card("<script>", "<alert>")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out
        assert "&lt;alert&gt;" in out

    def test_no_single_side_colored_accent_border(self):
        """graph8 design rule: no one-side colored borders (AI-tell)."""
        out = _repo_stream_stat_card("X", "1", accent="primary")
        # The card uses a uniform 1px all-sides border, no border-left/right/top/bottom
        # with a colored value.
        assert "border-left:" not in out
        assert "border-right:" not in out
        assert "border-top:" not in out
        assert "border-bottom:" not in out

    def test_uses_graph8_tokens_only(self):
        out = _repo_stream_stat_card("X", "1")
        for hx in _LEGACY_ACCENT_HEXES:
            assert hx not in out.lower()


# -----------------------------------------------------------------------
# TestStatusChip
# -----------------------------------------------------------------------


class TestStatusChip:
    def test_has_key_shows_key(self):
        out = _repo_stream_status_chip(True)
        assert "KEY" in out
        assert _G8_POSITIVE_FG in out

    def test_no_key_shows_no_key(self):
        out = _repo_stream_status_chip(False)
        assert "NO KEY" in out
        assert _G8_TEXT_MUTED in out

    def test_pill_structure(self):
        out = _repo_stream_status_chip(True)
        assert "border-radius" in out
        assert "padding" in out


# -----------------------------------------------------------------------
# TestDomainChip
# -----------------------------------------------------------------------


class TestDomainChip:
    def test_renders_domain(self):
        out = _repo_stream_domain_chip("acme.com")
        assert "acme.com" in out

    def test_escapes_html(self):
        out = _repo_stream_domain_chip("<script>evil</script>")
        assert "<script>" not in out
        assert "&lt;script" in out

    def test_uses_monospace(self):
        out = _repo_stream_domain_chip("x.com")
        assert "monospace" in out.lower()


# -----------------------------------------------------------------------
# TestWriteKeyMono
# -----------------------------------------------------------------------


class TestWriteKeyMono:
    def test_preview_rendered(self):
        out = _repo_stream_write_key_mono("wk_live_abc…")
        assert "wk_live_abc" in out
        assert _G8_PRIMARY in out

    def test_empty_shows_muted_hint(self):
        out = _repo_stream_write_key_mono("")
        assert "no write key" in out.lower()
        assert _G8_TEXT_MUTED in out

    def test_escapes_preview(self):
        out = _repo_stream_write_key_mono("<script>x</script>")
        assert "<script>" not in out
        assert "&lt;script" in out


# -----------------------------------------------------------------------
# TestEmptyState
# -----------------------------------------------------------------------


class TestEmptyState:
    def test_unavailable_mode(self):
        html_out = _render_repo_streams_empty_state_html(REPO_ID, "unavailable")
        assert "not available" in html_out.lower()
        assert REPO_ID in html_out
        assert _G8_TEXT_MUTED in html_out

    def test_no_streams_mode(self):
        html_out = _render_repo_streams_empty_state_html(REPO_ID, "no_streams")
        assert "no tracking streams" in html_out.lower()
        assert _G8_PRIMARY in html_out
        assert _G8_ACCENT_BG in html_out

    def test_mode_fallback_to_unavailable(self):
        """Unknown mode should render as unavailable."""
        html_out = _render_repo_streams_empty_state_html(REPO_ID, "bogus")
        assert "not available" in html_out.lower()

    def test_escapes_repo_id_in_empty_state(self):
        html_out = _render_repo_streams_empty_state_html("<script>x</script>", "no_streams")
        assert "<script>" not in html_out
        assert "&lt;script" in html_out


# -----------------------------------------------------------------------
# TestRenderHtml
# -----------------------------------------------------------------------


class TestRenderHtml:
    def test_none_streams_returns_unavailable_empty_state(self):
        out = render_repo_streams_html(repo_id=REPO_ID, streams=None)
        assert "not available" in out.lower()

    def test_non_list_streams_returns_unavailable(self):
        out = render_repo_streams_html(repo_id=REPO_ID, streams="not-a-list")
        assert "not available" in out.lower()

    def test_empty_list_returns_no_streams_empty_state(self):
        out = render_repo_streams_html(repo_id=REPO_ID, streams=[])
        assert "no tracking streams" in out.lower()

    def test_list_of_non_dicts_returns_no_streams(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=["not-a-dict", None, 123]
        )
        assert "no tracking streams" in out.lower()

    def test_full_render_contains_stream_names(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "graph8.com" in out
        assert "heyreach-graph8" in out
        assert "new-site" in out

    def test_full_render_contains_stat_grid(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        # 3 streams total, 2 with key, 1 without key, 3 distinct domains
        assert ">3<" in out  # streams count or domain count
        assert "With write key" in out
        assert "Missing key" in out

    def test_repo_label_in_header(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID,
            streams=SAMPLE_STREAMS,
            repo_label="acme/website",
        )
        assert "acme/website" in out

    def test_default_header_when_no_label(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert f"Repo #{REPO_ID}" in out

    def test_status_chip_rendered_per_stream(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert out.count("KEY") >= 2  # two chips should show "KEY"
        assert "NO KEY" in out

    def test_domains_rendered_for_each_stream(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "graph8.com" in out
        assert "www.graph8.com" in out
        assert "heyreach.graph8.com" in out
        assert "newsite.example.com" in out

    def test_write_key_preview_rendered(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        # First 16 chars of the first stream's key
        assert "wk_live_abcdef01" in out

    def test_stream_without_key_shows_hint(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "no write key" in out.lower()

    def test_overflow_caps_at_max_rendered(self):
        many = [
            {
                "id": f"s_{i}",
                "name": f"site_{i}",
                "domains": [f"site{i}.com"],
                "write_key": f"wk_{i}",
            }
            for i in range(_MAX_REPO_STREAMS_RENDERED + 5)
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=many)
        assert f"+ 5 more streams" in out

    def test_domain_chips_capped_with_overflow_note(self):
        big_domain_stream = [
            {
                "id": "s1",
                "name": "multi-domain",
                "domains": [f"d{i}.com" for i in range(_MAX_REPO_STREAM_DOMAIN_CHIPS + 3)],
                "write_key": "wk",
            }
        ]
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=big_domain_stream
        )
        assert "+ 3 more" in out

    def test_xss_escape_name(self):
        stream = [
            {
                "id": "s1",
                "name": "<script>alert(1)</script>",
                "domains": ["x.com"],
                "write_key": "wk",
            }
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=stream)
        assert "<script>alert" not in out
        assert "&lt;script&gt;" in out

    def test_xss_escape_domain(self):
        stream = [
            {
                "id": "s1",
                "name": "ok",
                "domains": ["<img src=x onerror=1>"],
                "write_key": "wk",
            }
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=stream)
        assert "<img src=x" not in out
        assert "&lt;img" in out

    def test_xss_escape_write_key(self):
        stream = [
            {
                "id": "s1",
                "name": "ok",
                "domains": ["x.com"],
                "write_key": "<script>key</script>" + "x" * 20,
            }
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=stream)
        assert "<script>key</script>" not in out

    def test_xss_escape_id(self):
        stream = [
            {
                "id": "<script>evil</script>",
                "name": "ok",
                "domains": ["x.com"],
                "write_key": "wk",
            }
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=stream)
        assert "<script>evil</script>" not in out
        assert "&lt;script&gt;evil" in out

    def test_no_legacy_accent_hexes(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        for hx in _LEGACY_ACCENT_HEXES:
            assert hx not in out.lower(), f"found legacy hex {hx}"

    def test_no_single_side_accent_borders(self):
        """graph8 design rule: no one-side colored borders."""
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        # Search for the AI-tell pattern: border-left:3px solid <colored>,
        # border-right:4px... Any `border-<side>:` with a non-muted color
        # is a leak. Allow border-bottom with just the muted border hex.
        # Strategy: grep border-<side>: entries and assert they only use
        # the muted _G8_BORDER (#dfdfdf) token.
        patterns = re.findall(
            r"border-(left|right|top|bottom)\s*:\s*[^;\"]+",
            out,
        )
        for side_rule in patterns:
            # bare `border-bottom: 1px solid #dfdfdf` is fine
            # but `border-left: 3px solid #7d2df3` is NOT allowed
            pass  # we simply assert the more specific rule below

        # Stronger assertion — single-side colored accents use
        # border-left/right: Xpx solid <primary/positive/warning>.
        accent_borders = [
            _G8_PRIMARY,
            _G8_POSITIVE_FG,
            _G8_WARNING_FG,
            "#ca3214",
        ]
        for accent in accent_borders:
            # The specific tell: border-left or border-right with this color
            assert (
                f"border-left:3px solid {accent}" not in out.lower()
            ), f"found AI-tell accent border-left {accent}"
            assert (
                f"border-right:3px solid {accent}" not in out.lower()
            ), f"found AI-tell accent border-right {accent}"

    def test_drill_up_points_at_siblings_not_self(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert f"g8://repos/{REPO_ID}/install" in out
        assert f"g8://repos/{REPO_ID}/overview" in out
        assert "g8://repos/dashboard" in out
        assert "g8://snippet/install" in out

    def test_drill_up_does_NOT_list_self(self):
        """Regression: drill-up must not reference own surface."""
        out = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        # The manage block should not reference g8://repos/{id}/streams
        manage_start = out.find("Install this stream")
        assert manage_start >= 0
        manage_block = out[manage_start:]
        assert f"g8://repos/{REPO_ID}/streams" not in manage_block


# -----------------------------------------------------------------------
# TestTextFallback
# -----------------------------------------------------------------------


class TestTextFallback:
    def test_none_returns_unavailable_message(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=None
        )
        assert "could not fetch" in out.lower()
        assert REPO_ID in out

    def test_non_list_returns_unavailable(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams="bogus"
        )
        assert "could not fetch" in out.lower()

    def test_empty_list_returns_no_streams(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=[]
        )
        assert "no tracking streams" in out.lower()

    def test_full_render_contains_names(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "graph8.com" in out
        assert "heyreach-graph8" in out
        assert "new-site" in out

    def test_key_labels(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "[KEY]" in out
        assert "[NO KEY]" in out

    def test_stats_rendered(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "Streams: 3" in out
        assert "With write key: 2" in out
        assert "Missing key: 1" in out
        assert "Distinct domains: 4" in out

    def test_domains_listed(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "graph8.com" in out
        assert "heyreach.graph8.com" in out

    def test_write_key_preview_in_text(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "wk_live_abcdef01" in out

    def test_missing_write_key_line(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert "write key: (not available)" in out.lower()

    def test_overflow_cap(self):
        many = [
            {"id": f"s_{i}", "name": f"site_{i}", "domains": [f"s{i}.com"], "write_key": f"wk{i}"}
            for i in range(_MAX_REPO_STREAMS_RENDERED + 3)
        ]
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=many
        )
        assert "+ 3 more streams" in out

    def test_manage_block_does_not_list_self(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        manage_start = out.find("## Install this stream")
        assert manage_start >= 0
        manage_block = out[manage_start:]
        assert f"g8://repos/{REPO_ID}/streams" not in manage_block

    def test_repo_label_in_header(self):
        out = render_repo_streams_text_fallback(
            repo_id=REPO_ID,
            streams=SAMPLE_STREAMS,
            repo_label="acme/site",
        )
        assert "acme/site" in out


# -----------------------------------------------------------------------
# TestSmoke
# -----------------------------------------------------------------------


class TestSmoke:
    def test_round_trip_stability_html(self):
        """Same input → same output across repeated calls."""
        out1 = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        out2 = render_repo_streams_html(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert out1 == out2

    def test_round_trip_stability_text(self):
        out1 = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        out2 = render_repo_streams_text_fallback(
            repo_id=REPO_ID, streams=SAMPLE_STREAMS
        )
        assert out1 == out2

    def test_single_stream_does_not_crash(self):
        out = render_repo_streams_html(
            repo_id=REPO_ID,
            streams=[{"id": "s1", "name": "only", "domains": [], "write_key": "wk"}],
        )
        assert "only" in out

    def test_unusual_stream_shapes_do_not_crash(self):
        weird = [
            {},  # empty
            {"id": "x"},  # only id
            {"domains": ["x.com"]},  # only domains
            {"write_key": "wk"},  # only write_key
        ]
        out = render_repo_streams_html(repo_id=REPO_ID, streams=weird)
        # should render without raising
        assert "<html" in out.lower()
