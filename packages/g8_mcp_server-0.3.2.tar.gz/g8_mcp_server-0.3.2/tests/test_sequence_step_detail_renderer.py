"""Unit tests for Surface #71 — per-sequence-step detail renderer.

URI: g8://sequences/{sequence_id}/steps/{step_id}

Renderer contract:
- Keyword-only signature: render_sequence_step_detail_html(
    *, preview, sequence_id, step_id)
- preview=None → "preview not available" empty state
- step_id not in preview.steps → "step not found" empty state
- Successful render: header + 4-KPI row + type-specific content
  section + prev/current/next sibling strip + drill-up card
- Drill-up does NOT self-reference the same step URI
- All design tokens from frontend/app/globals.css (no legacy hexes)
- No inline JS; all user-data fields XSS-escaped
- No single-side colored accent borders on accent palette
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _step_detail_clip,
    _step_detail_find_step,
    _step_detail_format_time_interval,
    _step_detail_id_matches,
    _step_detail_sequence_label,
    _step_detail_step_list,
    _step_detail_step_type_accent,
    render_sequence_step_detail_html,
    render_sequence_step_detail_text_fallback,
)


# ---------------------------------------------------------------- fixtures ---

_SEQ_ID = "seq_8ab27791efff40deaaaa"
_STEP_ID = "step_1e7d9a2b3c4d5e6f7g8h"


def _make_preview(*, name: str = "Outbound SaaS Q2", steps: list | None = None) -> dict:
    """Build a valid preview dict with flexible steps override."""
    default_steps = [
        {
            "id": _STEP_ID,
            "step_order": 1,
            "step_type": "email",
            "input_type": "TEMPLATE",
            "time_interval": 0,
            "step_data": {
                "subject": "Quick intro - {{first_name}}",
                "body": "Hi {{first_name}},\n\nWanted to reach out.",
                "template_id": "tpl_abc123",
            },
        },
        {
            "id": "step_2",
            "step_order": 2,
            "step_type": "wait",
            "input_type": "ON_DEMAND",
            "time_interval": 172800,
            "step_data": {},
        },
        {
            "id": "step_3",
            "step_order": 3,
            "step_type": "linkedin",
            "input_type": "TEMPLATE",
            "time_interval": 86400,
            "step_data": {"message": "Saw your post about Series B — congrats!"},
        },
        {
            "id": "step_4",
            "step_order": 4,
            "step_type": "task",
            "input_type": "ON_DEMAND",
            "time_interval": 259200,
            "step_data": {"title": "Follow up", "description": "Call if no reply"},
        },
    ]
    return {
        "id": _SEQ_ID,
        "name": name,
        "status": "active",
        "description": None,
        "steps": steps if steps is not None else default_steps,
        "channels": [],
    }


# ---------------------------------------------------------------- helpers ---


class TestClip:
    def test_non_string_returns_empty(self):
        assert _step_detail_clip(None, 100) == ""
        assert _step_detail_clip(42, 100) == ""
        assert _step_detail_clip({"x": 1}, 100) == ""

    def test_strips_whitespace(self):
        assert _step_detail_clip("   hello   ", 100) == "hello"

    def test_empty_string_returns_empty(self):
        assert _step_detail_clip("", 100) == ""
        assert _step_detail_clip("   ", 100) == ""

    def test_clips_at_cap(self):
        clipped = _step_detail_clip("a" * 200, 50)
        assert len(clipped) == 50
        assert clipped.endswith("…")

    def test_passes_through_under_cap(self):
        assert _step_detail_clip("short", 100) == "short"


class TestIdMatches:
    def test_none_step_matches_anything(self):
        assert _step_detail_id_matches(None, "anything") is True

    def test_non_dict_matches(self):
        assert _step_detail_id_matches("not a dict", "anything") is True

    def test_matching_id(self):
        assert _step_detail_id_matches({"id": "s1"}, "s1") is True

    def test_non_matching_id(self):
        assert _step_detail_id_matches({"id": "s1"}, "s2") is False

    def test_missing_id_key_is_lenient(self):
        assert _step_detail_id_matches({"x": 1}, "anything") is True

    def test_id_stripped(self):
        assert _step_detail_id_matches({"id": "  s1  "}, "s1") is True


class TestFindStep:
    def test_none_preview(self):
        assert _step_detail_find_step(None, "s1") is None

    def test_missing_steps_array(self):
        assert _step_detail_find_step({"id": "seq"}, "s1") is None

    def test_non_list_steps(self):
        assert _step_detail_find_step({"steps": "not a list"}, "s1") is None

    def test_finds_matching(self):
        preview = _make_preview()
        step = _step_detail_find_step(preview, _STEP_ID)
        assert step is not None
        assert step["step_type"] == "email"

    def test_returns_none_for_missing(self):
        preview = _make_preview()
        assert _step_detail_find_step(preview, "nonexistent") is None

    def test_skips_non_dict_rows(self):
        preview = {"steps": ["bad", None, {"id": "s1", "step_type": "email"}]}
        step = _step_detail_find_step(preview, "s1")
        assert step is not None
        assert step["step_type"] == "email"

    def test_step_id_with_whitespace(self):
        preview = _make_preview()
        step = _step_detail_find_step(preview, f"  {_STEP_ID}  ")
        assert step is not None


class TestStepList:
    def test_none_preview(self):
        assert _step_detail_step_list(None) == []

    def test_missing_steps_key(self):
        assert _step_detail_step_list({"id": "seq"}) == []

    def test_filters_non_dict(self):
        lst = _step_detail_step_list({"steps": [{"id": "a"}, None, "bad", {"id": "b"}]})
        assert len(lst) == 2


class TestSequenceLabel:
    def test_name_preferred(self):
        preview = _make_preview(name="Outbound SaaS Q2")
        assert "Outbound SaaS Q2" in _step_detail_sequence_label(preview, _SEQ_ID)

    def test_falls_back_to_id(self):
        label = _step_detail_sequence_label(None, _SEQ_ID)
        assert _SEQ_ID in label
        assert "Sequence " in label

    def test_falls_back_to_generic(self):
        assert _step_detail_sequence_label(None, "") == "Sequence"

    def test_empty_name_falls_back(self):
        preview = {"name": "   "}
        label = _step_detail_sequence_label(preview, _SEQ_ID)
        assert _SEQ_ID in label

    def test_name_xss_escaped(self):
        preview = {"name": "<script>alert(1)</script>"}
        label = _step_detail_sequence_label(preview, _SEQ_ID)
        assert "<script>" not in label
        assert "&lt;script&gt;" in label

    def test_long_name_clipped(self):
        preview = {"name": "X" * 500}
        label = _step_detail_sequence_label(preview, _SEQ_ID)
        assert "…" in label


class TestStepTypeAccent:
    @pytest.mark.parametrize(
        "step_type",
        ["email", "message", "sms", "text", "linkedin", "linkedin_message"],
    )
    def test_outreach_types_get_primary(self, step_type):
        bg, fg, border = _step_detail_step_type_accent(step_type)
        assert fg == "#7d2df3"  # _G8_PRIMARY

    @pytest.mark.parametrize("step_type", ["meeting", "demo", "appointment"])
    def test_meeting_types_get_positive(self, step_type):
        bg, fg, border = _step_detail_step_type_accent(step_type)
        assert fg == "#059669"  # _G8_POSITIVE_FG

    @pytest.mark.parametrize("step_type", ["wait", "delay", "pause"])
    def test_wait_types_get_muted(self, step_type):
        bg, fg, border = _step_detail_step_type_accent(step_type)
        assert fg == "#777777"  # _G8_TEXT_MUTED

    def test_unknown_falls_back_to_muted(self):
        bg, fg, border = _step_detail_step_type_accent("something_random")
        assert fg == "#777777"

    def test_none_falls_back_to_muted(self):
        bg, fg, border = _step_detail_step_type_accent(None)
        assert fg == "#777777"


class TestFormatTimeInterval:
    def test_none_is_immediate(self):
        assert _step_detail_format_time_interval(None) == "immediate"

    def test_zero_is_immediate(self):
        assert _step_detail_format_time_interval(0) == "immediate"

    def test_bool_rejected(self):
        assert _step_detail_format_time_interval(True) == "immediate"

    def test_non_number_is_immediate(self):
        assert _step_detail_format_time_interval("45") == "immediate"

    def test_seconds(self):
        assert _step_detail_format_time_interval(30) == "30 sec"

    def test_minutes(self):
        assert _step_detail_format_time_interval(300) == "5 min"

    def test_hours_only(self):
        assert _step_detail_format_time_interval(3600) == "1h"

    def test_hours_minutes(self):
        assert _step_detail_format_time_interval(5400) == "1h 30m"

    def test_days_only(self):
        assert _step_detail_format_time_interval(86400) == "1d"

    def test_days_hours(self):
        assert _step_detail_format_time_interval(90000) == "1d 1h"

    def test_two_days(self):
        assert _step_detail_format_time_interval(172800) == "2d"


# ---------------------------------------------------------------- empty states ---


class TestEmptyStateNoPreview:
    def test_renders_doctype(self):
        out = render_sequence_step_detail_html(
            preview=None, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert out.startswith("<!DOCTYPE html>")

    def test_mentions_not_available(self):
        out = render_sequence_step_detail_html(
            preview=None, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "not available" in out.lower()

    def test_xss_escape(self):
        out = render_sequence_step_detail_html(
            preview=None, sequence_id="<s>", step_id="<id>"
        )
        assert "<s>" not in out
        assert "&lt;s&gt;" in out


class TestEmptyStateStepNotFound:
    def test_renders_not_found(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="nonexistent"
        )
        assert "not found" in out.lower()

    def test_mentions_both_ids(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="nope"
        )
        assert _SEQ_ID in out
        assert "nope" in out

    def test_suggests_preview(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="nope"
        )
        assert "preview" in out.lower()


# ---------------------------------------------------------------- render edges ---


class TestRenderHtmlEdges:
    def test_missing_steps_array_triggers_not_found(self):
        preview = {"id": _SEQ_ID, "name": "Seq"}
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "not found" in out.lower()

    def test_empty_steps_triggers_not_found(self):
        preview = _make_preview(steps=[])
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "not found" in out.lower()


# ---------------------------------------------------------------- header ---


class TestHeader:
    def test_shows_step_order_and_type(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Step 1" in out
        assert "email" in out

    def test_shows_sequence_name_in_eyebrow(self):
        preview = _make_preview(name="My Cool Sequence")
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "My Cool Sequence" in out

    def test_step_id_in_header_code_chip(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"step: {_STEP_ID}" in out

    def test_sequence_id_in_header_code_chip(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"seq: {_SEQ_ID}" in out

    def test_h1_uppercase_eyebrow(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Sequence step" in out


# ---------------------------------------------------------------- KPI stats row ---


class TestStatsRow:
    def test_order_card(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#1" in out
        assert "Order" in out

    def test_type_card(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Type" in out
        # email is the step type
        assert out.count("email") >= 1

    def test_delay_immediate(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # step 1 has time_interval=0 → immediate
        assert "immediate" in out
        assert "Delay" in out

    def test_input_type_card(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Input" in out
        assert "TEMPLATE" in out


# ---------------------------------------------------------------- content sections ---


class TestEmailContent:
    def test_renders_subject(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Quick intro" in out
        assert "Subject" in out

    def test_renders_body(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Wanted to reach out" in out
        assert "Body" in out

    def test_renders_template_chip(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "tpl_abc123" in out
        assert "template" in out.lower()

    def test_body_in_pre_block(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "<pre" in out

    def test_subject_xss_escaped(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "s1",
                    "step_order": 1,
                    "step_type": "email",
                    "input_type": "TEMPLATE",
                    "time_interval": 0,
                    "step_data": {"subject": "<script>alert(1)</script>", "body": "ok"},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="s1"
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out


class TestLinkedinContent:
    def test_renders_message(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_3"
        )
        assert "Saw your post about Series B" in out
        assert "Message" in out


class TestTaskContent:
    def test_renders_title(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_4"
        )
        assert "Follow up" in out
        assert "Title" in out

    def test_renders_description(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_4"
        )
        assert "Call if no reply" in out
        assert "Description" in out


class TestWaitContent:
    def test_renders_wait_section(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_2"
        )
        assert "Wait step" in out
        # 172800s = 2d
        assert "2d" in out


class TestGenericFallback:
    def test_unknown_step_type_uses_generic(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "sx",
                    "step_order": 1,
                    "step_type": "custom_thing",
                    "input_type": "ON_DEMAND",
                    "time_interval": 0,
                    "step_data": {"foo": "bar", "baz": 42},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="sx"
        )
        assert "Step data" in out
        assert "foo" in out
        assert "bar" in out

    def test_empty_step_data_gets_empty_message(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "sx",
                    "step_order": 1,
                    "step_type": "custom_thing",
                    "input_type": "ON_DEMAND",
                    "time_interval": 0,
                    "step_data": {},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="sx"
        )
        assert "No content stored" in out


# ---------------------------------------------------------------- sibling strip ---


class TestSiblingStrip:
    def test_shows_current_step(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "(current)" in out

    def test_shows_sequence_flow_heading(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Sequence flow" in out

    def test_shows_step_count(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "of 4" in out

    def test_shows_other_step_uris(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # At step 1, window = [step1(current), step2, step3]
        assert "step_2" in out
        assert "step_3" in out

    def test_windows_around_middle_step(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_3"
        )
        # Window: step_1, step_2, step_3(current), step_4 → 4 entries
        # At step 3 (idx 2), start=0, end=5 → all 4 shown
        assert _STEP_ID in out  # step 1 id
        assert "step_2" in out
        assert "step_4" in out
        assert "(current)" in out


# ---------------------------------------------------------------- drill-up ---


class TestDrillUp:
    def test_shows_overview_link(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"g8://sequences/{_SEQ_ID}/overview" in out

    def test_shows_preview_link(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"g8://sequences/{_SEQ_ID}/preview" in out

    def test_shows_analytics_link(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"g8://sequences/{_SEQ_ID}/analytics" in out

    def test_shows_contacts_link(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"g8://sequences/{_SEQ_ID}/contacts" in out

    def test_shows_dashboard_link(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "g8://sequences/dashboard" in out

    def test_no_self_reference(self):
        """Drill-up card must NOT contain the current step's URI."""
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # The drill-up card appears AFTER the sibling strip. In the
        # sibling strip, OTHER steps' URIs are rendered, but the
        # current step's URI is NOT rendered (it's labeled "current"
        # without a URI). Verify that URI is entirely absent.
        self_uri = f"g8://sequences/{_SEQ_ID}/steps/{_STEP_ID}"
        assert self_uri not in out

    def test_manage_heading(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Manage this sequence" in out


# ---------------------------------------------------------------- design tokens ---


class TestDesignTokens:
    def test_has_primary(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#7d2df3" in out

    def test_has_border(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#dfdfdf" in out

    def test_has_aeonik(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "Aeonik" in out

    def test_has_card_radius(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "12px" in out  # _G8_CARD_RADIUS

    def test_has_muted_bg(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#f9f9f9" in out


class TestNoLegacyHexes:
    """Reject legacy Studio hex values."""

    @pytest.mark.parametrize("bad_hex", ["#FF0000", "#00FF00", "#0000FF"])
    def test_no_saturated_legacy(self, bad_hex):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert bad_hex not in out

    def test_no_black_background(self):
        """Black #000000 would be a legacy Studio tell. Allow text-color-black (#0A0A0A)."""
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#000000" not in out

    def test_no_legacy_shadcn_neutral_bg(self):
        """Reject generic #EBEBEB / #FAFAFA neutrals."""
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "#EBEBEB" not in out
        assert "#FAFAFA" not in out


# ---------------------------------------------------------------- no JS ---


class TestNoJavaScript:
    def test_no_script_tags(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "<script" not in out.lower()

    def test_no_inline_event_handlers(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        for evt in ("onclick=", "onmouseover=", "onerror=", "onload="):
            assert evt not in out.lower()


# ---------------------------------------------------------------- no colored accent borders ---


class TestNoSingleSideColoredAccentBorder:
    def test_no_border_left_primary(self):
        """The AI-tell: border-left: 3px solid #7d2df3 — never do this."""
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # Reject border-left: Xpx solid <primary/accent color>
        import re

        pattern = re.compile(
            r"border-(left|top|right|bottom):\s*\d+px\s+solid\s+#7d2df3",
            re.IGNORECASE,
        )
        assert not pattern.search(out)


# ---------------------------------------------------------------- XSS ---


class TestXssEscape:
    def test_sequence_name_escaped(self):
        preview = _make_preview(name="<b>hack</b>")
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "<b>hack</b>" not in out
        assert "&lt;b&gt;hack&lt;/b&gt;" in out

    def test_step_id_escaped(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id="<seq>", step_id="<step>"
        )
        assert "<seq>" not in out
        assert "<step>" not in out

    def test_step_type_escaped(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "s1",
                    "step_order": 1,
                    "step_type": "<xss>",
                    "input_type": "TEMPLATE",
                    "time_interval": 0,
                    "step_data": {},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="s1"
        )
        assert "<xss>" not in out
        assert "&lt;xss&gt;" in out

    def test_task_title_escaped(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "s1",
                    "step_order": 1,
                    "step_type": "task",
                    "input_type": "ON_DEMAND",
                    "time_interval": 0,
                    "step_data": {"title": "<img src=x>", "description": "ok"},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="s1"
        )
        assert "<img src=x>" not in out

    def test_generic_step_data_value_escaped(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "s1",
                    "step_order": 1,
                    "step_type": "custom",
                    "input_type": "ON_DEMAND",
                    "time_interval": 0,
                    "step_data": {"foo": "<script>"},
                }
            ]
        )
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id="s1"
        )
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------- well-formed ---


class TestWellFormed:
    def test_has_doctype(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert out.startswith("<!DOCTYPE html>")

    def test_has_html_body_tags(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "<html>" in out
        assert "<body" in out
        assert "</body>" in out
        assert "</html>" in out


# ---------------------------------------------------------------- text fallback ---


class TestTextFallback:
    def test_none_preview_yields_not_available(self):
        txt = render_sequence_step_detail_text_fallback(
            preview=None, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "not available" in txt.lower()

    def test_step_not_found(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="nope"
        )
        assert "not found" in txt.lower()

    def test_header_with_sequence_name(self):
        preview = _make_preview(name="My Seq")
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "My Seq" in txt
        assert "Step 1" in txt
        assert "email" in txt

    def test_step_and_seq_ids(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert f"`{_SEQ_ID}`" in txt
        assert f"`{_STEP_ID}`" in txt

    def test_stats_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "## Stats" in txt
        assert "- Order:" in txt
        assert "- Type:" in txt
        assert "- Delay:" in txt
        assert "- Input:" in txt

    def test_email_subject_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "## Subject" in txt
        assert "Quick intro" in txt

    def test_email_body_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "## Body" in txt
        assert "```" in txt
        assert "Wanted to reach out" in txt

    def test_template_id_chip(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "tpl_abc123" in txt

    def test_wait_section_for_wait_step(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_2"
        )
        assert "## Wait step" in txt
        assert "2d" in txt

    def test_linkedin_message_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_3"
        )
        assert "## Message" in txt
        assert "Series B" in txt

    def test_task_title_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_4"
        )
        assert "## Title" in txt
        assert "Follow up" in txt

    def test_task_description_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="step_4"
        )
        assert "## Description" in txt
        assert "Call if no reply" in txt

    def test_sibling_flow_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "## Sequence flow" in txt
        assert "of 4" in txt
        assert "(current)" in txt

    def test_drill_up_section(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "## Manage this sequence" in txt
        assert f"g8://sequences/{_SEQ_ID}/overview" in txt
        assert f"g8://sequences/{_SEQ_ID}/preview" in txt
        assert f"g8://sequences/{_SEQ_ID}/analytics" in txt
        assert f"g8://sequences/{_SEQ_ID}/contacts" in txt
        assert "g8://sequences/dashboard" in txt

    def test_no_self_reference_in_drill_up(self):
        """The /steps/{step_id} URI for THIS step must not appear in drill-up."""
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # Drill-up starts at "## Manage this sequence"
        drill_start = txt.index("## Manage this sequence")
        drill_section = txt[drill_start:]
        assert f"/steps/{_STEP_ID}" not in drill_section

    def test_newline_terminated(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert txt.endswith("\n")

    def test_generic_step_data_rendering(self):
        preview = _make_preview(
            steps=[
                {
                    "id": "sx",
                    "step_order": 1,
                    "step_type": "custom_thing",
                    "input_type": "ON_DEMAND",
                    "time_interval": 0,
                    "step_data": {"foo": "bar"},
                }
            ]
        )
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id="sx"
        )
        assert "## Step data" in txt
        assert "foo" in txt
        assert "bar" in txt


# ---------------------------------------------------------------- smoke ---


class TestSmoke:
    def test_full_email_render(self):
        preview = _make_preview()
        out = render_sequence_step_detail_html(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        # Hit every major section at least once.
        assert "<!DOCTYPE html>" in out
        assert "Sequence step" in out
        assert "Step 1" in out
        assert "Quick intro" in out
        assert "Wanted to reach out" in out
        assert "Sequence flow" in out
        assert "Manage this sequence" in out
        assert "#7d2df3" in out  # design token
        assert "<script" not in out.lower()

    def test_full_text_render(self):
        preview = _make_preview()
        txt = render_sequence_step_detail_text_fallback(
            preview=preview, sequence_id=_SEQ_ID, step_id=_STEP_ID
        )
        assert "# Step 1: email" in txt
        assert "## Stats" in txt
        assert "## Subject" in txt
        assert "## Body" in txt
        assert "## Sequence flow" in txt
        assert "## Manage this sequence" in txt
        assert txt.endswith("\n")
