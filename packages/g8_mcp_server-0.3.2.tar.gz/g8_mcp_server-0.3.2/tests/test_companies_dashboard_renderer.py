"""Unit tests for HTML app surface #59 — companies dashboard renderer.

Locks regression invariants for:
  - graph8 design tokens (no legacy accent hexes, no single-side colored
    accent borders)
  - drill-up card does NOT self-list the dashboard URI
  - no <script> / javascript: / inline event handlers
  - pagination safety: `total >= visible` override, `total < visible`
    ignored (clamped to `len(companies)`)
  - XSS escape on every user-controlled field
  - display name fallback chain (name → domain → `(unnamed company)`)
  - employee-size bucket ladder (6 buckets, left-to-right size order)
  - size palette (large = primary tint, mid = positive, small = muted)
  - bucket helper case-insensitive grouping + first-seen casing preservation
  - smoke tests on realistic and empty payloads
"""

from __future__ import annotations

import pytest

from g8_mcp_server import app_renderer as ar

_BASE_COMPANY = {
    "id": 101,
    "name": "Acme Corporation",
    "description": "B2B SaaS for supply-chain analytics.",
    "domain": "acme.com",
    "website": "https://acme.com",
    "industry": "Software",
    "employee_count": "250",
    "revenue": "50000000",
    "founded_year": 2014,
    "city": "San Francisco",
    "state": "California",
    "country": "United States",
    "linkedin_url": "https://linkedin.com/company/acme",
    "linkedin_followers": "12000",
    "logo_url": "https://logo.com/acme.png",
}

_SAMPLE_COMPANIES: list[dict] = [
    _BASE_COMPANY,
    {
        "id": 102,
        "name": "Beta Industries",
        "description": "Mid-market manufacturing",
        "domain": "beta.io",
        "website": "https://beta.io",
        "industry": "Manufacturing",
        "employee_count": "75",
        "founded_year": 2018,
        "city": "Austin",
        "state": "Texas",
        "country": "United States",
        "linkedin_url": "https://linkedin.com/company/beta",
    },
    {
        "id": 103,
        # No `name`; will fall back to domain.
        "domain": "gamma.co",
        "website": "https://gamma.co",
        "industry": "software",  # lowercase — groups with Software via bucket key
        "employee_count": "8",
        "country": "Canada",
    },
    {
        "id": 104,
        "name": "Delta Holdings",
        # No domain, no linkedin, no industry
        "employee_count": "15000",
        "country": "United Kingdom",
    },
    {
        "id": 105,
        # No name, no domain — fully anonymous.
        "industry": "Healthcare",
    },
]


# ----------------------------------------------------------------------
# Helper tests
# ----------------------------------------------------------------------


class TestClip:
    def test_empty(self):
        assert ar._companies_dashboard_clip("", 10) == ""

    def test_whitespace(self):
        assert ar._companies_dashboard_clip("   ", 10) == ""

    def test_none(self):
        assert ar._companies_dashboard_clip(None, 10) == ""

    def test_non_string(self):
        assert ar._companies_dashboard_clip(42, 10) == ""

    def test_short(self):
        assert ar._companies_dashboard_clip("hi", 10) == "hi"

    def test_long(self):
        out = ar._companies_dashboard_clip("a" * 50, 10)
        assert out.endswith("…")
        assert len(out) == 10

    def test_html_escape(self):
        assert "&lt;script&gt;" in ar._companies_dashboard_clip("<script>", 100)


class TestDisplayName:
    def test_name(self):
        assert ar._companies_dashboard_display_name({"name": "Acme"}) == "Acme"

    def test_name_trimmed(self):
        assert ar._companies_dashboard_display_name({"name": "  Acme  "}) == "Acme"

    def test_name_escaped(self):
        out = ar._companies_dashboard_display_name({"name": "<evil>"})
        assert "&lt;" in out
        assert "<evil>" not in out

    def test_name_clipped(self):
        out = ar._companies_dashboard_display_name({"name": "a" * 200})
        assert out.endswith("…")

    def test_falls_back_to_domain(self):
        assert (
            ar._companies_dashboard_display_name({"domain": "fallback.io"})
            == "fallback.io"
        )

    def test_falls_back_to_unnamed(self):
        assert (
            ar._companies_dashboard_display_name({})
            == "(unnamed company)"
        )

    def test_falls_back_to_unnamed_on_empty_strings(self):
        assert (
            ar._companies_dashboard_display_name({"name": "  ", "domain": "   "})
            == "(unnamed company)"
        )

    def test_domain_escape(self):
        out = ar._companies_dashboard_display_name({"domain": "<xss>.com"})
        assert "&lt;" in out

    def test_name_preferred_over_domain(self):
        assert (
            ar._companies_dashboard_display_name(
                {"name": "Acme", "domain": "acme.com"}
            )
            == "Acme"
        )


class TestReachabilityFlags:
    def test_has_domain(self):
        assert ar._companies_dashboard_has_domain({"domain": "x.com"}) is True

    def test_has_domain_empty(self):
        assert ar._companies_dashboard_has_domain({"domain": ""}) is False

    def test_has_domain_whitespace(self):
        assert ar._companies_dashboard_has_domain({"domain": "   "}) is False

    def test_has_domain_non_string(self):
        assert ar._companies_dashboard_has_domain({"domain": 42}) is False

    def test_has_website(self):
        assert ar._companies_dashboard_has_website({"website": "https://x.com"}) is True

    def test_has_website_missing(self):
        assert ar._companies_dashboard_has_website({}) is False

    def test_has_linkedin(self):
        assert ar._companies_dashboard_has_linkedin({"linkedin_url": "https://x"}) is True

    def test_has_linkedin_none(self):
        assert ar._companies_dashboard_has_linkedin({"linkedin_url": None}) is False


class TestParseEmployeeCount:
    def test_int(self):
        assert ar._companies_dashboard_parse_employee_count(250) == 250

    def test_string(self):
        assert ar._companies_dashboard_parse_employee_count("250") == 250

    def test_string_whitespace(self):
        assert ar._companies_dashboard_parse_employee_count("  250  ") == 250

    def test_string_commas(self):
        assert ar._companies_dashboard_parse_employee_count("1,250") == 1250

    def test_empty_string(self):
        assert ar._companies_dashboard_parse_employee_count("") is None

    def test_none(self):
        assert ar._companies_dashboard_parse_employee_count(None) is None

    def test_invalid_string(self):
        assert ar._companies_dashboard_parse_employee_count("abc") is None

    def test_negative_dropped(self):
        assert ar._companies_dashboard_parse_employee_count(-5) is None

    def test_negative_string_dropped(self):
        assert ar._companies_dashboard_parse_employee_count("-5") is None

    def test_zero_kept(self):
        assert ar._companies_dashboard_parse_employee_count(0) == 0

    def test_bool_rejected(self):
        # Bools are int subclasses in Python — guard against treating
        # True/False as 1/0.
        assert ar._companies_dashboard_parse_employee_count(True) is None
        assert ar._companies_dashboard_parse_employee_count(False) is None

    def test_float_rejected(self):
        assert ar._companies_dashboard_parse_employee_count(250.5) is None


class TestHasEmployees:
    def test_true(self):
        assert ar._companies_dashboard_has_employees({"employee_count": 250}) is True

    def test_zero_false(self):
        assert ar._companies_dashboard_has_employees({"employee_count": 0}) is False

    def test_missing_false(self):
        assert ar._companies_dashboard_has_employees({}) is False

    def test_unparseable_false(self):
        assert ar._companies_dashboard_has_employees({"employee_count": "abc"}) is False


class TestSizeBucket:
    @pytest.mark.parametrize(
        "value,expected",
        [
            (1, "1-10"),
            (10, "1-10"),
            (11, "11-50"),
            (50, "11-50"),
            (51, "51-200"),
            (200, "51-200"),
            (201, "201-1000"),
            (1000, "201-1000"),
            (1001, "1001-5000"),
            (5000, "1001-5000"),
            (5001, "5000+"),
            (50000, "5000+"),
        ],
    )
    def test_ladder(self, value, expected):
        assert ar._companies_dashboard_size_bucket(value) == expected

    def test_zero_none(self):
        assert ar._companies_dashboard_size_bucket(0) is None

    def test_negative_none(self):
        assert ar._companies_dashboard_size_bucket(-5) is None

    def test_unparseable_none(self):
        assert ar._companies_dashboard_size_bucket("abc") is None


class TestSizePalette:
    def test_large_primary(self):
        for label in ("201-1000", "1001-5000", "5000+"):
            bg, fg = ar._companies_dashboard_size_palette(label)
            assert bg == ar._G8_ACCENT_BG
            assert fg == ar._G8_PRIMARY

    def test_mid_positive(self):
        bg, fg = ar._companies_dashboard_size_palette("51-200")
        assert bg == ar._G8_POSITIVE_BG
        assert fg == ar._G8_POSITIVE_FG

    def test_small_muted(self):
        for label in ("1-10", "11-50"):
            bg, fg = ar._companies_dashboard_size_palette(label)
            assert bg == ar._G8_MUTED_BG
            assert fg == ar._G8_TEXT_MUTED

    def test_unknown_muted(self):
        bg, fg = ar._companies_dashboard_size_palette("100000+")
        assert bg == ar._G8_MUTED_BG


class TestSizeBuckets:
    def test_empty(self):
        assert ar._companies_dashboard_size_buckets([]) == []

    def test_orders_by_ladder(self):
        items = [
            {"employee_count": 10000},
            {"employee_count": 5},
            {"employee_count": 300},
            {"employee_count": 100},
        ]
        out = ar._companies_dashboard_size_buckets(items)
        labels = [label for label, _ in out]
        # Must appear in fixed ladder order, not sorted by count.
        ladder = ["1-10", "11-50", "51-200", "201-1000", "1001-5000", "5000+"]
        indices = [ladder.index(label) for label in labels]
        assert indices == sorted(indices)

    def test_drops_unparseable(self):
        items = [
            {"employee_count": "abc"},
            {"employee_count": 5},
            {},
            {"employee_count": None},
        ]
        out = ar._companies_dashboard_size_buckets(items)
        assert out == [("1-10", 1)]

    def test_counts_aggregate(self):
        items = [
            {"employee_count": 5},
            {"employee_count": 7},
            {"employee_count": 15},
        ]
        out = ar._companies_dashboard_size_buckets(items)
        assert out == [("1-10", 2), ("11-50", 1)]


class TestLocation:
    def test_full(self):
        assert (
            ar._companies_dashboard_location(_BASE_COMPANY)
            == "San Francisco, California, United States"
        )

    def test_city_only(self):
        assert ar._companies_dashboard_location({"city": "Austin"}) == "Austin"

    def test_country_only(self):
        assert (
            ar._companies_dashboard_location({"country": "Germany"})
            == "Germany"
        )

    def test_all_empty(self):
        assert ar._companies_dashboard_location({}) == ""

    def test_html_escape(self):
        out = ar._companies_dashboard_location({"city": "<xss>"})
        assert "&lt;" in out

    def test_clipped(self):
        out = ar._companies_dashboard_location({"city": "A" * 500})
        assert len(out) <= ar._MAX_COMPANIES_DASHBOARD_LOCATION_LEN
        assert out.endswith("…")


class TestBucket:
    def test_empty(self):
        assert ar._companies_dashboard_bucket([], "industry") == []

    def test_basic(self):
        items = [{"industry": "SaaS"}, {"industry": "SaaS"}, {"industry": "Health"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        assert out == [("SaaS", 2), ("Health", 1)]

    def test_case_insensitive_grouping(self):
        items = [{"industry": "SaaS"}, {"industry": "saas"}, {"industry": "SAAS"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        assert len(out) == 1
        assert out[0][1] == 3
        # First-seen casing preserved.
        assert out[0][0] == "SaaS"

    def test_preserves_display_casing(self):
        items = [{"industry": "  Healthcare  "}, {"industry": "healthcare"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        assert out[0][0] == "Healthcare"

    def test_tie_broken_alphabetically(self):
        items = [{"industry": "Zeta"}, {"industry": "Alpha"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        # Counts tied → alphabetical (Alpha first).
        assert [x[0] for x in out] == ["Alpha", "Zeta"]

    def test_drops_none(self):
        items = [{"industry": None}, {"industry": "Software"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        assert out == [("Software", 1)]

    def test_drops_non_string(self):
        items = [{"industry": 42}, {"industry": "Software"}]
        out = ar._companies_dashboard_bucket(items, "industry")
        assert out == [("Software", 1)]


class TestStatCard:
    def test_basic(self):
        html_ = ar._companies_dashboard_stat_card("Label", "42", accent="primary")
        assert "Label" in html_
        assert "42" in html_
        assert ar._G8_PRIMARY in html_

    def test_accent_positive(self):
        html_ = ar._companies_dashboard_stat_card("x", "1", accent="positive")
        assert ar._G8_POSITIVE_FG in html_

    def test_accent_text_default(self):
        html_ = ar._companies_dashboard_stat_card("x", "1")
        assert ar._G8_TEXT in html_

    def test_html_escape_label(self):
        html_ = ar._companies_dashboard_stat_card("<x>", "1")
        assert "&lt;x&gt;" in html_

    def test_html_escape_value(self):
        html_ = ar._companies_dashboard_stat_card("x", "<y>")
        assert "&lt;y&gt;" in html_

    def test_no_single_side_colored_accent_border(self):
        """Regression lock — no `border-left: … #color` or similar
        single-side colored borders (AI-tell pattern)."""
        html_ = ar._companies_dashboard_stat_card("x", "1", accent="primary")
        for side in ("border-left", "border-right", "border-top", "border-bottom"):
            # Must not have a side-colored accent border
            assert f"{side}:" not in html_ or f"{side}-color" not in html_


class TestChip:
    def test_renders_label_and_count(self):
        out = ar._companies_dashboard_chip("SaaS", 5, bg="#fff", fg="#000")
        assert "SaaS" in out
        assert "5" in out

    def test_escapes_label(self):
        out = ar._companies_dashboard_chip("<xss>", 1, bg="#fff", fg="#000")
        assert "&lt;xss&gt;" in out


class TestOverflowChip:
    def test_shows_count(self):
        out = ar._companies_dashboard_overflow_chip(3, "industry(s)")
        assert "3" in out
        assert "industry" in out


# ----------------------------------------------------------------------
# Empty state tests
# ----------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode_primary_tint(self):
        out = ar._render_companies_dashboard_empty_state_html(mode="empty")
        assert ar._G8_PRIMARY in out
        assert "No companies yet" in out

    def test_empty_mode_points_at_post(self):
        out = ar._render_companies_dashboard_empty_state_html(mode="empty")
        assert "POST /companies" in out

    def test_empty_mode_mentions_enrichment(self):
        out = ar._render_companies_dashboard_empty_state_html(mode="empty")
        assert "enrich-company" in out

    def test_unavailable_mode_muted(self):
        out = ar._render_companies_dashboard_empty_state_html(mode="unavailable")
        assert ar._G8_TEXT_MUTED in out
        assert "not available" in out

    def test_unknown_mode_falls_to_unavailable(self):
        out = ar._render_companies_dashboard_empty_state_html(mode="random")
        assert "not available" in out


# ----------------------------------------------------------------------
# Main render HTML tests
# ----------------------------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",
    "#4f46e5",
    "#10b981",
    "#ec4899",
    "#dc2626",
    "#16a34a",
)


class TestRenderHtml:
    def test_none_returns_unavailable(self):
        out = ar.render_companies_dashboard_html(companies=None)
        assert "not available" in out

    def test_empty_list_returns_empty_state(self):
        out = ar.render_companies_dashboard_html(companies=[])
        assert "No companies yet" in out

    def test_non_dict_filtered(self):
        out = ar.render_companies_dashboard_html(companies=[None, "x", 42])
        assert "No companies yet" in out

    def test_header_renders(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Companies dashboard" in out
        assert "<!DOCTYPE html>" in out

    def test_four_stat_cards(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Total companies" in out
        assert "With domain" in out
        assert "With LinkedIn" in out
        assert "Employee count known" in out

    def test_industry_cluster(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Industry mix" in out
        assert "Software" in out  # grouped from "Software" + "software"
        assert "Healthcare" in out

    def test_industry_case_insensitive_grouping_in_render(self):
        """Lowercase and uppercase 'software' should merge into one chip."""
        companies = [
            {"industry": "Software", "id": 1},
            {"industry": "software", "id": 2},
            {"industry": "SOFTWARE", "id": 3},
        ]
        out = ar.render_companies_dashboard_html(companies=companies)
        # Chip text format: "Software · 3"
        assert "· 3" in out

    def test_size_cluster(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Employee size" in out
        assert "1-10" in out  # gamma.co = 8
        assert "51-200" in out  # Beta = 75
        assert "201-1000" in out  # Acme = 250
        assert "5000+" in out  # Delta = 15000

    def test_country_cluster(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Countries" in out
        assert "United States" in out
        assert "Canada" in out

    def test_company_rows_rendered(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Acme Corporation" in out
        assert "Beta Industries" in out
        assert "Delta Holdings" in out
        # Anonymous row (no name + no domain + no industry) still renders
        assert "(unnamed company)" in out

    def test_domain_fallback_for_unnamed(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        # gamma.co has no name but domain present
        assert "gamma.co" in out

    def test_industry_badge_rendered(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        # Industry should appear both in the cluster AND as a row badge
        assert out.count("Software") + out.count("software") >= 2

    def test_linkedin_badge_rendered(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "LINKEDIN" in out

    def test_website_badge_rendered(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "WEBSITE" in out

    def test_founded_year_rendered(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Founded 2014" in out
        assert "Founded 2018" in out

    def test_employees_formatted_with_commas(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "15,000 employees" in out

    def test_drill_down_pointers(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "g8://companies/101" in out
        assert "g8://companies/101/notes" in out
        assert "g8://companies/101/contacts" in out
        assert "g8://companies/101/deals" in out

    def test_drill_up_has_six_pointers(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "Related surfaces" in out
        assert "g8://companies/{company_id}" in out
        assert "g8://fields/companies" in out
        assert "g8://contacts/dashboard" in out
        assert "POST /companies" in out
        assert "enrich-company" in out
        assert "g8_search_companies" in out

    def test_drill_up_does_NOT_list_self(self):
        """Regression lock — the dashboard must not self-reference."""
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "<code>g8://companies/dashboard</code>" not in out

    def test_no_single_side_colored_accent_border(self):
        """Graph8 design token lock."""
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        # With specific colored hex values — harder check
        assert "border-left:" not in out or "#7d2df3" not in out.split("border-left:")[1][:100]

    def test_no_legacy_accent_hexes(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code not in out.lower(), (
                f"legacy accent hex {hex_code} must not appear"
            )

    def test_no_javascript(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        for probe in ("<script", "javascript:", "onclick=", "onerror=", "onload="):
            assert probe.lower() not in out.lower(), (
                f"dangerous construct {probe!r} must not appear in output"
            )

    def test_xss_escape_on_name(self):
        out = ar.render_companies_dashboard_html(
            companies=[{"id": 1, "name": "<evil>"}]
        )
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_xss_escape_on_description(self):
        out = ar.render_companies_dashboard_html(
            companies=[
                {"id": 1, "name": "X", "description": "<script>alert(1)</script>"}
            ]
        )
        assert "<script>alert(1)</script>" not in out

    def test_xss_escape_on_domain(self):
        out = ar.render_companies_dashboard_html(
            companies=[{"id": 1, "name": "X", "domain": "<xss>.com"}]
        )
        assert "<xss>.com" not in out

    def test_xss_escape_on_industry(self):
        out = ar.render_companies_dashboard_html(
            companies=[{"id": 1, "name": "X", "industry": "<xss>"}]
        )
        assert "&lt;xss&gt;" in out
        assert "<xss>" not in out.replace("&lt;xss&gt;", "")

    def test_pagination_total_override_used(self):
        """When backend reports total > visible, show `(of N total)`."""
        out = ar.render_companies_dashboard_html(
            companies=_SAMPLE_COMPANIES, total=5000
        )
        assert "of 5000 total" in out

    def test_pagination_total_lower_than_visible_ignored(self):
        """Safety clamp — stale/wrong pagination can't show a total
        lower than the rows we rendered."""
        out = ar.render_companies_dashboard_html(
            companies=_SAMPLE_COMPANIES, total=1
        )
        assert "of 1 total" not in out
        # Must show the visible count (5) as the effective total
        assert "Total companies" in out

    def test_overflow_card_shown_past_limit(self):
        # Build 55 companies → triggers the overflow card (limit=50).
        many = [
            {"id": i, "name": f"Co{i}", "employee_count": 10}
            for i in range(1, 56)
        ]
        out = ar.render_companies_dashboard_html(companies=many, total=55)
        assert "+ 5 more company(s)" in out

    def test_overflow_card_absent_below_limit(self):
        out = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert "more company(s)" not in out


# ----------------------------------------------------------------------
# Text fallback tests
# ----------------------------------------------------------------------


class TestTextFallback:
    def test_none_returns_not_available(self):
        out = ar.render_companies_dashboard_text_fallback(companies=None)
        assert "not available" in out

    def test_empty_returns_empty_state(self):
        out = ar.render_companies_dashboard_text_fallback(companies=[])
        assert "No companies yet" in out
        assert "POST /companies" in out

    def test_header(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert out.startswith("# Companies dashboard")

    def test_stats_section(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Stats" in out
        assert "- Total companies: 5" in out
        assert "- With domain: 3" in out  # Acme, Beta, gamma.co
        assert "- With LinkedIn: 2" in out  # Acme, Beta
        assert "- Employee count known: 4" in out  # Acme, Beta, gamma.co, Delta

    def test_industry_section(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Industries" in out
        assert "- Software (2)" in out  # Acme + gamma (grouped)

    def test_size_section(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Employee size" in out
        assert "- 1-10 " in out
        assert "- 51-200 " in out
        assert "- 201-1000 " in out
        assert "- 5000+ " in out

    def test_country_section(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Countries" in out
        assert "United States" in out
        assert "Canada" in out

    def test_companies_section(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Companies (5)" in out
        assert "**Acme Corporation**" in out
        assert "**gamma.co**" in out  # domain fallback
        assert "**(unnamed company)**" in out  # anonymous fallback

    def test_company_badges(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "SOFTWARE" in out or "Software" in out.upper()
        assert "LINKEDIN" in out
        assert "WEBSITE" in out

    def test_drill_down_line(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "g8://companies/101" in out
        assert "/notes" in out
        assert "/contacts" in out
        assert "/deals" in out

    def test_manage_block(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "## Manage companies" in out
        assert "g8://companies/{company_id}" in out
        assert "g8://fields/companies" in out
        assert "g8://contacts/dashboard" in out
        assert "POST /companies" in out
        assert "enrich-company" in out
        assert "g8_search_companies" in out

    def test_manage_block_does_not_list_self(self):
        """Regression lock — text fallback must not self-reference."""
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        # Must not have the self-URI as a bullet
        assert "g8://companies/dashboard" not in out

    def test_ends_with_newline(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert out.endswith("\n")

    def test_pagination_header_suffix(self):
        out = ar.render_companies_dashboard_text_fallback(
            companies=_SAMPLE_COMPANIES, total=5000
        )
        assert "(of 5000 total)" in out

    def test_pagination_clamp_when_total_lower(self):
        out = ar.render_companies_dashboard_text_fallback(
            companies=_SAMPLE_COMPANIES, total=1
        )
        assert "(of 1 total)" not in out
        assert "- Total companies: 5" in out

    def test_overflow_note_past_limit(self):
        many = [
            {"id": i, "name": f"Co{i}", "employee_count": 10}
            for i in range(1, 56)
        ]
        out = ar.render_companies_dashboard_text_fallback(companies=many, total=55)
        assert "+ 5 more company(s)" in out

    def test_employees_and_founded_formatted(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "250 employees" in out
        assert "Founded 2014" in out

    def test_location_line(self):
        out = ar.render_companies_dashboard_text_fallback(companies=_SAMPLE_COMPANIES)
        assert "Location: San Francisco, California, United States" in out


# ----------------------------------------------------------------------
# Smoke tests
# ----------------------------------------------------------------------


class TestSmoke:
    def test_idempotent_renders(self):
        """Same input must produce same output (cacheable)."""
        html_a = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        html_b = ar.render_companies_dashboard_html(companies=_SAMPLE_COMPANIES)
        assert html_a == html_b

    def test_realistic_payload(self):
        html_ = ar.render_companies_dashboard_html(
            companies=_SAMPLE_COMPANIES, total=120
        )
        text = ar.render_companies_dashboard_text_fallback(
            companies=_SAMPLE_COMPANIES, total=120
        )
        assert len(html_) > 0
        assert len(text) > 0

    def test_empty_payload_renders_safely(self):
        html_ = ar.render_companies_dashboard_html(companies=[])
        text = ar.render_companies_dashboard_text_fallback(companies=[])
        assert "No companies yet" in html_
        assert "No companies yet" in text
