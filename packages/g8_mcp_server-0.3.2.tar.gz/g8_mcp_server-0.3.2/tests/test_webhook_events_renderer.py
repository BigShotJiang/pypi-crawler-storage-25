"""Unit tests for HTML app surface #47 — webhook events catalog renderer.

Surface #47 renders the org-wide webhook event type catalog at
`g8://webhooks/events` (+ `.txt`). Sibling to surface #43 (webhooks
dashboard) and surfaces #32/#39 (per-webhook overview + deliveries).
Backend returns `list[WebhookEventResponse{event, description}]` from
`GET /webhooks/events` — driven by `WEBHOOK_EVENTS` in
campaign_builder/services/webhook_service.py.

Coverage:
- Helpers (clip, category, bucket, prefix count, lifecycle count,
  stat_card, category label)
- Empty-state (both modes)
- render_webhook_events_html (None → unavailable, [] → empty, full render)
- render_webhook_events_text_fallback (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (non-graph8 tokens)
    - Drill-up points at siblings #43 / #32 / #39, not self
    - Category order follows canonical tuple
    - Overflow capped at _MAX_WEBHOOK_EVENTS_RENDERED
    - XSS escape on event names + descriptions
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_WEBHOOK_EVENTS_RENDERED,
    _MAX_WEBHOOK_EVENT_NAME_LEN,
    _MAX_WEBHOOK_EVENT_DESC_LEN,
    _WEBHOOK_EVENT_CATEGORY_LABELS,
    _WEBHOOK_EVENT_CATEGORY_ORDER,
    _render_webhook_events_empty_state_html,
    _webhook_events_bucket,
    _webhook_events_category,
    _webhook_events_category_label,
    _webhook_events_clip,
    _webhook_events_count_prefix,
    _webhook_events_lifecycle_count,
    _webhook_events_stat_card,
    render_webhook_events_html,
    render_webhook_events_text_fallback,
)


# graph8 token regressions ---------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",   # pre-graph8 indigo primary
    "#4f46e5",   # pre-graph8 indigo dark
    "#10b981",   # pre-graph8 success green (not the new palette)
    "#ec4899",   # pre-graph8 pink
    "#dc2626",   # pre-graph8 destructive
    "#16a34a",   # pre-graph8 success
)


# ---------------------------------------------------------------------------
# TestClip
# ---------------------------------------------------------------------------


class TestClip:
    def test_empty_string_returns_empty(self):
        assert _webhook_events_clip("", 50) == ""

    def test_whitespace_only_returns_empty(self):
        assert _webhook_events_clip("   \t\n", 50) == ""

    def test_none_returns_empty(self):
        assert _webhook_events_clip(None, 50) == ""

    def test_non_string_returns_empty(self):
        assert _webhook_events_clip(123, 50) == ""
        assert _webhook_events_clip(["x"], 50) == ""
        assert _webhook_events_clip({"a": 1}, 50) == ""

    def test_short_string_passes_through_escaped(self):
        assert _webhook_events_clip("hello", 50) == "hello"

    def test_clips_long_strings_with_ellipsis(self):
        s = "a" * 120
        out = _webhook_events_clip(s, 20)
        assert out.endswith("…")
        assert len(out) == 20

    def test_escapes_html(self):
        assert _webhook_events_clip("<script>", 50) == "&lt;script&gt;"


# ---------------------------------------------------------------------------
# TestCategory
# ---------------------------------------------------------------------------


class TestCategory:
    def test_simple_dotted_event(self):
        assert _webhook_events_category("campaign.created") == "campaign"

    def test_deeply_nested_event(self):
        assert _webhook_events_category("engagement.email_sent") == "engagement"

    def test_three_dots(self):
        # Only the FIRST segment is used.
        assert _webhook_events_category("foo.bar.baz") == "foo"

    def test_no_dot_returns_whole_name(self):
        assert _webhook_events_category("standalone") == "standalone"

    def test_empty_string_returns_other(self):
        assert _webhook_events_category("") == "other"

    def test_whitespace_returns_other(self):
        assert _webhook_events_category("   ") == "other"

    def test_none_returns_other(self):
        assert _webhook_events_category(None) == "other"

    def test_non_string_returns_other(self):
        assert _webhook_events_category(42) == "other"
        assert _webhook_events_category(["x"]) == "other"

    def test_leading_dot_returns_other(self):
        # Empty prefix before dot.
        assert _webhook_events_category(".event") == "other"

    def test_normalizes_case(self):
        assert _webhook_events_category("Campaign.Created") == "campaign"


# ---------------------------------------------------------------------------
# TestBucket
# ---------------------------------------------------------------------------


class TestBucket:
    def test_empty_list_returns_empty(self):
        assert _webhook_events_bucket([]) == []

    def test_single_event_single_bucket(self):
        out = _webhook_events_bucket([{"event": "campaign.created"}])
        assert len(out) == 1
        cat, items = out[0]
        assert cat == "campaign"
        assert len(items) == 1

    def test_respects_canonical_order(self):
        """engagement.* should come AFTER campaign/document/intelligence."""
        events = [
            {"event": "engagement.email_sent"},
            {"event": "campaign.created"},
            {"event": "intelligence.completed"},
        ]
        out = _webhook_events_bucket(events)
        categories = [cat for cat, _ in out]
        assert categories == ["campaign", "intelligence", "engagement"]

    def test_unknown_prefixes_sort_alpha_after_known(self):
        events = [
            {"event": "zzz.foo"},
            {"event": "campaign.created"},
            {"event": "aaa.foo"},
        ]
        out = _webhook_events_bucket(events)
        categories = [cat for cat, _ in out]
        # known categories first (in canonical order), then unknowns alpha
        assert categories[0] == "campaign"
        assert categories[1:] == ["aaa", "zzz"]

    def test_events_alpha_sorted_within_bucket(self):
        events = [
            {"event": "campaign.zzz"},
            {"event": "campaign.aaa"},
            {"event": "campaign.mmm"},
        ]
        out = _webhook_events_bucket(events)
        _, items = out[0]
        names = [i["event"] for i in items]
        assert names == ["campaign.aaa", "campaign.mmm", "campaign.zzz"]

    def test_skips_non_dicts(self):
        events = [{"event": "campaign.created"}, "not a dict", None, 42]
        out = _webhook_events_bucket(events)
        # only the real dict should bucket
        total_items = sum(len(items) for _, items in out)
        assert total_items == 1

    def test_missing_event_key_buckets_as_other(self):
        out = _webhook_events_bucket([{"description": "no event key"}])
        cats = [c for c, _ in out]
        assert cats == ["other"]


# ---------------------------------------------------------------------------
# TestPrefixCount / LifecycleCount
# ---------------------------------------------------------------------------


class TestPrefixCount:
    def test_engagement_count(self):
        events = [
            {"event": "engagement.email_sent"},
            {"event": "engagement.email_replied"},
            {"event": "campaign.created"},
        ]
        assert _webhook_events_count_prefix(events, "engagement") == 2

    def test_empty_list(self):
        assert _webhook_events_count_prefix([], "engagement") == 0

    def test_no_matches(self):
        events = [{"event": "campaign.created"}]
        assert _webhook_events_count_prefix(events, "engagement") == 0

    def test_skips_non_dicts(self):
        events = [{"event": "engagement.x"}, None, 42, "foo"]
        assert _webhook_events_count_prefix(events, "engagement") == 1


class TestLifecycleCount:
    def test_counts_non_engagement(self):
        events = [
            {"event": "campaign.created"},
            {"event": "document.generated"},
            {"event": "engagement.email_sent"},
        ]
        assert _webhook_events_lifecycle_count(events) == 2

    def test_all_engagement_is_zero(self):
        events = [
            {"event": "engagement.email_sent"},
            {"event": "engagement.sms_sent"},
        ]
        assert _webhook_events_lifecycle_count(events) == 0

    def test_empty_list(self):
        assert _webhook_events_lifecycle_count([]) == 0


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_renders_label_and_value(self):
        html = _webhook_events_stat_card("Total events", "36")
        assert "Total events" in html
        assert ">36<" in html

    def test_accent_primary_uses_graph8_primary(self):
        html = _webhook_events_stat_card("Total", "36", accent="primary")
        assert "#7d2df3" in html

    def test_accent_text_defaults_to_text_color(self):
        html = _webhook_events_stat_card("Total", "0", accent="text")
        assert "#0A0A0A" in html

    def test_uniform_border_no_single_side_accent(self):
        html = _webhook_events_stat_card("Foo", "1")
        # No border-left/border-top variants with colored accent.
        assert "border-left:" not in html
        assert "border-top:" not in html
        assert "border-right:" not in html
        assert "border-bottom:" not in html

    def test_escapes_html(self):
        html = _webhook_events_stat_card("<script>", "<bad>")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html
        assert "&lt;bad&gt;" in html


# ---------------------------------------------------------------------------
# TestCategoryLabel
# ---------------------------------------------------------------------------


class TestCategoryLabel:
    def test_known_category_uses_label(self):
        assert _webhook_events_category_label("campaign") == "Campaign lifecycle"
        assert _webhook_events_category_label("engagement") == "Engagement"

    def test_unknown_category_title_cases_with_space(self):
        assert _webhook_events_category_label("custom_event") == "Custom Event"

    def test_empty_category_falls_back_to_other(self):
        assert _webhook_events_category_label("") == "Other"

    def test_all_canonical_categories_have_labels(self):
        for cat in _WEBHOOK_EVENT_CATEGORY_ORDER:
            assert cat in _WEBHOOK_EVENT_CATEGORY_LABELS
            assert _WEBHOOK_EVENT_CATEGORY_LABELS[cat]


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_unavailable_mode_uses_muted_accent(self):
        html = _render_webhook_events_empty_state_html(mode="unavailable")
        assert "not available" in html
        assert "#777777" in html  # muted accent

    def test_empty_mode_uses_primary_accent(self):
        html = _render_webhook_events_empty_state_html(mode="empty")
        assert "No webhook events available" in html
        assert "#7d2df3" in html

    def test_uniform_border_no_single_side_accent(self):
        for mode in ("empty", "unavailable"):
            html = _render_webhook_events_empty_state_html(mode=mode)
            assert "border-left:" not in html
            assert "border-top:" not in html
            assert "border-right:" not in html
            assert "border-bottom:" not in html

    def test_references_raw_api(self):
        html = _render_webhook_events_empty_state_html(mode="unavailable")
        assert "GET /webhooks/events" in html


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


def _sample_events() -> list[dict]:
    """Realistic catalog mirror of WEBHOOK_EVENTS (trimmed subset)."""
    return [
        {"event": "campaign.created", "description": "Campaign was created"},
        {"event": "campaign.updated", "description": None},
        {"event": "campaign.launched"},
        {"event": "document.generated"},
        {"event": "document.failed"},
        {"event": "intelligence.completed"},
        {"event": "audience.ready"},
        {"event": "sequence.deployed"},
        {"event": "engagement.email_sent"},
        {"event": "engagement.email_replied"},
        {"event": "engagement.sms_sent"},
        {"event": "engagement.linkedin_message_sent"},
        {"event": "meeting.booked"},
    ]


class TestRenderHtml:
    def test_none_input_returns_unavailable(self):
        html = render_webhook_events_html(events=None)
        assert "not available" in html
        assert "#777777" in html

    def test_empty_list_returns_empty_state(self):
        html = render_webhook_events_html(events=[])
        assert "No webhook events available" in html

    def test_full_render_shows_header_and_total(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "Webhook events" in html
        assert "13 EVENTS" in html

    def test_full_render_has_four_stat_cards(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "Total events" in html
        assert "Categories" in html
        assert "Engagement" in html
        assert "Lifecycle" in html

    def test_stat_counts_match(self):
        events = _sample_events()
        html = render_webhook_events_html(events=events)
        # 13 total events, 4 engagement, 9 lifecycle, 7 categories
        # (campaign, document, intelligence, audience, sequence,
        #  engagement, meeting)
        assert ">13<" in html  # total
        assert ">4<" in html   # engagement
        assert ">9<" in html   # lifecycle
        assert ">7<" in html   # categories

    def test_category_sections_appear_in_canonical_order(self):
        html = render_webhook_events_html(events=_sample_events())
        # Check campaign comes before engagement in the rendered output.
        campaign_idx = html.find("Campaign lifecycle")
        engagement_idx = html.find("Engagement</h2>")
        meeting_idx = html.find("Meetings")
        assert 0 < campaign_idx < engagement_idx < meeting_idx

    def test_events_rendered_as_monospace_pills(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "campaign.created" in html
        assert "engagement.email_sent" in html
        assert "font-family:ui-monospace,monospace" in html

    def test_description_rendered_as_hover_title(self):
        events = [
            {"event": "campaign.created", "description": "Campaign was created"}
        ]
        html = render_webhook_events_html(events=events)
        assert 'title="Campaign was created"' in html

    def test_missing_description_omits_title_attr(self):
        events = [{"event": "campaign.created"}]
        html = render_webhook_events_html(events=events)
        assert 'title="' not in html

    def test_drill_up_does_NOT_list_self(self):
        """Regression lock: drill-up must not point back to g8://webhooks/events."""
        html = render_webhook_events_html(events=_sample_events())
        # Extract the drill-up section
        anchor = html.find("Manage webhooks")
        assert anchor > -1, "drill-up section missing"
        drill_up_tail = html[anchor:]
        assert "g8://webhooks/events" not in drill_up_tail

    def test_drill_up_points_at_siblings(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "g8://webhooks</code>" in html
        assert "g8://webhooks/{webhook_id}/overview" in html
        assert "g8://webhooks/{webhook_id}/deliveries" in html
        assert "POST /webhooks" in html

    def test_no_single_side_accent_borders(self):
        """AI-tell: no `border-left:...#7d2df3` colored bars."""
        html = render_webhook_events_html(events=_sample_events())
        assert "border-left:" not in html
        assert "border-top:" not in html
        assert "border-right:" not in html
        assert "border-bottom:" not in html

    def test_no_legacy_accent_hexes(self):
        html = render_webhook_events_html(events=_sample_events())
        for hex_color in _LEGACY_ACCENT_HEXES:
            assert hex_color not in html, (
                f"legacy hex {hex_color} leaked into HTML output"
            )

    def test_uses_graph8_primary(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "#7d2df3" in html

    def test_uses_aeonik_font(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "Aeonik" in html

    def test_uses_graph8_border_color(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "#dfdfdf" in html

    def test_xss_in_event_name_escaped(self):
        events = [{"event": "<script>alert(1)</script>"}]
        html = render_webhook_events_html(events=events)
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_description_escaped(self):
        events = [
            {
                "event": "campaign.created",
                "description": "<img src=x onerror=alert(1)>",
            }
        ]
        html = render_webhook_events_html(events=events)
        assert "<img src=x" not in html
        assert "&lt;img" in html

    def test_overflow_beyond_cap(self):
        """Cap renders at most _MAX_WEBHOOK_EVENTS_RENDERED events."""
        events = [
            {"event": f"campaign.event_{i:04d}"}
            for i in range(_MAX_WEBHOOK_EVENTS_RENDERED + 50)
        ]
        html = render_webhook_events_html(events=events)
        assert "more events omitted" in html
        # Spot check that events past cap are absent.
        assert f"campaign.event_{_MAX_WEBHOOK_EVENTS_RENDERED + 10:04d}" not in html

    def test_skips_non_dict_and_events_without_names(self):
        events = [
            {"event": "campaign.created"},
            "not a dict",
            None,
            {"description": "no event field"},
            {"event": ""},
            {"event": "   "},
        ]
        html = render_webhook_events_html(events=events)
        # Only the one valid event renders.
        assert "campaign.created" in html
        # Valid events count should be 1 (the rest are dropped or filtered)
        # Others bucket into "other" but the empty string is filtered in the chip loop
        assert ">1<" in html or ">2<" in html  # total count is 3 (none/other buckets)

    def test_clips_long_event_names(self):
        long_name = "campaign." + ("x" * 300)
        events = [{"event": long_name}]
        html = render_webhook_events_html(events=events)
        # Should include ellipsis
        assert "…" in html
        # Full name should NOT appear verbatim in HTML
        assert long_name not in html

    def test_clips_long_descriptions(self):
        long_desc = "desc " * 100
        events = [{"event": "campaign.created", "description": long_desc}]
        html = render_webhook_events_html(events=events)
        # Title attribute should contain the clipped version, not the full
        # Either ellipsis appears in title, or length is under cap
        if len(long_desc) > _MAX_WEBHOOK_EVENT_DESC_LEN:
            assert "…" in html

    def test_uses_shadcn_card_radius(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "border-radius:12px" in html

    def test_uses_pill_radius_for_chips(self):
        html = render_webhook_events_html(events=_sample_events())
        assert "border-radius:6px" in html


# ---------------------------------------------------------------------------
# TestTextFallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_input_returns_unavailable(self):
        text = render_webhook_events_text_fallback(events=None)
        assert "not available" in text
        assert text.startswith("#")  # markdown heading

    def test_empty_list_returns_empty_state(self):
        text = render_webhook_events_text_fallback(events=[])
        assert "empty" in text.lower()

    def test_full_render_shows_header(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "# Webhook events" in text
        assert "13 total" in text

    def test_has_four_summary_lines(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "Total events: 13" in text
        assert "Categories: 7" in text
        assert "Engagement: 4" in text
        assert "Lifecycle: 9" in text

    def test_category_sections_rendered(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "## Campaign lifecycle" in text
        assert "## Engagement" in text
        assert "## Meetings" in text

    def test_events_rendered_as_code_ticks(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "`campaign.created`" in text
        assert "`engagement.email_sent`" in text

    def test_description_appended_with_dash(self):
        events = [
            {"event": "campaign.created", "description": "Campaign was created"}
        ]
        text = render_webhook_events_text_fallback(events=events)
        assert "— Campaign was created" in text

    def test_missing_description_no_dash(self):
        events = [{"event": "campaign.created"}]
        text = render_webhook_events_text_fallback(events=events)
        line = next(
            (l for l in text.splitlines() if "campaign.created" in l), ""
        )
        # Bullet row should not have " — " suffix if description missing.
        assert " — " not in line

    def test_drill_up_section_does_NOT_list_self(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        manage_idx = text.find("## Manage webhooks")
        assert manage_idx > -1
        manage_section = text[manage_idx:]
        assert "g8://webhooks/events" not in manage_section

    def test_drill_up_points_at_siblings(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "g8://webhooks" in text
        assert "/overview" in text
        assert "/deliveries" in text
        assert "POST /webhooks" in text

    def test_ends_with_newline(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert text.endswith("\n")

    def test_no_html_in_text_fallback(self):
        text = render_webhook_events_text_fallback(events=_sample_events())
        assert "<" not in text
        assert "</" not in text
        assert "<div" not in text

    def test_overflow_noted_when_cap_hit(self):
        events = [
            {"event": f"campaign.event_{i:04d}"}
            for i in range(_MAX_WEBHOOK_EVENTS_RENDERED + 50)
        ]
        text = render_webhook_events_text_fallback(events=events)
        assert "more events omitted" in text


# ---------------------------------------------------------------------------
# TestSmoke — quick sanity checks
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_html_and_text_both_valid_for_realistic_catalog(self):
        events = _sample_events()
        html = render_webhook_events_html(events=events)
        text = render_webhook_events_text_fallback(events=events)
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html
        assert text.endswith("\n")

    def test_handles_full_webhook_events_list(self):
        """Smoke-test with the actual WEBHOOK_EVENTS constant from webhook_service."""
        from campaign_builder.services.webhook_service import WEBHOOK_EVENTS
        events = [{"event": e} for e in WEBHOOK_EVENTS]
        html = render_webhook_events_html(events=events)
        text = render_webhook_events_text_fallback(events=events)
        assert f"{len(WEBHOOK_EVENTS)} EVENTS" in html
        assert f"Total events: {len(WEBHOOK_EVENTS)}" in text
        for e in WEBHOOK_EVENTS:
            # Each event should appear somewhere in both outputs.
            assert e in html or e[: _MAX_WEBHOOK_EVENT_NAME_LEN] in html
            assert e in text or e[: _MAX_WEBHOOK_EVENT_NAME_LEN] in text

    def test_all_categories_have_stable_label(self):
        # Make sure every canonical category has a label entry.
        for cat in _WEBHOOK_EVENT_CATEGORY_ORDER:
            assert _webhook_events_category_label(cat)
