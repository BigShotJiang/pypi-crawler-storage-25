"""Tests for the CRM integrations dashboard renderer (upgrade 4 — #17)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _crm_provider_label,
    _sort_crm_integrations,
    render_crm_syncs_dashboard_html,
    render_crm_syncs_dashboard_text_fallback,
)


def _integ(
    provider: str | None = "hubspot",
    is_connected: bool | None = True,
    status: str | None = "connected",
    account_name: str | None = "Acme Inc.",
    last_sync_at: str | None = "2026-04-10T12:00:00Z",
) -> dict:
    return {
        "provider": provider,
        "is_connected": is_connected,
        "status": status,
        "account_name": account_name,
        "last_sync_at": last_sync_at,
    }


# ---------------------------------------------------------------------------
# _crm_provider_label
# ---------------------------------------------------------------------------


class TestCrmProviderLabel:
    def test_hubspot(self):
        assert _crm_provider_label("hubspot") == "HubSpot"

    def test_salesforce(self):
        assert _crm_provider_label("salesforce") == "Salesforce"

    def test_pipedrive(self):
        assert _crm_provider_label("pipedrive") == "Pipedrive"

    def test_zoho_alias(self):
        """zohocrm should resolve to 'Zoho' (same as 'zoho')."""
        assert _crm_provider_label("zohocrm") == "Zoho"

    def test_zoho_direct(self):
        assert _crm_provider_label("zoho") == "Zoho"

    def test_sugar_alias(self):
        """'sugar' and 'sugarcrm' should both map to 'SugarCRM'."""
        assert _crm_provider_label("sugar") == "SugarCRM"

    def test_sugarcrm_direct(self):
        assert _crm_provider_label("sugarcrm") == "SugarCRM"

    def test_dynamics_alias(self):
        assert _crm_provider_label("dynamics") == "Microsoft Dynamics"
        assert _crm_provider_label("ms_dynamics") == "Microsoft Dynamics"

    def test_unknown_title_case(self):
        """Unknown providers should get a Title Case fallback."""
        assert _crm_provider_label("freshsales") == "Freshsales"

    def test_unknown_with_underscore(self):
        """Underscores should be replaced with spaces in the fallback."""
        assert _crm_provider_label("some_crm") == "Some Crm"

    def test_none(self):
        """None should be handled gracefully."""
        result = _crm_provider_label(None)
        # Should be a reasonable placeholder (empty or 'Unknown')
        assert isinstance(result, str)

    def test_empty(self):
        """Empty string should not blow up."""
        result = _crm_provider_label("")
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# _sort_crm_integrations
# ---------------------------------------------------------------------------


class TestSortCrmIntegrations:
    def test_empty_list(self):
        assert _sort_crm_integrations([]) == []

    def test_connected_first(self):
        """Connected integrations should come before disconnected ones."""
        items = [
            _integ(provider="salesforce", is_connected=False),
            _integ(provider="zoho", is_connected=True),
        ]
        result = _sort_crm_integrations(items)
        assert result[0]["provider"] == "zoho"
        assert result[1]["provider"] == "salesforce"

    def test_preferred_order(self):
        """Within connected state, preferred providers come first."""
        items = [
            _integ(provider="sugarcrm", is_connected=True),
            _integ(provider="hubspot", is_connected=True),
            _integ(provider="salesforce", is_connected=True),
        ]
        result = _sort_crm_integrations(items)
        providers = [i["provider"] for i in result]
        # hubspot < salesforce < sugarcrm in preferred order
        assert providers == ["hubspot", "salesforce", "sugarcrm"]

    def test_unknown_providers_at_end(self):
        """Unknown providers should sort after known ones."""
        items = [
            _integ(provider="mysterycrm", is_connected=True),
            _integ(provider="hubspot", is_connected=True),
        ]
        result = _sort_crm_integrations(items)
        assert result[0]["provider"] == "hubspot"
        assert result[1]["provider"] == "mysterycrm"

    def test_tiebreak_by_account_name(self):
        """Same provider integrations sort by account_name alphabetically."""
        items = [
            _integ(provider="hubspot", is_connected=True, account_name="Zeta Corp"),
            _integ(provider="hubspot", is_connected=True, account_name="Acme Inc."),
        ]
        result = _sort_crm_integrations(items)
        assert result[0]["account_name"] == "Acme Inc."
        assert result[1]["account_name"] == "Zeta Corp"

    def test_disconnected_preferred_order(self):
        """Disconnected items also respect preferred order internally."""
        items = [
            _integ(provider="salesforce", is_connected=False),
            _integ(provider="hubspot", is_connected=False),
        ]
        result = _sort_crm_integrations(items)
        assert result[0]["provider"] == "hubspot"
        assert result[1]["provider"] == "salesforce"


# ---------------------------------------------------------------------------
# render_crm_syncs_dashboard_html
# ---------------------------------------------------------------------------


class TestRenderCrmSyncsDashboardHtml:
    def test_empty_list_returns_empty_state(self):
        html_out = render_crm_syncs_dashboard_html(integrations=[])
        assert "No CRM integrations" in html_out
        assert "<!doctype html>" in html_out

    def test_none_returns_empty_state(self):
        html_out = render_crm_syncs_dashboard_html(integrations=None)
        assert "No CRM integrations" in html_out

    def test_non_list_returns_empty_state(self):
        html_out = render_crm_syncs_dashboard_html(integrations="garbage")  # type: ignore[arg-type]
        assert "No CRM integrations" in html_out

    def test_only_garbage_returns_empty_state(self):
        """Non-dict items filtered out — if all garbage, empty state."""
        html_out = render_crm_syncs_dashboard_html(integrations=["a", 1, None])  # type: ignore[list-item]
        assert "No CRM integrations" in html_out

    def test_renders_basic_row(self):
        items = [_integ(provider="hubspot", account_name="Acme")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "HubSpot" in html_out
        assert "Acme" in html_out

    def test_org_label_rendered(self):
        items = [_integ()]
        html_out = render_crm_syncs_dashboard_html(integrations=items, org_label="Graph8")
        assert "Graph8" in html_out

    def test_default_org_label(self):
        items = [_integ()]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "Your Org" in html_out

    def test_connected_count_in_subhead(self):
        items = [
            _integ(provider="hubspot", is_connected=True),
            _integ(provider="salesforce", is_connected=False),
        ]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "2 integration(s)" in html_out
        assert "1 connected" in html_out

    def test_connected_dot_rendered(self):
        items = [_integ(is_connected=True)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "active-dot" in html_out

    def test_disconnected_dot_rendered(self):
        items = [_integ(is_connected=False)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "inactive-dot" in html_out

    def test_status_badge_rendered(self):
        items = [_integ(status="error")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "error" in html_out.lower()

    def test_status_fallback_when_missing(self):
        """Missing status should default to 'connected' / 'disconnected' based on is_connected."""
        items = [_integ(status=None, is_connected=True)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "connected" in html_out.lower()

        items = [_integ(status=None, is_connected=False)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "disconnected" in html_out.lower()

    def test_last_sync_rendered(self):
        items = [_integ(last_sync_at="2026-04-15T10:30:00Z")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "2026-04-15" in html_out
        assert "Last sync" in html_out

    def test_missing_last_sync_no_label(self):
        """When last_sync is missing, 'Last sync' label should not render."""
        items = [_integ(last_sync_at=None)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "Last sync" not in html_out

    def test_missing_account_name_placeholder(self):
        """Empty account_name should show 'No account' placeholder."""
        items = [_integ(account_name=None)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "No account" in html_out

    def test_html_escaped_in_account_name(self):
        """Account name with HTML chars should be escaped."""
        items = [_integ(account_name="<script>evil</script>")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_html_escaped_in_provider(self):
        """Unknown provider with HTML chars should be escaped."""
        items = [_integ(provider="<img src=x>")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "<img src=x>" not in html_out

    def test_html_escaped_in_status(self):
        items = [_integ(status="<svg>")]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "<svg>" not in html_out
        assert "&lt;svg&gt;" in html_out

    def test_preferred_order_in_render(self):
        """Preferred order (HubSpot, Salesforce, etc.) should drive row order."""
        items = [
            _integ(provider="sugarcrm", is_connected=True, account_name="C"),
            _integ(provider="hubspot", is_connected=True, account_name="A"),
            _integ(provider="salesforce", is_connected=True, account_name="B"),
        ]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        hub = html_out.find("HubSpot")
        sf = html_out.find("Salesforce")
        sugar = html_out.find("SugarCRM")
        assert hub < sf < sugar

    def test_cap_enforced(self):
        """Cap at _MAX_CRM_SYNCS_RENDERED integrations."""
        items = [
            _integ(provider=f"custom_{i}", account_name=f"A{i}")
            for i in range(app_renderer._MAX_CRM_SYNCS_RENDERED + 5)
        ]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "5 integration(s) omitted" in html_out

    def test_no_omitted_footer_when_within_cap(self):
        items = [_integ(provider=f"custom_{i}") for i in range(3)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "omitted" not in html_out

    def test_account_name_truncated(self):
        """Long account names should be truncated to _MAX_CRM_ACCOUNT_NAME_LEN."""
        long_name = "X" * (app_renderer._MAX_CRM_ACCOUNT_NAME_LEN + 100)
        items = [_integ(account_name=long_name)]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        # Full long name should NOT be present
        assert long_name not in html_out

    def test_non_dict_items_filtered(self):
        """Non-dict entries should be skipped, not crash."""
        items = [_integ(), "garbage", 42, None, _integ(provider="salesforce")]  # type: ignore[list-item]
        html_out = render_crm_syncs_dashboard_html(integrations=items)
        assert "2 integration(s)" in html_out


# ---------------------------------------------------------------------------
# render_crm_syncs_dashboard_text_fallback
# ---------------------------------------------------------------------------


class TestRenderCrmSyncsDashboardTextFallback:
    def test_empty_list(self):
        text = render_crm_syncs_dashboard_text_fallback(integrations=[])
        assert "No CRM integrations connected" in text

    def test_none(self):
        text = render_crm_syncs_dashboard_text_fallback(integrations=None)
        assert "No CRM integrations connected" in text

    def test_non_list(self):
        text = render_crm_syncs_dashboard_text_fallback(integrations="garbage")  # type: ignore[arg-type]
        assert "No CRM integrations connected" in text

    def test_only_garbage_items(self):
        text = render_crm_syncs_dashboard_text_fallback(integrations=["a", 1])  # type: ignore[list-item]
        assert "No CRM integrations connected" in text

    def test_renders_basic_row(self):
        items = [_integ(provider="hubspot", account_name="Acme")]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "HubSpot" in text
        assert "Acme" in text

    def test_connected_marker(self):
        items = [_integ(is_connected=True)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "●" in text

    def test_disconnected_marker(self):
        items = [_integ(is_connected=False)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "○" in text

    def test_status_fallback(self):
        items = [_integ(status=None, is_connected=True)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "[connected]" in text

        items = [_integ(status=None, is_connected=False)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "[disconnected]" in text

    def test_org_label(self):
        items = [_integ()]
        text = render_crm_syncs_dashboard_text_fallback(
            integrations=items, org_label="TestOrg"
        )
        assert "TestOrg" in text

    def test_default_org_label(self):
        items = [_integ()]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "Your Org" in text

    def test_count_summary_line(self):
        items = [
            _integ(provider="hubspot", is_connected=True),
            _integ(provider="salesforce", is_connected=False),
        ]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "2 integration(s)" in text
        assert "1 connected" in text

    def test_last_sync_suffix(self):
        items = [_integ(last_sync_at="2026-04-15T10:30:00Z")]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "last sync 2026-04-15" in text

    def test_missing_last_sync_no_suffix(self):
        items = [_integ(last_sync_at=None)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "last sync" not in text

    def test_missing_account_no_suffix(self):
        items = [_integ(account_name=None)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        # No "(account)" suffix when no account_name
        lines = text.split("\n")
        integration_line = [ln for ln in lines if "HubSpot" in ln][0]
        assert "(" not in integration_line

    def test_cap_overflow_message(self):
        items = [
            _integ(provider=f"custom_{i}")
            for i in range(app_renderer._MAX_CRM_SYNCS_RENDERED + 3)
        ]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "and 3 more integration(s)" in text

    def test_no_overflow_message_when_within_cap(self):
        items = [_integ(provider=f"custom_{i}") for i in range(3)]
        text = render_crm_syncs_dashboard_text_fallback(integrations=items)
        assert "more integration(s)" not in text
