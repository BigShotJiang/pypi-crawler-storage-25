"""Unit tests for the surface #28 audience-sync-detail renderer + helpers.

Surface #28 is the per-config audience sync detail at URI
`g8://audience-syncs/{config_id}/overview`. Complements surface #16
(audience syncs dashboard, org-wide list) and surface #18 (per-sync run
history).

Answers "what does THIS audience sync do — which platform, which audience,
what cadence, what mode, is it healthy, when did it last run?".

The `/overview` suffix is deliberate:
  - `g8://audience-syncs/{config_id}/runs` already exists (surface #18).
  - Without `/overview`, a bare `{config_id}` template would capture
    `42.txt` into `config_id` before the `.txt` fallback template is
    reached, shadowing the plaintext variant. The suffix makes both
    siblings unambiguous at dispatch time.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _audience_sync_detail_derive_label,
    _audience_sync_detail_mode_label,
    _audience_sync_detail_platform_label,
    _audience_sync_detail_tally_runs,
    _is_positive,
    render_audience_sync_detail_html,
    render_audience_sync_detail_text_fallback,
)


def _sample_config() -> dict:
    return {
        "id": 42,
        "audience_id": "aud_99",
        "platform": "meta",
        "platform_audience_name": "Q2 Launch Audience",
        "mode": "mirror",
        "refresh_cadence_hours": 24,
        "is_active": True,
        "status": "active",
        "last_sync_at": "2026-04-19T10:00:00Z",
        "created_at": "2026-04-01T00:00:00Z",
    }


def _sample_runs() -> list[dict]:
    return [
        {
            "id": 1,
            "status": "success",
            "started_at": "2026-04-19T10:00:00Z",
            "finished_at": "2026-04-19T10:01:00Z",
            "added_count": 1200,
            "removed_count": 50,
            "member_count": 25000,
        },
        {
            "id": 2,
            "status": "failed",
            "started_at": "2026-04-18T10:00:00Z",
            "finished_at": "2026-04-18T10:00:30Z",
            "error_message": "Rate limited by platform",
        },
        {
            "id": 3,
            "status": "running",
            "started_at": "2026-04-20T10:00:00Z",
        },
    ]


# -----------------------------------------------------------------------
# _audience_sync_detail_derive_label
# -----------------------------------------------------------------------


class TestAudienceSyncDetailDeriveLabel:
    def test_platform_audience_name_takes_priority(self):
        cfg = {
            "platform_audience_name": "Launch Audience",
            "name": "fallback",
            "platform": "meta",
        }
        assert _audience_sync_detail_derive_label(cfg) == "Launch Audience"

    def test_falls_back_to_name_when_pname_missing(self):
        cfg = {"name": "My Sync", "platform": "linkedin"}
        assert _audience_sync_detail_derive_label(cfg) == "My Sync"

    def test_falls_back_to_name_when_pname_blank(self):
        cfg = {"platform_audience_name": "   ", "name": "My Sync"}
        assert _audience_sync_detail_derive_label(cfg) == "My Sync"

    def test_falls_back_to_platform_label_when_only_platform(self):
        cfg = {"platform": "meta"}
        assert _audience_sync_detail_derive_label(cfg) == "Meta"

    def test_uses_linkedin_label(self):
        cfg = {"platform": "linkedin"}
        assert _audience_sync_detail_derive_label(cfg) == "LinkedIn"

    def test_uses_google_label(self):
        cfg = {"platform": "google"}
        assert _audience_sync_detail_derive_label(cfg) == "Google Ads"

    def test_unmapped_platform_passes_through(self):
        cfg = {"platform": "bespoke"}
        assert _audience_sync_detail_derive_label(cfg) == "bespoke"

    def test_empty_config_returns_sentinel(self):
        assert _audience_sync_detail_derive_label({}) == "(unnamed sync)"

    def test_all_blank_returns_sentinel(self):
        cfg = {"platform_audience_name": "", "name": "  ", "platform": ""}
        assert _audience_sync_detail_derive_label(cfg) == "(unnamed sync)"

    def test_non_string_platform_audience_name_ignored(self):
        cfg = {"platform_audience_name": 123, "platform": "meta"}
        assert _audience_sync_detail_derive_label(cfg) == "Meta"

    def test_strips_whitespace(self):
        cfg = {"platform_audience_name": "  Spaced  "}
        assert _audience_sync_detail_derive_label(cfg) == "Spaced"


# -----------------------------------------------------------------------
# _audience_sync_detail_platform_label
# -----------------------------------------------------------------------


class TestAudienceSyncDetailPlatformLabel:
    def test_meta_lowercase(self):
        assert _audience_sync_detail_platform_label("meta") == "Meta"

    def test_meta_uppercase(self):
        assert _audience_sync_detail_platform_label("META") == "Meta"

    def test_facebook_aliases_to_meta(self):
        assert _audience_sync_detail_platform_label("facebook") == "Meta"

    def test_linkedin(self):
        assert _audience_sync_detail_platform_label("linkedin") == "LinkedIn"

    def test_google(self):
        assert _audience_sync_detail_platform_label("google") == "Google Ads"

    def test_x(self):
        assert _audience_sync_detail_platform_label("x") == "X (Twitter)"

    def test_twitter_aliases_to_x(self):
        assert _audience_sync_detail_platform_label("twitter") == "X (Twitter)"

    def test_tiktok(self):
        assert _audience_sync_detail_platform_label("tiktok") == "TikTok"

    def test_reddit(self):
        assert _audience_sync_detail_platform_label("reddit") == "Reddit"

    def test_unmapped_title_cased(self):
        assert _audience_sync_detail_platform_label("bespoke") == "Bespoke"

    def test_none_returns_emdash(self):
        assert _audience_sync_detail_platform_label(None) == "\u2014"

    def test_empty_returns_emdash(self):
        assert _audience_sync_detail_platform_label("") == "\u2014"

    def test_whitespace_only_returns_emdash(self):
        assert _audience_sync_detail_platform_label("   ") == "\u2014"


# -----------------------------------------------------------------------
# _audience_sync_detail_mode_label
# -----------------------------------------------------------------------


class TestAudienceSyncDetailModeLabel:
    def test_mirror(self):
        assert (
            _audience_sync_detail_mode_label("mirror")
            == "Mirror (additive + removal)"
        )

    def test_mirror_uppercase(self):
        assert (
            _audience_sync_detail_mode_label("MIRROR")
            == "Mirror (additive + removal)"
        )

    def test_append_only(self):
        assert _audience_sync_detail_mode_label("append_only") == "Append-only"

    def test_unmapped_value(self):
        assert _audience_sync_detail_mode_label("hybrid_mode") == "Hybrid Mode"

    def test_none_returns_emdash(self):
        assert _audience_sync_detail_mode_label(None) == "\u2014"

    def test_empty_returns_emdash(self):
        assert _audience_sync_detail_mode_label("") == "\u2014"

    def test_whitespace_only_returns_emdash(self):
        assert _audience_sync_detail_mode_label("   ") == "\u2014"


# -----------------------------------------------------------------------
# _audience_sync_detail_tally_runs
# -----------------------------------------------------------------------


class TestAudienceSyncDetailTallyRuns:
    def test_empty_list_tallies_zero(self):
        tally = _audience_sync_detail_tally_runs([])
        assert tally == {
            "success": 0,
            "running": 0,
            "pending": 0,
            "failed": 0,
            "other": 0,
        }

    def test_buckets_success(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "success"}]
        )["success"] == 1

    def test_buckets_completed_as_success(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "completed"}]
        )["success"] == 1

    def test_buckets_complete_as_success(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "complete"}]
        )["success"] == 1

    def test_buckets_done_as_success(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "done"}]
        )["success"] == 1

    def test_buckets_running(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "running"}]
        )["running"] == 1

    def test_buckets_in_progress_as_running(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "in_progress"}]
        )["running"] == 1

    def test_buckets_processing_as_running(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "processing"}]
        )["running"] == 1

    def test_buckets_pending(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "pending"}]
        )["pending"] == 1

    def test_buckets_queued_as_pending(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "queued"}]
        )["pending"] == 1

    def test_buckets_waiting_as_pending(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "waiting"}]
        )["pending"] == 1

    def test_buckets_failed(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "failed"}]
        )["failed"] == 1

    def test_buckets_error_as_failed(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "error"}]
        )["failed"] == 1

    def test_buckets_unknown_as_other(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "weird"}]
        )["other"] == 1

    def test_buckets_missing_status_as_other(self):
        assert _audience_sync_detail_tally_runs([{}])["other"] == 1

    def test_case_insensitive(self):
        assert _audience_sync_detail_tally_runs(
            [{"status": "SUCCESS"}]
        )["success"] == 1

    def test_skips_non_dict_entries(self):
        # Non-dicts should not crash; they get silently dropped.
        tally = _audience_sync_detail_tally_runs(
            [{"status": "success"}, None, "x", 42, {"status": "failed"}]
        )
        assert tally["success"] == 1
        assert tally["failed"] == 1
        assert tally["other"] == 0

    def test_combined_tallies(self):
        runs = [
            {"status": "success"},
            {"status": "success"},
            {"status": "failed"},
            {"status": "running"},
            {"status": "weird"},
        ]
        tally = _audience_sync_detail_tally_runs(runs)
        assert tally["success"] == 2
        assert tally["failed"] == 1
        assert tally["running"] == 1
        assert tally["other"] == 1
        assert tally["pending"] == 0


# -----------------------------------------------------------------------
# _is_positive
# -----------------------------------------------------------------------


class TestIsPositive:
    def test_positive_int_is_true(self):
        assert _is_positive(5) is True

    def test_zero_is_false(self):
        assert _is_positive(0) is False

    def test_negative_int_is_false(self):
        assert _is_positive(-1) is False

    def test_none_is_false(self):
        assert _is_positive(None) is False

    def test_bool_true_is_false(self):
        # Don't let True sneak in as 1 — explicitly excluded.
        assert _is_positive(True) is False

    def test_bool_false_is_false(self):
        assert _is_positive(False) is False

    def test_positive_float_is_true(self):
        assert _is_positive(5.5) is True

    def test_float_zero_is_false(self):
        assert _is_positive(0.0) is False

    def test_numeric_string_handled(self):
        # int("10") -> 10 > 0 -> True
        assert _is_positive("10") is True

    def test_non_numeric_string_is_false(self):
        assert _is_positive("xyz") is False

    def test_empty_string_is_false(self):
        assert _is_positive("") is False


# -----------------------------------------------------------------------
# render_audience_sync_detail_html — empty state
# -----------------------------------------------------------------------


class TestRenderAudienceSyncDetailEmptyState:
    def test_none_config_triggers_empty_state(self):
        out = render_audience_sync_detail_html(config=None, config_id="42")
        assert "<html" in out
        assert "Audience sync not found" in out

    def test_non_dict_config_triggers_empty_state(self):
        out = render_audience_sync_detail_html(config="not-a-dict", config_id="42")
        assert "Audience sync not found" in out

    def test_empty_state_includes_config_id(self):
        out = render_audience_sync_detail_html(config=None, config_id="abc123")
        assert "abc123" in out

    def test_empty_state_references_list_tool(self):
        out = render_audience_sync_detail_html(config=None, config_id="42")
        assert "g8_list_audience_syncs" in out

    def test_empty_state_references_dashboard(self):
        out = render_audience_sync_detail_html(config=None, config_id="42")
        assert "g8://audience-syncs" in out

    def test_empty_state_escapes_config_id(self):
        out = render_audience_sync_detail_html(
            config=None, config_id="<script>evil</script>"
        )
        assert "<script>evil" not in out
        assert "&lt;script&gt;" in out or "evil" in out

    def test_empty_state_unknown_id_placeholder(self):
        out = render_audience_sync_detail_html(config=None, config_id="")
        assert "(unknown)" in out


# -----------------------------------------------------------------------
# render_audience_sync_detail_html — populated
# -----------------------------------------------------------------------


class TestRenderAudienceSyncDetailPopulated:
    def test_renders_full_config(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "<html" in html
        assert "</html>" in html

    def test_renders_platform_audience_name(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "Q2 Launch Audience" in html

    def test_renders_platform_label(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "Meta" in html

    def test_renders_config_id(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "#42" in html

    def test_renders_audience_id(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "aud_99" in html

    def test_renders_mode_label(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "Mirror (additive + removal)" in html

    def test_renders_cadence_daily(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        # 24h → "daily"
        assert "daily" in html.lower()

    def test_renders_custom_cadence(self):
        cfg = {**_sample_config(), "refresh_cadence_hours": 6}
        html = render_audience_sync_detail_html(config=cfg, config_id="42")
        assert "every 6h" in html

    def test_renders_last_sync(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "2026-04-19T10:00:00Z" in html

    def test_renders_never_when_no_last_sync(self):
        cfg = {**_sample_config(), "last_sync_at": None}
        html = render_audience_sync_detail_html(config=cfg, config_id="42")
        assert "never" in html

    def test_renders_active_status_badge(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "status-badge" in html
        assert "active" in html

    def test_renders_inactive_when_is_active_false(self):
        cfg = {**_sample_config(), "is_active": False, "status": None}
        html = render_audience_sync_detail_html(config=cfg, config_id="42")
        assert "inactive" in html

    def test_renders_run_summary_line(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "3 total" in html
        assert "1 succeeded" in html
        assert "1 failed" in html
        assert "1 running" in html

    def test_renders_run_rows(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "#1" in html
        assert "#2" in html
        assert "#3" in html

    def test_renders_run_member_deltas(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "+1.2k" in html
        assert "-50" in html

    def test_renders_run_error_message(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "Rate limited by platform" in html

    def test_truncates_long_error_message(self):
        long_err = "E" * 500
        runs = [
            {"id": 1, "status": "failed", "error_message": long_err},
        ]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        # Error is clipped with ellipsis; should not contain the full 500-E string
        assert "E" * 500 not in html
        assert "\u2026" in html  # ellipsis marker

    def test_renders_empty_runs_section(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=[]
        )
        assert "No runs yet for this sync" in html

    def test_no_runs_section_when_runs_none(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=None
        )
        # runs=None should not render any runs section
        assert "No runs yet" not in html
        assert "Recent runs" not in html

    def test_caps_runs_to_five(self):
        runs = [
            {"id": i, "status": "success", "started_at": f"2026-04-0{i}"}
            for i in range(1, 9)
        ]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        # IDs 1-5 rendered, 6-8 in overflow
        assert "#1" in html
        assert "#5" in html
        # overflow note shows 3 omitted
        assert "3 more run(s) omitted" in html

    def test_no_overflow_note_when_within_cap(self):
        runs = [{"id": 1, "status": "success"}]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        assert "more run(s) omitted" not in html

    def test_escapes_html_in_audience_name(self):
        cfg = {
            **_sample_config(),
            "platform_audience_name": "<script>alert(1)</script>",
        }
        html = render_audience_sync_detail_html(config=cfg, config_id="42")
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_html_in_error_message(self):
        runs = [
            {"id": 1, "status": "failed", "error_message": "<img src=x>"}
        ]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        assert "<img src=x>" not in html
        assert "&lt;img" in html

    def test_drill_down_hint_includes_runs_uri(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "g8://audience-syncs/42/runs" in html

    def test_drill_down_hint_includes_dashboard_uri(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "g8://audience-syncs" in html

    def test_uses_added_count_fallback_to_members_added(self):
        runs = [
            {
                "id": 1,
                "status": "success",
                "members_added": 500,
                "members_removed": 10,
                "total_members": 5000,
            }
        ]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        assert "+500" in html
        assert "-10" in html

    def test_skips_non_dict_run_entries(self):
        runs = [
            {"id": 1, "status": "success"},
            None,
            "x",
            {"id": 2, "status": "failed"},
        ]
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42", runs=runs
        )
        # Non-dicts don't blow up
        assert "#1" in html
        assert "#2" in html
        # Summary line reflects only valid runs (2 total, not 4)
        assert "2 total" in html

    def test_stat_grid_contains_five_cards(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        # Five stat-card divs
        assert html.count("stat-card") >= 5

    def test_header_contains_active_dot(self):
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id="42"
        )
        assert "active-dot" in html

    def test_renders_when_only_platform_provided(self):
        cfg = {"platform": "linkedin"}
        html = render_audience_sync_detail_html(config=cfg, config_id="1")
        # Falls back to platform label as title
        assert "LinkedIn" in html

    def test_long_id_is_clipped(self):
        long_id = "x" * 200
        html = render_audience_sync_detail_html(
            config=_sample_config(), config_id=long_id
        )
        # Header sync-id is clipped at 64; the x*200 should NOT appear in full
        assert "x" * 100 not in html


# -----------------------------------------------------------------------
# render_audience_sync_detail_text_fallback
# -----------------------------------------------------------------------


class TestRenderAudienceSyncDetailTextFallback:
    def test_none_config_returns_not_found_markdown(self):
        txt = render_audience_sync_detail_text_fallback(
            config=None, config_id="42"
        )
        assert txt.startswith("# Audience sync not found")
        assert "42" in txt
        assert "g8_list_audience_syncs" in txt

    def test_non_dict_config_returns_not_found(self):
        txt = render_audience_sync_detail_text_fallback(
            config="not-a-dict", config_id="42"
        )
        assert "not found" in txt

    def test_populated_starts_with_h1(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert txt.startswith("# Audience sync \u2014 Q2 Launch Audience")

    def test_renders_platform(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Platform: **Meta**" in txt

    def test_renders_status(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Status: **active**" in txt

    def test_renders_config_id(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "id: `42`" in txt

    def test_renders_overview_section(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "## Overview" in txt

    def test_renders_audience_id(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Audience ID: `aud_99`" in txt

    def test_renders_cadence(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Refresh cadence: daily" in txt

    def test_renders_mode(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Mode: Mirror (additive + removal)" in txt

    def test_renders_last_sync(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Last sync: 2026-04-19T10:00:00Z" in txt

    def test_renders_never_when_no_last_sync(self):
        cfg = {**_sample_config(), "last_sync_at": None}
        txt = render_audience_sync_detail_text_fallback(
            config=cfg, config_id="42"
        )
        assert "Last sync: never" in txt

    def test_renders_created_at(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "Created: 2026-04-01T00:00:00Z" in txt

    def test_renders_recent_runs_section(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "## Recent runs" in txt

    def test_renders_run_summary_line(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "Total: 3" in txt
        assert "1 succeeded" in txt
        assert "1 failed" in txt
        assert "1 running" in txt

    def test_renders_run_ids(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "- #1 [success]" in txt
        assert "- #2 [failed]" in txt
        assert "- #3 [running]" in txt

    def test_renders_run_member_deltas(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "+1.2k" in txt
        assert "-50" in txt

    def test_renders_run_error_message(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=_sample_runs()
        )
        assert "error: Rate limited by platform" in txt

    def test_no_runs_section_when_runs_none(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=None
        )
        assert "## Recent runs" not in txt

    def test_empty_runs_shows_no_runs_message(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=[]
        )
        assert "## Recent runs" in txt
        assert "No runs yet for this sync" in txt

    def test_caps_runs_to_five(self):
        runs = [
            {"id": i, "status": "success", "started_at": f"2026-04-0{i}"}
            for i in range(1, 9)
        ]
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=runs
        )
        assert "- #1 [success]" in txt
        assert "- #5 [success]" in txt
        assert "(+3 more run(s) omitted)" in txt

    def test_drill_down_hint_includes_runs_uri(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "g8://audience-syncs/42/runs" in txt

    def test_drill_down_hint_includes_dashboard(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert "g8://audience-syncs" in txt

    def test_trailing_newline(self):
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42"
        )
        assert txt.endswith("\n")

    def test_truncates_long_error_message(self):
        long_err = "E" * 500
        runs = [{"id": 1, "status": "failed", "error_message": long_err}]
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=runs
        )
        # Long error should be clipped to MAX (240)
        # The emitted line is "    error: <clipped>" — count E's on that line
        err_lines = [ln for ln in txt.split("\n") if ln.strip().startswith("error:")]
        assert err_lines, "expected at least one error line"
        # Clipped to 240 chars of E
        assert len(err_lines[0].split("error: ", 1)[1]) <= 260

    def test_unmapped_status_still_renders(self):
        cfg = {**_sample_config(), "status": "weird"}
        txt = render_audience_sync_detail_text_fallback(
            config=cfg, config_id="42"
        )
        assert "Status: **weird**" in txt

    def test_runs_with_only_started_at(self):
        runs = [{"id": 1, "status": "running", "started_at": "2026-04-20"}]
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=runs
        )
        assert "- #1 [running] \u2014 2026-04-20" in txt

    def test_runs_with_no_timestamps(self):
        runs = [{"id": 1, "status": "pending"}]
        txt = render_audience_sync_detail_text_fallback(
            config=_sample_config(), config_id="42", runs=runs
        )
        # Should render cleanly without a trailing em-dash
        assert "- #1 [pending]" in txt
        # Should NOT have trailing " — "
        line = next(
            ln for ln in txt.split("\n") if ln.strip().startswith("- #1")
        )
        assert not line.rstrip().endswith("\u2014")
