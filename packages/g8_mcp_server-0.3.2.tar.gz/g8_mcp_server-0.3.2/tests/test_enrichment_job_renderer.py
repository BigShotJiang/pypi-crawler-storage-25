"""Unit tests for the enrichment-job app surface renderer (Upgrade 4 #36).

Covers:
  * helper functions: normalize_status, status_palette, progress_pct,
    success_rate, parse_iso, duration_label, stat_card
  * empty states: None job (backend unavailable / 404)
  * full HTML render: header with status pill, 6-stat grid, progress
    bar with status-matched fill, success-rate sub-line with
    threshold colors (green >=70, amber >=40, red <40), provider
    waterfall with -> separators, timeline, drill-up pointers
  * status palette: queued/pending/processing/running/in_progress/
    completed/done/succeeded/failed/error/cancelled/canceled + unknown
  * progress_pct: division-by-zero safety, clamping, non-numeric input
  * success_rate: None when processed=0, clamping
  * parse_iso: datetime passthrough, Z-suffix, invalid
  * duration_label: seconds/minutes/hours/days/negative/missing
  * provider sequence: empty / one / many / overflow cap / clipping
    long names
  * XSS escape: status, field name, providers, job id, timestamps
  * text fallback parity
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from g8_mcp_server.app_renderer import (
    _ENRICHMENT_JOB_STATUS_PALETTE,
    _MAX_ENRICHMENT_FIELD_NAME_LEN,
    _MAX_ENRICHMENT_PROVIDER_NAME_LEN,
    _MAX_ENRICHMENT_PROVIDER_SEQUENCE_RENDERED,
    _enrichment_job_duration_label,
    _enrichment_job_normalize_status,
    _enrichment_job_parse_iso,
    _enrichment_job_progress_pct,
    _enrichment_job_stat_card,
    _enrichment_job_status_palette,
    _enrichment_job_success_rate,
    _render_enrichment_job_empty_state_html,
    render_enrichment_job_html,
    render_enrichment_job_text_fallback,
)


# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------


def _make_job(**overrides):
    base = {
        "id": "job_01hxk8m3p4nv2r9qw5e7t6yu8z",
        "field_to_enrich": "email",
        "status": "processing",
        "total_records": 1000,
        "processed_records": 500,
        "successful_enrichments": 400,
        "failed_enrichments": 100,
        "total_credits_used": 800,
        "provider_sequence": ["ZoomInfo", "Apollo", "Cognism"],
        "created_at": "2026-04-20T10:00:00Z",
        "started_at": "2026-04-20T10:01:00Z",
        "completed_at": "2026-04-20T10:16:00Z",
    }
    base.update(overrides)
    return base


# ===========================================================================
# _enrichment_job_normalize_status
# ===========================================================================


class TestNormalizeStatus:
    def test_returns_lowercase_for_known_status(self):
        assert _enrichment_job_normalize_status("PROCESSING") == "processing"

    def test_strips_whitespace(self):
        assert _enrichment_job_normalize_status("  completed  ") == "completed"

    def test_canceled_normalizes_to_cancelled(self):
        assert _enrichment_job_normalize_status("canceled") == "cancelled"

    def test_canceled_with_casing(self):
        assert _enrichment_job_normalize_status("CANCELED") == "cancelled"

    def test_cancelled_stays_cancelled(self):
        assert _enrichment_job_normalize_status("cancelled") == "cancelled"

    def test_empty_string_returns_unknown(self):
        assert _enrichment_job_normalize_status("") == "unknown"

    def test_whitespace_only_returns_unknown(self):
        assert _enrichment_job_normalize_status("   ") == "unknown"

    def test_none_returns_unknown(self):
        assert _enrichment_job_normalize_status(None) == "unknown"

    def test_non_string_returns_unknown(self):
        assert _enrichment_job_normalize_status(42) == "unknown"
        assert _enrichment_job_normalize_status([]) == "unknown"
        assert _enrichment_job_normalize_status({}) == "unknown"


# ===========================================================================
# _enrichment_job_status_palette
# ===========================================================================


class TestStatusPalette:
    @pytest.mark.parametrize(
        "status,expected_label",
        [
            ("queued", "QUEUED"),
            ("pending", "PENDING"),
            ("processing", "PROCESSING"),
            ("running", "RUNNING"),
            ("in_progress", "IN PROGRESS"),
            ("completed", "COMPLETED"),
            ("done", "DONE"),
            ("succeeded", "SUCCEEDED"),
            ("failed", "FAILED"),
            ("error", "ERROR"),
            ("cancelled", "CANCELLED"),
            ("canceled", "CANCELLED"),  # alias
        ],
    )
    def test_known_statuses(self, status, expected_label):
        text_color, bg_color, border_color, label = (
            _enrichment_job_status_palette(status)
        )
        assert label == expected_label
        # graph8 palette uses hex, rgba(), and `transparent` — all three
        # are valid CSS color values.
        for value in (text_color, bg_color, border_color):
            assert (
                value.startswith("#")
                or value.startswith("rgba(")
                or value == "transparent"
            ), f"unexpected color literal: {value!r}"

    def test_casing_is_normalized(self):
        _, _, _, label_upper = _enrichment_job_status_palette("PROCESSING")
        _, _, _, label_lower = _enrichment_job_status_palette("processing")
        assert label_upper == label_lower == "PROCESSING"

    def test_unknown_status_returns_neutral(self):
        text_color, bg_color, border_color, label = (
            _enrichment_job_status_palette("mystery_state")
        )
        assert label == "MYSTERY STATE"
        # graph8 ghost variant: --text-color-muted on transparent with --border
        assert text_color == "#777777"
        assert bg_color == "transparent"
        assert border_color == "#dfdfdf"

    def test_none_status_returns_unknown_label(self):
        _, _, _, label = _enrichment_job_status_palette(None)
        assert label == "UNKNOWN"

    def test_empty_status_returns_unknown_label(self):
        _, _, _, label = _enrichment_job_status_palette("")
        assert label == "UNKNOWN"

    def test_palette_dict_completeness(self):
        """Sanity check: palette dict contains expected keys."""
        for key in ("queued", "processing", "completed", "failed", "cancelled"):
            assert key in _ENRICHMENT_JOB_STATUS_PALETTE

    def test_processing_uses_primary(self):
        """Processing maps to graph8 primary purple (shadcn outline variant)."""
        color, bg, _, _ = _enrichment_job_status_palette("processing")
        assert color == "#7d2df3"  # --primary
        assert bg == "#f2eafe"  # --accent (primary tint)

    def test_completed_uses_positive(self):
        """Completed maps to graph8 positive (emerald on mint)."""
        color, bg, _, _ = _enrichment_job_status_palette("completed")
        assert color == "#059669"  # --positive-foreground
        assert bg == "#d1fae5"  # --positive

    def test_failed_uses_destructive(self):
        """Failed maps to graph8 destructive."""
        color, bg, _, _ = _enrichment_job_status_palette("failed")
        assert color == "#fffcfc"  # --destructive-foreground
        assert bg.startswith("rgba(202,50,20")  # --destructive at 90%

    def test_cancelled_uses_ghost(self):
        """Cancelled maps to graph8 ghost (muted on transparent)."""
        color, bg, _, _ = _enrichment_job_status_palette("cancelled")
        assert color == "#777777"  # --text-color-muted
        assert bg == "transparent"


# ===========================================================================
# _enrichment_job_progress_pct
# ===========================================================================


class TestProgressPct:
    def test_basic_percentage(self):
        assert _enrichment_job_progress_pct(50, 100) == 50.0

    def test_zero_processed(self):
        assert _enrichment_job_progress_pct(0, 100) == 0.0

    def test_full_completion(self):
        assert _enrichment_job_progress_pct(100, 100) == 100.0

    def test_zero_total_division_safety(self):
        assert _enrichment_job_progress_pct(5, 0) == 0.0

    def test_none_total(self):
        assert _enrichment_job_progress_pct(5, None) == 0.0

    def test_none_processed(self):
        assert _enrichment_job_progress_pct(None, 100) == 0.0

    def test_both_none(self):
        assert _enrichment_job_progress_pct(None, None) == 0.0

    def test_negative_total(self):
        assert _enrichment_job_progress_pct(5, -10) == 0.0

    def test_processed_exceeds_total_clamps(self):
        assert _enrichment_job_progress_pct(150, 100) == 100.0

    def test_non_numeric_processed(self):
        assert _enrichment_job_progress_pct("abc", 100) == 0.0

    def test_non_numeric_total(self):
        assert _enrichment_job_progress_pct(5, "xyz") == 0.0

    def test_fractional_percentage(self):
        result = _enrichment_job_progress_pct(1, 3)
        assert 33.0 < result < 34.0

    def test_string_numeric_inputs_work(self):
        # int() accepts numeric strings
        assert _enrichment_job_progress_pct("50", "100") == 50.0


# ===========================================================================
# _enrichment_job_success_rate
# ===========================================================================


class TestSuccessRate:
    def test_basic_rate(self):
        assert _enrichment_job_success_rate(80, 100) == 80.0

    def test_zero_processed_returns_none(self):
        assert _enrichment_job_success_rate(0, 0) is None

    def test_none_processed_returns_none(self):
        assert _enrichment_job_success_rate(5, None) is None

    def test_none_success(self):
        assert _enrichment_job_success_rate(None, 100) == 0.0

    def test_both_none_returns_none(self):
        assert _enrichment_job_success_rate(None, None) is None

    def test_full_success(self):
        assert _enrichment_job_success_rate(100, 100) == 100.0

    def test_success_exceeds_processed_clamps(self):
        assert _enrichment_job_success_rate(150, 100) == 100.0

    def test_negative_processed_returns_none(self):
        # int(-5) is -5, and the function guards on p <= 0
        assert _enrichment_job_success_rate(5, -5) is None

    def test_non_numeric_returns_none(self):
        assert _enrichment_job_success_rate("abc", 100) is None
        assert _enrichment_job_success_rate(50, "xyz") is None

    def test_fractional_rate(self):
        result = _enrichment_job_success_rate(1, 3)
        assert 33.0 < result < 34.0


# ===========================================================================
# _enrichment_job_parse_iso
# ===========================================================================


class TestParseIso:
    def test_basic_iso_string(self):
        dt = _enrichment_job_parse_iso("2026-04-20T10:00:00+00:00")
        assert dt is not None
        assert dt.year == 2026
        assert dt.month == 4

    def test_z_suffix_converted(self):
        dt = _enrichment_job_parse_iso("2026-04-20T10:00:00Z")
        assert dt is not None
        assert dt.tzinfo is not None

    def test_datetime_passthrough(self):
        original = datetime(2026, 4, 20, 10, 0, 0, tzinfo=timezone.utc)
        result = _enrichment_job_parse_iso(original)
        assert result is original

    def test_naive_datetime_passthrough(self):
        original = datetime(2026, 4, 20, 10, 0, 0)
        result = _enrichment_job_parse_iso(original)
        assert result is original

    def test_none_returns_none(self):
        assert _enrichment_job_parse_iso(None) is None

    def test_empty_string_returns_none(self):
        assert _enrichment_job_parse_iso("") is None

    def test_whitespace_only_returns_none(self):
        assert _enrichment_job_parse_iso("   ") is None

    def test_invalid_string_returns_none(self):
        assert _enrichment_job_parse_iso("not a date") is None

    def test_garbage_type_returns_none(self):
        assert _enrichment_job_parse_iso(42) is None
        assert _enrichment_job_parse_iso([]) is None
        assert _enrichment_job_parse_iso({}) is None

    def test_date_only_string(self):
        # `fromisoformat` accepts date-only strings in 3.11+
        dt = _enrichment_job_parse_iso("2026-04-20")
        # Either parses or returns None; should not raise
        assert dt is None or isinstance(dt, datetime)


# ===========================================================================
# _enrichment_job_duration_label
# ===========================================================================


class TestDurationLabel:
    def test_seconds(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:00:45Z"
        assert _enrichment_job_duration_label(start, end) == "45s"

    def test_zero_seconds(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:00:00Z"
        assert _enrichment_job_duration_label(start, end) == "0s"

    def test_minutes_and_seconds(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:02:30Z"
        assert _enrichment_job_duration_label(start, end) == "2m 30s"

    def test_exact_minute(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:01:00Z"
        assert _enrichment_job_duration_label(start, end) == "1m 0s"

    def test_hours_and_minutes(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T12:30:00Z"
        assert _enrichment_job_duration_label(start, end) == "2h 30m"

    def test_days_and_hours(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-22T15:00:00Z"
        assert _enrichment_job_duration_label(start, end) == "2d 5h"

    def test_negative_duration_returns_dash(self):
        start = "2026-04-20T11:00:00Z"
        end = "2026-04-20T10:00:00Z"
        assert _enrichment_job_duration_label(start, end) == "—"

    def test_missing_start_returns_dash(self):
        assert _enrichment_job_duration_label(None, "2026-04-20T10:00:00Z") == "—"

    def test_missing_end_returns_dash(self):
        assert _enrichment_job_duration_label("2026-04-20T10:00:00Z", None) == "—"

    def test_both_missing_returns_dash(self):
        assert _enrichment_job_duration_label(None, None) == "—"

    def test_invalid_start_returns_dash(self):
        assert _enrichment_job_duration_label("garbage", "2026-04-20T10:00:00Z") == "—"

    def test_invalid_end_returns_dash(self):
        assert _enrichment_job_duration_label("2026-04-20T10:00:00Z", "garbage") == "—"

    def test_datetime_instances_work(self):
        start = datetime(2026, 4, 20, 10, 0, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 20, 10, 0, 30, tzinfo=timezone.utc)
        assert _enrichment_job_duration_label(start, end) == "30s"

    def test_just_under_minute(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:00:59Z"
        assert _enrichment_job_duration_label(start, end) == "59s"

    def test_just_under_hour(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-20T10:59:59Z"
        assert _enrichment_job_duration_label(start, end) == "59m 59s"

    def test_exactly_24_hours_becomes_days(self):
        start = "2026-04-20T10:00:00Z"
        end = "2026-04-21T10:00:00Z"
        assert _enrichment_job_duration_label(start, end) == "1d 0h"


# ===========================================================================
# _enrichment_job_stat_card
# ===========================================================================


class TestStatCard:
    def test_basic_card(self):
        html = _enrichment_job_stat_card("Total", "100")
        assert "Total" in html
        assert "100" in html
        assert "stat-card" in html
        assert "stat-label" in html
        assert "stat-value" in html

    def test_card_accent_kwarg_ignored(self):
        """Design-system parity: accent kwarg is accepted but NOT rendered.

        Accent bars were removed in the 2026-04-20 graph8-frontend-parity
        refactor (single-side colored borders are an AI visual tell).
        Cards use a uniform shadcn Card style across all states.
        """
        # Passing accent must not inject a border-top accent anywhere.
        html = _enrichment_job_stat_card("Processed", "42", accent="#3b82f6")
        assert "#3b82f6" not in html
        assert "border-top:3px solid" not in html
        assert "border-top" not in html

    def test_card_without_accent(self):
        html = _enrichment_job_stat_card("Count", "5")
        assert "border-top:3px solid" not in html
        assert "border-top" not in html

    def test_card_uses_graph8_card_border(self):
        """Uniform shadcn Card border (1px solid --border)."""
        html = _enrichment_job_stat_card("Count", "5")
        assert "#dfdfdf" in html  # --border
        assert "border-radius:12px" in html  # --radius-card

    def test_card_has_shadow_xs(self):
        """Cards use --shadow-xs not border-top accent."""
        html = _enrichment_job_stat_card("Count", "5")
        assert "box-shadow" in html

    def test_escapes_label(self):
        html = _enrichment_job_stat_card("<script>x</script>", "10")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_value(self):
        html = _enrichment_job_stat_card("Bad", "<img>alert</img>")
        assert "<img>" not in html
        assert "&lt;img&gt;" in html


# ===========================================================================
# _render_enrichment_job_empty_state_html
# ===========================================================================


class TestEmptyState:
    def test_contains_job_id(self):
        html = _render_enrichment_job_empty_state_html(job_id="job_xyz")
        assert "job_xyz" in html

    def test_has_title(self):
        html = _render_enrichment_job_empty_state_html(job_id="j1")
        assert "Enrichment job not available" in html

    def test_valid_html_doctype(self):
        html = _render_enrichment_job_empty_state_html(job_id="j1")
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_empty_job_id_fallback(self):
        html = _render_enrichment_job_empty_state_html(job_id="")
        assert "(unknown)" in html

    def test_escapes_job_id(self):
        html = _render_enrichment_job_empty_state_html(
            job_id="<script>alert(1)</script>"
        )
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_clips_very_long_job_id(self):
        long_id = "x" * 1000
        html = _render_enrichment_job_empty_state_html(job_id=long_id)
        # Should not include the entire string verbatim (clipped to 64)
        assert long_id not in html

    def test_has_graph8_card_border(self):
        """Empty state uses uniform shadcn Card border, no accent line."""
        html = _render_enrichment_job_empty_state_html(job_id="j1")
        assert "#dfdfdf" in html  # --border
        assert "border-top:3px solid" not in html  # no AI-tell accent

    def test_uses_aeonik_font(self):
        html = _render_enrichment_job_empty_state_html(job_id="j1")
        assert "Aeonik" in html


# ===========================================================================
# render_enrichment_job_html — full render
# ===========================================================================


class TestRenderEnrichmentJobHtml:
    def test_none_job_returns_empty_state(self):
        html = render_enrichment_job_html(job=None, job_id="j1")
        assert "Enrichment job not available" in html

    def test_non_dict_job_returns_empty_state(self):
        html = render_enrichment_job_html(job=[], job_id="j1")
        assert "Enrichment job not available" in html
        html2 = render_enrichment_job_html(job="not a dict", job_id="j1")
        assert "Enrichment job not available" in html2

    def test_full_job_renders(self):
        html = render_enrichment_job_html(job=_make_job(), job_id="j1")
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_header_shows_field(self):
        html = render_enrichment_job_html(
            job=_make_job(field_to_enrich="phone_number"),
            job_id="j1",
        )
        assert "phone_number" in html

    def test_header_unknown_field_fallback(self):
        html = render_enrichment_job_html(
            job=_make_job(field_to_enrich=None),
            job_id="j1",
        )
        assert "(unknown field)" in html

    def test_status_pill_shown(self):
        html = render_enrichment_job_html(
            job=_make_job(status="processing"),
            job_id="j1",
        )
        assert "PROCESSING" in html

    def test_status_pill_unknown(self):
        html = render_enrichment_job_html(
            job=_make_job(status=""),
            job_id="j1",
        )
        assert "UNKNOWN" in html

    def test_canceled_status_normalizes(self):
        html = render_enrichment_job_html(
            job=_make_job(status="canceled"),
            job_id="j1",
        )
        assert "CANCELLED" in html

    def test_job_id_in_header(self):
        html = render_enrichment_job_html(
            job=_make_job(id="custom_job_123"),
            job_id="fallback",
        )
        assert "custom_job_123" in html

    def test_falls_back_to_path_job_id(self):
        html = render_enrichment_job_html(
            job=_make_job(id=None),
            job_id="path_id_777",
        )
        assert "path_id_777" in html

    def test_stat_grid_shows_all_counts(self):
        html = render_enrichment_job_html(
            job=_make_job(
                total_records=1234,
                processed_records=567,
                successful_enrichments=445,
                failed_enrichments=122,
                total_credits_used=890,
            ),
            job_id="j1",
        )
        assert "1234" in html
        assert "567" in html
        assert "445" in html
        assert "122" in html
        assert "890" in html

    def test_stat_labels_present(self):
        html = render_enrichment_job_html(job=_make_job(), job_id="j1")
        for label in ("Total records", "Processed", "Success", "Failed",
                      "Credits used", "Duration"):
            assert label in html

    def test_progress_bar_rendered(self):
        html = render_enrichment_job_html(
            job=_make_job(total_records=100, processed_records=50),
            job_id="j1",
        )
        assert "Progress" in html
        assert "50.0%" in html
        assert "50 / 100 records" in html

    def test_progress_bar_fill_completed_positive(self):
        """Completed progress bar uses graph8 --positive-foreground."""
        html = render_enrichment_job_html(
            job=_make_job(
                status="completed",
                total_records=100,
                processed_records=100,
            ),
            job_id="j1",
        )
        assert "#059669" in html  # --positive-foreground

    def test_progress_bar_fill_failed_destructive(self):
        """Failed progress bar uses graph8 --destructive."""
        html = render_enrichment_job_html(
            job=_make_job(status="failed"),
            job_id="j1",
        )
        assert "#ca3214" in html  # --destructive

    def test_progress_bar_fill_cancelled_muted(self):
        """Cancelled progress bar uses graph8 --text-color-muted."""
        html = render_enrichment_job_html(
            job=_make_job(status="cancelled"),
            job_id="j1",
        )
        assert "#777777" in html

    def test_progress_bar_fill_processing_primary(self):
        """Processing progress bar uses graph8 --primary (purple)."""
        html = render_enrichment_job_html(
            job=_make_job(status="processing"),
            job_id="j1",
        )
        assert "#7d2df3" in html  # --primary

    def test_success_rate_high_positive(self):
        """Success rate >=70 uses graph8 --positive-foreground."""
        html = render_enrichment_job_html(
            job=_make_job(
                successful_enrichments=80,
                processed_records=100,
            ),
            job_id="j1",
        )
        assert "80.0%" in html
        assert "#059669" in html  # --positive-foreground

    def test_success_rate_medium_warning(self):
        """Success rate 40-70 uses graph8 --warning-foreground."""
        html = render_enrichment_job_html(
            job=_make_job(
                successful_enrichments=50,
                processed_records=100,
            ),
            job_id="j1",
        )
        assert "50.0%" in html
        assert "#a0750a" in html  # --warning-foreground

    def test_success_rate_low_destructive(self):
        """Success rate <40 uses graph8 --destructive."""
        html = render_enrichment_job_html(
            job=_make_job(
                successful_enrichments=10,
                processed_records=100,
            ),
            job_id="j1",
        )
        assert "10.0%" in html
        assert "#ca3214" in html  # --destructive

    def test_success_rate_hidden_when_nothing_processed(self):
        html = render_enrichment_job_html(
            job=_make_job(
                successful_enrichments=0,
                processed_records=0,
            ),
            job_id="j1",
        )
        assert "Success rate over processed records" not in html

    def test_provider_sequence_rendered(self):
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=["Apollo", "ZoomInfo"]),
            job_id="j1",
        )
        assert "Apollo" in html
        assert "ZoomInfo" in html
        assert "→" in html  # waterfall separator

    def test_single_provider_no_separator(self):
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=["OnlyOne"]),
            job_id="j1",
        )
        assert "OnlyOne" in html
        # Should NOT have a trailing arrow after single provider
        # (we only add → between items, not after the last)
        chips_section_idx = html.find("Provider waterfall")
        assert chips_section_idx >= 0
        section = html[chips_section_idx:chips_section_idx + 400]
        # One provider, zero separators in the chip block
        assert section.count("→") == 0

    def test_empty_provider_sequence_shows_fallback(self):
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=[]),
            job_id="j1",
        )
        assert "No provider sequence configured" in html

    def test_missing_provider_sequence_shows_fallback(self):
        job = _make_job()
        del job["provider_sequence"]
        html = render_enrichment_job_html(job=job, job_id="j1")
        assert "No provider sequence configured" in html

    def test_non_list_provider_sequence_shows_fallback(self):
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence="not-a-list"),
            job_id="j1",
        )
        assert "No provider sequence configured" in html

    def test_provider_sequence_overflow(self):
        providers = [f"Provider{i}" for i in range(20)]
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=providers),
            job_id="j1",
        )
        rendered = _MAX_ENRICHMENT_PROVIDER_SEQUENCE_RENDERED
        overflow = 20 - rendered
        assert f"+ {overflow} more" in html
        # First rendered provider is visible, one past the cap is not
        assert f"Provider{rendered - 1}" in html

    def test_provider_sequence_clips_long_names(self):
        long_name = "X" * (_MAX_ENRICHMENT_PROVIDER_NAME_LEN + 20)
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=[long_name]),
            job_id="j1",
        )
        # Ellipsis appended after clipping
        assert "…" in html
        # Full long name should not appear verbatim
        assert long_name not in html

    def test_provider_sequence_position_numbered(self):
        html = render_enrichment_job_html(
            job=_make_job(provider_sequence=["A", "B", "C"]),
            job_id="j1",
        )
        assert "#1" in html
        assert "#2" in html
        assert "#3" in html

    def test_timeline_timestamps_shown(self):
        html = render_enrichment_job_html(
            job=_make_job(
                created_at="2026-04-20T10:00:00Z",
                started_at="2026-04-20T10:01:00Z",
                completed_at="2026-04-20T10:16:00Z",
            ),
            job_id="j1",
        )
        assert "2026-04-20T10:00:00Z" in html
        assert "2026-04-20T10:01:00Z" in html
        assert "2026-04-20T10:16:00Z" in html

    def test_timeline_missing_timestamps_dash(self):
        html = render_enrichment_job_html(
            job=_make_job(
                created_at=None,
                started_at=None,
                completed_at=None,
            ),
            job_id="j1",
        )
        assert "Timeline" in html
        assert "—" in html

    def test_duration_in_stat_grid(self):
        html = render_enrichment_job_html(
            job=_make_job(
                started_at="2026-04-20T10:00:00Z",
                completed_at="2026-04-20T10:15:00Z",
            ),
            job_id="j1",
        )
        assert "15m 0s" in html

    def test_duration_dash_when_missing(self):
        html = render_enrichment_job_html(
            job=_make_job(started_at=None, completed_at=None),
            job_id="j1",
        )
        # Stat card for Duration will show dash
        assert "—" in html

    def test_drill_up_present(self):
        html = render_enrichment_job_html(job=_make_job(), job_id="j1"),
        html = html[0]  # unwrap tuple from comma above
        assert "Drill into this job" in html
        assert "/progress" in html
        assert "/enrichment/jobs-active" in html

    def test_xss_escape_in_status(self):
        html = render_enrichment_job_html(
            job=_make_job(status="<script>alert(1)</script>"),
            job_id="j1",
        )
        assert "<script>" not in html

    def test_xss_escape_in_field_name(self):
        html = render_enrichment_job_html(
            job=_make_job(field_to_enrich="<img onerror=alert(1)>"),
            job_id="j1",
        )
        assert "<img" not in html
        assert "&lt;img" in html

    def test_xss_escape_in_provider(self):
        html = render_enrichment_job_html(
            job=_make_job(
                provider_sequence=["<script>alert(1)</script>"],
            ),
            job_id="j1",
        )
        assert "<script>" not in html

    def test_xss_escape_in_job_id(self):
        html = render_enrichment_job_html(
            job=_make_job(id="<script>x</script>"),
            job_id="j1",
        )
        assert "<script>x</script>" not in html

    def test_xss_escape_in_timestamp(self):
        html = render_enrichment_job_html(
            job=_make_job(created_at="<script>evil</script>"),
            job_id="j1",
        )
        assert "<script>evil</script>" not in html

    def test_field_name_clipping(self):
        long_field = "Y" * (_MAX_ENRICHMENT_FIELD_NAME_LEN + 100)
        html = render_enrichment_job_html(
            job=_make_job(field_to_enrich=long_field),
            job_id="j1",
        )
        assert long_field not in html

    def test_valid_html_shape(self):
        html = render_enrichment_job_html(job=_make_job(), job_id="j1")
        assert html.count("<!DOCTYPE html>") == 1
        assert html.count("<html") == 1
        assert html.count("</html>") == 1
        assert html.count("<body") == 1
        assert html.count("</body>") == 1

    def test_stat_cards_have_uniform_border(self):
        """All stat cards use the same graph8 --border color (#dfdfdf).

        No single-side accent colors differentiating success/failed/credits.
        The stat values carry the semantic meaning, not card chrome.
        """
        html = render_enrichment_job_html(
            job=_make_job(
                successful_enrichments=0,
                failed_enrichments=0,
                total_credits_used=0,
            ),
            job_id="j1",
        )
        # Uniform --border color present
        assert html.count("#dfdfdf") >= 6  # at least one per card
        # No accent colors formerly used on stat cards
        assert "#9ca3af" not in html  # old gray accent
        assert "#16a34a" not in html  # old green
        assert "#dc2626" not in html  # old red
        assert "#6366f1" not in html  # old indigo
        assert "#f59e0b" not in html  # old amber
        assert "#8b5cf6" not in html  # old violet

    def test_nonzero_credits_renders_but_no_accent(self):
        html = render_enrichment_job_html(
            job=_make_job(total_credits_used=500),
            job_id="j1",
        )
        assert "Credits used" in html
        assert "500" in html
        # No single-side colored accent bar regardless of credit count
        assert "border-top:3px solid" not in html


# ===========================================================================
# render_enrichment_job_text_fallback
# ===========================================================================


class TestTextFallback:
    def test_none_job_returns_not_available(self):
        text = render_enrichment_job_text_fallback(job=None, job_id="j1")
        assert "Enrichment job not available" in text
        assert "j1" in text

    def test_non_dict_job_returns_not_available(self):
        text = render_enrichment_job_text_fallback(job=[], job_id="j1")
        assert "Enrichment job not available" in text

    def test_header_with_field(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(field_to_enrich="email"),
            job_id="j1",
        )
        assert "# Enrichment job — email" in text

    def test_contains_job_id(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(id="my_job"),
            job_id="fallback",
        )
        assert "my_job" in text

    def test_status_uppercased(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(status="processing"),
            job_id="j1",
        )
        assert "PROCESSING" in text

    def test_stats_section(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(
                total_records=500,
                processed_records=250,
                successful_enrichments=200,
                failed_enrichments=50,
                total_credits_used=400,
            ),
            job_id="j1",
        )
        assert "## Stats" in text
        assert "Total records: 500" in text
        assert "Processed: 250" in text
        assert "Success: 200" in text
        assert "Failed: 50" in text
        assert "Credits used: 400" in text

    def test_progress_percentage_in_stats(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(total_records=100, processed_records=75),
            job_id="j1",
        )
        assert "75.0%" in text

    def test_success_rate_shown_when_processed(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(
                successful_enrichments=80,
                processed_records=100,
            ),
            job_id="j1",
        )
        assert "Success rate (over processed): 80.0%" in text
        assert "(80/100)" in text

    def test_success_rate_hidden_when_zero_processed(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(processed_records=0, successful_enrichments=0),
            job_id="j1",
        )
        assert "Success rate" not in text

    def test_provider_waterfall_section(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(provider_sequence=["Apollo", "ZoomInfo"]),
            job_id="j1",
        )
        assert "## Provider waterfall" in text
        assert "1. Apollo" in text
        assert "2. ZoomInfo" in text

    def test_provider_waterfall_empty(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(provider_sequence=[]),
            job_id="j1",
        )
        assert "(no provider sequence configured)" in text

    def test_provider_overflow_plural(self):
        providers = [f"P{i}" for i in range(_MAX_ENRICHMENT_PROVIDER_SEQUENCE_RENDERED + 3)]
        text = render_enrichment_job_text_fallback(
            job=_make_job(provider_sequence=providers),
            job_id="j1",
        )
        assert "+ 3 more providers in sequence" in text

    def test_provider_overflow_singular(self):
        providers = [f"P{i}" for i in range(_MAX_ENRICHMENT_PROVIDER_SEQUENCE_RENDERED + 1)]
        text = render_enrichment_job_text_fallback(
            job=_make_job(provider_sequence=providers),
            job_id="j1",
        )
        assert "+ 1 more provider in sequence" in text

    def test_provider_clipping_in_text(self):
        long_name = "Z" * (_MAX_ENRICHMENT_PROVIDER_NAME_LEN + 10)
        text = render_enrichment_job_text_fallback(
            job=_make_job(provider_sequence=[long_name]),
            job_id="j1",
        )
        assert "…" in text
        assert long_name not in text

    def test_timeline_section(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(
                created_at="2026-04-20T10:00:00Z",
                started_at="2026-04-20T10:01:00Z",
                completed_at="2026-04-20T10:16:00Z",
            ),
            job_id="j1",
        )
        assert "## Timeline" in text
        assert "Created: 2026-04-20T10:00:00Z" in text
        assert "Started: 2026-04-20T10:01:00Z" in text
        assert "Completed: 2026-04-20T10:16:00Z" in text

    def test_timeline_missing_dashes(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(
                created_at=None,
                started_at=None,
                completed_at=None,
            ),
            job_id="j1",
        )
        assert "Created: —" in text

    def test_drill_up_in_text(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(id="job_xyz"),
            job_id="fallback",
        )
        assert "## Drill into this job" in text
        assert "GET /enrichment/jobs/job_xyz/progress" in text
        assert "GET /enrichment/jobs-active" in text

    def test_trailing_newline(self):
        text = render_enrichment_job_text_fallback(job=_make_job(), job_id="j1")
        assert text.endswith("\n")
        # Only ONE trailing newline
        assert not text.endswith("\n\n")

    def test_unknown_field_fallback(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(field_to_enrich=None),
            job_id="j1",
        )
        assert "(unknown field)" in text

    def test_no_html_in_text_fallback(self):
        text = render_enrichment_job_text_fallback(job=_make_job(), job_id="j1")
        # Plain text / markdown — NO HTML tags
        assert "<div" not in text
        assert "<span" not in text
        assert "<section" not in text

    def test_duration_in_stats(self):
        text = render_enrichment_job_text_fallback(
            job=_make_job(
                started_at="2026-04-20T10:00:00Z",
                completed_at="2026-04-20T10:30:00Z",
            ),
            job_id="j1",
        )
        assert "Duration: 30m 0s" in text


# ===========================================================================
# Smoke tests
# ===========================================================================


class TestSmoke:
    def test_minimal_job_renders(self):
        """Renderer should not crash on bare-bones job dict."""
        html = render_enrichment_job_html(job={}, job_id="j1")
        assert html.startswith("<!DOCTYPE html>")

    def test_minimal_job_text(self):
        text = render_enrichment_job_text_fallback(job={}, job_id="j1")
        assert "Enrichment job" in text

    def test_all_statuses_render(self):
        for status in (
            "queued", "pending", "processing", "running", "in_progress",
            "completed", "done", "succeeded", "failed", "error",
            "cancelled", "canceled", "unknown_new_status",
        ):
            html = render_enrichment_job_html(
                job=_make_job(status=status),
                job_id="j1",
            )
            assert html.startswith("<!DOCTYPE html>")
            text = render_enrichment_job_text_fallback(
                job=_make_job(status=status),
                job_id="j1",
            )
            assert "## Stats" in text

    def test_all_numeric_fields_as_strings(self):
        """Some backends may return counts as strings; should still render."""
        html = render_enrichment_job_html(
            job={
                "id": "j1",
                "status": "completed",
                "total_records": "100",
                "processed_records": "100",
                "successful_enrichments": "95",
                "failed_enrichments": "5",
                "total_credits_used": "150",
            },
            job_id="j1",
        )
        assert "100" in html
        assert "95" in html
