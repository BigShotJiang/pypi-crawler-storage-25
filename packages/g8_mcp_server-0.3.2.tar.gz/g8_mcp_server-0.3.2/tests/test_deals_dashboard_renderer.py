"""Unit tests for HTML app surface #60 — deals dashboard renderer.

Locks regression invariants for:
  - graph8 design tokens (no legacy accent hexes, no single-side colored
    accent borders)
  - drill-up card does NOT self-list the dashboard URI
  - no <script> / javascript: / inline event handlers
  - pagination safety: `total >= visible` override, `total < visible`
    ignored (clamped to `len(deals)`)
  - XSS escape on every user-controlled field (name, description,
    stage_name, currency, deal_id in drill-down URI)
  - display name fallback (name → `(unnamed deal)`)
  - amount parser rejects bool, negative, NaN, inf
  - close-date horizon ladder (overdue → no close date) deterministic
  - dominant currency selection + pipeline caveat when mixed
  - sort key: amount-having deals come first, amount desc, no-amount last
  - smoke tests on realistic and empty payloads
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from g8_mcp_server import app_renderer as ar

# Anchor "today" at a fixed date so close-date bucket tests stay
# deterministic across CI/clock drift.
_NOW = datetime(2026, 5, 1, 12, 0, 0, tzinfo=timezone.utc)

_BASE_DEAL = {
    "id": "deal-111",
    "name": "Acme Enterprise License",
    "description": "3yr ELA for the analytics platform.",
    "amount": 150000.0,
    "currency": "USD",
    "stage_id": "stage-1",
    "stage_name": "Proposal",
    "pipeline_id": "pipe-1",
    "company_id": 101,
    "owner_id": "owner-1",
    "close_date": "2026-06-15",
    "created_at": "2026-03-01T00:00:00+00:00",
    "updated_at": "2026-04-15T00:00:00+00:00",
}

_SAMPLE_DEALS: list[dict] = [
    _BASE_DEAL,  # 150k USD, this quarter
    {
        "id": "deal-222",
        "name": "Beta Annual Renewal",
        "description": "Renewal for the mid-market plan.",
        "amount": 42000,
        "currency": "USD",
        "stage_name": "Negotiation",
        "pipeline_id": "pipe-1",
        "company_id": 102,
        "close_date": "2026-05-05",  # this week
    },
    {
        "id": "deal-333",
        "name": "Gamma Pilot",
        "description": None,
        "amount": "8500",  # string amount
        "currency": "EUR",
        "stage_name": "Discovery",
        "close_date": "2026-04-15",  # overdue
    },
    {
        "id": "deal-444",
        "name": "Delta Holdings Expansion",
        "amount": 250000.5,
        "currency": "USD",
        "stage_name": "Proposal",  # duplicate — tests bucketing
        "close_date": "2027-01-01",  # later
    },
    {
        # Anonymous deal — no id/name/amount/close_date to test defaults
        "stage_name": "Lead",
    },
]


# -------------------------------- #
# _deals_dashboard_clip           #
# -------------------------------- #

class TestClip:
    def test_non_string_returns_empty(self):
        assert ar._deals_dashboard_clip(None, 50) == ""
        assert ar._deals_dashboard_clip(123, 50) == ""
        assert ar._deals_dashboard_clip([], 50) == ""

    def test_empty_string_returns_empty(self):
        assert ar._deals_dashboard_clip("", 50) == ""
        assert ar._deals_dashboard_clip("   ", 50) == ""

    def test_short_string_passes_through(self):
        assert ar._deals_dashboard_clip("hello", 50) == "hello"

    def test_clips_long_string(self):
        result = ar._deals_dashboard_clip("x" * 100, 20)
        assert len(result) <= 20
        assert result.endswith("…")

    def test_html_escapes(self):
        result = ar._deals_dashboard_clip("<script>evil</script>", 100)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_strips_whitespace(self):
        assert ar._deals_dashboard_clip("  hello  ", 50) == "hello"


# -------------------------------- #
# _deals_dashboard_display_name   #
# -------------------------------- #

class TestDisplayName:
    def test_name_present(self):
        assert ar._deals_dashboard_display_name({"name": "Enterprise Deal"}) == "Enterprise Deal"

    def test_missing_name_falls_back(self):
        assert ar._deals_dashboard_display_name({}) == "(unnamed deal)"

    def test_blank_name_falls_back(self):
        assert ar._deals_dashboard_display_name({"name": "   "}) == "(unnamed deal)"

    def test_none_name_falls_back(self):
        assert ar._deals_dashboard_display_name({"name": None}) == "(unnamed deal)"

    def test_non_string_name_falls_back(self):
        assert ar._deals_dashboard_display_name({"name": 123}) == "(unnamed deal)"

    def test_html_escapes_name(self):
        result = ar._deals_dashboard_display_name({"name": "<evil>"})
        assert "<evil>" not in result
        assert "&lt;evil&gt;" == result

    def test_clips_long_name(self):
        long_name = "x" * 200
        result = ar._deals_dashboard_display_name({"name": long_name})
        assert len(result) <= ar._MAX_DEALS_DASHBOARD_NAME_LEN


# -------------------------------- #
# _deals_dashboard_parse_amount   #
# -------------------------------- #

class TestParseAmount:
    def test_int(self):
        assert ar._deals_dashboard_parse_amount(42) == 42.0

    def test_float(self):
        assert ar._deals_dashboard_parse_amount(42.5) == 42.5

    def test_zero(self):
        assert ar._deals_dashboard_parse_amount(0) == 0.0
        assert ar._deals_dashboard_parse_amount(0.0) == 0.0

    def test_string_plain(self):
        assert ar._deals_dashboard_parse_amount("42") == 42.0

    def test_string_with_commas(self):
        assert ar._deals_dashboard_parse_amount("1,000,000") == 1000000.0

    def test_string_with_whitespace(self):
        assert ar._deals_dashboard_parse_amount("  42.5  ") == 42.5

    def test_bool_rejected(self):
        # Python: bool is a subclass of int — `True + 1` works silently.
        # Reject explicitly to avoid silent coercion.
        assert ar._deals_dashboard_parse_amount(True) is None
        assert ar._deals_dashboard_parse_amount(False) is None

    def test_negative_rejected(self):
        assert ar._deals_dashboard_parse_amount(-1) is None
        assert ar._deals_dashboard_parse_amount(-0.01) is None
        assert ar._deals_dashboard_parse_amount("-100") is None

    def test_nan_rejected(self):
        assert ar._deals_dashboard_parse_amount(float("nan")) is None
        assert ar._deals_dashboard_parse_amount("nan") is None

    def test_inf_rejected(self):
        assert ar._deals_dashboard_parse_amount(float("inf")) is None
        assert ar._deals_dashboard_parse_amount(float("-inf")) is None

    def test_unparseable_string_rejected(self):
        assert ar._deals_dashboard_parse_amount("abc") is None
        assert ar._deals_dashboard_parse_amount("") is None
        assert ar._deals_dashboard_parse_amount("   ") is None

    def test_none_rejected(self):
        assert ar._deals_dashboard_parse_amount(None) is None

    def test_list_rejected(self):
        assert ar._deals_dashboard_parse_amount([1, 2]) is None


# -------------------------------- #
# _deals_dashboard_has_amount     #
# -------------------------------- #

class TestHasAmount:
    def test_has_amount_true(self):
        assert ar._deals_dashboard_has_amount({"amount": 100}) is True

    def test_has_amount_zero_true(self):
        # Zero is a valid amount (no-cost trial / internal swap)
        assert ar._deals_dashboard_has_amount({"amount": 0}) is True

    def test_has_amount_missing_false(self):
        assert ar._deals_dashboard_has_amount({}) is False

    def test_has_amount_none_false(self):
        assert ar._deals_dashboard_has_amount({"amount": None}) is False

    def test_has_amount_negative_false(self):
        assert ar._deals_dashboard_has_amount({"amount": -1}) is False


# -------------------------------- #
# _deals_dashboard_format_money   #
# -------------------------------- #

class TestFormatMoney:
    def test_int_formats_with_commas(self):
        assert ar._deals_dashboard_format_money(1000000, "USD") == "1,000,000 USD"

    def test_float_with_cents(self):
        assert ar._deals_dashboard_format_money(42.5, "USD") == "42.50 USD"

    def test_float_whole_no_cents(self):
        # 42.0 renders as "42" (no trailing .00)
        assert ar._deals_dashboard_format_money(42.0, "USD") == "42 USD"

    def test_no_currency(self):
        assert ar._deals_dashboard_format_money(42, None) == "42"

    def test_empty_currency(self):
        assert ar._deals_dashboard_format_money(42, "") == "42"
        assert ar._deals_dashboard_format_money(42, "   ") == "42"

    def test_currency_uppercased(self):
        assert ar._deals_dashboard_format_money(42, "usd") == "42 USD"


# -------------------------------- #
# _deals_dashboard_currency       #
# -------------------------------- #

class TestCurrency:
    def test_returns_uppercase(self):
        assert ar._deals_dashboard_currency({"currency": "usd"}) == "USD"

    def test_strips_whitespace(self):
        assert ar._deals_dashboard_currency({"currency": "  EUR  "}) == "EUR"

    def test_missing_returns_none(self):
        assert ar._deals_dashboard_currency({}) is None

    def test_blank_returns_none(self):
        assert ar._deals_dashboard_currency({"currency": "   "}) is None

    def test_non_string_returns_none(self):
        assert ar._deals_dashboard_currency({"currency": 123}) is None


# -------------------------------- #
# _deals_dashboard_parse_close_date #
# -------------------------------- #

class TestParseCloseDate:
    def test_date_only(self):
        parsed = ar._deals_dashboard_parse_close_date("2026-06-15")
        assert parsed is not None
        assert parsed.year == 2026
        assert parsed.month == 6
        assert parsed.day == 15

    def test_datetime_with_tz(self):
        parsed = ar._deals_dashboard_parse_close_date("2026-06-15T12:00:00+00:00")
        assert parsed is not None

    def test_datetime_z_suffix(self):
        # Z suffix (common backend format) gets normalized to +00:00
        parsed = ar._deals_dashboard_parse_close_date("2026-06-15T12:00:00Z")
        assert parsed is not None

    def test_naive_datetime_gets_utc(self):
        parsed = ar._deals_dashboard_parse_close_date("2026-06-15T12:00:00")
        assert parsed is not None
        assert parsed.tzinfo is not None

    def test_none_rejected(self):
        assert ar._deals_dashboard_parse_close_date(None) is None

    def test_empty_string_rejected(self):
        assert ar._deals_dashboard_parse_close_date("") is None
        assert ar._deals_dashboard_parse_close_date("   ") is None

    def test_invalid_string_rejected(self):
        assert ar._deals_dashboard_parse_close_date("not-a-date") is None
        assert ar._deals_dashboard_parse_close_date("2026/06/15") is None

    def test_non_string_rejected(self):
        assert ar._deals_dashboard_parse_close_date(1234567890) is None
        assert ar._deals_dashboard_parse_close_date(datetime.now()) is None


# -------------------------------- #
# _deals_dashboard_close_bucket   #
# -------------------------------- #

class TestCloseBucket:
    def test_overdue(self):
        # 2026-04-15 vs anchor 2026-05-01 = -16 days
        assert ar._deals_dashboard_close_bucket("2026-04-15", now=_NOW) == "overdue"

    def test_overdue_yesterday(self):
        assert ar._deals_dashboard_close_bucket("2026-04-30", now=_NOW) == "overdue"

    def test_this_week_today(self):
        assert ar._deals_dashboard_close_bucket("2026-05-01", now=_NOW) == "this week"

    def test_this_week_in_7_days(self):
        assert ar._deals_dashboard_close_bucket("2026-05-08", now=_NOW) == "this week"

    def test_this_month_in_8_days(self):
        assert ar._deals_dashboard_close_bucket("2026-05-09", now=_NOW) == "this month"

    def test_this_month_in_30_days(self):
        assert ar._deals_dashboard_close_bucket("2026-05-31", now=_NOW) == "this month"

    def test_this_quarter_in_31_days(self):
        assert ar._deals_dashboard_close_bucket("2026-06-01", now=_NOW) == "this quarter"

    def test_this_quarter_in_90_days(self):
        assert ar._deals_dashboard_close_bucket("2026-07-30", now=_NOW) == "this quarter"

    def test_later_in_91_days(self):
        assert ar._deals_dashboard_close_bucket("2026-07-31", now=_NOW) == "later"

    def test_later_next_year(self):
        assert ar._deals_dashboard_close_bucket("2027-05-01", now=_NOW) == "later"

    def test_no_close_date_missing(self):
        assert ar._deals_dashboard_close_bucket(None, now=_NOW) == "no close date"
        assert ar._deals_dashboard_close_bucket("", now=_NOW) == "no close date"
        assert ar._deals_dashboard_close_bucket("not-a-date", now=_NOW) == "no close date"

    def test_now_default_is_utc(self):
        # Without passing `now`, it should use current UTC time; just
        # verify it returns one of the valid bucket labels.
        result = ar._deals_dashboard_close_bucket("2030-01-01")
        assert result in ar._DEALS_DASHBOARD_HORIZON_BUCKETS


# -------------------------------- #
# _deals_dashboard_horizon_buckets #
# -------------------------------- #

class TestHorizonBuckets:
    def test_empty(self):
        assert ar._deals_dashboard_horizon_buckets([], now=_NOW) == []

    def test_ordered_ladder(self):
        # Mix deals across buckets; ladder order must be preserved.
        deals = [
            {"close_date": "2027-01-01"},  # later
            {"close_date": "2026-04-15"},  # overdue
            {"close_date": "2026-05-05"},  # this week
            {"close_date": None},          # no close date
        ]
        result = ar._deals_dashboard_horizon_buckets(deals, now=_NOW)
        labels = [lbl for lbl, _ in result]
        expected_order = ["overdue", "this week", "later", "no close date"]
        assert labels == expected_order

    def test_counts_aggregate(self):
        deals = [
            {"close_date": "2026-05-05"},
            {"close_date": "2026-05-06"},
            {"close_date": "2026-05-07"},
        ]
        result = ar._deals_dashboard_horizon_buckets(deals, now=_NOW)
        assert result == [("this week", 3)]

    def test_ignores_non_dicts(self):
        deals = [None, "not-a-dict", {"close_date": "2026-05-05"}]
        result = ar._deals_dashboard_horizon_buckets(deals, now=_NOW)
        assert result == [("this week", 1)]


# -------------------------------- #
# _deals_dashboard_horizon_palette #
# -------------------------------- #

class TestHorizonPalette:
    def test_overdue_destructive(self):
        bg, fg = ar._deals_dashboard_horizon_palette("overdue")
        assert "#ca3214" in fg

    def test_this_week_primary(self):
        bg, fg = ar._deals_dashboard_horizon_palette("this week")
        assert fg == ar._G8_PRIMARY

    def test_this_month_primary(self):
        bg, fg = ar._deals_dashboard_horizon_palette("this month")
        assert fg == ar._G8_PRIMARY

    def test_this_quarter_positive(self):
        bg, fg = ar._deals_dashboard_horizon_palette("this quarter")
        assert fg == ar._G8_POSITIVE_FG

    def test_later_muted(self):
        bg, fg = ar._deals_dashboard_horizon_palette("later")
        assert fg == ar._G8_TEXT_MUTED

    def test_no_close_date_muted(self):
        bg, fg = ar._deals_dashboard_horizon_palette("no close date")
        assert fg == ar._G8_TEXT_MUTED


# -------------------------------- #
# _deals_dashboard_bucket         #
# -------------------------------- #

class TestBucket:
    def test_empty(self):
        assert ar._deals_dashboard_bucket([], "stage_name") == []

    def test_sorts_by_count_desc(self):
        deals = [
            {"stage_name": "Proposal"},
            {"stage_name": "Discovery"},
            {"stage_name": "Proposal"},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        assert result[0] == ("Proposal", 2)

    def test_tie_broken_alphabetically(self):
        deals = [
            {"stage_name": "Won"},
            {"stage_name": "Discovery"},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        # Both have count 1; alphabetical tiebreak on lowercase
        labels = [lbl for lbl, _ in result]
        assert labels == ["Discovery", "Won"]

    def test_case_insensitive_grouping(self):
        deals = [
            {"stage_name": "proposal"},
            {"stage_name": "PROPOSAL"},
            {"stage_name": "Proposal"},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        # Three deals group into one bucket (first-seen casing wins)
        assert len(result) == 1
        assert result[0][1] == 3
        assert result[0][0] == "proposal"

    def test_preserves_display_casing(self):
        # First-seen "Mixed Case" display preserved over later casings.
        deals = [
            {"stage_name": "Mixed Case"},
            {"stage_name": "mixed case"},
            {"stage_name": "MIXED CASE"},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        assert len(result) == 1
        assert result[0][0] == "Mixed Case"

    def test_drops_non_strings(self):
        deals = [
            {"stage_name": "Proposal"},
            {"stage_name": None},
            {"stage_name": 123},
            {"stage_name": []},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        assert result == [("Proposal", 1)]

    def test_drops_blank_strings(self):
        deals = [
            {"stage_name": "Proposal"},
            {"stage_name": ""},
            {"stage_name": "   "},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        assert result == [("Proposal", 1)]

    def test_strips_whitespace(self):
        deals = [
            {"stage_name": "  Proposal  "},
            {"stage_name": "Proposal"},
        ]
        result = ar._deals_dashboard_bucket(deals, "stage_name")
        assert result == [("Proposal", 2)]


# -------------------------------- #
# _deals_dashboard_dominant_currency #
# -------------------------------- #

class TestDominantCurrency:
    def test_empty(self):
        assert ar._deals_dashboard_dominant_currency([]) == (None, 0)

    def test_single_currency(self):
        deals = [{"currency": "USD"}, {"currency": "USD"}]
        assert ar._deals_dashboard_dominant_currency(deals) == ("USD", 2)

    def test_mixed_currencies(self):
        deals = [
            {"currency": "USD"},
            {"currency": "USD"},
            {"currency": "EUR"},
        ]
        assert ar._deals_dashboard_dominant_currency(deals) == ("USD", 2)

    def test_alpha_tiebreak(self):
        # Equal counts → alphabetically earliest wins for determinism.
        deals = [
            {"currency": "USD"},
            {"currency": "EUR"},
        ]
        result = ar._deals_dashboard_dominant_currency(deals)
        assert result[0] == "EUR"

    def test_ignores_missing(self):
        deals = [
            {"currency": "USD"},
            {},
            {"currency": None},
        ]
        assert ar._deals_dashboard_dominant_currency(deals) == ("USD", 1)


# -------------------------------- #
# _deals_dashboard_total_value    #
# -------------------------------- #

class TestTotalValue:
    def test_empty(self):
        assert ar._deals_dashboard_total_value([], "USD") == 0.0
        assert ar._deals_dashboard_total_value([], None) == 0.0

    def test_sums_matching_currency(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "EUR"},
            {"amount": 50, "currency": "USD"},
        ]
        assert ar._deals_dashboard_total_value(deals, "USD") == 150.0

    def test_sums_all_when_currency_none(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "EUR"},
        ]
        # When currency filter is None, sum everything (caveat shown in UI)
        assert ar._deals_dashboard_total_value(deals, None) == 300.0

    def test_ignores_missing_amounts(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"currency": "USD"},  # no amount
            {"amount": None, "currency": "USD"},
        ]
        assert ar._deals_dashboard_total_value(deals, "USD") == 100.0


# -------------------------------- #
# _deals_dashboard_sort_key       #
# -------------------------------- #

class TestSortKey:
    def test_amount_having_deals_come_first(self):
        deals = [
            {"name": "A", "amount": None},
            {"name": "B", "amount": 100},
            {"name": "C"},
            {"name": "D", "amount": 50},
        ]
        sorted_deals = sorted(deals, key=ar._deals_dashboard_sort_key)
        names = [d["name"] for d in sorted_deals]
        # B (100) > D (50) > A, C (none — order among no-amount is stable)
        assert names[0] == "B"
        assert names[1] == "D"
        assert set(names[2:]) == {"A", "C"}

    def test_amount_desc(self):
        deals = [
            {"name": "small", "amount": 10},
            {"name": "big", "amount": 1000},
            {"name": "mid", "amount": 100},
        ]
        sorted_deals = sorted(deals, key=ar._deals_dashboard_sort_key)
        assert [d["name"] for d in sorted_deals] == ["big", "mid", "small"]


# -------------------------------- #
# _deals_dashboard_stat_card      #
# -------------------------------- #

class TestStatCard:
    def test_renders_label_and_value(self):
        html_out = ar._deals_dashboard_stat_card("Total", "42", accent="primary")
        assert "Total" in html_out
        assert "42" in html_out

    def test_primary_accent_uses_primary_color(self):
        html_out = ar._deals_dashboard_stat_card("X", "1", accent="primary")
        assert ar._G8_PRIMARY in html_out

    def test_positive_accent_uses_positive_fg(self):
        html_out = ar._deals_dashboard_stat_card("X", "1", accent="positive")
        assert ar._G8_POSITIVE_FG in html_out

    def test_unknown_accent_defaults_to_text(self):
        html_out = ar._deals_dashboard_stat_card("X", "1", accent="what-is-this")
        assert ar._G8_TEXT in html_out

    def test_escapes_user_input(self):
        html_out = ar._deals_dashboard_stat_card("<evil>", "<xss>", accent="text")
        assert "<evil>" not in html_out
        assert "<xss>" not in html_out

    def test_no_single_side_colored_accent_border(self):
        """Regression: graph8 design forbids one-sided colored accent borders."""
        html_out = ar._deals_dashboard_stat_card("X", "1", accent="primary")
        # Should use uniform `border:1px solid <color>`, never
        # `border-left:` / `border-top:` / `border-right:` / `border-bottom:`
        assert "border-left:" not in html_out
        assert "border-top:" not in html_out
        assert "border-right:" not in html_out
        assert "border-bottom:" not in html_out


# -------------------------------- #
# Chip helpers                    #
# -------------------------------- #

class TestChip:
    def test_escapes_label(self):
        out = ar._deals_dashboard_chip("<xss>", 1, bg="#fff", fg="#000")
        assert "<xss>" not in out
        assert "&lt;xss&gt;" in out

    def test_includes_count(self):
        out = ar._deals_dashboard_chip("label", 42, bg="#fff", fg="#000")
        assert "42" in out


class TestOverflowChip:
    def test_shows_remaining_and_suffix(self):
        out = ar._deals_dashboard_overflow_chip(5, "stage(s)")
        assert "5" in out
        assert "stage(s)" in out


# -------------------------------- #
# Empty state                     #
# -------------------------------- #

class TestEmptyState:
    def test_unavailable_mode(self):
        html_out = ar._render_deals_dashboard_empty_state_html("unavailable")
        assert "Deals dashboard not available" in html_out
        assert "GET /deals" in html_out

    def test_empty_mode(self):
        html_out = ar._render_deals_dashboard_empty_state_html("empty")
        assert "No deals yet" in html_out
        assert "POST /deals" in html_out

    def test_is_valid_html(self):
        html_out = ar._render_deals_dashboard_empty_state_html("empty")
        assert html_out.startswith("<!DOCTYPE html>")
        assert html_out.endswith("</html>")

    def test_empty_state_uses_graph8_font(self):
        html_out = ar._render_deals_dashboard_empty_state_html("empty")
        assert "Aeonik" in html_out

    def test_empty_state_uses_primary_accent(self):
        html_out = ar._render_deals_dashboard_empty_state_html("empty")
        assert ar._G8_PRIMARY in html_out


# -------------------------------- #
# render_deals_dashboard_html     #
# -------------------------------- #

class TestRenderHtml:
    def test_none_deals_returns_unavailable(self):
        html_out = ar.render_deals_dashboard_html(deals=None)
        assert "Deals dashboard not available" in html_out

    def test_empty_deals_returns_empty(self):
        html_out = ar.render_deals_dashboard_html(deals=[])
        assert "No deals yet" in html_out

    def test_empty_deals_with_total_zero(self):
        html_out = ar.render_deals_dashboard_html(deals=[], total=0)
        assert "No deals yet" in html_out

    def test_renders_title(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Deals dashboard" in html_out

    def test_shows_total_count_in_stats(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Total deals" in html_out
        # 5 deals in _SAMPLE_DEALS
        assert ">5<" in html_out

    def test_pagination_total_overrides_visible(self):
        html_out = ar.render_deals_dashboard_html(
            deals=_SAMPLE_DEALS, total=100, now=_NOW
        )
        assert "of 100 total" in html_out

    def test_pagination_total_lower_is_clamped(self):
        # total < visible should be ignored (clamped to visible count)
        html_out = ar.render_deals_dashboard_html(
            deals=_SAMPLE_DEALS, total=2, now=_NOW
        )
        # The effective total is len(deals)=5, not 2
        # Header suffix only shows when total > visible
        assert "of 2 total" not in html_out

    def test_pagination_total_equal_no_suffix(self):
        html_out = ar.render_deals_dashboard_html(
            deals=_SAMPLE_DEALS, total=5, now=_NOW
        )
        assert "of 5 total" not in html_out

    def test_renders_stage_section(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Stage mix" in html_out
        assert "Proposal" in html_out
        assert "Discovery" in html_out

    def test_renders_horizon_section(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Close date horizon" in html_out

    def test_renders_currency_section(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Currencies" in html_out
        assert "USD" in html_out
        assert "EUR" in html_out

    def test_shows_currency_caveat_when_mixed(self):
        """When deals use multiple currencies, a caveat is shown."""
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        # _SAMPLE_DEALS has 3 USD + 1 EUR amounts
        assert "dominant currency" in html_out

    def test_no_currency_caveat_when_single_currency(self):
        deals = [
            {"id": "a", "name": "A", "amount": 100, "currency": "USD"},
            {"id": "b", "name": "B", "amount": 200, "currency": "USD"},
        ]
        html_out = ar.render_deals_dashboard_html(deals=deals, now=_NOW)
        assert "dominant currency" not in html_out

    def test_renders_deal_rows(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Acme Enterprise License" in html_out
        assert "Beta Annual Renewal" in html_out
        assert "Gamma Pilot" in html_out

    def test_deals_sorted_by_amount_desc(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        # Delta 250k > Acme 150k > Beta 42k > Gamma 8.5k
        delta_pos = html_out.index("Delta Holdings Expansion")
        acme_pos = html_out.index("Acme Enterprise License")
        beta_pos = html_out.index("Beta Annual Renewal")
        gamma_pos = html_out.index("Gamma Pilot")
        assert delta_pos < acme_pos < beta_pos < gamma_pos

    def test_anonymous_deal_renders_with_fallback(self):
        # The 5th deal has no name — should show "(unnamed deal)"
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "(unnamed deal)" in html_out

    def test_xss_escape_name(self):
        malicious = [{
            "id": "x",
            "name": '<script>alert("xss")</script>',
            "amount": 100,
        }]
        html_out = ar.render_deals_dashboard_html(deals=malicious)
        assert "<script>" not in html_out

    def test_xss_escape_description(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "description": '<img src=x onerror=alert(1)>',
            "amount": 100,
        }]
        html_out = ar.render_deals_dashboard_html(deals=malicious)
        assert "<img src=x" not in html_out

    def test_xss_escape_stage_name(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "stage_name": '<svg onload=alert(1)>',
            "amount": 100,
        }]
        html_out = ar.render_deals_dashboard_html(deals=malicious)
        assert "<svg onload=" not in html_out

    def test_xss_escape_currency(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "amount": 100,
            "currency": "<script>USD</script>",
        }]
        html_out = ar.render_deals_dashboard_html(deals=malicious)
        assert "<script>" not in html_out

    def test_xss_escape_deal_id_in_drill_down(self):
        malicious = [{
            "id": '<script>xss</script>',
            "name": "A",
            "amount": 100,
        }]
        html_out = ar.render_deals_dashboard_html(deals=malicious)
        assert "<script>xss</script>" not in html_out
        assert "&lt;script&gt;xss&lt;/script&gt;" in html_out

    def test_renders_drill_down_for_valid_deal_id(self):
        deals = [{"id": "deal-111", "name": "A", "amount": 100}]
        html_out = ar.render_deals_dashboard_html(deals=deals)
        assert "g8://deals/deal-111" in html_out

    def test_renders_company_drill_down(self):
        deals = [{"id": "a", "name": "A", "amount": 100, "company_id": 42}]
        html_out = ar.render_deals_dashboard_html(deals=deals)
        assert "g8://companies/42" in html_out

    def test_drill_up_does_NOT_list_self(self):
        """Regression: drill-up card must not self-reference /dashboard."""
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        # Find the "Related surfaces" drill-up block
        drill_start = html_out.index("Related surfaces")
        drill_block = html_out[drill_start:]
        assert "g8://deals/dashboard" not in drill_block

    def test_drill_up_lists_related_surfaces(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "g8://deals/pipeline" in html_out
        assert "g8://pipelines/overview" in html_out

    def test_no_script_tags(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "<script" not in html_out
        assert "</script" not in html_out

    def test_no_javascript(self):
        """Regression: no javascript: URLs or on* event handlers."""
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "javascript:" not in html_out.lower()
        assert 'onclick="' not in html_out.lower()
        assert 'onload="' not in html_out.lower()
        assert 'onerror="' not in html_out.lower()

    def test_no_legacy_accent_hexes(self):
        """Regression: no pre-graph8 accent hexes."""
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        legacy = ["#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"]
        for hex_code in legacy:
            assert hex_code not in html_out

    def test_no_single_side_colored_accent_border(self):
        """Regression: no one-sided colored borders in any card."""
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "border-left:" not in html_out
        assert "border-top:" not in html_out
        assert "border-right:" not in html_out
        assert "border-bottom:" not in html_out

    def test_uses_graph8_font(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Aeonik" in html_out

    def test_uses_graph8_primary(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert ar._G8_PRIMARY in html_out

    def test_overflow_card_when_over_limit(self):
        deals = [{"id": f"d{i}", "name": f"Deal {i}", "amount": i + 1} for i in range(60)]
        html_out = ar.render_deals_dashboard_html(deals=deals)
        remaining = 60 - ar._MAX_DEALS_DASHBOARD_RENDERED
        assert f"+ {remaining} more deal(s)" in html_out

    def test_no_overflow_card_at_or_below_limit(self):
        deals = [
            {"id": f"d{i}", "name": f"Deal {i}", "amount": i + 1}
            for i in range(ar._MAX_DEALS_DASHBOARD_RENDERED)
        ]
        html_out = ar.render_deals_dashboard_html(deals=deals)
        assert "more deal(s)" not in html_out

    def test_overdue_badge_shown_on_row(self):
        deals = [{
            "id": "x", "name": "Overdue One", "amount": 100,
            "close_date": "2026-01-01",
        }]
        html_out = ar.render_deals_dashboard_html(deals=deals, now=_NOW)
        assert "OVERDUE" in html_out

    def test_no_close_date_no_horizon_badge(self):
        deals = [{"id": "x", "name": "Nodate", "amount": 100}]
        html_out = ar.render_deals_dashboard_html(deals=deals, now=_NOW)
        assert "NO CLOSE DATE" not in html_out  # badge skipped


# -------------------------------- #
# render_deals_dashboard_text_fallback #
# -------------------------------- #

class TestTextFallback:
    def test_none_deals_returns_unavailable(self):
        text = ar.render_deals_dashboard_text_fallback(deals=None)
        assert "not available" in text

    def test_empty_deals_returns_empty(self):
        text = ar.render_deals_dashboard_text_fallback(deals=[])
        assert "No deals yet" in text

    def test_renders_title(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "# Deals dashboard" in text

    def test_renders_stats_block(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Total deals: 5" in text
        assert "With close date" in text

    def test_shows_pipeline_value(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        # USD is dominant; total = 150000 + 42000 + 250000.50 = 442000.50
        assert "Pipeline value" in text
        assert "USD" in text

    def test_shows_avg_deal_size(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "Avg deal size" in text

    def test_no_pipeline_value_when_no_amounts(self):
        deals = [{"id": "a", "name": "A"}]
        text = ar.render_deals_dashboard_text_fallback(deals=deals, now=_NOW)
        assert "Pipeline value" not in text

    def test_renders_stages_section(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "## Stages" in text
        assert "Proposal (2)" in text

    def test_renders_horizon_section(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "## Close date horizon" in text

    def test_renders_currencies_section(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "## Currencies" in text
        assert "USD" in text
        assert "EUR" in text

    def test_renders_deals_section(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "## Deals" in text
        assert "Acme Enterprise License" in text

    def test_drill_down_uri(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "g8://deals/deal-111" in text

    def test_manage_pointers(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "## Manage deals" in text
        assert "g8://deals/pipeline" in text
        assert "g8://pipelines/overview" in text

    def test_drill_up_does_not_self_reference(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        # The "Manage deals" section is our drill-up block
        manage_start = text.index("## Manage deals")
        manage_block = text[manage_start:]
        assert "g8://deals/dashboard" not in manage_block

    def test_pagination_total_override(self):
        text = ar.render_deals_dashboard_text_fallback(
            deals=_SAMPLE_DEALS, total=100, now=_NOW
        )
        assert "of 100 total" in text

    def test_pagination_total_lower_is_clamped(self):
        text = ar.render_deals_dashboard_text_fallback(
            deals=_SAMPLE_DEALS, total=2, now=_NOW
        )
        assert "of 2 total" not in text
        assert "Total deals: 5" in text

    def test_anonymous_deal_fallback(self):
        text = ar.render_deals_dashboard_text_fallback(deals=_SAMPLE_DEALS, now=_NOW)
        assert "(unnamed deal)" in text

    def test_overflow_notice(self):
        deals = [
            {"id": f"d{i}", "name": f"Deal {i}", "amount": i + 1}
            for i in range(60)
        ]
        text = ar.render_deals_dashboard_text_fallback(deals=deals)
        remaining = 60 - ar._MAX_DEALS_DASHBOARD_RENDERED
        assert f"+ {remaining} more deal(s)" in text


# -------------------------------- #
# Smoke tests                     #
# -------------------------------- #

class TestSmoke:
    def test_realistic_payload_does_not_crash(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, now=_NOW)
        assert html_out.startswith("<!DOCTYPE html>")
        assert html_out.endswith("</html>")

    def test_empty_string_payload(self):
        # Extremely defensive — should not crash on empty list
        html_out = ar.render_deals_dashboard_html(deals=[])
        assert "<!DOCTYPE html>" in html_out

    def test_all_ignored_items(self):
        # All items filtered out (non-dict) — should behave like empty list
        html_out = ar.render_deals_dashboard_html(deals=[None, "not-a-dict", 42])
        # effective_total becomes 0 (all filtered) → empty state
        assert "No deals yet" in html_out

    def test_none_total_ok(self):
        html_out = ar.render_deals_dashboard_html(deals=_SAMPLE_DEALS, total=None)
        assert "<!DOCTYPE html>" in html_out
