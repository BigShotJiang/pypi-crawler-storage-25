"""Tests for the lists dashboard HTML + text renderers (upgrade 4 — #8)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _count_for_list,
    _group_lists_by_type,
    _list_type_color,
    render_lists_dashboard_html,
    render_lists_dashboard_text_fallback,
)


def _list_item(idx: int = 0, **overrides) -> dict:
    """Default list dict matching `ListItem`."""
    base = {
        "id": idx,
        "title": f"List {idx}",
        "type": "contacts",
        "total_contacts": 100,
        "total_companies": 0,
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-15T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestListTypeColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _list_type_color("contacts") == "#7d2df3"  # _G8_PRIMARY
        assert _list_type_color("people") == "#7d2df3"  # _G8_PRIMARY
        assert _list_type_color("companies") == "#059669"  # _G8_POSITIVE_FG
        assert _list_type_color("accounts") == "#059669"  # _G8_POSITIVE_FG

    def test_case_and_whitespace(self):
        assert _list_type_color("CONTACTS") == "#7d2df3"  # _G8_PRIMARY
        assert _list_type_color(" Companies ") == "#059669"  # _G8_POSITIVE_FG

    def test_unknown(self):
        assert _list_type_color("weird") == "#777777"
        assert _list_type_color(None) == "#777777"
        assert _list_type_color("") == "#777777"

    def test_no_banned_hexes_in_type_palette(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _LIST_TYPE_COLORS
        for k, v in _LIST_TYPE_COLORS.items():
            assert v.lower() not in banned, f"type={k!r} hex={v!r} is banned"


class TestCountForList:
    def test_contacts_only(self):
        assert _count_for_list({"total_contacts": 10}) == 10

    def test_companies_only(self):
        assert _count_for_list({"total_companies": 5}) == 5

    def test_both(self):
        assert _count_for_list({"total_contacts": 10, "total_companies": 5}) == 15

    def test_empty(self):
        assert _count_for_list({}) == 0

    def test_non_int_values_ignored(self):
        # Non-int values are ignored, not coerced
        assert _count_for_list({"total_contacts": "nope", "total_companies": 3}) == 3
        assert _count_for_list({"total_contacts": None, "total_companies": None}) == 0


class TestGroupListsByType:
    def test_empty(self):
        assert _group_lists_by_type([]) == []

    def test_ordering(self):
        lists = [
            _list_item(idx=1, type="accounts"),
            _list_item(idx=2, type="contacts"),
            _list_item(idx=3, type="companies"),
        ]
        result = _group_lists_by_type(lists)
        keys = [k for k, _ in result]
        # contacts first, then companies, then accounts
        assert keys.index("contacts") < keys.index("companies")
        assert keys.index("companies") < keys.index("accounts")

    def test_missing_type_bucketed_as_other(self):
        result = _group_lists_by_type(
            [_list_item(type=None), _list_item(type="")]
        )
        assert result[0][0] == "other"
        assert len(result[0][1]) == 2

    def test_unknown_types_preserve_insertion_order(self):
        lists = [
            _list_item(idx=1, type="alpha"),
            _list_item(idx=2, type="contacts"),
            _list_item(idx=3, type="beta"),
        ]
        result = _group_lists_by_type(lists)
        keys = [k for k, _ in result]
        # Preferred (contacts) comes first, then insertion order for unknowns
        assert keys == ["contacts", "alpha", "beta"]


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderListsDashboardHtml:
    def test_empty_state(self):
        html_out = render_lists_dashboard_html(lists=None)
        assert "No lists yet" in html_out

        html_out2 = render_lists_dashboard_html(lists=[])
        assert "No lists yet" in html_out2

    def test_non_list_input(self):
        html_out = render_lists_dashboard_html(lists="nope")  # type: ignore[arg-type]
        assert "No lists yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_lists_dashboard_html(lists=[None, "x", 1])  # type: ignore[list-item]
        assert "No lists yet" in html_out

    def test_renders_list_row(self):
        html_out = render_lists_dashboard_html(lists=[_list_item()])
        assert "List 0" in html_out
        assert "100" in html_out  # total
        assert "contacts" in html_out

    def test_type_grouping_rendered(self):
        html_out = render_lists_dashboard_html(
            lists=[
                _list_item(type="contacts"),
                _list_item(idx=1, type="companies", total_contacts=0, total_companies=50),
            ]
        )
        assert "contacts" in html_out
        assert "companies" in html_out

    def test_missing_title_fallback(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(title=None)]
        )
        assert "(untitled)" in html_out

    def test_total_badge(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(total_contacts=1234, total_companies=0)]
        )
        # Formatted with commas
        assert "1,234" in html_out

    def test_org_label(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_sort_by_total_desc(self):
        html_out = render_lists_dashboard_html(
            lists=[
                _list_item(idx=1, title="Small", total_contacts=5),
                _list_item(idx=2, title="Big", total_contacts=5000),
                _list_item(idx=3, title="Medium", total_contacts=500),
            ]
        )
        # Big should appear before Medium, which appears before Small.
        big_pos = html_out.find("Big")
        med_pos = html_out.find("Medium")
        small_pos = html_out.find("Small")
        assert big_pos < med_pos < small_pos

    def test_count_breakdown_contacts_and_companies(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(total_contacts=10, total_companies=5)]
        )
        assert "10 contacts" in html_out
        assert "5 companies" in html_out


class TestEscaping:
    def test_title_escaped(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(title="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_type_name_escaped(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(type="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_updated_timestamp_escaped(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(updated_at="<b>2026</b>")]
        )
        assert "<b>2026</b>" not in html_out


class TestBounds:
    def test_max_lists_rendered(self):
        lists = [_list_item(idx=i, title=f"L_{i}") for i in range(120)]
        html_out = render_lists_dashboard_html(lists=lists)
        # Within the cap range, first by sort (all same size, so insertion order).
        assert "L_0" in html_out
        assert "L_119" not in html_out  # past cap 80
        assert "omitted" in html_out

    def test_long_title_truncated(self):
        html_out = render_lists_dashboard_html(
            lists=[_list_item(title="t" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestListsDashboardTextFallback:
    def test_empty(self):
        out = render_lists_dashboard_text_fallback(lists=None)
        assert "No lists yet" in out

        out2 = render_lists_dashboard_text_fallback(lists=[])
        assert "No lists yet" in out2

    def test_non_list(self):
        out = render_lists_dashboard_text_fallback(lists="nope")  # type: ignore[arg-type]
        assert "No lists yet" in out

    def test_renders_key_fields(self):
        out = render_lists_dashboard_text_fallback(lists=[_list_item()])
        assert "List 0" in out
        assert "100" in out  # total count

    def test_type_grouping(self):
        out = render_lists_dashboard_text_fallback(
            lists=[
                _list_item(type="contacts"),
                _list_item(idx=1, type="companies", total_contacts=0, total_companies=50),
            ]
        )
        assert "## contacts" in out
        assert "## companies" in out

    def test_org_label(self):
        out = render_lists_dashboard_text_fallback(
            lists=[_list_item()], org_label="Acme"
        )
        assert "# Lists — Acme" in out

    def test_max_cap_footer(self):
        lists = [_list_item(idx=i) for i in range(120)]
        out = render_lists_dashboard_text_fallback(lists=lists)
        assert "more list(s)" in out

    def test_no_html_leak(self):
        out = render_lists_dashboard_text_fallback(
            lists=[_list_item(title="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_LISTS_RENDERED >= 10
        assert app_renderer._MAX_LIST_TITLE_LEN >= 50
