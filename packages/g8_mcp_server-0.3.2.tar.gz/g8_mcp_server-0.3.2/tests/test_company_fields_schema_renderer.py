"""Unit tests for Surface #45 — company fields schema renderer.

Narrower scope than surface #44's 116 tests since all structural
helpers (clip, is_custom, is_global, custom_count, list_specific_count,
datatypes, sort, stat_card) are SHARED with #44 and fully covered
there. This suite asserts:
  * Company-flavored empty-state copy
  * Main HTML renderer uses COMPANY-specific drill-up links
    (GET /fields/companies, entity=companies, sibling
    g8://fields/contacts)
  * Text fallback uses company-flavored headings
  * Regression lock: drill-up points at CONTACT sibling, NOT itself
  * Regression lock: no single-side accent borders, no legacy hexes
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _render_company_fields_schema_empty_state_html,
    render_company_fields_schema_html,
    render_company_fields_schema_text_fallback,
)


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode_mentions_entity_companies(self):
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        assert "POST /fields" in html
        assert "entity=companies" in html

    def test_unavailable_mode_mentions_get_fields_companies(self):
        html = _render_company_fields_schema_empty_state_html(mode="unavailable")
        assert "GET /fields/companies" in html

    def test_empty_mode_uses_primary_color(self):
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        assert "#7d2df3" in html

    def test_unavailable_mode_uses_muted_color(self):
        html = _render_company_fields_schema_empty_state_html(mode="unavailable")
        assert "#777777" in html

    def test_uses_graph8_font(self):
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        assert "Aeonik" in html

    def test_uses_graph8_border(self):
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        assert "#dfdfdf" in html

    def test_valid_doctype(self):
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        assert html.startswith("<!DOCTYPE html>")

    def test_heading_mentions_company(self):
        empty = _render_company_fields_schema_empty_state_html(mode="empty")
        unavail = _render_company_fields_schema_empty_state_html(
            mode="unavailable"
        )
        assert "company" in empty.lower()
        assert "company" in unavail.lower()

    def test_regression_empty_mode_does_NOT_say_contacts(self):
        """Lock: don't accidentally copy surface #44's contact copy."""
        html = _render_company_fields_schema_empty_state_html(mode="empty")
        # should NOT say "No contact fields" — this is the company surface
        assert "No contact fields" not in html
        assert "entity=contacts" not in html


# ---------------------------------------------------------------------------
# Main HTML renderer
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def _sample_fields(self):
        return [
            {
                "id": None,
                "title": "Company Name",
                "name": "company_name",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": None,
                "title": "Industry",
                "name": "industry",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": 101,
                "title": "ARR",
                "name": "arr",
                "data_type": "number",
                "is_global": True,
            },
            {
                "id": 102,
                "title": "Account Tier",
                "name": "account_tier",
                "data_type": "text",
                "is_global": False,  # list-specific
            },
        ]

    def test_none_fields_returns_unavailable(self):
        html = render_company_fields_schema_html(fields=None)
        assert "not available" in html.lower()
        assert "GET /fields/companies" in html

    def test_empty_list_returns_empty_state(self):
        html = render_company_fields_schema_html(fields=[])
        assert "No company fields" in html
        assert "entity=companies" in html

    def test_renders_total_stat(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert ">4</div>" in html

    def test_renders_base_and_custom(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        # 2 base (Company Name, Industry) + 2 custom (ARR, Account Tier)
        # Both appear as stats
        assert "BASE" in html.upper()
        assert "CUSTOM" in html.upper()

    def test_renders_list_specific_stat(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "LIST-SPECIFIC" in html.upper()

    def test_renders_data_types(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "Data types" in html
        assert "text" in html
        assert "number" in html

    def test_renders_field_rows(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "Company Name" in html
        assert "ARR" in html
        assert "Account Tier" in html

    def test_drill_up_points_at_get_fields_companies(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "GET /fields/companies" in html

    def test_drill_up_mentions_entity_companies(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "entity=companies" in html

    def test_drill_up_sibling_is_contacts(self):
        """Regression lock: drill-up points AT the contacts sibling, not
        at ourselves. Self-reference would be a copy-paste bug."""
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "g8://fields/contacts" in html
        # Must NOT self-reference
        assert "g8://fields/companies</code>" not in html.lower()

    def test_drill_up_mentions_crm_provider_sibling(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "g8://crm-syncs/" in html

    def test_title_says_companies_not_contacts(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "Companies schema" in html
        # Must NOT accidentally still say Contacts schema (copy-paste)
        assert "Contacts schema" not in html
        # …except as a drill-up pointer text. Check that the <h1> header
        # is the company one.
        assert "<h1" in html and "Companies schema" in html

    def test_header_subtitle_says_company(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "company field registry" in html

    def test_regression_title_tag_includes_companies(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "<title>Fields — Companies schema (4)</title>" in html

    def test_custom_badge_on_custom_rows(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "CUSTOM" in html

    def test_list_specific_badge_on_non_global(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "LIST-SPECIFIC" in html

    def test_html_escapes_titles(self):
        fields = [
            {
                "title": "<script>alert(1)</script>",
                "name": "x",
                "data_type": "text",
                "is_global": True,
            }
        ]
        html = render_company_fields_schema_html(fields=fields)
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_uses_graph8_primary(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "#7d2df3" in html

    def test_uses_graph8_border(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "#dfdfdf" in html

    def test_uses_graph8_font(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "Aeonik" in html

    def test_no_single_side_accent_borders(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "border-left:" not in html
        assert "border-top:" not in html
        assert "border-right:" not in html
        assert "border-bottom:" not in html

    def test_no_legacy_accent_hexes(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "#e5e7eb" not in html
        assert "#f3f4f6" not in html
        assert "#6b7280" not in html
        assert "#111827" not in html

    def test_total_chip_in_header(self):
        html = render_company_fields_schema_html(fields=self._sample_fields())
        assert "4 TOTAL" in html

    def test_overflow_note_when_exceeds_cap(self):
        fields = [
            {
                "id": None,
                "title": f"field {i}",
                "name": f"f{i}",
                "data_type": "text",
                "is_global": True,
            }
            for i in range(85)
        ]
        html = render_company_fields_schema_html(fields=fields)
        assert "5 more fields" in html

    def test_skips_non_dicts(self):
        fields = [
            {
                "id": None,
                "title": "Real",
                "name": "r",
                "data_type": "text",
                "is_global": True,
            },
            "not a dict",
            None,
            42,
        ]
        html = render_company_fields_schema_html(fields=fields)
        assert ">1</div>" in html

    def test_id_shown_for_custom_only(self):
        fields = [{"id": 99, "title": "Custom", "name": "c", "data_type": "text", "is_global": True}]
        html = render_company_fields_schema_html(fields=fields)
        assert "id=99" in html

    def test_id_none_not_leaked(self):
        fields = [{"id": None, "title": "Base", "name": "b", "data_type": "text", "is_global": True}]
        html = render_company_fields_schema_html(fields=fields)
        assert "id=None" not in html

    def test_base_sort_before_custom(self):
        fields = [
            {"id": 99, "title": "AAA custom", "name": "a", "data_type": "text", "is_global": True},
            {"id": None, "title": "ZZZ base", "name": "z", "data_type": "text", "is_global": True},
        ]
        html = render_company_fields_schema_html(fields=fields)
        z_pos = html.find("ZZZ base")
        a_pos = html.find("AAA custom")
        assert z_pos != -1 and a_pos != -1
        assert z_pos < a_pos


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def _sample_fields(self):
        return [
            {
                "id": None,
                "title": "Company Name",
                "name": "company_name",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": 42,
                "title": "ARR",
                "name": "arr",
                "data_type": "number",
                "is_global": True,
            },
            {
                "id": 43,
                "title": "Tier",
                "name": "tier",
                "data_type": "text",
                "is_global": False,
            },
        ]

    def test_none_returns_unavailable(self):
        text = render_company_fields_schema_text_fallback(fields=None)
        assert "not available" in text.lower()
        assert "GET /fields/companies" in text

    def test_empty_returns_empty_state(self):
        text = render_company_fields_schema_text_fallback(fields=[])
        assert "no company fields" in text.lower()
        assert "entity=companies" in text

    def test_starts_with_markdown_header(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert text.startswith("# Companies schema")

    def test_stats_section(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "- Total: 3" in text
        assert "- Base: 1" in text
        assert "- Custom: 2" in text
        assert "- List-specific: 1" in text

    def test_data_types_section(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "## Data types" in text
        assert "- text: 2" in text
        assert "- number: 1" in text

    def test_fields_section(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "## Fields (3 of 3)" in text
        assert "Company Name" in text
        assert "ARR" in text

    def test_regression_header_is_companies_not_contacts(self):
        """Lock: don't accidentally paste in Contacts schema heading."""
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "# Contacts schema" not in text

    def test_manage_section_references_companies_endpoint(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "GET /fields/companies" in text
        assert "entity=companies" in text

    def test_manage_section_includes_contacts_sibling(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "g8://fields/contacts" in text

    def test_manage_section_excludes_self_reference(self):
        """Lock: don't list ourselves as a sibling pointer."""
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        # Title is "Companies schema" so g8://fields/companies may appear
        # in `GET /fields/companies` but NOT as a "Company fields schema"
        # pointer line.
        assert "Company fields schema: g8://fields/companies" not in text

    def test_custom_flag_shown(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "[custom]" in text

    def test_list_specific_flag_shown(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "list-specific" in text

    def test_id_suffix_for_custom(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "id=42" in text
        assert "id=43" in text
        assert "id=None" not in text

    def test_ends_with_newline(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert text.endswith("\n")

    def test_no_html_in_output(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "<div" not in text
        assert "<span" not in text

    def test_data_type_in_brackets(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "<text>" in text
        assert "<number>" in text

    def test_provider_pointer(self):
        text = render_company_fields_schema_text_fallback(fields=self._sample_fields())
        assert "g8://crm-syncs/" in text


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_empty_state_both_modes(self):
        for mode in ("empty", "unavailable"):
            html = _render_company_fields_schema_empty_state_html(mode=mode)
            assert html.startswith("<!DOCTYPE html>")
            assert "</html>" in html

    def test_valid_html_envelope(self):
        fields = [
            {
                "id": None,
                "title": "F",
                "name": "f",
                "data_type": "text",
                "is_global": True,
            }
        ]
        html = render_company_fields_schema_html(fields=fields)
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html
        assert "<body" in html

    def test_text_fallback_plaintext(self):
        fields = [
            {
                "id": None,
                "title": "F",
                "name": "f",
                "data_type": "text",
                "is_global": True,
            }
        ]
        text = render_company_fields_schema_text_fallback(fields=fields)
        assert "<!DOCTYPE" not in text
        assert "</html>" not in text
