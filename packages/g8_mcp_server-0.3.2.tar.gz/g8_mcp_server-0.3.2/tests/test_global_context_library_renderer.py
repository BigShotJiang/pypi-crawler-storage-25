"""Tests for the global context library HTML + text renderers (upgrade 4 — #15)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _global_doc_status_color,
    _group_global_docs_by_category,
    render_global_context_library_html,
    render_global_context_library_text_fallback,
)


def _doc(
    id_: str = "d1",
    category: str | None = "context",
    doc_type: str | None = "brand_brief",
    title: str | None = "Brand Brief",
    status: str | None = "ready",
    updated_at: str | None = "2026-04-10T12:00:00Z",
) -> dict:
    return {
        "id": id_,
        "category": category,
        "doc_type": doc_type,
        "title": title,
        "status": status,
        "updated_at": updated_at,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestGlobalDocStatusColor:
    def test_ready(self):
        # Backported 2026-04-21 to graph8 _G8_POSITIVE_* tokens
        c = _global_doc_status_color("ready")
        assert c["bg"] == "#d1fae5"  # _G8_POSITIVE_BG
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG (was banned #166534)
        assert c["border"] == "#a7f3d0"  # _G8_POSITIVE_BORDER

    def test_generating(self):
        # Retained as inline hex — runtime-transient state not on the
        # canonical positive/destructive/warning/accent axes
        c = _global_doc_status_color("generating")
        assert c["fg"] == "#1e40af"

    def test_failed(self):
        # Backported 2026-04-21 to graph8 _G8_DESTRUCTIVE_ON_LIGHT_* tokens
        c = _global_doc_status_color("failed")
        assert c["bg"] == "#fee2e2"  # _G8_DESTRUCTIVE_ON_LIGHT_BG
        assert c["fg"] == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG (was banned #991b1b)
        assert c["border"] == "#fca5a5"  # _G8_DESTRUCTIVE_ON_LIGHT_BORDER

    def test_stale(self):
        # Backported 2026-04-21 to graph8 _G8_WARNING_* tokens
        c = _global_doc_status_color("stale")
        assert c["bg"] == "#fff3c4"  # _G8_WARNING_BG
        assert c["fg"] == "#a0750a"  # _G8_WARNING_FG
        assert c["border"] == "#fde68a"  # _G8_WARNING_BORDER

    def test_unknown_fallback(self):
        c = _global_doc_status_color("weird")
        # Fallback to "skipped" gray
        assert c["fg"] == "#777777"

    def test_none_fallback(self):
        c = _global_doc_status_color(None)
        assert c["fg"] == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        # Lock: no banned Studio hex may appear in any status entry
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import (
            _GLOBAL_DOC_STATUS_COLORS,
        )
        for status, pal in _GLOBAL_DOC_STATUS_COLORS.items():
            for role, value in pal.items():
                assert value.lower() not in banned, (
                    f"status={status!r} role={role!r} hex={value!r} is banned"
                )

    def test_empty_fallback(self):
        c = _global_doc_status_color("")
        assert c["fg"] == "#777777"

    def test_case_insensitive(self):
        c1 = _global_doc_status_color("READY")
        c2 = _global_doc_status_color("ready")
        assert c1 == c2


class TestGroupGlobalDocsByCategory:
    def test_preferred_order(self):
        # Provide categories out of preferred order — expect brief/context/
        # intelligence/research ordering on output.
        docs = [
            _doc(id_="r1", category="research"),
            _doc(id_="c1", category="context"),
            _doc(id_="b1", category="brief"),
            _doc(id_="i1", category="intelligence"),
        ]
        grouped = _group_global_docs_by_category(docs)
        assert list(grouped.keys()) == ["brief", "context", "intelligence", "research"]

    def test_unknown_category_preserved(self):
        docs = [
            _doc(id_="c1", category="context"),
            _doc(id_="x1", category="exotic"),
        ]
        grouped = _group_global_docs_by_category(docs)
        keys = list(grouped.keys())
        # context first (preferred), then exotic (unknown, insertion order)
        assert keys[0] == "context"
        assert "exotic" in keys

    def test_missing_category_to_other(self):
        docs = [_doc(id_="c1", category=None)]
        grouped = _group_global_docs_by_category(docs)
        assert "other" in grouped

    def test_case_insensitive(self):
        docs = [
            _doc(id_="c1", category="CONTEXT"),
            _doc(id_="c2", category="Context"),
            _doc(id_="c3", category="context"),
        ]
        grouped = _group_global_docs_by_category(docs)
        # All should land in the same "context" bucket
        assert len(grouped["context"]) == 3

    def test_empty(self):
        assert _group_global_docs_by_category([]) == {}

    def test_only_preferred_categories_included_when_present(self):
        # If "research" has no docs, it shouldn't appear as an empty key
        docs = [_doc(id_="c1", category="context")]
        grouped = _group_global_docs_by_category(docs)
        assert "research" not in grouped
        assert "context" in grouped


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderGlobalContextLibraryHtml:
    def test_empty_state_none(self):
        html_out = render_global_context_library_html(documents=None)
        assert "No global context yet" in html_out

    def test_empty_state_list(self):
        html_out = render_global_context_library_html(documents=[])
        assert "No global context yet" in html_out

    def test_non_list_input(self):
        html_out = render_global_context_library_html(documents="nope")  # type: ignore[arg-type]
        assert "No global context yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_global_context_library_html(
            documents=[None, "x", 1]  # type: ignore[list-item]
        )
        assert "No global context yet" in html_out

    def test_renders_doc(self):
        html_out = render_global_context_library_html(documents=[_doc()])
        assert "Brand Brief" in html_out
        assert "brand_brief" in html_out
        assert "ready" in html_out

    def test_category_heading_rendered(self):
        html_out = render_global_context_library_html(
            documents=[_doc(category="context")]
        )
        assert "Context" in html_out

    def test_category_label_for_brief(self):
        html_out = render_global_context_library_html(
            documents=[_doc(category="brief", doc_type="campaign_intelligence_brief")]
        )
        assert "Campaign Intelligence Brief" in html_out

    def test_category_label_for_unknown_title_cased(self):
        html_out = render_global_context_library_html(
            documents=[_doc(category="custom_cat", doc_type="x")]
        )
        # Unknown categories rendered with Title Case
        assert "Custom Cat" in html_out

    def test_ready_count_header(self):
        html_out = render_global_context_library_html(
            documents=[
                _doc(id_="a", status="ready"),
                _doc(id_="b", status="ready"),
                _doc(id_="c", status="generating"),
            ]
        )
        assert "2 ready" in html_out

    def test_total_count_header(self):
        html_out = render_global_context_library_html(
            documents=[_doc(id_=f"d{i}") for i in range(5)]
        )
        assert "5 doc(s)" in html_out

    def test_category_count_per_section(self):
        html_out = render_global_context_library_html(
            documents=[
                _doc(id_="a", category="context", status="ready"),
                _doc(id_="b", category="context", status="generating"),
            ]
        )
        assert "1/2 ready" in html_out

    def test_preferred_category_order(self):
        html_out = render_global_context_library_html(
            documents=[
                _doc(id_="r", category="research", doc_type="research_doc"),
                _doc(id_="b", category="brief", doc_type="brief_doc"),
                _doc(id_="c", category="context", doc_type="context_doc"),
                _doc(id_="i", category="intelligence", doc_type="intel_doc"),
            ]
        )
        # Label appears inside <h2> with whitespace — use label text directly
        brief_pos = html_out.find("Campaign Intelligence Brief")
        context_pos = html_out.find("Context", brief_pos + 1)
        intel_pos = html_out.find("Intelligence", context_pos + 1)
        research_pos = html_out.find("Research", intel_pos + 1)
        assert brief_pos >= 0
        assert context_pos >= 0
        assert intel_pos >= 0
        assert research_pos >= 0
        assert brief_pos < context_pos < intel_pos < research_pos

    def test_missing_title_fallback_to_doc_type(self):
        html_out = render_global_context_library_html(
            documents=[_doc(title=None, doc_type="brand_brief")]
        )
        assert "brand_brief" in html_out

    def test_missing_title_and_doc_type_fallback(self):
        html_out = render_global_context_library_html(
            documents=[_doc(title=None, doc_type=None)]
        )
        assert "(untitled)" in html_out

    def test_status_color_ready(self):
        html_out = render_global_context_library_html(
            documents=[_doc(status="ready")]
        )
        # graph8 positive-family (backported 2026-04-21)
        assert "#d1fae5" in html_out  # _G8_POSITIVE_BG

    def test_status_color_failed(self):
        html_out = render_global_context_library_html(
            documents=[_doc(status="failed")]
        )
        # graph8 destructive-on-light-family (backported 2026-04-21)
        assert "#fee2e2" in html_out  # _G8_DESTRUCTIVE_ON_LIGHT_BG

    def test_no_banned_hexes_in_rendered_html(self):
        # Render every status bucket and confirm no banned hex ever appears
        html_out = render_global_context_library_html(
            documents=[
                _doc(status="ready", title="R"),
                _doc(status="generating", title="G"),
                _doc(status="queued", title="Q"),
                _doc(status="stale", title="S"),
                _doc(status="failed", title="F"),
                _doc(status="skipped", title="SK"),
            ]
        )
        for banned in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert banned not in html_out.lower(), (
                f"banned hex {banned} present in rendered HTML"
            )

    def test_updated_timestamp_rendered(self):
        html_out = render_global_context_library_html(
            documents=[_doc(updated_at="2026-04-10T12:00:00Z")]
        )
        assert "Updated" in html_out
        assert "2026-04-10" in html_out

    def test_no_updated_label_when_missing(self):
        html_out = render_global_context_library_html(
            documents=[_doc(updated_at=None)]
        )
        assert "Updated" not in html_out

    def test_org_label(self):
        html_out = render_global_context_library_html(
            documents=[_doc()], org_label="Acme"
        )
        assert "Acme" in html_out


class TestEscaping:
    def test_title_escaped(self):
        html_out = render_global_context_library_html(
            documents=[_doc(title="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_doc_type_escaped(self):
        html_out = render_global_context_library_html(
            documents=[_doc(doc_type="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_status_escaped(self):
        html_out = render_global_context_library_html(
            documents=[_doc(status="<img src=x>")]
        )
        assert "<img src=x>" not in html_out


class TestBounds:
    def test_max_docs_rendered(self):
        # 100 docs, cap is 80 — footer note must appear
        docs = [_doc(id_=f"d{i}", category="context") for i in range(100)]
        html_out = render_global_context_library_html(documents=docs)
        assert "20 doc(s) omitted" in html_out

    def test_long_title_truncated(self):
        html_out = render_global_context_library_html(
            documents=[_doc(title="x" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestGlobalContextLibraryTextFallback:
    def test_empty_none(self):
        out = render_global_context_library_text_fallback(documents=None)
        assert "No global context documents yet" in out

    def test_empty_list(self):
        out = render_global_context_library_text_fallback(documents=[])
        assert "No global context documents yet" in out

    def test_non_list(self):
        out = render_global_context_library_text_fallback(documents="nope")  # type: ignore[arg-type]
        assert "No global context documents yet" in out

    def test_only_garbage_items(self):
        out = render_global_context_library_text_fallback(
            documents=[None, "x", 1]  # type: ignore[list-item]
        )
        assert "No global context documents yet" in out

    def test_renders_title(self):
        out = render_global_context_library_text_fallback(documents=[_doc()])
        assert "Brand Brief" in out

    def test_renders_status(self):
        out = render_global_context_library_text_fallback(documents=[_doc()])
        assert "(ready)" in out

    def test_renders_doc_type(self):
        out = render_global_context_library_text_fallback(documents=[_doc()])
        assert "[brand_brief]" in out

    def test_updated_line(self):
        out = render_global_context_library_text_fallback(
            documents=[_doc(updated_at="2026-04-10T12:00:00Z")]
        )
        assert "updated 2026-04-10" in out

    def test_no_updated_when_missing(self):
        out = render_global_context_library_text_fallback(
            documents=[_doc(updated_at=None)]
        )
        assert "updated" not in out

    def test_ready_count_line(self):
        out = render_global_context_library_text_fallback(
            documents=[
                _doc(id_="a", status="ready"),
                _doc(id_="b", status="generating"),
            ]
        )
        assert "1 ready" in out

    def test_category_headings(self):
        out = render_global_context_library_text_fallback(
            documents=[
                _doc(id_="a", category="brief", doc_type="x"),
                _doc(id_="b", category="context", doc_type="y"),
            ]
        )
        assert "## Campaign Intelligence Brief" in out
        assert "## Context" in out

    def test_category_ready_count_per_section(self):
        out = render_global_context_library_text_fallback(
            documents=[
                _doc(id_="a", category="context", status="ready"),
                _doc(id_="b", category="context", status="failed"),
            ]
        )
        assert "(1/2 ready)" in out

    def test_org_label(self):
        out = render_global_context_library_text_fallback(
            documents=[_doc()], org_label="Acme"
        )
        assert "# Global Context — Acme" in out

    def test_max_cap_footer(self):
        docs = [_doc(id_=f"d{i}") for i in range(100)]
        out = render_global_context_library_text_fallback(documents=docs)
        assert "more doc(s)" in out

    def test_no_html_leak(self):
        out = render_global_context_library_text_fallback(
            documents=[_doc(title="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_GLOBAL_DOCS_RENDERED >= 44
        assert app_renderer._MAX_GLOBAL_DOC_TITLE_LEN >= 50
