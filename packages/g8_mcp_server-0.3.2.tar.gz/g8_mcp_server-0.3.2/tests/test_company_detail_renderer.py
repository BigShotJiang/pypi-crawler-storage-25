"""Tests for company detail HTML app surface (surface #26).

Surface #26 renders a per-company drilldown: logo + size badge derived
from employee_count, stat-card grid (employees, revenue, founded year,
contacts, open deals), overview (industry, location, phone, LinkedIn
followers), web presence (domain, website, social chips), description,
linked contacts, linked deals. Completes the CRM entity triad with
surfaces #24 (deal detail) and #25 (contact detail).

Coverage emphasises:
- Size classification from employee_count
  - int: solo (1) / small (2-50) / mid (51-250) / large (251-1000) /
    enterprise (1001+)
  - range strings: "11-50" -> 11 -> small, "1001+" -> 1001 -> enterprise
  - non-int / None / empty / bool -> None (no badge)
- Size palette lookup (solo gray, small cyan, mid blue, large indigo,
  enterprise purple)
- Display name derivation: name > domain > "Company"
- Contact row display name derivation
- Location formatting "City, State, Country" with empty parts skipped
- Address formatting: street + location + zip
- LinkedIn follower formatter (k/M suffixes, pre-formatted passthrough)
- Empty state triggers (None / non-dict)
- XSS escape of user-controlled fields (name, description, industry,
  domain, website, contact name, email)
- Populated render: stat cards, info rows, social chips, contacts +
  deals sections, overflow footers, timestamps, logo rendering
- Text fallback parity with markdown structure
"""

from g8_mcp_server.app_renderer import (
    _COMPANY_DETAIL_SIZE_COLORS,
    _company_detail_classify_size,
    _company_detail_contact_display_name,
    _company_detail_derive_display_name,
    _company_detail_format_address,
    _company_detail_format_linkedin_followers,
    _company_detail_format_location,
    _company_detail_size_palette,
    _render_company_detail_empty_state_html,
    render_company_detail_html,
    render_company_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestCompanyDetailPaletteNoBannedHexes:
    """Lock test: _COMPANY_DETAIL_SIZE_COLORS must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_size_palette(self):
        for key, pal in _COMPANY_DETAIL_SIZE_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _COMPANY_DETAIL_SIZE_COLORS[{key!r}][{field!r}]"
                )


# ---------------------------------------------------------------------------
# Size classification
# ---------------------------------------------------------------------------


class TestCompanyDetailClassifySize:
    def test_solo_from_int(self):
        assert _company_detail_classify_size(1) == "solo"

    def test_small_from_int(self):
        assert _company_detail_classify_size(25) == "small"

    def test_small_boundary_high(self):
        assert _company_detail_classify_size(50) == "small"

    def test_mid_from_int(self):
        assert _company_detail_classify_size(100) == "mid"

    def test_mid_boundary_low(self):
        assert _company_detail_classify_size(51) == "mid"

    def test_mid_boundary_high(self):
        assert _company_detail_classify_size(250) == "mid"

    def test_large_from_int(self):
        assert _company_detail_classify_size(500) == "large"

    def test_large_boundary_high(self):
        assert _company_detail_classify_size(1000) == "large"

    def test_enterprise_from_int(self):
        assert _company_detail_classify_size(5000) == "enterprise"

    def test_enterprise_boundary_low(self):
        assert _company_detail_classify_size(1001) == "enterprise"

    def test_range_string_small(self):
        assert _company_detail_classify_size("11-50") == "small"

    def test_range_string_mid(self):
        assert _company_detail_classify_size("51-200") == "mid"

    def test_range_string_large(self):
        assert _company_detail_classify_size("501-1000") == "large"

    def test_range_string_enterprise(self):
        assert _company_detail_classify_size("1001+") == "enterprise"
        assert _company_detail_classify_size("10001+") == "enterprise"

    def test_plain_number_string(self):
        assert _company_detail_classify_size("42") == "small"
        assert _company_detail_classify_size("2000") == "enterprise"

    def test_none_returns_none(self):
        assert _company_detail_classify_size(None) is None

    def test_empty_string_returns_none(self):
        assert _company_detail_classify_size("") is None
        assert _company_detail_classify_size("   ") is None

    def test_zero_returns_none(self):
        assert _company_detail_classify_size(0) is None

    def test_negative_returns_none(self):
        assert _company_detail_classify_size(-10) is None

    def test_bool_returns_none(self):
        # bool is a subclass of int — guard explicitly
        assert _company_detail_classify_size(True) is None
        assert _company_detail_classify_size(False) is None

    def test_non_numeric_string_returns_none(self):
        assert _company_detail_classify_size("unknown") is None
        assert _company_detail_classify_size("N/A") is None

    def test_list_returns_none(self):
        assert _company_detail_classify_size(["100"]) is None

    def test_dict_returns_none(self):
        assert _company_detail_classify_size({"count": 100}) is None


# ---------------------------------------------------------------------------
# Size palette
# ---------------------------------------------------------------------------


class TestCompanyDetailSizePalette:
    def test_solo(self):
        pal = _company_detail_size_palette("solo")
        assert pal["fg"] == "#777777"

    def test_small(self):
        pal = _company_detail_size_palette("small")
        assert pal["fg"] == "#0e7490"

    def test_mid(self):
        pal = _company_detail_size_palette("mid")
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_large(self):
        pal = _company_detail_size_palette("large")
        assert pal["fg"] == "#7d2df3"

    def test_enterprise(self):
        pal = _company_detail_size_palette("enterprise")
        assert pal["fg"] == "#86198f"

    def test_none_returns_none(self):
        assert _company_detail_size_palette(None) is None

    def test_unknown_returns_none(self):
        assert _company_detail_size_palette("xxl") is None

    def test_non_string_returns_none(self):
        assert _company_detail_size_palette(42) is None


# ---------------------------------------------------------------------------
# Display name derivation
# ---------------------------------------------------------------------------


class TestCompanyDetailDeriveDisplayName:
    def test_name_wins(self):
        c = {"name": "Analytical Engines", "domain": "engines.co"}
        assert _company_detail_derive_display_name(c) == "Analytical Engines"

    def test_name_stripped(self):
        assert _company_detail_derive_display_name({"name": "  Co  "}) == "Co"

    def test_domain_fallback(self):
        assert _company_detail_derive_display_name({"domain": "engines.co"}) == "engines.co"

    def test_empty_returns_fallback(self):
        assert _company_detail_derive_display_name({}) == "Company"

    def test_whitespace_name_falls_through(self):
        c = {"name": "   ", "domain": "engines.co"}
        assert _company_detail_derive_display_name(c) == "engines.co"

    def test_non_string_fields_ignored(self):
        c = {"name": 42, "domain": None}
        assert _company_detail_derive_display_name(c) == "Company"


# ---------------------------------------------------------------------------
# Contact row display name derivation
# ---------------------------------------------------------------------------


class TestCompanyDetailContactDisplayName:
    def test_full_name_wins(self):
        c = {"full_name": "Ada Lovelace", "first_name": "A", "last_name": "L"}
        assert _company_detail_contact_display_name(c) == "Ada Lovelace"

    def test_first_last_fallback(self):
        c = {"first_name": "Ada", "last_name": "Lovelace"}
        assert _company_detail_contact_display_name(c) == "Ada Lovelace"

    def test_email_fallback(self):
        c = {"work_email": "ada@engines.co"}
        assert _company_detail_contact_display_name(c) == "ada@engines.co"

    def test_empty_returns_fallback(self):
        assert _company_detail_contact_display_name({}) == "(unnamed contact)"


# ---------------------------------------------------------------------------
# Location formatting
# ---------------------------------------------------------------------------


class TestCompanyDetailFormatLocation:
    def test_all_parts(self):
        c = {"city": "Austin", "state": "TX", "country": "USA"}
        assert _company_detail_format_location(c) == "Austin, TX, USA"

    def test_missing_state(self):
        c = {"city": "London", "country": "UK"}
        assert _company_detail_format_location(c) == "London, UK"

    def test_empty_strings_skipped(self):
        c = {"city": "Austin", "state": "", "country": "USA"}
        assert _company_detail_format_location(c) == "Austin, USA"

    def test_all_empty(self):
        assert _company_detail_format_location({}) == ""

    def test_non_string_skipped(self):
        c = {"city": 42, "country": "USA"}
        assert _company_detail_format_location(c) == "USA"


# ---------------------------------------------------------------------------
# Address formatting
# ---------------------------------------------------------------------------


class TestCompanyDetailFormatAddress:
    def test_full_address(self):
        c = {
            "address": "123 Main St",
            "city": "Austin",
            "state": "TX",
            "country": "USA",
            "zip": "78701",
        }
        result = _company_detail_format_address(c)
        assert "123 Main St" in result
        assert "Austin, TX, USA" in result
        assert "78701" in result

    def test_street_only(self):
        c = {"address": "123 Main St"}
        assert _company_detail_format_address(c) == "123 Main St"

    def test_location_only(self):
        c = {"city": "Austin", "country": "USA"}
        assert _company_detail_format_address(c) == "Austin, USA"

    def test_empty_address(self):
        assert _company_detail_format_address({}) == ""

    def test_zip_without_street(self):
        c = {"city": "Austin", "zip": "78701"}
        assert _company_detail_format_address(c) == "Austin, 78701"


# ---------------------------------------------------------------------------
# LinkedIn followers formatter
# ---------------------------------------------------------------------------


class TestCompanyDetailFormatLinkedInFollowers:
    def test_small_number_int(self):
        assert _company_detail_format_linkedin_followers(500) == "500"

    def test_thousands_int(self):
        assert _company_detail_format_linkedin_followers(1500) == "1.5k"

    def test_round_thousands(self):
        assert _company_detail_format_linkedin_followers(2000) == "2k"

    def test_millions_int(self):
        assert _company_detail_format_linkedin_followers(2_500_000) == "2.5M"

    def test_round_millions(self):
        assert _company_detail_format_linkedin_followers(3_000_000) == "3M"

    def test_plain_string_number(self):
        assert _company_detail_format_linkedin_followers("1500") == "1.5k"

    def test_comma_separated_string(self):
        assert _company_detail_format_linkedin_followers("12,345") == "12.3k"

    def test_preformatted_k_passthrough(self):
        assert _company_detail_format_linkedin_followers("12.3K") == "12.3K"

    def test_preformatted_m_passthrough(self):
        assert _company_detail_format_linkedin_followers("2.5M") == "2.5M"

    def test_empty_string_returns_empty(self):
        assert _company_detail_format_linkedin_followers("") == ""
        assert _company_detail_format_linkedin_followers("   ") == ""

    def test_none_returns_empty(self):
        assert _company_detail_format_linkedin_followers(None) == ""

    def test_bool_returns_empty(self):
        assert _company_detail_format_linkedin_followers(True) == ""
        assert _company_detail_format_linkedin_followers(False) == ""

    def test_garbage_string_passthrough(self):
        # Unparsable strings pass through as-is
        assert _company_detail_format_linkedin_followers("abc") == "abc"

    def test_list_returns_empty(self):
        assert _company_detail_format_linkedin_followers([1000]) == ""


# ---------------------------------------------------------------------------
# Empty state rendering
# ---------------------------------------------------------------------------


class TestRenderCompanyDetailEmptyStates:
    def test_none_company_renders_empty_state(self):
        html = render_company_detail_html(company=None, company_id="co_42")
        assert "Company not found" in html
        assert "co_42" in html

    def test_non_dict_renders_empty_state(self):
        html = render_company_detail_html(company="nope", company_id="co_42")
        assert "Company not found" in html

    def test_empty_state_references_search(self):
        html = render_company_detail_html(company=None, company_id="co_42")
        assert "g8_search_companies" in html

    def test_empty_state_escapes_id(self):
        html = _render_company_detail_empty_state_html(
            company_id="<script>alert(1)</script>"
        )
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_empty_state_handles_blank_id(self):
        html = _render_company_detail_empty_state_html(company_id="")
        assert "(unknown)" in html

    def test_text_fallback_empty(self):
        text = render_company_detail_text_fallback(company=None, company_id="co_42")
        assert "Company not found" in text
        assert "co_42" in text

    def test_text_fallback_non_dict(self):
        text = render_company_detail_text_fallback(company="nope", company_id="co_42")
        assert "Company not found" in text


# ---------------------------------------------------------------------------
# Populated HTML rendering
# ---------------------------------------------------------------------------


def _sample_company():
    return {
        "id": 42,
        "name": "Analytical Engines Ltd",
        "description": "Builds the first programmable computers.",
        "domain": "engines.co",
        "website": "https://engines.co",
        "logo_url": "https://engines.co/logo.png",
        "phone": "+44-20-7946-0000",
        "address": "123 Baker St",
        "city": "London",
        "state": "",
        "country": "UK",
        "zip": "W1U 6SE",
        "founded_year": 1843,
        "employee_count": 150,
        "revenue": "$10M-$50M",
        "industry": "Software",
        "industry_group": "B2B SaaS",
        "linkedin_url": "https://linkedin.com/company/engines",
        "linkedin_followers": 12500,
        "twitter_url": "https://x.com/engines",
        "facebook_url": "",
        "crunchbase_url": "https://crunchbase.com/engines",
        "contact_count": 25,
        "created_at": "2024-01-15T10:00:00Z",
        "updated_at": "2026-04-20T14:30:00Z",
    }


class TestRenderCompanyDetailPopulated:
    def test_name_in_header(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "Analytical Engines Ltd" in html

    def test_company_id_in_header(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert ">42<" in html  # rendered in the monospace div

    def test_size_badge_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        # 150 employees -> MID-MARKET
        assert '<span class="size-badge"' in html
        assert "MID-MARKET" in html

    def test_size_badge_enterprise(self):
        c = _sample_company()
        c["employee_count"] = 5000
        html = render_company_detail_html(company=c, company_id="42")
        assert "ENTERPRISE" in html

    def test_size_badge_skipped_when_none(self):
        c = _sample_company()
        c["employee_count"] = None
        html = render_company_detail_html(company=c, company_id="42")
        assert '<span class="size-badge"' not in html

    def test_employees_stat(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "Employees" in html
        assert "150" in html

    def test_revenue_stat(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "$10M-$50M" in html

    def test_founded_stat(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "1843" in html

    def test_founded_missing_dash(self):
        c = _sample_company()
        c["founded_year"] = None
        html = render_company_detail_html(company=c, company_id="42")
        # em-dash rendered when missing
        assert "Founded" in html

    def test_contacts_count(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        # contact_count=25 from sample
        assert "25" in html

    def test_industry_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "Software" in html
        assert "B2B SaaS" in html

    def test_location_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "London, UK" in html

    def test_address_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "123 Baker St" in html
        assert "W1U 6SE" in html

    def test_phone_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "+44-20-7946-0000" in html

    def test_linkedin_followers_formatted(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        # 12500 -> 12.5k
        assert "12.5k" in html

    def test_domain_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "engines.co" in html

    def test_website_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "https://engines.co" in html

    def test_linkedin_chip(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "LinkedIn" in html

    def test_twitter_chip(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "Twitter" in html

    def test_facebook_chip_skipped_when_empty(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        # facebook_url is "" in sample
        assert "Facebook" not in html

    def test_crunchbase_chip(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "Crunchbase" in html

    def test_description_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "first programmable computers" in html

    def test_description_section_skipped_when_empty(self):
        c = _sample_company()
        c["description"] = ""
        html = render_company_detail_html(company=c, company_id="42")
        assert "desc-section" not in html

    def test_logo_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert '<img class="logo"' in html
        assert "https://engines.co/logo.png" in html

    def test_logo_skipped_for_bad_url(self):
        c = _sample_company()
        c["logo_url"] = "javascript:alert(1)"
        html = render_company_detail_html(company=c, company_id="42")
        assert '<img class="logo"' not in html

    def test_xss_escape_in_name(self):
        c = _sample_company()
        c["name"] = "<script>evil()</script>"
        html = render_company_detail_html(company=c, company_id="42")
        assert "<script>evil()" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_in_description(self):
        c = _sample_company()
        c["description"] = "<img src=x onerror=alert(1)>"
        html = render_company_detail_html(company=c, company_id="42")
        assert "<img src=x" not in html
        assert "&lt;img" in html

    def test_xss_escape_in_industry(self):
        c = _sample_company()
        c["industry"] = "<b>Industry</b>"
        html = render_company_detail_html(company=c, company_id="42")
        assert "<b>Industry</b>" not in html

    def test_xss_escape_in_company_id(self):
        html = render_company_detail_html(
            company=_sample_company(), company_id="<script>alert(1)</script>"
        )
        assert "<script>alert" not in html

    def test_timestamps_rendered(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "created" in html.lower()
        assert "updated" in html.lower()

    def test_minimal_company(self):
        c = {"name": "Widgets"}
        html = render_company_detail_html(company=c, company_id="99")
        assert "Widgets" in html
        # Renders without crashing

    def test_nameless_company(self):
        c = {"domain": "nameless.co"}
        html = render_company_detail_html(company=c, company_id="99")
        assert "nameless.co" in html

    def test_empty_company(self):
        html = render_company_detail_html(company={}, company_id="99")
        # Falls back to "Company"
        assert ">Company<" in html or "Company —" in html or "Company" in html


# ---------------------------------------------------------------------------
# Related sections: contacts + deals
# ---------------------------------------------------------------------------


class TestRenderCompanyDetailRelatedSections:
    def test_contacts_section_rendered(self):
        contacts = [
            {
                "full_name": "Ada Lovelace",
                "job_title": "CEO",
                "seniority_level": "c_suite",
                "work_email": "ada@engines.co",
            },
            {
                "full_name": "Charles Babbage",
                "job_title": "CTO",
                "work_email": "charles@engines.co",
            },
        ]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "Ada Lovelace" in html
        assert "Charles Babbage" in html
        assert "CEO" in html
        assert "ada@engines.co" in html

    def test_contacts_section_skipped_when_none(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "contacts-section" not in html

    def test_contacts_overflow(self):
        contacts = [{"full_name": f"Contact {i}"} for i in range(25)]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "5 more contact(s) omitted" in html

    def test_contacts_non_dict_skipped(self):
        contacts = [{"full_name": "Real"}, "not a dict", None, {"full_name": "Also Real"}]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "Real" in html
        assert "Also Real" in html

    def test_contacts_seniority_uppercased(self):
        contacts = [{"full_name": "Ada", "seniority_level": "c_suite"}]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "C SUITE" in html

    def test_deals_section_rendered(self):
        deals = [
            {"name": "Big Deal", "stage": "Proposal", "value": 100000, "currency": "USD"},
            {"name": "Small Deal", "stage": "Discovery", "value": 5000, "currency": "USD"},
        ]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "Big Deal" in html
        assert "Small Deal" in html
        assert "Proposal" in html
        assert "Discovery" in html

    def test_deals_section_skipped_when_none(self):
        html = render_company_detail_html(company=_sample_company(), company_id="42")
        assert "deals-section" not in html

    def test_deals_overflow(self):
        deals = [{"name": f"Deal {i}", "stage": "Open"} for i in range(25)]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "5 more deal(s) omitted" in html

    def test_deals_non_dict_skipped(self):
        deals = [{"name": "Real"}, "not a deal", {"name": "Also Real"}]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "Real" in html
        assert "Also Real" in html

    def test_contact_name_xss_escape(self):
        contacts = [{"full_name": "<script>evil</script>"}]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "<script>evil" not in html
        assert "&lt;script&gt;" in html

    def test_deal_name_xss_escape(self):
        deals = [{"name": "<script>evil</script>", "stage": "Open"}]
        html = render_company_detail_html(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "<script>evil" not in html


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestRenderCompanyDetailTextFallback:
    def test_header_is_name(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert text.startswith("# Analytical Engines Ltd")

    def test_company_id_in_backticks(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "`42`" in text

    def test_size_line(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "Size: **MID-MARKET**" in text

    def test_size_line_skipped_when_none(self):
        c = _sample_company()
        c["employee_count"] = None
        text = render_company_detail_text_fallback(company=c, company_id="42")
        assert "Size:" not in text

    def test_overview_section(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "## Overview" in text
        assert "Employees: 150" in text
        assert "Revenue: $10M-$50M" in text
        assert "Founded: 1843" in text
        assert "Contacts: 25" in text
        assert "Open deals: 0" in text

    def test_details_section(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "## Details" in text
        assert "Industry: Software" in text
        assert "B2B SaaS" in text
        assert "Location: London, UK" in text
        assert "Phone: +44-20-7946-0000" in text
        assert "LinkedIn followers: 12.5k" in text

    def test_web_presence_section(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "## Web presence" in text
        assert "Domain: engines.co" in text
        assert "Website: https://engines.co" in text
        assert "LinkedIn: https://linkedin.com/company/engines" in text

    def test_description_section(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "## Description" in text
        assert "first programmable computers" in text

    def test_contacts_section(self):
        contacts = [
            {"full_name": "Ada Lovelace", "job_title": "CEO", "work_email": "ada@engines.co"}
        ]
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        # total_contacts uses contact_count=25 from the sample company
        assert "## Contacts (25)" in text
        assert "Ada Lovelace" in text
        assert "[CEO]" in text
        assert "ada@engines.co" in text

    def test_deals_section(self):
        deals = [{"name": "Big Deal", "stage": "Proposal", "value": 50000, "currency": "USD"}]
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "## Deals (1)" in text
        assert "Big Deal" in text
        assert "[Proposal]" in text

    def test_contacts_overflow(self):
        contacts = [{"full_name": f"C{i}"} for i in range(25)]
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42", contacts=contacts
        )
        assert "and 5 more" in text

    def test_deals_overflow(self):
        deals = [{"name": f"D{i}", "stage": "Open"} for i in range(25)]
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42", deals=deals
        )
        assert "and 5 more" in text

    def test_timestamps_footer(self):
        text = render_company_detail_text_fallback(
            company=_sample_company(), company_id="42"
        )
        assert "created 2024-01-15T10:00:00Z" in text
        assert "updated 2026-04-20T14:30:00Z" in text

    def test_empty_company_no_crash(self):
        text = render_company_detail_text_fallback(company={}, company_id="99")
        assert "# Company" in text
        assert "`99`" in text

    def test_nameless_uses_domain(self):
        c = {"domain": "nameless.co"}
        text = render_company_detail_text_fallback(company=c, company_id="99")
        assert "# nameless.co" in text
