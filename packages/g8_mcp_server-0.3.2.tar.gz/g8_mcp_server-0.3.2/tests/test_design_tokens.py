"""Tests for graph8 design tokens exposed by app_renderer.

This test file is the **source of truth** for which tokens exist and what
their semantic roles are. Any surface renderer that needs a color / border /
radius should pull from here rather than hardcoding hexes.

The banned-Studio-hex set (`#1d4ed8` / `#166534` / `#991b1b` / `#0891b2`) is
locked out of the token definitions — no token may equal or resolve to any of
them. Individual surface tests enforce the same lock on their rendered HTML.

Added 2026-04-21 as foundation for the Upgrade 4 token-backport effort
(surfaces #1–#35 still carry raw banned hexes).
"""
from __future__ import annotations

import inspect

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Banned hex lock (applies to every token value)
# ---------------------------------------------------------------------------

_BANNED_HEXES = frozenset({"#1d4ed8", "#166534", "#991b1b", "#0891b2"})


_ALL_G8_TOKEN_NAMES = (
    "_G8_PRIMARY",
    "_G8_PRIMARY_FG",
    "_G8_ACCENT_BG",
    "_G8_ACCENT_BORDER",
    "_G8_ACCENT_SOFT_BG",
    "_G8_ACCENT_SOFT_BORDER",
    "_G8_BORDER",
    "_G8_CARD_BG",
    "_G8_MUTED_BG",
    "_G8_MUTED_INPUT",
    "_G8_TEXT",
    "_G8_TEXT_MUTED",
    "_G8_POSITIVE_BG",
    "_G8_POSITIVE_FG",
    "_G8_POSITIVE_BORDER",
    "_G8_DESTRUCTIVE_BG",
    "_G8_DESTRUCTIVE_FG",
    "_G8_DESTRUCTIVE_ON_LIGHT_BG",
    "_G8_DESTRUCTIVE_ON_LIGHT_FG",
    "_G8_DESTRUCTIVE_ON_LIGHT_BORDER",
    "_G8_WARNING_BG",
    "_G8_WARNING_FG",
    "_G8_WARNING_BORDER",
    "_G8_SHADOW_XS",
    "_G8_FONT",
    "_G8_CARD_RADIUS",
    "_G8_PILL_RADIUS",
)


class TestTokenPresence:
    """Every named token must exist as a module-level string attribute."""

    @pytest.mark.parametrize("name", _ALL_G8_TOKEN_NAMES)
    def test_token_is_exported(self, name: str) -> None:
        assert hasattr(ar, name), f"token {name} not exported"

    @pytest.mark.parametrize("name", _ALL_G8_TOKEN_NAMES)
    def test_token_is_string(self, name: str) -> None:
        assert isinstance(getattr(ar, name), str), f"token {name} is not str"

    @pytest.mark.parametrize("name", _ALL_G8_TOKEN_NAMES)
    def test_token_is_nonempty(self, name: str) -> None:
        assert getattr(ar, name).strip(), f"token {name} is empty"


class TestBannedHexLock:
    """No token value may equal a banned Studio hex."""

    @pytest.mark.parametrize("name", _ALL_G8_TOKEN_NAMES)
    def test_token_is_not_banned_hex(self, name: str) -> None:
        value = getattr(ar, name).strip().lower()
        assert value not in _BANNED_HEXES, f"token {name} = {value!r} is banned"

    def test_all_tokens_not_banned(self) -> None:
        for name in _ALL_G8_TOKEN_NAMES:
            value = getattr(ar, name).strip().lower()
            assert value not in _BANNED_HEXES


class TestBrandPrimary:
    """Primary brand purple + Aeonik must be stable."""

    def test_primary_is_brand_purple(self) -> None:
        assert ar._G8_PRIMARY == "#7d2df3"

    def test_primary_fg_is_white(self) -> None:
        assert ar._G8_PRIMARY_FG == "#ffffff"

    def test_font_starts_with_aeonik(self) -> None:
        assert ar._G8_FONT.startswith("Aeonik")

    def test_font_has_sans_fallback(self) -> None:
        assert "sans-serif" in ar._G8_FONT


class TestPositiveFamily:
    """Positive / success palette (on light backgrounds)."""

    def test_positive_bg(self) -> None:
        assert ar._G8_POSITIVE_BG == "#d1fae5"

    def test_positive_fg(self) -> None:
        assert ar._G8_POSITIVE_FG == "#059669"

    def test_positive_border(self) -> None:
        assert ar._G8_POSITIVE_BORDER == "#a7f3d0"

    def test_positive_fg_is_not_banned(self) -> None:
        # `#166534` (old green) is banned; must not regress
        assert ar._G8_POSITIVE_FG.lower() != "#166534"


class TestDestructiveFamily:
    """Destructive palette — dark (for buttons) and on-light (for pills)."""

    def test_destructive_bg_dark(self) -> None:
        assert ar._G8_DESTRUCTIVE_BG == "rgba(202,50,20,0.9)"

    def test_destructive_fg_dark(self) -> None:
        assert ar._G8_DESTRUCTIVE_FG == "#fffcfc"

    def test_destructive_on_light_bg(self) -> None:
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_BG == "#fee2e2"

    def test_destructive_on_light_fg(self) -> None:
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_FG == "#b91c1c"

    def test_destructive_on_light_border(self) -> None:
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_BORDER == "#fca5a5"

    def test_destructive_on_light_fg_is_not_banned(self) -> None:
        # `#991b1b` (old dark red) is banned; must not regress
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_FG.lower() != "#991b1b"


class TestWarningFamily:
    """Warning / caution palette (amber on light)."""

    def test_warning_bg(self) -> None:
        assert ar._G8_WARNING_BG == "#fff3c4"

    def test_warning_fg(self) -> None:
        assert ar._G8_WARNING_FG == "#a0750a"

    def test_warning_border(self) -> None:
        assert ar._G8_WARNING_BORDER == "#fde68a"


class TestAccentFamily:
    """Accent / info palette (purple-tinted, replaces blue info hexes)."""

    def test_accent_bg(self) -> None:
        assert ar._G8_ACCENT_BG == "#f2eafe"

    def test_accent_border(self) -> None:
        assert ar._G8_ACCENT_BORDER == "rgba(125,45,243,0.2)"

    def test_accent_soft_bg(self) -> None:
        assert ar._G8_ACCENT_SOFT_BG == "#faf5ff"

    def test_accent_soft_border(self) -> None:
        assert ar._G8_ACCENT_SOFT_BORDER == "#e9d5ff"

    def test_accent_soft_bg_not_banned(self) -> None:
        # Old blue info bgs (#dbeafe / #eff6ff) are not banned-hex-locked
        # individually, but the accent-soft family explicitly replaces the
        # blue-family for semantic consistency. This test documents that the
        # soft accent is brand-purple-tinted, not blue.
        assert ar._G8_ACCENT_SOFT_BG.startswith("#f")  # light tint
        # And decidedly not one of the blue bgs:
        assert ar._G8_ACCENT_SOFT_BG.lower() not in ("#dbeafe", "#eff6ff")


class TestNeutralFamily:
    """Neutral / muted + text tokens."""

    def test_border(self) -> None:
        assert ar._G8_BORDER == "#dfdfdf"

    def test_card_bg(self) -> None:
        assert ar._G8_CARD_BG == "#ffffff"

    def test_muted_bg(self) -> None:
        assert ar._G8_MUTED_BG == "#f9f9f9"

    def test_text_primary(self) -> None:
        assert ar._G8_TEXT == "#0A0A0A"

    def test_text_muted(self) -> None:
        assert ar._G8_TEXT_MUTED == "#777777"


class TestRadiusAndShadow:
    """Card radius / shadow tokens."""

    def test_card_radius(self) -> None:
        assert ar._G8_CARD_RADIUS == "12px"

    def test_pill_radius(self) -> None:
        assert ar._G8_PILL_RADIUS == "6px"

    def test_shadow_xs_is_hsl(self) -> None:
        assert ar._G8_SHADOW_XS.startswith("0 ")
        assert "hsl" in ar._G8_SHADOW_XS.lower()


class TestSemanticMappingDocumented:
    """Documented mapping the backport uses to replace raw hexes.

    These mappings are the contract. If a future surface is migrated, it
    SHOULD use these tokens in lieu of the raw hexes on the left.
    """

    def test_dark_green_maps_to_positive_fg(self) -> None:
        # `#166534` (banned) → _G8_POSITIVE_FG
        assert ar._G8_POSITIVE_FG == "#059669"

    def test_soft_green_bg_maps_to_positive_bg(self) -> None:
        # `#dcfce7` → _G8_POSITIVE_BG (brand's light green)
        assert ar._G8_POSITIVE_BG == "#d1fae5"

    def test_soft_green_border_maps_to_positive_border(self) -> None:
        # `#86efac` → _G8_POSITIVE_BORDER
        assert ar._G8_POSITIVE_BORDER == "#a7f3d0"

    def test_dark_red_maps_to_destructive_on_light_fg(self) -> None:
        # `#991b1b` (banned) → _G8_DESTRUCTIVE_ON_LIGHT_FG
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_FG == "#b91c1c"

    def test_soft_red_bg_maps_to_destructive_on_light_bg(self) -> None:
        # `#fee2e2` → _G8_DESTRUCTIVE_ON_LIGHT_BG (same hue, explicit token)
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_BG == "#fee2e2"

    def test_soft_red_border_maps_to_destructive_on_light_border(self) -> None:
        # `#fca5a5` → _G8_DESTRUCTIVE_ON_LIGHT_BORDER
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_BORDER == "#fca5a5"

    def test_dark_blue_maps_to_primary(self) -> None:
        # `#1d4ed8` (banned) → _G8_PRIMARY (brand purple replaces info-blue)
        assert ar._G8_PRIMARY == "#7d2df3"


class TestNoTokenRegressions:
    """Locks that prevent accidental rewrite to banned values."""

    def test_positive_fg_not_166534(self) -> None:
        assert ar._G8_POSITIVE_FG.lower() != "#166534"

    def test_destructive_on_light_fg_not_991b1b(self) -> None:
        assert ar._G8_DESTRUCTIVE_ON_LIGHT_FG.lower() != "#991b1b"

    def test_primary_not_1d4ed8(self) -> None:
        assert ar._G8_PRIMARY.lower() != "#1d4ed8"

    def test_no_token_is_0891b2(self) -> None:
        for name in _ALL_G8_TOKEN_NAMES:
            assert getattr(ar, name).lower() != "#0891b2"


# ---------------------------------------------------------------------------
# Per-function drift lint
# ---------------------------------------------------------------------------
#
# The token dict tests above lock the VALUES of the _G8_* constants but do
# not guarantee that renderers actually use them. A function that
# hardcodes `#4338ca` (legacy indigo) would pass those tests while
# producing off-brand HTML.
#
# This lint scans the source of every `render_*_html` and
# `_render_*_html` function in `app_renderer.py` (via `inspect.getsource`)
# and fails if it finds a banned raw token outside of the
# `_DRIFT_WHITELIST` exemption set.
#
# The whitelist is empty by design: every future surface author must
# pick tokens from the `_G8_*` palette, not raw hexes. If a new legitimate
# use-case emerges, add the function name here with a comment explaining
# why the raw hex is load-bearing.
#
# Added 2026-04-21 after the token-drift audit discovered 36 drifted
# surfaces. Migration collapsed all raw hexes into `_G8_*` references;
# this lint prevents regression.

# Banned tokens: raw strings that should never appear inline in a
# `render_*_html` function body. Each maps to a semantic replacement the
# author should use instead. The migration on 2026-04-21 applied all of
# these globally; this table is the regression lock.
_BANNED_RAW_TOKENS: dict[str, str] = {
    # Font stack — renderer should interpolate `{_G8_FONT}` inside an
    # f-string. `-apple-system` on its own is whitelisted because it
    # appears as a fallback inside `_G8_FONT` itself.
    "-apple-system,": "interpolate `{_G8_FONT}` instead of inlining the fallback stack",
    # Muted backgrounds
    "#f9fafb": "use _G8_MUTED_BG (#f9f9f9)",
    "#fafafa": "use _G8_MUTED_BG (#f9f9f9)",
    "#f3f4f6": "use _G8_MUTED_BG (#f9f9f9)",
    # Borders
    "#e5e7eb": "use _G8_BORDER (#dfdfdf)",
    "#d1d5db": "use _G8_BORDER (#dfdfdf)",
    "#e5e5e5": "use _G8_BORDER (#dfdfdf)",
    # Primary text
    "#111827": "use _G8_TEXT (#0A0A0A)",
    "#1a1a1a": "use _G8_TEXT (#0A0A0A)",
    "#374151": "use _G8_TEXT (#0A0A0A)",
    # Muted text
    "#6b7280": "use _G8_TEXT_MUTED (#777777)",
    "#9ca3af": "use _G8_TEXT_MUTED (#777777)",
    "#4b5563": "use _G8_TEXT_MUTED (#777777)",
    # Legacy indigo family → brand purple
    "#4338ca": "use _G8_PRIMARY (#7d2df3)",
    "#4f46e5": "use _G8_PRIMARY (#7d2df3)",
    "#6366f1": "use _G8_PRIMARY (#7d2df3)",
    "#3730a3": "use _G8_PRIMARY (#7d2df3)",
    "#312e81": "use _G8_PRIMARY (#7d2df3)",
    # Legacy accent bg (indigo-tint) → purple-tint
    "#eef2ff": "use _G8_ACCENT_BG (#f2eafe)",
    "#e0e7ff": "use _G8_ACCENT_BG (#f2eafe)",
    "#dbeafe": "use _G8_ACCENT_BG (#f2eafe)",
    # Legacy positive
    "#16a34a": "use _G8_POSITIVE_FG (#059669)",
    "#15803d": "use _G8_POSITIVE_FG (#059669)",
    "#dcfce7": "use _G8_POSITIVE_BG (#d1fae5)",
    "#bbf7d0": "use _G8_POSITIVE_BG (#d1fae5)",
    # Legacy warning
    "#a16207": "use _G8_WARNING_FG (#a0750a)",
    "#eab308": "use _G8_WARNING_FG (#a0750a)",
    "#ca8a04": "use _G8_WARNING_FG (#a0750a)",
    "#fef3c7": "use _G8_WARNING_BG (#fff3c4)",
    "#fef9c3": "use _G8_WARNING_BG (#fff3c4)",
}


# Whitelist: render_*_html function names that are permitted to carry one
# or more banned raw tokens in their source. Empty by default — any entry
# requires a justifying comment. The migration on 2026-04-21 left this
# empty; add an entry only after reviewing the raw-hex usage and
# confirming it's load-bearing (e.g. a deliberate legacy-compat surface).
_DRIFT_WHITELIST: frozenset[str] = frozenset()


def _render_function_names() -> list[str]:
    """Collect every render_*_html and _render_*_html callable in
    `app_renderer` — both public surfaces and private helpers (empty
    states, status pills, etc)."""
    names = []
    for attr in dir(ar):
        if "render" not in attr.lower() or "html" not in attr.lower():
            continue
        if not callable(getattr(ar, attr)):
            continue
        names.append(attr)
    return sorted(names)


class TestPerFunctionTokenDrift:
    """Scan every render_*_html source for banned raw tokens.

    This is the strict lint that prevents a future contributor from
    hardcoding Studio-era hexes (or the `-apple-system` font-family
    fallback) inside a renderer. Catches drift at the function level,
    not just the module-token level.
    """

    def test_no_whitelist_stagglers(self) -> None:
        """Whitelist should stay empty. If an entry is added, it must be
        removed once the function is migrated."""
        assert _DRIFT_WHITELIST == frozenset(), (
            f"_DRIFT_WHITELIST is not empty: {sorted(_DRIFT_WHITELIST)}. "
            "Any exemption must be removed after migration completes."
        )

    @pytest.mark.parametrize("fn_name", _render_function_names())
    def test_no_banned_raw_tokens_in_source(self, fn_name: str) -> None:
        if fn_name in _DRIFT_WHITELIST:
            pytest.skip(f"{fn_name} is in _DRIFT_WHITELIST")

        fn = getattr(ar, fn_name)
        try:
            src = inspect.getsource(fn)
        except (OSError, TypeError):
            pytest.skip(f"could not get source for {fn_name}")

        src_lower = src.lower()
        hits: list[tuple[str, str]] = []
        for banned, remediation in _BANNED_RAW_TOKENS.items():
            if banned.lower() in src_lower:
                hits.append((banned, remediation))

        if hits:
            lines = [f"{fn_name} contains {len(hits)} banned raw token(s):"]
            for banned, remediation in hits:
                lines.append(f"  - {banned!r}  ->  {remediation}")
            pytest.fail("\n".join(lines))
