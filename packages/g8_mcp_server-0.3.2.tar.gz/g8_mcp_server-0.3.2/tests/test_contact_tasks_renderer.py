"""Unit tests for the contact-tasks app surface renderer (Upgrade 4 #35).

Covers:
  * helper functions: priority_info, clip_title, clip_description,
    assignee_label, normalize_status, status_label, bucket_counts,
    due_category, due_label, stat_card
  * empty states (None vs []) — backend unavailable vs zero-tasks start
    state
  * full HTML render: header, 6-stat grid, status bucket pills, timeline
    with status/priority/due/type pills, overflow footer, drill-up
  * priority palette: frontend parity (1=High, 2=Medium, else=Low)
  * due-date categorization: Overdue / Today / Tomorrow / Future / None
  * accent bar precedence: overdue > today > done > cancelled > priority
  * label fallback chain (first/last → name → display_name → work_email)
  * XSS escape coverage on all user-controlled fields
  * text fallback parity with HTML

Pattern matches test_contact_notes_renderer.py.
"""

from __future__ import annotations

from datetime import date

import pytest

from g8_mcp_server.app_renderer import (
    _CONTACT_TASK_STATUS_LABELS,
    _MAX_CONTACT_TASK_ASSIGNEE_LEN,
    _MAX_CONTACT_TASK_DESCRIPTION_LEN,
    _MAX_CONTACT_TASK_TITLE_LEN,
    _MAX_CONTACT_TASKS_RENDERED,
    _contact_tasks_assignee_label,
    _contact_tasks_bucket_counts,
    _contact_tasks_clip_description,
    _contact_tasks_clip_title,
    _contact_tasks_due_category,
    _contact_tasks_due_label,
    _contact_tasks_normalize_status,
    _contact_tasks_priority_info,
    _contact_tasks_stat_card,
    _contact_tasks_status_label,
    _render_contact_tasks_empty_state_html,
    render_contact_tasks_html,
    render_contact_tasks_text_fallback,
)


# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------


def _make_task(**overrides):
    base = {
        "id": "11111111-1111-1111-1111-111111111111",
        "entity_type": "contact",
        "entity_id": "42",
        "title": "Default task title",
        "description": "Default description",
        "status": "open",
        "priority": 2,
        "assignee_id": "u1",
        "assignee_name": "Alice",
        "due_date": None,
        "task_type": None,
        "created_by": "u1",
        "created_at": "2026-04-18T10:00:00Z",
        "updated_at": "2026-04-18T10:00:00Z",
    }
    base.update(overrides)
    return base


TODAY = date(2026, 4, 20)


# ---------------------------------------------------------------------------
# _contact_tasks_priority_info
# ---------------------------------------------------------------------------


class TestPriorityInfo:
    def test_priority_one_is_high(self):
        info = _contact_tasks_priority_info(1)
        assert info["label"] == "High"
        assert info["color"] == "#b91c1c"
        assert info["bg"] == "#fee2e2"

    def test_priority_two_is_medium(self):
        info = _contact_tasks_priority_info(2)
        assert info["label"] == "Medium"
        assert info["color"] == "#92400e"
        assert info["bg"] == "#fff3c4"

    def test_priority_three_is_low(self):
        info = _contact_tasks_priority_info(3)
        assert info["label"] == "Low"
        assert info["color"] == "#777777"

    def test_priority_zero_is_low(self):
        info = _contact_tasks_priority_info(0)
        assert info["label"] == "Low"

    def test_priority_none_is_low(self):
        info = _contact_tasks_priority_info(None)
        assert info["label"] == "Low"

    def test_priority_string_is_low(self):
        info = _contact_tasks_priority_info("not-an-int")
        assert info["label"] == "Low"

    def test_priority_string_digit_parses(self):
        info = _contact_tasks_priority_info("1")
        assert info["label"] == "High"

    def test_priority_negative_is_low(self):
        info = _contact_tasks_priority_info(-1)
        assert info["label"] == "Low"

    def test_returned_dict_is_copy(self):
        # Mutating the returned dict must not corrupt the palette table
        first = _contact_tasks_priority_info(1)
        first["label"] = "MUTATED"
        second = _contact_tasks_priority_info(1)
        assert second["label"] == "High"


# ---------------------------------------------------------------------------
# _contact_tasks_clip_title
# ---------------------------------------------------------------------------


class TestClipTitle:
    def test_short_title_unchanged(self):
        assert _contact_tasks_clip_title("Follow up") == "Follow up"

    def test_whitespace_stripped(self):
        assert _contact_tasks_clip_title("  foo  ") == "foo"

    def test_none_is_untitled(self):
        assert _contact_tasks_clip_title(None) == "(untitled task)"

    def test_empty_is_untitled(self):
        assert _contact_tasks_clip_title("") == "(untitled task)"

    def test_whitespace_only_is_untitled(self):
        assert _contact_tasks_clip_title("   \n\t  ") == "(untitled task)"

    def test_non_string_is_untitled(self):
        assert _contact_tasks_clip_title(42) == "(untitled task)"
        assert _contact_tasks_clip_title(["x"]) == "(untitled task)"

    def test_long_title_clipped_with_ellipsis(self):
        title = "A" * (_MAX_CONTACT_TASK_TITLE_LEN + 50)
        result = _contact_tasks_clip_title(title)
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACT_TASK_TITLE_LEN + 1  # +1 for ellipsis

    def test_clip_preserves_internal_content(self):
        title = "Important: " + "A" * (_MAX_CONTACT_TASK_TITLE_LEN + 50)
        result = _contact_tasks_clip_title(title)
        assert result.startswith("Important:")


# ---------------------------------------------------------------------------
# _contact_tasks_clip_description
# ---------------------------------------------------------------------------


class TestClipDescription:
    def test_empty_returns_empty_string(self):
        # Distinct from title's "(untitled task)" fallback
        assert _contact_tasks_clip_description(None) == ""
        assert _contact_tasks_clip_description("") == ""
        assert _contact_tasks_clip_description("   ") == ""

    def test_short_unchanged(self):
        assert _contact_tasks_clip_description("Short desc") == "Short desc"

    def test_whitespace_stripped(self):
        assert _contact_tasks_clip_description("  desc  ") == "desc"

    def test_long_clipped(self):
        desc = "B" * (_MAX_CONTACT_TASK_DESCRIPTION_LEN + 100)
        result = _contact_tasks_clip_description(desc)
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACT_TASK_DESCRIPTION_LEN + 1

    def test_non_string_empty(self):
        assert _contact_tasks_clip_description(123) == ""
        assert _contact_tasks_clip_description({"a": 1}) == ""


# ---------------------------------------------------------------------------
# _contact_tasks_assignee_label
# ---------------------------------------------------------------------------


class TestAssigneeLabel:
    def test_assignee_name_wins(self):
        assert _contact_tasks_assignee_label({"assignee_name": "Bob", "assignee_id": "u1"}) == "Bob"

    def test_fallback_to_id(self):
        assert _contact_tasks_assignee_label({"assignee_id": "u9"}) == "u9"

    def test_no_assignee_returns_unassigned(self):
        assert _contact_tasks_assignee_label({}) == "Unassigned"

    def test_name_empty_falls_back(self):
        assert _contact_tasks_assignee_label({"assignee_name": "  ", "assignee_id": "u1"}) == "u1"

    def test_whitespace_stripped(self):
        assert _contact_tasks_assignee_label({"assignee_name": "  Bob  "}) == "Bob"

    def test_both_missing_is_unassigned(self):
        assert _contact_tasks_assignee_label({"assignee_name": None, "assignee_id": None}) == "Unassigned"

    def test_long_name_clipped(self):
        name = "A" * (_MAX_CONTACT_TASK_ASSIGNEE_LEN + 50)
        result = _contact_tasks_assignee_label({"assignee_name": name})
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACT_TASK_ASSIGNEE_LEN + 1

    def test_non_dict_is_unassigned(self):
        assert _contact_tasks_assignee_label("not a dict") == "Unassigned"
        assert _contact_tasks_assignee_label(None) == "Unassigned"


# ---------------------------------------------------------------------------
# _contact_tasks_normalize_status
# ---------------------------------------------------------------------------


class TestNormalizeStatus:
    def test_open_unchanged(self):
        assert _contact_tasks_normalize_status("open") == "open"

    def test_uppercase_lowered(self):
        assert _contact_tasks_normalize_status("OPEN") == "open"

    def test_whitespace_stripped(self):
        assert _contact_tasks_normalize_status("  in_progress  ") == "in_progress"

    def test_canceled_normalized_to_cancelled(self):
        assert _contact_tasks_normalize_status("canceled") == "cancelled"

    def test_cancelled_unchanged(self):
        assert _contact_tasks_normalize_status("cancelled") == "cancelled"

    def test_empty_defaults_to_open(self):
        assert _contact_tasks_normalize_status("") == "open"
        assert _contact_tasks_normalize_status(None) == "open"
        assert _contact_tasks_normalize_status("   ") == "open"

    def test_unknown_passes_through(self):
        assert _contact_tasks_normalize_status("weird") == "weird"

    def test_non_string_default(self):
        assert _contact_tasks_normalize_status(42) == "open"


# ---------------------------------------------------------------------------
# _contact_tasks_status_label
# ---------------------------------------------------------------------------


class TestStatusLabel:
    def test_known_statuses(self):
        assert _contact_tasks_status_label("open") == "Open"
        assert _contact_tasks_status_label("in_progress") == "In progress"
        assert _contact_tasks_status_label("done") == "Done"
        assert _contact_tasks_status_label("cancelled") == "Cancelled"

    def test_canceled_maps_same_as_cancelled(self):
        assert _contact_tasks_status_label("canceled") == "Cancelled"

    def test_unknown_titlecased(self):
        assert _contact_tasks_status_label("needs_review") == "Needs Review"


# ---------------------------------------------------------------------------
# _contact_tasks_bucket_counts
# ---------------------------------------------------------------------------


class TestBucketCounts:
    def test_empty_has_all_four_buckets(self):
        buckets = _contact_tasks_bucket_counts([])
        assert buckets == {"open": 0, "in_progress": 0, "done": 0, "cancelled": 0}

    def test_counts_each_status(self):
        tasks = [
            _make_task(status="open"),
            _make_task(status="open"),
            _make_task(status="in_progress"),
            _make_task(status="done"),
            _make_task(status="cancelled"),
        ]
        buckets = _contact_tasks_bucket_counts(tasks)
        assert buckets["open"] == 2
        assert buckets["in_progress"] == 1
        assert buckets["done"] == 1
        assert buckets["cancelled"] == 1

    def test_canceled_aliased_to_cancelled(self):
        tasks = [_make_task(status="canceled"), _make_task(status="cancelled")]
        buckets = _contact_tasks_bucket_counts(tasks)
        assert buckets["cancelled"] == 2

    def test_unknown_status_adds_bucket(self):
        tasks = [_make_task(status="blocked")]
        buckets = _contact_tasks_bucket_counts(tasks)
        assert buckets.get("blocked") == 1
        # Canonical buckets still present
        assert "open" in buckets

    def test_missing_status_defaults_to_open(self):
        tasks = [_make_task(status=None), _make_task(status="")]
        buckets = _contact_tasks_bucket_counts(tasks)
        assert buckets["open"] == 2

    def test_non_dict_tasks_ignored(self):
        tasks = [_make_task(status="open"), "bad", None, 42]
        buckets = _contact_tasks_bucket_counts(tasks)
        assert buckets["open"] == 1


# ---------------------------------------------------------------------------
# _contact_tasks_due_category
# ---------------------------------------------------------------------------


class TestDueCategory:
    def test_none_returns_none(self):
        assert _contact_tasks_due_category(None, today=TODAY) is None

    def test_empty_string_returns_none(self):
        assert _contact_tasks_due_category("", today=TODAY) is None
        assert _contact_tasks_due_category("   ", today=TODAY) is None

    def test_past_date_is_overdue(self):
        assert _contact_tasks_due_category("2026-04-15", today=TODAY) == "overdue"

    def test_today_is_today(self):
        assert _contact_tasks_due_category("2026-04-20", today=TODAY) == "today"

    def test_tomorrow_is_tomorrow(self):
        assert _contact_tasks_due_category("2026-04-21", today=TODAY) == "tomorrow"

    def test_future_is_future(self):
        assert _contact_tasks_due_category("2026-05-01", today=TODAY) == "future"

    def test_datetime_iso_string_parses(self):
        assert _contact_tasks_due_category("2026-04-20T09:00:00Z", today=TODAY) == "today"

    def test_datetime_space_separator_parses(self):
        assert _contact_tasks_due_category("2026-04-15 12:00:00", today=TODAY) == "overdue"

    def test_unparseable_returns_none(self):
        assert _contact_tasks_due_category("not-a-date", today=TODAY) is None
        assert _contact_tasks_due_category("2026/04/20", today=TODAY) is None

    def test_non_string_returns_none(self):
        # Non-string non-None falls to str() conversion — ints become
        # digit-strings which won't parse as ISO dates → None
        assert _contact_tasks_due_category(42, today=TODAY) is None

    def test_defaults_to_utc_today_when_today_none(self):
        # Smoke: should not raise, returns a valid category or None
        result = _contact_tasks_due_category("2099-01-01")
        assert result in ("future", None)


# ---------------------------------------------------------------------------
# _contact_tasks_due_label
# ---------------------------------------------------------------------------


class TestDueLabel:
    def test_overdue(self):
        assert _contact_tasks_due_label("2026-04-15", today=TODAY) == "Overdue"

    def test_today(self):
        assert _contact_tasks_due_label("2026-04-20", today=TODAY) == "Due today"

    def test_tomorrow(self):
        assert _contact_tasks_due_label("2026-04-21", today=TODAY) == "Tomorrow"

    def test_future_shows_date(self):
        assert _contact_tasks_due_label("2026-05-01", today=TODAY) == "2026-05-01"

    def test_none_shows_em_dash(self):
        assert _contact_tasks_due_label(None, today=TODAY) == "—"

    def test_unparseable_echoes_raw(self):
        assert _contact_tasks_due_label("weird-date", today=TODAY) == "weird-date"

    def test_datetime_string_shows_date_part(self):
        assert _contact_tasks_due_label("2026-05-01T10:00:00Z", today=TODAY) == "2026-05-01"


# ---------------------------------------------------------------------------
# _contact_tasks_stat_card
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_basic_render(self):
        html = _contact_tasks_stat_card("Total", "5")
        assert "Total" in html
        assert ">5<" in html

    def test_escape_label_value(self):
        html = _contact_tasks_stat_card("<script>", "<x>")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html
        assert "&lt;x&gt;" in html

    def test_accent_added_to_style(self):
        html = _contact_tasks_stat_card("Total", "5", accent="#dc2626")
        assert "#dc2626" in html

    def test_no_accent_no_border_top(self):
        html = _contact_tasks_stat_card("Total", "5")
        assert "border-top:3px solid" not in html

    def test_accent_escaped(self):
        html = _contact_tasks_stat_card("x", "1", accent='#"><script>')
        assert "<script>" not in html


# ---------------------------------------------------------------------------
# _render_contact_tasks_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_not_available_mode(self):
        html = _render_contact_tasks_empty_state_html(contact_id="42", zero_tasks=False)
        assert "Tasks not available" in html
        assert "#777777" in html  # gray accent

    def test_no_tasks_yet_mode(self):
        html = _render_contact_tasks_empty_state_html(contact_id="42", zero_tasks=True)
        assert "No tasks yet" in html
        assert "#10b981" in html  # green (celebratory — start state)

    def test_contact_id_shown(self):
        html = _render_contact_tasks_empty_state_html(contact_id="abc-xyz", zero_tasks=True)
        assert "abc-xyz" in html

    def test_contact_id_unknown_fallback(self):
        html = _render_contact_tasks_empty_state_html(contact_id="", zero_tasks=False)
        assert "(unknown)" in html

    def test_contact_id_escaped(self):
        html = _render_contact_tasks_empty_state_html(contact_id="<script>", zero_tasks=False)
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_both_modes_return_valid_html(self):
        for zero in (True, False):
            html = _render_contact_tasks_empty_state_html(contact_id="42", zero_tasks=zero)
            assert html.startswith("<!DOCTYPE html>")
            assert html.rstrip().endswith("</html>")

    def test_create_task_hint_only_on_zero_tasks(self):
        zero = _render_contact_tasks_empty_state_html(contact_id="42", zero_tasks=True)
        not_avail = _render_contact_tasks_empty_state_html(contact_id="42", zero_tasks=False)
        # "Create the first task" only on zero mode
        assert "Create" in zero
        assert "Create" not in not_avail


# ---------------------------------------------------------------------------
# render_contact_tasks_html — empty / fallback cases
# ---------------------------------------------------------------------------


class TestRenderHtmlEmpty:
    def test_none_routes_to_not_available(self):
        html = render_contact_tasks_html(tasks=None, contact_id="42")
        assert "Tasks not available" in html

    def test_empty_list_routes_to_no_tasks_yet(self):
        html = render_contact_tasks_html(tasks=[], contact_id="42")
        assert "No tasks yet" in html

    def test_all_non_dict_routes_to_no_tasks_yet(self):
        html = render_contact_tasks_html(tasks=["bad", None, 42], contact_id="42")
        assert "No tasks yet" in html


# ---------------------------------------------------------------------------
# render_contact_tasks_html — full render
# ---------------------------------------------------------------------------


class TestRenderHtmlFull:
    def test_header_shows_label_from_first_last(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"first_name": "Jane", "last_name": "Doe"},
            today=TODAY,
        )
        assert "Jane Doe — tasks" in html

    def test_header_fallback_to_name(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"name": "Acme Lead"},
            today=TODAY,
        )
        assert "Acme Lead" in html

    def test_header_fallback_to_display_name(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"display_name": "@janed"},
            today=TODAY,
        )
        assert "@janed" in html

    def test_header_fallback_to_work_email(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"work_email": "jane@acme.co"},
            today=TODAY,
        )
        assert "jane@acme.co" in html

    def test_header_fallback_to_email(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"email": "personal@example.com"},
            today=TODAY,
        )
        assert "personal@example.com" in html

    def test_header_generic_when_no_contact(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert "Contact — tasks" in html

    def test_total_badge_shows_count(self):
        tasks = [_make_task() for _ in range(3)]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        assert "3 TOTAL" in html

    def test_stat_grid_six_cards(self):
        html = render_contact_tasks_html(tasks=[_make_task()], contact_id="42", today=TODAY)
        # Six stat labels: Total / Open / In progress / Overdue / Due today / Done
        for label in ("Total", "Open", "In progress", "Overdue", "Due today", "Done"):
            assert label in html

    def test_overdue_count_reflects_open_task(self):
        tasks = [
            _make_task(status="open", due_date="2026-04-10"),  # overdue
            _make_task(status="open", due_date="2026-04-10"),  # overdue
            _make_task(status="done", due_date="2026-04-10"),  # done — NOT counted
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        # Overdue count 2, Done count 1
        assert ">2<" in html  # overdue value
        # Done stat card also renders a 1
        assert "Done" in html

    def test_today_count_reflects_open_task(self):
        tasks = [
            _make_task(status="open", due_date="2026-04-20"),
            _make_task(status="in_progress", due_date="2026-04-20"),
            # Done on same day doesn't count
            _make_task(status="done", due_date="2026-04-20"),
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        # 2 tasks due today (the done one excluded)
        assert "Due today" in html
        # Rough check that "2" appears near Due today stat card
        assert ">2<" in html

    def test_done_count_present(self):
        tasks = [_make_task(status="done") for _ in range(4)]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        assert "Done" in html
        assert ">4<" in html

    def test_cancelled_excluded_from_due_rollups(self):
        tasks = [
            _make_task(status="cancelled", due_date="2026-04-10"),
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        # Overdue should be 0 because the only task is cancelled
        # (stat card renders ">0<" for zero overdue)
        assert "Overdue" in html

    def test_status_bucket_pills_present(self):
        tasks = [
            _make_task(status="open"),
            _make_task(status="in_progress"),
            _make_task(status="done"),
            _make_task(status="cancelled"),
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        for label in ("Open", "In progress", "Done", "Cancelled"):
            assert label in html

    def test_priority_pill_high(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(priority=1)], contact_id="42", today=TODAY
        )
        assert "High" in html
        assert "#b91c1c" in html

    def test_priority_pill_medium_default(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(priority=2)], contact_id="42", today=TODAY
        )
        assert "Medium" in html
        assert "#92400e" in html

    def test_priority_pill_low(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(priority=3)], contact_id="42", today=TODAY
        )
        assert "Low" in html

    def test_due_pill_overdue(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(status="open", due_date="2026-04-15")],
            contact_id="42",
            today=TODAY,
        )
        assert "Overdue" in html
        assert "#b91c1c" in html

    def test_due_pill_today(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(status="open", due_date="2026-04-20")],
            contact_id="42",
            today=TODAY,
        )
        assert "Due today" in html

    def test_due_pill_tomorrow(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(status="open", due_date="2026-04-21")],
            contact_id="42",
            today=TODAY,
        )
        assert "Tomorrow" in html

    def test_due_pill_future_with_date(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(status="open", due_date="2026-05-15")],
            contact_id="42",
            today=TODAY,
        )
        assert "Due 2026-05-15" in html

    def test_no_due_pill_when_no_due_date(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(due_date=None)], contact_id="42", today=TODAY
        )
        # No "Due today", no "Overdue" pill in the task row (they may still
        # appear in the stat card labels)
        # Count "Overdue" occurrences — should only be 1 (stat card label)
        # This is a loose assertion since the word Overdue appears elsewhere
        assert html.count("Overdue") <= 2  # stat card label once

    def test_task_type_pill_shown_when_set(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(task_type="call")], contact_id="42", today=TODAY
        )
        assert ">call<" in html

    def test_task_type_pill_absent_when_missing(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(task_type=None)], contact_id="42", today=TODAY
        )
        # No task-type pill with indigo styling
        assert "#f2eafe" in html or "#f2eafe" not in html  # vacuous but safe

    def test_assignee_shown_in_timeline(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(assignee_name="Bob")], contact_id="42", today=TODAY
        )
        assert "Bob" in html

    def test_unassigned_label_shown(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(assignee_name=None, assignee_id=None)],
            contact_id="42",
            today=TODAY,
        )
        assert "Unassigned" in html

    def test_task_id_code_shown(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(id="xyz-789")], contact_id="42", today=TODAY
        )
        assert "xyz-789" in html

    def test_task_title_shown(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(title="Call customer")],
            contact_id="42",
            today=TODAY,
        )
        assert "Call customer" in html

    def test_description_shown_when_present(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(description="Reach out 3x")],
            contact_id="42",
            today=TODAY,
        )
        assert "Reach out 3x" in html

    def test_description_absent_when_empty(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(description="")], contact_id="42", today=TODAY
        )
        # No description block rendered — check that the task still
        # renders (title is there) but the description div is not
        assert "Default task title" in html

    def test_timeline_overflow_shows_footer(self):
        tasks = [
            _make_task(id=f"task-{i}", title=f"Task {i}")
            for i in range(_MAX_CONTACT_TASKS_RENDERED + 5)
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        assert "+ 5 older tasks" in html

    def test_timeline_overflow_singular(self):
        tasks = [
            _make_task(id=f"task-{i}", title=f"Task {i}")
            for i in range(_MAX_CONTACT_TASKS_RENDERED + 1)
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        assert "+ 1 older task" in html
        assert "+ 1 older tasks" not in html

    def test_no_overflow_footer_when_under_cap(self):
        tasks = [_make_task() for _ in range(5)]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        assert "older task" not in html

    def test_drill_up_links_present(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert "g8://contacts/42" in html
        assert "g8://contacts/42/notes" in html
        assert "POST /contacts/42/tasks" in html

    def test_full_html_structure(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")
        assert "<body" in html


# ---------------------------------------------------------------------------
# XSS escape coverage
# ---------------------------------------------------------------------------


class TestXssEscape:
    def test_title_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(title="<script>alert(1)</script>")],
            contact_id="42",
            today=TODAY,
        )
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_description_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(description="<img src=x onerror=alert(1)>")],
            contact_id="42",
            today=TODAY,
        )
        assert "<img src=x" not in html
        assert "&lt;img" in html

    def test_assignee_name_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(assignee_name="<b>Bob</b>")],
            contact_id="42",
            today=TODAY,
        )
        assert "<b>Bob</b>" not in html
        assert "&lt;b&gt;Bob&lt;/b&gt;" in html

    def test_task_type_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(task_type="<em>call</em>")],
            contact_id="42",
            today=TODAY,
        )
        assert "<em>call</em>" not in html

    def test_task_id_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(id="<svg/onload=alert(1)>")],
            contact_id="42",
            today=TODAY,
        )
        assert "<svg/onload=alert(1)>" not in html

    def test_contact_id_escaped_in_header(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="<script>",
            today=TODAY,
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_contact_label_escaped(self):
        html = render_contact_tasks_html(
            tasks=[_make_task()],
            contact_id="42",
            contact={"first_name": "<img>", "last_name": "x"},
            today=TODAY,
        )
        assert "<img>" not in html
        assert "&lt;img&gt;" in html

    def test_no_double_escape(self):
        html = render_contact_tasks_html(
            tasks=[_make_task(title="Q&A session")],
            contact_id="42",
            today=TODAY,
        )
        # Should be &amp;, not &amp;amp;
        assert "&amp;amp;" not in html
        assert "Q&amp;A session" in html


# ---------------------------------------------------------------------------
# Accent bar precedence — overdue > today > done > cancelled > priority
# ---------------------------------------------------------------------------


class TestAccentPrecedence:
    def test_overdue_uses_red_border(self):
        html = render_contact_tasks_html(
            tasks=[
                _make_task(status="open", due_date="2026-04-10", priority=3),
            ],
            contact_id="42",
            today=TODAY,
        )
        # Left border should be red (#dc2626)
        assert "border-left:3px solid #dc2626" in html

    def test_today_uses_amber_border(self):
        html = render_contact_tasks_html(
            tasks=[
                _make_task(status="open", due_date="2026-04-20", priority=3),
            ],
            contact_id="42",
            today=TODAY,
        )
        assert "border-left:3px solid #b45309" in html

    def test_done_uses_green_border(self):
        html = render_contact_tasks_html(
            tasks=[
                _make_task(status="done", due_date="2026-04-10", priority=1),
            ],
            contact_id="42",
            today=TODAY,
        )
        # Done beats overdue — because done tasks don't need overdue
        # call-outs
        assert "border-left:3px solid #059669" in html

    def test_cancelled_uses_gray_border(self):
        html = render_contact_tasks_html(
            tasks=[
                _make_task(status="cancelled", due_date="2026-04-10", priority=1),
            ],
            contact_id="42",
            today=TODAY,
        )
        assert "border-left:3px solid #777777" in html

    def test_no_due_falls_back_to_priority(self):
        html = render_contact_tasks_html(
            tasks=[
                _make_task(status="open", due_date=None, priority=1),
            ],
            contact_id="42",
            today=TODAY,
        )
        # Priority 1 = red accent
        assert "border-left:3px solid #b91c1c" in html


# ---------------------------------------------------------------------------
# render_contact_tasks_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_empty_state(self):
        txt = render_contact_tasks_text_fallback(tasks=None, contact_id="42")
        assert "Tasks not available" in txt
        assert "# " in txt  # markdown

    def test_empty_list_empty_state(self):
        txt = render_contact_tasks_text_fallback(tasks=[], contact_id="42")
        assert "No tasks yet" in txt

    def test_all_non_dict_empty_state(self):
        txt = render_contact_tasks_text_fallback(
            tasks=["bad", None, 42], contact_id="42"
        )
        assert "No tasks yet" in txt

    def test_header_shows_label(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task()],
            contact_id="42",
            contact={"first_name": "Jane", "last_name": "Doe"},
            today=TODAY,
        )
        assert "# Jane Doe — tasks" in txt

    def test_header_generic_when_no_contact(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert "# Contact — tasks" in txt

    def test_summary_line_shows_counts(self):
        tasks = [
            _make_task(status="open"),
            _make_task(status="in_progress"),
            _make_task(status="done"),
        ]
        txt = render_contact_tasks_text_fallback(
            tasks=tasks, contact_id="42", today=TODAY
        )
        assert "Total: 3" in txt
        assert "Open: 1" in txt
        assert "In progress: 1" in txt
        assert "Done: 1" in txt

    def test_due_rollup_present(self):
        tasks = [
            _make_task(status="open", due_date="2026-04-15"),
            _make_task(status="open", due_date="2026-04-20"),
            _make_task(status="open", due_date="2026-04-21"),
        ]
        txt = render_contact_tasks_text_fallback(
            tasks=tasks, contact_id="42", today=TODAY
        )
        assert "Overdue: 1" in txt
        assert "Due today: 1" in txt
        assert "Tomorrow: 1" in txt

    def test_timeline_entry_format(self):
        task = _make_task(
            id="abc-1",
            title="Call customer",
            status="open",
            priority=1,
            assignee_name="Alice",
            due_date="2026-04-15",
            task_type="call",
        )
        txt = render_contact_tasks_text_fallback(
            tasks=[task], contact_id="42", today=TODAY
        )
        # Format: [Status] Priority | Title [type] | Assignee due=X (id=Y)
        assert "[Open]" in txt
        assert "High" in txt
        assert "Call customer" in txt
        assert "[call]" in txt
        assert "Alice" in txt
        assert "due=Overdue" in txt
        assert "id=abc-1" in txt

    def test_no_due_suffix_when_no_date(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task(due_date=None)], contact_id="42", today=TODAY
        )
        assert " due=" not in txt

    def test_no_type_suffix_when_no_type(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task(task_type=None)], contact_id="42", today=TODAY
        )
        # No "[type]" bracket near task listing
        # Task title is "Default task title" so the line has "Default task title |"
        # (pipe right after title, no [type] in between)
        lines = [line for line in txt.split("\n") if "Default task title" in line]
        assert any("| Alice" in line for line in lines)

    def test_newline_in_title_flattened(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task(title="Line1\nLine2")],
            contact_id="42",
            today=TODAY,
        )
        assert "Line1 ⏎ Line2" in txt

    def test_timeline_overflow_shows_footer(self):
        tasks = [
            _make_task(id=f"t-{i}", title=f"Task {i}")
            for i in range(_MAX_CONTACT_TASKS_RENDERED + 3)
        ]
        txt = render_contact_tasks_text_fallback(
            tasks=tasks, contact_id="42", today=TODAY
        )
        assert "+ 3 older tasks" in txt

    def test_timeline_overflow_singular(self):
        tasks = [
            _make_task(id=f"t-{i}", title=f"Task {i}")
            for i in range(_MAX_CONTACT_TASKS_RENDERED + 1)
        ]
        txt = render_contact_tasks_text_fallback(
            tasks=tasks, contact_id="42", today=TODAY
        )
        assert "+ 1 older task" in txt
        assert "+ 1 older tasks" not in txt

    def test_drill_up_links(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert "g8://contacts/42" in txt
        assert "g8://contacts/42/notes" in txt
        assert "POST /contacts/42/tasks" in txt

    def test_trailing_newline(self):
        txt = render_contact_tasks_text_fallback(
            tasks=[_make_task()], contact_id="42", today=TODAY
        )
        assert txt.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke / regression
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_renders_many_tasks_mixed_statuses(self):
        tasks = [
            _make_task(id=f"open-{i}", status="open") for i in range(5)
        ] + [
            _make_task(id=f"ip-{i}", status="in_progress") for i in range(3)
        ] + [
            _make_task(id=f"done-{i}", status="done") for i in range(10)
        ] + [
            _make_task(id=f"c-{i}", status="cancelled") for i in range(2)
        ]
        html = render_contact_tasks_html(tasks=tasks, contact_id="42", today=TODAY)
        txt = render_contact_tasks_text_fallback(tasks=tasks, contact_id="42", today=TODAY)
        # Total 20
        assert "20 TOTAL" in html
        assert "Total: 20" in txt

    def test_status_label_constants_frozen(self):
        # Guard against accidental edits to the label map
        assert _CONTACT_TASK_STATUS_LABELS["open"] == "Open"
        assert _CONTACT_TASK_STATUS_LABELS["in_progress"] == "In progress"
        assert _CONTACT_TASK_STATUS_LABELS["done"] == "Done"
        assert _CONTACT_TASK_STATUS_LABELS["cancelled"] == "Cancelled"
        assert _CONTACT_TASK_STATUS_LABELS["canceled"] == "Cancelled"
