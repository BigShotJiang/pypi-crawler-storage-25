"""Unit tests for the MCP HTML application-surface renderer.

Covers the Upgrade 4 spike that lets us return `mimeType="text/html"` resources
from the MCP server. The renderer must:

- HTML-escape every field that came from the backend / user data
- reject non-http(s)/data URIs (so Claude.ai can't be pointed at exotic schemes)
- cap the number of rendered images
- always produce something (empty state) when there are zero renderable images
- mirror the same truths in the plaintext fallback

We exercise it as pure-function unit tests — no FastMCP wiring needed here.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_IMAGES_RENDERED,
    render_ad_images_html,
    render_ad_images_text_fallback,
)


def _records(n: int, *, url_prefix: str = "https://cdn.example.com/img") -> list[dict]:
    return [
        {
            "image_id": f"meta_hero_{i}",
            "platform": "meta",
            "image_url": f"{url_prefix}-{i}.png",
            "aspect_ratio": "1.91:1",
            "style": f"modern style {i}",
        }
        for i in range(n)
    ]


class TestRenderAdImagesHtml:
    def test_returns_complete_html_document(self):
        html = render_ad_images_html(
            campaign_id="abc-123",
            campaign_name="Q2 Launch",
            image_records=_records(2),
        )
        assert html.startswith("<!doctype html>")
        assert "<html" in html and "</html>" in html.rstrip()
        assert "Q2 Launch" in html
        assert "abc-123" in html

    def test_escapes_user_data(self):
        """Malicious payloads in campaign_name or style must not escape attribute/tag context."""
        html = render_ad_images_html(
            campaign_id="abc-123",
            campaign_name="<script>alert(1)</script>",
            image_records=[{
                "image_id": "<img onerror=x>",
                "platform": "meta",
                "image_url": "https://cdn.example.com/ok.png",
                "aspect_ratio": "1.91:1",
                "style": "\"'<b>hax</b>",
            }],
        )
        # Escaped, never raw
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html
        assert "<img onerror=x>" not in html
        assert "&lt;b&gt;hax&lt;/b&gt;" in html

    def test_rejects_non_http_urls(self):
        """File/ javascript / mailto URLs must be skipped entirely."""
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="c",
            image_records=[
                {"image_id": "x1", "image_url": "javascript:alert(1)", "platform": "meta"},
                {"image_id": "x2", "image_url": "file:///etc/passwd", "platform": "meta"},
                {"image_id": "x3", "image_url": "https://ok.example.com/good.png", "platform": "meta"},
            ],
        )
        assert "javascript:" not in html
        assert "file:///" not in html
        assert "https://ok.example.com/good.png" in html
        # One skip note
        assert "2 image(s) omitted" in html

    def test_accepts_data_image_uris(self):
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="c",
            image_records=[{
                "image_id": "x",
                "image_url": "data:image/png;base64,AAAA",
                "platform": "meta",
            }],
        )
        assert "data:image/png;base64,AAAA" in html

    def test_caps_image_count(self):
        records = _records(_MAX_IMAGES_RENDERED + 5)
        html = render_ad_images_html(
            campaign_id="c", campaign_name="c", image_records=records
        )
        # Only MAX_IMAGES_RENDERED <figure> cards
        assert html.count("<figure") == _MAX_IMAGES_RENDERED
        # 5 extras accounted for in the skip note
        assert "5 image(s) omitted" in html

    def test_empty_state_when_no_renderable_images(self):
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="Campaign Alpha",
            image_records=[],
        )
        assert "No ad images generated" in html
        assert "Campaign Alpha" in html

    def test_empty_state_when_only_bad_urls(self):
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="c",
            image_records=[
                {"image_id": "a", "image_url": None, "platform": "meta"},
                {"image_id": "b", "image_url": "ftp://nope", "platform": "meta"},
            ],
        )
        assert "No ad images generated" in html

    def test_skips_non_dict_records(self):
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="c",
            image_records=[
                "not a dict",  # type: ignore[list-item]
                42,  # type: ignore[list-item]
                {"image_id": "x", "image_url": "https://ok/x.png", "platform": "meta"},
            ],
        )
        assert "ok/x.png" in html

    def test_no_javascript_ever_emitted(self):
        html = render_ad_images_html(
            campaign_id="c",
            campaign_name="c",
            image_records=_records(3),
        )
        # Hard rule from the spike: no <script>, no inline event handlers
        assert "<script" not in html.lower()
        assert "onclick=" not in html.lower()
        assert "onerror=" not in html.lower()


class TestRenderAdImagesTextFallback:
    def test_lists_each_image(self):
        text = render_ad_images_text_fallback(
            campaign_id="c",
            campaign_name="Camp",
            image_records=_records(3),
        )
        assert "Ad creatives for Camp (c)" in text
        for i in range(3):
            assert f"meta_hero_{i}" in text

    def test_empty_state_plaintext(self):
        text = render_ad_images_text_fallback(
            campaign_id="c",
            campaign_name="Camp",
            image_records=[],
        )
        assert "No ad images generated for this campaign yet." in text

    def test_caps_and_reports_remainder(self):
        records = _records(_MAX_IMAGES_RENDERED + 3)
        text = render_ad_images_text_fallback(
            campaign_id="c",
            campaign_name="Camp",
            image_records=records,
        )
        # MAX lines listed + "... and 3 more"
        assert f"... and 3 more (cap {_MAX_IMAGES_RENDERED})." in text

    def test_ignores_non_dict_records(self):
        text = render_ad_images_text_fallback(
            campaign_id="c",
            campaign_name="Camp",
            image_records=["nope", 1, {"image_id": "x", "image_url": "https://ok/x.png", "platform": "meta"}],
        )
        assert "https://ok/x.png" in text


@pytest.mark.parametrize("count", [0, 1, _MAX_IMAGES_RENDERED, _MAX_IMAGES_RENDERED + 1])
def test_html_round_trip_is_parseable(count):
    """Output must be valid-ish HTML — we lean on html.parser as a sanity check."""
    from html.parser import HTMLParser

    class _P(HTMLParser):
        def error(self, message):  # pragma: no cover - parser is forgiving
            raise AssertionError(message)

    html = render_ad_images_html(
        campaign_id=f"c-{count}",
        campaign_name=f"Campaign {count}",
        image_records=_records(count),
    )
    _P().feed(html)
