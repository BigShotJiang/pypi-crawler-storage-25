"""
Unit tests for Surface #55 — per-repo scan report renderer.

Surface #55 renders the latest persisted scan record for a single repo at
`g8://repos/{repo_id}/scan` (+ `.txt`). 4-segment template, sibling to
`/overview` (surface #32), `/install` (surface #49), and `/streams`
(surface #54).

Backend: `GET /repos/{repo_id}/scan` → ScanResponse dict with
{id, repo_id, tech_stack, api_routes, readme_summary, product_type,
gtm_readiness, scan_duration_ms, created_at}.

Coverage:
- Helpers (_repo_scan_clip, _repo_scan_id_display,
  _repo_scan_product_type_display, _repo_scan_tech_stack_items,
  _repo_scan_gtm_flag_items, _repo_scan_gtm_ready_count,
  _repo_scan_route_method_display, _repo_scan_route_rows,
  _repo_scan_duration_display, _repo_scan_created_at_display,
  _repo_scan_stat_card, _repo_scan_tech_chip, _repo_scan_gtm_pill,
  _repo_scan_route_chip)
- Empty-state (unavailable / no_scan modes)
- render_repo_scan_html (None → unavailable, full scan → rich HTML)
- render_repo_scan_text_fallback (markdown mirror)
- Regression locks:
    - test_no_single_side_accent_borders (AI-tell)
    - test_no_legacy_accent_hexes (pre-graph8 palette)
    - test_drill_up_does_NOT_list_self
    - test_manage_block_does_not_list_self
    - 4 stat cards present (Framework / API routes / Product type / GTM)
    - 4 GTM flag pills present (always 4, missing → False marker)
    - Route overflow at _MAX_REPO_SCAN_ROUTES_RENDERED
    - README clipped at _MAX_REPO_SCAN_README_LEN
    - XSS escape on user-controlled fields
"""

from __future__ import annotations

import datetime as dt
import re

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_MUTED_BG,
    _G8_POSITIVE_FG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_FG,
    _MAX_REPO_SCAN_README_LEN,
    _MAX_REPO_SCAN_ROUTES_RENDERED,
    _render_repo_scan_empty_state_html,
    _repo_scan_clip,
    _repo_scan_created_at_display,
    _repo_scan_duration_display,
    _repo_scan_gtm_flag_items,
    _repo_scan_gtm_pill,
    _repo_scan_gtm_ready_count,
    _repo_scan_id_display,
    _repo_scan_product_type_display,
    _repo_scan_route_chip,
    _repo_scan_route_method_display,
    _repo_scan_route_rows,
    _repo_scan_stat_card,
    _repo_scan_tech_chip,
    _repo_scan_tech_stack_items,
    render_repo_scan_html,
    render_repo_scan_text_fallback,
)


REPO_ID = "11111111-2222-3333-4444-555555555555"
SCAN_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

SAMPLE_SCAN: dict = {
    "id": SCAN_ID,
    "repo_id": REPO_ID,
    "tech_stack": {
        "framework": "next.js",
        "framework_version": "15.0.1",
        "language": "typescript",
        "router": "app",
        "styling": "tailwind",
        "auth_provider": "clerk",
        "database": "postgres",
        "deployment": "vercel",
    },
    "api_routes": [
        {"path": "/api/users", "methods": ["GET", "POST"]},
        {"path": "/api/users/[id]", "methods": ["GET", "PATCH", "DELETE"]},
        {"path": "/api/auth/login", "methods": ["POST"]},
    ],
    "readme_summary": "Internal admin dashboard for the example.com SaaS product.",
    "product_type": "b2b_saas",
    "gtm_readiness": {
        "has_tracking": True,
        "has_forms": True,
        "has_attribution": False,
        "has_identity": True,
    },
    "scan_duration_ms": 12345,
    "created_at": "2026-04-20T15:30:00",
}


# ---------------------------------------------------------------------- #
# Clip helper                                                            #
# ---------------------------------------------------------------------- #


class TestClip:
    def test_empty(self):
        assert _repo_scan_clip("", 100) == ""

    def test_whitespace_only(self):
        assert _repo_scan_clip("   ", 100) == ""

    def test_none(self):
        assert _repo_scan_clip(None, 100) == ""

    def test_non_string_coerces(self):
        assert _repo_scan_clip(42, 10) == "42"

    def test_short(self):
        assert _repo_scan_clip("hello", 100) == "hello"

    def test_long_truncated(self):
        v = "a" * 200
        out = _repo_scan_clip(v, 50)
        assert len(out) <= 50
        assert out.endswith("…")


# ---------------------------------------------------------------------- #
# id_display                                                             #
# ---------------------------------------------------------------------- #


class TestIdDisplay:
    def test_none(self):
        assert _repo_scan_id_display(None) == "(unknown)"

    def test_empty(self):
        assert _repo_scan_id_display("") == "(unknown)"

    def test_whitespace(self):
        assert _repo_scan_id_display("   ") == "(unknown)"

    def test_short(self):
        assert _repo_scan_id_display("abc") == "abc"

    def test_strips_whitespace(self):
        assert _repo_scan_id_display("  xyz  ") == "xyz"


# ---------------------------------------------------------------------- #
# product_type_display                                                   #
# ---------------------------------------------------------------------- #


class TestProductTypeDisplay:
    def test_none(self):
        assert _repo_scan_product_type_display(None) == ""

    def test_empty(self):
        assert _repo_scan_product_type_display("") == ""

    def test_underscore_replaced(self):
        assert _repo_scan_product_type_display("b2b_saas") == "b2b saas"

    def test_dash_replaced(self):
        assert _repo_scan_product_type_display("b2c-marketplace") == "b2c marketplace"

    def test_passthrough(self):
        assert _repo_scan_product_type_display("api") == "api"


# ---------------------------------------------------------------------- #
# tech_stack_items                                                       #
# ---------------------------------------------------------------------- #


class TestTechStackItems:
    def test_empty_dict(self):
        assert _repo_scan_tech_stack_items({}) == []

    def test_none(self):
        assert _repo_scan_tech_stack_items(None) == []

    def test_non_dict(self):
        assert _repo_scan_tech_stack_items([1, 2, 3]) == []

    def test_only_present_fields(self):
        out = _repo_scan_tech_stack_items({"framework": "next.js", "language": "typescript"})
        assert ("Framework", "next.js") in out
        assert ("Language", "typescript") in out
        # Other fields not present
        labels = [label for label, _ in out]
        assert "Styling" not in labels
        assert len(out) == 2

    def test_skips_empty_strings(self):
        out = _repo_scan_tech_stack_items({"framework": "", "language": "python"})
        labels = [label for label, _ in out]
        assert "Framework" not in labels
        assert "Language" in labels

    def test_preserves_order(self):
        out = _repo_scan_tech_stack_items(SAMPLE_SCAN["tech_stack"])
        labels = [label for label, _ in out]
        # Framework first, deployment last (per _REPO_SCAN_TECH_FIELDS order)
        assert labels[0] == "Framework"
        assert labels[-1] == "Deploy"


# ---------------------------------------------------------------------- #
# gtm_flag_items / gtm_ready_count                                       #
# ---------------------------------------------------------------------- #


class TestGtmFlagItems:
    def test_empty(self):
        out = _repo_scan_gtm_flag_items({})
        # Always 4 flags
        assert len(out) == 4
        # All False when keys missing
        assert all(ok is False for _, ok in out)

    def test_none(self):
        out = _repo_scan_gtm_flag_items(None)
        assert len(out) == 4
        assert all(ok is False for _, ok in out)

    def test_non_dict(self):
        out = _repo_scan_gtm_flag_items([])
        assert len(out) == 4

    def test_all_true(self):
        out = _repo_scan_gtm_flag_items({
            "has_tracking": True,
            "has_forms": True,
            "has_attribution": True,
            "has_identity": True,
        })
        assert all(ok is True for _, ok in out)

    def test_partial(self):
        out = _repo_scan_gtm_flag_items(SAMPLE_SCAN["gtm_readiness"])
        flags = dict(out)
        assert flags["Tracking"] is True
        assert flags["Forms"] is True
        assert flags["Attribution"] is False
        assert flags["Identity"] is True

    def test_labels_canonical(self):
        out = _repo_scan_gtm_flag_items({})
        labels = [label for label, _ in out]
        assert labels == ["Tracking", "Forms", "Attribution", "Identity"]


class TestGtmReadyCount:
    def test_empty(self):
        assert _repo_scan_gtm_ready_count({}) == 0

    def test_none(self):
        assert _repo_scan_gtm_ready_count(None) == 0

    def test_partial(self):
        assert _repo_scan_gtm_ready_count(SAMPLE_SCAN["gtm_readiness"]) == 3

    def test_full(self):
        assert _repo_scan_gtm_ready_count({
            "has_tracking": True,
            "has_forms": True,
            "has_attribution": True,
            "has_identity": True,
        }) == 4


# ---------------------------------------------------------------------- #
# route_method_display                                                   #
# ---------------------------------------------------------------------- #


class TestRouteMethodDisplay:
    def test_none(self):
        assert _repo_scan_route_method_display(None) == "GET"

    def test_empty(self):
        assert _repo_scan_route_method_display([]) == "GET"

    def test_non_list(self):
        assert _repo_scan_route_method_display("GET") == "GET"

    def test_uppercases(self):
        assert _repo_scan_route_method_display(["get", "post"]) == "GET, POST"

    def test_dedupes(self):
        assert _repo_scan_route_method_display(["GET", "GET", "POST"]) == "GET, POST"

    def test_sorts_alphabetically(self):
        assert _repo_scan_route_method_display(["POST", "GET"]) == "GET, POST"

    def test_filters_non_strings(self):
        assert _repo_scan_route_method_display(["GET", 42, None]) == "GET"


# ---------------------------------------------------------------------- #
# route_rows                                                             #
# ---------------------------------------------------------------------- #


class TestRouteRows:
    def test_empty(self):
        assert _repo_scan_route_rows([]) == []

    def test_none(self):
        assert _repo_scan_route_rows(None) == []

    def test_non_list(self):
        assert _repo_scan_route_rows({}) == []

    def test_filters_non_dict_entries(self):
        out = _repo_scan_route_rows([{"path": "/x"}, "garbage", 42])
        assert len(out) == 1

    def test_filters_missing_path(self):
        out = _repo_scan_route_rows([{"methods": ["GET"]}, {"path": "/x"}])
        assert len(out) == 1
        assert out[0][1] == "/x"

    def test_dedupes_by_method_and_path(self):
        out = _repo_scan_route_rows([
            {"path": "/x", "methods": ["GET"]},
            {"path": "/x", "methods": ["GET"]},
        ])
        assert len(out) == 1

    def test_keeps_distinct_methods(self):
        out = _repo_scan_route_rows([
            {"path": "/x", "methods": ["GET"]},
            {"path": "/x", "methods": ["POST"]},
        ])
        assert len(out) == 2

    def test_preserves_order(self):
        out = _repo_scan_route_rows(SAMPLE_SCAN["api_routes"])
        paths = [p for _, p in out]
        assert paths == ["/api/users", "/api/users/[id]", "/api/auth/login"]


# ---------------------------------------------------------------------- #
# duration_display                                                       #
# ---------------------------------------------------------------------- #


class TestDurationDisplay:
    def test_none(self):
        assert _repo_scan_duration_display(None) == ""

    def test_zero(self):
        assert _repo_scan_duration_display(0) == ""

    def test_negative(self):
        assert _repo_scan_duration_display(-100) == ""

    def test_non_int(self):
        assert _repo_scan_duration_display("1500") == ""

    def test_bool_rejected(self):
        # bool is subclass of int — make sure we don't accept it
        assert _repo_scan_duration_display(True) == ""

    def test_sub_second(self):
        assert _repo_scan_duration_display(450) == "450 ms"

    def test_seconds(self):
        assert _repo_scan_duration_display(12345) == "12.3s"

    def test_minutes_no_secs(self):
        # 120000 ms = 120s = 2m 0s → "2m"
        assert _repo_scan_duration_display(120000) == "2m"

    def test_minutes_with_secs(self):
        # 154000 ms = 154s = 2m 34s
        assert _repo_scan_duration_display(154000) == "2m 34s"


# ---------------------------------------------------------------------- #
# created_at_display                                                     #
# ---------------------------------------------------------------------- #


class TestCreatedAtDisplay:
    def test_none(self):
        assert _repo_scan_created_at_display(None) == ""

    def test_empty_string(self):
        assert _repo_scan_created_at_display("") == ""

    def test_iso_string(self):
        assert _repo_scan_created_at_display("2026-04-20T15:30:00") == "2026-04-20 15:30:00"

    def test_iso_string_with_tz(self):
        # First 19 chars only
        out = _repo_scan_created_at_display("2026-04-20T15:30:00.123456Z")
        assert out.startswith("2026-04-20 15:30:00")
        assert len(out) == 19

    def test_datetime_object(self):
        d = dt.datetime(2026, 4, 20, 15, 30, 0)
        assert _repo_scan_created_at_display(d) == "2026-04-20 15:30:00"


# ---------------------------------------------------------------------- #
# stat_card                                                              #
# ---------------------------------------------------------------------- #


class TestStatCard:
    def test_uniform_border(self):
        h = _repo_scan_stat_card("Framework", "next.js")
        assert f"border:1px solid {_G8_BORDER}" in h

    def test_primary_accent(self):
        h = _repo_scan_stat_card("X", "Y", accent="primary")
        assert _G8_PRIMARY in h

    def test_positive_accent(self):
        h = _repo_scan_stat_card("X", "Y", accent="positive")
        assert _G8_POSITIVE_FG in h

    def test_warning_accent(self):
        h = _repo_scan_stat_card("X", "Y", accent="warning")
        assert _G8_WARNING_FG in h

    def test_destructive_accent(self):
        h = _repo_scan_stat_card("X", "Y", accent="destructive")
        assert "#ca3214" in h

    def test_default_accent(self):
        h = _repo_scan_stat_card("X", "Y")
        assert _G8_TEXT in h

    def test_html_escapes_label_value(self):
        h = _repo_scan_stat_card("<x>", "<v>")
        assert "&lt;x&gt;" in h
        assert "&lt;v&gt;" in h
        assert "<x>" not in h.replace("&lt;x&gt;", "")

    def test_no_single_side_colored_accent_border(self):
        for accent in ("primary", "positive", "destructive", "warning", "text"):
            h = _repo_scan_stat_card("X", "Y", accent=accent)
            assert "border-left:" not in h
            assert "border-right:" not in h
            assert "border-top:" not in h
            assert "border-bottom:" not in h


# ---------------------------------------------------------------------- #
# tech_chip                                                              #
# ---------------------------------------------------------------------- #


class TestTechChip:
    def test_renders_label_value(self):
        h = _repo_scan_tech_chip("Framework", "next.js")
        assert "Framework" in h
        assert "next.js" in h

    def test_uses_primary_for_value(self):
        h = _repo_scan_tech_chip("Framework", "next.js")
        assert _G8_PRIMARY in h

    def test_uses_muted_bg(self):
        h = _repo_scan_tech_chip("X", "Y")
        assert _G8_MUTED_BG in h

    def test_escapes_xss(self):
        h = _repo_scan_tech_chip("<x>", "<script>")
        assert "&lt;script&gt;" in h
        assert "<script>" not in h.replace("&lt;script&gt;", "")


# ---------------------------------------------------------------------- #
# gtm_pill                                                               #
# ---------------------------------------------------------------------- #


class TestGtmPill:
    def test_true_uses_positive(self):
        h = _repo_scan_gtm_pill("Tracking", True)
        assert _G8_POSITIVE_FG in h
        assert "✓" in h

    def test_false_uses_muted(self):
        h = _repo_scan_gtm_pill("Tracking", False)
        assert _G8_TEXT_MUTED in h
        # Marker is em-dash
        assert "—" in h

    def test_escapes_label(self):
        h = _repo_scan_gtm_pill("<bad>", True)
        assert "&lt;bad&gt;" in h


# ---------------------------------------------------------------------- #
# route_chip                                                             #
# ---------------------------------------------------------------------- #


class TestRouteChip:
    def test_renders_method_and_path(self):
        h = _repo_scan_route_chip("GET", "/api/users")
        assert "GET" in h
        assert "/api/users" in h

    def test_uses_primary_for_method(self):
        h = _repo_scan_route_chip("POST", "/x")
        assert _G8_PRIMARY in h

    def test_escapes_xss_in_path(self):
        h = _repo_scan_route_chip("GET", "<script>")
        assert "&lt;script&gt;" in h
        assert "<script>" not in h.replace("&lt;script&gt;", "")


# ---------------------------------------------------------------------- #
# Empty state                                                            #
# ---------------------------------------------------------------------- #


class TestEmptyState:
    def test_unavailable_uses_muted(self):
        h = _render_repo_scan_empty_state_html(REPO_ID, "unavailable")
        assert _G8_TEXT_MUTED in h
        assert "not available" in h.lower()

    def test_no_scan_uses_primary(self):
        h = _render_repo_scan_empty_state_html(REPO_ID, "no_scan")
        assert _G8_PRIMARY in h
        assert "no scan" in h.lower()

    def test_no_scan_mentions_post(self):
        h = _render_repo_scan_empty_state_html(REPO_ID, "no_scan")
        assert f"POST /repos/{REPO_ID}/scan" in h

    def test_unknown_mode_falls_to_unavailable(self):
        h = _render_repo_scan_empty_state_html(REPO_ID, "garbage")
        assert "not available" in h.lower()

    def test_escapes_xss_in_repo_id(self):
        bad_id = "<script>alert(1)</script>"
        h = _render_repo_scan_empty_state_html(bad_id, "no_scan")
        assert "<script>alert(1)</script>" not in h.replace(
            "&lt;script&gt;alert(1)&lt;/script&gt;", ""
        )


# ---------------------------------------------------------------------- #
# render_repo_scan_html                                                  #
# ---------------------------------------------------------------------- #


class TestRenderHtml:
    def test_none_returns_unavailable(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=None)
        assert "not available" in h.lower()

    def test_non_dict_returns_unavailable(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan="garbage")
        assert "not available" in h.lower()

    def test_full_render_has_doctype(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert h.startswith("<!DOCTYPE html>")
        assert "</html>" in h

    def test_4_stat_cards_present(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # 4 stat-card labels
        assert "Framework" in h
        assert "API routes" in h
        assert "Product type" in h
        assert "GTM readiness" in h

    def test_framework_value_in_stat_card(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "next.js" in h

    def test_route_count_in_stat_card(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # 3 routes
        assert ">3<" in h

    def test_product_type_humanized(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # b2b_saas → "b2b saas"
        assert "b2b saas" in h

    def test_gtm_ready_count_3_of_4(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "3/4" in h

    def test_4_gtm_pills_rendered(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert ">Tracking<" in h
        assert ">Forms<" in h
        assert ">Attribution<" in h
        assert ">Identity<" in h

    def test_tech_stack_chips_rendered(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # All present tech-stack values
        for v in ["next.js", "15.0.1", "typescript", "app", "tailwind", "clerk", "postgres", "vercel"]:
            assert v in h

    def test_api_routes_rendered(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "/api/users" in h
        assert "/api/auth/login" in h

    def test_route_methods_rendered(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "GET, POST" in h

    def test_readme_summary_rendered(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "Internal admin dashboard" in h

    def test_readme_omitted_when_absent(self):
        scan_no_readme = {**SAMPLE_SCAN, "readme_summary": None}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=scan_no_readme)
        assert "README summary" not in h

    def test_meta_row_has_scan_id(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert SCAN_ID in h

    def test_meta_row_has_duration(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "12.3s" in h

    def test_meta_row_has_scanned_at(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "2026-04-20 15:30:00" in h

    def test_repo_id_in_header(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert REPO_ID in h

    def test_repo_label_from_repo_dict(self):
        repo = {"repo_name": "my-cool-app"}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN, repo=repo)
        assert "my-cool-app" in h

    def test_repo_label_falls_back_to_id(self):
        h = render_repo_scan_html(repo_id="abc-123", scan=SAMPLE_SCAN)
        assert "Repo abc-123" in h

    def test_drill_up_lists_siblings(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert f"g8://repos/{REPO_ID}/overview" in h
        assert f"g8://repos/{REPO_ID}/install" in h
        assert f"g8://repos/{REPO_ID}/streams" in h
        assert "g8://repos/dashboard" in h

    def test_drill_up_does_NOT_list_self(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # Self-URI should NOT appear inside the drill-up "Manage this repo" card
        # Find the "Manage this repo" card by its h2 marker
        idx = h.find("Manage this repo")
        assert idx != -1
        # Slice from "Manage this repo" to end of card
        card_end = h.find("</div>", idx)
        card_html = h[idx:card_end]
        assert f"g8://repos/{REPO_ID}/scan" not in card_html

    def test_drill_up_lists_post_endpoint(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert f"POST /repos/{REPO_ID}/scan" in h

    def test_xss_escape_on_framework(self):
        bad = {**SAMPLE_SCAN, "tech_stack": {"framework": "<script>alert(1)</script>"}}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "<script>alert(1)</script>" not in h.replace(
            "&lt;script&gt;alert(1)&lt;/script&gt;", ""
        )

    def test_xss_escape_on_route_path(self):
        bad = {**SAMPLE_SCAN, "api_routes": [{"path": "<script>", "methods": ["GET"]}]}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "<script>" not in h.replace("&lt;script&gt;", "")

    def test_xss_escape_on_readme(self):
        bad = {**SAMPLE_SCAN, "readme_summary": "<script>alert(1)</script>"}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "<script>alert(1)</script>" not in h.replace(
            "&lt;script&gt;alert(1)&lt;/script&gt;", ""
        )

    def test_xss_escape_on_repo_id(self):
        bad_id = "<script>"
        h = render_repo_scan_html(repo_id=bad_id, scan=SAMPLE_SCAN)
        assert "<script>" not in h.replace("&lt;script&gt;", "")

    def test_route_overflow_capped(self):
        many_routes = [
            {"path": f"/api/r{i}", "methods": ["GET"]}
            for i in range(_MAX_REPO_SCAN_ROUTES_RENDERED + 5)
        ]
        bad = {**SAMPLE_SCAN, "api_routes": many_routes}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "+ 5 more route" in h

    def test_readme_overflow_clipped(self):
        bad = {**SAMPLE_SCAN, "readme_summary": "x" * (_MAX_REPO_SCAN_README_LEN + 100)}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        # Truncated → ends with ellipsis somewhere in body
        assert "…" in h

    def test_no_tech_stack_shows_friendly_msg(self):
        bad = {**SAMPLE_SCAN, "tech_stack": {}}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "No tech stack detected" in h

    def test_no_routes_shows_friendly_msg(self):
        bad = {**SAMPLE_SCAN, "api_routes": []}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=bad)
        assert "No API routes detected" in h
        # Includes pointer to snippet install
        assert "snippet/install" in h

    def test_no_single_side_accent_borders(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # AI-tell pattern lockout
        assert "border-left:" not in h
        assert "border-right:" not in h
        assert "border-top:" not in h
        assert "border-bottom:" not in h

    def test_no_legacy_accent_hexes(self):
        h = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        legacy_hexes = ["#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"]
        for hex_color in legacy_hexes:
            assert hex_color.lower() not in h.lower()


# ---------------------------------------------------------------------- #
# render_repo_scan_text_fallback                                         #
# ---------------------------------------------------------------------- #


class TestTextFallback:
    def test_none_returns_unavailable(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=None)
        assert "not available" in t.lower()

    def test_non_dict_returns_unavailable(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan="garbage")
        assert "not available" in t.lower()

    def test_unavailable_includes_repo_id(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=None)
        assert REPO_ID in t

    def test_full_render_has_header(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert t.startswith("# ")
        assert "scan report" in t.lower()

    def test_stats_section(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## Stats" in t
        assert "Framework: next.js" in t
        assert "API routes: 3" in t
        assert "Product type: b2b saas" in t
        assert "GTM readiness: 3/4" in t

    def test_tech_stack_section(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## Tech stack" in t
        assert "**Framework:** `next.js`" in t

    def test_gtm_section(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## GTM readiness" in t
        assert "[✓] Tracking" in t
        assert "[—] Attribution" in t

    def test_api_routes_section(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## API routes detected" in t
        assert "/api/users" in t
        assert "GET, POST" in t

    def test_readme_section(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## README summary" in t
        assert "```" in t  # fenced code block
        assert "Internal admin dashboard" in t

    def test_readme_section_omitted_when_absent(self):
        scan_no_readme = {**SAMPLE_SCAN, "readme_summary": None}
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=scan_no_readme)
        assert "## README summary" not in t

    def test_route_overflow_note(self):
        many_routes = [
            {"path": f"/api/r{i}", "methods": ["GET"]}
            for i in range(_MAX_REPO_SCAN_ROUTES_RENDERED + 7)
        ]
        bad = {**SAMPLE_SCAN, "api_routes": many_routes}
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=bad)
        assert "+ 7 more route" in t

    def test_manage_block_present(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert "## Manage this repo" in t
        assert f"g8://repos/{REPO_ID}/overview" in t
        assert f"g8://repos/{REPO_ID}/install" in t
        assert f"g8://repos/{REPO_ID}/streams" in t

    def test_manage_block_does_not_list_self(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        # Self g8://repos/{id}/scan URI should NOT appear in manage block
        # (the POST and GET endpoints are fine — different URIs)
        idx = t.find("## Manage this repo")
        assert idx != -1
        manage_section = t[idx:]
        assert f"g8://repos/{REPO_ID}/scan" not in manage_section

    def test_unavailable_branch_has_manage_block(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=None)
        assert "## Manage this repo" in t

    def test_ends_with_newline(self):
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert t.endswith("\n")

    def test_no_tech_stack_shows_message(self):
        bad = {**SAMPLE_SCAN, "tech_stack": {}}
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=bad)
        assert "No tech stack detected" in t

    def test_no_routes_shows_message(self):
        bad = {**SAMPLE_SCAN, "api_routes": []}
        t = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=bad)
        assert "No API routes detected" in t


# ---------------------------------------------------------------------- #
# Smoke tests                                                            #
# ---------------------------------------------------------------------- #


class TestSmoke:
    def test_realistic_render_html_text_idempotent(self):
        h1 = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        h2 = render_repo_scan_html(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert h1 == h2
        t1 = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        t2 = render_repo_scan_text_fallback(repo_id=REPO_ID, scan=SAMPLE_SCAN)
        assert t1 == t2

    def test_empty_scan_dict_renders_safely(self):
        # Backend returns dict but with no fields populated
        empty_scan = {"id": "x", "repo_id": REPO_ID}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=empty_scan)
        assert h.startswith("<!DOCTYPE html>")
        # Empty scan still renders the GTM card with all-False pills
        assert "0/4" in h

    def test_full_gtm_readiness_renders_positive_accent(self):
        full_gtm = {**SAMPLE_SCAN, "gtm_readiness": {
            "has_tracking": True,
            "has_forms": True,
            "has_attribution": True,
            "has_identity": True,
        }}
        h = render_repo_scan_html(repo_id=REPO_ID, scan=full_gtm)
        # 4/4 → positive accent
        assert "4/4" in h
        assert _G8_POSITIVE_FG in h
