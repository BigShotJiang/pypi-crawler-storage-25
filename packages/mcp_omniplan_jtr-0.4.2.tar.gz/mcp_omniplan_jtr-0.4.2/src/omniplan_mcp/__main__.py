from omniplan_mcp.server import mcp
from omniplan_mcp import tasks, documents, dependencies, resources  # noqa: F401 - registers tools


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
