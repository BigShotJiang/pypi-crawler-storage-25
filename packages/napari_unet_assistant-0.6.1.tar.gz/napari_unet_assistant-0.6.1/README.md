# napari-unet-assistant

`napari-unet-assistant` is a napari plugin for supervised 2D and 3D U-Net segmentation workflows.

It is designed for users who already have image-mask training data and want to pair files, train a U-Net model, run inference, and inspect results directly inside napari.

This plugin is separate from SAM-based annotation workflows. Its focus is conventional supervised U-Net training from existing image-mask pairs.

## What's new in 0.6.1

- Added recursive dataset-folder auto pairing for TIFF datasets with `images`/`masks`, `raw`/`labels`, mixed-folder, and nested layouts.
- Added folder-name role hints so dataset folders can guide image-mask pairing even when filenames are less explicit.
- Added configurable augmentation presets: `none`, `conservative`, `balanced`, and `strong`.
- Added custom augmentation controls for flips, rotation, shear, scale, brightness jitter, and Gaussian noise.
- Added model-capacity options for standard, large, and xlarge U-Net widths.
- Added a model registry with built-in U-Net, MONAI, nnU-Net, and segmentation-models-pytorch backend hooks.
- Added separate model-family, backbone/encoder, and encoder-weight controls for clearer U-Net variant testing.
- Added a Model Sweep tab for running multiple backend, model-family, backbone, weight, and capacity combinations sequentially.
- Added a dedicated nnU-Net pipeline path that exports training pairs, runs nnU-Net v2 CLI training, and imports prediction TIFFs.
- Added early stopping with one learning-rate reduction on validation plateau before stopping after a second plateau.
- Added saving and loading of augmentation settings in run configuration metadata.
- Added a training stop button that cancels after the current batch, discards the interrupted model state, and clears GPU cache when available.
- Added a U-Net architecture preview for the selected 2D/3D mode and output-channel configuration.
- Added short tooltips across the main controls to explain settings in place.
- Improved the training UI layout with clearer tabs and more stable dock-widget sizing.

## Highlights

- TIFF-first 2D and 3D U-Net training
- Binary and multiclass segmentation
- Recursive smart image-mask pairing
- Pair review with confidence, reason, and shape-check status
- Patch-based training with configurable patch size and overlap
- Optional empty-mask patch inclusion
- Configurable augmentation presets and custom augmentation controls
- Standard, large, and xlarge U-Net capacity options
- Optional model backends for MONAI, nnU-Net, and segmentation-models-pytorch
- Model Sweep for batch training and validation comparison across model choices
- 80/20 validation split
- Continue training from a previous run
- Training cancellation from the UI
- Single-image and folder inference
- 2D image and 3D volume prediction
- TIFF prediction export
- napari-based visualization and QC

## Smart image-mask pairing

The plugin can pair training data from:

- a dataset root scanned recursively
- separate image and mask folders
- one mixed folder containing both images and masks
- a manual CSV file

Dataset-root auto scan supports common layouts such as:

- `images/` + `masks/`
- `raw/` + `labels/`
- nested TIFF folders under one dataset root
- one mixed folder containing `sample.tif` + `sample_mask.tif`

Supported naming patterns include:

- `sample.tif` + `sample_mask.tif`
- `sample_1.tif` + `sample_2.tif`
- `sample_image.tif` + `sample_mask.tif`
- `sample_raw.tif` + `sample_label.tif`

After scanning, the plugin shows each proposed pair with confidence, reason, and shape-check status. Ambiguous or invalid pairs are reported instead of being silently used for training.

Folder names such as `images`, `raw`, `masks`, and `labels` can also provide role hints during recursive dataset scans.

## Augmentation

Training supports augmentation presets and custom controls:

- `none`: no augmentation
- `conservative`: flips, small rotations/scales, and light brightness jitter
- `balanced`: stronger rotation/scale, shear, brightness jitter, and light Gaussian noise
- `strong`: wider rotation/scale/shear ranges, stronger brightness jitter, and stronger Gaussian noise
- `custom`: user-selected flips, rotation, shear, scale, brightness, and noise settings

The selected augmentation configuration is saved in each run folder's `config.json` and restored when loading run metadata.

## Training controls

The training panel includes a stop button for cancelling an active training run. Cancellation is checked between batches, so the current batch may finish before the run stops.

When a run is stopped, the interrupted model state is discarded and GPU cache is cleared when available.

The validation tab also includes early stopping controls. When enabled, the plugin monitors validation Dice. If validation Dice does not improve by at least the configured minimum gain for the patience window, the learning rate is reduced once. If validation Dice still does not improve for another patience window after that reduction, training stops early and keeps the best validation-Dice checkpoint. The per-epoch `history.csv` records `learning_rate`, `lr_reduced`, and `early_stopped`.

## Model capacity

Training can use standard, large, or xlarge U-Net widths. For 2D models, these use base channel widths of 32, 64, and 128. Larger models can learn more complex boundaries, but they need more GPU memory and may require a smaller batch size.

## Model backends

The default backend is the built-in U-Net and works without extra model packages. MONAI, segmentation-models-pytorch, and nnU-Net are optional backends, so they must be installed into the same Python environment that runs napari. Prefer `python -m pip` from that environment so the package is installed where napari can import it.

If you install a release of `napari-unet-assistant` that declares the optional extras, you can use:

```bash
python -m pip install napari-unet-assistant[monai]
python -m pip install napari-unet-assistant[smp]
python -m pip install napari-unet-assistant[nnunet]
python -m pip install napari-unet-assistant[models]
```

Use `models` to install all optional model backends at once. If your shell treats square brackets specially, quote the requirement:

```bash
python -m pip install "napari-unet-assistant[models]"
```

If the extras command does not install the backend package, install the backend dependency directly:

```bash
python -m pip install monai
python -m pip install segmentation-models-pytorch
python -m pip install nnunetv2
```

For a development checkout, install the extras from the repository root:

```bash
python -m pip install -e ".[models]"
```

For the GitHub version, put the extras before the `@` URL:

```bash
python -m pip install "napari-unet-assistant[models] @ git+https://github.com/wulinteousa2-hash/napari-unet-assistant.git"
```

You can verify that the optional packages are available with:

```bash
python -c "import monai; import segmentation_models_pytorch; import nnunetv2; print('optional model backends ok')"
```

If this import check fails, napari will still load the built-in U-Net backend, but the missing optional backend will not be usable until its package is installed in the active environment. After installing a backend, restart napari and select it from the `Model backend` dropdown.

The model registry lives under `src/napari_unet_assistant/models/` and separates provider code into `providers/`. MONAI and segmentation-models-pytorch models are regular `torch.nn.Module` backends. nnU-Net uses a dedicated pipeline workflow because nnU-Net manages its own data conversion, planning, preprocessing, training, and prediction commands.

Model selection is split into:

- `Model backend`: implementation source, such as built-in, MONAI, SMP, or nnU-Net
- `Model family`: architecture family, such as U-Net, U-Net++, SegResNet, or DeepLabV3+
- `Backbone / encoder`: feature extractor when the selected family supports one, such as ResNet34, ResNet50, EfficientNet-B0, DenseNet121, or MobileNetV2
- `Encoder weights`: pretrained encoder weights when supported
- `Model capacity`: built-in width preset used by backends that expose width/depth-style capacity

## Model Sweep

Use the `Model Sweep` tab when you want to compare multiple model configurations without starting each run manually. Set the shared training constants first, including data shape, task type, patch settings, augmentation, validation split, epochs, and batch size. Then check the backends and capacities to test, click `Preview model sweep`, and click `Run model sweep`. The regular `Model backend`, `Model family`, and `Backbone / encoder` controls in the `Run` tab are for single training runs; Model Sweep expands checked backends into valid model families, encoders, and encoder weights automatically.

The sweep runs configurations sequentially so one GPU is used predictably. Each completed configuration gets its own run folder with the usual files:

- `config.json`
- `run_summary.txt`
- `validation.json`
- `history.csv`
- `summary.json`
- `best_model.pt`

The sweep folder also writes:

- `sweep_config.json`: shared settings, augmentation, selected configurations, and skipped entries
- `sweep_results.csv`: one summary row per skipped, failed, or completed configuration
- `pairs.csv`: image-mask pairs used by the sweep

The `sweep_results.csv` table includes backend, model family, capacity, encoder, encoder weights, best validation loss, best validation Dice/IoU/F1, run folder, and any error message. Missing optional backend packages are reported as skipped during preview/run. Failed combinations do not stop the sweep; they are recorded and the next configuration runs. The stop button cancels after the current batch or epoch boundary and leaves partial results on disk.

nnU-Net is not trained through Model Sweep because it uses its own data-conversion, planning, training, and prediction pipeline rather than the plugin's direct `torch.nn.Module` training loop. To train nnU-Net, select `nnunet` in the `Run` tab and start a normal training run. The plugin exports the paired TIFF data to a self-contained nnU-Net work folder, runs `nnUNetv2_plan_and_preprocess`, runs `nnUNetv2_train`, and saves `nnunet_workflow.json` so the Inference panel can run `nnUNetv2_predict` and convert predictions back to TIFF.

## Manual CSV pairing

For manual pairing, provide a CSV file with one image-mask pair per row.

Required columns:

- `image_path`
- `mask_path`

Optional column:

- `key`

Example:

```csv
key,image_path,mask_path
sample01,/path/to/images/sample01.tif,/path/to/masks/sample01_mask.tif
sample02,/path/to/images/sample02.tif,/path/to/masks/sample02_mask.tif
```

Use absolute paths for the clearest behavior. Relative paths are interpreted from the current working directory.

Each image and mask should have matching spatial dimensions.

## Installation

```bash
pip install git+https://github.com/wulinteousa2-hash/napari-unet-assistant.git
```

For editable development:

```bash
git clone https://github.com/wulinteousa2-hash/napari-unet-assistant.git
cd napari-unet-assistant
pip install -e .
napari
```

## Basic workflow

1. Open napari.
2. Launch **U-Net Assistant**.
3. Choose a pairing mode.
4. Scan and review image-mask pairs.
5. Set training options.
6. Train a 2D or 3D U-Net model.
7. Load a saved run folder.
8. Run inference on new images or volumes.
9. Review prediction masks in napari.

## Supported data

### 2D training

- image: `(Y, X)` grayscale TIFF
- mask: `(Y, X)` label TIFF
- binary masks: `0 = background`, nonzero = foreground
- multiclass masks: integer labels

### 3D training

- image: `(Z, Y, X)` grayscale TIFF
- mask: `(Z, Y, X)` label TIFF
- multiclass masks should use integer labels:
  - `0 = background`
  - `1 = class 1`
  - `2 = class 2`
  - `3 = class 3`

## Patch options

### 2D

XY patch sizes:

- 64
- 128
- 256
- 512
- 1024

Default: `256 x 256`

### 3D

Z patch sizes:

- 8
- 16
- 32
- 64

XY patch sizes:

- 64
- 128
- 256
- 512
- 1024

Default: `16 x 256 x 256`

## Validation

The current training workflow uses a standard train/validation split. The default validation split is 20%.

K-fold cross-validation is not active in this release.

Each run writes `validation.json` with the active validation mode, split fraction, random seed, total patch count, train patch count, and validation patch count. The training log also reports the same split. Per-epoch validation metrics are written to `history.csv`.

At training start, the log reports the model backend, model family, backbone/encoder, encoder weights, capacity, patch settings, augmentation preset, validation setup, epochs, and batch size. The same user-readable summary is written to `run_summary.txt`, while full structured settings are saved in `config.json`.

## Outputs

Each run folder can contain:

- `best_model.pt`
- `config.json`
- `run_summary.txt`
- `summary.json`
- `history.csv`
- `validation.json`
- `pairs.csv`
- prediction TIFF outputs

## Current scope

This release is focused on TIFF-based supervised U-Net training and inference.

OME-Zarr, spectral/lambda workflows, and SAM-assisted annotation are intentionally outside the scope of this version.

## Reference

This project builds on U-Net-based nerve morphometry workflows described in:

Moiseev D, Hu B, Li J. Morphometric Analysis of Peripheral Myelinated Nerve Fibers through Deep Learning. *Journal of the Peripheral Nervous System*. 2019;24(1):87-93.  
https://pmc.ncbi.nlm.nih.gov/articles/PMC6420354/
