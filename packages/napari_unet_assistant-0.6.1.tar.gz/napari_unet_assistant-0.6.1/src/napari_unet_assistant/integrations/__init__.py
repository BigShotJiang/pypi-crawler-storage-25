"""External training and inference workflow integrations."""
