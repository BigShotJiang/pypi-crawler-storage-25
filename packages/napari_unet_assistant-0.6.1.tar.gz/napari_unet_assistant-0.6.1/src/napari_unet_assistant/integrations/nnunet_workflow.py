from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Callable, Iterable

import numpy as np

from ..io.loaders import ensure_numpy, load_image_any
from ..io.writers import ensure_dir, save_csv_rows, save_json, save_tiff
from ..utils.array_utils import rgb_to_gray_if_needed

LogCallback = Callable[[str], None] | None


def _require_simpleitk():
    try:
        import SimpleITK as sitk
    except Exception as exc:
        raise ImportError(
            "nnU-Net workflow export requires SimpleITK. Install nnU-Net support with: "
            "python -m pip install nnunetv2"
        ) from exc
    return sitk


def _require_nnunet_cli(command: str) -> str:
    exe = shutil.which(command)
    if exe is None:
        raise RuntimeError(
            f"Could not find {command} on PATH. Install nnU-Net v2 in the active napari "
            "environment and restart napari."
        )
    return exe


def _case_id(index: int, key: str | None = None) -> str:
    key = str(key or "").strip()
    cleaned = []
    for ch in key.lower():
        if ch.isalnum():
            cleaned.append(ch)
        elif cleaned and cleaned[-1] != "_":
            cleaned.append("_")
    suffix = "".join(cleaned).strip("_")[:32]
    if suffix:
        return f"case_{index:04d}_{suffix}"
    return f"case_{index:04d}"


def _dataset_name(dataset_id: int) -> str:
    return f"Dataset{int(dataset_id):03d}_NapariUnetAssistant"



def _clear_dir(path: Path) -> Path:
    path = ensure_dir(path)
    for item in path.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()
    return path

def _nnunet_env(work_dir: Path) -> dict[str, str]:
    env = os.environ.copy()
    env["nnUNet_raw"] = str(work_dir / "nnUNet_raw")
    env["nnUNet_preprocessed"] = str(work_dir / "nnUNet_preprocessed")
    env["nnUNet_results"] = str(work_dir / "nnUNet_results")
    return env


def _as_nnunet_image(arr: np.ndarray, mode: str) -> np.ndarray:
    arr = ensure_numpy(arr)
    arr = rgb_to_gray_if_needed(arr)
    if mode == "2d":
        if arr.ndim != 2:
            raise ValueError(f"Expected 2D image for nnU-Net 2D workflow, got shape {arr.shape}")
        arr = arr[None, ...]
    elif arr.ndim != 3:
        raise ValueError(f"Expected 3D image for nnU-Net 3D workflow, got shape {arr.shape}")
    return arr.astype(np.float32, copy=False)


def _as_nnunet_label(arr: np.ndarray, mode: str, task_type: str) -> np.ndarray:
    arr = ensure_numpy(arr)
    if arr.ndim > 2 and arr.shape[-1] in (3, 4):
        arr = arr[..., 0]
    if mode == "2d":
        if arr.ndim != 2:
            raise ValueError(f"Expected 2D mask for nnU-Net 2D workflow, got shape {arr.shape}")
        arr = arr[None, ...]
    elif arr.ndim != 3:
        raise ValueError(f"Expected 3D mask for nnU-Net 3D workflow, got shape {arr.shape}")
    if task_type == "binary":
        arr = (arr > 0).astype(np.uint8)
    else:
        arr = arr.astype(np.uint16, copy=False)
    return arr


def _write_nifti(path: Path, arr: np.ndarray) -> None:
    sitk = _require_simpleitk()
    img = sitk.GetImageFromArray(arr)
    sitk.WriteImage(img, str(path))


def _read_nifti(path: Path, mode: str) -> np.ndarray:
    sitk = _require_simpleitk()
    arr = sitk.GetArrayFromImage(sitk.ReadImage(str(path)))
    if mode == "2d" and arr.ndim == 3 and arr.shape[0] == 1:
        arr = arr[0]
    return arr


def _run_command(cmd: list[str], env: dict[str, str], cwd: Path, log_cb: LogCallback = None) -> None:
    if log_cb is not None:
        log_cb("Running: " + " ".join(cmd))
    proc = subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if log_cb is not None and proc.stdout:
        for line in proc.stdout.splitlines():
            if line.strip():
                log_cb(line)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}")


def prepare_nnunet_training_dataset(
    *,
    pairs: Iterable[dict],
    cfg,
    run_dir: str | Path,
    dataset_id: int,
    log_cb: LogCallback = None,
) -> dict:
    run_dir = ensure_dir(run_dir)
    work_dir = ensure_dir(run_dir / "nnunet_work")
    env = _nnunet_env(work_dir)
    for key in ("nnUNet_raw", "nnUNet_preprocessed", "nnUNet_results"):
        ensure_dir(env[key])

    dataset_dir = ensure_dir(Path(env["nnUNet_raw"]) / _dataset_name(dataset_id))
    images_tr = ensure_dir(dataset_dir / "imagesTr")
    labels_tr = ensure_dir(dataset_dir / "labelsTr")

    rows = []
    labels: dict[str, int] = {"background": 0}
    if cfg.task_type == "binary":
        labels["foreground"] = 1
    else:
        for i in range(1, int(cfg.out_channels)):
            labels[f"class_{i}"] = i

    pairs = list(pairs)
    for idx, pair in enumerate(pairs):
        case = _case_id(idx, pair.get("key"))
        image = _as_nnunet_image(load_image_any(pair["image_path"]), cfg.mode_2d_or_3d)
        mask = _as_nnunet_label(load_image_any(pair["mask_path"]), cfg.mode_2d_or_3d, cfg.task_type)
        if image.shape != mask.shape:
            raise ValueError(
                f"Image/mask shape mismatch for {pair.get('key') or idx}: "
                f"image={image.shape}, mask={mask.shape}"
            )
        _write_nifti(images_tr / f"{case}_0000.nii.gz", image)
        _write_nifti(labels_tr / f"{case}.nii.gz", mask)
        rows.append([case, pair.get("key", ""), pair["image_path"], pair["mask_path"]])
        if log_cb is not None:
            log_cb(f"Exported nnU-Net case: {case}")

    dataset_json = {
        "channel_names": {"0": "image"},
        "labels": labels,
        "numTraining": len(rows),
        "file_ending": ".nii.gz",
    }
    (dataset_dir / "dataset.json").write_text(json.dumps(dataset_json, indent=2), encoding="utf-8")
    save_csv_rows(run_dir / "nnunet_cases.csv", ["case", "key", "image_path", "mask_path"], rows)

    return {
        "dataset_id": int(dataset_id),
        "dataset_name": _dataset_name(dataset_id),
        "dataset_dir": str(dataset_dir),
        "work_dir": str(work_dir),
        "env": {k: env[k] for k in ("nnUNet_raw", "nnUNet_preprocessed", "nnUNet_results")},
        "num_training": len(rows),
    }


def run_nnunet_training_pipeline(
    *,
    pairs: Iterable[dict],
    cfg,
    run_dir: str | Path,
    dataset_id: int,
    configuration: str = "2d",
    fold: str = "0",
    trainer: str | None = None,
    log_cb: LogCallback = None,
) -> dict:
    plan_exe = _require_nnunet_cli("nnUNetv2_plan_and_preprocess")
    train_exe = _require_nnunet_cli("nnUNetv2_train")
    meta = prepare_nnunet_training_dataset(
        pairs=pairs,
        cfg=cfg,
        run_dir=run_dir,
        dataset_id=dataset_id,
        log_cb=log_cb,
    )
    work_dir = Path(meta["work_dir"])
    env = os.environ.copy()
    env.update(meta["env"])

    _run_command(
        [plan_exe, "-d", str(dataset_id), "--verify_dataset_integrity"],
        env=env,
        cwd=work_dir,
        log_cb=log_cb,
    )
    train_cmd = [train_exe, str(dataset_id), configuration, str(fold)]
    if trainer:
        train_cmd.extend(["-tr", trainer])
    _run_command(train_cmd, env=env, cwd=work_dir, log_cb=log_cb)

    result = {
        **meta,
        "configuration": configuration,
        "fold": str(fold),
        "trainer": trainer or "nnUNetTrainer",
        "status": "complete",
    }
    save_json(Path(run_dir) / "nnunet_workflow.json", result)
    save_json(Path(run_dir) / "summary.json", result)
    return result


def prepare_nnunet_prediction_inputs(
    *,
    cfg: dict,
    input_paths: list[str | Path],
    output_dir: str | Path,
) -> tuple[Path, dict[str, str]]:
    output_dir = ensure_dir(output_dir)
    images_ts = _clear_dir(output_dir / "nnunet_imagesTs")
    mapping: dict[str, str] = {}
    mode = cfg["mode_2d_or_3d"]
    for idx, path in enumerate(input_paths):
        path = Path(path)
        case = _case_id(idx, path.stem)
        image = _as_nnunet_image(load_image_any(path), mode)
        _write_nifti(images_ts / f"{case}_0000.nii.gz", image)
        mapping[case] = str(path)
    save_json(output_dir / "nnunet_prediction_inputs.json", mapping)
    return images_ts, mapping


def run_nnunet_prediction_pipeline(
    *,
    run_dir: str | Path,
    cfg: dict,
    input_paths: list[str | Path],
    output_dir: str | Path,
    overwrite: bool = False,
    log_cb: LogCallback = None,
) -> list[dict]:
    predict_exe = _require_nnunet_cli("nnUNetv2_predict")
    run_dir = Path(run_dir)
    output_dir = ensure_dir(output_dir)
    workflow = json.loads((run_dir / "nnunet_workflow.json").read_text(encoding="utf-8"))
    images_ts, mapping = prepare_nnunet_prediction_inputs(cfg=cfg, input_paths=input_paths, output_dir=output_dir)
    pred_nii_dir = _clear_dir(output_dir / "nnunet_predictions_nii")
    env = os.environ.copy()
    env.update(workflow["env"])
    cmd = [
        predict_exe,
        "-i", str(images_ts),
        "-o", str(pred_nii_dir),
        "-d", str(workflow["dataset_id"]),
        "-c", workflow.get("configuration", "2d"),
        "-f", str(workflow.get("fold", "0")),
    ]
    _run_command(cmd, env=env, cwd=Path(workflow["work_dir"]), log_cb=log_cb)

    report = []
    mode = cfg["mode_2d_or_3d"]
    for case, input_path in mapping.items():
        nii_path = pred_nii_dir / f"{case}.nii.gz"
        out_path = output_dir / f"{Path(input_path).stem}_pred.tif"
        if out_path.exists() and not overwrite:
            report.append({"input": input_path, "output": str(out_path), "status": "skipped_exists", "strategy": "nnunet"})
            continue
        pred = _read_nifti(nii_path, mode).astype(np.uint16, copy=False)
        save_tiff(out_path, pred)
        report.append({"input": input_path, "output": str(out_path), "status": "ok", "strategy": "nnunet"})
    return report
