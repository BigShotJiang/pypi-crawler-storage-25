from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class RunConfig:
    mode_2d_or_3d: str
    task_type: str               # "binary" or "multiclass"
    model_backend: str
    model_name: str
    in_channels: int
    out_channels: int
    model_base: int
    model_params: dict
    patch_xy: int
    patch_z: int | None
    overlap_percent: int
    include_empty_mask: bool
    batch_size: int
    epochs: int
    learning_rate: float
    val_mode: str                # "split" or "kfold"
    val_split: float
    k_folds: int
    use_gpu: bool
    image_dir: str
    mask_dir: str
    output_dir: str
    early_stopping: bool = True
    early_stopping_patience: int = 5
    early_stopping_min_delta: float = 0.0001
    lr_reduce_on_plateau: bool = True
    lr_reduce_factor: float = 0.5

    def to_dict(self) -> dict:
        return asdict(self)
