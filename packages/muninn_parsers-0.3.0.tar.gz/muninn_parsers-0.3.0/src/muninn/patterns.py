"""Common regex patterns shared across parsers.

This module provides reusable regex building blocks for parsing network
device CLI output.  Each pattern is exposed as a plain string constant
(for embedding inside larger expressions) **and** as a pre-compiled
``re.Pattern`` (for direct matching).

Naming convention::

    FOO     – raw pattern string, e.g. IPV4_ADDRESS
    FOO_RE  – compiled re.compile object, e.g. IPV4_ADDRESS_RE
"""

import re

# ---------------------------------------------------------------------------
# IPv4
# ---------------------------------------------------------------------------

# Matches a dotted-decimal IPv4 address (no prefix-length).
IPV4_ADDRESS = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"

# Matches an IPv4 CIDR prefix, e.g. 10.0.0.0/24.
IPV4_PREFIX = IPV4_ADDRESS + r"/\d{1,2}"

IPV4_ADDRESS_RE = re.compile(IPV4_ADDRESS)
IPV4_PREFIX_RE = re.compile(IPV4_PREFIX)

# ---------------------------------------------------------------------------
# MAC address  (Cisco dotted notation: aaaa.bbbb.cccc)
# ---------------------------------------------------------------------------

# Matches a Cisco-style dotted MAC address, e.g. 0012.7fff.04d7.
MAC_ADDRESS = r"[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}"

# Matches a colon-delimited MAC address, e.g. 00:50:56:ff:ba:6f.
MAC_ADDRESS_COLON = r"[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}"

MAC_ADDRESS_RE = re.compile(MAC_ADDRESS)
MAC_ADDRESS_COLON_RE = re.compile(MAC_ADDRESS_COLON)

# ---------------------------------------------------------------------------
# Table / section separator lines
# ---------------------------------------------------------------------------

# Line consisting entirely of three or more dashes.
SEPARATOR_DASH = r"^-{3,}$"

# Line consisting only of dashes and whitespace (columnar table divider).
SEPARATOR_DASH_SPACE = r"^[-\s]+$"

SEPARATOR_DASH_RE = re.compile(SEPARATOR_DASH, re.MULTILINE)
SEPARATOR_DASH_SPACE_RE = re.compile(SEPARATOR_DASH_SPACE, re.MULTILINE)
