"""Arista EOS parsers."""
