"""Nokia SR OS parsers."""
