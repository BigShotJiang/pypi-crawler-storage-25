# Tribulnation Bittrade SDK

> An SDK to connect Bittrade with the Tribulnation ecosystem.

🚧 Under construction.