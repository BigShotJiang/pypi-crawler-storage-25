"""
### Tribulnation Bittrade
> An SDK to connect Bittrade with the Tribulnation ecosystem.

- Details
"""