#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _wait_worker_quiet(manager, rounds=80, delay_sec=0.02):
    for _ in range(int(max(1, rounds))):
        thread = getattr(manager, '_worker_thread', None)
        if thread is None or not thread.is_alive():
            return
        time.sleep(delay_sec)


class TestSupportSendQueuePolicy(unittest.TestCase):

    def test_dedup_key_includes_anchor_context_and_issue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy(dedup_ttl_sec=60)
        key = policy.dedup_key({
            'send_type': 'run_evidence',
            'anchor_run_id': 'a1',
            'context_run_id': 'c1',
            'issue_code': 'x1',
            'source_scope_hash': 'h1',
        })
        self.assertEqual(key, 'run_evidence|a1|c1|x1|h1')


class TestSupportSendJobManager(unittest.TestCase):

    def test_enqueue_accepts_even_if_legacy_async_env_is_off(self):
        """MEDICAFE_SUPPORT_SEND_ASYNC is obsolete; queue is always used for supported types."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_ASYNC': '0',
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-legacy',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                self.assertNotEqual(str(res.get('policy_decision', '')), 'sync_fallback')
                _wait_worker_quiet(mgr)

    def test_background_job_logger_receives_progress_heartbeat(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((event_name, dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)

                def _execute(_job, progress_callback):
                    progress_callback('creating zip bundle')
                    return True, 'sent', {}

                mgr._execute_send = _execute
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-heartbeat|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)

        names = [name for name, _details in events]
        self.assertIn('job_accepted', names)
        self.assertIn('job_started', names)
        self.assertIn('job_progress', names)
        self.assertIn('job_finished', names)
        progress = [details for name, details in events if name == 'job_progress'][0]
        self.assertEqual(progress.get('progress_stage'), 'creating zip bundle')
        self.assertEqual(progress.get('installed_version'), '1.1.0')
        self.assertEqual(progress.get('recommendation_action_kind'), 'send_bundle')
        self.assertTrue(progress.get('heartbeat_at_utc'))
    def test_enqueue_records_post_update_autofollow_tags(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-post-update|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('source'), 'post_update_cloud_autofollow')
                self.assertEqual(job.get('installed_version'), '1.1.0')
                self.assertEqual(job.get('recommendation_action_kind'), 'send_bundle')
                _wait_worker_quiet(mgr)
    def test_recover_requeues_running_post_update_job_after_launcher_restart(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager, _utc_now
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-recover|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                job = mgr._build_job_record(req, 'started', 'started_immediately')
                job['status'] = 'running'
                job['progress_stage'] = 'sending email to support'
                job['heartbeat_at_utc'] = _utc_now()
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job.get('job_id')}, handle)
                with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                    result = mgr.recover_jobs_after_launcher_restart(
                        source='post_update_cloud_autofollow',
                        installed_version='1.1.0')
                recovered = result.get('recovered_job_ids', [])
                self.assertIn(job.get('job_id'), recovered)
                recovered_job = mgr._read_job(job.get('job_id'))
                self.assertEqual(recovered_job.get('status'), 'queued')
                self.assertEqual(recovered_job.get('policy_reason'), 'running_job_recovered_after_launcher_restart')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                queue_state = mgr._read_queue_state()
                self.assertIn(job.get('job_id'), queue_state.get('queued_job_ids', []))
                ensure_worker.assert_called_once_with()
    def test_enqueue_deduplicates_recent_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                # Give worker a brief moment to persist running/terminal state.
                time.sleep(0.05)
                second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                _wait_worker_quiet(mgr)

    def test_blocked_job_is_requeued_when_single_flight_busy(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                # Simulate post-dequeue state where picked job id was removed.
                mgr._write_queue_state([])
                mgr._acquire_single_flight = lambda _job_id: False
                mgr._run_single_job(job)
                refreshed = mgr._read_job(job_id)
                queue_state = mgr._read_queue_state()
                self.assertEqual(str(refreshed.get('status', '')), 'blocked')
                self.assertIn(job_id, queue_state.get('queued_job_ids', []))

    def test_retry_preserves_source_scope_hash_for_dedup_key(self):
        from MediCafe.support_send_jobs import SupportSendJobManager, SupportSendQueuePolicy
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')
                first_job = mgr._read_job(first_job_id)
                first_job['created_epoch'] = float(time.time()) - 3600.0
                mgr._write_job(first_job)

                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                retried_id = str(retried.get('job_id', '') or '')
                self.assertTrue(retried_id and retried_id != first_job_id)
                retried_job = mgr._read_job(retried_id)
                self.assertEqual(str(retried_job.get('source_scope_hash', '') or ''), 'scope-1')
                expected = SupportSendQueuePolicy().dedup_key({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                })
                self.assertEqual(str(retried_job.get('dedup_key', '') or ''), expected)
                _wait_worker_quiet(mgr)

    def test_cancel_queued_job_removes_from_queue_and_sets_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                res = mgr.cancel_job_if_possible(job_id, reason='test_cancel')
                self.assertTrue(res.get('ok'))
                self.assertEqual(str(res.get('policy_reason')), 'canceled_queued')
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'canceled')
                self.assertTrue(refreshed.get('suppress_restart_recovery'))
                queue_state = mgr._read_queue_state()
                self.assertNotIn(job_id, queue_state.get('queued_job_ids', []))

    def test_cancel_running_job_returns_running_not_cancelable(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'running'
            mgr._write_job(job)
            res = mgr.cancel_job_if_possible(job_id, reason='x')
            self.assertFalse(res.get('ok'))
            self.assertEqual(str(res.get('policy_reason')), 'running_not_cancelable')

    def test_run_single_job_skips_when_job_file_marked_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            mgr._write_job(job)
            calls = []

            def _track(_j, _cb):
                calls.append(1)
                return (True, 'ok', {})

            mgr._execute_send = _track
            mgr._run_single_job({'job_id': job_id})
            self.assertEqual(calls, [])

    def test_recover_skips_jobs_with_suppress_restart_recovery(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            job['suppress_restart_recovery'] = True
            mgr._write_job(job)
            mgr._write_queue_state([])
            recovery = mgr.recover_jobs_after_launcher_restart()
            self.assertEqual(recovery.get('recovered_job_ids', []), [])
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', []), [])


class TestFrozenRecommendationRunEvidence(unittest.TestCase):

    def test_run_evidence_send_skips_recompute_when_frozen_recommendation_provided(self):
        from MediCafe import cloud_readiness_recommendations as rec_mod
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            triage_path = os.path.join(reports_dir, 'artifact_triage_pack_test.txt')
            index_path = os.path.join(reports_dir, 'run_artifact_index_test.txt')
            bundle_path = os.path.join(reports_dir, 'support_bundle_test.zip')
            for p in (triage_path, index_path, bundle_path):
                with open(p, 'w') as h:
                    h.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab_root,
                'reports_dir': reports_dir,
                'run_id': '20260410-011341-b73de336',
                'artifact_files': [],
                'context_files': [],
            }
            frozen = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': '20260410-011341-b73de336',
                'action_preview': {'anchor_run_id': '20260410-011341-b73de336'},
            }
            with patch.object(rec_mod, 'collect_support_bundle', return_value=bundle_path, create=True), \
                    patch.object(rec_mod, 'submit_support_bundle_email', return_value=True, create=True), \
                    patch.object(rec_mod, '_build_run_artifact_snapshot', return_value=(True, '', snapshot), create=True), \
                    patch.object(rec_mod, '_artifact_bundle_quality', return_value={
                        'score': 100, 'label': 'GREEN', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'ready'
                    }, create=True), \
                    patch.object(rec_mod, '_write_artifact_triage_pack', return_value=triage_path, create=True), \
                    patch.object(rec_mod, '_write_run_artifact_index', return_value=index_path, create=True), \
                    patch.object(rec_mod, 'open_report_delivery_status', return_value=(False, '', ''), create=True), \
                    patch.object(rec_mod, '_collect_run_evidence_context_attachment', return_value=('', {}), create=True), \
                    patch.object(rec_mod, '_phase_d_dat_smoke_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(rec_mod, '_review_dat_qa_full_block_forced_attachment_paths', return_value=[], create=True), \
                    patch.object(rec_mod, '_phase_d_reprocess_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(rec_mod, '_latest_interrupt_report_paths', return_value=[], create=True), \
                    patch.object(rec_mod, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {}), create=True), \
                    patch.object(rec_mod, 'compute_operator_support_send_recommendation_core') as mock_compute:
                ok, msg, data = rec_mod.send_latest_run_evidence_bundle(
                    repo,
                    frozen_recommendation=frozen,
                )
            mock_compute.assert_not_called()
            self.assertTrue(isinstance(ok, bool))
            self.assertTrue(isinstance(msg, str))
