from __future__ import print_function

import io
import os
import sys
import unittest
from datetime import datetime

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class MediBotFinancialColumnsTests(unittest.TestCase):
    def test_medibot_ui_table_includes_it_code_and_rem_amt(self):
        from MediBot import MediBot_UI

        patient_info = [
            (datetime(2026, 1, 2), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]

        fake_payload = {
            'it_code_display': '12',
            'remaining_amount_display': '$ 250.00'
        }

        with patch('MediBot.MediBot_UI.get_patient_financial_display', return_value=fake_payload):
            stream = io.StringIO()
            old_stdout = sys.stdout
            try:
                sys.stdout = stream
                MediBot_UI.display_enhanced_patient_table(
                    patient_info,
                    'Test Table',
                    show_line_numbers=True,
                    config={}
                )
            finally:
                sys.stdout = old_stdout

        output = stream.getvalue()
        self.assertIn('IT Code', output)
        self.assertIn('Rem Amt', output)
        self.assertIn('12', output)
        self.assertIn('$ 250.00', output)

    def test_notepad_table_includes_it_code_and_rem_amt(self):
        from MediBot import MediBot_Notepad_Utils

        patient_info = [
            (datetime(2026, 1, 2), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]
        fake_payload = {
            'it_code_display': 'CI',
            'remaining_amount_display': '$ 100.00'
        }

        with patch('MediBot.MediBot_Notepad_Utils.get_patient_financial_display', return_value=fake_payload):
            content = MediBot_Notepad_Utils.format_patient_table_for_notepad(
                patient_info,
                'Notepad Test',
                config={}
            )

        self.assertIn('IT Code', content)
        self.assertIn('Rem Amt', content)
        self.assertIn('CI', content)
        self.assertIn('$ 100.00', content)


if __name__ == '__main__':
    unittest.main()
