# -*- coding: utf-8 -*-
"""Tests for MediCafe.json_io (pytest; dev Python 3.11+)."""
from __future__ import print_function

import json
import io
import logging
import os
import sys
import threading
import time

import pytest

_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from MediCafe import json_io  # noqa: E402


def test_write_json_atomic_roundtrip(tmp_path):
    p = str(tmp_path / 'cfg.json')
    payload = {'a': 1, 'b': [2, 3]}
    assert json_io.write_json_atomic(
        p, payload, 'test', 'pytest', indent=2, lock=False, ensure_ascii=True
    )
    with open(p, 'r', encoding='utf-8') as handle:
        got = json.load(handle)
    assert got == payload


def test_write_preserves_original_on_failed_promote(tmp_path, monkeypatch):
    dest = str(tmp_path / 'out.json')
    original = {'keep': True}
    with open(dest, 'w', encoding='utf-8') as handle:
        json.dump(original, handle)

    calls = {'n': 0}

    def boom_rename(src, dst):
        calls['n'] += 1
        raise OSError(13, 'permission denied')

    monkeypatch.setattr(os, 'rename', boom_rename)
    if hasattr(os, 'replace'):
        def boom_replace(src, dst):
            calls['n'] += 1
            raise OSError(13, 'permission denied')

        monkeypatch.setattr(os, 'replace', boom_replace)

    ok = json_io.write_json_atomic(
        dest, {'new': 'data'}, 'test', 'pytest', lock=False, ensure_ascii=True
    )
    assert ok is False
    with open(dest, 'r', encoding='utf-8') as handle:
        disk = json.load(handle)
    assert disk == original
    temps = [f for f in os.listdir(tmp_path) if 'tmp' in f and f.endswith('.json')]
    assert not temps


def test_lock_blocks_second_writer(tmp_path):
    path = str(tmp_path / 'x.json')
    lock_path = path + '.lock'
    results = []

    def first():
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, b'{"pid":999999,"created_at":0}')
        os.close(fd)
        time.sleep(0.3)
        try:
            os.remove(lock_path)
        except OSError:
            pass

    def second():
        ok = json_io.write_json_atomic(path, {'v': 2}, 't', 'w2', lock=True, ensure_ascii=True)
        results.append(ok)

    t1 = threading.Thread(target=first)
    t2 = threading.Thread(target=second)
    t1.start()
    time.sleep(0.05)
    t2.start()
    t1.join(timeout=5)
    t2.join(timeout=5)
    assert results == [True]
    assert os.path.isfile(path)


def test_stale_lock_removed(tmp_path):
    path = str(tmp_path / 'y.json')
    lock_path = path + '.lock'
    old = time.time() - 700
    with open(lock_path, 'w') as handle:
        handle.write('{"pid":999999,"created_at":%s}' % old)
    os.utime(lock_path, (old, old))
    assert json_io.write_json_atomic(path, {'ok': True}, 't', 'w', lock=True, ensure_ascii=True)
    assert not os.path.exists(lock_path)


def test_append_jsonl_and_rotate(tmp_path):
    jl = str(tmp_path / 'ev.jsonl')
    assert json_io.append_jsonl(jl, {'x': 1}, 'a', 'w', lock=False)
    assert json_io.append_jsonl(jl, {'x': 2}, 'a', 'w', lock=False)
    assert json_io.rotate_jsonl_tail(jl, 1, 'a', 'w')
    lines = open(jl, 'r', encoding='utf-8').read().strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])['x'] == 2


def test_update_json_uses_atomic(tmp_path, monkeypatch):
    cfg = str(tmp_path / 'config.json')
    with open(cfg, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old'}, handle)

    calls = []
    real_write = json_io.write_json_atomic

    def fake_atomic(path, payload, artifact, writer, **kwargs):
        calls.append((artifact, writer, path))
        kw = dict(kwargs)
        kw['lock'] = False
        return real_write(path, payload, artifact, writer, **kw)

    monkeypatch.setattr('MediCafe.json_io.write_json_atomic', fake_atomic)
    import importlib

    import MediBot.update_json as update_json_mod

    importlib.reload(update_json_mod)

    update_json_mod.update_csv_path(cfg, str(tmp_path / 'new.csv'))
    assert calls and calls[0][0] == 'config_local' and calls[0][1] == 'update_json'
    local_sidecar = tmp_path / 'config.local.json'
    with open(str(local_sidecar), 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    assert 'new.csv' in str(data.get('CSV_FILE_PATH', ''))


def test_bootstrap_sidecars_dry_run_and_apply(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    report_path = tmp_path / 'bootstrap-report.json'

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old.csv', 'MediLink_Config': {'local_storage_path': 'store'}}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}}, handle)

    dry_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=False, report_path=str(report_path))
    assert '$/CSV_FILE_PATH' in dry_report['moved']['config']
    assert '$/optum_payer_list' in dry_report['moved']['crosswalk']
    assert not (tmp_path / 'config.local.json').exists()

    apply_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True, report_path=str(report_path))
    assert (tmp_path / 'config.local.json').exists()
    assert (tmp_path / 'crosswalk.state.json').exists()
    assert apply_report['backups']

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        config_disk = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        crosswalk_disk = json.load(handle)
    assert 'CSV_FILE_PATH' not in config_disk
    assert 'optum_payer_list' not in crosswalk_disk

    second_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True, report_path=str(report_path))
    assert (tmp_path / 'config.local.json').exists()
    assert (tmp_path / 'crosswalk.state.json').exists()

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        config_disk_second = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        crosswalk_disk_second = json.load(handle)
    assert config_disk_second == config_disk
    assert crosswalk_disk_second == crosswalk_disk
    assert second_report['backups']


def test_bootstrap_sidecars_backups_are_rollback_viable(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    original_config = {'CSV_FILE_PATH': 'orig.csv', 'MediLink_Config': {'local_storage_path': 'store'}}
    original_crosswalk = {'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}}

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump(original_config, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump(original_crosswalk, handle)

    report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True)
    assert report['backups']

    backup_map = {}
    for path in report['backups']:
        if 'config.json.sidecar-bootstrap.' in path:
            backup_map['config'] = path
        if 'crosswalk.json.sidecar-bootstrap.' in path:
            backup_map['crosswalk'] = path
    assert os.path.exists(backup_map['config'])
    assert os.path.exists(backup_map['crosswalk'])

    with open(backup_map['config'], 'r', encoding='utf-8') as handle:
        assert json.load(handle) == original_config
    with open(backup_map['crosswalk'], 'r', encoding='utf-8') as handle:
        assert json.load(handle) == original_crosswalk


def test_save_crosswalk_drops_state_owned_subtrees(tmp_path, monkeypatch):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    loader.clear_config_cache()
    loader.load_configuration(config_path, crosswalk_path)
    config = {'MediLink_Config': {'endpoints': {}, 'crosswalkPath': crosswalk_path}}
    crosswalk = {
        'payer_id': {'12345': {'endpoint': 'AVAILITY', 'medisoft_id': [], 'medisoft_medicare_id': []}},
        'optum_payer_list': {'metadata': {'last_update': 'today'}, 'payers': {'87726': {'search_claim': True}}},
    }
    assert crosswalk_utils.save_crosswalk(None, config, crosswalk, skip_api_operations=True) is True

    with open(crosswalk_path, 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert 'optum_payer_list' not in saved


def test_write_crosswalk_state_optum_writes_crosswalk_state_sidecar(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    payload = {'metadata': {'last_update': 'today'}, 'payers': {'87726': {'search_claim': True}}}
    ok, written_path = sidecar.write_crosswalk_state_optum(
        config_path,
        crosswalk_path,
        payload,
        writer='pytest',
    )

    assert ok is True
    assert written_path.endswith('crosswalk.state.json')
    with open(written_path, 'r', encoding='utf-8') as handle:
        state_doc = json.load(handle)
    assert state_doc['__sidecar__']['artifact'] == 'crosswalk_state'
    assert state_doc['optum_payer_list'] == payload


def test_save_crosswalk_state_optum_writes_optum_payload_to_sidecar(tmp_path):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    loader.clear_config_cache()
    loader.load_configuration(config_path, crosswalk_path)
    config = {'MediLink_Config': {'endpoints': {}, 'crosswalkPath': crosswalk_path}}
    crosswalk = {
        'payer_id': {},
        'optum_payer_list': {
            'metadata': {'last_update': 'today'},
            'payers': {'87726': {'search_claim': True}},
        },
    }

    ok, state_path = crosswalk_utils.save_crosswalk_state_optum(config, crosswalk)

    assert ok is True
    assert state_path.endswith('crosswalk.state.json')
    with open(state_path, 'r', encoding='utf-8') as handle:
        state_doc = json.load(handle)
    assert state_doc['optum_payer_list'] == crosswalk['optum_payer_list']


def test_client_secret_update_writes_endpoint_secret_to_config_local_sidecar(tmp_path):
    from MediBot import client_secret_update
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'endpoints': {}}}, handle)

    endpoint_payload = {
        'client_id': 'abc123',
        'client_secret': 'secret-value',
        'client_secret_last_updated': '2026-04-16T12:00:00',
    }

    ok, error = client_secret_update.save_endpoint_secret(config_path, 'AVAILITY', endpoint_payload)

    assert ok is True
    assert error is None
    sidecar_path = tmp_path / 'config.local.json'
    assert sidecar_path.exists()
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert saved['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'secret-value'

    loader.clear_config_cache()
    loaded_config, _ = loader.load_configuration(
        config_path=str(config_path),
        crosswalk_path=str(tmp_path / 'crosswalk.json'),
    )
    assert loaded_config['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'secret-value'


def test_update_certificate_provider_config_writes_config_local_sidecar(tmp_path):
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)

    success, error = loader.update_certificate_provider_config(
        {'mode': 'managed_ca', 'enabled': True},
        config_path=config_path,
    )

    assert success is True
    assert error is None
    sidecar_path = tmp_path / 'config.local.json'
    assert sidecar_path.exists()
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert saved['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    assert saved['MediLink_Config']['certificate_provider']['enabled'] is True

    loader.clear_config_cache()
    loaded_config, _ = loader.load_configuration(
        config_path=str(config_path),
        crosswalk_path=str(tmp_path / 'crosswalk.json'),
    )
    assert loaded_config['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    assert loaded_config['MediLink_Config']['certificate_provider']['enabled'] is True


def test_preflight_json_io_passes_with_writable_dirs(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)
    assert fails == []


def test_preflight_detects_readonly_file(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    os.chmod(config_path, 0o444)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    try:
        fails = json_io.collect_json_io_preflight_failures(ctx)
        assert any('r+ probe' in f for f in fails)
    finally:
        os.chmod(config_path, 0o644)


def test_telemetry_probe_candidates_readonly_does_not_call_queue_resolver(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    called = {'resolve_queue_dir': False}
    sentinel = os.path.join(str(tmp_path), 'created_by_resolver')

    def creating_resolver(medi):
        called['resolve_queue_dir'] = True
        os.makedirs(sentinel)
        return os.path.join(sentinel, 'reports_queue')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)

    candidates = json_io._telemetry_probe_candidates_readonly(
        os.path.join(str(tmp_path), 'config.json'),
        local_storage,
    )

    assert called['resolve_queue_dir'] is False
    assert os.path.join(local_storage, 'telemetry') in candidates
    assert not os.path.exists(sentinel)


def test_preflight_does_not_create_optional_telemetry_dirs(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    def creating_resolver(medi):
        os.makedirs(os.path.join(str(tmp_path), 'reports_queue_created'))
        return os.path.join(str(tmp_path), 'reports_queue_created')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)

    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': local_storage}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)

    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': local_storage,
        'source_folder': local_storage,
        'target_folder': local_storage,
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)

    assert fails == []
    assert not os.path.exists(os.path.join(local_storage, 'telemetry'))
    assert not os.path.exists(os.path.join(str(tmp_path), 'reports_queue_created'))


def test_json_io_event_reaches_root_logger():
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)

        json_io._emit_json_io_event({'phase': 'success', 'artifact': 'test', 'writer': 'pytest'})
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    assert 'JSON_IO_EVENT' in logged
    assert '"phase": "success"' in logged


def test_probe_directory_io_detects_replace_existing_failure(tmp_path, monkeypatch):
    real_replace = os.replace

    def fail_probe_replace(src, dst):
        if '.medicafe_json_io_probe.' in str(dst):
            raise OSError(17, 'file exists')
        return real_replace(src, dst)

    monkeypatch.setattr(os, 'replace', fail_probe_replace)
    result = json_io.probe_directory_io(str(tmp_path), 'pytest_replace_probe')

    assert result['ok'] is False
    assert result['phase'] == 'dir_probe_replace_existing'
    assert result.get('errno') == 17
    assert 'diagnostics' in result


def test_json_io_diagnostic_reaches_root_logger(tmp_path):
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)

        json_io._emit_failure_diagnostics(
            str(tmp_path / 'config.json'),
            'config',
            'pytest',
            'promote_failed',
            exc=OSError(17, 'file exists'),
        )
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    assert 'JSON_IO_DIAGNOSTIC' in logged
    assert 'promote_failed' in logged
    assert 'path_diagnostics' in logged


def test_collect_path_diagnostics_reports_readonly_file(tmp_path):
    path = str(tmp_path / 'readonly.json')
    with open(path, 'w') as handle:
        handle.write('{}')
    os.chmod(path, 0o444)
    try:
        diag = json_io.collect_path_diagnostics(path)
        assert diag.get('target_readonly') is True
        assert diag.get('target_readonly_summary') == 'read-only or not writable'
    finally:
        os.chmod(path, 0o644)
