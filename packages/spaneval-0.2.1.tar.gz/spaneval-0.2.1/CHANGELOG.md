# Changelog

## 0.1.0 (2026-03-07)

- Initial release.
