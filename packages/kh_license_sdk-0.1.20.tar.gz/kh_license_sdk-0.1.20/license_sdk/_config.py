"""Runtime configuration for the licence SDK (agent side)."""
import os

PROXY_URL = os.environ.get("MYCOMPANY_LICENCE_SERVER", "https://license-server.example.com")
CACHE_DIR = os.environ.get("MYCOMPANY_CACHE_DIR", os.path.expanduser("~/.mycompany/licence_cache"))
PINNED_ROOT_PUBLIC_KEY_PEM = os.environ.get("MYCOMPANY_ROOT_PUBLIC_KEY", "")
SERVER_URL = os.environ.get("MYCOMPANY_SERVER_URL", PROXY_URL)
