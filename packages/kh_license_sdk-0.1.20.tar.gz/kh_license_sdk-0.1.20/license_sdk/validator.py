from __future__ import annotations
import glob
import os
import site
import sys
from pathlib import Path

from license_sdk.jwt_utils import verify_jwt, JwtVerificationError
from license_sdk.key_manager import KeyManager
from license_sdk.models import LicencePayload
from license_sdk.temporal import get_reference_time


class LicenceError(Exception):
    """Raised when a licence check fails. Message is shown to the developer."""


def check_licence(
    package_name: str,
    site_packages_path: str | None = None,
    cache_dir: str | None = None,
    pinned_root_public_key_pem: str | None = None,
    environment: str | None = None,
    _mock_key_info: dict | None = ...,  # test injection only
) -> LicencePayload:
    """Validate the LICENCE.jwt for package_name and return its payload.

    Called by both the import hook (layer 1) and by each protected
    package's own __init__.py (layer 2 — defence in depth).

    Args:
        package_name: Top-level package name (e.g. "mypackage").
        site_packages_path: Override site-packages discovery (tests).
        cache_dir: Override cache directory (tests).
        pinned_root_public_key_pem: Override pinned root key (tests).
        environment: Expected runtime environment (e.g. "prod"). When
            provided, validated against the JWT's environment field.
        _mock_key_info: Inject a fake KeyInfo for unit testing.
            Use `...` (default) for normal operation (no mock injection).
            Use `None` to simulate no key available.
            Use a dict to inject a specific key.

    Returns:
        LicencePayload with validated JWT claims.

    Raises:
        LicenceError: With a developer-friendly English message.
    """
    from license_sdk import _config  # lazy import avoids circular deps
    _cache_dir = cache_dir or _config.CACHE_DIR
    _root_pem = pinned_root_public_key_pem or _config.PINNED_ROOT_PUBLIC_KEY_PEM
    if not _root_pem:
        raise LicenceError(
            "[MyCompany] Root public key not configured.\n"
            "  Set the MYCOMPANY_ROOT_PUBLIC_KEY environment variable."
        )

    jwt_path = _find_licence_jwt(package_name, site_packages_path)
    if jwt_path is None:
        raise LicenceError(
            f"[MyCompany] No licence found for '{package_name}'.\n"
            f"  Install via the licensed PyPI proxy: {_config.PROXY_URL}/pypi/"
        )

    try:
        manager = KeyManager(cache_dir=_cache_dir, pinned_root_public_key_pem=_root_pem)
    except ValueError as e:
        raise LicenceError(
            f"[MyCompany] Root public key is invalid: {e}\n"
            "  Check the MYCOMPANY_ROOT_PUBLIC_KEY environment variable."
        ) from e

    if _mock_key_info is not ...:
        if _mock_key_info is not None:
            manager._cache_key(_mock_key_info)
    # In production: manager.refresh_if_needed() is called by the hook before check_licence()

    public_key_pem = manager.get_current_public_key_pem()
    if public_key_pem is None:
        raise LicenceError(
            f"[MyCompany] No public key available to verify '{package_name}'.\n"
            f"  Connect to the network and retry, or renew at {_config.PROXY_URL}/portal/"
        )

    token = Path(jwt_path).read_text().strip()

    # Compute server_time_offset from the injected/cached key if available
    server_time_offset = None
    if manager._cached_key and "server_time" in manager._cached_key:
        import time as _time
        server_time_offset = manager._cached_key["server_time"] - int(_time.time())

    reference_time = get_reference_time(server_time_offset=server_time_offset)

    try:
        payload = verify_jwt(token, public_key_pem, reference_time=reference_time)
    except JwtVerificationError as e:
        msg = str(e)
        if "expired" in msg:
            raise LicenceError(
                f"[MyCompany] Licence expired for '{package_name}'.\n"
                f"  Renew at {_config.PROXY_URL}/portal/"
            ) from e
        raise LicenceError(
            f"[MyCompany] Licence verification failed for '{package_name}': {e}"
        ) from e

    if environment is not None and payload.environment != environment:
        raise LicenceError(
            f"[MyCompany] '{package_name}' is licensed for '{payload.environment}', "
            f"detected environment: '{environment}'."
        )

    return payload


def _find_licence_jwt(package_name: str, site_packages_override: str | None) -> str | None:
    """Find the LICENCE.jwt file for package_name in site-packages."""
    if site_packages_override:
        search_roots = [site_packages_override]
    else:
        try:
            search_roots = site.getsitepackages()
        except AttributeError:
            search_roots = [p for p in sys.path if "site-packages" in p or "dist-packages" in p]
    for root in search_roots:
        pattern = os.path.join(root, f"{package_name}-*.dist-info", "LICENCE.jwt")
        matches = glob.glob(pattern)
        if matches:
            return sorted(matches)[-1]
    return None
