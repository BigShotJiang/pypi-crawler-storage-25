from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, field_validator

VALID_ENVIRONMENTS = {"dev", "staging", "prod"}
VALID_LICENCE_TYPES = {"monthly", "annual", "per_seat", "per_env", "per_package", "bundle", "trial"}


class LicencePayload(BaseModel):
    """JWT payload embedded in the LICENCE.jwt file inside a wheel."""
    kid: str
    iss: str
    sub: str
    iat: int
    exp: int
    licence_id: str
    package: str
    version: str
    environment: str
    seats: int
    licence_type: str

    @field_validator("environment")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        if v not in VALID_ENVIRONMENTS:
            raise ValueError(f"environment must be one of {VALID_ENVIRONMENTS}, got '{v}'")
        return v

    @field_validator("licence_type")
    @classmethod
    def validate_licence_type(cls, v: str) -> str:
        if v not in VALID_LICENCE_TYPES:
            raise ValueError(f"licence_type must be one of {VALID_LICENCE_TYPES}, got '{v}'")
        return v


class KeyInfo(BaseModel):
    """Response from GET /api/v1/keys/current"""
    kid: str
    public_key_pem: str
    root_signature: str
    server_time: int
    expires_at: int


class AuditEvent(BaseModel):
    """Single import event buffered by the agent."""
    ts: int
    package: str
    version: str
    licence_id: str
    result: Literal["ok", "expired", "revoked", "clock_skew", "missing"]
    time_source: Literal["ntp", "server_offset", "local"]
