"""license-sdk: shared JWT and licence validation logic."""
