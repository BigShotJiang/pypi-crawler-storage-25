from __future__ import annotations

from jose import jwt, JWTError
from license_sdk.models import LicencePayload
import time as _time


class JwtVerificationError(Exception):
    """Raised when a LICENCE.jwt cannot be verified."""


def sign_jwt(payload: dict, private_key_pem: str) -> str:
    """Sign a payload dict as a JWT using RS256."""
    return jwt.encode(payload, private_key_pem, algorithm="RS256")


def verify_jwt(token: str, public_key_pem: str, reference_time: int | None = None) -> LicencePayload:
    """Verify a JWT and return its payload as a LicencePayload.

    Args:
        token: The JWT string.
        public_key_pem: PEM-encoded RSA public key.
        reference_time: Unix timestamp for expiry check (NTP-validated time).
            If None, uses int(time.time()). Pass get_reference_time() for NTP checks.

    Raises:
        JwtVerificationError: On expired token, bad signature, or invalid payload.
    """
    if reference_time is None:
        reference_time = int(_time.time())

    try:
        raw = jwt.decode(token, public_key_pem, algorithms=["RS256"],
                         options={"verify_exp": False})
    except JWTError as e:
        raise JwtVerificationError(f"JWT signature verification failed: {e}") from e

    exp = raw.get("exp", 0)
    if exp < reference_time:
        raise JwtVerificationError(
            f"JWT expired (exp={exp}, reference_time={reference_time})"
        )

    try:
        return LicencePayload(**raw)
    except Exception as e:
        raise JwtVerificationError(f"Invalid JWT payload: {e}") from e
