from __future__ import annotations
import base64
import binascii
import json
import os
import re
import time
from pathlib import Path
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from cryptography.exceptions import InvalidSignature


class RootKeyVerificationError(Exception):
    """Raised when a signing key's root signature is invalid."""


class KeyManager:
    """Manages public key caching and root key pinning for the licence agent.

    The root public key is pinned at agent build time and used to verify
    every signing key received from the server. This prevents MITM attacks
    on the key refresh endpoint.
    """

    def __init__(self, cache_dir: str, pinned_root_public_key_pem: str):
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        key = serialization.load_pem_public_key(pinned_root_public_key_pem.encode())
        if not isinstance(key, RSAPublicKey) or key.key_size != 4096:
            raise ValueError(
                f"Pinned root key must be RSA-4096; got {type(key).__name__} "
                f"{getattr(key, 'key_size', '?')} bits"
            )
        self._root_public_key = key
        self._cached_key: dict | None = self._load_cached_key()

    def _verify_root_signature(self, public_key_pem: str, root_signature_b64: str) -> None:
        """Verify that the signing key was signed by the root key.

        Raises:
            RootKeyVerificationError: If signature is invalid or cannot be decoded.
        """
        try:
            sig_bytes = base64.b64decode(root_signature_b64)
        except (binascii.Error, ValueError) as e:
            raise RootKeyVerificationError("Cannot decode root signature") from e

        try:
            self._root_public_key.verify(
                sig_bytes,
                public_key_pem.encode(),
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
        except InvalidSignature as e:
            raise RootKeyVerificationError(
                "Signing key rejected: root signature mismatch"
            ) from e

    def _cache_key(self, key_info: dict) -> None:
        """Cache a verified key info dict to disk after verifying root signature."""
        self._verify_root_signature(
            key_info["public_key_pem"], key_info["root_signature"]
        )
        if "server_time" not in key_info:
            raise ValueError("key_info is missing required field: server_time")
        safe_kid = re.sub(r"[^a-zA-Z0-9_\-]", "_", key_info["kid"])
        cache_file = self._cache_dir / f"key_{safe_kid}.json"
        cache_file.write_text(json.dumps(key_info))
        # Update last_refresh with server_time_offset
        local_now = int(time.time())
        offset = key_info["server_time"] - local_now
        refresh_file = self._cache_dir / "last_refresh.json"
        refresh_file.write_text(json.dumps({
            "kid": key_info["kid"],
            "cached_at": local_now,
            "server_time_offset": offset,
        }))
        self._cached_key = key_info

    def _load_cached_key(self) -> dict | None:
        try:
            refresh = json.loads((self._cache_dir / "last_refresh.json").read_text())
            key_file = self._cache_dir / f"key_{refresh['kid']}.json"
            return json.loads(key_file.read_text())
        except (FileNotFoundError, KeyError, json.JSONDecodeError):
            return None

    def get_current_public_key_pem(self) -> str | None:
        """Return the cached public key PEM, or None if no valid key is cached."""
        if self._cached_key is None:
            return None
        return self._cached_key["public_key_pem"]

    def is_refresh_needed(self, max_age_days: int = 6) -> bool:
        """Return True if the cached key is older than max_age_days."""
        try:
            refresh = json.loads((self._cache_dir / "last_refresh.json").read_text())
            age = time.time() - refresh["cached_at"]
            return age > max_age_days * 86400
        except (FileNotFoundError, KeyError, json.JSONDecodeError):
            return True
