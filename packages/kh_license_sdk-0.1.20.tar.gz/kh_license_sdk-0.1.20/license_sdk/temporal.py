from __future__ import annotations
import time
import warnings
import ntplib

NTP_SERVER = "pool.ntp.org"
NTP_TIMEOUT = 2.0
CLOCK_SKEW_THRESHOLD = 300  # 5 minutes in seconds


class ClockSkewWarning(UserWarning):
    """Emitted when system clock appears to be behind the reference time."""


def get_reference_time(server_time_offset: int | None = None) -> int:
    """Return the most reliable unix timestamp available.

    Always returns max(local, ntp, estimated_server) to prevent
    backward clock manipulation attacks on JWT expiry checks.

    Args:
        server_time_offset: If provided, overrides the cached offset.
            Pass None to load from cache automatically.

    Returns:
        Unix timestamp (integer seconds).
    """
    local_now = int(time.time())
    candidates: list[int] = [local_now]

    ntp_time = _query_ntp(NTP_SERVER, timeout=NTP_TIMEOUT)
    if ntp_time is not None:
        candidates.append(ntp_time)

    offset = server_time_offset if server_time_offset is not None else _load_server_time_offset()
    if offset is not None:
        candidates.append(local_now + offset)

    reference = max(candidates)

    if reference - local_now > CLOCK_SKEW_THRESHOLD:
        warnings.warn(
            f"[MyCompany] System clock appears to be set in the past. "
            f"Local: {local_now}, Reference: {reference} "
            f"(delta: {reference - local_now}s). Using reference time.",
            ClockSkewWarning,
            stacklevel=2,
        )

    return reference


def _query_ntp(server: str, timeout: float = NTP_TIMEOUT) -> int | None:
    """Query an NTP server. Returns unix timestamp or None on failure."""
    try:
        client = ntplib.NTPClient()
        response = client.request(server, version=3, timeout=timeout)
        return int(response.tx_time)
    except Exception:
        return None


def _load_server_time_offset() -> int | None:
    """Load cached server time offset from disk (written by key_manager after refresh)."""
    import json
    import os
    cache_path = os.path.expanduser("~/.mycompany/licence_cache/last_refresh.json")
    try:
        with open(cache_path) as f:
            data = json.load(f)
        return int(data.get("server_time_offset", 0)) or None
    except (FileNotFoundError, KeyError, ValueError, json.JSONDecodeError):
        return None
