from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict


class SearchHybridConfig(TypedDict, total=False):
    enabled: bool
    fusion_mode: str
    rrf_k: int
    dense_weight: float
    sparse_weight: float
    metadata_sparse_enabled: bool


class SearchRerankConfig(TypedDict, total=False):
    enabled: bool
    top_k: int


class SearchReturnConfig(TypedDict, total=False):
    include_text: bool
    include_scores: bool
    include_provenance: bool


class MetadataFilter(TypedDict, total=False):
    """A single metadata filter predicate."""

    key: str
    op: str  # ==, !=, >, >=, <, <=, in, not_in, contains, text_match
    value: Any


class MetadataFilters(TypedDict, total=False):
    """Structured metadata filters with logical condition."""

    filters: list[MetadataFilter]
    condition: str  # "and" or "or"


class SearchGenerationConfig(TypedDict, total=False):
    model: str
    thinking_budget: int | None
    temperature: float
    max_tokens: int
    context_top_k: int


class SearchOptions(TypedDict, total=False):
    query: str
    top_k: int
    filters: dict[str, Any] | MetadataFilters
    hybrid: SearchHybridConfig
    rerank: SearchRerankConfig
    return_config: SearchReturnConfig


class SearchGenerateOptions(TypedDict, total=False):
    query: str
    top_k: int
    filters: dict[str, Any] | MetadataFilters
    hybrid: SearchHybridConfig
    rerank: SearchRerankConfig
    return_config: SearchReturnConfig
    generation: SearchGenerationConfig


class SearchBatchOptions(TypedDict, total=False):
    queries: list[str]
    top_k: int
    filters: dict[str, Any] | MetadataFilters
    hybrid: SearchHybridConfig
    rerank: SearchRerankConfig
    return_config: SearchReturnConfig


class SearchResult(TypedDict, total=False):
    chunk_id: str
    id: str  # Alias for chunk_id (both are returned for backwards compat)
    score: float | None
    raw_score: float | None
    text: str | None
    custom_metadata: dict | None
    system_metadata: dict | None
    offset_start: int | None
    offset_end: int | None
    page_start: int | None
    page_end: int | None


class SearchColdStartMeta(TypedDict, total=False):
    likely: bool
    dense_cache_hit: bool | None
    sparse_cache_hit: bool | None


class SearchMeta(TypedDict, total=False):
    cold_start: SearchColdStartMeta | None
    warnings: list[str] | None


class SearchResponse(TypedDict, total=False):
    results: list[SearchResult]
    meta: SearchMeta


class SearchBatchResponse(TypedDict, total=False):
    responses: list[SearchResponse]


class SearchGenerateResponse(TypedDict, total=False):
    answer: str
    model: str
    thinking_budget: int | None
    results: list[SearchResult]
    meta: SearchMeta
    used_sources: list[str]
