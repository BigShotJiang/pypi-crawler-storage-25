from __future__ import annotations

from typing import Any, TypedDict


class ValidationIssue(TypedDict, total=False):
    """A single validation warning or error from dry-run or apply."""

    severity: str
    code: str
    message: str
    path: str | None


class PipelineSpecResponse(TypedDict, total=False):
    """A single pipeline spec record."""

    id: str
    org_id: str
    project_id: str
    name: str
    description: str | None
    topology: dict[str, Any]
    status: str
    has_draft: bool
    parent_pipeline_spec_id: str | None
    created_by: str | None
    bound_entity_count: int
    binding_summary: dict[str, Any]
    created_at: str
    updated_at: str


class PipelineSpecListResponse(TypedDict):
    """Paginated list of pipeline specs."""

    pipeline_specs: list[PipelineSpecResponse]
    total: int
    limit: int
    offset: int


class DryRunResult(TypedDict, total=False):
    """Result of a pipeline spec dry run (validation preview)."""

    valid: bool
    issues: list[ValidationIssue]
    would_create_agents: int
    would_create_feeds: int
    would_create_corpora: int
    would_bind_existing: int


class ApplyResult(TypedDict, total=False):
    """Result of applying a pipeline spec."""

    success: bool
    created_agent_ids: list[str]
    created_feed_ids: list[str]
    created_corpus_ids: list[str]
    created_subscription_ids: list[str]
    bound_entity_ids: list[str]
    issues: list[ValidationIssue]


class SkippedEntity(TypedDict, total=False):
    """Entity skipped during cascade archive."""

    entity_type: str
    entity_id: str
    entity_name: str
    reason: str
    other_pipeline_ids: list[str]


class ArchiveResult(TypedDict, total=False):
    """Result of archiving a pipeline spec with cascade."""

    pipeline_spec: PipelineSpecResponse
    archived_agents: list[str]
    archived_feeds: list[str]
    deactivated_subscriptions: list[str]
    skipped_entities: list[SkippedEntity]


class DraftActivateResult(TypedDict, total=False):
    """Result of activating a pipeline spec draft (incremental apply)."""

    success: bool
    created_agent_ids: list[str]
    created_feed_ids: list[str]
    created_corpus_ids: list[str]
    created_subscription_ids: list[str]
    removed_binding_ids: list[str]
    updated_entity_ids: list[str]
    issues: list[ValidationIssue]


class FieldDiff(TypedDict, total=False):
    """Single field-level difference between spec and actual entity state."""

    field: str
    spec_value: str | None
    actual_value: str | None


class EntityDiff(TypedDict, total=False):
    """Drift status and field diffs for a single bound entity."""

    entity_type: str
    entity_id: str
    entity_name: str
    drift_status: str
    field_diffs: list[FieldDiff]


class DriftSummary(TypedDict, total=False):
    """Summary counts for a drift report."""

    total_entities: int
    in_sync: int
    drifted: int
    missing: int
    untracked: int


class DriftReport(TypedDict, total=False):
    """Full drift report comparing pipeline spec topology vs actual entity state."""

    pipeline_spec_id: str
    status: str
    entity_diffs: list[EntityDiff]
    summary: DriftSummary


class RefreshChanges(TypedDict, total=False):
    """Summary of changes made during a pipeline spec refresh."""

    updated_entities: list[str]
    removed_entities: list[str]
    unchanged_entities: list[str]


class RefreshResult(TypedDict, total=False):
    """Result of refreshing a pipeline spec from current entity state."""

    draft_id: str
    changes: RefreshChanges


class GraphNode(TypedDict, total=False):
    """A single node in the pipeline graph representation."""

    id: str
    type: str
    label: str
    metadata: dict[str, Any]
    status: str | None
    binding_role: str | None


class GraphEdge(TypedDict, total=False):
    """A single edge in the pipeline graph representation."""

    source: str
    target: str
    type: str
    metadata: dict[str, Any]


class GraphResponse(TypedDict, total=False):
    """Full graph representation of a pipeline spec topology."""

    pipeline_spec_id: str
    status: str
    nodes: list[GraphNode]
    edges: list[GraphEdge]
