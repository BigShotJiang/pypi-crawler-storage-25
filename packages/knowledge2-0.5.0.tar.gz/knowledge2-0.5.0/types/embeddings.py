from __future__ import annotations

from typing import List, TypedDict


class EmbeddingItem(TypedDict):
    embedding: list[float]
    index: int


class EmbeddingsResponse(TypedDict):
    data: list[EmbeddingItem]
    model: str


class EmbeddingModelInfo(TypedDict):
    model_name: str
    is_default: bool


class EmbeddingModelListResponse(TypedDict):
    models: list[EmbeddingModelInfo]
