from __future__ import annotations

from typing import Any, NotRequired, TypedDict


class IndexBuildResponse(TypedDict):
    job_id: str
    index_ids: list[str]
    idempotent_replay: NotRequired[bool]


class IndexStatusResponse(TypedDict, total=False):
    build_set_id: str | None
    requested_mode: str | None
    effective_mode: str | None
    start_change_seq_exclusive: int | None
    end_change_seq_inclusive: int | None
    retrieval_status: str | None
    retrieval_reason: str | None
    document_count: int | None
    dense_status: str | None
    sparse_status: str | None
    sparse_metadata_status: str | None
    dense_reason: str | None
    sparse_reason: str | None
    sparse_metadata_reason: str | None


class IndexCompactResponse(TypedDict, total=False):
    archived: Any
    keep: int


class IndexOptimizeResponse(TypedDict):
    job_id: str
    job_type: str
