from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict


class CorpusResponse(TypedDict, total=False):
    id: str
    project_id: str
    name: str
    description: str | None
    is_tutorial: bool
    is_demo: bool
    created_at: str | None
    org_name: str | None
    project_name: str | None
    chunking_config: dict[str, Any] | None


class CorpusListResponse(TypedDict):
    corpora: list[CorpusResponse]
    total: int


class CorpusDeleteResponse(TypedDict, total=False):
    message: str
    counts: dict[str, int]


class CorpusStatusResponse(TypedDict, total=False):
    status: str
    search_status: str
    retrieval_ready: bool
    retrieval_status: str | None
    ingesting: bool
    indexing: bool
    document_count: int
    documents_processing: int
    documents_failed: int
    documents_failed_ratio: float
    dense_status: str | None
    sparse_status: str | None
