from __future__ import annotations

from typing import Any, TypedDict


class SourceAgentInfo(TypedDict, total=False):
    """Source agent reference in an agent response."""

    agent_id: str
    agent_name: str
    mode: str


class ToolConfigResponse(TypedDict, total=False):
    """Webhook tool configuration (secret masked in responses)."""

    webhook_url: str
    webhook_secret: str | None
    webhook_retries: int | None


class AgentResponse(TypedDict, total=False):
    """A single knowledge agent record."""

    id: str
    org_id: str
    project_id: str | None
    name: str
    slug: str
    description: str | None
    corpus_id: str | None
    task_type: str
    instructions: str | None
    model: str
    status: str
    parent_agent_id: str | None
    source_agents: list[SourceAgentInfo]
    tool_config: ToolConfigResponse | None
    declared_schema: dict[str, Any] | None
    harvest_policy: str
    created_at: str | None
    updated_at: str | None


class AgentListResponse(TypedDict):
    """Paginated list of agents."""

    agents: list[AgentResponse]
    total: int
    limit: int
    offset: int


class AgentChatResponse(TypedDict, total=False):
    """Response from chatting with an agent."""

    answer: str
    model: str
    results: list[dict[str, Any]]
    used_sources: list[str]
    meta: dict[str, Any] | None


class AgentModelInfo(TypedDict, total=False):
    """Information about an available agent model."""

    id: str
    name: str
    provider: str
    default: bool


class AgentModelsResponse(TypedDict):
    """List of available models for knowledge agents."""

    models: list[AgentModelInfo]


class TaskTypeInfo(TypedDict, total=False):
    """Information about an available agent task type."""

    id: str
    name: str
    description: str
    output_schema: str | None
    supports_chat: bool


class AgentTaskTypesResponse(TypedDict):
    """List of available agent task types."""

    task_types: list[TaskTypeInfo]


class Provenance(TypedDict, total=False):
    """Execution provenance in the envelope metadata."""

    run_id: str | None
    agent_id: str
    agent_name: str
    agent_version: str
    task_type: str
    model: str
    input_chunk_ids: list[str]
    reference_corpus_id: str | None
    reference_chunk_ids: list[str]
    source_agents: list[dict[str, Any]]
    execution_time_ms: int
    envelope_version: int


class EnvelopeFields(TypedDict, total=False):
    """Fields section of the agent output envelope."""

    declared: dict[str, Any]
    inferred: dict[str, Any]


class EnvelopeMetadata(TypedDict, total=False):
    """Metadata section of the agent output envelope."""

    declared: dict[str, Any]
    inferred: dict[str, Any]
    provenance: Provenance


class AgentRunEnvelope(TypedDict, total=False):
    """Typed envelope for agent task output.

    The envelope is the structured output of ``execute_agent_task``.
    ``content`` is the primary payload; ``fields`` and ``metadata``
    carry declared/inferred structured data and execution provenance.
    """

    content: str
    fields: EnvelopeFields
    metadata: EnvelopeMetadata


class AgentRunResponse(TypedDict):
    """Response from triggering an agent task run."""

    job_id: str
    status: str


class AgentRunListItem(TypedDict, total=False):
    """A single agent task run in the runs list."""

    job_id: str
    status: str
    created_at: str
    completed_at: str | None
    result: AgentRunEnvelope | dict[str, Any] | None
    error_message: str | None


class AgentRunListResponse(TypedDict):
    """Paginated list of agent task runs."""

    runs: list[AgentRunListItem]
    total: int


class SubscriptionResponse(TypedDict, total=False):
    """A feed subscription for an agent."""

    id: str
    agent_id: str
    feed_id: str
    feed_name: str | None
    feed_activation_status: str | None
    role: str
    created_at: str


class SubscriptionListResponse(TypedDict):
    """List of feed subscriptions for an agent."""

    subscriptions: list[SubscriptionResponse]
