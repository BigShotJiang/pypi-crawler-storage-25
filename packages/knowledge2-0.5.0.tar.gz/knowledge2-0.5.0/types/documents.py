from __future__ import annotations

from typing import Literal, NotRequired, TypedDict


class ChunkingConfig(TypedDict, total=False):
    """Chunking configuration for document ingestion.

    All fields are optional. Unset fields inherit from corpus defaults or
    application-owned defaults in the worker.
    """

    # Top-level chunking strategy
    strategy: Literal["fixed", "paragraph", "semantic", "semchunk", "unstructured", "docling"]
    # Unstructured sub-strategy (only used when strategy="unstructured")
    chunking_strategy: Literal["basic", "by_title", "by_page", "by_similarity"]
    # Max characters per chunk
    chunk_size: int
    # Overlap between chunks (characters)
    overlap: int
    # Combine small sections under N chars (by_title specific)
    combine_text_under_n_chars: int
    # Allow sections to span pages
    multipage_sections: bool
    # Soft limit before hard max (new_after_n_chars)
    new_after_n_chars: int
    # Concurrent Unstructured API requests
    max_concurrent_requests: int
    # API timeout in milliseconds
    timeout: int
    # Near-duplicate handling for chunk insertion
    dedup_mode: Literal["off", "minhash"]
    dedup_partition_keys: list[str]

    # Docling-specific fields (only used when strategy="docling")
    docling_chunker_type: Literal["hybrid", "hierarchical"]
    docling_tokenizer_model: str
    docling_max_tokens: int
    docling_merge_peers: bool
    docling_merge_list_items: bool
    docling_processing_mode: Literal["auto", "sequential", "batch"]
    docling_accelerator: Literal["auto", "cuda", "cpu"]


class DocumentCreateResponse(TypedDict):
    id: str
    job_id: str
    idempotent_replay: NotRequired[bool]
    message: NotRequired[str]


class DocumentBatchItem(TypedDict, total=False):
    source_uri: str | None
    raw_text: str
    metadata: dict | None


class DocumentUrlItem(TypedDict, total=False):
    url: str
    title: str | None
    tags: list[str] | None
    metadata: dict | None


class DocumentUrlIngestResponse(TypedDict):
    job_id: str
    submitted: int
    idempotent_replay: NotRequired[bool]


class DocumentManifestIngestResponse(TypedDict):
    job_id: str
    idempotent_replay: NotRequired[bool]


class DocumentListItem(TypedDict, total=False):
    id: str
    corpus_id: str
    source_uri: str
    custom_metadata: dict
    system_metadata: dict
    created_at: str | None
    status: str | None
    size_bytes: int | None
    content_type: str | None
    preview: str | None


class DocumentListResponse(TypedDict):
    documents: list[DocumentListItem]
    total: int


class DocumentDetailResponse(DocumentListItem):
    pass


class DocumentDeleteResponse(TypedDict, total=False):
    message: str
    reindex_job_id: str | None


class BatchItemError(TypedDict, total=False):
    index: int
    error: str


class DocumentBatchUploadResponse(TypedDict):
    """Response for multipart batch file upload."""

    job_id: str
    doc_ids: list[str]
    count: int
    idempotent_replay: NotRequired[bool]
    errors: NotRequired[list[BatchItemError]]


class DocumentUploadFormat(TypedDict):
    key: str
    label: str
    extensions: list[str]


class DocumentUploadCapabilitiesResponse(TypedDict):
    advertised_formats: list[DocumentUploadFormat]
