from __future__ import annotations

from typing import Any, TypedDict


class ProjectResponse(TypedDict, total=False):
    id: str
    name: str
    org_id: str
    status: str
    archived_at: str | None


class ProjectDeleteResponse(TypedDict, total=False):
    message: str
    counts: dict[str, int]


class ProjectListResponse(TypedDict):
    projects: list[ProjectResponse]
    total: int


class ProjectArchiveResult(TypedDict, total=False):
    """Result of archiving a project."""

    archived_agents: int
    archived_feeds: int
    archived_pipelines: int


class ProjectRestoreResult(TypedDict, total=False):
    """Result of restoring (unarchiving) a project."""

    restored_agents: int
    restored_feeds: int
    restored_pipelines: int


class ProjectDeletionRequest(TypedDict, total=False):
    """Result of requesting deletion for an archived project."""

    deletion_request_id: str
    confirmation_code: str | None
    expires_at: str


class ProjectDeletionConfirmation(TypedDict, total=False):
    """Result of confirming deletion of an archived project."""

    project_id: str
    message: str
