from __future__ import annotations

from typing import TypedDict


class GenerationModelItem(TypedDict, total=False):
    id: str
    name: str
    provider: str
    default: bool


class GenerationModelsListResponse(TypedDict):
    models: list[GenerationModelItem]
