"""Raw HTTP response wrapper for the Knowledge2 SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class RawResponse(Generic[T]):
    """Typed wrapper exposing HTTP-level details alongside the parsed body.

    Returned by ``client.with_raw_response.<method>(...)``.

    Attributes:
        status_code: HTTP status code (e.g. 200, 201).
        headers: Response headers as a plain dict.
        parsed: The same typed result the normal method would return.
    """

    status_code: int
    headers: dict[str, str]
    parsed: T
