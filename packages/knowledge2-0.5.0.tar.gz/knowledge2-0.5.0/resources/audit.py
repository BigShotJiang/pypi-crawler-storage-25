"""Audit-log resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._paging import Page, SyncPager
from sdk._request_options import RequestOptions
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import AuditLogActionsResponse


class AuditMixin(RequesterMixin):
    def list_audit_logs(
        self,
        *,
        corpus_id: str | None = None,
        project_id: str | None = None,
        action: str | None = None,
        entity_type: str | None = None,
        since: str | None = None,
        until: str | None = None,
        user_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List audit log entries with optional filters.

        Args:
            corpus_id: Filter logs to a specific corpus.
            project_id: Filter logs to a specific project.
            action: Filter logs by action type.
            entity_type: Filter logs by entity type.
            since: Filter logs created on or after this ISO 8601 timestamp.
            until: Filter logs created before this ISO 8601 timestamp.
            user_id: Filter logs by the acting user.
            limit: Maximum number of entries to return per page.
            offset: Number of entries to skip for pagination.

        Returns:
            A Page containing audit log entries with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if corpus_id:
            params["corpus_id"] = corpus_id
        if project_id:
            params["project_id"] = project_id
        if action:
            params["action"] = action
        if entity_type:
            params["entity_type"] = entity_type
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if user_id:
            params["user_id"] = user_id
        return self._list_page(
            "GET",
            "/v1/audit-logs",
            items_key="logs",
            params=params or None,
            limit=limit,
            offset=offset,
        )

    def iter_audit_logs(
        self,
        *,
        corpus_id: str | None = None,
        project_id: str | None = None,
        action: str | None = None,
        entity_type: str | None = None,
        since: str | None = None,
        until: str | None = None,
        user_id: str | None = None,
        limit: int = 100,
        request_options: RequestOptions | None = None,
    ) -> SyncPager[dict[str, Any]]:
        """Iterate over audit logs, automatically paginating.

        Args:
            corpus_id: Filter logs to a specific corpus.
            project_id: Filter logs to a specific project.
            action: Filter logs by action type.
            entity_type: Filter logs by entity type.
            since: Filter logs created on or after this ISO 8601 timestamp.
            until: Filter logs created before this ISO 8601 timestamp.
            user_id: Filter logs by the acting user.
            limit: Page size used for each underlying API request.

        Yields:
            Individual audit log entry dicts.

        Raises:
            Knowledge2Error: If any underlying API request fails.
        """
        params: dict[str, Any] = {}
        if corpus_id:
            params["corpus_id"] = corpus_id
        if project_id:
            params["project_id"] = project_id
        if action:
            params["action"] = action
        if entity_type:
            params["entity_type"] = entity_type
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if user_id:
            params["user_id"] = user_id
        return self._paginate(
            "GET", "/v1/audit-logs", items_key="logs", params=params or None, limit=limit
        )

    def list_audit_actions(
        self,
        *,
        user_id: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> AuditLogActionsResponse:
        """List distinct audit action types that have occurred in the organization.

        Args:
            user_id: Filter actions to those performed by a specific user.

        Returns:
            An object containing the list of distinct action type strings.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        data = self._request(
            "GET", "/v1/audit-logs/actions", params=params or None, request_options=request_options
        )
        return self._maybe_validate(data, "AuditLogActionsResponse")
