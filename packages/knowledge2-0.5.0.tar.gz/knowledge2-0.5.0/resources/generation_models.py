"""Generation model resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from sdk._request_options import RequestOptions
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import GenerationModelsListResponse


class GenerationModelsMixin(RequesterMixin):
    def list_generation_models(
        self,
        *,
        request_options: RequestOptions | None = None,
    ) -> GenerationModelsListResponse:
        """List available generation models.

        Returns:
            A response containing the available generation models.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        data = self._request(
            "GET",
            "/v1/models/generation",
            request_options=request_options,
        )
        return self._maybe_validate(data, "GenerationModelsListResponse")
