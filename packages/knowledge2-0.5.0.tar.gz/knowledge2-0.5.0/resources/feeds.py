"""Feed resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._paging import Page
from sdk._preview import preview_resource
from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.resources._mixin_base import RequesterMixin


@preview_resource
class FeedsMixin(RequesterMixin):
    def create_feed(
        self,
        *,
        project_id: str,
        name: str,
        source_agent_id: str,
        persistent: bool = False,
        target_corpus: dict[str, Any] | None = None,
        reactive: bool = False,
        execution_mode: str = "retrieve",
        schedule_interval: str | None = None,
        schedule_hour: int | None = None,
        start_from: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Create a new knowledge feed.

        Args:
            project_id: ID of the project that will own the feed.
            name: Human-readable name for the feed.
            source_agent_id: ID of the source agent for the feed.
            persistent: Whether the feed persists results to storage.
            target_corpus: Optional target corpus configuration dict. Pass
                ``{"existing": "<corpus-id>"}`` to write into an existing corpus,
                or ``{"create_new": True}`` to have the API create a new one.
            reactive: Whether the feed triggers on new data automatically.
            execution_mode: Execution mode for the feed (defaults to
                ``"retrieve"``).
            schedule_interval: Optional cron-style schedule interval.
            schedule_hour: UTC hour (0-23) for daily scheduled feeds. Only
                valid when schedule_interval is ``'1d'``.
            start_from: Optional ISO-8601 timestamp to start processing from.

        Returns:
            The newly created feed record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        source_agent_id = require_str(source_agent_id, "source_agent_id")
        payload: dict[str, Any] = {
            "project_id": project_id,
            "name": name,
            "source_agent_id": source_agent_id,
            "persistent": persistent,
            "reactive": reactive,
            "execution_mode": execution_mode,
        }
        if target_corpus is not None:
            payload["target_corpus"] = target_corpus
        if schedule_interval is not None:
            payload["schedule_interval"] = schedule_interval
        if schedule_hour is not None:
            payload["schedule_hour"] = schedule_hour
        if start_from is not None:
            payload["start_from"] = start_from
        data = self._request("POST", "/v1/feeds", json=payload, request_options=request_options)
        return self._maybe_validate(data, "FeedResponse")

    def list_feeds(
        self,
        *,
        project_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List feeds accessible to the current credentials.

        Args:
            project_id: Optional project ID to filter feeds by.
            limit: Maximum number of feeds to return per page.
            offset: Number of feeds to skip for pagination.

        Returns:
            A Page containing feed records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if project_id is not None:
            params["project_id"] = project_id
        return self._list_page(
            "GET",
            "/v1/feeds",
            items_key="feeds",
            params=params or None,
            limit=limit,
            offset=offset,
        )

    def get_feed(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Retrieve a single feed by ID.

        Args:
            feed_id: Unique identifier of the feed.

        Returns:
            The feed record.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        data = self._request("GET", f"/v1/feeds/{feed_id}", request_options=request_options)
        return self._maybe_validate(data, "FeedResponse")

    def update_feed(
        self,
        feed_id: str,
        *,
        name: str | None = None,
        execution_mode: str | None = None,
        reactive: bool | None = None,
        schedule_interval: str | None = None,
        schedule_hour: int | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Update feed settings.

        Args:
            feed_id: ID of the feed to update.
            name: New name for the feed.
            execution_mode: New execution mode for the feed.
            reactive: Whether the feed triggers on new data automatically.
            schedule_interval: New cron-style schedule interval.
            schedule_hour: UTC hour (0-23) for daily scheduled feeds. Only
                valid when schedule_interval is ``'1d'``.

        Returns:
            Updated feed record.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if execution_mode is not None:
            payload["execution_mode"] = execution_mode
        if reactive is not None:
            payload["reactive"] = reactive
        if schedule_interval is not None:
            payload["schedule_interval"] = schedule_interval
        if schedule_hour is not None:
            payload["schedule_hour"] = schedule_hour
        data = self._request(
            "PATCH", f"/v1/feeds/{feed_id}", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "FeedResponse")

    def delete_feed(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> None:
        """Delete a feed.

        Args:
            feed_id: Unique identifier of the feed to delete.

        Returns:
            None (the API returns 204 No Content on success).

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        self._request("DELETE", f"/v1/feeds/{feed_id}", request_options=request_options)

    def run_feed(
        self,
        feed_id: str,
        *,
        return_results: bool | None = None,
        dry_run: bool = False,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Trigger a feed run.

        Args:
            feed_id: Unique identifier of the feed to run.
            return_results: Whether to include results in the response.
                When ``None`` (default), the API applies a smart default
                based on feed type (``True`` for standard, ``False`` for
                persistent feeds).
            dry_run: If ``True``, simulate the run without persisting results.

        Returns:
            A dict containing the feed run results and metadata.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        params: dict[str, Any] = {"dry_run": dry_run}
        if return_results is not None:
            params["return_results"] = return_results
        data = self._request(
            "POST",
            f"/v1/feeds/{feed_id}/run",
            params=params,
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedRunResponse")
