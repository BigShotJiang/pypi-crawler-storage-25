"""Job management resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._paging import Page, SyncPager
from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import JobResponse, JobStatusResponse, ReconcileJobsResponse


class JobsMixin(RequesterMixin):
    def get_job(
        self,
        job_id: str,
        request_options: RequestOptions | None = None,
    ) -> JobResponse:
        """Retrieve details of a single job.

        Args:
            job_id: Unique identifier of the job.

        Returns:
            The job record including type, status, and metadata.

        Raises:
            NotFoundError: If the job does not exist.
            Knowledge2Error: If the API request fails.
        """
        job_id = require_str(job_id, "job_id")
        data = self._request("GET", f"/v1/jobs/{job_id}", request_options=request_options)
        return self._maybe_validate(data, "JobResponse")

    def list_jobs(
        self,
        *,
        corpus_id: str | None = None,
        job_type: str | None = None,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List jobs with optional filters.

        Args:
            corpus_id: Filter to jobs belonging to this corpus.
            job_type: Filter by job type (e.g. ``"ingest"``, ``"index"``,
                ``"train"``).
            status: Filter by job status (e.g. ``"pending"``,
                ``"running"``, ``"completed"``, ``"failed"``).
            limit: Maximum number of jobs to return per page.
            offset: Number of jobs to skip for pagination.

        Returns:
            A Page containing job records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if corpus_id:
            params["corpus_id"] = corpus_id
        if job_type:
            params["job_type"] = job_type
        if status:
            params["status"] = status
        return self._list_page(
            "GET", "/v1/jobs", items_key="jobs", params=params or None, limit=limit, offset=offset
        )

    def iter_jobs(
        self,
        *,
        corpus_id: str | None = None,
        job_type: str | None = None,
        status: str | None = None,
        limit: int = 100,
        request_options: RequestOptions | None = None,
    ) -> SyncPager[dict[str, Any]]:
        """Iterate over jobs, automatically paginating.

        Args:
            corpus_id: Filter to jobs belonging to this corpus.
            job_type: Filter by job type.
            status: Filter by job status.
            limit: Page size used for each underlying API request.

        Yields:
            Individual job dicts.

        Raises:
            Knowledge2Error: If any underlying API request fails.
        """
        params: dict[str, Any] = {}
        if corpus_id:
            params["corpus_id"] = corpus_id
        if job_type:
            params["job_type"] = job_type
        if status:
            params["status"] = status
        return self._paginate(
            "GET", "/v1/jobs", items_key="jobs", params=params or None, limit=limit
        )

    def cancel_job(
        self,
        job_id: str,
        request_options: RequestOptions | None = None,
    ) -> JobStatusResponse:
        """Cancel a running or pending job.

        Args:
            job_id: Unique identifier of the job to cancel.

        Returns:
            The updated job status after cancellation.

        Raises:
            NotFoundError: If the job does not exist.
            Knowledge2Error: If the API request fails.
        """
        job_id = require_str(job_id, "job_id")
        data = self._request("POST", f"/v1/jobs/{job_id}:cancel", request_options=request_options)
        return self._maybe_validate(data, "JobStatusResponse")

    def retry_job(
        self,
        job_id: str,
        request_options: RequestOptions | None = None,
    ) -> JobStatusResponse:
        """Retry a failed job.

        Args:
            job_id: Unique identifier of the job to retry.

        Returns:
            The updated job status after scheduling the retry.

        Raises:
            NotFoundError: If the job does not exist.
            Knowledge2Error: If the API request fails.
        """
        job_id = require_str(job_id, "job_id")
        data = self._request("POST", f"/v1/jobs/{job_id}:retry", request_options=request_options)
        return self._maybe_validate(data, "JobStatusResponse")

    def reconcile_jobs(
        self,
        request_options: RequestOptions | None = None,
    ) -> ReconcileJobsResponse:
        """Reconcile stale or stuck jobs across the platform.

        Returns:
            A summary of reconciled jobs (e.g. counts of requeued or
            cancelled jobs).

        Raises:
            Knowledge2Error: If the API request fails.
        """
        data = self._request("POST", "/v1/jobs:reconcile", request_options=request_options)
        return self._maybe_validate(data, "ReconcileJobsResponse")
