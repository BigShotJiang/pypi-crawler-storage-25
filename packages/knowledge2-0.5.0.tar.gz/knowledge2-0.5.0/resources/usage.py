"""Usage metrics resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._request_options import RequestOptions
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import UsageByCorpusResponse, UsageByKeyResponse, UsageSummaryResponse


class UsageMixin(RequesterMixin):
    def usage_summary(
        self,
        *,
        range_value: str = "7d",
        corpus_id: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> UsageSummaryResponse:
        """Retrieve an aggregate usage summary.

        .. note:: Requires **bearer token** auth, not an API key.

        Args:
            range_value: Time range for the summary (e.g. ``"7d"``,
                ``"30d"``).
            corpus_id: Optional corpus to scope the summary to.

        Returns:
            Aggregated usage statistics for the requested period.

        Raises:
            AuthenticationError: If called with an API key instead of a
                bearer token.
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {"range": range_value}
        if corpus_id:
            params["corpus_id"] = corpus_id
        data = self._request(
            "GET", "/v1/usage/summary", params=params, request_options=request_options
        )
        return self._maybe_validate(data, "UsageSummaryResponse")

    def usage_by_corpus(
        self,
        *,
        range_value: str = "7d",
        request_options: RequestOptions | None = None,
    ) -> UsageByCorpusResponse:
        """Retrieve usage metrics broken down by corpus.

        .. note:: Requires **bearer token** auth, not an API key.

        Args:
            range_value: Time range for the breakdown (e.g. ``"7d"``,
                ``"30d"``).

        Returns:
            Per-corpus usage statistics for the requested period.

        Raises:
            AuthenticationError: If called with an API key instead of a
                bearer token.
            Knowledge2Error: If the API request fails.
        """
        data = self._request(
            "GET",
            "/v1/usage/by_corpus",
            params={"range": range_value},
            request_options=request_options,
        )
        return self._maybe_validate(data, "UsageByCorpusResponse")

    def usage_by_key(
        self,
        request_options: RequestOptions | None = None,
    ) -> UsageByKeyResponse:
        """Retrieve usage metrics broken down by API key.

        .. note:: Requires **bearer token** auth, not an API key.

        Returns:
            Per-key usage statistics.

        Raises:
            AuthenticationError: If called with an API key instead of a
                bearer token.
            Knowledge2Error: If the API request fails.
        """
        data = self._request("GET", "/v1/usage/by_key", request_options=request_options)
        return self._maybe_validate(data, "UsageByKeyResponse")
