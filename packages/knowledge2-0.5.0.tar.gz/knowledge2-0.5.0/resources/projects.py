"""Project resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._paging import Page, SyncPager
from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.errors import ConfirmationRequiredError
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import (
    ProjectArchiveResult,
    ProjectDeleteResponse,
    ProjectDeletionConfirmation,
    ProjectDeletionRequest,
    ProjectResponse,
    ProjectRestoreResult,
)


class ProjectsMixin(RequesterMixin):
    def create_project(
        self,
        name: str,
        *,
        org_id: str | None = None,
        org_name: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> ProjectResponse:
        """Create a new project within an organisation.

        If neither *org_id* nor *org_name* is supplied, the client's
        default ``org_id`` (if set) is used.

        Args:
            name: Display name for the project.
            org_id: Explicit organisation ID to own the project.
            org_name: Organisation name (resolved server-side if
                *org_id* is not provided).

        Returns:
            The newly created project record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        payload: dict[str, Any] = {"name": name}
        resolved_org_id = org_id or getattr(self, "org_id", None)
        if resolved_org_id:
            payload["org_id"] = resolved_org_id
        if org_name:
            payload["org_name"] = org_name
        data = self._request("POST", "/v1/projects", json=payload, request_options=request_options)
        return self._maybe_validate(data, "ProjectResponse")

    def list_projects(
        self,
        limit: int = 100,
        offset: int = 0,
        *,
        include_archived: bool = False,
        status: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List projects accessible to the current credentials.

        Args:
            limit: Maximum number of projects to return per page.
            offset: Number of projects to skip for pagination.
            include_archived: When ``True``, include archived projects
                in the results.
            status: Filter projects by status (e.g. ``"active"``,
                ``"archived"``).

        Returns:
            A Page containing project records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if include_archived:
            params["include_archived"] = True
        if status is not None:
            params["status"] = status
        return self._list_page(
            "GET",
            "/v1/projects",
            items_key="projects",
            params=params or None,
            limit=limit,
            offset=offset,
        )

    def iter_projects(
        self,
        *,
        limit: int = 100,
        request_options: RequestOptions | None = None,
    ) -> SyncPager[dict[str, Any]]:
        """Iterate over projects, automatically paginating.

        Args:
            limit: Page size used for each underlying API request.

        Yields:
            Individual project dicts.

        Raises:
            Knowledge2Error: If any underlying API request fails.
        """
        return self._paginate("GET", "/v1/projects", items_key="projects", limit=limit)

    def get_project(
        self,
        project_id: str,
        request_options: RequestOptions | None = None,
    ) -> ProjectResponse:
        """Retrieve a single project by identifier."""
        project_id = require_str(project_id, "project_id")
        data = self._request("GET", f"/v1/projects/{project_id}", request_options=request_options)
        return self._maybe_validate(data, "ProjectResponse")

    def update_project(
        self,
        project_id: str,
        *,
        name: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> ProjectResponse:
        """Update a project's mutable public fields."""
        project_id = require_str(project_id, "project_id")
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        data = self._request(
            "PATCH",
            f"/v1/projects/{project_id}",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectResponse")

    def delete_project(
        self,
        project_id: str,
        *,
        confirm: bool = False,
        force: bool = False,
        request_options: RequestOptions | None = None,
    ) -> ProjectDeleteResponse:
        """Delete a project.

        This is an irreversible operation. You must pass ``confirm=True``
        to acknowledge this and proceed.

        Args:
            project_id: Unique identifier of the project to delete.
            confirm: Safety guard — must be ``True`` to execute.
            force: When ``True``, cascade cleanup for a single corpus-backed
                project before deleting it. Other blocking project resources,
                or projects with multiple corpora, must still be cleaned up
                first.

        Returns:
            Confirmation of the deletion.

        Raises:
            ConfirmationRequiredError: If *confirm* is not ``True``.
            NotFoundError: If the project does not exist.
            ConflictError: If the project has associated resources.
        """
        project_id = require_str(project_id, "project_id")
        if not confirm:
            raise ConfirmationRequiredError("project", project_id)
        data = self._request(
            "DELETE",
            f"/v1/projects/{project_id}",
            params={"force": force} if force else None,
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectDeleteResponse")

    # ------------------------------------------------------------------
    # Project lifecycle (archive / unarchive / deletion)
    # ------------------------------------------------------------------

    def archive_project(
        self,
        project_id: str,
        request_options: RequestOptions | None = None,
    ) -> ProjectArchiveResult:
        """Archive a project.

        Archiving a project also archives its associated agents, feeds,
        and pipelines.

        Args:
            project_id: Unique identifier of the project to archive.

        Returns:
            Counts of archived child resources.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        data = self._request(
            "POST",
            f"/v1/projects/{project_id}/archive",
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectArchiveResult")

    def unarchive_project(
        self,
        project_id: str,
        request_options: RequestOptions | None = None,
    ) -> ProjectRestoreResult:
        """Restore an archived project.

        Unarchiving a project also restores its associated agents, feeds,
        and pipelines.

        Args:
            project_id: Unique identifier of the project to restore.

        Returns:
            Counts of restored child resources.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        data = self._request(
            "POST",
            f"/v1/projects/{project_id}/unarchive",
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectRestoreResult")

    def request_project_deletion(
        self,
        project_id: str,
        request_options: RequestOptions | None = None,
    ) -> ProjectDeletionRequest:
        """Request deletion of an archived project.

        Returns a confirmation code that must be passed to
        :meth:`confirm_project_deletion` to finalize the deletion.

        Args:
            project_id: Unique identifier of the project to delete.

        Returns:
            A deletion request with a confirmation code and expiry.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        data = self._request(
            "POST",
            f"/v1/projects/{project_id}/delete",
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectDeletionRequest")

    def confirm_project_deletion(
        self,
        project_id: str,
        confirmation_code: str,
        request_options: RequestOptions | None = None,
    ) -> ProjectDeletionConfirmation:
        """Confirm deletion of an archived project.

        This is an irreversible operation. The *confirmation_code* must
        be obtained from a prior call to :meth:`request_project_deletion`.

        Args:
            project_id: Unique identifier of the project to delete.
            confirmation_code: The code returned by
                :meth:`request_project_deletion`.

        Returns:
            Confirmation of the deletion.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        confirmation_code = require_str(confirmation_code, "confirmation_code")
        data = self._request(
            "POST",
            f"/v1/projects/{project_id}/delete/confirm",
            json={"confirmation_code": confirmation_code},
            request_options=request_options,
        )
        return self._maybe_validate(data, "ProjectDeletionConfirmation")
