"""Search resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import (
    EmbeddingModelListResponse,
    EmbeddingsResponse,
    FeedbackResponse,
    SearchBatchResponse,
    SearchGenerateResponse,
    SearchResponse,
)
from sdk.types.search import (
    SearchGenerationConfig,
    SearchHybridConfig,
    SearchRerankConfig,
    SearchReturnConfig,
)


class SearchMixin(RequesterMixin):
    def search(
        self,
        corpus_id: str,
        query: str,
        *,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        hybrid: SearchHybridConfig | dict[str, Any] | None = None,
        rerank: SearchRerankConfig | dict[str, Any] | None = None,
        return_config: SearchReturnConfig | dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> SearchResponse:
        """Search a corpus for relevant chunks.

        Args:
            corpus_id: The corpus to search.
            query: The search query text.
            top_k: Maximum number of results to return.
            filters: Optional metadata filters to narrow results.
            hybrid: Hybrid search configuration (dense/sparse weighting).
            rerank: Reranking configuration applied after initial retrieval.
            return_config: Controls which fields are included in the
                response (e.g. text, metadata, provenance).

        Returns:
            Search results with scored chunks, metadata, and text.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.

        Example:
            >>> results = client.search("corpus-123", "machine learning basics", top_k=5)
            >>> for chunk in results["chunks"]:
            ...     print(chunk["score"], chunk["text"][:80])
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if filters is not None:
            payload["filters"] = filters
        if hybrid is not None:
            payload["hybrid"] = hybrid
        if rerank is not None:
            payload["rerank"] = rerank
        if return_config is not None:
            payload["return"] = return_config
        data = self._request(
            "POST", f"/v1/corpora/{corpus_id}/search", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "SearchResponse")

    def search_batch(
        self,
        corpus_id: str,
        queries: list[str],
        *,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        hybrid: SearchHybridConfig | dict[str, Any] | None = None,
        rerank: SearchRerankConfig | dict[str, Any] | None = None,
        return_config: SearchReturnConfig | dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> SearchBatchResponse:
        """Execute multiple search queries against a corpus in a single request.

        Args:
            corpus_id: The corpus to search.
            queries: List of search query texts.
            top_k: Maximum number of results to return per query.
            filters: Optional metadata filters applied to all queries.
            hybrid: Hybrid search configuration (dense/sparse weighting).
            rerank: Reranking configuration applied after initial retrieval.
            return_config: Controls which fields are included in each
                query's results.

        Returns:
            Batch search results — one result set per input query.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, Any] = {"queries": queries, "top_k": top_k}
        if filters is not None:
            payload["filters"] = filters
        if hybrid is not None:
            payload["hybrid"] = hybrid
        if rerank is not None:
            payload["rerank"] = rerank
        if return_config is not None:
            payload["return"] = return_config
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/search:batch",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "SearchBatchResponse")

    def search_generate(
        self,
        corpus_id: str,
        query: str,
        *,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        hybrid: SearchHybridConfig | dict[str, Any] | None = None,
        rerank: SearchRerankConfig | dict[str, Any] | None = None,
        return_config: SearchReturnConfig | dict[str, Any] | None = None,
        generation: SearchGenerationConfig | dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> SearchGenerateResponse:
        """Search a corpus and generate an LLM answer grounded in the results.

        Combines retrieval with LLM generation (RAG) in a single call.

        Args:
            corpus_id: The corpus to search.
            query: The search query text.
            top_k: Maximum number of retrieval results fed to the generator.
            filters: Optional metadata filters to narrow retrieval results.
            hybrid: Hybrid search configuration (dense/sparse weighting).
            rerank: Reranking configuration applied after initial retrieval.
            return_config: Controls which fields are included in the
                retrieval results.
            generation: LLM generation settings (model, temperature,
                max_tokens, etc.). If ``generation.model`` is omitted,
                the server uses its configured default model.

        Returns:
            The generated answer together with the supporting retrieval
            results.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if filters is not None:
            payload["filters"] = filters
        if hybrid is not None:
            payload["hybrid"] = hybrid
        if rerank is not None:
            payload["rerank"] = rerank
        if return_config is not None:
            payload["return"] = return_config
        if generation is not None:
            payload["generation"] = generation
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/search:generate",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "SearchGenerateResponse")

    def embeddings(
        self,
        model: str,
        inputs: list[str],
        embed_type: str = "query",
        request_options: RequestOptions | None = None,
    ) -> EmbeddingsResponse:
        """Generate vector embeddings for the given texts.

        Args:
            model: Name or ID of the embedding model to use.
            inputs: List of text strings to embed.
            embed_type: Embedding type — ``"query"`` for search queries
                or ``"document"`` for corpus documents.

        Returns:
            Embedding vectors for each input text.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        payload = {"model": model, "input": inputs, "type": embed_type}
        data = self._request(
            "POST", "/v1/embeddings", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "EmbeddingsResponse")

    def list_embedding_models(
        self,
        request_options: RequestOptions | None = None,
    ) -> EmbeddingModelListResponse:
        """List available embedding models.

        Returns the set of embedding models that can be used with the
        ``embeddings`` method, indicating which model is the default.

        Returns:
            The list of available embedding models with default flag.

        Raises:
            Knowledge2Error: If the API request fails.

        Example:
            >>> resp = client.list_embedding_models()
            >>> for m in resp["models"]:
            ...     print(m["model_name"], m["is_default"])
        """
        data = self._request("GET", "/v1/embeddings/models", request_options=request_options)
        return self._maybe_validate(data, "EmbeddingModelListResponse")

    def create_feedback(
        self,
        corpus_id: str,
        query: str,
        *,
        clicked_chunk_ids: list[str] | None = None,
        rating: int | None = None,
        abstained: bool = False,
        request_options: RequestOptions | None = None,
    ) -> FeedbackResponse:
        """Submit relevance feedback for a search query.

        Feedback is used to improve training data and evaluate retrieval
        quality.

        Args:
            corpus_id: The corpus the query was executed against.
            query: The original search query text.
            clicked_chunk_ids: IDs of chunks the user found relevant.
            rating: Overall relevance rating for the result set.
            abstained: If ``True``, indicates the user chose not to
                rate the results.

        Returns:
            Confirmation that the feedback was recorded.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, Any] = {
            "query": query,
            "clicked_chunk_ids": clicked_chunk_ids,
            "rating": rating,
            "abstained": abstained,
        }
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/feedback",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedbackResponse")
