from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from sdk import AsyncKnowledge2, Knowledge2
from sdk.integrations._client import (
    merge_return_config,
    resolve_async_client,
    resolve_client,
    resolve_corpus_id,
)
from sdk.integrations.llamaindex.filters import llama_filters_to_k2

try:
    from llama_index.core import QueryBundle
    from llama_index.core.retrievers import BaseRetriever
    from llama_index.core.schema import NodeWithScore, TextNode
    from llama_index.core.vector_stores.types import MetadataFilters
except ImportError as exc:  # pragma: no cover - import-time dependency guard
    raise ImportError(
        "LlamaIndex integration requires llama-index-core. Install with `pip install .[llamaindex]`."
    ) from exc


class K2LlamaIndexRetriever(BaseRetriever):
    """LlamaIndex retriever backed by Knowledge2 search."""

    def __init__(
        self,
        *,
        corpus_id: str | None = None,
        client: Knowledge2 | None = None,
        api_key: str | None = None,
        api_host: str | None = None,
        top_k: int = 10,
        filters: MetadataFilters | None = None,
        hybrid: dict[str, Any] | None = None,
        rerank: dict[str, Any] | None = None,
        return_config: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._client = resolve_client(client=client, api_key=api_key, api_host=api_host)
        self._async_client: AsyncKnowledge2 | None = None
        self._corpus_id = resolve_corpus_id(corpus_id)
        self._top_k = top_k
        self._filters = filters
        self._hybrid = hybrid
        self._rerank = rerank
        self._return_config = return_config

    def _ensure_async_client(self) -> AsyncKnowledge2:
        """Lazily create an AsyncKnowledge2 sharing the sync client's credentials."""
        if self._async_client is None:
            self._async_client = resolve_async_client(sync_client=self._client)
        return self._async_client

    async def aclose(self) -> None:
        """Close the lazily-created async client, releasing connections."""
        if self._async_client is not None:
            await self._async_client.close()
            self._async_client = None

    @staticmethod
    def _result_to_node_with_score(
        result: Mapping[str, Any], corpus_id: str
    ) -> NodeWithScore | None:
        """Convert a single K2 search result to a LlamaIndex NodeWithScore."""
        custom_meta = result.get("custom_metadata") or {}
        system_meta = result.get("system_metadata") or {}
        if not custom_meta and not system_meta:
            legacy = result.get("metadata")
            if isinstance(legacy, dict):
                custom_meta = legacy
        if not isinstance(custom_meta, dict):
            custom_meta = {}
        if not isinstance(system_meta, dict):
            system_meta = {}
        chunk_metadata = {**system_meta, **custom_meta}

        chunk_id = result.get("chunk_id")
        if not chunk_id:
            return None

        node = TextNode(
            id_=chunk_id,
            text=result.get("text") or "",
            metadata={
                **chunk_metadata,
                "chunk_id": chunk_id,
                "corpus_id": corpus_id,
                "raw_score": result.get("raw_score"),
                "offset_start": result.get("offset_start"),
                "offset_end": result.get("offset_end"),
                "page_start": result.get("page_start"),
                "page_end": result.get("page_end"),
            },
        )
        score = result.get("score")
        if score is None:
            score = result.get("raw_score")
        return NodeWithScore(node=node, score=score)

    def _retrieve(self, query_bundle: QueryBundle) -> list[NodeWithScore]:
        query_text = query_bundle.query_str if hasattr(query_bundle, "query_str") else None
        if not query_text:
            raise ValueError("K2LlamaIndexRetriever requires a text query")

        k2_filters = llama_filters_to_k2(self._filters)
        response = self._client.search(
            self._corpus_id,
            query_text,
            top_k=self._top_k,
            filters=k2_filters,
            hybrid=self._hybrid,
            rerank=self._rerank,
            return_config=merge_return_config(
                base=self._return_config,
                override=None,
                include_text=True,
                include_scores=True,
                include_provenance=True,
            ),
        )

        nodes: list[NodeWithScore] = []
        for result in response.get("results", []):
            node = self._result_to_node_with_score(result, self._corpus_id)
            if node is not None:
                nodes.append(node)
        return nodes

    async def _aretrieve(self, query_bundle: QueryBundle) -> list[NodeWithScore]:
        """Async variant for event-loop-safe LlamaIndex integration."""
        query_text = query_bundle.query_str if hasattr(query_bundle, "query_str") else None
        if not query_text:
            raise ValueError("K2LlamaIndexRetriever requires a text query")

        async_client = self._ensure_async_client()
        k2_filters = llama_filters_to_k2(self._filters)
        response = await async_client.search(
            self._corpus_id,
            query_text,
            top_k=self._top_k,
            filters=k2_filters,
            hybrid=self._hybrid,
            rerank=self._rerank,
            return_config=merge_return_config(
                base=self._return_config,
                override=None,
                include_text=True,
                include_scores=True,
                include_provenance=True,
            ),
        )

        nodes: list[NodeWithScore] = []
        for result in response.get("results", []):
            node = self._result_to_node_with_score(result, self._corpus_id)
            if node is not None:
                nodes.append(node)
        return nodes
