"""Knowledge2 SDK exception hierarchy.

All SDK exceptions inherit from :class:`Knowledge2Error`, so callers can
use ``except Knowledge2Error`` as a catch-all.

Hierarchy::

    Knowledge2Error (base)
    ├── APIError (HTTP errors from the API)
    │   ├── BadRequestError (400)
    │   ├── AuthenticationError (401)
    │   ├── PermissionDeniedError (403)
    │   │   └── FeatureNotEnabledError (403, code=feature_not_enabled)
    │   ├── NotFoundError (404)
    │   ├── ConflictError (409)
    │   ├── ValidationError (422)
    │   ├── RateLimitError (429)
    │   │   └── QuotaExceededError (429, code=quota_exceeded)
    │   └── ServerError (500, 502, 503, 504)
    ├── APIConnectionError (network / DNS failures)
    ├── APITimeoutError (request timeout)
    └── ConfirmationRequiredError (client-side deletion guard)
"""

from __future__ import annotations

from typing import Any


class Knowledge2Error(Exception):
    """Base exception for all Knowledge2 SDK errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    @property
    def retryable(self) -> bool:
        """Whether the operation that caused this error can be retried."""
        return False


class APIError(Knowledge2Error):
    """Error returned by the Knowledge2 API (HTTP 4xx / 5xx)."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        code: str | None = None,
        details: Any = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.details = details
        self.request_id = request_id


class BadRequestError(APIError):
    """HTTP 400 — the request was malformed or missing required fields."""

    @property
    def retryable(self) -> bool:
        return False


class AuthenticationError(APIError):
    """HTTP 401 — invalid or missing API key / bearer token."""

    @property
    def retryable(self) -> bool:
        return False


class PermissionDeniedError(APIError):
    """HTTP 403 — the API key lacks the required scopes, or the requested feature is not enabled for the organization."""

    @property
    def retryable(self) -> bool:
        return False


class FeatureNotEnabledError(PermissionDeniedError):
    """The requested feature is not enabled for this organization.

    Raised when the API returns 403 with code 'feature_not_enabled'.
    Catch this separately from PermissionDeniedError to handle feature
    gate blocks specifically.
    """

    @property
    def feature(self) -> str | None:
        return self.details.get("feature") if isinstance(self.details, dict) else None

    @property
    def console_url(self) -> str | None:
        return self.details.get("console_url") if isinstance(self.details, dict) else None

    @property
    def contact_email(self) -> str | None:
        return self.details.get("contact_email") if isinstance(self.details, dict) else None


class NotFoundError(APIError):
    """HTTP 404 — the requested resource does not exist."""

    @property
    def retryable(self) -> bool:
        return False


class ConflictError(APIError):
    """HTTP 409 — resource conflict (e.g. duplicate idempotency key)."""

    @property
    def retryable(self) -> bool:
        return False


class ValidationError(APIError):
    """HTTP 422 — request validation failed."""

    @property
    def retryable(self) -> bool:
        return False


class RateLimitError(APIError):
    """HTTP 429 — too many requests.

    The :attr:`retry_after` attribute contains the server-suggested
    wait time in seconds (from the ``Retry-After`` header), or *None*
    if the header was absent.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 429,
        retry_after: float | None = None,
        code: str | None = None,
        details: Any = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            code=code,
            details=details,
            request_id=request_id,
        )
        self.retry_after = retry_after

    @property
    def retryable(self) -> bool:
        return True


class QuotaExceededError(RateLimitError):
    """Organization quota exceeded — distinct from rate limiting.

    Raised when the API returns 429 with code 'quota_exceeded'.
    Unlike RateLimitError, this is NOT retryable — the quota limit
    must be increased by an org admin.
    """

    @property
    def retryable(self) -> bool:
        return False

    @property
    def quota(self) -> str | None:
        return self.details.get("quota") if isinstance(self.details, dict) else None

    @property
    def current(self) -> int | None:
        v = self.details.get("current") if isinstance(self.details, dict) else None
        if v is None:
            return None
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    @property
    def limit(self) -> int | None:
        v = self.details.get("limit") if isinstance(self.details, dict) else None
        if v is None:
            return None
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    @property
    def console_url(self) -> str | None:
        return self.details.get("console_url") if isinstance(self.details, dict) else None


class ServerError(APIError):
    """HTTP 500 / 502 / 503 / 504 — server-side failure."""

    @property
    def retryable(self) -> bool:
        return True


class APIConnectionError(Knowledge2Error):
    """Network connectivity failure (DNS, connection refused, etc.)."""

    @property
    def retryable(self) -> bool:
        return True


class APITimeoutError(Knowledge2Error):
    """The request timed out."""

    @property
    def retryable(self) -> bool:
        return True


class ConfirmationRequiredError(Knowledge2Error):
    """Raised when a destructive operation requires explicit confirmation.

    Delete methods require ``confirm=True`` as a safety guard.
    This exception is part of the :class:`Knowledge2Error` hierarchy,
    so ``except Knowledge2Error`` catch-alls will handle it.
    """

    def __init__(self, resource_type: str, resource_id: str) -> None:
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(
            f"{resource_type.capitalize()} {resource_id!r} deletion is irreversible. "
            f"Pass confirm=True to proceed."
        )
