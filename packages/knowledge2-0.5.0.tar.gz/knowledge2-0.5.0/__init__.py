"""Knowledge2 Python SDK."""

from sdk._version import __version__

from ._async_paging import AsyncPager
from ._base import ClientLimits, ClientTimeouts
from ._logging import set_debug
from ._paging import Page, SyncPager
from ._raw_response import RawResponse
from ._request_options import RequestOptions
from .async_client import AsyncKnowledge2
from .client import Knowledge2, Knowledge2Validated
from .errors import (
    APIConnectionError,
    APIError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConfirmationRequiredError,
    ConflictError,
    FeatureNotEnabledError,
    Knowledge2Error,
    NotFoundError,
    PermissionDeniedError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .resources.pipeline_builder import PipelineBuilder

# K2Config is lazily imported to keep pydantic-settings optional.
# Users who don't need K2Config never import pydantic-settings.


def __getattr__(name: str):
    if name == "K2Config":
        from .config import K2Config

        return K2Config
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "APIConnectionError",
    "APIError",
    "APITimeoutError",
    "AsyncKnowledge2",
    "AsyncPager",
    "AuthenticationError",
    "BadRequestError",
    "ClientLimits",
    "ClientTimeouts",
    "ConfirmationRequiredError",
    "ConflictError",
    "FeatureNotEnabledError",
    "K2Config",
    "Knowledge2",
    "Knowledge2Error",
    "Knowledge2Validated",
    "NotFoundError",
    "Page",
    "PermissionDeniedError",
    "PipelineBuilder",
    "QuotaExceededError",
    "RateLimitError",
    "RawResponse",
    "RequestOptions",
    "ServerError",
    "SyncPager",
    "ValidationError",
    "__version__",
    "set_debug",
]
