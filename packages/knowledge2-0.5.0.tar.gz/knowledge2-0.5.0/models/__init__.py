"""Pydantic response models for the Knowledge2 SDK.

Requires: pip install knowledge2[pydantic]
"""

from __future__ import annotations


def __getattr__(name: str):
    """Provide a helpful error when importing model classes without pydantic."""
    try:
        import pydantic
    except ImportError:
        raise ImportError(
            f"Cannot import '{name}' — Pydantic response models require the optional "
            "'pydantic' dependency. Install with: pip install 'knowledge2[pydantic]'"
        ) from None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
