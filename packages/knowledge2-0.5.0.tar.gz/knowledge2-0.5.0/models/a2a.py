"""Pydantic models for A2A (Agent-to-Agent) types."""

from __future__ import annotations

from typing import Any, Literal

from sdk.models._base import K2BaseModel


class A2ATextPartModel(K2BaseModel):
    kind: Literal["text"]
    text: str


class A2ADataPartModel(K2BaseModel):
    kind: Literal["data"]
    data: dict[str, Any]


class A2AArtifactModel(K2BaseModel):
    artifactId: str | None = None
    name: str | None = None
    parts: list[A2ATextPartModel | A2ADataPartModel] | None = None
    metadata: dict[str, Any] | None = None


class A2ATaskStatusModel(K2BaseModel):
    state: str | None = None
    timestamp: str | None = None
    message: dict[str, Any] | None = None


class A2ATaskResponseModel(K2BaseModel):
    id: str | None = None
    contextId: str | None = None
    status: A2ATaskStatusModel | None = None
    artifacts: list[A2AArtifactModel] | None = None
    history: list[dict[str, Any]] | None = None
    metadata: dict[str, Any] | None = None
    kind: Literal["task"] | None = None


class A2AJsonRpcErrorModel(K2BaseModel):
    code: int | None = None
    message: str | None = None
    data: dict[str, Any] | None = None


class A2AJsonRpcResponseModel(K2BaseModel):
    jsonrpc: str | None = None
    id: str | int | None = None
    result: A2ATaskResponseModel | None = None
    error: A2AJsonRpcErrorModel | None = None


class A2AAgentSkillModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    description: str | None = None
    tags: list[str] | None = None
    examples: list[str] | None = None
    inputModes: list[str] | None = None
    outputModes: list[str] | None = None


class A2AAgentCapabilitiesModel(K2BaseModel):
    streaming: bool | None = None
    pushNotifications: bool | None = None
    stateTransitionHistory: bool | None = None


class A2AAgentProviderModel(K2BaseModel):
    organization: str | None = None
    url: str | None = None


class A2AAgentAuthenticationModel(K2BaseModel):
    schemes: list[str] | None = None
    credentials: str | None = None


class A2AAgentCardResponseModel(K2BaseModel):
    name: str | None = None
    description: str | None = None
    url: str | None = None
    provider: A2AAgentProviderModel | None = None
    version: str | None = None
    capabilities: A2AAgentCapabilitiesModel | None = None
    authentication: A2AAgentAuthenticationModel | None = None
    defaultInputModes: list[str] | None = None
    defaultOutputModes: list[str] | None = None
    skills: list[A2AAgentSkillModel] | None = None
