"""Pydantic models for corpora types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class CorpusResponseModel(K2BaseModel):
    id: str | None = None
    project_id: str | None = None
    name: str | None = None
    description: str | None = None
    is_tutorial: bool | None = None
    is_demo: bool | None = None
    created_at: str | None = None
    org_name: str | None = None
    project_name: str | None = None
    chunking_config: dict[str, object] | None = None


class CorpusListResponseModel(K2BaseModel):
    corpora: list[CorpusResponseModel]
    total: int


class CorpusDeleteResponseModel(K2BaseModel):
    message: str | None = None
    counts: dict[str, int] | None = None


class CorpusStatusResponseModel(K2BaseModel):
    status: str | None = None
    search_status: str | None = None
    retrieval_ready: bool | None = None
    retrieval_status: str | None = None
    ingesting: bool | None = None
    indexing: bool | None = None
    document_count: int | None = None
    documents_processing: int | None = None
    documents_failed: int | None = None
    documents_failed_ratio: float | None = None
    dense_status: str | None = None
    sparse_status: str | None = None
