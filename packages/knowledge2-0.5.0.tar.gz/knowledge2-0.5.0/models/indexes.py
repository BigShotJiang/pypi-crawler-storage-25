"""Pydantic models for index types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class IndexBuildResponseModel(K2BaseModel):
    job_id: str
    index_ids: list[str]
    idempotent_replay: bool = False


class IndexStatusResponseModel(K2BaseModel):
    build_set_id: str | None = None
    requested_mode: str | None = None
    effective_mode: str | None = None
    start_change_seq_exclusive: int | None = None
    end_change_seq_inclusive: int | None = None
    retrieval_status: str | None = None
    retrieval_reason: str | None = None
    document_count: int | None = None
    dense_status: str | None = None
    sparse_status: str | None = None
    sparse_metadata_status: str | None = None
    dense_reason: str | None = None
    sparse_reason: str | None = None
    sparse_metadata_reason: str | None = None


class IndexCompactResponseModel(K2BaseModel):
    archived: Any | None = None
    keep: int | None = None


class IndexOptimizeResponseModel(K2BaseModel):
    job_id: str
    job_type: str
