"""Pydantic models for auth types."""

from __future__ import annotations

from pydantic import Field

from sdk.models._base import K2BaseModel


class ApiKeyCreateResponseModel(K2BaseModel):
    id: str
    org_id: str
    name: str
    api_key: str


class ApiKeyRotateResponseModel(K2BaseModel):
    id: str
    org_id: str
    name: str
    api_key: str


class ApiKeyRevokeResponseModel(K2BaseModel):
    id: str
    revoked: bool


class ApiKeyListItemModel(K2BaseModel):
    id: str | None = None
    org_id: str | None = None
    org_name: str | None = None
    name: str | None = None
    scopes: dict | None = None
    project_names: list[str] | None = None
    revoked: bool | None = None
    created_at: str | None = None
    last_used_at: str | None = None


class ApiKeyListResponseModel(K2BaseModel):
    keys: list[ApiKeyListItemModel]


class WhoAmIResponseModel(K2BaseModel):
    org_id: str
    api_key_id: str
    name: str
    features: dict[str, bool] = Field(default_factory=dict)
