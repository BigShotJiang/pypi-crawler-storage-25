"""Pydantic models for onboarding types."""

from __future__ import annotations

from pydantic import Field

from sdk.models._base import K2BaseModel

# =============================================================================
# Gold Labels
# =============================================================================


class GoldLabelDocumentReferenceModel(K2BaseModel):
    type: str | None = None
    value: str | None = None


class GoldLabelChunkReferenceModel(K2BaseModel):
    type: str | None = None
    value: str | int | dict | None = None


class GoldLabelEntryModel(K2BaseModel):
    query: str | None = None
    document_reference: GoldLabelDocumentReferenceModel | None = None
    chunk_reference: GoldLabelChunkReferenceModel | None = None
    relevant_text: str | None = None
    metadata: dict | None = None


class GoldLabelsUploadRequestModel(K2BaseModel):
    labels: list[GoldLabelEntryModel] | None = None
    description: str | None = None


class ResolvedLabelInfoModel(K2BaseModel):
    label_id: str
    query: str
    chunk_id: str | None
    document_id: str | None
    confidence: float
    resolution_method: str


class GoldLabelsUploadResponseModel(K2BaseModel):
    corpus_id: str
    total_uploaded: int
    resolved_count: int
    unmatched_count: int
    labels: list[ResolvedLabelInfoModel]


class GoldLabelListItemModel(K2BaseModel):
    id: str
    query: str
    chunk_id: str | None
    document_id: str | None
    source: str | None
    confidence: float | None
    created_at: str


class GoldLabelsListResponseModel(K2BaseModel):
    corpus_id: str
    total: int
    labels: list[GoldLabelListItemModel]


# =============================================================================
# Dataset Analysis
# =============================================================================


class DatasetAnalysisRequestModel(K2BaseModel):
    description: str | None = None
    auto_bootstrap: bool | None = None
    bootstrap_num_samples: int | None = None
    queries_per_chunk: int | None = None


class DatasetAnalysisResponseModel(K2BaseModel):
    analysis_id: str
    corpus_id: str
    status: str
    job_id: str | None
    estimated_duration_seconds: int | None
    created_at: str


class DatasetAnalysisSummaryModel(K2BaseModel):
    analysis_id: str
    status: str
    current_stage: str | None
    stages_completed: list[str]
    has_prompt: bool
    has_evaluation: bool
    bootstrap_enabled: bool
    bootstrap_labels_count: int | None
    documents_at_analysis: int | None
    started_at: str
    created_at: str
    completed_at: str | None
    error_message: str | None
    domain: str | None
    lexical_strategy: str | None
    quality_score: float | None


class OnboardingStatusResponseModel(K2BaseModel):
    corpus_id: str
    latest_analysis: DatasetAnalysisSummaryModel | None
    gold_labels_count: int
    synthetic_batches_count: int
    has_summaries: bool
    analysis_stale: bool


class QueryProfileResponseModel(K2BaseModel):
    corpus_id: str
    example_queries: list[str]
    dataset_name: str | None = None
    use_cases: list[str] = Field(default_factory=list)
    dataset_hints: list[str] = Field(default_factory=list)
    analysis: dict = Field(default_factory=dict)
    optimize_state: dict = Field(default_factory=dict)
    updated_at: str | None = None


class SearcherPersonaModel(K2BaseModel):
    who: str
    goal: str
    knowledge_state: str


class LexicalStrategyModel(K2BaseModel):
    recommendation: str
    rationale: str
    techniques: list[str]


class DatasetAnalysisDetailsModel(K2BaseModel):
    analysis_id: str
    corpus_id: str
    status: str
    created_at: str
    completed_at: str | None
    config: dict
    schema_analysis: dict | None
    domain: str | None
    expertise_level: str | None
    data_relationship: str | None
    searcher_persona: SearcherPersonaModel | None
    lexical_strategy: LexicalStrategyModel | None
    stage1_analysis: dict | None
    artifact_uri: str | None
    prompt_uri: str | None
    bootstrap_enabled: bool
    bootstrap_labels_count: int | None
    error_message: str | None


# =============================================================================
# Synthetic Query Generation
# =============================================================================


class SyntheticQueryGenerationRequestModel(K2BaseModel):
    analysis_id: str | None = None
    sample_size: int | None = None
    queries_per_chunk: int | None = None
    use_document_context: bool | None = None
    eval_sample_size: int | None = None


class SyntheticQueryBatchResponseModel(K2BaseModel):
    batch_id: str
    corpus_id: str
    analysis_id: str
    status: str
    job_id: str | None
    sample_size: int | None
    queries_per_chunk: int
    estimated_queries: int | None
    created_at: str


class SyntheticQueryBatchSummaryModel(K2BaseModel):
    batch_id: str
    status: str
    sample_size: int | None
    queries_per_chunk: int
    total_chunks_processed: int | None
    total_queries_generated: int | None
    created_at: str
    completed_at: str | None


class SyntheticQueryBatchListResponseModel(K2BaseModel):
    corpus_id: str
    batches: list[SyntheticQueryBatchSummaryModel]


class SyntheticQuerySampleModel(K2BaseModel):
    chunk_id: str
    chunk_text_preview: str
    queries: list[str]


class SyntheticQueryBatchDetailsModel(K2BaseModel):
    batch_id: str
    corpus_id: str
    analysis_id: str
    status: str
    created_at: str
    completed_at: str | None
    sample_size: int | None
    queries_per_chunk: int
    use_document_context: bool
    config: dict
    total_chunks_processed: int | None
    total_queries_generated: int | None
    stats: dict
    artifact_uri: str | None
    sample_queries: list[SyntheticQuerySampleModel]
    error_message: str | None


# =============================================================================
# Evaluation
# =============================================================================


class EvaluationRequestModel(K2BaseModel):
    batch_id: str | None = None
    sample_size: int | None = None


class EvaluationResponseModel(K2BaseModel):
    eval_id: str
    corpus_id: str
    batch_id: str
    status: str
    job_id: str | None
    created_at: str


class EvaluationMetricsModel(K2BaseModel):
    total_evaluated: int | None = None
    avg_relevance: float | None = None
    avg_groundedness: float | None = None
    avg_style: float | None = None
    avg_lexical_diversity: float | None = None
    pass_rate: float | None = None
    score_distribution: dict | None = None


class EvaluationSummaryModel(K2BaseModel):
    eval_id: str
    batch_id: str
    status: str
    sample_size: int | None
    metrics: EvaluationMetricsModel | None
    created_at: str
    completed_at: str | None


class EvaluationListResponseModel(K2BaseModel):
    corpus_id: str
    evaluations: list[EvaluationSummaryModel]


class EvaluationDetailsModel(K2BaseModel):
    eval_id: str
    corpus_id: str
    batch_id: str
    status: str
    created_at: str
    completed_at: str | None
    sample_size: int | None
    config: dict
    metrics: EvaluationMetricsModel | None
    artifact_uri: str | None
    sample_results: list[dict]
    error_message: str | None


class EvaluationReportResponseModel(K2BaseModel):
    eval_id: str
    corpus_id: str
    metrics: EvaluationMetricsModel | None
    recommendations: list[str]


# =============================================================================
# Document Summarization
# =============================================================================


class SummarizationRequestModel(K2BaseModel):
    force_regenerate: bool | None = None


class SummarizationResponseModel(K2BaseModel):
    corpus_id: str
    job_id: str | None
    status: str
    total_documents: int
    documents_with_summaries: int
    documents_to_summarize: int
    created_at: str


class SummarizationStatusResponseModel(K2BaseModel):
    corpus_id: str
    total_documents: int
    documents_with_summaries: int
    coverage_percent: float
    latest_job_status: str | None
    latest_job_completed_at: str | None


class DocumentSummaryResponseModel(K2BaseModel):
    document_id: str
    corpus_id: str
    summary: str
    document_type: str | None
    entities: dict
    key_facts: list[str]
    generation_model: str | None
    created_at: str
