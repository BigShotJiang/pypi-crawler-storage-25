"""Pydantic models for chunk types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class ChunkListItemModel(K2BaseModel):
    id: str | None = None
    text: str | None = None
    custom_metadata: dict | None = None
    system_metadata: dict | None = None
    offset_start: int | None = None
    offset_end: int | None = None
    page_start: int | None = None
    page_end: int | None = None


class ChunkListResponseModel(K2BaseModel):
    chunks: list[ChunkListItemModel]
