"""Pydantic models for job types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class JobActionsModel(K2BaseModel):
    can_cancel: bool | None = None
    can_retry: bool | None = None


class JobResponseModel(K2BaseModel):
    id: str | None = None
    job_type: str | None = None
    status: str | None = None
    actions: JobActionsModel | None = None
    payload: dict | None = None
    result: dict | None = None
    error_message: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    heartbeat_at: str | None = None
    requeue_count: int | None = None
    run_after: str | None = None


class JobListItemModel(K2BaseModel):
    id: str | None = None
    job_type: str | None = None
    status: str | None = None
    actions: JobActionsModel | None = None
    payload: dict | None = None
    result: dict | None = None
    error_message: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    heartbeat_at: str | None = None
    requeue_count: int | None = None
    run_after: str | None = None


class JobListResponseModel(K2BaseModel):
    jobs: list[JobListItemModel]


class JobStatusResponseModel(K2BaseModel):
    status: str


class ReconcileJobsResponseModel(K2BaseModel):
    reconciled: int
