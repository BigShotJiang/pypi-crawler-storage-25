"""Pydantic models for generation model types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class GenerationModelItemModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    provider: str | None = None
    default: bool | None = None


class GenerationModelsListResponseModel(K2BaseModel):
    models: list[GenerationModelItemModel]
