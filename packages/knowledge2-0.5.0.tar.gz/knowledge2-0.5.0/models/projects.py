"""Pydantic models for project types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class ProjectResponseModel(K2BaseModel):
    id: str
    name: str
    org_id: str
    status: str = "active"
    archived_at: str | None = None


class ProjectDeleteResponseModel(K2BaseModel):
    message: str | None = None
    counts: dict[str, int] | None = None


class ProjectListResponseModel(K2BaseModel):
    projects: list[ProjectResponseModel]
    total: int


class ProjectArchiveResultModel(K2BaseModel):
    archived_agents: int | None = None
    archived_feeds: int | None = None
    archived_pipelines: int | None = None


class ProjectRestoreResultModel(K2BaseModel):
    restored_agents: int | None = None
    restored_feeds: int | None = None
    restored_pipelines: int | None = None


class ProjectDeletionRequestModel(K2BaseModel):
    deletion_request_id: str | None = None
    confirmation_code: str | None = None
    expires_at: str | None = None


class ProjectDeletionConfirmationModel(K2BaseModel):
    project_id: str | None = None
    message: str | None = None
