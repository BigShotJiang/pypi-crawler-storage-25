"""Pydantic models for audit types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class AuditLogItemModel(K2BaseModel):
    id: str | None = None
    action: str | None = None
    entity_type: str | None = None
    entity_id: str | None = None
    org_id: str | None = None
    project_id: str | None = None
    corpus_id: str | None = None
    api_key_id: str | None = None
    user_id: str | None = None
    payload: dict | None = None
    created_at: str | None = None


class AuditLogListResponseModel(K2BaseModel):
    logs: list[AuditLogItemModel]
    total: int


class AuditLogActionsResponseModel(K2BaseModel):
    actions: list[str]
