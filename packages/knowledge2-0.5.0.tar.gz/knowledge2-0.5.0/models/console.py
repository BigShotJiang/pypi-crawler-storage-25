"""Pydantic models for console types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel
from sdk.models.jobs import JobListItemModel


class ConsoleMeResponseModel(K2BaseModel):
    provisioned: bool | None = None
    org_id: str | None = None
    org_name: str | None = None
    project_id: str | None = None
    project_name: str | None = None
    role: str | None = None
    is_org_admin: bool | None = None
    auth_subject: str | None = None
    user_id: str | None = None
    email: str | None = None
    name: str | None = None


class ConsoleBootstrapResponseModel(ConsoleMeResponseModel):
    created: bool | None = None


class ConsoleSummaryResponseModel(K2BaseModel):
    corpora_total: int
    documents_total: int
    documents_failed: int
    recent_jobs: list[JobListItemModel]


class ConsoleProjectItemModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    org_id: str | None = None
    role: str | None = None


class ConsoleProjectListResponseModel(K2BaseModel):
    projects: list[ConsoleProjectItemModel]


class ConsoleOrgResponseModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    contact_email: str | None = None


class TeamMemberModel(K2BaseModel):
    membership_id: str | None = None
    user_id: str | None = None
    email: str | None = None
    name: str | None = None
    role: str | None = None
    created_at: str | None = None
    is_current_user: bool | None = None


class TeamListResponseModel(K2BaseModel):
    members: list[TeamMemberModel]


class InviteListItemModel(K2BaseModel):
    id: str | None = None
    email: str | None = None
    role: str | None = None
    created_at: str | None = None
    expires_at: str | None = None
    accepted_at: str | None = None


class InviteListResponseModel(K2BaseModel):
    invites: list[InviteListItemModel]


class InviteCreateResponseModel(K2BaseModel):
    id: str | None = None
    email: str | None = None
    role: str | None = None
    token: str | None = None
    expires_at: str | None = None


class InviteAcceptResponseModel(K2BaseModel):
    org_id: str | None = None
    org_name: str | None = None
    project_id: str | None = None
    project_name: str | None = None
    role: str | None = None


class MemberUpdateResponseModel(K2BaseModel):
    updated: bool
    role: str


class MemberRemoveResponseModel(K2BaseModel):
    removed: bool
