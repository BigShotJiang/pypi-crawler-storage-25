"""Pydantic models for usage types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class UsageSeriesPointModel(K2BaseModel):
    date: str
    count: int


class UsageSummaryResponseModel(K2BaseModel):
    range: str | None = None
    total_requests: int | None = None
    daily: list[UsageSeriesPointModel] | None = None
    latency_p50_ms: float | None = None
    latency_p95_ms: float | None = None
    error_rate: float | None = None


class UsageByCorpusItemModel(K2BaseModel):
    corpus_id: str | None = None
    corpus_name: str | None = None
    requests: int | None = None


class UsageByCorpusResponseModel(K2BaseModel):
    items: list[UsageByCorpusItemModel]


class UsageByKeyItemModel(K2BaseModel):
    key_id: str | None = None
    name: str | None = None
    requests: int | None = None


class UsageByKeyResponseModel(K2BaseModel):
    items: list[UsageByKeyItemModel]
