"""Pydantic models for embedding types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class EmbeddingItemModel(K2BaseModel):
    embedding: list[float]
    index: int


class EmbeddingsResponseModel(K2BaseModel):
    data: list[EmbeddingItemModel]
    model: str


class EmbeddingModelInfoModel(K2BaseModel):
    model_name: str
    is_default: bool


class EmbeddingModelListResponseModel(K2BaseModel):
    models: list[EmbeddingModelInfoModel]
