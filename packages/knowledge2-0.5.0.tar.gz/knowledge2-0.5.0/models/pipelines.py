"""Pydantic models for pipeline types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class ValidationIssueModel(K2BaseModel):
    severity: str | None = None
    code: str | None = None
    message: str | None = None
    path: str | None = None


class PipelineSpecResponseModel(K2BaseModel):
    id: str | None = None
    org_id: str | None = None
    project_id: str | None = None
    name: str | None = None
    description: str | None = None
    topology: dict[str, Any] | None = None
    status: str | None = None
    has_draft: bool | None = None
    parent_pipeline_spec_id: str | None = None
    created_by: str | None = None
    bound_entity_count: int | None = None
    binding_summary: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class PipelineSpecListResponseModel(K2BaseModel):
    pipeline_specs: list[PipelineSpecResponseModel]
    total: int
    limit: int
    offset: int


class DryRunResultModel(K2BaseModel):
    valid: bool | None = None
    issues: list[ValidationIssueModel] | None = None
    would_create_agents: int | None = None
    would_create_feeds: int | None = None
    would_create_corpora: int | None = None
    would_bind_existing: int | None = None


class ApplyResultModel(K2BaseModel):
    success: bool | None = None
    created_agent_ids: list[str] | None = None
    created_feed_ids: list[str] | None = None
    created_corpus_ids: list[str] | None = None
    created_subscription_ids: list[str] | None = None
    bound_entity_ids: list[str] | None = None
    issues: list[ValidationIssueModel] | None = None


class SkippedEntityModel(K2BaseModel):
    entity_type: str | None = None
    entity_id: str | None = None
    entity_name: str | None = None
    reason: str | None = None
    other_pipeline_ids: list[str] | None = None


class ArchiveResultModel(K2BaseModel):
    pipeline_spec: PipelineSpecResponseModel | None = None
    archived_agents: list[str] | None = None
    archived_feeds: list[str] | None = None
    deactivated_subscriptions: list[str] | None = None
    skipped_entities: list[SkippedEntityModel] | None = None


class DraftActivateResultModel(K2BaseModel):
    success: bool | None = None
    created_agent_ids: list[str] | None = None
    created_feed_ids: list[str] | None = None
    created_corpus_ids: list[str] | None = None
    created_subscription_ids: list[str] | None = None
    removed_binding_ids: list[str] | None = None
    updated_entity_ids: list[str] | None = None
    issues: list[ValidationIssueModel] | None = None


class FieldDiffModel(K2BaseModel):
    field: str | None = None
    spec_value: str | None = None
    actual_value: str | None = None


class EntityDiffModel(K2BaseModel):
    entity_type: str | None = None
    entity_id: str | None = None
    entity_name: str | None = None
    drift_status: str | None = None
    field_diffs: list[FieldDiffModel] | None = None


class DriftSummaryModel(K2BaseModel):
    total_entities: int | None = None
    in_sync: int | None = None
    drifted: int | None = None
    missing: int | None = None
    untracked: int | None = None


class DriftReportModel(K2BaseModel):
    pipeline_spec_id: str | None = None
    status: str | None = None
    entity_diffs: list[EntityDiffModel] | None = None
    summary: DriftSummaryModel | None = None


class RefreshChangesModel(K2BaseModel):
    updated_entities: list[str] | None = None
    removed_entities: list[str] | None = None
    unchanged_entities: list[str] | None = None


class RefreshResultModel(K2BaseModel):
    draft_id: str | None = None
    changes: RefreshChangesModel | None = None


class GraphNodeModel(K2BaseModel):
    id: str | None = None
    type: str | None = None
    label: str | None = None
    metadata: dict[str, Any] | None = None
    status: str | None = None
    binding_role: str | None = None


class GraphEdgeModel(K2BaseModel):
    source: str | None = None
    target: str | None = None
    type: str | None = None
    metadata: dict[str, Any] | None = None


class GraphResponseModel(K2BaseModel):
    pipeline_spec_id: str | None = None
    status: str | None = None
    nodes: list[GraphNodeModel] | None = None
    edges: list[GraphEdgeModel] | None = None
