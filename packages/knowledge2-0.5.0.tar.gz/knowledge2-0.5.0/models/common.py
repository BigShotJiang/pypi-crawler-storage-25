"""Pydantic models for common types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class ApiErrorDetailModel(K2BaseModel):
    code: str | None = None
    message: str | None = None
    details: Any | None = None
    request_id: str | None = None
