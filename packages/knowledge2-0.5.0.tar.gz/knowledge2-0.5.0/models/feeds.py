"""Pydantic models for feed types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class FeedSubscriptionResponseModel(K2BaseModel):
    id: str | None = None
    agent_id: str | None = None
    agent_name: str | None = None
    role: str | None = None


class FeedResponseModel(K2BaseModel):
    id: str | None = None
    project_id: str | None = None
    source_agent_id: str | None = None
    name: str | None = None
    execution_mode: str | None = None
    persistent: bool | None = None
    reactive: bool | None = None
    target_corpus_id: str | None = None
    schedule_interval: str | None = None
    schedule_hour: int | None = None
    start_from: str | None = None
    activation_status: str | None = None
    last_checked_seq: int | None = None
    last_run_at: str | None = None
    last_run_result_count: int | None = None
    subscriptions: list[FeedSubscriptionResponseModel] | None = None
    parent_feed_id: str | None = None
    has_draft: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None


class FeedListResponseModel(K2BaseModel):
    feeds: list[FeedResponseModel]
    total: int
    limit: int
    offset: int


class FeedRunResponseModel(K2BaseModel):
    new_content: bool | None = None
    results: list[dict[str, Any]] | None = None
    result_count: int | None = None
    truncated: bool | None = None
    ingestion_job_id: str | None = None
    dry_run: bool | None = None
    would_ingest_count: int | None = None
    feed_run_id: str | None = None
