"""Base Pydantic model for Knowledge2 API responses."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class K2BaseModel(BaseModel):
    """Base model for all Knowledge2 API response models.

    Configuration:
    - extra="allow": unknown server fields are preserved, not rejected.
    - validate_assignment=True: re-validates when fields are set post-init.
    - use_enum_values=True: enum fields store the value, not the enum member.
    - populate_by_name=True: allows field access by both Python name and alias.
    """

    model_config = ConfigDict(
        extra="allow",
        validate_assignment=True,
        validate_by_alias=True,
        use_enum_values=True,
        populate_by_name=True,
    )
