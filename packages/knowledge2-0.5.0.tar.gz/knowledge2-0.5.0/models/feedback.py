"""Pydantic models for feedback types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class FeedbackResponseModel(K2BaseModel):
    message: str
