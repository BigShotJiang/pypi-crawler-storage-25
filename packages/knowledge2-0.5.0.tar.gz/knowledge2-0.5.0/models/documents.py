"""Pydantic models for document types."""

from __future__ import annotations

import logging
from typing import Literal

from pydantic import model_validator

from sdk.models._base import K2BaseModel

logger = logging.getLogger(__name__)


class ChunkingConfigModel(K2BaseModel):
    strategy: (
        Literal["fixed", "paragraph", "semantic", "semchunk", "unstructured", "docling"] | None
    ) = None
    chunking_strategy: Literal["basic", "by_title", "by_page", "by_similarity"] | None = None
    chunk_size: int | None = None
    overlap: int | None = None
    combine_text_under_n_chars: int | None = None
    multipage_sections: bool | None = None
    new_after_n_chars: int | None = None
    max_concurrent_requests: int | None = None
    timeout: int | None = None
    dedup_mode: Literal["off", "minhash"] | None = None
    dedup_partition_keys: list[str] | None = None
    docling_chunker_type: Literal["hybrid", "hierarchical"] | None = None
    docling_tokenizer_model: str | None = None
    docling_max_tokens: int | None = None
    docling_merge_peers: bool | None = None
    docling_merge_list_items: bool | None = None
    docling_processing_mode: Literal["auto", "sequential", "batch"] | None = None
    docling_accelerator: Literal["auto", "cuda", "cpu"] | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_docling_ray_config(cls, value):
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        removed_fields = (
            "docling_ray_num_workers",
            "docling_ray_docs_per_batch",
            "docling_min_batch_size",
            "docling_min_ray_threshold_multiplier",
        )
        ignored = [field for field in removed_fields if field in normalized]
        if ignored:
            logger.warning(
                "Ignoring removed Docling Ray chunking fields in SDK model: %s",
                ", ".join(sorted(ignored)),
            )
            for field_name in ignored:
                normalized.pop(field_name, None)

        processing_mode = normalized.get("docling_processing_mode")
        if isinstance(processing_mode, str) and processing_mode.strip().lower() == "ray":
            logger.warning(
                "Docling processing mode 'ray' is no longer supported; using 'batch' instead"
            )
            normalized["docling_processing_mode"] = "batch"

        return normalized


class DocumentCreateResponseModel(K2BaseModel):
    id: str
    job_id: str
    idempotent_replay: bool = False


class DocumentBatchItemModel(K2BaseModel):
    source_uri: str | None = None
    raw_text: str | None = None
    metadata: dict | None = None


class DocumentUrlItemModel(K2BaseModel):
    url: str | None = None
    title: str | None = None
    tags: list[str] | None = None
    metadata: dict | None = None


class DocumentUrlIngestResponseModel(K2BaseModel):
    job_id: str
    submitted: int
    idempotent_replay: bool = False


class DocumentManifestIngestResponseModel(K2BaseModel):
    job_id: str
    idempotent_replay: bool = False


class DocumentListItemModel(K2BaseModel):
    id: str | None = None
    corpus_id: str | None = None
    source_uri: str | None = None
    custom_metadata: dict | None = None
    system_metadata: dict | None = None
    created_at: str | None = None
    status: str | None = None
    size_bytes: int | None = None
    content_type: str | None = None
    preview: str | None = None


class DocumentListResponseModel(K2BaseModel):
    documents: list[DocumentListItemModel]
    total: int


class DocumentDetailResponseModel(DocumentListItemModel):
    pass


class DocumentDeleteResponseModel(K2BaseModel):
    message: str | None = None
    reindex_job_id: str | None = None


class BatchItemErrorModel(K2BaseModel):
    index: int | None = None
    error: str | None = None


class DocumentBatchUploadResponseModel(K2BaseModel):
    job_id: str
    doc_ids: list[str]
    count: int
    idempotent_replay: bool = False
    errors: list[BatchItemErrorModel] | None = None


class DocumentUploadFormatModel(K2BaseModel):
    key: str
    label: str
    extensions: list[str]


class DocumentUploadCapabilitiesResponseModel(K2BaseModel):
    advertised_formats: list[DocumentUploadFormatModel]
