"""Pydantic models for search types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class SearchHybridConfigModel(K2BaseModel):
    enabled: bool | None = None
    fusion_mode: str | None = None
    rrf_k: int | None = None
    dense_weight: float | None = None
    sparse_weight: float | None = None
    metadata_sparse_enabled: bool | None = None


class SearchRerankConfigModel(K2BaseModel):
    enabled: bool | None = None
    top_k: int | None = None


class SearchReturnConfigModel(K2BaseModel):
    include_text: bool | None = None
    include_scores: bool | None = None
    include_provenance: bool | None = None


class MetadataFilterModel(K2BaseModel):
    key: str | None = None
    op: str | None = None
    value: Any | None = None


class MetadataFiltersModel(K2BaseModel):
    filters: list[MetadataFilterModel] | None = None
    condition: str | None = None


class SearchGenerationConfigModel(K2BaseModel):
    model: str | None = None
    thinking_budget: int | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    context_top_k: int | None = None


class SearchOptionsModel(K2BaseModel):
    query: str | None = None
    top_k: int | None = None
    filters: dict[str, Any] | MetadataFiltersModel | None = None
    hybrid: SearchHybridConfigModel | None = None
    rerank: SearchRerankConfigModel | None = None
    return_config: SearchReturnConfigModel | None = None


class SearchGenerateOptionsModel(K2BaseModel):
    query: str | None = None
    top_k: int | None = None
    filters: dict[str, Any] | MetadataFiltersModel | None = None
    hybrid: SearchHybridConfigModel | None = None
    rerank: SearchRerankConfigModel | None = None
    return_config: SearchReturnConfigModel | None = None
    generation: SearchGenerationConfigModel | None = None


class SearchBatchOptionsModel(K2BaseModel):
    queries: list[str] | None = None
    top_k: int | None = None
    filters: dict[str, Any] | MetadataFiltersModel | None = None
    hybrid: SearchHybridConfigModel | None = None
    rerank: SearchRerankConfigModel | None = None
    return_config: SearchReturnConfigModel | None = None


class SearchResultModel(K2BaseModel):
    chunk_id: str | None = None
    id: str | None = None
    score: float | None = None
    raw_score: float | None = None
    text: str | None = None
    custom_metadata: dict | None = None
    system_metadata: dict | None = None
    offset_start: int | None = None
    offset_end: int | None = None
    page_start: int | None = None
    page_end: int | None = None


class SearchColdStartMetaModel(K2BaseModel):
    likely: bool | None = None
    dense_cache_hit: bool | None = None
    sparse_cache_hit: bool | None = None


class SearchMetaModel(K2BaseModel):
    cold_start: SearchColdStartMetaModel | None = None
    warnings: list[str] | None = None


class SearchResponseModel(K2BaseModel):
    results: list[SearchResultModel] | None = None
    meta: SearchMetaModel | None = None


class SearchBatchResponseModel(K2BaseModel):
    responses: list[SearchResponseModel] | None = None


class SearchGenerateResponseModel(K2BaseModel):
    answer: str | None = None
    model: str | None = None
    thinking_budget: int | None = None
    results: list[SearchResultModel] | None = None
    meta: SearchMetaModel | None = None
    used_sources: list[str] | None = None
