"""Pydantic models for org types."""

from __future__ import annotations

from sdk.models._base import K2BaseModel


class OrgResponseModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    contact_email: str | None = None
