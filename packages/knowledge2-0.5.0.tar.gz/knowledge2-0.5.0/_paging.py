"""Pagination primitives for the Knowledge2 SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Generic, Iterator, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class Page(Generic[T]):
    """A single page of results with pagination metadata."""

    items: list[T]
    total: int
    offset: int
    limit: int

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[T]:
        return iter(self.items)

    def __bool__(self) -> bool:
        return len(self.items) > 0


class SyncPager(Generic[T]):
    """Stateful paginator that lazily fetches pages.

    Hides whether underlying pagination is offset- or cursor-based.
    """

    def __init__(
        self,
        fetch_page: Callable[[int, int], tuple[list[T], int]],
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> None:
        self._fetch_page = fetch_page
        self._limit = limit
        self._offset = offset
        self._exhausted = False
        self._first_page: Page[T] | None = None
        self._first_page_consumed = False

    @property
    def total(self) -> int:
        """Total number of items across all pages.

        Lazily fetches the first page if not yet fetched.
        """
        if self._first_page is None:
            items, total = self._fetch_page(self._offset, self._limit)
            self._first_page = Page(
                items=items, total=total, offset=self._offset, limit=self._limit
            )
        return self._first_page.total

    def _advance(self, page: Page[T]) -> None:
        """Update offset or mark exhausted after consuming a page."""
        if len(page.items) < self._limit or (
            page.total > len(page.items) and self._offset + self._limit >= page.total
        ):
            self._exhausted = True
        else:
            self._offset += self._limit

    def next_page(self) -> Page[T] | None:
        """Fetch the next page. Returns None when exhausted."""
        if self._exhausted:
            return None
        # Return cached first page if it hasn't been consumed yet
        if self._first_page is not None and not self._first_page_consumed:
            self._first_page_consumed = True
            self._advance(self._first_page)
            return self._first_page
        items, total = self._fetch_page(self._offset, self._limit)
        page = Page(items=items, total=total, offset=self._offset, limit=self._limit)
        if self._first_page is None:
            self._first_page = page
            self._first_page_consumed = True
        self._advance(page)
        return page

    def iter_pages(self) -> Iterator[Page[T]]:
        """Iterate over all pages."""
        while True:
            page = self.next_page()
            if page is None:
                break
            yield page
            if not page.items:
                break

    def __iter__(self) -> Iterator[T]:
        """Item-level iteration across all pages."""
        for page in self.iter_pages():
            yield from page.items
