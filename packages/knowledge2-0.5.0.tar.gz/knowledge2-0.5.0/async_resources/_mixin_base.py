from __future__ import annotations

from collections.abc import Awaitable
from typing import Any, Protocol, runtime_checkable

from sdk._async_paging import AsyncPager
from sdk._paging import Page


@runtime_checkable
class AsyncRequesterMixin(Protocol):
    async def _request(self, method: str, path: str, **kwargs: Any) -> Any: ...

    def _maybe_validate(self, data: Any, model_name: str) -> Any: ...

    @staticmethod
    def _idempotency_headers(idempotency_key: str | None) -> dict[str, str]: ...

    async def _wait_for_job(
        self, job_id: str, *, poll_s: int = 5, timeout_s: float | None = None
    ) -> dict[str, Any]: ...

    async def _list_page(
        self,
        method: str,
        path: str,
        *,
        items_key: str,
        params: dict[str, Any] | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Page[dict[str, Any]]: ...

    def _paginate(
        self,
        method: str,
        path: str,
        *,
        items_key: str,
        params: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> AsyncPager[dict[str, Any]]: ...
