"""Async corpus resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._async_paging import AsyncPager
from sdk._paging import Page
from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.async_resources._mixin_base import AsyncRequesterMixin
from sdk.errors import ConfirmationRequiredError
from sdk.types import (
    CorpusDeleteResponse,
    CorpusResponse,
    CorpusStatusResponse,
)


class AsyncCorporaMixin(AsyncRequesterMixin):
    async def create_corpus(
        self,
        project_id: str,
        name: str,
        description: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> CorpusResponse:
        """Create a new corpus within a project.

        Args:
            project_id: The project that will own the corpus.
            name: Human-readable name for the corpus.
            description: Optional description of the corpus contents.

        Returns:
            The newly created corpus record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        payload: dict[str, Any] = {"project_id": project_id, "name": name}
        if description is not None:
            payload["description"] = description
        data = await self._request(
            "POST", "/v1/corpora", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "CorpusResponse")

    async def list_corpora(
        self,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List corpora accessible to the current credentials.

        Args:
            limit: Maximum number of corpora to return per page.
            offset: Number of corpora to skip for pagination.

        Returns:
            A Page containing corpus records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        return await self._list_page(
            "GET", "/v1/corpora", items_key="corpora", limit=limit, offset=offset
        )

    def iter_corpora(
        self,
        *,
        limit: int = 100,
        request_options: RequestOptions | None = None,
    ) -> AsyncPager[dict[str, Any]]:
        """Lazily paginate corpora, yielding individual corpus items.

        Args:
            limit: Page size used for each underlying API request.

        Yields:
            Individual corpus response dicts.

        Raises:
            Knowledge2Error: If any underlying API request fails.
        """
        return self._paginate(
            "GET",
            "/v1/corpora",
            items_key="corpora",
            limit=limit,
        )

    async def get_corpus(
        self,
        corpus_id: str,
        request_options: RequestOptions | None = None,
    ) -> CorpusResponse:
        """Retrieve a single corpus by ID.

        Args:
            corpus_id: Unique identifier of the corpus.

        Returns:
            The corpus record.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        data = await self._request(
            "GET", f"/v1/corpora/{corpus_id}", request_options=request_options
        )
        return self._maybe_validate(data, "CorpusResponse")

    async def get_corpus_status(
        self,
        corpus_id: str,
        request_options: RequestOptions | None = None,
    ) -> CorpusStatusResponse:
        """Retrieve the ingestion and indexing status of a corpus.

        Args:
            corpus_id: Unique identifier of the corpus.

        Returns:
            Status information including document counts and index state.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        data = await self._request(
            "GET", f"/v1/corpora/{corpus_id}/status", request_options=request_options
        )
        return self._maybe_validate(data, "CorpusStatusResponse")

    async def update_corpus(
        self,
        corpus_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        chunking_config: dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> CorpusResponse:
        """Update corpus settings.

        Args:
            corpus_id: ID of the corpus to update
            name: New name for the corpus
            description: New description for the corpus.  Pass an empty
                string to clear an existing description.
            chunking_config: Default chunking configuration for documents in this corpus.

        Returns:
            Updated corpus response
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if chunking_config is not None:
            payload["chunking_config"] = chunking_config
        data = await self._request(
            "PATCH", f"/v1/corpora/{corpus_id}", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "CorpusResponse")

    async def delete_corpus(
        self,
        corpus_id: str,
        *,
        confirm: bool = False,
        force: bool = False,
        request_options: RequestOptions | None = None,
    ) -> CorpusDeleteResponse:
        """Delete a corpus and its associated data.

        This is an irreversible operation.  You must pass ``confirm=True``
        to acknowledge this and proceed.

        Args:
            corpus_id: Unique identifier of the corpus to delete.
            confirm: Safety guard -- must be ``True`` to execute the
                deletion.  Raises ``ConfirmationRequiredError`` when ``False``.
            force: If ``True``, purge dependent corpus resources during
                deletion.

        Returns:
            Confirmation of the deletion.

        Raises:
            ConfirmationRequiredError: If *confirm* is not ``True``.
            NotFoundError: If the corpus does not exist.
            ConflictError: If *force* is ``False`` and the corpus has
                active resources.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        if not confirm:
            raise ConfirmationRequiredError("corpus", corpus_id)
        data = await self._request(
            "DELETE",
            f"/v1/corpora/{corpus_id}",
            params={"force": force},
            request_options=request_options,
        )
        return self._maybe_validate(data, "CorpusDeleteResponse")
