"""Async authentication resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

import warnings
from typing import Any

from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.async_resources._mixin_base import AsyncRequesterMixin
from sdk.types import (
    ApiKeyCreateResponse,
    ApiKeyListResponse,
    ApiKeyRevokeResponse,
    ApiKeyRotateResponse,
    WhoAmIResponse,
)


class AsyncAuthMixin(AsyncRequesterMixin):
    async def create_api_key(
        self,
        org_id: str,
        name: str,
        scopes: dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> ApiKeyCreateResponse:
        """Create a new API key for the given organisation.

        Args:
            org_id: Organisation that will own the key.
            name: Human-readable name for the key.
            scopes: Optional scope restrictions for the key.

        Returns:
            The newly created API key, including the raw secret (shown only once).

        Raises:
            Knowledge2Error: If the API request fails.
        """
        org_id = require_str(org_id, "org_id")
        payload: dict[str, Any] = {"org_id": org_id, "name": name}
        if scopes is not None:
            payload["scopes"] = scopes
        data = await self._request(
            "POST", "/v1/auth/api-keys", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "ApiKeyCreateResponse")

    async def list_api_keys(
        self, *, request_options: RequestOptions | None = None
    ) -> ApiKeyListResponse:
        """List all API keys visible to the current credentials.

        Returns:
            A list of API key metadata objects.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        data = await self._request("GET", "/v1/auth/api-keys", request_options=request_options)
        return self._maybe_validate(data, "ApiKeyListResponse")

    async def revoke_api_key(
        self,
        key_id: str,
        request_options: RequestOptions | None = None,
    ) -> ApiKeyRevokeResponse:
        """Revoke an API key so it can no longer be used for authentication.

        Args:
            key_id: Unique identifier of the API key to revoke.

        Returns:
            Confirmation of the revocation.

        Raises:
            NotFoundError: If the key does not exist.
            Knowledge2Error: If the API request fails.
        """
        key_id = require_str(key_id, "key_id")
        data = await self._request(
            "POST", f"/v1/auth/api-keys/{key_id}:revoke", request_options=request_options
        )
        return self._maybe_validate(data, "ApiKeyRevokeResponse")

    async def rotate_api_key(
        self,
        key_id: str,
        request_options: RequestOptions | None = None,
    ) -> ApiKeyRotateResponse:
        """Rotate an API key, generating a new secret and invalidating the old one.

        Args:
            key_id: Unique identifier of the API key to rotate.

        Returns:
            The rotated key with the new raw secret (shown only once).

        Raises:
            NotFoundError: If the key does not exist.
            Knowledge2Error: If the API request fails.
        """
        key_id = require_str(key_id, "key_id")
        data = await self._request(
            "POST", f"/v1/auth/api-keys/{key_id}:rotate", request_options=request_options
        )
        return self._maybe_validate(data, "ApiKeyRotateResponse")

    async def get_whoami(self, *, request_options: RequestOptions | None = None) -> WhoAmIResponse:
        """Return information about the current API key.

        Returns:
            A dict containing ``org_id``, ``key_id``, ``name``,
            ``scopes``, and other metadata for the authenticated key.
        """
        data = await self._request("GET", "/v1/auth/whoami", request_options=request_options)
        return self._maybe_validate(data, "WhoAmIResponse")

    async def fetch_whoami(
        self, *, request_options: RequestOptions | None = None
    ) -> WhoAmIResponse:
        """Return information about the current API key.

        .. deprecated::
            Use :meth:`get_whoami` instead.
        """
        warnings.warn(
            "fetch_whoami() is deprecated, use get_whoami() instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self.get_whoami()
