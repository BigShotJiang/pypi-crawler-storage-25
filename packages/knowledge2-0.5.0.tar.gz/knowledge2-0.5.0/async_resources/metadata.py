"""Async metadata discovery resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.async_resources._mixin_base import AsyncRequesterMixin


class AsyncMetadataMixin(AsyncRequesterMixin):
    """Async metadata discovery operations."""

    async def discover_metadata(
        self,
        corpus_id: str,
        *,
        refresh: bool = False,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Discover metadata fields available in a corpus.

        Returns distinct metadata keys with inferred types, value
        distributions, and basic statistics.

        Args:
            corpus_id: Corpus ID to discover metadata for.
            refresh: Force cache refresh (bypass cached results).

        Returns:
            Discovery response with fields, types, and stats.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        params: dict[str, Any] = {}
        if refresh:
            params["refresh"] = "true"
        data = await self._request(
            "GET",
            f"/v1/corpora/{corpus_id}/metadata/discover",
            params=params,
            request_options=request_options,
        )
        return data
