"""Async organisation resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._request_options import RequestOptions
from sdk.async_resources._mixin_base import AsyncRequesterMixin
from sdk.types import OrgResponse


class AsyncOrgsMixin(AsyncRequesterMixin):
    async def create_org(
        self,
        name: str,
        contact_email: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> OrgResponse:
        """Create a new organisation.

        Args:
            name: Display name for the organisation.
            contact_email: Optional contact email address for the org.

        Returns:
            The newly created organisation record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        payload: dict[str, Any] = {"name": name}
        if contact_email is not None:
            payload["contact_email"] = contact_email
        data = await self._request(
            "POST", "/v1/orgs", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "OrgResponse")
