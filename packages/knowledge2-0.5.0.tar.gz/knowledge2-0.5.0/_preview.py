"""Decorator for marking SDK resource classes as preview features."""

from __future__ import annotations

import functools
import inspect
import warnings
from typing import Any, TypeVar

_warned: set[str] = set()

_T = TypeVar("_T", bound=type)


def preview_resource(cls: _T) -> _T:
    """Class decorator that wraps public methods to emit a one-shot RuntimeWarning.

    The warning fires once per method name per process, alerting callers
    that the resource requires a server-side feature flag.

    Properties and private/dunder methods are left untouched.
    """
    for name, attr in list(vars(cls).items()):
        if name.startswith("_"):
            continue
        if isinstance(attr, (property, classmethod, staticmethod)):
            continue
        if not callable(attr):
            continue

        fn = attr

        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(
                *args: Any, _fn: Any = fn, _name: str = name, **kwargs: Any
            ) -> Any:
                key = f"{_fn.__qualname__}"
                if key not in _warned:
                    _warned.add(key)
                    warnings.warn(
                        f"{_name}() is a preview feature and may not be available "
                        f"in all environments. The underlying API requires a "
                        f"feature flag to be enabled."
                        f" Visit https://console.knowledge2.ai/settings/support"
                        f" to request access.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                return await _fn(*args, **kwargs)

            setattr(cls, name, async_wrapper)
        else:

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, _fn: Any = fn, _name: str = name, **kwargs: Any) -> Any:
                key = f"{_fn.__qualname__}"
                if key not in _warned:
                    _warned.add(key)
                    warnings.warn(
                        f"{_name}() is a preview feature and may not be available "
                        f"in all environments. The underlying API requires a "
                        f"feature flag to be enabled."
                        f" Visit https://console.knowledge2.ai/settings/support"
                        f" to request access.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                return _fn(*args, **kwargs)

            setattr(cls, name, sync_wrapper)

    return cls
