"""Shared transport helpers for sync and async HTTP clients.

All functions are stateless and side-effect-free (except logging).
They are extracted from :class:`BaseClient` so that
:class:`AsyncBaseClient` can reuse the same logic without duplication.
"""

from __future__ import annotations

import contextlib
import random
from typing import Any

import httpx

from sdk.errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    FeatureNotEnabledError,
    Knowledge2Error,
    NotFoundError,
    PermissionDeniedError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    ValidationError,
)

# Status codes that map to specific error subclasses.
_STATUS_ERROR_MAP: dict[int, type[APIError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
    500: ServerError,
    502: ServerError,
    503: ServerError,
    504: ServerError,
}

# Code-based overrides: (status_code, error_code) -> more specific error class.
_CODE_ERROR_OVERRIDE: dict[tuple[int, str], type[APIError]] = {
    (403, "feature_not_enabled"): FeatureNotEnabledError,
    (429, "quota_exceeded"): QuotaExceededError,
}


def error_from_response(response: httpx.Response) -> APIError:
    """Parse an error response into the appropriate APIError subclass."""
    request_id = response.headers.get("X-Request-Id")
    code: str | None = None
    details: Any = None
    message = response.text or response.reason_phrase or "Unknown error"
    try:
        payload = response.json()
    except ValueError:
        payload = None
    if isinstance(payload, dict):
        error = payload.get("error")
        if isinstance(error, dict):
            code = error.get("code")
            details = error.get("details")
            request_id = error.get("request_id") or request_id
            message = error.get("message") or message
        elif "detail" in payload:
            detail = payload.get("detail")
            if isinstance(detail, str):
                message = detail
            else:
                details = detail
    if request_id:
        message = f"{message} (request_id={request_id})"

    status = response.status_code

    # Build human-readable message from Pydantic validation details for 422
    if status == 422 and isinstance(details, list) and details:
        parts = []
        for item in details:
            if isinstance(item, dict):
                loc = item.get("loc", [])
                field = " → ".join(str(s) for s in loc if s != "body") or "unknown"
                msg = item.get("msg", "invalid")
                parts.append(f"{field} — {msg}")
        if parts:
            message = "Validation failed: " + "; ".join(parts)
            if request_id:
                message = f"{message} (request_id={request_id})"

    error_cls = _STATUS_ERROR_MAP.get(status)
    if error_cls is None:
        error_cls = ServerError if 500 <= status < 600 else APIError

    # Narrow to a more specific subclass when the error code matches.
    if code:
        override_key = (status, code)
        if override_key in _CODE_ERROR_OVERRIDE:
            error_cls = _CODE_ERROR_OVERRIDE[override_key]

    if error_cls is not None and issubclass(error_cls, RateLimitError):
        retry_after_raw = response.headers.get("Retry-After")
        retry_after: float | None = None
        if retry_after_raw is not None:
            with contextlib.suppress(ValueError, TypeError):
                retry_after = float(retry_after_raw)
        return error_cls(
            message,
            status_code=status,
            retry_after=retry_after,
            code=code,
            details=details,
            request_id=request_id,
        )

    return error_cls(
        message,
        status_code=status,
        code=code,
        details=details,
        request_id=request_id,
    )


def calculate_backoff(
    attempt: int,
    error: Knowledge2Error | None,
    *,
    backoff_factor: float = 0.5,
    backoff_max: float = 8.0,
) -> float:
    """Calculate exponential backoff delay with jitter."""
    if isinstance(error, RateLimitError) and error.retry_after is not None:
        return error.retry_after
    base = backoff_factor * (2**attempt)
    jitter = random.random() * 0.25 * base
    return min(base + jitter, backoff_max)


def build_auth_headers(
    *,
    api_key: str | None,
    bearer_token: str | None,
    admin_token: str | None,
    user_agent: str,
    default_headers: dict[str, str],
    extra: dict[str, str] | None = None,
) -> dict[str, str]:
    """Assemble request headers with auth credentials."""
    headers = dict(default_headers)
    extra_headers = extra if extra is not None else {}
    if api_key:
        headers["X-API-Key"] = api_key
        if "X-API-Key" in extra_headers:
            extra_headers["X-API-Key"] = api_key
    if bearer_token:
        bearer_value = f"Bearer {bearer_token}"
        headers["Authorization"] = bearer_value
        if "Authorization" in extra_headers:
            extra_headers["Authorization"] = bearer_value
    if admin_token:
        headers["X-Admin-Token"] = admin_token
        if "X-Admin-Token" in extra_headers:
            extra_headers["X-Admin-Token"] = admin_token
    if user_agent and "User-Agent" not in headers and "User-Agent" not in extra_headers:
        headers["User-Agent"] = user_agent
    if extra_headers:
        headers.update(extra_headers)
    return headers
