"""Per-call request options for the Knowledge2 SDK."""

from __future__ import annotations

from dataclasses import dataclass

from sdk._base import ClientTimeouts

_BLOCKED_HEADERS = frozenset(
    {
        "authorization",
        "content-type",
        "accept",
        "content-length",
        "x-api-key",
        "x-admin-token",
        "user-agent",
    }
)


@dataclass(frozen=True)
class RequestOptions:
    """Per-call overrides for timeout, retry, and passthrough headers.

    Any field left as ``None`` inherits the client-level default.

    Args:
        timeout: Override the client-level :class:`ClientTimeouts` for
            this single call.
        max_retries: Override the client-level ``max_retries`` for this
            single call.
        passthrough_headers: Non-semantic headers (e.g. ``X-Request-ID``,
            ``X-Correlation-ID``) forwarded verbatim.  SDK-managed headers
            (``Authorization``, ``Content-Type``, ``X-API-Key``, etc.)
            raise :class:`ValueError` if supplied.
    """

    timeout: ClientTimeouts | None = None
    max_retries: int | None = None
    passthrough_headers: dict[str, str] | None = None

    def __post_init__(self) -> None:
        if self.passthrough_headers:
            for name in self.passthrough_headers:
                if name.lower() in _BLOCKED_HEADERS:
                    raise ValueError(
                        f"Header {name!r} is managed by the SDK and cannot be "
                        f"set via passthrough_headers. "
                        f"Blocked headers: {sorted(_BLOCKED_HEADERS)}"
                    )
