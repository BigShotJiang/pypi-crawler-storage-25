"""Parameter validation utilities for the Knowledge2 SDK."""

from __future__ import annotations


def require_str(value: str, name: str) -> str:
    """Validate that a required string parameter is non-empty.

    Strips whitespace and raises :class:`ValueError` if the result is
    empty.  Returns the stripped value for use as the canonical form.

    Args:
        value: The parameter value to validate.
        name: The parameter name (used in the error message).

    Returns:
        The stripped, non-empty string.

    Raises:
        ValueError: If *value* is not a string or is empty/whitespace-only.
    """
    stripped = value.strip() if isinstance(value, str) else ""
    if not stripped:
        raise ValueError(f"'{name}' must be a non-empty string, got {value!r}")
    return stripped


def _check_deprecated_system_prompt(
    system_prompt: str | None,
    instructions: str | None,
    *,
    stacklevel: int = 3,
) -> None:
    """Reject ambiguous input and warn about deprecated ``system_prompt`` param."""
    if system_prompt is not None and instructions is not None:
        raise ValueError(
            "Cannot pass both 'system_prompt' and 'instructions'. "
            "Use 'instructions'; 'system_prompt' is deprecated."
        )
    if system_prompt is not None:
        import warnings

        warnings.warn(
            "system_prompt is deprecated, use instructions instead",
            DeprecationWarning,
            stacklevel=stacklevel,
        )
