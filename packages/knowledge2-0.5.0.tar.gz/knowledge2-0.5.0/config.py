"""Typed, validated, immutable configuration for the Knowledge2 SDK.

Requires the ``pydantic-settings`` package::

    pip install knowledge2[config]

Usage::

    from sdk import Knowledge2, K2Config

    # From environment variables (K2_API_KEY, K2_API_HOST, etc.)
    config = K2Config()
    client = Knowledge2(config=config)

    # Explicit values — invalid config raises at construction
    config = K2Config(api_key="k2_...", max_retries=5)
    client = Knowledge2(config=config)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

try:
    from pydantic import Field, PositiveFloat, PositiveInt
    from pydantic_settings import BaseSettings, SettingsConfigDict
except ImportError as _exc:
    raise ImportError(
        "K2Config requires 'pydantic-settings'. Install it with: pip install knowledge2[config]"
    ) from _exc


class K2Config(BaseSettings):
    """Frozen, validated configuration for :class:`~sdk.client.Knowledge2`.

    Populated from environment variables with the ``K2_`` prefix
    (e.g. ``K2_API_KEY``, ``K2_API_HOST``), or passed directly.

    Invalid values (negative timeouts, unknown keys) raise a
    :class:`pydantic.ValidationError` at construction time — not at
    first request.

    The object is **frozen** after creation; mutating fields raises an
    error.
    """

    api_host: str = Field(default="https://api.knowledge2.ai")
    api_key: str | None = Field(default=None, repr=False)
    org_id: str | None = Field(default=None)
    bearer_token: str | None = Field(default=None, repr=False)
    admin_token: str | None = Field(default=None, repr=False)
    max_retries: PositiveInt = Field(default=2)
    timeout_connect: PositiveFloat | None = Field(default=5.0)
    timeout_read: PositiveFloat | None = Field(default=60.0)
    timeout_write: PositiveFloat | None = Field(default=30.0)
    max_connections: PositiveInt = Field(default=20)
    max_keepalive_connections: PositiveInt = Field(default=10)

    model_config = SettingsConfigDict(
        env_prefix="K2_",
        frozen=True,
        extra="forbid",
    )

    @classmethod
    def from_file(cls, path: str | Path, **overrides: Any) -> K2Config:
        """Load configuration from a JSON or YAML file.

        YAML support requires ``PyYAML`` (install via
        ``pip install knowledge2[yaml]``).

        Explicit *overrides* take precedence over file values.

        Args:
            path: Path to a JSON or YAML configuration file.
            **overrides: K2Config field values that override the file
                contents (e.g. ``api_key="k2_..."``).  Only config
                field names are accepted.

        Returns:
            A frozen :class:`K2Config` instance.
        """
        p = Path(path).expanduser()
        raw = p.read_text(encoding="utf-8")

        suffix = p.suffix.lower()
        if suffix in {".yaml", ".yml"}:
            try:
                import yaml  # type: ignore[import-untyped]
            except ImportError as exc:
                raise ImportError(
                    "YAML config requires 'PyYAML'. Install it with: pip install knowledge2[yaml]"
                ) from exc
            data: dict[str, Any] = yaml.safe_load(raw) or {}
        else:
            data = json.loads(raw)

        if not isinstance(data, dict):
            raise TypeError(
                f"Config file must contain a JSON/YAML mapping, got {type(data).__name__}"
            )
        data.update(overrides)
        return cls(**data)

    @classmethod
    def from_profile(
        cls,
        name: str,
        path: str | Path | None = None,
        **overrides: Any,
    ) -> K2Config:
        """Load a named profile from a multi-profile config file.

        The file must contain a top-level mapping where each key is a
        profile name and each value is a config dict::

            # ~/.k2/config.yaml
            default:
              api_key: k2_prod_...
            staging:
              api_host: https://staging.api.knowledge2.ai
              api_key: k2_stg_...

        Args:
            name: The profile key to load.
            path: Config file path.  Defaults to ``~/.k2/config.yaml``
                (falls back to ``~/.k2/config.json``).
            **overrides: K2Config field values that override the
                profile contents.  Only config field names are accepted.

        Returns:
            A frozen :class:`K2Config` instance.

        Raises:
            FileNotFoundError: If no config file is found.
            KeyError: If the profile name is not in the file.
        """
        if path is not None:
            resolved = Path(path).expanduser()
        else:
            base = Path.home() / ".k2"
            yaml_path = base / "config.yaml"
            yml_path = base / "config.yml"
            json_path = base / "config.json"
            if yaml_path.exists():
                resolved = yaml_path
            elif yml_path.exists():
                resolved = yml_path
            elif json_path.exists():
                resolved = json_path
            else:
                raise FileNotFoundError(
                    f"No config file found at {yaml_path}, {yml_path}, or {json_path}"
                )

        raw = resolved.read_text(encoding="utf-8")
        suffix = resolved.suffix.lower()
        if suffix in {".yaml", ".yml"}:
            try:
                import yaml
            except ImportError as exc:
                raise ImportError(
                    "YAML config requires 'PyYAML'. Install it with: pip install knowledge2[yaml]"
                ) from exc
            all_profiles: dict[str, Any] = yaml.safe_load(raw) or {}
        else:
            all_profiles = json.loads(raw)

        if not isinstance(all_profiles, dict):
            raise TypeError(
                f"Config file must contain a mapping of profiles, got {type(all_profiles).__name__}"
            )
        if name not in all_profiles:
            raise KeyError(
                f"Profile '{name}' not found. Available profiles: {', '.join(all_profiles.keys())}"
            )

        data = dict(all_profiles[name])
        data.update(overrides)
        return cls(**data)
