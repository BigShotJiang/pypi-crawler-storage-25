"""Async pagination primitives for the Knowledge2 SDK."""

from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Generic, TypeVar

from sdk._paging import Page

T = TypeVar("T")


class AsyncPager(Generic[T]):
    """Async stateful paginator that lazily fetches pages."""

    def __init__(
        self,
        fetch_page: Callable[[int, int], Awaitable[tuple[list[T], int]]],
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> None:
        self._fetch_page = fetch_page
        self._limit = limit
        self._offset = offset
        self._exhausted = False
        self._first_page: Page[T] | None = None
        self._first_page_consumed = False

    async def get_total(self) -> int:
        """Total number of items across all pages.

        Lazily fetches the first page if not yet fetched.
        """
        if self._first_page is None:
            items, total = await self._fetch_page(self._offset, self._limit)
            self._first_page = Page(
                items=items, total=total, offset=self._offset, limit=self._limit
            )
        return self._first_page.total

    def _advance(self, page: Page[T]) -> None:
        """Update offset or mark exhausted after consuming a page."""
        if len(page.items) < self._limit or (
            page.total > len(page.items) and self._offset + self._limit >= page.total
        ):
            self._exhausted = True
        else:
            self._offset += self._limit

    async def next_page(self) -> Page[T] | None:
        """Fetch the next page. Returns None when exhausted."""
        if self._exhausted:
            return None
        # Return cached first page if it hasn't been consumed yet
        if self._first_page is not None and not self._first_page_consumed:
            self._first_page_consumed = True
            self._advance(self._first_page)
            return self._first_page
        items, total = await self._fetch_page(self._offset, self._limit)
        page = Page(items=items, total=total, offset=self._offset, limit=self._limit)
        if self._first_page is None:
            self._first_page = page
            self._first_page_consumed = True
        self._advance(page)
        return page

    async def iter_pages(self) -> AsyncIterator[Page[T]]:
        """Iterate over all pages."""
        while True:
            page = await self.next_page()
            if page is None:
                break
            yield page
            if not page.items:
                break

    def __aiter__(self) -> AsyncIterator[T]:
        """Item-level iteration across all pages."""
        return self._item_iterator()

    async def _item_iterator(self) -> AsyncIterator[T]:
        async for page in self.iter_pages():
            for item in page.items:
                yield item
