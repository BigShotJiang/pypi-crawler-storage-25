from setuptools import setup, find_packages

exec(open('deep_ensembles_pytorch/version.py').read())

setup(
    name = 'deep-ensembles-pytorch',
    packages = find_packages(),
    version = __version__,
    license = 'MIT',
    description = 'Deep Ensembles - Pytorch',
    long_description = open('README.md').read(),
    long_description_content_type = 'text/markdown',
    author = 'Phil Wang',
    author_email = 'lucidrains@gmail.com',
    url = 'https://github.com/lucidrains/deep-ensembles-pytorch',
    keywords = [
        'artificial intelligence',
        'deep learning',
        'uncertainty estimation',
        'ensemble methods',
        'bayesian deep learning',
    ],
    install_requires = [
        'accelerate',
        'einops>=0.7',
        'ema-pytorch>=0.4.2',
        'torch>=2.0',
        'tqdm',
    ],
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
    ],
)
