import math
from pathlib import Path
from functools import partial
from collections import namedtuple
from multiprocessing import cpu_count

import torch
from torch import nn, einsum
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR

from einops import rearrange, reduce, repeat
from einops.layers.torch import Rearrange

from tqdm.auto import tqdm
from ema_pytorch import EMA
from accelerate import Accelerator

# ──────────────────────────────────────────────
# constants
# ──────────────────────────────────────────────

EnsemblePrediction = namedtuple('EnsemblePrediction', ['mean', 'variance', 'probs'])
MemberOutput = namedtuple('MemberOutput', ['mean', 'log_var'])

# ──────────────────────────────────────────────
# helpers
# ──────────────────────────────────────────────

def exists(x):
    return x is not None

def default(val, d):
    if exists(val):
        return val
    return d() if callable(d) else d

def identity(t, *args, **kwargs):
    return t

def cycle(dl):
    while True:
        for data in dl:
            yield data

def num_to_groups(num, divisor):
    groups = num // divisor
    remainder = num % divisor
    arr = [divisor] * groups
    if remainder > 0:
        arr.append(remainder)
    return arr

def cast_tuple(t, length = 1):
    if isinstance(t, tuple):
        return t
    return ((t,) * length)

def divisible_by(numer, denom):
    return (numer % denom) == 0

# ──────────────────────────────────────────────
# small helper modules
# ──────────────────────────────────────────────

class RMSNorm(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.scale = dim ** 0.5
        self.g = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        return F.normalize(x, dim = -1) * self.g * self.scale


class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x):
        return self.fn(x) + x


def MLP(dim_in, dim_out, *, hidden_dim = None, depth = 3, norm = True):
    """
    Standard feedforward network with optional residual layers.
    Eq. (1) in paper: f_θ : R^d → R^2  (mean, log-var for regression)
    """
    hidden_dim = default(hidden_dim, dim_in * 4)
    layers = []

    for i in range(depth):
        is_first = i == 0
        is_last  = i == (depth - 1)

        in_dim  = dim_in    if is_first else hidden_dim
        out_dim = dim_out   if is_last  else hidden_dim

        layers.append(nn.Linear(in_dim, out_dim))
        if not is_last:
            if norm:
                layers.append(RMSNorm(out_dim))
            layers.append(nn.SiLU())

    return nn.Sequential(*layers)

# ──────────────────────────────────────────────
# ensemble member — regression head
# ──────────────────────────────────────────────

class RegressionMember(nn.Module):
    """
    Single ensemble member for regression.
    Outputs Gaussian parameters (μ, σ²) per eq. (3) in the paper.
    The variance is parameterised as log σ² and softplus-activated
    to ensure positivity, following Nix & Weigend (1994).
    """
    def __init__(
        self,
        dim_in,
        dim_out = 1,
        *,
        hidden_dim = None,
        depth = 3,
        min_variance = 1e-6,
    ):
        super().__init__()
        hidden_dim = default(hidden_dim, 100)
        self.min_variance = min_variance

        self.backbone = MLP(dim_in, hidden_dim, hidden_dim = hidden_dim, depth = depth - 1, norm = True)
        self.mean_head    = nn.Linear(hidden_dim, dim_out)
        self.log_var_head = nn.Linear(hidden_dim, dim_out)

    def forward(self, x):
        h = self.backbone(x)
        mean    = self.mean_head(h)
        log_var = self.log_var_head(h)
        # softplus to guarantee σ² > 0, then clamp
        variance = F.softplus(log_var) + self.min_variance
        return MemberOutput(mean = mean, log_var = variance.log())


class ClassificationMember(nn.Module):
    """
    Single ensemble member for classification.
    Outputs class logits; softmax is applied at ensemble-aggregation time.
    """
    def __init__(
        self,
        dim_in,
        num_classes,
        *,
        hidden_dim = None,
        depth = 3,
    ):
        super().__init__()
        hidden_dim = default(hidden_dim, 100)

        self.net = MLP(dim_in, num_classes, hidden_dim = hidden_dim, depth = depth, norm = True)

    def forward(self, x):
        return self.net(x)   # logits

# ──────────────────────────────────────────────
# losses
# ──────────────────────────────────────────────

def gaussian_nll_loss(mean, log_var, target):
    """
    Proper scoring rule — Gaussian NLL.
    Eq. (3): L(θ) = − log N(y; μ_θ(x), σ²_θ(x))
           = 0.5 * [log σ² + (y − μ)² / σ²]  + const.
    """
    var = log_var.exp()
    return 0.5 * (log_var + (target - mean).pow(2) / var).mean()


def adversarial_input(model, x, target, loss_fn, *, eps = 0.01):
    """
    Fast Gradient Sign Method (FGSM) perturbation.
    Eq. (5): x̃ = x + ε · sign(∇_x L(θ, x, y))
    Used optionally to smooth the predictive distributions.
    """
    x_adv = x.detach().clone().requires_grad_(True)
    loss  = loss_fn(model, x_adv, target)
    loss.backward()
    with torch.no_grad():
        x_adv = x_adv + eps * x_adv.grad.sign()
    return x_adv.detach()

# ──────────────────────────────────────────────
# deep ensemble — regression
# ──────────────────────────────────────────────

class DeepEnsemble(nn.Module):
    """
    Deep Ensemble for uncertainty-aware regression.
    Sec. 3 of the paper — M independently trained networks,
    each predicting (μ_m, σ²_m); mixture of Gaussians aggregation.

    Aggregate mean:     μ* = (1/M) Σ_m μ_m
    Aggregate variance: σ*² = (1/M) Σ_m (σ²_m + μ²_m) − μ*²
    """
    def __init__(
        self,
        dim_in,
        dim_out = 1,
        *,
        num_members = 5,
        hidden_dim = 100,
        depth = 3,
        use_adversarial_training = True,
        adversarial_eps = 0.01,
        min_variance = 1e-6,
    ):
        super().__init__()
        self.num_members = num_members
        self.use_adversarial_training = use_adversarial_training
        self.adversarial_eps = adversarial_eps

        self.members = nn.ModuleList([
            RegressionMember(
                dim_in,
                dim_out,
                hidden_dim = hidden_dim,
                depth = depth,
                min_variance = min_variance,
            )
            for _ in range(num_members)
        ])

    def member_loss(self, member, x, target):
        out = member(x)
        return gaussian_nll_loss(out.mean, out.log_var, target)

    def forward(self, x, target = None):
        if exists(target):
            # ── training: return total loss across members ──
            total_loss = 0.
            for member in self.members:
                loss = self.member_loss(member, x, target)

                if self.use_adversarial_training and self.training:
                    x_adv = adversarial_input(
                        member, x, target,
                        loss_fn = lambda m, xi, yi: self.member_loss(m, xi, yi),
                        eps = self.adversarial_eps,
                    )
                    loss = 0.5 * loss + 0.5 * self.member_loss(member, x_adv, target)

                total_loss = total_loss + loss

            return total_loss / self.num_members

        # ── inference: mixture-of-Gaussians aggregation ──
        means, vars_ = [], []
        with torch.no_grad():
            for member in self.members:
                out = member(x)
                means.append(out.mean)
                vars_.append(out.log_var.exp())

        # stack: (M, B, dim_out)
        means = torch.stack(means)
        vars_ = torch.stack(vars_)

        mu_star  = means.mean(dim = 0)
        var_star = (vars_ + means.pow(2)).mean(dim = 0) - mu_star.pow(2)

        return EnsemblePrediction(mean = mu_star, variance = var_star, probs = None)

    def sample_predictions(self, x):
        """Return individual member predictions (useful for visualising spread)."""
        preds = []
        with torch.no_grad():
            for member in self.members:
                out = member(x)
                preds.append(MemberOutput(mean = out.mean, log_var = out.log_var))
        return preds

# ──────────────────────────────────────────────
# deep ensemble — classification
# ──────────────────────────────────────────────

class DeepEnsembleClassifier(nn.Module):
    """
    Deep Ensemble for uncertainty-aware classification.
    Sec. 3.3 — M independently trained softmax classifiers.
    Aggregate: p*(y|x) = (1/M) Σ_m p_m(y|x)
    """
    def __init__(
        self,
        dim_in,
        num_classes,
        *,
        num_members = 5,
        hidden_dim = 100,
        depth = 3,
    ):
        super().__init__()
        self.num_members  = num_members
        self.num_classes  = num_classes

        self.members = nn.ModuleList([
            ClassificationMember(dim_in, num_classes, hidden_dim = hidden_dim, depth = depth)
            for _ in range(num_members)
        ])

    def forward(self, x, target = None):
        if exists(target):
            # target: (B,) long
            total_loss = 0.
            for member in self.members:
                logits = member(x)
                total_loss = total_loss + F.cross_entropy(logits, target)
            return total_loss / self.num_members

        # ── inference ──
        probs_list = []
        with torch.no_grad():
            for member in self.members:
                probs_list.append(F.softmax(member(x), dim = -1))

        # (M, B, C) → average over M
        probs = torch.stack(probs_list).mean(dim = 0)

        # predictive entropy as uncertainty proxy
        entropy = -(probs * (probs + 1e-9).log()).sum(dim = -1)

        return EnsemblePrediction(mean = None, variance = entropy.unsqueeze(-1), probs = probs)

# ──────────────────────────────────────────────
# dataset helper
# ──────────────────────────────────────────────

class TensorDataset(Dataset):
    def __init__(self, X, y):
        assert len(X) == len(y)
        self.X = X
        self.y = y

    def __len__(self):
        return len(self.X)

    def __getitem__(self, i):
        return self.X[i], self.y[i]

# ──────────────────────────────────────────────
# Trainer
# ──────────────────────────────────────────────

class Trainer:
    """
    Handles multi-GPU / mixed-precision training via 🤗 Accelerate.
    Each ensemble member is trained with identical data but different
    random initialisations — no special data splitting required (Sec. 3).
    """
    def __init__(
        self,
        ensemble,
        dataset,
        *,
        train_batch_size = 64,
        train_lr = 1e-3,
        train_num_steps = 10_000,
        weight_decay = 0.,
        lr_scheduler = True,
        ema_decay = 0.995,
        ema_update_every = 10,
        amp = False,
        results_folder = './results',
        save_every = 1000,
    ):
        self.accelerator = Accelerator(mixed_precision = 'fp16' if amp else 'no')

        self.ensemble   = ensemble
        self.ema        = EMA(ensemble, beta = ema_decay, update_every = ema_update_every)
        self.results_folder = Path(results_folder)
        self.results_folder.mkdir(exist_ok = True, parents = True)

        self.batch_size      = train_batch_size
        self.train_num_steps = train_num_steps
        self.save_every      = save_every
        self.step            = 0

        dl = DataLoader(dataset, batch_size = train_batch_size, shuffle = True,
                        num_workers = 0, pin_memory = True)

        self.opt = Adam(ensemble.parameters(), lr = train_lr, weight_decay = weight_decay)
        self.scheduler = CosineAnnealingLR(self.opt, T_max = train_num_steps) if lr_scheduler else None

        self.ensemble, self.opt, self.dl = self.accelerator.prepare(ensemble, self.opt, dl)
        self.ema.to(self.accelerator.device)

        self.dl = cycle(self.dl)

    @property
    def device(self):
        return self.accelerator.device

    def save(self, milestone):
        if not self.accelerator.is_local_main_process:
            return
        data = {
            'step'     : self.step,
            'model'    : self.accelerator.get_state_dict(self.ensemble),
            'ema'      : self.ema.state_dict(),
            'opt'      : self.opt.state_dict(),
            'scheduler': self.scheduler.state_dict() if exists(self.scheduler) else None,
        }
        torch.save(data, str(self.results_folder / f'model-{milestone}.pt'))

    def load(self, milestone):
        device = self.accelerator.device
        data   = torch.load(str(self.results_folder / f'model-{milestone}.pt'), map_location = device)

        ensemble = self.accelerator.unwrap_model(self.ensemble)
        ensemble.load_state_dict(data['model'])

        self.step = data['step']
        self.opt.load_state_dict(data['opt'])
        self.ema.load_state_dict(data['ema'])

        if exists(self.scheduler) and exists(data['scheduler']):
            self.scheduler.load_state_dict(data['scheduler'])

    def train(self):
        with tqdm(initial = self.step, total = self.train_num_steps,
                  disable = not self.accelerator.is_main_process) as pbar:

            while self.step < self.train_num_steps:
                self.ensemble.train()
                X, y = next(self.dl)

                with self.accelerator.autocast():
                    loss = self.ensemble(X, y)

                self.accelerator.backward(loss)
                self.accelerator.clip_grad_norm_(self.ensemble.parameters(), 1.0)

                pbar.set_description(f'loss: {loss.item():.4f}')

                self.opt.step()
                self.opt.zero_grad()

                if exists(self.scheduler):
                    self.scheduler.step()

                self.step += 1
                self.ema.update()

                if divisible_by(self.step, self.save_every):
                    milestone = self.step // self.save_every
                    self.save(milestone)

                pbar.update(1)

        self.accelerator.print('training complete')
