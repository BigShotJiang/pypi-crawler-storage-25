"""Twitter MCP Server - twikit-based, no API key needed."""

import argparse
import json
import os
import re
import time
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from pathlib import Path

import httpx
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from twitter_mcp._vendor.twikit import Client
from twitter_mcp._vendor.twikit.errors import NotFound, TooManyRequests

mcp = FastMCP("twitter")

# Cookies 路径: 环境变量 > 默认路径
COOKIES_PATH = Path(
    os.environ.get(
        "TWITTER_COOKIES",
        os.path.expanduser("~/.config/twitter-mcp/cookies.json"),
    )
)

# Matches /i/article/<digits> in any twitter.com / x.com URL.
_ARTICLE_URL_RE = re.compile(r"/i/article/(\d+)")
_SYNDICATION_URL = "https://cdn.syndication.twimg.com/tweet-result"
_GRAPHQL_BASE = "https://x.com/i/api/graphql"

# Article reader (issue #10) — two-hop flow.
#
# `ArticleEntityResultByRestId` (the op 0.1.8 used) is X's *editor* op:
# it only returns content for articles you authored. The public reader has
# no dedicated GraphQL operation; instead, the X web client takes two hops:
#
#   1. ArticleRedirectScreenQuery resolves the article rest_id to the
#      underlying tweet rest_id (the article body lives on a tweet).
#   2. TweetResultByRestId fetches that tweet with the article fieldToggles
#      enabled, exposing the body at
#      `.article.article_results.result.plain_text`.
#
# Refresh the queryId the same way every other twikit Endpoint constant is
# refreshed when X rotates a hash (curl `bundle.Articles.*.js` from
# `abs.twimg.com/responsive-web/client-web/`, no auth required).
_ARTICLE_REDIRECT_QUERY_ID = "zrSRXJmE1vj37AUmkh2oGg"
_ARTICLE_REDIRECT_OP_NAME = "ArticleRedirectScreenQuery"


async def _get_client() -> Client:
    """Create an authenticated twikit client."""
    cookies = json.loads(COOKIES_PATH.read_text())
    client = Client("en")
    client.set_cookies({"auth_token": cookies["auth_token"], "ct0": cookies["ct0"]})
    return client


def _parse_article_url_or_id(value: str | None) -> str | None:
    """Return the article rest_id if `value` is an /i/article/<id> URL, else None.

    Bare numeric IDs are NOT treated as articles — article and tweet IDs share
    the same numeric shape, and we cannot distinguish them without an HTTP call.
    """
    if not value:
        return None
    m = _ARTICLE_URL_RE.search(value)
    return m.group(1) if m else None


def _extract_tweet_id(value: str) -> str:
    """Strip a tweet URL down to its numeric ID; pass numeric IDs through."""
    if "/" in value:
        return value.rstrip("/").split("/")[-1]
    return value


# ── Tools ──────────────────────────────────────────────


@mcp.tool()
async def send_tweet(text: str, reply_to: str | None = None) -> str:
    """Send a tweet. Optionally reply to a tweet by ID.

    Args:
        text: Tweet content (max 280 chars).
        reply_to: Optional tweet ID to reply to.
    """
    client = await _get_client()
    tweet = await client.create_tweet(text=text, reply_to=reply_to)
    return json.dumps({"id": tweet.id, "text": text, "status": "sent"})


@mcp.tool()
async def get_tweet(tweet_id: str) -> str:
    """Fetch a tweet by ID.

    Args:
        tweet_id: The tweet ID (numeric string) or full URL.
    """
    article_id = _parse_article_url_or_id(tweet_id)
    if article_id is not None:
        raise ToolError(
            f"This is an X Article (id={article_id}), not a tweet. "
            f"Use get_article instead."
        )

    tweet_id = _extract_tweet_id(tweet_id)

    client = await _get_client()
    tweets = await client.get_tweets_by_ids([tweet_id])
    if not tweets or tweets[0] is None:
        raise ToolError(
            f"Tweet {tweet_id} not found. If this is an X Article URL, "
            f"use get_article instead."
        )
    t = tweets[0]
    return json.dumps(
        {
            "id": t.id,
            "author": t.user.screen_name,
            "author_name": t.user.name,
            "text": t.text,
            "created_at": str(t.created_at),
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
    )


@mcp.tool()
async def get_timeline(count: int = 20) -> str:
    """Fetch home timeline tweets.

    Args:
        count: Number of tweets to fetch (default 20).
    """
    client = await _get_client()
    tweets = await client.get_timeline(count=count)
    result = []
    for t in tweets:
        result.append(
            {
                "id": t.id,
                "author": t.user.screen_name,
                "text": t.text[:200],
                "likes": t.favorite_count,
                "retweets": t.retweet_count,
            }
        )
    return json.dumps(result)


@mcp.tool()
async def search_tweets(query: str, count: int = 20, product: str = "Latest") -> str:
    """Search tweets.

    Args:
        query: Search query string.
        count: Number of results (default 20).
        product: "Latest" or "Top" (default "Latest").
    """
    client = await _get_client()
    tweets = await client.search_tweet(query, product=product, count=count)
    result = []
    for t in tweets:
        result.append(
            {
                "id": t.id,
                "author": t.user.screen_name,
                "text": t.text[:200],
                "likes": t.favorite_count,
                "retweets": t.retweet_count,
            }
        )
    return json.dumps(result)


@mcp.tool()
async def like_tweet(tweet_id: str) -> str:
    """Like a tweet by ID.

    Args:
        tweet_id: The tweet ID.
    """
    client = await _get_client()
    await client.favorite_tweet(tweet_id)
    return json.dumps({"tweet_id": tweet_id, "status": "liked"})


@mcp.tool()
async def retweet(tweet_id: str) -> str:
    """Retweet a tweet by ID.

    Args:
        tweet_id: The tweet ID.
    """
    client = await _get_client()
    await client.retweet(tweet_id)
    return json.dumps({"tweet_id": tweet_id, "status": "retweeted"})


@mcp.tool()
async def get_user_tweets(screen_name: str, count: int = 20) -> str:
    """Get recent tweets from a specific user.

    Args:
        screen_name: Twitter username (without @).
        count: Number of tweets to fetch (default 20).
    """
    client = await _get_client()
    user = await client.get_user_by_screen_name(screen_name)
    tweets = await client.get_user_tweets(user.id, tweet_type="Tweets", count=count)
    result = []
    for t in tweets:
        result.append(
            {
                "id": t.id,
                "text": t.text[:200],
                "created_at": str(t.created_at),
                "likes": t.favorite_count,
                "retweets": t.retweet_count,
            }
        )
    return json.dumps(result)


_PAGINATED_MAX_COUNT = 100

_VALID_TREND_CATEGORIES = frozenset(
    {"trending", "for-you", "news", "sports", "entertainment"}
)

_VALID_COMMUNITY_TWEET_TYPES = frozenset({"Top", "Latest", "Media"})


def _require_exactly_one(
    screen_name: str | None, user_id: str | None, *, op: str
) -> None:
    """Enforce exactly-one-of-(screen_name, user_id) input contract.

    Both args optional in the signature so an LLM caller can use whichever
    handle it has, but giving neither (or both) is a tool-level error,
    not a silent fall-through to twikit.
    """
    if not (screen_name or user_id):
        raise ToolError(f"{op} requires either `screen_name` or `user_id`.")
    if screen_name and user_id:
        raise ToolError(
            f"{op} accepts `screen_name` OR `user_id`, not both — got both."
        )


def _user_to_dict(u) -> dict:
    """Compact user dict used in followers / following list outputs.

    Truncates description to 200 chars (matches get_user_tweets / get_timeline
    pattern) so a 100-entry list doesn't blow MAX_MCP_OUTPUT_TOKENS.
    """
    return {
        "id": u.id,
        "screen_name": u.screen_name,
        "name": u.name,
        "description": (u.description or "")[:200],
        "followers_count": u.followers_count,
        "verified": u.verified,
        "is_blue_verified": u.is_blue_verified,
    }


@mcp.tool()
async def get_user_info(
    screen_name: str | None = None, user_id: str | None = None
) -> str:
    """Get a user's profile metadata by screen name OR numeric user ID.

    Caller must provide exactly one of `screen_name` / `user_id`.

    Args:
        screen_name: Twitter username (without @).
        user_id: Twitter numeric user ID.
    """
    _require_exactly_one(screen_name, user_id, op="get_user_info")
    client = await _get_client()
    try:
        if user_id:
            u = await client.get_user_by_id(user_id)
        else:
            u = await client.get_user_by_screen_name(screen_name)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(
            f"User not found: {screen_name or user_id}. Check the spelling / id."
        )

    return json.dumps(
        {
            "id": u.id,
            "screen_name": u.screen_name,
            "name": u.name,
            "description": u.description,
            "created_at": str(u.created_at),
            "followers_count": u.followers_count,
            "following_count": u.following_count,
            "tweets_count": u.statuses_count,
            # `verified` is the legacy gold/grey badge (almost always False
            # on modern X — pre-2023 verification batch). `is_blue_verified`
            # is the X Premium blue check most accounts actually have today.
            # Expose both so callers can pick. (PR #23 review feedback.)
            "verified": u.verified,
            "is_blue_verified": u.is_blue_verified,
            "profile_image_url": u.profile_image_url_https,
            "protected": u.protected,
            "location": u.location,
            "url": u.url,
        }
    )


async def _resolve_user_id(
    client: Client, screen_name: str | None, user_id: str | None
) -> str:
    """Return numeric user_id, resolving from screen_name if needed."""
    if user_id:
        return user_id
    user = await client.get_user_by_screen_name(screen_name)
    return user.id


@mcp.tool()
async def get_user_followers(
    screen_name: str | None = None,
    user_id: str | None = None,
    count: int = 20,
    cursor: str | None = None,
) -> str:
    """Get a user's followers list.

    Note: X aggressively rate-limits follower / following requests — use
    sparingly, paginate via `cursor`, don't loop without backoff.

    Caller must provide exactly one of `screen_name` / `user_id`.

    Args:
        screen_name: Twitter username (without @).
        user_id: Twitter numeric user ID.
        count: Number of followers to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    _require_exactly_one(screen_name, user_id, op="get_user_followers")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )

    client = await _get_client()
    try:
        uid = await _resolve_user_id(client, screen_name, user_id)
        result = await client.get_user_followers(uid, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name or user_id}.")

    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def get_user_following(
    screen_name: str | None = None,
    user_id: str | None = None,
    count: int = 20,
    cursor: str | None = None,
) -> str:
    """Get accounts that a user follows (their following list).

    Note: X aggressively rate-limits follower / following requests — use
    sparingly, paginate via `cursor`, don't loop without backoff.

    Caller must provide exactly one of `screen_name` / `user_id`.

    Args:
        screen_name: Twitter username (without @).
        user_id: Twitter numeric user ID.
        count: Number to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    _require_exactly_one(screen_name, user_id, op="get_user_following")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )

    client = await _get_client()
    try:
        uid = await _resolve_user_id(client, screen_name, user_id)
        result = await client.get_user_following(uid, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name or user_id}.")

    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def follow_user(screen_name: str) -> str:
    """Follow a user by screen name.

    Note: X aggressively rate-limits follow / unfollow — avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    user = await client.get_user_by_screen_name(screen_name)
    await client.follow_user(user.id)
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "followed"}
    )


@mcp.tool()
async def unfollow_user(screen_name: str) -> str:
    """Unfollow a user by screen name.

    Note: X aggressively rate-limits follow / unfollow — avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    user = await client.get_user_by_screen_name(screen_name)
    await client.unfollow_user(user.id)
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "unfollowed"}
    )


@mcp.tool()
async def delete_tweet(tweet_id: str) -> str:
    """Delete a tweet by ID.

    Args:
        tweet_id: The tweet ID to delete.
    """
    client = await _get_client()
    try:
        await client.delete_tweet(tweet_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    return json.dumps({"tweet_id": tweet_id, "status": "deleted"})


@mcp.tool()
async def unfavorite_tweet(tweet_id: str) -> str:
    """Unlike a tweet by ID.

    Args:
        tweet_id: The tweet ID to unlike.
    """
    client = await _get_client()
    try:
        await client.unfavorite_tweet(tweet_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    return json.dumps({"tweet_id": tweet_id, "status": "unliked"})


@mcp.tool()
async def delete_retweet(tweet_id: str) -> str:
    """Un-retweet a tweet by ID.

    Args:
        tweet_id: The tweet ID to un-retweet.
    """
    client = await _get_client()
    try:
        await client.delete_retweet(tweet_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    return json.dumps({"tweet_id": tweet_id, "status": "un-retweeted"})


@mcp.tool()
async def bookmark_tweet(tweet_id: str, folder_id: str | None = None) -> str:
    """Bookmark a tweet. Optionally add it to a bookmark folder.

    Args:
        tweet_id: The tweet ID to bookmark.
        folder_id: Optional bookmark folder ID.
    """
    client = await _get_client()
    try:
        await client.bookmark_tweet(tweet_id, folder_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    result: dict = {"tweet_id": tweet_id, "status": "bookmarked"}
    if folder_id is not None:
        result["folder_id"] = folder_id
    return json.dumps(result)


@mcp.tool()
async def delete_bookmark(tweet_id: str) -> str:
    """Remove a tweet from bookmarks.

    Args:
        tweet_id: The tweet ID to un-bookmark.
    """
    client = await _get_client()
    try:
        await client.delete_bookmark(tweet_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Bookmark for tweet {tweet_id} not found.")
    return json.dumps({"tweet_id": tweet_id, "status": "un-bookmarked"})


@mcp.tool()
async def get_bookmarks(count: int = 20, cursor: str | None = None) -> str:
    """Get bookmarked tweets (paginated).

    Args:
        count: Number of bookmarks to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_bookmarks(count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    tweets = [
        {
            "id": t.id,
            "author": t.user.screen_name,
            "text": t.text[:200],
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
        for t in result
    ]
    return json.dumps(
        {
            "tweets": tweets,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(tweets),
        }
    )


@mcp.tool()
async def get_favoriters(
    tweet_id: str, count: int = 40, cursor: str | None = None
) -> str:
    """Get users who liked a tweet (paginated).

    Args:
        tweet_id: The tweet ID.
        count: Number of users to fetch (default 40, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_favoriters(tweet_id, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def get_retweeters(
    tweet_id: str, count: int = 40, cursor: str | None = None
) -> str:
    """Get users who retweeted a tweet (paginated).

    Args:
        tweet_id: The tweet ID.
        count: Number of users to fetch (default 40, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_retweeters(tweet_id, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} not found.")
    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def search_user(query: str, count: int = 20, cursor: str | None = None) -> str:
    """Search for users by query (paginated).

    Args:
        query: Search query string.
        count: Number of users to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not query.strip():
        raise ToolError("query must not be empty.")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.search_user(query, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def get_trends(category: str = "trending", count: int = 20) -> str:
    """Get trending topics by category.

    Args:
        category: One of "trending", "for-you", "news", "sports", "entertainment"
            (default "trending").
        count: Number of trends to fetch (default 20).
    """
    if category not in _VALID_TREND_CATEGORIES:
        raise ToolError(
            f"category must be one of {sorted(_VALID_TREND_CATEGORIES)}, got: {category!r}"
        )
    if count < 1:
        raise ToolError("count must be >= 1.")
    client = await _get_client()
    try:
        trends = await client.get_trends(category, count=count)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    result = [
        {
            "name": t.name,
            "tweets_count": t.tweets_count,
            "domain_context": t.domain_context,
        }
        for t in trends
    ]
    return json.dumps({"trends": result, "category": category})


@mcp.tool()
async def get_article_preview(tweet_id: str) -> str:
    """Get title/preview/cover of an X Article embedded in a tweet.

    Uses X's public syndication endpoint — no authentication required.

    Args:
        tweet_id: ID (numeric string) or full URL of a tweet that links to an article.
    """
    tweet_id = _extract_tweet_id(tweet_id)
    async with httpx.AsyncClient() as c:
        resp = await c.get(
            _SYNDICATION_URL,
            params={"id": tweet_id, "token": "a"},
            timeout=15,
        )
    resp.raise_for_status()
    data = resp.json()
    article = data.get("article")
    if not article:
        raise ToolError(f"Tweet {tweet_id} does not embed an article.")
    cover = article.get("cover_media", {}).get("media_info", {}).get("original_img_url")
    return json.dumps(
        {
            "rest_id": article["rest_id"],
            "title": article.get("title", ""),
            "preview_text": article.get("preview_text", ""),
            "cover_image": cover,
            "tweet_id": data.get("id_str", tweet_id),
            "author": data.get("user", {}).get("screen_name", ""),
        }
    )


_ARTICLE_FORMATS = ("preview", "plain", "full")


@mcp.tool()
async def get_article(article_id: str, format: str = "plain") -> str:
    """Fetch an X Article (long-form post) by rest_id or URL.

    Two-hop reader flow (issue #10):

      1. `ArticleRedirectScreenQuery` resolves the article rest_id to the
         underlying tweet rest_id.
      2. `TweetResultByRestId` (twikit's existing helper) fetches the tweet
         with article fieldToggles enabled. The body lives at
         `tweet.article.article_results.result`.

    Requires authentication via cookies — same as every other authenticated
    tool here. No env-var setup.

    Args:
        article_id: Article rest_id (numeric string) or full /i/article/<id> URL.
        format: Output shape, one of:
            - "preview" (~1 KB) — rest_id, title, preview_text, cover_image
            - "plain"   (~20 KB, default) — above + plain_text + media URL list
              + lifecycle_state. The LLM-friendly shape.
            - "full"    (~150 KB+) — raw GraphQL payload including the heavy
              content_state rich-block tree. Use only when you need it
              (rich-content rendering, archiving, structure analysis).
    """
    if format not in _ARTICLE_FORMATS:
        raise ToolError(
            f"format must be one of {'/'.join(_ARTICLE_FORMATS)}, got: {format!r}"
        )

    rest_id = _parse_article_url_or_id(article_id) or article_id
    client = await _get_client()

    # ── Hop 1: article rest_id → tweet rest_id ──────────────────────────
    # twikit's transport returns (response_json, raw_response) — see issue #12.
    redirect_url = (
        f"{_GRAPHQL_BASE}/{_ARTICLE_REDIRECT_QUERY_ID}/{_ARTICLE_REDIRECT_OP_NAME}"
    )
    redirect, _ = await client.gql.gql_get(
        redirect_url,
        {"articleEntityId": rest_id},
        {},
    )
    tweet_id = (
        (redirect or {})
        .get("data", {})
        .get("article_result_by_rest_id", {})
        .get("result", {})
        .get("metadata", {})
        .get("tweet_results", {})
        .get("rest_id")
    )
    if not tweet_id:
        raise ToolError(
            f"Article {rest_id} not found "
            f"(deleted, private, or not visible to this account)."
        )

    # ── Hop 2: tweet → article body ─────────────────────────────────────
    tweet_resp, _ = await client.gql.tweet_result_by_rest_id(tweet_id)
    article = (
        (tweet_resp or {})
        .get("data", {})
        .get("tweetResult", {})
        .get("result", {})
        .get("article", {})
        .get("article_results", {})
        .get("result")
    )
    if not article:
        raise ToolError(
            f"Tweet {tweet_id} did not return an article payload "
            f"(article may be unavailable)."
        )

    if format == "full":
        return json.dumps(article, ensure_ascii=False)

    cover = article.get("cover_media", {}).get("media_info", {}).get("original_img_url")

    if format == "preview":
        out = {
            "rest_id": article.get("rest_id"),
            "title": article.get("title"),
            "preview_text": article.get("preview_text", ""),
            "cover_image": cover,
        }
    else:  # "plain"
        # Article media URLs live at media_entities[*].media_info.original_img_url
        # — NOT at the flat media_url_https / media_url that tweet schema uses
        # (issue #16). Drop entries where the URL can't be extracted so callers
        # don't see a list of nulls.
        media = []
        for m in article.get("media_entities") or []:
            url = ((m or {}).get("media_info") or {}).get("original_img_url")
            if url:
                media.append(url)
        out = {
            "rest_id": article.get("rest_id"),
            "title": article.get("title"),
            "preview_text": article.get("preview_text", ""),
            "plain_text": article.get("plain_text", ""),
            "cover_image": cover,
            "media": media,
            "lifecycle_state": article.get("lifecycle_state"),
        }
    return json.dumps(out, ensure_ascii=False)


_VALID_NOTIFICATION_TYPES = frozenset({"All", "Verified", "Mentions"})


@mcp.tool()
async def block_user(screen_name: str) -> str:
    """Block a user by screen name.

    Note: X aggressively rate-limits / risk-scans block + mute. Avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        await client.block_user(user.id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "blocked"}
    )


@mcp.tool()
async def unblock_user(screen_name: str) -> str:
    """Unblock a user by screen name.

    Note: X aggressively rate-limits / risk-scans block + mute. Avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        await client.unblock_user(user.id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "unblocked"}
    )


@mcp.tool()
async def mute_user(screen_name: str) -> str:
    """Mute a user by screen name.

    Note: X aggressively rate-limits / risk-scans block + mute. Avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        await client.mute_user(user.id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "muted"}
    )


@mcp.tool()
async def unmute_user(screen_name: str) -> str:
    """Unmute a user by screen name.

    Note: X aggressively rate-limits / risk-scans block + mute. Avoid bulk usage
    or your account may be temporarily restricted.

    Args:
        screen_name: Twitter username (without @).
    """
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        await client.unmute_user(user.id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")
    return json.dumps(
        {"user_id": user.id, "screen_name": screen_name, "status": "unmuted"}
    )


@mcp.tool()
async def get_notifications(
    notification_type: str = "All",
    count: int = 40,
    cursor: str | None = None,
) -> str:
    """Fetch notifications (paginated).

    Args:
        notification_type: One of "All", "Verified", "Mentions" (default "All").
        count: Number to fetch (default 40, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if notification_type not in _VALID_NOTIFICATION_TYPES:
        raise ToolError(
            f"notification_type must be one of {sorted(_VALID_NOTIFICATION_TYPES)}, "
            f"got: {notification_type!r}"
        )
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_notifications(
            notification_type, count=count, cursor=cursor
        )
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")

    notifications = []
    for n in result:
        entry: dict = {
            "id": n.id,
            "timestamp_ms": n.timestamp_ms,
            "icon": n.icon,
            "message": n.message,
        }
        if n.tweet is not None:
            entry["tweet_id"] = n.tweet.id
        notifications.append(entry)

    return json.dumps(
        {
            "notifications": notifications,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(notifications),
        }
    )


@mcp.tool()
async def send_dm(screen_name: str, text: str, media_id: str | None = None) -> str:
    """Send a direct message to a user by screen name.

    Note: Sends a PRIVATE message. Do not bulk-call. X has aggressive anti-spam
    on DMs and may suspend the account.

    Args:
        screen_name: Twitter username (without @) to send the DM to.
        text: Message content (required, must not be empty).
        media_id: Optional media ID to attach.
    """
    if not text.strip():
        raise ToolError("text must not be empty.")
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        message = await client.send_dm(user.id, text, media_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")
    return json.dumps({"message_id": message.id, "status": "sent"})


@mcp.tool()
async def send_dm_to_group(
    group_id: str, text: str, media_id: str | None = None
) -> str:
    """Send a direct message to a group conversation.

    Note: Sends a PRIVATE message. Do not bulk-call. X has aggressive anti-spam
    on DMs and may suspend the account.

    Args:
        group_id: The group conversation ID.
        text: Message content (required, must not be empty).
        media_id: Optional media ID to attach.
    """
    if not text.strip():
        raise ToolError("text must not be empty.")
    client = await _get_client()
    try:
        message = await client.send_dm_to_group(group_id, text, media_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Group {group_id!r} not found.")
    return json.dumps({"message_id": message.id, "status": "sent"})


@mcp.tool()
async def get_dm_history(screen_name: str, max_id: str | None = None) -> str:
    """Get DM conversation history with a user.

    Note: Retrieves PRIVATE messages. Do not bulk-call. X has aggressive
    anti-spam on DMs and may suspend the account.

    Args:
        screen_name: Twitter username (without @).
        max_id: If specified, retrieves messages older than this ID (for pagination).
            Pass the value from a previous response's `next_cursor` here on the
            next call to walk further back in time.
    """
    client = await _get_client()
    try:
        user = await client.get_user_by_screen_name(screen_name)
        result = await client.get_dm_history(user.id, max_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"User not found: {screen_name}.")

    messages = [
        {
            "id": m.id,
            "text": m.text[:500],
            "sender_id": m.sender_id,
            "recipient_id": m.recipient_id,
            "time": m.time,
        }
        for m in result
    ]
    return json.dumps(
        {
            "messages": messages,
            "next_cursor": getattr(result, "next_cursor", None),
        }
    )


@mcp.tool()
async def delete_dm(message_id: str) -> str:
    """Delete a direct message by ID.

    Note: Deletes a PRIVATE message. Do not bulk-call. X has aggressive
    anti-spam on DMs and may suspend the account.

    Args:
        message_id: The message ID to delete.
    """
    client = await _get_client()
    try:
        await client.delete_dm(message_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Message {message_id} not found.")
    return json.dumps({"message_id": message_id, "status": "deleted"})


def _list_to_dict(lst) -> dict:
    """Compact list dict used in list outputs.

    Truncates description to 200 chars (matches _user_to_dict pattern).
    `mode` is "Public" | "Private" in twikit's List model.
    """
    return {
        "id": lst.id,
        "name": lst.name,
        "description": (lst.description or "")[:200],
        "member_count": lst.member_count,
        "subscriber_count": lst.subscriber_count,
        "is_private": lst.mode == "Private",
        "created_at": str(lst.created_at),
    }


def _community_to_dict(c) -> dict:
    """Compact community dict used in community tool outputs.

    Truncates description to 200 chars (matches _user_to_dict / _list_to_dict).
    """
    return {
        "id": c.id,
        "name": c.name,
        "description": (c.description or "")[:200],
        "member_count": c.member_count,
        "is_member": c.is_member,
        "join_policy": c.join_policy,
        "created_at": str(c.created_at),
    }


def _community_member_to_dict(m) -> dict:
    """Compact dict for twikit's CommunityMember (members + moderators).

    CommunityMember is *not* a User — it lacks `description` / `followers_count`.
    Surfaces only the fields actually present on the model.
    """
    return {
        "id": m.id,
        "screen_name": m.screen_name,
        "name": m.name,
        "community_role": m.community_role,
        "verified": m.verified,
        "is_blue_verified": m.is_blue_verified,
        "protected": m.protected,
        "following": m.following,
        "followed_by": m.followed_by,
    }


@mcp.tool()
async def get_list(list_id: str) -> str:
    """Get a Twitter List by ID.

    Args:
        list_id: The list ID.
    """
    client = await _get_client()
    try:
        lst = await client.get_list(list_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"List {list_id} not found.")
    return json.dumps(_list_to_dict(lst))


@mcp.tool()
async def get_lists(count: int = 20, cursor: str | None = None) -> str:
    """Get the authenticated user's Twitter Lists (paginated).

    Args:
        count: Number of lists to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_lists(count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    lists = [_list_to_dict(lst) for lst in result]
    return json.dumps(
        {
            "lists": lists,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(lists),
        }
    )


@mcp.tool()
async def get_list_tweets(
    list_id: str, count: int = 20, cursor: str | None = None
) -> str:
    """Get tweets from a Twitter List (paginated).

    Args:
        list_id: The list ID.
        count: Number of tweets to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_list_tweets(list_id, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"List {list_id} not found.")
    tweets = [
        {
            "id": t.id,
            "author": t.user.screen_name,
            "text": t.text[:200],
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
        for t in result
    ]
    return json.dumps(
        {
            "tweets": tweets,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(tweets),
        }
    )


@mcp.tool()
async def get_list_members(
    list_id: str, count: int = 20, cursor: str | None = None
) -> str:
    """Get members of a Twitter List (paginated).

    Args:
        list_id: The list ID.
        count: Number of members to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_list_members(list_id, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"List {list_id} not found.")
    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def get_list_subscribers(
    list_id: str, count: int = 20, cursor: str | None = None
) -> str:
    """Get subscribers of a Twitter List (paginated).

    Args:
        list_id: The list ID.
        count: Number of subscribers to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_list_subscribers(list_id, count=count, cursor=cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"List {list_id} not found.")
    users = [_user_to_dict(u) for u in result]
    return json.dumps(
        {
            "users": users,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(users),
        }
    )


@mcp.tool()
async def create_list(
    name: str, description: str = "", is_private: bool = False
) -> str:
    """Create a new Twitter List.

    Args:
        name: The name for the new list (required, must not be empty).
        description: Description for the list (default empty).
        is_private: If True, the list is private (default False = public).
    """
    if not name.strip():
        raise ToolError("name must not be empty.")
    client = await _get_client()
    try:
        lst = await client.create_list(name, description, is_private)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    return json.dumps(_list_to_dict(lst))


@mcp.tool()
async def edit_list(
    list_id: str,
    name: str | None = None,
    description: str | None = None,
    is_private: bool | None = None,
) -> str:
    """Edit a Twitter List's metadata.

    At least one of `name`, `description`, or `is_private` must be provided.
    Pass an empty string for `description` to clear it.

    Args:
        list_id: The list ID (required).
        name: New name for the list.
        description: New description (empty string clears it).
        is_private: True to make private, False to make public.
    """
    if name is None and description is None and is_private is None:
        raise ToolError("at least one of name/description/is_private must be provided.")
    client = await _get_client()
    try:
        lst = await client.edit_list(list_id, name, description, is_private)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"List {list_id} not found.")
    return json.dumps(_list_to_dict(lst))


@mcp.tool()
async def add_list_member(
    list_id: str,
    screen_name: str | None = None,
    user_id: str | None = None,
) -> str:
    """Add a user to a Twitter List.

    Caller must provide exactly one of `screen_name` / `user_id`.

    Args:
        list_id: The list ID (required).
        screen_name: Twitter username (without @).
        user_id: Twitter numeric user ID.
    """
    _require_exactly_one(screen_name, user_id, op="add_list_member")
    client = await _get_client()
    try:
        uid = await _resolve_user_id(client, screen_name, user_id)
        lst = await client.add_list_member(list_id, uid)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Not found: list {list_id} or user {screen_name or user_id}.")
    return json.dumps(_list_to_dict(lst))


@mcp.tool()
async def remove_list_member(
    list_id: str,
    screen_name: str | None = None,
    user_id: str | None = None,
) -> str:
    """Remove a user from a Twitter List.

    Caller must provide exactly one of `screen_name` / `user_id`.

    Args:
        list_id: The list ID (required).
        screen_name: Twitter username (without @).
        user_id: Twitter numeric user ID.
    """
    _require_exactly_one(screen_name, user_id, op="remove_list_member")
    client = await _get_client()
    try:
        uid = await _resolve_user_id(client, screen_name, user_id)
        lst = await client.remove_list_member(list_id, uid)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Not found: list {list_id} or user {screen_name or user_id}.")
    return json.dumps(_list_to_dict(lst))


@mcp.tool()
async def create_scheduled_tweet(
    scheduled_at: int,
    text: str = "",
    media_ids: list[str] | None = None,
) -> str:
    """Schedule a tweet to be posted at a future Unix timestamp.

    Scheduled tweets follow X's standard rate limits, no special caveats needed.

    Args:
        scheduled_at: Unix epoch seconds when the tweet should be posted (must be in the future).
        text: Tweet text. At least one of text or media_ids must be provided.
        media_ids: List of media IDs to attach to the scheduled tweet.
    """
    if scheduled_at <= int(time.time()):
        raise ToolError("scheduled_at must be a future Unix timestamp.")
    if not text.strip() and not media_ids:
        raise ToolError(
            "at least one of text or media_ids must be provided (empty tweet)."
        )
    client = await _get_client()
    try:
        tweet_id = await client.create_scheduled_tweet(scheduled_at, text, media_ids)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    return json.dumps(
        {
            "scheduled_tweet_id": tweet_id,
            "scheduled_at": scheduled_at,
            "status": "scheduled",
        }
    )


@mcp.tool()
async def get_scheduled_tweets() -> str:
    """Return all scheduled tweets for the authenticated user.

    Note: returns the FULL list in one call — twikit's API does not paginate
    scheduled tweets. This is fine in practice since X caps scheduled tweets
    per account at a small number.

    Scheduled tweets follow X's standard rate limits, no special caveats needed.
    """
    client = await _get_client()
    try:
        tweets = await client.get_scheduled_tweets()
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    result = [
        {
            "id": t.id,
            "text": t.text[:200],
            "scheduled_at": t.execute_at,
            "state": t.state,
            "media_count": len(t.media),
        }
        for t in tweets
    ]
    return json.dumps({"scheduled_tweets": result, "count": len(result)})


@mcp.tool()
async def delete_scheduled_tweet(scheduled_tweet_id: str) -> str:
    """Delete a scheduled tweet by its scheduled tweet ID.

    Scheduled tweets follow X's standard rate limits, no special caveats needed.

    Args:
        scheduled_tweet_id: The ID of the scheduled tweet (from create_scheduled_tweet
            or get_scheduled_tweets). This is NOT a regular tweet ID.
    """
    if not scheduled_tweet_id:
        raise ToolError("scheduled_tweet_id must be non-empty.")
    client = await _get_client()
    try:
        await client.delete_scheduled_tweet(scheduled_tweet_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Scheduled tweet {scheduled_tweet_id} not found.")
    return json.dumps({"scheduled_tweet_id": scheduled_tweet_id, "status": "deleted"})


@mcp.tool()
async def create_poll(choices: list[str], duration_minutes: int) -> str:
    """Create an X poll and return its card URI.

    X polls have 2-4 choices and a duration in minutes.
    Pass the returned card_uri to send_tweet's poll_uri parameter to attach the poll.

    Args:
        choices: Poll choices (2-4 entries required; each must be non-empty).
        duration_minutes: Poll duration in minutes (must be > 0).
    """
    if len(choices) not in (2, 3, 4):
        raise ToolError(
            "choices must have 2, 3, or 4 entries (X polls allow 2-4 options)."
        )
    if duration_minutes <= 0:
        raise ToolError("duration_minutes must be greater than 0.")
    if duration_minutes > 10_080:
        raise ToolError(
            "duration_minutes cannot exceed 10080 (7 days — X poll maximum)."
        )
    for choice in choices:
        if not choice.strip():
            raise ToolError("all poll choices must be non-empty.")
        if len(choice) > 25:
            raise ToolError(f"poll choice {choice!r} exceeds X's 25-character limit.")
    client = await _get_client()
    try:
        card_uri = await client.create_poll(choices, duration_minutes)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    return json.dumps({"card_uri": card_uri, "status": "created"})


@mcp.tool()
async def vote(
    selected_choice: str,
    card_uri: str,
    tweet_id: str,
    card_name: str,
) -> str:
    """Vote on an X poll.

    X polls have 2-4 choices and a duration in minutes.
    The card_uri and card_name come from the tweet's poll card metadata (obtainable via get_tweet).

    Args:
        selected_choice: The label of the choice to vote for (must be non-empty).
        card_uri: The poll card URI (from the tweet's poll card metadata).
        tweet_id: The ID of the tweet containing the poll.
        card_name: The name of the poll card (from the tweet's poll card metadata).
    """
    if not selected_choice.strip():
        raise ToolError("selected_choice must be non-empty.")
    if not card_uri:
        raise ToolError("card_uri must be non-empty.")
    if not card_name:
        raise ToolError("card_name must be non-empty.")
    if not tweet_id:
        raise ToolError("tweet_id must be non-empty.")
    client = await _get_client()
    try:
        await client.vote(selected_choice, card_uri, tweet_id, card_name)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Tweet {tweet_id} or poll card not found.")
    return json.dumps(
        {"tweet_id": tweet_id, "selected_choice": selected_choice, "status": "voted"}
    )


@mcp.tool()
async def get_community(community_id: str) -> str:
    """Get a Twitter Community by ID.

    Args:
        community_id: The community ID.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    client = await _get_client()
    try:
        community = await client.get_community(community_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    return json.dumps(_community_to_dict(community))


@mcp.tool()
async def search_community(query: str, cursor: str | None = None) -> str:
    """Search for Twitter Communities by query (paginated).

    Note: twikit's search_community does not support a count parameter.

    Args:
        query: Search query string.
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not query.strip():
        raise ToolError("query must not be empty.")
    client = await _get_client()
    try:
        result = await client.search_community(query, cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    communities = [_community_to_dict(c) for c in result]
    return json.dumps(
        {
            "communities": communities,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(communities),
        }
    )


@mcp.tool()
async def get_community_tweets(
    community_id: str,
    tweet_type: str,
    count: int = 40,
    cursor: str | None = None,
) -> str:
    """Get tweets from a Twitter Community (paginated).

    Args:
        community_id: The community ID.
        tweet_type: One of "Top", "Latest", or "Media".
        count: Number of tweets to fetch (default 40, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    if tweet_type not in _VALID_COMMUNITY_TWEET_TYPES:
        raise ToolError(
            f"tweet_type must be one of {sorted(_VALID_COMMUNITY_TWEET_TYPES)}, "
            f"got: {tweet_type!r}"
        )
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_community_tweets(
            community_id, tweet_type, count, cursor
        )
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    tweets = [
        {
            "id": t.id,
            "author": t.user.screen_name,
            "text": t.text[:200],
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
        for t in result
    ]
    return json.dumps(
        {
            "tweets": tweets,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(tweets),
        }
    )


@mcp.tool()
async def get_communities_timeline(count: int = 20, cursor: str | None = None) -> str:
    """Get tweets from communities the authenticated user has joined (paginated).

    Args:
        count: Number of tweets to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_communities_timeline(count, cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    tweets = [
        {
            "id": t.id,
            "author": t.user.screen_name,
            "text": t.text[:200],
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
        for t in result
    ]
    return json.dumps(
        {
            "tweets": tweets,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(tweets),
        }
    )


@mcp.tool()
async def get_community_members(
    community_id: str, count: int = 20, cursor: str | None = None
) -> str:
    """Get members of a Twitter Community (paginated).

    Args:
        community_id: The community ID.
        count: Number of members to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_community_members(community_id, count, cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    members = [_community_member_to_dict(m) for m in result]
    return json.dumps(
        {
            "members": members,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(members),
        }
    )


@mcp.tool()
async def get_community_moderators(
    community_id: str, count: int = 20, cursor: str | None = None
) -> str:
    """Get moderators of a Twitter Community (paginated).

    Args:
        community_id: The community ID.
        count: Number of moderators to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.get_community_moderators(community_id, count, cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    moderators = [_community_member_to_dict(m) for m in result]
    return json.dumps(
        {
            "moderators": moderators,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(moderators),
        }
    )


@mcp.tool()
async def search_community_tweet(
    community_id: str,
    query: str,
    count: int = 20,
    cursor: str | None = None,
) -> str:
    """Search tweets within a Twitter Community (paginated).

    Args:
        community_id: The community ID.
        query: Search query string.
        count: Number of tweets to fetch (default 20, max 100).
        cursor: Pagination cursor from a previous response's `next_cursor`.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    if not query.strip():
        raise ToolError("query must not be empty.")
    if count < 1:
        raise ToolError("count must be >= 1.")
    if count > _PAGINATED_MAX_COUNT:
        raise ToolError(
            f"count exceeds the {_PAGINATED_MAX_COUNT} cap; paginate via `cursor` instead."
        )
    client = await _get_client()
    try:
        result = await client.search_community_tweet(community_id, query, count, cursor)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    tweets = [
        {
            "id": t.id,
            "author": t.user.screen_name,
            "text": t.text[:200],
            "likes": t.favorite_count,
            "retweets": t.retweet_count,
        }
        for t in result
    ]
    return json.dumps(
        {
            "tweets": tweets,
            "next_cursor": getattr(result, "next_cursor", None),
            "count": len(tweets),
        }
    )


@mcp.tool()
async def join_community(community_id: str) -> str:
    """Join a Twitter Community.

    Args:
        community_id: The community ID to join.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    client = await _get_client()
    try:
        community = await client.join_community(community_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    return json.dumps({**_community_to_dict(community), "status": "joined"})


@mcp.tool()
async def leave_community(community_id: str) -> str:
    """Leave a Twitter Community.

    Args:
        community_id: The community ID to leave.
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    client = await _get_client()
    try:
        community = await client.leave_community(community_id)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    return json.dumps({**_community_to_dict(community), "status": "left"})


@mcp.tool()
async def request_to_join_community(
    community_id: str, answer: str | None = None
) -> str:
    """Request to join a Twitter Community.

    For communities with restricted join policies that require moderator
    approval, an `answer` to the join request question may be required.

    Args:
        community_id: The community ID to request to join.
        answer: Optional answer to the join request question (required for
            some communities with moderator approval policy).
    """
    if not community_id:
        raise ToolError("community_id must be non-empty.")
    client = await _get_client()
    try:
        await client.request_to_join_community(community_id, answer)
    except TooManyRequests as e:
        raise ToolError(f"X rate limit exceeded; retry later. ({e})")
    except NotFound:
        raise ToolError(f"Community {community_id} not found.")
    return json.dumps({"community_id": community_id, "status": "request_sent"})


def _get_version() -> str:
    """Read the installed package version, falling back to 'unknown'."""
    try:
        return _pkg_version("twikit-mcp")
    except PackageNotFoundError:
        return "unknown"


def main():
    parser = argparse.ArgumentParser(
        prog="twikit-mcp",
        description="Twitter/X MCP server — twikit-based, no API key needed.",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"twikit-mcp {_get_version()}",
    )
    parser.parse_args()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
