import dataclasses
import datetime
import enum
import hashlib
import re
import typing

import dacite
import yaml

import consts
import odg.filter
import odg.model
import odg.shared_cfg
import rescore.model as rm
import util


class ModelValidationError(ValueError):
    pass


class RescoringSpecificity(enum.Enum):
    GLOBAL = 'global'
    COMPONENT = 'component'
    ARTEFACT = 'artefact'
    SINGLE = 'single'

    def _asint(self, rescoring_scopes):
        if rescoring_scopes is self.GLOBAL:
            return 0
        elif rescoring_scopes is self.COMPONENT:
            return 1
        elif rescoring_scopes is self.ARTEFACT:
            return 2
        elif rescoring_scopes is self.SINGLE:
            return 3
        else:
            raise ValueError(f'unknown {rescoring_scopes=}')

    def __lt__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) < self._asint(other)

    def __le__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) <= self._asint(other)

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) == self._asint(other)

    def __ne__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) != self._asint(other)

    def __gt__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) > self._asint(other)

    def __ge__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._asint(self) >= self._asint(other)


@dataclasses.dataclass
class MinMaxRange:
    min: float
    max: float


@dataclasses.dataclass
class OsIdFindingSelector:
    """
    :param list[str] status:
        List of regexes to determine matching osid findings based on their status.
    """

    status: list[str]


@dataclasses.dataclass
class CryptoFindingSelector:
    """
    :param list[str] ratings:
        List of regexes to determine matching crypto findings based on their rating.
    """

    ratings: list[str]


@dataclasses.dataclass
class GHASFindingSelector:
    """
    :param list[str] resolution:
        List of regexes to determine matching github secret findings.
    """

    resolutions: list[str | None]


@dataclasses.dataclass
class IPFindingSelector:
    policy_violation_ids: list[str]
    labels: list[str]


@dataclasses.dataclass
class LicenseFindingSelector:
    """
    :param list[str] license_names:
        List of regexes to determine matching licenses.
    """

    license_names: list[str]


@dataclasses.dataclass
class MalwareFindingSelector:
    """
    :param list[str] malware_names:
        List of regexes to determine matching malware.
    """

    malware_names: list[str]


@dataclasses.dataclass
class SASTFindingSelector:
    """
    :param list[str] sub_types:
        List of regexes to determine matching missing linter findings.
    """

    sub_types: list[str]


@dataclasses.dataclass
class VulnerabilityFindingSelector:
    """
    :param MinMaxRange cve_score_range:
        Min (including) and max (including) cve score to determine matching CVEs.
    """

    cve_score_range: MinMaxRange


class MetaAllowedProcessingTimes(enum.StrEnum):
    INPUT = 'input'


class RescoringModes(enum.StrEnum):
    MANUAL = 'manual'
    AUTOMATIC = 'automatic'


@dataclasses.dataclass
class FindingCategorisation:
    """
    :param str id:
        Stable identifier for the category (must not change as it will be written into findings as
        well).
    :param str display_name:
        Human-friendly name of the category (will be displayed to the user).
    :param int value:
        Finding type independent scala to determine the actual severity of the category, e.g. to
        be able to sort by severity or to determine appropriate colours. Only values between 0 and
        100 are allowed. Note: There must be exactly one category per finding which defines value as
        0 to express that a finding is not relevant anymore.
    :param str allowed_processing_time:
        The time after which a finding must have been assessed at the latest. Known units:
            - seconds: s, sec
            - minutes: m, min
            - hours: h, hr
            - days: d (default)
            - weeks: w
            - years: a
    :param RescoringModes rescoring:
        Specifies whether the categorisation is applicable to user rescoring (-> `manual`) and/or to
        full-automatic rescorings (-> `automatic`). Note that the latter requires a respective
        rescoring ruleset to be available.
    :param Selector selector:
        Used to determine findings which should be assigned to this category.
    """

    id: str
    display_name: str
    value: int
    allowed_processing_time: MetaAllowedProcessingTimes | str | int | None
    rescoring: RescoringModes | list[RescoringModes] | None
    selector: (
        CryptoFindingSelector
        | GHASFindingSelector
        | IPFindingSelector
        | LicenseFindingSelector
        | MalwareFindingSelector
        | SASTFindingSelector
        | VulnerabilityFindingSelector
        | OsIdFindingSelector
        | None
    )

    def __post_init__(self):
        if (
            not isinstance(self.allowed_processing_time, MetaAllowedProcessingTimes)
            and self.allowed_processing_time is not None
        ):
            self.allowed_processing_time = util.convert_to_timedelta(self.allowed_processing_time)

        if isinstance(self.rescoring, RescoringModes):
            self.rescoring = [self.rescoring]

    @property
    def automatic_rescoring(self) -> bool:
        if not self.rescoring:
            return False

        if isinstance(self.rescoring, list):
            return RescoringModes.AUTOMATIC in self.rescoring

        return self.rescoring is RescoringModes.AUTOMATIC

    @property
    def allowed_processing_time_raw(self) -> str | None:
        """
        Parses the allowed processing time into a string together with its unit in case it was
        implicitly converted into a `timedelta` object during `__post_init__`. The returned value
        may be used to be persisted in an `ArtefactMetadata` object.
        """
        if (
            isinstance(self.allowed_processing_time, MetaAllowedProcessingTimes)
            or self.allowed_processing_time is None
        ):
            return self.allowed_processing_time

        return f'{int(self.allowed_processing_time.total_seconds())}s'

    def due_date(
        self,
        discovery_date: datetime.date,
    ) -> datetime.date | None:
        if not self.allowed_processing_time:
            return None

        return discovery_date + self.allowed_processing_time

    def effective_due_date(
        self,
        finding: odg.model.ArtefactMetadata,
        rescoring: odg.model.ArtefactMetadata | None = None,
    ) -> datetime.date | None:
        """
        Returns the effective due date for the referenced finding. If any related rescoring exist,
        the date will be derived from this rescoring, otherwise it will be derived from the original
        finding.

        In case of a rescoring, a due date which is explicitly set will take precedence over those
        calculated ad-hoc and an `allowed_processing_time` stored in the finding/rescoring will take
        precedence over the one configured in the currently active categorisation-cfg (be backwards
        compatible for rescorings/findings without due dates).

        If `None` is returned, the finding is categorised as "resolved" and does not have to be
        processed anymore.
        """
        if rescoring:
            if due_date := rescoring.data.due_date:
                return due_date

            if allowed_processing_time := rescoring.data.allowed_processing_time:
                return finding.discovery_date + util.convert_to_timedelta(allowed_processing_time)

            return self.due_date(finding.discovery_date)

        if allowed_processing_time := finding.allowed_processing_time:
            return finding.discovery_date + util.convert_to_timedelta(allowed_processing_time)

        return self.due_date(finding.discovery_date)


@dataclasses.dataclass
class FindingIssues:
    """
    :param str template:
        Template to use for the created GitHub issues. See `issue_replicator.github` for available
        substitues.
    :param str title_template:
        Template to use for the title of the created GitHub issues. Available substituates are
        `artefact`, `meta` and `data` (derived from the respective finding of type
        `odg.model.ArtefactMetadata`).
    :param bool enable_issues:
        If disabled, no GitHub issues will be created/updated for the specified finding type.
    :param bool enable_assignees:
        If set, determined responsibles will be automatically assigned to their respective issues.
    :param bool enable_per_finding:
        If set, GitHub issues will be created per finding for a specific artefact as opposed to a
        single issue with all findings.
    :param list[str] labels:
        List of labels that should be added to the created GitHub issues.
    :param list[str] attrs_to_group_by:
        Allows a custom configuration of those attributes, which should be used to group artefacts
        for a reporting in a shared GitHub issue. If not set, it defaults to the initial behaviour
        which uses `component_name`, `artefact_kind`, `artefact.artefact_name` and
        `artefact.artefact_type` for grouping. Nested attributes are expected to be separated using
        a dot `.`. Note: The order of the specified attributes is significant as they are
        concatenated in the order they were specified to create a stable issue id.
    """

    template: str = '{summary}'
    title_template: str = (
        '[{meta.type}] - {artefact.component_name}:{artefact.artefact.artefact_name}'  # noqa: E501
    )
    enable_issues: bool = True
    enable_assignees: bool = True
    enable_per_finding: bool = False
    labels: list[str] = dataclasses.field(default_factory=list)
    attrs_to_group_by: list[str] = dataclasses.field(
        default_factory=lambda: [
            'component_name',
            'artefact_kind',
            'artefact.artefact_name',
            'artefact.artefact_type',
        ],
    )
    default_assignee_mode: odg.model.ResponsibleAssigneeModes = (
        odg.model.ResponsibleAssigneeModes.SKIP
    )  # noqa: E501

    def group_id_for_artefact(
        self,
        artefact: odg.model.ComponentArtefactId,
    ) -> str:
        """
        Creates a stable representation of the grouping relevant attributes of the `artefact`.
        """
        artefact_raw = dataclasses.asdict(artefact)

        def resolve_attr_ref(attr_ref: str) -> str:
            prop = artefact_raw
            for attr_ref_part in attr_ref.split('.'):
                prop = prop.get(attr_ref_part, {})

            if isinstance(prop, dict):
                return odg.model.normalise_artefact_extra_id(prop)

            return prop

        return ''.join(str(resolve_attr_ref(attr_ref)) for attr_ref in self.attrs_to_group_by)

    def issue_id(
        self,
        artefact: odg.model.ComponentArtefactId,
        due_date: datetime.date,
        version: str = 'v1',
    ) -> str:
        """
        The issue-id (fka. correlation-id) is built from the grouping relevant properties of the
        `artefact` as well as the `due_date`. It is intended to be used to reference a GitHub issue
        to distinguish between issues "managed" by the Open-Delivery-Gear vs. those manually
        "managed". Also, a version prefix is added to be able to differentiate issue-ids in case
        their calculation changes in the future.
        """
        group_id = self.group_id_for_artefact(artefact)
        digest_str = group_id + due_date.isoformat()
        digest = hashlib.shake_128(
            digest_str.encode(),
            usedforsecurity=False,
        ).hexdigest(23)

        return f'{version}/{digest}'

    def issue_title(
        self,
        finding: odg.model.ArtefactMetadata,
    ) -> str:
        return self.title_template.format(
            artefact=finding.artefact,
            meta=finding.meta,
            data=finding.data,
        )

    def strip_artefact(
        self,
        artefact: odg.model.ComponentArtefactId,
        keep_group_attributes: bool = True,
    ) -> odg.model.ComponentArtefactId:
        """
        Based on `keep_group_attributes`, either returns an artefact which only contains the
        attributes which are used for grouping, or the opposite.
        """

        def include_attribute(attr_ref: str) -> bool:
            is_group_attribute = attr_ref in self.attrs_to_group_by
            return is_group_attribute == keep_group_attributes

        return odg.model.ComponentArtefactId(
            component_name=artefact.component_name if include_attribute('component_name') else None,  # noqa: E501
            component_version=artefact.component_version
            if include_attribute('component_version')
            else None,  # noqa: E501
            artefact_kind=artefact.artefact_kind if include_attribute('artefact_kind') else None,
            artefact=odg.model.LocalArtefactId(
                artefact_name=artefact.artefact.artefact_name
                if include_attribute('artefact.artefact_name')
                else None,  # noqa: E501
                artefact_version=artefact.artefact.artefact_version
                if include_attribute('artefact.artefact_version')
                else None,  # noqa: E501
                artefact_type=artefact.artefact.artefact_type
                if include_attribute('artefact.artefact_type')
                else None,  # noqa: E501
                artefact_extra_id=artefact.artefact.artefact_extra_id
                if include_attribute('artefact.artefact_extra_id')
                else dict(),  # noqa: E501
            ),
        )


@dataclasses.dataclass
class SharedCfgReference:
    cfg_name: str
    ref: (
        odg.shared_cfg.SharedCfgGitHubReference
        | odg.shared_cfg.SharedCfgLocalReference
        | odg.shared_cfg.SharedCfgOCMReference
    )


@dataclasses.dataclass
class ReuseDiscoveryDate:
    """
    :param bool enabled:
        Specifies whether discovery dates should be reused at all.
    :param str max_reuse_time:
        The time after the last update of a finding during which a discovery date is reused.
        Known units:
            - seconds: s, sec
            - minutes: m, min
            - hours: h, hr
            - days: d (default)
            - weeks: w
            - years: a
    """

    enabled: bool = True
    max_reuse_time: str | int | None = None

    def __post_init__(self):
        if self.max_reuse_time is not None:
            self.max_reuse_time = util.convert_to_timedelta(self.max_reuse_time)


@dataclasses.dataclass
class Finding:
    """
    :param Datatype type:
    :param list[FindingCategorisation] categorisation:
        The available categories for this type of findings and information on how to assign the
        findings to one of these categories. If a string is given, the corresponding standard
        categorisations are automatically set after instantiation of this class.
    :param list[odg.filter.ComponentArtefactFilter] filter:
        An optional filter to restrict detection of findings to certain artefacts.
    :param RuleSet rescoring_ruleset:
        Based on the finding type, there might be a ruleset available to automatically suggest/do
        rescorings. If a string is given, the corresponding standard ruleset is automatically set
        after instantiation of this class.
    :param FindingIssues issues:
        Configuration whether and if yes, how, GitHub tracking issues should be created/updated.
    :param RescoringScope default_scope:
        Default scope selection to be used for rescoring via the Delivery-Dashboard.
    :param ReuseDiscoveryDate reuse_discovery_date:
        Specifies the behaviour of reusing discovery dates of existing findings.
    :param int sprint_assignment_offset:
        Specifies the offset to which sprint relative to the due date of a finding, the finding
        should be assigned to. The default (offset=0) means that the finding is assigned to the
        *next* sprint *after* the calculated due date. In contrast, offset=-1 would mean that the
        finding is assigned to the sprint which ends directly *before* the calculated due date.
    """

    type: odg.model.Datatype
    categorisations: SharedCfgReference | list[FindingCategorisation]
    filter: list[odg.filter.ComponentArtefactFilter] | None
    rescoring_ruleset: SharedCfgReference | dict | None
    issues: FindingIssues = dataclasses.field(default_factory=FindingIssues)
    default_scope: RescoringSpecificity = dataclasses.field(
        default_factory=lambda: RescoringSpecificity.ARTEFACT,
    )
    reuse_discovery_date: ReuseDiscoveryDate = dataclasses.field(default_factory=ReuseDiscoveryDate)
    sprint_assignment_offset: int = 0

    @staticmethod
    def from_dict(
        findings_raw: list[dict],
        finding_type: odg.model.Datatype | None = None,
    ) -> list[typing.Self] | typing.Self | None:
        if not finding_type:
            return [
                dacite.from_dict(
                    data_class=Finding,
                    data=finding_raw,
                    config=dacite.Config(
                        cast=[enum.Enum],
                    ),
                )
                for finding_raw in findings_raw
            ]

        for finding_raw in findings_raw:
            if odg.model.Datatype(finding_raw['type']) is finding_type:
                break
        else:
            return None

        return dacite.from_dict(
            data_class=Finding,
            data=finding_raw,
            config=dacite.Config(
                cast=[enum.Enum],
            ),
        )

    @staticmethod
    def from_file(
        path: str,
        finding_type: odg.model.Datatype | None = None,
    ) -> list[typing.Self] | typing.Self | None:
        with open(path) as file:
            findings_raw = yaml.safe_load(file) or []

        return Finding.from_dict(
            findings_raw=findings_raw,
            finding_type=finding_type,
        )

    def __post_init__(self):
        shared_cfg_lookup = odg.shared_cfg.shared_cfg_lookup()

        if isinstance(self.categorisations, SharedCfgReference):
            default_cfg = shared_cfg_lookup(self.categorisations.ref)

            self.categorisations = default_finding_categorisations(
                categorisations_raw=default_cfg.get('categorisations', []),
                finding_type=self.type,
                name=self.categorisations.cfg_name,
            )

        if isinstance(self.rescoring_ruleset, SharedCfgReference):
            default_cfg = shared_cfg_lookup(self.rescoring_ruleset.ref)

            self.rescoring_ruleset = default_rescoring_ruleset(
                rescoring_rulesets_raw=default_cfg.get('rescoring_rulesets', []),
                finding_type=self.type,
                name=self.rescoring_ruleset.cfg_name,
            )

        if isinstance(self.rescoring_ruleset, dict):
            if self.type is odg.model.Datatype.SAST_FINDING:
                self.rescoring_ruleset = rm.SastRescoringRuleSet.from_dict(self.rescoring_ruleset)

            elif self.type is odg.model.Datatype.VULNERABILITY_FINDING:
                self.rescoring_ruleset = rm.CveRescoringRuleSet.from_dict(self.rescoring_ruleset)

        self._validate()

    def _validate(self):
        match self.type:
            case odg.model.Datatype.OSID_FINDING:
                self._validate_osid()
            case odg.model.Datatype.CRYPTO_FINDING:
                self._validate_crypto()
            case odg.model.Datatype.DIKI_FINDING:
                self._validate_diki()
            case odg.model.Datatype.GHAS_FINDING:
                self._validate_ghas()
            case odg.model.Datatype.LICENSE_FINDING:
                self._validate_license()
            case odg.model.Datatype.MALWARE_FINDING:
                self._validate_malware()
            case odg.model.Datatype.SAST_FINDING:
                self._validate_sast()
            case odg.model.Datatype.VULNERABILITY_FINDING:
                self._validate_vulnerabilty()
            case odg.model.Datatype.INVENTORY_FINDING:
                self._validate_inventory()
            case odg.model.Datatype.IP_FINDING:
                self._validate_ip()
            case _:
                pass

    def _validate_osid(self):
        violations = self._validate_categorisations(
            expected_selector=OsIdFindingSelector,
        )

        if not violations:
            return
        e = ModelValidationError('osid finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_crypto(self):
        violations = self._validate_categorisations(
            expected_selector=CryptoFindingSelector,
        )

        if not violations:
            return

        e = ModelValidationError('crypto finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_diki(self):
        violations = self._validate_categorisations()

        if not violations:
            return

        e = ModelValidationError('diki finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_ghas(self):
        violations = self._validate_categorisations(
            expected_selector=GHASFindingSelector,
        )

        if not violations:
            return

        e = ModelValidationError('ghas finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_ip(self):
        violations = self._validate_categorisations(
            expected_selector=IPFindingSelector,
        )

        if not violations:
            return

        e = ModelValidationError('ip finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_license(self):
        violations = self._validate_categorisations(
            expected_selector=LicenseFindingSelector,
        )

        if not violations:
            return

        e = ModelValidationError('license finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_malware(self):
        violations = self._validate_categorisations(
            expected_selector=MalwareFindingSelector,
        )

        if not violations:
            return

        e = ModelValidationError('malware finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_sast(self):
        violations = self._validate_categorisations(
            expected_selector=SASTFindingSelector,
        )

        if self.rescoring_ruleset:
            if not isinstance(self.rescoring_ruleset, rm.SastRescoringRuleSet):
                violations.append(f'rescoring rule set must be of type {rm.SastRescoringRuleSet}')

            else:
                violations.extend(self._validate_rescoring_ruleset())

        if not violations:
            return

        e = ModelValidationError('sast finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_vulnerabilty(self):
        violations = self._validate_categorisations(
            expected_selector=VulnerabilityFindingSelector,
        )

        if not self.none_categorisation:
            violations.append(
                'there must be at least one categorisation with "value=0" to express that a '
                'finding is not relevant anymore',
            )

        if self.rescoring_ruleset:
            if not isinstance(self.rescoring_ruleset, rm.CveRescoringRuleSet):
                violations.append(f'rescoring rule set must be of type {rm.CveRescoringRuleSet}')

            else:
                violations.extend(self._validate_rescoring_ruleset())

        if not violations:
            return

        e = ModelValidationError('vulnerability finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_inventory(self):
        violations = self._validate_categorisations()

        if not violations:
            return

        e = ModelValidationError('inventory finding model violations found:')
        e.add_note('\n'.join(violations))
        raise e

    def _validate_categorisations(
        self,
        expected_selector: object | None = None,
    ) -> list[str]:
        violations = []

        for categorisation in self.categorisations:
            selector = categorisation.selector
            if selector and expected_selector and not isinstance(selector, expected_selector):
                violations.append(f'selector must be of type {expected_selector}')

            if categorisation.id.startswith(consts.RESCORING_OPERATOR_SET_TO_PREFIX):
                violations.append(
                    f'the prefix "{consts.RESCORING_OPERATOR_SET_TO_PREFIX}" is reserved for '
                    'operations defined in the rescoring ruleset',
                )

        return violations

    def _validate_rescoring_ruleset(self) -> list[str]:
        violations = []

        if self.rescoring_ruleset.operations:
            for operation in self.rescoring_ruleset.operations.values():
                violations.extend(self._validate_rescoring_ruleset_operation(operation))

        for rule in self.rescoring_ruleset.rules:
            violations.extend(
                self._validate_rescoring_ruleset_operation(
                    operation=rule.operation,
                    operations=self.rescoring_ruleset.operations,
                ),
            )

        return violations

    def _validate_rescoring_ruleset_operation(
        self,
        operation: rm.Operation | str,
        operations: dict[str, rm.Operation | str] | None = None,
    ) -> list[str]:
        if not operations:
            operations = dict()

        if isinstance(operation, str):
            if operation in operations:
                return []

            if operation.startswith(
                consts.RESCORING_OPERATOR_SET_TO_PREFIX,
            ) and self.categorisation_by_id(
                id=operation.removeprefix(consts.RESCORING_OPERATOR_SET_TO_PREFIX),
                absent_ok=True,
            ):
                return []

            return [f'no categorisation matches operator "{operation}"']

        violations = []

        for op in operation.order:
            if op not in operations and not self.categorisation_by_id(id=op, absent_ok=True):
                violations.append(f'no categorisation matches operator "{op}" in "{operation}"')

        return violations

    @property
    def none_categorisation(self) -> FindingCategorisation | None:
        """
        Returns the category which marks a finding as "not relevant anymore", e.g. if it is assessed
        as a false-positive.
        """
        for categorisation in self.categorisations:
            if categorisation.value == 0:
                return categorisation

    def categorisation_by_id(
        self,
        id: str,
        absent_ok: bool = False,
    ) -> FindingCategorisation | None:
        for categorisation in self.categorisations:
            if categorisation.id == id:
                return categorisation

        if absent_ok:
            return None

        raise ValueError(f'did not find categorisation with {id=} for type "{self.type}"')

    def matches(self, artefact: odg.model.ComponentArtefactId) -> bool:
        if not self.filter:
            return True

        # we need to check whether there is at least one "include" filter because if there is none,
        # all not explicitly excluded artefacts are automatically included
        is_include_filter = odg.filter.FilterSemantics.INCLUDE in (f.semantics for f in self.filter)

        is_included = False
        is_excluded = False

        for filter in self.filter:
            if filter.semantics is odg.filter.FilterSemantics.INCLUDE and filter.matches(artefact):
                is_included = True
            elif filter.semantics is odg.filter.FilterSemantics.EXCLUDE and filter.matches(artefact):
                is_excluded = True

        return not is_excluded and (not is_include_filter or is_included)


def default_finding_categorisations(
    categorisations_raw: list[dict],
    finding_type: odg.model.Datatype,
    name: str,
) -> list[FindingCategorisation]:
    for categorisation_raw in categorisations_raw:
        if odg.model.Datatype(categorisation_raw['type']) is finding_type:
            break
    else:
        raise ValueError(f'did not find default categorisation for {finding_type=}')

    if name not in categorisation_raw:
        raise ValueError(f'did not find default categorisation for {finding_type=} and {name=}')

    return [
        dacite.from_dict(
            data_class=FindingCategorisation,
            data=categorisation,
            config=dacite.Config(
                cast=[enum.Enum],
            ),
        )
        for categorisation in categorisation_raw[name]
    ]


def default_rescoring_ruleset(
    rescoring_rulesets_raw: list[dict],
    finding_type: odg.model.Datatype,
    name: str,
) -> dict:
    for rescoring_ruleset_raw in rescoring_rulesets_raw:
        if odg.model.Datatype(rescoring_ruleset_raw['type']) is finding_type:
            break
    else:
        raise ValueError(f'did not find default rescoring ruleset for {finding_type=}')

    if name not in rescoring_ruleset_raw:
        raise ValueError(f'did not find default rescoring ruleset for {finding_type=} and {name=}')

    return rescoring_ruleset_raw[name]


def categorise_finding(
    finding_cfg: Finding,
    finding_property,
    **kwargs,
) -> FindingCategorisation | None:
    """
    Used to find the categorisation a finding belongs to according to the passed `finding_property`.
    """
    for categorisation in finding_cfg.categorisations:
        if not (selector := categorisation.selector):
            continue

        if isinstance(selector, CryptoFindingSelector):
            for rating in selector.ratings:
                if re.fullmatch(rating, finding_property, re.IGNORECASE):
                    return categorisation

        elif isinstance(selector, GHASFindingSelector):
            for resolution in selector.resolutions:
                if resolution is None or finding_property is None:
                    if resolution == finding_property:
                        return categorisation
                elif re.fullmatch(resolution, finding_property, re.IGNORECASE):
                    return categorisation

        elif isinstance(selector, IPFindingSelector):
            if selector.policy_violation_ids:
                for policy_violation_id in selector.policy_violation_ids:
                    if re.fullmatch(policy_violation_id, finding_property or '', re.IGNORECASE):
                        break
                else:
                    continue

            labels = kwargs.get('labels') or []

            if selector.labels:
                for label_pattern in selector.labels:
                    for label in labels:
                        if re.fullmatch(label_pattern, label, re.IGNORECASE):
                            break
                    else:
                        continue

                    break
                else:
                    continue

            return categorisation

        elif isinstance(selector, LicenseFindingSelector):
            for license_name in selector.license_names:
                if re.fullmatch(license_name, finding_property, re.IGNORECASE):
                    return categorisation

        elif isinstance(selector, MalwareFindingSelector):
            for malware_name in selector.malware_names:
                if re.fullmatch(malware_name, finding_property, re.IGNORECASE):
                    return categorisation

        elif isinstance(selector, SASTFindingSelector):
            for selector_sub_type in selector.sub_types:
                if re.fullmatch(selector_sub_type, finding_property, re.IGNORECASE):
                    return categorisation

        elif isinstance(selector, VulnerabilityFindingSelector):
            if (
                finding_property >= selector.cve_score_range.min
                and finding_property <= selector.cve_score_range.max
            ):
                return categorisation

        elif isinstance(selector, OsIdFindingSelector):
            for status in selector.status:
                if re.fullmatch(status, finding_property, re.IGNORECASE):
                    return categorisation
