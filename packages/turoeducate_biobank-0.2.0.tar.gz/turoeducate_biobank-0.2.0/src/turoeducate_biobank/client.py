"""
Synchronous HTTP client for the TuroEducate Biobank API.

Designed to be used either via the CLI or directly from Python:

    from turoeducate_biobank import BiobankClient
    client = BiobankClient.from_env()                    # uses TUROEDUCATE_BIOBANK_TOKEN
    # or
    client = BiobankClient(host="https://app.turoeducate.com", token="bb_live_…")

    schema = client.schema()
    cohort = client.cohorts.create(name="Breast Ki-67", filters=[
        {"field": "Stain Types", "op": "contains", "value": "Ki-67"},
    ])
    for s in client.specimens.iter_all(filters=cohort.filters):
        print(s.slide_id_value, s.metadata.get("Test Code"))
"""
from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional

import httpx

from . import __version__
from .auth import Credentials, load_credentials
from .exceptions import ApiError, AuthError
from .models import (
    ApiToken,
    ApiTokenCreated,
    BiobankGrant,
    BiobankSchema,
    ChatMessage,
    ChatThread,
    ChatThreadDetail,
    ChatTurnResponse,
    Cohort,
    ExportResponse,
    FilterClause,
    Note,
    SlideDownloadResponse,
    Specimen,
    SpecimenList,
    SlideRef,
)


_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0, read=120.0)


class BiobankClient:
    """Sync client wrapping every /api/v1/biobank/* endpoint."""

    def __init__(
        self,
        host: str,
        token: str,
        *,
        timeout: Optional[httpx.Timeout] = None,
    ) -> None:
        self.host = host.rstrip("/")
        self.token = token
        self._http = httpx.Client(
            base_url=f"{self.host}/api/v1",
            timeout=timeout or _DEFAULT_TIMEOUT,
            headers={
                "Authorization": f"Bearer {token}",
                "User-Agent": f"turoeducate-biobank/{__version__}",
                "Accept": "application/json",
            },
        )
        self.specimens = _Specimens(self)
        self.slides = _Slides(self)
        self.cohorts = _Cohorts(self)
        self.notes = _Notes(self)
        self.chat = _Chat(self)
        self.tokens = _Tokens(self)
        self.grants = _Grants(self)

    # ---- Construction helpers ----

    @classmethod
    def from_env(cls) -> "BiobankClient":
        creds = load_credentials()
        if creds is None:
            raise AuthError(
                "No credentials found. Run `biobank login` or set "
                "TUROEDUCATE_BIOBANK_HOST + TUROEDUCATE_BIOBANK_TOKEN."
            )
        return cls(host=creds.host, token=creds.token)

    @classmethod
    def from_credentials(cls, creds: Credentials) -> "BiobankClient":
        return cls(host=creds.host, token=creds.token)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "BiobankClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ---- Low-level request ----

    def _request(self, method: str, path: str, **kw) -> Any:
        try:
            r = self._http.request(method, path, **kw)
        except httpx.HTTPError as exc:
            raise ApiError(0, f"network error: {exc}")
        if r.status_code == 401:
            raise AuthError(_extract_detail(r) or "unauthorized")
        if 200 <= r.status_code < 300:
            if not r.content:
                return None
            return r.json()
        raise ApiError(r.status_code, _extract_detail(r) or r.text)

    # ---- Top-level resources ----

    def me(self) -> Dict[str, Any]:
        return self._request("GET", "/auth/me")

    def schema(self) -> BiobankSchema:
        data = self._request("GET", "/biobank/schema")
        return BiobankSchema.model_validate(data)

    def source(self) -> Dict[str, Any]:
        return self._request("GET", "/biobank/source")

    def whoami(self) -> Dict[str, Any]:
        return self.me()


def _extract_detail(r: httpx.Response) -> Optional[str]:
    try:
        body = r.json()
    except (json.JSONDecodeError, ValueError):
        return None
    if isinstance(body, dict):
        d = body.get("detail")
        if isinstance(d, str):
            return d
        if isinstance(d, list) and d and isinstance(d[0], dict):
            return d[0].get("msg")
    return None


# ---------------------------------------------------------------------------
# Sub-resources
# ---------------------------------------------------------------------------


class _Specimens:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 50,
        sort: Optional[str] = None,
        filters: Optional[List[Any]] = None,
    ) -> SpecimenList:
        params: Dict[str, Any] = {"page": page, "page_size": page_size}
        if sort:
            params["sort"] = sort
        if filters:
            params["filters"] = json.dumps([_clause_dict(f) for f in filters])
        data = self._c._request("GET", "/biobank/specimens", params=params)
        return SpecimenList.model_validate(data)

    def iter_all(
        self,
        *,
        page_size: int = 200,
        sort: Optional[str] = None,
        filters: Optional[List[Any]] = None,
    ) -> Iterable[Specimen]:
        page = 1
        while True:
            r = self.list(page=page, page_size=page_size, sort=sort, filters=filters)
            for s in r.items:
                yield s
            if page * page_size >= r.total:
                return
            page += 1

    def get(self, specimen_id: str) -> Specimen:
        data = self._c._request("GET", f"/biobank/specimens/{specimen_id}")
        return Specimen.model_validate(data)

    def search(self, q: str, *, page: int = 1, page_size: int = 50) -> List[Specimen]:
        data = self._c._request(
            "GET", "/biobank/specimens/search",
            params={"q": q, "page": page, "page_size": page_size},
        )
        return [Specimen.model_validate(x) for x in (data or {}).get("items", [])]

    def export(
        self,
        *,
        filters: Optional[List[Any]] = None,
        ids: Optional[List[str]] = None,
        columns: Optional[List[str]] = None,
    ) -> ExportResponse:
        body: Dict[str, Any] = {}
        if filters is not None:
            body["filters"] = [_clause_dict(f) for f in filters]
        if ids is not None:
            body["ids"] = ids
        if columns is not None:
            body["columns"] = columns
        data = self._c._request("POST", "/biobank/specimens/export", json=body)
        return ExportResponse.model_validate(data)


class _Slides:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def list(self, specimen_id: str) -> List[SlideRef]:
        data = self._c._request("GET", f"/biobank/specimens/{specimen_id}/slides")
        return [SlideRef.model_validate(x) for x in (data or [])]

    def download_url(self, slide_id: str) -> SlideDownloadResponse:
        """
        Issue a presigned S3 GET URL for the raw slide file.

        Requires the caller to hold the ``view_download`` (or ``edit``)
        permission on the slide's specimen. The URL is valid for 1 hour.
        """
        data = self._c._request("GET", f"/biobank/slides/{slide_id}/download")
        return SlideDownloadResponse.model_validate(data)

    def download(self, slide_id: str, dest_path: str) -> str:
        """
        Stream the slide file to ``dest_path`` on disk. Returns the
        absolute path of the written file. Uses the presigned URL — no
        bytes flow through TuroEducate.
        """
        import os
        info = self.download_url(slide_id)
        with httpx.Client(timeout=httpx.Timeout(60.0, read=None)) as raw:
            with raw.stream("GET", info.download_url) as resp:
                resp.raise_for_status()
                with open(dest_path, "wb") as fh:
                    for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                        fh.write(chunk)
        return os.path.abspath(dest_path)


class _Cohorts:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def list(self) -> List[Cohort]:
        data = self._c._request("GET", "/biobank/cohorts")
        return [Cohort.model_validate(x) for x in (data or [])]

    def get(self, cohort_id: str) -> Cohort:
        data = self._c._request("GET", f"/biobank/cohorts/{cohort_id}")
        return Cohort.model_validate(data)

    def create(
        self,
        *,
        name: str,
        filters: List[Any],
        description: Optional[str] = None,
    ) -> Cohort:
        body = {
            "name": name,
            "description": description,
            "filters": [_clause_dict(f) for f in filters],
        }
        data = self._c._request("POST", "/biobank/cohorts", json=body)
        return Cohort.model_validate(data)

    def update(
        self,
        cohort_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        filters: Optional[List[Any]] = None,
    ) -> Cohort:
        body: Dict[str, Any] = {}
        if name is not None: body["name"] = name
        if description is not None: body["description"] = description
        if filters is not None: body["filters"] = [_clause_dict(f) for f in filters]
        data = self._c._request("PATCH", f"/biobank/cohorts/{cohort_id}", json=body)
        return Cohort.model_validate(data)

    def delete(self, cohort_id: str) -> None:
        self._c._request("DELETE", f"/biobank/cohorts/{cohort_id}")


class _Notes:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def list(self, specimen_id: str) -> List[Note]:
        data = self._c._request("GET", f"/biobank/specimens/{specimen_id}/notes")
        return [Note.model_validate(x) for x in (data or [])]

    def add(self, specimen_id: str, text: str) -> Note:
        data = self._c._request(
            "POST", f"/biobank/specimens/{specimen_id}/notes",
            json={"text": text},
        )
        return Note.model_validate(data)

    def delete(self, note_id: str) -> None:
        self._c._request("DELETE", f"/biobank/notes/{note_id}")


class _Chat:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def threads(self) -> List[ChatThread]:
        data = self._c._request("GET", "/biobank/chat/threads")
        return [ChatThread.model_validate(x) for x in (data or [])]

    def thread(self, thread_id: str) -> ChatThreadDetail:
        data = self._c._request("GET", f"/biobank/chat/threads/{thread_id}")
        return ChatThreadDetail.model_validate(data)

    def delete_thread(self, thread_id: str) -> None:
        self._c._request("DELETE", f"/biobank/chat/threads/{thread_id}")

    def send(
        self,
        message: str,
        *,
        thread_id: Optional[str] = None,
        cohort_filters: Optional[List[Any]] = None,
    ) -> ChatTurnResponse:
        body: Dict[str, Any] = {"message": message}
        if thread_id:
            body["thread_id"] = thread_id
        if cohort_filters:
            body["cohort_filters"] = [_clause_dict(f) for f in cohort_filters]
        data = self._c._request("POST", "/biobank/chat", json=body)
        return ChatTurnResponse.model_validate(data)


class _Tokens:
    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def list(self) -> List[ApiToken]:
        data = self._c._request("GET", "/auth/api-tokens")
        return [ApiToken.model_validate(x) for x in (data or [])]

    def create(
        self,
        *,
        name: str,
        scopes: List[str],
        expires_in_days: Optional[int] = None,
    ) -> ApiTokenCreated:
        body: Dict[str, Any] = {"name": name, "scopes": scopes}
        if expires_in_days is not None:
            body["expires_in_days"] = expires_in_days
        data = self._c._request("POST", "/auth/api-tokens", json=body)
        return ApiTokenCreated.model_validate(data)

    def revoke(self, token_id: str) -> None:
        self._c._request("DELETE", f"/auth/api-tokens/{token_id}")


class _Grants:
    """
    Inspect grants currently held by the caller — useful when the partner
    wants to confirm exactly what their token can see.

    Admin-side grant management (``list``, ``revoke``) lives on the web UI
    and the API; the CLI deliberately exposes only ``mine`` so a partner's
    workstation never holds the verbs needed to revoke other people's grants.
    """

    def __init__(self, c: BiobankClient) -> None:
        self._c = c

    def mine(self) -> List[BiobankGrant]:
        data = self._c._request("GET", "/biobank/grants/mine")
        return [BiobankGrant.model_validate(x) for x in (data or [])]

    def accept_invite(self, token: str) -> BiobankGrant:
        data = self._c._request("POST", "/biobank/invites/accept", json={"token": token})
        return BiobankGrant.model_validate(data)


def _clause_dict(c: Any) -> Dict[str, Any]:
    if isinstance(c, FilterClause):
        return c.model_dump()
    if isinstance(c, dict):
        return c
    raise TypeError(f"filter must be FilterClause or dict, got {type(c).__name__}")
