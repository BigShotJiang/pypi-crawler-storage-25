"""
Parse the CLI's terse filter mini-DSL into FilterClause dicts.

    "Gender eq female"                  -> {"field":"Gender","op":"eq","value":"female"}
    "Age at Collection gt 50"           -> {"field":"Age at Collection","op":"gt","value":50}
    "Stain Types contains Ki-67"        -> {"field":"Stain Types","op":"contains","value":"Ki-67"}
    "Diagnosis Category in Breast,GI"   -> {"field":"...","op":"in","value":["Breast","GI"]}
    "Age between 40,60"                 -> {"field":"Age","op":"between","value":[40,60]}
"""
from __future__ import annotations

from typing import Any, Dict, List

from .exceptions import BiobankError


OPS = ("between", "contains", "gte", "lte", "eq", "ne", "gt", "lt", "in")


def _coerce_scalar(v: str) -> Any:
    s = v.strip()
    if not s:
        return s
    # int
    try:
        return int(s)
    except ValueError:
        pass
    # float
    try:
        return float(s)
    except ValueError:
        pass
    # bool literals
    low = s.lower()
    if low in ("true", "yes"):
        return True
    if low in ("false", "no"):
        return False
    return s


def parse_clause(expr: str) -> Dict[str, Any]:
    tokens = expr.split()
    if len(tokens) < 3:
        raise BiobankError(
            f"Filter must look like 'FIELD OP VALUE'. Got: {expr!r}"
        )
    # Find the rightmost op-token so the field can contain spaces and op is unambiguous.
    op_idx = None
    for i in range(len(tokens) - 2, 0, -1):
        if tokens[i] in OPS:
            op_idx = i
            break
    if op_idx is None:
        raise BiobankError(
            f"Couldn't find an operator in {expr!r}. Allowed ops: {', '.join(OPS)}"
        )
    field = " ".join(tokens[:op_idx])
    op = tokens[op_idx]
    value_str = " ".join(tokens[op_idx + 1:]).strip()
    if not field or not value_str:
        raise BiobankError(f"Field and value must both be non-empty in {expr!r}")

    value: Any
    if op in ("in", "between"):
        parts = [p.strip() for p in value_str.split(",") if p.strip()]
        if op == "between" and len(parts) != 2:
            raise BiobankError("`between` needs exactly two comma-separated values")
        value = [_coerce_scalar(p) for p in parts]
    else:
        value = _coerce_scalar(value_str)

    return {"field": field, "op": op, "value": value}


def parse_clauses(exprs: List[str]) -> List[Dict[str, Any]]:
    return [parse_clause(e) for e in exprs]
