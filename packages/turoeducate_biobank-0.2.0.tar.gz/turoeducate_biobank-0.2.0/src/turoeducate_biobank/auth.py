"""
Local credential storage.

Default location: ~/.config/turoeducate-biobank/credentials.json (0600 perms).
Set TUROEDUCATE_BIOBANK_HOME=/some/dir to override (useful in CI).

Schema:
    {
      "host": "https://app.turoeducate.com",
      "token": "bb_live_xxxxx",
      "user_email": "you@example.com"
    }

Environment overrides (always win over the file):
    TUROEDUCATE_BIOBANK_HOST   – API base URL
    TUROEDUCATE_BIOBANK_TOKEN  – bb_live_… token
"""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


def _config_dir() -> Path:
    override = os.environ.get("TUROEDUCATE_BIOBANK_HOME")
    if override:
        return Path(override).expanduser()
    base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "turoeducate-biobank"


def _credentials_path() -> Path:
    return _config_dir() / "credentials.json"


@dataclass
class Credentials:
    host: str
    token: str
    user_email: Optional[str] = None


def load_credentials() -> Optional[Credentials]:
    """Load creds: env vars first, then on-disk credentials.json."""
    env_host = os.environ.get("TUROEDUCATE_BIOBANK_HOST")
    env_token = os.environ.get("TUROEDUCATE_BIOBANK_TOKEN")
    if env_host and env_token:
        return Credentials(host=env_host.rstrip("/"), token=env_token, user_email=None)

    path = _credentials_path()
    if not path.exists():
        # Allow env-token alone if a default host can be set
        if env_token:
            host = env_host or "https://app.turoeducate.com"
            return Credentials(host=host.rstrip("/"), token=env_token)
        return None
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    return Credentials(
        host=(env_host or data.get("host", "")).rstrip("/"),
        token=env_token or data.get("token", ""),
        user_email=data.get("user_email"),
    )


def save_credentials(creds: Credentials) -> Path:
    path = _credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "host": creds.host.rstrip("/"),
        "token": creds.token,
        "user_email": creds.user_email,
    }
    path.write_text(json.dumps(payload, indent=2))
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        pass
    return path


def clear_credentials() -> bool:
    path = _credentials_path()
    if path.exists():
        path.unlink()
        return True
    return False
