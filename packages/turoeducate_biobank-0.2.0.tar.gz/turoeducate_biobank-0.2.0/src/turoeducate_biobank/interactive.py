"""
biobank ai — interactive Turo chat in the terminal.

Renders Markdown text + Markdown tables via rich, dim-cyan tool-use chips,
one-line chart summaries, and a small specimen-preview box. Every turn
carries the `cohort_filters` derived from the most recent filter_specimens
call so multi-turn narrowing works the same as in the web app.

Slash commands:

    /threads               list saved chats
    /open <id>             switch to thread <id> (prefix-match OK)
    /new                   start a fresh thread
    /clear                 clear the cohort context
    /cohort                show the current cohort filters
    /save <name>           save the current cohort context as a named cohort
    /export                export the current cohort to ./cohort.csv
    /help                  print this list
    /exit, /quit, Ctrl+D   leave
"""
from __future__ import annotations

import base64
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from .auth import _config_dir
from .client import BiobankClient
from .models import ChatMessage


SLASH_HELP = [
    ("/threads",          "list saved chats"),
    ("/open <id|prefix>", "switch to that thread"),
    ("/new",              "start a fresh thread"),
    ("/clear",            "clear the cohort context"),
    ("/cohort",           "show current cohort filters"),
    ("/save <name>",      "persist the current filters as a named cohort"),
    ("/export",           "export the current cohort to ./cohort.csv"),
    ("/help",             "show this list"),
    ("/exit",             "leave (Ctrl+D also works)"),
]


PROMPT_STYLE = Style.from_dict({
    "prompt":   "ansicyan bold",
    "thread":   "ansigray italic",
})


def run_repl(
    client: BiobankClient,
    console: Console,
    *,
    thread_id: Optional[str] = None,
    cohort_id: Optional[str] = None,
) -> None:
    state = _ReplState(client, console)
    if cohort_id:
        try:
            ch = client.cohorts.get(cohort_id)
            state.cohort_filters = [f.model_dump() for f in ch.filters]
            console.print(f"[dim]loaded cohort:[/dim] {ch.name}  ({len(state.cohort_filters)} filters)")
        except Exception as exc:
            console.print(f"[red]could not load cohort:[/red] {exc}")
    if thread_id:
        state.thread_id = thread_id
        try:
            detail = client.chat.thread(thread_id)
            console.print(_thread_banner(detail.title, thread_id, len(detail.messages)))
            # Re-apply the most recent filter call from the resumed thread.
            recovered = _filters_from_messages(detail.messages)
            if recovered is not None:
                state.cohort_filters = recovered
        except Exception as exc:
            console.print(f"[red]could not load thread:[/red] {exc}")

    _print_welcome(console)

    history_dir = _config_dir() / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    session: PromptSession = PromptSession(
        history=FileHistory(str(history_dir / "ai.history")),
        style=PROMPT_STYLE,
    )

    while True:
        try:
            label = "you"
            cohort_n = len(state.cohort_filters)
            cohort_txt = f"[{cohort_n} filter{'s' if cohort_n != 1 else ''}]" if cohort_n else ""
            line = session.prompt(HTML(
                f"<prompt>{label}</prompt><thread> {cohort_txt}</thread> » "
            ))
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]bye[/dim]")
            return

        line = line.strip()
        if not line:
            continue

        if line.startswith("/"):
            if _handle_slash(line, state):
                continue
            return  # /exit returns falsy from _handle_slash via raising SystemExit; here we use False to mean "leave"

        # Send to Turo
        try:
            r = client.chat.send(
                line,
                thread_id=state.thread_id,
                cohort_filters=state.cohort_filters or None,
            )
        except Exception as exc:
            console.print(f"[red]error:[/red] {exc}")
            continue

        if r.thread_id != state.thread_id:
            state.thread_id = r.thread_id
            console.print(f"[dim]new thread: {r.thread_id}[/dim]")

        render_assistant_messages(console, r.new_messages)

        # Re-apply the most recent filter call so subsequent turns inherit it.
        recovered = _filters_from_messages(r.new_messages)
        if recovered is not None:
            state.cohort_filters = recovered


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def render_assistant_messages(console: Console, messages: List[ChatMessage]) -> None:
    """Pretty-print only the assistant messages from a turn."""
    for m in messages:
        if m.role != "assistant":
            continue
        for b in m.content or []:
            t = b.get("type")
            if t == "text":
                txt = (b.get("text") or "").strip()
                if not txt:
                    continue
                console.print(Markdown(txt))
            elif t == "tool_use":
                name = b.get("name", "?")
                arg = _short_args(b.get("input", {}))
                console.print(f"[dim cyan]→ {name}({arg})[/dim cyan]")
            elif t == "tool_result":
                out = b.get("output")
                if isinstance(out, dict) and out.get("download_url"):
                    console.print(
                        f"[green]↓ CSV ready · {out.get('row_count','?')} rows[/green]  "
                        f"[dim](use /export to write it to disk)[/dim]"
                    )
            elif t == "chart":
                spec = b.get("spec") or {}
                _render_chart(console, spec)
            elif t == "specimens":
                _render_specimens(console, b)


def _render_chart(console: Console, spec: Dict[str, Any]) -> None:
    typ = spec.get("type", "?")
    title = spec.get("title", "")
    data = spec.get("data") or []
    n = len(data)
    if typ == "table":
        # Render the table directly.
        if not data:
            return
        cols = list(data[0].keys())
        t = Table(title=title or None, header_style="bold", show_lines=False)
        for c in cols:
            t.add_column(c)
        for row in data[:25]:
            t.add_row(*[str(row.get(c, "")) for c in cols])
        console.print(t)
        if n > 25:
            console.print(f"[dim]… and {n - 25} more rows[/dim]")
        return

    # For numeric distribution charts, draw a tiny ASCII bar.
    if typ in ("bar", "h_bar", "histogram", "pie", "donut", "treemap"):
        try:
            rows = [(str(d.get(spec.get("x", "x"))), float(d.get(spec.get("y", "y")) or 0)) for d in data]
        except (TypeError, ValueError):
            rows = []
        if rows:
            t = Table(title=f"{title}  [dim]({typ})[/dim]", header_style="bold", show_lines=False, show_edge=False)
            t.add_column(spec.get("x", "x"), style="cyan")
            t.add_column(spec.get("y", "y"), justify="right")
            t.add_column("", style="cyan")
            mx = max(v for _, v in rows) or 1
            for label, v in rows[:15]:
                bar = "█" * max(1, int(round(20 * v / mx)))
                t.add_row(label[:30], _fmt_num(v), bar)
            console.print(t)
            if len(rows) > 15:
                console.print(f"[dim]… +{len(rows) - 15} more[/dim]")
            return

    # Fallback summary line for other chart types.
    console.print(Panel(
        f"[bold]{title or typ}[/bold]  [dim]chart_type={typ} · {n} datapoints[/dim]",
        border_style="dim",
        padding=(0, 1),
        expand=False,
    ))


def _render_specimens(console: Console, block: Dict[str, Any]) -> None:
    count = block.get("count", 0)
    preview = block.get("preview") or []
    t = Table(title=f"{count} matching specimens (preview)", header_style="bold", show_lines=False)
    t.add_column("Specimen ID", style="cyan")
    t.add_column("Test")
    t.add_column("Diagnosis")
    for s in preview[:10]:
        m = s.get("metadata") or {}
        t.add_row(
            s.get("slide_id_value", "?"),
            str(m.get("Test Code", "")),
            (str(m.get("ICD-10 Description") or m.get("Diagnosis Category") or ""))[:50],
        )
    console.print(t)
    if count > len(preview):
        console.print(f"[dim]… {count - len(preview)} more in the full cohort[/dim]")


def _short_args(d: Dict[str, Any], max_len: int = 80) -> str:
    s = ", ".join(f"{k}={_short_val(v)}" for k, v in d.items())
    return s[:max_len] + ("…" if len(s) > max_len else "")


def _short_val(v: Any) -> str:
    if isinstance(v, list):
        if v and isinstance(v[0], dict):
            return f"[{len(v)} clauses]"
        return "[" + ",".join(str(x) for x in v[:3]) + ("…" if len(v) > 3 else "") + "]"
    s = str(v)
    return s if len(s) <= 30 else s[:27] + "…"


def _fmt_num(v: float) -> str:
    if v == int(v):
        return str(int(v))
    return f"{v:.2f}"


def _filters_from_messages(messages: List[Any]) -> Optional[List[Dict[str, Any]]]:
    """Walk back through assistant messages, return the most recent filter_specimens.input.filters."""
    for m in reversed(messages):
        role = getattr(m, "role", None) or (m.get("role") if isinstance(m, dict) else None)
        if role != "assistant":
            continue
        content = getattr(m, "content", None)
        if content is None and isinstance(m, dict):
            content = m.get("content")
        for b in (content or []):
            if b.get("type") == "tool_use" and b.get("name") == "filter_specimens":
                fs = (b.get("input") or {}).get("filters")
                if isinstance(fs, list):
                    return fs
        return None  # only inspect the latest assistant message
    return None


def _thread_banner(title: Optional[str], thread_id: str, n_msgs: int) -> str:
    return f"[bold]{title or 'Untitled'}[/bold]  [dim]({thread_id[:8]}…, {n_msgs} messages)[/dim]"


def _print_welcome(console: Console) -> None:
    console.print(Panel(
        "[bold cyan]Turo[/bold cyan]  · biobank assistant\n"
        "[dim]Type a question. Slash commands: /help · /threads · /new · /exit[/dim]",
        border_style="cyan", padding=(0, 1),
    ))


# ---------------------------------------------------------------------------
# Slash commands
# ---------------------------------------------------------------------------


class _ReplState:
    def __init__(self, client: BiobankClient, console: Console) -> None:
        self.client = client
        self.console = console
        self.thread_id: Optional[str] = None
        self.cohort_filters: List[Dict[str, Any]] = []


def _handle_slash(line: str, state: _ReplState) -> bool:
    """Return True to keep the REPL running, False to quit."""
    parts = line.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd in ("/exit", "/quit"):
        state.console.print("[dim]bye[/dim]")
        return False

    if cmd == "/help":
        for c, desc in SLASH_HELP:
            state.console.print(f"  [cyan]{c:<22}[/cyan] {desc}")
        return True

    if cmd == "/threads":
        try:
            rows = state.client.chat.threads()
        except Exception as exc:
            state.console.print(f"[red]error:[/red] {exc}"); return True
        for th in rows:
            marker = "[green]●[/green] " if th.id == state.thread_id else "  "
            state.console.print(f"{marker}{th.id[:8]}…  {th.title or 'Untitled'}  [dim]{th.updated_at}[/dim]")
        return True

    if cmd == "/open":
        if not arg:
            state.console.print("[red]usage:[/red] /open <thread-id-prefix>"); return True
        try:
            rows = state.client.chat.threads()
        except Exception as exc:
            state.console.print(f"[red]error:[/red] {exc}"); return True
        match = [t for t in rows if t.id.startswith(arg)]
        if not match:
            state.console.print(f"[red]no thread starts with {arg!r}[/red]"); return True
        if len(match) > 1:
            state.console.print(f"[yellow]ambiguous prefix; matches:[/yellow] {[t.id[:8] for t in match]}")
            return True
        target = match[0]
        try:
            detail = state.client.chat.thread(target.id)
        except Exception as exc:
            state.console.print(f"[red]error:[/red] {exc}"); return True
        state.thread_id = target.id
        state.console.print(_thread_banner(detail.title, target.id, len(detail.messages)))
        recovered = _filters_from_messages(detail.messages)
        if recovered is not None:
            state.cohort_filters = recovered
            state.console.print(f"[dim]restored cohort: {len(recovered)} filter(s)[/dim]")
        return True

    if cmd == "/new":
        state.thread_id = None
        state.console.print("[dim]new thread (will be created on next message)[/dim]")
        return True

    if cmd == "/clear":
        state.cohort_filters = []
        state.console.print("[dim]cohort cleared[/dim]")
        return True

    if cmd == "/cohort":
        if not state.cohort_filters:
            state.console.print("[dim]no active cohort filters[/dim]")
        else:
            for f in state.cohort_filters:
                v = ",".join(map(str, f["value"])) if isinstance(f["value"], list) else str(f["value"])
                state.console.print(f"  [cyan]{f['field']}[/cyan] {f['op']} {v}")
        return True

    if cmd == "/save":
        if not arg:
            state.console.print("[red]usage:[/red] /save <name>"); return True
        if not state.cohort_filters:
            state.console.print("[yellow]no active cohort to save[/yellow]"); return True
        try:
            ch = state.client.cohorts.create(name=arg, filters=state.cohort_filters)
        except Exception as exc:
            state.console.print(f"[red]error:[/red] {exc}"); return True
        state.console.print(f"[green]✓[/green] saved cohort [bold]{ch.name}[/bold] (id={ch.id}, matching={ch.matching_count})")
        return True

    if cmd == "/export":
        if not state.cohort_filters:
            state.console.print("[yellow]no cohort to export[/yellow]"); return True
        try:
            r = state.client.specimens.export(filters=state.cohort_filters)
        except Exception as exc:
            state.console.print(f"[red]error:[/red] {exc}"); return True
        url = r.download_url
        if url.startswith("data:") and ";base64," in url:
            body = base64.b64decode(url.split(";base64,", 1)[1])
        else:
            with httpx.Client() as h:
                body = h.get(url).content
        out = Path("cohort.csv")
        out.write_bytes(body)
        state.console.print(f"[green]✓[/green] wrote {r.row_count} rows to {out.resolve()}")
        return True

    state.console.print(f"[yellow]unknown command:[/yellow] {cmd}  [dim](try /help)[/dim]")
    return True
