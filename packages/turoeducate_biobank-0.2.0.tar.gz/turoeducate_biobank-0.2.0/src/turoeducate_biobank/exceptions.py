class BiobankError(Exception):
    """Base for everything raised by this package."""


class AuthError(BiobankError):
    """No / invalid / revoked credentials."""


class ApiError(BiobankError):
    """A non-2xx response from the API. .status_code + .detail are populated."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")
