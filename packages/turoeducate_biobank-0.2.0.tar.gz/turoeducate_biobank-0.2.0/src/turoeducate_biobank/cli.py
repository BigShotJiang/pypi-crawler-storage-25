"""
biobank — TuroEducate Biobank CLI.

Commands:

    biobank login                        – mint an API token, save it
    biobank logout                       – wipe credentials
    biobank whoami                       – show current user

    biobank tokens list / create / revoke
    biobank schema show

    biobank specimens list / get / search / export
    biobank slides list

    biobank cohorts list / get / create / apply / delete
    biobank notes list / add / delete

    biobank chat ask <message>
    biobank chat threads list / delete
    biobank ai                           – interactive Claude-Code-style REPL
    biobank validate                     – self-check
"""
from __future__ import annotations

import base64
import csv
import getpass
import json
import sys
from pathlib import Path
from typing import Iterable, List, Optional

import click
import httpx
from rich.console import Console
from rich.table import Table

from . import __version__
from .auth import (
    Credentials,
    clear_credentials,
    load_credentials,
    save_credentials,
)
from .client import BiobankClient
from .exceptions import ApiError, AuthError, BiobankError
from ._filter_dsl import parse_clauses


DEFAULT_HOST = "https://app.turoeducate.com"
console = Console()
err_console = Console(stderr=True, style="bold red")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_client() -> BiobankClient:
    creds = load_credentials()
    if creds is None:
        err_console.print(
            "Not authenticated. Run [bold]biobank login[/bold] or set "
            "TUROEDUCATE_BIOBANK_HOST + TUROEDUCATE_BIOBANK_TOKEN."
        )
        sys.exit(2)
    return BiobankClient(host=creds.host, token=creds.token)


def _die(exc: BaseException) -> None:
    if isinstance(exc, AuthError):
        err_console.print(f"Auth: {exc}")
        sys.exit(1)
    if isinstance(exc, ApiError):
        err_console.print(f"API {exc.status_code}: {exc.detail}")
        sys.exit(1)
    if isinstance(exc, BiobankError):
        err_console.print(str(exc))
        sys.exit(2)
    raise exc


def _json(obj) -> None:
    console.print_json(json.dumps(obj, default=str))


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------


@click.group()
@click.version_option(__version__, prog_name="biobank")
def main() -> None:
    """TuroEducate Biobank — programmatic specimen registry."""


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default=None, help=f"Backend URL (default: {DEFAULT_HOST}).")
@click.option("--email", default=None, help="Account email. Prompted if omitted.")
@click.option("--token-name", default="cli", show_default=True,
              help="Name to give the API token created during login.")
def login(host: Optional[str], email: Optional[str], token_name: str) -> None:
    """Log in with email + password and persist a long-lived API token."""
    host = (host or click.prompt("Backend URL", default=DEFAULT_HOST, show_default=True)).rstrip("/")
    if not (host.startswith("http://") or host.startswith("https://")):
        err_console.print("Backend URL must start with http:// or https://")
        sys.exit(2)
    if not email:
        email = click.prompt("Email")
    password = getpass.getpass("Password: ")

    # 1) Get JWT
    try:
        r = httpx.post(
            f"{host}/api/v1/auth/login",
            json={"username": email, "password": password},
            timeout=20.0,
        )
    except httpx.HTTPError as exc:
        err_console.print(f"network error: {exc}")
        sys.exit(1)
    if r.status_code != 200:
        err_console.print(f"Login failed: {r.status_code} {r.text}")
        sys.exit(1)
    jwt = r.json().get("access_token")
    if not jwt:
        err_console.print("Login response missing access_token.")
        sys.exit(1)

    # 2) Mint an API token (read+write by default; the user can rotate to scoped via `biobank tokens create`)
    try:
        r = httpx.post(
            f"{host}/api/v1/auth/api-tokens",
            headers={"Authorization": f"Bearer {jwt}"},
            json={"name": token_name, "scopes": ["read", "write"]},
            timeout=20.0,
        )
    except httpx.HTTPError as exc:
        err_console.print(f"network error minting token: {exc}")
        sys.exit(1)
    if r.status_code not in (200, 201):
        err_console.print(f"Failed to mint API token: {r.status_code} {r.text}")
        sys.exit(1)
    body = r.json()
    raw = body["token"]

    creds = Credentials(host=host, token=raw, user_email=email)
    path = save_credentials(creds)
    console.print(f"[green]✓[/green] Logged in as [bold]{email}[/bold]")
    console.print(f"  API token [dim]{body['prefix']}…[/dim]  scopes={','.join(body['scopes'])}")
    console.print(f"  saved to [dim]{path}[/dim]")


@main.command()
def logout() -> None:
    """Remove stored credentials."""
    if clear_credentials():
        console.print("[green]✓[/green] credentials cleared")
    else:
        console.print("[dim]no credentials to clear[/dim]")


@main.command()
def whoami() -> None:
    """Show the current user."""
    try:
        c = _get_client()
        u = c.me()
    except BaseException as exc:
        _die(exc)
        return
    console.print(f"[bold]{u.get('email','?')}[/bold]  role=[cyan]{u.get('role','?')}[/cyan]"
                  f"  org_id=[dim]{u.get('organization_id') or '—'}[/dim]")


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------


@main.group()
def tokens() -> None:
    """Manage API tokens."""


@tokens.command("list")
def tokens_list() -> None:
    try:
        c = _get_client()
        rows = c.tokens.list()
    except BaseException as exc:
        _die(exc); return
    if not rows:
        console.print("[dim]no tokens[/dim]"); return
    t = Table(title="API tokens", show_lines=False, header_style="bold")
    t.add_column("Prefix", style="cyan")
    t.add_column("Name")
    t.add_column("Scopes", style="magenta")
    t.add_column("Last used")
    t.add_column("Expires")
    t.add_column("Status")
    for r in rows:
        status = "active"
        if r.revoked_at: status = "[red]revoked[/red]"
        t.add_row(
            r.prefix + "…",
            r.name,
            ",".join(r.scopes),
            str(r.last_used_at or "—"),
            str(r.expires_at or "—"),
            status,
        )
    console.print(t)


@tokens.command("create")
@click.option("--name", required=True, help="Human-readable name.")
@click.option("--scope", "scopes", multiple=True, default=("read",),
              type=click.Choice(["read", "write", "admin"]), show_default=True,
              help="Repeat for multiple scopes (e.g. --scope read --scope write).")
@click.option("--expires-in-days", type=int, default=None,
              help="Days until expiry. Omit for non-expiring tokens.")
def tokens_create(name: str, scopes: Iterable[str], expires_in_days: Optional[int]) -> None:
    try:
        c = _get_client()
        t = c.tokens.create(name=name, scopes=list(scopes), expires_in_days=expires_in_days)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] created token [bold]{t.name}[/bold]")
    console.print(f"  id={t.id}")
    console.print(f"  prefix={t.prefix}…")
    console.print(f"  scopes={','.join(t.scopes)}")
    if t.expires_at: console.print(f"  expires_at={t.expires_at}")
    console.print()
    console.print(f"[bold yellow]TOKEN (shown ONCE):[/bold yellow] {t.token}")


@tokens.command("revoke")
@click.argument("token_id")
def tokens_revoke(token_id: str) -> None:
    try:
        c = _get_client()
        c.tokens.revoke(token_id)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] revoked {token_id}")


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


@main.command("schema")
@click.option("--json", "as_json", is_flag=True, help="Print raw JSON.")
def schema_show(as_json: bool) -> None:
    """Show the org's biobank schema."""
    try:
        c = _get_client()
        s = c.schema()
    except BaseException as exc:
        _die(exc); return
    if as_json:
        _json(s.model_dump(mode="json")); return
    console.print(f"[bold]Biobank schema[/bold]  v{s.version}  slide_id_field=[cyan]{s.slide_id_field}[/cyan]")
    t = Table(show_lines=False, header_style="bold")
    t.add_column("Field"); t.add_column("Type", style="cyan"); t.add_column("Choices", style="dim"); t.add_column("S")
    for f in s.fields:
        t.add_row(f.label, f.type, ", ".join(f.choices or [])[:60], "•" if f.searchable else "")
    console.print(t)


# ---------------------------------------------------------------------------
# Specimens
# ---------------------------------------------------------------------------


def _filter_options(f):
    f = click.option("-f", "--filter", "filters", multiple=True,
                     help="Filter clause (e.g. 'Gender eq female'). Repeatable.")(f)
    return f


@main.group()
def specimens() -> None:
    """Query specimens."""


@specimens.command("list")
@_filter_options
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=30, show_default=True, type=int)
@click.option("--sort", default=None, help="field name; prefix '-' for desc.")
@click.option("--json", "as_json", is_flag=True)
def specimens_list(filters, page, page_size, sort, as_json) -> None:
    try:
        c = _get_client()
        result = c.specimens.list(
            page=page, page_size=page_size, sort=sort,
            filters=parse_clauses(list(filters)) if filters else None,
        )
    except BaseException as exc:
        _die(exc); return
    if as_json:
        _json(result.model_dump(mode="json")); return
    t = Table(title=f"specimens · page {result.page}/{(result.total + page_size - 1)//page_size or 1} · total {result.total}", show_lines=False, header_style="bold")
    t.add_column("Specimen ID", style="cyan")
    t.add_column("Test")
    t.add_column("Age", justify="right")
    t.add_column("Gender")
    t.add_column("Slides", justify="right")
    t.add_column("Diagnosis")
    for s in result.items:
        m = s.metadata
        t.add_row(
            s.slide_id_value,
            str(m.get("Test Code", "")),
            str(m.get("Age at Collection", m.get("Age", ""))),
            str(m.get("Gender", m.get("Sex", ""))),
            str(s.slide_count),
            (str(m.get("Diagnosis Category") or m.get("ICD-10 Description") or ""))[:40],
        )
    console.print(t)


@specimens.command("get")
@click.argument("specimen_id")
@click.option("--json", "as_json", is_flag=True)
def specimens_get(specimen_id, as_json) -> None:
    try:
        c = _get_client()
        s = c.specimens.get(specimen_id)
    except BaseException as exc:
        _die(exc); return
    if as_json:
        _json(s.model_dump(mode="json")); return
    console.print(f"[bold cyan]{s.slide_id_value}[/bold cyan]  [dim]({s.id})[/dim]")
    console.print(f"created [dim]{s.created_at}[/dim]")
    console.print(f"slides ({s.slide_count}):")
    for sl in s.slides:
        console.print(f"  • {sl.filename}  [dim]dsa={sl.dsa_item_id or '—'}[/dim]")
    console.print()
    console.print("[bold]Metadata[/bold]")
    for k, v in s.metadata.items():
        if v in (None, ""):
            continue
        console.print(f"  [cyan]{k}[/cyan]  {v}")


@specimens.command("search")
@click.argument("query")
@click.option("--limit", default=20, show_default=True, type=int)
def specimens_search(query, limit) -> None:
    try:
        c = _get_client()
        rows = c.specimens.search(query, page_size=limit)
    except BaseException as exc:
        _die(exc); return
    t = Table(title=f"search: {query!r}", show_lines=False, header_style="bold")
    t.add_column("Specimen ID", style="cyan"); t.add_column("Test"); t.add_column("Diagnosis")
    for s in rows:
        m = s.metadata
        t.add_row(s.slide_id_value, str(m.get("Test Code", "")),
                  (str(m.get("ICD-10 Description") or ""))[:60])
    console.print(t)


@specimens.command("export")
@_filter_options
@click.option("--cohort", "cohort_id", default=None, help="Use a saved cohort's filters.")
@click.option("-o", "--output", default="-", help="Output path; '-' = stdout.")
def specimens_export(filters, cohort_id, output) -> None:
    """Export the matching cohort as CSV."""
    try:
        c = _get_client()
        clauses: List = []
        if cohort_id:
            ch = c.cohorts.get(cohort_id)
            clauses.extend([f.model_dump() for f in ch.filters])
        if filters:
            clauses.extend(parse_clauses(list(filters)))
        result = c.specimens.export(filters=clauses or None)
    except BaseException as exc:
        _die(exc); return

    # The API returns a `data:text/csv;base64,...` URL. Decode to bytes.
    url = result.download_url
    if url.startswith("data:") and ";base64," in url:
        body = base64.b64decode(url.split(";base64,", 1)[1])
    else:
        # Future-proof for signed-URL style responses.
        with httpx.Client() as h:
            body = h.get(url).content

    if output == "-":
        sys.stdout.buffer.write(body)
    else:
        Path(output).write_bytes(body)
        console.print(f"[green]✓[/green] wrote {result.row_count} rows to {output}")


# ---------------------------------------------------------------------------
# Slides
# ---------------------------------------------------------------------------


@main.group()
def slides() -> None:
    """Per-specimen slide trays."""


@slides.command("list")
@click.argument("specimen_id")
def slides_list(specimen_id) -> None:
    try:
        c = _get_client()
        rows = c.slides.list(specimen_id)
    except BaseException as exc:
        _die(exc); return
    t = Table(title=f"slides for {specimen_id}", show_lines=False, header_style="bold")
    t.add_column("Filename", style="cyan"); t.add_column("DSA item id"); t.add_column("Slide id", style="dim")
    for s in rows:
        t.add_row(s.filename, s.dsa_item_id or "—", s.id)
    console.print(t)


@slides.command("download-url")
@click.argument("slide_id")
def slides_download_url(slide_id: str) -> None:
    """Print a presigned download URL for the slide. Requires view+download."""
    try:
        c = _get_client()
        info = c.slides.download_url(slide_id)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[bold]{info.filename}[/bold]")
    console.print(info.download_url)
    console.print(f"[dim]expires in {info.expires_in}s[/dim]")


@slides.command("download")
@click.argument("slide_id")
@click.option("-o", "--output", type=click.Path(dir_okay=False, writable=True),
              help="Where to write the file. Defaults to ./<slide-filename>.")
def slides_download(slide_id: str, output: Optional[str]) -> None:
    """
    Stream the slide file to disk. Requires view+download permission.
    The bytes flow direct from S3 to your machine — TuroEducate only
    issues the presigned URL.
    """
    import os
    try:
        c = _get_client()
        info = c.slides.download_url(slide_id)
        target = output or os.path.join(os.getcwd(), info.filename)
        console.print(f"Downloading [cyan]{info.filename}[/cyan] → {target}")
        path = c.slides.download(slide_id, target)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] saved to {path}")


# ---------------------------------------------------------------------------
# Grants — inspect what the current credential can access
# ---------------------------------------------------------------------------


@main.group()
def grants() -> None:
    """Inspect biobank grants held by your account."""


@grants.command("list")
def grants_list() -> None:
    """List active grants you currently hold (across orgs)."""
    try:
        c = _get_client()
        rows = c.grants.mine()
    except BaseException as exc:
        _die(exc); return
    if not rows:
        console.print("[dim]No active biobank grants on this account.[/dim]"); return
    t = Table(show_lines=False, header_style="bold")
    t.add_column("Org", style="cyan")
    t.add_column("Scope")
    t.add_column("Permission")
    t.add_column("Expires", style="dim")
    t.add_column("Granted by", style="dim")
    for g in rows:
        t.add_row(
            g.organization_name or g.organization_id[:8],
            g.scope_label or g.scope_kind,
            g.permission,
            g.expires_at.strftime("%Y-%m-%d"),
            g.granted_by_name or "—",
        )
    console.print(t)


@grants.command("accept")
@click.argument("invite_token")
def grants_accept(invite_token: str) -> None:
    """Accept a biobank invite by its token (from the invite email link)."""
    try:
        c = _get_client()
        g = c.grants.accept_invite(invite_token)
    except BaseException as exc:
        _die(exc); return
    console.print(
        f"[green]✓[/green] Accepted: {g.scope_label or g.scope_kind} "
        f"({g.permission}, expires {g.expires_at.strftime('%Y-%m-%d')})"
    )


# ---------------------------------------------------------------------------
# Cohorts
# ---------------------------------------------------------------------------


@main.group()
def cohorts() -> None:
    """Saved filter sets."""


@cohorts.command("list")
def cohorts_list() -> None:
    try:
        c = _get_client()
        rows = c.cohorts.list()
    except BaseException as exc:
        _die(exc); return
    if not rows:
        console.print("[dim]no cohorts yet[/dim]"); return
    t = Table(show_lines=False, header_style="bold")
    t.add_column("Name", style="cyan")
    t.add_column("Match", justify="right")
    t.add_column("Filters", justify="right")
    t.add_column("Author", style="dim")
    t.add_column("ID", style="dim")
    for ch in rows:
        t.add_row(ch.name, str(ch.matching_count if ch.matching_count is not None else "—"),
                  str(len(ch.filters)), ch.author_name or "—", ch.id)
    console.print(t)


@cohorts.command("get")
@click.argument("cohort_id")
@click.option("--json", "as_json", is_flag=True)
def cohorts_get(cohort_id, as_json) -> None:
    try:
        c = _get_client()
        ch = c.cohorts.get(cohort_id)
    except BaseException as exc:
        _die(exc); return
    if as_json:
        _json(ch.model_dump(mode="json")); return
    console.print(f"[bold cyan]{ch.name}[/bold cyan]  [dim]({ch.id})[/dim]")
    if ch.description: console.print(f"  {ch.description}")
    console.print(f"  matching: [bold]{ch.matching_count}[/bold]")
    console.print(f"  filters:")
    for f in ch.filters:
        v = ",".join(map(str, f.value)) if isinstance(f.value, list) else str(f.value)
        console.print(f"    [cyan]{f.field}[/cyan] {f.op} {v}")


@cohorts.command("create")
@click.option("--name", required=True)
@click.option("--description", default=None)
@_filter_options
def cohorts_create(name, description, filters) -> None:
    if not filters:
        err_console.print("Need at least one --filter clause."); sys.exit(2)
    try:
        c = _get_client()
        ch = c.cohorts.create(name=name, description=description,
                              filters=parse_clauses(list(filters)))
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] created [bold]{ch.name}[/bold]  id={ch.id}  matching={ch.matching_count}")


@cohorts.command("apply")
@click.argument("cohort_id")
@click.option("--limit", default=20, show_default=True, type=int)
@click.option("--json", "as_json", is_flag=True)
def cohorts_apply(cohort_id, limit, as_json) -> None:
    """Show specimens matching a saved cohort."""
    try:
        c = _get_client()
        ch = c.cohorts.get(cohort_id)
        result = c.specimens.list(page=1, page_size=limit,
                                  filters=[f.model_dump() for f in ch.filters])
    except BaseException as exc:
        _die(exc); return
    if as_json:
        _json(result.model_dump(mode="json")); return
    console.print(f"[bold]{ch.name}[/bold]  ({result.total} matching, showing {len(result.items)})")
    t = Table(show_lines=False, header_style="bold")
    t.add_column("Specimen ID", style="cyan"); t.add_column("Test"); t.add_column("Age"); t.add_column("Gender"); t.add_column("Slides")
    for s in result.items:
        m = s.metadata
        t.add_row(s.slide_id_value, str(m.get("Test Code", "")),
                  str(m.get("Age at Collection", "")),
                  str(m.get("Gender", "")),
                  str(s.slide_count))
    console.print(t)


@cohorts.command("delete")
@click.argument("cohort_id")
def cohorts_delete(cohort_id) -> None:
    try:
        c = _get_client()
        c.cohorts.delete(cohort_id)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] deleted {cohort_id}")


# ---------------------------------------------------------------------------
# Notes
# ---------------------------------------------------------------------------


@main.group()
def notes() -> None:
    """Per-specimen notes."""


@notes.command("list")
@click.argument("specimen_id")
def notes_list(specimen_id) -> None:
    try:
        c = _get_client()
        rows = c.notes.list(specimen_id)
    except BaseException as exc:
        _die(exc); return
    if not rows:
        console.print("[dim]no notes[/dim]"); return
    for n in rows:
        console.print(f"[cyan]{n.author_name or n.author_id or '?'}[/cyan]  [dim]{n.created_at}[/dim]")
        console.print(f"  {n.text}")
        console.print()


@notes.command("add")
@click.argument("specimen_id")
@click.argument("text", nargs=-1, required=True)
def notes_add(specimen_id, text) -> None:
    try:
        c = _get_client()
        n = c.notes.add(specimen_id, " ".join(text))
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] added note {n.id}")


@notes.command("delete")
@click.argument("note_id")
def notes_delete(note_id) -> None:
    try:
        c = _get_client()
        c.notes.delete(note_id)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] deleted")


# ---------------------------------------------------------------------------
# Chat (one-shot + threads management)
# ---------------------------------------------------------------------------


@main.group()
def chat() -> None:
    """Talk to Turo from the terminal."""


@chat.command("ask")
@click.argument("message", nargs=-1, required=True)
@click.option("--thread-id", default=None, help="Continue an existing thread.")
def chat_ask(message, thread_id) -> None:
    """Send a single message; print the response."""
    try:
        c = _get_client()
        r = c.chat.send(" ".join(message), thread_id=thread_id)
    except BaseException as exc:
        _die(exc); return
    from .interactive import render_assistant_messages
    render_assistant_messages(console, r.new_messages)
    console.print(f"\n[dim]thread: {r.thread_id}[/dim]")


@chat.group("threads")
def chat_threads() -> None:
    """Manage chat threads."""


@chat_threads.command("list")
def chat_threads_list() -> None:
    try:
        c = _get_client()
        rows = c.chat.threads()
    except BaseException as exc:
        _die(exc); return
    t = Table(show_lines=False, header_style="bold")
    t.add_column("ID", style="dim"); t.add_column("Title", style="cyan"); t.add_column("Updated")
    for th in rows:
        t.add_row(th.id, th.title or "Untitled", str(th.updated_at))
    console.print(t)


@chat_threads.command("delete")
@click.argument("thread_id")
def chat_threads_delete(thread_id) -> None:
    try:
        c = _get_client()
        c.chat.delete_thread(thread_id)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] deleted")


# ---------------------------------------------------------------------------
# Interactive AI mode
# ---------------------------------------------------------------------------


@main.command("ai")
@click.option("--thread-id", default=None, help="Resume an existing thread.")
@click.option("--cohort", default=None, help="Pre-load a saved cohort as the cohort context.")
def ai_mode(thread_id: Optional[str], cohort: Optional[str]) -> None:
    """Open the interactive Turo chat (REPL)."""
    from .interactive import run_repl
    try:
        c = _get_client()
        run_repl(c, console, thread_id=thread_id, cohort_id=cohort)
    except BaseException as exc:
        _die(exc)


# ---------------------------------------------------------------------------
# Validate (self-check)
# ---------------------------------------------------------------------------


@main.command("validate")
def validate() -> None:
    """Run a self-check: auth, schema, one specimen read."""
    try:
        c = _get_client()
        u = c.me()
        s = c.schema()
        sample = next(iter(c.specimens.iter_all(page_size=1)), None)
    except BaseException as exc:
        _die(exc); return
    console.print(f"[green]✓[/green] auth: {u.get('email')}  ({u.get('role')})")
    console.print(f"[green]✓[/green] schema: {len(s.fields)} fields, v{s.version}")
    if sample:
        console.print(f"[green]✓[/green] read OK: 1 specimen ({sample.slide_id_value})")
    else:
        console.print("[yellow]![/yellow] read OK but no specimens in this org")


if __name__ == "__main__":
    main()
