"""Pydantic v2 models mirroring the backend response schemas."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ----- Schema -----

BiobankFieldType = Literal["string", "number", "date", "enum", "boolean"]


class BiobankFieldDef(BaseModel):
    name: str
    type: BiobankFieldType
    label: str
    choices: Optional[List[str]] = None
    searchable: bool = False


class BiobankSchema(BaseModel):
    fields: List[BiobankFieldDef]
    slide_id_field: str
    version: int


# ----- Specimens -----


class SlideRef(BaseModel):
    id: str
    filename: str
    dsa_item_id: Optional[str] = None
    thumbnail_url: Optional[str] = None


class Specimen(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    slide_id_value: str
    metadata: Dict[str, Any]
    slide: Optional[SlideRef] = None
    slides: List[SlideRef] = Field(default_factory=list)
    slide_count: int = 0
    created_at: datetime


class SpecimenList(BaseModel):
    items: List[Specimen]
    total: int
    page: int
    page_size: int


# ----- Filters / cohorts -----

FilterOp = Literal[
    "eq", "ne", "gt", "gte", "lt", "lte", "in", "contains", "between",
]


class FilterClause(BaseModel):
    model_config = ConfigDict(extra="ignore")
    field: str
    op: FilterOp
    value: Any


class Cohort(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    description: Optional[str] = None
    filters: List[FilterClause]
    user_id: str
    author_name: Optional[str] = None
    matching_count: Optional[int] = None
    created_at: datetime
    updated_at: datetime


# ----- Notes -----


class Note(BaseModel):
    id: str
    text: str
    author_id: Optional[str] = None
    author_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# ----- Chat / threads -----


class ChatThread(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    title: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    role: Literal["user", "assistant"]
    content: List[Dict[str, Any]]
    created_at: datetime


class ChatThreadDetail(ChatThread):
    messages: List[ChatMessage] = Field(default_factory=list)


class ChatTurnResponse(BaseModel):
    thread_id: str
    title: Optional[str] = None
    new_messages: List[ChatMessage]


# ----- Tokens -----


class ApiToken(BaseModel):
    id: str
    name: str
    prefix: str
    scopes: List[str]
    last_used_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    revoked_at: Optional[datetime] = None
    created_at: datetime


class ApiTokenCreated(ApiToken):
    token: str


# ----- Export -----


class ExportResponse(BaseModel):
    download_url: str
    row_count: int


# ----- Slide download -----


class SlideDownloadResponse(BaseModel):
    download_url: str
    filename: str
    expires_in: int = 3600


# ----- Grants -----


GrantPermission = Literal["view", "view_download", "edit"]
GrantScopeKind = Literal["biobank", "folder", "cohort"]


class BiobankGrant(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    organization_id: str
    organization_name: Optional[str] = None
    grantee_user_id: str
    grantee_email: Optional[str] = None
    grantee_name: Optional[str] = None
    scope_kind: GrantScopeKind
    scope_id: Optional[str] = None
    scope_label: Optional[str] = None
    permission: GrantPermission
    granted_by: Optional[str] = None
    granted_by_name: Optional[str] = None
    expires_at: datetime
    revoked_at: Optional[datetime] = None
    created_at: datetime
