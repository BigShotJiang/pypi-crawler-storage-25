name: Check and Build

on:
  push:
    branches:
      - master
  pull_request:
  workflow_dispatch:
  release:
    types:
      - released

permissions: read-all

jobs:
  lint:
    name: Lint codebase
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        python: &python-versions
          - "3.11"
          - "3.12"
          - "3.13"
          - "3.14"
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - uses: actions/setup-python@v6
        with:
          python-version: ${{{{ matrix.python }}}}
          cache: pip
      - &install-emake
        name: Install emake
        run: pip install emake
      - name: Run lint
        run: emake lint

  test:
    name: Test
    runs-on: ${{{{ matrix.os }}}}
    strategy:
      matrix:
        python: *python-versions
        os:
          - ubuntu-latest
          - windows-latest
          - macos-latest
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - uses: actions/setup-python@v6
        with:
          python-version: ${{{{ matrix.python }}}}
          cache: pip
      - *install-emake
      - name: Run tests
        run: emake test

  build-sdist:
    name: Build sdist
    needs: &build-needs
      - lint
      - test
    runs-on: ubuntu-latest
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - *install-emake
      - name: Building sdist
        run: emake build --sdist
      - uses: actions/upload-artifact@v6
        with:
          name: pip-sdist
          path: dist/*
          if-no-files-found: error

  build-any-wheel:
    name: Build wheel
    needs: *build-needs
    runs-on: ubuntu-latest
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - *install-emake
      - name: Building wheel
        run: emake build --wheel
      - name: Test wheel
        run: emake test --wheel
      - uses: actions/upload-artifact@v6
        with:
          name: pip-wheel-none-any
          path: dist/*
          if-no-files-found: error

  build-wheel:
    name: Build wheel
    needs: *build-needs
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        python: *python-versions
        arch:
          - x86_64
          - i686
          - ppc64le
          - aarch64
          - armv7l
          - riscv64
          - s390x
        libc:
          - glibc
          - musl
        exclude:
          - arch: i686 # segfaults currently
            python: "3.14"
            libc: glibc
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - *install-emake
      - name: Building wheel
        run: |
          emake build \
            --native-wheel \
            --arch ${{{{ matrix.arch }}}} \
            --libc ${{{{ matrix.libc }}}} \
            --python ${{{{ matrix.python }}}}
      - name: Testing wheel
        run: |
          emake test \
            --wheel \
            --arch ${{{{ matrix.arch }}}} \
            --libc ${{{{ matrix.libc }}}} \
            --python ${{{{ matrix.python }}}}
      - uses: actions/upload-artifact@v6
        with:
          name: pip-wheel-${{{{ matrix.python }}}}-${{{{ matrix.arch }}}}-${{{{ matrix.libc }}}}
          path: dist/*
          if-no-files-found: error

  build-executable:
    name: Build executable
    needs: *build-needs
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        python:
          - "3.11"
        arch:
          - x86_64
          - i686
          - ppc64le
          - aarch64
          - armv7l
          - riscv64
          - s390x
        libc:
          - glibc
          - musl
        exclude:
          - arch: i686 # Currently getting OOM error
          - arch: armv7l # Currently getting OOM error
            libc: glibc
        include:
          - arch: i686
            libc: glibc
            python: "3.11"
            nocompress: true
          - arch: i686
            libc: musl
            python: "3.11"
            nocompress: true
          - arch: armv7l
            libc: glibc
            python: "3.11"
            nocompress: true
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - *install-emake
      - name: Building executable
        run: |
          emake build \
            --executable \
            --arch ${{{{ matrix.arch }}}} \
            --libc ${{{{ matrix.libc }}}} \
            --python ${{{{ matrix.python }}}} \
            ${{{{ matrix.nocompress && '--no-compress' || '' }}}}
      - uses: actions/upload-artifact@v6
        with:
          name: executable-${{{{ matrix.python }}}}-${{{{ matrix.arch }}}}-${{{{ matrix.libc }}}}
          path: dist/*
          if-no-files-found: error

  publish:
    name: Publish to PyPi
    if: github.event_name == 'release' && startsWith(github.ref, 'refs/tags')
    needs: &release-needs
      - build-sdist
      - build-any-wheel
      - build-wheel
      - build-executable
    runs-on: ubuntu-latest
    permissions:
      id-token: write
    environment:
      name: pypi
      url: https://pypi.org/p/{project_name}
    steps:
      - name: Download pip packages
        id: download
        uses: actions/download-artifact@v8
        with:
          pattern: pip-*
          merge-multiple: true
          path: dist
      - name: Publish package distributions to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: ${{{{ steps.download.outputs.download-path }}}}
          skip-existing: true

  release:
    name: Add release artifacts
    if: github.event_name == 'release' && startsWith(github.ref, 'refs/tags')
    needs: *release-needs
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: Checkout the Git repository
        uses: actions/checkout@v6
      - name: Download artifact
        id: download
        uses: actions/download-artifact@v8
        with:
          pattern: pip-*
          merge-multiple: true
          path: dist
      - name: Download executables
        uses: actions/download-artifact@v8
        with:
          pattern: executable-*
          merge-multiple: true
          path: ${{{{ steps.download.outputs.download-path }}}}
      - name: Upload to release
        run: find . -type f | xargs -rI {{}} gh release upload "$TAG" {{}} --clobber
        env:
          GH_TOKEN: ${{{{ github.token }}}}
          TAG: ${{{{ github.event.release.tag_name }}}}
        working-directory: ${{{{ steps.download.outputs.download-path }}}}
