# Benchmarking

This directory contains k6 + Python/Node benchmark tooling for LangGraph API.

## Available Commands

- `make benchmark-ramp` - Ramps up to a set number of concurrent virtual users, holds plateau load, then ramps down.
  - **Environment variables:**
    - `LOAD_SIZE`, `LEVELS`, `PLATEAU_DURATION`
    - `P95_RUN_DURATION`, `AVERAGE_RUN_DURATION`
  - **Example:**
    - `BENCHMARK_PROFILE=streaming-long BENCHMARK_TYPE=stream_write LOAD_SIZE=300 LEVELS=3 make benchmark-ramp`

- `make benchmark-staircase` - Runs stepwise capacity testing with SLO checks and a final staircase summary.
  - **Environment variables:**
    - `K6_EXECUTOR`, `START_LOAD`, `STEP_SIZE`, `NUM_STEPS`, `PLATEAU_DURATION`
    - `MAX_VUS`, `MAX_VUS_MULTIPLIER`, `PRE_ALLOCATED_VUS`
    - `WARMUP_ITERS`, `COOLDOWN_DURATION`
    - `MIN_SUCCESS_RATE`, `MAX_P50_DURATION_MS`, `MAX_P95_DURATION_MS`, `ABORT_ERROR_RATE`
  - **Example:**
    - `BENCHMARK_PROFILE=parallel-small START_LOAD=30 STEP_SIZE=15 NUM_STEPS=10 make benchmark-staircase`

- `make benchmark-capacity` - Runs binary-search capacity tests and writes `capacity_summary.json`.
  - **Environment variables:**
    - `CLUSTER_NAME`
    - `WORKLOAD_NAMES` (comma-separated) or `WORKLOAD_NAME`
  - **Support note:** `BENCHMARK_TYPE` is supported but usually determined by profile/workload defaults.
  - **Example:**
    - `CLUSTER_NAME=dr-1-node WORKLOAD_NAMES=parallel-small,parallel-medium make benchmark-capacity`

- `make benchmark-mixed` - Runs quick and long workloads concurrently to measure contention/fairness.
  - **Environment variables:**
    - `SLOWEST_N`
    - Quick workload knobs: `QUICK_VUS`, `QUICK_ITERATIONS`, `QUICK_STEPS`, `QUICK_DATA_SIZE`, `QUICK_MAX_WAIT_SECONDS`, `QUICK_POLL_INTERVAL`
    - Long workload knobs: `LONG_VUS`, `LONG_ITERATIONS`, `LONG_STEPS`, `LONG_DELAY`, `LONG_DATA_SIZE`, `LONG_MAX_WAIT_SECONDS`, `LONG_POLL_INTERVAL`
  - **Support note:** Does **not** support benchmark universal/profile/context knobs (`BENCHMARK_TYPE`, `BENCHMARK_PROFILE`, `RUN_MODE`, `STREAM_RESUMABLE`, or context overrides). Only mixed-workload vars + generic `BASE_URL`/`LANGSMITH_API_KEY` apply.
  - **Example:**
    - `BASE_URL=http://localhost:9123 QUICK_VUS=300 LONG_VUS=8 LONG_STEPS=60 make benchmark-mixed`

- `make benchmark-charts` - Builds charts from the latest `raw_data_*.json` ramp output. Only works for ramp.
- `make benchmark-clean` - Deletes local benchmark result/chart artifacts.
- `make benchmark-reset` - Cleans benchmark server state via `clean-cli.js`.
- `make benchmark-new-revision` - Triggers a new benchmark deployment revision.

## Benchmark runner types (`BENCHMARK_TYPE`)

The runner contains the actual logic each virtual user will execute during the benchmark and steps to validate the logic worked correctly. Options are:

- `wait_write` - Uses `/runs/wait` and validates completion plus expected counter progression.
- `stream_write` - Uses `/runs/stream` with `stream_mode=['values','messages']` and validates streamed events.
- `assistants` - Benchmarks assistant CRUD/list style API behavior.
- `threads` - Benchmarks thread CRUD/list style API behavior.
- `enqueued_runs_order` - Enqueues multiple runs and validates completion ordering behavior.
- `cancel_first_second_completes` - Starts two runs, cancels one, and validates cancellation semantics.
- `thread_runs_metadata_search` - Creates a run and validates filtering/search by run metadata.
- `threads_search_metadata` - Validates thread metadata search/filter behavior.
- `meta_workload` (randomly delegates to one of the others)

## Profiles (`BENCHMARK_PROFILE`)

Profiles are quick ways to configure the benchmark graph for any run depending on the use case.

- `default` - Baseline single-step stateless profile with small checkpoint writes.
- `streaming-long` - Long-running stateful streaming profile with 2KB regular chunks and occasional 2MB spikes.
- `stateless-parallel-small` - Stateless high-fanout profile with small checkpoint payloads.
- `stateless-parallel-medium` - Stateless high-fanout profile with medium checkpoint payloads.
- `parallel-small` - Stateful high-fanout profile with small checkpoint payloads.
- `parallel-medium` - Stateful high-fanout profile with medium checkpoint payloads.

Each profile defines:

- `context` (delay/steps/checkpoint/streaming/burst knobs)
- `capacity` defaults (`runMode`, `rampEndBase`, `runExecutionTimeoutSeconds`)
- `resumable` default (can be overridden by `STREAM_RESUMABLE`)

## Core environment knobs

Common:

- `BASE_URL` - Target LangGraph API endpoint for benchmark traffic.
- `LANGSMITH_API_KEY` - API key used for authenticated benchmark deployments.
- `BENCHMARK_TYPE` - Selects which runner implementation to execute.
- `BENCHMARK_PROFILE` - Selects a named profile from `benchmark_profiles.ts`.
- `RUN_MODE` (`stateless`/`stateful`) - Controls whether runs execute directly or via created threads.
- `STREAM_RESUMABLE` - Overrides profile default for resumable stream persistence.

Context overrides (merged on top of profile):

- `DELAY` - Per-node sleep delay in seconds.
- `DELAY_JITTER_RATIO` - Randomized delay spread ratio around `DELAY` (for desynchronizing requests).
- `EXPAND` - Fanout width (number of parallel branches at start).
- `STEPS` - Number of graph turns/iterations to execute.
- `CHECKPOINT_SIZE` - Bytes written per checkpoint operation.
- `LLM_ENABLED` - Enables fake LLM streaming inside the benchmark graph.
- `STREAM_SIZE` - Normal total streamed payload size (bytes).
- `CHUNK_SIZE` - Stream chunk size (bytes) when emitting payload.
- `BURST_MODE` - Enables probabilistic burst streaming behavior.
- `BURST_PROBABILITY` - Probability that a run uses burst payload size.
- `BURST_SIZE` - Burst payload size (bytes) when burst mode triggers.

## Common commands

```bash
# Ramp benchmark (default profile + wait_write unless overridden)
make benchmark-ramp

# Ramp with profile + stream runner
BENCHMARK_PROFILE=streaming-long BENCHMARK_TYPE=stream_write make benchmark-ramp

# Staircase benchmark
make benchmark-staircase

# Capacity benchmark (single workload)
CLUSTER_NAME=dr-1-node WORKLOAD_NAME=parallel-small make benchmark-capacity

# Capacity benchmark (multiple workloads)
CLUSTER_NAME=dr-1-node WORKLOAD_NAMES=parallel-small,parallel-medium make benchmark-capacity

# Mixed workload benchmark
make benchmark-mixed

# Build charts from latest ramp raw_data file
make benchmark-charts

# Remove local benchmark artifacts
make benchmark-clean
```

## Outputs

- Ramp:
  - `raw_data_<timestamp>.json`
  - `results_<timestamp>.json`
  - `summary_<timestamp>.json`
  - `*_chart_*.png` (when chart generation is run)
- Staircase:
  - `staircase_summary.json`
- Capacity:
  - `capacity_summary.json`
- Mixed:
  - `mixed_workload_*.json`

## CI workflows

- Daily ramp benchmark: `.github/workflows/benchmark.yml`
- Capacity benchmark matrix: `.github/workflows/benchmark-capacity.yml`
- Mixed benchmark matrix: `.github/workflows/benchmark-mixed.yml`

## References

- [k6 docs](https://k6.io/docs/)
- [k6 JavaScript API](https://k6.io/docs/javascript-api/)
