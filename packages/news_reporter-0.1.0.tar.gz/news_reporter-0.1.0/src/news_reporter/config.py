"""Configuration constants and curated source list."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
PACKAGE_ROOT = Path(__file__).resolve().parent

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

DB_PATH = Path(os.getenv("NEWS_DB_PATH", PROJECT_ROOT / "news.db")).resolve()
PHOTOCARD_DIR = Path(
    os.getenv("PHOTOCARD_OUTPUT_DIR", PROJECT_ROOT / "photocards")
).resolve()
FONTS_DIR = PACKAGE_ROOT / "assets" / "fonts"

SEARCH_CACHE_TTL_SECONDS = 3600
ARTICLE_CACHE_TTL_SECONDS = 86400

HTTP_TIMEOUT_SECONDS = 8.0
HTTP_RETRIES = 3
HTTP_BACKOFF_BASE = 1.0

SEARCH_TOTAL_BUDGET_SECONDS = 15.0

USER_AGENT = "news-reporter/0.1 (+https://github.com/faithdevs/news-reporter)"

# Curated feeds verified to be live + free. Reuters/AP discontinued public RSS.
RSS_FEEDS: list[dict[str, str]] = [
    {"name": "BBC World", "url": "https://feeds.bbci.co.uk/news/world/rss.xml"},
    {"name": "BBC Top", "url": "https://feeds.bbci.co.uk/news/rss.xml"},
    {"name": "Guardian World", "url": "https://www.theguardian.com/world/rss"},
    {"name": "Guardian US", "url": "https://www.theguardian.com/us-news/rss"},
    {"name": "Al Jazeera", "url": "https://www.aljazeera.com/xml/rss/all.xml"},
    {"name": "NPR News", "url": "https://feeds.npr.org/1001/rss.xml"},
    {"name": "DW Top", "url": "https://rss.dw.com/rdf/rss-en-all"},
    {"name": "NYT World", "url": "https://rss.nytimes.com/services/xml/rss/nyt/World.xml"},
    {"name": "Hacker News Top", "url": "https://hnrss.org/frontpage"},
]

GDELT_DOC_URL = "https://api.gdeltproject.org/api/v2/doc/doc"
GDELT_MAX_RECORDS = 25
