"""Shared dataclasses."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass(slots=True)
class Article:
    url: str
    source: str
    headline: str
    published_at: str | None = None
    snippet: str | None = None
    full_text: str | None = None
    fetched_at: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class SearchResult:
    query: str
    articles: list[Article] = field(default_factory=list)
    partial: bool = False
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "articles": [a.to_dict() for a in self.articles],
            "partial": self.partial,
            "errors": self.errors,
            "count": len(self.articles),
        }
