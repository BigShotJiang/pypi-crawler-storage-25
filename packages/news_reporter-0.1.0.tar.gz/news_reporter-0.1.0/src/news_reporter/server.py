"""News MCP server entrypoint (FastMCP).

Transport selection via env var:

    MCP_TRANSPORT=stdio              (default; for Claude Desktop, Cursor, Inspector)
    MCP_TRANSPORT=streamable-http    (for remote hosting; Smithery, Fly, Railway, etc.)
    MCP_TRANSPORT=sse                (legacy SSE transport)

When using HTTP/SSE, set HOST and PORT (defaults: 0.0.0.0 / 8000).
"""

from __future__ import annotations

import logging
import os

from mcp.server.fastmcp import FastMCP

from . import config, db
from .tools.photocard import create_photocard as _create_photocard
from .tools.report import generate_report_structure as _generate_report_structure
from .tools.search import search_news as _search_news

logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("news_reporter")

_HOST = os.getenv("HOST", "0.0.0.0")
_PORT = int(os.getenv("PORT", "8000"))

mcp = FastMCP("news-reporter", host=_HOST, port=_PORT)


@mcp.tool()
async def search_news(
    query: str,
    max_results: int = 10,
    date_from: str | None = None,
    date_to: str | None = None,
) -> dict:
    """Search global news from RSS feeds + GDELT.

    Args:
        query: Topic or keywords to search for.
        max_results: Maximum articles to return (default 10).
        date_from: Optional ISO date (YYYY-MM-DD) lower bound.
        date_to: Optional ISO date (YYYY-MM-DD) upper bound.

    Returns:
        Dict with `articles` (list), `count`, `partial`, `errors`, `cache_hit`.
    """
    return await _search_news(query, max_results, date_from, date_to)


@mcp.tool()
def generate_report_structure(articles: list[dict], topic: str) -> str:
    """Build a structured Markdown report skeleton from aggregated articles.

    The skeleton contains Executive Summary, Key Events / Timeline, Conflicting
    Perspectives, Impact Analysis, and raw Source Articles sections. Synthesis
    sections are left as HTML comments for the consumer LLM to fill in.

    Args:
        articles: List of article dicts (as returned by search_news).
        topic: Report topic, used as the title.

    Returns:
        Markdown string.
    """
    return _generate_report_structure(articles, topic)


@mcp.tool()
def create_photocard(
    headline: str,
    subtitle: str | None = None,
    output_path: str | None = None,
) -> dict:
    """Render a 1080x1080 PNG photocard with headline overlay.

    Args:
        headline: Main headline text (auto-fitted, max 4 lines).
        subtitle: Optional secondary line.
        output_path: Optional file path; defaults to ./photocards/<slug>-<ts>.png.

    Returns:
        Dict with `path`, `base64`, `width`, `height`, `mime_type`.
    """
    return _create_photocard(headline, subtitle, output_path)


def main() -> None:
    db.init_db()
    transport = os.getenv("MCP_TRANSPORT", "stdio").lower()
    if transport not in {"stdio", "streamable-http", "sse"}:
        log.warning("Unknown MCP_TRANSPORT=%s, falling back to stdio", transport)
        transport = "stdio"
    log.info(
        "News MCP server starting (transport=%s, db=%s)", transport, config.DB_PATH
    )
    if transport == "stdio":
        mcp.run()
    else:
        mcp.run(transport=transport)


if __name__ == "__main__":
    main()
