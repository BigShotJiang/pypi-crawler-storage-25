"""Best-effort article full-text extraction via BeautifulSoup."""

from __future__ import annotations

import logging
import re

import httpx
from bs4 import BeautifulSoup

from .. import config

log = logging.getLogger(__name__)

_WS_RE = re.compile(r"\s+")


def _extract_text(soup: BeautifulSoup) -> str | None:
    for selector in ("article", "main", "div[role=main]"):
        node = soup.select_one(selector)
        if node:
            text = node.get_text(separator=" ", strip=True)
            if text and len(text) > 200:
                return _WS_RE.sub(" ", text).strip()
    paragraphs = soup.find_all("p")
    if paragraphs:
        joined = " ".join(p.get_text(" ", strip=True) for p in paragraphs)
        if len(joined) > 200:
            return _WS_RE.sub(" ", joined).strip()
    return None


def _extract_og_description(soup: BeautifulSoup) -> str | None:
    tag = soup.find("meta", attrs={"property": "og:description"})
    if tag and tag.get("content"):
        return tag["content"].strip()
    tag = soup.find("meta", attrs={"name": "description"})
    if tag and tag.get("content"):
        return tag["content"].strip()
    return None


async def scrape_full_text(url: str, client: httpx.AsyncClient | None = None) -> str | None:
    """Fetch URL and return body text, or None on failure."""
    headers = {"User-Agent": config.USER_AGENT}
    own_client = client is None
    if own_client:
        client = httpx.AsyncClient(headers=headers, follow_redirects=True)
    try:
        resp = await client.get(url, timeout=config.HTTP_TIMEOUT_SECONDS)
        resp.raise_for_status()
        ctype = resp.headers.get("content-type", "")
        if "html" not in ctype.lower():
            return None
        soup = BeautifulSoup(resp.text, "lxml")
        return _extract_text(soup) or _extract_og_description(soup)
    except (httpx.HTTPError, httpx.InvalidURL) as exc:
        log.debug("Scrape failed for %s: %s", url, exc)
        return None
    finally:
        if own_client and client is not None:
            await client.aclose()
