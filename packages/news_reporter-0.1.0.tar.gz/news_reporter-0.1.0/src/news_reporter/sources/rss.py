"""RSS feed aggregation via feedparser."""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timezone
from time import mktime

import feedparser
import httpx

from .. import config
from ..models import Article

log = logging.getLogger(__name__)

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> set[str]:
    return set(_TOKEN_RE.findall(text.lower()))


def _matches(query: str, *fields: str | None) -> bool:
    q_tokens = _tokenize(query)
    if not q_tokens:
        return True
    haystack = " ".join(f for f in fields if f).lower()
    if query.lower() in haystack:
        return True
    h_tokens = _tokenize(haystack)
    return q_tokens.issubset(h_tokens)


def _entry_published_iso(entry) -> str | None:
    for key in ("published_parsed", "updated_parsed"):
        ts = entry.get(key)
        if ts:
            try:
                dt = datetime.fromtimestamp(mktime(ts), tz=timezone.utc)
                return dt.isoformat()
            except (ValueError, OverflowError):
                continue
    return None


def _entry_to_article(entry, source_name: str) -> Article | None:
    url = entry.get("link") or entry.get("id")
    headline = entry.get("title")
    if not url or not headline:
        return None
    snippet = entry.get("summary") or entry.get("description")
    if snippet:
        snippet = re.sub(r"<[^>]+>", "", snippet).strip()
        if len(snippet) > 500:
            snippet = snippet[:497] + "..."
    return Article(
        url=url,
        source=source_name,
        headline=headline.strip(),
        published_at=_entry_published_iso(entry),
        snippet=snippet,
    )


async def _fetch_one(client: httpx.AsyncClient, feed: dict[str, str]) -> tuple[str, str | None]:
    url = feed["url"]
    try:
        resp = await client.get(url, timeout=config.HTTP_TIMEOUT_SECONDS)
        resp.raise_for_status()
        return feed["name"], resp.text
    except (httpx.HTTPError, httpx.InvalidURL) as exc:
        log.warning("RSS fetch failed for %s: %s", url, exc)
        return feed["name"], None


def _parse(name: str, body: str | None, query: str) -> list[Article]:
    if not body:
        return []
    parsed = feedparser.parse(body)
    out: list[Article] = []
    for entry in parsed.entries:
        article = _entry_to_article(entry, name)
        if article and _matches(query, article.headline, article.snippet):
            out.append(article)
    return out


async def fetch_rss(
    query: str,
    feeds: list[dict[str, str]] | None = None,
) -> tuple[list[Article], list[str]]:
    """Fetch all configured feeds in parallel, filter by query. Returns (articles, errors)."""
    feeds = feeds if feeds is not None else config.RSS_FEEDS
    headers = {"User-Agent": config.USER_AGENT}
    errors: list[str] = []
    async with httpx.AsyncClient(headers=headers, follow_redirects=True) as client:
        results = await asyncio.gather(
            *(_fetch_one(client, f) for f in feeds), return_exceptions=False
        )
    articles: list[Article] = []
    for (name, body), feed in zip(results, feeds):
        if body is None:
            errors.append(f"rss:{name}")
            continue
        try:
            articles.extend(_parse(name, body, query))
        except Exception as exc:  # noqa: BLE001 - feedparser swallows most errors itself
            log.warning("RSS parse failed for %s: %s", feed["url"], exc)
            errors.append(f"rss-parse:{name}")
    return articles, errors
