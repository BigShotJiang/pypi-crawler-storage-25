"""GDELT 2.0 DOC API client (no auth required)."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

import httpx

from .. import config
from ..models import Article

log = logging.getLogger(__name__)


def _parse_gdelt_date(s: str | None) -> str | None:
    """GDELT formats observed: YYYYMMDDHHMMSS or YYYYMMDDTHHMMSSZ."""
    if not s:
        return None
    cleaned = s.replace("T", "").replace("Z", "").strip()
    if len(cleaned) < 14:
        return None
    try:
        dt = datetime.strptime(cleaned[:14], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat()
    except ValueError:
        return None


def _normalize(article_json: dict) -> Article | None:
    url = article_json.get("url")
    title = article_json.get("title")
    if not url or not title:
        return None
    domain = article_json.get("domain") or "GDELT"
    return Article(
        url=url,
        source=domain,
        headline=title.strip(),
        published_at=_parse_gdelt_date(article_json.get("seendate")),
        snippet=None,
    )


async def fetch_gdelt(
    query: str,
    max_records: int = config.GDELT_MAX_RECORDS,
    date_from: str | None = None,
    date_to: str | None = None,
) -> tuple[list[Article], list[str]]:
    """Query GDELT DOC API. Returns (articles, errors)."""
    params = {
        "query": query,
        "mode": "ArtList",
        "format": "json",
        "maxrecords": str(max_records),
        "sort": "DateDesc",
    }
    if date_from:
        params["startdatetime"] = _to_gdelt_dt(date_from, end=False)
    if date_to:
        params["enddatetime"] = _to_gdelt_dt(date_to, end=True)

    headers = {"User-Agent": config.USER_AGENT}
    errors: list[str] = []
    last_exc: Exception | None = None
    for attempt in range(config.HTTP_RETRIES):
        try:
            async with httpx.AsyncClient(headers=headers, follow_redirects=True) as client:
                resp = await client.get(
                    config.GDELT_DOC_URL,
                    params=params,
                    timeout=config.HTTP_TIMEOUT_SECONDS,
                )
            if resp.status_code == 429:
                errors.append("gdelt:rate-limited")
                await asyncio.sleep(config.HTTP_BACKOFF_BASE * (2 ** attempt))
                continue
            resp.raise_for_status()
            try:
                payload = resp.json()
            except ValueError:
                errors.append("gdelt:invalid-json")
                return [], errors
            raw = payload.get("articles", []) if isinstance(payload, dict) else []
            out: list[Article] = []
            for item in raw:
                a = _normalize(item)
                if a:
                    out.append(a)
            return out, errors
        except httpx.HTTPError as exc:
            last_exc = exc
            log.warning("GDELT attempt %d failed: %s", attempt + 1, exc)
            await asyncio.sleep(config.HTTP_BACKOFF_BASE * (2 ** attempt))
    if last_exc:
        errors.append(f"gdelt:{type(last_exc).__name__}")
    return [], errors


def _to_gdelt_dt(iso_or_date: str, end: bool) -> str:
    """Convert ISO 8601 (or YYYY-MM-DD) to GDELT YYYYMMDDHHMMSS."""
    s = iso_or_date.strip()
    try:
        if "T" in s:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        else:
            dt = datetime.strptime(s, "%Y-%m-%d")
            if end:
                dt = dt.replace(hour=23, minute=59, second=59)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).strftime("%Y%m%d%H%M%S")
    except ValueError:
        return ""
