"""search_news MCP tool implementation."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime

from .. import config, db
from ..models import Article, SearchResult
from ..sources import gdelt, rss

log = logging.getLogger(__name__)


def _within_range(article: Article, date_from: str | None, date_to: str | None) -> bool:
    if not date_from and not date_to:
        return True
    if not article.published_at:
        return True  # do not filter out articles with unknown date
    try:
        pub = datetime.fromisoformat(article.published_at.replace("Z", "+00:00"))
    except ValueError:
        return True
    if date_from:
        try:
            df = datetime.fromisoformat(date_from)
            if pub.tzinfo is None:
                pub = pub.replace(tzinfo=df.tzinfo)
            if df.tzinfo is None and pub.tzinfo is not None:
                df = df.replace(tzinfo=pub.tzinfo)
            if pub < df:
                return False
        except ValueError:
            pass
    if date_to:
        try:
            dt = datetime.fromisoformat(date_to)
            if pub.tzinfo is None and dt.tzinfo is not None:
                pub = pub.replace(tzinfo=dt.tzinfo)
            if dt.tzinfo is None and pub.tzinfo is not None:
                dt = dt.replace(tzinfo=pub.tzinfo)
            if pub > dt:
                return False
        except ValueError:
            pass
    return True


def _dedupe_by_url(articles: list[Article]) -> list[Article]:
    seen: set[str] = set()
    out: list[Article] = []
    for a in articles:
        if a.url in seen:
            continue
        seen.add(a.url)
        out.append(a)
    return out


def _sort_key(a: Article) -> str:
    return a.published_at or ""


async def _gather_sources(
    query: str, date_from: str | None, date_to: str | None
) -> tuple[list[Article], list[str]]:
    rss_task = asyncio.create_task(rss.fetch_rss(query))
    gdelt_task = asyncio.create_task(
        gdelt.fetch_gdelt(query, date_from=date_from, date_to=date_to)
    )
    try:
        results = await asyncio.wait_for(
            asyncio.gather(rss_task, gdelt_task, return_exceptions=True),
            timeout=config.SEARCH_TOTAL_BUDGET_SECONDS,
        )
    except asyncio.TimeoutError:
        rss_task.cancel()
        gdelt_task.cancel()
        return [], ["search:timeout"]

    articles: list[Article] = []
    errors: list[str] = []
    for res in results:
        if isinstance(res, BaseException):
            log.warning("source error: %s", res)
            errors.append(f"source:{type(res).__name__}")
            continue
        a_list, errs = res
        articles.extend(a_list)
        errors.extend(errs)
    return articles, errors


async def search_news(
    query: str,
    max_results: int = 10,
    date_from: str | None = None,
    date_to: str | None = None,
    db_path: str | None = None,
) -> dict:
    """Search news from RSS + GDELT, cached in SQLite."""
    if not query or not query.strip():
        return SearchResult(query=query, errors=["empty-query"]).to_dict()

    qhash = db.query_hash(query, date_from, date_to)
    cached = db.get_search(qhash, db_path=db_path)
    if cached is not None:
        filtered = [a for a in cached if _within_range(a, date_from, date_to)]
        result = SearchResult(query=query, articles=filtered[:max_results])
        return {**result.to_dict(), "cache_hit": True}

    articles, errors = await _gather_sources(query, date_from, date_to)
    articles = [a for a in articles if _within_range(a, date_from, date_to)]
    articles = _dedupe_by_url(articles)
    articles.sort(key=_sort_key, reverse=True)

    for a in articles:
        db.put_article(a, db_path=db_path)
    db.put_search(qhash, query, [a.url for a in articles], db_path=db_path)

    partial = bool(errors)
    final = articles[:max_results]
    result = SearchResult(query=query, articles=final, partial=partial, errors=errors)
    return {**result.to_dict(), "cache_hit": False}
