"""create_photocard MCP tool implementation."""

from __future__ import annotations

import base64
import hashlib
import io
import re
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .. import config

CANVAS_SIZE = 1080
MARGIN = 80
HEADLINE_MAX_LINES = 4
HEADLINE_INITIAL_PX = 84
HEADLINE_MIN_PX = 36
SUBTITLE_PX = 36
WATERMARK_PX = 22

PALETTE: list[tuple[tuple[int, int, int], tuple[int, int, int]]] = [
    ((20, 24, 38), (90, 28, 64)),
    ((6, 24, 36), (12, 56, 80)),
    ((30, 12, 36), (108, 28, 60)),
    ((10, 30, 20), (28, 80, 56)),
    ((28, 12, 12), (96, 36, 28)),
    ((8, 16, 32), (24, 48, 96)),
    ((24, 18, 8), (96, 60, 16)),
    ((16, 8, 24), (52, 16, 72)),
]

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(text: str, max_len: int = 60) -> str:
    s = _SLUG_RE.sub("-", text.lower()).strip("-")
    return s[:max_len] or "photocard"


def _palette_for(headline: str) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    h = int(hashlib.sha256(headline.encode("utf-8")).hexdigest(), 16)
    return PALETTE[h % len(PALETTE)]


def _gradient_bg(top: tuple[int, int, int], bottom: tuple[int, int, int]) -> Image.Image:
    img = Image.new("RGB", (CANVAS_SIZE, CANVAS_SIZE), top)
    draw = ImageDraw.Draw(img)
    for y in range(CANVAS_SIZE):
        t = y / (CANVAS_SIZE - 1)
        r = int(top[0] + (bottom[0] - top[0]) * t)
        g = int(top[1] + (bottom[1] - top[1]) * t)
        b = int(top[2] + (bottom[2] - top[2]) * t)
        draw.line([(0, y), (CANVAS_SIZE, y)], fill=(r, g, b))
    return img.filter(ImageFilter.SMOOTH)


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    bundled = config.FONTS_DIR / "DejaVuSans-Bold.ttf"
    if bundled.exists():
        return ImageFont.truetype(str(bundled), size=size)
    return ImageFont.load_default(size=size)


def _wrap_text(
    text: str, font: ImageFont.FreeTypeFont, max_width: int, draw: ImageDraw.ImageDraw
) -> list[str]:
    words = text.split()
    if not words:
        return []
    lines: list[str] = []
    current = words[0]
    for w in words[1:]:
        candidate = f"{current} {w}"
        if draw.textlength(candidate, font=font) <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = w
    lines.append(current)
    return lines


def _fit_headline(
    text: str, max_width: int, max_lines: int, draw: ImageDraw.ImageDraw
) -> tuple[ImageFont.FreeTypeFont, list[str]]:
    size = HEADLINE_INITIAL_PX
    while size >= HEADLINE_MIN_PX:
        font = _load_font(size)
        lines = _wrap_text(text, font, max_width, draw)
        if len(lines) <= max_lines and all(
            draw.textlength(line, font=font) <= max_width for line in lines
        ):
            return font, lines
        size -= 4
    font = _load_font(HEADLINE_MIN_PX)
    lines = _wrap_text(text, font, max_width, draw)
    return font, lines[:max_lines]


def _line_height(font: ImageFont.FreeTypeFont) -> int:
    ascent, descent = font.getmetrics()
    return int((ascent + descent) * 1.15)


def create_photocard(
    headline: str,
    subtitle: str | None = None,
    output_path: str | None = None,
) -> dict:
    """Render a 1080x1080 photocard PNG. Returns path + base64."""
    if not headline or not headline.strip():
        raise ValueError("headline must be a non-empty string")

    top, bottom = _palette_for(headline)
    img = _gradient_bg(top, bottom)
    draw = ImageDraw.Draw(img, "RGBA")

    # Subtle vignette / dark band behind text for legibility
    band = Image.new("RGBA", (CANVAS_SIZE, CANVAS_SIZE), (0, 0, 0, 0))
    band_draw = ImageDraw.Draw(band)
    band_draw.rectangle([0, 240, CANVAS_SIZE, 840], fill=(0, 0, 0, 60))
    img = Image.alpha_composite(img.convert("RGBA"), band)
    draw = ImageDraw.Draw(img)

    text_max_width = CANVAS_SIZE - 2 * MARGIN
    headline_font, headline_lines = _fit_headline(
        headline.strip(), text_max_width, HEADLINE_MAX_LINES, draw
    )

    line_h = _line_height(headline_font)
    total_h = line_h * len(headline_lines)
    if subtitle:
        total_h += int(SUBTITLE_PX * 1.6) + 20
    y = (CANVAS_SIZE - total_h) // 2

    for line in headline_lines:
        w = draw.textlength(line, font=headline_font)
        x = (CANVAS_SIZE - w) // 2
        draw.text((x + 2, y + 2), line, font=headline_font, fill=(0, 0, 0, 180))
        draw.text((x, y), line, font=headline_font, fill=(255, 255, 255, 255))
        y += line_h

    if subtitle:
        sub_font = _load_font(SUBTITLE_PX)
        sub_lines = _wrap_text(subtitle.strip(), sub_font, text_max_width, draw)[:2]
        y += 20
        for line in sub_lines:
            w = draw.textlength(line, font=sub_font)
            x = (CANVAS_SIZE - w) // 2
            draw.text((x, y), line, font=sub_font, fill=(230, 230, 230, 230))
            y += int(SUBTITLE_PX * 1.4)

    wm_font = _load_font(WATERMARK_PX)
    watermark = "news-reporter"
    wm_w = draw.textlength(watermark, font=wm_font)
    draw.text(
        (CANVAS_SIZE - MARGIN - wm_w, CANVAS_SIZE - MARGIN),
        watermark,
        font=wm_font,
        fill=(255, 255, 255, 153),
    )

    final = img.convert("RGB")

    if output_path:
        out = Path(output_path)
    else:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        out = config.PHOTOCARD_DIR / f"{_slug(headline)}-{ts}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    final.save(out, format="PNG", optimize=True)

    buf = io.BytesIO()
    final.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")

    return {
        "path": str(out),
        "base64": b64,
        "width": CANVAS_SIZE,
        "height": CANVAS_SIZE,
        "mime_type": "image/png",
    }
