"""generate_report_structure MCP tool implementation."""

from __future__ import annotations

from datetime import datetime, timezone


def _fmt_date(s: str | None) -> str:
    if not s:
        return "Unknown date"
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return s


def _fmt_datetime(s: str | None) -> str:
    if not s:
        return "Unknown date"
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except ValueError:
        return s


def _published_key(article: dict) -> str:
    return article.get("published_at") or ""


def generate_report_structure(articles: list[dict], topic: str) -> str:
    """Build a Markdown report skeleton from aggregated articles.

    The consumer LLM fills in synthesis sections (Executive Summary, Conflicting
    Perspectives, Impact Analysis) using the structured evidence below.
    """
    if not articles:
        return (
            f"# Report: {topic}\n\n"
            f"_Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}_\n\n"
            "_No articles available for this topic._\n"
        )

    sorted_articles = sorted(articles, key=_published_key)
    sources = sorted({a.get("source", "Unknown") for a in sorted_articles})
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    timeline_lines = []
    for a in sorted_articles:
        date = _fmt_date(a.get("published_at"))
        headline = a.get("headline", "Untitled")
        source = a.get("source", "Unknown")
        url = a.get("url", "")
        timeline_lines.append(f"- **{date}** — {headline} ({source}) — {url}")

    raw_lines = []
    for i, a in enumerate(sorted_articles, start=1):
        raw_lines.append(f"### {i}. {a.get('headline', 'Untitled')}")
        raw_lines.append(
            f"- **Source:** {a.get('source', 'Unknown')}  "
            f"| **Published:** {_fmt_datetime(a.get('published_at'))}"
        )
        raw_lines.append(f"- **URL:** {a.get('url', '')}")
        snippet = a.get("snippet")
        if snippet:
            raw_lines.append(f"- **Snippet:** {snippet}")
        full_text = a.get("full_text")
        if full_text:
            preview = full_text if len(full_text) <= 1500 else full_text[:1500] + "..."
            raw_lines.append(f"- **Full text (truncated):** {preview}")
        raw_lines.append("")

    return (
        f"# Report: {topic}\n"
        f"_Generated: {timestamp} | Sources: {len(sorted_articles)} articles "
        f"from {len(sources)} outlets ({', '.join(sources)})_\n\n"
        "## Executive Summary\n"
        "<!-- LLM: synthesize 3-5 sentences from articles below -->\n\n"
        "## Key Events / Timeline\n" + "\n".join(timeline_lines) + "\n\n"
        "## Conflicting Perspectives\n"
        "<!-- LLM: identify divergent framings across sources; reference URLs -->\n\n"
        "## Impact Analysis\n"
        "<!-- LLM: short, medium, long-term impacts -->\n\n"
        "## Source Articles (raw)\n" + "\n".join(raw_lines)
    )
