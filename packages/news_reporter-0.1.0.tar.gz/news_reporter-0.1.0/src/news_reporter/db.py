"""SQLite cache layer for articles + search results."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from . import config
from .models import Article

SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    url TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    headline TEXT NOT NULL,
    published_at TEXT,
    snippet TEXT,
    full_text TEXT,
    fetched_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS search_cache (
    query_hash TEXT PRIMARY KEY,
    query TEXT NOT NULL,
    article_urls_json TEXT NOT NULL,
    cached_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);
CREATE INDEX IF NOT EXISTS idx_articles_source ON articles(source);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def query_hash(query: str, date_from: str | None, date_to: str | None) -> str:
    payload = f"{query.strip().lower()}|{date_from or ''}|{date_to or ''}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


_INITIALIZED: set[str] = set()


@contextmanager
def connect(db_path: Path | str | None = None) -> Iterator[sqlite3.Connection]:
    path = str(db_path) if db_path is not None else str(config.DB_PATH)
    if path not in _INITIALIZED:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        _bootstrap = sqlite3.connect(path, isolation_level=None)
        try:
            _bootstrap.executescript(SCHEMA)
        finally:
            _bootstrap.close()
        _INITIALIZED.add(path)
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        yield conn
    finally:
        conn.close()


def init_db(db_path: Path | str | None = None) -> None:
    path = str(Path(db_path).resolve()) if db_path is not None else str(config.DB_PATH)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as conn:
        conn.executescript(SCHEMA)
    _INITIALIZED.add(path)


def _row_to_article(row: sqlite3.Row) -> Article:
    return Article(
        url=row["url"],
        source=row["source"],
        headline=row["headline"],
        published_at=row["published_at"],
        snippet=row["snippet"],
        full_text=row["full_text"],
        fetched_at=row["fetched_at"],
    )


def put_article(article: Article, db_path: Path | str | None = None) -> None:
    if not article.fetched_at:
        article.fetched_at = now_iso()
    with connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO articles (url, source, headline, published_at, snippet, full_text, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(url) DO UPDATE SET
                source=excluded.source,
                headline=excluded.headline,
                published_at=excluded.published_at,
                snippet=COALESCE(excluded.snippet, articles.snippet),
                full_text=COALESCE(excluded.full_text, articles.full_text),
                fetched_at=excluded.fetched_at
            """,
            (
                article.url,
                article.source,
                article.headline,
                article.published_at,
                article.snippet,
                article.full_text,
                article.fetched_at,
            ),
        )


def get_article(url: str, db_path: Path | str | None = None) -> Article | None:
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM articles WHERE url = ?", (url,)).fetchone()
        return _row_to_article(row) if row else None


def is_article_fresh(article: Article, ttl_seconds: int = config.ARTICLE_CACHE_TTL_SECONDS) -> bool:
    if not article.fetched_at:
        return False
    fetched = datetime.fromisoformat(article.fetched_at)
    age = (datetime.now(timezone.utc) - fetched).total_seconds()
    return age < ttl_seconds


def put_search(qhash: str, query: str, urls: list[str], db_path: Path | str | None = None) -> None:
    with connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO search_cache (query_hash, query, article_urls_json, cached_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(query_hash) DO UPDATE SET
                query=excluded.query,
                article_urls_json=excluded.article_urls_json,
                cached_at=excluded.cached_at
            """,
            (qhash, query, json.dumps(urls), now_iso()),
        )


def get_search(
    qhash: str,
    ttl_seconds: int = config.SEARCH_CACHE_TTL_SECONDS,
    db_path: Path | str | None = None,
) -> list[Article] | None:
    with connect(db_path) as conn:
        row = conn.execute(
            "SELECT * FROM search_cache WHERE query_hash = ?", (qhash,)
        ).fetchone()
        if not row:
            return None
        cached = datetime.fromisoformat(row["cached_at"])
        age = (datetime.now(timezone.utc) - cached).total_seconds()
        if age >= ttl_seconds:
            return None
        urls = json.loads(row["article_urls_json"])
        if not urls:
            return []
        placeholders = ",".join("?" * len(urls))
        rows = conn.execute(
            f"SELECT * FROM articles WHERE url IN ({placeholders})", urls
        ).fetchall()
        by_url = {r["url"]: _row_to_article(r) for r in rows}
        return [by_url[u] for u in urls if u in by_url]


def purge_expired(db_path: Path | str | None = None) -> dict[str, int]:
    """Remove expired search cache entries and stale articles. Returns counts."""
    with connect(db_path) as conn:
        search_cutoff = (
            datetime.now(timezone.utc).timestamp() - config.SEARCH_CACHE_TTL_SECONDS
        )
        article_cutoff = (
            datetime.now(timezone.utc).timestamp() - config.ARTICLE_CACHE_TTL_SECONDS
        )
        s_iso = datetime.fromtimestamp(search_cutoff, tz=timezone.utc).isoformat()
        a_iso = datetime.fromtimestamp(article_cutoff, tz=timezone.utc).isoformat()
        s_count = conn.execute(
            "DELETE FROM search_cache WHERE cached_at < ?", (s_iso,)
        ).rowcount
        a_count = conn.execute(
            "DELETE FROM articles WHERE fetched_at < ?", (a_iso,)
        ).rowcount
        return {"search_cache_deleted": s_count, "articles_deleted": a_count}
