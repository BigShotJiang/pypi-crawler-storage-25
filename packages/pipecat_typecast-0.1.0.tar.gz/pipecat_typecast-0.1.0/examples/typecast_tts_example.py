"""Basic example of using TypecastTTSService with Pipecat.

Prerequisites:
    pip install pipecat-typecast "pipecat-ai[daily,openai,silero]"

    Set environment variables:
        TYPECAST_API_KEY   - your Typecast API key
        DAILY_API_KEY      - your Daily API key (for WebRTC transport)
        DAILY_ROOM_URL     - your Daily room URL
        OPENAI_API_KEY     - your OpenAI API key

Usage:
    python typecast_tts_example.py
"""

import asyncio
import os

from loguru import logger

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import LLMRunFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.transports.daily.transport import DailyParams, DailyTranscriptionSettings, DailyTransport
from pipecat_typecast import TypecastTTSService

# Replace with your preferred voice ID from the Typecast voice library
VOICE_ID = "tc_689450bdcce4027c2f06eee8"


async def main():
    transport = DailyTransport(
        os.environ["DAILY_ROOM_URL"],
        None,
        "Typecast Bot",
        DailyParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
            transcription_enabled=True,
            transcription_settings=DailyTranscriptionSettings(language="en"),
        ),
    )

    tts = TypecastTTSService(
        api_key=os.environ["TYPECAST_API_KEY"],
        settings=TypecastTTSService.Settings(
            voice=VOICE_ID,
            model="ssfm-v30",
        ),
    )

    llm = OpenAILLMService(
        api_key=os.environ["OPENAI_API_KEY"],
        settings=OpenAILLMService.Settings(
            system_instruction="You are a helpful voice assistant. Keep responses concise.",
        ),
    )

    context = LLMContext()
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(vad_analyzer=SileroVADAnalyzer()),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(allow_interruptions=True),
    )

    @transport.event_handler("on_first_participant_joined")
    async def on_first_participant_joined(transport, participant):
        logger.info(f"Participant joined: {participant['id']}")
        await transport.capture_participant_transcription(participant["id"])
        context.add_message({"role": "user", "content": "Please introduce yourself briefly."})
        await task.queue_frames([LLMRunFrame()])

    runner = PipelineRunner()
    await runner.run(task)


if __name__ == "__main__":
    asyncio.run(main())
