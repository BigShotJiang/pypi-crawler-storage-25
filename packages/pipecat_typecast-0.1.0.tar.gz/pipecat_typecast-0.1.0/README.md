# pipecat-typecast

A community integration that adds [Typecast](https://typecast.ai) TTS support to [Pipecat](https://github.com/pipecat-ai/pipecat).

Typecast provides high-quality multilingual neural voices with fine-grained emotion and prosody controls.

## Installation

```bash
pip install pipecat-typecast
```

Or with `uv`:

```bash
uv add pipecat-typecast
```

## Usage

```python
from pipecat_typecast import TypecastTTSService

tts = TypecastTTSService(
    api_key="YOUR_TYPECAST_API_KEY",
    settings=TypecastTTSService.Settings(
        voice="tc_689450bdcce4027c2f06eee8",
        model="ssfm-v30",
    ),
)
```

### Emotion control

```python
tts = TypecastTTSService(
    api_key="YOUR_TYPECAST_API_KEY",
    settings=TypecastTTSService.Settings(
        voice="tc_689450bdcce4027c2f06eee8",
        model="ssfm-v30",
        emotion_type="preset",
        emotion_preset="happy",       # normal | happy | sad | angry | whisper | toneup | tonedown
        emotion_intensity=1.5,        # 0.0 – 2.0
    ),
)
```

### Prosody controls

```python
TypecastTTSService.Settings(
    voice="tc_689450bdcce4027c2f06eee8",
    audio_tempo=1.2,   # 0.5 – 2.0 (speech speed)
    audio_pitch=2,     # -12 to +12 semitones
    volume=120,        # 0 – 200
    seed=42,           # reproducible output
)
```

## Running the example

```bash
cd examples
TYPECAST_API_KEY=... DAILY_API_KEY=... DAILY_ROOM_URL=... OPENAI_API_KEY=... python typecast_tts_example.py
```

The example creates a voice agent in a Daily WebRTC room that responds to speech using Typecast TTS.

## Settings reference

| Setting | Type | Default | Description |
|---|---|---|---|
| `voice` | `str` | — | Typecast voice ID (required) |
| `model` | `str` | `ssfm-v30` | TTS model: `ssfm-v30` or `ssfm-v21` |
| `language` | `str` | auto | ISO 639-3 language code |
| `emotion_type` | `str` | — | `smart` or `preset` |
| `emotion_preset` | `str` | — | `normal`, `happy`, `sad`, `angry`, `whisper`, `toneup`, `tonedown` |
| `emotion_intensity` | `float` | `1.0` | Emotion intensity (0.0–2.0) |
| `previous_text` | `str` | — | Context before current utterance |
| `next_text` | `str` | — | Context after current utterance |
| `audio_tempo` | `float` | `1.0` | Speech speed (0.5–2.0) |
| `audio_pitch` | `int` | `0` | Pitch in semitones (-12 to +12) |
| `volume` | `int` | `100` | Volume (0–200) |
| `seed` | `int` | — | Seed for reproducible output |

## Pipecat compatibility

| pipecat-typecast | pipecat-ai |
|---|---|
| 0.1.x | >=0.0.62 |

## Maintainer

[@ironyee](https://github.com/ironyee)

## License

BSD 2-Clause — see [LICENSE](LICENSE).
