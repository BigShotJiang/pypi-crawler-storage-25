# Changelog

## [0.1.0] - 2026-03-31

### Added
- Initial release of `pipecat-typecast`
- `TypecastTTSService`: HTTP-based TTS using the Typecast REST API
- `TypecastTTSSettings`: runtime-updatable settings with emotion/prosody controls
- Support for Korean and 14 additional languages (ISO 639-3 codes)
- Emotion control: `smart` (context-aware) and `preset` modes
- Prosody controls: `audio_tempo`, `audio_pitch`, `volume`, `seed`
- WAV → PCM decoding with proper error handling
- Metrics support via `can_generate_metrics()`
- Full test suite with mock HTTP server
- Example pipeline using Daily WebRTC transport
