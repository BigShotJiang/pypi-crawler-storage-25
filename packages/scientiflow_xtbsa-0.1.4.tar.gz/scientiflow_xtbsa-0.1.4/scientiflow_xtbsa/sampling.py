from pathlib import Path
from typing import List, Optional, Dict
import numpy as np
import MDAnalysis as mda
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import json
import csv
import os

def get_representative_frames_pca(
    top, traj, pca_selection: str, nframes: int, random_state: int = 42, verbose: bool = False
) -> List[int]:
    """
    Load trajectory, perform PCA on selected atoms, cluster in PC space, and pick
    representative frames (closest to cluster centroids).
    Returns 0-based frame indices sorted ascending.
    """
    u = mda.Universe(str(top), str(traj))
    ag = u.select_atoms(pca_selection)
    if ag.n_atoms == 0:
        raise ValueError(f"PCA selection matched 0 atoms: {pca_selection}")

    n_frames = len(u.trajectory)
    if n_frames == 0:
        raise ValueError("Trajectory has 0 frames")

    # Gather coordinates for selected atoms for all frames
    coords = np.empty((n_frames, ag.n_atoms, 3), dtype=float)
    for i, ts in enumerate(u.trajectory):
        coords[i] = ag.positions  # AtomGroup updates per frame

    # Flatten per-frame coordinates
    X = coords.reshape(n_frames, -1)

    # PCA to 3 PCs (or as many as possible)
    n_components = min(3, X.shape[1])
    pcs = PCA(n_components=n_components, random_state=random_state).fit_transform(X)

    # Cluster PCs into k groups (k <= number of frames)
    k = min(nframes, n_frames)
    if k < nframes and verbose:
        print(f"Requested nframes={nframes} but only {n_frames} frames available; using k={k}")

    kmeans = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
    labels = kmeans.fit_predict(pcs)

    # Representative frame per cluster: closest to centroid in PC space
    frame_indices = []
    for cluster_id in range(k):
        cluster_idx = np.where(labels == cluster_id)[0]
        centroid = kmeans.cluster_centers_[cluster_id]
        dists = np.linalg.norm(pcs[cluster_idx] - centroid, axis=1)
        rep = int(cluster_idx[np.argmin(dists)])
        frame_indices.append(rep)

    frame_indices = sorted(set(frame_indices))
    if verbose:
        print(f"Selected frame indices (0-based): {frame_indices}")
    return frame_indices

def _to_range_string(indices_1based: List[int]) -> str:
    """Convert sorted 1-based indices to compact range string '1-3,5,7-9'."""
    if not indices_1based:
        return ""
    ranges = []
    start = prev = indices_1based[0]
    for x in indices_1based[1:]:
        if x == prev + 1:
            prev = x
            continue
        ranges.append(f"{start}" if start == prev else f"{start}-{prev}")
        start = prev = x
    ranges.append(f"{start}" if start == prev else f"{start}-{prev}")
    return ",".join(ranges)

# --------- helpers: exact coordinate-based mapping per frame (no rounding) ---------
def _coord_key_tuple(xyz: np.ndarray):
    """
    Return a tuple key for a 3-vector of floats. Uses exact floats from MDAnalysis
    (no rounding) as requested.
    """
    return (float(xyz[0]), float(xyz[1]), float(xyz[2]))

def _order_map_for_ag(ag: mda.core.groups.AtomGroup):
    """
    Build a map from exact coordinate tuple to 1-based order(s) within the AtomGroup.
    Multiple atoms can share the same coordinates; keep all in insertion order.
    """
    mapping = {}
    for i, pos in enumerate(ag.positions, start=1):
        key = _coord_key_tuple(pos)
        mapping.setdefault(key, []).append(i)
    return mapping

def _map_orders_by_coords(target_ag: mda.core.groups.AtomGroup, ref_map: dict) -> List[int]:
    """
    Map each atom in target_ag to 1-based order in the reference AtomGroup using exact
    coordinate matching. If multiple candidates exist for a coordinate, assign the first
    not-yet-used one to keep a stable 1:1 mapping.
    """
    used = set()
    orders = []
    for pos in target_ag.positions:
        key = _coord_key_tuple(pos)
        if key not in ref_map:
            # In the same frame with the same coordinates this should not happen
            # If it does, skip to be robust.
            continue
        candidates = ref_map[key]
        # pick first not used, else fall back to first
        chosen = None
        for c in candidates:
            if c not in used:
                chosen = c
                break
        if chosen is None:
            chosen = candidates[0]
        used.add(chosen)
        orders.append(chosen)
    # unique sorted for compact ranges
    return sorted(set(orders))

def _select_inner_protein(u: mda.Universe, write_selection: str, lig_resname: str, cutoff: float, whole_residue: bool):
    """
    Select protein atoms for QM region around ligand:
      - whole_residue=True: include entire residues within cutoff of ligand.
      - whole_residue=False: include only atoms within cutoff of ligand.
    Both cases restrict to write_selection and exclude ligand atoms.
    """
    base = f"({write_selection}) and not resname {lig_resname}"
    if whole_residue:
        query = f"byres (around {cutoff} resname {lig_resname}) and {base}"
    else:
        query = f"(around {cutoff} resname {lig_resname}) and {base}"
    return u.select_atoms(query)
# -----------------------------------------------------------------------------

def _build_element_map_from_pdb(pdb_path: Path, lig_resname: str) -> Dict[str, str]:
    """
    Build a map of atom_name -> element from a reference ligand PDB file.
    Safe mapping: uses atom names only (e.g., 'C1' -> 'C', 'N1' -> 'N', 'H1' -> 'H').
    This is used to fill missing element info when writing XYZ files.
    """
    try:
        u_pdb = mda.Universe(str(pdb_path))
        lig_atoms = u_pdb.select_atoms(f"resname {lig_resname}")
        if lig_atoms.n_atoms == 0:
            return {}
        
        # Build atom_name -> element map
        element_map = {}
        for atom in lig_atoms:
            atom_name = atom.name.strip()
            element = atom.element if hasattr(atom, 'element') else None
            if atom_name and element:
                element_map[atom_name] = element
        
        return element_map
    except Exception as e:
        print(f"Warning: Could not load element map from {pdb_path}: {e}")
        return {}

def _apply_elements_to_xyz(xyz_path: Path, atom_group: mda.core.groups.AtomGroup, element_map: Dict[str, str]) -> None:
    """
    Apply element symbols to a written XYZ file using atom names from the AtomGroup.
    Matches atoms by order and atom name. Rewrites the XYZ file with proper elements.
    Safe approach: uses atom names, preserves all coordinates from trajectory.
    """
    if not element_map:
        return  # No elements to apply
    
    try:
        # Read existing XYZ
        with open(xyz_path, 'r') as f:
            lines = f.readlines()
        
        if len(lines) < 3:
            return  # Invalid XYZ format
        
        n_atoms = int(lines[0].strip())
        header = lines[1]
        atom_lines = lines[2:2+n_atoms]
        
        if len(atom_lines) != n_atoms:
            return  # Mismatch in atom count
        
        # Build new atom lines with elements applied by atom name
        new_atom_lines = []
        for idx, atom in enumerate(atom_group):
            if idx >= len(atom_lines):
                break
            
            line = atom_lines[idx]
            parts = line.split()
            
            # Try to get element from map using atom name
            atom_name = atom.name.strip()
            element = element_map.get(atom_name, None)
            
            if element:
                # Replace or insert element symbol
                coords = parts[-3:] if len(parts) >= 3 else ["0.0", "0.0", "0.0"]
                new_line = f"{element:>3} {coords[0]:>12} {coords[1]:>12} {coords[2]:>12}\n"
                new_atom_lines.append(new_line)
            else:
                # Keep original line if no element found
                new_atom_lines.append(line)
        
        # Write back
        with open(xyz_path, 'w') as f:
            f.write(lines[0])  # natoms
            f.write(header)     # header comment
            f.writelines(new_atom_lines)
    
    except Exception as e:
        print(f"Warning: Could not apply elements to {xyz_path}: {e}")

def _apply_elements_to_complex_xyz(xyz_path: Path, complex_ag: mda.core.groups.AtomGroup, 
                                   ligand_ag: mda.core.groups.AtomGroup, 
                                   element_map: Dict[str, str]) -> None:
    """
    Apply element symbols to ligand atoms within a complex XYZ file.
    The complex XYZ contains both protein and ligand atoms. This function only applies
    elements to ligand atoms (by matching their indices in complex_ag), leaving protein
    atoms unchanged.
    """
    if not element_map:
        return
    
    try:
        # Find indices of ligand atoms within complex_ag
        ligand_indices = set()
        complex_indices = complex_ag.indices
        ligand_indices_set = set(ligand_ag.indices)
        
        for i, idx in enumerate(complex_indices):
            if idx in ligand_indices_set:
                ligand_indices.add(i)
        
        if not ligand_indices:
            return  # No ligand atoms found in complex
        
        # Read existing XYZ
        with open(xyz_path, 'r') as f:
            lines = f.readlines()
        
        if len(lines) < 3:
            return
        
        n_atoms = int(lines[0].strip())
        header = lines[1]
        atom_lines = lines[2:2+n_atoms]
        
        if len(atom_lines) != n_atoms or len(atom_lines) != len(complex_ag):
            return
        
        # Build new atom lines: apply elements only to ligand atoms
        new_atom_lines = []
        for idx, atom in enumerate(complex_ag):
            if idx >= len(atom_lines):
                break
            
            line = atom_lines[idx]
            
            if idx in ligand_indices:
                # This is a ligand atom; try to apply element
                atom_name = atom.name.strip()
                element = element_map.get(atom_name, None)
                
                if element:
                    parts = line.split()
                    coords = parts[-3:] if len(parts) >= 3 else ["0.0", "0.0", "0.0"]
                    new_line = f"{element:>3} {coords[0]:>12} {coords[1]:>12} {coords[2]:>12}\n"
                    new_atom_lines.append(new_line)
                else:
                    new_atom_lines.append(line)
            else:
                # Protein atom; keep as is
                new_atom_lines.append(line)
        
        # Write back
        with open(xyz_path, 'w') as f:
            f.write(lines[0])
            f.write(header)
            f.writelines(new_atom_lines)
    
    except Exception as e:
        print(f"Warning: Could not apply elements to complex XYZ {xyz_path}: {e}")

# -----------------------------------------------------------------------------

def export_frames_and_qm_region(
    top,
    traj,
    write_selection: str,
    lig_resname: str,
    frame_indices: List[int],
    outdir: Path,
    qm_cutoff: float,
    whole_residue: bool = True,
    verbose: bool = False,
    ligand_pdb: Optional[Path] = None,
):
    """
    For each frame:
      - write frame_XXX_complex.xyz, frame_XXX_protein.xyz, frame_XXX_ligand.xyz
      - determine QM region indices:
          * whole_residue=True  -> whole residues near ligand
          * whole_residue=False -> only atoms near ligand
        complex indices in complex.xyz numbering; protein indices in protein.xyz numbering; ligand indices 1..n.
      - write qm_region.json and initialize scientiflow_xtbsa_report.csv.
    
    If ligand_pdb is provided (optional):
      - Load element symbols from reference ligand PDB
      - Apply elements to ligand XYZ files by matching atom names
      - Keeps all coordinates from trajectory; only adds element info for xTB compatibility
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    u = mda.Universe(str(top), str(traj))

    # Atom groups defining XYZ output order (positions update per frame)
    complex_ag = u.select_atoms(write_selection)
    if complex_ag.n_atoms == 0:
        raise ValueError(f"Write selection matched 0 atoms: {write_selection}")
    ligand_all = u.select_atoms(f"({write_selection}) and resname {lig_resname}")
    if ligand_all.n_atoms == 0:
        raise ValueError(f"No ligand atoms found for resname '{lig_resname}' within write-selection.")
    protein_all = u.select_atoms(f"({write_selection}) and not resname {lig_resname}")

    qm_json = {}
    report_rows = []  # rows for scientiflow_xtbsa_report.csv

    # Load element map from reference PDB if provided
    element_map = {}
    if ligand_pdb:
        element_map = _build_element_map_from_pdb(ligand_pdb, lig_resname)
        if element_map and verbose:
            print(f"Loaded element map from {ligand_pdb}: {len(element_map)} atoms")

    for i, frame_idx in enumerate(sorted(frame_indices), start=1):
        # Move to frame
        u.trajectory[frame_idx]

        # Paths
        complex_path = outdir / f"frame_{i:03d}_complex.xyz"
        protein_path = outdir / f"frame_{i:03d}_protein.xyz"
        ligand_path = outdir / f"frame_{i:03d}_ligand.xyz"

        # Write XYZs for this frame (orders of AGs define numbering)
        complex_ag.write(str(complex_path))
        if protein_all.n_atoms:
            protein_all.write(str(protein_path))
        ligand_all.write(str(ligand_path))

        # Apply element symbols to ligand atoms if reference PDB was provided
        if element_map:
            # Apply to ligand XYZ
            _apply_elements_to_xyz(ligand_path, ligand_all, element_map)
            # Apply to complex XYZ (only ligand atoms within it)
            _apply_elements_to_complex_xyz(complex_path, complex_ag, ligand_all, element_map)

        # Build coordinate -> order maps for this frame
        complex_map = _order_map_for_ag(complex_ag)
        protein_map = _order_map_for_ag(protein_all) if protein_all.n_atoms else {}
        # ligand numbering is always full 1..n in its own file; map still useful for checks
        ligand_map = _order_map_for_ag(ligand_all)

        # Determine inner protein (whole residues or atoms within cutoff of ligand)
        inner_protein_ag = _select_inner_protein(u, write_selection, lig_resname, qm_cutoff, whole_residue)

        # Complex numbering (for XTB --oniom on complex.xyz)
        ligand_complex_idx = _map_orders_by_coords(ligand_all, complex_map)
        inner_protein_complex_idx = _map_orders_by_coords(inner_protein_ag, complex_map)
        qm_complex_idx = sorted(set(ligand_complex_idx).union(inner_protein_complex_idx))

        # Protein numbering (only protein part of QM region)
        inner_protein_protein_idx = _map_orders_by_coords(inner_protein_ag, protein_map) if protein_map else []

        # Ligand numbering: 1..n (full ligand in ligand.xyz)
        ligand_local_idx = list(range(1, ligand_all.n_atoms + 1))

        # Build JSON entry
        frame_key = f"frame_{i:03d}"
        qm_json[frame_key] = {
            "complex": _to_range_string(qm_complex_idx),
            "protein": _to_range_string(inner_protein_protein_idx),
            "ligand": _to_range_string(ligand_local_idx),
        }

        # Add report row (relative base path; energy columns to be filled after xTB run)
        base_path = Path(outdir) / f"frame_{i:03d}"
        base_rel = os.path.relpath(base_path, start=Path.cwd())
        report_rows.append(
            {
                "frame_base_path": base_rel.replace("\\", "/"),
                "complex_energy": "",
                "protein_energy": "",
                "ligand_energy": "",
                "binding_free_energy": "",
            }
        )

        if verbose:
            print(
                f"{frame_key}: complex={qm_json[frame_key]['complex']} "
                f"protein={qm_json[frame_key]['protein']} "
                f"ligand={qm_json[frame_key]['ligand']}"
            )

    # Write qm_region.json
    with (outdir / "qm_region.json").open("w") as f:
        json.dump(qm_json, f, indent=2)

    # Write report CSV in current working directory
    csv_path = Path.cwd() / "scientiflow_xtbsa_report.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "frame_base_path",
                "complex_energy",
                "protein_energy",
                "ligand_energy",
                "binding_free_energy",
            ],
        )
        writer.writeheader()
        writer.writerows(report_rows)


