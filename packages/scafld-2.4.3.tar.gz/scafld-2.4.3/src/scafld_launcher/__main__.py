from scafld_launcher.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
