"""Tests for firmware & microcode audit (CHECK 45)."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from ufw_audit.checks.firmware import (
    FirmwareSnapshot,
    _detect_cpu_vendor,
    _dpkg_installed,
    _parse_fwupd_updates,
    check_firmware,
)
from ufw_audit.scoring import FindingLevel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _snap(
    fwupd_available: bool = True,
    fwupd_updates: list[str] | None = None,
    fwupd_error: str = "",
    cpu_vendor: str = "intel",
    microcode_installed: bool = True,
    microcode_package: str = "intel-microcode",
    microcode_na: bool = False,
) -> FirmwareSnapshot:
    return FirmwareSnapshot(
        fwupd_available=fwupd_available,
        fwupd_pending_updates=fwupd_updates or [],
        fwupd_error=fwupd_error,
        cpu_vendor=cpu_vendor,
        microcode_installed=microcode_installed,
        microcode_package=microcode_package,
        microcode_not_applicable=microcode_na,
    )


def _finding(result, key):
    """Return the unique finding with the given key, or raise AssertionError."""
    matches = [f for f in result.findings if f.key == key]
    assert len(matches) == 1, f"expected exactly 1 finding with key={key!r}, got {len(matches)}"
    return matches[0]


# ---------------------------------------------------------------------------
# TestCheckFirmwareFwupd
# ---------------------------------------------------------------------------

class TestCheckFirmwareFwupd:
    def test_fwupd_missing_info(self):
        result = check_firmware(_snap(fwupd_available=False))
        f = _finding(result, "firmware.fwupd_missing")
        assert f.level == FindingLevel.INFO

    def test_fwupd_missing_no_deduction(self):
        result = check_firmware(_snap(fwupd_available=False))
        assert not any(d.key == "firmware.fwupd_missing" for d in result.deductions)

    def test_fwupd_error_info(self):
        result = check_firmware(_snap(fwupd_error="no devices found"))
        f = _finding(result, "firmware.fwupd_error")
        assert f.level == FindingLevel.INFO

    def test_fwupd_error_no_deduction(self):
        result = check_firmware(_snap(fwupd_error="no devices found"))
        assert not any(d.key == "firmware.fwupd_error" for d in result.deductions)

    def test_fwupd_updates_warn(self):
        result = check_firmware(_snap(fwupd_updates=["System Firmware"]))
        f = _finding(result, "firmware.fwupd_updates")
        assert f.level == FindingLevel.WARN

    def test_fwupd_updates_deducts_1pt(self):
        result = check_firmware(_snap(fwupd_updates=["System Firmware"]))
        assert len([d for d in result.deductions if d.key == "firmware.fwupd_updates"]) == 1
        d = next(d for d in result.deductions if d.key == "firmware.fwupd_updates")
        assert d.points == 1

    def test_fwupd_no_updates_ok(self):
        result = check_firmware(_snap(fwupd_updates=[]))
        f = _finding(result, "firmware.fwupd_ok")
        assert f.level == FindingLevel.OK

    def test_fwupd_multiple_updates_flat_deduction(self):
        """Deduction is flat −1 regardless of how many devices have updates."""
        result = check_firmware(_snap(fwupd_updates=["BIOS", "NIC", "SSD"]))
        _finding(result, "firmware.fwupd_updates")
        d = next(d for d in result.deductions if d.key == "firmware.fwupd_updates")
        assert d.points == 1

    def test_fwupd_error_and_updates_both_reported(self):
        """When both fwupd_error and pending updates are set, both findings are emitted."""
        result = check_firmware(_snap(
            fwupd_updates=["BIOS"],
            fwupd_error="daemon not running",
        ))
        assert any(f.key == "firmware.fwupd_error" for f in result.findings)
        assert any(f.key == "firmware.fwupd_updates" for f in result.findings)


# ---------------------------------------------------------------------------
# TestCheckFirmwareMicrocode
# ---------------------------------------------------------------------------

class TestCheckFirmwareMicrocode:
    def test_microcode_installed_ok(self):
        result = check_firmware(_snap())
        f = _finding(result, "firmware.microcode_ok")
        assert f.level == FindingLevel.OK

    def test_microcode_missing_warn(self):
        result = check_firmware(_snap(microcode_installed=False, microcode_package=""))
        f = _finding(result, "firmware.microcode_missing")
        assert f.level == FindingLevel.WARN

    def test_microcode_missing_deducts_1pt(self):
        result = check_firmware(_snap(microcode_installed=False, microcode_package=""))
        assert len([d for d in result.deductions if d.key == "firmware.microcode_missing"]) == 1
        d = next(d for d in result.deductions if d.key == "firmware.microcode_missing")
        assert d.points == 1

    def test_microcode_missing_cmd_contains_package(self):
        result = check_firmware(_snap(cpu_vendor="intel", microcode_installed=False, microcode_package=""))
        f = _finding(result, "firmware.microcode_missing")
        assert "intel-microcode" in (f.cmd or "")

    def test_microcode_missing_amd_cmd(self):
        result = check_firmware(_snap(cpu_vendor="amd", microcode_installed=False, microcode_package=""))
        f = _finding(result, "firmware.microcode_missing")
        assert "amd64-microcode" in (f.cmd or "")

    def test_microcode_not_applicable_info(self):
        result = check_firmware(_snap(cpu_vendor="unknown", microcode_installed=False, microcode_na=True))
        f = _finding(result, "firmware.microcode_na")
        assert f.level == FindingLevel.INFO

    def test_amd_microcode_ok(self):
        result = check_firmware(_snap(
            cpu_vendor="amd",
            microcode_installed=True,
            microcode_package="amd64-microcode",
        ))
        f = _finding(result, "firmware.microcode_ok")
        assert f.level == FindingLevel.OK

    def test_total_deduction_both_issues(self):
        result = check_firmware(_snap(
            fwupd_updates=["BIOS"],
            microcode_installed=False,
            microcode_package="",
        ))
        assert sum(d.points for d in result.deductions) == 2


# ---------------------------------------------------------------------------
# TestCheckFirmwareIntegration
# ---------------------------------------------------------------------------

class TestCheckFirmwareIntegration:
    def test_clean_system_two_ok_findings(self):
        """A fully healthy system produces exactly two OK findings."""
        result = check_firmware(_snap())
        ok_findings = [f for f in result.findings if f.level == FindingLevel.OK]
        assert len(ok_findings) == 2
        assert not result.deductions

    def test_all_issues_two_deductions(self):
        """fwupd pending + microcode missing → exactly −2 pts total."""
        result = check_firmware(_snap(
            fwupd_updates=["System Firmware"],
            microcode_installed=False,
            microcode_package="",
        ))
        assert sum(d.points for d in result.deductions) == 2
        assert len([f for f in result.findings if f.level == FindingLevel.WARN]) == 2

    def test_fwupd_missing_plus_microcode_ok_no_deduction(self):
        result = check_firmware(_snap(fwupd_available=False))
        assert sum(d.points for d in result.deductions) == 0

    def test_findings_count_fwupd_error_path(self):
        """fwupd error + microcode ok → 1 INFO + 1 OK, no deductions."""
        result = check_firmware(_snap(fwupd_error="daemon unavailable"))
        assert sum(d.points for d in result.deductions) == 0
        assert any(f.level == FindingLevel.INFO for f in result.findings)
        assert any(f.level == FindingLevel.OK for f in result.findings)


# ---------------------------------------------------------------------------
# TestDetectCpuVendor
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("vendor_line,expected", [
    ("vendor_id\t: GenuineIntel\n", "intel"),
    ("vendor_id\t: AuthenticAMD\n", "amd"),
    ("vendor_id\t: SomeFPGA\n",     "unknown"),
    ("vendor_id : GenuineIntel\n",  "intel"),     # space before colon
    ("VENDOR_ID\t: AuthenticAMD\n", "amd"),       # uppercase key
    ("vendor_id\t: genuineintel\n", "intel"),     # lowercase value
])
def test_detect_cpu_vendor_parametrized(vendor_line, expected):
    content = vendor_line + "model name\t: some processor\n"
    with patch("ufw_audit.checks.firmware.Path") as mock_path:
        mock_path.return_value.read_text.return_value = content
        assert _detect_cpu_vendor() == expected


class TestDetectCpuVendor:
    def test_no_vendor_id(self):
        content = "model name\t: some processor\n"
        with patch("ufw_audit.checks.firmware.Path") as mock_path:
            mock_path.return_value.read_text.return_value = content
            assert _detect_cpu_vendor() == "unknown"

    def test_oserror_returns_unknown(self):
        with patch("ufw_audit.checks.firmware.Path") as mock_path:
            mock_path.return_value.read_text.side_effect = OSError("no file")
            assert _detect_cpu_vendor() == "unknown"

    def test_multiple_vendor_id_lines_first_wins(self):
        """When /proc/cpuinfo has multiple CPU entries, the first match is used."""
        content = (
            "vendor_id\t: GenuineIntel\n"
            "vendor_id\t: AuthenticAMD\n"
        )
        with patch("ufw_audit.checks.firmware.Path") as mock_path:
            mock_path.return_value.read_text.return_value = content
            assert _detect_cpu_vendor() == "intel"


# ---------------------------------------------------------------------------
# TestDpkgInstalled
# ---------------------------------------------------------------------------

class TestDpkgInstalled:
    def test_installed_package(self):
        out = "ii  intel-microcode  3.20230808.1  amd64  Processor microcode firmware for Intel CPUs\n"
        with patch("ufw_audit.checks.firmware._run", return_value=out):
            assert _dpkg_installed("intel-microcode")

    def test_installed_tab_separated(self):
        out = "ii\tintel-microcode\t3.20230808.1\tamd64\tProcessor microcode\n"
        with patch("ufw_audit.checks.firmware._run", return_value=out):
            assert _dpkg_installed("intel-microcode")

    def test_installed_arch_qualified(self):
        """dpkg may output 'intel-microcode:amd64' — package name still matches."""
        out = "ii  intel-microcode:amd64  3.20230808.1  amd64  Processor microcode\n"
        with patch("ufw_audit.checks.firmware._run", return_value=out):
            assert _dpkg_installed("intel-microcode")

    def test_not_installed_package(self):
        out = "dpkg-query: no packages found matching intel-microcode\n"
        with patch("ufw_audit.checks.firmware._run", return_value=out):
            assert not _dpkg_installed("intel-microcode")

    def test_partially_installed(self):
        out = "rc  intel-microcode  3.20200609.2  amd64  ...\n"
        with patch("ufw_audit.checks.firmware._run", return_value=out):
            assert not _dpkg_installed("intel-microcode")

    def test_empty_output(self):
        with patch("ufw_audit.checks.firmware._run", return_value=""):
            assert not _dpkg_installed("intel-microcode")

    def test_none_output(self):
        with patch("ufw_audit.checks.firmware._run", return_value=None):
            assert not _dpkg_installed("intel-microcode")


# ---------------------------------------------------------------------------
# TestParseFwupdUpdates
# ---------------------------------------------------------------------------

class TestParseFwupdUpdates:
    SAMPLE_OUTPUT = """\
Lenovo ThinkPad X1 Carbon Gen 8
  Update available: N2VET43W (1.43.0 -> 1.44.0)
  Summary: ThinkPad BIOS Update
  Version:  1.44.0
  Urgency:  High

Intel Management Engine
  Update available: (...)
  Version: 16.1.25.1865
"""

    def test_extracts_device_names(self):
        devices = _parse_fwupd_updates(self.SAMPLE_OUTPUT)
        assert any("ThinkPad" in d or "Lenovo" in d for d in devices)

    def test_no_key_value_lines(self):
        devices = _parse_fwupd_updates(self.SAMPLE_OUTPUT)
        for d in devices:
            assert ":" not in d

    def test_no_updates_output(self):
        out = "Devices with no available firmware updates: \nSystem Firmware\n"
        devices = _parse_fwupd_updates(out)
        assert isinstance(devices, list)

    def test_empty_output(self):
        assert _parse_fwupd_updates("") == []

    def test_only_headers_returns_empty(self):
        """Lines that are all key:value or headers should produce no device names."""
        out = (
            "Version: 1.0\n"
            "Summary: nothing\n"
            "Status: active\n"
        )
        assert _parse_fwupd_updates(out) == []

    def test_deduplicates_device_names(self):
        """Same device name appearing twice must appear only once."""
        out = "MyDevice\nMyDevice\n"
        devices = _parse_fwupd_updates(out)
        assert devices.count("MyDevice") <= 1

    def test_caps_at_ten_devices(self):
        """Parser must not return more than 10 device names."""
        out = "\n".join(f"Device{i}" for i in range(20)) + "\n"
        devices = _parse_fwupd_updates(out)
        assert len(devices) <= 10

    def test_indented_lines_skipped(self):
        """Indented lines (summary/detail) must not appear as device names."""
        out = "RealDevice\n  some detail here\n"
        devices = _parse_fwupd_updates(out)
        assert not any("detail" in d for d in devices)

    def test_strict_key_value_lines_excluded(self):
        """Lines like 'Version: 1.2' must never appear as device names."""
        out = "Version: 1.2\nUpdate available\nSummary: nothing\n"
        devices = _parse_fwupd_updates(out)
        assert "Version: 1.2" not in devices
        assert "Summary: nothing" not in devices

    def test_exact_device_names(self):
        """Device names extracted from sample output must match exactly."""
        devices = _parse_fwupd_updates(self.SAMPLE_OUTPUT)
        assert "Lenovo ThinkPad X1 Carbon Gen 8" in devices
        assert "Intel Management Engine" in devices


# ---------------------------------------------------------------------------
# TestFromSystem
# ---------------------------------------------------------------------------

class TestFromSystem:
    def test_no_fwupd_available(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=False),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="intel"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert not snap.fwupd_available
        assert snap.fwupd_pending_updates == []

    def test_fwupd_no_updates(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=True),
            patch("ufw_audit.checks.firmware._run", return_value="No upgrades for any devices"),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="intel"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.fwupd_pending_updates == []
        assert snap.fwupd_error == ""

    def test_fwupd_error_captured(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=True),
            patch("ufw_audit.checks.firmware._run", return_value="Failed to get updates: error connecting to daemon"),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="intel"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.fwupd_error != ""

    def test_fwupd_run_returns_none(self):
        """_run returning None must not raise and must leave pending_updates empty."""
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=True),
            patch("ufw_audit.checks.firmware._run", return_value=None),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="intel"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.fwupd_pending_updates == []

    def test_intel_microcode_detected(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=False),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="intel"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.microcode_installed
        assert snap.microcode_package == "intel-microcode"

    def test_amd_microcode_detected(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=False),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="amd"),
            patch("ufw_audit.checks.firmware._dpkg_installed", return_value=True),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.microcode_installed
        assert snap.microcode_package == "amd64-microcode"

    def test_unknown_cpu_not_applicable(self):
        with (
            patch("ufw_audit.checks.firmware._command_exists", return_value=False),
            patch("ufw_audit.checks.firmware._detect_cpu_vendor", return_value="unknown"),
        ):
            snap = FirmwareSnapshot.from_system()
        assert snap.microcode_not_applicable
        assert not snap.microcode_installed
