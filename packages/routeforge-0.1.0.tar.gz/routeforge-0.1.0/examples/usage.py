"""
llmrouter usage example
-----------------------
Shows how to initialise the router from a config dict (no YAML file needed),
route a few prompts, and inspect the observability logs.
"""

import os
from llmrouter import LLMRouter

# --- Build config inline (or use LLMRouter.from_yaml("config.yaml")) ---
config = {
    "default_model": "gpt-4o-mini",
    "log_path": "runs.json",
    "complexity_threshold": 0.45,
    "models": [
        {
            "name": "gpt-4o-mini",
            "model_id": "gpt-4o-mini",
            "provider": "openai",
            "api_keys": [os.environ["OPENAI_API_KEY"]],
            "cost_per_1k_input": 0.00015,
            "cost_per_1k_output": 0.0006,
            "tags": ["cheap", "general", "summarisation", "translation"],
        },
        {
            "name": "gpt-4o",
            "model_id": "gpt-4o",
            "provider": "openai",
            "api_keys": [os.environ["OPENAI_API_KEY"]],
            "cost_per_1k_input": 0.0025,
            "cost_per_1k_output": 0.01,
            "tags": ["strong", "reasoning", "code", "creative"],
        },
    ],
}

router = LLMRouter.from_dict(config)

# --- Route some prompts ---
prompts = [
    "Summarise this in one sentence: The Eiffel Tower is in Paris.",
    "Write a FastAPI endpoint that accepts a file upload and returns its SHA256 hash.",
    "Prove that the square root of 2 is irrational.",
    "Translate 'Good morning, how are you?' into French.",
]

for prompt in prompts:
    print(f"\nPrompt: {prompt[:60]}...")
    resp = router.route(prompt)
    print(f"  → Model: {resp.meta.model}  ({resp.meta.provider})")
    print(f"  → Task: {resp.meta.task_type}  |  Complexity: {resp.meta.complexity_score}")
    print(f"  → Layer: {resp.meta.routing_layer}  |  Reason: {resp.meta.routing_reason}")
    print(f"  → Tokens: {resp.meta.input_tokens} in / {resp.meta.output_tokens} out")
    print(f"  → Cost: ${resp.meta.estimated_cost_usd:.6f}  |  Latency: {resp.meta.latency_ms:.0f}ms")
    print(f"  → Response: {resp.content[:100]}...")

# --- View logs ---
print("\n--- Last 2 runs from log ---")
for run in router.logs(last_n=2):
    print(run)