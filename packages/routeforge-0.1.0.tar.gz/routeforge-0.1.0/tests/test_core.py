import pytest
from routeforge.scorer import complexity_score, classify_task
from routeforge.config import RouterConfig
from routeforge.balancer import KeyBalancer


# --- complexity scorer ---

def test_simple_prompt_low_score():
    score = complexity_score("What is the Eiffel Tower?")
    assert score < 0.4

def test_complex_prompt_high_score():
    score = complexity_score(
        "Prove that the halting problem is undecidable using a diagonalisation argument, "
        "then analyze its implications for formal verification of software systems."
    )
    assert score > 0.4

def test_score_bounded():
    for prompt in ["hi", "x" * 2000, "write a poem about the moon step-by-step"]:
        s = complexity_score(prompt)
        assert 0.0 <= s <= 1.0


# --- task classifier ---

def test_classify_code():
    assert classify_task("Write a Python function to reverse a linked list") == "code"

def test_classify_translation():
    assert classify_task("Translate 'hello world' into French") == "translation"

def test_classify_summarisation():
    assert classify_task("Summarize this article in 3 bullet points") == "summarisation"

def test_classify_reasoning():
    assert classify_task("Prove that there are infinitely many prime numbers") == "reasoning"

def test_classify_general_fallback():
    assert classify_task("blorp blorp flibble") == "general"


# --- config loading ---

def test_config_from_dict():
    cfg = RouterConfig.from_dict({
        "default_model": "mini",
        "models": [
            {
                "name": "mini",
                "model_id": "gpt-4o-mini",
                "provider": "openai",
                "api_keys": ["sk-test"],
                "tags": ["cheap"],
            }
        ],
    })
    assert cfg.default_model == "mini"
    assert len(cfg.models) == 1
    assert cfg.get_model("mini").provider == "openai"

def test_get_models_by_tag():
    cfg = RouterConfig.from_dict({
        "models": [
            {"name": "a", "model_id": "m1", "provider": "openai", "api_keys": [], "tags": ["cheap"]},
            {"name": "b", "model_id": "m2", "provider": "openai", "api_keys": [], "tags": ["strong"]},
            {"name": "c", "model_id": "m3", "provider": "openai", "api_keys": [], "tags": ["cheap", "code"]},
        ]
    })
    cheap = cfg.get_models_by_tag("cheap")
    assert len(cheap) == 2
    assert cfg.get_models_by_tag("strong")[0].name == "b"


# --- balancer ---

def test_round_robin():
    from routeforge.config import ModelEntry
    model = ModelEntry(name="test", model_id="m", provider="openai", api_keys=["k1", "k2", "k3"])
    balancer = KeyBalancer()
    keys = [balancer.next_key(model) for _ in range(6)]
    assert keys == ["k1", "k2", "k3", "k1", "k2", "k3"]

def test_single_key():
    from routeforge.config import ModelEntry
    model = ModelEntry(name="test", model_id="m", provider="openai", api_keys=["only-key"])
    balancer = KeyBalancer()
    assert balancer.next_key(model) == "only-key"
    assert balancer.next_key(model) == "only-key"

def test_no_keys_returns_none():
    from routeforge.config import ModelEntry
    model = ModelEntry(name="test", model_id="m", provider="ollama", api_keys=[])
    balancer = KeyBalancer()
    assert balancer.next_key(model) is None


# --- meta-router ---

from routeforge.meta_router import is_ambiguous, _parse_response

def test_is_ambiguous_true():
    # No task match + score in middle band
    assert is_ambiguous(0.5, False) is True

def test_is_ambiguous_false_task_matched():
    # Task was matched — should not be ambiguous
    assert is_ambiguous(0.5, True) is False

def test_is_ambiguous_false_low_score():
    assert is_ambiguous(0.2, False) is False

def test_is_ambiguous_false_high_score():
    assert is_ambiguous(0.8, False) is False

def test_parse_response_clean_json():
    raw = '{"model": "gpt-4o", "task_type": "reasoning", "reason": "Complex math problem"}'
    result = _parse_response(raw)
    assert result["model"] == "gpt-4o"
    assert result["task_type"] == "reasoning"

def test_parse_response_strips_fences():
    raw = '```json\n{"model": "claude-sonnet", "task_type": "code", "reason": "Coding task"}\n```'
    result = _parse_response(raw)
    assert result["model"] == "claude-sonnet"

def test_parse_response_invalid_returns_none():
    assert _parse_response("not json at all") is None
    assert _parse_response("") is None