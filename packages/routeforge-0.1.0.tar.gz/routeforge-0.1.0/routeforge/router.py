from __future__ import annotations
from routeforge.config import RouterConfig, ModelEntry
from routeforge.balancer import KeyBalancer
from routeforge.scorer import complexity_score, classify_task
from routeforge.providers import dispatch
from routeforge.logger import RunLogger
from routeforge.models import RouteResponse, RouteMeta
from routeforge.meta_router import is_ambiguous, meta_route


class LLMRouter:
    """
    Intelligent LLM router with four routing layers:

    1. Task classifier  — routes by detected task type (code, reasoning, etc.)
    2. Complexity gate  — routes clearly simple/complex prompts to cheap/strong models
    3. Meta-router      — LLM call when score is ambiguous and no task matched
    4. Default fallback — uses the configured default_model
    """

    def __init__(self, config: RouterConfig) -> None:
        self._config = config
        self._balancer = KeyBalancer()
        self._logger = RunLogger(config.log_path)

    @classmethod
    def from_yaml(cls, path: str) -> "LLMRouter":
        return cls(RouterConfig.from_yaml(path))

    @classmethod
    def from_dict(cls, data: dict) -> "LLMRouter":
        return cls(RouterConfig.from_dict(data))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def route(
        self,
        prompt: str,
        system: str | None = None,
        **kwargs,
    ) -> RouteResponse:
        """Route a prompt to the best model and return a RouteResponse."""
        model, layer, reason = self._select_model(prompt)
        messages = self._build_messages(prompt, system)
        api_key = self._balancer.next_key(model)

        content, input_tok, output_tok, latency = dispatch(model, api_key, messages, **kwargs)

        cost = self._estimate_cost(model, input_tok, output_tok)
        task = classify_task(prompt)
        score = complexity_score(prompt)

        meta = RouteMeta(
            model=model.name,
            provider=model.provider,
            routing_layer=layer,
            routing_reason=reason,
            task_type=task,
            complexity_score=score,
            input_tokens=input_tok,
            output_tokens=output_tok,
            latency_ms=latency,
            estimated_cost_usd=cost,
        )
        response = RouteResponse(content=content, meta=meta)
        self._logger.log(prompt, response)
        return response

    def logs(self, last_n: int | None = None) -> list[dict]:
        """Read run logs. Optionally limit to last N entries."""
        return self._logger.read(last_n)

    # ------------------------------------------------------------------
    # Internal routing logic
    # ------------------------------------------------------------------

    def _select_model(self, prompt: str) -> tuple[ModelEntry, str, str]:
        """
        Returns (model, routing_layer, reason).

        Routing priority:
        1. Task classifier  — keyword/regex match on task type
        2. Complexity gate  — unambiguous low/high score -> cheap/strong model
        3. Meta-router      — LLM decides when score is in ambiguous band (0.35-0.65)
        4. Default fallback — configured default_model or first model
        """
        task = classify_task(prompt)
        score = complexity_score(prompt)
        threshold = self._config.complexity_threshold
        task_matched = task != "general"

        # Layer 1: task-aware routing
        task_models = self._config.get_models_by_tag(task)
        if task_models:
            chosen = self._pick_by_complexity(task_models, score, threshold)
            return chosen, "task_classifier", f"Task detected as '{task}'; selected by complexity ({score:.2f})"

        # Layer 2: complexity routing -- only when score is unambiguous
        if not is_ambiguous(score, task_matched):
            if score < threshold:
                cheap_models = self._config.get_models_by_tag("cheap")
                if cheap_models:
                    return cheap_models[0], "complexity", f"Low complexity ({score:.2f}); routed to cheap model"
            else:
                strong_models = self._config.get_models_by_tag("strong")
                if strong_models:
                    return strong_models[0], "complexity", f"High complexity ({score:.2f}); routed to strong model"

        # Layer 3: meta-router -- ambiguous score, let an LLM decide
        if is_ambiguous(score, task_matched):
            meta_model = self._resolve_meta_model()
            if meta_model:
                api_key = self._balancer.next_key(meta_model)
                result = meta_route(prompt, self._config, meta_model, api_key)
                if result:
                    chosen, _, reason = result
                    return chosen, "meta_router", f"Ambiguous score ({score:.2f}); meta-router: {reason}"

        # Layer 4: default fallback
        if self._config.default_model:
            model = self._config.get_model(self._config.default_model)
            if model:
                return model, "default", "No confident signal; using default model"

        if self._config.models:
            return self._config.models[0], "default", "Absolute fallback to first configured model"

        raise RuntimeError("No models configured in RouterConfig.")

    def _resolve_meta_model(self) -> ModelEntry | None:
        """Pick the model that will power the meta-router call."""
        if self._config.meta_router_model:
            return self._config.get_model(self._config.meta_router_model)
        cheap = self._config.get_models_by_tag("cheap")
        if cheap:
            return cheap[0]
        return self._config.models[0] if self._config.models else None

    def _pick_by_complexity(
        self,
        models: list[ModelEntry],
        score: float,
        threshold: float,
    ) -> ModelEntry:
        """Within a set of candidate models, prefer cheap ones for simple prompts."""
        if score < threshold:
            cheap = [m for m in models if "cheap" in m.tags]
            if cheap:
                return cheap[0]
        strong = [m for m in models if "strong" in m.tags]
        if strong:
            return strong[0]
        return models[0]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_messages(self, prompt: str, system: str | None) -> list[dict]:
        msgs: list[dict] = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return msgs

    def _estimate_cost(self, model: ModelEntry, input_tok: int, output_tok: int) -> float:
        cost = (input_tok / 1000) * model.cost_per_1k_input
        cost += (output_tok / 1000) * model.cost_per_1k_output
        return round(cost, 6)