from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RouteMeta:
    model: str
    provider: str
    routing_layer: str          # "complexity" | "task_classifier" | "meta_router"
    routing_reason: str
    task_type: str              # "code" | "reasoning" | "creative" | "factual" | "translation" | "summarisation" | "general"
    complexity_score: float     # 0.0 - 1.0
    input_tokens: int
    output_tokens: int
    latency_ms: float
    estimated_cost_usd: float


@dataclass
class RouteResponse:
    content: str
    meta: RouteMeta
    raw: Optional[dict] = field(default=None, repr=False)