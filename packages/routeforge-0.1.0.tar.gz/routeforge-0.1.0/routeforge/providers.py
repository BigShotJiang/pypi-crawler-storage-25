from __future__ import annotations
import time
import httpx
from routeforge.config import ModelEntry


class ProviderError(Exception):
    pass


def _count_tokens_approx(text: str) -> int:
    """Rough token estimate: ~4 chars per token."""
    return max(1, len(text) // 4)


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------

def call_openai(
    model: ModelEntry,
    api_key: str,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    """Returns (content, input_tokens, output_tokens, latency_ms)."""
    import openai
    client = openai.OpenAI(api_key=api_key)
    t0 = time.perf_counter()
    resp = client.chat.completions.create(
        model=model.model_id,
        messages=messages,
        **kwargs,
    )
    latency = (time.perf_counter() - t0) * 1000
    content = resp.choices[0].message.content or ""
    input_tokens = resp.usage.prompt_tokens if resp.usage else _count_tokens_approx(str(messages))
    output_tokens = resp.usage.completion_tokens if resp.usage else _count_tokens_approx(content)
    return content, input_tokens, output_tokens, round(latency, 2)


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------

def call_anthropic(
    model: ModelEntry,
    api_key: str,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    import anthropic
    client = anthropic.Anthropic(api_key=api_key)
    # Anthropic separates system prompt from messages
    system = next((m["content"] for m in messages if m["role"] == "system"), "")
    user_msgs = [m for m in messages if m["role"] != "system"]
    t0 = time.perf_counter()
    resp = client.messages.create(
        model=model.model_id,
        max_tokens=kwargs.get("max_tokens", 2048),
        system=system or "You are a helpful assistant.",
        messages=user_msgs,
    )
    latency = (time.perf_counter() - t0) * 1000
    content = resp.content[0].text if resp.content else ""
    input_tokens = resp.usage.input_tokens if resp.usage else _count_tokens_approx(str(messages))
    output_tokens = resp.usage.output_tokens if resp.usage else _count_tokens_approx(content)
    return content, input_tokens, output_tokens, round(latency, 2)


# ---------------------------------------------------------------------------
# OpenRouter  (OpenAI-compatible, just different base_url + model naming)
# ---------------------------------------------------------------------------

def call_openrouter(
    model: ModelEntry,
    api_key: str,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    import openai
    base_url = model.base_url or "https://openrouter.ai/api/v1"
    client = openai.OpenAI(api_key=api_key, base_url=base_url)
    t0 = time.perf_counter()
    resp = client.chat.completions.create(
        model=model.model_id,
        messages=messages,
        **kwargs,
    )
    latency = (time.perf_counter() - t0) * 1000
    content = resp.choices[0].message.content or ""
    input_tokens = resp.usage.prompt_tokens if resp.usage else _count_tokens_approx(str(messages))
    output_tokens = resp.usage.completion_tokens if resp.usage else _count_tokens_approx(content)
    return content, input_tokens, output_tokens, round(latency, 2)


# ---------------------------------------------------------------------------
# HuggingFace Inference API
# ---------------------------------------------------------------------------

def call_huggingface(
    model: ModelEntry,
    api_key: str,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    base_url = model.base_url or f"https://api-inference.huggingface.co/models/{model.model_id}/v1"
    prompt = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
    payload = {"inputs": prompt, "parameters": {"max_new_tokens": kwargs.get("max_tokens", 512)}}
    t0 = time.perf_counter()
    resp = httpx.post(
        f"{base_url}/chat/completions" if "v1" in base_url else base_url,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={"model": model.model_id, "messages": messages},
        timeout=60,
    )
    latency = (time.perf_counter() - t0) * 1000
    if resp.status_code != 200:
        raise ProviderError(f"HuggingFace error {resp.status_code}: {resp.text}")
    data = resp.json()
    # HF Inference API returns choices in OpenAI format when using /v1/chat/completions
    content = data["choices"][0]["message"]["content"] if "choices" in data else str(data)
    input_tokens = _count_tokens_approx(str(messages))
    output_tokens = _count_tokens_approx(content)
    return content, input_tokens, output_tokens, round(latency, 2)


# ---------------------------------------------------------------------------
# Ollama  (local)
# ---------------------------------------------------------------------------

def call_ollama(
    model: ModelEntry,
    api_key: str | None,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    base_url = model.base_url or "http://localhost:11434"
    t0 = time.perf_counter()
    resp = httpx.post(
        f"{base_url}/api/chat",
        json={"model": model.model_id, "messages": messages, "stream": False},
        timeout=120,
    )
    latency = (time.perf_counter() - t0) * 1000
    if resp.status_code != 200:
        raise ProviderError(f"Ollama error {resp.status_code}: {resp.text}")
    data = resp.json()
    content = data.get("message", {}).get("content", "")
    input_tokens = _count_tokens_approx(str(messages))
    output_tokens = _count_tokens_approx(content)
    return content, input_tokens, output_tokens, round(latency, 2)


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_PROVIDER_MAP = {
    "openai": call_openai,
    "anthropic": call_anthropic,
    "openrouter": call_openrouter,
    "huggingface": call_huggingface,
    "ollama": call_ollama,
}


def dispatch(
    model: ModelEntry,
    api_key: str | None,
    messages: list[dict],
    **kwargs,
) -> tuple[str, int, int, float]:
    fn = _PROVIDER_MAP.get(model.provider)
    if fn is None:
        raise ProviderError(f"Unknown provider: {model.provider!r}")
    return fn(model, api_key, messages, **kwargs)