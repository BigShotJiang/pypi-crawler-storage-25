from __future__ import annotations
from threading import Lock
from routeforge.config import ModelEntry


class KeyBalancer:
    """Round-robin balancer across multiple API keys for a single model."""

    def __init__(self) -> None:
        self._counters: dict[str, int] = {}
        self._lock = Lock()

    def next_key(self, model: ModelEntry) -> str | None:
        if not model.api_keys:
            return None
        if len(model.api_keys) == 1:
            return model.api_keys[0]
        with self._lock:
            idx = self._counters.get(model.name, 0)
            key = model.api_keys[idx % len(model.api_keys)]
            self._counters[model.name] = idx + 1
        return key