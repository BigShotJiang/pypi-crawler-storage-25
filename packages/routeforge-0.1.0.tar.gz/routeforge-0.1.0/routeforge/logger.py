from __future__ import annotations
import json
import os
from datetime import datetime, timezone
from routeforge.models import RouteResponse


class RunLogger:
    def __init__(self, path: str) -> None:
        self.path = path

    def log(self, prompt: str, response: RouteResponse) -> None:
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "prompt_preview": prompt[:200],
            "model": response.meta.model,
            "provider": response.meta.provider,
            "routing_layer": response.meta.routing_layer,
            "routing_reason": response.meta.routing_reason,
            "task_type": response.meta.task_type,
            "complexity_score": response.meta.complexity_score,
            "input_tokens": response.meta.input_tokens,
            "output_tokens": response.meta.output_tokens,
            "latency_ms": response.meta.latency_ms,
            "estimated_cost_usd": response.meta.estimated_cost_usd,
        }
        runs: list[dict] = []
        if os.path.exists(self.path):
            try:
                with open(self.path) as f:
                    runs = json.load(f)
            except (json.JSONDecodeError, OSError):
                runs = []
        runs.append(entry)
        with open(self.path, "w") as f:
            json.dump(runs, f, indent=2)

    def read(self, last_n: int | None = None) -> list[dict]:
        if not os.path.exists(self.path):
            return []
        with open(self.path) as f:
            runs = json.load(f)
        return runs[-last_n:] if last_n else runs