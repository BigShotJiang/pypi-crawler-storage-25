from __future__ import annotations
import re


# ---------------------------------------------------------------------------
# Layer 1 — Complexity scorer
# Returns a float 0.0 (trivial) → 1.0 (very complex)
# ---------------------------------------------------------------------------

_COMPLEX_PATTERNS = [
    r"\bprove\b", r"\bderive\b", r"\banalyze\b", r"\barchitect\b",
    r"\boptimize\b", r"\bcompare.*trade.?off", r"\bexplain.*depth\b",
    r"\bstep[- ]by[- ]step\b", r"\bwhy\b.*\bhow\b", r"\bimplications\b",
]

_SIMPLE_PATTERNS = [
    r"\bwhat is\b", r"\bdefine\b", r"\blist\b", r"\bname\b",
    r"\btranslate\b", r"\bconvert\b", r"\bsummarise\b", r"\bsummarize\b",
]


def complexity_score(prompt: str) -> float:
    text = prompt.lower()
    tokens = len(prompt.split())

    # Token length signal (normalised, cap at 500 tokens = 1.0)
    length_score = min(tokens / 500, 1.0)

    # Pattern signals — complex patterns weighted more heavily
    complex_hits = sum(1 for p in _COMPLEX_PATTERNS if re.search(p, text))
    simple_hits = sum(1 for p in _SIMPLE_PATTERNS if re.search(p, text))
    pattern_score = min(complex_hits * 0.25, 0.75) - min(simple_hits * 0.1, 0.3)

    # Sentence depth: average words per sentence
    sentences = [s.strip() for s in re.split(r"[.!?]", text) if s.strip()]
    avg_words = (sum(len(s.split()) for s in sentences) / len(sentences)) if sentences else 0
    depth_score = min(avg_words / 30, 1.0) * 0.35

    score = (length_score * 0.25) + (depth_score) + (pattern_score * 0.40)
    return round(max(0.0, min(1.0, score)), 4)


# ---------------------------------------------------------------------------
# Layer 2 — Task classifier
# Returns a task type string
# ---------------------------------------------------------------------------

_TASK_RULES: list[tuple[str, list[str]]] = [
    ("code", [
        r"\bcode\b", r"\bfunction\b", r"\bclass\b", r"\bscript\b",
        r"\bpython\b", r"\bjavascript\b", r"\btypescript\b", r"\brust\b",
        r"\bsql\b", r"\bbug\b", r"\bdebug\b", r"\brefactor\b",
        r"\bapi\b.*\bimplement\b", r"\bfastapi\b", r"\bdjango\b",
        r"\bwrite.*function\b", r"\bfix.*code\b",
    ]),
    ("reasoning", [
        r"\bprove\b", r"\bderive\b", r"\blogic\b", r"\bmath\b",
        r"\bcalculate\b", r"\bsolve\b", r"\bequation\b", r"\btheorem\b",
        r"\breason\b", r"\bwhy\b.*\bbecause\b", r"\bargue\b",
        r"\bcritique\b", r"\bevaluate\b",
    ]),
    ("creative", [
        r"\bwrite.*story\b", r"\bpoem\b", r"\blyric\b", r"\bfiction\b",
        r"\bnarrative\b", r"\bcreative\b", r"\bimagine\b", r"\bblog post\b",
        r"\bmarketing copy\b", r"\btagline\b", r"\bcopywrite\b",
    ]),
    ("translation", [
        r"\btranslate\b", r"\bin (french|spanish|german|hindi|arabic|japanese|chinese|korean)\b",
        r"\bto (french|spanish|german|hindi|arabic|japanese|chinese|korean)\b",
    ]),
    ("summarisation", [
        r"\bsummari[sz]e\b", r"\btl;dr\b", r"\bshorten\b",
        r"\bbrief(ly)?\b", r"\bgist\b", r"\bkey points\b",
    ]),
    ("factual", [
        r"\bwhat is\b", r"\bwho is\b", r"\bwhen (was|did|is)\b",
        r"\bwhere (is|was|are)\b", r"\bdefine\b", r"\bexplain\b",
        r"\bhow does\b", r"\bwhat are\b",
    ]),
]


def classify_task(prompt: str) -> str:
    text = prompt.lower()
    scores: dict[str, int] = {}
    for task, patterns in _TASK_RULES:
        hits = sum(1 for p in patterns if re.search(p, text))
        if hits:
            scores[task] = hits
    if not scores:
        return "general"
    return max(scores, key=lambda k: scores[k])