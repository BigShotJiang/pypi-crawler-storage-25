from __future__ import annotations
import yaml
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ModelEntry:
    name: str           # display name / alias
    model_id: str       # provider model string e.g. "openai/gpt-4o"
    provider: str       # "openai" | "anthropic" | "openrouter" | "huggingface" | "ollama"
    api_keys: list[str] = field(default_factory=list)
    base_url: str | None = None
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    context_window: int = 8192
    tags: list[str] = field(default_factory=list)   # e.g. ["code", "strong", "cheap"]


@dataclass
class RouterConfig:
    models: list[ModelEntry] = field(default_factory=list)
    default_model: str | None = None            # alias of fallback model
    log_path: str = "llmrouter_runs.json"
    meta_router_model: str | None = None        # alias of model used for meta-routing
    complexity_threshold: float = 0.5           # below = cheap model, above = strong model

    @classmethod
    def from_yaml(cls, path: str) -> "RouterConfig":
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls._from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RouterConfig":
        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> "RouterConfig":
        models = [
            ModelEntry(
                name=m["name"],
                model_id=m["model_id"],
                provider=m["provider"],
                api_keys=m.get("api_keys", []),
                base_url=m.get("base_url"),
                cost_per_1k_input=m.get("cost_per_1k_input", 0.0),
                cost_per_1k_output=m.get("cost_per_1k_output", 0.0),
                context_window=m.get("context_window", 8192),
                tags=m.get("tags", []),
            )
            for m in data.get("models", [])
        ]
        return cls(
            models=models,
            default_model=data.get("default_model"),
            log_path=data.get("log_path", "llmrouter_runs.json"),
            meta_router_model=data.get("meta_router_model"),
            complexity_threshold=data.get("complexity_threshold", 0.5),
        )

    def get_model(self, name: str) -> ModelEntry | None:
        return next((m for m in self.models if m.name == name), None)

    def get_models_by_tag(self, tag: str) -> list[ModelEntry]:
        return [m for m in self.models if tag in m.tags]