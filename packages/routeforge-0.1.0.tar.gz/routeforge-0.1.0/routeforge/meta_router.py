from __future__ import annotations
import json
from routeforge.config import ModelEntry, RouterConfig
from routeforge.providers import dispatch


# Ambiguous band — scores in this range trigger the meta-router
_AMBIGUOUS_LOW = 0.35
_AMBIGUOUS_HIGH = 0.65


def is_ambiguous(complexity_score: float, task_matched: bool) -> bool:
    """
    Returns True when heuristic routing lacks confidence:
    - No task keyword match, AND
    - Complexity score falls in the uncertain middle band
    """
    return (not task_matched) and (_AMBIGUOUS_LOW <= complexity_score <= _AMBIGUOUS_HIGH)


_SYSTEM_PROMPT = """You are a routing assistant. Given a user prompt and a list of available LLM models, 
select the single best model for the task.

Respond ONLY with a JSON object. No explanation, no markdown, no extra text.

Format:
{
  "model": "<model name from the list>",
  "task_type": "<one of: code, reasoning, creative, translation, summarisation, factual, general>",
  "reason": "<one sentence explaining why>"
}"""


def _build_routing_prompt(prompt: str, models: list[ModelEntry]) -> str:
    model_descriptions = "\n".join(
        f'- "{m.name}": provider={m.provider}, tags={m.tags}, '
        f'cost_per_1k_input=${m.cost_per_1k_input}, context={m.context_window}'
        for m in models
    )
    return (
        f"User prompt:\n{prompt}\n\n"
        f"Available models:\n{model_descriptions}\n\n"
        f"Which model should handle this prompt?"
    )


def meta_route(
    prompt: str,
    config: RouterConfig,
    meta_model: ModelEntry,
    api_key: str | None,
) -> tuple[ModelEntry, str, str] | None:
    """
    Calls a cheap LLM to pick the best model for the prompt.
    Returns (chosen_model, task_type, reason) or None on failure.
    """
    routing_prompt = _build_routing_prompt(prompt, config.models)
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": routing_prompt},
    ]

    try:
        content, _, _, _ = dispatch(meta_model, api_key, messages, max_tokens=200)
        data = _parse_response(content)
        if data is None:
            return None

        chosen_name = data.get("model", "").strip()
        task_type = data.get("task_type", "general").strip()
        reason = data.get("reason", "Meta-router decision").strip()

        chosen_model = config.get_model(chosen_name)
        if chosen_model is None:
            # Model name hallucinated — fall back to default
            return None

        return chosen_model, task_type, reason

    except Exception:
        return None


def _parse_response(content: str) -> dict | None:
    """Safely parse JSON from LLM response, stripping markdown fences if present."""
    text = content.strip()
    # Strip ```json ... ``` fences if the model adds them
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(
            line for line in lines
            if not line.strip().startswith("```")
        ).strip()
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return None