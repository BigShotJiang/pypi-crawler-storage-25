#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-24
################################################################

import time
import numpy as np
import multiprocessing as mp
from dataclasses import dataclass
from typing import Any, Optional

from hex_device import HexDeviceApi, Arm, Hands
from hex_util_runtime import HexRate, HexShmRingBuffer, ns_now, hex_ts_to_ns
from ..base import HexRobotBase, HexRobotBaseParams


@dataclass
class HexRobotHelloY6Params(HexRobotBaseParams):
    led_buffer_size: int = 10


class HexRobotHelloY6(HexRobotBase):

    def __init__(
            self,
            params: HexRobotHelloY6Params = HexRobotHelloY6Params(),
    ) -> None:
        HexRobotBase.__init__(self)
        self.__params = params
        self.__hex_api: Optional[HexDeviceApi] = None
        self.__arm: Optional[Arm] = None
        self.__gripper: Optional[Hands] = None

        self.__dof_dict = {"arm": 6, "gripper": 7}
        self.__ring_dict = {
            "arm_motor": None,
            "gripper_motor": None,
            "gripper_led": None,
        }
        self.init_vars()

    def get_dofs(self) -> dict[str, int]:
        return self.__dof_dict

    def set_gripper_led_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__ring_dict["gripper_led"] is None:
            return
        self.__ring_dict["gripper_led"].write(cmd_dict)

    def get_arm_motor(self, latest: bool = True) -> np.ndarray:
        if self.__ring_dict["arm_motor"] is None:
            return None
        return self.__ring_dict["arm_motor"].read(latest=latest)

    def get_gripper_motor(self, latest: bool = True) -> np.ndarray:
        if self.__ring_dict["gripper_motor"] is None:
            return None
        return self.__ring_dict["gripper_motor"].read(latest=latest)

    def init_vars(self):
        self.__host = self.__params.host
        self.__port = self.__params.port
        self.__ctrl_rate = int(self.__params.ctrl_rate)
        self.__state_buffer_size = int(self.__params.state_buffer_size)
        self.__led_queue_max = int(self.__params.led_buffer_size)
        self.__sens_ts = self.__params.sens_ts

        # state buffer
        arm_state_dtype = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (6, )),
            ("vel", np.float64, (6, )),
        ])
        self.__ring_dict["arm_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=arm_state_dtype,
        )
        gripper_state_dtype = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (7, )),
        ])
        self.__ring_dict["gripper_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=gripper_state_dtype,
        )

        # gripper led buffer
        gripper_led_dtype = np.dtype([
            ("r", np.int64, (6, )),
            ("g", np.int64, (6, )),
            ("b", np.int64, (6, )),
        ])
        self.__ring_dict["gripper_led"] = HexShmRingBuffer(
            capacity=self.__led_queue_max,
            dtype=gripper_led_dtype,
        )

    def init_robot(self):
        # open device
        self.__hex_api = HexDeviceApi(
            ws_url=f"ws://{self.__host}:{self.__port}",
            control_hz=self.__ctrl_rate,
        )

        # open arm
        while self.__hex_api.find_device_by_robot_type(26) is None:
            print("\033[33mArm not found\033[0m")
            time.sleep(1)
        self.__arm = self.__hex_api.find_device_by_robot_type(26)
        self.__arm.start()

        # open gripper
        while self.__hex_api.find_optional_device_by_id(1) is None:
            print("\033[33mGripper not found\033[0m")
            time.sleep(1)
        self.__gripper = self.__hex_api.find_optional_device_by_id(1)
        self.__gripper.set_rgb_stripe_command(
            [255] * 6,
            [0] * 6,
            [0] * 6,
        )

        self._init_event.set()

    def deinit_robot(self):
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()

        if self.__gripper is not None:
            self.__gripper.set_rgb_stripe_command(
                [255] * 6,
                [0] * 6,
                [0] * 6,
            )
        if self.__arm is not None:
            self.__arm.stop()
            self.__arm = None
        if self.__hex_api is not None:
            self.__hex_api.close()
            self.__hex_api = None
        self.__gripper = None

        for key in self.__ring_dict.keys():
            if self.__ring_dict[key] is not None:
                self.__ring_dict[key].close()
                self.__ring_dict[key] = None

    def work_loop(self) -> None:
        rate = HexRate(2 * self.__ctrl_rate)
        while not self.stop_event.is_set():
            rate.sleep()
            self.__state_func()
            self.__led_func()

    def __state_func(self) -> None:
        self.__arm_state_func()
        self.__gripper_state_func()

    def __arm_state_func(self) -> None:
        arm_state = self.__arm.get_simple_motor_status()
        if arm_state is None:
            return

        ts_ns = hex_ts_to_ns(arm_state["ts"]) if self.__sens_ts else ns_now()
        self.__ring_dict["arm_motor"].write({
            "ts_ns": ts_ns,
            "pos": arm_state["pos"],
            "vel": arm_state["vel"],
        })

    def __gripper_state_func(self) -> None:
        gripper_state = self.__gripper.get_simple_motor_status()
        if gripper_state is None:
            return

        ts_ns = hex_ts_to_ns(
            gripper_state["ts"]) if self.__sens_ts else ns_now()
        self.__ring_dict["gripper_motor"].write({
            "ts_ns": ts_ns,
            "pos": gripper_state["pos"],
        })

    def __led_func(self) -> None:
        led_cmd_frame = self.__ring_dict["gripper_led"].read()
        if led_cmd_frame is not None:
            self.__gripper.set_rgb_stripe_command(
                led_cmd_frame["r"].tolist(),
                led_cmd_frame["g"].tolist(),
                led_cmd_frame["b"].tolist(),
            )
