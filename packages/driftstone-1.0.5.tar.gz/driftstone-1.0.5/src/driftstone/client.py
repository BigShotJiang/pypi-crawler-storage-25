from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, Mapping

import httpx

from ._internal.constants import DEFAULT_API_BASE_URL
from ._internal.utils import logger, set_debug
from ._internal.transport import Method, Transport
from .exceptions import DriftstoneError, DriftstoneHTTPError
from .models.repository import DriftstoneUpload, DriftstoneUploadFile
from .resources.repositories import DriftstoneRepositories
from .version import __version__

class Driftstone:
    def __init__(
        self,
        api_key: str,
        *,
        version: Literal["v1"] = "v1",
        timeout: float = 30.0,
        debug: bool = False,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.debug = debug
        set_debug(self.debug)
        
        logger.info("Initializing Driftstone client with provided API key")

        trimmed_key = api_key.strip()
        if not trimmed_key:
            raise ValueError("api_key must be provided")
        if not trimmed_key.startswith("dk-"):
            raise ValueError("Invalid Driftstone API key")

        self.api_key = trimmed_key
        self.version = version
        self.timeout = timeout
        self.base_url = f"{DEFAULT_API_BASE_URL}/{self.version}"

        self._transport = Transport(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.timeout,
            user_agent=f"Driftstone-python/{__version__}",
            http_client=http_client,
        )

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "Driftstone":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _request(
        self,
        method: Method,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self._transport.request(method, path, payload)

    def upload_file(self, url: str, file: str | Path | bytes) -> bool:
        if not isinstance(url, str) or not url.strip():
            raise DriftstoneError("url must be a non-empty string")

        if isinstance(file, bytes):
            content = file
        elif isinstance(file, (str, Path)):
            path = Path(file)
            if not path.exists() or not path.is_file():
                raise DriftstoneError(f"file must be an existing file: {path}")
            content = path.read_bytes()
        else:
            raise DriftstoneError("file must be bytes or a filesystem path")

        try:
            response = httpx.put(
                url.strip(),
                content=content,
                headers={"Content-Type": "application/octet-stream"},
                timeout=self.timeout,
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise DriftstoneHTTPError(f"File upload failed: {exc}") from exc

        return True

    def upload_files(
        self,
        upload: DriftstoneUpload,
        files: list[DriftstoneUploadFile | Mapping[str, str]],
        root: str | Path,
    ) -> bool:
        if not isinstance(upload, DriftstoneUpload):
            raise DriftstoneError("upload must be a DriftstoneUpload")

        root_path = Path(root).resolve()
        if not root_path.exists() or not root_path.is_dir():
            raise DriftstoneError(f"root must be an existing directory: {root_path}")

        upload_urls = {
            upload_url.name: upload_url.url
            for upload_url in upload.upload_urls
        }
        payload_files = DriftstoneRepositories._normalize_upload_files(files)

        for file in payload_files:
            upload_url = upload_urls.get(file["name"])
            if not upload_url:
                raise DriftstoneError(f"Missing upload URL for file '{file['name']}'")

            file_path = (root_path / Path(file["name"])).resolve()
            if root_path != file_path and root_path not in file_path.parents:
                raise DriftstoneError(f"file path must stay within root: {file['name']}")

            self.upload_file(upload_url, file_path)

        return True

    @property
    def repositories(self) -> DriftstoneRepositories:
        return DriftstoneRepositories(self)

    @property
    def repos(self) -> DriftstoneRepositories:
        return self.repositories
