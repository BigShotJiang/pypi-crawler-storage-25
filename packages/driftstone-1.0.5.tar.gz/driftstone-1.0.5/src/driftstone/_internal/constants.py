DEFAULT_API_BASE_URL = "https://pickaxeproject--driftstone-api-v2-api.modal.run"
