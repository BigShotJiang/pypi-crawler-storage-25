from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class DriftstoneRepository:
    id: str
    org_id: str
    name: str
    slug: str
    branch: str
    storage_path: str | None = None
    head_identifier: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneRepository":
        return cls(
            id=str(payload["id"]),
            org_id=str(payload["orgId"]),
            name=str(payload["name"]),
            slug=str(payload["slug"]),
            branch=str(payload["branch"]),
            storage_path=payload.get("storagePath"),
            head_identifier=payload.get("headIdentifier"),
            created_at=payload.get("createdAt"),
            updated_at=payload.get("updatedAt"),
        )

    @property
    def default_branch(self) -> str:
        return self.branch


@dataclass(frozen=True, slots=True)
class DriftstoneBranch:
    id: str
    repo_id: str
    name: str
    storage_path: str | None = None
    run_id: str | None = None
    status: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneBranch":
        return cls(
            id=str(payload["id"]),
            repo_id=str(payload["repoId"]),
            name=str(payload["name"]),
            storage_path=payload.get("storagePath"),
            run_id=payload.get("runId"),
            status=payload.get("status"),
            created_at=payload.get("createdAt"),
            updated_at=payload.get("updatedAt"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneDeleteResult:
    repo_id: str
    status: str
    branch: str | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneDeleteResult":
        return cls(
            repo_id=str(payload["repoId"]),
            status=str(payload["status"]),
            branch=payload.get("branch"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneUploadFile:
    name: str
    hash: str

    def _to_api(self) -> dict[str, str]:
        return {
            "name": self.name,
            "hash": self.hash,
        }


@dataclass(frozen=True, slots=True)
class DriftstoneUploadUrl:
    name: str
    url: str

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneUploadUrl":
        return cls(
            name=str(payload["name"]),
            url=str(payload["url"]),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneUpload:
    repo_id: str
    upload_id: str
    upload_urls: list[DriftstoneUploadUrl]

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneUpload":
        upload_urls = payload.get("uploadUrls", [])
        return cls(
            repo_id=str(payload["repoId"]),
            upload_id=str(payload["uploadId"]),
            upload_urls=[
                DriftstoneUploadUrl._from_api(item)
                for item in upload_urls
                if isinstance(item, Mapping)
            ],
        )


@dataclass(frozen=True, slots=True)
class DriftstoneUploadComplete:
    repo_id: str
    upload_id: str
    status: str

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneUploadComplete":
        return cls(
            repo_id=str(payload["repoId"]),
            upload_id=str(payload["uploadId"]),
            status=str(payload["status"]),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneDownloadFile:
    path: str

    def _to_api(self) -> dict[str, str]:
        return {
            "path": self.path,
        }


@dataclass(frozen=True, slots=True)
class DriftstoneDownloadUrl:
    path: str
    url: str

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneDownloadUrl":
        return cls(
            path=str(payload["path"]),
            url=str(payload["url"]),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneDownload:
    repo_id: str
    download_urls: list[DriftstoneDownloadUrl]

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneDownload":
        download_urls = payload.get("downloadUrls", [])
        return cls(
            repo_id=str(payload["repoId"]),
            download_urls=[
                DriftstoneDownloadUrl._from_api(item)
                for item in download_urls
                if isinstance(item, Mapping)
            ],
        )


@dataclass(frozen=True, slots=True)
class DriftstoneCopy:
    repo_id: str
    run_id: str
    status: str
    source_dir: str | None = None
    dest_dir: str | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneCopy":
        return cls(
            repo_id=str(payload["repoId"]),
            run_id=str(payload["runId"]),
            status=str(payload["status"]),
            source_dir=payload.get("sourceDir"),
            dest_dir=payload.get("destDir"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneCopyStatus:
    repo_id: str
    run_id: str
    status: str
    result: dict[str, Any] | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneCopyStatus":
        result = payload.get("result")
        return cls(
            repo_id=str(payload["repoId"]),
            run_id=str(payload["runId"]),
            status=str(payload["status"]),
            result=result if isinstance(result, dict) else None,
        )
