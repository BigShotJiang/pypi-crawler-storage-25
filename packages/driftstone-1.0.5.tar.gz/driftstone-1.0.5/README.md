## Driftstone - Python

Python SDK for the Driftstone repository API.

### Install

```bash
pip install driftstone
```

### Quick Start

```python
from driftstone import Driftstone

client = Driftstone(api_key="your-api-key")

repo = client.repos.create(
    "hello-world",
)

upload = client.repos.create_upload(
    "hello-world",
    storage_dir="ver-1234abcd",
    branch="main",
    files=[{"name": "README.md", "hash": "64-character-sha256-or-client-hash"}],
)

# Upload each file to the returned signed URL with PUT and
# Content-Type: application/octet-stream.
for upload_url in upload.upload_urls:
    print(upload_url.name, upload_url.url)

client.repos.complete_upload("hello-world", upload.upload_id)

download = client.repos.create_download(
    "hello-world",
    type="main",
    files=[{"path": "ver-1234abcd/README.md"}],
)

for download_url in download.download_urls:
    print(download_url.path, download_url.url)

branch = client.repos.create_branch(
    "hello-world",
    "feature-readme",
    storage_dir="state-123",
    transforms={"README.md": "# Example Repo\nUpdated content.\n"},
)

branch_upload = client.repos.create_upload(
    "hello-world",
    storage_dir="state-456",
    branch=branch.name,
    files=[{"name": "README.md", "hash": "64-character-sha256-or-client-hash"}],
)
client.repos.complete_upload("hello-world", branch_upload.upload_id)

print(repo.id, branch.name)
```

### Using A Context Manager

```python
from driftstone import Driftstone

with Driftstone(api_key="your-api-key") as client:
    repo = client.repos.get("hello-world")
    branches = client.repos.list_branches(repo.slug)

    print(repo.name, [branch.name for branch in branches])
```
