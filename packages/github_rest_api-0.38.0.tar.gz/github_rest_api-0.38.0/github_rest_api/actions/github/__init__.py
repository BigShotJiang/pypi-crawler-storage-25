"""GitHub-related Actions scripts."""
