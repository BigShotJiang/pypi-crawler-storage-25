import argparse
from pathlib import Path

import pytest

from aiva_agent.cli import _parse_vcf_specs


def test_empty_returns_empty_list():
    assert _parse_vcf_specs("") == []
    assert _parse_vcf_specs("   ") == []


def test_single_bare_path_aliases_to_vcf():
    assert _parse_vcf_specs("sample.vcf.gz") == [("vcf", Path("sample.vcf.gz"))]


def test_single_aliased_path():
    assert _parse_vcf_specs("proband=p.vcf.gz") == [("proband", Path("p.vcf.gz"))]


def test_multi_aliased_trio():
    assert _parse_vcf_specs("proband=p.vcf.gz,father=f.vcf.gz,mother=m.vcf.gz") == [
        ("proband", Path("p.vcf.gz")),
        ("father", Path("f.vcf.gz")),
        ("mother", Path("m.vcf.gz")),
    ]


def test_strips_whitespace_around_parts():
    assert _parse_vcf_specs(" proband = p.vcf.gz , father = f.vcf.gz ") == [
        ("proband", Path("p.vcf.gz")),
        ("father", Path("f.vcf.gz")),
    ]


def test_rejects_mix_of_bare_and_aliased():
    with pytest.raises(argparse.ArgumentTypeError, match="Mix of bare path"):
        _parse_vcf_specs("p.vcf.gz,father=f.vcf.gz")


def test_rejects_multiple_bare_paths():
    with pytest.raises(argparse.ArgumentTypeError, match="alias=path syntax"):
        _parse_vcf_specs("a.vcf.gz,b.vcf.gz")


def test_rejects_duplicate_alias():
    with pytest.raises(argparse.ArgumentTypeError, match="Duplicate alias"):
        _parse_vcf_specs("a=p.vcf.gz,a=q.vcf.gz")


def test_rejects_empty_alias():
    with pytest.raises(argparse.ArgumentTypeError, match="Empty alias"):
        _parse_vcf_specs("=p.vcf.gz")


def test_rejects_empty_path():
    with pytest.raises(argparse.ArgumentTypeError, match="Empty path"):
        _parse_vcf_specs("alias=")


@pytest.mark.parametrize(
    "bad_alias",
    ["1father", "with-dash", "with space", "has.dot", "has/slash", "x" * 33],
)
def test_rejects_invalid_identifier(bad_alias: str):
    # The parser may classify these as "Invalid alias" or as the bare-path-
    # contains-equals fast-path; both are correct rejections. We only assert
    # that *some* ArgumentTypeError fires.
    with pytest.raises(argparse.ArgumentTypeError):
        _parse_vcf_specs(f"{bad_alias}=p.vcf.gz")


def test_rejects_invalid_identifier_in_multi_spec():
    # In a multi-spec input the bare-path fast-path doesn't apply, so the
    # original "Invalid alias" message surfaces. Pin that message here.
    with pytest.raises(argparse.ArgumentTypeError, match="Invalid alias"):
        _parse_vcf_specs("good=a.vcf.gz,bad-alias=b.vcf.gz")


def test_underscore_and_digit_aliases_ok():
    assert _parse_vcf_specs("_alias=p.vcf.gz") == [("_alias", Path("p.vcf.gz"))]
    assert _parse_vcf_specs("a1=p.vcf.gz") == [("a1", Path("p.vcf.gz"))]


@pytest.mark.parametrize(
    "reserved", ["select", "from", "where", "table", "view", "join", "SELECT", "Where"]
)
def test_rejects_reserved_keyword_aliases(reserved: str):
    with pytest.raises(argparse.ArgumentTypeError, match="Reserved DuckDB keyword"):
        _parse_vcf_specs(f"{reserved}=p.vcf.gz")


@pytest.mark.parametrize("alias", ["foo_long", "Proband_Long", "vcf_long", "x_LONG"])
def test_rejects_long_suffix_aliases(alias: str):
    # `_long` is reserved as the auto-generated tidy companion suffix.
    with pytest.raises(argparse.ArgumentTypeError, match="Reserved alias suffix"):
        _parse_vcf_specs(f"{alias}=p.vcf.gz")


def test_default_vcf_alias_is_not_reserved():
    # `vcf` is intentionally allowed (it's the default alias for bare paths).
    assert _parse_vcf_specs("vcf=p.vcf.gz") == [("vcf", Path("p.vcf.gz"))]


def test_rejects_case_insensitive_duplicate_alias():
    # DuckDB view names are case-insensitive — catch the collision at parse time
    # rather than letting it fail later as a Catalog Error.
    with pytest.raises(argparse.ArgumentTypeError, match="Duplicate alias"):
        _parse_vcf_specs("Proband=p.vcf.gz,proband=q.vcf.gz")


def test_helpful_error_when_bare_path_contains_equals():
    # A path like '/data/key=value.vcf.gz' would otherwise produce a confusing
    # "Invalid alias '/data/key'" message; the parser should hint at the cause.
    with pytest.raises(argparse.ArgumentTypeError, match="bare path"):
        _parse_vcf_specs("/data/key=value.vcf.gz")
