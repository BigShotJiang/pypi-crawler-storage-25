import json

import pytest

from aiva_agent.tools._shared import (
    extract_display,
    extract_json,
    extract_tool_summary,
    format_table_response,
    make_table_id,
    set_interface,
    to_json,
)


@pytest.fixture
def web_interface():
    """Opt-in to the structured-envelope shape `format_table_response`
    emits on the web interface. The autouse fixture in conftest.py resets
    back to `"cli"` after each test."""
    set_interface("web")


def test_to_json_str_passes_through():
    assert to_json("hello") == "hello"


def test_to_json_dict_serializes_with_indent():
    text = to_json({"a": 1, "b": [2, 3]})
    assert json.loads(text) == {"a": 1, "b": [2, 3]}
    assert "\n" in text  # indented


def test_to_json_handles_non_serializable_via_default_str():
    class Foo:
        def __repr__(self) -> str:
            return "Foo()"

    text = to_json({"f": Foo()})
    assert "Foo()" in text


def test_extract_json_finds_object_in_prose():
    text = "Here is the result:\n{\"classification\": \"Pathogenic\", \"score\": 7}\nDone."
    assert extract_json(text) == {"classification": "Pathogenic", "score": 7}


def test_extract_json_returns_none_when_no_object():
    assert extract_json("just prose, no braces") is None


def test_extract_json_returns_none_on_invalid_json():
    assert extract_json("{not valid json}") is None


def test_extract_json_handles_nested_objects():
    text = '{"outer": {"inner": [1, 2, {"deep": "ok"}]}}'
    assert extract_json(text) == {"outer": {"inner": [1, 2, {"deep": "ok"}]}}


def test_make_table_id_format_and_uniqueness():
    tid = make_table_id()
    assert tid.startswith("tbl_")
    assert len(tid) == 4 + 12  # "tbl_" + 6 hex bytes
    assert all(c in "0123456789abcdef" for c in tid[4:])
    assert len({make_table_id() for _ in range(500)}) == 500


def test_format_table_response_returns_json_string(web_interface):
    out = format_table_response(["a", "b"], [(1, 2), (3, 4)])
    assert isinstance(out, str)
    env = json.loads(out)
    assert env["success"] is True
    assert env["tool_name"] == "query_vcf"
    assert env["display"]["type"] == "table"
    assert env["display"]["data"]["columns"] == ["a", "b"]
    assert env["display"]["data"]["rows"] == [{"a": 1, "b": 2}, {"a": 3, "b": 4}]
    assert env["table_id"] in env["message"]


def test_format_table_response_coerces_unsupported_cells(web_interface):
    class Weird:
        def __repr__(self) -> str:
            return "Weird()"

    out = format_table_response(["x", "y"], [(["nested"], Weird())])
    env = json.loads(out)
    row = env["display"]["data"]["rows"][0]
    assert row["x"] == ["nested"]
    assert row["y"] == "Weird()"


def test_format_table_response_zero_rows(web_interface):
    out = format_table_response(["a"], [])
    env = json.loads(out)
    assert env["display"]["data"]["rows"] == []
    assert "0 rows" in env["message"]


def test_format_table_response_singular_message(web_interface):
    out = format_table_response(["a"], [(1,)])
    env = json.loads(out)
    assert "1 row " in env["message"]


def test_extract_display_round_trip(web_interface):
    out = format_table_response(["a"], [(1,)])
    env = extract_display(out)
    assert env is not None
    assert env["display"]["type"] == "table"
    assert env["table_id"].startswith("tbl_")


def test_format_table_response_cli_returns_tsv():
    """On the CLI interface the model needs the rows themselves, not a
    table_id placeholder. CLI is the contextvar default."""
    out = format_table_response(["chrom", "pos"], [("chr1", 100), ("chr2", 200)])
    assert isinstance(out, str)
    assert not out.lstrip().startswith("{")
    assert "tbl_" not in out
    assert "[TABLE:" not in out
    assert out.startswith("chrom\tpos\n")
    assert "chr1\t100" in out
    assert "chr2\t200" in out
    assert out.rstrip().endswith("(2 rows)")


def test_format_table_response_cli_zero_rows():
    out = format_table_response(["a"], [])
    assert out == "(0 rows)"


def test_extract_display_rejects_non_envelope():
    assert extract_display("") is None
    assert extract_display("SQL error: foo") is None
    assert extract_display("plain prose with no braces") is None
    assert extract_display('{"foo": "bar"}') is None  # no display key
    assert extract_display('{"display": {"type": "image"}}') is None  # wrong type
    assert extract_display("{not valid json}") is None


def test_extract_display_rejects_python_repr():
    # Sessions persisted before format_table_response returned a JSON string
    # stored Python repr. We deliberately do not parse those.
    repr_text = "{'success': True, 'display': {'type': 'table', 'data': {}}}"
    assert extract_display(repr_text) is None


def test_extract_tool_summary_returns_stripped_value():
    assert extract_tool_summary('{"summary": "Counting BRCA1 variants", "sql": "SELECT 1"}') == "Counting BRCA1 variants"
    assert extract_tool_summary('{"summary": "  with surrounding space  "}') == "with surrounding space"


def test_extract_tool_summary_returns_none_when_missing():
    assert extract_tool_summary(None) is None
    assert extract_tool_summary("") is None
    assert extract_tool_summary("not json") is None
    assert extract_tool_summary("[1,2,3]") is None  # not a dict
    assert extract_tool_summary('{"sql": "SELECT 1"}') is None  # no summary key
    assert extract_tool_summary('{"summary": ""}') is None  # empty after strip
    assert extract_tool_summary('{"summary": "   "}') is None  # whitespace only
    assert extract_tool_summary('{"summary": 42}') is None  # non-string
