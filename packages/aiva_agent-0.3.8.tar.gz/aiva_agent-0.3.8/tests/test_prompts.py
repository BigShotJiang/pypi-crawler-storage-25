from pathlib import Path

import pytest

from aiva_agent.prompts import (
    ANNOTATE_SECTION,
    CLASSIFY_SECTION,
    LITERATURE_SECTION,
    RANK_GENES_SECTION,
    TRIALS_SECTION,
    VCF_SECTION_BASE,
    VCF_SECTION_MULTI_TEMPLATE,
    VCF_SECTION_SINGLE,
    WEB_SECTION,
    get_main_system_prompt,
)
from aiva_agent.tools._shared import set_interface


@pytest.fixture
def web_interface():
    """`VCF_SECTION_BASE` is the web-shape literal — substring assertions
    against it require the web variant. Conftest autouse resets after."""
    set_interface("web")


def test_core_sections_always_included():
    p = get_main_system_prompt(["vcf"])
    assert "AIVA" in p
    assert "DIRECTNESS AND ANTI-SYCOPHANCY" in p
    assert "SOURCE CITATION RULES" in p
    assert "RESPONSE FORMATTING" in p


def test_only_enabled_tool_sections_appear():
    p = get_main_system_prompt(["literature"])
    assert LITERATURE_SECTION in p
    assert ANNOTATE_SECTION not in p
    assert TRIALS_SECTION not in p
    assert RANK_GENES_SECTION not in p
    assert CLASSIFY_SECTION not in p
    assert VCF_SECTION_BASE not in p


def test_unknown_tool_names_silently_skipped():
    p = get_main_system_prompt(["bogus"])
    for section in (
        VCF_SECTION_BASE,
        ANNOTATE_SECTION,
        LITERATURE_SECTION,
        TRIALS_SECTION,
        RANK_GENES_SECTION,
        CLASSIFY_SECTION,
    ):
        assert section not in p


def test_classify_section_includes_argument_template():
    p = get_main_system_prompt(["classify"])
    assert "variant_data" in p
    assert "classification_type" in p
    assert "phenotype_terms" in p
    assert "additional_context" in p
    assert "GRCh37" in p and "GRCh38" in p


def test_full_prompt_assembles_all_sections(web_interface):
    enabled = ["vcf", "annotate", "literature", "trials", "rank_genes", "web", "classify"]
    p = get_main_system_prompt(enabled)
    for section in (
        VCF_SECTION_BASE,
        ANNOTATE_SECTION,
        LITERATURE_SECTION,
        TRIALS_SECTION,
        RANK_GENES_SECTION,
        WEB_SECTION,
        CLASSIFY_SECTION,
    ):
        assert section in p


def test_web_section_documents_action_parameter():
    p = get_main_system_prompt(["web"])
    assert "action='search'" in p or "action=\"search\"" in p
    assert "action='scrape'" in p or "action=\"scrape\"" in p


def test_section_ordering_preserves_enabled_order(web_interface):
    p = get_main_system_prompt(["literature", "vcf", "annotate"])
    assert p.index(LITERATURE_SECTION) < p.index(VCF_SECTION_BASE) < p.index(ANNOTATE_SECTION)


def test_vcf_section_single_view_default(web_interface):
    p = get_main_system_prompt(["vcf"])
    assert VCF_SECTION_BASE in p
    assert VCF_SECTION_SINGLE in p
    assert "MULTI-VCF MODE" not in p


def test_vcf_section_multi_view_when_multiple_specs(web_interface):
    specs = [
        ("proband", Path("p.vcf.gz")),
        ("father", Path("f.vcf.gz")),
        ("mother", Path("m.vcf.gz")),
    ]
    p = get_main_system_prompt(["vcf"], vcf_specs=specs)
    assert VCF_SECTION_BASE in p
    assert "MULTI-VCF MODE" in p
    assert "`proband`" in p
    assert "`father`" in p
    assert "`mother`" in p
    assert VCF_SECTION_SINGLE not in p


def test_vcf_section_cli_replaces_table_id_instruction(web_interface):
    """On the CLI interface the model receives plain TSV — the system prompt
    must NOT instruct it to emit `[TABLE:tbl_…]` placeholders, and it MUST
    tell the model to render the rows itself."""
    p_web = get_main_system_prompt(["vcf"])
    set_interface("cli")
    p_cli = get_main_system_prompt(["vcf"])
    assert "reference the table as `[TABLE:" not in p_cli
    assert "reference the table as `[TABLE:" in p_web
    assert "Do NOT emit `[TABLE:" in p_cli
    assert "render the rows yourself" in p_cli
    assert "TSV" in p_cli


def test_vcf_section_documents_format_column_convention():
    p = get_main_system_prompt(["vcf"])
    assert "FORMAT_<FIELD>_<SAMPLE>" in p
    # Old (incorrect) "structs" wording must not regress.
    assert "FORMAT structs" not in p


def test_bash_section_appears_when_enabled():
    p = get_main_system_prompt(["bash"])
    assert "SHELL ACCESS" in p
    assert "run_bash" in p


def test_bash_section_bakes_in_workdir(tmp_path):
    p = get_main_system_prompt(["bash"], workdir=tmp_path)
    assert str(tmp_path) in p


def test_bash_section_falls_back_to_cwd_without_workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    p = get_main_system_prompt(["bash"])
    assert str(tmp_path) in p


def test_bash_section_absent_when_disabled():
    p = get_main_system_prompt(["literature"])
    assert "SHELL ACCESS" not in p
    assert "run_bash" not in p


def test_bash_section_warns_against_env_dump():
    p = get_main_system_prompt(["bash"])
    assert "LLM_API_KEY" in p
    assert "printenv" in p
    assert "private" in p.lower()


def test_bash_section_directs_failed_tools_to_alternative_apis():
    p = get_main_system_prompt(["bash"])
    assert "structured tool" in p.lower()
    assert "different" in p.lower()
    assert "upstream" in p.lower()


def test_bash_section_lists_additional_biomedical_apis():
    p = get_main_system_prompt(["bash"])
    bash_section = p[p.index("SHELL ACCESS"):]
    for name in ("Open Targets", "Ensembl REST", "UniProt", "DisGeNET", "GTEx", "OMIM", "HPO"):
        assert name in bash_section, f"missing API name in bash section: {name}"


def test_bam_section_renders_when_specs_and_bash_enabled():
    p = get_main_system_prompt(
        ["bash"], bam_specs=[("bam", Path("/tmp/x.bam"))]
    )
    assert "BAM/CRAM ACCESS" in p
    assert "pysam" in p
    assert "/tmp/x.bam" in p


def test_bam_section_multi_lists_each_alias():
    specs = [("tumor", Path("/tmp/t.bam")), ("normal", Path("/tmp/n.bam"))]
    p = get_main_system_prompt(["bash"], bam_specs=specs)
    assert "MULTI-BAM MODE" in p
    assert "`tumor`" in p and "`normal`" in p


def test_bam_section_absent_without_specs():
    p = get_main_system_prompt(["bash"])
    assert "BAM/CRAM ACCESS" not in p


def test_bam_section_absent_when_bash_disabled():
    # bash is the only access path now; without it, surfacing BAM paths would
    # point the agent at a tool it doesn't have.
    p = get_main_system_prompt(
        ["literature"], bam_specs=[("bam", Path("/tmp/x.bam"))]
    )
    assert "BAM/CRAM ACCESS" not in p


def test_image_section_web_uses_workdir_url_prefix(web_interface):
    p = get_main_system_prompt(["bash"])
    assert "IMAGE RENDERING" in p
    assert "/workdir/" in p
    assert "![alt](/workdir/<relative-path>)" in p
    assert "absolute filesystem path" not in p.lower() or "do not use absolute" in p.lower()


def test_image_section_cli_reports_absolute_path():
    p = get_main_system_prompt(["bash"])
    assert "IMAGE OUTPUT" in p
    assert "/workdir/" not in p
    assert "absolute filesystem path" in p.lower()
    assert "Do NOT emit `![alt](...)` markdown" in p


def test_image_section_absent_when_bash_disabled():
    """Without `bash`, the model has no way to save images, so the section
    is dead weight and we drop it on both interfaces."""
    for interface in ("cli", "web"):
        set_interface(interface)
        p = get_main_system_prompt(["literature"])
        assert "IMAGE RENDERING" not in p
        assert "IMAGE OUTPUT" not in p
