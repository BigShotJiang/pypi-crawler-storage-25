"""Integration test for the compact vcf_schema summary.

Uses the bundled `data/test.vcf.gz` (a 56-sample CAGI cohort) to verify the
summary fits in the agent's context budget and lists samples + FORMAT field
names correctly. Skips if the test fixture isn't present.
"""

from pathlib import Path

import pytest

FIXTURE = Path("data/test.vcf.gz")


@pytest.fixture
def summary() -> str:
    if not FIXTURE.exists():
        pytest.skip(f"missing fixture: {FIXTURE}")
    from aiva_agent.tools.vcf import _open_connection, _summarize_view

    specs = [("vcf", FIXTURE)]
    con = _open_connection(specs)
    try:
        return _summarize_view(con, "vcf", FIXTURE)
    finally:
        con.close()


@pytest.fixture
def long_summary() -> str:
    if not FIXTURE.exists():
        pytest.skip(f"missing fixture: {FIXTURE}")
    from aiva_agent.tools.vcf import _open_connection, _summarize_view

    specs = [("vcf", FIXTURE)]
    con = _open_connection(specs)
    try:
        return _summarize_view(con, "vcf_long", FIXTURE)
    finally:
        con.close()


def test_summary_is_compact(summary: str):
    # The whole single-view summary should fit in a handful of lines, not
    # hundreds. A 56-sample file produces 430 raw DESCRIBE rows; the summary
    # must collapse them.
    n_lines = summary.count("\n") + 1
    assert n_lines <= 10, f"expected ≤10 lines, got {n_lines}\n{summary}"


def test_summary_lists_view_header(summary: str):
    assert summary.startswith("view: vcf")
    assert "data/test.vcf.gz" in summary


def test_summary_lists_standard_columns(summary: str):
    assert "CHROM VARCHAR" in summary
    assert "POS BIGINT" in summary
    assert "ALT VARCHAR[]" in summary


def test_summary_includes_info_block(summary: str):
    assert "INFO_AC" in summary
    assert "INFO_AN" in summary


def test_summary_lists_samples(summary: str):
    assert "samples" in summary
    # The fixture has trio CAGI7_RGP IDs; verify at least one shows up.
    assert "CAGI7_RGP" in summary


def test_long_summary_marks_shape_and_sample_id(long_summary: str):
    assert long_summary.startswith("view: vcf_long")
    assert "tidy/long" in long_summary
    assert "SAMPLE_ID" in long_summary


def test_long_summary_uses_bare_format_columns(long_summary: str):
    # Long-format FORMAT cols have no per-sample suffix; the schema must
    # render them as bare FORMAT_<FIELD> on a single line.
    format_line = next(
        (line for line in long_summary.splitlines() if "FORMAT (per row" in line),
        None,
    )
    assert format_line is not None, f"missing FORMAT line:\n{long_summary}"
    assert "FORMAT_GT VARCHAR" in format_line
    assert "FORMAT_AD INTEGER[]" in format_line
    # No per-sample suffix should leak in.
    assert "FORMAT_GT_CAGI7" not in format_line


def test_long_summary_omits_samples_listing(long_summary: str):
    # Sample IDs are rows in long mode, not columns — don't list them.
    assert "samples (" not in long_summary


def test_summary_lists_format_field_names_once(summary: str):
    # Each canonical FORMAT field should appear exactly once in the
    # FORMAT/<sample> block, regardless of how many samples are in the file.
    format_line = next(
        (line for line in summary.splitlines() if line.lstrip().startswith("FORMAT/")),
        None,
    )
    assert format_line is not None, f"missing FORMAT line:\n{summary}"
    for fid in ("GT", "AD", "GQ", "FT", "PGT", "PID", "PS", "RGQ"):
        assert format_line.count(f"{fid} ") == 1 or format_line.count(f", {fid}") == 1, (
            f"{fid} should appear exactly once in:\n{format_line}"
        )
