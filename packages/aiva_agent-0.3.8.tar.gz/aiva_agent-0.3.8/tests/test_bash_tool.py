import asyncio
import json
from pathlib import Path

from agents.tool_context import ToolContext

from aiva_agent.tools.bash import (
    MAX_OUTPUT_CHARS,
    MAX_STREAM_BYTES,
    _execute,
    _truncate_middle,
    build_bash_tool,
)


def _run(cwd: Path | str, command: str, timeout_seconds: int = 60) -> str:
    return asyncio.run(_execute(str(cwd), command, timeout_seconds))


def _invoke_through_closure(tool, **kwargs) -> str:
    """Drive the FunctionTool's agent-facing entry so build_bash_tool's
    closure (the captured cwd) is actually exercised."""
    kwargs.setdefault("summary", "test call")
    args_json = json.dumps(kwargs)
    ctx: ToolContext = ToolContext(
        context=None,
        tool_name=tool.name,
        tool_call_id="test-call-id",
        tool_arguments=args_json,
    )

    async def _go() -> str:
        return await tool.on_invoke_tool(ctx, args_json)

    return asyncio.run(_go())


def test_truncate_middle_preserves_short_text():
    assert _truncate_middle("hello", 100) == "hello"


def test_truncate_middle_truncates_long_text():
    text = "a" * 20000
    out = _truncate_middle(text, 8000)
    assert len(out) <= 8200
    assert "truncated" in out
    assert out.startswith("a")
    assert out.endswith("a")


def test_execute_captures_stdout(tmp_path):
    out = _run(tmp_path, "echo hello world")
    assert "hello world" in out
    assert "exit_code: 0" in out


def test_execute_runs_in_workdir(tmp_path):
    (tmp_path / "marker.txt").write_text("here")
    out = _run(tmp_path, "ls")
    assert "marker.txt" in out


def test_execute_captures_stderr_and_nonzero_exit(tmp_path):
    out = _run(tmp_path, "echo problem >&2; exit 7")
    assert "problem" in out
    assert "stderr" in out
    assert "exit_code: 7" in out


def test_execute_timeout(tmp_path):
    out = _run(tmp_path, "sleep 5", timeout_seconds=1)
    assert "timeout after 1s" in out


def test_execute_truncates_huge_output(tmp_path):
    n = MAX_OUTPUT_CHARS * 3
    out = _run(tmp_path, f"python3 -c \"print('x' * {n})\"")
    assert len(out) <= MAX_OUTPUT_CHARS + 200
    assert "truncated" in out


def test_execute_caps_stream_bytes_for_runaway_output(tmp_path):
    # A command that would emit ~50MB if read fully. The byte cap must keep
    # the captured stdout near MAX_STREAM_BYTES, bounding Python memory.
    cmd = "python3 -c \"import sys; sys.stdout.write('x' * 50_000_000)\""
    out = _run(tmp_path, cmd, timeout_seconds=10)
    assert "exit_code: 0" in out
    stdout_section = out.split("stdout:\n", 1)[1].split("\n\nexit_code", 1)[0]
    assert len(stdout_section) <= MAX_STREAM_BYTES + 1024


def test_build_bash_tool_resolves_workdir_to_absolute(tmp_path, monkeypatch):
    # Relative path passed to build_bash_tool must be resolved at construction
    # time, not at invocation: chdir away before invoking and verify pwd still
    # reports tmp_path.
    monkeypatch.chdir(tmp_path)
    tool, cleanup = build_bash_tool(Path("."))
    monkeypatch.chdir(Path("/"))
    try:
        out = _invoke_through_closure(tool, command="pwd")
        assert str(tmp_path.resolve()) in out
        assert getattr(tool, "name", None) == "run_bash"
    finally:
        cleanup()


def test_build_bash_tool_invocation_through_function_tool_surface(tmp_path):
    (tmp_path / "hello.txt").write_text("world")
    tool, cleanup = build_bash_tool(tmp_path)
    try:
        out = _invoke_through_closure(tool, command="cat hello.txt")
        assert "world" in out
        assert "exit_code: 0" in out
    finally:
        cleanup()
