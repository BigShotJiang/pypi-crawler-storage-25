"""Tests for the pipe-delimited Format-spec parser and the auto-generated
DuckDB macros that expose VEP CSQ / snpEff ANN / bcftools BCSQ subfields
without making the agent count pipe positions."""

from pathlib import Path

import pytest

from aiva_agent.tools.vcf import (
    _open_connection,
    _pipe_format_subfields,
    _sanitize_subfield,
    _summarize_view,
)

VEP_FIXTURE = Path("data/8XNjn0QrKY82y0rm.vcf.gz")
GATK_FIXTURE = Path("data/test.vcf.gz")


# ---------------------------------------------------------------------------
# Pure-function: _pipe_format_subfields
# ---------------------------------------------------------------------------


def test_parses_vep_csq_description():
    desc = (
        '"Consequence annotations from Ensembl VEP. Format: '
        'Allele|Consequence|IMPACT|SYMBOL|Gene|Feature_type|Feature"'
    )
    subs = _pipe_format_subfields(desc)
    assert subs == [
        "Allele", "Consequence", "IMPACT", "SYMBOL", "Gene", "Feature_type", "Feature"
    ]


def test_parses_snpeff_ann_with_single_quotes_and_padding():
    desc = (
        "\"Functional annotations: 'Allele | Annotation | Annotation_Impact | "
        "Gene_Name | Gene_ID'\""
    )
    subs = _pipe_format_subfields(desc)
    assert subs == [
        "Allele", "Annotation", "Annotation_Impact", "Gene_Name", "Gene_ID"
    ]


def test_parses_bcsq_short_form():
    desc = '"Format: Consequence|gene|transcript|biotype"'
    subs = _pipe_format_subfields(desc)
    assert subs == ["Consequence", "gene", "transcript", "biotype"]


def test_strips_trailing_period():
    desc = '"Format: A|B|C."'
    assert _pipe_format_subfields(desc) == ["A", "B", "C"]


def test_preserves_empty_subfield_positions():
    # Real CSQ headers do leave empty positions to keep column indices stable.
    desc = '"Format: A||C"'
    assert _pipe_format_subfields(desc) == ["A", "", "C"]


def test_returns_none_for_no_format_clause():
    assert _pipe_format_subfields('"Allele count"') is None
    assert _pipe_format_subfields('"Total depth at site"') is None


def test_returns_none_for_too_few_subfields():
    # Need ≥3 to be considered a pipe-delimited format spec.
    assert _pipe_format_subfields('"Format: A|B"') is None


def test_returns_none_for_empty_or_missing_description():
    assert _pipe_format_subfields("") is None
    assert _pipe_format_subfields(None) is None


def test_handles_unbalanced_outer_quotes():
    # If duckhts ever stops preserving the outer quotes we should still parse.
    desc = "Format: A|B|C|D"
    assert _pipe_format_subfields(desc) == ["A", "B", "C", "D"]


# ---------------------------------------------------------------------------
# Pure-function: _sanitize_subfield
# ---------------------------------------------------------------------------


def test_sanitize_lowercases_and_replaces_specials():
    assert _sanitize_subfield("CLIN_SIG") == "clin_sig"
    assert _sanitize_subfield("REF/ALT") == "ref_alt"
    assert _sanitize_subfield("Protein position") == "protein_position"


def test_sanitize_prefixes_leading_digit():
    assert _sanitize_subfield("1KG_AF") == "_1kg_af"


def test_sanitize_returns_empty_for_unusable():
    assert _sanitize_subfield("") == ""
    assert _sanitize_subfield("---") == ""


# ---------------------------------------------------------------------------
# Integration: real VEP-annotated VCF
# ---------------------------------------------------------------------------


@pytest.fixture
def vep_con():
    if not VEP_FIXTURE.exists():
        pytest.skip(f"missing fixture: {VEP_FIXTURE}")
    con = _open_connection([("vcf", VEP_FIXTURE)])
    try:
        yield con
    finally:
        con.close()


def test_csq_macros_registered(vep_con):
    # A handful of canonical CSQ subfields all the way to the end of the spec.
    expected = [
        "vcf_csq_consequence",
        "vcf_csq_clin_sig",
        "vcf_csq_symbol",
        "vcf_csq_cadd_phred",
    ]
    rows = vep_con.execute(
        "SELECT function_name FROM duckdb_functions() "
        "WHERE function_name LIKE 'vcf_csq_%'"
    ).fetchall()
    names = {r[0] for r in rows}
    for macro in expected:
        assert macro in names, f"missing macro: {macro}"


def test_csq_consequence_macro_returns_per_transcript_list(vep_con):
    rows = vep_con.execute(
        "SELECT vcf_csq_consequence(INFO_CSQ) FROM vcf "
        "WHERE INFO_CSQ IS NOT NULL LIMIT 3"
    ).fetchall()
    for (consequences,) in rows:
        assert isinstance(consequences, list)
        assert len(consequences) >= 1
        assert all(isinstance(c, str) for c in consequences)


def test_substring_trap_is_closed(vep_con):
    # ILIKE '%pathogenic%' over the raw blob picks up `not_pathogenic`,
    # `Conflicting_classifications_of_pathogenicity`, and similar tokens.
    # The macro form is exact-value: it must produce fewer hits on a real
    # ClinVar-annotated VCF.
    ilike_count = vep_con.execute(
        "SELECT count(*) FROM vcf WHERE "
        "len(list_filter(INFO_CSQ, x -> x ILIKE '%pathogenic%')) > 0"
    ).fetchone()[0]
    macro_count = vep_con.execute(
        "SELECT count(*) FROM vcf WHERE "
        "list_contains(vcf_csq_clin_sig(INFO_CSQ), 'pathogenic') OR "
        "list_contains(vcf_csq_clin_sig(INFO_CSQ), 'likely_pathogenic')"
    ).fetchone()[0]
    assert ilike_count > macro_count, (
        f"expected ilike > macro on a ClinVar-annotated VCF; "
        f"got ilike={ilike_count}, macro={macro_count}"
    )


def test_summary_lists_csq_subfields(vep_con):
    summary = _summarize_view(vep_con, "vcf", VEP_FIXTURE)
    assert "INFO_CSQ" in summary
    assert "pipe-delimited" in summary
    assert "vcf_csq_" in summary
    # A few canonical subfields should appear by sanitized name.
    for name in ("consequence", "clin_sig", "symbol"):
        assert name in summary, f"expected {name} in:\n{summary}"


# ---------------------------------------------------------------------------
# GATK-only fixture: zero pipe-delimited fields, no macros, no errors
# ---------------------------------------------------------------------------


def test_gatk_fixture_registers_no_csq_macros():
    if not GATK_FIXTURE.exists():
        pytest.skip(f"missing fixture: {GATK_FIXTURE}")
    con = _open_connection([("vcf", GATK_FIXTURE)])
    try:
        rows = con.execute(
            "SELECT function_name FROM duckdb_functions() "
            "WHERE function_name LIKE 'vcf_csq_%' OR function_name LIKE 'vcf_ann_%'"
        ).fetchall()
        assert rows == []
        summary = _summarize_view(con, "vcf", GATK_FIXTURE)
        assert "pipe-delimited" not in summary
    finally:
        con.close()


# ---------------------------------------------------------------------------
# Multi-VCF: alias prefix prevents macro-name collisions across views
# ---------------------------------------------------------------------------


def test_multi_vcf_macros_are_namespaced_by_alias():
    if not VEP_FIXTURE.exists():
        pytest.skip(f"missing fixture: {VEP_FIXTURE}")
    # Register the same VEP file twice under different aliases. If alias
    # namespacing weren't applied the second registration would either
    # fail (CREATE) or silently clobber the first. With CREATE OR REPLACE
    # we get same-name collisions which we want to detect, so verify the
    # presence of distinct macro names.
    con = _open_connection([("proband", VEP_FIXTURE), ("father", VEP_FIXTURE)])
    try:
        rows = con.execute(
            "SELECT function_name FROM duckdb_functions() "
            "WHERE function_name IN ("
            "'proband_csq_consequence','father_csq_consequence',"
            "'proband_csq_clin_sig','father_csq_clin_sig')"
        ).fetchall()
        names = {r[0] for r in rows}
        for n in (
            "proband_csq_consequence",
            "father_csq_consequence",
            "proband_csq_clin_sig",
            "father_csq_clin_sig",
        ):
            assert n in names, f"missing namespaced macro: {n}"
    finally:
        con.close()
