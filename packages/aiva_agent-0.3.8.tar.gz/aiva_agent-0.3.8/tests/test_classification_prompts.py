"""Tests for the dynamic ACMG/AMP prompt builders."""

import json

import pytest

from aiva_agent.classification_prompts import (
    build_acmg_prompt,
    build_amp_prompt,
    build_classification_prompt,
    get_system_prompt,
)

ACMG_CRITERIA_CODES = [
    "PVS1",
    "PS1", "PS2", "PS3", "PS4",
    "PM1", "PM2_Supporting", "PM3", "PM4", "PM5", "PM6",
    "PP1", "PP2", "PP3", "PP4",
    "BA1",
    "BS1", "BS2", "BS3", "BS4",
    "BP1", "BP2", "BP3", "BP4", "BP5", "BP7",
]

AMP_CRITERIA_CODES = [
    "TA", "TB", "TC", "TD",
    "DA", "DB", "DC", "DD",
    "PA", "PB", "PC", "PD",
    "BN1", "BN2", "BN3", "BN4",
]

SAMPLE_VARIANT = {"chrom": "7", "pos": 140453136, "ref": "A", "alt": "T"}


def test_build_acmg_prompt_interpolates_variant_data():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert json.dumps(SAMPLE_VARIANT, indent=2) in p
    assert "GRCh38" in p
    assert "ACMG/AMP 2015" in p


def test_build_acmg_prompt_contains_evidence_grounding_block():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "EVIDENCE GROUNDING" in p
    assert "Verified Clinical Context" in p


def test_build_acmg_prompt_enumerates_all_26_criteria():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    for code in ACMG_CRITERIA_CODES:
        assert code in p, f"ACMG criterion {code} missing from prompt"


def test_build_acmg_prompt_documents_pvs1_strength_tiers():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "Very Strong" in p
    assert "Strong" in p
    assert "Moderate" in p
    assert "Supporting" in p
    assert "default to Moderate" in p


def test_build_acmg_prompt_includes_scoring_rules():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "PVS1=8/4/2/1" in p
    assert "PS*=4" in p
    assert "PM*=2" in p


def test_build_acmg_prompt_includes_reference_cases():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "Classification Spectrum" in p
    assert "Do NOT default to Pathogenic" in p
    assert "VUS (leaning pathogenic)" in p


def test_build_acmg_prompt_mentions_fallback_tools():
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "web_search" in p
    assert "run_bash" in p
    assert "Open Targets" in p
    assert "Ensembl REST" in p


def test_build_acmg_prompt_appends_additional_context_when_provided():
    sentinel = "PROBAND-XYZ123 trio analysis, mother and father both unaffected"
    base = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    with_ctx = build_acmg_prompt(
        SAMPLE_VARIANT,
        assembly="GRCh38",
        additional_context=sentinel,
    )
    assert sentinel in with_ctx
    assert sentinel not in base
    assert "Verified Clinical Context (confirmed by primary clinician/agent)" in with_ctx


def test_build_amp_prompt_enumerates_all_16_criteria():
    p = build_amp_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    for code in AMP_CRITERIA_CODES:
        assert code in p, f"AMP criterion {code} missing from prompt"


def test_build_amp_prompt_includes_tier_framework():
    p = build_amp_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    for tier in ("Tier I-A", "Tier I-B", "Tier II-C", "Tier II-D", "Tier III", "Tier IV"):
        assert tier in p


def test_build_amp_prompt_includes_reference_cases():
    p = build_amp_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "Do NOT default to Tier I-A" in p
    assert "BRAF V600E" in p


def test_build_amp_prompt_mentions_fallback_tools():
    p = build_amp_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    assert "web_search" in p
    assert "run_bash" in p


def test_build_classification_prompt_dispatches_to_amp():
    p = build_classification_prompt(
        SAMPLE_VARIANT, classification_type="amp", assembly="GRCh38"
    )
    assert "AMP/ASCO/CAP 2017" in p
    assert "Tier I-A" in p
    assert "ACMG/AMP 2015" not in p


def test_build_classification_prompt_dispatches_to_acmg():
    p = build_classification_prompt(
        SAMPLE_VARIANT, classification_type="acmg", assembly="GRCh38"
    )
    assert "ACMG/AMP 2015" in p
    assert "Tier I-A" not in p


def test_build_classification_prompt_unknown_type_falls_back_to_acmg():
    p = build_classification_prompt(
        SAMPLE_VARIANT, classification_type="bogus", assembly="GRCh38"
    )
    assert "ACMG/AMP 2015" in p


@pytest.mark.parametrize("kind,expected", [
    ("acmg", "clinical genetics expert"),
    ("amp", "oncology expert"),
])
def test_get_system_prompt_returns_type_specific_role(kind, expected):
    assert expected in get_system_prompt(kind)


def test_get_system_prompt_mentions_time_budget():
    for kind in ("acmg", "amp"):
        assert "120-second" in get_system_prompt(kind)


def test_get_system_prompt_uses_registered_tool_names():
    """Guard: prompts must name tools by their registered identifiers so the
    sub-agent doesn't silently lose access by calling a non-existent name."""
    assert "annotate_variant" in get_system_prompt("acmg")
    assert "search_clinical_trials" in get_system_prompt("amp")


def test_build_acmg_prompt_lists_full_combining_rules():
    """Guard against regressing the Richards 2015 Table 5 fix.

    A prior version of the prompt summarized the ruleset in one line and omitted
    several Path / LP sub-rules, letting the sub-agent over-call Pathogenic for
    1 S + 1 M + 2 P (which should map to "1 S + 1–2 M" → LP).
    """
    p = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    for substring in (
        "1 S + 1–2 M",   # the LP rule the BRAF V600E run should have hit
        "1 M + ≥4 P",
        "≥2 S",
        "Strengths FIXED",
        "VCEP",
    ):
        assert substring in p, f"combining-rules guard substring missing: {substring!r}"


def test_both_prompts_enforce_strict_json_output():
    acmg = build_acmg_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    amp = build_amp_prompt(SAMPLE_VARIANT, assembly="GRCh38")
    for p in (acmg, amp):
        assert "OUTPUT FORMAT (STRICT)" in p
        assert "single JSON object" in p
