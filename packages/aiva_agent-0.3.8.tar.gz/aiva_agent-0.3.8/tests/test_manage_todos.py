import asyncio
import json

from agents.tool_context import ToolContext

from aiva_agent.tools.manage_todos import (
    Todo,
    TodoList,
    TodoStatus,
    TodoWorker,
    _handle_clear,
    _handle_complete,
    _handle_create,
    _handle_create_multiple,
    _handle_delete,
    _handle_list,
    _handle_update,
    build_manage_todos_tool,
)


def _invoke_through_closure(tool, **kwargs) -> str:
    """Drive the FunctionTool's agent-facing entry so the worker captured by
    build_manage_todos_tool's closure is the one being exercised."""
    kwargs.setdefault("summary", "test call")
    args_json = json.dumps(kwargs)
    ctx: ToolContext = ToolContext(
        context=None,
        tool_name=tool.name,
        tool_call_id="test-call-id",
        tool_arguments=args_json,
    )

    async def _go() -> str:
        return await tool.on_invoke_tool(ctx, args_json)

    return asyncio.run(_go())


# -- Dataclass / handler unit tests ----------------------------------------


def test_todo_default_status_is_pending():
    todo = Todo(description="x")
    assert todo.status == TodoStatus.PENDING
    assert todo.completed_at is None
    assert todo.updated_at is None


def test_todo_to_dict_serializes_status_value_and_iso_datetimes():
    todo = Todo(description="x")
    d = todo.to_dict()
    assert d["status"] == "pending"
    # ISO 8601 round-trips through fromisoformat
    from datetime import datetime

    assert datetime.fromisoformat(d["created_at"]) == todo.created_at
    assert d["updated_at"] is None
    assert d["completed_at"] is None


def test_todolist_add_and_get():
    tl = TodoList()
    todo = tl.add("first")
    assert tl.get(todo.id) is todo
    assert tl.get("nonexistent") is None


def test_todolist_remove_returns_true_on_hit_false_on_miss():
    tl = TodoList()
    todo = tl.add("first")
    assert tl.remove(todo.id) is True
    assert tl.remove(todo.id) is False  # already gone
    assert tl.todos == []


def test_handle_create_requires_description():
    tl = TodoList()
    out = _handle_create(tl, "")
    assert out["success"] is False
    assert "description" in out["error"].lower()


def test_handle_create_returns_todo_payload():
    tl = TodoList()
    out = _handle_create(tl, "annotate BRAF V600E")
    assert out["success"] is True
    assert out["todo"]["description"] == "annotate BRAF V600E"
    assert out["todo"]["status"] == "pending"
    assert tl.todos[0].id == out["todo"]["id"]


def test_handle_create_multiple_rejects_empty_list():
    tl = TodoList()
    assert _handle_create_multiple(tl, [])["success"] is False
    assert _handle_create_multiple(tl, None)["success"] is False


def test_handle_create_multiple_creates_each():
    tl = TodoList()
    out = _handle_create_multiple(tl, ["a", "b", "c"])
    assert out["success"] is True
    assert [t["description"] for t in out["todos"]] == ["a", "b", "c"]
    assert len(tl.todos) == 3


def test_handle_list_no_filter_returns_all():
    tl = TodoList()
    tl.add("a")
    tl.add("b")
    out = _handle_list(tl, "")
    assert out["success"] is True
    assert len(out["todos"]) == 2


def test_handle_list_active_filter_excludes_completed():
    tl = TodoList()
    a = tl.add("a")
    tl.add("b")
    a.mark_completed()
    out = _handle_list(tl, "active")
    descs = [t["description"] for t in out["todos"]]
    assert descs == ["b"]


def test_handle_list_active_filter_also_excludes_cancelled():
    tl = TodoList()
    a = tl.add("a")
    b = tl.add("b")
    c = tl.add("c")
    a.status = TodoStatus.CANCELLED
    b.mark_completed()
    out = _handle_list(tl, "active")
    assert [t["description"] for t in out["todos"]] == ["c"]


def test_handle_list_completed_filter():
    tl = TodoList()
    a = tl.add("a")
    tl.add("b")
    a.mark_completed()
    out = _handle_list(tl, "completed")
    assert [t["description"] for t in out["todos"]] == ["a"]


def test_handle_list_unknown_filter_returns_error():
    tl = TodoList()
    out = _handle_list(tl, "bogus")
    assert out["success"] is False
    assert "bogus" in out["error"]


def test_handle_update_requires_todo_id():
    tl = TodoList()
    out = _handle_update(tl, "", "new desc", "")
    assert out["success"] is False


def test_handle_update_unknown_id_returns_error():
    tl = TodoList()
    out = _handle_update(tl, "no-such-id", "x", "")
    assert out["success"] is False
    assert "not found" in out["error"]


def test_handle_update_changes_description_and_sets_updated_at():
    tl = TodoList()
    todo = tl.add("orig")
    assert todo.updated_at is None
    out = _handle_update(tl, todo.id, "renamed", "")
    assert out["success"] is True
    assert todo.description == "renamed"
    assert todo.updated_at is not None


def test_handle_update_status_pending_to_in_progress():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_update(tl, todo.id, "", "in_progress")
    assert out["success"] is True
    assert todo.status == TodoStatus.IN_PROGRESS
    assert todo.completed_at is None


def test_handle_update_status_to_completed_sets_completed_at():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_update(tl, todo.id, "", "completed")
    assert out["success"] is True
    assert todo.status == TodoStatus.COMPLETED
    assert todo.completed_at is not None


def test_handle_update_completed_to_in_progress_clears_completed_at():
    tl = TodoList()
    todo = tl.add("x")
    _handle_update(tl, todo.id, "", "completed")
    assert todo.completed_at is not None  # set by completion

    out = _handle_update(tl, todo.id, "", "in_progress")
    assert out["success"] is True
    assert todo.status == TodoStatus.IN_PROGRESS
    # Reversing the completion must clear completed_at, otherwise the serialized
    # dict will claim the work is done even though the agent reverted it.
    assert todo.completed_at is None
    assert out["todo"]["completed_at"] is None


def test_handle_update_completed_to_cancelled_clears_completed_at():
    tl = TodoList()
    todo = tl.add("x")
    _handle_update(tl, todo.id, "", "completed")
    out = _handle_update(tl, todo.id, "", "cancelled")
    assert out["success"] is True
    assert todo.status == TodoStatus.CANCELLED
    assert todo.completed_at is None


def test_handle_update_rejects_unknown_status():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_update(tl, todo.id, "", "weird")
    assert out["success"] is False
    assert "weird" in out["error"]


def test_handle_update_requires_at_least_one_field():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_update(tl, todo.id, "", "")
    assert out["success"] is False


def test_handle_complete_marks_done():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_complete(tl, todo.id)
    assert out["success"] is True
    assert todo.status == TodoStatus.COMPLETED
    assert todo.completed_at is not None


def test_handle_complete_requires_id_and_existence():
    tl = TodoList()
    assert _handle_complete(tl, "")["success"] is False
    assert _handle_complete(tl, "missing")["success"] is False


def test_handle_delete_removes_todo():
    tl = TodoList()
    todo = tl.add("x")
    out = _handle_delete(tl, todo.id)
    assert out["success"] is True
    assert tl.todos == []


def test_handle_delete_requires_id_and_existence():
    tl = TodoList()
    assert _handle_delete(tl, "")["success"] is False
    assert _handle_delete(tl, "missing")["success"] is False


def test_handle_clear_removes_only_completed():
    tl = TodoList()
    a = tl.add("a")
    b = tl.add("b")
    a.mark_completed()
    out = _handle_clear(tl)
    assert out["success"] is True
    assert out["cleared_count"] == 1
    assert [t.id for t in tl.todos] == [b.id]


def test_remaining_count_excludes_cancelled():
    tl = TodoList()
    a = tl.add("a")
    tl.add("b")
    a.status = TodoStatus.CANCELLED
    # Only "b" is non-terminal — "remaining" should be 1, not 2.
    out = _handle_complete(tl, tl.todos[1].id)
    assert "0 remaining" in out["message"]


def test_worker_dispatch_unknown_action_lists_allowed():
    worker = TodoWorker()
    out = worker.dispatch("nope")
    assert out["success"] is False
    assert "create" in out["allowed"]
    assert "clear" in out["allowed"]


# -- Closure / FunctionTool surface tests ----------------------------------


def test_build_manage_todos_tool_closure_persists_state_within_run():
    tool, cleanup = build_manage_todos_tool()
    try:
        created = json.loads(_invoke_through_closure(tool, action="create", description="step 1"))
        assert created["success"] is True
        todo_id = created["todo"]["id"]

        listed = json.loads(_invoke_through_closure(tool, action="list"))
        assert listed["success"] is True
        assert [t["id"] for t in listed["todos"]] == [todo_id]

        completed = json.loads(_invoke_through_closure(tool, action="complete", todo_id=todo_id))
        assert completed["success"] is True
        assert completed["todo"]["status"] == "completed"
    finally:
        cleanup()


def test_build_manage_todos_tool_create_multiple_through_closure():
    tool, cleanup = build_manage_todos_tool()
    try:
        out = json.loads(
            _invoke_through_closure(
                tool, action="create_multiple", descriptions=["a", "b", "c"]
            )
        )
        assert out["success"] is True
        assert len(out["todos"]) == 3
    finally:
        cleanup()


def test_build_manage_todos_tool_two_instances_have_isolated_state():
    tool_a, cleanup_a = build_manage_todos_tool()
    tool_b, cleanup_b = build_manage_todos_tool()
    try:
        _invoke_through_closure(tool_a, action="create", description="only-in-a")
        listed_b = json.loads(_invoke_through_closure(tool_b, action="list"))
        assert listed_b["success"] is True
        assert listed_b["todos"] == []
    finally:
        cleanup_a()
        cleanup_b()


def test_build_manage_todos_tool_name_is_manage_todos():
    tool, cleanup = build_manage_todos_tool()
    try:
        assert tool.name == "manage_todos"
    finally:
        cleanup()
