"""Tests for the tidy/long companion view (`<alias>_long`).

The wide view stays the right shape for trio / per-variant queries; the
long view exists for `GROUP BY SAMPLE_ID` aggregations and per-sample
stats. These tests verify the view is registered alongside the wide one
and that pipe-delimited annotation fields are reachable via the same
macros documented for the wide view (typed `VEP_*` columns are
intentionally omitted from the schema summary; see
test_long_view_summary_omits_vep_block).
"""

from pathlib import Path

import pytest

from aiva_agent.tools.vcf import _open_connection, view_aliases

VEP_FIXTURE = Path("data/8XNjn0QrKY82y0rm.vcf.gz")
GATK_FIXTURE = Path("data/test.vcf.gz")


# ---------------------------------------------------------------------------
# view_aliases: pure helper
# ---------------------------------------------------------------------------


def test_view_aliases_emits_wide_then_long_per_spec():
    specs = [("proband", Path("p.vcf.gz")), ("father", Path("f.vcf.gz"))]
    out = view_aliases(specs)
    assert out == [
        ("proband", Path("p.vcf.gz")),
        ("proband_long", Path("p.vcf.gz")),
        ("father", Path("f.vcf.gz")),
        ("father_long", Path("f.vcf.gz")),
    ]


def test_view_aliases_empty_input():
    assert view_aliases([]) == []


# ---------------------------------------------------------------------------
# Long view shape on the multisample fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def gatk_con():
    if not GATK_FIXTURE.exists():
        pytest.skip(f"missing fixture: {GATK_FIXTURE}")
    con = _open_connection([("vcf", GATK_FIXTURE)])
    try:
        yield con
    finally:
        con.close()


def test_long_view_is_registered(gatk_con):
    cols = gatk_con.execute("DESCRIBE vcf_long").fetchall()
    names = [c[0] for c in cols]
    assert "SAMPLE_ID" in names
    # bare FORMAT_<FIELD> with no sample suffix
    assert "FORMAT_GT" in names
    assert "FORMAT_AD" in names


def test_long_view_returns_rows_through_registered_alias(gatk_con):
    # Exercises the registered `vcf_long` view (not raw read_bcf) so a
    # typo in _open_connection's tidy_format kwarg fails this test.
    rows = gatk_con.execute(
        "SELECT SAMPLE_ID, FORMAT_GT FROM vcf_long "
        "WHERE CHROM='chr1' AND POS BETWEEN 1 AND 200000 LIMIT 10"
    ).fetchall()
    assert len(rows) > 0
    sample_ids = {r[0] for r in rows}
    assert all(sid is not None and sid != "" for sid in sample_ids)
    # And confirm the wide view still resolves through its alias too.
    wide_rows = gatk_con.execute(
        "SELECT CHROM, POS FROM vcf "
        "WHERE CHROM='chr1' AND POS BETWEEN 1 AND 200000 LIMIT 5"
    ).fetchall()
    assert len(wide_rows) > 0


def test_long_row_count_is_wide_times_samples_on_region(gatk_con):
    # Exercise the n_long == n_wide × n_samples invariant on a small region
    # rather than the whole file: a full long-table scan on a 52-sample
    # WGS file is 1.9M rows and not worth running in a unit test.
    region_sql = (
        "FROM read_bcf('data/test.vcf.gz', tidy_format:=true, region:='chr1:1-10000000')"
    )
    n_long_region = gatk_con.execute(f"SELECT count(*) {region_sql}").fetchone()[0]
    n_samples = gatk_con.execute(
        f"SELECT count(DISTINCT SAMPLE_ID) {region_sql}"
    ).fetchone()[0]
    n_wide_region = gatk_con.execute(
        "SELECT count(*) FROM read_bcf('data/test.vcf.gz', region:='chr1:1-10000000')"
    ).fetchone()[0]
    assert n_samples > 0
    assert n_long_region == n_wide_region * n_samples


def test_per_sample_aggregation_runs_on_long_view(gatk_con):
    # The canonical per-sample aggregation question — runs as a single
    # GROUP BY on the long view, with one row per sample. Use a region
    # filter via the table function so we don't full-scan in a unit test.
    rows = gatk_con.execute("""
        SELECT SAMPLE_ID, count(*) AS n
        FROM read_bcf('data/test.vcf.gz', tidy_format:=true, region:='chr1:1-10000000')
        WHERE list_contains(FILTER, 'PASS')
          AND regexp_matches(FORMAT_GT, '^[01][/|]1$')
        GROUP BY SAMPLE_ID
    """).fetchall()
    assert len(rows) > 0
    assert all(isinstance(r[1], int) and r[1] >= 0 for r in rows)


def test_wide_view_unchanged_by_long_companion(gatk_con):
    # The wide view should still expose per-sample columns alongside the
    # long companion — long doesn't replace wide, it joins it.
    cols = gatk_con.execute("DESCRIBE vcf").fetchall()
    names = [c[0] for c in cols]
    assert "SAMPLE_ID" not in names
    # at least one FORMAT_<FIELD>_<SAMPLE> is present
    assert any(
        n.startswith("FORMAT_GT_CAGI7_RGP_") for n in names
    ), "expected per-sample FORMAT_GT_<SAMPLE> columns on wide view"


# ---------------------------------------------------------------------------
# VEP_* surface on long view (VEP-annotated fixture)
# ---------------------------------------------------------------------------


@pytest.fixture
def vep_con():
    if not VEP_FIXTURE.exists():
        pytest.skip(f"missing fixture: {VEP_FIXTURE}")
    con = _open_connection([("vcf", VEP_FIXTURE)])
    try:
        yield con
    finally:
        con.close()


def test_long_view_summary_omits_vep_block(vep_con):
    # The duckhts tidy_format output includes typed VEP_* columns that
    # duplicate INFO_CSQ. The schema renderer should not surface them —
    # eager VEP_* materialization is ~5x slower than the macro path on
    # INFO_CSQ, and exposing both forces the agent to track two naming
    # conventions for the same data.
    from aiva_agent.tools.vcf import _summarize_view
    summary = _summarize_view(vep_con, "vcf_long", VEP_FIXTURE)
    assert "VEP_" not in summary
    assert "INFO_CSQ" in summary
    assert "vcf_csq_" in summary


def test_csq_macros_callable_with_long_view_blob(vep_con):
    # Macros take a blob argument; INFO_CSQ exists in BOTH views, so the
    # macros should be callable with the long view's INFO_CSQ too.
    rows = vep_con.execute("""
        SELECT vcf_csq_consequence(INFO_CSQ) FROM vcf_long
        WHERE INFO_CSQ IS NOT NULL LIMIT 3
    """).fetchall()
    for (consequences,) in rows:
        assert isinstance(consequences, list)
        assert len(consequences) >= 1


# ---------------------------------------------------------------------------
# Multi-VCF: each spec produces both views, namespaced
# ---------------------------------------------------------------------------


def test_multi_vcf_dual_registration():
    if not VEP_FIXTURE.exists():
        pytest.skip(f"missing fixture: {VEP_FIXTURE}")
    con = _open_connection(
        [("proband", VEP_FIXTURE), ("father", VEP_FIXTURE)]
    )
    try:
        for view in ("proband", "proband_long", "father", "father_long"):
            cols = con.execute(f"DESCRIBE {view}").fetchall()
            assert cols, f"view {view!r} should be registered"
        # Macros remain attached to the base alias only.
        rows = con.execute(
            "SELECT function_name FROM duckdb_functions() "
            "WHERE function_name IN ("
            "'proband_csq_clin_sig','father_csq_clin_sig')"
        ).fetchall()
        assert {r[0] for r in rows} == {
            "proband_csq_clin_sig",
            "father_csq_clin_sig",
        }
    finally:
        con.close()
