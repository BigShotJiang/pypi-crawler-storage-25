"""Dynamic prompt builders for the variant-classifier sub-agent.

Mirrors genomiq's ``tools_core/classification_prompts.py`` builder shape: each
classification call produces a focused, type-specific user-turn prompt with the
variant data interpolated inline, plus a short type-specific system message that
sets the role and time budget. The full ACMG **or** AMP framework is carried per
call — never both — keeping the sub-agent narrowly scoped to the criteria
actually being evaluated.

Tool-availability sentences mention only what aiva-agent actually wires into the
classifier (see ``agent.py``: ``annotate_variant``, ``search_biomedical_literature``,
``search_clinical_trials``). genomiq references to ``query_knowledge_graph``,
``web_search``, and ``firecrawl`` are intentionally dropped here.
"""

import json
from typing import Any, Dict, Optional


def build_acmg_prompt(
    variant_data: Dict[str, Any],
    assembly: str,
    description: Optional[str] = None,
    phenotype_terms: Optional[str] = None,
    additional_context: Optional[str] = None,
) -> str:
    """Build the ACMG/AMP 2015 classification prompt (germline)."""
    prompt = f"""Classify this genomic variant using ACMG/AMP 2015 guidelines with SYSTEMATIC evaluation of ALL criteria.

**Clinical Context:**
- Description: {description or 'Not provided'}
- Phenotype: {phenotype_terms or 'Not provided'}
- Genome Assembly: {assembly}

**Variant Data:**
{json.dumps(variant_data, indent=2)}

**Key Interpretation Rules:**
- **DO NOT defer to ClinVar's existing classification** — your classification must be based on YOUR evaluation of all criteria, not ClinVar's conclusion.
- Missing gnomAD = RARE variant (supports PM2_Supporting).
- **In-silico prediction priority**: CADD and DITTO are primary. CADD≥15 or DITTO≥0.5 strongly supports deleterious effect. Other scores (SIFT, PolyPhen, MutationTaster, REVEL) are secondary/confirmatory only.
- Avoid plain "VUS" — use "VUS (leaning pathogenic)" or "VUS (leaning benign)" to provide actionable guidance.

**EVIDENCE GROUNDING (CRITICAL):** Every criterion marked `met` must cite a concrete source: (a) the **Verified Clinical Context** below, or (b) a tool call made in this session (`annotate_variant`, `search_biomedical_literature`, `search_clinical_trials`, `web_search`, `run_bash`). Do **NOT** rely on training knowledge about specific variants/genes/disease associations. If a tool returns nothing or errors out, mark the dependent criterion as `not_met` — do not fall back on memorized knowledge. Name the source in each met criterion's `evidence_summary` entry (e.g., "gnomAD AF=0.31 per annotate_variant", "de novo per Verified Clinical Context", "PMID:12345 per literature search", "OMIM:123456 per run_bash curl").

**Fallback tools (use only when the primary tools fall short):**
- `web_search` (`action="search"` / `action="scrape"`): use for FDA labels, NCCN/ASCO/CAP guideline pages, OMIM gene pages — material that PubMed doesn't index. NOT for variant-specific data (gnomAD/CADD/ClinVar come from `annotate_variant`).
- `run_bash`: use to query biomedical APIs the structured tools don't cover, or as an alternative upstream when `annotate_variant`/`search_biomedical_literature` keeps failing. Useful APIs: Open Targets (drug ↔ target ↔ disease), Ensembl REST (gene/transcript/sequence), UniProt (protein function/domains), DisGeNET (disease-gene), HPO (phenotype-gene). Pattern: `curl -s '<url>' | jq '<filter>'`. Hit one or two endpoints; do NOT iterate. NEVER dump environment variables or call `env`/`printenv`.

Use these sparingly — every extra tool call eats your 120-second budget.

**General Rule:** Each criterion is either fully met or not. If uncertain whether a threshold is met, it is NOT met.

**ACMG/AMP 2015 Criteria — evaluate ALL of these:**

PATHOGENIC:
- **PVS1** (Very Strong → Supporting per ClinGen flowchart): Null variant in gene with established LOF mechanism.
    - *Very Strong*: Nonsense/frameshift with NMD predicted.
    - *Strong*: Canonical splice with confirmed exon skipping, or last-exon truncation with established functional impact.
    - *Moderate*: Only one transcript affected, or limited LOF evidence.
    - *Supporting*: Low regional constraint or alternative splicing rescue.
    - If uncertain, default to Moderate.
    - LOF-mechanism gate: confirm via `annotate_variant action="gnomad_constraint" gene="<gene>"`. `pLI` ≥0.9 or `oe_lof_upper` <0.35 supports LOF mechanism; low pLI in a non-cancer gene weakens PVS1 toward Moderate. (Cancer-predisposition genes are an exception — see PP2 caveat.)
- **PS1** (Strong): Same amino acid change as a previously established pathogenic variant.
- **PS2** (Strong): Confirmed de novo (maternity AND paternity confirmed) with disease and no family history. If de novo is assumed/uncertain, use PM6 instead; if no de novo data provided, neither applies.
- **PS3** (Strong): Well-established functional studies show damaging effect.
- **PS4** (Strong): Prevalence in affecteds vs controls OR>5, CI excludes 1.
- **PM1** (Moderate): In a mutational hot spot or critical functional domain AND no benign variation at that location (both required — domain annotation alone is insufficient).
- **PM2_Supporting** (Supporting, downgraded per ClinGen 2018): Absent from gnomAD/ExAC (or extremely low frequency if recessive).
- **PM3** (Moderate): For recessive disorders, in trans with a pathogenic variant.
- **PM4** (Moderate): Protein length change from in-frame indel or stop-loss.
- **PM5** (Moderate): Novel missense at same position as established pathogenic missense (verify other variants are truly pathogenic in ClinVar/lit, not just reported).
- **PM6** (Moderate): Assumed de novo without confirmed maternity AND paternity.
- **PP1** (Supporting): Co-segregation with disease in multiple affected family members.
- **PP2** (Supporting): Missense in a gene with quantitative constraint metrics. Look up via `annotate_variant action="gnomad_constraint" gene="<gene>"`. Apply if `mis_z` ≥3.09 OR `oe_mis_upper` <0.5 (per ClinGen). General gene-level constraint is insufficient. Caveat: pLI/LOEUF underestimates constraint for cancer-predisposition genes (BRCA1, TP53, etc.) — for established tumor suppressors, treat low pLI as inconclusive, not benign.
- **PP3** (Supporting): **Requires actual computational scores.** CADD≥15 or DITTO≥0.5 (primary); REVEL≥0.75, SIFT=deleterious, PolyPhen=damaging (secondary). Do NOT apply from domain location, conservation, or structural inference alone.
- **PP4** (Supporting): Phenotype highly specific (pathognomonic) for disease with single genetic etiology — not general symptoms.
- (PP5/BP6 removed per ClinGen 2018 — DO NOT apply.)

BENIGN:
- **BA1** (Stand-alone): gnomAD AF >5% in any population.
- **BS1** (Strong): AF greater than expected for the disorder (typically >1%).
- **BS2** (Strong): Observed in healthy adult with full penetrance expected at early age.
- **BS3** (Strong): Functional studies show no damaging effect.
- **BS4** (Strong): Lack of segregation in affected family members.
- **BP1** (Supporting): Missense in a gene where only truncating variants cause disease.
- **BP2** (Supporting): In trans with pathogenic (dominant) or in cis with pathogenic.
- **BP3** (Supporting): In-frame indel in repetitive region without known function.
- **BP4** (Supporting): **Requires actual computational scores.** CADD<15 and DITTO<0.5 (primary); SIFT=tolerated, PolyPhen=benign (secondary). Same restriction as PP3.
- **BP5** (Supporting): Found in a case with alternate molecular basis for disease.
- **BP7** (Supporting): Synonymous with no predicted splice impact.

**Instructions:**
1. Check if annotations (gnomAD, CADD, ClinVar, consequence) are already in the Variant Data above.
2. If missing, call **annotate_variant ONCE** for variant data: `action="vep"` (primary; consequences, gnomAD, SIFT/PolyPhen, domains); `action="myvariant"` with `include_commercial=true` (secondary; for CADD if VEP omits); `action="myvariant"` (fallback if VEP errors). Do NOT call multiple times — one call returns all data; only retry on error or rate-limit. Additionally, call `action="gnomad_constraint" gene="<gene>"` once per session if you are evaluating PP2 or gating PVS1 strength — it is gene-keyed and cached, so the same gene is free on repeat calls. (BS1 uses allele frequency from VEP/myvariant, not constraint, so don't trigger gnomad_constraint just for BS1.)
3. Gather evidence with **search_biomedical_literature**. Useful queries: `"{{gene}} {{phenotype}}"`, `"{{gene}} loss of function"` (PVS1), `"{{gene}} functional study"` (PS3), `"{{gene}} {{phenotype}} case series"` (PS4), `"{{gene}} family segregation"` (PP1). Missing gnomAD = RARE (supports PM2_Supporting).
4. Evaluate every criterion as `met` / `not_met` / `not_applicable` per the rules above.
5. ACMG 2015 combining rules (Richards Table 5). Shorthand: VS=PVS1, S=PS*, M=PM*, P=PP*. Walk top→bottom; first match wins.
   - **Pathogenic** if ANY: (a) 1 VS + (≥1 S | ≥2 M | 1 M + 1 P | ≥2 P); (b) ≥2 S; (c) 1 S + (≥3 M | 2 M + ≥2 P | 1 M + ≥4 P).
   - **Likely Pathogenic** if ANY (and not Pathogenic): 1 VS + 1 M; 1 S + 1–2 M; 1 S + ≥2 P; ≥3 M; 2 M + ≥2 P; 1 M + ≥4 P.
   - **Benign**: 1 BA1 OR ≥2 BS. **Likely Benign**: 1 BS + 1 BP OR ≥2 BP. Else: **VUS** (leaning pathogenic / leaning benign by weight).
   - **Strengths FIXED by code prefix.** PS*=S, PM*=M, PP*=P. Only PVS1 varies (flowchart above). Do NOT upgrade a PS to VS, PM to S, or PP to M unless citing a named ClinGen VCEP rule.
   - **Audit before classifying.** Count `{{VS, S, M, P}}` from your met list, walk the rules, pick the first match, reflect counts in `classification_rationale`.
6. **OUTPUT FORMAT (STRICT):** Respond with a single JSON object — `{{...}}` only, no ` ``` ` fences, no prose before/after, no markdown headings. All reasoning goes inside `classification_rationale`. Non-JSON output will fail downstream parsing.
{{
  "classification": "Pathogenic|Likely Pathogenic|VUS (leaning pathogenic)|VUS (leaning benign)|Likely Benign|Benign",
  "confidence": "high|medium|low",
  "acmg_score": 2,
  "criteria_met": ["PM2_Supporting", "PP3"],
  "evidence_summary": {{
    "PVS1": "N/A: missense, not null",
    "PS1":  "No ClinVar pathogenic at this residue",
    "PS2":  "No de novo data",
    "PS3":  "No functional studies found",
    "PS4":  "Single case report; insufficient for OR>5",
    "PM1":  "In domain but benign variation present at region",
    "PM2_Supporting": "Absent in gnomAD v4 (0/1.5M alleles) per annotate_variant — Supporting per ClinGen 2018",
    "PM3":  "N/A: disorder not recessive",
    "PM4":  "N/A: SNV, no length change",
    "PM5":  "No established pathogenic missense at same residue",
    "PM6":  "No de novo data",
    "PP1":  "No segregation data",
    "PP2":  "No constraint metrics (mis_z not elevated)",
    "PP3":  "CADD=28.5, REVEL=0.89 per annotate_variant — both exceed thresholds",
    "PP4":  "Phenotype not pathognomonic",
    "BA1":  "N/A: absent in gnomAD",
    "BS1":  "N/A: absent in gnomAD",
    "BS2":  "No healthy adult observation",
    "BS3":  "No functional studies found",
    "BS4":  "No segregation data",
    "BP1":  "N/A: gene tolerates missense",
    "BP2":  "No trans/cis pathogenic observation",
    "BP3":  "N/A: not in repetitive region",
    "BP4":  "N/A: scores support deleterious",
    "BP5":  "No alternate molecular basis",
    "BP7":  "N/A: missense, not synonymous"
  }},
  "classification_rationale": "2 Supporting (PM2_Supporting + PP3) does not meet Likely Pathogenic threshold. Population rarity and computational prediction alone are insufficient for pathogenic lean.",
  "sources": ["ClinVar:12215", "PubMed:12345678", "gnomAD v4.0"]
}}

**Output Rules:**
- `criteria_met`: Array of criterion codes that ARE satisfied (e.g., ["PM2_Supporting", "PP3", "PVS1"]).
- `evidence_summary`: Object with an entry for **every one of the 26 criteria** — none may be omitted. For criteria that ARE met, the entry is the supporting evidence. For criteria that are NOT met, the entry is a one-line reason (rejection reason or why the criterion does not apply to this variant type).
- `acmg_score`: Calculate based on met criteria (PVS1=8/4/2/1 per applied strength, PS*=4, PM*=2, PP*=1, BA1=-8, BS*=-4, BP*=-1). Exception: PM2_Supporting=1 (downgraded per ClinGen 2018).
- `sources`: Clean bibliography of distinct external references — database name + identifier only (e.g., `"ClinVar:18559"`, `"gnomAD v4"`, `"Ensembl VEP"`, `"PMID:40015453"`). One entry per source, even if you pulled multiple data fields from it (gnomAD exome and gnomAD genome are one source). Do NOT restate evidence values, scores, or thresholds — those belong in `evidence_summary`. Do NOT include the user-supplied Verified Clinical Context as a source.

**Classification Spectrum — Do NOT default to Pathogenic. Most real-world variants are VUS or Benign. Calibrate against these reference cases:**
- **Pathogenic**: Null variant in established LOF gene with NMD predicted → criteria_met=["PVS1"] (Very Strong alone) OR established pathogenic missense at same residue + functional evidence → criteria_met=["PS1","PS3","PM2_Supporting","PP3"]
- **Likely Pathogenic**: Rare missense in constrained gene with strong computational + segregation → criteria_met=["PM2_Supporting","PP1","PP3","PM5"]
- **VUS (leaning pathogenic)**: Rare missense with strong computational only → criteria_met=["PM2_Supporting","PP3"] (the example above)
- **VUS (leaning benign)**: Missense with no notable evidence either way → criteria_met=[] or just one weak supporting criterion
- **Likely Benign**: Missense in tolerant gene with benign computational predictions → criteria_met=["BP1","BP4"]
- **Benign**: Allele frequency >5% in gnomAD → criteria_met=["BA1"] (Stand-alone)

IMPORTANT: You MUST output an `evidence_summary` entry for ALL 26 criteria (PP5/BP6 removed per ClinGen 2018). `criteria_met` lists only met codes."""

    if additional_context:
        prompt += (
            f"\n\n**Verified Clinical Context (confirmed by primary clinician/agent):**\n"
            f"{additional_context}\n\n"
            f"Apply ACMG criteria based strictly on what is explicitly stated above. "
            f"Do not extrapolate beyond what is explicitly stated."
        )

    return prompt


def build_amp_prompt(
    variant_data: Dict[str, Any],
    assembly: str,
    description: Optional[str] = None,
    phenotype_terms: Optional[str] = None,
    additional_context: Optional[str] = None,
) -> str:
    """Build the AMP/ASCO/CAP 2017 classification prompt (somatic/cancer)."""
    prompt = f"""Classify this somatic variant using AMP/ASCO/CAP 2017 guidelines for clinical significance in cancer.

**Clinical Context:**
- Description: {description or 'Not provided'}
- Clinical Notes/Cancer Type: {phenotype_terms or 'Not provided'}
- Genome Assembly: {assembly}

**Variant Data:**
{json.dumps(variant_data, indent=2)}

**Key Interpretation Rules:**
- **DO NOT defer to ClinVar's existing classification** — your tier assignment must be based on YOUR evaluation of the evidence, not ClinVar's conclusion.
- **In-silico prediction priority**: CADD and DITTO are primary predictors for functional impact. CADD≥15 or DITTO≥0.5 suggests functional impact. Other scores (SIFT, PolyPhen, REVEL) are secondary.
- **Oncogenicity assessment**: For novel variants, prioritize OncoKB, CIViC, and COSMIC evidence over general population databases.
- Germline variants with high population frequency (>1% gnomAD) likely Tier IV unless proven somatic driver.

**EVIDENCE GROUNDING (CRITICAL):** Every criterion marked `met` must cite a concrete source: (a) the **Verified Clinical Context** below, or (b) a tool call made in this session (`annotate_variant`, `search_biomedical_literature`, `search_clinical_trials`, `web_search`, `run_bash`). Do **NOT** rely on training knowledge about specific variants/drugs/tumor-type associations — even if you "know" BRAF V600E is approved for melanoma, verify with a tool (OncoKB via annotate_variant civic, FDA label via `web_search`, or a literature search citing NCCN) before assigning Tier I-A. If a tool returns nothing or errors out, mark the criterion as `not_met` and shift toward a lower tier — do not fall back on memorized knowledge. Name the source in each met criterion's `evidence_summary` entry (e.g., "OncoKB Level 1 per annotate_variant civic", "PMID:12345 per literature search", "NCT trial per search_clinical_trials", "FDA label per web_search").

**Fallback tools (use only when the primary tools fall short):**
- `web_search` (`action="search"` / `action="scrape"`): use for FDA labels, NCCN/ASCO/CAP guideline pages, drug package inserts — material that PubMed doesn't index. NOT for variant-specific data (gnomAD/CADD/ClinVar come from `annotate_variant`).
- `run_bash`: use to query biomedical APIs the structured tools don't cover, or as an alternative upstream when primary tools keep failing. Useful APIs: Open Targets (drug ↔ target ↔ disease), Ensembl REST (gene/transcript/sequence), UniProt (protein function/domains), DisGeNET (disease-gene), HPO (phenotype-gene). Pattern: `curl -s '<url>' | jq '<filter>'`. Hit one or two endpoints; do NOT iterate. NEVER dump environment variables or call `env`/`printenv`.

Use these sparingly — every extra tool call eats your 120-second budget.

**Tier Framework:** **Tier I** = strong clinical significance (A: FDA-approved/NCCN/ASCO/CAP for this tumor; B: well-powered studies with expert consensus). **Tier II** = potential significance (C: FDA-approved for different tumor or trial-eligible; D: preclinical/case reports/biological rationale). **Tier III** = unknown significance, insufficient evidence. **Tier IV** = benign/likely benign.

**AMP Criteria — evaluate ALL of these:**
- **TA / TB / TC / TD**: Therapeutic evidence (A=FDA/guidelines for this tumor; B=consensus; C=approved in different tumor or trial-eligible; D=preclinical only).
- **DA / DB / DC / DD**: Diagnostic evidence (same A→D evidence ladder).
- **PA / PB / PC / PD**: Prognostic evidence (same A→D evidence ladder).
- **BN1**: gnomAD AF >1%.
- **BN2** (Requires actual computational scores): CADD<15 and DITTO<0.5, SIFT=tolerated, PolyPhen=benign. Do NOT apply from domain/structural inference alone.
- **BN3**: Known germline polymorphism.
- **BN4**: Synonymous with no predicted splice impact.

**General Rule:** Each criterion is fully met or not. If evidence is insufficient, mark `not_applicable`.

**Instructions:**
1. Check if annotations are already in Variant Data above.
2. If missing, call **annotate_variant ONCE**: `action="vep"` (primary; consequences, gnomAD, SIFT/PolyPhen, domains); `"myvariant"` with `include_commercial=true` (secondary; CADD); `"myvariant"` (fallback); `"civic"` (cancer drug response — requires gene + variant_name). Do NOT call annotate_variant multiple times.
3. Gather evidence with **search_biomedical_literature**. Useful queries: `"{{gene}} {{mutation}} {{cancer_type}} targeted therapy"` (TA/TB), `"{{gene}} resistance {{drug}}"` (drug resistance), `"{{gene}} {{cancer_type}} prognosis"` (PA/PB), `"{{gene}} {{cancer_type}} diagnosis"` (DA/DB), `"{{gene}} {{variant_hgvs}} oncogenic"` (variant-specific), `"{{gene}} oncogene tumor suppressor"` (mechanism). Use **search_clinical_trials** for recruiting trials (informs TA/TB/TC). Missing gnomAD = RARE.
4. Evaluate every criterion as `met` / `not_met` / `not_applicable`. Assign tier based on highest evidence level found.

**OUTPUT FORMAT (STRICT):** Respond with a single JSON object — `{{...}}` only, no ` ``` ` fences, no prose before/after, no markdown headings. All reasoning goes inside the `*_summary` fields. Non-JSON output will fail downstream parsing.
{{
  "classification": "Tier I-A|Tier I-B|Tier II-C|Tier II-D|Tier III|Tier IV",
  "confidence": "high|medium|low",
  "criteria_met": ["TA", "PB"],
  "evidence_summary": {{
    "TA": "FDA-approved drug X for this tumor per literature search (NCCN/FDA label cited in PMID:xxxxx)",
    "TB": "No expert-consensus therapeutic evidence",
    "TC": "No approved therapy in different tumor type",
    "TD": "No preclinical therapeutic evidence",
    "DA": "Not in standard tumor classification",
    "DB": "No society consensus on diagnostic use",
    "DC": "No diagnostic evidence in other tumors",
    "DD": "No preclinical diagnostic evidence",
    "PA": "No FDA/guideline prognostic evidence",
    "PB": "PMID:xxxxx — cohort study shows worse OS in mutation-positive cases",
    "PC": "No prognostic evidence in other tumors",
    "PD": "No preclinical prognostic evidence",
    "BN1": "N/A: AF <1% in gnomAD",
    "BN2": "N/A: scores support functional impact",
    "BN3": "Not a known germline polymorphism",
    "BN4": "N/A: not synonymous"
  }},
  "therapeutic_summary": "Overall description of therapeutic implications (drugs, trials, resistance)...",
  "diagnostic_summary": "Overall description of diagnostic implications (tumor type, subtyping)...",
  "prognostic_summary": "Overall description of prognostic implications (survival, outcome)...",
  "sources": ["OncoKB", "ClinVar:12345", "PubMed:12345678", "NCCN Guidelines"]
}}

**Output Rules:**
- `criteria_met`: Array of criterion codes that ARE satisfied.
- `evidence_summary`: Object with an entry for **every one of the 16 AMP criteria** (TA/TB/TC/TD, DA/DB/DC/DD, PA/PB/PC/PD, BN1/BN2/BN3/BN4) — none may be omitted. For criteria that ARE met, the entry is the supporting evidence. For criteria that are NOT met, the entry is a one-line reason.
- `sources`: Clean bibliography of distinct external references — database name + identifier only (e.g., `"OncoKB"`, `"CIViC:1234"`, `"COSMIC:V600E"`, `"ClinVar:12345"`, `"PMID:40015453"`, `"NCCN 2024"`, `"FDA label: vemurafenib"`). One entry per source, even if you pulled multiple data fields from it. Do NOT restate evidence values, drug names, or therapy details — those belong in `evidence_summary` and the tier-specific summaries. Do NOT include the user-supplied Verified Clinical Context as a source.

**Tier Spectrum — Do NOT default to Tier I-A. Most somatic variants are Tier III (unknown significance) unless they have clear FDA/guideline-level evidence in the matched tumor type. Calibrate against these reference cases:**
- **Tier I-A**: FDA-approved targeted therapy for THIS tumor type with this exact alteration (e.g., BRAF V600E in melanoma → vemurafenib) → criteria_met=["TA"]. Requires explicit FDA approval or NCCN/ASCO/CAP listing — *not* preclinical or off-label evidence.
- **Tier I-B**: Well-powered studies with expert consensus, but not yet FDA-approved → criteria_met=["TB"] or ["TB","PB"]
- **Tier II-C**: FDA-approved therapy in a DIFFERENT tumor type, or active clinical trial eligibility → criteria_met=["TC"]
- **Tier II-D**: Preclinical evidence, case reports, or biological rationale only → criteria_met=["TD"] or ["TD","PD"]
- **Tier III**: No applicable evidence found in any category → criteria_met=[] (most novel/rare variants land here)
- **Tier IV**: Common germline polymorphism or no functional impact → criteria_met=["BN1"] or ["BN1","BN3"]

IMPORTANT: You MUST output an `evidence_summary` entry for all 16 criteria; `criteria_met` lists only met codes. Focus on clinical actionability — use OncoKB, CIViC, and cancer-specific databases."""

    if additional_context:
        prompt += (
            f"\n\n**Verified Clinical Context (confirmed by primary clinician/agent):**\n"
            f"{additional_context}\n\n"
            f"Apply AMP criteria based on what is explicitly stated above. "
            f"Do not extrapolate beyond what is explicitly stated."
        )

    return prompt


def get_system_prompt(classification_type: str) -> str:
    """Short role + time-budget statement passed as the sub-Agent's instructions."""
    if classification_type == "amp":
        return (
            "You are an oncology expert specializing in somatic variant interpretation using "
            "AMP/ASCO/CAP guidelines. You have a strict 120-second time budget. Prioritize: "
            "1) annotate_variant (one call), 2) one or two targeted literature searches, "
            "3) search_clinical_trials only if relevant for therapy/eligibility. Do NOT make redundant "
            "tool calls. Return only valid JSON."
        )
    return (
        "You are a clinical genetics expert specializing in variant interpretation using "
        "ACMG/AMP guidelines. You have a strict 120-second time budget. Prioritize: "
        "1) annotate_variant (one call), 2) one or two targeted literature searches. "
        "Do NOT make redundant tool calls. Return only valid JSON."
    )


def build_classification_prompt(
    variant_data: Dict[str, Any],
    classification_type: str,
    assembly: str,
    description: Optional[str] = None,
    phenotype_terms: Optional[str] = None,
    additional_context: Optional[str] = None,
) -> str:
    """Dispatch to the ACMG or AMP builder based on ``classification_type``.

    Unknown types fall back to ACMG (the broader germline framework).
    """
    if classification_type == "amp":
        return build_amp_prompt(
            variant_data, assembly, description, phenotype_terms, additional_context
        )
    return build_acmg_prompt(
        variant_data, assembly, description, phenotype_terms, additional_context
    )
