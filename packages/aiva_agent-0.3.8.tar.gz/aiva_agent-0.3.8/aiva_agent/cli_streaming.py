"""Streaming helpers: decide whether to stream agent events to the user,
and build the event-handler that prints tool tags to stderr while writing
the final answer's text deltas to stdout. Imported by `cli.py` (CLI
streaming) and `notebook.py` (notebook streaming).
"""

import os
import sys
from pathlib import Path

_ENV_FALSY_VALUES = ("0", "false", "no", "off")
_ENV_TRUTHY_VALUES = ("1", "true", "yes", "on")
_TOOL_OUTPUT_MAX_CHARS = 2000


def _env_truthy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _ENV_TRUTHY_VALUES


def _resolve_stream(flag: bool, output_path: Path | None) -> bool:
    """Decide whether to stream agent events to the user.

    Resolution order: --output forces off (file gets the final answer only) >
    --stream flag (presence forces on) > AIVA_STREAM env (1/true/yes/on or
    0/false/no/off) > auto (on iff stdout is a TTY).
    """
    if output_path is not None:
        return False
    if flag:
        return True
    raw = os.environ.get("AIVA_STREAM", "").strip().lower()
    if raw in _ENV_TRUTHY_VALUES:
        return True
    if raw in _ENV_FALSY_VALUES:
        return False
    return sys.stdout.isatty()


def _make_stream_renderer():
    """Build an event handler that prints tool tags to stderr and streams the
    final answer's text deltas to stdout. Returns (handler, finalize) — call
    finalize() after stream_events() completes to flush a trailing newline if
    any text was streamed.

    Set AIVA_STREAM_TOOL_OUTPUT=1 to also dump each tool's output (truncated to
    AIVA_STREAM_TOOL_OUTPUT_MAX chars, default 2000). Useful for debugging;
    off by default since tool outputs can be very large JSON blobs.
    """
    from agents.stream_events import RawResponsesStreamEvent, RunItemStreamEvent
    from openai.types.responses import ResponseTextDeltaEvent

    from .tools._shared import extract_tool_summary, tool_call_arguments

    show_tool_output = _env_truthy("AIVA_STREAM_TOOL_OUTPUT")
    raw_max = os.environ.get("AIVA_STREAM_TOOL_OUTPUT_MAX", "").strip()
    try:
        # 0 (or negative) means unlimited.
        max_chars = int(raw_max) if raw_max else _TOOL_OUTPUT_MAX_CHARS
    except ValueError:
        max_chars = _TOOL_OUTPUT_MAX_CHARS

    state = {"streamed_any_text": False}

    def handler(event: object) -> None:
        if isinstance(event, RawResponsesStreamEvent):
            data = event.data
            if isinstance(data, ResponseTextDeltaEvent) and data.delta:
                sys.stdout.write(data.delta)
                sys.stdout.flush()
                state["streamed_any_text"] = True
            return
        if isinstance(event, RunItemStreamEvent):
            item = event.item
            item_type = getattr(item, "type", None)
            if item_type == "tool_call_item":
                tool_name = getattr(item, "tool_name", None) or "<tool>"
                summary = extract_tool_summary(tool_call_arguments(item))
                suffix = f" — {summary}" if summary else ""
                print(f"[tool] {tool_name}{suffix}…", file=sys.stderr, flush=True)
            elif item_type == "tool_call_output_item":
                print("[tool] done", file=sys.stderr, flush=True)
                if show_tool_output:
                    raw = getattr(item, "output", None)
                    text = raw if isinstance(raw, str) else repr(raw)
                    if not text:
                        return
                    if max_chars > 0 and len(text) > max_chars:
                        elided = len(text) - max_chars
                        text = f"{text[:max_chars]}…[+{elided} more chars]"
                    for line in text.splitlines() or [text]:
                        print(f"  {line}", file=sys.stderr, flush=True)
            # message_output_item is intentionally ignored: raw deltas already
            # printed the text. reasoning_item / handoff_* / mcp_* are not
            # surfaced today; add cases here if a use-case appears.

    def finalize() -> None:
        if state["streamed_any_text"]:
            sys.stdout.write("\n")
            sys.stdout.flush()

    return handler, finalize
