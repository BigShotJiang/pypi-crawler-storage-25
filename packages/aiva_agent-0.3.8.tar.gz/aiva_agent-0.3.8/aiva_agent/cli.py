import argparse
import asyncio
import os
import sys
import uuid
from pathlib import Path

from dotenv import load_dotenv

# Load .env from cwd (and walk up) before reading any LLM_* env vars. Existing
# shell-exported env values take precedence (override=False).
load_dotenv(override=False)

from .agent import ALL_TOOLS, DEFAULT_MODEL, run_once, run_once_streamed  # noqa: E402
from .cli_specs import (  # noqa: E402  (re-exported for notebook.py and tests)
    _has_bam_index,
    _parse_bam_specs,
    _parse_path_specs,
    _parse_vcf_specs,
)
from .cli_streaming import (  # noqa: E402  (re-exported for notebook.py)
    _env_truthy,
    _make_stream_renderer,
    _resolve_stream,
)

__all__ = [
    "_env_truthy",
    "_has_bam_index",
    "_make_stream_renderer",
    "_parse_bam_specs",
    "_parse_disabled",
    "_parse_path_specs",
    "_parse_vcf_specs",
    "_resolve_stream",
    "main",
]


def _parse_disabled(raw: str) -> list[str]:
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    unknown = [p for p in parts if p not in ALL_TOOLS]
    if unknown:
        raise argparse.ArgumentTypeError(
            f"Unknown tool(s): {unknown}. Choose from {list(ALL_TOOLS)}."
        )
    return parts


def _resolve_prompt(prompt: str | None, prompt_file: Path | None) -> str:
    """Read the prompt from --prompt, --prompt-file, or stdin.

    Precedence: --prompt-file > --prompt. If --prompt is `-`, read stdin.
    """
    if prompt_file is not None:
        if not prompt_file.exists():
            raise SystemExit(f"ERROR: prompt file not found: {prompt_file}")
        return prompt_file.read_text(encoding="utf-8").strip()
    if prompt is None:
        raise SystemExit("ERROR: provide --prompt or --prompt-file.")
    if prompt == "-":
        data = sys.stdin.read().strip()
        if not data:
            raise SystemExit("ERROR: --prompt - was given but stdin is empty.")
        return data
    return prompt


def _resolve_specs_from_env(
    cli_value: list[tuple[str, Path]] | None,
    env_var: str,
    parser_fn,
) -> tuple[list[tuple[str, Path]], bool]:
    """Resolve --vcf / --bam: CLI value wins; otherwise fall back to the env
    var. Returns (specs, from_env) so error messages can name the source.
    Exits the process on env-parse failure (mirrors the original inline
    behavior in main())."""
    if cli_value is not None:
        return list(cli_value), False
    env_raw = os.environ.get(env_var, "")
    if not env_raw:
        return [], False
    try:
        return parser_fn(env_raw), True
    except argparse.ArgumentTypeError as e:
        print(f"error: {env_var}: {e}", file=sys.stderr)
        raise SystemExit(2) from e


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aiva_agent",
        description="Ask natural-language questions about a VCF, gather variant annotations, search literature, find trials, or classify variants.",
    )
    parser.add_argument(
        "--disable",
        type=_parse_disabled,
        default=os.environ.get("AIVA_DISABLE", ""),
        help=(
            f"Comma-separated tools to disable. Choices: {list(ALL_TOOLS)}. "
            "Falls back to AIVA_DISABLE env var; the flag replaces (does not merge) "
            "the env value. Default: nothing disabled (all tools on)."
        ),
    )
    parser.add_argument(
        "--workdir",
        type=Path,
        default=None,
        help=(
            "Working directory for the bash tool. The agent runs all shell "
            "commands with cwd set to this folder. Falls back to AIVA_WORKDIR "
            "env, then to the current working directory."
        ),
    )
    parser.add_argument(
        "--vcf",
        type=_parse_vcf_specs,
        default=None,
        help=(
            "VCF spec(s). Single bare path: '--vcf sample.vcf.gz' (registers "
            "view `vcf`). Multiple aliased paths: "
            "'--vcf proband=p.vcf.gz,father=f.vcf.gz' (registers views "
            "`proband`, `father`). Falls back to AIVA_VCF env var; the flag "
            "replaces (does not merge) the env value. If neither is set, the "
            "vcf tool auto-disables itself."
        ),
    )
    parser.add_argument(
        "--bam",
        type=_parse_bam_specs,
        default=None,
        help=(
            "BAM/CRAM spec(s) the agent can query via the bash tool with "
            "`pysam`. Single bare path: '--bam sample.bam'. Multiple "
            "aliased paths: '--bam tumor=t.bam,normal=n.bam'. Falls back to "
            "AIVA_BAM env var; the flag replaces (does not merge) the env "
            "value. Region queries require a `.bai`/`.csi`/`.crai` index "
            "next to the BAM."
        ),
    )
    prompt_group = parser.add_mutually_exclusive_group(required=True)
    prompt_group.add_argument(
        "--prompt",
        type=str,
        help="The question to ask the agent. Use '-' to read from stdin.",
    )
    prompt_group.add_argument(
        "--prompt-file",
        type=Path,
        help="Path to a file containing the prompt (UTF-8). Trailing whitespace is stripped.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("LLM_MODEL", DEFAULT_MODEL),
        help=(
            "Model ID exactly as the provider expects "
            "(e.g. 'gpt-5.5', 'claude-opus-4-7', 'grok-2', 'meta-llama/Llama-3.1-70B-Instruct'). "
            "Falls back to LLM_MODEL env var, then to a built-in default."
        ),
    )
    parser.add_argument(
        "--base-url",
        default=None,
        help=(
            "OpenAI-compatible endpoint base URL (e.g. https://api.openai.com/v1, "
            "https://api.x.ai/v1, https://api.anthropic.com/v1). Falls back to LLM_BASE_URL env var."
        ),
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key for the chosen provider. Falls back to LLM_API_KEY env var. "
            "Prefer setting LLM_API_KEY in the environment to avoid shell-history leakage."
        ),
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Write the agent's answer to this file instead of stdout. Parent directories are created automatically.",
    )
    parser.add_argument(
        "--session-id",
        type=str,
        default=os.environ.get("AIVA_SESSION_ID", "").strip() or None,
        help=(
            "Conversation session ID. Reuse the same value across runs to "
            "continue a conversation; history is stored under "
            "<workdir>/.aiva/sessions.db. Falls back to AIVA_SESSION_ID env "
            "var. If unset, a fresh UUID is generated per run (effectively "
            "stateless)."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=_env_truthy("AIVA_FORCE"),
        help=(
            "Allow --output to overwrite an existing file. Falls back to "
            "AIVA_FORCE env (1/true/yes); the flag wins if set."
        ),
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        default=False,
        help=(
            "Stream tool-call tags to stderr and the final answer to stdout "
            "as tokens arrive. The flag forces streaming on. Otherwise, "
            "AIVA_STREAM env wins (1/true/yes/on or 0/false/no/off); if "
            "unset, streaming auto-enables when stdout is a TTY. --output "
            "always disables streaming (file gets the final answer only)."
        ),
    )
    return parser


def _check_vcf_specs(
    vcf_specs: list[tuple[str, Path]], from_env: bool, disabled: list[str]
) -> int:
    """Validate VCF spec paths exist and toggle the tool off if none provided.
    Returns a non-zero exit code if a hard error should abort the run."""
    if vcf_specs:
        missing = [(alias, path) for alias, path in vcf_specs if not path.exists()]
        if missing:
            origin = " (from AIVA_VCF)" if from_env else ""
            for _alias, path in missing:
                print(f"VCF not found: {path}{origin}", file=sys.stderr)
            return 2
        return 0
    print(
        "warning: vcf tool disabled (no --vcf flag or AIVA_VCF env). "
        "Pass --disable vcf to silence, or set AIVA_VCF in .env.",
        file=sys.stderr,
    )
    disabled.append("vcf")
    return 0


def _check_bam_specs(bam_specs: list[tuple[str, Path]], from_env: bool) -> int:
    """Validate BAM spec paths exist (hard error) and warn — but don't
    fail — when an index is missing (region queries will fail at runtime,
    full-file scans still work). No-op if no specs were provided."""
    if not bam_specs:
        return 0
    missing = [(alias, path) for alias, path in bam_specs if not path.exists()]
    if missing:
        origin = " (from AIVA_BAM)" if from_env else ""
        for _alias, path in missing:
            print(f"BAM not found: {path}{origin}", file=sys.stderr)
        return 2
    for _alias, path in bam_specs:
        if not _has_bam_index(path):
            origin = " (from AIVA_BAM)" if from_env else ""
            print(
                f"warning: no .bai/.csi/.crai index next to {path}{origin}; "
                f"region-bounded queries will fail. Create one with "
                f"`python -c \"import pysam; pysam.index('{path}')\"`.",
                file=sys.stderr,
            )
    return 0


def main() -> int:
    parser = _build_arg_parser()
    args = parser.parse_args()

    session_id = args.session_id or f"aiva-{uuid.uuid4().hex[:12]}"
    disabled = list(args.disable)

    vcf_specs, vcf_from_env = _resolve_specs_from_env(args.vcf, "AIVA_VCF", _parse_vcf_specs)
    bam_specs, bam_from_env = _resolve_specs_from_env(args.bam, "AIVA_BAM", _parse_bam_specs)

    if args.workdir is not None:
        workdir = args.workdir
    else:
        env_workdir = os.environ.get("AIVA_WORKDIR", "").strip()
        workdir = Path(env_workdir) if env_workdir else Path.cwd()

    if "bash" not in disabled:
        if not workdir.exists() or not workdir.is_dir():
            print(
                f"ERROR: workdir does not exist or is not a directory: {workdir}",
                file=sys.stderr,
            )
            return 2

    if "vcf" not in disabled:
        rc = _check_vcf_specs(vcf_specs, vcf_from_env, disabled)
        if rc:
            return rc

    rc = _check_bam_specs(bam_specs, bam_from_env)
    if rc:
        return rc

    prompt = _resolve_prompt(args.prompt, args.prompt_file)

    if args.output is not None and args.output.exists() and not args.force:
        print(
            f"ERROR: {args.output} already exists. Pass --force to overwrite.",
            file=sys.stderr,
        )
        return 2

    if not args.session_id:
        print(
            f"session: {session_id} (set AIVA_SESSION_ID to resume)",
            file=sys.stderr,
        )

    stream = _resolve_stream(args.stream, args.output)

    run_kwargs = dict(
        vcf_specs=vcf_specs if "vcf" not in disabled else None,
        bam_specs=bam_specs or None,
        disabled_tools=disabled,
        model=args.model,
        base_url=args.base_url,
        api_key=args.api_key,
        session_id=session_id,
        workdir=workdir,
        interface="cli",
    )

    if stream:
        handler, finalize = _make_stream_renderer()
        try:
            result = asyncio.run(
                run_once_streamed(prompt, on_event=handler, **run_kwargs)
            )
        finally:
            finalize()
    else:
        result = asyncio.run(run_once(prompt, **run_kwargs))

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
        print(f"Wrote {len(result)} chars to {args.output}", file=sys.stderr)
    elif not stream:
        print(result)
    # When streaming, the final answer was already written to stdout by the
    # delta handler; finalize() added the trailing newline.
    return 0


if __name__ == "__main__":
    sys.exit(main())
