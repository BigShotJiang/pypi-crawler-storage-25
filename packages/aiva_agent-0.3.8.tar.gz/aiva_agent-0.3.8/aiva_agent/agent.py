"""Agent runtime: builds an OpenAI Agents SDK Agent from --disable, runs it once.

Multi-provider works through any OpenAI-compatible endpoint:
- User passes --model, --base-url, --api-key (or sets LLM_BASE_URL / LLM_API_KEY)
- We construct AsyncOpenAI(base_url=, api_key=) and OpenAIChatCompletionsModel(model=, ...)
- Pass that as model= to Agent(...)

No PROVIDERS dict, no provider-prefix parsing, no LiteLLM. The user already knows
their provider's URL and has their key; we don't need to enumerate.
"""

import asyncio
import os
from pathlib import Path
from typing import Awaitable, Callable, Iterable

from agents import Agent, OpenAIChatCompletionsModel, Runner, SQLiteSession, function_tool
from agents.stream_events import StreamEvent
from openai import AsyncOpenAI

from .classification_prompts import build_classification_prompt, get_system_prompt
from .prompts import get_main_system_prompt
from .tools._shared import Interface, set_interface
from .tools import (
    build_annotate_tool,
    build_bash_tool,
    build_literature_tool,
    build_manage_todos_tool,
    build_rank_genes_tool,
    build_trials_tool,
    build_vcf_tools,
    build_web_tool,
)

DEFAULT_MODEL = "gpt-5.5"
DEFAULT_MAX_TURNS = 25

ALL_TOOLS = (
    "vcf",
    "annotate",
    "literature",
    "trials",
    "rank_genes",
    "web",
    "classify",
    "bash",
    "manage_todos",
)


def _resolve_max_turns() -> int:
    raw = os.environ.get("AIVA_MAX_TURNS", "").strip()
    if not raw:
        return DEFAULT_MAX_TURNS
    try:
        n = int(raw)
    except ValueError:
        return DEFAULT_MAX_TURNS
    return n if n > 0 else DEFAULT_MAX_TURNS


def _resolve_workdir(workdir: Path | None) -> Path:
    """Freeze the bash workdir to a concrete absolute Path so the prompt and
    the subprocess cwd cannot diverge if Path.cwd() shifts between them
    (matters in notebooks where users may os.chdir between calls).
    """
    return workdir.resolve() if workdir is not None else Path.cwd().resolve()


def _resolve_disabled(disabled_tools: Iterable[str] | None) -> list[str]:
    """Return the active tool list = ALL_TOOLS minus the disabled set.

    Default (None / empty) → every tool is on. Unknown names are ignored
    (the CLI already validates), preserving the lenient behavior of the
    previous `_resolve_enabled`.
    """
    if not disabled_tools:
        return list(ALL_TOOLS)
    drop = {name.strip() for name in disabled_tools if name and name.strip()}
    return [t for t in ALL_TOOLS if t not in drop]


def build_model(
    model: str,
    base_url: str | None = None,
    api_key: str | None = None,
) -> OpenAIChatCompletionsModel:
    """Construct an OpenAIChatCompletionsModel pointing at any OpenAI-compatible endpoint.

    Resolution order for base_url and api_key:
    1. The argument passed in (CLI flag).
    2. LLM_BASE_URL / LLM_API_KEY env vars.
    """
    resolved_base_url = base_url or os.environ.get("LLM_BASE_URL")
    resolved_api_key = api_key or os.environ.get("LLM_API_KEY")
    client = AsyncOpenAI(base_url=resolved_base_url, api_key=resolved_api_key)
    return OpenAIChatCompletionsModel(model=model, openai_client=client)


def build_classifier_tool(
    classifier_tools: list,
    model: str,
    base_url: str | None,
    api_key: str | None,
):
    """Wrap the variant-classifier sub-agent as a @function_tool callable from the parent.

    Mirrors genomiq's SubAgentRunner pattern: per call, build a fresh Agent with the
    classifier's own tool palette and a *type-specific* system prompt + user-turn prompt
    (ACMG or AMP, never both), then run it via Runner.run and return the JSON output.

    The model/client is built once and shared across calls; only the lightweight Agent
    wrapper is constructed per call so the instructions can switch on classification_type.
    """
    sub_model = build_model(model, base_url, api_key)

    # `variant_data` is a heterogeneous dict (rsid OR hgvs OR chrom/pos/ref/alt) — strict
    # JSON Schema doesn't model that cleanly without a TypedDict per shape, so we relax
    # strict mode for this single tool. The shape contract is documented in the docstring
    # and enforced by the per-call prompt.
    @function_tool(strict_mode=False)
    async def classify_variant(
        summary: str,
        variant_data: dict,
        classification_type: str,
        assembly: str,
        phenotype_terms: str = "",
        description: str = "",
        additional_context: str = "",
    ) -> str:
        """Classify a genomic variant using ACMG/AMP 2015 guidelines (germline) or
        AMP/ASCO/CAP 2017 guidelines (somatic). Runs as a sub-agent that gathers
        annotations, literature, and trial evidence on its own, returning a JSON
        classification with criteria_met, evidence_summary, and sources.

        Args:
            summary: User-facing label, e.g. "Classifying BRAF V600E (ACMG)".
            variant_data: One of {"rsid": "rs..."} or {"hgvs": "..."} or
                {"chrom": "...", "pos": ..., "ref": "...", "alt": "..."}.
            classification_type: 'acmg' for germline or 'amp' for somatic/cancer.
            assembly: 'GRCh37' or 'GRCh38'.
            phenotype_terms: e.g. 'melanoma', 'hereditary breast cancer'.
            description: Sample/patient context (optional).
            additional_context: Verified clinical context (de novo status, family history,
                zygosity, segregation). Apply criteria strictly to what's stated here.
        """
        del summary
        prompt = build_classification_prompt(
            variant_data=variant_data,
            classification_type=classification_type,
            assembly=assembly,
            description=description or None,
            phenotype_terms=phenotype_terms or None,
            additional_context=additional_context or None,
        )
        sub_agent = Agent(
            name="variant-classifier",
            instructions=get_system_prompt(classification_type),
            model=sub_model,
            tools=classifier_tools,
        )
        result = await Runner.run(sub_agent, prompt, max_turns=_resolve_max_turns())
        return result.final_output

    return classify_variant


def build_tools_and_cleanup(
    enabled: list[str],
    vcf_specs: list[tuple[str, Path]] | None,
    model: str,
    base_url: str | None,
    api_key: str | None,
    workdir: Path | None = None,
) -> tuple[list, list]:
    """Construct the tool list for an agent run plus any cleanup callables.

    Raises ValueError if 'vcf' is in `enabled` but `vcf_specs` is empty. The
    CLI auto-disables vcf with a warning before reaching this function; the
    guard is the contract for direct library callers.

    `vcf_specs` is a list of `(alias, path)` pairs; each becomes a named
    DuckDB view. Single-file invocations should pass `[("vcf", path)]`.

    `bam_specs` is accepted so paths flow into the system prompt as context
    for the bash tool to query via pysam. There is no dedicated BAM tool.

    classify is special: it needs annotate / literature / trials available to its
    sub-agent. We build those tools once and share the instances between the parent's
    palette and the classifier's palette.
    """
    tools: list = []
    cleanups: list = []

    annotate_tool = literature_tool = trials_tool = None
    web_tool = bash_tool = None

    if "vcf" in enabled:
        if not vcf_specs:
            raise ValueError("--vcf is required when 'vcf' is enabled")
        vcf_tools, vcf_cleanup = build_vcf_tools(vcf_specs)
        tools.extend(vcf_tools)
        cleanups.append(vcf_cleanup)

    if "annotate" in enabled or "classify" in enabled:
        annotate_tool = build_annotate_tool()
        if "annotate" in enabled:
            tools.append(annotate_tool)

    if "literature" in enabled or "classify" in enabled:
        literature_tool, literature_cleanup = build_literature_tool()
        cleanups.append(literature_cleanup)
        if "literature" in enabled:
            tools.append(literature_tool)

    if "trials" in enabled or "classify" in enabled:
        trials_tool, trials_cleanup = build_trials_tool()
        cleanups.append(trials_cleanup)
        if "trials" in enabled:
            tools.append(trials_tool)

    if "rank_genes" in enabled:
        rank_genes_tool, rank_genes_cleanup = build_rank_genes_tool()
        cleanups.append(rank_genes_cleanup)
        tools.append(rank_genes_tool)

    if "web" in enabled:
        web_tool = build_web_tool()
        tools.append(web_tool)

    if "bash" in enabled:
        if workdir is None:
            raise ValueError("workdir is required when 'bash' is enabled")
        bash_tool, bash_cleanup = build_bash_tool(workdir)
        tools.append(bash_tool)
        cleanups.append(bash_cleanup)

    if "manage_todos" in enabled:
        todos_tool, todos_cleanup = build_manage_todos_tool()
        tools.append(todos_tool)
        cleanups.append(todos_cleanup)

    if "classify" in enabled:
        # Share tool instances with the parent palette when they're enabled, so the
        # classifier sub-agent inherits the same web/bash escape hatches the user wired up.
        classifier_tools = [
            t for t in (annotate_tool, literature_tool, trials_tool, web_tool, bash_tool)
            if t is not None
        ]
        tools.append(
            build_classifier_tool(
                classifier_tools=classifier_tools,
                model=model,
                base_url=base_url,
                api_key=api_key,
            )
        )

    return tools, cleanups


def _session_db_path(workdir: Path) -> Path:
    """Sessions live next to the workdir so history is per-dataset."""
    return workdir / ".aiva" / "sessions.db"


def _prepare_run(
    *,
    vcf_specs: list[tuple[str, Path]] | None,
    bam_specs: list[tuple[str, Path]] | None,
    disabled_tools: Iterable[str] | None,
    model: str,
    base_url: str | None,
    api_key: str | None,
    session_id: str | None,
    workdir: Path | None,
    interface: Interface,
) -> tuple[Agent, SQLiteSession | None, list]:
    """Assemble the agent, session, and cleanup list shared by run_once / run_once_streamed."""
    set_interface(interface)
    enabled = _resolve_disabled(disabled_tools)
    resolved_workdir = _resolve_workdir(workdir)
    tools, cleanups = build_tools_and_cleanup(
        enabled=enabled,
        vcf_specs=vcf_specs,
        model=model,
        base_url=base_url,
        api_key=api_key,
        workdir=resolved_workdir,
    )
    session = None
    if session_id:
        db_path = _session_db_path(resolved_workdir)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        session = SQLiteSession(session_id, str(db_path))
    agent = Agent(
        name="aiva",
        instructions=get_main_system_prompt(
            enabled,
            vcf_specs=vcf_specs,
            bam_specs=bam_specs,
            workdir=resolved_workdir,
        ),
        model=build_model(model, base_url, api_key),
        tools=tools,
    )
    return agent, session, cleanups


async def _run_cleanups(cleanups: list) -> None:
    for cleanup in cleanups:
        try:
            result = cleanup()
            if asyncio.iscoroutine(result):
                await result
        except Exception:
            pass


async def run_once(
    prompt: str,
    *,
    vcf_specs: list[tuple[str, Path]] | None = None,
    bam_specs: list[tuple[str, Path]] | None = None,
    disabled_tools: Iterable[str] | None = None,
    model: str = DEFAULT_MODEL,
    base_url: str | None = None,
    api_key: str | None = None,
    session_id: str | None = None,
    workdir: Path | None = None,
    interface: Interface = "cli",
) -> str:
    agent, session, cleanups = _prepare_run(
        vcf_specs=vcf_specs,
        bam_specs=bam_specs,
        disabled_tools=disabled_tools,
        model=model,
        base_url=base_url,
        api_key=api_key,
        session_id=session_id,
        workdir=workdir,
        interface=interface,
    )
    try:
        result = await Runner.run(
            agent, prompt, max_turns=_resolve_max_turns(), session=session
        )
        return result.final_output
    finally:
        await _run_cleanups(cleanups)


async def run_once_streamed(
    prompt: str,
    *,
    on_event: Callable[[StreamEvent], None | Awaitable[None]],
    vcf_specs: list[tuple[str, Path]] | None = None,
    bam_specs: list[tuple[str, Path]] | None = None,
    disabled_tools: Iterable[str] | None = None,
    model: str = DEFAULT_MODEL,
    base_url: str | None = None,
    api_key: str | None = None,
    session_id: str | None = None,
    workdir: Path | None = None,
    interface: Interface = "cli",
) -> str:
    """Streaming counterpart to run_once: invokes on_event for every SDK stream event,
    then returns result.final_output once the stream completes.

    on_event receives raw agents.stream_events.* objects (RawResponsesStreamEvent,
    RunItemStreamEvent, AgentUpdatedStreamEvent). Sync or async callables are accepted.
    """
    agent, session, cleanups = _prepare_run(
        vcf_specs=vcf_specs,
        bam_specs=bam_specs,
        disabled_tools=disabled_tools,
        model=model,
        base_url=base_url,
        api_key=api_key,
        session_id=session_id,
        workdir=workdir,
        interface=interface,
    )
    try:
        result = Runner.run_streamed(
            agent, prompt, max_turns=_resolve_max_turns(), session=session
        )
        async for event in result.stream_events():
            maybe_coro = on_event(event)
            if asyncio.iscoroutine(maybe_coro):
                await maybe_coro
        return result.final_output
    finally:
        await _run_cleanups(cleanups)
