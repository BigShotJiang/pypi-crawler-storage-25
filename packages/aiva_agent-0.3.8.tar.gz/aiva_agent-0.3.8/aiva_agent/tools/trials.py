import asyncio
from typing import Any

import requests
from agents import function_tool

from ._shared import to_json

CTGOV_BASE = "https://clinicaltrials.gov/api/v2/studies"
USER_AGENT = "aiva-agent/0.1 (https://github.com/MHSPL/aiva-agent)"

PHASE_MAP = {
    "EARLY_PHASE1": "EARLY_PHASE1",
    "PHASE1": "PHASE1",
    "PHASE2": "PHASE2",
    "PHASE3": "PHASE3",
    "PHASE4": "PHASE4",
    "NOT_APPLICABLE": "NA",
}

LIST_FIELDS = [
    "NCTId", "BriefTitle", "OverallStatus", "Phase", "Condition",
    "InterventionName", "StartDate", "CompletionDate", "EnrollmentCount",
    "LeadSponsorName", "StudyType", "LocationFacility", "LocationCity",
    "LocationState", "LocationCountry",
]


class ClinicalTrialsWorker:
    """ClinicalTrials.gov rejects httpx (Cloudflare TLS fingerprinting), so we use
    `requests` and dispatch via asyncio.to_thread for non-blocking calls."""

    def __init__(self) -> None:
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": USER_AGENT})

    async def _get(self, url: str, params: dict[str, Any]) -> dict[str, Any]:
        response = await asyncio.to_thread(self._session.get, url, params=params, timeout=30)
        response.raise_for_status()
        return response.json()

    async def aclose(self) -> None:
        self._session.close()

    async def search(
        self,
        condition: str | None = None,
        intervention: str | None = None,
        gene_or_variant: str | None = None,
        phase: str | None = None,
        recruiting_status: str | None = None,
        study_type: str | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 100))
        params: dict[str, Any] = {
            "format": "json",
            "pageSize": limit,
            "fields": ",".join(LIST_FIELDS),
        }
        if condition:
            params["query.cond"] = condition
        if intervention:
            params["query.intr"] = intervention
        if gene_or_variant:
            params["query.term"] = gene_or_variant

        advanced: list[str] = []
        if phase:
            normalized = PHASE_MAP.get(phase.upper())
            if normalized:
                advanced.append(f"AREA[Phase]{normalized}")
        if study_type:
            advanced.append(f"AREA[StudyType]{study_type.upper()}")
        if advanced:
            params["filter.advanced"] = " AND ".join(advanced)

        if recruiting_status:
            params["filter.overallStatus"] = recruiting_status.upper()
        elif not any([phase, intervention, condition, gene_or_variant]):
            params["filter.overallStatus"] = "RECRUITING"

        data = await self._get(CTGOV_BASE, params)
        studies = data.get("studies", [])
        return {
            "total_trials": data.get("totalCount", len(studies)),
            "returned_trials": len(studies),
            "trials": [self._format_trial(s) for s in studies],
        }

    async def details(self, nct_id: str) -> dict[str, Any]:
        data = await self._get(f"{CTGOV_BASE}/{nct_id}", {"format": "json"})
        if "protocolSection" not in data:
            return {"error": f"Trial {nct_id} not found"}
        return self._extract_details(data, nct_id)

    @staticmethod
    def _format_trial(study: dict[str, Any]) -> dict[str, Any]:
        protocol = study.get("protocolSection", {})
        idm = protocol.get("identificationModule", {})
        statusm = protocol.get("statusModule", {})
        designm = protocol.get("designModule", {})
        condm = protocol.get("conditionsModule", {})
        intm = protocol.get("armsInterventionsModule", {})
        sponsorm = protocol.get("sponsorCollaboratorsModule", {})
        contactsm = protocol.get("contactsLocationsModule", {})

        locations: list[str] = []
        for loc in contactsm.get("locations", [])[:3]:
            parts = [p for p in (loc.get("facility", ""), loc.get("city", ""), loc.get("state", ""), loc.get("country", "")) if p]
            if parts:
                locations.append(", ".join(parts))

        nct = idm.get("nctId", "")
        return {
            "nct_id": nct,
            "title": idm.get("briefTitle", ""),
            "url": f"https://clinicaltrials.gov/study/{nct}" if nct else "",
            "status": statusm.get("overallStatus", ""),
            "phase": (designm.get("phases") or ["N/A"])[0],
            "study_type": designm.get("studyType", ""),
            "conditions": condm.get("conditions", []),
            "interventions": [i.get("name", "") for i in intm.get("interventions", [])],
            "start_date": statusm.get("startDateStruct", {}).get("date", ""),
            "completion_date": statusm.get("completionDateStruct", {}).get("date", ""),
            "enrollment": statusm.get("enrollmentInfo", {}).get("count"),
            "sponsor": sponsorm.get("leadSponsor", {}).get("name", ""),
            "locations": locations,
        }

    @staticmethod
    def _extract_details(data: dict[str, Any], nct_id: str) -> dict[str, Any]:
        protocol = data.get("protocolSection", {})
        idm = protocol.get("identificationModule", {})
        statusm = protocol.get("statusModule", {})
        designm = protocol.get("designModule", {})
        condm = protocol.get("conditionsModule", {})
        intm = protocol.get("armsInterventionsModule", {})
        eligm = protocol.get("eligibilityModule", {})
        sponsorm = protocol.get("sponsorCollaboratorsModule", {})
        descm = protocol.get("descriptionModule", {})
        outm = protocol.get("outcomesModule", {})
        contactsm = protocol.get("contactsLocationsModule", {})
        return {
            "nct_id": idm.get("nctId", ""),
            "title": idm.get("briefTitle", ""),
            "official_title": idm.get("officialTitle", ""),
            "url": f"https://clinicaltrials.gov/study/{nct_id}",
            "status": statusm.get("overallStatus", ""),
            "phase": designm.get("phases", []),
            "study_type": designm.get("studyType", ""),
            "description": descm.get("briefSummary", ""),
            "detailed_description": descm.get("detailedDescription", ""),
            "conditions": condm.get("conditions", []),
            "interventions": [
                {"type": i.get("type", ""), "name": i.get("name", ""), "description": i.get("description", "")}
                for i in intm.get("interventions", [])
            ],
            "primary_outcomes": [
                {"measure": o.get("measure", ""), "description": o.get("description", ""), "time_frame": o.get("timeFrame", "")}
                for o in outm.get("primaryOutcomes", [])
            ],
            "eligibility": {
                "criteria": eligm.get("eligibilityCriteria", ""),
                "gender": eligm.get("sex", ""),
                "min_age": eligm.get("minimumAge", ""),
                "max_age": eligm.get("maximumAge", ""),
                "accepts_healthy": eligm.get("healthyVolunteers", False),
            },
            "enrollment": {"count": statusm.get("enrollmentInfo", {}).get("count"), "type": statusm.get("enrollmentInfo", {}).get("type")},
            "dates": {
                "start": statusm.get("startDateStruct", {}).get("date", ""),
                "primary_completion": statusm.get("primaryCompletionDateStruct", {}).get("date", ""),
                "completion": statusm.get("completionDateStruct", {}).get("date", ""),
                "last_update": statusm.get("lastUpdatePostDateStruct", {}).get("date", ""),
            },
            "sponsor": {
                "lead": sponsorm.get("leadSponsor", {}).get("name", ""),
                "collaborators": [c.get("name", "") for c in sponsorm.get("collaborators", [])],
            },
            "locations": [
                {"facility": loc.get("facility", ""), "city": loc.get("city", ""), "state": loc.get("state", ""), "country": loc.get("country", ""), "status": loc.get("status", "")}
                for loc in contactsm.get("locations", [])
            ],
        }


def build_trials_tool():
    worker = ClinicalTrialsWorker()

    @function_tool
    async def search_clinical_trials(
        summary: str,
        action: str,
        context: str = "",
        nct_id: str | None = None,
        condition: str | None = None,
        intervention: str | None = None,
        gene_or_variant: str | None = None,
        phase: str | None = None,
        recruiting_status: str | None = None,
        study_type: str | None = None,
        limit: int = 10,
    ) -> str:
        """Search clinical trials from ClinicalTrials.gov. action='search' finds trials by
        condition / intervention / gene_or_variant / phase / recruiting_status. action='details'
        fetches full info for a specific NCT ID. When searching with both gene/variant AND
        condition/intervention, consider making two separate queries.

        Args:
            summary: User-facing label, e.g. "Finding recruiting BRAF V600E trials".
            action: 'search' or 'details'.
            context: Brief explanation of what you're seeking.
            nct_id: Required for action='details' (e.g., 'NCT04280705').
            condition: Disease or condition (e.g., 'breast cancer').
            intervention: Drug, device, or treatment.
            gene_or_variant: Gene name or variant (e.g., 'BRAF V600E').
            phase: PHASE1 / PHASE2 / PHASE3 / PHASE4 / EARLY_PHASE1 / NOT_APPLICABLE.
            recruiting_status: RECRUITING, NOT_RECRUITING, COMPLETED, etc.
            study_type: INTERVENTIONAL / OBSERVATIONAL / EXPANDED_ACCESS.
            limit: Max results (1-100, default 10).
        """
        del summary
        try:
            if action == "details":
                if not nct_id:
                    return to_json({"error": "nct_id required when action='details'."})
                data = await worker.details(nct_id)
            elif action == "search":
                data = await worker.search(
                    condition=condition,
                    intervention=intervention,
                    gene_or_variant=gene_or_variant,
                    phase=phase,
                    recruiting_status=recruiting_status,
                    study_type=study_type,
                    limit=limit,
                )
            else:
                return to_json({"error": f"Unknown action: {action}"})
            return to_json(data)
        except requests.RequestException as e:
            return to_json({"error": f"ClinicalTrials.gov network error: {e}"})
        except Exception as e:
            return to_json({"error": f"ClinicalTrials.gov unexpected error: {e}"})

    return search_clinical_trials, worker.aclose
