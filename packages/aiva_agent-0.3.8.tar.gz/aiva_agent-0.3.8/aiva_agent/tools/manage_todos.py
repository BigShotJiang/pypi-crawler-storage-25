"""Todo-list tool for planning and tracking multi-step work within an agent run.

Ported from genomiq's manage_todos. State is held in-memory inside the closure
returned by build_manage_todos_tool, so todos live for one run and die with it
(the LLM can still see prior tool calls in a resumed SQLiteSession transcript).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable

from agents import function_tool

from ._shared import to_json


class TodoStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


@dataclass
class Todo:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    description: str = ""
    status: TodoStatus = TodoStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime | None = None
    completed_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "status": self.status.value,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }

    def mark_completed(self) -> None:
        now = datetime.now()
        self.status = TodoStatus.COMPLETED
        self.completed_at = now
        self.updated_at = now


@dataclass
class TodoList:
    todos: list[Todo] = field(default_factory=list)

    def add(self, description: str) -> Todo:
        todo = Todo(description=description)
        self.todos.append(todo)
        return todo

    def get(self, todo_id: str) -> Todo | None:
        for todo in self.todos:
            if todo.id == todo_id:
                return todo
        return None

    def remove(self, todo_id: str) -> bool:
        before = len(self.todos)
        self.todos = [t for t in self.todos if t.id != todo_id]
        return len(self.todos) != before

    def by_status(self, status: TodoStatus) -> list[Todo]:
        return [t for t in self.todos if t.status == status]

    def active(self) -> list[Todo]:
        # "Active" = non-terminal. CANCELLED counts as terminal so it doesn't
        # show up as remaining work in the messages or in `list status=active`.
        return [
            t
            for t in self.todos
            if t.status not in (TodoStatus.COMPLETED, TodoStatus.CANCELLED)
        ]


def _ok(message: str, **extra: Any) -> dict[str, Any]:
    return {"success": True, "message": message, **extra}


def _err(error: str, **extra: Any) -> dict[str, Any]:
    return {"success": False, "error": error, **extra}


def _handle_create(todo_list: TodoList, description: str) -> dict[str, Any]:
    if not description:
        return _err("description is required for action=create")
    todo = todo_list.add(description)
    return _ok(f"created todo: {description}", todo=todo.to_dict())


def _handle_create_multiple(
    todo_list: TodoList, descriptions: list[str] | None
) -> dict[str, Any]:
    if not descriptions:
        return _err("descriptions list is required for action=create_multiple")
    created = [todo_list.add(d).to_dict() for d in descriptions]
    return _ok(f"created {len(created)} todos", todos=created)


def _handle_list(todo_list: TodoList, status_filter: str) -> dict[str, Any]:
    f = (status_filter or "").strip().lower()
    if f == "active":
        todos = todo_list.active()
    elif f == "completed":
        todos = todo_list.by_status(TodoStatus.COMPLETED)
    elif f == "":
        todos = list(todo_list.todos)
    else:
        try:
            todos = todo_list.by_status(TodoStatus(f))
        except ValueError:
            return _err(
                f"unknown status filter: {status_filter}",
                allowed=["", "active", "completed", *(s.value for s in TodoStatus)],
            )

    active_count = len(todo_list.active())
    completed_count = len(todo_list.by_status(TodoStatus.COMPLETED))
    return _ok(
        f"found {len(todos)} todos ({active_count} active, {completed_count} completed)",
        todos=[t.to_dict() for t in todos],
    )


def _handle_update(
    todo_list: TodoList, todo_id: str, description: str, status: str
) -> dict[str, Any]:
    if not todo_id:
        return _err("todo_id is required for action=update")
    todo = todo_list.get(todo_id)
    if not todo:
        return _err(f"todo not found: {todo_id}")

    changed: dict[str, Any] = {}
    if description:
        todo.description = description
        changed["description"] = description
    if status:
        try:
            todo.status = TodoStatus(status.strip().lower())
            changed["status"] = todo.status.value
        except ValueError:
            return _err(
                f"unknown status: {status}",
                allowed=[s.value for s in TodoStatus],
            )

    if not changed:
        return _err("provide description and/or status to update")

    now = datetime.now()
    todo.updated_at = now
    if todo.status == TodoStatus.COMPLETED:
        if todo.completed_at is None:
            todo.completed_at = now
    else:
        # Reversing a completed todo back to pending/in_progress/cancelled —
        # clear the stale completion timestamp so the serialized dict doesn't
        # claim the work is done.
        todo.completed_at = None

    return _ok(f"updated todo: {todo.description}", todo=todo.to_dict())


def _handle_complete(todo_list: TodoList, todo_id: str) -> dict[str, Any]:
    if not todo_id:
        return _err("todo_id is required for action=complete")
    todo = todo_list.get(todo_id)
    if not todo:
        return _err(f"todo not found: {todo_id}")
    todo.mark_completed()
    return _ok(
        f"completed: {todo.description} ({len(todo_list.active())} remaining)",
        todo=todo.to_dict(),
    )


def _handle_delete(todo_list: TodoList, todo_id: str) -> dict[str, Any]:
    if not todo_id:
        return _err("todo_id is required for action=delete")
    todo = todo_list.get(todo_id)
    if not todo:
        return _err(f"todo not found: {todo_id}")
    description = todo.description
    todo_list.remove(todo_id)
    return _ok(
        f"deleted: {description} ({len(todo_list.active())} remaining)",
        deleted_id=todo_id,
    )


def _handle_clear(todo_list: TodoList) -> dict[str, Any]:
    completed = todo_list.by_status(TodoStatus.COMPLETED)
    for todo in completed:
        todo_list.remove(todo.id)
    return _ok(
        f"cleared {len(completed)} completed todos ({len(todo_list.active())} remaining)",
        cleared_count=len(completed),
    )


class TodoWorker:
    """Holds a TodoList and routes action strings to handlers."""

    def __init__(self) -> None:
        self.todo_list = TodoList()

    def dispatch(
        self,
        action: str,
        *,
        description: str = "",
        todo_id: str = "",
        status: str = "",
        descriptions: list[str] | None = None,
    ) -> dict[str, Any]:
        if action == "create":
            return _handle_create(self.todo_list, description)
        if action == "create_multiple":
            return _handle_create_multiple(self.todo_list, descriptions)
        if action == "list":
            return _handle_list(self.todo_list, status)
        if action == "update":
            return _handle_update(self.todo_list, todo_id, description, status)
        if action == "complete":
            return _handle_complete(self.todo_list, todo_id)
        if action == "delete":
            return _handle_delete(self.todo_list, todo_id)
        if action == "clear":
            return _handle_clear(self.todo_list)
        return _err(
            f"unknown action: {action}",
            allowed=[
                "create",
                "create_multiple",
                "list",
                "update",
                "complete",
                "delete",
                "clear",
            ],
        )


def build_manage_todos_tool() -> tuple[Any, Callable[[], None]]:
    """Build a stateful todo tool whose list lives for the agent run.

    Returns (tool, cleanup_fn). The cleanup is a no-op; the tuple shape mirrors
    the other build_*_tool helpers so build_tools_and_cleanup stays symmetric.
    """
    worker = TodoWorker()

    @function_tool
    async def manage_todos(
        summary: str,
        action: str,
        description: str = "",
        todo_id: str = "",
        status: str = "",
        descriptions: list[str] | None = None,
    ) -> str:
        """Plan and track multi-step work. Use this when the user's request
        will take several tool calls — create todos up front, mark them
        in_progress as you start each one, complete them as you finish.

        Args:
            summary: User-facing label, e.g. "Planning trio analysis steps".

        Actions:
            - create: add one todo (requires `description`).
            - create_multiple: add several at once (requires `descriptions`).
            - list: list todos. Optional `status`: "active", "completed",
                "pending", "in_progress", "cancelled", or empty for all.
            - update: change a todo's description and/or status (requires
                `todo_id`; pass `description` and/or `status`).
            - complete: mark a todo done (requires `todo_id`).
            - delete: remove a todo (requires `todo_id`).
            - clear: remove all completed todos.

        Returns:
            JSON with `success` and either a `message` + payload (todo / todos
            / counts) or an `error` string.
        """
        del summary
        return to_json(
            worker.dispatch(
                action,
                description=description,
                todo_id=todo_id,
                status=status,
                descriptions=descriptions,
            )
        )

    def cleanup() -> None:
        return None

    return manage_todos, cleanup
