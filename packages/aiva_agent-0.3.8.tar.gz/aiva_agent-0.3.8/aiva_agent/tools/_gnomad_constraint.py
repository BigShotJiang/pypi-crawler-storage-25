"""gnomAD GraphQL gene-constraint helper for the annotate tool.

Lives in its own module so ``annotate.py`` stays under the 450-LOC ceiling. The
public surface is :func:`fetch_gnomad_constraint`, called by ``annotate_variant``
when ``action="gnomad_constraint"``. Genes are keyed UPPERCASE; results are
cached in-process across calls because constraint metrics are gene-level and
stable. Permanent misses (gene genuinely not in gnomAD) are cached; transient
GraphQL errors are NOT cached.

Returned dicts share the shape conventions of the other ``_annotate_*`` methods
in ``annotate.py`` — plain dicts; outer ``annotate_variant`` wraps with
``to_json``. The ``interpretation`` block precomputes the boolean conclusions a
classifier needs (PP2 missense_constrained, PVS1 lof_intolerant) so the
sub-agent doesn't have to re-derive thresholds from raw numbers.
"""

from __future__ import annotations

from typing import Any

import httpx

_GNOMAD_GRAPHQL_URL = "https://gnomad.broadinstitute.org/api"
_GNOMAD_HTTP_TIMEOUT = 15.0

_GRAPHQL_QUERY = """
query GeneConstraint($symbol: String!) {
  gene(gene_symbol: $symbol, reference_genome: GRCh38) {
    gene_id
    symbol
    gnomad_constraint {
      mis_z lof_z syn_z pLI
      oe_lof oe_lof_lower oe_lof_upper
      oe_mis oe_mis_lower oe_mis_upper
      oe_syn obs_lof exp_lof obs_mis exp_mis
    }
  }
}
"""

_CACHE: dict[str, dict[str, Any]] = {}


async def fetch_gnomad_constraint(gene: str | None) -> dict[str, Any]:
    """Fetch gene-level constraint metrics from the gnomAD GraphQL API.

    Used by ACMG criteria PP2 (missense constraint), PVS1 strength (LOF
    mechanism via pLI / LOEUF), and as a sanity input to BS1.
    """
    if not gene or not gene.strip():
        return {
            "_source": "gnomad_constraint",
            "error": "gene parameter is required",
        }

    cache_key = gene.strip().upper()
    if cache_key in _CACHE:
        cached = dict(_CACHE[cache_key])
        cached["_cache_hit"] = True
        return cached

    try:
        async with httpx.AsyncClient(timeout=_GNOMAD_HTTP_TIMEOUT) as client:
            resp = await client.post(
                _GNOMAD_GRAPHQL_URL,
                json={"query": _GRAPHQL_QUERY, "variables": {"symbol": cache_key}},
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            payload = resp.json()
    except Exception as e:
        # Transient — do not cache. Caller may retry once.
        return {
            "_source": "gnomad_constraint",
            "gene_symbol": cache_key,
            "error": f"gnomAD GraphQL request failed: {e}",
            "suggestion": (
                "gnomAD may be rate-limited or down. Retry once; if it fails again, "
                "mark PP2 as not_applicable due to missing constraint data."
            ),
        }

    errors = payload.get("errors")
    gene_node = (payload.get("data") or {}).get("gene")

    if errors or gene_node is None:
        msg = errors[0]["message"] if errors else "Gene not found in gnomAD"
        data: dict[str, Any] = {
            "_source": "gnomad_constraint",
            "gene_symbol": cache_key,
            "error": msg,
            "note": "gnomAD has no constraint data for this gene. PP2 cannot use constraint metrics here.",
        }
        # Cache only permanent misses (no GraphQL error, gene absent).
        if not errors and gene_node is None:
            _CACHE[cache_key] = data
        return data

    constraint = gene_node.get("gnomad_constraint") or {}
    mis_z = constraint.get("mis_z")
    oe_mis_upper = constraint.get("oe_mis_upper")
    oe_lof_upper = constraint.get("oe_lof_upper")
    pli = constraint.get("pLI")

    data = {
        "_source": "gnomad_constraint",
        "gene_symbol": gene_node.get("symbol", cache_key),
        "gene_id": gene_node.get("gene_id"),
        "constraint": constraint,
        "interpretation": {
            "missense_constrained": (
                (mis_z is not None and mis_z >= 3.09)
                or (oe_mis_upper is not None and oe_mis_upper < 0.5)
            ),
            "lof_intolerant": (pli or 0) >= 0.9,
            "loeuf_below_0_35": oe_lof_upper is not None and oe_lof_upper < 0.35,
        },
        "thresholds": {
            "mis_z": ">=3.09 supports PP2 (missense constraint per ClinGen)",
            "oe_mis_upper": "<0.5 also supports PP2",
            "pLI": ">=0.9 supports PVS1 LOF mechanism",
            "oe_lof_upper": "(LOEUF) <0.35 indicates strong LOF intolerance",
        },
        "caveat": (
            "pLI/LOEUF underestimates constraint for cancer-predisposition genes "
            "(BRCA1, TP53, etc.) because heterozygous LOF carriers survive to be "
            "sequenced. For established tumor suppressors, treat low pLI as "
            "inconclusive, not benign."
        ),
    }
    _CACHE[cache_key] = data
    return data


def _clear_cache_for_tests() -> None:
    """Test hook — clear the in-process cache between cases."""
    _CACHE.clear()
