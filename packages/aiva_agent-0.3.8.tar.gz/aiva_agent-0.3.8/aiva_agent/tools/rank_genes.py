import asyncio
from typing import Any

import httpx
from agents import function_tool

from ._shared import to_json

API_URL = "https://phen2gene.wglab.org/api"
USER_AGENT = "aiva-agent/0.1 (https://github.com/MHSPL/aiva-agent)"

WEIGHT_MODELS = {
    "ic": "Information Content - best for rare disease (default)",
    "sk": "Skewness-weighted",
    "w": "Ontology-based",
    "u": "Unweighted",
}


class RankGenesWorker:
    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            timeout=60.0,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    @staticmethod
    def _normalize(hpo_ids: list[str]) -> list[str]:
        out: list[str] = []
        for hpo in hpo_ids:
            term = hpo.strip().upper()
            if not term.startswith("HP:"):
                term = f"HP:{term}"
            out.append(term)
        return out

    async def _call_api(self, hpo_ids: list[str], weight_model: str) -> dict[str, Any]:
        params = {"HPO_list": ";".join(hpo_ids), "weight_model": weight_model}
        response = await self._client.get(API_URL, params=params)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _apply_exclusion_penalties(
        positive: list[dict[str, Any]],
        excluded: list[dict[str, Any]],
        strength: float,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        lookup: dict[str, dict[str, Any]] = {}
        for g in excluded:
            name = g.get("Gene") or g.get("gene", "")
            lookup[name] = {
                "score": float(g.get("Score") or g.get("score", 0)),
                "status": g.get("Status") or g.get("status", "Predicted"),
            }

        if not lookup:
            return positive, []

        kept: list[dict[str, Any]] = []
        removed: list[str] = []

        for g in positive:
            name = g.get("Gene") or g.get("gene", "")
            if name in lookup:
                info = lookup[name]
                if info["status"] == "SeedGene":
                    removed.append(name)
                    continue
                original = float(g.get("Score") or g.get("score", 0))
                penalized = original * (1 - info["score"] * strength)
                modified = dict(g)
                if "Score" in modified:
                    modified["Score"] = penalized
                else:
                    modified["score"] = penalized
                kept.append(modified)
            else:
                kept.append(g)

        score_key = "Score" if kept and "Score" in kept[0] else "score"
        kept.sort(key=lambda g: float(g.get(score_key, 0)), reverse=True)
        rank_key = "Rank" if kept and "Rank" in kept[0] else "rank"
        for i, g in enumerate(kept, 1):
            g[rank_key] = i
        return kept, removed

    async def get_genes_for_phenotypes(
        self,
        hpo_ids: list[str],
        weight_model: str = "ic",
        limit: int = 100,
        excluded_hpo_ids: list[str] | None = None,
        exclusion_strength: float | None = None,
    ) -> dict[str, Any]:
        if not hpo_ids:
            return {"error": "No HPO IDs provided. Provide at least one HPO term (e.g., HP:0002459)."}

        if weight_model not in WEIGHT_MODELS:
            weight_model = "ic"
        limit = max(1, min(limit, 1000))
        strength = 0.5 if exclusion_strength is None else max(0.0, min(1.0, exclusion_strength))

        normalized = self._normalize(hpo_ids)
        normalized_excluded = self._normalize(excluded_hpo_ids) if excluded_hpo_ids else []

        if normalized_excluded:
            positive_data, excluded_result = await asyncio.gather(
                self._call_api(normalized, weight_model),
                self._call_api(normalized_excluded, weight_model),
                return_exceptions=True,
            )
            if isinstance(positive_data, BaseException):
                raise positive_data
            excluded_data = excluded_result if not isinstance(excluded_result, BaseException) else None
        else:
            positive_data = await self._call_api(normalized, weight_model)
            excluded_data = None

        if positive_data.get("errors"):
            return {
                "error": f"Gene-ranking errors: {'; '.join(positive_data['errors'])}",
                "invalid_hpo_ids": positive_data["errors"],
            }

        results = positive_data.get("results", [])
        removed: list[str] = []
        if excluded_data and not excluded_data.get("errors"):
            excluded_results = excluded_data.get("results", [])
            if excluded_results:
                results, removed = self._apply_exclusion_penalties(results, excluded_results, strength)

        formatted = [
            {
                "gene": g.get("Gene") or g.get("gene", ""),
                "rank": g.get("Rank") or g.get("rank", 0),
                "score": g.get("Score") or g.get("score", 0),
                "status": g.get("Status") or g.get("status", "Predicted"),
            }
            for g in results[:limit]
        ]

        out: dict[str, Any] = {
            "genes": formatted,
            "total_genes": len(results),
            "returned_genes": len(formatted),
            "hpo_terms_used": normalized,
            "weight_model": weight_model,
            "weight_model_description": WEIGHT_MODELS[weight_model],
            "top_genes_summary": ", ".join(g["gene"] for g in formatted[:10]),
        }
        if normalized_excluded:
            out["excluded_hpo_terms"] = normalized_excluded
            out["genes_removed_by_exclusion"] = removed
            out["exclusion_strength"] = strength
        return out


def build_rank_genes_tool():
    worker = RankGenesWorker()

    @function_tool
    async def get_genes_for_phenotypes(
        summary: str,
        hpo_ids: list[str],
        weight_model: str = "ic",
        limit: int = 100,
        excluded_hpo_ids: list[str] | None = None,
        exclusion_strength: float | None = None,
        context: str = "",
    ) -> str:
        """Get candidate genes ranked by association to HPO phenotype terms for rare disease
        diagnosis. Uses Information Content (IC) weighting by default. Supports excluding
        phenotypes the patient does NOT have to improve specificity.

        Args:
            summary: User-facing label, e.g. "Ranking genes for proband phenotypes".
            hpo_ids: HPO IDs describing patient phenotypes (e.g., ["HP:0002459", "HP:0010522"]).
            weight_model: 'ic' (default), 'sk', 'w', or 'u'.
            limit: Max genes to return (default 100, max 1000).
            excluded_hpo_ids: Optional HPO IDs the patient does NOT have.
            exclusion_strength: 0.0-1.0 (default 0.5) — how aggressively to penalize.
            context: Clinical context for logging.
        """
        del summary
        try:
            data = await worker.get_genes_for_phenotypes(
                hpo_ids=hpo_ids,
                weight_model=weight_model,
                limit=limit,
                excluded_hpo_ids=excluded_hpo_ids,
                exclusion_strength=exclusion_strength,
            )
            return to_json(data)
        except httpx.TimeoutException:
            return to_json({"error": "Gene-ranking request timed out. Try with fewer HPO terms."})
        except httpx.HTTPStatusError as e:
            return to_json({"error": f"Gene-ranking upstream returned HTTP {e.response.status_code}."})
        except httpx.HTTPError as e:
            return to_json({"error": f"Gene-ranking network error ({type(e).__name__})."})
        except Exception as e:
            return to_json({"error": f"Gene-ranking unexpected error ({type(e).__name__})."})

    return get_genes_for_phenotypes, worker.aclose
