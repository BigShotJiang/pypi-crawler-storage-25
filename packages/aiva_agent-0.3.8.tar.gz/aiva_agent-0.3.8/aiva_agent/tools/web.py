"""Web search + URL scrape — a single tool with an `action` parameter.

Mirrors the action-based shape of `annotate_variant` and `search_clinical_trials`:
one tool the model invokes with action='search' or action='scrape'.

Backends are intentionally free + no-account:
- Search: DuckDuckGo (via ``ddgs``) — metasearch across DuckDuckGo / Bing / Brave.
- Scrape: ``trafilatura`` — clean main-content extraction from any HTML page.

Neither requires an API key. Per-user IPs hit the upstream services directly.
"""

import asyncio
from typing import Any
from urllib.parse import urlparse

import requests
import trafilatura
from agents import function_tool
from ddgs import DDGS

from ._shared import to_json

# Browser-like UA. PubMed/PMC and many other sites are behind Cloudflare and
# block bots with library default UAs. We fetch via `requests` (different TLS
# stack than httpx — the same fix we use in trials.py) with this UA, then hand
# the HTML to trafilatura.extract for clean main-content extraction.
# Full browser-style header set. PubMed/PMC and many other sites are behind
# Cloudflare which blocks library-default headers and TLS fingerprints. The
# combo of `requests` (different TLS stack than httpx) + this header set gets
# us through anti-bot challenges on common targets.
BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/webp,image/apng,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Upgrade-Insecure-Requests": "1",
}
MAX_SCRAPE_CHARS = 20_000
FETCH_TIMEOUT = 30


class WebSearchWorker:
    """Runs DuckDuckGo searches and trafilatura scrapes off the asyncio event loop."""

    def __init__(self) -> None:
        # ddgs and trafilatura are sync libraries — we dispatch via asyncio.to_thread
        # so we don't block the agent loop.
        self._ddgs = DDGS()
        self._http = requests.Session()
        self._http.headers.update(BROWSER_HEADERS)

    async def search(self, query: str, limit: int) -> dict[str, Any]:
        limit = max(1, min(limit, 50))

        def _go() -> list[dict[str, Any]]:
            return list(self._ddgs.text(query, max_results=limit))

        results = await asyncio.to_thread(_go)
        formatted = [
            {
                "title": r.get("title", ""),
                "url": r.get("href") or r.get("url", ""),
                "snippet": r.get("body", ""),
            }
            for r in results
        ]
        return {
            "query": query,
            "returned_results": len(formatted),
            "results": formatted,
        }

    async def scrape(self, url: str) -> dict[str, Any]:
        # Block non-HTTP schemes — `requests` follows file://, ftp://, etc., which
        # would let a model exfiltrate local files or hit cloud-metadata endpoints
        # via redirects. Limit to http/https and require a host.
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            return {"url": url, "error": "Only http(s) URLs with a hostname are allowed."}

        def _go() -> dict[str, Any]:
            try:
                response = self._http.get(url, timeout=FETCH_TIMEOUT, allow_redirects=True)
                response.raise_for_status()
                html = response.text
            except requests.RequestException as e:
                return {"url": url, "error": f"Fetch failed: {e}"}
            text = trafilatura.extract(html, include_comments=False, include_tables=True)
            if not text:
                return {"url": url, "error": "No main content extracted (page may be JS-only or empty)."}
            truncated = text[:MAX_SCRAPE_CHARS]
            return {
                "url": url,
                "char_count": len(text),
                "truncated": len(text) > MAX_SCRAPE_CHARS,
                "content": truncated,
            }

        return await asyncio.to_thread(_go)


def build_web_tool():
    worker = WebSearchWorker()

    @function_tool
    async def web_search(
        summary: str,
        action: str,
        context: str = "",
        query: str | None = None,
        limit: int = 10,
        url: str | None = None,
    ) -> str:
        """Search the web or scrape a specific URL. Single tool with two actions:

        - action='search': searches DuckDuckGo (free, no key, metasearch across multiple
          engines). Returns title / url / snippet for each result. Use this when looking
          for relevant pages (e.g. a paper, a guideline document, a database entry).
        - action='scrape': fetches the URL and returns clean main-content text via
          trafilatura. Use this AFTER a search to read a specific page in detail
          (e.g. extract the body of a PubMed paper or NCCN guideline).

        Two-step workflow: search for short snippets first, then scrape the most
        relevant URL(s) for full content. Don't scrape every result — only what you
        need. Output is truncated at 20,000 characters per scrape.

        Args:
            summary: User-facing label, e.g. "Scraping NCCN melanoma guideline".
            action: 'search' or 'scrape'.
            context: Brief explanation of what you're looking for (logging only).
            query: Search terms (required for action='search').
            limit: Max search results, 1-50 (default 10). Only used for action='search'.
            url: URL to scrape (required for action='scrape').
        """
        del summary
        try:
            if action == "search":
                if not query:
                    return to_json({"error": "query is required for action='search'."})
                data = await worker.search(query=query, limit=limit)
            elif action == "scrape":
                if not url:
                    return to_json({"error": "url is required for action='scrape'."})
                data = await worker.scrape(url=url)
            else:
                return to_json({"error": f"Unknown action: {action}. Use 'search' or 'scrape'."})
            return to_json(data)
        except Exception as e:
            return to_json({"error": f"web_search ({action}) failed: {e}"})

    return web_search
