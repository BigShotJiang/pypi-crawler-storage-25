from typing import Any

import httpx
from agents import function_tool

from ._shared import to_json

PUBTATOR_BASE = "https://www.ncbi.nlm.nih.gov/research/pubtator3-api"
USER_AGENT = "aiva-agent/0.1 (https://github.com/MHSPL/aiva-agent)"


class PubTatorWorker:
    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=PUBTATOR_BASE,
            headers={"User-Agent": USER_AGENT},
            timeout=30.0,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def search(self, query: str, limit: int = 10, sort: str = "relevance") -> dict[str, Any]:
        limit = max(1, min(limit, 100))
        if sort not in ("relevance", "date"):
            sort = "relevance"

        params: dict[str, Any] = {"text": query, "size": limit}
        if sort == "date":
            params["sort"] = "date desc"

        response = await self._client.get("/search/", params=params)
        response.raise_for_status()
        data = response.json()

        results = data.get("results", []) if data else []
        formatted = [self._format_result(r) for r in results]
        return {
            "query": query,
            "total_results": data.get("count", len(results)) if data else 0,
            "returned_results": len(formatted),
            "results": formatted,
        }

    def _format_result(self, result: dict[str, Any]) -> dict[str, Any]:
        text_hl = result.get("text_hl", "")
        date = result.get("date", "")
        year = result.get("meta_date_publication") or (date[:4] if date else "")
        return {
            "pmid": str(result.get("pmid", "")),
            "pmcid": result.get("pmcid", ""),
            "title": result.get("title", ""),
            "journal": result.get("journal", ""),
            "year": year,
            "authors": result.get("authors", []),
            "doi": result.get("doi", ""),
            "relevance_score": result.get("score", 0),
            "annotations": {
                "genes": self._extract_entities(text_hl, "@GENE_"),
                "diseases": self._extract_entities(text_hl, "@DISEASE_"),
                "variants": self._extract_entities(text_hl, "@VARIANT_"),
                "chemicals": self._extract_entities(text_hl, "@CHEMICAL_"),
            },
            "citation": result.get("citations", {}).get("NLM", ""),
        }

    @staticmethod
    def _extract_entities(text_hl: str, prefix: str) -> list[str]:
        if not text_hl:
            return []
        seen: set[str] = set()
        out: list[str] = []
        for part in text_hl.split(prefix)[1:]:
            end = part.find("@@@")
            if end == -1:
                continue
            raw = part[:end].strip()
            if "_" in raw:
                name, _, identifier = raw.rpartition("_")
                rendered = f"{name.replace('_', ' ')} ({identifier})"
            else:
                rendered = raw
            if rendered and rendered not in seen:
                seen.add(rendered)
                out.append(rendered)
        return out


def build_literature_tool():
    worker = PubTatorWorker()

    @function_tool
    async def search_biomedical_literature(
        summary: str,
        query: str,
        limit: int = 10,
        sort: str = "relevance",
        context: str = "",
    ) -> str:
        """Search PubMed/PMC literature with automatic entity annotation (genes, diseases,
        variants, chemicals). Returns PMIDs, citations, and annotated entities from PubTator3.

        Args:
            summary: User-facing label, e.g. "Searching literature for KRAS G12C".
            query: Search terms (gene names, diseases, variants, keywords).
            limit: Max results (1-100, default 10).
            sort: 'relevance' (default) or 'date' (newest first).
            context: Brief explanation of what research is being requested.
        """
        del summary
        try:
            data = await worker.search(query=query, limit=limit, sort=sort)
            return to_json(data)
        except httpx.HTTPError as e:
            return to_json({"error": f"PubTator network error: {e}"})
        except Exception as e:
            return to_json({"error": f"PubTator unexpected error: {e}"})

    return search_biomedical_literature, worker.aclose
