"""Path-spec parsing for `--vcf` / `--bam` flags. Each flag accepts either
a bare path (folded to `[(default_alias, Path)]`) or a comma-separated
`alias=path[,alias=path...]` list. The two flags share validation; they
differ only in the default alias and a couple of error-message strings.
"""

import argparse
from pathlib import Path

from .tools._shared import ALIAS_RE, MAX_ALIAS_LEN, RESERVED_ALIASES


def _parse_path_specs(
    raw: str,
    *,
    default_alias: str,
    kind: str,
    sample_path: str,
    forbid_long_suffix: bool,
) -> list[tuple[str, Path]]:
    """Parse a `path` or `alias=path[,alias=path...]` spec into (alias, Path)
    pairs. Shared between `--vcf` and `--bam`. The two flags differ only in
    the default alias (`vcf` / `bam`), the example path used in error
    messages, the `kind` label surfaced in errors, and whether `_long`
    aliases are reserved (vcf only — its tidy companion view uses that
    suffix).
    """
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    if not parts:
        return []

    has_eq = [("=" in p) for p in parts]
    if len(parts) == 1 and has_eq[0]:
        head, _, _ = parts[0].partition("=")
        head = head.strip()
        if head and (not ALIAS_RE.match(head) or len(head) > MAX_ALIAS_LEN):
            raise argparse.ArgumentTypeError(
                f"Could not parse {kind} spec {parts[0]!r}: looks like a bare path "
                "containing '=' (which we use as the alias separator). Rename "
                f"the file or wrap it in an alias, e.g. 'sample={sample_path}'."
            )
    if any(has_eq) and not all(has_eq):
        raise argparse.ArgumentTypeError(
            "Mix of bare path and alias=path is not allowed. "
            "Either give one bare path, or alias every path."
        )
    if not any(has_eq):
        if len(parts) > 1:
            raise argparse.ArgumentTypeError(
                f"Multiple paths require alias=path syntax, e.g. "
                f"'a={sample_path},b={sample_path}'."
            )
        return [(default_alias, Path(parts[0]))]

    specs: list[tuple[str, Path]] = []
    seen: set[str] = set()
    for p in parts:
        alias, _, path_str = p.partition("=")
        alias = alias.strip()
        path_str = path_str.strip()
        if not alias:
            raise argparse.ArgumentTypeError(f"Empty alias in spec: {p!r}.")
        if not path_str:
            raise argparse.ArgumentTypeError(f"Empty path for alias {alias!r}.")
        if not ALIAS_RE.match(alias) or len(alias) > MAX_ALIAS_LEN:
            raise argparse.ArgumentTypeError(
                f"Invalid alias {alias!r}: must match [A-Za-z_][A-Za-z0-9_]* and be ≤32 chars."
            )
        if alias.lower() in RESERVED_ALIASES:
            raise argparse.ArgumentTypeError(
                f"Reserved DuckDB keyword: {alias!r}. Pick a different alias "
                f"(e.g. add a suffix: {alias}_view)."
            )
        if forbid_long_suffix and alias.lower().endswith("_long"):
            raise argparse.ArgumentTypeError(
                f"Reserved alias suffix: {alias!r} ends in '_long', which is "
                f"used for the auto-generated tidy companion view. Drop the "
                f"suffix or pick a different alias."
            )
        if alias.lower() in seen:
            raise argparse.ArgumentTypeError(
                f"Duplicate alias: {alias!r} (aliases are case-insensitive in DuckDB)."
            )
        seen.add(alias.lower())
        specs.append((alias, Path(path_str)))
    return specs


def _parse_vcf_specs(raw: str) -> list[tuple[str, Path]]:
    """Parse a VCF spec string into a list of (alias, Path) pairs.

    Two forms are accepted:
      - Single bare path: "sample.vcf.gz" -> [("vcf", Path("sample.vcf.gz"))].
      - Comma-separated alias=path: "proband=p.vcf.gz,father=f.vcf.gz".

    Mixing the two forms in a single argument is rejected. Aliases must be
    valid SQL identifiers (used unquoted in CREATE VIEW), max 32 chars.
    """
    return _parse_path_specs(
        raw,
        default_alias="vcf",
        kind="VCF",
        sample_path="p.vcf.gz",
        forbid_long_suffix=True,
    )


def _parse_bam_specs(raw: str) -> list[tuple[str, Path]]:
    """Parse a BAM spec string into a list of (alias, Path) pairs.

    Same shape as `--vcf`: bare path becomes `[("bam", Path(...))]`, or
    comma-separated `alias=path` for tumor/normal or family layouts.
    """
    return _parse_path_specs(
        raw,
        default_alias="bam",
        kind="BAM",
        sample_path="t.bam",
        forbid_long_suffix=False,
    )


def _has_bam_index(path: Path) -> bool:
    """duckhts uses htslib, which looks for `.bai`/`.csi` next to a BAM and
    `.crai` next to a CRAM. Checking both `path + .bai` and `path.with_suffix
    ('.bai')` covers the two conventions (`sample.bam.bai` and `sample.bai`).
    """
    candidates = (
        path.with_name(path.name + ".bai"),
        path.with_name(path.name + ".csi"),
        path.with_name(path.name + ".crai"),
        path.with_suffix(".bai"),
        path.with_suffix(".crai"),
    )
    return any(c.exists() for c in candidates)
