"""POST /sessions/{id}/messages — bridge run_once_streamed to an SSE stream.

Concurrency: each session has an asyncio.Lock cached on WebState. Two
simultaneous posts to the same session return 409 instead of corrupting
SQLiteSession (which isn't built for parallel writers).

Cancellation: if the client disconnects mid-stream we cancel the runner
task in the generator's `finally` so SDK cleanups (e.g., DuckDB connection
close) run.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import AsyncIterator

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from ..agent import run_once_streamed
from .event_bridge import make_event_handler
from .sse import format_sse, queue_to_sse

router = APIRouter()


class _MessageIn(BaseModel):
    prompt: str


@router.post("/sessions/{session_id}/messages")
async def post_message(request: Request, session_id: str, body: _MessageIn):
    state = request.app.state.aiva
    meta_store = request.app.state.meta_store

    meta = meta_store.get(session_id)
    if meta is None:
        raise HTTPException(404, "session not found")

    prompt = body.prompt.strip()
    if not prompt:
        raise HTTPException(400, "empty prompt")

    if not meta.name:
        meta_store.set_name(session_id, prompt[:60])

    lock = state.lock_for(session_id)
    if lock.locked():
        raise HTTPException(409, "session is busy")

    vcf_specs = [(alias, Path(path)) for alias, path in meta.vcf_specs]
    bam_specs = [(alias, Path(path)) for alias, path in meta.bam_specs]
    disabled_tools = ("vcf",) if not vcf_specs else None

    queue: asyncio.Queue = asyncio.Queue()
    handler = make_event_handler(queue)

    async def runner_task() -> str:
        return await run_once_streamed(
            prompt,
            on_event=handler,
            vcf_specs=vcf_specs or None,
            bam_specs=bam_specs or None,
            disabled_tools=disabled_tools,
            model=state.model,
            base_url=state.base_url,
            api_key=state.api_key,
            session_id=session_id,
            workdir=state.workdir,
            interface="web",
        )

    async def generator() -> AsyncIterator[bytes]:
        await lock.acquire()
        task: asyncio.Task[str] = asyncio.create_task(_run_and_finalize(runner_task, queue))
        try:
            async for chunk in queue_to_sse(queue):
                yield chunk
            try:
                await task
            except Exception as e:
                yield format_sse("error", {"message": str(e)})
                return
            meta_store.touch(session_id)
        finally:
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
            lock.release()

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


async def _run_and_finalize(runner_task, queue: asyncio.Queue) -> str:
    try:
        result = await runner_task()
    except asyncio.CancelledError:
        queue.put_nowait(None)
        raise
    except Exception as e:
        queue.put_nowait(("error", {"message": str(e)}))
        queue.put_nowait(None)
        raise
    queue.put_nowait(("final", {"text": result}))
    queue.put_nowait(None)
    return result
