"""GET /workdir/{path} — serve files under the configured workdir, so images
the agent saves can be referenced from the rendered markdown via
`![alt](/workdir/<relative-path>)`. Path traversal is rejected the same way
the file picker does it.
"""

from __future__ import annotations

import mimetypes

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse

from .file_picker import resolve_under

router = APIRouter()


@router.get("/workdir/{rel_path:path}")
async def serve_workdir_file(request: Request, rel_path: str):
    workdir = request.app.state.aiva.workdir
    try:
        target = resolve_under(workdir, rel_path)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e
    # routes_workdir keeps its own try/except because it raises 404 (not 400)
    # on resolve failure: this endpoint serves assistant-generated image paths,
    # where a missing file is a stale link, not a bad request.
    if not target.is_file():
        raise HTTPException(404, "not a file")
    media_type, _ = mimetypes.guess_type(str(target))
    return FileResponse(target, media_type=media_type or "application/octet-stream")
