"""SQLite metadata store for web UI sessions.

Holds only UI-specific fields (display name, bound VCF/BAM specs, timestamps).
Conversation history lives in `<workdir>/.aiva/sessions.db` via the SDK's
SQLiteSession, alongside this metadata DB — sessions are scoped per-workdir,
so switching workdir gives you a different history namespace.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS web_sessions (
  id              TEXT PRIMARY KEY,
  name            TEXT,
  vcf_specs       TEXT NOT NULL,
  bam_specs       TEXT NOT NULL,
  created_at      TEXT NOT NULL,
  last_message_at TEXT
);
"""


@dataclass
class SessionMeta:
    id: str
    name: str | None
    vcf_specs: list[tuple[str, str]]
    bam_specs: list[tuple[str, str]]
    created_at: str
    last_message_at: str | None

    def to_json(self) -> dict:
        return {
            "id": self.id,
            "name": self.name or self.id,
            "vcf_specs": [{"alias": a, "path": p} for a, p in self.vcf_specs],
            "bam_specs": [{"alias": a, "path": p} for a, p in self.bam_specs],
            "created_at": self.created_at,
            "last_message_at": self.last_message_at,
        }


class MetaStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._lock = threading.Lock()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def new_id() -> str:
        return f"aiva-{uuid.uuid4().hex[:12]}"

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def create(
        self,
        *,
        name: str | None,
        vcf_specs: list[tuple[str, str]],
        bam_specs: list[tuple[str, str]],
        session_id: str | None = None,
    ) -> SessionMeta:
        sid = session_id or self.new_id()
        meta = SessionMeta(
            id=sid,
            name=name,
            vcf_specs=vcf_specs,
            bam_specs=bam_specs,
            created_at=self._now(),
            last_message_at=None,
        )
        with self._lock, self._connect() as conn:
            conn.execute(
                "INSERT INTO web_sessions(id, name, vcf_specs, bam_specs, created_at, last_message_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    meta.id,
                    meta.name,
                    _specs_to_json(meta.vcf_specs),
                    _specs_to_json(meta.bam_specs),
                    meta.created_at,
                    meta.last_message_at,
                ),
            )
        return meta

    def get(self, session_id: str) -> SessionMeta | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, name, vcf_specs, bam_specs, created_at, last_message_at "
                "FROM web_sessions WHERE id = ?",
                (session_id,),
            ).fetchone()
        return self._row_to_meta(row) if row else None

    def list_all(self) -> list[SessionMeta]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name, vcf_specs, bam_specs, created_at, last_message_at "
                "FROM web_sessions ORDER BY COALESCE(last_message_at, created_at) DESC"
            ).fetchall()
        return [self._row_to_meta(r) for r in rows]

    def update_specs(
        self,
        session_id: str,
        *,
        vcf_specs: list[tuple[str, str]],
        bam_specs: list[tuple[str, str]],
    ) -> SessionMeta | None:
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "UPDATE web_sessions SET vcf_specs = ?, bam_specs = ? WHERE id = ?",
                (_specs_to_json(vcf_specs), _specs_to_json(bam_specs), session_id),
            )
            if cur.rowcount == 0:
                return None
        return self.get(session_id)

    def set_name(self, session_id: str, name: str) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                "UPDATE web_sessions SET name = ? WHERE id = ?",
                (name, session_id),
            )

    def touch(self, session_id: str) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                "UPDATE web_sessions SET last_message_at = ? WHERE id = ?",
                (self._now(), session_id),
            )

    def delete(self, session_id: str) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM web_sessions WHERE id = ?", (session_id,))
        return cur.rowcount > 0

    @staticmethod
    def _row_to_meta(row: sqlite3.Row) -> SessionMeta:
        return SessionMeta(
            id=row["id"],
            name=row["name"],
            vcf_specs=_specs_from_json(row["vcf_specs"]),
            bam_specs=_specs_from_json(row["bam_specs"]),
            created_at=row["created_at"],
            last_message_at=row["last_message_at"],
        )


def _specs_to_json(specs: list[tuple[str, str]]) -> str:
    return json.dumps([{"alias": a, "path": p} for a, p in specs])


def _specs_from_json(raw: str) -> list[tuple[str, str]]:
    return [(s["alias"], s["path"]) for s in json.loads(raw)]
