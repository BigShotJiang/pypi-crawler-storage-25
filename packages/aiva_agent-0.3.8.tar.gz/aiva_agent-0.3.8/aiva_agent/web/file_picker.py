"""Walk the configured working directory and list VCF/BAM files for the UI's
session-creation form. Paths are returned relative to the workdir; the server
resolves them to absolute paths before storing or passing them to the agent.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from fastapi import HTTPException

from ..cli_specs import _has_bam_index

_VCF_SUFFIXES = (".vcf.gz", ".vcf.bgz", ".bcf")
_BAM_SUFFIXES = (".bam", ".cram")
_MAX_DEPTH = 6


@dataclass
class FileEntry:
    path: str
    name: str
    size: int
    has_index: bool

    def to_json(self) -> dict:
        return {
            "path": self.path,
            "name": self.name,
            "size": self.size,
            "has_index": self.has_index,
        }


def _matches(name: str, suffixes: tuple[str, ...]) -> bool:
    lower = name.lower()
    return any(lower.endswith(suf) for suf in suffixes)


def _has_vcf_index(path: Path) -> bool:
    return path.with_name(path.name + ".tbi").exists() or path.with_name(path.name + ".csi").exists()


def list_files(root: Path) -> dict[str, list[dict]]:
    root = root.resolve()
    vcfs: list[FileEntry] = []
    bams: list[FileEntry] = []
    others: list[FileEntry] = []
    for entry in _walk(root, _MAX_DEPTH):
        rel = Path(entry.path).relative_to(root).as_posix()
        try:
            stat = entry.stat(follow_symlinks=False)
        except OSError:
            continue
        if _matches(entry.name, _VCF_SUFFIXES):
            vcfs.append(FileEntry(rel, entry.name, stat.st_size, _has_vcf_index(Path(entry.path))))
        elif _matches(entry.name, _BAM_SUFFIXES):
            bams.append(FileEntry(rel, entry.name, stat.st_size, _has_bam_index(Path(entry.path))))
        elif _is_index_sidecar(entry.name):
            continue
        else:
            others.append(FileEntry(rel, entry.name, stat.st_size, False))
    vcfs.sort(key=lambda e: e.path)
    bams.sort(key=lambda e: e.path)
    others.sort(key=lambda e: e.path)
    return {
        "vcf": [e.to_json() for e in vcfs],
        "bam": [e.to_json() for e in bams],
        "other": [e.to_json() for e in others],
    }


_INDEX_SUFFIXES = (".tbi", ".csi", ".bai", ".crai")


def _is_index_sidecar(name: str) -> bool:
    lower = name.lower()
    return any(lower.endswith(suf) for suf in _INDEX_SUFFIXES)


def _walk(root: Path, max_depth: int):
    if not root.is_dir():
        return
    stack: list[tuple[Path, int]] = [(root, 0)]
    while stack:
        cur, depth = stack.pop()
        try:
            with os.scandir(cur) as it:
                children = list(it)
        except (PermissionError, OSError):
            continue
        for child in children:
            try:
                if child.is_symlink():
                    continue
                if child.is_dir(follow_symlinks=False):
                    if child.name.startswith("."):
                        continue
                    if depth + 1 <= max_depth:
                        stack.append((Path(child.path), depth + 1))
                    continue
                if child.is_file(follow_symlinks=False):
                    if child.name.startswith("."):
                        continue
                    yield child
            except OSError:
                continue


def resolve_under(root: Path, rel_path: str, *, must_exist: bool = True) -> Path:
    """Resolve a user-supplied relative path under root, refusing escape.

    Raises ValueError if the resolved path is outside root, or if
    `must_exist=True` and the path doesn't exist.

    With `must_exist=False` this function does NOT 404 on missing paths —
    it only enforces the escape check and returns the resolved Path. The
    caller is responsible for checking `is_file()` / `is_dir()` and raising
    its own 404. Used by download / delete handlers that distinguish
    "file vs dir" themselves and need a missing-file 404 from the
    operation, not this guard.
    """
    root = root.resolve()
    candidate = (root / rel_path).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as e:
        raise ValueError(f"path escapes workdir: {rel_path!r}") from e
    if must_exist and not candidate.exists():
        raise ValueError(f"file not found: {rel_path!r}")
    return candidate


def resolve_or_400(root: Path, rel_path: str, *, must_exist: bool = True) -> Path:
    """`resolve_under` that converts `ValueError` to `HTTPException(400)`. Used
    by route handlers so each one doesn't repeat the try/except."""
    try:
        return resolve_under(root, rel_path, must_exist=must_exist)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
