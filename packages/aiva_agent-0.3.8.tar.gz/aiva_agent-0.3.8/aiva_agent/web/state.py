"""Shared per-process state for the web UI.

The asyncio.Lock per session_id prevents two browser tabs from writing to the
same SQLiteSession concurrently — the SDK isn't built for parallel writers.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class WebState:
    workdir: Path
    model: str
    base_url: str | None
    api_key: str | None
    locks: dict[str, asyncio.Lock] = field(default_factory=dict)

    @property
    def aiva_dir(self) -> Path:
        return self.workdir / ".aiva"

    @property
    def session_db_path(self) -> Path:
        return self.aiva_dir / "sessions.db"

    @property
    def web_db_path(self) -> Path:
        return self.aiva_dir / "web_sessions.db"

    def lock_for(self, session_id: str) -> asyncio.Lock:
        lock = self.locks.get(session_id)
        if lock is None:
            lock = asyncio.Lock()
            self.locks[session_id] = lock
        return lock

    def drop_lock(self, session_id: str) -> None:
        self.locks.pop(session_id, None)
