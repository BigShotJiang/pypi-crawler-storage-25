"""Console-script entry: parse CLI args, build WebState, hand to uvicorn.

Lazily imports FastAPI/uvicorn so users who only use the terminal CLI don't
need the [web] extras installed.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from ..agent import DEFAULT_MODEL


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _workdir_from_env() -> Path | None:
    raw = os.environ.get("AIVA_WORKDIR", "").strip()
    return Path(raw) if raw else None


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aiva_agent_serve",
        description=(
            "Local web UI for aiva-agent. Pick a VCF/BAM from --workdir and chat with the agent. "
            "All flags fall back to env vars (AIVA_WORKDIR, AIVA_HOST, AIVA_PORT, "
            "LLM_MODEL, LLM_BASE_URL, LLM_API_KEY)."
        ),
    )
    parser.add_argument(
        "--workdir",
        type=Path,
        default=_workdir_from_env(),
        help=(
            "Folder the UI scans for VCF/BAM files, also the cwd for the agent's "
            "bash tool, and where session history is stored (under .aiva/). "
            "Falls back to AIVA_WORKDIR."
        ),
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("AIVA_HOST", "127.0.0.1"),
        help="Falls back to AIVA_HOST. Default: 127.0.0.1.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=_env_int("AIVA_PORT", 8765),
        help="Falls back to AIVA_PORT. Default: 8765.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("LLM_MODEL", DEFAULT_MODEL),
        help="Model ID; same semantics as the CLI's --model. Falls back to LLM_MODEL.",
    )
    parser.add_argument(
        "--base-url",
        default=None,
        help="OpenAI-compatible endpoint base URL. Falls back to LLM_BASE_URL.",
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help="API key. Falls back to LLM_API_KEY (preferred to keep it out of shell history).",
    )
    parser.add_argument("--reload", action="store_true")
    return parser


def main() -> int:
    load_dotenv(override=False)
    args = _build_arg_parser().parse_args()

    if args.workdir is None:
        print(
            "ERROR: --workdir is required (or set AIVA_WORKDIR in your env / .env).",
            file=sys.stderr,
        )
        return 2

    workdir = args.workdir.resolve()
    if not workdir.exists() or not workdir.is_dir():
        print(f"ERROR: --workdir does not exist or is not a directory: {workdir}", file=sys.stderr)
        return 2

    try:
        import uvicorn

        from .state import WebState
    except ModuleNotFoundError as e:
        print(
            f"ERROR: missing web dependency ({e.name}). Install with: pip install 'aiva-agent[web]'",
            file=sys.stderr,
        )
        return 2

    state = WebState(
        workdir=workdir,
        model=args.model,
        base_url=args.base_url,
        api_key=args.api_key,
    )
    state.aiva_dir.mkdir(parents=True, exist_ok=True)

    if args.reload:
        os.environ["AIVA_WORKDIR"] = str(workdir)
        uvicorn.run(
            "aiva_agent.web.serve:_reload_app",
            host=args.host,
            port=args.port,
            reload=True,
            factory=True,
        )
        return 0

    from .app import create_app

    app = create_app(state)
    print(f"aiva web UI on http://{args.host}:{args.port}  (workdir={workdir})", file=sys.stderr)
    uvicorn.run(app, host=args.host, port=args.port)
    return 0


def _reload_app():
    """Factory used only by --reload. Reads paths/creds from env so uvicorn's
    spawned worker can rebuild WebState without losing the CLI args.
    """
    from .app import create_app
    from .state import WebState

    state = WebState(
        workdir=Path(os.environ["AIVA_WORKDIR"]),
        model=os.environ.get("LLM_MODEL", DEFAULT_MODEL),
        base_url=os.environ.get("LLM_BASE_URL"),
        api_key=os.environ.get("LLM_API_KEY"),
    )
    state.aiva_dir.mkdir(parents=True, exist_ok=True)
    return create_app(state)


if __name__ == "__main__":
    sys.exit(main())
