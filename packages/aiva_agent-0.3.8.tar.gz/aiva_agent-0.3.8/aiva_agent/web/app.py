"""FastAPI app factory. Mounts all routers, static files, and Jinja
templates. The created app holds a single shared `WebState` on `app.state.aiva`.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .meta_store import MetaStore
from .routes_files import router as files_router
from .routes_messages import router as messages_router
from .routes_pages import router as pages_router
from .routes_sessions import router as sessions_router
from .routes_workdir import router as workdir_router
from .state import WebState

_HERE = Path(__file__).resolve().parent


def create_app(state: WebState) -> FastAPI:
    app = FastAPI(title="aiva-agent web", docs_url=None, redoc_url=None)
    app.state.aiva = state
    app.state.meta_store = MetaStore(state.web_db_path)
    app.state.templates = Jinja2Templates(directory=str(_HERE / "templates"))

    app.mount("/static", StaticFiles(directory=str(_HERE / "static")), name="static")
    app.include_router(pages_router)
    app.include_router(files_router)
    app.include_router(sessions_router)
    app.include_router(messages_router)
    app.include_router(workdir_router)
    return app
