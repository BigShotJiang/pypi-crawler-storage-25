"""SSE plumbing: format an event dict as `event:`/`data:` lines, and adapt
an asyncio.Queue into an async generator suitable for StreamingResponse.

The queue uses `None` as a sentinel meaning "no more events". The producer
(routes_messages) is responsible for enqueuing the sentinel after the
runner finishes or errors.
"""

from __future__ import annotations

import asyncio
import json
from typing import AsyncIterator


def format_sse(event_type: str, payload: dict | None = None) -> bytes:
    body = json.dumps(payload or {}, separators=(",", ":"))
    return f"event: {event_type}\ndata: {body}\n\n".encode("utf-8")


async def queue_to_sse(queue: asyncio.Queue) -> AsyncIterator[bytes]:
    while True:
        item = await queue.get()
        if item is None:
            return
        event_type, payload = item
        yield format_sse(event_type, payload)
