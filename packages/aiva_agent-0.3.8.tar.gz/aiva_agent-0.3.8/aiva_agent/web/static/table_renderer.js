// Render structured tool tables (genomiq display envelope) and expand
// [TABLE:tbl_xxx] citations in assistant prose into inline tables.
//
// Cells go through textContent so DOMPurify isn't needed for the table
// itself. Citation expansion runs after the assistant markdown is
// already sanitized by the caller, so this file only manipulates DOM
// text that originated from sanitized HTML.

const _TABLE_CACHE = new Map();
const _TABLE_CITE_RE = /\[TABLE:(tbl_[a-f0-9]+)\]/g;

function formatToolCell(value) {
  if (value === null || value === undefined) return "null";
  if (Array.isArray(value)) return JSON.stringify(value);
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

// RFC-4180-ish CSV escape: wrap any field containing comma/quote/CR/LF in
// double quotes, doubling internal quotes. Empty stays empty.
function csvEscape(s) {
  const v = String(s ?? "");
  return /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
}

function buildTableCsv(cols, rows) {
  const head = cols.map(csvEscape).join(",");
  const body = rows
    .map((r) => cols.map((c) => csvEscape(formatToolCell(r[c]))).join(","))
    .join("\n");
  return body ? head + "\n" + body + "\n" : head + "\n";
}

function downloadCsv(filename, csvText) {
  const blob = new Blob([csvText], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function appendToolTable(target, display, tableId) {
  const data = (display && display.data) || { columns: [], rows: [] };
  const cols = data.columns || [];
  const rows = data.rows || [];

  const wrap = document.createElement("div");
  wrap.className = "tool-table-wrap";
  if (tableId) wrap.id = tableId;

  const tbl = document.createElement("table");
  tbl.className = "tool-table";

  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  for (const c of cols) {
    const th = document.createElement("th");
    th.textContent = c;
    headRow.appendChild(th);
  }
  thead.appendChild(headRow);
  tbl.appendChild(thead);

  const tbody = document.createElement("tbody");
  for (const r of rows) {
    const tr = document.createElement("tr");
    for (const c of cols) {
      const td = document.createElement("td");
      td.textContent = formatToolCell(r[c]);
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
  tbl.appendChild(tbody);
  wrap.appendChild(tbl);
  target.appendChild(wrap);

  const meta = document.createElement("div");
  meta.className = "tool-table-meta";
  const label = document.createElement("span");
  const idPart = tableId ? `[TABLE:${tableId}] · ` : "";
  label.textContent = `${idPart}${rows.length} row${rows.length === 1 ? "" : "s"}`;
  meta.appendChild(label);
  if (rows.length > 0) {
    const dl = document.createElement("button");
    dl.type = "button";
    dl.className = "tool-table-download";
    dl.textContent = "download CSV";
    dl.addEventListener("click", () => {
      downloadCsv(`${tableId || "table"}.csv`, buildTableCsv(cols, rows));
    });
    meta.appendChild(dl);
  }
  target.appendChild(meta);
}

function rememberTable(tableId, display) {
  if (tableId && display) _TABLE_CACHE.set(tableId, display);
}

// Drop every cached table. Call before re-populating from a session
// reload so the cache doesn't grow unbounded as the user switches chats.
function clearTableCache() {
  _TABLE_CACHE.clear();
}

// Rewrite [TABLE:tbl_xxx] tokens to markdown links so marked.parse turns
// them into anchors that expandTableCites can find post-render.
function rewriteTableCitations(text) {
  return (text || "").replace(_TABLE_CITE_RE, "[$1](#$1)");
}

// After assistant markdown is sanitized and inserted, swap each citation
// link for an inline-rendered table from the cache. Unknown ids stay as
// links so the user still sees the citation text.
function expandTableCites(rootEl) {
  const links = rootEl.querySelectorAll('a[href^="#tbl_"]');
  for (const a of links) {
    const id = a.getAttribute("href").slice(1);
    const display = _TABLE_CACHE.get(id);
    if (!display) continue;
    const block = document.createElement("div");
    block.className = "inline-table-block";
    appendToolTable(block, display, null);
    a.replaceWith(block);
  }
}

window.appendToolTable = appendToolTable;
window.rememberTable = rememberTable;
window.clearTableCache = clearTableCache;
window.rewriteTableCitations = rewriteTableCitations;
window.expandTableCites = expandTableCites;
