// Bindings modal: two-pane attach picker (attached / available).
// Loaded as a classic script after sessions.js — shares top-level scope
// (`state`, `$`, `renderHeader`, `refreshSessions`, `loadFiles`, `apiJson`,
//  `ALIAS_RE`, `MAX_ALIAS_LEN` are not defined elsewhere; the alias rules
//  here are intentionally a JS-side mirror of tools/_shared.py).

const ALIAS_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;
const ALIAS_MAX = 32;

// Local-to-dialog state. Rebuilt on every open from session meta.
//   attached: Map<path, {kind: "vcf"|"bam", alias: string, name: string, has_index: bool, displayPath}>
//   filter:   { query: string, kind: "all"|"vcf"|"bam" }
const pickerState = {
  attached: new Map(),
  filter: { query: "", kind: "all" },
};

async function openBindingsDialog() {
  await loadFiles();
  resetPickerState();
  renderAttached();
  renderAvailable();
  $("#bindings-dialog").showModal();
  $("#bindings-search").focus();
}

function resetPickerState() {
  pickerState.attached.clear();
  pickerState.filter.query = "";
  pickerState.filter.kind = "all";
  const search = $("#bindings-search");
  if (search) search.value = "";
  for (const btn of document.querySelectorAll(".bindings-filter-btn")) {
    btn.classList.toggle("active", btn.dataset.filter === "all");
  }
  const meta = state.currentMeta;
  if (meta) {
    for (const b of meta.vcf_specs) addAttachedFromMeta(b, "vcf");
    for (const b of meta.bam_specs) addAttachedFromMeta(b, "bam");
    return;
  }
  for (const b of state.pendingSpecs.vcf) addAttachedFromMeta(b, "vcf");
  for (const b of state.pendingSpecs.bam) addAttachedFromMeta(b, "bam");
}

function addAttachedFromMeta(b, kind) {
  const match = matchKnownFile(b.path);
  const displayPath = match ? match.path : b.path;
  const name = match ? match.name : b.path.split("/").pop();
  const hasIndex = match ? match.has_index : true;
  pickerState.attached.set(b.path, {
    kind,
    alias: b.alias,
    name,
    has_index: hasIndex,
    displayPath,
  });
}

function matchKnownFile(absOrRel) {
  const all = [...(state.files.vcf || []), ...(state.files.bam || [])];
  for (const f of all) if (f.path === absOrRel) return f;
  // Absolute path stored on the session may end with a known relative path.
  for (const f of all) if (absOrRel.endsWith("/" + f.path)) return f;
  return null;
}

function renderAttached() {
  const host = $("#bindings-attached");
  host.replaceChildren();
  const byKind = { vcf: [], bam: [] };
  for (const [path, info] of pickerState.attached) byKind[info.kind].push({ path, ...info });
  byKind.vcf.sort((a, b) => a.path.localeCompare(b.path));
  byKind.bam.sort((a, b) => a.path.localeCompare(b.path));
  buildAttachedGroup(host, "VCF", "vcf", byKind.vcf);
  buildAttachedGroup(host, "BAM", "bam", byKind.bam);
  $("#bindings-attached-count").textContent = String(pickerState.attached.size);
}

function buildAttachedGroup(host, label, kind, items) {
  const wrap = document.createElement("div");
  wrap.className = "bindings-group";
  const head = document.createElement("div");
  head.className = "bindings-group-label";
  head.textContent = label;
  wrap.appendChild(head);
  if (items.length === 0) {
    const empty = document.createElement("div");
    empty.className = "bindings-group-empty";
    empty.textContent = "—";
    wrap.appendChild(empty);
    host.appendChild(wrap);
    return;
  }
  for (const item of items) {
    wrap.appendChild(buildAttachedRow(item));
  }
  host.appendChild(wrap);
}

function buildPathSpan(className, path, hasIndex) {
  const span = document.createElement("span");
  span.className = className;
  span.title = path;
  span.textContent = path;
  if (!hasIndex) {
    const idx = document.createElement("span");
    idx.className = "binding-noindex";
    idx.textContent = " (no index)";
    span.appendChild(idx);
  }
  return span;
}

function buildAttachedRow(item) {
  const row = document.createElement("div");
  row.className = "attached-row";
  row.dataset.path = item.path;

  const displayPath = item.displayPath || item.path;
  const path = buildPathSpan("attached-path", displayPath, item.has_index);
  // displayPath is the picker-friendly relative path; the real session-stored
  // path (which may be absolute) is the tooltip.
  path.title = item.path;

  const alias = document.createElement("input");
  alias.type = "text";
  alias.className = "attached-alias";
  alias.value = item.alias;
  alias.placeholder = deriveAlias(displayPath);
  alias.maxLength = ALIAS_MAX;
  alias.spellcheck = false;
  alias.autocomplete = "off";
  alias.setAttribute("aria-label", `alias for ${item.path}`);
  alias.addEventListener("input", () => {
    const entry = pickerState.attached.get(item.path);
    if (entry) entry.alias = alias.value;
  });

  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "attached-remove";
  remove.setAttribute("aria-label", `detach ${item.path}`);
  remove.title = "detach";
  remove.textContent = "×";
  remove.addEventListener("click", () => {
    pickerState.attached.delete(item.path);
    renderAttached();
    renderAvailable();
  });

  row.append(path, alias, remove);
  return row;
}

function filteredGroups() {
  const q = pickerState.filter.query.trim().toLowerCase();
  const kind = pickerState.filter.kind;
  const groups = [];
  if (kind === "all" || kind === "vcf") groups.push({ label: "VCF", kind: "vcf", all: state.files.vcf || [] });
  if (kind === "all" || kind === "bam") groups.push({ label: "BAM", kind: "bam", all: state.files.bam || [] });
  for (const g of groups) {
    g.items = q ? g.all.filter((f) => f.path.toLowerCase().includes(q)) : g.all;
  }
  return groups;
}

function renderAvailable() {
  const host = $("#bindings-available");
  host.replaceChildren();
  const groups = filteredGroups();
  let totalShown = 0;
  for (const g of groups) {
    totalShown += g.items.length;
    host.appendChild(buildAvailableGroup(g.label, g.kind, g.items, g.all.length));
  }
  if (totalShown === 0) {
    const empty = document.createElement("div");
    empty.className = "bindings-available-empty";
    const q = pickerState.filter.query.trim();
    empty.textContent = q ? `no files match "${q}"` : "no files in data dir";
    host.appendChild(empty);
  }
  updateSelectAllButton(groups);
}

function updateSelectAllButton(groups) {
  const btn = $("#bindings-select-all");
  if (!btn) return;
  let addable = 0;
  for (const g of groups) {
    for (const f of g.items) if (!pickerState.attached.has(f.path)) addable++;
  }
  btn.disabled = addable === 0;
  btn.textContent = addable > 0 ? `Select all (${addable})` : "Select all";
}

function selectAllFiltered() {
  const groups = filteredGroups();
  const taken = new Set();
  for (const info of pickerState.attached.values()) taken.add(info.alias.toLowerCase());
  let added = 0;
  for (const g of groups) {
    for (const f of g.items) {
      if (pickerState.attached.has(f.path)) continue;
      const alias = uniqueAlias(deriveAlias(f.path), taken);
      taken.add(alias.toLowerCase());
      pickerState.attached.set(f.path, {
        kind: g.kind,
        alias,
        name: f.name,
        has_index: f.has_index,
        displayPath: f.path,
      });
      added++;
    }
  }
  if (added === 0) return;
  renderAttached();
  renderAvailable();
}

function uniqueAlias(base, taken) {
  let alias = base;
  let n = 2;
  while (taken.has(alias.toLowerCase())) {
    const suffix = `_${n++}`;
    alias = base.slice(0, ALIAS_MAX - suffix.length) + suffix;
  }
  return alias;
}

function buildAvailableGroup(label, kind, items, total) {
  const wrap = document.createElement("div");
  wrap.className = "bindings-group";
  const head = document.createElement("div");
  head.className = "bindings-group-label";
  const labelSpan = document.createElement("span");
  labelSpan.textContent = label;
  const countSpan = document.createElement("span");
  countSpan.className = "bindings-group-count";
  countSpan.textContent = items.length === total ? String(total) : `${items.length} / ${total}`;
  head.append(labelSpan, countSpan);
  wrap.appendChild(head);
  if (items.length === 0) {
    const empty = document.createElement("div");
    empty.className = "bindings-group-empty";
    empty.textContent = "—";
    wrap.appendChild(empty);
    return wrap;
  }
  for (const f of items) wrap.appendChild(buildAvailableRow(f, kind));
  return wrap;
}

function buildAvailableRow(f, kind) {
  const row = document.createElement("div");
  row.className = "available-row";
  const isAttached = pickerState.attached.has(f.path);
  if (isAttached) row.classList.add("is-attached");

  const add = document.createElement("button");
  add.type = "button";
  add.className = "available-add";
  add.title = isAttached ? "already attached" : "attach";
  add.setAttribute("aria-label", isAttached ? `${f.path} already attached` : `attach ${f.path}`);
  add.textContent = isAttached ? "✓" : "+";
  add.disabled = isAttached;
  add.addEventListener("click", () => attachFile(f, kind));

  const path = buildPathSpan("available-path", f.path, f.has_index);
  row.append(add, path);
  return row;
}

function attachFile(f, kind) {
  if (pickerState.attached.has(f.path)) return;
  pickerState.attached.set(f.path, {
    kind,
    alias: deriveAlias(f.path),
    name: f.name,
    has_index: f.has_index,
    displayPath: f.path,
  });
  renderAttached();
  renderAvailable();
  focusAttachedAlias(f.path, { select: true });
}

// CSS.escape has been baseline-available in every modern browser since 2016;
// a hand-rolled fallback only escapes a subset of metacharacters and silently
// breaks selectors for paths containing `[`, `]`, `.`, `:`, spaces, etc.
const cssEscape = (s) => CSS.escape(s);

function onSearchInput(e) {
  pickerState.filter.query = e.target.value;
  renderAvailable();
}

function onFilterClick(e) {
  const btn = e.target.closest(".bindings-filter-btn");
  if (!btn) return;
  pickerState.filter.kind = btn.dataset.filter;
  for (const b of document.querySelectorAll(".bindings-filter-btn")) {
    b.classList.toggle("active", b === btn);
  }
  renderAvailable();
}

async function onBindingsSave(e) {
  e.preventDefault();
  const vcf = [];
  const bam = [];
  const seen = new Set();
  for (const [path, info] of pickerState.attached) {
    const alias = info.alias.trim();
    if (!ALIAS_RE.test(alias) || alias.length > ALIAS_MAX) {
      alert(`Invalid alias "${alias}" for ${path}. Use letters, digits, and underscores; start with letter/underscore; max ${ALIAS_MAX}.`);
      focusAttachedAlias(path);
      return;
    }
    if (seen.has(alias.toLowerCase())) {
      alert(`Duplicate alias: ${alias}`);
      focusAttachedAlias(path);
      return;
    }
    seen.add(alias.toLowerCase());
    (info.kind === "vcf" ? vcf : bam).push({ alias, path });
  }
  if (state.currentId) {
    await patchBindings(vcf, bam);
  } else {
    state.pendingSpecs = { vcf, bam };
    refreshBindingChips();
  }
  $("#bindings-dialog").close();
}

function focusAttachedAlias(path, { select = false } = {}) {
  const row = document.querySelector(`#bindings-attached .attached-row[data-path="${cssEscape(path)}"]`);
  if (!row) return;
  const input = row.querySelector(".attached-alias");
  if (!input) return;
  input.focus();
  if (select) input.select();
}

function detachBinding(alias, kind) {
  const meta = state.currentMeta;
  if (!meta) {
    const bucket = kind === "vcf" ? "vcf" : "bam";
    state.pendingSpecs[bucket] = state.pendingSpecs[bucket].filter((b) => b.alias !== alias);
    refreshBindingChips();
    return;
  }
  const vcf = meta.vcf_specs
    .filter((b) => !(kind === "vcf" && b.alias === alias))
    .map((b) => ({ alias: b.alias, path: b.path }));
  const bam = meta.bam_specs
    .filter((b) => !(kind === "bam" && b.alias === alias))
    .map((b) => ({ alias: b.alias, path: b.path }));
  patchBindings(vcf, bam);
}

async function patchBindings(vcf, bam) {
  const id = state.currentId;
  if (!id) return;
  const res = await apiJson(`/sessions/${encodeURIComponent(id)}/bindings`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ vcf, bam }),
  });
  if (!res) return;
  const meta = await res.json();
  renderHeader(meta);
  refreshSessions();
}

function deriveAlias(path) {
  const base = path.split("/").pop().split(".")[0] || "f";
  let s = base.replace(/[^A-Za-z0-9_]/g, "_");
  if (!/^[A-Za-z_]/.test(s)) s = "f_" + s;
  return s.slice(0, ALIAS_MAX);
}
