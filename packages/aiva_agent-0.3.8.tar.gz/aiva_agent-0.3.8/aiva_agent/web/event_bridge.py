"""Translate SDK StreamEvents into SSE event tuples on a queue.

Sister to `cli_streaming._make_stream_renderer`; both switch on the same
event types but write to different sinks (queue vs stdout/stderr) and the
web emits structured payloads with `call_id` for pairing.
"""

from __future__ import annotations

import asyncio
import json
from typing import Callable

from ..tools._shared import (
    extract_display,
    extract_tool_summary,
    tool_call_arguments,
    truncate_tool_output,
)


def make_event_handler(queue: asyncio.Queue) -> Callable[[object], None]:
    from agents.stream_events import RawResponsesStreamEvent, RunItemStreamEvent
    from openai.types.responses import ResponseTextDeltaEvent

    def handler(event: object) -> None:
        if isinstance(event, RawResponsesStreamEvent):
            data = event.data
            if isinstance(data, ResponseTextDeltaEvent) and data.delta:
                queue.put_nowait(("token", {"delta": data.delta}))
            return
        if isinstance(event, RunItemStreamEvent):
            item = event.item
            item_type = getattr(item, "type", None)
            if item_type == "tool_call_item":
                queue.put_nowait(("tool_start", _tool_start_payload(item)))
            elif item_type == "tool_call_output_item":
                queue.put_nowait(("tool_end", _tool_end_payload(item)))

    return handler


def _tool_start_payload(item: object) -> dict:
    return {
        "call_id": _call_id(item),
        "tool_name": getattr(item, "tool_name", None) or "tool",
        "summary": extract_tool_summary(tool_call_arguments(item)),
    }


def _tool_end_payload(item: object) -> dict:
    output = getattr(item, "output", None)
    raw = _stringify_output(output)
    envelope = extract_display(raw)
    if envelope is not None:
        return {
            "call_id": _call_id(item),
            "table_id": envelope.get("table_id"),
            "display": envelope["display"],
            "message": envelope.get("message"),
        }
    text, truncated = truncate_tool_output(raw)
    return {
        "call_id": _call_id(item),
        "output_preview": text,
        "truncated": truncated,
    }


def _call_id(item: object) -> str | None:
    cid = getattr(item, "call_id", None)
    if cid:
        return cid
    raw = getattr(item, "raw_item", None)
    if raw is None:
        return None
    if isinstance(raw, dict):
        return raw.get("call_id")
    return getattr(raw, "call_id", None)


def _stringify_output(output: object) -> str:
    if output is None:
        return ""
    if isinstance(output, str):
        return output
    try:
        return json.dumps(output, default=str)
    except (TypeError, ValueError):
        return str(output)
