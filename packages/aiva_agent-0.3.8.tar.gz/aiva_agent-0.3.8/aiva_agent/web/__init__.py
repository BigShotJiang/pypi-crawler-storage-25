"""Local web UI for aiva-agent. Opt-in: requires the [web] extra.

The CLI (`aiva_agent`) does not import this package, so users who only use
the terminal don't need fastapi/uvicorn installed.
"""

from .app import create_app
from .state import WebState

__all__ = ["create_app", "WebState"]
