"""GET /files — list files under the configured workdir.

Also exposes GET /files/download and DELETE /files for individual files.
All paths are resolved under the workdir; escape attempts are rejected.

These endpoints have no auth. The server binds to 127.0.0.1 by default
(see serve.py) and assumes a trusted local context. If that changes,
add auth before exposing /files/download or DELETE /files.
"""

from __future__ import annotations

import asyncio
import mimetypes
import os
import shutil
import zipfile
from collections.abc import Iterator
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import FileResponse, Response, StreamingResponse

from .file_picker import list_files, resolve_or_400

router = APIRouter()


def _content_disposition(filename: str) -> str:
    # RFC 5987: ASCII fallback + UTF-8 `filename*` so non-ASCII / quoted names
    # survive the round-trip to the browser.
    ascii_fallback = filename.encode("ascii", "replace").decode("ascii").replace('"', "")
    return f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{quote(filename)}'


@router.get("/files")
async def files(request: Request):
    state = request.app.state.aiva
    return await asyncio.to_thread(list_files, state.workdir)


@router.get("/files/download")
async def download_file(request: Request, path: str = Query(...)):
    state = request.app.state.aiva
    resolved = resolve_or_400(state.workdir, path, must_exist=False)
    if resolved.is_file():
        media_type, encoding = mimetypes.guess_type(resolved.name)
        # For compressed bioinformatics files (foo.vcf.gz, foo.bcf.gz),
        # mimetypes returns the *inner* type (text/x-vcard for .vcf!) plus an
        # encoding hint. Surface the encoding as the actual type so browsers
        # don't try to render a gzip blob as text.
        if encoding == "gzip":
            media_type = "application/gzip"
        return FileResponse(
            path=str(resolved),
            filename=resolved.name,
            media_type=media_type or "application/octet-stream",
            headers={"Content-Disposition": _content_disposition(resolved.name)},
        )
    if resolved.is_dir():
        zip_name = f"{resolved.name}.zip"
        return StreamingResponse(
            _stream_zip(resolved),
            media_type="application/zip",
            headers={"Content-Disposition": _content_disposition(zip_name)},
        )
    raise HTTPException(status_code=404, detail="path not found")


@router.delete("/files")
async def delete_file(request: Request, path: str = Query(...)):
    state = request.app.state.aiva
    resolved = resolve_or_400(state.workdir, path, must_exist=False)
    if resolved == state.workdir.resolve():
        raise HTTPException(status_code=400, detail="refusing to delete workdir root")
    try:
        if resolved.is_dir():
            await asyncio.to_thread(shutil.rmtree, resolved)
        else:
            await asyncio.to_thread(os.unlink, resolved)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail="path not found") from e
    return Response(status_code=204)


_ZIP_CHUNK = 1 << 20  # 1 MiB


def _stream_zip(root: Path) -> Iterator[bytes]:
    # Stream the zip out incrementally so we never buffer the whole archive in
    # memory. ZIP_STORED + chunked zf.open writes mean a multi-GB BAM/FASTQ
    # never lands in memory whole — `ZipFile.write(fp)` would compress the
    # entire file synchronously before any drain. Genomic files are already
    # compressed (.bam, .vcf.gz), so ZIP_STORED costs ~nothing.
    buf = _ZipBuffer()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED, allowZip64=True) as zf:
        for dirpath, _dirs, filenames in os.walk(root, followlinks=False):
            for name in filenames:
                fp = Path(dirpath) / name
                if fp.is_symlink():
                    continue
                arcname = fp.relative_to(root.parent).as_posix()
                with fp.open("rb") as src, zf.open(arcname, "w", force_zip64=True) as dst:
                    while True:
                        chunk = src.read(_ZIP_CHUNK)
                        if not chunk:
                            break
                        dst.write(chunk)
                        yield buf.drain()
                yield buf.drain()
    yield buf.drain()


class _ZipBuffer:
    """File-like sink ZipFile writes into; `drain()` returns and clears the
    accumulated bytes."""

    def __init__(self) -> None:
        self._chunks: list[bytes] = []
        self._pos = 0

    def write(self, data: bytes) -> int:
        self._chunks.append(data)
        self._pos += len(data)
        return len(data)

    def tell(self) -> int:
        return self._pos

    def flush(self) -> None:
        pass

    def drain(self) -> bytes:
        out = b"".join(self._chunks)
        self._chunks.clear()
        return out
