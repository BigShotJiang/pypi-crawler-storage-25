"""Session CRUD: list / create / read history / delete."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel, Field

from ..tools._shared import ALIAS_RE, MAX_ALIAS_LEN, RESERVED_ALIASES
from .file_picker import resolve_or_400
from .history import normalize_history_item, open_sqlite_session

router = APIRouter()


class _SpecIn(BaseModel):
    alias: str
    path: str  # path relative to data_dir


class _CreateSession(BaseModel):
    name: str | None = None
    vcf: list[_SpecIn] = Field(default_factory=list)
    bam: list[_SpecIn] = Field(default_factory=list)


class _PatchBindings(BaseModel):
    vcf: list[_SpecIn] = Field(default_factory=list)
    bam: list[_SpecIn] = Field(default_factory=list)


@router.get("/sessions")
async def list_sessions(request: Request):
    return [m.to_json() for m in request.app.state.meta_store.list_all()]


@router.post("/sessions")
async def create_session(request: Request, body: _CreateSession):
    state = request.app.state.aiva
    vcf_specs = _validate_specs(state.workdir, body.vcf, forbid_long=True)
    bam_specs = _validate_specs(state.workdir, body.bam, forbid_long=False)

    meta = request.app.state.meta_store.create(
        name=body.name.strip() if body.name else None,
        vcf_specs=vcf_specs,
        bam_specs=bam_specs,
    )
    return meta.to_json()


@router.get("/sessions/{session_id}")
async def get_session(request: Request, session_id: str):
    meta = request.app.state.meta_store.get(session_id)
    if meta is None:
        raise HTTPException(404, "session not found")
    history = await _read_history(request.app.state.aiva, session_id)
    return {"meta": meta.to_json(), "history": history}


@router.patch("/sessions/{session_id}/bindings")
async def patch_bindings(request: Request, session_id: str, body: _PatchBindings):
    state = request.app.state.aiva
    meta_store = request.app.state.meta_store
    if meta_store.get(session_id) is None:
        raise HTTPException(404, "session not found")
    vcf_specs = _validate_specs(state.workdir, body.vcf, forbid_long=True)
    bam_specs = _validate_specs(state.workdir, body.bam, forbid_long=False)
    meta = meta_store.update_specs(session_id, vcf_specs=vcf_specs, bam_specs=bam_specs)
    if meta is None:
        raise HTTPException(404, "session not found")
    return meta.to_json()


@router.delete("/sessions/{session_id}", status_code=204)
async def delete_session(request: Request, session_id: str):
    state = request.app.state.aiva
    existed = request.app.state.meta_store.delete(session_id)
    if not existed:
        raise HTTPException(404, "session not found")
    async with open_sqlite_session(str(state.session_db_path), session_id) as session:
        await session.clear_session()
    state.drop_lock(session_id)
    return Response(status_code=204)


def _validate_specs(root, specs: list[_SpecIn], *, forbid_long: bool) -> list[tuple[str, str]]:
    seen: set[str] = set()
    out: list[tuple[str, str]] = []
    for s in specs:
        alias = s.alias.strip()
        if not alias or len(alias) > MAX_ALIAS_LEN or not ALIAS_RE.match(alias):
            raise HTTPException(400, f"invalid alias: {alias!r}")
        if alias.lower() in RESERVED_ALIASES:
            raise HTTPException(400, f"reserved alias: {alias!r}")
        if forbid_long and alias.lower().endswith("_long"):
            raise HTTPException(400, f"alias may not end with '_long': {alias!r}")
        if alias.lower() in seen:
            raise HTTPException(400, f"duplicate alias: {alias!r}")
        seen.add(alias.lower())
        resolved = resolve_or_400(root, s.path)
        out.append((alias, str(resolved)))
    return out


async def _read_history(state, session_id: str) -> list[dict[str, Any]]:
    async with open_sqlite_session(str(state.session_db_path), session_id) as session:
        items = await session.get_items()
    rendered: list[dict[str, Any]] = []
    for it in items:
        norm = normalize_history_item(it)
        if norm is not None:
            rendered.append(norm)
    return rendered
