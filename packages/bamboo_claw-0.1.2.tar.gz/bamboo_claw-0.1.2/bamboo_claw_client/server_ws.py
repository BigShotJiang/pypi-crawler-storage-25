"""WebSocket transport for the Bamboo Claw central server."""

from __future__ import annotations

import asyncio
import json
import logging
import platform
from typing import Awaitable, Callable, Optional

from websockets import connect as ws_connect
from websockets.exceptions import ConnectionClosed, WebSocketException

logger = logging.getLogger(__name__)

STATUS_INTERVAL = 30
MAX_BACKOFF = 60


class ServerConnection:
    """Persistent authenticated websocket client for Bamboo Claw."""

    def __init__(
        self,
        server_url: str,
        token: str,
        client_id: str = "",
        hostname: str = "",
    ):
        self.server_url = server_url
        self.token = token
        self.client_id = client_id
        self.hostname = hostname or platform.node()
        self.ws = None
        self.connected = False
        self._status_task: asyncio.Task | None = None
        self._status_provider: Callable[[], dict] | None = None

    async def connect(self) -> str:
        """Connect and authenticate with the server. Returns assigned client_id."""
        from bamboo_claw_client.config import build_server_ws_url

        url = build_server_ws_url(self.server_url)
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self.client_id:
            headers["X-Client-Id"] = self.client_id

        try:
            self.ws = await ws_connect(
                url,
                additional_headers=headers,
                ping_interval=None,
                ping_timeout=None,
            )
        except (OSError, WebSocketException) as exc:
            raise Exception(f"Failed to connect to server at {self.server_url}: {exc}")

        welcome = await self._receive()
        if welcome.get("type") == "error":
            message = welcome.get("message", "Authentication failed")
            await self.ws.close()
            self.ws = None
            raise Exception(f"Server rejected connection: {message}")
        if welcome.get("type") != "welcome":
            raise Exception(f"Expected welcome, got: {welcome.get('type')}")

        self.client_id = welcome.get("client_id", self.client_id)
        self.connected = True
        return self.client_id

    async def register(
        self,
        *,
        capabilities: list[dict],
        connectivity: dict,
        runtime_health: dict,
        gateway_info: dict | None = None,
        resources: dict | None = None,
    ) -> None:
        """Send post-connect registration with capabilities and runtime health."""
        payload = self._build_status_payload(
            message_type="register",
            capabilities=capabilities,
            connectivity=connectivity,
            runtime_health=runtime_health,
            gateway_info=gateway_info,
            resources=resources,
        )
        await self._send(payload)

        response = await self._receive()
        if response.get("type") != "registered":
            raise Exception(f"Registration failed: {response}")
        logger.info("Registered with server as %s", self.client_id)

    async def send_client_status(
        self,
        *,
        capabilities: list[dict],
        connectivity: dict,
        runtime_health: dict,
        reason: str = "heartbeat",
        gateway_info: dict | None = None,
        resources: dict | None = None,
    ) -> None:
        payload = self._build_status_payload(
            message_type="client_status",
            capabilities=capabilities,
            connectivity=connectivity,
            runtime_health=runtime_health,
            gateway_info=gateway_info,
            resources=resources,
        )
        payload["reason"] = reason
        await self._send(payload)

    async def start_status_updates(self, status_provider: Callable[[], dict]) -> None:
        self._status_provider = status_provider
        self._status_task = asyncio.create_task(self._status_loop())

    async def start_heartbeat(self) -> None:
        """Compatibility shim for older tests/callers."""
        async def _empty() -> dict:
            return {
                "capabilities": [],
                "connectivity": {},
                "runtime_health": {"active_jobs": 0, "queued_jobs": 0, "max_concurrent_jobs": 1},
            }

        await self.start_status_updates(_empty)

    async def send_job_event(self, job_event: dict) -> None:
        await self._send({"type": "job_event", **job_event})

    async def send_job_result(self, job_result: dict) -> None:
        await self._send({"type": "job_result", **job_result})

    async def send_job_query_result(
        self,
        query_id: str,
        *,
        ok: bool,
        result: dict | None = None,
        error: str | None = None,
    ) -> None:
        payload = {"type": "job_query_result", "query_id": query_id, "ok": ok}
        if result is not None:
            payload["result"] = result
        if error is not None:
            payload["error"] = error
        await self._send(payload)

    async def send_chat_event(self, request_id: str, payload: dict):
        """Legacy compatibility for staged server rollout."""
        await self._send({"type": "chat_event", "request_id": request_id, "payload": payload})

    async def send_command_result(self, request_id: str, ok: bool, result=None, error=None):
        payload = {"type": "command_result", "id": request_id, "ok": ok}
        if result is not None:
            payload["result"] = result
        if error is not None:
            payload["error"] = error
        await self._send(payload)

    async def send_gateway_status(self, connected: bool):
        await self._send({"type": "gateway_status", "connected": connected})

    async def listen(self, on_message: Callable[[dict], Awaitable[None]]):
        """Listen for incoming authenticated messages from the server."""
        try:
            async for raw in self.ws:
                data = json.loads(raw)
                msg_type = data.get("type")
                if msg_type in {"job", "job_query", "command"}:
                    await on_message(data)
                elif msg_type in {"heartbeat_ack", "registered"}:
                    continue
                elif msg_type == "error":
                    logger.warning("Server error: %s", data.get("message"))
        except ConnectionClosed:
            pass
        finally:
            self.connected = False

    async def disconnect(self):
        self.connected = False
        if self._status_task and not self._status_task.done():
            self._status_task.cancel()
            await asyncio.gather(self._status_task, return_exceptions=True)
        if self.ws:
            try:
                await self.ws.close()
            except Exception:
                pass
            self.ws = None

    async def _status_loop(self) -> None:
        while self.connected and self._status_provider:
            await asyncio.sleep(STATUS_INTERVAL)
            if not self.connected or not self._status_provider:
                break
            try:
                payload = self._status_provider()
                if asyncio.iscoroutine(payload):
                    payload = await payload
                await self.send_client_status(
                    capabilities=payload.get("capabilities", []),
                    connectivity=payload.get("connectivity", {}),
                    runtime_health=payload.get("runtime_health", {}),
                    gateway_info=payload.get("gateway_info"),
                    resources=payload.get("resources"),
                    reason="heartbeat",
                )
            except Exception:
                self.connected = False
                break

    def _build_status_payload(
        self,
        *,
        message_type: str,
        capabilities: list[dict],
        connectivity: dict,
        runtime_health: dict,
        gateway_info: dict | None,
        resources: dict | None,
    ) -> dict:
        connectivity = dict(connectivity or {})
        if gateway_info is not None and "gateway" not in connectivity:
            connectivity["gateway"] = gateway_info
        return {
            "type": message_type,
            "protocol_version": 2,
            "client_info": {
                "hostname": self.hostname,
                "version": "0.1.0",
                "platform": platform.system(),
            },
            "capabilities": capabilities,
            "connectivity": connectivity,
            "runtime_health": runtime_health,
            # Legacy fields retained for staged rollout.
            "gateway": (gateway_info or connectivity.get("gateway") or {"connected": False}),
            "resources": resources or {},
        }

    async def _send(self, payload: dict) -> None:
        if not self.ws or not self.connected:
            return
        await self.ws.send(json.dumps(payload))

    async def _receive(self) -> dict:
        raw = await self.ws.recv()
        return json.loads(raw)

    async def reconnect_loop(self) -> str:
        """Reconnect with exponential backoff. Returns client_id on success."""
        backoff = 1
        while True:
            logger.info("Attempting server reconnect in %ds...", backoff)
            await asyncio.sleep(backoff)
            try:
                client_id = await self.connect()
                logger.info("Server reconnected as %s", client_id)
                return client_id
            except Exception as exc:
                logger.warning("Server reconnect failed: %s", exc)
                backoff = min(backoff * 2, MAX_BACKOFF)
