"""SQLite-backed runtime journal for client job execution."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path


ACTIVE_STATES = {"queued", "accepted", "running"}
TERMINAL_STATES = {"succeeded", "failed", "timeout", "cancelled"}


def _json_dumps(value) -> str | None:
    if value is None:
        return None
    return json.dumps(value, sort_keys=True)


def _json_loads(value):
    if not value:
        return None
    return json.loads(value)


class RuntimeJournal:
    """Persist logical jobs, ordered events, and replay state."""

    SCHEMA_VERSION = 1

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    capability TEXT NOT NULL,
                    action TEXT NOT NULL,
                    state TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    started_at REAL,
                    completed_at REAL,
                    attempt INTEGER NOT NULL DEFAULT 0,
                    pid INTEGER,
                    exit_code INTEGER,
                    request_payload TEXT,
                    result_payload TEXT,
                    error TEXT,
                    last_seq INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS job_events (
                    job_id TEXT NOT NULL,
                    seq INTEGER NOT NULL,
                    created_at REAL NOT NULL,
                    event_type TEXT NOT NULL,
                    state TEXT,
                    stream TEXT,
                    payload TEXT,
                    PRIMARY KEY (job_id, seq),
                    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS client_runtime (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            conn.execute(
                """
                INSERT INTO client_runtime (key, value)
                VALUES ('schema_version', ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value
                """,
                (str(self.SCHEMA_VERSION),),
            )

    def record_job_received(
        self,
        *,
        job_id: str,
        capability: str,
        action: str,
        request_payload: dict,
    ) -> dict:
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO jobs (
                    job_id, capability, action, state, created_at, updated_at, request_payload
                )
                VALUES (?, ?, ?, 'received', ?, ?, ?)
                """,
                (job_id, capability, action, now, now, _json_dumps(request_payload)),
            )
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return self._row_to_job(row)

    def append_event(
        self,
        *,
        job_id: str,
        event_type: str,
        payload: dict | None,
        state: str | None = None,
        stream: str | None = None,
        attempt: int | None = None,
        pid: int | None = None,
        exit_code: int | None = None,
        error: str | None = None,
    ) -> dict:
        now = time.time()
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
            if row is None:
                raise KeyError(f"unknown job_id: {job_id}")

            seq = int(row["last_seq"]) + 1
            conn.execute(
                """
                INSERT INTO job_events (job_id, seq, created_at, event_type, state, stream, payload)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (job_id, seq, now, event_type, state, stream, _json_dumps(payload)),
            )

            next_state = state or row["state"]
            started_at = row["started_at"]
            completed_at = row["completed_at"]
            if next_state == "running" and started_at is None:
                started_at = now
            if next_state in TERMINAL_STATES:
                completed_at = now

            conn.execute(
                """
                UPDATE jobs
                SET state = ?,
                    updated_at = ?,
                    started_at = ?,
                    completed_at = ?,
                    attempt = COALESCE(?, attempt),
                    pid = COALESCE(?, pid),
                    exit_code = COALESCE(?, exit_code),
                    error = COALESCE(?, error),
                    last_seq = ?
                WHERE job_id = ?
                """,
                (
                    next_state,
                    now,
                    started_at,
                    completed_at,
                    attempt,
                    pid,
                    exit_code,
                    error,
                    seq,
                    job_id,
                ),
            )

        return {
            "job_id": job_id,
            "seq": seq,
            "event_type": event_type,
            "state": next_state,
            "stream": stream,
            "payload": payload or {},
            "created_at": now,
        }

    def update_job_metadata(
        self,
        job_id: str,
        *,
        attempt: int | None = None,
        pid: int | None = None,
        exit_code: int | None = None,
        error: str | None = None,
        result: dict | None = None,
        state: str | None = None,
    ) -> dict | None:
        now = time.time()
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
            if row is None:
                return None
            next_state = state or row["state"]
            completed_at = row["completed_at"]
            if next_state in TERMINAL_STATES and completed_at is None:
                completed_at = now
            conn.execute(
                """
                UPDATE jobs
                SET state = ?,
                    updated_at = ?,
                    completed_at = ?,
                    attempt = COALESCE(?, attempt),
                    pid = COALESCE(?, pid),
                    exit_code = COALESCE(?, exit_code),
                    error = COALESCE(?, error),
                    result_payload = COALESCE(?, result_payload)
                WHERE job_id = ?
                """,
                (
                    next_state,
                    now,
                    completed_at,
                    attempt,
                    pid,
                    exit_code,
                    error,
                    _json_dumps(result),
                    job_id,
                ),
            )
            updated = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return self._row_to_job(updated)

    def record_terminal_result(
        self,
        *,
        job_id: str,
        state: str,
        result: dict | None = None,
        error: str | None = None,
        exit_code: int | None = None,
    ) -> dict:
        payload = {"result": result} if result is not None else {}
        if error:
            payload["error"] = error
        event = self.append_event(
            job_id=job_id,
            event_type="result",
            state=state,
            payload=payload,
            exit_code=exit_code,
            error=error,
        )
        self.update_job_metadata(
            job_id,
            state=state,
            exit_code=exit_code,
            error=error,
            result=result,
        )
        summary = self.get_job(job_id) or {}
        return {
            "job_id": job_id,
            "capability": summary.get("capability"),
            "action": summary.get("action"),
            "state": state,
            "seq": event["seq"],
            "result": result,
            "error": error,
            "exit_code": exit_code,
        }

    def get_job(self, job_id: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return self._row_to_job(row) if row else None

    def list_jobs(self, *, state: str | None = None, limit: int = 100) -> list[dict]:
        query = "SELECT * FROM jobs"
        params: list[object] = []
        if state:
            query += " WHERE state = ?"
            params.append(state)
        query += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_job(row) for row in rows]

    def get_events(self, job_id: str, *, after_seq: int = 0, limit: int | None = None) -> list[dict]:
        query = """
            SELECT job_id, seq, created_at, event_type, state, stream, payload
            FROM job_events
            WHERE job_id = ? AND seq > ?
            ORDER BY seq ASC
        """
        params: list[object] = [job_id, after_seq]
        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_event(row) for row in rows]

    def build_replay_payload(self, cursor_map: dict[str, int] | None) -> dict:
        cursor_map = cursor_map or {}
        active_jobs = self._list_stateful_jobs(ACTIVE_STATES)
        terminal_results: list[dict] = []
        events: dict[str, list[dict]] = {}

        for job_id, cursor in cursor_map.items():
            summary = self.get_job(job_id)
            if not summary:
                continue
            replay_events = self.get_events(job_id, after_seq=int(cursor or 0))
            if replay_events:
                events[job_id] = replay_events
            if summary["state"] in TERMINAL_STATES and summary["last_seq"] > int(cursor or 0):
                terminal_results.append(
                    {
                        "job_id": job_id,
                        "capability": summary["capability"],
                        "action": summary["action"],
                        "state": summary["state"],
                        "seq": summary["last_seq"],
                        "result": summary.get("result"),
                        "error": summary.get("error"),
                        "exit_code": summary.get("exit_code"),
                    }
                )

        return {
            "active_jobs": active_jobs,
            "events": events,
            "terminal_results": terminal_results,
        }

    def force_job_timestamps(self, job_id: str, *, completed_at_epoch: float) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE jobs
                SET created_at = ?, updated_at = ?, completed_at = ?
                WHERE job_id = ?
                """,
                (completed_at_epoch, completed_at_epoch, completed_at_epoch, job_id),
            )

    def prune_completed(self, *, retention_age_seconds: int, max_database_bytes: int) -> int:
        now = time.time()
        pruned = 0
        with self._connect() as conn:
            cutoff = now - retention_age_seconds
            rows = conn.execute(
                """
                SELECT job_id
                FROM jobs
                WHERE state IN ('succeeded', 'failed', 'timeout', 'cancelled')
                  AND completed_at IS NOT NULL
                  AND completed_at <= ?
                ORDER BY completed_at ASC
                """,
                (cutoff,),
            ).fetchall()
            for row in rows:
                conn.execute("DELETE FROM jobs WHERE job_id = ?", (row["job_id"],))
                pruned += 1

            conn.commit()

        if pruned:
            with self._connect() as conn:
                conn.execute("VACUUM")

        while self.path.exists() and self.path.stat().st_size > max_database_bytes:
            with self._connect() as conn:
                row = conn.execute(
                    """
                    SELECT job_id
                    FROM jobs
                    WHERE state IN ('succeeded', 'failed', 'timeout', 'cancelled')
                    ORDER BY completed_at ASC
                    LIMIT 1
                    """
                ).fetchone()
                if row is None:
                    break
                conn.execute("DELETE FROM jobs WHERE job_id = ?", (row["job_id"],))
                pruned += 1
            with self._connect() as conn:
                conn.execute("VACUUM")

        return pruned

    def _list_stateful_jobs(self, states: set[str]) -> list[dict]:
        placeholders = ",".join("?" for _ in states)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM jobs WHERE state IN ({placeholders}) ORDER BY created_at ASC",
                tuple(states),
            ).fetchall()
        return [self._row_to_job(row) for row in rows]

    def _row_to_job(self, row: sqlite3.Row | None) -> dict | None:
        if row is None:
            return None
        return {
            "job_id": row["job_id"],
            "capability": row["capability"],
            "action": row["action"],
            "state": row["state"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "started_at": row["started_at"],
            "completed_at": row["completed_at"],
            "attempt": row["attempt"],
            "pid": row["pid"],
            "exit_code": row["exit_code"],
            "request": _json_loads(row["request_payload"]),
            "result": _json_loads(row["result_payload"]),
            "error": row["error"],
            "last_seq": row["last_seq"],
        }

    def _row_to_event(self, row: sqlite3.Row) -> dict:
        return {
            "job_id": row["job_id"],
            "seq": row["seq"],
            "created_at": row["created_at"],
            "event_type": row["event_type"],
            "state": row["state"],
            "stream": row["stream"],
            "payload": _json_loads(row["payload"]) or {},
        }
