"""Shared retry helpers for the v2 client supervisor."""

from collections.abc import Iterator


FIXED_RETRY_DELAYS = (5, 10, 20)
FIXED_RETRY_CEILING = 30


def fixed_retry_schedule() -> Iterator[int]:
    """Yield the v2 supervisory retry schedule indefinitely."""
    for delay in FIXED_RETRY_DELAYS:
        yield delay
    while True:
        yield FIXED_RETRY_CEILING
