"""Bounded client job runtime with durable journal-backed state."""

from __future__ import annotations

import asyncio
import contextlib
import shutil
from collections import deque
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from bamboo_claw_client.runtime_journal import ACTIVE_STATES, RuntimeJournal, TERMINAL_STATES


DEFAULT_CANCEL_GRACE_SECONDS = 10
DEFAULT_RETENTION_AGE_SECONDS = 7 * 24 * 60 * 60
DEFAULT_RETENTION_MAX_BYTES = 100 * 1024 * 1024


@dataclass
class JobOutcome:
    state: str
    result: dict | None = None
    error: str | None = None
    exit_code: int | None = None


class UnsupportedJobError(Exception):
    """Raised when a capability/action pair is not supported."""


class AdapterUnavailableError(Exception):
    """Raised when a capability adapter is configured but unavailable."""


async def _maybe_await(callback, payload) -> None:
    if callback is None:
        return
    result = callback(payload)
    if asyncio.iscoroutine(result):
        await result


class JobContext:
    """Per-job execution context passed to adapters."""

    def __init__(self, runtime: "JobRuntime", message: dict, attempt: int):
        self.runtime = runtime
        self.message = message
        self.job_id = str(message["job_id"])
        self.capability = str(message["capability"])
        self.action = str(message["action"])
        self.params = message.get("params") or {}
        self.attempt = attempt
        self._cancel_hook: Callable[[], Awaitable[None] | None] | None = None

    async def emit_state(self, state: str, payload: dict | None = None) -> dict:
        return await self.runtime._emit_event(
            job_id=self.job_id,
            capability=self.capability,
            action=self.action,
            event_type="state",
            state=state,
            payload=payload or {"state": state},
            attempt=self.attempt,
        )

    async def emit_output(self, stream: str, content: str) -> dict:
        return await self.runtime._emit_event(
            job_id=self.job_id,
            capability=self.capability,
            action=self.action,
            event_type="output",
            state="running",
            stream=stream,
            payload={"stream": stream, "content": content},
            attempt=self.attempt,
        )

    async def emit_gateway(self, payload: dict) -> dict:
        return await self.runtime._emit_event(
            job_id=self.job_id,
            capability=self.capability,
            action=self.action,
            event_type="gateway",
            state="running",
            payload=payload,
            attempt=self.attempt,
        )

    def set_cancel_hook(self, hook: Callable[[], Awaitable[None] | None]) -> None:
        self._cancel_hook = hook
        self.runtime.set_cancel_hook(self.job_id, hook)

    def set_process_metadata(self, *, pid: int | None = None) -> None:
        self.runtime.journal.update_job_metadata(
            self.job_id,
            attempt=self.attempt,
            pid=pid,
            state="running",
        )


class OpenClawChatAdapter:
    """Capability adapter that bridges jobs onto the persistent gateway client."""

    capability = "openclaw"
    actions = ("chat",)

    def __init__(self, gateway):
        self.gateway = gateway

    async def run(self, action: str, params: dict, context: JobContext):
        if action != "chat":
            raise UnsupportedJobError(f"Unsupported action for openclaw: {action}")
        if not getattr(self.gateway, "connected", False):
            raise AdapterUnavailableError("OpenClaw gateway is not connected")

        async def on_event(event: dict):
            await context.emit_gateway(event)

        result = await self.gateway.send_chat_message(
            message=params.get("message", ""),
            session_key=params.get("session_key"),
            attachments=params.get("attachments"),
            on_event=on_event,
        )
        if result.get("state") == "aborted":
            return JobOutcome(
                state="cancelled",
                result={
                    "content": result.get("content", "(aborted)"),
                    "session_key": result.get("sessionKey"),
                },
            )
        return {
            "content": result.get("content", ""),
            "session_key": result.get("sessionKey"),
        }


class ExternalProcessAdapter:
    """Structured subprocess-backed execution adapter."""

    actions = ("exec",)

    def __init__(self, capability: str, executable: str):
        self.capability = capability
        self.executable = executable

    async def run(self, action: str, params: dict, context: JobContext):
        if action != "exec":
            raise UnsupportedJobError(f"Unsupported action for {self.capability}: {action}")

        command = shutil.which(self.executable)
        if not command:
            raise AdapterUnavailableError(f"{self.capability}.exec adapter unavailable")

        args = params.get("args") or []
        if not isinstance(args, list) or any(not isinstance(item, str) for item in args):
            raise UnsupportedJobError("exec args must be a list of strings")

        workdir = params.get("workdir")
        timeout = params.get("timeout")

        process = await asyncio.create_subprocess_exec(
            command,
            *args,
            cwd=workdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        context.set_process_metadata(pid=process.pid)
        context.set_cancel_hook(lambda: self._cancel_process(process))

        stdout_task = asyncio.create_task(self._stream_reader(process.stdout, "stdout", context))
        stderr_task = asyncio.create_task(self._stream_reader(process.stderr, "stderr", context))

        try:
            if timeout:
                return_code = await asyncio.wait_for(process.wait(), timeout=float(timeout))
            else:
                return_code = await process.wait()
        except asyncio.TimeoutError:
            await self._terminate_process(process)
            return JobOutcome(state="timeout", error="Process timed out")
        except asyncio.CancelledError:
            await self._terminate_process(process)
            raise
        finally:
            await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)

        if return_code == 0:
            return {
                "returncode": return_code,
                "args": args,
            }

        return JobOutcome(
            state="failed",
            result={"returncode": return_code, "args": args},
            error=f"Process exited with code {return_code}",
            exit_code=return_code,
        )

    async def _stream_reader(self, stream, name: str, context: JobContext) -> None:
        if stream is None:
            return
        while True:
            chunk = await stream.readline()
            if not chunk:
                break
            await context.emit_output(name, chunk.decode("utf-8", errors="replace").rstrip("\n"))

    async def _cancel_process(self, process) -> None:
        if process.returncode is not None:
            return
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=DEFAULT_CANCEL_GRACE_SECONDS)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()

    async def _terminate_process(self, process) -> None:
        if process.returncode is not None:
            return
        process.kill()
        await process.wait()


class JobRuntime:
    """Durable bounded runtime for capability-based client jobs."""

    def __init__(
        self,
        *,
        journal: RuntimeJournal,
        max_concurrent_jobs: int,
        on_job_event=None,
        on_job_result=None,
        on_status_change=None,
    ):
        self.journal = journal
        self.max_concurrent_jobs = max(1, int(max_concurrent_jobs))
        self.on_job_event = on_job_event
        self.on_job_result = on_job_result
        self.on_status_change = on_status_change
        self._adapters: dict[tuple[str, str], Any] = {}
        self._queue: deque[dict] = deque()
        self._queued_ids: set[str] = set()
        self._running: dict[str, asyncio.Task] = {}
        self._cancel_hooks: dict[str, Callable[[], Awaitable[None] | None]] = {}

    def register_adapter(self, adapter) -> None:
        for action in getattr(adapter, "actions", ()):
            self._adapters[(str(adapter.capability), str(action))] = adapter

    def build_capabilities(self) -> list[dict]:
        by_capability: dict[str, list[str]] = {}
        for capability, action in self._adapters:
            by_capability.setdefault(capability, []).append(action)
        return [
            {"capability": capability, "actions": sorted(actions)}
            for capability, actions in sorted(by_capability.items())
        ]

    def health_snapshot(self) -> dict:
        return {
            "active_jobs": len(self._running),
            "queued_jobs": len(self._queue),
            "max_concurrent_jobs": self.max_concurrent_jobs,
        }

    def set_cancel_hook(self, job_id: str, hook) -> None:
        self._cancel_hooks[job_id] = hook

    async def handle_job_message(self, message: dict) -> dict:
        job_id = str(message.get("job_id") or "")
        capability = str(message.get("capability") or "")
        action = str(message.get("action") or "")
        params = message.get("params") or {}
        if not job_id or not capability or not action:
            raise UnsupportedJobError("job_id, capability, and action are required")

        existing = self.journal.get_job(job_id)
        if existing and (existing["state"] in ACTIVE_STATES or existing["state"] in TERMINAL_STATES):
            await self._replay_duplicate(existing)
            return {"duplicate": True, "job": existing}

        adapter = self._adapters.get((capability, action))
        if adapter is None:
            self.journal.record_job_received(
                job_id=job_id,
                capability=capability,
                action=action,
                request_payload=params,
            )
            result = self.journal.record_terminal_result(
                job_id=job_id,
                state="failed",
                error=f"Unsupported capability/action: {capability}.{action}",
            )
            await _maybe_await(self.on_job_result, result)
            return {"duplicate": False, "job": self.journal.get_job(job_id)}

        self.journal.record_job_received(
            job_id=job_id,
            capability=capability,
            action=action,
            request_payload=params,
        )

        queued = len(self._running) >= self.max_concurrent_jobs
        if queued:
            self._queue.append(
                {
                    "job_id": job_id,
                    "capability": capability,
                    "action": action,
                    "params": params,
                }
            )
            self._queued_ids.add(job_id)
            await self._emit_event(
                job_id=job_id,
                capability=capability,
                action=action,
                event_type="state",
                state="queued",
                payload={"state": "queued"},
                attempt=0,
            )
            await self._notify_status_change()
            return {"duplicate": False, "queued": True, "job": self.journal.get_job(job_id)}

        await self._emit_event(
            job_id=job_id,
            capability=capability,
            action=action,
            event_type="state",
            state="accepted",
            payload={"state": "accepted"},
            attempt=0,
        )
        self._start_job({"job_id": job_id, "capability": capability, "action": action, "params": params})
        await self._notify_status_change()
        return {"duplicate": False, "queued": False, "job": self.journal.get_job(job_id)}

    async def handle_query(self, message: dict) -> dict:
        query = str(message.get("query") or "")
        if query == "job.get":
            return {"job": self.journal.get_job(str(message.get("job_id") or ""))}
        if query == "job.list":
            return {"jobs": self.journal.list_jobs(limit=int(message.get("limit") or 100))}
        if query == "job.logs.range":
            job_id = str(message.get("job_id") or "")
            cursor = int(message.get("cursor") or 0)
            items = self.journal.get_events(job_id, after_seq=cursor)
            next_cursor = items[-1]["seq"] if items else cursor
            return {"items": items, "next_cursor": next_cursor}
        if query == "job.replay":
            return self.journal.build_replay_payload(message.get("cursor_map") or {})
        if query == "job.cancel":
            job = await self.cancel_job(str(message.get("job_id") or ""))
            return {"job": job}
        raise UnsupportedJobError(f"Unsupported query: {query}")

    async def cancel_job(self, job_id: str) -> dict | None:
        if job_id in self._queued_ids:
            self._queue = deque(item for item in self._queue if str(item["job_id"]) != job_id)
            self._queued_ids.discard(job_id)
            result = self.journal.record_terminal_result(
                job_id=job_id,
                state="cancelled",
                error="Cancelled before execution",
            )
            await _maybe_await(self.on_job_result, result)
            await self._notify_status_change()
            return self.journal.get_job(job_id)

        hook = self._cancel_hooks.get(job_id)
        if hook is not None:
            maybe = hook()
            if asyncio.iscoroutine(maybe):
                await maybe

        task = self._running.get(job_id)
        if task and not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
            summary = self.journal.get_job(job_id)
            if summary and summary["state"] in ACTIVE_STATES:
                result = self.journal.record_terminal_result(
                    job_id=job_id,
                    state="cancelled",
                    error="Cancelled",
                )
                await _maybe_await(self.on_job_result, result)
            self._running.pop(job_id, None)
            await self._notify_status_change()
        return self.journal.get_job(job_id)

    async def wait_for_idle(self) -> None:
        while self._running or self._queue:
            running = list(self._running.values())
            if running:
                await asyncio.gather(*running, return_exceptions=True)
            else:
                await asyncio.sleep(0)

    async def _replay_duplicate(self, summary: dict) -> None:
        if summary["state"] in TERMINAL_STATES:
            payload = {
                "job_id": summary["job_id"],
                "capability": summary["capability"],
                "action": summary["action"],
                "state": summary["state"],
                "seq": summary["last_seq"],
                "result": summary.get("result"),
                "error": summary.get("error"),
                "exit_code": summary.get("exit_code"),
            }
            await _maybe_await(self.on_job_result, payload)
            return

        await self._emit_event(
            job_id=summary["job_id"],
            capability=summary["capability"],
            action=summary["action"],
            event_type="state",
            state=summary["state"],
            payload={"state": summary["state"], "duplicate": True},
            attempt=summary.get("attempt") or 0,
        )

    def _start_job(self, message: dict) -> None:
        job_id = str(message["job_id"])
        task = asyncio.create_task(self._run_job(message))
        self._running[job_id] = task

    async def _run_job(self, message: dict) -> None:
        job_id = str(message["job_id"])
        capability = str(message["capability"])
        action = str(message["action"])
        adapter = self._adapters[(capability, action)]
        attempt = (self.journal.get_job(job_id) or {}).get("attempt", 0) + 1
        context = JobContext(self, message, attempt)

        try:
            await self._emit_event(
                job_id=job_id,
                capability=capability,
                action=action,
                event_type="state",
                state="running",
                payload={"state": "running"},
                attempt=attempt,
            )
            outcome = await adapter.run(action, message.get("params") or {}, context)
            if isinstance(outcome, JobOutcome):
                final = outcome
            else:
                final = JobOutcome(state="succeeded", result=outcome)
        except AdapterUnavailableError as exc:
            final = JobOutcome(state="failed", error=str(exc))
        except UnsupportedJobError as exc:
            final = JobOutcome(state="failed", error=str(exc))
        except asyncio.CancelledError:
            final = JobOutcome(state="cancelled", error="Cancelled")
        except Exception as exc:
            final = JobOutcome(state="failed", error=str(exc))
        finally:
            self._cancel_hooks.pop(job_id, None)

        result = self.journal.record_terminal_result(
            job_id=job_id,
            state=final.state,
            result=final.result,
            error=final.error,
            exit_code=final.exit_code,
        )
        self.journal.prune_completed(
            retention_age_seconds=DEFAULT_RETENTION_AGE_SECONDS,
            max_database_bytes=DEFAULT_RETENTION_MAX_BYTES,
        )
        await _maybe_await(self.on_job_result, result)

        self._running.pop(job_id, None)
        await self._notify_status_change()
        await self._drain_queue()

    async def _drain_queue(self) -> None:
        while self._queue and len(self._running) < self.max_concurrent_jobs:
            message = self._queue.popleft()
            job_id = str(message["job_id"])
            self._queued_ids.discard(job_id)
            await self._emit_event(
                job_id=job_id,
                capability=str(message["capability"]),
                action=str(message["action"]),
                event_type="state",
                state="accepted",
                payload={"state": "accepted"},
                attempt=(self.journal.get_job(job_id) or {}).get("attempt", 0),
            )
            self._start_job(message)
        await self._notify_status_change()

    async def _emit_event(
        self,
        *,
        job_id: str,
        capability: str,
        action: str,
        event_type: str,
        state: str,
        payload: dict,
        attempt: int,
        stream: str | None = None,
        pid: int | None = None,
    ) -> dict:
        event = self.journal.append_event(
            job_id=job_id,
            event_type=event_type,
            state=state,
            payload=payload,
            stream=stream,
            attempt=attempt,
            pid=pid,
        )
        broadcast = {
            "job_id": job_id,
            "capability": capability,
            "action": action,
            "seq": event["seq"],
            "event_type": event_type,
            "state": state,
            "stream": stream,
            "payload": payload,
        }
        await _maybe_await(self.on_job_event, broadcast)
        return broadcast

    async def _notify_status_change(self) -> None:
        await _maybe_await(self.on_status_change, self.health_snapshot())
