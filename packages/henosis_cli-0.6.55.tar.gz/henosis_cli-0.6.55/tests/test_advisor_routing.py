import asyncio
import importlib
from types import SimpleNamespace
from pathlib import Path
import uuid


def _new_local_tmp() -> Path:
    base = Path.cwd() / ".pytest_local_tmp"
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"advisor-routing-{uuid.uuid4().hex[:10]}"
    p.mkdir(parents=True, exist_ok=False)
    return p


def make_cli(tmp_path: Path):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    cli._clear_codex_auth_state_on_disk(clear_shared=False)
    return cli


def test_advisor_auto_route_prefers_codex_then_byok_then_backend():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.access_hub = None

    cli.advisor_auth_mode = "auto"
    cli.auth_user = "user@example.com"
    cli.codex_access_token = "access-token"
    cli.codex_refresh_token = "refresh-token"

    assert cli._advisor_route_preferences() == ["codex_oauth", "backend"]

    cli.codex_access_token = None
    cli.codex_refresh_token = None

    class _Hub:
        def has_provider_key(self, provider):
            return provider == "openai"

    cli.access_hub = _Hub()
    assert cli._advisor_route_preferences() == ["byok", "backend"]

    cli.access_hub = None
    assert cli._advisor_route_preferences() == ["backend"]


def test_codex_local_advisor_tool_uses_gpt_55_over_codex_when_auto(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.enable_advisor = True
    cli.advisor_model = "gpt-5.5"
    cli.advisor_reasoning_effort = "xhigh"
    cli.advisor_auth_mode = "auto"
    cli.codex_access_token = "access-token"
    cli.codex_refresh_token = "refresh-token"
    cli.codex_account_id = "acct_123"

    captured = {}

    monkeypatch.setattr(cli_mod, "HAS_LOCAL_ADVISOR", True)
    monkeypatch.setattr(
        cli_mod,
        "local_resolve_advisor_config",
        lambda _cli: SimpleNamespace(
            advisor_model=_cli.advisor_model,
            reasoning_effort=_cli.advisor_reasoning_effort,
            max_uses=2,
            enabled=True,
        ),
    )
    monkeypatch.setattr(
        cli_mod,
        "local_build_advisor_input_items",
        lambda **kwargs: [{"role": "user", "content": "advisor transcript"}],
    )

    async def fake_invoke_advisor_via_codex(model_name: str, transcript: str, reasoning_effort: str):
        captured["model_name"] = model_name
        captured["transcript"] = transcript
        captured["reasoning_effort"] = reasoning_effort
        return {
            "ok": True,
            "data": {
                "text": "advisor says hi",
                "advisor_model": model_name,
                "reasoning_effort": reasoning_effort,
                "usage": {"input_tokens": 11, "output_tokens": 5, "total_tokens": 16},
                "cost_usd": 0.123,
                "auth_mode": "codex_oauth",
            },
        }

    monkeypatch.setattr(cli, "_invoke_advisor_via_codex", fake_invoke_advisor_via_codex)

    result = asyncio.run(
        cli._codex_local_advisor_tool_result([
            {"role": "user", "content": "Please advise."},
        ])
    )

    assert result["ok"] is True
    assert captured == {
        "model_name": "gpt-5.5",
        "transcript": [{"role": "user", "content": "advisor transcript"}],
        "reasoning_effort": "xhigh",
    }
    assert result["data"]["advisor_model"] == "gpt-5.5"
    assert result["data"]["auth_mode"] == "codex_oauth"


def test_codex_advisor_request_uses_streaming_codex_payload(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    captured = {}

    async def fake_stream_request(*, req_payload, http_timeout):
        captured["req_payload"] = dict(req_payload or {})
        captured["http_timeout"] = http_timeout
        return {
            "model_used": "gpt-5.5",
            "text_chunks": ["advisor ok"],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "advisor ok"}],
                }
            ],
            "usage": {"input_tokens": 5, "output_tokens": 2, "total_tokens": 7},
            "thinking_text": "",
            "thinking_meta": {},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)

    result = asyncio.run(
        cli._invoke_advisor_via_codex(
            "gpt-5.5",
            [{"role": "user", "content": "advisor transcript"}],
            "xhigh",
        )
    )

    assert result["ok"] is True
    assert captured["req_payload"]["stream"] is True
    assert captured["req_payload"]["store"] is False
    assert captured["req_payload"]["instructions"].strip()
    assert "strategic" in captured["req_payload"]["instructions"].lower()
    assert captured["req_payload"]["input"] == [{"role": "user", "content": "advisor transcript"}]
    assert captured["req_payload"]["reasoning"] == {"effort": "xhigh"}
    assert result["data"]["advisor_model"] == "gpt-5.5"


def test_codex_advisor_request_drops_unresolved_function_calls(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    captured = {}

    async def fake_stream_request(*, req_payload, http_timeout):
        captured["input"] = list(req_payload.get("input") or [])
        return {
            "model_used": "gpt-5.5",
            "text_chunks": ["advisor ok"],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "advisor ok"}],
                }
            ],
            "usage": {"input_tokens": 5, "output_tokens": 2, "total_tokens": 7},
            "thinking_text": "",
            "thinking_meta": {},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)

    result = asyncio.run(
        cli._invoke_advisor_via_codex(
            "gpt-5.5",
            [
                {"role": "user", "content": "start"},
                {"type": "function_call", "call_id": "call_done", "name": "read_file", "arguments": "{}"},
                {"type": "function_call_output", "call_id": "call_done", "output": "ok"},
                {"type": "function_call", "call_id": "call_pending", "name": "advisor", "arguments": "{}"},
                {"role": "user", "content": "please advise"},
            ],
            "xhigh",
        )
    )

    assert result["ok"] is True
    function_items = [
        item
        for item in captured["input"]
        if isinstance(item, dict) and str(item.get("type") or "") in {"function_call", "function_call_output"}
    ]
    assert {item.get("call_id") for item in function_items} == {"call_done"}
    assert all(item.get("call_id") != "call_pending" for item in function_items)


def test_codex_local_advisor_tool_filters_inflight_calls_before_build(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.enable_advisor = True
    cli.advisor_auth_mode = "auto"
    cli.codex_access_token = "access-token"
    cli.codex_refresh_token = "refresh-token"

    captured = {}

    monkeypatch.setattr(cli_mod, "HAS_LOCAL_ADVISOR", True)
    monkeypatch.setattr(
        cli_mod,
        "local_resolve_advisor_config",
        lambda _cli: SimpleNamespace(
            advisor_model="gpt-5.5",
            reasoning_effort="xhigh",
            max_uses=2,
            enabled=True,
        ),
    )

    def fake_build_advisor_input_items(**kwargs):
        captured["conversation_items"] = list(kwargs.get("conversation_items") or [])
        return [{"role": "user", "content": "advisor transcript"}]

    monkeypatch.setattr(cli_mod, "local_build_advisor_input_items", fake_build_advisor_input_items)

    async def fake_invoke_advisor_via_codex(model_name, transcript, reasoning_effort):
        return {
            "ok": True,
            "data": {
                "text": "advisor says hi",
                "advisor_model": model_name,
                "reasoning_effort": reasoning_effort,
                "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
                "cost_usd": 0.0,
                "auth_mode": "codex_oauth",
            },
        }

    monkeypatch.setattr(cli, "_invoke_advisor_via_codex", fake_invoke_advisor_via_codex)

    result = asyncio.run(
        cli._codex_local_advisor_tool_result(
            [
                {"role": "user", "content": "start"},
                {"type": "function_call", "call_id": "call_pending", "name": "advisor", "arguments": "{}"},
            ]
        )
    )

    assert result["ok"] is True
    assert captured["conversation_items"] == [{"role": "user", "content": "start"}]


def test_codex_local_tool_schemas_include_advisor_even_when_file_tools_are_off(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)

    monkeypatch.setattr(cli_mod, "HAS_LOCAL_ADVISOR", True)

    tools = cli._codex_local_tool_schemas(
        level=2,
        tools_enabled=False,
        browser_tools_enabled=False,
        advisor_enabled=True,
    )
    names = {tool.get("name") for tool in tools if isinstance(tool, dict)}

    assert names == {"advisor"}


def test_codex_local_stream_payload_exposes_advisor_when_enabled(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.requested_tools = False
    cli.browser_tools_enabled = False
    cli.enable_advisor = True

    monkeypatch.setattr(cli_mod, "HAS_LOCAL_ADVISOR", True)

    captured = {}

    async def fake_stream_request(*, req_payload, http_timeout):
        captured["tools"] = req_payload.get("tools") or []
        return {
            "model_used": "gpt-5.4",
            "text_chunks": ["advisor ready"],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "advisor ready"}],
                }
            ],
            "usage": {"prompt_tokens": 9, "completion_tokens": 3, "total_tokens": 12},
            "thinking_text": "",
            "thinking_meta": {},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)

    result = asyncio.run(cli._stream_codex_local_once("hello"))

    tool_names = {tool.get("name") for tool in captured.get("tools", []) if isinstance(tool, dict)}
    assert "advisor" in tool_names
    assert result == "advisor ready"
