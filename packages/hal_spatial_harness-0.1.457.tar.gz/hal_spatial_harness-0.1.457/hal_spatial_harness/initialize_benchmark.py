import os
from pathlib import Path

# 3rd-party packages
import pandas as pd
from alive_progress import alive_bar
from huggingface_hub import snapshot_download
from zipfile import ZipFile
from importlib.resources import files


class BenchmarkStats:
    def __init__(self, ):
        csv_path = files("hal_spatial_harness") / "annotations.csv"
        self.df = pd.read_csv(csv_path)   
    
    def _print_stats(self, column, title):
        pd.set_option("display.max_rows", None)

        df_counts = (
            self.df[column]
            .value_counts()
            .sort_values()
            .rename_axis(title)
            .reset_index(name="Count")
        )

        print(df_counts.to_markdown(index=False))  # clean table


    def get_dataset_stats(self):
        self._print_stats("dataset", "Dataset")


    def get_category_stats(self):
        self._print_stats("category", "Category")


    def get_sub_category_stats(self):
        self._print_stats("sub_category", "Sub Category")


    def get_task_stats(self):
        self._print_stats("task", "Task")




def initialize_benchmark(local_path):
    token = os.environ.get("HF_TOKEN",None)
    repo_id="Wahiddhrubo/hal-spatial"
    
    if not token:
        raise ValueError("Dataset is no Public Yet!!!")

    
    snapshot_download(
        repo_id=repo_id,
        repo_type="dataset",   # "dataset" or "model"
        local_dir=local_path,  # your path
        token=token,
        allow_patterns=None,   # optional: download only some files
        ignore_patterns=None,  # optional: ignore some files
    )

    
    zip_path = Path(local_path) / "question_images.zip"
    extract_to = Path(local_path) / "question_images"
    
    with ZipFile(zip_path, 'r') as z:
        members = z.infolist()
    
        with alive_bar(len(members), title="Extracting files") as bar:
            for m in members:
                z.extract(m, extract_to)
                bar()

    zip_path.unlink()


def prompt_generator(row):

    # print(row)
    
    prompt = f"""You are a vision-language reasoning agent.
Understand the intent of the question based on the category {row['category']}. Focus on key visual or logical cues such as shading, color consistency, spatial relations, or context depending on the category.

Carefully read and compare all choices, paying attention to small differences and ignoring formatting issues. Use relative reasoning when needed (e.g., darker vs lighter, same vs different).

Choose the {'Answer' if row['question_type'] != 'MCQ' else 'OPTION LETTER ONLY'} that best matches the question’s intent based on sound reasoning, not assumptions. 

JUST GIVE THE ANSWER NO NEED OF REASONING.

Question:
{row['question']}
"""

    choices= f"""Choices: {row['choices']} """ if row["choices"] else ""

    

    return  {**row, "task_description": prompt + choices}





def process_benchmark(
        df,
        categories,
        sub_categories,
        task_ids,
        max_tasks,
        continue_run=False,
        eval_path="",  
    ):
    
    if len(categories):
        df=df[df["category"].isin(categories)]
    
    if len(task_ids):
        df=df[df["task"].isin(task_ids)]
    
    if len(sub_categories):
        df=df[df["sub_category"].isin(sub_categories)]
        
    ids=[]
    if continue_run:
        if os.path.exists(eval_path):
            prev_df=pd.read_csv(eval_path)
            ids=prev_df[prev_df["response"].notna()]["id"].to_list()
        
    
    
    
    
    
    df=df[~df["id"].isin(ids)]
    dataset=df.set_index('id').to_dict(orient='index')
    
    if max_tasks and max_tasks > 0 and max_tasks < len(dataset):
        print(f"Limiting to the first {max_tasks} tasks as requested")
        keep_task_ids = list(dataset.keys())[: max_tasks]
        dataset = {task_id: dataset[task_id] for task_id in keep_task_ids}

    
    return dataset

