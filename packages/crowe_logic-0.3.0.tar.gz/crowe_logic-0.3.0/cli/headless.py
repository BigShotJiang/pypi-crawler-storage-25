"""
Headless Crowe Logic Command runner for external hosts that want to
drive the agent over a JSON event stream.

Reads a single conversation turn (full message history) as JSON on
stdin and emits one JSON event per line to stdout for the assistant's
response. Each line is a complete JSON object terminated by ``\n``;
hosts read until they see ``{"type":"done"}`` or ``{"type":"error"}``.

This is the contract that lets a non-terminal host (the VS Code chat
participant, an HTTP gateway, a test runner) reuse the same agent loop
the CLI runs without parsing Rich/ANSI output. The renderer is just
swapped: ``BaseOpenAIProvider.stream_response`` accepts an optional
renderer instance, and ``JsonStreamRenderer`` here conforms to the same
interface ``StreamRenderer`` exposes.

Input schema (one JSON object on stdin)::

    {
      "messages": [
        {"role": "user",      "content": "..."},
        {"role": "assistant", "content": "..."},
        ...
      ],
      "model":   "auto",            # optional, defaults to MODEL_CHAIN[0]
      "session": "vscode-abc123"    # optional, opaque tag for telemetry
    }

Output events (line-delimited JSON on stdout)::

    {"type":"ready"}
    {"type":"reasoning","delta":"..."}
    {"type":"token","delta":"..."}
    {"type":"tool","name":"...","args":"...","status":"ok|fail","duration_ms":N,"result":"..."}
    {"type":"spinner","label":"..."}        # transient state hints
    {"type":"segment_end"}                   # boundary between rounds
    {"type":"done","tokens":N,"reasoning_tokens":N,"elapsed_ms":N,"ttft_ms":N}
    {"type":"error","message":"...","kind":"..."}
"""

from __future__ import annotations

import json
import os
import sys
import time
import argparse

from cli.session_runtime import (
    build_runtime_system_instructions,
    handle_local_control_command,
    update_session_runtime,
)


# Make sure the Foundry root is importable when this module is invoked as
# ``python -m cli.headless`` from anywhere (e.g., the VS Code extension
# spawning it from a different cwd).
_PACKAGE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PACKAGE_ROOT not in sys.path:
    sys.path.insert(0, _PACKAGE_ROOT)


# ── Wire protocol ────────────────────────────────────────────────────────


def emit(event_type: str, **fields) -> None:
    """Write one JSON event to stdout, terminated by newline + flush.

    Newline-delimited JSON is the simplest framing that lets the host
    parse incrementally without a length prefix. We flush per event so
    streaming actually streams instead of buffering until the process
    exits.
    """
    sys.stdout.write(json.dumps({"type": event_type, **fields}) + "\n")
    sys.stdout.flush()


def emit_error(message: str, kind: str = "runtime") -> None:
    emit("error", message=message, kind=kind)


def _meter_turn(*, tokens: int, reasoning_tokens: int, model_label: str, elapsed_ms: int) -> None:
    """POST a credit-consume request to the control plane.

    Fire-and-forget. The PAT identifies which workspace to debit; if
    `CROWE_LOGIC_PAT` is unset, we skip metering entirely (BYOK / dev /
    free-tier with no signup yet). Cost is one credit per ~250 output
    tokens, rounded up — the exact rate lives server-side, this is a
    pre-flight estimate so the user sees their balance update fast.
    """
    pat = os.environ.get("CROWE_LOGIC_PAT", "").strip()
    if not pat or not pat.startswith("crowe_pat_"):
        return
    base_url = os.environ.get(
        "CROWE_LOGIC_API_URL", "https://api.crowelogic.com"
    ).rstrip("/")
    # Extract workspace id from the PAT format: crowe_pat_<workspace>_<secret>
    body = pat[len("crowe_pat_"):]
    parts = body.split("_", 1)
    if len(parts) != 2:
        return
    workspace_id = parts[0]
    # Coarse cost estimate: 1 credit per 250 tokens, minimum 1.
    total_tokens = max(1, int(tokens) + int(reasoning_tokens))
    amount = max(1, (total_tokens + 249) // 250)
    try:
        import urllib.request
        import json as _json
        req = urllib.request.Request(
            f"{base_url}/api/workspaces/{workspace_id}/credits/consume",
            data=_json.dumps({
                "amount": amount,
                "reason": "turn",
                "model_label": model_label,
                "metadata": {
                    "tokens": int(tokens),
                    "reasoning_tokens": int(reasoning_tokens),
                    "elapsed_ms": int(elapsed_ms),
                },
            }).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {pat}",
            },
            method="POST",
        )
        # 1.5s timeout; chat must not block on billing
        urllib.request.urlopen(req, timeout=1.5)
    except Exception:
        # Never fail a chat turn over a metering hiccup
        pass


# ── Renderer ─────────────────────────────────────────────────────────────


class JsonStreamRenderer:
    """Renderer that emits JSON events instead of drawing to a terminal.

    Conforms to the interface ``BaseOpenAIProvider.stream_response``
    expects from ``StreamRenderer``: ``start``, ``set_spinner``,
    ``stop_spinner``, ``feed``, ``feed_reasoning``, ``end_segment``,
    ``finish``, plus the ``current_segment_text`` property. The host
    consumes the resulting event stream and renders it natively (the VS
    Code extension uses the Chat API; an HTTP gateway could SSE it).

    Segment semantics mirror the Rich renderer exactly so the provider
    loop's calls into ``current_segment_text`` and ``end_segment``
    behave identically. ``_text_chunks`` is the per-segment buffer;
    ``end_segment`` clears it after the provider has read its contents.
    """

    def __init__(self, *, session_id: str = "", model_label: str = "") -> None:
        self._text_chunks: list[str] = []
        self._full_text_chunks: list[str] = []
        self._full_reasoning_chunks: list[str] = []
        self._token_count = 0
        self._reasoning_token_count = 0
        self._t_start = 0.0
        self._t_first_token = 0.0
        self._t_end = 0.0
        self._session_id = session_id
        self._model_label = model_label

    def start(self) -> None:
        self._t_start = time.monotonic()
        emit("ready")

    def set_spinner(self, label: str) -> None:
        # Mirror StreamRenderer.set_spinner: finalize the segment, then
        # advertise the new spinner state. The host can render this as a
        # status line, a progress message, or ignore it entirely.
        self.end_segment()
        emit("spinner", label=label)

    def stop_spinner(self) -> None:
        emit("spinner", label=None)

    def feed(self, token: str) -> None:
        if self._t_first_token == 0.0:
            self._t_first_token = time.monotonic()
        self._text_chunks.append(token)
        self._full_text_chunks.append(token)
        self._token_count += 1
        emit("token", delta=token)

    def feed_reasoning(self, token: str) -> None:
        self._full_reasoning_chunks.append(token)
        self._reasoning_token_count += 1
        emit("reasoning", delta=token)

    def end_segment(self) -> None:
        # The provider reads current_segment_text BEFORE calling this,
        # exactly as it does with the Rich renderer. Clearing here lets
        # the next round start with an empty buffer.
        self._text_chunks = []
        emit("segment_end")

    def finish(self, session_state=None) -> None:
        self._t_end = time.monotonic()
        self._persist_transcript()
        ttft_ms = (
            int((self._t_first_token - self._t_start) * 1000)
            if self._t_first_token > 0 else 0
        )
        elapsed_ms = int((self._t_end - self._t_start) * 1000)
        emit(
            "done",
            tokens=self._token_count,
            reasoning_tokens=self._reasoning_token_count,
            elapsed_ms=elapsed_ms,
            ttft_ms=ttft_ms,
        )
        # Best-effort credit metering. Fire-and-forget POST to the
        # control plane so a single turn debits the workspace's
        # ledger. Failures are silent — never block the chat on a
        # billing service hiccup.
        try:
            _meter_turn(
                tokens=self._token_count,
                reasoning_tokens=self._reasoning_token_count,
                model_label=self._model_label,
                elapsed_ms=elapsed_ms,
            )
        except Exception:
            pass

    @property
    def current_segment_text(self) -> str:
        return "".join(self._text_chunks)

    def abort(self, session_state=None) -> None:
        self._persist_transcript()

    def _persist_transcript(self) -> None:
        if not self._session_id:
            return
        update_session_runtime(
            self._session_id,
            last_answer_text="".join(self._full_text_chunks).strip(),
            last_reasoning_text="".join(self._full_reasoning_chunks).strip(),
            last_model=self._model_label,
        )


def json_render_tool_card(console, name, args_json, status, result, duration_ms):
    """Tool-card renderer for the JSON event stream.

    Same call signature as ``cli.branding.render_tool_card`` so it can
    be passed straight into ``BaseOpenAIProvider.stream_response`` as the
    ``render_tool_card`` argument. Tool results are truncated to keep
    the wire payload bounded; the host can request the full result via
    a follow-up tool history view if it cares.
    """
    emit(
        "tool",
        name=name,
        args=args_json,
        status=status,
        result=(result or "")[:5000],
        duration_ms=duration_ms,
    )


# ── Orchestrator stub ────────────────────────────────────────────────────


class _NoopOrchestrator:
    """Drop-in for crowe_synapse_engine.Orchestrator when it isn't available.

    The CLI uses the orchestrator to log tool executions to a SQLite
    history DB. Headless mode tries to load the real one for parity, but
    falls back to a no-op so the agent never crashes if Crowe Synapse
    isn't installed in the host environment (e.g., a slimmed-down
    container image).
    """

    def record_execution(self, **_kwargs):
        return None


_orchestrator_singleton = None


def _get_orchestrator():
    global _orchestrator_singleton
    if _orchestrator_singleton is not None:
        return _orchestrator_singleton
    try:
        from crowe_synapse_engine import Orchestrator
        _orchestrator_singleton = Orchestrator(
            db_path=os.path.expanduser("~/.crowe-logic/memory.db"),
            agents_dir=os.path.join(_PACKAGE_ROOT, "agents"),
            templates_dir=os.path.join(_PACKAGE_ROOT, "crowe_synapse_engine", "templates"),
        )
    except Exception:
        _orchestrator_singleton = _NoopOrchestrator()
    return _orchestrator_singleton


# ── Provider selection ──────────────────────────────────────────────────


# Provider kinds this headless runner knows how to construct. Anything
# outside this set (watsonx, mistral, cohere, fireworks, etc.) is silently
# skipped during auto-selection so the chain falls through to the next
# supported entry instead of raising "Headless mode does not support
# provider kind 'X'".
_HEADLESS_SUPPORTED_PROVIDERS = frozenset({
    "openrouter",
    "ollama",
    "nvidia",
    "openai_compat",
    "azure_openai",
    "anthropic",
})


def _is_provider_credentialed(cfg: dict) -> bool:
    """Best-effort check that a model's required env vars are populated.

    Returns False when we can predict the provider would raise immediately
    on construction. Used during auto-selection to skip models that lack
    credentials so /api/gateway/chat/stream picks the first model that can
    actually answer instead of erroring on the first unconfigured one.
    """
    kind = cfg.get("provider", "openrouter")
    if kind == "openrouter":
        return bool(os.environ.get("OPENROUTER_API_KEY", ""))
    if kind == "ollama":
        return True
    if kind == "nvidia":
        return bool(os.environ.get("NVIDIA_NIM_ENDPOINT", "")) and bool(os.environ.get("NVIDIA_API_KEY", ""))
    if kind == "openai_compat":
        endpoint_var = cfg.get("endpoint_env", "CROWE_OPEN_ENDPOINT")
        return bool(os.environ.get(endpoint_var, ""))
    if kind == "azure_openai":
        from config.agent_config import azure_openai_runtime_config
        return not azure_openai_runtime_config(cfg)["missing"]
    if kind == "anthropic":
        endpoint_var = cfg.get("endpoint_env", "AZURE_ANTHROPIC_ENDPOINT")
        api_key_var = cfg.get("api_key_env", "AZURE_ANTHROPIC_API_KEY")
        return bool(os.environ.get(endpoint_var, "")) and bool(os.environ.get(api_key_var, ""))
    return False


def _pick_auto_model(chain: list[dict]) -> dict:
    """Pick the first chain entry whose provider is supported AND credentialed.

    Falls back to chain[0] if nothing qualifies; that preserves the original
    error path so the user sees a clear message naming a model from their
    config rather than something synthetic.
    """
    for cfg in chain:
        if cfg.get("provider", "openrouter") not in _HEADLESS_SUPPORTED_PROVIDERS:
            continue
        if not _is_provider_credentialed(cfg):
            continue
        return cfg
    return chain[0]


def _build_provider(model_id: str, *, session_id: str = ""):
    """Construct a provider for the requested model.

    ``model_id`` is either ``"auto"`` (use the first SUPPORTED + credentialed
    entry in MODEL_CHAIN) or the ``name`` field of a MODEL_CHAIN entry.
    Reuses MODEL_CHAIN so the headless mode and the interactive CLI agree
    on which models exist and how to authenticate against each provider.

    For 'auto', unsupported provider kinds (watsonx, mistral, cohere,
    fireworks, etc.) are skipped and the chain falls through to the next
    qualifying model. For an explicit model_id naming an unsupported
    provider, we still raise so the caller sees what went wrong.
    """
    from config.agent_config import MODEL_CHAIN, resolve_model_config, provider_model_name

    chain = list(MODEL_CHAIN)
    if not chain:
        raise RuntimeError("MODEL_CHAIN is empty in config/agent_config.py")

    if model_id == "auto":
        cfg = _pick_auto_model(chain)
    else:
        cfg = resolve_model_config(model_id)
        if cfg is None:
            raise RuntimeError(
                f"Unknown model '{model_id}'. Use 'auto' or one of: "
                + ", ".join(m["name"] for m in chain[:10])
                + ("..." if len(chain) > 10 else "")
            )
        # The router entry (e.g. crowelm-auto) is a meta-model with
        # provider="auto"; resolve it the same way as the literal "auto"
        # by picking the first credentialed concrete tier.
        if cfg.get("provider") == "auto":
            cfg = _pick_auto_model(chain)

    provider_kind = cfg.get("provider", "openrouter")
    label = cfg.get("label", "CroweLM")
    name = provider_model_name(cfg)
    system_instructions = build_runtime_system_instructions(cfg, session_id=session_id)

    if provider_kind == "openrouter":
        from config.agent_config import OPENROUTER_API_KEY, OPENROUTER_BASE_URL
        from providers.openrouter import OpenRouterProvider
        if not OPENROUTER_API_KEY:
            raise RuntimeError("OPENROUTER_API_KEY is not set")
        return OpenRouterProvider(
            api_key=OPENROUTER_API_KEY,
            base_url=OPENROUTER_BASE_URL,
            model=name,
            system_instructions=system_instructions,
            label=label,
        )

    if provider_kind == "ollama":
        from config.agent_config import OLLAMA_BASE_URL
        from providers.ollama import OllamaProvider
        return OllamaProvider(
            model=name,
            system_instructions=system_instructions,
            base_url=OLLAMA_BASE_URL,
            label=label,
        )

    if provider_kind == "nvidia":
        from config.agent_config import NVIDIA_NIM_ENDPOINT, NVIDIA_API_KEY
        from providers.nvidia import NvidiaProvider
        if not NVIDIA_NIM_ENDPOINT or not NVIDIA_API_KEY:
            raise RuntimeError(
                "NVIDIA_NIM_ENDPOINT and NVIDIA_API_KEY must both be set "
                "to use the nvidia provider"
            )
        return NvidiaProvider(
            model=name,
            system_instructions=system_instructions,
            endpoint=NVIDIA_NIM_ENDPOINT,
            api_key=NVIDIA_API_KEY,
            label=label,
        )

    if provider_kind == "openai_compat":
        from providers.hosted_openai import HostedOpenAIProvider
        endpoint_var = cfg.get("endpoint_env", "CROWE_OPEN_ENDPOINT")
        api_key_var = cfg.get("api_key_env", "CROWE_OPEN_API_KEY")
        endpoint = os.environ.get(endpoint_var, "")
        api_key = os.environ.get(api_key_var, "")
        if not endpoint:
            raise RuntimeError(
                f"Hosted model '{label}' is missing an endpoint "
                f"({endpoint_var})"
            )
        return HostedOpenAIProvider(
            model=name,
            system_instructions=system_instructions,
            endpoint=endpoint,
            api_key=api_key,
            label=label,
        )

    if provider_kind == "azure_openai":
        from providers.azure_openai import AzureOpenAIProvider, AzureResponsesProvider
        from config.agent_config import azure_openai_runtime_config
        runtime = azure_openai_runtime_config(cfg)
        if runtime["missing"]:
            raise RuntimeError(
                f"Azure model '{label}' is missing credentials "
                f"({' / '.join(runtime['missing'])})"
            )
        provider_cls = AzureResponsesProvider if cfg.get("surface") == "responses" else AzureOpenAIProvider
        return provider_cls(
            model=runtime["model"],
            system_instructions=system_instructions,
            endpoint=runtime["endpoint"],
            api_key=runtime["api_key"],
            label=label,
        )

    if provider_kind == "anthropic":
        from providers.anthropic import AnthropicProvider
        endpoint_var = cfg.get("endpoint_env", "AZURE_ANTHROPIC_ENDPOINT")
        api_key_var = cfg.get("api_key_env", "AZURE_ANTHROPIC_API_KEY")
        endpoint = os.environ.get(endpoint_var, "")
        api_key = os.environ.get(api_key_var, "")
        if not endpoint or not api_key:
            raise RuntimeError(
                f"Anthropic model '{label}' is missing credentials "
                f"({endpoint_var} / {api_key_var})"
            )
        return AnthropicProvider(
            model=name,
            system_instructions=system_instructions,
            endpoint=endpoint,
            api_key=api_key,
            label=label,
        )

    raise RuntimeError(f"Headless mode does not support provider kind '{provider_kind}'")


# ── Main ────────────────────────────────────────────────────────────────


def _read_input(args) -> dict:
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            return json.load(f)
    raw = sys.stdin.read()
    if not raw.strip():
        raise RuntimeError("No input on stdin (expected a JSON object)")
    return json.loads(raw)


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="crowe-logic-command",
        description="Run one Crowe Logic Command turn and emit JSON events.",
    )
    parser.add_argument("--input", help="Read JSON input from this file instead of stdin")
    parser.add_argument("--model", default="auto",
                        help="Model id from MODEL_CHAIN (default: first entry)")
    args = parser.parse_args()

    try:
        payload = _read_input(args)
    except Exception as e:
        emit_error(f"Failed to read input: {e}", kind="input")
        return 2

    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        emit_error("Input must include a non-empty 'messages' array", kind="input")
        return 2

    # Defensively drop any prior turns whose content is empty / whitespace.
    # Anthropic 400s with "messages.0: user messages must have non-empty
    # content" when the wire payload has a role:user/content:"" entry, and
    # the chat webview's history occasionally contains one of these from
    # a previously-aborted turn (the assistant text never accumulated, so
    # only the user message landed in history). Filtering here covers
    # every caller that talks to this script, not just the IDE.
    messages = [
        m for m in messages
        if isinstance(m, dict)
        and m.get("role") in ("user", "assistant")
        and isinstance(m.get("content"), str)
        and m["content"].strip()
    ]
    if not messages:
        emit_error("All input messages had empty content after filtering", kind="input")
        return 2
    if messages[-1].get("role") != "user":
        emit_error("Input messages must end with a user turn", kind="input")
        return 2

    model_id = payload.get("model") or args.model
    session_id = payload.get("session") or "headless"

    local_response = handle_local_control_command(messages[-1].get("content") or "", session_id=session_id)
    if local_response is not None:
        emit("ready")
        emit("token", delta=local_response)
        emit("done", tokens=max(1, len(local_response.split())), reasoning_tokens=0, elapsed_ms=0, ttft_ms=0)
        return 0

    try:
        provider = _build_provider(model_id, session_id=session_id)
    except Exception as e:
        emit_error(str(e), kind="config")
        return 3

    # Replay the prior turns into the provider's internal state, then
    # call add_user_message for the trailing user turn. The provider
    # was just constructed so its messages list contains only the
    # system prompt; we append every prior turn so the model sees the
    # full conversation context VS Code already tracks for us. Tool
    # messages on input are ignored — the host doesn't track them,
    # the provider will recreate them as the agent runs tools.
    for msg in messages[:-1]:
        if not isinstance(msg, dict):
            continue
        role = msg.get("role")
        if role in ("user", "assistant"):
            provider.messages.append({"role": role, "content": msg.get("content") or ""})
    provider.add_user_message(messages[-1].get("content") or "")

    session_state = {
        "favicon": "",
        "tool_count": 0,
        "session_id": session_id,
        "active_model": getattr(provider, "label", ""),
    }
    renderer = JsonStreamRenderer(session_id=session_id, model_label=getattr(provider, "label", ""))

    try:
        provider.stream_response(
            console=None,
            render_tool_card=json_render_tool_card,
            session_state=session_state,
            _get_orchestrator=_get_orchestrator,
            renderer=renderer,
        )
    except KeyboardInterrupt:
        renderer.abort(session_state=session_state)
        emit_error("Interrupted", kind="cancelled")
        return 130
    except Exception as e:
        emit_error(f"{type(e).__name__}: {e}", kind="provider")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
