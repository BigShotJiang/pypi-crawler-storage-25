from __future__ import annotations

from enum import Enum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field


# --- Base model ---

class _AstaModel(BaseModel):
    """Base class providing standard serialization for all Asta models."""
    model_config = ConfigDict(populate_by_name=True)

    def to_dict(self) -> dict:
        return self.model_dump(by_alias=True, exclude_none=True)

    @classmethod
    def from_dict(cls, data: dict) -> Self:
        return cls.model_validate(data)


# --- Enums ---

class EntityType(str, Enum):
    PAPER = "PAPER"


class AnnotationType(str, Enum):
    SNIPPET = "SNIPPET"
    FACET = "FACET"
    DISPLAY_TEXT = "DISPLAY_TEXT"


class ContentBlockType(str, Enum):
    SECTION = "SECTION"
    SECTIONS = "SECTIONS"
    MARKDOWN = "MARKDOWN"
    FIGURE = "FIGURE"
    CODE = "CODE"


# --- Entity models (re-exported from asta-types) ---

from asta_types import S2Author, S2Paper  # noqa: F401


def paper_tag(entity_id: str, annotation_id: str, corpus_id: str | None, citation: str, artifact_id: str | None = None) -> str:
    """Build an inline ``<paper>`` tag for embedding in markdown content."""
    parts = [f'entityId="{entity_id}"', f'annotationId="{annotation_id}"']
    if corpus_id:
        parts.append(f'corpusId="{corpus_id}"')
    if artifact_id:
        parts.append(f'artifactId="{artifact_id}"')
    return f"<paper {' '.join(parts)}>{citation}</paper>"


class Paper(_AstaModel):
    id: str
    type: EntityType = EntityType.PAPER
    display_label: str | None = Field(None, alias="displayLabel")
    s2_metadata: S2Paper | None = Field(None, alias="s2Metadata")

    def to_dict(self) -> dict:
        d = self.model_dump(by_alias=True, exclude_none=True)
        # type is an enum — serialize as string value
        d["type"] = self.type.value
        return d


# --- Annotation models ---

class _AnnotationBase(_AstaModel):
    id: str
    entity_id: str = Field(alias="entityId")


class Snippet(_AnnotationBase):
    type: AnnotationType = AnnotationType.SNIPPET
    text: str = ""
    heading: str | None = None
    sentence_id: str | None = Field(None, alias="sentenceId")

    def to_dict(self) -> dict:
        d = self.model_dump(by_alias=True, exclude_none=True)
        d["type"] = self.type.value
        return d


class Facet(_AnnotationBase):
    type: AnnotationType = AnnotationType.FACET
    name: str = ""
    value: str | int | float | bool = ""

    def to_dict(self) -> dict:
        d = self.model_dump(by_alias=True, exclude_none=True)
        d["type"] = self.type.value
        return d


class DisplayText(_AnnotationBase):
    type: AnnotationType = AnnotationType.DISPLAY_TEXT
    text: str = ""

    def to_dict(self) -> dict:
        d = self.model_dump(by_alias=True, exclude_none=True)
        d["type"] = self.type.value
        return d


# Union types
Annotation = Snippet | Facet | DisplayText
