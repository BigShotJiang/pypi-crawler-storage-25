"""Artifacts CLI — export A2A task artifacts to various formats.

Usage:
    artifacts --input test-output/ --output export/
    artifacts --input test-output/ --output export/ --format html
"""

from __future__ import annotations

import json
import os
import sys

import click

from asta_artifact import Artifact
from asta_artifact.exporter import (
    export_artifacts_to_html_directory,
    export_artifacts_to_md_directory,
)


def _entry_from_artifact_dict(art: dict) -> dict:
    """Build an entry for a single A2A Artifact dict.

    Returns a dict with kind='asta' (entities+content DataPart) or kind='raw'
    (any other data). Non-data parts are ignored.
    """
    artifact_id = art.get("artifact_id") or art.get("artifactId") or ""
    name = art.get("name") or artifact_id
    description = art.get("description")
    art_meta = art.get("metadata") or {}
    type_tag = art_meta.get("type")

    data = None
    content_type = None
    is_asta = False
    for part in art.get("parts", []) or []:
        pdata = part.get("data") if isinstance(part, dict) else None
        if pdata is None:
            continue
        pmeta = (part.get("metadata") or {}) if isinstance(part, dict) else {}
        ct = pmeta.get("contentType") or pmeta.get("mimeType")
        if content_type is None:
            content_type = ct
        if (isinstance(pdata, dict)
                and "entities" in pdata and "content" in pdata):
            is_asta = True
            data = pdata
            break
        if data is None:
            data = pdata

    if is_asta:
        return {
            "kind": "asta",
            "artifact_id": artifact_id,
            "name": name,
            "description": description,
            "artifact": Artifact.from_dict(data),
            "content_type": content_type,
            "type_tag": type_tag,
        }
    return {
        "kind": "raw",
        "artifact_id": artifact_id,
        "name": name,
        "description": description,
        "data": data,
        "content_type": content_type,
        "type_tag": type_tag,
    }


def _entries_from_doc(data: dict) -> list[dict]:
    """Extract entries from a loaded JSON doc, preserving artifact order."""
    entries: list[dict] = []
    # Unwrap JSON-RPC envelope: {"jsonrpc": ..., "result": {...}}
    if (isinstance(data, dict) and "result" in data
            and isinstance(data["result"], dict)):
        data = data["result"]
    if isinstance(data, dict) and isinstance(data.get("artifacts"), list):
        for art in data["artifacts"]:
            if isinstance(art, dict):
                entries.append(_entry_from_artifact_dict(art))
    elif isinstance(data, dict) and "parts" in data and (
            "artifact_id" in data or "artifactId" in data):
        entries.append(_entry_from_artifact_dict(data))
    elif isinstance(data, dict) and "entities" in data and "content" in data:
        entries.append({
            "kind": "asta",
            "artifact_id": data.get("id", ""),
            "name": data.get("name", data.get("id", "")),
            "description": data.get("description"),
            "artifact": Artifact.from_dict(data),
            "content_type": None,
            "type_tag": None,
        })
    return entries


def _load_entries_from_dir(input_dir: str) -> list[dict]:
    """Load all artifact entries from JSON files in input_dir.

    Entries are returned in the order they appear inside each file, with
    files iterated in ascending filename order. The caller reverses to
    get newest-first.
    """
    entries: list[dict] = []
    for fname in sorted(os.listdir(input_dir)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(input_dir, fname)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        entries.extend(_entries_from_doc(data))
    return entries


@click.command()
@click.option("--input", "input_dir", required=True,
              help="Directory containing result JSON files")
@click.option("--output", "output_dir", required=True,
              help="Directory to write exported files")
@click.option("--format", "fmt", default="html",
              type=click.Choice(["html", "md"]),
              help="Output format (default: html)")
def main(input_dir: str, output_dir: str, fmt: str) -> None:
    """Export A2A task artifacts to HTML or Markdown."""
    if not os.path.isdir(input_dir):
        click.echo(f"Error: {input_dir} is not a directory")
        sys.exit(1)

    entries = _load_entries_from_dir(input_dir)
    if not entries:
        click.echo(f"Error: no artifacts found in {input_dir}")
        sys.exit(1)

    click.echo(f"Loaded {len(entries)} artifacts from {input_dir}")

    if fmt == "html":
        export_artifacts_to_html_directory(entries, output_dir)
    elif fmt == "md":
        export_artifacts_to_md_directory(entries, output_dir)

    click.echo(f"Exported to {output_dir}")


if __name__ == "__main__":
    main()
