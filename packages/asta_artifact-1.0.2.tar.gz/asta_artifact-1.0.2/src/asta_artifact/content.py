from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Literal

from pydantic import Field

from .models import ContentBlockType, _AstaModel

if TYPE_CHECKING:
    from .artifact import Artifact


class Section(_AstaModel):
    id: str
    type: Literal["SECTION"] = "SECTION"
    title: str
    description: str | None = None
    child_ids: list[str] = Field(default_factory=list, alias="childIds")
    annotation_ids: list[str] = Field(default_factory=list, alias="annotationIds")


class Markdown(_AstaModel):
    id: str
    type: Literal["MARKDOWN"] = "MARKDOWN"
    text: str
    annotation_ids: list[str] = Field(default_factory=list, alias="annotationIds")


class Figure(_AstaModel):
    id: str
    type: Literal["FIGURE"] = "FIGURE"
    imageb64: str
    caption: str | None = None
    annotation_ids: list[str] = Field(default_factory=list, alias="annotationIds")


class Code(_AstaModel):
    id: str
    type: Literal["CODE"] = "CODE"
    code: str
    language: str | None = None
    annotation_ids: list[str] = Field(default_factory=list, alias="annotationIds")


class Sections(_AstaModel):
    id: str
    type: Literal["SECTIONS"] = "SECTIONS"
    title: str
    child_ids: list[str] = Field(default_factory=list, alias="childIds")
    annotation_ids: list[str] = Field(default_factory=list, alias="annotationIds")


# Union type
ContentBlock = Section | Sections | Markdown | Figure | Code

# Dict dispatch for content_block_from_dict
_BLOCK_FACTORIES = {
    ContentBlockType.SECTION.value: Section.from_dict,
    ContentBlockType.SECTIONS.value: Sections.from_dict,
    ContentBlockType.MARKDOWN.value: Markdown.from_dict,
    ContentBlockType.FIGURE.value: Figure.from_dict,
    ContentBlockType.CODE.value: Code.from_dict,
}


def content_block_from_dict(data: dict) -> ContentBlock:
    block_type = data.get("type")
    factory = _BLOCK_FACTORIES.get(block_type)
    if factory is None:
        raise ValueError(f"Unknown content block type: {block_type}")
    return factory(data)


class SectionsContext:
    """Context manager for building child sections inside a SECTIONS block."""

    def __init__(self, artifact: Artifact, sections_block: Sections):
        self._artifact = artifact
        self._sections_block = sections_block

    @contextmanager
    def section(self, title: str):
        """Create a child SECTION and yield a SectionContext for adding content."""
        content_id = self._artifact._next_content_id()
        sec = Section(id=content_id, title=title)
        self._artifact._content.append(sec)
        self._sections_block.child_ids.append(content_id)
        ctx = SectionContext(self._artifact, sec)
        yield ctx


class SectionContext:
    """Context manager for building content within a section."""

    def __init__(self, artifact: Artifact, section: Section):
        self._artifact = artifact
        self._section = section

    def _add(self, block_cls, **kwargs):
        content_id = self._artifact._next_content_id()
        block = block_cls(id=content_id, **kwargs)
        self._artifact._content.append(block)
        self._section.child_ids.append(content_id)
        return block

    def markdown(self, text: str) -> Markdown:
        return self._add(Markdown, text=text)

    def table(self, headers: list[str], rows: list[list[str]]) -> Markdown:
        """Render a markdown table. Values are auto-escaped for pipes and newlines."""
        def _esc(v: str) -> str:
            return str(v).replace("|", "\\|").replace("\n", " ")
        lines = [
            "| " + " | ".join(headers) + " |",
            "| " + " | ".join("---" for _ in headers) + " |",
        ]
        for row in rows:
            lines.append("| " + " | ".join(_esc(v) for v in row) + " |")
        return self._add(Markdown, text="\n".join(lines))

    def bullet_list(self, items: list, header: str | None = None) -> Markdown:
        """Render a markdown bullet list with an optional bold header.

        Items can be strings or dicts (uses the ``text`` key).
        """
        lines = []
        if header:
            lines.append(f"**{header}:**")
        for item in items:
            text = item.get("text", str(item)) if isinstance(item, dict) else str(item)
            lines.append(f"- {text}")
        return self._add(Markdown, text="\n".join(lines))

    def figure(self, imageb64: str, caption: str | None = None) -> Figure:
        return self._add(Figure, imageb64=imageb64, caption=caption)

    def code(self, code: str, language: str | None = None) -> Code:
        return self._add(Code, code=code, language=language)

    @contextmanager
    def sections(self, title: str):
        """Create a nested SECTIONS container and yield a SectionsContext."""
        content_id = self._artifact._next_content_id()
        block = Sections(id=content_id, title=title)
        self._artifact._content.append(block)
        self._section.child_ids.append(content_id)
        ctx = SectionsContext(self._artifact, block)
        yield ctx
