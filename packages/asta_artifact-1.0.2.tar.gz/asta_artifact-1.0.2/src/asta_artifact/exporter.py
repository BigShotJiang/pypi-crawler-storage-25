"""Artifact HTML exporter — renders Asta artifacts as standalone HTML pages."""

from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING

from .models import AnnotationType, Paper, Snippet, Facet, DisplayText
from .content import Section, Sections, Markdown, Figure, Code

if TYPE_CHECKING:
    from .artifact import Artifact

_ARTIFACT_REF_RE = re.compile(
    r'<artifact\s+id="([^"]+)"(?:\s+contentId="([^"]*)")?(?:\s*/>|>(?P<label>[^<]*)</artifact>)'
)

_PAPER_TAG_RE = re.compile(
    r"""<paper\s+entityId=["']([^"']+)["']\s+annotationId=["']([^"']+)["']"""
    r"""(?:\s+corpusId=["']([^"']+)["'])?"""
    r"""(?:\s+artifactId=["']([^"']+)["'])?\s*>"""
    r"""([^<]*)</paper>"""
)


# ---- CSS ----

COMMON_STYLES = """
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap');
body { font-family: Manrope, Arial, sans-serif; line-height: 1.6; max-width: 900px; margin: 0 auto; padding: 20px; color: #0A3235; background: #FAF2E9; }
h1, h2, h3 { font-weight: 700; }
h1 { font-size: 1.5em; border-bottom: 2px solid #105257; padding-bottom: 8px; }
h2 { font-size: 1.2em; margin-top: 24px; color: #105257; }
.desc { background: #fff; padding: 12px; margin: 12px 0; border-left: 3px solid #0FCB8C; border-radius: 4px; }
.entity-card { background: #fff; padding: 12px; margin: 8px 0; border-left: 3px solid #0FCB8C; border-radius: 4px; }
.entity-card .label { font-weight: 700; font-size: 1.05em; }
.entity-card .meta { font-size: 0.9em; color: #5D5D5D; margin-top: 4px; }
.annotation-group { margin: 12px 0; padding: 10px; background: #fff; border: 1px solid #D6D6D6; border-radius: 4px; }
.annotation-group h4 { margin: 0 0 8px 0; font-size: 0.95em; color: #5D5D5D; }
.snippet { margin: 6px 0; padding: 8px; background: #FAF2E9; border-left: 2px solid #F0529C; font-size: 0.93em; }
.snippet .heading { font-weight: 700; color: #0A3235; margin-bottom: 2px; }
.facet { display: inline-block; padding: 2px 8px; margin: 2px 4px; background: #E6FAF3; color: #105257; border-radius: 10px; font-size: 0.85em; }
.facet strong { color: #0A3235; }
.facet-group { display: flex; flex-wrap: wrap; gap: 4px; margin: 6px 0; }
.facet-detail { margin: 6px 0; padding: 6px 10px; background: #fff; border-radius: 4px; font-size: 0.9em; line-height: 1.5; }
.display-text { margin: 4px 0; font-size: 0.93em; color: #5D5D5D; }
details { margin: 8px 0; }
details summary { cursor: pointer; font-weight: 600; padding: 8px; background: #fff; border: 1px solid #D6D6D6; border-radius: 4px; color: #105257; }
details summary:hover { background: #E6FAF3; }
details > .section-body { padding: 12px; border: 1px solid #D6D6D6; border-top: none; background: #fff; }
pre { background: #0A3235; color: #FAF2E9; padding: 12px; overflow-x: auto; font-size: 0.9em; border-radius: 4px; }
code { font-family: 'Space Mono', monospace; }
a { color: #105257; text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; }
a:hover { color: #F0529C; }
table { border-collapse: collapse; width: 100%; margin: 12px 0; }
th, td { border: 1px solid #D6D6D6; padding: 8px 12px; text-align: left; }
th { background: #105257; color: #FAF2E9; font-weight: 600; }
tr:nth-child(even) { background: #fff; }
tr:nth-child(odd) { background: #FAF2E9; }
.toc { margin-bottom: 20px; }
.toc ul { list-style: none; padding: 0; }
.toc li { margin: 4px 0; }
.evidence { margin: 12px 0; padding: 10px; background: #fff; border-left: 3px solid #B11BE8; border-radius: 4px; }
.evidence ul { margin: 6px 0; padding-left: 20px; }
.evidence li { margin: 4px 0; font-size: 0.93em; line-height: 1.5; }
.evidence a { color: #105257; text-decoration: none; }
.evidence a:hover { color: #F0529C; text-decoration: underline; }
.evidence-line { margin: 6px 0; }
.evidence-line p { display: inline; }
.entity-badge { display: inline-block; padding: 1px 8px; margin: 1px 3px; background: #E6FAF3; border-radius: 10px; font-size: 0.8em; color: #105257; text-decoration: none; white-space: nowrap; vertical-align: middle; }
.entity-badge:hover { background: #0FCB8C; color: #fff; text-decoration: none; }
.paper-tag { display: inline-block; padding: 1px 8px; margin: 1px 3px; background: #E6FAF3; border-radius: 10px; font-size: 0.8em; color: #105257; text-decoration: none; white-space: nowrap; vertical-align: middle; cursor: pointer; }
nav a { text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; }
.ev-inline { display: inline-flex; align-items: center; border: 1px solid #888; border-radius: 4px; overflow: hidden; font-size: 0.82em; background: #E6FAF3; vertical-align: middle; margin: 0 2px; line-height: 1.2; }
.ev-ext { padding: 2px 7px; color: #5D5D5D; text-decoration: none; white-space: nowrap; border-right: 1px solid #888; }
.ev-ext:hover { background: #d0f0e4; color: #105257; }
.ev-cite { padding: 2px 7px; color: #105257; text-decoration: none; white-space: nowrap; font-weight: 500; }
.ev-cite:hover { background: #d0f0e4; color: #F0529C; }
.ev-div { width: 0; border-left: 1px solid #888; align-self: stretch; }
.ev-row { margin: 6px 0; display: flex; flex-wrap: wrap; gap: 6px; }
.annotation-item { background: #fff; padding: 12px; margin: 8px 0; border-left: 3px solid #B11BE8; border-radius: 4px; }
.annotation-header { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 6px; }
.annotation-type-badge { display: inline-block; padding: 1px 8px; background: #f0e6ff; color: #7b2fbe; border-radius: 10px; font-size: 0.78em; text-transform: uppercase; letter-spacing: 0.04em; white-space: nowrap; flex-shrink: 0; margin-top: 2px; }
.annotation-paper { flex: 1; }
.annotation-paper-title { font-weight: 700; color: #105257; font-size: 0.95em; }
.annotation-paper-meta { display: block; font-size: 0.85em; color: #5D5D5D; margin-top: 2px; }
.annotation-heading { font-size: 0.88em; color: #5D5D5D; font-style: italic; margin: 4px 0 4px 0; }
.annotation-text { margin-top: 6px; padding: 8px 10px; background: #FAF2E9; border-left: 2px solid #F0529C; font-size: 0.93em; line-height: 1.5; }
.annotation-extraction-link { margin-top: 6px; font-size: 0.85em; }
.annotation-extraction-link a { color: #105257; font-weight: 500; }
"""


# ---- Helpers ----

def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _resolve_content_id(content_id: str) -> str:
    """Convert a datum content ID to the HTML anchor used by the extraction exporter.

    Extraction artifacts auto-generate section IDs as c_001, c_003, c_005, …
    (section+child pairs per datum).  Deep links encode the datum index in the
    uuid fragment, e.g. ``uuid-e5181.0`` → index 0 → section ``c-001``.
    """
    m = re.match(r'^uuid-e\d+\.(\d+)$', content_id)
    if m:
        idx = int(m.group(1))
        return f"c-{2 * idx + 1:03d}"
    # Already in c-NNN form or unknown — pass through unchanged.
    return content_id


def _short_paper_label(entity: Paper) -> str:
    """Generate a short badge label from a Paper entity."""
    meta = entity.s2_metadata
    if meta:
        parts = []
        if meta.authors:
            first = meta.authors[0].name.split()[-1] if meta.authors[0].name else ""
            if len(meta.authors) > 2:
                parts.append(first + " et al.")
            elif len(meta.authors) == 2:
                parts.append(first)
            else:
                parts.append(first)
        if meta.year:
            parts.append(str(meta.year))
        label = " ".join(parts)
        if label:
            return label
    label = entity.display_label or ""
    if len(label) > 60:
        return label[:60] + "..."
    return label or "ref"


def _markdown_to_html(text: str) -> str:
    import markdown
    # Ensure blank line before list items so markdown renders them properly
    text = re.sub(r'(\S)\n([-*+] )', r'\1\n\n\2', text)
    text = re.sub(r'(\S)\n(\d+\. )', r'\1\n\n\2', text)
    return markdown.markdown(text, extensions=["extra", "tables"])


def _create_html_page(title: str, content: str, css: str) -> str:
    return (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '    <meta charset="UTF-8">\n'
        '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f'    <title>{_escape_html(title)}</title>\n'
        f'    <style>{css}</style>\n'
        '</head>\n<body>\n'
        f'{content}\n'
        '</body>\n</html>'
    )


# ---- Exporter ----

class ArtifactExporter:
    """Export artifacts to HTML."""

    _PAPER_REF_RE = re.compile(r'paper-([0-9a-f]{20,})')

    def __init__(self, artifact: Artifact):
        self.artifact = artifact
        self._annotations_by_entity: dict[str, list] = defaultdict(list)
        for ann in artifact.annotations.values():
            self._annotations_by_entity[ann.entity_id].append(ann)
        self._inline_annotation_ids: set[str] = set()
        for block in artifact.content:
            if hasattr(block, 'annotation_ids'):
                self._inline_annotation_ids.update(block.annotation_ids)
        self._entity_links: dict[str, str] = {}
        self._source_links: dict[str, str] = {}
        self._source_names: dict[str, str] = {}
        self._ann_to_extraction: dict[str, tuple[str, str | None]] = {}
        self._scan_paper_tags()

    def _scan_paper_tags(self) -> None:
        """Build ann_id → (artifact_id, content_id) from <paper> tags in content."""
        for block in self.artifact.content:
            if not hasattr(block, 'text'):
                continue
            for m in _PAPER_TAG_RE.finditer(block.text):
                ann_id = m.group(2)
                artifact_ref = m.group(4)
                if ann_id and artifact_ref:
                    art_id, _, cid = artifact_ref.partition('#')
                    self._ann_to_extraction[ann_id] = (art_id, cid or None)

    def _render_entity(self, entity_id: str, entity: Paper,
                       link_href: str | None = None) -> str:
        parts = []
        label = _escape_html(entity.display_label or entity.id)

        # Build S2 URL
        s2_url = None
        if entity_id.startswith("paper-"):
            corpus_id = entity_id[6:]
            if corpus_id.isdigit():
                s2_url = f"https://www.semanticscholar.org/paper/{corpus_id}"
        if s2_url is None and entity.s2_metadata and entity.s2_metadata.corpus_id:
            s2_url = f"https://www.semanticscholar.org/paper/{entity.s2_metadata.corpus_id}"

        parts.append(f'<div class="entity-card" id="entity-{entity_id}">')
        if s2_url:
            parts.append(f'<div class="label"><a href="{s2_url}">{label}</a></div>')
        else:
            parts.append(f'<div class="label">{label}</div>')

        meta = entity.s2_metadata
        if meta:
            meta_items = []
            if meta.authors:
                author_names = ", ".join(a.name for a in meta.authors[:3])
                if len(meta.authors) > 3:
                    author_names += " et al."
                meta_items.append(author_names)
            if meta.year:
                meta_items.append(str(meta.year))
            if meta.venue:
                meta_items.append(meta.venue)
            if s2_url:
                meta_items.append(f'<a href="{s2_url}">Semantic Scholar</a>')
            if meta_items:
                parts.append(f'<div class="meta">{" | ".join(meta_items)}</div>')

        parts.append('</div>')
        return '\n'.join(parts)

    def _render_annotations_for_entity(self, entity_id: str) -> str:
        annotations = self._annotations_by_entity.get(entity_id, [])
        if not annotations:
            return ''

        facets = []
        display_texts = []
        for a in annotations:
            if isinstance(a, Facet) and a.id not in self._inline_annotation_ids:
                facets.append(a)
            elif isinstance(a, DisplayText):
                display_texts.append(a)

        if not facets and not display_texts:
            return ''

        parts = ['<div class="annotation-group">']

        if facets:
            # Short facets as pills, long ones as detail blocks
            short = [f for f in facets if len(str(f.value)) <= 60]
            long = [f for f in facets if len(str(f.value)) > 60]
            if short:
                parts.append('<div class="facet-group">')
                for f in short:
                    parts.append(
                        f'<span class="facet"><strong>{_escape_html(f.name)}:</strong> '
                        f'{_escape_html(str(f.value))}</span>'
                    )
                parts.append('</div>')
            for f in long:
                parts.append(
                    f'<div class="facet-detail"><strong>{_escape_html(f.name)}:</strong> '
                    f'{_escape_html(str(f.value))}</div>'
                )

        for dt in display_texts:
            parts.append(f'<div class="display-text">{_escape_html(dt.text)}</div>')

        parts.append('</div>')
        return '\n'.join(parts)

    def _entity_s2_url(self, entity_id: str, entity: Paper) -> str | None:
        if entity_id.startswith("paper-"):
            cid = entity_id[6:]
            if cid.isdigit():
                return f"https://www.semanticscholar.org/paper/{cid}"
        if entity.s2_metadata and entity.s2_metadata.corpus_id:
            return f"https://www.semanticscholar.org/paper/{entity.s2_metadata.corpus_id}"
        return None

    def _render_annotation_item(self, ann_id: str, ann: Snippet) -> str:
        """Render a single Snippet annotation: type badge + source paper + extracted text."""
        entity = self.artifact.entities.get(ann.entity_id)
        parts = [f'<div class="annotation-item" id="{ann_id}">']
        parts.append('<div class="annotation-header">')
        parts.append('<span class="annotation-type-badge">Snippet</span>')

        if entity:
            s2_url = self._entity_s2_url(ann.entity_id, entity)
            label = _escape_html(entity.display_label or ann.entity_id)
            title_html = (f'<a href="{s2_url}" class="annotation-paper-title">{label}</a>'
                          if s2_url else f'<span class="annotation-paper-title">{label}</span>')
            meta = entity.s2_metadata
            meta_html = ''
            if meta:
                items = []
                if meta.authors:
                    names = ", ".join(a.name for a in meta.authors[:3])
                    if len(meta.authors) > 3:
                        names += " et al."
                    items.append(_escape_html(names))
                if meta.year:
                    items.append(str(meta.year))
                if meta.venue:
                    items.append(_escape_html(meta.venue))
                if items:
                    meta_html = f'<span class="annotation-paper-meta">{" | ".join(items)}</span>'
            parts.append(f'<div class="annotation-paper">{title_html}{meta_html}</div>')

        parts.append('</div>')  # annotation-header

        if ann.heading:
            parts.append(f'<div class="annotation-heading">{_escape_html(ann.heading)}</div>')

        if ann.text:
            clean = re.sub(r'<artifact[^>]*/>', '', ann.text).strip()
            if clean:
                parts.append(f'<div class="annotation-text">{_escape_html(clean)}</div>')

        # Link to specific datum in extraction artifact
        extraction_ref = self._ann_to_extraction.get(ann_id)
        if extraction_ref:
            art_id, content_id = extraction_ref
            base_href = self._source_links.get(art_id)
            if base_href:
                anchor = _resolve_content_id(content_id) if content_id else None
                href = f"{base_href}#{anchor}" if anchor else base_href
                art_name = self._source_names.get(art_id, "extraction")
                parts.append(
                    f'<div class="annotation-extraction-link">'
                    f'<a href="{href}">View in {_escape_html(art_name)} \u2192</a>'
                    f'</div>'
                )

        parts.append('</div>')
        return '\n'.join(parts)

    @staticmethod
    def _parse_source_ref(text: str) -> tuple[str, str | None] | None:
        """Parse ``<artifact id="..." contentId="..." />`` from snippet text."""
        m = _ARTIFACT_REF_RE.search(text)
        if m:
            return m.group(1), m.group(2)
        return None

    def _resolve_snippet_link(self, snip: Snippet) -> str | None:
        """Resolve the best link for a snippet badge.

        Parses ``<artifact id="..." contentId="..." />`` from the snippet text
        to resolve source deep-links.  Falls back to entity_id -> file mapping.
        """
        ref = self._parse_source_ref(snip.text)
        if ref:
            artifact_id, content_id = ref
            base = self._source_links.get(artifact_id)
            if base:
                if content_id:
                    return base + "#" + content_id
                return base
        return self._entity_links.get(snip.entity_id)

    def _render_description(self, text: str) -> str:
        """Render description text, resolving inline artifact and paper references.

        Replaces ``<artifact id="..." />`` with named links and ``paper-{hash}``
        with Semantic Scholar links, while escaping all other text.
        """
        replacements = []
        for m in _ARTIFACT_REF_RE.finditer(text):
            artifact_id = m.group(1)
            inline_label = m.group("label")
            href = self._source_links.get(artifact_id)
            label = inline_label or self._source_names.get(artifact_id) or _escape_html(artifact_id)
            if href:
                replacements.append((m.start(), m.end(), f'<a href="{href}">{label}</a>'))
            else:
                replacements.append((m.start(), m.end(), label))

        for m in _PAPER_TAG_RE.finditer(text):
            if not any(s <= m.start() and e >= m.end() for s, e, _ in replacements):
                entity_id = m.group(1)
                corpus_id = m.group(3)
                citation = m.group(5)
                # Build S2 link
                s2_url = None
                if corpus_id:
                    s2_url = f"https://www.semanticscholar.org/paper/{corpus_id}"
                elif entity_id in self.artifact.entities:
                    entity = self.artifact.entities[entity_id]
                    if entity.s2_metadata and entity.s2_metadata.corpus_id:
                        s2_url = f"https://www.semanticscholar.org/paper/{entity.s2_metadata.corpus_id}"
                if s2_url:
                    replacements.append((m.start(), m.end(),
                                         f'<a href="{s2_url}" class="paper-tag">{_escape_html(citation)}</a>'))
                else:
                    replacements.append((m.start(), m.end(),
                                         f'<span class="paper-tag">{_escape_html(citation)}</span>'))

        for m in self._PAPER_REF_RE.finditer(text):
            if not any(s <= m.start() and e >= m.end() for s, e, _ in replacements):
                paper_key = m.group(0)
                corpus_id = m.group(1)
                entity = self.artifact.entities.get(paper_key)
                s2_url = f"https://www.semanticscholar.org/paper/{corpus_id}"
                if entity:
                    label = _escape_html(entity.display_label or paper_key)
                    replacements.append((m.start(), m.end(), f'<a href="{s2_url}">{label}</a>'))

        if not replacements:
            return _escape_html(text)

        replacements.sort(key=lambda r: r[0])
        parts = []
        last_end = 0
        for start, end, html in replacements:
            if start > last_end:
                parts.append(_escape_html(text[last_end:start]))
            parts.append(html)
            last_end = end
        if last_end < len(text):
            parts.append(_escape_html(text[last_end:]))
        return ''.join(parts)

    def _replace_artifact_tags(self, html: str) -> str:
        """Replace <artifact id="...">label</artifact> tags in rendered HTML with anchor links."""
        def _replace(m):
            artifact_id = m.group(1)
            inline_label = m.group("label")
            href = self._source_links.get(artifact_id)
            label = inline_label or self._source_names.get(artifact_id) or _escape_html(artifact_id)
            if href:
                return f'<a href="{href}">{label}</a>'
            return label
        return _ARTIFACT_REF_RE.sub(_replace, html)

    def _replace_paper_tags(self, html: str) -> str:
        """Replace <paper> tags with inline evidence button groups."""
        def _replace(m):
            entity_id = m.group(1)
            annotation_id = m.group(2)
            corpus_id = m.group(3)
            artifact_ref = m.group(4)
            citation = m.group(5)

            # Resolve S2 link
            s2_url = None
            if corpus_id:
                s2_url = f"https://www.semanticscholar.org/paper/{corpus_id}"
            elif entity_id in self.artifact.entities:
                entity = self.artifact.entities[entity_id]
                if entity.s2_metadata and entity.s2_metadata.corpus_id:
                    s2_url = f"https://www.semanticscholar.org/paper/{entity.s2_metadata.corpus_id}"

            # Resolve extraction deep-link (resolve content-id to HTML anchor)
            extraction_link = None
            if artifact_ref:
                art_id, _, content_id = artifact_ref.partition("#")
                base = self._source_links.get(art_id)
                if base:
                    anchor = _resolve_content_id(content_id) if content_id else None
                    extraction_link = f"{base}#{anchor}" if anchor else base
            else:
                # Fallback: resolve from annotation snippet text
                ann = self.artifact.annotations.get(annotation_id)
                if ann and isinstance(ann, Snippet):
                    ref = self._parse_source_ref(ann.text)
                    if ref:
                        base = self._source_links.get(ref[0])
                        if base:
                            anchor = _resolve_content_id(ref[1]) if ref[1] else None
                            extraction_link = f"{base}#{anchor}" if anchor else base

            # Single citation pill — links to extraction datum, falls back to S2
            cite_href = extraction_link or s2_url
            ann_attr = f' data-ann="{annotation_id}"' if annotation_id else ''
            if cite_href:
                return (f'<span class="ev-inline"{ann_attr}>'
                        f'<a href="{cite_href}" class="ev-cite">{_escape_html(citation)}</a>'
                        f'</span>')
            return (f'<span class="ev-inline"{ann_attr}>'
                    f'<span class="ev-cite">{_escape_html(citation)}</span>'
                    f'</span>')
        return _PAPER_TAG_RE.sub(_replace, html)

    def _render_content_block(self, block, content_by_id: dict) -> str:
        if isinstance(block, Sections):
            inner_parts = []
            for child_id in block.child_ids:
                child = content_by_id.get(child_id)
                if child:
                    inner_parts.append(self._render_content_block(child, content_by_id))

            section_id = block.id.replace("_", "-")
            parts = [f'<details open id="{_escape_html(section_id)}">']
            parts.append(f'<summary>{_escape_html(block.title)}</summary>')
            parts.append('<div class="section-body">')
            parts.extend(inner_parts)
            parts.append('</div></details>')
            return '\n'.join(parts)

        if isinstance(block, Section):
            inner_parts = []
            for child_id in block.child_ids:
                child = content_by_id.get(child_id)
                if child:
                    inner_parts.append(self._render_content_block(child, content_by_id))

            section_id = block.id.replace("_", "-")
            parts = [f'<details open id="{_escape_html(section_id)}">']
            parts.append(f'<summary>{_escape_html(block.title)}</summary>')
            parts.append('<div class="section-body">')

            if block.description:
                parts.append(f'<div class="desc">{self._render_description(block.description)}</div>')

            parts.extend(inner_parts)
            parts.append('</div></details>')
            return '\n'.join(parts)

        if isinstance(block, Markdown):
            html = _markdown_to_html(block.text)
            html = self._replace_artifact_tags(html)
            html = self._replace_paper_tags(html)

            # Render inline annotations (facets + snippet evidence pills)
            if block.annotation_ids:
                has_paper_tags = _PAPER_TAG_RE.search(block.text) is not None
                snippets = []
                facets = []
                for aid in block.annotation_ids:
                    ann = self.artifact.annotations.get(aid)
                    if isinstance(ann, Snippet) and not has_paper_tags:
                        snippets.append(ann)
                    elif isinstance(ann, Facet):
                        facets.append(ann)

                # Evidence pills from snippet annotations
                evidence_pills = []
                seen_entities: set[str] = set()
                for snip in snippets:
                    eid = snip.entity_id
                    if eid in seen_entities:
                        continue
                    seen_entities.add(eid)
                    entity = self.artifact.entities.get(eid)
                    citation = _short_paper_label(entity) if entity else eid

                    s2_url = None
                    if entity and entity.s2_metadata and entity.s2_metadata.corpus_id:
                        s2_url = f"https://www.semanticscholar.org/paper/{entity.s2_metadata.corpus_id}"
                    elif eid.startswith("paper-"):
                        cid = eid[6:]
                        if cid.isdigit():
                            s2_url = f"https://www.semanticscholar.org/paper/{cid}"

                    if s2_url:
                        evidence_pills.append(f'<a href="{s2_url}" class="ev-cite">{_escape_html(citation)}</a>')
                    else:
                        evidence_pills.append(f'<span class="ev-cite">{_escape_html(citation)}</span>')

                seen_facets: set[str] = set()
                pills = []
                for f in facets:
                    key = f"{f.name}:{f.value}"
                    if key in seen_facets:
                        continue
                    seen_facets.add(key)
                    pills.append(
                        f'<span class="facet"><strong>{_escape_html(f.name)}:</strong> '
                        f'{_escape_html(str(f.value))}</span>'
                    )

                extra = ''
                if evidence_pills:
                    extra += '\n<div class="ev-row">' + ' '.join(
                        f'<span class="ev-inline">{p}</span>' for p in evidence_pills
                    ) + '</div>'
                if pills:
                    extra += '\n<div class="facet-group">' + ''.join(pills) + '</div>'

                return f'<div class="evidence-line">{html}{extra}</div>'

            return f'<div class="evidence-line">{html}</div>'

        if isinstance(block, Figure):
            parts = ['<figure>']
            if block.imageb64:
                parts.append(f'<img src="data:image/png;base64,{block.imageb64}" alt="Figure" style="max-width:100%">')
            if block.caption:
                parts.append(f'<figcaption>{_escape_html(block.caption)}</figcaption>')
            parts.append('</figure>')
            return '\n'.join(parts)

        if isinstance(block, Code):
            lang = block.language or ''
            return f'<pre><code class="language-{_escape_html(lang)}">{_escape_html(block.code)}</code></pre>'

        return ''

    def to_html(self, include_entities: bool = True,
                include_raw_json: bool = False,
                entity_links: dict | None = None,
                source_links: dict | None = None,
                source_names: dict | None = None,
                nav_html: str | None = None) -> str:
        if entity_links:
            self._entity_links = entity_links
        if source_links:
            self._source_links = source_links
        if source_names:
            self._source_names = source_names

        html: list[str] = []
        if nav_html:
            html.append(nav_html)

        html.append(f'<h1>{_escape_html(self.artifact.name)}</h1>')

        # Build content_by_id lookup and identify child blocks
        content_by_id: dict = {}
        child_block_ids: set[str] = set()
        for block in self.artifact.content:
            content_by_id[block.id] = block
            if isinstance(block, (Section, Sections)):
                child_block_ids.update(block.child_ids)

        # Table of contents for top-level sections only
        sections = [b for b in self.artifact.content
                    if isinstance(b, (Section, Sections)) and b.id not in child_block_ids]
        if sections:
            html.append('<div class="toc"><strong>Contents:</strong><ul>')
            for sec in sections:
                sec_id = sec.id.replace("_", "-")
                html.append(f'<li><a href="#{_escape_html(sec_id)}">{_escape_html(sec.title)}</a></li>')
            html.append('</ul></div>')

        # Render only top-level content (skip blocks owned by sections)
        for block in self.artifact.content:
            if block.id in child_block_ids:
                continue
            html.append(self._render_content_block(block, content_by_id))

        # Related artifacts
        if self._source_links:
            items = []
            for artifact_id, href in sorted(self._source_links.items()):
                label = self._source_names.get(artifact_id, artifact_id)
                items.append(f'<li><a href="{href}">{_escape_html(label)}</a></li>')
            if items:
                html.append('<hr><nav class="toc"><strong>Related Artifacts:</strong><ul>')
                html.extend(items)
                html.append('</ul></nav>')

        # Entities section — source papers with S2 links
        if include_entities and self.artifact.entities:
            html.append('<hr><h2>Entities</h2>')
            for entity_id, entity in self.artifact.entities.items():
                if isinstance(entity, Paper):
                    html.append(self._render_entity(entity_id, entity))
                    ann_html = self._render_annotations_for_entity(entity_id)
                    if ann_html:
                        html.append(ann_html)

        # Raw JSON
        if include_raw_json:
            html.append('<hr><h2>Raw JSON (Debug)</h2>')
            html.append(f'<pre>{_escape_html(json.dumps(self.artifact.to_dict(), indent=2))}</pre>')

        return _create_html_page(self.artifact.name, '\n'.join(html), COMMON_STYLES)

    def save_html(self, path: str | Path, **kwargs) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(self.to_html(**kwargs))


# ---- Markdown conversion ----

_EV_INLINE_RE = re.compile(
    r'<span class="ev-inline"(?:\s+data-ann="(?P<ann>[^"]*)")?\s*>'
    r'(?P<body>.*?)</span>',
    re.DOTALL,
)
_EV_EXT_RE = re.compile(
    r'<a\s+href="(?P<href>[^"]+)"\s+class="ev-ext">(?P<label>[^<]+)</a>')
_EV_CITE_RE = re.compile(
    r'<(?:a\s+href="(?P<href>[^"]+)"|span)\s+class="ev-cite">(?P<label>[^<]+)</(?:a|span)>')
_DETAILS_RE = re.compile(
    r'<details[^>]*>\s*<summary[^>]*>(?P<title>.*?)</summary>\s*'
    r'<div class="section-body">(?P<body>.*?)</div>\s*</details>',
    re.DOTALL,
)
_DETAILS_NOWRAP_RE = re.compile(
    r'<details[^>]*>\s*<summary[^>]*>(?P<title>.*?)</summary>'
    r'(?P<body>.*?)</details>',
    re.DOTALL,
)


def _preprocess_html_for_md(
    html: str,
    artifact: Artifact,
    details_level: int = 3,
) -> tuple[str, list]:
    """Rewrite custom HTML constructs into plain markdown-ready HTML.

    Returns ``(html, [])`` — evidence pills are converted to inline ``<a>``
    links (extraction deep-link preferred, S2 fallback) so html2text renders
    them as ``[citation](href)``.

    * ``<span class="ev-inline" data-ann="X">...</span>`` — replaced with
      an inline anchor to the extraction datum or Semantic Scholar.
    * ``<details>/<summary>`` — flattened to ``<hN>title</hN>`` + body.
    """
    def _replace_ev(m: re.Match) -> str:
        body = m.group('body') or ''

        # Prefer the extraction deep-link (ev-ext href)
        ext_href: str | None = None
        ext_match = _EV_EXT_RE.search(body)
        if ext_match:
            ext_href = ext_match.group('href')

        citation: str = ''
        s2_url: str | None = None
        cite_match = _EV_CITE_RE.search(body)
        if cite_match:
            s2_url = cite_match.group('href') if cite_match.group('href') else None
            citation = cite_match.group('label').strip()

        if not citation:
            return ''

        href = ext_href or s2_url
        if href:
            return f'<a href="{href}">{citation}</a>'
        return citation

    html = _EV_INLINE_RE.sub(_replace_ev, html)

    def _flatten_details(match: re.Match) -> str:
        title = match.group('title').strip()
        body = match.group('body')
        return f'<h{details_level}>{title}</h{details_level}>\n{body}\n'

    html = _DETAILS_RE.sub(_flatten_details, html)
    html = _DETAILS_NOWRAP_RE.sub(_flatten_details, html)
    return html, []


def _render_footnotes_md(footnotes: list[tuple]) -> str:
    """Render the footnote definitions block in GFM footnote syntax."""
    if not footnotes:
        return ''
    lines = ['', '---', '']
    for idx, entry in enumerate(footnotes, start=1):
        citation = entry[0] if len(entry) > 0 else ''
        snippet = entry[1] if len(entry) > 1 else ''
        url = entry[2] if len(entry) > 2 else None
        title = entry[3] if len(entry) > 3 else ''

        parts: list[str] = []
        if snippet:
            parts.append(f'"{snippet}"')

        ref_parts = []
        if citation:
            ref_parts.append(citation)
        if title:
            ref_parts.append(f'*{title}*')
        ref = ', '.join(ref_parts)

        if ref and url:
            parts.append(f'{ref}. [↗]({url})')
        elif ref:
            parts.append(ref)

        body = ' — '.join(parts) if parts else '(no reference)'
        lines.append(f'[^{idx}]: {body}')
    return '\n'.join(lines) + '\n'


def _html_to_markdown(html: str, artifact: Artifact,
                      html_to_md_filenames: dict[str, str] | None = None) -> str:
    """Convert a rendered artifact HTML page to Markdown via html2text.

    ``html_to_md_filenames`` maps ``.html`` filenames to ``.md`` filenames
    so cross-artifact links are rewritten to the MD file names.
    """
    import html2text

    pre_html, footnotes = _preprocess_html_for_md(html, artifact)

    h = html2text.HTML2Text()
    h.body_width = 0
    h.ignore_images = True
    h.ignore_emphasis = False
    h.protect_links = True
    h.mark_code = True
    md = h.handle(pre_html)

    # Rewrite .html → .md for cross-artifact relative links.
    if html_to_md_filenames:
        for html_name, md_name in html_to_md_filenames.items():
            md = md.replace(html_name, md_name)

    md = md.rstrip() + '\n'
    md += _render_footnotes_md(footnotes)
    return md


# ---- BibTeX helpers ----

def _bibtex_citekey(entity_id: str, entity: Paper) -> str:
    """Generate a BibTeX citation key: {lastname}{year}{title_word}."""
    meta = entity.s2_metadata
    lastname = 'anon'
    year = ''
    title_word = ''

    if meta:
        if meta.authors:
            name = (meta.authors[0].name or '').strip()
            parts = name.split()
            if parts:
                lastname = re.sub(r'[^a-zA-Z]', '', parts[-1]).lower() or 'anon'
        if meta.year:
            year = str(meta.year)

    stopwords = {'a', 'an', 'the', 'on', 'in', 'of', 'for', 'and', 'or', 'is', 'are',
                 'to', 'from', 'with', 'using', 'via', 'at'}
    for word in (entity.display_label or '').split():
        clean = re.sub(r'[^a-zA-Z0-9]', '', word).lower()
        if clean and clean not in stopwords:
            title_word = clean[:10]
            break

    return f"{lastname}{year}{title_word}"


def _bibtex_entry(citekey: str, entity_id: str, entity: Paper) -> str:
    """Render a single BibTeX @article entry."""
    meta = entity.s2_metadata
    lines = [f'@article{{{citekey},']

    if entity.display_label:
        lines.append(f'  title     = {{{entity.display_label}}},')

    if meta:
        if meta.authors:
            author_str = ' and '.join(a.name for a in meta.authors if a.name)
            if author_str:
                lines.append(f'  author    = {{{author_str}}},')
        if meta.year:
            lines.append(f'  year      = {{{meta.year}}},')
        if meta.venue:
            lines.append(f'  journal   = {{{meta.venue}}},')

    # S2 URL from entity_id or metadata
    url = None
    if entity_id.startswith('paper-'):
        cid = entity_id[6:]
        if cid.isdigit():
            url = f'https://www.semanticscholar.org/paper/{cid}'
    if url is None and meta and meta.corpus_id:
        url = f'https://www.semanticscholar.org/paper/{meta.corpus_id}'
    if url:
        lines.append(f'  url       = {{{url}}},')

    lines.append('}')
    return '\n'.join(lines)


# ---- Convenience functions ----

def export_artifact_to_html(artifact: Artifact, path: str | Path) -> None:
    """Convenience function to export an artifact to HTML."""
    ArtifactExporter(artifact).save_html(path)


def export_artifact_to_md(artifact: Artifact, path: str | Path) -> None:
    """Convenience function to export an artifact to Markdown."""
    exporter = ArtifactExporter(artifact)
    html = exporter.to_html()
    md = _html_to_markdown(html, artifact)
    Path(path).write_text(md, encoding='utf-8')


def export_artifact_directory_to_html(artifact_dir: str | Path,
                                      output_path: str | Path) -> None:
    """Export an artifact directory (with artifact.json) to HTML."""
    from .artifact import Artifact
    artifact_dir = Path(artifact_dir)
    json_path = artifact_dir / "artifact.json"
    if not json_path.exists():
        raise FileNotFoundError(f"artifact.json not found in {artifact_dir}")
    artifact = Artifact.load(json_path)
    export_artifact_to_html(artifact, output_path)


# ---- Multi-artifact directory export ----

def _slugify(text: str) -> str:
    """Convert text to a filesystem-safe slug."""
    import re
    slug = text.lower().strip()
    slug = re.sub(r'[^\w\s-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug).rstrip('-')
    return slug


def _build_links(artifact: Artifact, other_artifacts: list[Artifact],
                 other_filenames: dict[str, str]):
    """Build (entity_links, source_links, source_names) for an artifact.

    entity_links: entity_id -> href (Paper entities shared across artifacts)
    source_links: artifact_id -> href (for snippet source deep-links)
    source_names: artifact_id -> display name (for link labels)
    """
    entity_links: dict[str, str] = {}
    source_links: dict[str, str] = {}
    source_names: dict[str, str] = {}

    artifact_id_to_file: dict[str, str] = {}
    artifact_id_to_name: dict[str, str] = {}
    for other in other_artifacts:
        fname = other_filenames.get(other.id, '')
        artifact_id_to_file[other.id] = fname
        artifact_id_to_name[other.id] = other.name

    # Sort others: those with more annotations first
    sorted_others = sorted(other_artifacts, key=lambda a: len(a.annotations))

    # Map paper entities to files containing them
    paper_to_file: dict[str, str] = {}
    for other in sorted_others:
        for eid in other.entities:
            if eid not in paper_to_file:
                target = other_filenames.get(other.id)
                if target:
                    paper_to_file[eid] = target

    for eid in artifact.entities:
        if eid in paper_to_file:
            entity_links[eid] = paper_to_file[eid]

    # Build source links from snippet text and artifact content
    for ann in artifact.annotations.values():
        if isinstance(ann, Snippet):
            ref = ArtifactExporter._parse_source_ref(ann.text)
            if ref:
                aid = ref[0]
                if aid in artifact_id_to_file:
                    source_links[aid] = artifact_id_to_file[aid]
                    source_names[aid] = artifact_id_to_name.get(aid, aid)

    texts_to_scan = []
    if artifact.description:
        texts_to_scan.append(artifact.description)
    for block in artifact.content:
        if hasattr(block, 'text'):
            texts_to_scan.append(block.text)

    for text in texts_to_scan:
        for m in _ARTIFACT_REF_RE.finditer(text):
            aid = m.group(1)
            if aid in artifact_id_to_file:
                source_links[aid] = artifact_id_to_file[aid]
                source_names[aid] = artifact_id_to_name.get(aid, aid)

        # Also pick up extraction artifact IDs from <paper artifactId="..."> tags
        for m in _PAPER_TAG_RE.finditer(text):
            artifact_ref = m.group(4)
            if artifact_ref:
                aid = artifact_ref.split('#', 1)[0]
                if aid in artifact_id_to_file:
                    source_links[aid] = artifact_id_to_file[aid]
                    source_names[aid] = artifact_id_to_name.get(aid, aid)

    return entity_links, source_links, source_names


_INDEX_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap');
body { font-family: Manrope, Arial, sans-serif; margin: 0; padding: 20px 20px 40px; color: #0A3235; background: #FAF2E9; }
h1 { font-weight: 700; font-size: 1.5em; border-bottom: 2px solid #105257; padding-bottom: 8px; max-width: 960px; margin: 0 auto 24px; }
.group { max-width: 960px; margin: 0 auto 20px; }
.group-label { font-size: 0.88em; text-transform: uppercase; letter-spacing: 0.06em; color: #105257; font-weight: 700; margin: 8px 4px; }
.artifact-list { padding: 0; list-style: none; margin: 0; }
.artifact-list li { background: #fff; border: 1px solid #D6D6D6; border-radius: 6px; padding: 10px 14px; margin-bottom: 8px; font-size: 0.95em; }
.artifact-list a { color: #105257; text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; font-weight: 600; }
.artifact-list a:hover { color: #F0529C; }
.type-badge { display: inline-block; padding: 1px 8px; margin-left: 8px; background: #E6FAF3; color: #105257; border-radius: 10px; font-size: 0.75em; text-transform: uppercase; letter-spacing: 0.04em; }
.desc-line { color: #5D5D5D; font-size: 0.88em; margin-top: 4px; }
"""


# Maps subtype → (group label, display order). Lower order renders higher.
# Subtypes not listed fall into "Data" at the bottom.
_GROUPS: list[tuple[str, str, list[str]]] = [
    ("theories", "Theories", ["theory"]),
    ("novelty", "Novelty", ["novelty"]),
    ("extractions", "Extractions", ["extraction"]),
    ("schemas", "Schemas", ["extraction-schema"]),
    ("data", "Data", [
        "theory-store", "paper-store", "novelty-assessment", "asta-artifact",
    ]),
]


def _subtype_from_entry(entry: dict) -> str:
    """Derive the subtype token from an entry.

    Prefers the short Artifact.metadata.type tag, then parses the vendor
    MIME subtype from DataPart.metadata.contentType
    (``application/vnd.<vendor>.<subtype>+json``).
    """
    tag = entry.get("type_tag")
    if tag:
        return str(tag)
    ct = entry.get("content_type") or ""
    if "/" in ct:
        _, _, rest = ct.partition("/")
        rest = rest.split(";", 1)[0].strip()
        if rest.endswith("+json"):
            rest = rest[: -len("+json")]
        # vnd.<vendor>.<subtype>
        parts = rest.split(".")
        if len(parts) >= 3 and parts[0] == "vnd":
            return ".".join(parts[2:])
        return rest
    return ""


def _group_key(subtype: str) -> tuple[int, str]:
    """Return (priority, group_label) for a given subtype."""
    for idx, (_, label, members) in enumerate(_GROUPS):
        if subtype in members:
            return (idx, label)
    # Unknown subtypes fall under the last group ("Data").
    last_idx = len(_GROUPS) - 1
    return (last_idx, _GROUPS[last_idx][1])


def _group_dir(subtype: str) -> str:
    """Return the subdirectory name for a given subtype."""
    for gid, _, members in _GROUPS:
        if subtype in members:
            return gid
    return _GROUPS[-1][0]


def _rel_path(source_dir: str, target_path: str) -> str:
    """Relative link from source_dir to target_path (both subdir-prefixed paths)."""
    parts = target_path.split("/", 1)
    if len(parts) == 2 and parts[0] == source_dir:
        return parts[1]
    return f"../{target_path}" if "/" in target_path else target_path


def export_artifacts_to_html_directory(entries: list[dict] | list[Artifact],
                                       output_dir: str | Path) -> Path:
    """Export artifact entries to a flat index.html listing all artifacts
    newest-first (input order reversed).

    Accepts either:
      * A list of entry dicts with ``kind`` of ``"asta"`` or ``"raw"`` (as
        produced by the CLI loader). ``"asta"`` entries carry an
        ``Artifact`` and render to HTML; ``"raw"`` entries carry a
        ``data`` dict and are written verbatim as JSON.
      * A legacy list of :class:`Artifact` — each is treated as asta.

    Returns the path to the output directory.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    from .artifact import Artifact as _Artifact

    # Normalize legacy list[Artifact] input.
    norm: list[dict] = []
    for e in entries:
        if isinstance(e, _Artifact):
            norm.append({
                "kind": "asta",
                "artifact_id": e.id,
                "name": e.name,
                "description": e.description,
                "artifact": e,
                "content_type": None,
                "type_tag": None,
            })
        else:
            norm.append(dict(e))

    # Assign unique filenames under per-type subdirectories.
    used: dict[str, int] = {}

    def _uniq(base: str, ext: str, subdir: str) -> str:
        candidate = f"{subdir}/{base}.{ext}" if base else f"{subdir}/artifact.{ext}"
        n = used.get(candidate, 0)
        used[candidate] = n + 1
        if n == 0:
            return candidate
        return f"{subdir}/{base or 'artifact'}-{n}.{ext}"

    asta_entries = [e for e in norm if e["kind"] == "asta"]
    for e in asta_entries:
        art = e["artifact"]
        subtype = _subtype_from_entry(e)
        e["group_dir"] = _group_dir(subtype)
        slug = _slugify(e.get("name") or art.name or art.id or "artifact")
        e["filename"] = _uniq(slug, "html", e["group_dir"])

    # Render each asta artifact with cross-links to siblings.
    sibling_filenames_all = {e["artifact"].id: e["filename"] for e in asta_entries}
    for e in asta_entries:
        art = e["artifact"]
        source_dir = e["group_dir"]
        others = [o["artifact"] for o in asta_entries if o is not e]
        # Compute links relative to this artifact's subdirectory.
        sibling_filenames = {
            aid: _rel_path(source_dir, fname)
            for aid, fname in sibling_filenames_all.items()
            if aid != art.id
        }
        entity_links, source_links, source_names = _build_links(
            art, others, sibling_filenames
        )
        exporter = ArtifactExporter(art)
        back_nav = '<nav><a href="../index.html">&larr; All artifacts</a></nav>'
        html = exporter.to_html(
            entity_links=entity_links,
            source_links=source_links,
            source_names=source_names,
            nav_html=back_nav,
        )
        out_path = output_dir / e["filename"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")

    # Dump raw-data artifacts as JSON in the data/ subdir.
    for e in norm:
        if e["kind"] != "raw":
            continue
        subtype = _subtype_from_entry(e)
        subdir = _group_dir(subtype)
        e["group_dir"] = subdir
        slug = _slugify(e.get("name") or e.get("artifact_id") or "data")
        e["filename"] = _uniq(slug, "json", subdir)
        payload = e.get("data")
        out_path = output_dir / e["filename"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    # Partition entries into subtype groups, newest-first within each group.
    groups_buckets: dict[int, list[dict]] = {}
    group_labels: dict[int, str] = {}
    for e in reversed(norm):
        subtype = _subtype_from_entry(e)
        priority, label = _group_key(subtype)
        groups_buckets.setdefault(priority, []).append(e)
        group_labels[priority] = label

    body = ['<h1>Artifacts</h1>']
    for idx in range(len(_GROUPS)):
        bucket = groups_buckets.get(idx)
        if not bucket:
            continue
        body.append('<div class="group">')
        body.append(f'<div class="group-label">{_escape_html(group_labels[idx])}</div>')
        body.append('<ul class="artifact-list">')
        for e in bucket:
            name = _escape_html(e.get("name") or e.get("artifact_id") or "")
            href = e.get("filename", "")
            badge_tag = e.get("type_tag") or _subtype_from_entry(e)
            badge = (
                f' <span class="type-badge">{_escape_html(badge_tag)}</span>'
                if badge_tag else ''
            )
            desc = e.get("description")
            link = f'<a href="{href}">{name}</a>' if href else name
            body.append(f'<li>{link}{badge}')
            if desc:
                body.append(f'<div class="desc-line">{_escape_html(desc)}</div>')
            body.append('</li>')
        body.append('</ul></div>')

    index_html = _create_html_page('Artifacts', '\n'.join(body), _INDEX_CSS)
    (output_dir / 'index.html').write_text(index_html, encoding='utf-8')


def export_artifacts_to_md_directory(entries: list[dict] | list[Artifact],
                                     output_dir: str | Path) -> Path:
    """Export artifact entries as Markdown, grouped by subtype in index.md.

    Mirrors :func:`export_artifacts_to_html_directory`: asta entries render
    to ``.md`` via html2text; raw entries are dumped verbatim as ``.json``.
    Cross-artifact links use ``./slug.md``.
    """
    from .artifact import Artifact as _Artifact

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    norm: list[dict] = []
    for e in entries:
        if isinstance(e, _Artifact):
            norm.append({
                "kind": "asta",
                "artifact_id": e.id,
                "name": e.name,
                "description": e.description,
                "artifact": e,
                "content_type": None,
                "type_tag": None,
            })
        else:
            norm.append(dict(e))

    used: dict[str, int] = {}

    def _uniq(base: str, ext: str, subdir: str) -> str:
        candidate = f"{subdir}/{base}.{ext}" if base else f"{subdir}/artifact.{ext}"
        n = used.get(candidate, 0)
        used[candidate] = n + 1
        if n == 0:
            return candidate
        return f"{subdir}/{base or 'artifact'}-{n}.{ext}"

    asta_entries = [e for e in norm if e["kind"] == "asta"]

    # Assign md filenames under per-type subdirectories.
    html_to_md: dict[str, str] = {}
    for e in asta_entries:
        art = e["artifact"]
        subtype = _subtype_from_entry(e)
        e["group_dir"] = _group_dir(subtype)
        slug = _slugify(e.get("name") or art.name or art.id or "artifact")
        md_name = _uniq(slug, "md", e["group_dir"])
        e["filename"] = md_name
        html_name = md_name[:-3] + ".html"
        html_to_md[html_name] = md_name

    sibling_filenames_all = {e["artifact"].id: e["filename"] for e in asta_entries}

    for e in asta_entries:
        art = e["artifact"]
        source_dir = e["group_dir"]
        others = [o["artifact"] for o in asta_entries if o is not e]
        sibling_filenames = {
            aid: _rel_path(source_dir, fname)
            for aid, fname in sibling_filenames_all.items()
            if aid != art.id
        }
        entity_links, source_links, source_names = _build_links(
            art, others, sibling_filenames
        )
        exporter = ArtifactExporter(art)
        back_nav = '<nav><a href="../index.html">&larr; All artifacts</a></nav>'
        html = exporter.to_html(
            entity_links=entity_links,
            source_links=source_links,
            source_names=source_names,
            nav_html=back_nav,
        )
        md = _html_to_markdown(html, art, html_to_md_filenames=html_to_md)
        md = md.replace("../index.html", "../index.md")
        out_path = output_dir / e["filename"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(md, encoding="utf-8")

    for e in norm:
        if e["kind"] != "raw":
            continue
        subtype = _subtype_from_entry(e)
        subdir = _group_dir(subtype)
        e["group_dir"] = subdir
        slug = _slugify(e.get("name") or e.get("artifact_id") or "data")
        e["filename"] = _uniq(slug, "json", subdir)
        out_path = output_dir / e["filename"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(e.get("data"), indent=2, default=str), encoding="utf-8")

    # index.md grouped by subtype, newest-first within group.
    groups_buckets: dict[int, list[dict]] = {}
    group_labels: dict[int, str] = {}
    for e in reversed(norm):
        subtype = _subtype_from_entry(e)
        priority, label = _group_key(subtype)
        groups_buckets.setdefault(priority, []).append(e)
        group_labels[priority] = label

    md_lines: list[str] = ['# Artifacts', '']
    for idx in range(len(_GROUPS)):
        bucket = groups_buckets.get(idx)
        if not bucket:
            continue
        md_lines.append(f'## {group_labels[idx]}')
        md_lines.append('')
        for e in bucket:
            name = e.get("name") or e.get("artifact_id") or ""
            href = e.get("filename", "")
            tag = e.get("type_tag") or _subtype_from_entry(e)
            badge = f' _({tag})_' if tag else ''
            line = f'- [{name}]({href}){badge}' if href else f'- {name}{badge}'
            md_lines.append(line)
            desc = e.get("description")
            if desc:
                md_lines.append(f'  {desc}')
        md_lines.append('')

    (output_dir / 'index.md').write_text('\n'.join(md_lines), encoding='utf-8')

    # Collect all unique paper entities and write references.bib
    papers: dict[str, Paper] = {}
    for e in asta_entries:
        for eid, entity in e["artifact"].entities.items():
            if eid not in papers:
                papers[eid] = entity

    if papers:
        used_keys: dict[str, int] = {}
        bib_lines = ['% Auto-generated bibliography', '% Source: Asta artifact export', '']
        for eid, entity in sorted(papers.items()):
            key = _bibtex_citekey(eid, entity)
            n = used_keys.get(key, 0)
            used_keys[key] = n + 1
            if n > 0:
                key = f'{key}{n + 1}'
            bib_lines.append(_bibtex_entry(key, eid, entity))
            bib_lines.append('')
        (output_dir / 'references.bib').write_text('\n'.join(bib_lines), encoding='utf-8')

    return output_dir
