#!/bin/bash
IS_PROD=$1

rm dist/*
uv run python -m build

if [ "$IS_PROD" = "true" ]; then
uv run twine upload dist/*
else
uv run twine upload --repository testpypi dist/*
fi
