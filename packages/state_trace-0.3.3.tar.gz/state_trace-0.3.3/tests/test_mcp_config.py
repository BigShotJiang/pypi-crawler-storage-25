from __future__ import annotations

from state_trace.mcp_config import build_mcp_config


def test_build_mcp_config_uses_project_namespace_and_absolute_command() -> None:
    config = build_mcp_config(
        namespace="repo-x",
        storage_path="/Users/me/.state-trace/repo-x.db",
        command="/opt/bin/state-trace-mcp",
    )

    server = config["mcpServers"]["state-trace"]
    assert server["command"] == "/opt/bin/state-trace-mcp"
    assert server["env"] == {
        "STATE_TRACE_STORAGE_PATH": "/Users/me/.state-trace/repo-x.db",
        "STATE_TRACE_NAMESPACE": "repo-x",
        "STATE_TRACE_CAPACITY_LIMIT": "256",
    }


def test_build_mcp_config_keeps_fractional_capacity_limit() -> None:
    config = build_mcp_config(
        namespace="repo-x",
        storage_path="/tmp/repo-x.db",
        capacity_limit=128.5,
        command="state-trace-mcp",
    )

    assert config["mcpServers"]["state-trace"]["env"]["STATE_TRACE_CAPACITY_LIMIT"] == "128.5"
