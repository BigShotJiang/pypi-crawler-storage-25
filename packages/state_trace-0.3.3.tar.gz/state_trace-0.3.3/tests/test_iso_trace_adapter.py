"""Unit tests for the iso-trace ingestion adapter.

Tests use synthetic Session JSON matching @razroo/iso-trace's documented
types.d.ts shape, so the adapter is exercised independently of any
particular harness output format.
"""

from __future__ import annotations

import json
from pathlib import Path

from state_trace import MemoryEngine
from state_trace.iso_trace_adapter import (
    ingest_iso_trace_session,
    iso_trace_session_to_agent_log,
)


def _sample_iso_trace_session() -> dict:
    """A minimal Claude Code-style session: user prompt, assistant edits a
    file, runs a test, observes a failure, edits again, observes success."""
    return {
        "id": "claude-session-001",
        "source": {"harness": "claude-code", "format": "jsonl", "path": "/some/session.jsonl"},
        "cwd": "/Users/me/projects/my-repo",
        "model": "claude-sonnet-4-6",
        "startedAt": "2026-04-24T10:00:00Z",
        "endedAt": "2026-04-24T10:08:00Z",
        "durationMs": 480000,
        "tokenUsage": {"input": 12000, "output": 800, "cacheRead": 6000, "cacheCreated": 0},
        "turns": [
            {
                "index": 0,
                "role": "user",
                "at": "2026-04-24T10:00:00Z",
                "events": [
                    {
                        "kind": "message",
                        "role": "user",
                        "text": "Login still returns 401 after the refresh-token retry; please investigate src/auth.ts",
                    }
                ],
            },
            {
                "index": 1,
                "role": "assistant",
                "at": "2026-04-24T10:01:00Z",
                "events": [
                    {"kind": "message", "role": "assistant", "text": "Inspecting the refresh path."},
                    {"kind": "tool_call", "id": "call_1", "name": "Read", "input": {"file_path": "src/auth.ts"}},
                    {"kind": "tool_result", "toolUseId": "call_1", "output": "...source of src/auth.ts..."},
                    {"kind": "file_op", "op": "read", "path": "src/auth.ts", "tool": "Read"},
                ],
            },
            {
                "index": 2,
                "role": "assistant",
                "at": "2026-04-24T10:03:00Z",
                "events": [
                    {"kind": "message", "role": "assistant", "text": "Patching the retry to keep Authorization."},
                    {"kind": "tool_call", "id": "call_2", "name": "Edit", "input": {"file_path": "src/auth.ts", "old_string": "delete h.Authorization", "new_string": "// keep h.Authorization"}},
                    {"kind": "tool_result", "toolUseId": "call_2", "output": "Edit applied"},
                    {"kind": "file_op", "op": "edit", "path": "src/auth.ts", "tool": "Edit"},
                ],
            },
            {
                "index": 3,
                "role": "assistant",
                "at": "2026-04-24T10:05:00Z",
                "events": [
                    {"kind": "tool_call", "id": "call_3", "name": "Bash", "input": {"command": "pytest tests/test_auth.py::test_refresh_retry"}},
                    {"kind": "tool_result", "toolUseId": "call_3", "output": "tests/test_auth.py::test_refresh_retry FAILED"},
                ],
            },
            {
                "index": 4,
                "role": "assistant",
                "at": "2026-04-24T10:07:00Z",
                "events": [
                    {"kind": "tool_call", "id": "call_4", "name": "Edit", "input": {"file_path": "src/auth.ts", "old_string": "// keep h.Authorization", "new_string": "headers.Authorization = h.Authorization"}},
                    {"kind": "tool_result", "toolUseId": "call_4", "output": "Edit applied"},
                    {"kind": "file_op", "op": "edit", "path": "src/auth.ts", "tool": "Edit"},
                ],
            },
            {
                "index": 5,
                "role": "assistant",
                "at": "2026-04-24T10:08:00Z",
                "events": [
                    {"kind": "tool_call", "id": "call_5", "name": "Bash", "input": {"command": "pytest tests/test_auth.py::test_refresh_retry"}},
                    {"kind": "tool_result", "toolUseId": "call_5", "output": "tests/test_auth.py::test_refresh_retry PASSED"},
                ],
            },
        ],
    }


def test_session_to_agent_log_extracts_issue_and_steps() -> None:
    log = iso_trace_session_to_agent_log(_sample_iso_trace_session())

    assert log["format"] == "agent_log"
    assert log["source"] == "iso_trace"
    assert log["session_id"] == "claude-session-001"
    assert "Login still returns 401" in log["issue_text"]
    assert log["issue_title"].startswith("Login still returns 401")
    assert log["repo"] == "my-repo"  # derived from cwd basename

    # Skips the user-only turn 0; produces 5 actionable steps.
    assert len(log["steps"]) == 5

    # First action step should reflect the Read tool call.
    first = log["steps"][0]
    assert first["action_kind"] == "open"
    assert "src/auth.ts" in first["action"]
    assert "src/auth.ts" in first["files"]
    assert first["status"] == "info"

    # Edit step should preserve action and files.
    edit_step = log["steps"][1]
    assert edit_step["action_kind"] == "edit"
    assert "src/auth.ts" in edit_step["action"]
    assert "src/auth.ts" in edit_step["files"]

    # Failed test step should classify as error.
    failed = log["steps"][2]
    assert failed["status"] == "error"
    assert "FAILED" in failed["observation"]

    # Final passing test step should classify as success.
    passed = log["steps"][4]
    assert passed["status"] == "success"
    assert "PASSED" in passed["observation"]


def test_ingest_iso_trace_session_into_engine(tmp_path: Path) -> None:
    """End-to-end: write a session JSON, ingest it, verify the graph
    contains expected typed nodes."""
    session_path = tmp_path / "session.json"
    session_path.write_text(json.dumps(_sample_iso_trace_session()), encoding="utf-8")

    engine = MemoryEngine(capacity_limit=256.0)
    ingest_iso_trace_session(engine, session_path)

    types = {node.type for node in engine.graph_manager.all_nodes()}
    # Standard agent_log ingestion produces these typed nodes.
    assert {"task", "decision", "observation", "file"} <= types
    assert any(node.content == "src/auth.ts" for node in engine.graph_manager.all_nodes() if node.type == "file")

    # Brief should now surface src/auth.ts as the patch target.
    brief = engine.retrieve_brief(
        "which file should I patch to fix login?",
        {"session": "claude-session-001", "goal": "resume from claude-session-001"},
        mode="small_model",
    )
    assert brief["patch_file"] == "src/auth.ts" or "src/auth.ts" in brief.get("target_files", [])
