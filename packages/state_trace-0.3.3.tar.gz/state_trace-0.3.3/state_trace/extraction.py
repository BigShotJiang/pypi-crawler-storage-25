from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from state_trace.graph import GraphManager
from state_trace.types import Edge, Node
from state_trace.utils import estimate_capacity, extract_context_tokens, jaccard_similarity, slugify, tokenize


TASK_HINTS = {"fix", "implement", "investigate", "debug", "refactor", "add", "remove", "update"}
OBSERVATION_HINTS = {"error", "broken", "failed", "fails", "failing", "observed", "noticed", "returns", "401", "500"}
DECISION_HINTS = {"decide", "decided", "choose", "chosen", "adopt", "prefer", "will use"}
GOAL_HINTS = {"goal", "need to", "want to", "target", "objective"}


class ExtractionResult(BaseModel):
    node: Node
    keywords: list[str] = Field(default_factory=list)
    edge_candidates: list[Edge] = Field(default_factory=list)


def infer_node_type(text: str, context: dict[str, Any] | None = None) -> str:
    context = context or {}
    explicit_type = context.get("type") or context.get("node_type")
    if explicit_type:
        return str(explicit_type)

    lowered = text.lower()
    if context.get("patch_hunk") or text.lstrip().startswith("@@"):
        return "patch_hunk"
    if context.get("error_signature"):
        return "error_signature"
    if context.get("symbol"):
        return "symbol"
    if context.get("test_target") or context.get("node_kind") == "test":
        return "test"
    if context.get("command") or context.get("node_kind") == "command":
        return "command"
    if context.get("status") == "error" or context.get("error_signatures"):
        return "observation"
    if context.get("action_kind") in {"edit", "open", "find_file", "submit", "create"}:
        return "decision"
    if context.get("issue_text"):
        return "task"
    if context.get("file") or context.get("files"):
        return "file" if "/" in text or "." in text else "observation"
    if "/" in text or any(marker in lowered for marker in [".py", ".ts", ".js", ".tsx", ".json", ".md"]):
        return "file"
    if any(keyword in lowered for keyword in OBSERVATION_HINTS):
        return "observation"
    if any(keyword in lowered for keyword in TASK_HINTS):
        return "task"
    if any(keyword in lowered for keyword in DECISION_HINTS):
        return "decision"
    if any(keyword in lowered for keyword in GOAL_HINTS):
        return "goal"
    if context.get("session"):
        return "observation"
    return "concept"


def make_node_id(graph_manager: GraphManager, node_type: str, content: str, stable: bool = False) -> str:
    base_id = f"{node_type}:{slugify(content)}"
    if stable:
        return base_id

    candidate = base_id
    suffix = 2
    while graph_manager.has_node(candidate):
        candidate = f"{base_id}-{suffix}"
        suffix += 1
    return candidate


def make_anchor_node(
    graph_manager: GraphManager,
    anchor_type: str,
    content: str,
    metadata: dict[str, Any] | None = None,
) -> Node:
    anchor_id = make_node_id(graph_manager, anchor_type, content, stable=True)
    existing = graph_manager.get_node(anchor_id)
    if existing:
        return existing

    node = Node(
        id=anchor_id,
        type=anchor_type,
        content=content,
        importance=0.7 if anchor_type in {"goal", "session"} else 0.6,
        recency=1.0,
        capacity_used=estimate_capacity(content, metadata),
        capacity_max=8.0,
        metadata=metadata or {},
    )
    graph_manager.add_node(node)
    return node


def extract_event(text: str, context: dict[str, Any] | None, graph_manager: GraphManager) -> ExtractionResult:
    context = context or {}
    node_type = infer_node_type(text, context)
    metadata = dict(context)
    keywords = tokenize(text) | extract_context_tokens(context)
    metadata["keywords"] = sorted(keywords)
    metadata.setdefault("current", True)
    stable_id = bool(context.get("stable_id")) or node_type in {"file", "goal", "session"}
    node = Node(
        id=make_node_id(graph_manager, node_type, text, stable=stable_id),
        type=node_type,
        content=text,
        importance=float(context.get("importance", 0.55 if node_type in {"task", "decision", "goal"} else 0.45)),
        recency=1.0,
        capacity_used=estimate_capacity(text, metadata),
        capacity_max=float(context.get("capacity_max", 8.0)),
        event_at=context.get("event_at"),
        valid_at=context.get("valid_at"),
        invalid_at=context.get("invalid_at"),
        metadata=metadata,
    )
    edge_candidates = _extract_edge_candidates(node, context, graph_manager, keywords)
    return ExtractionResult(node=node, keywords=sorted(keywords), edge_candidates=edge_candidates)


def _extract_edge_candidates(
    node: Node,
    context: dict[str, Any],
    graph_manager: GraphManager,
    keywords: set[str],
) -> list[Edge]:
    edges: list[Edge] = []
    relation_map = {
        "related_to": "related_to",
        "depends_on": "depends_on",
        "blocks": "blocks",
        "solves": "solves",
        "causes": "causes",
        "motivates": "motivates",
        "validates": "validates",
        "precedes": "precedes",
        "supersedes": "supersedes",
        "rejected_by": "rejected_by",
        "supports": "supports",
        "contradicts": "contradicts",
        "verified_by": "verified_by",
    }
    for context_key, edge_type in relation_map.items():
        targets = context.get(context_key)
        if not targets:
            continue
        if isinstance(targets, str):
            targets = [targets]
        for target in targets:
            if graph_manager.has_node(target):
                edges.append(Edge(source=node.id, target=target, type=edge_type, weight=0.9))

    for file_value in _as_list(context.get("file")) + _as_list(context.get("files")):
        file_node = make_anchor_node(graph_manager, "file", str(file_value), {"path": str(file_value)})
        edge_type, weight = _infer_file_relationship(node, context)
        edges.append(Edge(source=node.id, target=file_node.id, type=edge_type, weight=weight))

    for session_value in _as_list(context.get("session")) + _as_list(context.get("session_id")):
        session_node = make_anchor_node(graph_manager, "session", str(session_value), {"session": str(session_value)})
        edges.append(Edge(source=session_node.id, target=node.id, type="contains", weight=1.0))

    for goal_value in _as_list(context.get("goal")):
        goal_node = make_anchor_node(graph_manager, "goal", str(goal_value), {"goal": str(goal_value)})
        edges.append(Edge(source=node.id, target=goal_node.id, type="supports", weight=0.9))

    auto_linking_disabled = bool(context.get("disable_auto_links")) or (
        context.get("source") in {"swe-agent", "openhands", "iso_trace"} and context.get("step_index") is not None
    )
    explicit_file_targets = {
        make_node_id(graph_manager, "file", str(file_value), stable=True)
        for file_value in (_as_list(context.get("file")) + _as_list(context.get("files")))
    }
    if not auto_linking_disabled:
        for candidate in graph_manager.all_nodes(include_compressed=False):
            if candidate.id == node.id:
                continue
            if explicit_file_targets and candidate.type == "file":
                continue
            candidate_keywords = set(candidate.metadata.get("keywords", [])) or tokenize(candidate.content)
            overlap = jaccard_similarity(keywords, candidate_keywords)
            if overlap < 0.18:
                continue
            edge_type = _infer_relationship(node.type, candidate.type)
            edges.append(Edge(source=node.id, target=candidate.id, type=edge_type, weight=min(1.0, 0.4 + overlap)))

    deduped: dict[tuple[str, str, str], Edge] = {}
    for edge in edges:
        deduped[(edge.source, edge.target, edge.type)] = edge
    return list(deduped.values())


def _infer_relationship(source_type: str, target_type: str) -> str:
    if source_type == "task" and target_type == "observation":
        return "solves"
    if source_type == "observation" and target_type == "task":
        return "blocks"
    if source_type == "command" and target_type == "test":
        return "runs"
    if source_type == "patch_hunk" and target_type == "file":
        return "patches_file"
    if source_type == "patch_hunk" and target_type == "symbol":
        return "touches_symbol"
    if source_type == "error_signature" and target_type == "file":
        return "fails_in"
    if source_type == "symbol" and target_type == "file":
        return "references_file"
    if target_type == "file":
        if source_type == "decision":
            return "touches_file"
        if source_type == "observation":
            return "mentions_file"
        if source_type == "command":
            return "touches_file"
        if source_type == "test":
            return "verifies"
        if source_type == "task":
            return "references_file"
        return "related_to"
    if source_type == "decision":
        return "depends_on"
    return "related_to"


def _infer_file_relationship(node: Node, context: dict[str, Any]) -> tuple[str, float]:
    if node.type == "task":
        return "references_file", 0.9

    if node.type == "decision":
        action_kind = str(context.get("action_kind", "")).lower()
        if action_kind in {"edit", "submit", "create"}:
            return "patches_file", 0.96
        if action_kind in {"open", "find_file", "read"}:
            return "touches_file", 0.9
        return "touches_file", 0.86

    if node.type == "observation":
        status = str(context.get("status", "")).lower()
        if status == "error":
            return "fails_in", 0.94
        return "mentions_file", 0.84

    return "related_to", 0.85


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]
