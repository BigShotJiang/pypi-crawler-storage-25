"""Generate project-scoped MCP client config for state-trace."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sysconfig
from pathlib import Path
from typing import Any


def _script_names() -> tuple[str, ...]:
    if os.name == "nt":
        return ("state-trace-mcp.exe", "state-trace-mcp")
    return ("state-trace-mcp",)


def resolve_entrypoint() -> str:
    """Return an absolute path to the installed state-trace-mcp script."""
    scripts_dir = sysconfig.get_path("scripts")
    if scripts_dir:
        for name in _script_names():
            candidate = Path(scripts_dir) / name
            if candidate.exists():
                return str(candidate)

    found = shutil.which("state-trace-mcp")
    if found:
        return found

    return "state-trace-mcp"


def build_mcp_config(
    *,
    name: str = "state-trace",
    namespace: str,
    storage_path: str,
    capacity_limit: float = 256.0,
    command: str | None = None,
) -> dict[str, Any]:
    capacity = float(capacity_limit)
    env: dict[str, str] = {
        "STATE_TRACE_STORAGE_PATH": storage_path,
        "STATE_TRACE_NAMESPACE": namespace,
        "STATE_TRACE_CAPACITY_LIMIT": str(int(capacity) if capacity.is_integer() else capacity),
    }
    return {
        "mcpServers": {
            name: {
                "command": command or resolve_entrypoint(),
                "env": env,
            }
        }
    }


def _default_namespace() -> str:
    name = Path.cwd().name.strip()
    return name or "state-trace"


def _default_storage(namespace: str) -> str:
    return str(Path.home() / ".state-trace" / f"{namespace}.db")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Print a project-level .mcp.json config for the installed state-trace MCP server."
    )
    parser.add_argument("--name", default="state-trace", help="MCP server name in the client config.")
    parser.add_argument(
        "--namespace",
        default=None,
        help="state-trace namespace. Defaults to the current directory name.",
    )
    parser.add_argument(
        "--storage-path",
        default=None,
        help="SQLite/JSON memory path. Defaults to ~/.state-trace/<namespace>.db.",
    )
    parser.add_argument(
        "--capacity-limit",
        type=float,
        default=256.0,
        help="Working-memory budget in capacity units.",
    )
    parser.add_argument(
        "--command",
        default=None,
        help="Override the state-trace-mcp command path.",
    )
    args = parser.parse_args()

    namespace = args.namespace or _default_namespace()
    storage_path = args.storage_path or _default_storage(namespace)
    config = build_mcp_config(
        name=args.name,
        namespace=namespace,
        storage_path=storage_path,
        capacity_limit=args.capacity_limit,
        command=args.command,
    )
    print(json.dumps(config, indent=2))


if __name__ == "__main__":  # pragma: no cover
    main()
