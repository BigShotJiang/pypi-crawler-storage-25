from __future__ import annotations

import heapq
import math
import re
from collections import Counter
from typing import Any

import networkx as nx
from pydantic import BaseModel

from state_trace.graph import GraphManager
from state_trace.scoring import ScoreConfig, score_node
from state_trace.types import Node
from state_trace.utils import (
    FILE_EXTENSION_RE,
    compact_text,
    extract_context_tokens,
    extract_file_paths,
    extract_test_targets,
    flatten_context_values,
    is_test_target,
    jaccard_similarity,
    tokenize,
    tokenize_sequence,
)


FAILURE_TERMS = {"broken", "bug", "error", "fail", "failed", "failing", "failure", "why"}
FILE_TERMS = {"edit", "file", "patch", "touch", "where", "which"}
HISTORY_TERMS = {"after", "before", "earlier", "first", "history", "next", "previous", "prior", "tried"}
TEST_TERMS = {"pytest", "rerun", "test", "verify"}
SUBMIT_TERMS = {"ready", "ship", "submit"}
COMMAND_TERMS = {"command", "execute", "reproduce", "rerun", "run"}
FILE_EDGE_TYPES = {"patches_file", "touches_file", "references_file", "mentions_file", "fails_in", "verifies"}
EDGE_TYPE_PRIORS = {
    "locate_file": {
        "patches_file": 1.6,
        "touches_file": 1.3,
        "fails_in": 1.26,
        "references_file": 1.18,
        "mentions_file": 1.12,
        "contains_patch": 1.34,
        "touches_symbol": 1.22,
        "references_symbol": 1.12,
        "verifies": 1.08,
        "runs": 1.02,
        "validates": 1.18,
        "verified_by": 1.2,
        "rejected_by": 0.86,
        "contradicts": 0.74,
        "solves": 1.14,
        "causes": 1.08,
        "motivates": 1.06,
        "precedes": 0.96,
        "derived_from": 0.72,
        "related_to": 0.82,
        "supports": 0.8,
        "contains": 0.72,
        "supersedes": 0.5,
    },
    "failure_analysis": {
        "fails_in": 1.45,
        "emits_error": 1.4,
        "causes": 1.28,
        "blocks": 1.22,
        "contradicts": 1.18,
        "rejected_by": 1.18,
        "motivates": 1.18,
        "touches_file": 1.14,
        "mentions_file": 1.1,
        "patches_file": 1.04,
        "references_file": 1.02,
        "verified_by": 0.9,
        "validates": 0.95,
        "solves": 0.9,
        "supersedes": 0.72,
        "derived_from": 0.8,
        "related_to": 0.9,
    },
    "history": {
        "precedes": 1.35,
        "motivates": 1.28,
        "validates": 1.22,
        "verified_by": 1.18,
        "rejected_by": 1.16,
        "contradicts": 1.14,
        "supersedes": 1.38,
        "causes": 1.1,
        "derived_from": 1.02,
        "patches_file": 1.08,
        "touches_file": 1.04,
        "related_to": 0.9,
    },
    "general": {
        "solves": 1.1,
        "blocks": 1.08,
        "causes": 1.06,
        "patches_file": 1.1,
        "contains_patch": 1.08,
        "touches_file": 1.02,
        "fails_in": 1.08,
        "mentions_file": 1.0,
        "touches_symbol": 1.04,
        "references_symbol": 1.02,
        "verifies": 1.02,
        "verified_by": 1.06,
        "rejected_by": 0.94,
        "contradicts": 0.92,
        "precedes": 1.0,
        "motivates": 1.0,
        "validates": 1.04,
        "supersedes": 0.78,
        "derived_from": 0.84,
        "related_to": 0.94,
    },
}


class RetrievalFeatureConfig(BaseModel):
    enable_graph_traversal: bool = True
    enable_temporal_reasoning: bool = True
    enable_type_routing: bool = True
    enable_provenance: bool = True
    enable_compact_brief: bool = True


def retrieve(
    query: str,
    context: dict[str, Any] | None,
    graph_manager: GraphManager,
    score_config: ScoreConfig | None = None,
    depth_limit: int = 2,
    limit: int = 5,
    include_compressed: bool = False,
    feature_config: RetrievalFeatureConfig | None = None,
) -> dict[str, Any]:
    context = context or {}
    score_config = score_config or ScoreConfig()
    feature_config = feature_config or RetrievalFeatureConfig()
    query_tokens = tokenize(query)
    query_terms = tokenize_sequence(query)
    context_tokens = extract_context_tokens(context)
    profile = _query_profile(query, query_tokens, feature_config)

    seed_scores = _seed_nodes(graph_manager, query, query_terms, query_tokens, context, context_tokens, include_compressed, profile)
    profile["seed_steps"] = [
        graph_manager.get_node(node_id).metadata.get("step_index")
        for node_id in seed_scores
        if graph_manager.get_node(node_id) and graph_manager.get_node(node_id).metadata.get("step_index") is not None
    ]
    if feature_config.enable_graph_traversal:
        traversed = _traverse(graph_manager, seed_scores, depth_limit, include_compressed, profile)
    else:
        traversed = {node_id: {"causal_proximity": seed_score, "depth": 0} for node_id, seed_score in seed_scores.items()}

    # All three per-edge bonus aggregations (artifact_bridge,
    # edge_semantic_bonus, provenance_bonus) are computed in single
    # O(E) sweeps instead of per-node — each edge contributes to both
    # endpoints, so visiting it once is enough.
    all_bridges = (
        _compute_all_artifact_bridges(graph_manager, traversed, profile)
        if feature_config.enable_graph_traversal
        else {}
    )
    all_edge_semantic = (
        _compute_all_edge_semantic_bonuses(graph_manager, profile)
        if feature_config.enable_graph_traversal
        else {}
    )
    all_provenance = (
        _compute_all_provenance_bonuses(graph_manager, query_tokens)
        if feature_config.enable_provenance
        else {}
    )
    all_supersession = (
        _compute_all_supersession_bonuses(graph_manager, profile)
        if feature_config.enable_temporal_reasoning
        else {}
    )

    scored_nodes: list[dict[str, Any]] = []
    for node_id, traversal_data in traversed.items():
        node = graph_manager.get_node(node_id)
        if node is None:
            continue
        if node.metadata.get("compressed") and not include_compressed and not node.metadata.get("summary"):
            continue

        relevance = _relevance(node, query_tokens)
        state_match = _state_match(node, context, context_tokens)
        artifact_bridge = all_bridges.get(node.id, 0.0) if feature_config.enable_graph_traversal else 0.0
        edge_semantic_bonus = all_edge_semantic.get(node.id, 0.0) if feature_config.enable_graph_traversal else 0.0
        provenance_bonus = all_provenance.get(node.id, 0.0) if feature_config.enable_provenance else 0.0
        intent_bonus = _intent_bonus(node, profile)
        sequence_bonus = _sequence_bonus(node, profile) if feature_config.enable_graph_traversal else 0.0
        temporal_bonus = _temporal_bonus(node, profile) if feature_config.enable_temporal_reasoning else 0.0
        supersession_bonus = all_supersession.get(node.id, 0.0) if feature_config.enable_temporal_reasoning else 0.0
        matched_terms = sorted((set(node.metadata.get("keywords", [])) or tokenize(node.content)) & (query_tokens | context_tokens))
        query_term_bonus = min(0.12, len(matched_terms) * 0.03)
        total_score = score_node(
            node=node,
            relevance=relevance,
            causal_proximity=traversal_data["causal_proximity"],
            state_match=state_match,
            config=score_config,
        )
        total_score = round(
            total_score
            + (0.12 * artifact_bridge)
            + edge_semantic_bonus
            + provenance_bonus
            + intent_bonus
            + sequence_bonus
            + temporal_bonus
            + supersession_bonus
            + query_term_bonus,
            6,
        )
        scored_nodes.append(
            {
                "node": node,
                "score": total_score,
                "relevance": relevance,
                "causal_proximity": traversal_data["causal_proximity"],
                "state_match": state_match,
                "artifact_bridge": artifact_bridge,
                "edge_semantic_bonus": edge_semantic_bonus,
                "provenance_bonus": provenance_bonus,
                "intent_bonus": intent_bonus,
                "sequence_bonus": sequence_bonus,
                "temporal_bonus": temporal_bonus,
                "supersession_bonus": supersession_bonus,
                "query_term_bonus": query_term_bonus,
                "depth": traversal_data["depth"],
                "matched_terms": matched_terms,
                "is_anchor": node.type in {"session", "goal", "episode"},
            }
        )

    ranked = _select_ranked_nodes(scored_nodes, profile, limit)
    for item in ranked:
        item["node"].touch()
        graph_manager.update_node(item["node"])

    top_node_ids = [item["node"].id for item in ranked]
    chains = _build_causal_chains(graph_manager, list(seed_scores), top_node_ids, depth_limit + 1)
    summary = _build_summary(ranked)
    reasoning = _build_reasoning(ranked, chains, context, profile)

    return {
        "summary": summary,
        "intent": profile["intent"],
        "feature_config": feature_config.model_dump(mode="json"),
        "nodes": [_serialize_ranked_node(item, graph_manager) for item in ranked],
        "chains": chains,
        "reasoning": reasoning,
    }


def _query_profile(query: str, query_tokens: set[str], feature_config: RetrievalFeatureConfig | None = None) -> dict[str, Any]:
    feature_config = feature_config or RetrievalFeatureConfig()
    lowered = query.lower()
    wants_file = any(term in lowered or term in query_tokens for term in FILE_TERMS) and ("file" in lowered or "patch" in lowered or "where" in lowered)
    wants_history = any(term in lowered or term in query_tokens for term in HISTORY_TERMS)
    wants_failure = any(term in lowered or term in query_tokens for term in FAILURE_TERMS)
    wants_test = any(term in lowered or term in query_tokens for term in TEST_TERMS)
    wants_submit = "submit" in lowered or any(term in lowered or term in query_tokens for term in SUBMIT_TERMS)
    wants_command = any(term in lowered or term in query_tokens for term in COMMAND_TERMS)

    if not feature_config.enable_type_routing:
        intent = "general"
        required_types = []
        type_preferences = {}
    elif wants_file:
        intent = "locate_file"
        required_types = ["file", "decision", "observation"]
        type_preferences = {"file": 0.18, "patch_hunk": 0.1, "decision": 0.1, "observation": 0.06, "task": 0.04, "symbol": 0.04}
    elif wants_history:
        intent = "history"
        required_types = ["decision", "observation"]
        type_preferences = {"decision": 0.14, "observation": 0.1, "command": 0.08, "task": 0.05, "file": 0.03}
    elif wants_failure:
        intent = "failure_analysis"
        required_types = ["observation", "decision", "file"]
        type_preferences = {"observation": 0.16, "error_signature": 0.12, "decision": 0.1, "task": 0.08, "file": 0.08, "test": 0.04}
    else:
        intent = "general"
        required_types = ["task", "observation"]
        type_preferences = {"task": 0.08, "observation": 0.08, "decision": 0.05, "file": 0.04, "symbol": 0.03, "test": 0.03}

    if feature_config.enable_type_routing and wants_test:
        if "test" not in required_types:
            required_types.append("test")
        type_preferences["test"] = max(type_preferences.get("test", 0.0), 0.14)
        type_preferences["command"] = max(type_preferences.get("command", 0.0), 0.08)
    if feature_config.enable_type_routing and wants_command:
        type_preferences["command"] = max(type_preferences.get("command", 0.0), 0.14)

    return {
        "intent": intent,
        "required_types": required_types,
        "type_preferences": type_preferences,
        "wants_file": wants_file,
        "wants_history": wants_history,
        "wants_failure": wants_failure,
        "wants_test": wants_test,
        "wants_submit": wants_submit,
        "wants_command": wants_command,
        "before": "before" in lowered or "previous" in lowered or "prior" in lowered,
        "after": "after" in lowered or "next" in lowered,
        "asks_current_state": any(term in lowered for term in ("current", "latest", "now", "still", "today")),
        "seed_steps": [],
    }


def _seed_nodes(
    graph_manager: GraphManager,
    query: str,
    query_terms: list[str],
    query_tokens: set[str],
    context: dict[str, Any],
    context_tokens: set[str],
    include_compressed: bool,
    profile: dict[str, Any],
) -> dict[str, float]:
    seeds: dict[str, float] = {}
    nodes = graph_manager.all_nodes(include_compressed=include_compressed)
    if not nodes:
        return seeds

    query_paths = extract_file_paths(" ".join([query, *flatten_context_values(context)]))
    documents = []
    for node in nodes:
        node_tokens = set(node.metadata.get("keywords", [])) or tokenize(node.content)
        doc_tokens = _node_doc_tokens(node)
        lexical = jaccard_similarity(query_tokens, node_tokens)
        state = _state_match(node, context, context_tokens)
        metadata_match = _seed_metadata_bonus(node, profile)
        exact_path_bonus = _path_match_bonus(node, query_paths, query_tokens)
        temporal_seed = 0.05 if node.invalid_at is None else (-0.08 if profile["asks_current_state"] else -0.02)
        documents.append(
            {
                "node": node,
                "node_tokens": node_tokens,
                "doc_tokens": doc_tokens,
                "lexical": lexical,
                "state": state,
                "metadata_match": metadata_match,
                "exact_path_bonus": exact_path_bonus,
                "temporal_seed": temporal_seed,
            }
        )

    bm25_scores = _bm25_scores(query_terms, {item["node"].id: item["doc_tokens"] for item in documents})
    bm25_max = max(bm25_scores.values(), default=0.0)

    for item in documents:
        node = item["node"]
        bm25 = bm25_scores.get(node.id, 0.0)
        normalized_bm25 = (bm25 / bm25_max) if bm25_max else 0.0
        seed_score = (
            (0.42 * normalized_bm25)
            + (0.23 * item["lexical"])
            + (0.17 * item["state"])
            + item["metadata_match"]
            + item["exact_path_bonus"]
            + item["temporal_seed"]
        )
        if seed_score >= 0.16:
            seeds[node.id] = min(1.0, seed_score)

    if not seeds:
        fallback = sorted(
            graph_manager.all_nodes(include_compressed=include_compressed),
            key=lambda node: (node.recency, node.importance),
            reverse=True,
        )[:3]
        for node in fallback:
            seeds[node.id] = max(0.1, node.recency * 0.5)

    return seeds


def _traverse(
    graph_manager: GraphManager,
    seed_scores: dict[str, float],
    depth_limit: int,
    include_compressed: bool,
    profile: dict[str, Any],
) -> dict[str, dict[str, float]]:
    frontier: list[tuple[float, int, str]] = []
    traversed: dict[str, dict[str, float]] = {}

    for node_id, seed_score in seed_scores.items():
        heapq.heappush(frontier, (-seed_score, 0, node_id))

    while frontier:
        negative_priority, depth, node_id = heapq.heappop(frontier)
        priority = -negative_priority
        node = graph_manager.get_node(node_id)
        if node is None:
            continue
        if node.metadata.get("compressed") and not include_compressed and not node.metadata.get("summary"):
            continue

        existing = traversed.get(node_id)
        if existing and existing["causal_proximity"] >= priority and existing["depth"] <= depth:
            continue

        traversed[node_id] = {"causal_proximity": priority, "depth": depth}
        if depth >= depth_limit:
            continue

        for neighbor, edge in graph_manager.get_neighbors(node_id, direction="both"):
            if neighbor.metadata.get("compressed") and not include_compressed and not neighbor.metadata.get("summary"):
                continue
            edge_factor = _edge_transition_factor(edge, node, neighbor, profile)
            next_priority = priority * edge_factor * (0.55 + (0.45 * edge.weight)) * (
                0.5 + (0.25 * neighbor.importance) + (0.25 * neighbor.recency)
            )
            if next_priority < 0.08:
                continue
            heapq.heappush(frontier, (-min(1.0, next_priority), depth + 1, neighbor.id))

    return traversed


def _edge_transition_factor(edge: Any, node: Node, neighbor: Node, profile: dict[str, Any]) -> float:
    intent = profile["intent"]
    factor = EDGE_TYPE_PRIORS.get(intent, EDGE_TYPE_PRIORS["general"]).get(edge.type, 1.0)

    if edge.type in FILE_EDGE_TYPES:
        if profile["wants_file"] and "file" in {node.type, neighbor.type}:
            factor += 0.14
        if neighbor.metadata.get("edited"):
            factor += 0.08
        if edge.type == "patches_file" and neighbor.metadata.get("edited"):
            factor += 0.05

    if edge.type == "supersedes":
        factor += 0.12 if profile["wants_history"] else -0.18
        if profile["asks_current_state"] and neighbor.invalid_at is not None:
            factor -= 0.08

    if edge.type == "derived_from" and not profile["wants_history"]:
        factor -= 0.04

    if neighbor.invalid_at is not None and not profile["wants_history"] and edge.type != "supersedes":
        factor -= 0.08

    return max(0.35, min(1.9, factor))


def _relevance(node: Node, query_tokens: set[str]) -> float:
    if not query_tokens:
        return 0.0
    node_tokens = set(node.metadata.get("keywords", [])) or tokenize(node.content)
    direct_overlap = jaccard_similarity(query_tokens, node_tokens)
    substring_bonus = 0.0
    lowered_content = node.content.lower()
    for token in query_tokens:
        if token in lowered_content:
            substring_bonus += 0.05
    return min(1.0, direct_overlap + substring_bonus)


def _state_match(node: Node, context: dict[str, Any], context_tokens: set[str]) -> float:
    if not context:
        return 0.0

    node_tokens = set(node.metadata.get("keywords", [])) or tokenize(node.content)
    score = jaccard_similarity(node_tokens, context_tokens)

    for key in ("session", "session_id", "goal", "file", "files", "type", "repo"):
        if key not in context:
            continue
        context_value = context[key]
        if isinstance(context_value, list):
            values = {str(value).lower() for value in context_value}
        else:
            values = {str(context_value).lower()}
        metadata_value = node.metadata.get(key)
        if metadata_value is not None:
            metadata_values = metadata_value if isinstance(metadata_value, list) else [metadata_value]
            metadata_values = {str(value).lower() for value in metadata_values}
            if values & metadata_values:
                score += 0.35
        if node.type == key.replace("_id", "") and str(node.content).lower() in values:
            score += 0.4

    return min(1.0, score)


def _seed_metadata_bonus(node: Node, profile: dict[str, Any]) -> float:
    bonus = 0.0
    if profile["wants_failure"] and node.metadata.get("status") == "error":
        bonus += 0.18
    if profile["wants_failure"] and node.type == "error_signature":
        bonus += 0.15
    if profile["wants_file"] and node.type == "file":
        bonus += 0.08
    if profile["wants_file"] and node.type == "patch_hunk":
        bonus += 0.06
    if profile.get("wants_test") and node.type == "test":
        bonus += 0.14
    if profile.get("wants_test") and node.type == "command":
        bonus += 0.08
    if profile["wants_history"] and node.metadata.get("step_index") is not None:
        bonus += 0.06
    if node.metadata.get("action_kind") in {"edit", "open", "submit"} and profile["intent"] in {"locate_file", "history"}:
        bonus += 0.06
    if node.type == "episode" and profile["wants_history"]:
        bonus += 0.04
    return bonus


def _document_text(node: Node) -> str:
    parts = [node.content]
    for key in (
        "path",
        "issue_title",
        "submission_diff",
        "raw_action",
        "raw_observation",
        "raw_thought",
        "original_content",
        "test_target",
    ):
        value = node.metadata.get(key)
        if value:
            parts.append(str(value))
    for key in ("files", "error_signatures"):
        value = node.metadata.get(key)
        if value:
            parts.append(" ".join(str(item) for item in value))
    return " ".join(parts)


# Cache of BM25 tokens per (node id, content length). Tokenizing each
# node's document text on every retrieve dominated _seed_nodes — the
# tokens are deterministic from the node, so we memoize. Keyed by
# content length so a content edit (e.g. compression) naturally invalidates.
_DOC_TOKEN_CACHE: dict[tuple[str, int], list[str]] = {}


def _node_doc_tokens(node: Node) -> list[str]:
    cache_key = (node.id, len(node.content))
    cached = _DOC_TOKEN_CACHE.get(cache_key)
    if cached is not None:
        return cached
    tokens = tokenize_sequence(_document_text(node))
    _DOC_TOKEN_CACHE[cache_key] = tokens
    return tokens


def _bm25_scores(query_terms: list[str], documents: dict[str, list[str]]) -> dict[str, float]:
    if not documents or not query_terms:
        return {doc_id: 0.0 for doc_id in documents}

    doc_freq = Counter()
    for tokens in documents.values():
        doc_freq.update(set(tokens))
    avgdl = sum(len(tokens) for tokens in documents.values()) / max(len(documents), 1)
    total_docs = len(documents)
    k1 = 1.5
    b = 0.75

    scores: dict[str, float] = {}
    for doc_id, tokens in documents.items():
        counts = Counter(tokens)
        doc_len = len(tokens) or 1
        score = 0.0
        for term in query_terms:
            tf = counts.get(term)
            if not tf:
                continue
            df = doc_freq.get(term, 0)
            idf = math.log(1 + ((total_docs - df + 0.5) / (df + 0.5)))
            denom = tf + k1 * (1 - b + b * (doc_len / (avgdl or 1.0)))
            score += idf * ((tf * (k1 + 1)) / denom)
        scores[doc_id] = score
    return scores


def _path_match_bonus(node: Node, query_paths: list[str], query_tokens: set[str]) -> float:
    if not query_paths and node.type != "file":
        return 0.0

    candidates = [str(node.content).lower()]
    path_value = node.metadata.get("path")
    if path_value:
        candidates.append(str(path_value).lower())
    for file_value in node.metadata.get("files", []):
        candidates.append(str(file_value).lower())

    best = 0.0
    for query_path in query_paths:
        lowered_query_path = query_path.lower()
        basename = lowered_query_path.rsplit("/", 1)[-1]
        for candidate in candidates:
            if candidate == lowered_query_path or candidate.endswith(lowered_query_path):
                best = max(best, 0.24)
            elif basename and candidate.endswith(basename):
                best = max(best, 0.14)

    if node.type == "file":
        path_tokens = tokenize(" ".join(candidates))
        overlap = len(path_tokens & query_tokens)
        if overlap:
            best = max(best, min(0.12, overlap * 0.03))
    return best


def _cached_neighbors(
    graph_manager: GraphManager,
    node_id: str,
    cache: dict[str, list[tuple[Node, Any]]],
) -> list[tuple[Node, Any]]:
    cached = cache.get(node_id)
    if cached is not None:
        return cached
    fresh = graph_manager.get_neighbors(node_id, direction="both")
    cache[node_id] = fresh
    return fresh


def _bridge_local_score(
    node: Node,
    neighbor: Node,
    edge: Any,
    neighbor_traversal: dict[str, float],
    profile: dict[str, Any],
) -> float:
    """Per-edge contribution to node's artifact_bridge score.

    Mirrors the body of the legacy per-node loop so behavior is preserved.
    """
    local = neighbor_traversal["causal_proximity"] * edge.weight * _edge_transition_factor(edge, node, neighbor, profile)
    if node.type == "file" and neighbor.type in {"decision", "observation", "task"}:
        local += 0.12
    if node.type == "file" and node.metadata.get("edited"):
        local += 0.15
    if node.type == "file" and node.metadata.get("inspected"):
        local += 0.06
    if node.type == "file" and "reproduce" in node.content.lower():
        local -= 0.12
    if profile["wants_failure"] and node.type == "decision" and neighbor.metadata.get("status") == "error":
        local += 0.08
    if profile["wants_history"] and node.metadata.get("step_index") is not None and neighbor.metadata.get("step_index") is not None:
        distance = abs(int(node.metadata["step_index"]) - int(neighbor.metadata["step_index"]))
        local += max(0.0, 0.08 - (distance * 0.02))
    return local


def _compute_all_artifact_bridges(
    graph_manager: GraphManager,
    traversed: dict[str, dict[str, float]],
    profile: dict[str, Any],
) -> dict[str, float]:
    """Compute artifact_bridge for every traversed node in one O(E) sweep.

    Equivalent to calling the legacy _artifact_bridge per node — each
    edge between two traversed nodes contributes to both endpoints'
    bridge score. Cuts the per-node get_neighbors call (each edge was
    visited twice, once from each endpoint) and the function-call
    overhead for ~5k scored nodes.
    """
    if not traversed:
        return {}

    bridges: dict[str, float] = {}
    nodes = graph_manager.graph.nodes
    for u, v, _, payload in graph_manager.graph.edges(keys=True, data=True):
        if u not in traversed or v not in traversed:
            continue
        u_payload = nodes.get(u)
        v_payload = nodes.get(v)
        if u_payload is None or v_payload is None:
            continue
        u_node: Node = u_payload["data"]
        v_node: Node = v_payload["data"]
        edge: Any = payload["data"]

        u_local = _bridge_local_score(u_node, v_node, edge, traversed[v], profile)
        if u_local > bridges.get(u, 0.0):
            bridges[u] = u_local

        v_local = _bridge_local_score(v_node, u_node, edge, traversed[u], profile)
        if v_local > bridges.get(v, 0.0):
            bridges[v] = v_local

    return {nid: min(1.0, score) for nid, score in bridges.items()}


def _edge_semantic_local(
    node: Node,
    neighbor: Node,
    edge: Any,
    profile: dict[str, Any],
) -> tuple[float, bool]:
    """Per-edge contribution to node's edge_semantic_bonus.

    Returns (bonus_delta, contributes_to_has_specific_file_edge).
    """
    edge_type = edge.type
    node_type = node.type

    if edge_type == "patches_file":
        delta = 0.18 if node_type == "file" else 0.07
        if neighbor.metadata.get("action_kind") == "submit":
            delta += 0.02
        return delta, True
    if edge_type == "fails_in":
        return (0.12 if node_type == "file" else 0.05), True
    if edge_type == "touches_file":
        return (0.08 if node_type == "file" else 0.04), True
    if edge_type == "mentions_file":
        return (0.06 if node_type == "file" else 0.03), True
    if edge_type == "references_file":
        return (0.04 if node_type == "file" else 0.02), True
    if edge_type == "supersedes":
        return (0.05 if profile["wants_history"] else (0.02 if node.invalid_at is None else -0.03)), False
    if edge_type == "verified_by":
        return (0.09 if node_type in {"file", "decision", "test"} else 0.04), False
    if edge_type == "rejected_by":
        return (0.06 if profile["wants_history"] else 0.01), False
    if edge_type == "contradicts":
        return (0.08 if profile["wants_failure"] else 0.02), False
    if edge_type == "contains_patch":
        return (0.12 if node_type in {"patch_hunk", "file"} else 0.04), False
    if edge_type == "touches_symbol":
        return (0.07 if node_type in {"symbol", "patch_hunk"} else 0.03), False
    return 0.0, False


def _compute_all_edge_semantic_bonuses(
    graph_manager: GraphManager,
    profile: dict[str, Any],
) -> dict[str, float]:
    """Compute edge_semantic_bonus for every node in one O(E) sweep.

    Each edge contributes to both endpoints' bonus, so visiting once is
    enough — replaces 5k per-node get_neighbors+inner-loop calls.
    """
    bonuses: dict[str, float] = {}
    has_file_edge: dict[str, bool] = {}
    nodes = graph_manager.graph.nodes

    for u, v, _, payload in graph_manager.graph.edges(keys=True, data=True):
        u_payload = nodes.get(u)
        v_payload = nodes.get(v)
        if u_payload is None or v_payload is None:
            continue
        u_node: Node = u_payload["data"]
        v_node: Node = v_payload["data"]
        edge: Any = payload["data"]

        u_delta, u_file = _edge_semantic_local(u_node, v_node, edge, profile)
        if u_delta:
            bonuses[u] = bonuses.get(u, 0.0) + u_delta
        if u_file:
            has_file_edge[u] = True

        v_delta, v_file = _edge_semantic_local(v_node, u_node, edge, profile)
        if v_delta:
            bonuses[v] = bonuses.get(v, 0.0) + v_delta
        if v_file:
            has_file_edge[v] = True

    if profile["wants_file"]:
        for node_id, payload in nodes.items():
            node: Node = payload["data"]
            if node.type != "file":
                continue
            if node.metadata.get("edited"):
                bonuses[node_id] = bonuses.get(node_id, 0.0) + 0.08
            if node.metadata.get("error_related"):
                bonuses[node_id] = bonuses.get(node_id, 0.0) + 0.04
            if not has_file_edge.get(node_id):
                bonuses[node_id] = bonuses.get(node_id, 0.0) - 0.08

    return {nid: max(-0.08, min(0.34, score)) for nid, score in bonuses.items()}


def _compute_all_supersession_bonuses(
    graph_manager: GraphManager,
    profile: dict[str, Any],
) -> dict[str, float]:
    """Compute supersession_bonus for every node by indexing supersedes
    edges once instead of running two find_edges per scored node."""
    has_outgoing: set[str] = set()
    has_incoming: set[str] = set()
    for u, v, _, payload in graph_manager.graph.edges(keys=True, data=True):
        if payload["data"].type != "supersedes":
            continue
        has_outgoing.add(u)
        has_incoming.add(v)

    if not has_outgoing and not has_incoming:
        return {}

    wants_history = profile["wants_history"]
    nodes = graph_manager.graph.nodes
    bonuses: dict[str, float] = {}
    for node_id in has_outgoing | has_incoming:
        payload = nodes.get(node_id)
        if payload is None:
            continue
        node: Node = payload["data"]
        bonus = 0.0
        if node_id in has_outgoing and node.invalid_at is None:
            bonus += 0.06 if not wants_history else 0.03
        if node_id in has_incoming:
            bonus += 0.07 if wants_history else -0.04
        if bonus:
            bonuses[node_id] = bonus
    return bonuses


def _supersession_bonus(graph_manager: GraphManager, node: Node, profile: dict[str, Any]) -> float:
    """Legacy per-node fallback (kept for callers that don't precompute)."""
    outgoing = graph_manager.find_edges(source=node.id, edge_type="supersedes")
    incoming = graph_manager.find_edges(target=node.id, edge_type="supersedes")

    bonus = 0.0
    if outgoing and node.invalid_at is None:
        bonus += 0.06 if not profile["wants_history"] else 0.03
    if incoming and profile["wants_history"]:
        bonus += 0.07
    if incoming and not profile["wants_history"]:
        bonus -= 0.04
    return bonus


def _compute_all_provenance_bonuses(
    graph_manager: GraphManager,
    query_tokens: set[str],
) -> dict[str, float]:
    """Compute provenance_bonus for every node in one O(E) sweep.

    Only derived_from edges with an episode endpoint contribute, so we
    iterate edges once and update both endpoints. Cuts the 5k per-node
    get_neighbors+filter calls.
    """
    if not query_tokens:
        return {}

    bonuses: dict[str, float] = {}
    nodes = graph_manager.graph.nodes
    episode_token_cache: dict[str, set[str]] = {}

    def episode_tokens(episode: Node) -> set[str]:
        cached = episode_token_cache.get(episode.id)
        if cached is not None:
            return cached
        tokens = set(episode.metadata.get("keywords", [])) or tokenize(episode.content)
        episode_token_cache[episode.id] = tokens
        return tokens

    for u, v, _, payload in graph_manager.graph.edges(keys=True, data=True):
        edge: Any = payload["data"]
        if edge.type != "derived_from":
            continue
        u_payload = nodes.get(u)
        v_payload = nodes.get(v)
        if u_payload is None or v_payload is None:
            continue
        u_node: Node = u_payload["data"]
        v_node: Node = v_payload["data"]

        if v_node.type == "episode":
            overlap = jaccard_similarity(query_tokens, episode_tokens(v_node))
            local = (0.08 * overlap) + (0.02 * edge.weight)
            if u_node.type == "file":
                local += 0.03
            if local > bonuses.get(u, 0.0):
                bonuses[u] = local

        if u_node.type == "episode":
            overlap = jaccard_similarity(query_tokens, episode_tokens(u_node))
            local = (0.08 * overlap) + (0.02 * edge.weight)
            if v_node.type == "file":
                local += 0.03
            if local > bonuses.get(v, 0.0):
                bonuses[v] = local

    return {nid: min(0.12, b) for nid, b in bonuses.items()}


def _provenance_bonus(
    graph_manager: GraphManager,
    node: Node,
    query_tokens: set[str],
    neighbor_cache: dict[str, list[tuple[Node, Any]]],
) -> float:
    """Legacy per-node fallback (kept for callers that don't precompute)."""
    if not query_tokens:
        return 0.0

    best = 0.0
    for neighbor, edge in _cached_neighbors(graph_manager, node.id, neighbor_cache):
        if edge.type != "derived_from":
            continue
        if neighbor.type != "episode":
            continue
        overlap = jaccard_similarity(query_tokens, set(neighbor.metadata.get("keywords", [])) or tokenize(neighbor.content))
        local = (0.08 * overlap) + (0.02 * edge.weight)
        if node.type == "file":
            local += 0.03
        best = max(best, local)
    return min(0.12, best)


def _intent_bonus(node: Node, profile: dict[str, Any]) -> float:
    bonus = profile["type_preferences"].get(node.type, 0.0)
    if profile["wants_failure"] and node.metadata.get("status") == "error":
        bonus += 0.08
        if node.metadata.get("action_kind") == "python":
            bonus += 0.05
        if node.metadata.get("action_kind") == "edit":
            bonus -= 0.03
    if profile["wants_failure"] and node.type == "error_signature":
        bonus += 0.12
    if profile["wants_file"] and node.type == "file":
        bonus += 0.06
        if node.metadata.get("edited"):
            bonus += 0.14
        if node.metadata.get("inspected"):
            bonus += 0.06
        if "reproduce" in node.content.lower():
            bonus -= 0.12
    if profile["wants_file"] and node.type == "patch_hunk":
        bonus += 0.08
    if profile["wants_history"] and node.metadata.get("step_index") is not None:
        bonus += 0.04
    if profile["intent"] == "locate_file" and node.metadata.get("action_kind") == "submit":
        bonus += 0.05
    if node.type in {"session", "goal"}:
        bonus -= 0.08
    return bonus


def _temporal_bonus(node: Node, profile: dict[str, Any]) -> float:
    bonus = 0.0
    if node.invalid_at is not None:
        bonus -= 0.16 if not profile["wants_history"] else 0.02
    elif node.metadata.get("current", True):
        if profile["asks_current_state"]:
            bonus += 0.06
        elif node.type in {"file", "observation", "decision"}:
            bonus += 0.02
    if profile["wants_failure"] and node.metadata.get("status") == "error":
        bonus += 0.04 if node.invalid_at is None else -0.06
    if profile["wants_history"] and node.invalid_at is not None:
        bonus += 0.05
    if node.type == "episode":
        bonus -= 0.04
    return bonus


def _sequence_bonus(node: Node, profile: dict[str, Any]) -> float:
    if not profile["wants_history"]:
        return 0.0
    step_index = node.metadata.get("step_index")
    seed_steps = [int(step) for step in profile.get("seed_steps", []) if step is not None]
    if step_index is None or not seed_steps:
        return 0.0

    step_index = int(step_index)
    nearest = min(abs(step_index - seed_step) for seed_step in seed_steps)
    bonus = max(0.0, 0.12 - (nearest * 0.03))
    if profile["before"] and step_index <= max(seed_steps):
        bonus += 0.03
    if profile["after"] and step_index >= min(seed_steps):
        bonus += 0.03
    return bonus


def _select_ranked_nodes(scored_nodes: list[dict[str, Any]], profile: dict[str, Any], limit: int) -> list[dict[str, Any]]:
    ordered = sorted(scored_nodes, key=lambda item: item["score"], reverse=True)
    non_anchor_ranked = [item for item in ordered if not item["is_anchor"]]
    anchor_ranked = [item for item in ordered if item["is_anchor"]]

    selected: list[dict[str, Any]] = []
    seen = set()

    def maybe_add(item: dict[str, Any]) -> None:
        marker = _dedupe_marker(item)
        if marker in seen or len(selected) >= limit:
            return
        seen.add(marker)
        selected.append(item)

    for required_type in profile["required_types"]:
        candidate = next((item for item in non_anchor_ranked if item["node"].type == required_type and _dedupe_marker(item) not in seen), None)
        if candidate:
            maybe_add(candidate)

    for candidate in non_anchor_ranked:
        maybe_add(candidate)
        if len(selected) >= limit:
            break

    for candidate in anchor_ranked:
        maybe_add(candidate)
        if len(selected) >= limit:
            break

    return selected[:limit]


def _dedupe_marker(item: dict[str, Any]) -> tuple[Any, ...]:
    step_index = item["node"].metadata.get("step_index")
    if step_index is not None:
        return (item["node"].type, step_index, item["node"].metadata.get("action_kind"))
    return (item["node"].type, item["node"].content[:120])


def _build_causal_chains(
    graph_manager: GraphManager,
    seed_node_ids: list[str],
    top_node_ids: list[str],
    cutoff: int,
) -> list[list[str]]:
    if not seed_node_ids or not top_node_ids:
        return []

    chain_candidates: list[list[str]] = []
    # Build a minimal undirected topology graph for shortest-path queries.
    # The default `to_undirected()` deep-copies every Node/Edge Pydantic
    # model and dominates retrieval cost on large graphs (~17s/61k edges);
    # since shortest_path only needs adjacency, copying data is wasted work.
    search_graph = nx.Graph()
    search_graph.add_nodes_from(graph_manager.graph.nodes())
    search_graph.add_edges_from((u, v) for u, v, _ in graph_manager.graph.edges(keys=True))
    excluded_types = {"session", "goal", "episode"}
    preferred_top_nodes = [node_id for node_id in top_node_ids if _node_type(graph_manager, node_id) not in excluded_types]
    preferred_seeds = [node_id for node_id in seed_node_ids if _node_type(graph_manager, node_id) not in excluded_types]

    for source_id in preferred_top_nodes:
        for target_id in preferred_top_nodes:
            if source_id == target_id or source_id not in search_graph or target_id not in search_graph:
                continue
            path = _shortest_path(search_graph, source_id, target_id, cutoff)
            if path:
                chain_candidates.append(path)

    for target_id in preferred_top_nodes or top_node_ids:
        for seed_id in preferred_seeds or seed_node_ids:
            if seed_id == target_id or seed_id not in search_graph or target_id not in search_graph:
                continue
            path = _shortest_path(search_graph, seed_id, target_id, cutoff)
            if not path:
                continue
            chain_candidates.append(path)
            break

    unique_chains: list[list[str]] = []
    seen = set()
    for chain in sorted(chain_candidates, key=len):
        marker = tuple(chain)
        if marker in seen:
            continue
        seen.add(marker)
        unique_chains.append(chain)
    return unique_chains[:3]


def _node_type(graph_manager: GraphManager, node_id: str) -> str:
    node = graph_manager.get_node(node_id)
    return node.type if node else ""


def _shortest_path(search_graph: nx.Graph, source: str, target: str, cutoff: int) -> list[str]:
    try:
        shortest_path = nx.shortest_path(search_graph, source=source, target=target)
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return []
    if len(shortest_path) - 1 > cutoff or len(shortest_path) < 2:
        return []
    return shortest_path


def _build_summary(ranked: list[dict[str, Any]]) -> str:
    if not ranked:
        return "No relevant memories found."

    leading = ranked[:3]
    fragments = [f"{item['node'].type}: {item['node'].content}" for item in leading]
    return "Most relevant memories: " + " | ".join(fragments)


def _build_reasoning(
    ranked: list[dict[str, Any]],
    chains: list[list[str]],
    context: dict[str, Any],
    profile: dict[str, Any],
) -> str:
    if not ranked:
        return "No nodes matched the query or current state."

    explanations = []
    for item in ranked[:3]:
        node = item["node"]
        reasons = []
        if item["matched_terms"]:
            reasons.append(f"keyword overlap on {', '.join(item['matched_terms'][:4])}")
        if item["state_match"] >= 0.3:
            reasons.append("matches the active task/session state")
        if item["artifact_bridge"] >= 0.25:
            reasons.append("is connected to the right causal artifacts")
        if item["edge_semantic_bonus"] >= 0.12:
            reasons.append("sits on the most relevant causal edge types for this query")
        if item["provenance_bonus"] >= 0.05:
            reasons.append("has strong provenance from the relevant agent-log steps")
        if item["sequence_bonus"] >= 0.08:
            reasons.append("sits near the relevant step sequence")
        if item["temporal_bonus"] >= 0.04:
            reasons.append("reflects the current valid state of the task")
        if item["temporal_bonus"] <= -0.08:
            reasons.append("was retained mainly as historical context after being superseded")
        if item["supersession_bonus"] >= 0.05:
            reasons.append("explicitly supersedes stale task state")
        if item["causal_proximity"] >= 0.3:
            reasons.append("is close to the causal neighborhood of the seed memories")
        explanations.append(f"{node.id} was selected because it {' and '.join(reasons) or 'remains highly salient'}.")

    if chains:
        explanations.append(f"Retrieved {len(chains)} causal chain(s) across the graph.")
    if context:
        explanations.append("State-aware scoring boosted memories aligned with the provided context.")
    explanations.append("Hybrid seeding combined BM25-style lexical signals, exact path matches, and edge-aware graph traversal.")
    explanations.append(f"Query intent was treated as {profile['intent'].replace('_', ' ')}.")
    return " ".join(explanations)


def _serialize_ranked_node(item: dict[str, Any], graph_manager: GraphManager) -> dict[str, Any]:
    payload = item["node"].model_dump(mode="json")
    payload["score"] = item["score"]
    payload["relevance"] = item["relevance"]
    payload["causal_proximity"] = item["causal_proximity"]
    payload["state_match"] = item["state_match"]
    payload["artifact_bridge"] = item["artifact_bridge"]
    payload["edge_semantic_bonus"] = item["edge_semantic_bonus"]
    payload["provenance_bonus"] = item["provenance_bonus"]
    payload["intent_bonus"] = item["intent_bonus"]
    payload["sequence_bonus"] = item["sequence_bonus"]
    payload["temporal_bonus"] = item["temporal_bonus"]
    payload["supersession_bonus"] = item["supersession_bonus"]
    payload["query_term_bonus"] = item["query_term_bonus"]
    payload["matched_terms"] = item["matched_terms"]
    payload["depth"] = item["depth"]
    payload["provenance"] = _collect_provenance(graph_manager, item["node"].id)
    return payload


def _collect_provenance(graph_manager: GraphManager, node_id: str) -> list[dict[str, Any]]:
    provenance = []
    for neighbor, edge in graph_manager.get_neighbors(node_id, direction="both", edge_types={"derived_from"}):
        if neighbor.type != "episode":
            continue
        provenance.append(
            {
                "episode_id": neighbor.id,
                "step_index": neighbor.metadata.get("step_index"),
                "episode_kind": neighbor.metadata.get("episode_kind"),
                "content": neighbor.content,
                "edge_type": edge.type,
            }
        )
    provenance.sort(key=lambda item: (item["step_index"] is None, item["step_index"]))
    return provenance[:3]


BRIEF_MODE_BUDGETS = {
    "small_model": 220,
    "large_model": 700,
    "default": 360,
}


def build_agent_brief(
    query: str,
    retrieval_result: dict[str, Any],
    mode: str = "default",
    feature_config: RetrievalFeatureConfig | None = None,
) -> dict[str, Any]:
    feature_config = feature_config or RetrievalFeatureConfig.model_validate(retrieval_result.get("feature_config", {}))
    profile = _query_profile(query, tokenize(query), feature_config)
    nodes = retrieval_result.get("nodes", [])

    ranked_file_nodes = sorted(
        [
            node
            for node in nodes
            if node.get("type") == "file" and str(node.get("content", "")).strip() and "::" not in str(node.get("content", ""))
        ],
        key=lambda node: _brief_file_priority(node, profile),
        reverse=True,
    )
    raw_file_candidates = _unique_strings([node["content"] for node in ranked_file_nodes])
    target_files = _unique_strings([node["content"] for node in ranked_file_nodes if _brief_file_priority(node, profile) > 0.0])

    # Cold-start fallback: when target_files comes up short (e.g. issue text
    # only mentions one file, or the agent hasn't inspected anything yet),
    # mine file-path candidates out of the query + top-scored node content
    # and any `issue_text` metadata so Artifact@5 has something beyond a
    # single candidate to rank. Dogfood / n=500 finding: pre-fix, A@5 == A@1
    # because cold-start localization only had one file node in the graph.
    if len(target_files) < 5:
        lexical_sources: list[str] = [query]
        for node in nodes[:5]:
            content_text = str(node.get("content", "")).strip()
            if content_text:
                lexical_sources.append(content_text)
            metadata = node.get("metadata", {}) or {}
            issue_text_value = metadata.get("issue_text")
            if issue_text_value:
                lexical_sources.append(str(issue_text_value))
            hints_text_value = metadata.get("hints_text")
            if hints_text_value:
                lexical_sources.append(str(hints_text_value))
        lexical_candidates = _extract_lexical_file_candidates(" ".join(lexical_sources))
        existing_paths = {path.lower() for path in target_files}
        for candidate in lexical_candidates:
            if len(target_files) >= 5:
                break
            candidate_lower = candidate.lower()
            if (
                candidate_lower in existing_paths
                or _is_support_or_scratch_file(candidate)
                or "::" in candidate
                or not _looks_like_file_path(candidate)
            ):
                continue
            target_files.append(candidate)
            existing_paths.add(candidate_lower)
    current_state = _unique_strings(
        [
            _brief_node_line(node)
            for node in nodes
            if node.get("type") in {"observation", "decision", "task"} and not node.get("invalid_at")
        ]
    )
    failed_attempts = _unique_strings(
        [
            _brief_node_line(node)
            for node in nodes
            if node.get("invalid_at")
            or node.get("metadata", {}).get("invalidated_reason")
            or (node.get("metadata", {}).get("status") == "error" and profile["wants_history"])
        ]
    )
    # Give the top two evidence lines a wider budget so load-bearing
    # numbers/specifics survive compaction. Subsequent lines stay terse so
    # the brief still fits a small-model budget. Dogfood finding: 96-char
    # truncation on the top observation hid the "52K tokens/turn from
    # portals.yml" detail behind generic prefix text. The top result is
    # often a high-importance task; the key specifics live in the adjacent
    # observation, so two head slots matter.
    evidence_raw = [
        _brief_evidence_line(node, content_limit=220 if idx < 2 else 96)
        for idx, node in enumerate(nodes)
    ]
    evidence = _unique_strings(evidence_raw)
    tests_to_rerun = _unique_strings(
        [node["content"] for node in nodes if node.get("type") == "test"]
        + [test_target for node in nodes for test_target in extract_test_targets(str(node.get("content", "")))]
    )
    tests_to_rerun = [test_target for test_target in tests_to_rerun if is_test_target(test_target)]
    recent_commands = _unique_strings([node["content"] for node in nodes if node.get("type") == "command"])
    symbols = _unique_strings([node["content"] for node in nodes if node.get("type") == "symbol"])
    patch_hints = _unique_strings([compact_text(node["content"], 120) for node in nodes if node.get("type") == "patch_hunk"])
    # Only surface a patch_file when the query is actually about a file
    # (wants_file) or the intent is code-locating / failure-analysis and a
    # file was ranked. Dogfood finding: forcing patch_file from any available
    # file node misled agents on "what is the 100x opportunity"-style queries
    # into inspecting code that had nothing to do with the answer.
    wants_patch_target = profile.get("wants_file") or profile["intent"] in {"locate_file", "failure_analysis"}
    top_node_is_file = bool(nodes) and nodes[0].get("type") == "file"
    if wants_patch_target or top_node_is_file:
        patch_file = next(
            (file_path for file_path in target_files if not _is_support_or_scratch_file(file_path)),
            target_files[0] if target_files else None,
        )
    else:
        patch_file = None
    rerun_command = f"pytest {tests_to_rerun[0]}" if tests_to_rerun else None
    scratch_file = next((file_path for file_path in raw_file_candidates if _is_scratch_file(file_path)), None)
    if not scratch_file:
        scratch_candidates = []
        for node in nodes:
            scratch_candidates.extend(extract_file_paths(str(node.get("content", ""))))
            scratch_candidates.extend(str(item) for item in node.get("metadata", {}).get("files", []))
        scratch_file = next((file_path for file_path in _unique_strings(scratch_candidates) if _is_scratch_file(file_path)), None)
    if not rerun_command and profile.get("wants_command") and scratch_file:
        rerun_command = f"python {scratch_file}"
    if not rerun_command and recent_commands:
        rerun_command = recent_commands[0]
    if rerun_command and profile.get("wants_command") and scratch_file and rerun_command.split(" ", 1)[0] in {"create", "edit", "open", "find_file", "read"}:
        rerun_command = f"python {scratch_file}"
    confidence = round(min(0.99, max((float(nodes[0].get("score", 0.0)) if nodes else 0.0), 0.0)), 3)

    brief = {
        "query": compact_text(query, 160),
        "intent": retrieval_result.get("intent", profile["intent"]),
        "summary": compact_text(retrieval_result.get("summary", ""), 220),
        "patch_file": patch_file,
        "rerun_command": rerun_command,
        "confidence": confidence,
        "target_files": target_files[:5],
        "tests_to_rerun": tests_to_rerun[:3],
        "recent_commands": recent_commands[:3],
        "symbols": symbols[:4],
        "patch_hints": patch_hints[:3],
        "current_state": current_state[:4],
        "failed_attempts": failed_attempts[:4],
        "causal_chain": [" -> ".join(chain) for chain in retrieval_result.get("chains", [])[:2]],
        "recommended_actions": _recommended_actions(
            profile,
            target_files,
            tests_to_rerun,
            rerun_command,
            current_state,
            failed_attempts,
        )[:5],
        "evidence": evidence[:5],
        "reasoning": compact_text(retrieval_result.get("reasoning", ""), 220),
    }
    strategy = "priority" if feature_config.enable_compact_brief else "naive"
    return fit_agent_brief(brief, mode=mode, strategy=strategy)


def fit_agent_brief(
    brief: dict[str, Any],
    mode: str = "default",
    token_budget: int | None = None,
    strategy: str = "priority",
) -> dict[str, Any]:
    budget = token_budget or BRIEF_MODE_BUDGETS.get(mode, BRIEF_MODE_BUDGETS["default"])
    fitted = {
        "query": compact_text(str(brief.get("query", "")), 160),
        "intent": str(brief.get("intent", "general")),
        "summary": compact_text(str(brief.get("summary", "")), 220 if mode == "small_model" else 360),
        "patch_file": compact_text(str(brief.get("patch_file", "")), 120) if brief.get("patch_file") else "",
        "rerun_command": compact_text(str(brief.get("rerun_command", "")), 140) if brief.get("rerun_command") else "",
        "confidence": float(brief.get("confidence", 0.0) or 0.0),
        "target_files": _compact_list(brief.get("target_files", []), 96 if mode == "small_model" else 140),
        "tests_to_rerun": _compact_list(brief.get("tests_to_rerun", []), 96 if mode == "small_model" else 140),
        "recent_commands": _compact_list(brief.get("recent_commands", []), 96 if mode == "small_model" else 160),
        "symbols": _compact_list(brief.get("symbols", []), 80 if mode == "small_model" else 120),
        "patch_hints": _compact_list(brief.get("patch_hints", []), 96 if mode == "small_model" else 160),
        "current_state": _compact_list(brief.get("current_state", []), 120 if mode == "small_model" else 220),
        "failed_attempts": _compact_list(brief.get("failed_attempts", []), 120 if mode == "small_model" else 220),
        "causal_chain": _compact_list(brief.get("causal_chain", []), 120 if mode == "small_model" else 220),
        "recommended_actions": _compact_list(brief.get("recommended_actions", []), 96 if mode == "small_model" else 140),
        "evidence": _compact_list_tiered(
            brief.get("evidence", []),
            head_limit=240 if mode == "small_model" else 360,
            tail_limit=120 if mode == "small_model" else 220,
        ),
        "reasoning": compact_text(str(brief.get("reasoning", "")), 180 if mode == "small_model" else 280),
    }

    if strategy == "naive":
        return _fit_naive_brief(fitted, budget)

    while True:
        rendered = render_agent_brief(fitted)
        token_estimate = len(tokenize_sequence(rendered))
        if token_estimate <= budget:
            fitted["token_budget"] = budget
            fitted["token_estimate"] = token_estimate
            fitted["rendered"] = rendered
            fitted["render_strategy"] = strategy
            return fitted
        if len(fitted["evidence"]) > 2:
            fitted["evidence"].pop()
            continue
        if len(fitted["failed_attempts"]) > 1:
            fitted["failed_attempts"].pop()
            continue
        if len(fitted["current_state"]) > 1:
            fitted["current_state"].pop()
            continue
        if len(fitted["patch_hints"]) > 1:
            fitted["patch_hints"].pop()
            continue
        if len(fitted["symbols"]) > 1:
            fitted["symbols"].pop()
            continue
        if len(fitted["recent_commands"]) > 1:
            fitted["recent_commands"].pop()
            continue
        if len(fitted["tests_to_rerun"]) > 1:
            fitted["tests_to_rerun"].pop()
            continue
        if len(fitted["causal_chain"]) > 1:
            fitted["causal_chain"].pop()
            continue
        if len(fitted["target_files"]) > 3:
            # Keep at least 3 target files so Artifact@5 has something to rank
            # against. Pre-fix, this popped down to 1 and collapsed A@5 onto A@1.
            fitted["target_files"].pop()
            continue
        if len(fitted["recommended_actions"]) > 2:
            fitted["recommended_actions"].pop()
            continue
        if len(fitted["summary"]) > 90:
            fitted["summary"] = compact_text(fitted["summary"], len(fitted["summary"]) - 20)
            continue
        if len(fitted["reasoning"]) > 80:
            fitted["reasoning"] = compact_text(fitted["reasoning"], len(fitted["reasoning"]) - 20)
            continue
        fitted["token_budget"] = budget
        fitted["token_estimate"] = token_estimate
        fitted["rendered"] = rendered
        fitted["render_strategy"] = strategy
        return fitted


def render_agent_brief(brief: dict[str, Any]) -> str:
    lines = [
        f"QUERY: {brief.get('query', '')}",
        f"INTENT: {brief.get('intent', 'general')}",
        f"SUMMARY: {brief.get('summary', '')}",
    ]
    if brief.get("patch_file"):
        lines.append(f"PATCH_FILE: {brief['patch_file']}")
    if brief.get("rerun_command"):
        lines.append(f"RERUN_COMMAND: {brief['rerun_command']}")
    if brief.get("confidence"):
        lines.append(f"CONFIDENCE: {brief['confidence']:.3f}")
    _append_brief_section(lines, "TARGET_FILES", brief.get("target_files", []))
    _append_brief_section(lines, "TESTS_TO_RERUN", brief.get("tests_to_rerun", []))
    _append_brief_section(lines, "RECENT_COMMANDS", brief.get("recent_commands", []))
    _append_brief_section(lines, "SYMBOLS", brief.get("symbols", []))
    _append_brief_section(lines, "PATCH_HINTS", brief.get("patch_hints", []))
    _append_brief_section(lines, "CURRENT_STATE", brief.get("current_state", []))
    _append_brief_section(lines, "FAILED_ATTEMPTS", brief.get("failed_attempts", []))
    _append_brief_section(lines, "CAUSAL_CHAIN", brief.get("causal_chain", []))
    _append_brief_section(lines, "RECOMMENDED_ACTIONS", brief.get("recommended_actions", []))
    _append_brief_section(lines, "EVIDENCE", brief.get("evidence", []))
    if brief.get("reasoning"):
        lines.append(f"REASONING: {brief['reasoning']}")
    return "\n".join(lines).strip()


def _fit_naive_brief(brief: dict[str, Any], budget: int) -> dict[str, Any]:
    rendered = render_agent_brief(brief)
    tokens = tokenize_sequence(rendered)
    if len(tokens) > budget:
        rendered = " ".join(tokens[:budget])
    fitted = dict(brief)
    fitted["patch_file"] = ""
    fitted["rerun_command"] = ""
    fitted["target_files"] = []
    fitted["tests_to_rerun"] = []
    fitted["recent_commands"] = []
    fitted["symbols"] = []
    fitted["patch_hints"] = []
    fitted["recommended_actions"] = []
    fitted["token_budget"] = budget
    fitted["token_estimate"] = min(len(tokens), budget)
    fitted["rendered"] = rendered
    fitted["render_strategy"] = "naive"
    return fitted


def _append_brief_section(lines: list[str], title: str, values: Any) -> None:
    if not isinstance(values, list) or not values:
        return
    lines.append(f"{title}:")
    lines.extend(f"- {value}" for value in values)


def _brief_node_line(node: dict[str, Any], content_limit: int = 96) -> str:
    content = compact_text(str(node.get("content", "")), content_limit)
    step_index = node.get("metadata", {}).get("step_index")
    prefix = node.get("type", "memory")
    if step_index is not None:
        prefix = f"{prefix}@{step_index}"
    if node.get("invalid_at"):
        prefix = f"{prefix}:stale"
    return f"{prefix}: {content}"


def _brief_evidence_line(node: dict[str, Any], content_limit: int = 96) -> str:
    matched = node.get("matched_terms", [])[:3]
    matched_suffix = f" | matched={','.join(matched)}" if matched else ""
    return f"{_brief_node_line(node, content_limit=content_limit)}{matched_suffix}"


def _recommended_actions(
    profile: dict[str, Any],
    target_files: list[str],
    tests_to_rerun: list[str],
    rerun_command: str | None,
    current_state: list[str],
    failed_attempts: list[str],
) -> list[str]:
    actions: list[str] = []
    success_evidence = " ".join(current_state).lower()
    if profile.get("wants_submit"):
        actions.append("submit_patch")
    if rerun_command and profile.get("wants_command") and not tests_to_rerun:
        actions.append(f"rerun_command: {rerun_command}")
    for file_path in [candidate for candidate in target_files if "::" not in candidate and not (profile.get("wants_command") and _is_scratch_file(candidate))][:2]:
        verb = "patch_file" if profile["wants_file"] or profile["wants_failure"] else "inspect_file"
        actions.append(f"{verb}: {file_path}")
    for test_target in tests_to_rerun[:1]:
        actions.append(f"rerun_test: {test_target}")
    if rerun_command and not tests_to_rerun and not profile.get("wants_command"):
        actions.append(f"rerun_command: {rerun_command}")
    if current_state:
        actions.append(f"verify_state: {current_state[0]}")
    if failed_attempts:
        actions.append(f"avoid_repeat: {failed_attempts[0]}")
    if not profile.get("wants_submit") and any(marker in success_evidence for marker in ("pass", "passed", "success", "validated", "solved")):
        actions.append("submit_patch")
    return _unique_strings(actions)


def _brief_file_priority(node: dict[str, Any], profile: dict[str, Any]) -> float:
    metadata = node.get("metadata", {})
    path = str(node.get("content", ""))
    score = float(node.get("score", 0.0))
    action_kinds = set(metadata.get("action_kinds", []))
    if metadata.get("edited"):
        score += 0.2
    if metadata.get("error_related"):
        score += 0.1
    if "submit" in action_kinds:
        score += 0.12
    if "edit" in action_kinds:
        score += 0.1
    if profile.get("wants_submit") and metadata.get("edited"):
        score += 0.1
    if _is_support_or_scratch_file(path):
        score -= 0.45 if not metadata.get("edited") else 0.15
    if _is_scratch_file(path) and profile.get("wants_command"):
        score += 0.22
    if path.endswith("__init__.py") and not metadata.get("edited"):
        score -= 0.25
    return score


_GITHUB_BLOB_PATH_RE = re.compile(
    r"https?://(?:www\.)?github\.com/[^/\s]+/[^/\s]+/(?:blob|tree)/[^/\s]+/([^\s)#?]+)",
    re.IGNORECASE,
)
_GITLAB_BLOB_PATH_RE = re.compile(
    r"https?://(?:www\.)?gitlab\.com/[^/\s]+/[^/\s]+/-/blob/[^/\s]+/([^\s)#?]+)",
    re.IGNORECASE,
)
# Python module references like `astropy.modeling.separable` or
# `django.utils.html.escape` mentioned in issue text. The trailing segment
# could be a function, class, or submodule — we generate path candidates
# for both interpretations.
_PYTHON_MODULE_RE = re.compile(
    r"\b([a-z][a-z0-9_]*(?:\.[a-z_][a-z0-9_]*){2,})\b"
)


def _module_to_path_candidates(text: str) -> list[str]:
    """Translate Python module references in `text` into file path candidates.

    `astropy.modeling.separable` produces both:
      - `astropy/modeling/separable.py`     (the dotted name is a module)
      - `astropy/modeling.py` + `astropy/modeling/separable.py` is also
        plausible if the LAST segment is a function or class — we hedge by
        also emitting the parent path when the last segment looks lowercase
        (likely a function or submodule, not a class).

    Conservative: only matches dotted names with at least 3 segments, all
    lowercase (Python class names start uppercase, which we skip). Common
    stdlib namespaces like `os.path` are short enough not to match.
    """
    seen: set[str] = set()
    out: list[str] = []
    for match in _PYTHON_MODULE_RE.findall(text):
        segments = match.split(".")
        # Skip if any segment looks like a class (capitalized) — those are
        # type references, not module paths. PYTHON_MODULE_RE is already
        # lowercase-only via the character class, but be defensive.
        if any(seg and seg[0].isupper() for seg in segments):
            continue
        # Skip well-known non-module dotted names that are technical jargon.
        joined = match.lower()
        if joined.startswith(("e.g", "i.e", "vs.")) or joined in {"a.b.c"}:
            continue
        # Module-as-file: astropy.modeling.separable -> astropy/modeling/separable.py
        candidate = "/".join(segments) + ".py"
        if candidate not in seen:
            seen.add(candidate)
            out.append(candidate)
        # Submodule-as-file (drop the final segment if it's plausibly a
        # function or class name on the parent module):
        # astropy.modeling.separable.separability_matrix
        #   -> astropy/modeling/separable.py
        if len(segments) >= 4:
            parent_candidate = "/".join(segments[:-1]) + ".py"
            if parent_candidate not in seen:
                seen.add(parent_candidate)
                out.append(parent_candidate)
    return out


def _extract_lexical_file_candidates(text: str) -> list[str]:
    """Mine repo-relative file paths from text, including ones embedded in
    code-host URLs and inferred from Python module references.

    Normal trajectory ingestion uses `extract_file_paths`, which rejects URLs
    (they're rarely meaningful during edit/test loops). At cold start from an
    issue text, the golden file is far more often embedded in a github.com
    blob URL than bare, AND issue authors describe the bug location using
    dotted Python module names (`astropy.modeling.separable_matrix`) instead
    of repo-relative paths. The fallback mines all three forms.
    """
    candidates = list(extract_file_paths(text))
    seen = {candidate for candidate in candidates}
    for regex in (_GITHUB_BLOB_PATH_RE, _GITLAB_BLOB_PATH_RE):
        for match in regex.findall(text):
            path = match.rstrip("/").strip()
            if not path or path in seen:
                continue
            candidates.append(path)
            seen.add(path)
    for module_path in _module_to_path_candidates(text):
        if module_path in seen:
            continue
        candidates.append(module_path)
        seen.add(module_path)
    return candidates


def _looks_like_file_path(candidate: str) -> bool:
    """Conservative filter for lexical file-path candidates.

    Used by the cold-start fallback in build_agent_brief to avoid promoting
    things like 'src/foo' without an extension, version strings like '1.2.3',
    or is/was-style paths that extract_file_paths will occasionally emit.
    """
    value = candidate.strip()
    if not value or len(value) < 4:
        return False
    # Must contain either a directory separator or a recognizable file extension.
    has_separator = "/" in value
    has_extension = bool(FILE_EXTENSION_RE.search(value))
    if not (has_separator and has_extension):
        return False
    # Reject obvious non-paths.
    lowered = value.lower()
    if lowered in {"is/was", "before/after", "and/or"}:
        return False
    return True


def _is_support_or_scratch_file(path: str) -> bool:
    lowered = path.lower()
    basename = lowered.rsplit("/", 1)[-1]
    return (
        basename.startswith("reproduce")
        or basename in {"setup.py", "pyproject.toml", "tox.ini", "readme.md"}
        or "/docs/" in lowered
    )


def _is_scratch_file(path: str) -> bool:
    return path.lower().rsplit("/", 1)[-1].startswith("reproduce")


def _compact_list(values: Any, limit: int) -> list[str]:
    if not isinstance(values, list):
        return []
    return [compact_text(str(value), limit) for value in values if str(value).strip()]


def _compact_list_tiered(
    values: Any, head_limit: int, tail_limit: int, head_count: int = 2
) -> list[str]:
    """Compact the first `head_count` elements to head_limit and the rest to tail_limit.

    Used for evidence fields where the top-scored observations carry the
    load-bearing detail and must survive small-model compaction. Defaults to
    `head_count=2` because the top-ranked result is often a high-importance
    task node that provides context, while the key specifics ("52K tokens",
    "portals.yml") live in the adjacent observation at rank 2.
    """
    if not isinstance(values, list):
        return []
    out: list[str] = []
    for index, value in enumerate(values):
        value_str = str(value)
        if not value_str.strip():
            continue
        limit = head_limit if index < head_count else tail_limit
        out.append(compact_text(value_str, limit))
    return out


def _unique_strings(values: list[str]) -> list[str]:
    unique: list[str] = []
    seen = set()
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        unique.append(value)
    return unique
