# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com).

## [Unreleased]

## [0.12.0] - 2026-05-07

### Added
- `ContainerEntry.dsm_version` — captured at create time via `importlib.metadata.version("dtach-sessions")`.
- `ContainerEntry.session_id` — links a container back to the session that created it.
- `SessionEntry` / `SessionRegistry` — daemon-owned session metadata (replaces `~/.dsm/{sid}/meta.json`).
- `AliasEntry` / `AliasRegistry` — daemon-owned alias storage (replaces CLI-side reads/writes of `~/.dsm/aliases.json`).
- 9 new daemon NDJSON commands: `create_session`, `get_session`, `list_sessions`, `update_session`, `remove_session`, `next_session_number`, `alias_set`, `alias_list`, `alias_remove`.
- `tests/test_architecture.py` — AST-based architecture test enforcing that the CLI never touches state files outside the allowlist (`config.json`, `dsm.sock`).
- Architectural invariant `STATE-01` in `.organon/specs/dsm.invariants.yaml`.
- "Architectural Invariants" section near the top of `CLAUDE.md`.

### Changed
- The CLI is now a thin client. 10 helpers were deleted (`load_meta`, `save_meta`, `find_session`, `find_session_or_none`, `next_session_number`, `load_aliases`, `save_aliases`, `resolve_alias`, `_find_container_names`, `_find_meta_by_container_name`); their call sites route through the daemon.
- `ContainerEntry.from_dict` is now strict: missing fields raise `KeyError`. No silent defaults.
- The `create_container` daemon command accepts an optional `session_id` field; backward-compatible on the wire.

### Removed
- `~/.dsm/{sid}/meta.json` — session metadata now lives at `~/.dsm/sessions/{id}.json`, owned by the daemon.
- CLI-side reads/writes of `~/.dsm/aliases.json` — daemon owns persistence.

### Migration (from 0.11.x)

This is NOT an automatic migration. v0.12.0 ships clean — there is no migration code in the daemon. Upgrade procedure (manual):

```bash
dsm daemon stop                                                    # stop the daemon
docker rm -f $(docker ps -aq --filter "name=dsm_") 2>/dev/null    # remove any zombie dsm containers
cp ~/.dsm/config.json /tmp/dsm-config-backup.json                  # back up your config profiles
rm -rf ~/.dsm/                                                     # wipe the legacy state directory
mkdir -p ~/.dsm
mv /tmp/dsm-config-backup.json ~/.dsm/config.json                  # restore config
# install v0.12.0
dsm ls                                                             # lazy-restart the daemon
```

Note: Host-side `{repo}-worktrees/` directories are git-managed and are NOT touched by this procedure. They may contain uncommitted work; manage them separately.

## [0.11.0] - 2026-05-07

### Added
- `dsm doctor` command — read-only diagnostic that classifies each registered container by removal safety. Probes host-side worktree state and branch merge status against `origin/<default>` (auto-detected via `origin/HEAD`, with fallbacks to `origin/main`/`origin/master`/literal `main`). Status enum: `clean+merged`, `clean+unmerged`, `dirty`, `untracked`, `orphan`, `unknown`. Output groups by repo, sorts by actionability, surfaces a staleness banner when local default lags `origin/<default>` or `FETCH_HEAD` is older than an hour. The classifier is shared infrastructure for the future `dsm prune`.

## [0.10.0] - 2026-05-07

### Added
- Daemon state validation: registry entries are now reconciled against Docker reality at startup and on demand. Containers that disappeared while the daemon was down (or behind its back) are marked with a new `missing` status instead of being reported as `running`.
- `dsm validate` command — re-checks every registry entry against Docker, marking newly-vanished containers `missing` and recovering reappeared ones back to `running` (also re-adds them to port watching).
- `container_gone` event broadcast on the daemon's event stream when the PortWatcher detects a container has disappeared.
- `dsm ls` shows `missing` rows and prints a stderr footer suggesting `dsm rm <name>` or `dsm validate` when any are present.

### Changed
- `dsm rm` now falls back to a registry lookup when the given id has no session directory, fixing the asymmetry where `dsm ls` showed a container that `dsm rm` couldn't find.
- `dsm ls`, `dsm ports`, `dsm forward`, and `dsm unforward` now require the daemon (auto-starting it as before). When the daemon cannot start, they exit with a single clean error suggesting `dsm daemon status`. The previous on-disk registry fallback has been removed.
- `dsm start` (start_container) and `dsm forward` (start_forward) reject containers in `missing` status with a clear "recreate via 'dsm container'" error.

### Removed
- Disk-fallback code paths in the CLI (`_daemon_client`, `_registry_fallback`, `_cmd_ports_direct`). The daemon is the single source of registry truth.

## [0.9.0] - 2026-05-05

### Added
- Config profile inheritance via `extends` key — profiles can inherit from another profile and override fields

## [0.8.0] - 2026-04-21

### Added
- `reserved_host_ports` top-level config key — host-machine port reservation that prevents the daemon from claiming ports owned by host apps regardless of process startup order. Accepts a list of ints (`[8007, 8018]`) or a dict mapping port to documentation note (`{"8007": "coder_ui prod backend"}`)

## [0.7.2] - 2026-04-15

### Fixed
- Port auto-forwarding and event broadcast were silently failing on Python 3.14+ due to `asyncio.get_event_loop()` in worker threads

## [0.7.1] - 2026-04-15

### Fixed
- Deduplicate volume mounts by container destination to prevent Docker "Duplicate mount point" errors when config and caller both specify the same mount

## [0.7.0] - 2026-04-15

### Added
- `.git` overlay mount: when workspace is read-only, `.git/` is mounted read-write so git operations (worktree add, commit, fetch) work while main branch source stays protected
- `_container_layout_valid` function for centralized container mount validation
- Architecture brief and rationale documents (DSM_ARCHITECTURE.md, DSM_RATIONALE.md)

### Changed
- `ensure_container` defaults to `workspace_access="ro"` (was `"rw"`)
- Branch no longer forces workspace to read-write — the `.git` overlay handles git writes
- Existing containers missing the `.git` overlay are automatically recreated

### Removed
- Implicit `rw` override when branch is specified in `cmd_container` and `build_docker_run_cmd`

## [0.6.0] - 2026-04-15

### Added
- `volumes` config field for arbitrary host-to-container mounts using Docker `-v` syntax
- `dsm --version` flag

## [0.5.4] - 2026-04-14

### Fixed
- Warn before removing running containers missing `/worktrees` mount instead of silently killing sessions
- Force workspace to read-write when branch requires `git worktree add` (was blocked by default `ro` access)
- Serialize container-mutating daemon operations with per-container `asyncio.Lock` to prevent TOCTOU races

### Added
- Direct tests for `container_has_mount` function (was always mocked)
- End-to-end tests for `cmd_container` CLI entry point
- Worktree volume and directory assertions in `ensure_container` tests

## [0.5.3] - 2026-04-14

### Fixed
- `build_docker_run_cmd` now takes the actual worktree path instead of assuming bare-worktree layout
- Container reuse path creates worktrees inside the container (mounts are fixed at creation time)
- Workdir is always `/workspace` for new containers (worktree is mounted there directly)

### Removed
- `init-worktree` command — dsm protects main via mount access control, not git layout

## [0.5.2] - 2026-04-14

### Added
- Mount full `~/.ssh` directory into containers (read-only) for git/GitHub SSH access
- Generated CLAUDE.md now includes workspace layout, mounted repos with access modes, and git/SSH instructions
- `agent_instructions` config field — inline text or file path appended to agent CLAUDE.md

## [0.5.1] - 2026-04-14

### Changed
- All container Docker operations (create, start, stop, remove) now route through the daemon as single gateway
- CLI no longer calls `docker run/start/stop/rm` directly for container sessions
- `remove_container` daemon command now handles Docker stop/rm atomically with registry cleanup

### Added
- `create_container`, `start_container`, `stop_container` daemon commands
- `docker_cmd` field on registry entries for faithful container recreation
- Configurable timeout on `DsmClient.send()` for long-running operations
- `force` param on `remove_container` for cleaning unknown containers

### Removed
- Direct Docker mutation calls from CLI (`_register_container_with_daemon`, `_try_register_container`, `_deregister_container`)

## [0.5.0] - 2026-04-14

### Added
- Background daemon (`dsm daemon start|stop|status`) with Unix socket server and NDJSON protocol
- Container registry with atomic JSON persistence (`~/.dsm/registry/`)
- CLI operates as thin daemon client with lazy daemon start
- `dsm ports`, `dsm forward`, `dsm unforward` — port detection and forwarding via socat
- `dsm ports --watch` — background watcher that auto-forwards ports as services start/stop
- `PortWatcher` with 2s polling, state diffing, and container restart detection
- Port detection via `/proc/$PID/net/tcp` (zero-overhead, no docker exec)
- Agent context injection: generate and mount `CLAUDE.md` into containers
- DSM environment variables injected into container sessions
- `workspace_access` parameter for container mount control
- `remove_container` daemon command for deregistering containers
- 90 new tests (151 total)

### Fixed
- Duplicate port forwards piling up on container restart or PortWatcher restart
- Stale forward entries now pruned on daemon startup (dead socat PIDs removed)
- Workspace mount set to read-write so git operations work inside containers
- Daemon logging and robust error handling in PortWatcher
- PortWatcher seeded with existing containers on daemon startup
- `discover_repos` scanner skips git worktrees

### Changed
- PortWatcher migrated from threading to asyncio

## [0.4.0] - 2026-04-09

### Added
- `list_worktrees(repo_path)` — parse `git worktree list --porcelain` into structured dicts
- `get_default_branch(repo_path)` — detect default branch via origin/HEAD with main/master fallback
- `discover_repos` now returns rich dicts (`name`, `path`, `repo_type`, `default_branch`) instead of bare Paths
- `discover_repos` `scan_depth` parameter for recursive directory scanning (default 1)
- `slugify` `max_length` parameter for branch name truncation
- 17 new unit tests (61 total)

### Changed
- `create_git_worktree` returns `Path` and raises `RuntimeError` instead of calling `sys.exit()`
- `create_git_worktree` places worktrees in sibling `{repo}-worktrees/` dir for standard repos (bare-worktree repos unchanged)
- `build_volume_mounts` updated for new `discover_repos` dict return type

## [0.3.0] - 2026-04-08

### Added
- Config system for container sessions (`~/.dsm/config.json`) with named configs, SSH key mounting, repo auto-discovery, and environment variable expansion
- Container reuse: `dsm con` reuses existing containers instead of failing on conflict
- `--new` flag to force-recreate a container
- `--config`, `--mount`, `--access`, `-e`/`--env` CLI flags for container sessions
- Library API for ui_coder: `ensure_container()`, `create_worktree_in_container()`, `get_container_state()`
- Unit test suite (44 tests covering config, container, and build functions)
- `.gitignore`

### Changed
- `build_docker_run_cmd` `env_vars` parameter is now optional for backward compatibility
- Container name is always `dsm_{repo}` regardless of branch (one container per repo)
- Session metadata is saved when reusing containers with new worktrees

### Removed
- Automatic Anthropic API key injection into containers

## [0.2.0] - 2026-04-07

### Added
- Local sessions with dtach (`dsm local`)
- SSH sessions with keepalive (`dsm ssh`)
- Docker container sessions with repo mounting (`dsm container`)
- Git worktree initialization (`dsm init-worktree`)
- Session management: list, resume, tail, remove, clean
- SSH host aliases
- Auto-injection of Anthropic API key into containers
- Output capture via `script` for local/ssh sessions

### Changed
- Renamed `create` subcommand to `local` (alias `l`)

[Unreleased]: https://github.com/pjsulin/dsm/compare/v0.12.0...HEAD
[0.12.0]: https://github.com/pjsulin/dsm/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/pjsulin/dsm/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/pjsulin/dsm/compare/v0.9.0...v0.10.0
[0.9.0]: https://github.com/pjsulin/dsm/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/pjsulin/dsm/compare/v0.7.2...v0.8.0
[0.7.2]: https://github.com/pjsulin/dsm/compare/v0.7.1...v0.7.2
[0.7.1]: https://github.com/pjsulin/dsm/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/pjsulin/dsm/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/pjsulin/dsm/compare/v0.5.4...v0.6.0
[0.5.4]: https://github.com/pjsulin/dsm/compare/v0.5.3...v0.5.4
[0.5.3]: https://github.com/pjsulin/dsm/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/pjsulin/dsm/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/pjsulin/dsm/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/pjsulin/dsm/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/pjsulin/dsm/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/pjsulin/dsm/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/pjsulin/dsm/releases/tag/v0.2.0
