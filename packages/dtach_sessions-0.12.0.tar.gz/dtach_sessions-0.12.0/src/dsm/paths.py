"""Path layout for DSM runtime artifacts.

Owns the on-disk layout for ``~/.dsm/`` so the CLI does not have to construct
state-file paths directly. Daemon-owned stores (registry, sessions, aliases)
live alongside session-owned ephemeral artifacts (sockets, logs, agent
context). This module is the single source of truth for those paths.

Architecture invariant (STATE-01): ``cli.py`` reaches state via the daemon's
NDJSON commands; the only ``~/.dsm/`` paths it constructs directly are the
two allowlisted constants (``config.json`` and ``dsm.sock``). All other
session-relative paths are produced here and imported by the CLI.
"""

from __future__ import annotations

from pathlib import Path

DSM_HOME = Path.home() / ".dsm"


def session_runtime_dir(sid: str) -> Path:
    """Return the per-session runtime directory under DSM_HOME.

    Hosts ephemeral artifacts only: dtach socket, output log, and the agent
    context CLAUDE.md. SessionEntry records live in ``~/.dsm/sessions/`` and
    are owned by the daemon's SessionRegistry.
    """
    return DSM_HOME / sid


def session_socket_path(sid: str) -> Path:
    """Return the dtach socket path for *sid*."""
    return session_runtime_dir(sid) / "socket"


def session_log_path(sid: str) -> Path:
    """Return the output-log path for *sid* (local/ssh sessions only)."""
    return session_runtime_dir(sid) / "output.log"
