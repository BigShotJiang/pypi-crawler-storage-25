"""dsm doctor — classify containers by removal safety.

Read-only diagnostics: probes each container's host-side worktree and branch
state via git, classifies into a status enum, and surfaces what's safe to
prune. No mutations — this is the identification half of the future
``dsm prune``, which will reuse the same classifier.
"""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal


DoctorStatus = Literal[
    "clean+merged",
    "clean+unmerged",
    "dirty",
    "untracked",
    "orphan",
    "unknown",
]


# Sort priority for table output (most actionable first).
STATUS_ORDER: dict[str, int] = {
    "orphan": 0,
    "unknown": 1,
    "clean+merged": 2,
    "clean+unmerged": 3,
    "untracked": 4,
    "dirty": 5,
}


FETCH_HEAD_STALE_SECONDS = 3600


@dataclass
class ContainerReport:
    """Per-container classification and supporting diagnostic counts."""

    container_name: str
    status: DoctorStatus
    branch: str | None = None
    worktree_path: Path | None = None
    repo_path: Path | None = None
    dirty_files: int = 0
    untracked_files: int = 0
    unmerged_commits: int = 0
    notes: list[str] = field(default_factory=list)


# ── Git probes ────────────────────────────────────────────────────────────


def _git(repo: Path, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
        check=False,
    )


def detect_default_branch(repo_path: Path) -> tuple[str, str | None]:
    """Detect the upstream default branch ref.

    Returns ``(default_ref, warning)`` where ``default_ref`` is the remote
    ref like ``origin/main`` (or the literal ``main`` as a last resort) and
    ``warning`` is a user-facing string when fallbacks were used.
    """
    head = _git(repo_path, "symbolic-ref", "--short", "refs/remotes/origin/HEAD")
    if head.returncode == 0 and head.stdout.strip():
        return head.stdout.strip(), None

    for candidate in ("origin/main", "origin/master"):
        if _git(repo_path, "rev-parse", "--verify", candidate).returncode == 0:
            return candidate, (
                f"origin/HEAD not set in {repo_path}; using {candidate}. "
                "Run `git remote set-head origin --auto` to make it permanent."
            )

    return "main", (
        f"origin/HEAD, origin/main, and origin/master all missing in {repo_path}; "
        "defaulting to literal 'main'. "
        "Run `git fetch && git remote set-head origin --auto`."
    )


def worktree_status(
    worktree_path: Path,
) -> tuple[Literal["clean", "dirty", "untracked"], int, int]:
    """Classify worktree state and count dirty/untracked entries.

    Returns ``(state, dirty_count, untracked_count)`` where ``"dirty"`` means
    at least one tracked-file modification exists, ``"untracked"`` means
    clean except for untracked files, and ``"clean"`` means no porcelain
    output. A git failure is treated as ``"dirty"`` so it can't be silently
    pruned.
    """
    proc = _git(worktree_path, "status", "--porcelain")
    if proc.returncode != 0:
        return "dirty", 0, 0
    lines = [ln for ln in proc.stdout.splitlines() if ln]
    untracked = sum(1 for ln in lines if ln.startswith("??"))
    dirty = len(lines) - untracked
    if dirty > 0:
        return "dirty", dirty, untracked
    if untracked > 0:
        return "untracked", 0, untracked
    return "clean", 0, 0


def branch_unmerged_count(
    repo_path: Path, default_ref: str, branch: str
) -> int:
    """Count commits on ``branch`` not reachable from ``default_ref``.

    Returns ``-1`` if git can't compute the answer (e.g., one of the refs is
    missing); callers should treat that as ambiguous.
    """
    proc = _git(repo_path, "rev-list", "--count", f"{default_ref}..{branch}")
    if proc.returncode != 0:
        return -1
    try:
        return int(proc.stdout.strip())
    except ValueError:
        return -1


def branch_exists(repo_path: Path, branch: str) -> bool:
    return (
        _git(repo_path, "rev-parse", "--verify", branch).returncode == 0
    )


def staleness_probe(repo_path: Path, default_ref: str) -> dict:
    """Two no-network freshness signals for the remote default branch.

    Returns:
        - ``local_behind``: commits on ``default_ref`` not in the local
          branch of the same name. ``0`` if up to date or no local branch.
        - ``fetch_head_age_seconds``: seconds since FETCH_HEAD was modified,
          or ``None`` if FETCH_HEAD is missing.
    """
    local_branch = default_ref.split("/", 1)[1] if "/" in default_ref else default_ref
    behind_proc = _git(
        repo_path, "rev-list", "--count", f"{local_branch}..{default_ref}"
    )
    if behind_proc.returncode == 0:
        try:
            local_behind = int(behind_proc.stdout.strip())
        except ValueError:
            local_behind = 0
    else:
        local_behind = 0

    age: int | None = None
    git_path_proc = _git(repo_path, "rev-parse", "--git-path", "FETCH_HEAD")
    if git_path_proc.returncode == 0:
        candidate = Path(git_path_proc.stdout.strip())
        if not candidate.is_absolute():
            candidate = repo_path / candidate
        if candidate.exists():
            age = int(time.time() - candidate.stat().st_mtime)

    return {"local_behind": local_behind, "fetch_head_age_seconds": age}


# ── Per-container classifier ──────────────────────────────────────────────


def _resolve_worktree_path(repo_path: Path, branch: str) -> Path:
    """Worktree path for ``branch`` given ``repo_path``.

    Mirrors ``create_git_worktree``'s placement: bare-worktree repos
    (``repo_path/.bare`` exists) keep worktrees inside ``repo_path``;
    standard repos use the sibling ``{name}-worktrees`` directory.
    """
    if (repo_path / ".bare").is_dir():
        return repo_path / branch
    return repo_path.parent / f"{repo_path.name}-worktrees" / branch


def classify_container(
    container_name: str,
    meta: dict | None,
    default_ref: str | None = None,
) -> ContainerReport:
    """Classify a single container's removal safety.

    ``meta`` is the session ``meta.json`` dict (``None`` for registry-only
    entries). ``default_ref`` is precomputed so callers can amortize
    ``detect_default_branch`` across containers sharing a repo; if omitted,
    it is detected on demand.
    """
    if meta is None:
        return ContainerReport(
            container_name=container_name,
            status="unknown",
            notes=["No session metadata"],
        )

    container = meta.get("container", {})
    repo_path_str = container.get("repo_path")
    branch = container.get("branch")

    if not repo_path_str or not branch:
        return ContainerReport(
            container_name=container_name,
            status="unknown",
            branch=branch,
            notes=["Missing repo_path or branch in session meta"],
        )

    repo_path = Path(repo_path_str)
    if not repo_path.exists():
        return ContainerReport(
            container_name=container_name,
            status="unknown",
            branch=branch,
            repo_path=repo_path,
            notes=[f"Repo path missing on host: {repo_path}"],
        )

    worktree_path = _resolve_worktree_path(repo_path, branch)

    if not branch_exists(repo_path, branch):
        return ContainerReport(
            container_name=container_name,
            status="orphan",
            branch=branch,
            worktree_path=worktree_path if worktree_path.exists() else None,
            repo_path=repo_path,
            notes=["Branch ref missing — worktree may be a stale leftover"],
        )

    if default_ref is None:
        default_ref, _warning = detect_default_branch(repo_path)

    if worktree_path.exists():
        state, dirty, untracked = worktree_status(worktree_path)
    else:
        state, dirty, untracked = "clean", 0, 0

    unmerged = branch_unmerged_count(repo_path, default_ref, branch)
    unmerged_count = max(unmerged, 0)

    if state == "dirty":
        return ContainerReport(
            container_name=container_name,
            status="dirty",
            branch=branch,
            worktree_path=worktree_path,
            repo_path=repo_path,
            dirty_files=dirty,
            untracked_files=untracked,
            unmerged_commits=unmerged_count,
        )
    if state == "untracked":
        return ContainerReport(
            container_name=container_name,
            status="untracked",
            branch=branch,
            worktree_path=worktree_path,
            repo_path=repo_path,
            untracked_files=untracked,
            unmerged_commits=unmerged_count,
        )

    status: DoctorStatus = "clean+merged" if unmerged == 0 else "clean+unmerged"
    return ContainerReport(
        container_name=container_name,
        status=status,
        branch=branch,
        worktree_path=worktree_path,
        repo_path=repo_path,
        unmerged_commits=unmerged_count,
    )
