#!/usr/bin/env python3
"""dsm - dtach session manager

Manage persistent detachable terminal sessions using dtach,
with container and git worktree support.

Usage:
    dsm local -t "Title" [-d "Description"] [-C DIR] -- <command...>
    dsm ssh HOST [-t TITLE] [-d DESC] [SSH_ARGS...]
    dsm container -t TITLE REPO_PATH BRANCH [--image IMG] [-- CMD]
    dsm list
    dsm resume <id>
    dsm tail <id> [<id>...]
    dsm rm <id>
    dsm clean
    dsm alias set|ls|rm
"""

import argparse
import json
import os
import re
import signal
import shlex
import shutil
import socket
import subprocess
import sys
import time as _time
from datetime import datetime
from pathlib import Path

from dsm import ports
from dsm import doctor as _doctor
from dsm import paths as _paths
from typing import Optional

DSM_DIR = _paths.DSM_HOME
CONFIG_FILE = DSM_DIR / "config.json"
DAEMON_SOCKET = DSM_DIR / "dsm.sock"


# ── Daemon client ─────────────────────────────────────────────────────────


class DsmClient:
    """Synchronous NDJSON client for the dsm daemon Unix socket."""

    def __init__(self, socket_path: Path) -> None:
        self.socket_path = socket_path
        self._sock: socket.socket | None = None

    def connect(self) -> None:
        """Open a connection to the daemon socket."""
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(5.0)
        try:
            sock.connect(str(self.socket_path))
        except (ConnectionRefusedError, FileNotFoundError, OSError) as exc:
            sock.close()
            raise ConnectionError(
                f"Cannot connect to daemon at {self.socket_path}: {exc}"
            ) from exc
        self._sock = sock

    def send(self, cmd: str, timeout: float | None = None, **params) -> dict:
        """Send a command and return the parsed response.

        Args:
            cmd: Command name for the daemon.
            timeout: Socket timeout in seconds for this call. Resets after.
            **params: Additional parameters sent as JSON fields.

        Raises RuntimeError if the daemon returns an error.
        """
        if self._sock is None:
            raise ConnectionError("Not connected — call connect() first")
        request: dict = {"cmd": cmd}
        request.update(params)
        payload = json.dumps(request).encode() + b"\n"

        old_timeout = self._sock.gettimeout()
        if timeout is not None:
            self._sock.settimeout(timeout)
        try:
            self._sock.sendall(payload)

            # Read response line
            buf = b""
            while b"\n" not in buf:
                chunk = self._sock.recv(4096)
                if not chunk:
                    raise ConnectionError("Daemon closed the connection")
                buf += chunk
        finally:
            self._sock.settimeout(old_timeout)

        line = buf.split(b"\n", 1)[0]
        response = json.loads(line)
        if response.get("error"):
            raise RuntimeError(f"Daemon error: {response['error']}")
        return response.get("result")

    def close(self) -> None:
        """Close the socket connection."""
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()


def _try_daemon_connect(socket_path: Path) -> bool:
    """Return True if the daemon socket accepts a connection."""
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(str(socket_path))
        s.close()
        return True
    except (ConnectionRefusedError, FileNotFoundError, OSError):
        return False


def ensure_daemon_running(socket_path: Path = DAEMON_SOCKET) -> None:
    """Ensure the daemon is running, spawning it if necessary.

    Tries to connect to the socket. If that fails, spawns the daemon as a
    background subprocess and retries with brief backoff.

    Raises RuntimeError if the daemon cannot be started after retries.
    """
    if _try_daemon_connect(socket_path):
        return

    # Ensure ~/.dsm/ exists so the daemon log open() below succeeds on a
    # fresh install. The daemon also mkdir's its socket parent on start, but
    # we open the log file BEFORE the daemon process is spawned.
    socket_path.parent.mkdir(parents=True, exist_ok=True)

    # Spawn daemon as a background process
    log_path = socket_path.parent / "daemon.log"
    log_file = open(log_path, "a")
    subprocess.Popen(
        [sys.executable, "-m", "dsm.daemon", "--socket", str(socket_path)],
        stdout=log_file,
        stderr=log_file,
        start_new_session=True,
    )

    # Retry connection with backoff
    for attempt in range(6):
        _time.sleep(0.5)
        if _try_daemon_connect(socket_path):
            return

    raise RuntimeError(
        f"Daemon failed to start after retries. Socket: {socket_path}"
    )


def _daemon_client_required() -> DsmClient:
    """Return a connected DsmClient, exiting cleanly if the daemon is unreachable.

    The daemon is the single source of truth for registry state. All commands
    that read or mutate that state route through this helper. If the daemon
    cannot be reached or auto-started, print a user-facing error and exit.
    """
    try:
        ensure_daemon_running(DAEMON_SOCKET)
        client = DsmClient(DAEMON_SOCKET)
        client.connect()
        return client
    except (ConnectionError, RuntimeError) as e:
        print(
            f"Error: dsm daemon failed to start ({e}). "
            f"Run `dsm daemon status` for details.",
            file=sys.stderr,
        )
        sys.exit(1)


def _get_session_or_exit(client: "DsmClient", sid: str) -> dict:
    """Look up a session via daemon RPC. Hard-exits on miss or ambiguous prefix.

    Wraps ``client.send("get_session", id=sid)`` and translates the daemon's
    structured ambiguous-prefix error into the user-facing message format.
    Returns the session dict on a successful match.
    """
    entry = _get_session_or_none(client, sid)
    if entry is None:
        print(f"Error: session '{sid}' not found", file=sys.stderr)
        sys.exit(1)
    return entry


def _get_session_or_none(client: "DsmClient", sid: str) -> dict | None:
    """Look up a session via daemon RPC. Returns None on miss.

    Hard-exits on ambiguous prefix matches (caller can't disambiguate).
    """
    try:
        return client.send("get_session", id=sid)
    except RuntimeError as exc:
        msg = str(exc)
        prefix = "Daemon error: "
        if msg.startswith(prefix):
            try:
                payload = json.loads(msg[len(prefix):])
            except (json.JSONDecodeError, ValueError):
                raise
            if isinstance(payload, dict) and payload.get("marker") == "ambiguous_prefix":
                matches = payload.get("matches", [])
                print(
                    f"Error: ambiguous id '{payload.get('prefix', sid)}', "
                    f"matches: {', '.join(matches)}",
                    file=sys.stderr,
                )
                sys.exit(1)
        raise


# ── Utilities ──────────────────────────────────────────────────────────────


def slugify(text: str, max_length: int | None = None) -> str:
    slug = text.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    slug = slug.strip("-")
    if max_length is not None:
        slug = slug[:max_length].rstrip("-")
    return slug


def _unique_session_id(client: "DsmClient", slug: str) -> str:
    """Pick a session id unique among existing sessions.

    Queries the daemon's SessionRegistry for existing ids and falls back to a
    suffix loop ({slug}-2, {slug}-3, ...) on collision.
    """
    existing = {s["id"] for s in client.send("list_sessions")}
    if slug not in existing:
        return slug
    i = 2
    while f"{slug}-{i}" in existing:
        i += 1
    return f"{slug}-{i}"


def socket_alive(sock_path: Path) -> bool:
    if not sock_path.exists():
        return False
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.5)
        s.connect(str(sock_path))
        s.close()
        return True
    except (ConnectionRefusedError, FileNotFoundError, OSError):
        return False


def container_alive(name: str) -> bool:
    try:
        result = subprocess.run(
            ["docker", "ps", "-q", "-f", f"name=^{name}$"],
            capture_output=True, text=True, check=True,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def dtach_exec(sock: str, command: list[str], log_path: str | None = None):
    """Launch dtach with optional output capture via script."""
    if log_path:
        # macOS uses -F for flush, Linux uses -f
        script_cmd = ["script", "-q", "-F", log_path] + command
        os.execvp("dtach", ["dtach", "-c", sock, "-z"] + script_cmd)
    else:
        os.execvp("dtach", ["dtach", "-c", sock, "-z"] + command)


# ── Config helpers ─────────────────────────────────────────────────────────


def load_config() -> dict:
    """Load config from ~/.dsm/config.json"""
    if not CONFIG_FILE.exists():
        return get_default_config()
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Warning: failed to load config: {e}", file=sys.stderr)
        return get_default_config()


def get_default_config() -> dict:
    """Return minimal default config if file doesn't exist"""
    return {
        "version": "1.0",
        "default_config": "none",
        "configs": {"none": {}}
    }


def _resolve_config(configs: dict, name: str, seen: list = None) -> dict:
    """Resolve a config profile, applying 'extends' inheritance.

    Child values override base. Nested dicts (env, ssh) are shallow-merged
    so the child can override individual keys without repeating the whole block.
    Lists and scalars are replaced outright.
    """
    if seen is None:
        seen = []
    if name in seen:
        chain = " -> ".join(seen + [name])
        print(f"Error: circular config inheritance: {chain}", file=sys.stderr)
        sys.exit(1)

    raw = configs.get(name, {})
    base_name = raw.get("extends")
    if not base_name:
        return {k: v for k, v in raw.items()}

    if base_name not in configs:
        print(f"Error: config '{name}' extends '{base_name}' which does not exist", file=sys.stderr)
        sys.exit(1)

    base = _resolve_config(configs, base_name, seen + [name])
    result = dict(base)
    for key, value in raw.items():
        if key == "extends":
            continue
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            merged = dict(result[key])
            merged.update(value)
            result[key] = merged
        else:
            result[key] = value
    return result


def get_named_config(config_name: str = None) -> dict:
    """Get a specific named config, or default"""
    cfg = load_config()
    name = config_name or cfg.get("default_config", "none")

    configs = cfg.get("configs", {})
    if name not in configs:
        print(f"Error: config '{name}' not found in {CONFIG_FILE}", file=sys.stderr)
        print(f"Available configs: {', '.join(configs.keys())}", file=sys.stderr)
        sys.exit(1)

    return _resolve_config(configs, name)


def expand_env_vars(env_dict: dict) -> dict:
    """Expand ${VAR} references from host environment (strict mode)"""
    expanded = {}

    for key, value in env_dict.items():
        def replacer(match):
            var_name = match.group(1)
            var_value = os.environ.get(var_name)
            if var_value is None:
                print(f"Error: Environment variable '{var_name}' not found", file=sys.stderr)
                print(f"Required by config env.{key}", file=sys.stderr)
                print(f"Set it with: export {var_name}=<value>", file=sys.stderr)
                sys.exit(1)
            return var_value

        expanded_value = re.sub(r'\$\{([^}]+)\}', replacer, str(value))
        expanded[key] = expanded_value

    return expanded


def get_default_branch(repo_path: str) -> str:
    """Determine the default branch of a repository.

    Checks ``refs/remotes/origin/HEAD`` first, then falls back to checking
    for common branch names (main, master).

    Args:
        repo_path: Path to repo (or .bare directory for bare-worktree repos)

    Returns:
        Default branch name (falls back to "main")
    """
    try:
        result = subprocess.run(
            ["git", "-C", repo_path, "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip().split("/")[-1]
    except Exception:
        pass

    for branch in ("main", "master"):
        result = subprocess.run(
            ["git", "-C", repo_path, "rev-parse", "--verify", f"refs/heads/{branch}"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            return branch

    return "main"


def discover_repos(
    repos_dir: str,
    exclude_paths: list[str] = None,
    scan_depth: int = 1,
) -> list[dict]:
    """Find all git repos in a directory.

    Scans for directories containing ``.git`` (standard repos) or ``.bare``
    (bare-worktree repos). Returns rich metadata for each discovered repo.

    Args:
        repos_dir: Root directory to scan
        exclude_paths: Absolute paths to exclude from results
        scan_depth: How many levels deep to recurse (default 1 = immediate children only)

    Returns:
        List of dicts with keys: ``name``, ``path`` (str), ``repo_type``
        ("bare-worktree" | "standard"), ``default_branch``
    """
    repos_path = Path(repos_dir).expanduser().resolve()
    if not repos_path.exists():
        print(f"Warning: repos_dir '{repos_dir}' does not exist", file=sys.stderr)
        return []

    exclude_paths = exclude_paths or []
    exclude_set = {Path(p).resolve() for p in exclude_paths}

    repos: list[dict] = []
    _scan_directory(repos_path, repos, exclude_set, depth=0, max_depth=scan_depth)
    repos.sort(key=lambda r: r["name"])
    return repos


def _scan_directory(
    path: Path, repos: list[dict], exclude_set: set[Path], depth: int, max_depth: int
) -> None:
    """Recursively scan a directory for git repos."""
    if depth >= max_depth:
        return

    try:
        entries = sorted(path.iterdir())
    except PermissionError:
        return

    for entry in entries:
        if not entry.is_dir() or entry.resolve() in exclude_set:
            continue

        bare_dir = entry / ".bare"
        git_dir = entry / ".git"

        if bare_dir.exists() and bare_dir.is_dir():
            repos.append({
                "name": entry.name,
                "path": str(entry),
                "repo_type": "bare-worktree",
                "default_branch": get_default_branch(str(bare_dir)),
            })
        elif git_dir.is_dir():
            repos.append({
                "name": entry.name,
                "path": str(entry),
                "repo_type": "standard",
                "default_branch": get_default_branch(str(entry)),
            })
        else:
            _scan_directory(entry, repos, exclude_set, depth + 1, max_depth)


def build_volume_mounts(config: dict, repo_path: Path, branch: str,
                       extra_mounts: list[str], access: str) -> list[str]:
    """Build volume mount list from config + args"""
    volumes = []

    # SSH directory (if SSH enabled) — gives agents git/GitHub access
    ssh_config = config.get("ssh", {})
    if ssh_config.get("enabled"):
        ssh_dir = Path("~/.ssh").expanduser()
        if ssh_dir.exists():
            volumes.append(f"{ssh_dir}:/home/ubuntu/.ssh:ro")
        else:
            print(f"Warning: SSH directory not found at {ssh_dir}", file=sys.stderr)

    # Repos from repos_dir
    repos_dir = config.get("repos_dir")
    if repos_dir:
        exclude = []
        if config.get("exclude_current_main") and branch:
            main_path = repo_path / "main"
            if main_path.exists():
                exclude.append(str(main_path))

        for repo in discover_repos(repos_dir, exclude):
            mount_name = repo["name"]
            volumes.append(f"{repo['path']}:/mnt/{mount_name}:{access}")

    # Explicit repos list
    for repo in config.get("repos", []):
        repo_path_obj = Path(repo).expanduser().resolve()
        if repo_path_obj.exists():
            mount_name = repo_path_obj.name
            volumes.append(f"{repo_path_obj}:/mnt/{mount_name}:{access}")
        else:
            print(f"Warning: repo '{repo}' does not exist", file=sys.stderr)

    # Arbitrary volumes from config (Docker -v syntax: src:dst[:mode])
    for vol in config.get("volumes", []):
        parts = vol.split(":")
        if len(parts) >= 2:
            src = str(Path(parts[0]).expanduser().resolve())
            dst = parts[1]
            mode = parts[2] if len(parts) > 2 else ""
            if Path(src).exists():
                entry = f"{src}:{dst}:{mode}" if mode else f"{src}:{dst}"
                volumes.append(entry)
            else:
                print(f"Warning: volume source '{parts[0]}' does not exist", file=sys.stderr)
        else:
            print(f"Warning: invalid volume format '{vol}', expected src:dst[:mode]", file=sys.stderr)

    # Extra mounts from --mount flags
    for mount in extra_mounts:
        mount_path = Path(mount).expanduser().resolve()
        if mount_path.exists():
            mount_name = mount_path.name
            volumes.append(f"{mount_path}:/mnt/{mount_name}:{access}")
        else:
            print(f"Warning: mount path '{mount}' does not exist", file=sys.stderr)

    return volumes


def build_port_mappings(config: dict) -> list[str]:
    """Build port mappings from config"""
    ports = []
    ssh_config = config.get("ssh", {})
    if ssh_config.get("enabled"):
        ssh_port = ssh_config.get("port", 2222)
        ports.append(f"{ssh_port}:22")
    return ports


def _detect_host_ip() -> str:
    """Detect the host IP for container-to-host communication.

    Prefers Tailscale IP (stable, routable from anywhere), falls back to
    first LAN IP from hostname -I.
    """
    # Try Tailscale first
    try:
        result = subprocess.run(
            ["ip", "-4", "addr", "show", "tailscale0"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.startswith("inet "):
                    # "inet 100.81.32.42/32 ..." -> "100.81.32.42"
                    return line.split()[1].split("/")[0]
    except FileNotFoundError:
        pass

    # Fall back to first IP from hostname
    try:
        result = subprocess.run(
            ["hostname", "-I"], capture_output=True, text=True,
        )
        if result.returncode == 0:
            ips = result.stdout.strip().split()
            if ips:
                return ips[0]
    except FileNotFoundError:
        pass

    return "localhost"


def _build_dsm_env_vars(container_name: str) -> list[str]:
    """Build DSM-injected environment variables for container context.

    These tell the agent about its runtime environment so it doesn't have
    to discover it's in a container or guess host URLs.
    """
    host_ip = _detect_host_ip()
    return [
        "-e", f"DSM_CONTAINER=1",
        "-e", f"DSM_CONTAINER_NAME={container_name}",
        "-e", f"DSM_HOST_IP={host_ip}",
        "-e", "DSM_PORT_FORWARDING=auto",
    ]


def _generate_agent_context(
    container_name: str,
    volumes: list[str] | None = None,
    config: dict | None = None,
    branch: str | None = None,
    workspace_access: str = "ro",
) -> Path:
    """Generate a CLAUDE.md file with container environment instructions.

    Written to ~/.dsm/agent-context/{container_name}.md on the host, then
    bind-mounted into the container at ~/.claude/CLAUDE.md so Claude Code
    reads it automatically.
    """
    host_ip = _detect_host_ip()
    context_dir = Path.home() / ".dsm" / "agent-context"
    context_dir.mkdir(parents=True, exist_ok=True)
    context_file = context_dir / f"{container_name}.md"

    sections = []

    # Header
    sections.append("# Container Environment\n")
    sections.append("You are running inside a Docker container managed by dsm.\n")

    # Networking
    sections.append(f"""## Networking

- **Container name:** `{container_name}`
- **Host IP:** `{host_ip}`
- Ports bound to `0.0.0.0` are auto-forwarded to the host by dsm
- When giving the user a URL, use `http://{host_ip}:<port>` — never `localhost`
""")

    # Workspace layout
    ws_access_str = "rw" if branch else workspace_access
    workspace_section = "## Workspace\n\n"
    workspace_section += f"- `/workspace` — repository root ({ws_access_str})\n"
    if ws_access_str == "ro":
        workspace_section += "- `/workspace/.git` — git metadata (rw overlay) — git operations work even though workspace is read-only\n"
    workspace_section += "- `/worktrees` — worktree home (one directory per branch)\n"
    if branch:
        workspace_section += f"- `/worktrees/{branch}` — active worktree for branch `{branch}`\n"
        workspace_section += "\nWork in `/worktrees/{branch}`, not `/workspace` directly.\n"
        workspace_section += "Do NOT modify files in `/workspace` — it is read-only (main branch protection).\n"

    # Document mounted repos from volume list
    if volumes:
        mnt_repos = []
        for vol in volumes:
            parts = vol.split(":")
            if len(parts) >= 2 and parts[1].startswith("/mnt/"):
                mount_name = parts[1].split("/mnt/")[1]
                access_mode = parts[2] if len(parts) > 2 else "rw"
                mnt_repos.append((mount_name, access_mode))
        if mnt_repos:
            workspace_section += "- Other repositories available at `/mnt/`:\n"
            for name, mode in sorted(mnt_repos):
                workspace_section += f"  - `/mnt/{name}` ({mode})\n"

    sections.append(workspace_section)

    # Git/SSH
    ssh_config = (config or {}).get("ssh", {})
    if ssh_config.get("enabled"):
        sections.append("""## Git and SSH

- SSH keys are mounted at `~/.ssh` (read-only from host)
- Git operations (clone, push, pull) work via SSH — use `git@github.com:` URLs
- SSH config from the host is available (includes any GitHub host aliases)
""")

    # Environment variables
    sections.append("""## Environment Variables

- `$DSM_HOST_IP` — host IP for constructing URLs
- `$DSM_CONTAINER_NAME` — this container's name
- `$DSM_PORT_FORWARDING` — `auto` (dsm handles port forwarding)
""")

    # User-provided agent instructions from config
    agent_instructions = (config or {}).get("agent_instructions")
    if agent_instructions:
        # Can be inline text or a file path
        instructions_path = Path(agent_instructions).expanduser()
        if instructions_path.exists():
            instructions_text = instructions_path.read_text().strip()
        else:
            instructions_text = agent_instructions.strip()
        if instructions_text:
            sections.append(f"## Project Instructions\n\n{instructions_text}\n")

    context_file.write_text("\n".join(sections))
    return context_file


def _build_agent_context_volume(
    container_name: str,
    volumes: list[str] | None = None,
    config: dict | None = None,
    branch: str | None = None,
    workspace_access: str = "ro",
) -> list[str]:
    """Build the volume mount for the agent context file.

    Mounts the generated CLAUDE.md as a read-only file at ~/.claude/CLAUDE.md
    inside the container. This overlays the directory mount of ~/.claude.
    """
    context_file = _generate_agent_context(
        container_name, volumes=volumes, config=config,
        branch=branch, workspace_access=workspace_access,
    )
    return ["-v", f"{context_file}:/home/ubuntu/.claude/CLAUDE.md:ro"]


def build_env_vars(config: dict, extra_env: list[str]) -> list[str]:
    """Build environment variable list from config + args"""
    env_vars = []

    # Environment variables from config
    raw_env = config.get("env", {})
    if raw_env:
        expanded_env = expand_env_vars(raw_env)
        for key, value in expanded_env.items():
            env_vars.extend(["-e", f"{key}={value}"])

    # Extra env vars from -e flags (KEY=VALUE format)
    for env_str in extra_env:
        if "=" in env_str:
            env_vars.extend(["-e", env_str])
        else:
            print(f"Warning: invalid env format '{env_str}', expected KEY=VALUE", file=sys.stderr)

    return env_vars


# ── Container helpers ──────────────────────────────────────────────────────


def container_has_mount(container_name: str, destination: str) -> bool:
    """Check if a container has a bind mount at the given destination path."""
    result = subprocess.run(
        ["docker", "inspect", "-f",
         "{{range .Mounts}}{{.Destination}} {{end}}", container_name],
        capture_output=True, text=True,
    )
    return result.returncode == 0 and destination in result.stdout.split()


def get_container_state(container_name: str) -> str | None:
    """Check if a docker container exists. Returns 'running', 'exited', or None."""
    result = subprocess.run(
        ["docker", "inspect", "-f", "{{.State.Status}}", container_name],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _container_layout_valid(
    container_name: str, repo_path: Path, workspace_access: str
) -> bool:
    """Check if a container has the current canonical mount layout.

    Validates:
    - /worktrees mount exists
    - .git overlay mount exists when workspace is ro and repo has .git
    """
    if not container_has_mount(container_name, "/worktrees"):
        return False
    if workspace_access == "ro" and (repo_path / ".git").exists():
        if not container_has_mount(container_name, "/workspace/.git"):
            return False
    return True


def ensure_container(
    container_name: str,
    repo_path: Path,
    image: str,
    ports: list[str] | None = None,
    volumes: list[str] | None = None,
    env_vars: list[str] | None = None,
    workspace_access: str = "ro",
    config: dict | None = None,
    session_id: str | None = None,
    client: "DsmClient | None" = None,
) -> str:
    """Ensure a container is running with the canonical layout.

    Canonical layout:
        /workspace       ← repo root (bind from repo_path, default ro)
        /workspace/.git  ← git metadata overlay (rw, when workspace is ro)
        /worktrees       ← worktree home (bind from {repo}-worktrees/)

    The /worktrees bind mount is always created. When workspace_access is "ro"
    and the repo has a .git directory, a .git overlay mount is added
    automatically so git operations (worktree add, commit, fetch) work.

    Callers should not add the /worktrees or .git overlay mounts themselves
    — this function owns the layout contract.

    If the container exists but has an outdated layout (missing /worktrees or
    .git overlay), it is removed and recreated.

    Args:
        container_name: Docker container name
        repo_path: Host path to repository (mounted at /workspace)
        image: Docker image name
        ports: Port mappings (host:container)
        volumes: Additional volume mounts (host:container:mode).
            Do NOT include the /worktrees mount — it is added automatically.
        env_vars: Environment variables as ["-e", "KEY=val", ...]
        workspace_access: Mount mode for /workspace (default "rw")
        config: DSM config dict (forwarded for agent context generation)

    Returns:
        The container state action taken: "already_running", "started", or "created"

    Raises:
        RuntimeError: If container fails to start or create
    """
    owns_client = client is None
    if owns_client:
        client = _daemon_client_required()
    try:
        state = get_container_state(container_name)

        if state == "running":
            if not _container_layout_valid(container_name, repo_path, workspace_access):
                print(
                    f"Warning: container '{container_name}' has outdated layout. "
                    f"Stopping and recreating.",
                    file=sys.stderr,
                )
                client.send("remove_container", container=container_name, force=True)
                state = None
            else:
                # Re-register in case daemon restarted and lost state
                client.send("start_container", container=container_name)
                return "already_running"

        if state is not None:
            if not _container_layout_valid(container_name, repo_path, workspace_access):
                print(
                    f"Warning: container '{container_name}' has outdated layout. "
                    f"Removing and recreating.",
                    file=sys.stderr,
                )
                client.send("remove_container", container=container_name, force=True)
            else:
                # Container exists but not running — restart via daemon
                client.send("start_container", container=container_name)
                return "started"

        # Container doesn't exist (or was just removed) — create via daemon
        # Always create the worktrees bind mount
        worktrees_dir = repo_path.parent / f"{repo_path.name}-worktrees"
        worktrees_dir.mkdir(exist_ok=True)

        all_volumes = list(volumes or [])
        all_volumes.append(f"{worktrees_dir}:/worktrees")

        cmd = build_docker_run_cmd(
            container_name=container_name,
            mount_path=repo_path,
            image=image,
            ports=ports or [],
            volumes=all_volumes,
            env_vars=env_vars,
            branch=None,
            workspace_access=workspace_access,
            config=config,
        )
        client.send("create_container", timeout=120,
                     container_name=container_name, docker_cmd=cmd,
                     session_id=session_id)
        return "created"
    finally:
        if owns_client:
            client.close()


def create_worktree_in_container(
    container_name: str,
    branch: str,
    workspace: str = "/workspace",
) -> str:
    """Create a git worktree inside a running container.

    Uses 3-tier strategy: track remote branch, existing local branch, new branch.
    Creates worktree at /worktrees/{branch} inside the container.

    Args:
        container_name: Running container name
        branch: Branch name (also used as worktree subdirectory name)
        workspace: Path to the repo inside the container

    Returns:
        Container path to the created worktree (e.g. /worktrees/feature-x)

    Raises:
        RuntimeError: If repo has no commits or all strategies fail
    """
    worktree_path = f"/worktrees/{branch}"

    # Check repo has commits
    result = subprocess.run(
        ["docker", "exec", container_name,
         "git", "-C", workspace, "rev-parse", "HEAD"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Repository in {container_name}:{workspace} has no commits. "
            "Cannot create worktree from an empty repository."
        )

    strategies = [
        # Tier 1: track remote branch
        ["git", "-C", workspace, "worktree", "add",
         "--track", "-b", branch, worktree_path, f"origin/{branch}"],
        # Tier 2: existing local branch
        ["git", "-C", workspace, "worktree", "add", worktree_path, branch],
        # Tier 3: new branch
        ["git", "-C", workspace, "worktree", "add", "-b", branch, worktree_path],
    ]

    last_stderr = ""
    for strategy in strategies:
        result = subprocess.run(
            ["docker", "exec", container_name, *strategy],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            return worktree_path
        last_stderr = result.stderr.strip()

    raise RuntimeError(
        f"Failed to create worktree for branch '{branch}' "
        f"in container '{container_name}': {last_stderr}"
    )


# ── Worktree helpers ───────────────────────────────────────────────────────


def create_git_worktree(repo_path: Path, branch_name: str) -> Path:
    """Create a git worktree for the specified branch (3-tier: remote, local, new).

    For bare-worktree repos (.bare inside), worktrees are siblings inside the
    repo container directory (repo_path/branch_name).
    For standard repos (.git dir), worktrees go in a sibling directory
    (repo_path.parent/repo_name-worktrees/branch_name) to avoid nesting.

    Args:
        repo_path: Path to the repository root
        branch_name: Branch name for the worktree

    Returns:
        Path to the created worktree

    Raises:
        RuntimeError: If all strategies fail or repo has no commits
    """
    # Check repo has at least one commit
    result = subprocess.run(
        ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Repository at {repo_path} has no commits. "
            "Cannot create worktree from an empty repository."
        )

    # Determine worktree placement based on repo type
    bare_dir = repo_path / ".bare"
    if bare_dir.exists() and bare_dir.is_dir():
        # Bare-worktree repos: worktrees are siblings inside the container dir
        worktree_path = repo_path / branch_name
    else:
        # Standard repos: sibling directory to avoid nesting inside working tree
        worktrees_dir = repo_path.parent / f"{repo_path.name}-worktrees"
        worktrees_dir.mkdir(exist_ok=True)
        worktree_path = worktrees_dir / branch_name

    # Tier 1: track remote branch
    result = subprocess.run(
        ["git", "-C", str(repo_path), "worktree", "add",
         "--track", "-b", branch_name, str(worktree_path), f"origin/{branch_name}"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return worktree_path

    # Tier 2: existing local branch
    result = subprocess.run(
        ["git", "-C", str(repo_path), "worktree", "add",
         str(worktree_path), branch_name],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return worktree_path

    # Tier 3: new branch from default
    try:
        ref_result = subprocess.run(
            ["git", "-C", str(repo_path), "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, check=True,
        )
        default_branch = ref_result.stdout.strip().split("/")[-1]
    except subprocess.CalledProcessError:
        default_branch = "main"

    result = subprocess.run(
        ["git", "-C", str(repo_path), "worktree", "add",
         "-b", branch_name, str(worktree_path), default_branch],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return worktree_path

    raise RuntimeError(
        f"Failed to create worktree for branch '{branch_name}': {result.stderr.strip()}"
    )


def list_worktrees(repo_path: str) -> list[dict]:
    """List worktrees for a repository.

    Parses ``git worktree list --porcelain`` output.

    Args:
        repo_path: Path to the repository (or .bare directory for bare-worktree repos)

    Returns:
        List of dicts with keys: ``branch`` (str), ``path`` (str), ``is_bare`` (bool)
    """
    result = subprocess.run(
        ["git", "-C", repo_path, "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return []

    worktrees: list[dict] = []
    current_path = ""
    current_branch = ""
    is_bare = False

    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_path = line[len("worktree "):]
        elif line.startswith("branch "):
            ref = line[len("branch "):]
            current_branch = ref.split("/")[-1]
        elif line == "bare":
            is_bare = True
        elif line == "":
            if current_path:
                worktrees.append({
                    "branch": current_branch,
                    "path": current_path,
                    "is_bare": is_bare,
                })
            current_path = ""
            current_branch = ""
            is_bare = False

    # Handle last entry (no trailing blank line)
    if current_path:
        worktrees.append({
            "branch": current_branch,
            "path": current_path,
            "is_bare": is_bare,
        })

    return worktrees


def get_anthropic_key() -> Optional[str]:
    """Get Anthropic API key from environment, config files, or shell configs."""
    # Environment variable
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if api_key:
        print("Found Anthropic API key in environment variable")
        return api_key

    # Claude config locations
    claude_config_paths = [
        Path.home() / ".config" / "claude" / "config.json",
        Path.home() / ".claude" / "config.json",
        Path.home() / "Library" / "Application Support" / "Claude" / "config.json",
    ]
    for config_path in claude_config_paths:
        if config_path.exists():
            try:
                with open(config_path) as f:
                    config = json.load(f)
                    for key_name in ("api_key", "anthropic_api_key"):
                        if key_name in config:
                            print(f"Found Anthropic API key in {config_path}")
                            return config[key_name]
            except (json.JSONDecodeError, KeyError, IOError):
                continue

    # Shell configs
    shell_configs = [
        Path.home() / ".bashrc",
        Path.home() / ".zshrc",
        Path.home() / ".bash_profile",
        Path.home() / ".profile",
    ]
    for shell_config in shell_configs:
        if shell_config.exists():
            try:
                with open(shell_config) as f:
                    content = f.read()
                    match = re.search(
                        r'export\s+ANTHROPIC_API_KEY\s*=\s*["\']?([^"\'\s]+)["\']?',
                        content,
                    )
                    if match:
                        print(f"Found Anthropic API key in {shell_config}")
                        return match.group(1)
            except IOError:
                continue

    return None


# ── Commands ───────────────────────────────────────────────────────────────


def cmd_local(args):
    if not args.command:
        print("Error: no command specified after --", file=sys.stderr)
        sys.exit(1)

    if not shutil.which("dtach"):
        print("Error: dtach is not installed", file=sys.stderr)
        sys.exit(1)

    slug = slugify(args.title)
    if not slug:
        print("Error: title produces empty slug", file=sys.stderr)
        sys.exit(1)

    command = args.command
    if command and command[0] == "claude" and "--dangerously-skip-permissions" not in command:
        command = [command[0], "--dangerously-skip-permissions"] + command[1:]

    cwd = os.path.abspath(args.dir) if args.dir else os.getcwd()
    if not os.path.isdir(cwd):
        print(f"Error: directory '{cwd}' does not exist", file=sys.stderr)
        sys.exit(1)
    os.chdir(cwd)

    client = _daemon_client_required()
    try:
        sid = _unique_session_id(client, slug)
        session_dir = _paths.session_runtime_dir(sid)
        session_dir.mkdir(parents=True)

        now = datetime.now().isoformat()
        client.send("create_session", entry={
            "id": sid,
            "type": "local",
            "title": args.title,
            "description": args.description or "",
            "command": command,
            "cwd": cwd,
            "created_at": now,
            "modified_at": now,
            "container_name": None,
            "extra": {},
        })
    finally:
        client.close()

    sock = str(_paths.session_socket_path(sid))
    log_path = str(_paths.session_log_path(sid))
    dtach_exec(sock, command, log_path)


def cmd_ssh(args):
    client = _daemon_client_required()
    try:
        aliases = client.send("alias_list")
        host = aliases.get(args.host, args.host)

        if args.title:
            title = args.title
        else:
            n = client.send("next_session_number").get("number", 1)
            title = f"session-{n}"
        description = args.description or f"SSH session to {host}"

        if not shutil.which("dtach"):
            print("Error: dtach is not installed", file=sys.stderr)
            sys.exit(1)

        slug = slugify(title)
        if not slug:
            print("Error: title produces empty slug", file=sys.stderr)
            sys.exit(1)

        sid = _unique_session_id(client, slug)
        session_dir = _paths.session_runtime_dir(sid)
        session_dir.mkdir(parents=True)

        keepalive = [
            "-o", "ServerAliveInterval=60",
            "-o", "ServerAliveCountMax=3",
            "-o", "TCPKeepAlive=yes",
        ]
        ssh_cmd = ["ssh"] + keepalive + args.ssh_args + [host]

        now = datetime.now().isoformat()
        client.send("create_session", entry={
            "id": sid,
            "type": "ssh",
            "title": title,
            "description": description,
            "command": ssh_cmd,
            "cwd": os.getcwd(),
            "created_at": now,
            "modified_at": now,
            "container_name": None,
            "extra": {"host": host, "ssh_args": args.ssh_args},
        })
    finally:
        client.close()

    sock = str(_paths.session_socket_path(sid))
    log_path = str(_paths.session_log_path(sid))
    dtach_exec(sock, ssh_cmd, log_path)


def build_docker_run_cmd(container_name: str, mount_path: Path, image: str,
                         ports: list[str], volumes: list[str],
                         env_vars: list[str] | None = None,
                         branch: str | None = None,
                         workspace_access: str = "ro",
                         config: dict | None = None) -> list[str]:
    """Build the docker run command for a container session.

    Mounts mount_path at /workspace with the given access mode. When
    workspace_access is "ro" and mount_path has a .git directory, a .git
    overlay mount is added automatically (rw) so git operations work.
    """
    ws_access = workspace_access

    docker_cmd = [
        "docker", "run", "-d", "--name", container_name,
        "-v", f"{mount_path}:/workspace:{ws_access}",
        "-w", "/workspace",
    ]

    # .git overlay: when workspace is read-only, overlay .git as read-write
    # so git operations (worktree add, commit, fetch) still work
    if ws_access == "ro":
        git_dir = Path(mount_path) / ".git"
        if git_dir.exists():
            docker_cmd.extend(["-v", f"{git_dir}:/workspace/.git:rw"])

    # Port mappings
    for port in ports:
        docker_cmd.extend(["-p", port])

    # Extra volume mounts — deduplicate by container destination to prevent
    # Docker "Duplicate mount point" errors when config and caller both
    # specify the same mount (last occurrence wins)
    seen_destinations: dict[str, str] = {}
    for vol in volumes:
        parts = vol.split(":")
        dest = parts[1] if len(parts) >= 2 else parts[0]
        seen_destinations[dest] = vol
    for vol in seen_destinations.values():
        docker_cmd.extend(["-v", vol])

    # DSM environment variables (container context for agents)
    docker_cmd.extend(_build_dsm_env_vars(container_name))

    # Agent context file — CLAUDE.md with container environment instructions
    docker_cmd.extend(_build_agent_context_volume(
        container_name, volumes=volumes, config=config,
        branch=branch, workspace_access=workspace_access,
    ))

    # Environment variables from config/args (after DSM vars so user can override)
    docker_cmd.extend(env_vars or [])

    docker_cmd.extend([image, "sleep", "infinity"])
    return docker_cmd


def cmd_container(args):
    repo_path = Path(args.repo_path).resolve()
    branch = args.branch  # may be None

    # Validate repo path is git repo
    if not repo_path.exists():
        print(f"Error: repository path does not exist: {repo_path}", file=sys.stderr)
        sys.exit(1)
    if not (repo_path / ".git").exists() and not (repo_path / ".bare").exists():
        print(f"Error: path is not a git repository: {repo_path}", file=sys.stderr)
        sys.exit(1)

    # Load config
    config = get_named_config(args.config)

    # Determine access mode
    # With the .git overlay mount, ro workspace is safe even with branches —
    # .git/ is mounted rw so worktree creation and git operations work
    access = args.access or config.get("default_access", "ro")

    # Build volumes from config + args
    config_volumes = build_volume_mounts(config, repo_path, branch,
                                        args.mount, access)
    all_volumes = config_volumes + args.volume  # config + manual -v flags

    # Build ports from config + args
    config_ports = build_port_mappings(config)
    all_ports = config_ports + args.port  # config + manual -p flags

    # Build env vars from config + args
    all_env_vars = build_env_vars(config, args.env)

    # Get image
    image = args.image or config.get("image", "patricksulin/devcontainer:latest")

    repo_name = repo_path.name
    container_name = f"dsm_{repo_name}"
    # Sanitize for docker
    container_name = re.sub(r"[^a-zA-Z0-9._-]", "_", container_name)

    # Check if container already exists
    container_state = get_container_state(container_name)

    client = _daemon_client_required()
    try:
        # --new: remove existing container first
        if container_state and args.new:
            print(f"Removing existing container '{container_name}'...")
            client.send("remove_container", container=container_name, force=True)

        # Pick the session id up front so we can stamp it on the
        # ContainerEntry created by `create_container`.
        title = args.title or (f"{repo_name}/{branch}" if branch else repo_name)
        slug = slugify(title)
        if not slug:
            slug = container_name
        sid = _unique_session_id(client, slug)

        # Delegate to ensure_container — it owns the canonical layout:
        #   /workspace  ← repo root
        #   /worktrees  ← worktree bind mount (always created)
        # It handles reuse (already running), restart (stopped), layout
        # validation (recreates if /worktrees mount missing), and creation.
        try:
            action = ensure_container(
                container_name, repo_path, image,
                ports=all_ports, volumes=all_volumes,
                env_vars=all_env_vars, workspace_access=access,
                config=config,
                session_id=sid,
                client=client,
            )
        except (ConnectionError, RuntimeError) as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        print(f"Container '{container_name}': {action}")

        # Create worktree inside container if branch specified
        if branch:
            try:
                create_worktree_in_container(container_name, branch)
                print(f"Created worktree: /worktrees/{branch}")
            except RuntimeError as e:
                print(f"Error creating worktree: {e}", file=sys.stderr)
                sys.exit(1)

        command = args.command if args.command else ["claude", "--dangerously-skip-permissions"]
        workdir = f"/worktrees/{branch}" if branch else "/workspace"

        now = datetime.now().isoformat()
        client.send("create_session", entry={
            "id": sid,
            "type": "container",
            "title": title,
            "description": "",
            "command": command,
            "cwd": str(repo_path),
            "created_at": now,
            "modified_at": now,
            "container_name": container_name,
            "extra": {
                "image": image,
                "repo_path": str(repo_path),
                "branch": branch,
                "ports": all_ports,
                "volumes": all_volumes,
                "env": all_env_vars,
            },
        })
    finally:
        client.close()

    # Exec into container and run command
    exec_cmd = ["docker", "exec", "-it", container_name, "bash", "-lc",
                 f"cd {workdir} && {shlex.join(command)}"]
    os.execvp("docker", exec_cmd)


def cmd_list(args):
    client = _daemon_client_required()
    try:
        raw_sessions = client.send("list_sessions")
        containers = client.send("list_containers")
    finally:
        client.close()

    # Compute display status per session: live/dead derived from runtime probes
    # (docker for container sessions, socket for local/ssh). Sort by id so
    # output order matches the previous directory-walk-based listing.
    sessions = []
    for s in sorted(raw_sessions, key=lambda x: x["id"]):
        stype = s.get("type", "local")
        if stype == "container":
            cname = s.get("container_name", "")
            status = "live" if cname and container_alive(cname) else "dead"
        else:
            sock_path = _paths.session_socket_path(s["id"])
            status = "live" if socket_alive(sock_path) else "dead"
        s["status"] = status
        sessions.append(s)

    # Collect container names from sessions to avoid duplicates
    session_container_names = set()
    for s in sessions:
        if s.get("type") == "container":
            cname = s.get("container_name") or ""
            if cname:
                session_container_names.add(cname)

    # Index registry status by container name for cross-referencing
    registry_status_by_name = {c["container_name"]: c.get("status", "unknown") for c in containers}

    # Override session status with registry status when registry says "missing".
    # session_status above returns "live"/"dead" based on docker; "missing" is
    # the daemon's authoritative signal that the entry is orphaned.
    for s in sessions:
        if s.get("type") == "container":
            cname = s.get("container_name") or ""
            if registry_status_by_name.get(cname) == "missing":
                s["status"] = "missing"

    # Add registry-only entries (not already shown via session)
    registry_entries = [
        c for c in containers if c["container_name"] not in session_container_names
    ]

    if not sessions and not registry_entries:
        print("No sessions.")
        return

    # Build unified list: sessions + synthetic entries for registry-only containers
    all_entries = list(sessions)
    for c in registry_entries:
        all_entries.append({
            "id": c["container_name"],
            "type": "container",
            "title": c["container_name"],
            "status": c.get("status", "unknown"),
            "command": [],
            "created_at": c.get("created_at", ""),
            "_registry_only": True,
        })

    if not all_entries:
        print("No sessions.")
        return

    id_w = max(len(s["id"]) for s in all_entries)
    type_w = max(len(s.get("type", "local")) for s in all_entries)
    title_w = max(len(s["title"]) for s in all_entries)
    status_w = max(6, max(len(s["status"]) for s in all_entries))
    cmd_w = max((len(shlex.join(s["command"])) if s.get("command") else 0) for s in all_entries)
    cmd_w = max(cmd_w, 7)  # min width for "COMMAND" header

    header = (
        f"{'ID':<{id_w}}  {'TYPE':<{type_w}}  {'STATUS':<{status_w}}  {'TITLE':<{title_w}}  "
        f"{'COMMAND':<{cmd_w}}  {'CREATED'}"
    )
    print(header)
    print("-" * len(header))

    for s in all_entries:
        created = ""
        if s.get("created_at"):
            try:
                created = datetime.fromisoformat(s["created_at"]).strftime("%Y-%m-%d %H:%M")
            except (ValueError, TypeError):
                created = s.get("created_at", "")[:16]
        cmd_str = shlex.join(s["command"]) if s.get("command") else "(registry)"
        stype = s.get("type", "local")
        print(
            f"{s['id']:<{id_w}}  {stype:<{type_w}}  {s['status']:<{status_w}}  {s['title']:<{title_w}}  "
            f"{cmd_str:<{cmd_w}}  {created}"
        )

    missing_count = sum(1 for s in all_entries if s["status"] == "missing")
    if missing_count:
        print(
            f"\n{missing_count} container(s) marked missing — "
            f"run `dsm rm <name>` to clean up, or `dsm validate` to re-check.",
            file=sys.stderr,
        )


def cmd_resume(args):
    client = _daemon_client_required()
    try:
        meta = _get_session_or_exit(client, args.id)
    finally:
        client.close()

    stype = meta.get("type", "local")
    sid = meta["id"]

    if stype == "container":
        extra = meta.get("extra", {}) or {}
        cname = meta.get("container_name") or extra.get("name", "")
        command = meta.get("command") or ["claude", "--dangerously-skip-permissions"]
        branch = extra.get("branch")
        workdir = "/workspace"

        if not container_alive(cname):
            print(f"Container '{cname}' is dead. Recreating...", file=sys.stderr)
            # Remove old container and recreate via daemon
            try:
                client = _daemon_client_required()
            except (ConnectionError, RuntimeError) as e:
                print(f"Error: daemon required to recreate container: {e}", file=sys.stderr)
                sys.exit(1)
            try:
                client.send("remove_container", container=cname, force=True)
                repo_path = Path(extra.get("repo_path", ""))
                image = extra.get("image", "patricksulin/devcontainer:latest")
                cports = extra.get("ports", [])
                volumes = extra.get("volumes", [])
                env_vars = extra.get("env", [])
                mount_path = repo_path
                ws_access = "ro"
                if branch:
                    mount_path = create_git_worktree(repo_path, branch)
                    ws_access = "rw"  # worktree dir mounted directly — needs rw
                docker_cmd = build_docker_run_cmd(cname, mount_path, image,
                                                   cports, volumes, env_vars, branch,
                                                   workspace_access=ws_access)
                client.send("create_container", timeout=120,
                            container_name=cname, docker_cmd=docker_cmd,
                            session_id=sid)
                client.send("update_session", id=sid, fields={})
            except RuntimeError as e:
                print(f"Error: failed to recreate container: {e}", file=sys.stderr)
                sys.exit(1)
            finally:
                client.close()
            print(f"Container '{cname}' recreated")
            # Exec with command
            exec_cmd = ["docker", "exec", "-it", cname, "bash", "-lc",
                         f"cd {workdir} && {shlex.join(command)}"]
            os.execvp("docker", exec_cmd)
        else:
            client = _daemon_client_required()
            try:
                client.send("update_session", id=sid, fields={})
            finally:
                client.close()
            # Attach to running container
            os.execvp("docker", ["docker", "exec", "-it", cname, "bash", "-l"])
    else:
        # local or ssh
        sock = _paths.session_socket_path(sid)
        client = _daemon_client_required()
        try:
            client.send("update_session", id=sid, fields={})
        finally:
            client.close()
        if not socket_alive(sock):
            print(f"Session '{sid}' is dead. Recreating...", file=sys.stderr)
            cwd = meta.get("cwd") or os.getcwd()
            os.chdir(cwd)
            log_path = str(_paths.session_log_path(sid))
            dtach_exec(str(sock), meta["command"], log_path)
        else:
            os.execvp("dtach", ["dtach", "-a", str(sock), "-z"])


def cmd_tail(args):
    if not args.ids:
        print("Error: at least one session ID required", file=sys.stderr)
        sys.exit(1)

    log_files = []
    client = _daemon_client_required()
    try:
        for sid in args.ids:
            meta = _get_session_or_exit(client, sid)
            stype = meta.get("type", "local")
            real_sid = meta["id"]
            if stype == "container":
                print(f"Tail not supported for container sessions (use 'dsm resume {real_sid}' instead)", file=sys.stderr)
                sys.exit(1)
            log_path = _paths.session_log_path(real_sid)
            if not log_path.exists():
                print(f"Error: no output log for session '{real_sid}' (session may predate output capture)", file=sys.stderr)
                sys.exit(1)
            log_files.append(str(log_path))
    finally:
        client.close()

    os.execvp("tail", ["tail", "-f"] + log_files)




def cmd_alias(args):
    client = _daemon_client_required()
    try:
        if args.alias_cmd == "set":
            try:
                client.send("alias_set", name=args.name, target=args.target)
            except RuntimeError as exc:
                print(f"Error: {exc}", file=sys.stderr)
                sys.exit(1)
            print(f"Alias '{args.name}' -> {args.target}")
        elif args.alias_cmd == "ls":
            aliases = client.send("alias_list")
            if not aliases:
                print("No aliases.")
                return
            name_w = max(len(n) for n in aliases)
            for name, target in sorted(aliases.items()):
                print(f"  {name:<{name_w}}  ->  {target}")
        elif args.alias_cmd == "rm":
            try:
                client.send("alias_remove", name=args.name)
            except RuntimeError as exc:
                # KeyError from daemon comes through as "Daemon error: '<name>'"
                print(f"Error: alias '{args.name}' not found", file=sys.stderr)
                sys.exit(1)
            print(f"Removed alias '{args.name}'")
        else:
            print("Usage: dsm alias {set,ls,rm}", file=sys.stderr)
    finally:
        client.close()


def cmd_clean(args):
    client = _daemon_client_required()
    try:
        sessions = client.send("list_sessions")
        if not sessions:
            print("No sessions.")
            return
        removed = 0
        for s in sorted(sessions, key=lambda x: x["id"]):
            sid = s["id"]
            stype = s.get("type", "local")
            if stype == "container":
                extra = s.get("extra", {}) or {}
                cname = s.get("container_name") or extra.get("name", "")
                alive = bool(cname) and container_alive(cname)
                if alive:
                    continue
                if cname:
                    try:
                        client.send("remove_container", container=cname, force=True)
                    except RuntimeError:
                        pass
            else:
                if socket_alive(_paths.session_socket_path(sid)):
                    continue
            client.send("remove_session", id=sid)
            session_dir = _paths.session_runtime_dir(sid)
            if session_dir.exists():
                shutil.rmtree(session_dir)
            print(f"  Removed dead session '{sid}'")
            removed += 1
    finally:
        client.close()

    if removed == 0:
        print("No dead sessions.")
    else:
        print(f"Cleaned {removed} dead session(s).")


def cmd_rm(args):
    client = _daemon_client_required()
    try:
        meta = _get_session_or_none(client, args.id)

        # Fallback: no session, but the id might be a registry-only container
        # (created and then `docker rm`'d behind DSM's back, leaving the
        # registry entry orphaned). Look it up via the daemon.
        if meta is None:
            try:
                entry = client.send("get_container", container=args.id)
            except RuntimeError:
                entry = None
            if entry is None:
                print(f"Error: no session or container found: {args.id}", file=sys.stderr)
                sys.exit(1)

            cname = entry["container_name"]
            if container_alive(cname):
                print(f"Container '{cname}' is still running. Stop it? [y/N] ", end="", flush=True)
                if input().strip().lower() != "y":
                    return
            client.send("remove_container", container=cname, force=True)
            print(f"Removed container '{cname}' (registry-only entry, no session)")
            return

        sid = meta["id"]
        stype = meta.get("type", "local")

        if stype == "container":
            extra = meta.get("extra", {}) or {}
            cname = meta.get("container_name") or extra.get("name", "")
            if cname and container_alive(cname):
                print(f"Container '{cname}' is still running. Stop it? [y/N] ", end="", flush=True)
                if input().strip().lower() != "y":
                    return
            # Remove container via daemon (handles docker stop/rm + registry)
            if cname:
                client.send("remove_container", container=cname, force=True)
        else:
            sock = _paths.session_socket_path(sid)
            if socket_alive(sock):
                print(f"Session '{sid}' is still live. Kill it? [y/N] ", end="", flush=True)
                if input().strip().lower() != "y":
                    return

        client.send("remove_session", id=sid)
    finally:
        client.close()

    # Remove ephemeral runtime artifacts (socket, output.log, agent context)
    session_dir = _paths.session_runtime_dir(sid)
    if session_dir.exists():
        shutil.rmtree(session_dir)
    print(f"Removed session '{sid}'")


# ── Port forwarding commands ───────────────────────────────────────────────


def _cmd_ports_watch(containers: list[str], exclude_ports: set[int]):
    """Run the port watcher until Ctrl+C."""
    def on_change(changes: list[ports.PortChange]):
        ts = datetime.now().strftime("%H:%M:%S")
        for c in changes:
            if c.action == "added":
                if c.forward and c.forward.alive:
                    print(f"[{ts}] {c.container_name}: + {c.port.port}/{c.port.protocol} "
                          f"{c.port.bind_address} -> forwarded to host:{c.forward.host_port}")
                elif c.port.bind_address in ("127.0.0.1", "::1"):
                    print(f"[{ts}] {c.container_name}: + {c.port.port}/{c.port.protocol} "
                          f"{c.port.bind_address} (loopback — not forwardable)")
                else:
                    print(f"[{ts}] {c.container_name}: + {c.port.port}/{c.port.protocol} "
                          f"{c.port.bind_address} (forward failed)")
            elif c.action == "removed":
                print(f"[{ts}] {c.container_name}: - {c.port.port}/{c.port.protocol} "
                      f"(service stopped, forward removed)")
        sys.stdout.flush()

    watcher = ports.PortWatcher(
        containers=containers,
        on_change=on_change,
        exclude_ports=exclude_ports,
    )

    print(f"Watching {len(containers)} container(s): {', '.join(containers)}")
    if exclude_ports:
        print(f"Excluding ports: {', '.join(str(p) for p in sorted(exclude_ports))}")
    print("Press Ctrl+C to stop.\n")

    watcher.start()

    def handle_signal(signum, frame):
        watcher.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # Block main thread until watcher stops
    try:
        signal.pause()
    except AttributeError:
        # signal.pause() not available on Windows
        import time
        while watcher.running:
            time.sleep(1)


def cmd_ports(args):
    """List detected listening ports and active forwards for containers."""
    if args.watch:
        # --watch mode: use the old foreground PortWatcher approach
        if args.container:
            containers = [args.container]
        else:
            client = _daemon_client_required()
            try:
                sessions = client.send("list_sessions")
            finally:
                client.close()
            containers = sorted({
                s["container_name"] for s in sessions
                if s.get("type") == "container"
                and s.get("container_name")
                and container_alive(s["container_name"])
            })
            if not containers:
                print("No running container sessions found.")
                return
        _cmd_ports_watch(containers, set(args.exclude_port))
        return

    client = _daemon_client_required()
    try:
        port_list = client.send("list_ports", **({"container": args.container} if args.container else {}))
        forward_list = client.send("list_forwards", **({"container": args.container} if args.container else {}))
    finally:
        client.close()

    if not port_list and not forward_list:
        if args.container:
            print(f"No ports or forwards for '{args.container}'.")
        else:
            print("No ports or forwards detected.")
        return

    # Group by container
    by_container: dict[str, dict] = {}
    for p in port_list:
        cname = p.get("container", args.container or "unknown")
        by_container.setdefault(cname, {"ports": [], "forwards": []})["ports"].append(p)
    for f in forward_list:
        cname = f.get("container", args.container or "unknown")
        by_container.setdefault(cname, {"ports": [], "forwards": []})["forwards"].append(f)

    for cname, data in sorted(by_container.items()):
        print(f"Container: {cname}")
        forwarded = {f["container_port"]: f for f in data["forwards"]}

        for p in data["ports"]:
            fwd = forwarded.get(p["port"])
            if p.get("bind_address") in ("127.0.0.1", "::1"):
                status = "(loopback only — not forwardable)"
            elif fwd:
                status = f"-> forwarded to host:{fwd['host_port']} (pid {fwd.get('socat_pid', '?')})"
            else:
                status = "(not forwarded)"
            print(f"  {p['port']}/{p.get('protocol', 'tcp')}  {p.get('bind_address', ''):15s}  {status}")

        # Stale forwards
        detected_ports = {p["port"] for p in data["ports"]}
        for f in data["forwards"]:
            if f["container_port"] not in detected_ports:
                print(f"  {f['container_port']}/tcp  {'':15s}  -> host:{f['host_port']} (stale — port no longer detected)")
        print()


def cmd_forward(args):
    """Forward a container port to the host."""
    client = _daemon_client_required()
    try:
        # Check if already forwarded
        forwards = client.send("list_forwards", container=args.container)
        for fwd in forwards:
            if fwd["container_port"] == args.port:
                print(f"Port {args.port} is already forwarded to host:{fwd['host_port']}")
                return

        try:
            result = client.send(
                "start_forward",
                container=args.container,
                port=args.port,
                host_port=args.host_port,
            )
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        host_port = result.get("host_port", args.port)
        if host_port != args.port:
            print(f"Forwarding {args.container}:{args.port} -> host:{host_port} (requested port unavailable)")
        else:
            print(f"Forwarding {args.container}:{args.port} -> host:{host_port}")
    finally:
        client.close()
    _update_forward_meta(args.container)


def cmd_unforward(args):
    """Stop forwarding a container port."""
    client = _daemon_client_required()
    try:
        # Get current forwards to find the host_port for the message
        forwards = client.send("list_forwards", container=args.container)
        host_port = None
        for fwd in forwards:
            if fwd["container_port"] == args.port:
                host_port = fwd["host_port"]
                break

        if host_port is None:
            print(f"Error: port {args.port} is not being forwarded for '{args.container}'.", file=sys.stderr)
            sys.exit(1)

        try:
            client.send("stop_forward", container=args.container, port=args.port)
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        print(f"Stopped forwarding {args.container}:{args.port} (was host:{host_port})")
    finally:
        client.close()
    _update_forward_meta(args.container)


def _update_forward_meta(container_name: str):
    """Stamp the live forward set onto the matching session's ``extra``."""
    forwards = ports.list_forwards(container_name)
    forwarded_ports = [
        {
            "container_port": h.container_port,
            "host_port": h.host_port,
            "protocol": "tcp",
            "socat_pid": h.process.pid if h.process else None,
        }
        for h in forwards
    ]

    client = _daemon_client_required()
    try:
        sessions = client.send("list_sessions")
        for s in sessions:
            if s.get("type") != "container":
                continue
            if s.get("container_name") != container_name:
                continue
            extra = dict(s.get("extra", {}) or {})
            extra["forwarded_ports"] = forwarded_ports
            client.send("update_session", id=s["id"], fields={"extra": extra})
    finally:
        client.close()


# ── Daemon subcommand ─────────────────────────────────────────────────────


def cmd_daemon(args):
    """Handle dsm daemon start|stop|status."""
    action = args.daemon_action

    if action == "start":
        try:
            ensure_daemon_running(DAEMON_SOCKET)
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        # Get the daemon PID via status command
        client = DsmClient(DAEMON_SOCKET)
        try:
            client.connect()
            status = client.send("status")
            print(f"Daemon started (pid: {status['pid']})")
        except (ConnectionError, RuntimeError):
            print("Daemon started")
        finally:
            client.close()

    elif action == "stop":
        client = DsmClient(DAEMON_SOCKET)
        try:
            client.connect()
            client.send("shutdown")
            print("Daemon stopped")
        except ConnectionError:
            print("Daemon is not running.")
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            client.close()

    elif action == "status":
        client = DsmClient(DAEMON_SOCKET)
        try:
            client.connect()
            status = client.send("status")
            uptime_secs = status.get("uptime", 0)
            mins, secs = divmod(int(uptime_secs), 60)
            hours, mins = divmod(mins, 60)
            if hours > 0:
                uptime_str = f"{hours}h {mins}m {secs}s"
            elif mins > 0:
                uptime_str = f"{mins}m {secs}s"
            else:
                uptime_str = f"{secs}s"

            print(f"Daemon running")
            print(f"  PID:        {status['pid']}")
            print(f"  Uptime:     {uptime_str}")
            print(f"  Containers: {status['containers']}")
            print(f"  Forwards:   {status['forwards']}")
        except ConnectionError:
            print("Daemon is not running.")
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            client.close()

    else:
        print("Usage: dsm daemon {start,stop,status}", file=sys.stderr)
        sys.exit(1)


def cmd_validate(args):
    """Reconcile registry entries with Docker."""
    client = _daemon_client_required()
    try:
        summary = client.send("validate")
    finally:
        client.close()

    missing = summary.get("missing", [])
    recovered = summary.get("recovered", [])
    unchanged = summary.get("unchanged", [])

    if missing:
        print(f"Marked missing ({len(missing)}):")
        for name in missing:
            print(f"  {name}")
    if recovered:
        print(f"Recovered ({len(recovered)}):")
        for name in recovered:
            print(f"  {name}")
    if not missing and not recovered:
        print(f"All {len(unchanged)} container(s) consistent with Docker.")


def _session_to_doctor_meta(session: dict) -> dict:
    """Project a SessionEntry dict into the legacy doctor-meta shape.

    The doctor classifier was authored against the old ``meta.json`` schema
    (``{"container": {"name": ..., "repo_path": ..., "branch": ...}}``).
    SessionEntry stores type-specific fields in ``extra`` and the back-ref to
    the container in ``container_name``. This helper bridges the two so the
    classifier remains agnostic to the data source.
    """
    extra = session.get("extra", {}) or {}
    return {
        "id": session.get("id"),
        "type": session.get("type"),
        "title": session.get("title"),
        "container": {
            "name": session.get("container_name") or extra.get("name"),
            "repo_path": extra.get("repo_path"),
            "branch": extra.get("branch"),
            "image": extra.get("image"),
            "ports": extra.get("ports", []),
            "volumes": extra.get("volumes", []),
            "env": extra.get("env", []),
        },
    }


def cmd_doctor(args):
    """Classify each container by removal safety (read-only)."""
    client = _daemon_client_required()
    try:
        containers = client.send("list_containers")
        sessions = client.send("list_sessions")
    finally:
        client.close()

    if not containers:
        print("No containers registered.")
        return

    # Index sessions by container_name (back-ref) and by linked session_id so
    # we can resolve a ContainerEntry to its originating session via either
    # back-edge. session_id is the authoritative link (set at create time);
    # container_name lookups handle pre-existing entries from before the
    # session_id field was introduced.
    sessions_by_cname: dict[str, dict] = {}
    sessions_by_id: dict[str, dict] = {}
    for s in sessions:
        sessions_by_id[s["id"]] = s
        cname = s.get("container_name")
        if cname:
            sessions_by_cname[cname] = s

    # Group containers by repo so we run default-branch detection and the
    # staleness probe once per repo, not once per container.
    metas: dict[str, dict | None] = {}
    repo_keys: dict[str, Path | None] = {}
    for c in containers:
        name = c["container_name"]
        sid = c.get("session_id")
        session = None
        if sid and sid in sessions_by_id:
            session = sessions_by_id[sid]
        elif name in sessions_by_cname:
            session = sessions_by_cname[name]
        meta = _session_to_doctor_meta(session) if session is not None else None
        metas[name] = meta
        repo_str = (meta or {}).get("container", {}).get("repo_path")
        repo_keys[name] = Path(repo_str) if repo_str else None

    repo_default: dict[Path, tuple[str, str | None]] = {}
    repo_staleness: dict[Path, dict] = {}
    for repo in {p for p in repo_keys.values() if p is not None}:
        if not repo.exists():
            continue
        default_ref, warning = _doctor.detect_default_branch(repo)
        repo_default[repo] = (default_ref, warning)
        repo_staleness[repo] = _doctor.staleness_probe(repo, default_ref)

    reports: list[_doctor.ContainerReport] = []
    for c in containers:
        name = c["container_name"]
        meta = metas[name]
        repo = repo_keys[name]
        default_ref = repo_default.get(repo, (None, None))[0] if repo else None
        reports.append(_doctor.classify_container(name, meta, default_ref))

    reports.sort(key=lambda r: (
        _doctor.STATUS_ORDER.get(r.status, 99),
        r.container_name,
    ))

    # Banner: surface stale remote refs / behind-local-default per repo.
    banner_lines: list[str] = []
    for repo, info in sorted(repo_staleness.items()):
        msgs = []
        if info["local_behind"] > 0:
            local = repo_default[repo][0].split("/", 1)[-1]
            msgs.append(
                f"local {local} is {info['local_behind']} commit(s) behind "
                f"{repo_default[repo][0]}"
            )
        age = info["fetch_head_age_seconds"]
        if age is not None and age > _doctor.FETCH_HEAD_STALE_SECONDS:
            hours = age // 3600
            msgs.append(
                f"FETCH_HEAD is {hours}h old — `origin/*` may be stale"
            )
        if msgs:
            banner_lines.append(f"  {repo}: {'; '.join(msgs)}")

    warnings = [w for _, (_, w) in repo_default.items() if w]
    if banner_lines:
        print("Staleness:")
        for line in banner_lines:
            print(line)
        print("  → run `git fetch` in the affected repo(s).")
        print()
    for w in warnings:
        print(f"Warning: {w}", file=sys.stderr)

    name_w = max(len(r.container_name) for r in reports)
    name_w = max(name_w, len("CONTAINER"))
    branch_w = max((len(r.branch or "-") for r in reports), default=6)
    branch_w = max(branch_w, len("BRANCH"))
    status_w = max(len(r.status) for r in reports)
    status_w = max(status_w, len("STATUS"))

    header = (
        f"{'CONTAINER':<{name_w}}  {'BRANCH':<{branch_w}}  "
        f"{'STATUS':<{status_w}}  WORKTREE"
    )
    print(header)
    print("-" * len(header))
    for r in reports:
        wt = str(r.worktree_path) if r.worktree_path else "-"
        print(
            f"{r.container_name:<{name_w}}  {(r.branch or '-'):<{branch_w}}  "
            f"{r.status:<{status_w}}  {wt}"
        )

    safe = sum(1 for r in reports if r.status == "clean+merged")
    needs_attention = len(reports) - safe
    print(
        f"\n{len(reports)} container(s) — {safe} safe to remove (clean+merged), "
        f"{needs_attention} need attention."
    )


# ── Main / argparse ───────────────────────────────────────────────────────


def main():
    from importlib.metadata import version as pkg_version
    parser = argparse.ArgumentParser(
        prog="dsm",
        description="dtach session manager — local, SSH, and container sessions",
        epilog=(
            "examples:\n"
            "  # Local sessions\n"
            "  dsm local -t 'organon' -C ~/projects/organon -- claude\n"
            "  dsm local -t 'Dev server' -- npm run dev\n"
            "\n"
            "  # SSH sessions\n"
            "  dsm ssh prod                               SSH using saved alias\n"
            "  dsm ssh user@10.0.0.1                      SSH directly to host\n"
            "\n"
            "  # Container sessions\n"
            "  dsm container -t mytest /path/to/repo main\n"
            "  dsm con -t mytest /path/to/repo feature-x --image myimg:latest\n"
            "  dsm con -t mytest /path/to/repo main -- bash\n"
            "\n"
            "  # Managing sessions\n"
            "  dsm ls                                     list all sessions\n"
            "  dsm resume organon                         reattach to session\n"
            "  dsm tail organon                           tail session output\n"
            "  dsm rm organon                             remove a session\n"
            "  dsm clean                                  remove all dead sessions\n"
            "\n"
            "  # Aliases\n"
            "  dsm alias set prod user@10.0.0.1\n"
            "  dsm alias ls\n"
            "  dsm alias rm prod\n"
            "\n"
            "workflow:\n"
            "  1. dsm local/ssh/container     create and attach\n"
            "  2. ctrl+\\                      detach (session keeps running)\n"
            "  3. dsm ls                      see all sessions\n"
            "  4. dsm resume <id>             reattach\n"
            "  5. dsm tail <id>               follow output (local/ssh only)\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version",
                        version=f"dsm {pkg_version('dtach-sessions')}")
    sub = parser.add_subparsers(dest="cmd")

    # local
    p_local = sub.add_parser(
        "local", aliases=["l"],
        help="Create and attach to a new local session",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_local.add_argument("-t", "--title", required=True, help="Session title (used to generate ID)")
    p_local.add_argument("-d", "--description", default="", help="Optional description")
    p_local.add_argument("-C", "--dir", default="", help="Working directory for the session")

    # ssh
    p_ssh = sub.add_parser(
        "ssh",
        help="Create an SSH session",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_ssh.add_argument("host", help="SSH destination (user@host or alias)")
    p_ssh.add_argument("-t", "--title", default="", help="Session title")
    p_ssh.add_argument("-d", "--description", default="", help="Optional description")
    p_ssh.add_argument("ssh_args", nargs="*", help="Extra SSH args")

    # container
    p_container = sub.add_parser(
        "container", aliases=["con"],
        help="Create a container session",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_container.add_argument("-t", "--title", default="", help="Session title")
    p_container.add_argument("repo_path", help="Path to git worktree repo")
    p_container.add_argument("branch", nargs="?", default=None,
                             help="Branch name (optional — creates worktree if provided)")
    p_container.add_argument("--image", default="", help="Docker image (default: from config or patricksulin/devcontainer:latest)")
    p_container.add_argument("--config", default=None,
                             help="Named config to use (default: from config.json)")
    p_container.add_argument("--mount", action="append", default=[],
                             help="Mount specific repo (repeatable)")
    p_container.add_argument("--access", choices=["ro", "rw"], default=None,
                             help="Access mode for config-based mounts (default: from config or ro)")
    p_container.add_argument("-e", "--env", action="append", default=[],
                             help="Environment variable KEY=VALUE (repeatable)")
    p_container.add_argument("-p", "--port", action="append", default=[],
                             help="Port mapping host:container (repeatable)")
    p_container.add_argument("-v", "--volume", action="append", default=[],
                             help="Volume mount host:container (repeatable)")
    p_container.add_argument("--new", action="store_true", default=False,
                             help="Remove existing container and create a new one")

    # alias
    p_alias = sub.add_parser("alias", help="Manage remote host aliases")
    alias_sub = p_alias.add_subparsers(dest="alias_cmd")
    p_alias_set = alias_sub.add_parser("set", help="Save an alias")
    p_alias_set.add_argument("name", help="Alias name")
    p_alias_set.add_argument("target", help="SSH destination (user@host)")
    alias_sub.add_parser("ls", help="List aliases")
    p_alias_rm = alias_sub.add_parser("rm", help="Remove an alias")
    p_alias_rm.add_argument("name", help="Alias name to remove")

    # list
    sub.add_parser("list", aliases=["ls"], help="List all sessions")

    # resume
    p_resume = sub.add_parser(
        "resume", aliases=["r"],
        help="Reattach to a session (restarts if dead)",
    )
    p_resume.add_argument("id", help="Session ID (or unique prefix)")

    # tail
    p_tail = sub.add_parser("tail", help="Tail session output logs")
    p_tail.add_argument("ids", nargs="+", help="Session ID(s)")

    # rm
    p_rm = sub.add_parser("rm", help="Remove a session")
    p_rm.add_argument("id", help="Session ID (or unique prefix)")

    # clean
    sub.add_parser("clean", help="Remove all dead sessions")

    # daemon
    p_daemon = sub.add_parser("daemon", help="Manage the dsm daemon")
    p_daemon.add_argument(
        "daemon_action",
        choices=["start", "stop", "status"],
        help="Action: start, stop, or status",
    )

    # ports
    p_ports = sub.add_parser("ports", help="List detected ports in a container")
    p_ports.add_argument("container", nargs="?", default=None,
                         help="Container name (optional — shows all if omitted)")
    p_ports.add_argument("--watch", "-w", action="store_true", default=False,
                         help="Watch for port changes and auto-forward (runs until Ctrl+C)")
    p_ports.add_argument("--exclude-port", type=int, action="append", default=[],
                         help="Port to exclude from auto-forwarding (repeatable)")

    # forward
    p_forward = sub.add_parser("forward", help="Forward a container port to the host")
    p_forward.add_argument("container", help="Container name")
    p_forward.add_argument("port", type=int, help="Container port to forward")
    p_forward.add_argument("--host-port", type=int, default=None,
                           help="Host port (default: same as container port)")

    # unforward
    p_unforward = sub.add_parser("unforward", help="Stop forwarding a container port")
    p_unforward.add_argument("container", help="Container name")
    p_unforward.add_argument("port", type=int, help="Container port to stop forwarding")

    # validate
    sub.add_parser(
        "validate",
        help="Reconcile registry entries with Docker (mark missing/recovered)",
    )

    # doctor
    sub.add_parser(
        "doctor",
        help="Classify containers by removal safety (read-only)",
    )

    # Split on -- to separate dsm args from session command
    argv = sys.argv[1:]
    if "--" in argv:
        split_idx = argv.index("--")
        dsm_args = argv[:split_idx]
        cmd_args = argv[split_idx + 1:]
    else:
        dsm_args = argv
        cmd_args = []

    args = parser.parse_args(dsm_args)
    args.command = cmd_args

    if args.cmd in ("local", "l"):
        cmd_local(args)
    elif args.cmd == "ssh":
        cmd_ssh(args)
    elif args.cmd in ("container", "con"):
        cmd_container(args)
    elif args.cmd == "alias":
        cmd_alias(args)
    elif args.cmd in ("list", "ls"):
        cmd_list(args)
    elif args.cmd in ("resume", "r"):
        cmd_resume(args)
    elif args.cmd == "tail":
        cmd_tail(args)
    elif args.cmd == "rm":
        cmd_rm(args)
    elif args.cmd == "clean":
        cmd_clean(args)
    elif args.cmd == "daemon":
        cmd_daemon(args)
    elif args.cmd == "ports":
        cmd_ports(args)
    elif args.cmd == "forward":
        cmd_forward(args)
    elif args.cmd == "unforward":
        cmd_unforward(args)
    elif args.cmd == "validate":
        cmd_validate(args)
    elif args.cmd == "doctor":
        cmd_doctor(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
