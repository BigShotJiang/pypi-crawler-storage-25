"""Container registry for the dsm daemon.

Defines the persistent data structures and the ContainerRegistry class used by
the daemon. Models are serialized to JSON files under ~/.dsm/registry/ for
persistence across daemon restarts.

The dataclasses here are pure data — they carry no process handles or runtime
state. This separates them from ports.py's ForwardHandle (which holds a live
subprocess.Popen) and ListeningPort (which is a transient scan result).
"""

from __future__ import annotations

import datetime
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal


@dataclass
class PortInfo:
    """A listening port detected inside a container (persistent record)."""

    port: int
    bind_address: str
    protocol: str  # "tcp" or "tcp6"

    def to_dict(self) -> dict:
        return {
            "port": self.port,
            "bind_address": self.bind_address,
            "protocol": self.protocol,
        }

    @classmethod
    def from_dict(cls, data: dict) -> PortInfo:
        return cls(
            port=data["port"],
            bind_address=data["bind_address"],
            protocol=data["protocol"],
        )


@dataclass
class ForwardInfo:
    """A port forward record (persistent — no live process handle)."""

    container_port: int
    host_port: int
    socat_pid: int
    alive: bool = True

    def to_dict(self) -> dict:
        return {
            "container_port": self.container_port,
            "host_port": self.host_port,
            "socat_pid": self.socat_pid,
            "alive": self.alive,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ForwardInfo:
        return cls(
            container_port=data["container_port"],
            host_port=data["host_port"],
            socat_pid=data["socat_pid"],
            alive=data.get("alive", True),
        )


@dataclass
class ContainerEntry:
    """Full registry entry for a container tracked by the daemon."""

    container_name: str
    container_id: str
    container_ip: str
    status: str  # "running", "stopped", "unknown"
    created_at: str  # ISO 8601
    updated_at: str  # ISO 8601
    dsm_version: str  # value of importlib.metadata.version("dtach-sessions") at create time
    session_id: str | None  # id of the SessionEntry that created this container, or None
    ports: list[PortInfo] = field(default_factory=list)
    forwards: list[ForwardInfo] = field(default_factory=list)
    docker_cmd: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "container_name": self.container_name,
            "container_id": self.container_id,
            "container_ip": self.container_ip,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "dsm_version": self.dsm_version,
            "session_id": self.session_id,
            "ports": [p.to_dict() for p in self.ports],
            "forwards": [f.to_dict() for f in self.forwards],
        }
        if self.docker_cmd:
            d["docker_cmd"] = self.docker_cmd
        return d

    @classmethod
    def from_dict(cls, data: dict) -> ContainerEntry:
        # Strict: missing fields raise KeyError. No silent defaults on schema fields.
        return cls(
            container_name=data["container_name"],
            container_id=data["container_id"],
            container_ip=data["container_ip"],
            status=data["status"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            dsm_version=data["dsm_version"],
            session_id=data["session_id"],
            ports=[PortInfo.from_dict(p) for p in data.get("ports", [])],
            forwards=[ForwardInfo.from_dict(f) for f in data.get("forwards", [])],
            docker_cmd=data.get("docker_cmd", []),
        )


class ContainerRegistry:
    """In-memory container state backed by per-container JSON files.

    Each container is persisted as ``{container_name}.json`` inside
    *registry_dir*. Writes use atomic rename (write to ``.tmp``, then
    ``os.rename``) to prevent corruption on crash.
    """

    def __init__(self, registry_dir: Path) -> None:
        self._registry_dir = registry_dir
        self._entries: dict[str, ContainerEntry] = {}

    # -- Loading ---------------------------------------------------------------

    def load(self) -> None:
        """Read all ``*.json`` files from *registry_dir* into memory.

        Creates the directory if it does not exist.
        """
        os.makedirs(self._registry_dir, exist_ok=True)
        self._entries.clear()
        for path in self._registry_dir.glob("*.json"):
            with open(path) as fh:
                data = json.load(fh)
            entry = ContainerEntry.from_dict(data)
            self._entries[entry.container_name] = entry

    # -- Queries ---------------------------------------------------------------

    def get(self, container_name: str) -> ContainerEntry | None:
        """Return the entry for *container_name*, or ``None``."""
        return self._entries.get(container_name)

    def list(self) -> list[ContainerEntry]:
        """Return all registered entries."""
        return list(self._entries.values())

    # -- Mutations -------------------------------------------------------------

    def register(
        self,
        container_name: str,
        container_id: str,
        ip: str,
        dsm_version: str,
        session_id: str | None,
    ) -> ContainerEntry:
        """Create a new entry with current timestamps and add it to the registry.

        Strict: ``dsm_version`` and ``session_id`` are required (no silent
        defaults). The daemon stamps ``dsm_version`` from
        ``importlib.metadata.version("dtach-sessions")`` and ``session_id``
        from the optional CLI request payload (or ``None``).
        """
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        entry = ContainerEntry(
            container_name=container_name,
            container_id=container_id,
            container_ip=ip,
            status="running",
            created_at=now,
            updated_at=now,
            dsm_version=dsm_version,
            session_id=session_id,
        )
        self._entries[container_name] = entry
        return entry

    def update(self, container_name: str, **fields: object) -> ContainerEntry:
        """Update *fields* on an existing entry and bump ``updated_at``.

        Raises ``KeyError`` if the container is not registered.
        """
        entry = self._entries[container_name]
        for key, value in fields.items():
            if not hasattr(entry, key):
                raise AttributeError(
                    f"ContainerEntry has no field {key!r}"
                )
            setattr(entry, key, value)
        entry.updated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        return entry

    def remove(self, container_name: str) -> None:
        """Remove an entry from memory and delete its JSON file on disk."""
        self._entries.pop(container_name, None)
        path = self._registry_dir / f"{container_name}.json"
        if path.exists():
            path.unlink()

    # -- Persistence -----------------------------------------------------------

    def persist(self, container_name: str) -> None:
        """Atomically write a single entry to disk.

        Writes to ``{name}.json.tmp`` first, then renames to ``{name}.json``
        so a crash mid-write never leaves a corrupt file.
        """
        entry = self._entries[container_name]
        os.makedirs(self._registry_dir, exist_ok=True)
        target = self._registry_dir / f"{container_name}.json"
        tmp = self._registry_dir / f"{container_name}.json.tmp"
        with open(tmp, "w") as fh:
            json.dump(entry.to_dict(), fh, indent=2)
            fh.write("\n")
        os.rename(tmp, target)

    def persist_all(self) -> None:
        """Persist every entry currently in memory."""
        for name in self._entries:
            self.persist(name)


# ─── Sessions ────────────────────────────────────────────────────────────────


SessionType = Literal["local", "ssh", "container"]


@dataclass
class SessionEntry:
    """Persistent record for a dsm session.

    Mirrors the schema previously stored at ``~/.dsm/{sid}/meta.json``. Type-
    specific fields (image, branch, ports, ssh_args, ...) live in ``extra`` so
    the top-level schema stays flat.
    """

    id: str
    type: SessionType
    title: str
    description: str
    command: list[str]
    cwd: str
    created_at: str  # ISO 8601
    modified_at: str  # ISO 8601
    container_name: str | None
    extra: dict

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "title": self.title,
            "description": self.description,
            "command": list(self.command),
            "cwd": self.cwd,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
            "container_name": self.container_name,
            "extra": dict(self.extra),
        }

    @classmethod
    def from_dict(cls, data: dict) -> SessionEntry:
        # Strict: missing fields raise KeyError. No silent defaults.
        return cls(
            id=data["id"],
            type=data["type"],
            title=data["title"],
            description=data["description"],
            command=list(data["command"]),
            cwd=data["cwd"],
            created_at=data["created_at"],
            modified_at=data["modified_at"],
            container_name=data["container_name"],
            extra=dict(data["extra"]),
        )


class SessionRegistry:
    """In-memory session state backed by per-session JSON files.

    Mirrors :class:`ContainerRegistry`: each session is persisted as
    ``{id}.json`` inside *registry_dir* with atomic-rename writes.
    """

    def __init__(self, registry_dir: Path) -> None:
        self._registry_dir = registry_dir
        self._entries: dict[str, SessionEntry] = {}

    # -- Loading ---------------------------------------------------------------

    def load(self) -> None:
        """Read all ``*.json`` files from *registry_dir* into memory.

        Creates the directory if it does not exist.
        """
        os.makedirs(self._registry_dir, exist_ok=True)
        self._entries.clear()
        for path in self._registry_dir.glob("*.json"):
            with open(path) as fh:
                data = json.load(fh)
            entry = SessionEntry.from_dict(data)
            self._entries[entry.id] = entry

    # -- Queries ---------------------------------------------------------------

    def get(self, id_or_prefix: str) -> SessionEntry | None:
        """Look up by exact id, falling back to unique-prefix match.

        Returns ``None`` if no session matches. Raises :class:`RuntimeError`
        when a prefix matches multiple sessions — the daemon's
        ``get_session`` handler catches this and reformats it into a
        structured payload for the CLI.
        """
        # Exact match wins.
        entry = self._entries.get(id_or_prefix)
        if entry is not None:
            return entry

        matches = [eid for eid in self._entries if eid.startswith(id_or_prefix)]
        if not matches:
            return None
        if len(matches) > 1:
            raise RuntimeError(
                f"ambiguous session id prefix {id_or_prefix!r}: "
                f"matches {sorted(matches)!r}"
            )
        return self._entries[matches[0]]

    def list(self) -> list[SessionEntry]:
        """Return all registered sessions."""
        return list(self._entries.values())

    # -- Mutations -------------------------------------------------------------

    def register(self, entry: SessionEntry) -> None:
        """Insert *entry* keyed by its ``id``.

        Caller is responsible for ensuring ids are unique; the registry does
        not auto-rename or de-collide.
        """
        self._entries[entry.id] = entry

    def update(self, id: str, **fields: object) -> SessionEntry:
        """Update *fields* on an existing session and bump ``modified_at``.

        Raises ``KeyError`` if *id* is not registered.
        """
        if id not in self._entries:
            raise KeyError(id)
        entry = self._entries[id]
        for key, value in fields.items():
            if not hasattr(entry, key):
                raise AttributeError(f"SessionEntry has no field {key!r}")
            setattr(entry, key, value)
        entry.modified_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        return entry

    def remove(self, id: str) -> None:
        """Remove a session from memory and delete its JSON file on disk.

        Raises ``KeyError`` if *id* is not registered.
        """
        if id not in self._entries:
            raise KeyError(id)
        self._entries.pop(id)
        path = self._registry_dir / f"{id}.json"
        if path.exists():
            path.unlink()

    # -- Persistence -----------------------------------------------------------

    def persist(self, id: str) -> None:
        """Atomically write a single session to disk."""
        entry = self._entries[id]
        os.makedirs(self._registry_dir, exist_ok=True)
        target = self._registry_dir / f"{id}.json"
        tmp = self._registry_dir / f"{id}.json.tmp"
        with open(tmp, "w") as fh:
            json.dump(entry.to_dict(), fh, indent=2)
            fh.write("\n")
        os.rename(tmp, target)

    def persist_all(self) -> None:
        """Persist every session currently in memory."""
        for id in self._entries:
            self.persist(id)


# ─── Aliases ─────────────────────────────────────────────────────────────────


@dataclass
class AliasEntry:
    """A named SSH-target alias.

    ``name`` must be non-empty and free of whitespace; ``target`` must be
    non-empty. Validation runs on construction so callers cannot smuggle bad
    values past the registry.
    """

    name: str
    target: str

    def __post_init__(self) -> None:
        if not self.name or any(c.isspace() for c in self.name):
            raise ValueError(
                "alias name must be non-empty and contain no whitespace"
            )
        if not self.target:
            raise ValueError("alias target must be non-empty")

    def to_dict(self) -> dict:
        return {"name": self.name, "target": self.target}

    @classmethod
    def from_dict(cls, data: dict) -> AliasEntry:
        return cls(name=data["name"], target=data["target"])


class AliasRegistry:
    """Single-file registry of name → target aliases.

    Persisted as one JSON dict at ``~/.dsm/aliases.json``. Atomic-rename
    writes the whole file on every mutation. The daemon is the single writer.
    """

    def __init__(self, file_path: Path) -> None:
        self._file_path = file_path
        self._entries: dict[str, AliasEntry] = {}

    # -- Loading ---------------------------------------------------------------

    def load(self) -> None:
        """Read the alias file into memory.

        If the file is absent, the in-memory dict is empty.
        """
        self._entries.clear()
        if not self._file_path.exists():
            return
        with open(self._file_path) as fh:
            data = json.load(fh)
        # Validate every entry through AliasEntry construction.
        for name, target in data.items():
            self._entries[name] = AliasEntry(name=name, target=target)

    # -- Queries ---------------------------------------------------------------

    def get(self, name: str) -> str | None:
        """Return the target for *name*, or ``None`` if unknown."""
        entry = self._entries.get(name)
        return entry.target if entry is not None else None

    def list(self) -> dict[str, str]:
        """Return the wire-projection mapping name → target.

        This is the exact shape returned by the ``alias_list`` daemon
        command, so the daemon handler can return this value directly.
        """
        return {name: entry.target for name, entry in self._entries.items()}

    # -- Mutations -------------------------------------------------------------

    def set(self, name: str, target: str) -> None:
        """Set *name* to *target*, validate, and persist immediately.

        Raises :class:`ValueError` (via ``AliasEntry.__post_init__``) if the
        name or target is invalid.
        """
        entry = AliasEntry(name=name, target=target)
        self._entries[name] = entry
        self.persist()

    def remove(self, name: str) -> None:
        """Remove *name*. Raises ``KeyError`` if unknown."""
        if name not in self._entries:
            raise KeyError(name)
        del self._entries[name]
        self.persist()

    # -- Persistence -----------------------------------------------------------

    def persist(self) -> None:
        """Atomically write the entire alias file."""
        os.makedirs(self._file_path.parent, exist_ok=True)
        tmp = self._file_path.with_suffix(self._file_path.suffix + ".tmp")
        with open(tmp, "w") as fh:
            json.dump(self.list(), fh, indent=2)
            fh.write("\n")
        os.rename(tmp, self._file_path)
