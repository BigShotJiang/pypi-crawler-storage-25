# Mini Sprint: Daemon State Validation

**Status:** Completed
**Created:** 2026-05-06
**Completed:** 2026-05-06
**Type:** Bug Fix
**Related:** Backlog [#001] (cleanup bugs), Sprint 01 (daemon architecture)

## Description

The daemon serves registry data without checking Docker reality. `dsm ls` reports containers as `running` that may not exist; `dsm rm` can't remove an entry that has no session dir; CLI commands access state through multiple paths so different commands see different views.

Fix: make the daemon validate against Docker (continuously via PortWatcher, on demand via `dsm validate`, and at startup), and route every read of registry state through the daemon.

## Thinking

### What's actually happening today

**PortWatcher already emits per-port `removed` events when a container disappears** (ports.py:583-593). It builds `PortChange(action="removed")` for each previously-seen port, stops their forwards, and fires the callback. What it doesn't do:
1. Remove the container from `self._containers`, so it polls the ghost forever.
2. Emit any container-level signal — the daemon sees N port removals but no "the entity is gone" event, so the registry status stays `running`.

**Startup has no validation.** After a reboot or daemon restart, `registry.load()` reads JSON from disk verbatim. Containers that Docker removed while the daemon was down keep their old `status="running"`.

**CLI lookup asymmetry is the original `dsm rm dsm_ion` bug.** `cmd_rm` keys off `find_session(args.id)`, which requires a session dir on disk. `cmd_list` reads the registry. If the registry has an entry but no session dir exists, `ls` shows it and `rm` can't find it. The fix isn't transport (daemon vs disk) — it's a lookup fallback in `cmd_rm`.

**State-access patterns to consolidate.** Today: `_daemon_client()` (returns None, triggers fallback), `_registry_fallback()` (reads disk), `_cmd_ports_direct()` (direct docker scan), `find_session()` (session dir), `container_alive()` (direct docker). The principle is *registry truth always comes from the daemon*. Ephemeral docker checks (`container_alive` in `cmd_resume`/`cmd_clean`) are fine to keep — they're not registry reads.

### Decisions

- **`PortChange` schema:** make `port` optional, add `action="container_gone"`. PortWatcher still fires per-port `removed` for forward cleanup, then a trailing `container_gone` to signal the entity. No new callback type.
- **Recovery is manual via `dsm validate`.** No periodic re-validation. `dsm validate` is bidirectional — also flips `missing → running` if Docker now has the container.
- **Missing-state mutations rejected:** `_cmd_start_container` and `_cmd_start_forward` raise on missing entries with "container missing — recreate first." `_cmd_remove_container` already passes `check=False` to docker stop/rm, so registry-only removal works once the lookup gets there.
- **Daemon-unavailable error message:** `"Error: dsm daemon failed to start. Run \`dsm daemon status\` for details."` then `sys.exit(1)`.
- **`cmd_rm` lookup change:** if `find_session()` raises, treat `args.id` as a container name and ask the daemon. Skip `shutil.rmtree(session_dir)` in that branch.
- **What stays:** `cmd_clean`, `cmd_resume`, `_find_container_names` keep their direct `container_alive()` calls. Single-path applies to *registry reads*, not all docker exec.
- **What dies:** `_daemon_client()` (line 165), `_registry_fallback()` (line 191), `_cmd_ports_direct()` (line 1893), and the disk-fallback branches inside `cmd_list`/`cmd_ports`.

### Recovery story

A container marked `missing` means the registry entry exists but `docker inspect` says no. Worktree files are safe on the host (bind mounts to `{repo}-worktrees/`). Recovery: `dsm rm <name>` to drop the registry entry, then `dsm container ...` to recreate. No data loss.

If the user manually `docker start`s a container that DSM thinks is missing, `dsm validate` flips it back to `running` and the PortWatcher reseeds it on the next start (or via the validate command, which can re-add it to the watch list).

## Plan

### 1. Container-gone signal end-to-end (ports.py, daemon.py)
- [x] Make `PortChange.port: Optional[ListeningPort]`, add `"container_gone"` to allowed actions
- [x] In `_poll_container` scan-failure branch: after firing per-port `removed` changes, append a `PortChange(action="container_gone", port=None)` and remove the name from `self._containers`
- [x] In daemon `_on_port_change`: on `container_gone`, call `registry.update(name, status="missing")` + `registry.persist(name)` + `broadcast_event("container_gone", {"container": name})`

### 2. Startup validation (daemon.py)
- [x] Add `_validate_containers()` — for each registry entry, run `docker inspect`, set status to `missing` if absent, `running` if present, persist any changes
- [x] Call from `start()` between `registry.load()` and `_cleanup_stale_forwards()`
- [x] Filter PortWatcher seed list to exclude `missing` entries

### 3. `dsm validate` command (daemon.py, cli.py)
- [x] Add `_cmd_validate` async handler — re-runs the same logic as `_validate_containers()` but also re-adds reappeared containers to PortWatcher; returns `{"missing": [...], "recovered": [...], "unchanged": [...]}`
- [x] Register `"validate"` in `_commands` dispatch table
- [x] Add `dsm validate` CLI subcommand that calls it and prints a summary

### 4. Single-path CLI (cli.py)
- [x] Delete `_daemon_client()`, `_registry_fallback()`, `_cmd_ports_direct()`
- [x] Update `_daemon_client_required()` to catch `RuntimeError`/`ConnectionError` from `ensure_daemon_running`, print the standard error message, `sys.exit(1)`
- [x] `cmd_list`: replace `_daemon_client()` block + disk-fallback `else` branch with single `_daemon_client_required()` call
- [x] `cmd_ports`: replace `_daemon_client()` block + disk-fallback tail with single `_daemon_client_required()` call
- [x] `cmd_forward`: swap `_daemon_client()` → `_daemon_client_required()`
- [x] `cmd_unforward`: swap `_daemon_client()` → `_daemon_client_required()`

### 5. `cmd_rm` lookup fix (cli.py)
- [x] Add `find_session_or_none()` returning `Path | None`; keep `find_session()` as the strict variant
- [x] On no session match, query the daemon for a container entry matching `args.id`
- [x] If found via registry, run the container removal flow (daemon `remove_container`) and skip `shutil.rmtree(session_dir)`
- [x] If neither path matches, error: `"no session or container found: {args.id}"`

### 6. Honest display (cli.py)
- [x] `cmd_list`: cross-reference registry status onto session-backed rows so `missing` overrides `dead`
- [x] Render `missing` rows with status `missing`; widen status column dynamically
- [x] After the table, if any rows are `missing`, print to stderr: `"N container(s) marked missing — run \`dsm rm <name>\` to clean up, or \`dsm validate\` to re-check."`

### 7. Reject missing-state mutations (daemon.py)
- [x] `_cmd_start_container`: if entry exists with status `missing`, raise `RuntimeError("container '<name>' is missing — recreate via 'dsm container'")`
- [x] `_cmd_start_forward`: same check before forward setup

### 8. Tests
- [x] PortWatcher: scan failure removes container from `_containers` and emits `container_gone` change (test_ports.py)
- [x] PortWatcher: container disappears before first scan still fires `container_gone` (test_ports.py)
- [x] Daemon `_on_port_change`: `container_gone` updates registry status to `missing` and persists (test_state_validation.py)
- [x] Daemon `_validate_containers()` on startup marks absent docker containers as missing
- [x] `_validate_containers` filters PortWatcher seed list to exclude missing entries
- [x] `dsm validate`: missing → running transition when container reappears, re-adds to watcher
- [x] `dsm validate`: running → missing transition when container disappears
- [x] `_cmd_start_container` rejects missing entries
- [x] `_cmd_start_forward` rejects missing entries
- [x] `cmd_rm` falls back to registry lookup when no session dir exists
- [x] `cmd_rm` errors clearly when neither session nor registry has the id
- [x] `cmd_list` shows `missing` status and prints the stderr footer
- [x] `_daemon_client_required` prints clean error and exits 1 when daemon can't start
- [x] Removed three dead `_registry_fallback` tests (feature deleted)
- [x] Existing test suite passes (192/192)

## Log

**2026-05-06:** Investigation started from `dsm rm dsm_ion` returning "session not found" while `dsm ls` showed it. Initial analysis pinned this as a daemon validation gap. On review, discovered the actual `dsm rm` bug is a lookup asymmetry independent of the daemon path (cmd_rm keys off session dir, cmd_list keys off registry). PortWatcher already fires per-port `removed` events on container disappearance — what's missing is a container-level signal and the registry status update. Plan rewritten to separate the two fixes (signal plumbing vs. lookup fallback) and to bake in concrete decisions for `PortChange` schema, missing-state mutation policy, recovery model (manual via `dsm validate`), and which direct-docker paths stay vs. die.

**2026-05-06 (later):** All 8 plan tasks executed. Test surprise during writing: validate-command tests intermittently saw `unchanged` instead of `missing`/`recovered` because the live PortWatcher's polling loop was racing the test — it would real-`docker exec` a fake container, fail, fire `container_gone`, and mark the entry missing before validate could observe the transition. Fix was to stop the watcher in tests after `daemon.start()` so validate is the only state observer. The race is benign in production (PortWatcher and validate converge on the same answer) but it underscored that container_gone propagation works end-to-end without help. 11 new tests in `test_state_validation.py`; 3 obsolete `_registry_fallback` tests deleted; suite at 192/192.
