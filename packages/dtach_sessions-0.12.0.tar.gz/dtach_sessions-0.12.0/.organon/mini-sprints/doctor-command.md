# Mini Sprint: `dsm doctor` Command

**Status:** Completed
**Created:** 2026-05-07
**Completed:** 2026-05-07
**Type:** Feature
**Related:** Daemon state validation mini sprint (foundation for cleanup); future `dsm prune`

## Description

Add a read-only `dsm doctor` command that classifies every container by the safety of removing it, based on its worktree state and how its branch relates to the upstream default branch. This is the identification half of cleanup — the future `dsm prune` will act on the same classifications. No mutations in this sprint; all signal, no action.

## Thinking

### What we want to know per container

For each container in the registry, we want a single status that tells the user "is this safe to throw away?" Two host-side git questions answer it:

1. **Is the worktree clean?** No tracked-file modifications, no untracked files. Untracked files split into their own state because they're "soft risk" — recoverable from local fs until next worktree delete, but not in `.git`.
2. **Is the branch fully merged?** Every commit on the branch is reachable from `origin/<default>`. We compare against `origin/<default>`, not local `<default>`, so the user's "I haven't pulled in a week" doesn't make recently-merged branches look unmerged. Squash-merge detection is explicitly out of scope (UI coder workflow uses full merges).

### Status enum (single column in the table)

- `clean+merged` — worktree clean, branch reachable from `origin/<default>`. Safe to remove.
- `clean+unmerged` — worktree clean, branch has commits not in `origin/<default>`. Branch work would survive (it's in `.git`); container removal still safe but worth flagging.
- `dirty` — worktree has tracked-file modifications. Risky.
- `untracked` — worktree clean except for untracked files. Soft risk.
- `orphan` — worktree exists but the branch ref is gone. Cleanup-eligible after the user verifies they didn't intend the branch.
- `unknown` — no session metadata (registry-only entry, container created and orphaned). Can't be classified — can't determine repo/branch.

### Default branch detection

Auto-detect via `git symbolic-ref --short refs/remotes/origin/HEAD`. Fallback chain when missing:
1. `git rev-parse --verify origin/main` → use `origin/main`
2. `git rev-parse --verify origin/master` → use `origin/master`
3. Default to literal `main` and emit a warning suggesting `git remote set-head origin --auto` to fix permanently.

### Staleness signal

Two probes, both no-network:

1. **Local default behind origin** — `git rev-list --count <default>..origin/<default>`. If > 0, local default branch is behind. (We compare against `origin/<default>` so this is informational, not a correctness issue, but the user might want to pull.)
2. **Remote refs themselves stale** — mtime of `.git/FETCH_HEAD`. If > 1 hour old, `origin/<default>` itself may not reflect the remote.

Display these as a single banner above the table when either condition is true. Don't auto-fetch in this sprint; suggest `git fetch` in the banner instead.

### Output shape

One unified table — columns: `ID`, `BRANCH`, `WORKTREE`, `STATUS`. The `STATUS` column carries the enum value. Sort by status (most-actionable first: `orphan`, `unknown`, `clean+merged`, `clean+unmerged`, `untracked`, `dirty`). A trailing summary line: `N containers — X safe to remove (clean+merged), Y need attention.`

### Decisions

- **Command name:** `dsm doctor` (diagnostic; sets up future `dsm prune` to consume the same classifier).
- **Output:** one table, single status column.
- **Branch detection:** auto-detect via `origin/HEAD`, probe-and-fallback chain on miss.
- **Staleness:** banner above the table, no auto-fetch.
- **No squash-merge handling.** UI coder workflow uses full merges; revisit only if that changes.
- **Read-only.** No registry writes, no docker calls, no daemon mutations. The daemon is queried for the registry list (single-path principle still applies); everything else is host-side `git`.
- **Registry-only entries:** classified as `unknown` and shown in the table. Don't error on them.

## Plan

### 1. Detection module (`src/dsm/doctor.py` or section in `cli.py`)
- [x] `detect_default_branch(repo_path) -> tuple[str, str | None]` — returns `(branch_ref, warning)`. Tries `origin/HEAD` → `origin/main` → `origin/master` → `main` (with warning).
- [x] `worktree_status(worktree_path) -> Literal["clean", "dirty", "untracked"]` — runs `git status --porcelain`, classifies based on `^??` vs other prefixes.
- [x] `branch_unmerged_count(repo_path, default_ref, branch) -> int` — `git -C <repo> rev-list --count <default_ref>..<branch>`. Zero = merged.
- [x] `branch_exists(repo_path, branch) -> bool` — `git -C <repo> rev-parse --verify <branch>`.
- [x] `staleness_probe(repo_path, default_ref) -> dict` — returns `{"local_behind": int, "fetch_head_age_seconds": int | None}`.

### 2. Per-container classifier
- [x] `classify_container(meta, daemon_entry, repo_path, default_ref) -> ContainerReport` — composes the above and returns a structured report with `status`, `branch`, `worktree_path`, plus diagnostic detail (dirty file count, unmerged commit count) for display.
- [x] Handle the `unknown` case: meta missing or repo_path missing → return early with `status="unknown"`.
- [x] Handle the `orphan` case: branch_exists returns False → `status="orphan"`.

### 3. CLI command (`cmd_doctor` in `cli.py`)
- [x] Fetch container list via daemon (`_daemon_client_required` + `list_containers`).
- [x] For each container, find its session meta via `find_session_or_none(container_name)` — registry-only entries return None.
- [x] Group by repo (multiple containers may share a repo) so default-branch detection and staleness probe run once per repo.
- [x] Build the unified table; sort by status priority.
- [x] Print staleness banner above the table when applicable.
- [x] Print summary line below.

### 4. Argparse + dispatch
- [x] `sub.add_parser("doctor", help="Classify containers by removal safety (read-only)")`
- [x] Add `elif args.cmd == "doctor": cmd_doctor(args)` in `main()`.

### 5. Tests (`tests/test_doctor.py`)
- [x] Helper to build a real git repo + worktree fixture in tmp_path (no mocks for git plumbing; it's fast enough).
- [x] `clean+merged`: worktree clean, branch fully merged into `origin/main`.
- [x] `clean+unmerged`: worktree clean, branch ahead of `origin/main`.
- [x] `dirty`: tracked-file modification in the worktree.
- [x] `untracked`: clean but with an untracked file.
- [x] `orphan`: branch ref deleted, worktree path still exists.
- [x] `unknown`: registry-only entry (no session meta).
- [x] Default-branch detection: with `origin/HEAD` set, with only `origin/main` set, with only `origin/master` set, with neither (warning emitted).
- [x] Staleness banner: local behind origin/main; FETCH_HEAD older than threshold.

## Log

**2026-05-07:** Mini sprint drafted after a design conversation that confirmed: full merges only (no squash detection needed); auto-detect default via `origin/HEAD` with probe fallback; single table with status column; staleness shown as a banner without auto-fetch. This is the identification half of the eventual `dsm prune` workflow — the same classifier will be reused there.

**2026-05-07:** Implemented. `src/dsm/doctor.py` holds the probes and classifier; `cmd_doctor` in `cli.py` groups containers by repo so default-branch detection and the staleness probe run once per repo. 14 tests in `tests/test_doctor.py` cover all six status enum values, the four default-branch detection paths, and both staleness signals — all use real git repos under `tmp_path` (no subprocess mocks). Full suite: 206/206 passing.
