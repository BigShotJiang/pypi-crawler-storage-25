# Requirements: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Sprint:** eliminate_second_store

## Summary

Make the daemon the single owner of every persistent state read and write in `dsm`. Eliminate the CLI-owned files `~/.dsm/{sid}/meta.json` and `~/.dsm/aliases.json`. Add `dsm_version` and `session_id` to `ContainerEntry`. Add a mechanical test that prevents future reintroduction of CLI-side state files.

## Dependencies

**Information needed from prior phases:**
- `kickoff.md` — sprint context, decisions made, scope bounds.

**Information provided to next phases:**
- To `research.md`: open technical questions on session storage layout, daemon command surface, migration ordering.
- To `architecture.md`: component boundaries (`SessionRegistry`, alias storage, daemon command additions).
- To `spec.md`: contracts for new daemon commands, `SessionEntry`/`ContainerEntry` schema, architecture-test allowlist semantics.
- To `plan.md`: phase boundaries and dependency order.

## Stakeholders

- **Primary user:** project owner. Cares that `dsm doctor` (and future `dsm prune`) work on real machines without "unknown" rows; that future architectural drift is mechanically blocked.
- **Future Claude (this assistant in later conversations):** cares that the rule is loaded automatically (auto-memory + CLAUDE.md + invariants spec) so the principle is a planning input, not a private re-derivation.

## Goals

### Primary

The daemon is the single process that owns every read and write of persistent state. The CLI does not open any file under `~/.dsm/` for state IO.

### Secondary

- `ContainerEntry` is self-describing (records the dsm version that created it and the session it owns).
- Architectural drift away from the primary goal is mechanically blocked by a test.
- The principle is captured in places that get loaded by future planning (invariants spec, auto-memory, CLAUDE.md).

## Functional Requirements

### FR-1: Daemon owns session state
- The daemon stores session records in `~/.dsm/sessions/{id}.json` using the same atomic-write pattern as `ContainerRegistry`.
- The daemon exposes session CRUD over the existing NDJSON socket: create, get (with prefix lookup), list, update, remove, and `next_session_number`.
- Every session write that today calls `save_meta(session_dir, meta)` is replaced by a daemon RPC.
- Every session read that today calls `load_meta(...)`, `find_session*`, or walks `DSM_DIR.iterdir()` is replaced by a daemon RPC.

### FR-2: Daemon owns alias state
- Aliases live as a single in-memory dict in the daemon, persisted to `~/.dsm/aliases.json` only by the daemon.
- The daemon exposes `alias_set`, `alias_list`, `alias_remove`.
- The CLI's `cmd_alias` paths and `resolve_alias` route through the daemon.

### FR-3: Schema additions to `ContainerEntry`
- `dsm_version: str` — captured by the daemon at create-container time via `importlib.metadata.version("dtach-sessions")`. Pre-existing entries get `"<unknown>"`.
- `session_id: str | None` — populated when a CLI session creates the container; `None` for direct daemon-side or pre-existing entries.

### FR-4: Clean install (no migration)
- v0.12.0 ships with no migration code. The upgrade path is: stop the daemon, `rm -rf ~/.dsm/`, install v0.12.0, restart. Documented in CHANGELOG.
- All `from_dict` constructors are strict: missing fields raise. Silent defaults are not used.

### FR-5: CLI consolidation
- The following helpers are deleted from `cli.py`: `load_meta`, `save_meta`, `find_session`, `find_session_or_none`, `_find_meta_by_container_name`, `next_session_number`, `_find_container_names`, `load_aliases`, `save_aliases`, `resolve_alias`.
- No code in `cli.py` constructs a `Path` rooted at `DSM_DIR` for any subpath outside the allowlist (`config.json`, `dsm.sock`).

### FR-6: Mechanical enforcement
- `tests/test_architecture.py::test_cli_does_not_touch_state_files` — AST walk of `src/dsm/cli.py` that fails on any file IO or `Path` construction under `~/.dsm/` outside the allowlist. Failure message names file:line.
- `STATE-01` is added to `.organon/specs/dsm.invariants.yaml` with `enforced_by` pointing at the test path.

### FR-7: Visibility for future planning
- `CLAUDE.md` gains an "Architectural Invariants" section near the top that names the rule and points to `dsm.invariants.yaml`.
- Auto-memory file `feedback_single_persistent_store.md` exists and is referenced from `MEMORY.md`. Body captures the rule, the *why* (history of drift across multiple sprints), and the *how to apply*.

## Non-Functional Requirements

### NFR-1: Clean upgrade
- The upgrade procedure (`rm -rf ~/.dsm/`) is documented clearly in CHANGELOG and is acceptable for this codebase (single-user, single-machine, no production deployment). No automatic migration.

### NFR-3: Test suite green
- All 206 existing tests continue to pass. New tests cover the new surfaces and the migration. Architecture test runs as part of the standard pytest suite.

### NFR-4: Performance
- Session/alias commands have the same perceived latency as today (single round-trip over the local Unix socket). No new background work added on the hot path.

## Acceptance Criteria

A reviewer can verify each item directly:

- [ ] **AC-1:** `grep -nE 'open\(|\.iterdir\(\)|Path\(' src/dsm/cli.py | grep -v 'config\.json\|dsm\.sock'` returns no state-file matches under `DSM_DIR`. (Codifies the architecture-test rule manually for spot-check.)
- [ ] **AC-2:** `tests/test_architecture.py::test_cli_does_not_touch_state_files` passes today and would fail if a violation were introduced (verified by a planted-violation test fixture).
- [ ] **AC-3:** After `rm -rf ~/.dsm/` and a fresh `dsm container ... main` invocation, `dsm doctor` classifies the new container with a non-`unknown` status (verifies that the new architecture closes the gap that motivated this sprint).
- [ ] **AC-4:** Each `ContainerEntry` written by `dsm container ...` in v0.12.0 includes a non-empty `dsm_version` field and a `session_id` matching the session that created it.
- [ ] **AC-5:** `STATE-01` is present in `dsm.invariants.yaml`. The auto-memory feedback file exists and is indexed in `MEMORY.md`. The CLAUDE.md "Architectural Invariants" section is present and references the invariants spec.
- [ ] **AC-6:** Existing test suite still passes; new tests cover SessionRegistry CRUD, daemon session protocol round-trip, daemon alias protocol round-trip, and architecture-test sanity (planted-violation fixture).
- [ ] **AC-7:** CHANGELOG documents the full upgrade procedure with explicit backup steps:
  ```
  1. dsm daemon stop
  2. docker rm -f $(docker ps -aq --filter "name=dsm_")
  3. cp ~/.dsm/config.json /tmp/dsm-config-backup.json
  4. rm -rf ~/.dsm/
  5. mkdir -p ~/.dsm && mv /tmp/dsm-config-backup.json ~/.dsm/config.json
  6. install v0.12.0
  7. dsm ls   # lazy-restart
  ```
  Host-side `{repo}-worktrees/` directories are not touched (may contain uncommitted git work; user's call). Procedure backs up the user's config profiles before the wipe.

## Project Documentation Impact

### Project Specs Affected
- `.organon/specs/dsm.invariants.yaml` — add `STATE-01`.
- `.organon/specs/session.model.yaml` — extend / supersede with new `SessionEntry` schema.
- `.organon/specs/container-entry.model.yaml` — add `dsm_version`, `session_id`.
- `.organon/specs/daemon-protocol.workflow.yaml` — add session and alias commands.
- `.organon/specs/cli.contract.yaml` — note the disallowed-paths rule.

### CLAUDE.md Sections Affected
- New "Architectural Invariants" section near the top.
- Directory Map updated (sessions move under daemon ownership; legacy paths flagged).

### Other Project Docs
- `.organon/STRUCTURE.md` — runtime paths section: clarify what is daemon-owned vs ephemeral; correct the outdated "CLI falls back to reading registry JSON files from disk" note (already false since v0.10.0).
- `MEMORY.md` (auto-memory) — add feedback entry pointer.

## Scope

### In Scope (Must Have)
- All FR-1 through FR-7.
- Migration from current v0.11.x state on the user's machine.
- Architecture test as part of the pytest suite.

### Out of Scope
- ui_coder API extraction (backlog #002).
- Port-forwarding agent visibility (backlog #003).
- Test-teardown daemon-subprocess leaks (backlog #004).
- Refactoring `ensure_container` or other large CLI internals not directly tied to state IO.

### Decisions Locked During Requirements Review
- **Architecture test scanner:** Python `ast` module. A complementary skill is added separately for deeper LLM-driven audits; the AST test is the mechanical floor.
- **Session storage layout:** file-per-record at `~/.dsm/sessions/{id}.json` (mirrors `ContainerRegistry`).
- **Migration:** none in code. Manual `rm -rf ~/.dsm/` is the upgrade path.
- **Architecture-test allowlist:** literal-string match on path segments (`"config.json"`, `"dsm.sock"`).
- **Schema strictness:** `from_dict` is strict — missing fields raise.
