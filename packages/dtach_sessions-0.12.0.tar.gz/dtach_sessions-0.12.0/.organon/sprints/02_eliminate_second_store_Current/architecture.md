# Architecture: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Sprint:** eliminate_second_store

## Summary

Three new dataclasses and two new registry classes added to `registry.py`. Nine new daemon commands added to the existing dispatch table. CLI helpers deleted; call sites converted to daemon RPCs. One new test module for the architectural enforcement test. No new dependencies — stdlib only.

## Dependencies

**Information needed from prior phases:**
- `requirements.md` — functional requirements, acceptance criteria, locked decisions.
- `research.md` — existing patterns (ContainerRegistry, daemon `_commands`), AST node types, CLI consolidation inventory.

**Information provided to next phases:**
- To `spec.md`: exact contracts for each new daemon command, dataclass field schemas, architecture-test allowlist semantics.
- To `plan.md`: scaffolding order, phase dependencies.

## Module Organization

**New files:**
- `tests/test_architecture.py` — AST-based architecture test.

**Modified files:**
- `src/dsm/registry.py` — adds `SessionEntry`, `SessionRegistry`, `AliasEntry`, `AliasRegistry`; extends `ContainerEntry` with `dsm_version` and `session_id`.
- `src/dsm/daemon.py` — owns the new registries; adds 9 command handlers; loads aliases on startup, persists on mutation.
- `src/dsm/cli.py` — deletes 10 CLI helpers (research.md §5); call sites convert to daemon RPCs.
- `.organon/specs/dsm.invariants.yaml` — adds `STATE-01`.
- `CLAUDE.md` — adds top-of-file "Architectural Invariants" section.
- `CHANGELOG.md` — `[Unreleased]` documents the upgrade procedure (`rm -rf ~/.dsm/`).

**New auto-memory file:**
- `~/.claude/projects/-home-pjsulin-repos-dev-dsm/memory/feedback_single_persistent_store.md` — feedback entry; pointer added to `MEMORY.md`.

**Runtime paths after sprint:**
- `~/.dsm/registry/*.json` — `ContainerEntry` records (existing).
- `~/.dsm/sessions/*.json` — `SessionEntry` records (new, daemon-owned).
- `~/.dsm/aliases.json` — single JSON dict of alias records (new, daemon-owned).
- `~/.dsm/config.json` — user input (unchanged).
- `~/.dsm/dsm.sock`, `~/.dsm/daemon.log` — daemon runtime (unchanged).
- `~/.dsm/{sid}/socket`, `~/.dsm/{sid}/output.log`, `~/.dsm/{sid}/CLAUDE.md` — ephemeral runtime artifacts only (no `meta.json` after this sprint).

## Class Structure

### `registry.py` — modifications and additions

**Modified:**

- `ContainerEntry` — gains:
  - `dsm_version: str` (no default; strict)
  - `session_id: str | None` (no default; strict — must be supplied even if None)
  - `to_dict` / `from_dict` updated to include both. `from_dict` raises `KeyError` on missing fields (strict).

**New:**

- `SessionEntry` — dataclass mirroring the current `meta.json` schema:
  ```
  id: str
  type: Literal["local", "ssh", "container"]
  title: str
  description: str
  command: list[str]
  cwd: str
  created_at: str
  modified_at: str
  container_name: str | None
  extra: dict   # type-specific fields (image, branch, ports, volumes, env, ssh_args)
  ```
  Strict `from_dict`. Atomic `to_dict`.

- `SessionRegistry` — class-shape copy of `ContainerRegistry`:
  - `__init__(registry_dir: Path)` — directory is `~/.dsm/sessions/` at runtime.
  - `load`, `get(id_or_prefix) -> SessionEntry | None` (prefix lookup like `find_session_or_none`), `list`, `register(entry)`, `update(id, **fields)`, `remove(id)`, `persist(id)`, `persist_all()`.
  - Same atomic-rename pattern (`tmp` + `os.rename`).

- `AliasEntry` — dataclass:
  ```
  name: str
  target: str

  def __post_init__(self):
      if not self.name or any(c.isspace() for c in self.name):
          raise ValueError("alias name must be non-empty and contain no whitespace")
      if not self.target:
          raise ValueError("alias target must be non-empty")
  ```
  `to_dict` / `from_dict`.

- `AliasRegistry` — single-file persistence (one JSON dict at `~/.dsm/aliases.json`):
  - `__init__(file_path: Path)`.
  - `load()` — reads dict from file (or `{}` if absent).
  - `get(name)`, `list() -> dict[str, str]`, `set(name, target)`, `remove(name)`.
  - `persist()` — atomic write (`.tmp` + rename) of the entire file.
  - Single-file is acceptable here because the entire alias set is small (typically < 20 entries) and the daemon is the single writer.

### `daemon.py` — modifications

`DsmDaemon.__init__` gains:
```
self.sessions = SessionRegistry(sessions_dir)
self.aliases = AliasRegistry(aliases_path)
```

`DsmDaemon.start()` calls `self.sessions.load()` and `self.aliases.load()` alongside `self.registry.load()`.

Nine new command handlers, all following the existing signature `async def _cmd_X(self, request, writer) -> Any`:

| Command | Handler | Purpose |
|---------|---------|---------|
| `create_session` | `_cmd_create_session` | Insert SessionEntry; return id. Generates id from title slug + collision suffix. |
| `get_session` | `_cmd_get_session` | Return entry for id or unique prefix; `None` on miss; raise on ambiguous prefix. |
| `list_sessions` | `_cmd_list_sessions` | Return all SessionEntries as dicts. |
| `update_session` | `_cmd_update_session` | Mutate fields, bump `modified_at`. |
| `remove_session` | `_cmd_remove_session` | Delete by id. |
| `next_session_number` | `_cmd_next_session_number` | Returns max(existing `session-N` numbers) + 1. |
| `alias_set` | `_cmd_alias_set` | Set name → target, validate, persist. |
| `alias_list` | `_cmd_alias_list` | Return full alias dict. |
| `alias_remove` | `_cmd_alias_remove` | Delete by name. |

`_cmd_create_container` is modified:
- Reads optional `session_id` from request.
- Calls `importlib.metadata.version("dtach-sessions")` once at module load; caches the value.
- Passes both into `registry.register(...)`.
- `ContainerRegistry.register` signature gains `dsm_version: str` and `session_id: str | None` parameters.

All nine new handlers added to `_commands` dispatch dict.

### `cli.py` — modifications

10 helpers deleted. 29 call sites converted to daemon RPCs (research.md §5). The pattern is uniform:

```python
# before
meta = load_meta(session_dir)

# after
client = _daemon_client_required()
try:
    meta = client.send("get_session", id=sid)
finally:
    client.close()
```

Where multiple operations happen in one command, the connection is held open across them (already the existing pattern for `cmd_list`, `cmd_clean`, etc.).

### `tests/test_architecture.py` — new test module

One test: `test_cli_does_not_touch_state_files`. Implementation outline:

```python
import ast
from pathlib import Path

CLI_SOURCE = Path("src/dsm/cli.py")
ALLOWED_FINAL_SEGMENTS = {"config.json", "dsm.sock"}

def test_cli_does_not_touch_state_files():
    tree = ast.parse(CLI_SOURCE.read_text())
    violations: list[str] = []
    for node in ast.walk(tree):
        if _is_violating_path_construction(node):
            violations.append(f"line {node.lineno}: {ast.unparse(node)}")
        if _is_violating_open_call(node):
            violations.append(f"line {node.lineno}: {ast.unparse(node)}")
    assert not violations, "\n".join(violations)
```

Helper predicates inspect the node types listed in research.md §4. Allowlist is applied by walking `ast.BinOp` chains and matching constant string segments against `ALLOWED_FINAL_SEGMENTS`.

A second test, `test_planted_violation_is_caught`, parses an inline string fixture containing a deliberate violation and asserts the walker finds it. This proves the test catches what it claims.

## Component Boundaries

```
                       ┌───────────────────────────┐
                       │          cli.py           │
                       │   (thin client; no IO)    │
                       └──────────────┬────────────┘
                                      │ NDJSON over Unix socket
                                      ▼
                       ┌───────────────────────────┐
                       │         daemon.py         │
                       │  - dispatch _commands     │
                       │  - owns registries        │
                       │  - owns persistence       │
                       └──────────────┬────────────┘
                                      │
              ┌───────────────────────┼───────────────────────┐
              ▼                       ▼                       ▼
   ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐
   │ ContainerRegistry  │  │  SessionRegistry   │  │   AliasRegistry    │
   │ ~/.dsm/registry/   │  │  ~/.dsm/sessions/  │  │  ~/.dsm/aliases.json│
   │ file-per-record    │  │  file-per-record   │  │  single file       │
   └────────────────────┘  └────────────────────┘  └────────────────────┘
```

The CLI never reaches around the daemon. Every persistent read or write goes through one of the three registries, all owned by the daemon, all gated by the `_commands` dispatch.

## Non-Functional Properties

- **Zero new dependencies** — stdlib only.
- **Single writer for every store** — daemon process. Atomic-rename writes prevent corruption.
- **Strict schemas** — `from_dict` raises on missing fields. No silent defaults.
- **Same wire latency** — new commands are a single round-trip, identical to existing commands.
- **No migration code at runtime** — clean `rm -rf ~/.dsm/` upgrade.

## Scaffolding Plan

1. **Registry foundations** — `SessionEntry`, `SessionRegistry`, `AliasEntry`, `AliasRegistry` in `registry.py`. Tests for each. No daemon/CLI integration yet.
2. **`ContainerEntry` schema extension** — add the two new fields. Update existing tests to pass `dsm_version` and `session_id`.
3. **Daemon command surface** — wire the three registries into `DsmDaemon.__init__`, load on `start()`, add the 9 command handlers, register in `_commands`. Tests round-trip each.
4. **CLI consolidation** — replace each helper, delete the helper, update call sites. Existing tests must continue to pass.
5. **Architecture test** — add `tests/test_architecture.py`. Ensure it passes after the consolidation. Add the planted-violation sanity test.
6. **Invariant + memory + CLAUDE.md** — `STATE-01`, `feedback_single_persistent_store.md`, CLAUDE.md section.
7. **Release** — CHANGELOG, version bump to 0.12.0.

This order ensures every step has working tests at the end. CLI consolidation (step 4) cannot start until step 3 lands the daemon endpoints. Architecture test (step 5) must be added after step 4 so it passes from the moment it's introduced.

## Project Documentation Impact

- `STRUCTURE.md` — runtime paths section; `~/.dsm/sessions/` added; the outdated "CLI falls back to reading registry JSON files from disk" line corrected (it's been false since v0.10.0).
- `CLAUDE.md` — new "Architectural Invariants" section near the top.
- `dsm.invariants.yaml` — `STATE-01` added.
- `session.model.yaml`, `container-entry.model.yaml`, `daemon-protocol.workflow.yaml`, `cli.contract.yaml` — schema and protocol updates. Spec phase will detail these.
