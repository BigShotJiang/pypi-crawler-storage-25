# Specification: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Sprint:** eliminate_second_store

## Summary

Defines the wire contracts for the 9 new daemon commands, the schemas for the three dataclasses (extended `ContainerEntry`, new `SessionEntry`, new `AliasEntry`), and the exact rules the architecture test enforces. No implementation — just the interfaces.

## Dependencies

**From prior phases:**
- `requirements.md` — what must be true.
- `research.md` — patterns to follow, AST node types.
- `architecture.md` — module organization, scaffolding order.

**To plan phase:** these contracts; no further design open.

## Wire Protocol

The existing NDJSON-over-Unix-socket protocol is unchanged. New commands ride the same envelope:

```json
Request:  {"cmd": "<name>", ...params}
Response: {"result": <data>}                     // success
          {"error": "<message>"}                 // failure
```

## Schemas

### `ContainerEntry` (extended)

```
container_name: str           # existing
container_id: str             # existing
container_ip: str             # existing
status: str                   # existing — "running" | "stopped" | "missing" | "unknown"
created_at: str               # existing — ISO 8601
updated_at: str               # existing — ISO 8601
ports: list[PortInfo]         # existing
forwards: list[ForwardInfo]   # existing
docker_cmd: list[str]         # existing
dsm_version: str              # NEW — value of importlib.metadata.version("dtach-sessions") at create time
session_id: str | None        # NEW — id of the SessionEntry that created this container, or None
```

**Strictness:** `from_dict` raises `KeyError` if any field is missing. No silent defaults. JSON files must contain all fields.

### `SessionEntry` (new)

```
id: str                       # slug-based unique id (e.g., "claude-code-1")
type: Literal["local", "ssh", "container"]
title: str
description: str              # may be ""
command: list[str]
cwd: str                      # working directory; "" allowed
created_at: str               # ISO 8601
modified_at: str              # ISO 8601
container_name: str | None    # back-ref to ContainerEntry; None for local/ssh
extra: dict                   # type-specific fields:
                              #   container: image, branch, repo_path, ports, volumes, env
                              #   ssh: host, ssh_args
                              #   local: (typically empty)
```

**Strictness:** `from_dict` raises on missing fields. Type-specific data lives in `extra` to keep the top-level schema flat.

**Persistence path:** `~/.dsm/sessions/{id}.json`. Atomic write via tmp + rename.

### `AliasEntry` (new)

```
name: str          # non-empty; no whitespace
target: str        # non-empty; e.g., "user@host", "host", "10.0.0.1"
```

**Validation in `__post_init__`:**
- `name` must be non-empty and contain no whitespace.
- `target` must be non-empty.

**Persistence:** all aliases live in a single JSON dict at `~/.dsm/aliases.json`:
```json
{"prod": "user@10.0.0.1", "dev": "user@dev.local"}
```
Atomic write of the whole file via tmp + rename. Daemon is the only writer.

## Daemon Commands

Each request and response shown below is the JSON payload (without the `cmd` and `result`/`error` envelope).

### Sessions

| Command | Request fields | Response | Errors |
|---------|----------------|----------|--------|
| `create_session` | `entry` (full SessionEntry dict, with `id` left blank for daemon to assign, OR caller-supplied) | `{"id": "<session-id>"}` | `ValueError` on schema violation; `RuntimeError` on id collision |
| `get_session` | `id` (full id or unique prefix) | SessionEntry dict, or `null` | `RuntimeError` on ambiguous prefix (multiple matches) |
| `list_sessions` | — | `[SessionEntry, ...]` | — |
| `update_session` | `id`, `fields` (dict of mutable fields: `title`, `description`, `cwd`, `command`, `extra`) | updated SessionEntry dict | `KeyError` on unknown id; `ValueError` on bad field |
| `remove_session` | `id` | `null` | `KeyError` on unknown id |
| `next_session_number` | — | `{"number": N}` (int — max of existing `session-N` titles + 1, or 1 if none) | — |

### Aliases

| Command | Request fields | Response | Errors |
|---------|----------------|----------|--------|
| `alias_set` | `name`, `target` | `null` | `ValueError` on empty/whitespace name or empty target |
| `alias_list` | — | `{name: target, ...}` (dict) | — |
| `alias_remove` | `name` | `null` | `KeyError` on unknown name |

### `create_container` — extension

Existing command gains optional `session_id` field:

```
Request:
  container_name: str       # existing
  docker_cmd: list[str]     # existing
  session_id: str | None    # NEW — optional; daemon stores in ContainerEntry
```

Daemon-side: the daemon reads `importlib.metadata.version("dtach-sessions")` once at module load and stores it on every new ContainerEntry as `dsm_version`. The CLI does not send the version.

Response: `ContainerEntry` dict (now includes `dsm_version` and `session_id`).

## Architecture Test

### Test signature
```python
def test_cli_does_not_touch_state_files(): ...
def test_planted_violation_is_caught(): ...
```

Both live in `tests/test_architecture.py`.

### Subject
The first test parses **only** `src/dsm/cli.py`. Other modules (`daemon.py`, `registry.py`, `ports.py`) legitimately own state IO; they are exempt.

### Violation rule

A node in the parsed AST is a **violation** if:

1. It constructs a `Path` rooted at `DSM_DIR` (i.e., contains `ast.Name(id="DSM_DIR")` as part of a `BinOp(op=Div())` chain) and **none** of the constant string segments in the chain are in the allowlist.

2. It calls `open(...)` whose first argument resolves to a path constructed under `DSM_DIR` (same allowlist rule).

3. It calls a Path method that reads or mutates state — `iterdir`, `glob`, `read_text`, `write_text`, `mkdir`, `unlink`, `rename`, `touch` — on a Path constructed under `DSM_DIR` (same allowlist rule).

`exists()` is **not** a violation. Reading whether a path exists is a probe, not state IO.

### Allowlist (literal-string match)

```python
ALLOWED_FINAL_SEGMENTS = {"config.json", "dsm.sock"}
```

A path construction is allowed if any constant string segment in its chain matches an entry in this set. Examples:
- `Path(DSM_DIR / "config.json")` — allowed.
- `DSM_DIR / "dsm.sock"` — allowed.
- `DSM_DIR / "registry"` — flagged.
- `DSM_DIR / sid / "meta.json"` — flagged.

### Failure message

On violation, the test fails with a multi-line message, one violation per line:
```
src/dsm/cli.py:N: <unparsed AST snippet>
src/dsm/cli.py:M: <unparsed AST snippet>
...
```

Generated via `ast.unparse(node)` so the failure message names actual code, not a node type.

### Sanity test (`test_planted_violation_is_caught`)

Parses an inline string fixture:
```python
PLANTED = '''
from pathlib import Path
DSM_DIR = Path.home() / ".dsm"
def violator():
    return list(DSM_DIR.iterdir())
'''
```
Asserts the walker (factored into a helper function) finds at least one violation. Proves the test catches what it claims and would not silently pass if the real test were broken.

## CLI Refactor Contract

After this sprint, every site in `src/dsm/cli.py` that previously called one of the deleted helpers (research.md §5) calls the corresponding daemon RPC instead. The behavior visible to the user is unchanged:
- `dsm ls` still lists sessions.
- `dsm rm <id>` still removes a session and its container.
- `dsm alias set/ls/rm` still works.
- `dsm doctor` still runs (and is now able to classify registry-only entries that have a linked `session_id` — though the user is wiping state, so this is moot for v0.12.0).

The CLI does NOT gain any new user-facing commands or flags. This is purely an internal architectural refactor.

## Out of Spec

- Pagination on `list_sessions` — sessions are O(small); skip until needed.
- Watch/event subscriptions for session changes — no consumer; defer.
- A `dsm sessions` subcommand for direct session inspection — covered by existing `dsm ls`; no new command.

## Acceptance per Spec

Each schema, command, and rule above maps directly to a test (see `requirements.md` AC-1 through AC-7). No spec entry exists without a corresponding acceptance test.
