# Research: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Sprint:** eliminate_second_store

## Summary

Three existing patterns in the codebase carry this sprint with no novel infrastructure: (1) `ContainerRegistry` for file-per-record persistence, (2) the daemon's class-level `_commands` dispatch dict, (3) Python's stdlib `ast` module for the architecture test. CLI consolidation is mechanical: 9 helpers, ~29 call sites, ~28 `DSM_DIR` references. No third-party dependencies needed.

## Findings

### 1. `ContainerRegistry` is the persistence template

`src/dsm/registry.py:116-213` already implements exactly the shape `SessionRegistry` needs:
- In-memory `dict[str, T]` of records keyed by id.
- `load()` slurps `*.json` from a directory at startup.
- `register()`, `get()`, `list()`, `update()`, `remove()`.
- `persist(name)` writes atomically: temp file + `os.rename` to final path.
- `persist_all()` for shutdown.

`SessionRegistry` is a near-copy of this class with a different record type (`SessionEntry`) and a different directory (`~/.dsm/sessions/`). No structural deviation.

### 2. Daemon command dispatch is a class-level dict

`src/dsm/daemon.py:454` reads `handler = self._commands.get(cmd)`. The dispatch table at `daemon.py:790-808` maps command names to handler methods. Each handler has the signature `async def _cmd_X(self, request: dict, writer: asyncio.StreamWriter) -> Any`.

Adding a new command is two lines: define `async def _cmd_create_session(...)`, add `"create_session": _cmd_create_session` to `_commands`. No protocol changes, no client-side changes beyond using `client.send("create_session", ...)`.

### 3. NDJSON serialization is dict-based, not class-based

The wire protocol passes plain dicts. `from_dict` / `to_dict` on dataclasses do the conversion at the boundaries. `SessionEntry` follows the same pattern — implement `to_dict` / `from_dict` and the protocol just works.

### 4. Python `ast` module — what the architecture test inspects

The test parses `src/dsm/cli.py` with `ast.parse(...)` and walks the tree with `ast.walk(...)`. The node types that matter:

- **`ast.Name(id="DSM_DIR")`** — every reference to the global. Each one is a candidate for inspection.
- **`ast.BinOp(op=ast.Div())`** — the `/` operator on `Path` objects, used in constructions like `DSM_DIR / "registry"`. The right-hand side is the next path segment.
- **`ast.Constant(value="...")`** — the string segments. The architecture test reads these to apply the allowlist.
- **`ast.Call(func=ast.Name(id="open"))`** — direct file opens. Inspect the first argument's structure.
- **`ast.Attribute(attr="iterdir"|"exists"|"glob"|"read_text"|"write_text"|"mkdir"|"unlink")`** — Path methods that read or mutate filesystem state.

The walker collects offending node positions (line, col) and asserts the list is empty. Failure message names file:line for each violation.

### 5. CLI consolidation surface — concrete inventory

**Helpers in `cli.py` to delete (10):**

| Function | Line | Replacement |
|----------|------|-------------|
| `load_meta` | 234 | `client.send("get_session", id=...)` |
| `save_meta` | 242 | `client.send("create_session" \| "update_session", ...)` |
| `find_session_or_none` | 248 | `client.send("get_session", id=...)` (returns None on miss) |
| `find_session` | 270 | `get_session` + raise on None at call site |
| `next_session_number` | 287 | `client.send("next_session_number")` |
| `load_aliases` | 314 | `client.send("alias_list")` |
| `save_aliases` | 322 | per-mutation `alias_set` / `alias_remove` |
| `resolve_alias` | 328 | `alias_list` + dict lookup at call site |
| `_find_container_names` | 1762 | `list_sessions` + filter by type+container_alive |
| `_find_meta_by_container_name` | 2063 | new daemon endpoint OR `list_sessions` + filter |

**Call sites of these helpers in `cli.py`:** 29 (grep count). Mechanical edits — the helpers go away, call sites become `client` calls. The daemon-client connection pattern already exists (`_daemon_client_required`); every call site already has access to it or can acquire it.

**`DSM_DIR` references in `cli.py`:** 28. After the consolidation, the only legitimate uses are:
- Constants (`DAEMON_SOCKET = DSM_DIR / "dsm.sock"`)
- `CONFIG_FILE = DSM_DIR / "config.json"` reads in `load_config`
- `ensure_daemon_running` (mkdir for socket parent — daemon-spawn helper)

Everything else gets deleted as part of removing the helpers above.

### 6. Daemon command additions — final list

| Command | Handler | Returns |
|---------|---------|---------|
| `create_session` | `_cmd_create_session` | session id |
| `get_session` | `_cmd_get_session` | `SessionEntry.to_dict()` or `None` |
| `list_sessions` | `_cmd_list_sessions` | `list[SessionEntry.to_dict()]` |
| `update_session` | `_cmd_update_session` | updated `SessionEntry.to_dict()` |
| `remove_session` | `_cmd_remove_session` | `None` |
| `next_session_number` | `_cmd_next_session_number` | int |
| `alias_set` | `_cmd_alias_set` | `None` |
| `alias_list` | `_cmd_alias_list` | `dict[str, str]` |
| `alias_remove` | `_cmd_alias_remove` | `None` |

`_cmd_create_container` gains: read optional `session_id` from request payload; capture `dsm_version = importlib.metadata.version("dtach-sessions")`; pass both to `registry.register(...)`. The registry's `register` signature gains two parameters with sensible defaults so existing callers don't break.

### 7. Aliases — daemon-side storage

A single dict on `DsmDaemon` (`self._aliases: dict[str, str]`), persisted to `~/.dsm/aliases.json` by the daemon only. Atomic write on every mutation (write to `.tmp`, rename). Loaded once at startup. The alias file path is part of the daemon's responsibility, not the CLI's.

### 8. Architecture test allowlist — exact expression

Two literal strings: `"config.json"` and `"dsm.sock"`. The test walks `Path` constructions rooted at `DSM_DIR` and inspects every constant string segment in the chain. If any segment matches the allowlist, the construction is allowed. Otherwise it's flagged. (Q4 decision.)

This is one allowlist, applied to one module (`src/dsm/cli.py`). The test doesn't run on `daemon.py`, `registry.py`, or `ports.py` — those modules legitimately own state IO. The scope of the test is *the CLI does not touch state*, not *no module touches state*.

## Open Questions

None. All requirements-phase open questions resolved during the requirements review (see `requirements.md` decisions section). Architecture phase can proceed.

## What Architecture Phase Needs

- Confirm: `SessionRegistry` lives in `registry.py` alongside `ContainerRegistry`, or in a new `sessions.py`? Slight preference for `registry.py` (one persistence module, mirroring pattern).
- Confirm: the architecture test goes in a new file `tests/test_architecture.py`, distinct from the existing test modules. Yes — separates "code correctness" tests from "code structure" tests.
- Confirm: aliases module-level state on `DsmDaemon` vs a dedicated `AliasRegistry`. For something this small (single dict), a dedicated registry is over-engineering — `self._aliases` on the daemon is fine.

These are minor structural choices the architecture doc will pin down.
