# Pass 1 Structure: Eliminate Second Persistent Store

**Sprint:** eliminate_second_store
**Created:** 2026-05-07
**Source documents reviewed:** kickoff.md, requirements.md, research.md, architecture.md, spec.md

## Overview

6 phases, 30 high-level tasks. The architecture doc proposed 7 scaffolding steps; this Pass 1 collapses scaffolding steps 1 and 2 (registry foundations + ContainerEntry schema extension) into a single "Registry Foundations" phase since both are pure `registry.py` schema work that can be done in one mechanical pass with one strict-from_dict test sweep. The other steps map 1:1 to phases.

The critical-path chain is Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 6. Phase 5 (governance / invariants / memory / CLAUDE.md) has no code dependencies and can run in parallel with Phase 4 once the wire contracts in Phase 3 are stable.

## Phase Structure

### Phase 1: Registry Foundations

**Goal:** Land all dataclass and registry-class additions in `registry.py` so the daemon has the persistence primitives it needs.
**Dependencies:** none
**Estimate:** medium (2 new dataclasses, 2 new registries, 1 schema extension; mirrors `ContainerRegistry` pattern; well-scoped to one file)
**Parallelism within phase:** `SessionEntry`/`SessionRegistry`, `AliasEntry`/`AliasRegistry`, and the `ContainerEntry` extension are independent — three parallel work streams within the same module.

Tasks:
- Add `dsm_version` and `session_id` fields to `ContainerEntry` (strict `from_dict`, updated `to_dict`) (type: implement)
- Update `ContainerRegistry.register()` signature to accept `dsm_version` and `session_id` (type: refactor)
- Add `SessionEntry` dataclass with strict `from_dict` / `to_dict` (type: implement)
- Add `SessionRegistry` class mirroring `ContainerRegistry` (atomic write, file-per-record at `~/.dsm/sessions/`) (type: implement)
- Add `AliasEntry` dataclass with `__post_init__` validation (non-empty name/no-whitespace, non-empty target) (type: implement)
- Add `AliasRegistry` class with single-file persistence (`~/.dsm/aliases.json`) and atomic write (type: implement)
- Update existing `ContainerEntry` tests to pass new required fields (strict schema may break existing fixtures) (type: test)
- Add unit tests for `SessionEntry`, `SessionRegistry`, `AliasEntry`, `AliasRegistry` CRUD + atomic-write semantics (type: test)

---

### Phase 2: Daemon Command Surface

**Goal:** Wire the new registries into `DsmDaemon` and expose 9 new NDJSON commands plus the `create_container` extension.
**Dependencies:** Phase 1
**Estimate:** medium (9 thin handlers around CRUD + 1 dispatch-table wiring + 1 existing-handler extension; pattern is uniform)
**Parallelism within phase:** the 6 session commands and the 3 alias commands are independent dispatch entries — can be implemented in two parallel batches. The `create_container` extension is a small standalone change.

Tasks:
- Wire `SessionRegistry` and `AliasRegistry` into `DsmDaemon.__init__` and `start()` lifecycle (type: implement)
- Cache `importlib.metadata.version("dtach-sessions")` at module load on `daemon.py` (type: implement)
- Implement session command handlers: `_cmd_create_session`, `_cmd_get_session` (with prefix/ambiguity rules), `_cmd_list_sessions`, `_cmd_update_session`, `_cmd_remove_session`, `_cmd_next_session_number` (type: implement)
- Implement alias command handlers: `_cmd_alias_set`, `_cmd_alias_list`, `_cmd_alias_remove` (type: implement)
- Extend `_cmd_create_container` to accept optional `session_id` and stamp `dsm_version` (type: implement)
- Register all 9 new handlers in `_commands` dispatch dict (type: implement)
- Add round-trip integration tests for each new command via the existing daemon test harness (type: test)
- Add error-path tests: ambiguous prefix, unknown id, schema violations, alias validation (type: test)

---

### Phase 3: CLI Consolidation

**Goal:** Delete 10 CLI helpers and convert 29 call sites to daemon RPCs so `cli.py` no longer touches `~/.dsm/` state.
**Dependencies:** Phase 2 (daemon endpoints must exist before CLI can call them)
**Estimate:** large (mechanical but high-volume: ~29 call sites across many CLI commands; risk of subtle behavior shifts in `cmd_list`, `cmd_clean`, `cmd_rm`, `cmd_alias`, `cmd_doctor`, `ensure_container`)
**Parallelism within phase:** call-site conversions are independent per CLI subcommand (`cmd_list`, `cmd_resume`, `cmd_rm`, `cmd_alias`, `cmd_clean`, `cmd_doctor`, `ensure_container`) — six parallel batches. Helper deletions must come last.

Tasks:
- Convert session-helper call sites: `load_meta` / `save_meta` / `find_session` / `find_session_or_none` / `next_session_number` (type: refactor)
- Convert container-name lookup helpers: `_find_container_names`, `_find_meta_by_container_name` (type: refactor)
- Convert alias-helper call sites: `load_aliases` / `save_aliases` / `resolve_alias` (type: refactor)
- Update `ensure_container` and container-creation flow to send `session_id` to daemon (type: refactor)
- Hold daemon-client connections open across multi-op CLI commands (matches existing `cmd_list` / `cmd_clean` pattern) (type: refactor)
- Delete the 10 deprecated CLI helpers and their `DSM_DIR` references (type: refactor)
- Verify all 206 existing CLI tests still pass; update fixtures that constructed `meta.json` directly (type: test)
- Add CLI integration tests for end-to-end flows that exercised the deleted helpers (`dsm rm`, `dsm alias set/ls/rm`, `dsm doctor`, `dsm ls`) (type: test)

---

### Phase 4: Architecture Test

**Goal:** Add the AST-based mechanical enforcement test that prevents reintroduction of CLI-side state IO.
**Dependencies:** Phase 3 (test must pass on first commit; cannot be added until `cli.py` is clean)
**Estimate:** small-medium (one new test file; AST walker logic is mechanical but has subtleties around `BinOp` chain walking and allowlist matching)
**Parallelism within phase:** the production walker and the planted-violation sanity test can be developed in parallel.

Tasks:
- Create `tests/test_architecture.py` with helper predicates for AST violation detection (type: implement)
- Implement `test_cli_does_not_touch_state_files` — walks `src/dsm/cli.py`, applies allowlist (`config.json`, `dsm.sock`), reports file:line on violation (type: implement)
- Implement `test_planted_violation_is_caught` — inline-string fixture proves the walker catches what it claims (type: test)
- Verify both tests pass under the current pytest configuration (no new test runners needed) (type: test)

---

### Phase 5: Invariant, Memory, and CLAUDE.md Updates

**Goal:** Capture the principle in the four places that make it a planning input for future work — invariants spec, auto-memory, top-of-CLAUDE.md, and STRUCTURE.md.
**Dependencies:** Phase 4 (the invariant's `enforced_by` references the test path; safer to land after the test exists)
**Estimate:** small (pure prose / YAML edits; no code)
**Parallelism within phase:** all four documents can be edited in parallel — they share no content.

Tasks:
- Add `STATE-01` entry to `.organon/specs/dsm.invariants.yaml` with `enforced_by` pointing at `tests/test_architecture.py::test_cli_does_not_touch_state_files` (type: document)
- Create auto-memory file `feedback_single_persistent_store.md` (rule, history of drift, how to apply) and index it in `MEMORY.md` (type: document)
- Add "Architectural Invariants" section near the top of `CLAUDE.md` referencing `dsm.invariants.yaml` (type: document)
- Update `.organon/STRUCTURE.md` runtime-paths section: add `~/.dsm/sessions/`, correct the outdated "CLI falls back to reading registry JSON files from disk" line (type: document)

---

### Phase 6: Release v0.12.0

**Goal:** Document the manual-wipe upgrade path, bump the version, and ship.
**Dependencies:** Phases 1, 2, 3, 4, 5 (everything must be in before release)
**Estimate:** small (mechanical; uses existing `/release` skill flow)
**Parallelism within phase:** sequential by nature — CHANGELOG entry, then version bump, then tag.

Tasks:
- Write `CHANGELOG.md` entry under v0.12.0: lists schema changes, daemon command additions, CLI consolidation, architecture test, and the manual `rm -rf ~/.dsm/` upgrade procedure (type: document)
- Bump version in `pyproject.toml` and any other version-pinned locations (type: implement)
- Run full test suite end-to-end as a final gate (type: test)
- Run `/release-check` then `/release` to tag v0.12.0 (type: review)

## Phase Dependency Graph

```
Phase 1 (Registry Foundations)
   │
   ▼
Phase 2 (Daemon Command Surface)
   │
   ▼
Phase 3 (CLI Consolidation)
   │
   ▼
Phase 4 (Architecture Test)
   │
   ▼
Phase 5 (Invariant + Memory + CLAUDE.md)
   │
   ▼
Phase 6 (Release v0.12.0)
```

Phase 5 could technically begin once Phase 4's test path is fixed (the invariant only references the test file path, not its implementation), allowing limited Phase-4/Phase-5 overlap. Treat as strictly sequential in Pass 2 unless the user wants the optimization.

## Requirement → Phase Coverage Check

| Requirement | Phase(s) |
|------------|---------|
| FR-1 Daemon owns session state | 1, 2 |
| FR-2 Daemon owns alias state | 1, 2 |
| FR-3 ContainerEntry schema additions | 1, 2 |
| FR-4 Clean install / strict from_dict | 1, 6 (CHANGELOG) |
| FR-5 CLI consolidation | 3 |
| FR-6 Mechanical enforcement | 4, 5 (STATE-01) |
| FR-7 Visibility for future planning | 5 |
| NFR-1 Clean upgrade documented | 6 |
| NFR-3 Test suite green | 1, 2, 3, 4, 6 |
| NFR-4 Performance | 2 (single round-trip handlers) |
| AC-1 No `open(`/`iterdir()`/`Path(` under DSM_DIR in cli.py | 3, 4 |
| AC-2 Architecture test passes; planted violation caught | 4 |
| AC-3 Doctor classifies new container correctly | 3 |
| AC-4 Each ContainerEntry has dsm_version and session_id | 1, 2, 3 |
| AC-5 STATE-01, memory entry, CLAUDE.md section present | 5 |
| AC-6 New tests cover SessionRegistry, daemon round-trips, architecture sanity | 1, 2, 4 |
| AC-7 CHANGELOG documents upgrade procedure | 6 |

Every requirement and acceptance criterion maps to at least one phase. No spec entry is orphaned.

## Scope Concerns and Suggestions for Pass 2

1. **Phase 3 is the largest and riskiest phase.** 29 call sites in a single CLI module touching multiple commands (`cmd_list`, `cmd_rm`, `cmd_clean`, `cmd_alias`, `cmd_doctor`, `ensure_container`). Pass 2 should split this phase's tasks by CLI subcommand rather than by helper, so each task is a self-contained "convert `cmd_X` to use the daemon" unit with its own integration test. This makes parallel execution safer and isolates regression blast radius.

2. **Strict-`from_dict` ripple risk.** Making `ContainerEntry.from_dict` raise on missing fields will break every existing test fixture and golden snapshot that constructs a `ContainerEntry` dict literal without `dsm_version` / `session_id`. Pass 2 should explicitly inventory those fixtures (likely 5–15 sites in `tests/test_registry.py`, `tests/test_daemon.py`, `tests/test_integration_daemon.py`) and treat the fixture migration as its own task, not a side-effect of the dataclass change.

3. **`get_session` ambiguous-prefix semantics.** The spec says "RuntimeError on ambiguous prefix" but today's CLI behavior (`find_session`) uses `cli.py`-side error formatting. Pass 2 should pin which side renders the user-facing message (daemon raises structured error → CLI formats), so error UX stays identical post-refactor.

4. **`_cmd_create_container` change is a wire-protocol change.** The new optional `session_id` parameter is backward-compatible on the wire, but tests that mock the request payload will need updating. Tag this in Pass 2 so it isn't lost in the larger Phase 2 task list.

5. **Auto-memory file location.** The architecture doc places it under `~/.claude/projects/.../memory/`, which is outside the repo. Pass 2 should make explicit that this task creates a file outside the working tree and is not git-tracked — different verification rules apply.

6. **Phase 5 / Phase 4 overlap.** As noted in the dependency-graph section, the `STATE-01` entry only needs the test's path string, not its passing state. Pass 2 could parallelize these two phases at small cost. Recommendation: keep sequential for clarity; the savings are minutes.

7. **No phase exceeds the 10–12 task soft limit.** Phase 1 (8 tasks) and Phase 3 (8 tasks) are the largest. If Pass 2's split-by-subcommand recommendation is accepted, Phase 3 may swell to ~10 tasks — still inside the limit.

## Missing or Weak Source Material

None. All five sprint planning documents are present, internally coherent, and the architecture/spec docs explicitly hand off a scaffolding order with no further design open questions. Pass 2 can proceed without additional input.
