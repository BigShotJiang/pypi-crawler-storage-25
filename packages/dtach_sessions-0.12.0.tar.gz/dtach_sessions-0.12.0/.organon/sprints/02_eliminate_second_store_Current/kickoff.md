# Kickoff: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Sprint:** eliminate_second_store
**Status:** Created

## Context

Triggered by a `dsm doctor` run on the user's actual machine showing 9/9 containers as `unknown` — registry-only entries with no session metadata to classify against. The conversation that followed traced architectural drift back through Sprint 01 (daemon foundation), the daemon-state-validation mini sprint (v0.10.0), and the doctor-command mini sprint (v0.11.0).

An inventory of prior conversations confirmed the user has stated the principle "the daemon is the single process that owns all persistent state" on at least five distinct dates (Apr 12, Apr 15, Apr 16, May 6, May 7). Despite this, the principle has never reached a sprint plan, an invariants document, an auto-memory entry, or an enforcement test. Each prior sprint scoped narrowly enough that the second persistent store survived — Sprint 01 explicitly preserved it ("Backward compatible: Existing ~/.dsm/ session metadata unchanged"); v0.10.0 narrowed "single source of truth" to *registry* state only; v0.11.0 hard-coded a CLI walk of session dirs into the doctor command.

This sprint puts the principle in all four places (spec, memory, top-of-CLAUDE.md, mechanical test) and operationalizes it by eliminating the CLI-owned persistent stores.

## What Was Discussed

1. **The architectural mandate, stated cleanly.** The daemon provides a single process for read/write consistency over a single persistent store. The CLI is a thin client; it does not maintain its own persistent state. The CLI does not open files under `~/.dsm/` for reading or writing state. Two narrow exclusions: `config.json` (user input) and ephemeral runtime artifacts inside session directories (dtach socket, output.log, generated `CLAUDE.md`).

2. **The two stores today.** `~/.dsm/registry/{name}.json` is daemon-owned and correct. `~/.dsm/{sid}/meta.json` and `~/.dsm/aliases.json` are CLI-owned and are violations of the mandate.

3. **Schema gaps in `ContainerEntry`.** The registry does not record the `dsm` version that created an entry or the session id that owns it. Both are needed for the registry to be self-describing across upgrades and to support `dsm doctor` and the future `dsm prune`.

4. **Why this kept happening.** Prior sprints addressed adjacent symptoms (registry orphans, `dsm rm` lookup failures, removal-safety classification) without naming "eliminate the second store" as a goal. The principle was stated in conversation but never reached a planning input — no sprint template loads transcripts, the invariants spec doesn't currently contain it, and the auto-memory has only two entries (neither captures this rule). Each plan I wrote applied a "smallest correct change to fix the symptom" heuristic that produced narrow, correct, second-store-preserving plans.

5. **Enforcement is the missing piece.** Prose in `CLAUDE.md` and dev-docs does not survive contact with implementation work. The principle must live in (a) `dsm.invariants.yaml` as `STATE-01`, (b) auto-memory so it loads at every conversation start, (c) a top-of-`CLAUDE.md` pointer, and (d) a mechanical pytest that fails when `cli.py` opens any non-allowlisted path under `~/.dsm/`. The mechanical test is the load-bearing piece.

## Decisions Made

**Sprint goal (single sentence):** Eliminate `~/.dsm/{sid}/meta.json` and `~/.dsm/aliases.json` as CLI-owned persistent state, move both into the daemon, and add an enforcement test that prevents reintroduction.

**Schema:**
- `ContainerEntry` gains `dsm_version: str` (captured at create-time via `importlib.metadata.version("dtach-sessions")`) and `session_id: str | None` (set when a CLI session creates the container).
- New `SessionEntry` dataclass capturing what currently lives in `meta.json`. `SessionRegistry` mirrors `ContainerRegistry` — file-per-record JSON at `~/.dsm/sessions/{id}.json`, atomic write-and-rename.
- Aliases live as a single daemon-managed dict, persisted to `~/.dsm/aliases.json` *but read and written exclusively by the daemon*.

**Daemon protocol:**
- Adds session CRUD: `create_session`, `get_session` (with prefix matching), `list_sessions`, `update_session`, `remove_session`, `next_session_number`.
- Adds alias CRUD: `alias_set`, `alias_list`, `alias_remove`.
- `create_container` accepts optional `session_id` and stores `dsm_version` automatically.

**Migration:**
- **None in code.** v0.12.0 ships clean. Manual one-time procedure (documented in CHANGELOG):
  ```bash
  dsm daemon stop
  docker rm -f $(docker ps -aq --filter "name=dsm_")    # remove zombie containers
  cp ~/.dsm/config.json /tmp/dsm-config-backup.json     # preserve config profiles
  rm -rf ~/.dsm/
  mkdir -p ~/.dsm
  mv /tmp/dsm-config-backup.json ~/.dsm/config.json
  # install v0.12.0
  dsm ls                                                # lazy-restarts daemon
  ```
- Host-side worktree directories at `{repo}-worktrees/{branch}/` are git-managed and **not touched** — may contain uncommitted work; user decides whether to clean those separately.
- No migration logic in the daemon, no backward-compat code paths.
- The `from_dict` constructors are strict — missing fields raise rather than silently defaulting. Loud failure preferred over silent inconsistency.

**Enforcement (built in this sprint):**
- `STATE-01` added to `.organon/specs/dsm.invariants.yaml` with `enforced_by` pointing at the new test.
- `tests/test_architecture.py::test_cli_does_not_touch_state_files` — AST-walks `src/dsm/cli.py` and fails on any path-construction or file IO under `~/.dsm/` outside the allowlist (`config.json`, `dsm.sock`).
- `CLAUDE.md` gains an "Architectural Invariants" section at the top pointing to `dsm.invariants.yaml`.
- Auto-memory gets a feedback entry: rule, *why* (history of drift across multiple sprints), *how to apply*.

**Out of scope:**
- ui_coder API extraction (backlog #002).
- Port-forwarding agent visibility (backlog #003).
- Test-teardown daemon leaks (backlog #004).

## Decisions Locked During Requirements Review

- **Q1 — Architecture-test scanner:** AST-based (Python `ast` module). A skill (`/check-state-isolation` or similar) is added separately as a deeper-review tool, but the AST test is the mechanical floor.
- **Q2 — Session storage layout:** file-per-record at `~/.dsm/sessions/{id}.json`, mirroring `ContainerRegistry`'s atomic-write pattern.
- **Q3 — Migration ordering:** dissolved. No migration code; manual `rm -rf ~/.dsm/` is the upgrade path.
- **Q4 — Architecture-test allowlist form:** literal-string match on path segments (`"config.json"`, `"dsm.sock"`).
- **Schema strictness:** `from_dict` is strict — missing fields raise.

## Source Material

A draft mini-sprint at `.organon/mini-sprints/eliminate-second-store.md` was written during the conversation before we agreed this needed full sprint treatment. Its body informs the requirements / research / architecture / spec passes that follow this kickoff. The draft will be removed once those passes have absorbed its content (decision pending — see open question below).

The conversation that produced this sprint, including the prior-conversations inventory, lives in `~/.claude/projects/-home-pjsulin-repos-dev-dsm/63e8c209-d9f2-4598-b66d-562b2475f747.jsonl`.

## Next Steps (per sprint-planning work mode)

1. **Requirements** — `requirements.md` capturing stakeholder needs, success criteria, acceptance tests for each invariant.
2. **Research** — `research.md` reviewing existing patterns in the codebase (registry persistence, daemon protocol, atomic writes); decisions on session storage layout and migration ordering.
3. **Architecture** — `architecture.md` defining new modules (`SessionRegistry`, daemon command surface) and integration with existing daemon lifecycle.
4. **Specification** — `spec.md` defining contracts for the new daemon commands, the new dataclass schemas, and the architecture test's allowlist semantics.
5. **Plan** — three passes via `/plan-sprint` (structure → detail → review).

## Open Question for User

The mini-sprint draft at `.organon/mini-sprints/eliminate-second-store.md` overlaps content-wise with what will become requirements/architecture/spec. Two options:
- **Delete the draft** once kickoff is reviewed — clean separation, no duplicate source-of-truth.
- **Keep the draft** as scratch reference, archive after sprint completes.

Default action when not specified: delete after the requirements pass absorbs its content.
