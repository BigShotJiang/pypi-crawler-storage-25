# Implementation Plan: Eliminate Second Persistent Store

**Created:** 2026-05-07
**Started:** [Date when sprint execution begins - determines sprint number]
**Sprint:** eliminate_second_store (number assigned when started)

## Overview

Make the daemon the single owner of every persistent state read and write in `dsm`. Eliminate `~/.dsm/{sid}/meta.json` and `~/.dsm/aliases.json` as CLI-owned stores by introducing `SessionRegistry` and `AliasRegistry` in the daemon, extending `ContainerEntry` with `dsm_version` and `session_id`, deleting 10 CLI helpers and converting their ~29 call sites to daemon RPCs, and adding an AST-based architecture test that mechanically blocks reintroduction. The principle is also captured in the invariants spec, an auto-memory entry, the top of `CLAUDE.md`, and `STRUCTURE.md`. Ships as v0.12.0 with a documented manual `rm -rf ~/.dsm/` upgrade path.

Six sequential phases, 35 tasks total.

## Workflow

This sprint follows the workflow-task model:
- Planning Level: Research → Design → Spec → Plan (this document)
- Development Level: Implement → Test → Review → Document

Phases are strictly sequential — each phase ends with passing tests before the next begins. Within a phase, tasks may run in parallel where dependencies permit; parallel-eligible tasks are flagged in their dependency lists. Each task is one commit boundary.

## Tasks

### Phase 1: Registry Foundations

**Status:** pending
**Dependencies:** none
**Estimate:** medium — schema work confined to `registry.py` and a fixture migration sweep

Goal: Land all dataclass and registry-class additions in `registry.py` so the daemon has the persistence primitives it needs. New `SessionEntry`/`SessionRegistry` and `AliasEntry`/`AliasRegistry`, plus the `ContainerEntry` schema extension. Existing test fixtures that construct `ContainerEntry` instances or dicts are migrated to satisfy the new strict schema.

#### Task 1.1: Add `dsm_version` and `session_id` fields to `ContainerEntry`

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§ContainerEntry (extended)](spec.md#containerentry-extended), [architecture.md§registry.py — modifications and additions](architecture.md#registrypy--modifications-and-additions)
- **Description:** Add `dsm_version: str` and `session_id: str | None` to the `ContainerEntry` dataclass with no defaults. Update `to_dict` to emit both fields and `from_dict` to read them strictly (raise `KeyError` on missing fields). **Atomic group:** Tasks 1.1, 1.2, and 1.7 must land together — strict `from_dict` will break every existing test fixture until 1.7 migrates them. Test suite is allowed to be red on a 1.1-only or 1.1+1.2-only intermediate state; it must pass after 1.7.
- **Commit:**

#### Task 1.2: Update `ContainerRegistry.register()` signature for new fields

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [1.1]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§ContainerEntry (extended)](spec.md#containerentry-extended), [research.md§Daemon command additions — final list](research.md#6-daemon-command-additions--final-list)
- **Description:** Extend `ContainerRegistry.register()` to accept `dsm_version` and `session_id` parameters and stamp them on the new `ContainerEntry`. Strict — no silent defaults.
- **Commit:**

#### Task 1.3: Add `SessionEntry` dataclass

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§SessionEntry (new)](spec.md#sessionentry-new), [architecture.md§registry.py — modifications and additions](architecture.md#registrypy--modifications-and-additions)
- **Description:** Add the `SessionEntry` dataclass with the schema fields (`id`, `type`, `title`, `description`, `command`, `cwd`, `created_at`, `modified_at`, `container_name`, `extra`). Implement strict `from_dict` (raises on missing fields) and `to_dict`.
- **Commit:**

#### Task 1.4: Add `SessionRegistry` class

- **Type:** implement
- **Status:** pending
- **Dependencies:** [1.3]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [architecture.md§registry.py — modifications and additions](architecture.md#registrypy--modifications-and-additions), [research.md§ContainerRegistry is the persistence template](research.md#1-containerregistry-is-the-persistence-template)
- **Description:** Add `SessionRegistry` mirroring `ContainerRegistry`: `__init__(registry_dir)`, `load`, `get` (with prefix-lookup semantics, raises `RuntimeError` on ambiguous prefix, returns `None` on no match), `list`, `register`, `update` (raises `KeyError` on unknown id), `remove` (raises `KeyError` on unknown id), `persist`, `persist_all`. File-per-record JSON at `~/.dsm/sessions/{id}.json` with atomic `tmp` + `os.rename` writes. The `RuntimeError` raised on ambiguous prefix is what the daemon handler in Task 2.3 catches, reformats into a structured JSON-parseable payload, and re-raises so the CLI can render the user-facing message.
- **Commit:**

#### Task 1.5: Add `AliasEntry` dataclass

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§AliasEntry (new)](spec.md#aliasentry-new), [architecture.md§registry.py — modifications and additions](architecture.md#registrypy--modifications-and-additions)
- **Description:** Add the `AliasEntry` dataclass with `name` and `target` fields. Implement `__post_init__` validation: name must be non-empty and contain no whitespace; target must be non-empty. Implement `to_dict` and `from_dict`.
- **Commit:**

#### Task 1.6: Add `AliasRegistry` class

- **Type:** implement
- **Status:** pending
- **Dependencies:** [1.5]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [architecture.md§registry.py — modifications and additions](architecture.md#registrypy--modifications-and-additions), [research.md§Aliases — daemon-side storage](research.md#7-aliases--daemon-side-storage)
- **Description:** Add `AliasRegistry` with single-file persistence at `~/.dsm/aliases.json`: `__init__(file_path)`, `load`, `get`, `list`, `set`, `remove`, `persist` (atomic `.tmp` + rename of the whole file). **Wire-boundary projection:** `list()` returns the underlying `dict[str, str]` form (name → target) directly so it can be used as the `alias_list` daemon response without further conversion. Internal storage may still use `AliasEntry` instances for validation.
- **Commit:**

#### Task 1.7: Migrate existing `ContainerEntry` test fixtures

- **Type:** test
- **Status:** pending
- **Dependencies:** [1.1, 1.2]
- **Files:**
  - Modify: tests/test_registry.py
  - Modify: tests/test_state_validation.py
  - Modify: tests/test_cli_daemon.py
  - Modify: tests/test_daemon.py
  - Modify: tests/test_integration_daemon.py
- **Context:** [requirements.md§FR-4: Clean install (no migration)](requirements.md#fr-4-clean-install-no-migration), [_pass1_structure.md§Scope Concerns](_pass1_structure.md#scope-concerns-and-suggestions-for-pass-2)
- **Description:** Inventory every `ContainerEntry(...)` constructor call and every dict literal passed to `ContainerEntry.from_dict(...)` across the 5 listed test modules and add `dsm_version` and `session_id` fields. Strict `from_dict` would otherwise reject these fixtures. Confirmed sites include test_registry.py:172, test_state_validation.py:298/306, test_cli_daemon.py:77/154, test_integration_daemon.py:75 — sweep each file and adjust every match.
- **Commit:**

#### Task 1.8: Unit tests for new registries and dataclasses

- **Type:** test
- **Status:** pending
- **Dependencies:** [1.3, 1.4, 1.5, 1.6]
- **Files:**
  - Modify: tests/test_registry.py
- **Context:** [requirements.md§AC-6](requirements.md#acceptance-criteria), [spec.md§Schemas](spec.md#schemas)
- **Description:** Add unit tests for `SessionEntry` (strict `from_dict`, round-trip), `SessionRegistry` (load, register, get-by-id, get-by-prefix, ambiguous-prefix raises, update, remove, atomic-write semantics), `AliasEntry` (validation rejects empty/whitespace name and empty target), and `AliasRegistry` (CRUD + atomic single-file persist).
- **Commit:**

---

### Phase 2: Daemon Command Surface

**Status:** pending
**Dependencies:** [Phase 1]
**Estimate:** medium — 9 thin handlers around CRUD + dispatch wiring + 1 existing-handler extension

Goal: Wire the new registries into `DsmDaemon` and expose 9 new NDJSON commands plus the `create_container` extension. Within this phase the session handlers (2.3), alias handlers (2.4), and `_cmd_create_container` extension (2.5) are independent and may run in parallel after 2.1/2.2.

#### Task 2.1: Wire `SessionRegistry` and `AliasRegistry` into `DsmDaemon`

- **Type:** implement
- **Status:** pending
- **Dependencies:** [Phase 1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [architecture.md§daemon.py — modifications](architecture.md#daemonpy--modifications)
- **Description:** Add `self.sessions = SessionRegistry(sessions_dir)` and `self.aliases = AliasRegistry(aliases_path)` to `DsmDaemon.__init__`. Call `self.sessions.load()` and `self.aliases.load()` from `start()` alongside `self.registry.load()`.
- **Commit:**

#### Task 2.2: Cache `dsm_version` at module load in `daemon.py`

- **Type:** implement
- **Status:** pending
- **Dependencies:** [Phase 1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [research.md§Daemon command additions — final list](research.md#6-daemon-command-additions--final-list), [spec.md§create_container — extension](spec.md#create_container--extension)
- **Description:** Add a module-level `DSM_VERSION = importlib.metadata.version("dtach-sessions")` cached once at load. Used by `_cmd_create_container` to stamp every new `ContainerEntry`.
- **Commit:**

#### Task 2.3: Implement session command handlers

- **Type:** implement
- **Status:** pending
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Sessions](spec.md#sessions), [architecture.md§daemon.py — modifications](architecture.md#daemonpy--modifications)
- **Description:** Implement the six session handlers: `_cmd_create_session`, `_cmd_get_session`, `_cmd_list_sessions`, `_cmd_update_session`, `_cmd_remove_session`, `_cmd_next_session_number`. **Ambiguous-prefix contract for `_cmd_get_session`:** raise a structured `RuntimeError` whose message is JSON-parseable, with marker `"ambiguous_prefix"` and a `matches: [list of ids]` payload, so the CLI can catch and reformat. The CLI will render the user-visible message identically to today's `find_session` output: `"Error: ambiguous id '{prefix}', matches: {comma-separated list}"`.
- **Commit:**

#### Task 2.4: Implement alias command handlers

- **Type:** implement
- **Status:** pending
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Aliases](spec.md#aliases), [architecture.md§daemon.py — modifications](architecture.md#daemonpy--modifications)
- **Description:** Implement the three alias handlers: `_cmd_alias_set` (validates via `AliasEntry.__post_init__`), `_cmd_alias_list`, `_cmd_alias_remove`. Each mutation persists the single JSON file atomically.
- **Commit:**

#### Task 2.5: Extend `_cmd_create_container` with `session_id` and `dsm_version`

- **Type:** implement
- **Status:** pending
- **Dependencies:** [2.2]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§create_container — extension](spec.md#create_container--extension)
- **Description:** Read optional `session_id` from the request payload and pass both it and the cached `DSM_VERSION` into `registry.register(...)`. Wire-protocol change: the request payload gains optional `session_id`. Existing tests in `test_cli_daemon.py` and `test_daemon.py` that mock or assert on the `create_container` request payload will need to be updated in task 2.7.
- **Commit:**

#### Task 2.6: Register new handlers in `_commands` dispatch table

- **Type:** implement
- **Status:** pending
- **Dependencies:** [2.3, 2.4]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [research.md§Daemon command dispatch is a class-level dict](research.md#2-daemon-command-dispatch-is-a-class-level-dict)
- **Description:** Add the 9 new commands to the `_commands` dispatch dict: `create_session`, `get_session`, `list_sessions`, `update_session`, `remove_session`, `next_session_number`, `alias_set`, `alias_list`, `alias_remove`.
- **Commit:**

#### Task 2.7: Update existing `create_container` request fixtures in tests

- **Type:** test
- **Status:** pending
- **Dependencies:** [2.5]
- **Files:**
  - Modify: tests/test_cli_daemon.py
  - Modify: tests/test_daemon.py
- **Context:** [_pass1_structure.md§Scope Concerns](_pass1_structure.md#scope-concerns-and-suggestions-for-pass-2), [spec.md§create_container — extension](spec.md#create_container--extension)
- **Description:** Update every test that mocks or constructs the `create_container` daemon request to include the new optional `session_id` field where appropriate, and assert on the new `dsm_version` field in returned `ContainerEntry` dicts.
- **Commit:**

#### Task 2.8: Round-trip integration tests for new commands

- **Type:** test
- **Status:** pending
- **Dependencies:** [2.6]
- **Files:**
  - Modify: tests/test_integration_daemon.py
- **Context:** [requirements.md§AC-6](requirements.md#acceptance-criteria), [spec.md§Daemon Commands](spec.md#daemon-commands)
- **Description:** Exercise each of the 9 new commands end-to-end through the live daemon test harness: create → get → list → update → remove for sessions; set → list → remove for aliases; `next_session_number`. Verify happy-path responses match the spec.
- **Commit:**

#### Task 2.9: Error-path tests for new commands

- **Type:** test
- **Status:** pending
- **Dependencies:** [2.6]
- **Files:**
  - Modify: tests/test_integration_daemon.py
- **Context:** [spec.md§Daemon Commands](spec.md#daemon-commands)
- **Description:** Cover the documented error paths: ambiguous-prefix `get_session` produces the structured `RuntimeError` payload; unknown id on `update`/`remove` raises `KeyError`; alias validation rejects empty/whitespace names and empty targets; schema-violating `create_session` raises `ValueError`.
- **Commit:**

---

### Phase 3: CLI Consolidation

**Status:** pending
**Dependencies:** [Phase 2]
**Estimate:** large — mechanical but high-volume; split per CLI subcommand to isolate regression blast radius

Goal: Delete 10 CLI helpers and convert all call sites to daemon RPCs so `cli.py` no longer touches `~/.dsm/` state outside the allowlist (`config.json`, `dsm.sock`). Each CLI subcommand is its own task with clear file boundaries; the helper deletion task runs last after every call site has been migrated. Subcommand-conversion tasks (3.1 through 3.7) may run in parallel.

#### Task 3.1: Convert `cmd_list` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory), [architecture.md§cli.py — modifications](architecture.md#clipy--modifications)
- **Description:** Replace every `load_meta` / `find_session*` / `DSM_DIR.iterdir()` call inside `cmd_list` (cli.py:1452) with `client.send("list_sessions")` and downstream filtering. Hold the daemon-client connection open across the multi-op listing.
- **Commit:**

#### Task 3.2: Convert `cmd_resume` and `cmd_tail` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory)
- **Description:** Replace `find_session` / `load_meta` calls inside `cmd_resume` (cli.py:1554) and `cmd_tail` (cli.py:1621) with `client.send("get_session", id=...)`. Catch the structured ambiguous-prefix `RuntimeError` (per Task 2.3 contract) and reformat the message identically to today's CLI output. Match the existing daemon-client connection-lifetime pattern (`_daemon_client_required` then `try/finally: client.close()` — see `cmd_list` for reference); single-op commands close immediately after the call returns.
- **Commit:**

#### Task 3.3: Convert `cmd_rm` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory)
- **Description:** Replace `find_session` / `load_meta` / `save_meta` calls inside `cmd_rm` (cli.py:1703) with `get_session` + `remove_session` daemon RPCs. Hold the connection open for the multi-op flow (lookup → remove session → remove container).
- **Commit:**

#### Task 3.4: Convert `cmd_clean` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory)
- **Description:** Replace `DSM_DIR.iterdir()` / `load_meta` walking inside `cmd_clean` (cli.py:1671) with `list_sessions` + per-id liveness check + `remove_session` daemon RPCs. Hold the connection open.
- **Commit:**

#### Task 3.5: Convert `cmd_alias` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory), [spec.md§Aliases](spec.md#aliases)
- **Description:** Replace `load_aliases` / `save_aliases` / `resolve_alias` calls inside `cmd_alias` (cli.py:1645) and the `cmd_ssh` `resolve_alias` call site with `alias_set` / `alias_list` / `alias_remove` daemon RPCs. The `resolve_alias` helper becomes an `alias_list` lookup at call sites. Match the existing daemon-client connection-lifetime pattern; multi-step `cmd_alias` invocations (e.g., `dsm alias ls` after `dsm alias set`) reuse a single connection only within one CLI invocation — across CLI invocations each command opens its own connection.
- **Commit:**

#### Task 3.6: Convert `cmd_doctor` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory), [requirements.md§AC-3](requirements.md#acceptance-criteria)
- **Description:** Remove the hard-coded CLI walk of session dirs in `cmd_doctor` (cli.py:2078) introduced by the v0.11.0 mini sprint. Replace with `list_sessions` + the registry data already returned by the existing daemon endpoints. Keep doctor's classification logic intact; only the data-source changes. **Executor risk note:** `cmd_doctor` was added late (v0.11.0 mini sprint) and may have implicit assumptions about the `meta.json` walk shape (e.g., session-dir presence as liveness signal). After mechanical conversion, verify `dsm doctor` against a live daemon with sessions of all three types (local, ssh, container) and a registry-only orphan; tune classification fields only if the new data source produces a regression. Tag any tweak with a clear commit message so it's not lost in the larger refactor.
- **Commit:**

#### Task 3.7: Convert `ensure_container` and `cmd_container` to daemon RPCs

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [Phase 2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory), [spec.md§create_container — extension](spec.md#create_container--extension)
- **Description:** Update `ensure_container` (cli.py:832) and `cmd_container` (cli.py:1330) call sites: replace `_find_container_names` / `_find_meta_by_container_name` / `next_session_number` / `save_meta` calls with the corresponding daemon RPCs (`list_sessions`, `next_session_number`, `create_session`). Pass the new session id into `create_container`'s `session_id` parameter so the daemon stamps it on the `ContainerEntry`. Match the existing daemon-client connection-lifetime pattern: `ensure_container` and `cmd_container` are multi-op flows (next_session_number → create_session → create_container), so hold a single connection open across all three calls and close in a `try/finally` block, matching `cmd_list` / `cmd_clean`.
- **Commit:**

#### Task 3.8: Delete the 10 deprecated CLI helpers

- **Type:** refactor
- **Status:** pending
- **Dependencies:** [3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [requirements.md§FR-5: CLI consolidation](requirements.md#fr-5-cli-consolidation), [research.md§CLI consolidation surface — concrete inventory](research.md#5-cli-consolidation-surface--concrete-inventory)
- **Description:** Delete `load_meta`, `save_meta`, `find_session`, `find_session_or_none`, `next_session_number`, `load_aliases`, `save_aliases`, `resolve_alias`, `_find_container_names`, `_find_meta_by_container_name`. Remove every now-unused `DSM_DIR / "..."` construction. The only legitimate `DSM_DIR` references that remain are `DAEMON_SOCKET = DSM_DIR / "dsm.sock"`, `CONFIG_FILE = DSM_DIR / "config.json"`, and the `mkdir` for the socket parent in `ensure_daemon_running`.
- **Commit:**

#### Task 3.9: Update CLI tests for migrated call sites

- **Type:** test
- **Status:** pending
- **Dependencies:** [3.8]
- **Files:**
  - Modify: tests/test_cli_daemon.py
  - Modify: tests/test_doctor.py
- **Context:** [requirements.md§NFR-3: Test suite green](requirements.md#nfr-3-test-suite-green)
- **Description:** Update fixtures in CLI tests that previously constructed `meta.json` files directly under `tmp_path` to instead populate the daemon's `SessionRegistry` via daemon RPCs. Verify all 206 existing CLI tests continue to pass.
- **Commit:**

#### Task 3.10: Add CLI integration tests for end-to-end consolidated flows

- **Type:** test
- **Status:** pending
- **Dependencies:** [3.8]
- **Files:**
  - Modify: tests/test_cli_daemon.py
- **Context:** [requirements.md§AC-3](requirements.md#acceptance-criteria), [requirements.md§AC-6](requirements.md#acceptance-criteria)
- **Description:** Add end-to-end tests for the consolidated flows: `dsm rm <id>`, `dsm alias set/ls/rm`, `dsm doctor`, `dsm ls` — exercising the full CLI → daemon → registry round-trip. These cover the surfaces that previously relied on the deleted helpers. **AC-3 coverage:** include an end-to-end test that creates a session via `create_session`, registers a corresponding `ContainerEntry` via `create_container` with the linked `session_id`, and asserts `dsm doctor` classifies the container with a non-`unknown` status — verifying the new architecture closes the gap that motivated this sprint.
- **Commit:**

---

### Phase 4: Architecture Test

**Status:** pending
**Dependencies:** [Phase 3]
**Estimate:** small-medium — one new test file; AST walker logic is mechanical but has subtleties around `BinOp` chain walking and allowlist matching

Goal: Add the AST-based mechanical enforcement test that prevents reintroduction of CLI-side state IO. Cannot be added until Phase 3 is complete because the test must pass on its first commit. The walker helpers (4.1) and the planted-violation sanity test (4.3) are independent and may run in parallel.

#### Task 4.1: Create `tests/test_architecture.py` skeleton with helper predicates

- **Type:** implement
- **Status:** pending
- **Dependencies:** [Phase 3]
- **Files:**
  - Create: tests/test_architecture.py
- **Context:** [spec.md§Architecture Test](spec.md#architecture-test), [research.md§Python ast module — what the architecture test inspects](research.md#4-python-ast-module--what-the-architecture-test-inspects)
- **Description:** Create the test module with helper functions: `_walk_path_construction(node)` for walking `BinOp(op=Div())` chains rooted at `DSM_DIR`, `_collect_constant_segments(node)` for collecting string segments, and `_is_violation(node, allowlist)` for applying the allowlist match. Define `ALLOWED_FINAL_SEGMENTS = {"config.json", "dsm.sock"}`.
- **Commit:**

#### Task 4.2: Implement `test_cli_does_not_touch_state_files`

- **Type:** implement
- **Status:** pending
- **Dependencies:** [4.1]
- **Files:**
  - Modify: tests/test_architecture.py
- **Context:** [spec.md§Architecture Test](spec.md#architecture-test), [requirements.md§FR-6: Mechanical enforcement](requirements.md#fr-6-mechanical-enforcement)
- **Description:** Implement the production test: parse `src/dsm/cli.py`, walk all AST nodes, flag (a) `Path` constructions rooted at `DSM_DIR` outside the allowlist, (b) `open(...)` calls whose first argument is such a path, and (c) state-mutating Path methods (`iterdir`, `glob`, `read_text`, `write_text`, `mkdir`, `unlink`, `rename`, `touch`). `exists()` is allowed. Failure message lists `src/dsm/cli.py:N: <ast.unparse(node)>` per violation.
- **Commit:**

#### Task 4.3: Implement `test_planted_violation_is_caught`

- **Type:** test
- **Status:** pending
- **Dependencies:** [4.1]
- **Files:**
  - Modify: tests/test_architecture.py
- **Context:** [spec.md§Sanity test (test_planted_violation_is_caught)](spec.md#sanity-test-test_planted_violation_is_caught)
- **Description:** Add the sanity test that parses an inline string fixture containing a deliberate violation (`DSM_DIR.iterdir()`) and asserts the helper walker catches it. Proves the test catches what it claims and would not silently pass if the walker were broken.
- **Commit:**

#### Task 4.4: Verify both architecture tests pass under the existing pytest config

- **Type:** test
- **Status:** pending
- **Dependencies:** [4.2, 4.3]
- **Files:**
  - Modify: tests/test_architecture.py
- **Context:** [requirements.md§AC-2](requirements.md#acceptance-criteria), [requirements.md§NFR-3](requirements.md#nfr-3-test-suite-green)
- **Description:** Run the full pytest suite. Confirm `test_cli_does_not_touch_state_files` passes against the post-Phase-3 `cli.py` and `test_planted_violation_is_caught` passes. Tighten predicates if any false positive surfaces; resolve via allowlist refinement only if the case is genuinely outside scope (do NOT widen allowlist to mask a real violation).
- **Commit:**

---

### Phase 5: Invariant, Memory, and CLAUDE.md Updates

**Status:** pending
**Dependencies:** [Phase 4]
**Estimate:** small — pure prose / YAML edits; no code

Goal: Capture the principle in the four places that make it a planning input for future work — invariants spec, auto-memory, top-of-CLAUDE.md, and STRUCTURE.md. All four tasks are independent and may run in parallel.

#### Task 5.1: Add `STATE-01` to `dsm.invariants.yaml`

- **Type:** document
- **Status:** pending
- **Dependencies:** [Phase 4]
- **Files:**
  - Modify: .organon/specs/dsm.invariants.yaml
- **Context:** [requirements.md§FR-6](requirements.md#fr-6-mechanical-enforcement), [requirements.md§AC-5](requirements.md#acceptance-criteria)
- **Description:** Add a `STATE-01` invariant entry naming the rule "the daemon is the single process that owns all persistent state; the CLI does not open files under `~/.dsm/` outside the allowlist (`config.json`, `dsm.sock`)" with `enforced_by` pointing at `tests/test_architecture.py::test_cli_does_not_touch_state_files`.
- **Commit:**

#### Task 5.2: Create auto-memory feedback file (out-of-tree)

- **Type:** document
- **Status:** pending
- **Dependencies:** [Phase 4]
- **Files:**
  - Create: ~/.claude/projects/-home-pjsulin-repos-dev-dsm/memory/feedback_single_persistent_store.md
  - Modify: ~/.claude/projects/-home-pjsulin-repos-dev-dsm/memory/MEMORY.md
- **Context:** [requirements.md§FR-7](requirements.md#fr-7-visibility-for-future-planning), [architecture.md§Module Organization](architecture.md#module-organization)
- **Description:** Create the feedback file capturing the rule, the *why* (history of drift across Sprint 01, v0.10.0 daemon-state-validation, v0.11.0 doctor-command — the principle was stated by the user on 5+ distinct dates but never reached a planning input), and the *how to apply* (treat any new CLI-side `~/.dsm/` IO as a planning red flag; route through the daemon). Add the index entry to `MEMORY.md`. **Out-of-tree:** these files live under `~/.claude/projects/...` and are NOT in the repo. They will not appear in `git diff`. Verification is by file existence + content correctness, not by `pytest` or `git`.
- **Commit:**

#### Task 5.3: Add "Architectural Invariants" section to CLAUDE.md

- **Type:** document
- **Status:** pending
- **Dependencies:** [Phase 4]
- **Files:**
  - Modify: CLAUDE.md
- **Context:** [requirements.md§FR-7](requirements.md#fr-7-visibility-for-future-planning), [requirements.md§CLAUDE.md Sections Affected](requirements.md#claudemd-sections-affected)
- **Description:** Add an "Architectural Invariants" section near the top of `CLAUDE.md` (above "Architecture") naming the rule and pointing to `.organon/specs/dsm.invariants.yaml` as the authoritative source.
- **Commit:**

#### Task 5.4: Update `.organon/STRUCTURE.md` runtime-paths section

- **Type:** document
- **Status:** pending
- **Dependencies:** [Phase 4]
- **Files:**
  - Modify: .organon/STRUCTURE.md
- **Context:** [requirements.md§Other Project Docs](requirements.md#other-project-docs), [architecture.md§Runtime paths after sprint](architecture.md#module-organization)
- **Description:** Add `~/.dsm/sessions/` (daemon-owned, file-per-record) to the runtime-paths section. Correct the outdated "CLI falls back to reading registry JSON files from disk" line (false since v0.10.0). Mark `~/.dsm/{sid}/meta.json` as removed in v0.12.0.
- **Commit:**

---

### Phase 6: Release v0.12.0

**Status:** pending
**Dependencies:** [Phase 5]
**Estimate:** small — mechanical; uses existing `/release` skill flow

Goal: Document the manual-wipe upgrade path, bump the version, and ship. Sequential by nature: CHANGELOG entry, version bump, full-suite gate, then tag.

#### Task 6.1: Write CHANGELOG entry for v0.12.0

- **Type:** document
- **Status:** pending
- **Dependencies:** [Phase 5]
- **Files:**
  - Modify: CHANGELOG.md
- **Context:** [requirements.md§AC-7](requirements.md#acceptance-criteria), [requirements.md§NFR-1: Clean upgrade](requirements.md#nfr-1-clean-upgrade)
- **Description:** Add a v0.12.0 entry summarizing the schema additions (`ContainerEntry.dsm_version`, `ContainerEntry.session_id`), the new daemon commands, the CLI consolidation, and the architecture test. Document the upgrade procedure: stop daemon (`dsm daemon stop`), wipe state (`rm -rf ~/.dsm/`), install v0.12.0, restart.
- **Commit:**

#### Task 6.2: Bump version to 0.12.0

- **Type:** implement
- **Status:** pending
- **Dependencies:** [6.1]
- **Files:**
  - Modify: pyproject.toml
- **Context:** [requirements.md§AC-7](requirements.md#acceptance-criteria)
- **Description:** Bump the package version in `pyproject.toml` from 0.11.x to 0.12.0. Confirm `importlib.metadata.version("dtach-sessions")` returns the new value (used by the daemon to stamp `dsm_version` on new entries).
- **Commit:**

#### Task 6.3: Run the full test suite as a final gate

- **Type:** test
- **Status:** pending
- **Dependencies:** [6.2]
- **Files:**
  - Modify: (none — verification only)
- **Context:** [requirements.md§NFR-3: Test suite green](requirements.md#nfr-3-test-suite-green)
- **Description:** Execute `uv run pytest` end-to-end. Every test (existing + new) must pass. Architecture test must report no violations. No commit unless all green.
- **Commit:**

#### Task 6.4: Run `/release-check` and `/release` to tag v0.12.0

- **Type:** review
- **Status:** pending
- **Dependencies:** [6.3]
- **Files:**
  - Modify: (release tooling owns the tag commit)
- **Context:** [requirements.md§AC-7](requirements.md#acceptance-criteria)
- **Description:** Invoke the `/release-check` skill to verify readiness, then `/release` to bump, tag, and push v0.12.0. CI publishes to PyPI on the version tag.
- **Commit:**

## Commit Conventions

Sprint work uses format: `feat(sprint-NN):`, `fix(sprint-NN):`, `docs(sprint-NN):`, `test(sprint-NN):`, `refactor(sprint-NN):`

Examples:
```bash
feat(sprint-NN): Add SessionRegistry and SessionEntry to registry.py
refactor(sprint-NN): Convert cmd_list to daemon RPCs
test(sprint-NN): Add round-trip integration tests for session commands
docs(sprint-NN): Add STATE-01 invariant
```

## Completion Criteria

This sprint is complete when:

- [ ] All Phase 1–6 tasks completed with commit hashes
- [ ] **AC-1:** No `open(`, `iterdir()`, or `Path(` references under `DSM_DIR` in `src/dsm/cli.py` outside the allowlist (`config.json`, `dsm.sock`)
- [ ] **AC-2:** `tests/test_architecture.py::test_cli_does_not_touch_state_files` passes; `test_planted_violation_is_caught` proves the walker fires
- [ ] **AC-3:** After a fresh `dsm container ... main` invocation, `dsm doctor` classifies the new container with a non-`unknown` status
- [ ] **AC-4:** Each `ContainerEntry` written by `dsm container ...` includes a non-empty `dsm_version` and a `session_id` matching the creating session
- [ ] **AC-5:** `STATE-01` is present in `dsm.invariants.yaml`; auto-memory `feedback_single_persistent_store.md` exists and is indexed in `MEMORY.md`; CLAUDE.md "Architectural Invariants" section is present and references the invariants spec
- [ ] **AC-6:** New tests cover `SessionRegistry`/`AliasRegistry` CRUD, daemon round-trips for all 9 new commands, and architecture-test sanity
- [ ] **AC-7:** CHANGELOG documents the upgrade procedure: stop daemon, wipe `~/.dsm/`, install v0.12.0, restart
- [ ] All 206 existing tests + new tests pass
- [ ] Sprint status updated to Completed

## Notes

**Task Format:**

- **Phase ID:** Integer (1–6)
- **Task ID:** Phase.Task format (1.1, 1.2, ..., 6.4)
- **Type:** implement | test | document | research | design | specify | plan | debug | refactor | review
- **Status:** pending | in_progress | completed | failed
- **Dependencies:** Task IDs `[1.1, 1.2]` or Phase IDs `[Phase 1]` or `none`
- **Files:** Actions on files (Create/Modify/Delete with paths)
- **Context:** Markdown links to sprint docs, e.g. `[spec.md§Section](spec.md#section)`
- **Description:** Human-readable task description (1–3 sentences)
- **Commit:** Git commit hash (populated after execution)

**Orchestration:**

- Phases are strictly sequential. Within a phase, tasks may run in parallel where their declared dependencies permit.
- Parallel-eligible tasks within Phase 1: 1.1, 1.3, 1.5 (with 1.2/1.4/1.6 following).
- Parallel-eligible tasks within Phase 2: 2.3, 2.4, 2.5 after 2.1/2.2.
- Parallel-eligible tasks within Phase 3: 3.1 through 3.7 are independent per CLI subcommand. 3.8 (helper deletion) runs last.
- Parallel-eligible tasks within Phase 4: 4.2 and 4.3 share 4.1 as a dependency but are otherwise independent.
- Parallel-eligible tasks within Phase 5: all four (5.1, 5.2, 5.3, 5.4).
- Phase 6 is strictly sequential.

**Out-of-tree task:**

- Task 5.2 creates files under `~/.claude/projects/-home-pjsulin-repos-dev-dsm/memory/`. These are not git-tracked. Verification is by file existence and content review, not by `git diff` or pytest.

**Wire-protocol changes:**

- The `create_container` daemon command gains an optional `session_id` field (Task 2.5). Backward-compatible on the wire (optional), but tests that mock the request payload must be updated (Task 2.7).
- The ambiguous-prefix contract for `get_session` (Task 2.3) is a structured `RuntimeError` with JSON-parseable payload; the CLI catches and reformats to today's user-visible message (Task 3.2).

## Pass 3 Review

**Reviewed:** 2026-05-07

Pass 3 review complete. Plan structure matches the template; all required fields present on every task. Coverage matrix below confirms every FR/NFR/AC and every spec contract maps to at least one task. Pass-2 unresolved-question items (cmd_doctor risk, daemon-client lifetime pattern, AliasRegistry.list() projection, SessionRegistry.get raise alignment) addressed via in-task description tweaks. AC-3 coverage explicitly added to Task 3.10. Atomic-group note added to Task 1.1 to flag that 1.1+1.2+1.7 must land before suite goes green again.

- [x] Structural compliance verified
- [x] File operations reviewed (no conflicts)
- [x] Test coverage reviewed (every implementation phase has matching test tasks)
- [x] Documentation reviewed (CLAUDE.md, STRUCTURE.md, invariants spec, CHANGELOG, auto-memory all covered)
- [x] Dependencies reviewed (DAG; no cycles; all referenced IDs exist)
- [x] Commit boundaries reviewed (atomic; 1.1+1.2+1.7 explicitly flagged as a fixture-migration group)
- [x] Completeness reviewed (all 7 FR + 3 NFR + 7 AC + 9 daemon commands + 3 schemas + arch test + sanity test mapped)
- [x] Scope reviewed (Phase 3 = 10 tasks, within soft limit; estimates realistic)

**Coverage matrix (FR / NFR / AC → tasks):**

| Item | Tasks |
|------|-------|
| FR-1 Daemon owns session state | 1.3, 1.4, 2.1, 2.3, 3.1–3.4, 3.7, 3.9 |
| FR-2 Daemon owns alias state | 1.5, 1.6, 2.1, 2.4, 3.5 |
| FR-3 ContainerEntry schema additions | 1.1, 1.2, 2.2, 2.5 |
| FR-4 Clean install / strict from_dict | 1.1, 1.3, 1.5, 1.7, 6.1 |
| FR-5 CLI consolidation | 3.1–3.8 |
| FR-6 Mechanical enforcement | 4.1, 4.2, 4.3, 4.4, 5.1 |
| FR-7 Visibility for future planning | 5.1, 5.2, 5.3, 5.4 |
| NFR-1 Clean upgrade documented | 6.1 |
| NFR-3 Test suite green | 1.7, 1.8, 2.7–2.9, 3.9, 3.10, 4.4, 6.3 |
| NFR-4 Performance | 2.3, 2.4 (single round-trip handlers) |
| AC-1 No DSM_DIR opens in cli.py | 3.8, verified by 4.2 |
| AC-2 Architecture test passes; planted catch | 4.2, 4.3, 4.4 |
| AC-3 Doctor classifies new container correctly | 3.6, 3.10 (explicit end-to-end test) |
| AC-4 Each ContainerEntry has dsm_version + session_id | 1.1, 2.2, 2.5, 3.7 |
| AC-5 STATE-01, memory entry, CLAUDE.md section | 5.1, 5.2, 5.3 |
| AC-6 New tests for SessionRegistry, daemon round-trips, arch sanity | 1.8, 2.8, 4.3 |
| AC-7 CHANGELOG documents upgrade | 6.1 |

**Spec contracts → tasks:**

| Spec contract | Tasks |
|---------------|-------|
| ContainerEntry (extended) schema | 1.1, 1.2 |
| SessionEntry schema | 1.3 |
| AliasEntry schema | 1.5 |
| `create_session` | 2.3, 2.6, 2.8 |
| `get_session` (incl. ambiguous prefix) | 1.4 (raise), 2.3 (structured error), 3.2 (CLI catch) |
| `list_sessions` | 2.3, 2.6, 2.8 |
| `update_session` | 2.3, 2.6, 2.8 |
| `remove_session` | 2.3, 2.6, 2.8 |
| `next_session_number` | 2.3, 2.6, 2.8 |
| `alias_set` | 2.4, 2.6, 2.8 |
| `alias_list` | 1.6 (dict projection), 2.4, 2.6 |
| `alias_remove` | 2.4, 2.6, 2.8 |
| `create_container` extension | 2.5, 2.7 |
| Architecture test rule | 4.1, 4.2 |
| Sanity test (planted violation) | 4.3 |

**Plan Status:** Ready for implementation. No blocking issues. All Pass-2 unresolved questions addressed in-plan; executor has sufficient context for each task.

---
Created: 2026-05-07
Sprint: eliminate_second_store
