"""Integration tests for daemon lifecycle and lazy-start.

Tasks 5.1 and 5.2 of the daemon sprint.  End-to-end tests that exercise
the real DsmDaemon and DsmClient together — no mocks.  Uses tmp_path for
socket and registry isolation; asyncio.run() wrappers (no pytest-asyncio).
"""

from __future__ import annotations

import asyncio
import functools
import json
import os
import threading
from pathlib import Path

import pytest

from dsm.cli import DsmClient, ensure_daemon_running
from dsm.daemon import DsmDaemon
from dsm.registry import ContainerRegistry


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _send_recv(socket_path: Path, request: dict) -> dict:
    """Connect, send a single NDJSON request, read one response, close."""
    reader, writer = await asyncio.open_unix_connection(str(socket_path))
    payload = json.dumps(request).encode() + b"\n"
    writer.write(payload)
    await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5)
    writer.close()
    await writer.wait_closed()
    return json.loads(line)


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    """Create, start, and return a daemon using tmp_path for isolation."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


async def _run_in_thread(fn, *args, **kwargs):
    """Run a blocking function in a thread so the event loop stays free."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(fn, *args, **kwargs))


# ── Task 5.1: Full daemon lifecycle ─────────────────────────────────────────


def test_full_daemon_lifecycle(tmp_path: Path):
    """End-to-end: start, register, verify, list, status, shutdown, persist, reload."""

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        # 1. Start DsmDaemon
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon.start()

        try:
            # 2. Register a container via DsmClient (in thread — it's synchronous)
            def _register():
                with DsmClient(sock) as client:
                    return client.send(
                        "register_container",
                        container="integration-web",
                        container_id="int-abc123",
                        ip="10.0.0.42",
                    )

            reg_result = await _run_in_thread(_register)
            assert reg_result["container_name"] == "integration-web"
            assert reg_result["container_id"] == "int-abc123"
            # Phase 2 schema additions.
            assert reg_result["dsm_version"], "daemon must stamp non-empty dsm_version"
            assert reg_result["session_id"] is None

            # 3. Verify registry JSON file exists on disk
            reg_file = reg_dir / "integration-web.json"
            assert reg_file.exists(), "Registry file should exist after register"

            # 4. Send list_containers, verify the container appears
            def _list():
                with DsmClient(sock) as client:
                    return client.send("list_containers")

            containers = await _run_in_thread(_list)
            assert len(containers) == 1
            assert containers[0]["container_name"] == "integration-web"

            # 5. Send status, verify container count
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert status["containers"] == 1

        finally:
            # 6. Send shutdown
            def _shutdown():
                client = DsmClient(sock)
                client.connect()
                try:
                    client.send("shutdown")
                finally:
                    client.close()

            await _run_in_thread(_shutdown)

        # Give daemon time to complete shutdown
        await asyncio.sleep(0.5)

        # 7. Verify socket removed
        assert not sock.exists(), "Socket should be removed after shutdown"

        # 8. Verify registry file persisted on disk (survives daemon stop)
        reg_file = reg_dir / "integration-web.json"
        assert reg_file.exists(), "Registry file should survive daemon shutdown"
        data = json.loads(reg_file.read_text())
        assert data["container_name"] == "integration-web"
        assert data["container_id"] == "int-abc123"
        assert data["container_ip"] == "10.0.0.42"

        # 9. Start a NEW daemon on same paths, verify it loads the persisted registry
        daemon2 = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon2.start()

        try:
            def _list_after_reload():
                with DsmClient(sock) as client:
                    return client.send("list_containers")

            containers2 = await _run_in_thread(_list_after_reload)
            assert len(containers2) == 1
            assert containers2[0]["container_name"] == "integration-web"
            assert containers2[0]["container_id"] == "int-abc123"
        finally:
            await daemon2.stop()

    asyncio.run(_run())


# ── Task 5.2: Lazy start via ensure_daemon_running ──────────────────────────


def test_ensure_daemon_running_spawns_in_thread(tmp_path: Path):
    """ensure_daemon_running starts a daemon when no socket exists.

    Instead of spawning a real subprocess (fragile in CI), we start the
    daemon in-process on a background thread and verify that
    ensure_daemon_running succeeds once the socket appears.
    """

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        # Confirm no socket exists yet
        assert not sock.exists()

        # Start daemon in a background thread (simulates the subprocess)
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        daemon_started = asyncio.Event()

        async def _run_daemon():
            await daemon.start()
            daemon_started.set()
            assert daemon._stop_event is not None
            await daemon._stop_event.wait()

        daemon_task = asyncio.create_task(_run_daemon())
        await daemon_started.wait()

        try:
            # Now ensure_daemon_running should succeed (socket exists)
            def _ensure():
                ensure_daemon_running(socket_path=sock)

            await _run_in_thread(_ensure)

            # Verify we can actually communicate
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert "pid" in status
            assert "containers" in status
        finally:
            await daemon.stop()
            daemon_task.cancel()
            try:
                await daemon_task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())


def test_ensure_daemon_running_connect_retry(tmp_path: Path):
    """ensure_daemon_running retries until the socket appears.

    Starts a daemon with a small delay to exercise the retry logic.
    """

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)

        async def _delayed_start():
            """Start the daemon after a short delay to exercise retry."""
            await asyncio.sleep(0.3)
            await daemon.start()
            assert daemon._stop_event is not None
            await daemon._stop_event.wait()

        daemon_task = asyncio.create_task(_delayed_start())

        try:
            # ensure_daemon_running will fail the first _try_daemon_connect
            # but succeed after retries once the daemon starts
            def _ensure():
                ensure_daemon_running(socket_path=sock)

            await _run_in_thread(_ensure)

            # Verify communication works
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert status["containers"] == 0
        finally:
            await daemon.stop()
            daemon_task.cancel()
            try:
                await daemon_task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())


# ── Phase 2 (sprint 02): session and alias command round-trips ───────────────


def _make_session_payload(
    sid: str,
    *,
    type: str = "local",
    title: str | None = None,
    description: str = "",
    command: list[str] | None = None,
    cwd: str = "",
    container_name: str | None = None,
    extra: dict | None = None,
) -> dict:
    """Build a SessionEntry-shaped dict for ``create_session`` requests."""
    now = "2026-05-07T00:00:00+00:00"
    return {
        "id": sid,
        "type": type,
        "title": title if title is not None else sid,
        "description": description,
        "command": command if command is not None else ["bash"],
        "cwd": cwd,
        "created_at": now,
        "modified_at": now,
        "container_name": container_name,
        "extra": extra if extra is not None else {},
    }


def test_session_command_roundtrip(tmp_path: Path):
    """Sessions: create, get-by-id, get-by-prefix, list, update, remove."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    # Create
                    payload = _make_session_payload("alpha-one", title="alpha-one")
                    create_resp = client.send("create_session", entry=payload)
                    assert create_resp == {"id": "alpha-one"}

                    # Get by full id
                    fetched = client.send("get_session", id="alpha-one")
                    assert fetched is not None
                    assert fetched["id"] == "alpha-one"
                    assert fetched["title"] == "alpha-one"
                    assert fetched["type"] == "local"

                    # Get by unique prefix
                    by_prefix = client.send("get_session", id="alpha")
                    assert by_prefix is not None
                    assert by_prefix["id"] == "alpha-one"

                    # List
                    listing = client.send("list_sessions")
                    assert isinstance(listing, list)
                    assert len(listing) == 1
                    assert listing[0]["id"] == "alpha-one"

                    # Update mutable fields
                    updated = client.send(
                        "update_session",
                        id="alpha-one",
                        fields={"title": "renamed", "cwd": "/tmp"},
                    )
                    assert updated["title"] == "renamed"
                    assert updated["cwd"] == "/tmp"
                    # modified_at must have been bumped past the original.
                    assert updated["modified_at"] != payload["modified_at"]

                    # Remove
                    rm_resp = client.send("remove_session", id="alpha-one")
                    assert rm_resp is None

                    # Confirm gone
                    after = client.send("get_session", id="alpha-one")
                    assert after is None

                    listing_after = client.send("list_sessions")
                    assert listing_after == []

            await _run_in_thread(_flow)

            # Persistence side-effect: file should be gone after remove.
            sess_file = tmp_path / "sessions" / "alpha-one.json"
            assert not sess_file.exists()
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_next_session_number(tmp_path: Path):
    """next_session_number returns 1 when empty, max+1 otherwise."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    # Empty registry -> 1
                    n0 = client.send("next_session_number")
                    assert n0 == {"number": 1}

                    # Add a "session-3" titled session — non-session-N titles
                    # must be ignored.
                    client.send(
                        "create_session",
                        entry=_make_session_payload("xyz", title="custom-name"),
                    )
                    client.send(
                        "create_session",
                        entry=_make_session_payload("sess3", title="session-3"),
                    )
                    n3 = client.send("next_session_number")
                    assert n3 == {"number": 4}

                    # Higher session-N anywhere bumps the result.
                    client.send(
                        "create_session",
                        entry=_make_session_payload("sess7", title="session-7"),
                    )
                    n7 = client.send("next_session_number")
                    assert n7 == {"number": 8}

            await _run_in_thread(_flow)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_alias_command_roundtrip(tmp_path: Path):
    """Aliases: set, list, remove via daemon RPCs."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    empty = client.send("alias_list")
                    assert empty == {}

                    assert client.send("alias_set", name="prod", target="user@10.0.0.1") is None
                    assert client.send("alias_set", name="dev", target="user@dev.local") is None

                    listing = client.send("alias_list")
                    assert listing == {"prod": "user@10.0.0.1", "dev": "user@dev.local"}

                    assert client.send("alias_remove", name="prod") is None
                    after = client.send("alias_list")
                    assert after == {"dev": "user@dev.local"}

            await _run_in_thread(_flow)

            # Single-file persistence: aliases.json should hold the surviving entry.
            alias_file = tmp_path / "aliases.json"
            assert alias_file.exists()
            data = json.loads(alias_file.read_text())
            assert data == {"dev": "user@dev.local"}
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_get_session_ambiguous_prefix_raises_structured_error(tmp_path: Path):
    """Ambiguous prefix -> error with JSON payload tagged ``ambiguous_prefix``."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    client.send(
                        "create_session", entry=_make_session_payload("alpha-one"),
                    )
                    client.send(
                        "create_session", entry=_make_session_payload("alpha-two"),
                    )
                    raised = None
                    try:
                        client.send("get_session", id="alpha")
                    except Exception as exc:
                        raised = exc
                    assert raised is not None, "ambiguous prefix must raise"
                    # DsmClient wraps the daemon's error string as
                    # "Daemon error: <message>". The marker payload is
                    # everything after that prefix.
                    msg = str(raised)
                    prefix = "Daemon error: "
                    assert msg.startswith(prefix), msg
                    payload = json.loads(msg[len(prefix):])
                    assert payload["marker"] == "ambiguous_prefix"
                    assert payload["prefix"] == "alpha"
                    assert sorted(payload["matches"]) == ["alpha-one", "alpha-two"]

            await _run_in_thread(_flow)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_session_unknown_id_errors(tmp_path: Path):
    """update_session / remove_session with unknown id raise KeyError-shaped errors."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    for cmd in ("update_session", "remove_session"):
                        raised = None
                        try:
                            if cmd == "update_session":
                                client.send(cmd, id="missing", fields={"title": "x"})
                            else:
                                client.send(cmd, id="missing")
                        except Exception as exc:
                            raised = exc
                        assert raised is not None, f"{cmd} on unknown id must raise"
                        # repr(KeyError('missing')) -> "'missing'", which is what
                        # str(exc) becomes after the daemon serialises it.
                        assert "missing" in str(raised)

            await _run_in_thread(_flow)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_alias_validation_rejects_bad_input(tmp_path: Path):
    """alias_set rejects empty / whitespace name and empty target."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    bad_inputs = [
                        {"name": "", "target": "user@host"},
                        {"name": "with space", "target": "user@host"},
                        {"name": "ok", "target": ""},
                    ]
                    for payload in bad_inputs:
                        raised = None
                        try:
                            client.send("alias_set", **payload)
                        except Exception as exc:
                            raised = exc
                        assert raised is not None, f"alias_set must reject {payload!r}"

                    # Unknown name on remove -> KeyError.
                    raised = None
                    try:
                        client.send("alias_remove", name="missing-alias")
                    except Exception as exc:
                        raised = exc
                    assert raised is not None
                    assert "missing-alias" in str(raised)

            await _run_in_thread(_flow)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_create_session_schema_violation_rejected(tmp_path: Path):
    """create_session with a payload missing required fields raises ValueError."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _flow():
                with DsmClient(daemon.socket_path) as client:
                    incomplete = {"id": "broken", "type": "local"}
                    raised = None
                    try:
                        client.send("create_session", entry=incomplete)
                    except Exception as exc:
                        raised = exc
                    assert raised is not None, "schema violation must raise"

                    # Empty id -> ValueError as well.
                    bad_id = _make_session_payload("placeholder")
                    bad_id["id"] = ""
                    raised = None
                    try:
                        client.send("create_session", entry=bad_id)
                    except Exception as exc:
                        raised = exc
                    assert raised is not None, "empty id must raise"

            await _run_in_thread(_flow)
        finally:
            await daemon.stop()

    asyncio.run(_run())
