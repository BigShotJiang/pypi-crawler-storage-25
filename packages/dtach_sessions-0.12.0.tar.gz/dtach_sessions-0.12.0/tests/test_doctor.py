"""Tests for ``dsm doctor`` classification.

Uses real git repos under ``tmp_path`` rather than mocks — git plumbing is
fast and the classifier asks small, well-defined questions of git, so a
real repo is both more accurate and simpler than mocking subprocess.
"""

from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path

import pytest

from dsm import doctor


# ── Repo fixtures ─────────────────────────────────────────────────────────


def _git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env.update({
        "GIT_AUTHOR_NAME": "test",
        "GIT_AUTHOR_EMAIL": "test@example.com",
        "GIT_COMMITTER_NAME": "test",
        "GIT_COMMITTER_EMAIL": "test@example.com",
    })
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        check=check, capture_output=True, text=True, env=env,
    )


def _make_repo_with_origin(tmp_path: Path) -> tuple[Path, Path]:
    """Create a working repo wired to a fake origin sharing ``main``.

    Returns ``(repo_path, origin_path)``.
    """
    origin = tmp_path / "origin.git"
    _git(tmp_path, "init", "--bare", "-b", "main", str(origin))

    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-b", "main")
    _git(repo, "remote", "add", "origin", str(origin))
    (repo / "README.md").write_text("hello\n")
    _git(repo, "add", ".")
    _git(repo, "commit", "-m", "initial")
    _git(repo, "push", "-u", "origin", "main")
    _git(repo, "remote", "set-head", "origin", "--auto")
    return repo, origin


def _add_branch_worktree(
    repo: Path, branch: str, *, ahead_commits: int = 0
) -> Path:
    """Create a worktree for ``branch`` based on origin/main.

    ``ahead_commits`` adds commits on the branch that aren't on origin/main —
    set to 0 for a fully merged state.
    """
    worktrees_dir = repo.parent / f"{repo.name}-worktrees"
    worktrees_dir.mkdir(exist_ok=True)
    wt = worktrees_dir / branch
    _git(repo, "worktree", "add", "-b", branch, str(wt), "origin/main")
    for i in range(ahead_commits):
        f = wt / f"f{i}.txt"
        f.write_text(f"{i}\n")
        _git(wt, "add", ".")
        _git(wt, "commit", "-m", f"commit {i}")
    return wt


def _meta(container_name: str, repo: Path, branch: str) -> dict:
    return {
        "id": "test",
        "type": "container",
        "title": "test",
        "container": {
            "name": container_name,
            "repo_path": str(repo),
            "branch": branch,
        },
    }


# ── Status enum ───────────────────────────────────────────────────────────


def test_clean_merged(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    _add_branch_worktree(repo, "feat-merged", ahead_commits=0)
    report = doctor.classify_container(
        "dsm_repo", _meta("dsm_repo", repo, "feat-merged")
    )
    assert report.status == "clean+merged"
    assert report.unmerged_commits == 0
    assert report.dirty_files == 0
    assert report.untracked_files == 0


def test_clean_unmerged(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    _add_branch_worktree(repo, "feat-ahead", ahead_commits=2)
    report = doctor.classify_container(
        "dsm_repo", _meta("dsm_repo", repo, "feat-ahead")
    )
    assert report.status == "clean+unmerged"
    assert report.unmerged_commits == 2


def test_dirty(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    wt = _add_branch_worktree(repo, "feat-dirty")
    (wt / "README.md").write_text("modified content\n")
    report = doctor.classify_container(
        "dsm_repo", _meta("dsm_repo", repo, "feat-dirty")
    )
    assert report.status == "dirty"
    assert report.dirty_files >= 1


def test_untracked(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    wt = _add_branch_worktree(repo, "feat-untracked")
    (wt / "scratch.tmp").write_text("local notes\n")
    report = doctor.classify_container(
        "dsm_repo", _meta("dsm_repo", repo, "feat-untracked")
    )
    assert report.status == "untracked"
    assert report.untracked_files >= 1
    assert report.dirty_files == 0


def test_orphan(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    wt = _add_branch_worktree(repo, "feat-orphan")
    # Force-delete the branch ref while leaving the worktree directory in place.
    # `git worktree remove` would clean the dir; we want the orphan signature.
    _git(repo, "worktree", "remove", "--force", str(wt))
    wt.mkdir()
    (wt / "leftover.txt").write_text("stale\n")
    _git(repo, "branch", "-D", "feat-orphan")
    report = doctor.classify_container(
        "dsm_repo", _meta("dsm_repo", repo, "feat-orphan")
    )
    assert report.status == "orphan"


def test_unknown_no_meta():
    report = doctor.classify_container("dsm_orphan", None)
    assert report.status == "unknown"
    assert report.branch is None


def test_unknown_missing_repo_path(tmp_path: Path):
    meta = {
        "container": {
            "name": "dsm_x",
            "repo_path": str(tmp_path / "does-not-exist"),
            "branch": "main",
        }
    }
    report = doctor.classify_container("dsm_x", meta)
    assert report.status == "unknown"


# ── Default-branch detection ──────────────────────────────────────────────


def test_default_via_origin_head(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    ref, warning = doctor.detect_default_branch(repo)
    assert ref == "origin/main"
    assert warning is None


def test_default_origin_main_fallback(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    # Remove origin/HEAD symbolic ref to force the fallback chain.
    _git(repo, "symbolic-ref", "--delete", "refs/remotes/origin/HEAD")
    ref, warning = doctor.detect_default_branch(repo)
    assert ref == "origin/main"
    assert warning is not None
    assert "origin/HEAD" in warning


def test_default_origin_master_fallback(tmp_path: Path):
    origin = tmp_path / "origin.git"
    _git(tmp_path, "init", "--bare", "-b", "master", str(origin))
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-b", "master")
    _git(repo, "remote", "add", "origin", str(origin))
    (repo / "f").write_text("x")
    _git(repo, "add", ".")
    _git(repo, "commit", "-m", "init")
    _git(repo, "push", "-u", "origin", "master")
    # Don't set origin/HEAD — but make sure origin/main isn't there either.
    ref, warning = doctor.detect_default_branch(repo)
    assert ref == "origin/master"
    assert warning is not None


def test_default_literal_fallback(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-b", "main")
    (repo / "f").write_text("x")
    _git(repo, "add", ".")
    _git(repo, "commit", "-m", "init")
    # No origin remote at all.
    ref, warning = doctor.detect_default_branch(repo)
    assert ref == "main"
    assert warning is not None
    assert "origin/main" in warning or "origin/HEAD" in warning


# ── Staleness probe ───────────────────────────────────────────────────────


def test_staleness_local_behind(tmp_path: Path):
    repo, origin = _make_repo_with_origin(tmp_path)

    # Push another commit to origin via a separate clone, then fetch — local
    # main now lags origin/main by one commit.
    other = tmp_path / "other"
    _git(tmp_path, "clone", str(origin), str(other))
    (other / "next.txt").write_text("next\n")
    _git(other, "add", ".")
    _git(other, "commit", "-m", "next")
    _git(other, "push")
    _git(repo, "fetch", "origin")

    info = doctor.staleness_probe(repo, "origin/main")
    assert info["local_behind"] == 1
    assert info["fetch_head_age_seconds"] is not None


def test_staleness_fetch_head_age(tmp_path: Path):
    repo, _ = _make_repo_with_origin(tmp_path)
    _git(repo, "fetch", "origin")
    fetch_head = repo / ".git" / "FETCH_HEAD"
    assert fetch_head.exists()
    # Backdate FETCH_HEAD beyond the staleness threshold.
    old = time.time() - (doctor.FETCH_HEAD_STALE_SECONDS + 60)
    os.utime(fetch_head, (old, old))
    info = doctor.staleness_probe(repo, "origin/main")
    assert info["fetch_head_age_seconds"] > doctor.FETCH_HEAD_STALE_SECONDS


# ── Sort order sanity ─────────────────────────────────────────────────────


def test_status_order_priority():
    # Most-actionable first: orphan, unknown, then clean+merged, etc.
    ordered = sorted(
        ["dirty", "clean+merged", "orphan", "untracked", "unknown", "clean+unmerged"],
        key=lambda s: doctor.STATUS_ORDER[s],
    )
    assert ordered == [
        "orphan", "unknown", "clean+merged", "clean+unmerged", "untracked", "dirty"
    ]
