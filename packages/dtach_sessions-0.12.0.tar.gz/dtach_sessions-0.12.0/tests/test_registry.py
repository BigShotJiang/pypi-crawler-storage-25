"""Tests for container registry CRUD and persistence (dsm.registry module)."""

import json
from pathlib import Path

import pytest

from dsm.registry import (
    AliasEntry,
    AliasRegistry,
    ContainerEntry,
    ContainerRegistry,
    ForwardInfo,
    PortInfo,
    SessionEntry,
    SessionRegistry,
)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_registry(tmp_path: Path) -> ContainerRegistry:
    """Create a registry backed by a temp directory."""
    reg = ContainerRegistry(tmp_path / "registry")
    reg.load()
    return reg


def _register_sample(reg: ContainerRegistry, name: str = "web") -> ContainerEntry:
    """Register a sample container and return the entry."""
    return reg.register(
        name, f"sha256:{name}", f"172.17.0.{hash(name) % 250 + 2}",
        dsm_version="<test>", session_id=None,
    )


# ── CRUD: register / get ─────────────────────────────────────────────────────


def test_register_and_get(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)

    assert entry.container_name == "web"
    assert entry.container_id == "sha256:abc"
    assert entry.container_ip == "172.17.0.2"
    assert entry.status == "running"
    assert entry.created_at is not None
    assert entry.ports == []
    assert entry.forwards == []

    fetched = reg.get("web")
    assert fetched is entry


def test_get_missing_returns_none(tmp_path: Path):
    reg = _make_registry(tmp_path)
    assert reg.get("nonexistent") is None


# ── CRUD: list ───────────────────────────────────────────────────────────────


def test_list_returns_all(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:a", "172.17.0.2", dsm_version="<test>", session_id=None)
    reg.register("db", "sha256:b", "172.17.0.3", dsm_version="<test>", session_id=None)
    reg.register("cache", "sha256:c", "172.17.0.4", dsm_version="<test>", session_id=None)

    entries = reg.list()
    names = {e.container_name for e in entries}
    assert names == {"web", "db", "cache"}


def test_list_empty(tmp_path: Path):
    reg = _make_registry(tmp_path)
    assert reg.list() == []


# ── CRUD: update ─────────────────────────────────────────────────────────────


def test_update_fields(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    old_updated_at = entry.updated_at

    updated = reg.update("web", status="stopped", container_ip="172.17.0.99")

    assert updated.status == "stopped"
    assert updated.container_ip == "172.17.0.99"
    assert updated.updated_at >= old_updated_at
    # Original object is mutated in place
    assert reg.get("web") is updated


def test_update_nonexistent_raises(tmp_path: Path):
    reg = _make_registry(tmp_path)
    with pytest.raises(KeyError):
        reg.update("ghost", status="stopped")


def test_update_invalid_field_raises(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    with pytest.raises(AttributeError, match="no field"):
        reg.update("web", bogus_field="nope")


# ── CRUD: remove ─────────────────────────────────────────────────────────────


def test_remove(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    reg.persist("web")

    reg.remove("web")

    assert reg.get("web") is None
    assert not (tmp_path / "registry" / "web.json").exists()


def test_remove_nonexistent_is_noop(tmp_path: Path):
    reg = _make_registry(tmp_path)
    # Should not raise
    reg.remove("ghost")


# ── Persistence round-trip ───────────────────────────────────────────────────


def test_persist_and_reload(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    entry.ports = [PortInfo(port=8080, bind_address="0.0.0.0", protocol="tcp")]
    entry.forwards = [ForwardInfo(container_port=8080, host_port=8080, socat_pid=12345)]
    reg.persist("web")

    # Create a completely new registry on the same directory
    reg2 = ContainerRegistry(tmp_path / "registry")
    reg2.load()

    loaded = reg2.get("web")
    assert loaded is not None
    assert loaded.container_name == "web"
    assert loaded.container_id == "sha256:abc"
    assert loaded.container_ip == "172.17.0.2"
    assert loaded.status == "running"
    assert loaded.created_at == entry.created_at
    assert loaded.updated_at == entry.updated_at
    assert len(loaded.ports) == 1
    assert loaded.ports[0].port == 8080
    assert loaded.ports[0].bind_address == "0.0.0.0"
    assert loaded.ports[0].protocol == "tcp"
    assert len(loaded.forwards) == 1
    assert loaded.forwards[0].container_port == 8080
    assert loaded.forwards[0].host_port == 8080
    assert loaded.forwards[0].socat_pid == 12345
    assert loaded.forwards[0].alive is True


def test_persist_multiple_and_reload(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:a", "172.17.0.2", dsm_version="<test>", session_id=None)
    reg.register("db", "sha256:b", "172.17.0.3", dsm_version="<test>", session_id=None)
    reg.persist_all()

    reg2 = ContainerRegistry(tmp_path / "registry")
    reg2.load()

    names = {e.container_name for e in reg2.list()}
    assert names == {"web", "db"}


# ── from_dict: missing optional fields ───────────────────────────────────────


def test_container_entry_from_dict_missing_optional_fields():
    """ports and forwards are optional in persisted JSON."""
    data = {
        "container_name": "web",
        "container_id": "sha256:abc",
        "container_ip": "172.17.0.2",
        "status": "running",
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
        "dsm_version": "<test>",
        "session_id": None,
    }
    entry = ContainerEntry.from_dict(data)
    assert entry.ports == []
    assert entry.forwards == []


def test_forward_info_from_dict_missing_alive():
    """alive defaults to True when missing from dict."""
    data = {
        "container_port": 8080,
        "host_port": 8080,
        "socat_pid": 999,
    }
    info = ForwardInfo.from_dict(data)
    assert info.alive is True


# ── Atomic write behavior ────────────────────────────────────────────────────


def test_persist_no_tmp_files_remain(tmp_path: Path):
    """After persist, no .tmp files should remain in the registry directory."""
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    reg.register("db", "sha256:def", "172.17.0.3", dsm_version="<test>", session_id=None)
    reg.persist_all()

    registry_dir = tmp_path / "registry"
    tmp_files = list(registry_dir.glob("*.tmp"))
    assert tmp_files == [], f"Leftover .tmp files: {tmp_files}"


def test_persist_writes_valid_json(tmp_path: Path):
    """The JSON file on disk should be valid JSON after persist."""
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2", dsm_version="<test>", session_id=None)
    entry.ports = [PortInfo(port=3000, bind_address="0.0.0.0", protocol="tcp")]
    reg.persist("web")

    json_path = tmp_path / "registry" / "web.json"
    assert json_path.exists()

    with open(json_path) as fh:
        data = json.load(fh)

    assert data["container_name"] == "web"
    assert data["container_id"] == "sha256:abc"
    assert len(data["ports"]) == 1
    assert data["ports"][0]["port"] == 3000


def test_persist_all_writes_all_entries(tmp_path: Path):
    """persist_all should write one JSON file per registered container."""
    reg = _make_registry(tmp_path)
    names = ["alpha", "bravo", "charlie"]
    for i, name in enumerate(names):
        reg.register(name, f"sha256:{name}", f"172.17.0.{i + 2}", dsm_version="<test>", session_id=None)

    reg.persist_all()

    registry_dir = tmp_path / "registry"
    json_files = {p.stem for p in registry_dir.glob("*.json")}
    assert json_files == set(names)


# ─── SessionEntry ────────────────────────────────────────────────────────────


def _make_session(
    id: str = "sess-1",
    *,
    type: str = "container",
    title: str = "Test Session",
    container_name: str | None = "ctr-1",
) -> SessionEntry:
    return SessionEntry(
        id=id,
        type=type,  # type: ignore[arg-type]
        title=title,
        description="",
        command=["bash"],
        cwd="/work",
        created_at="2026-05-07T00:00:00+00:00",
        modified_at="2026-05-07T00:00:00+00:00",
        container_name=container_name,
        extra={},
    )


def test_session_entry_to_dict_round_trip():
    entry = _make_session(
        id="sess-1",
        type="container",
        container_name="ctr-1",
    )
    entry.extra = {"image": "ubuntu", "branch": "main"}
    payload = entry.to_dict()

    assert payload["id"] == "sess-1"
    assert payload["type"] == "container"
    assert payload["extra"] == {"image": "ubuntu", "branch": "main"}

    restored = SessionEntry.from_dict(payload)
    assert restored == entry


def test_session_entry_from_dict_strict_missing_field_raises():
    """Missing any required field raises KeyError — no silent defaults."""
    base = {
        "id": "x",
        "type": "local",
        "title": "t",
        "description": "",
        "command": [],
        "cwd": "",
        "created_at": "now",
        "modified_at": "now",
        "container_name": None,
        "extra": {},
    }
    for missing_field in list(base.keys()):
        data = {k: v for k, v in base.items() if k != missing_field}
        with pytest.raises(KeyError):
            SessionEntry.from_dict(data)


# ─── SessionRegistry ─────────────────────────────────────────────────────────


def _make_session_registry(tmp_path: Path) -> SessionRegistry:
    reg = SessionRegistry(tmp_path / "sessions")
    reg.load()
    return reg


def test_session_registry_load_empty_dir(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    assert reg.list() == []


def test_session_registry_register_and_get_by_id(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    entry = _make_session(id="alpha-1")
    reg.register(entry)

    assert reg.get("alpha-1") is entry


def test_session_registry_get_by_unique_prefix(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    reg.register(_make_session(id="alpha-1"))
    reg.register(_make_session(id="bravo-1"))

    fetched = reg.get("alp")
    assert fetched is not None
    assert fetched.id == "alpha-1"


def test_session_registry_get_ambiguous_prefix_raises(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    reg.register(_make_session(id="alpha-1"))
    reg.register(_make_session(id="alpha-2"))

    with pytest.raises(RuntimeError, match="ambiguous"):
        reg.get("alpha")


def test_session_registry_get_unknown_returns_none(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    reg.register(_make_session(id="alpha-1"))

    assert reg.get("nosuch") is None


def test_session_registry_update_bumps_modified_at(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    entry = _make_session(id="s1")
    reg.register(entry)
    old_modified = entry.modified_at

    updated = reg.update("s1", title="Renamed")
    assert updated.title == "Renamed"
    assert updated.modified_at >= old_modified


def test_session_registry_update_unknown_id_raises(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    with pytest.raises(KeyError):
        reg.update("ghost", title="x")


def test_session_registry_remove(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    reg.register(_make_session(id="s1"))
    reg.persist("s1")

    reg.remove("s1")
    assert reg.get("s1") is None
    assert not (tmp_path / "sessions" / "s1.json").exists()


def test_session_registry_remove_unknown_raises(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    with pytest.raises(KeyError):
        reg.remove("ghost")


def test_session_registry_persist_atomic_no_tmp_files(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    reg.register(_make_session(id="s1"))
    reg.register(_make_session(id="s2"))
    reg.persist_all()

    sessions_dir = tmp_path / "sessions"
    tmp_files = list(sessions_dir.glob("*.tmp"))
    assert tmp_files == []
    json_files = {p.stem for p in sessions_dir.glob("*.json")}
    assert json_files == {"s1", "s2"}


def test_session_registry_persist_and_reload(tmp_path: Path):
    reg = _make_session_registry(tmp_path)
    entry = _make_session(id="s1", title="Original")
    entry.extra = {"image": "ubuntu"}
    reg.register(entry)
    reg.persist("s1")

    reg2 = SessionRegistry(tmp_path / "sessions")
    reg2.load()

    loaded = reg2.get("s1")
    assert loaded is not None
    assert loaded.title == "Original"
    assert loaded.extra == {"image": "ubuntu"}


# ─── AliasEntry ──────────────────────────────────────────────────────────────


def test_alias_entry_rejects_empty_name():
    with pytest.raises(ValueError, match="name"):
        AliasEntry(name="", target="user@host")


def test_alias_entry_rejects_whitespace_name():
    with pytest.raises(ValueError, match="name"):
        AliasEntry(name="prod prod", target="user@host")
    with pytest.raises(ValueError, match="name"):
        AliasEntry(name="\tprod", target="user@host")


def test_alias_entry_rejects_empty_target():
    with pytest.raises(ValueError, match="target"):
        AliasEntry(name="prod", target="")


def test_alias_entry_to_dict_round_trip():
    entry = AliasEntry(name="prod", target="user@10.0.0.1")
    payload = entry.to_dict()
    assert payload == {"name": "prod", "target": "user@10.0.0.1"}
    assert AliasEntry.from_dict(payload) == entry


# ─── AliasRegistry ───────────────────────────────────────────────────────────


def _make_alias_registry(tmp_path: Path) -> AliasRegistry:
    reg = AliasRegistry(tmp_path / "aliases.json")
    reg.load()
    return reg


def test_alias_registry_load_missing_file(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    assert reg.list() == {}
    assert reg.get("anything") is None


def test_alias_registry_set_persists_immediately(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")

    file_path = tmp_path / "aliases.json"
    assert file_path.exists()
    on_disk = json.loads(file_path.read_text())
    assert on_disk == {"prod": "user@10.0.0.1"}


def test_alias_registry_get_returns_target(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")
    assert reg.get("prod") == "user@10.0.0.1"


def test_alias_registry_list_returns_dict_projection(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")
    reg.set("dev", "user@dev.local")

    listing = reg.list()
    assert listing == {"prod": "user@10.0.0.1", "dev": "user@dev.local"}
    # Mutating the returned dict must not affect internal state.
    listing["prod"] = "tampered"
    assert reg.get("prod") == "user@10.0.0.1"


def test_alias_registry_remove(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")
    reg.set("dev", "user@dev.local")

    reg.remove("prod")
    assert reg.get("prod") is None
    assert reg.list() == {"dev": "user@dev.local"}

    # File on disk reflects the removal.
    on_disk = json.loads((tmp_path / "aliases.json").read_text())
    assert on_disk == {"dev": "user@dev.local"}


def test_alias_registry_remove_unknown_raises(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    with pytest.raises(KeyError):
        reg.remove("ghost")


def test_alias_registry_set_validates_via_alias_entry(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    with pytest.raises(ValueError):
        reg.set("", "user@host")
    with pytest.raises(ValueError):
        reg.set("bad name", "user@host")
    with pytest.raises(ValueError):
        reg.set("prod", "")


def test_alias_registry_persist_atomic_no_tmp_file(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")

    leftover = list(tmp_path.glob("*.tmp"))
    assert leftover == []


def test_alias_registry_reload_round_trip(tmp_path: Path):
    reg = _make_alias_registry(tmp_path)
    reg.set("prod", "user@10.0.0.1")
    reg.set("dev", "user@dev.local")

    reg2 = AliasRegistry(tmp_path / "aliases.json")
    reg2.load()
    assert reg2.list() == {"prod": "user@10.0.0.1", "dev": "user@dev.local"}
