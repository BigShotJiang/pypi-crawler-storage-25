"""Tests for CLI-daemon integration and graceful degradation.

Tasks 4.7 and 4.8 of the daemon sprint.  Tests DsmClient against a real
DsmDaemon, and verifies fallback behavior when the daemon is unavailable.
Uses tmp_path for socket and registry isolation; asyncio.run() wrappers
(no pytest-asyncio).
"""

from __future__ import annotations

import asyncio
import functools
import json
from pathlib import Path

import pytest

from dsm.cli import DsmClient
from dsm.daemon import DsmDaemon
from dsm.registry import ContainerRegistry


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _run_in_thread(fn, *args, **kwargs):
    """Run a blocking function in a thread so the event loop stays free."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(fn, *args, **kwargs))


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    """Create, start, and return a daemon using tmp_path for isolation."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


# ── Task 4.7: CLI with daemon running ────────────────────────────────────────


def test_client_status(tmp_path: Path):
    """DsmClient connects and sends status, gets a valid response."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    result = client.send("status")
                    assert "pid" in result
                    assert "uptime" in result
                    assert "containers" in result
                    assert "forwards" in result

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_register_then_list(tmp_path: Path):
    """Register a container via client, then list it back."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    # Register
                    reg_result = client.send(
                        "register_container",
                        container="webapp",
                        container_id="deadbeef",
                        ip="172.17.0.5",
                    )
                    assert reg_result["container_name"] == "webapp"
                    assert reg_result["container_id"] == "deadbeef"
                    assert reg_result["container_ip"] == "172.17.0.5"
                    # Phase 2 schema additions.
                    assert reg_result["dsm_version"], "daemon must stamp non-empty dsm_version"
                    assert reg_result["session_id"] is None

                    # List
                    containers = client.send("list_containers")
                    assert len(containers) == 1
                    assert containers[0]["container_name"] == "webapp"

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_context_manager(tmp_path: Path):
    """DsmClient works as a context manager (connect/close)."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    result = client.send("status")
                    assert isinstance(result["containers"], int)

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_send_shutdown(tmp_path: Path):
    """Sending shutdown via client causes the daemon to stop."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        sock_path = daemon.socket_path

        def _do():
            client = DsmClient(sock_path)
            client.connect()
            try:
                client.send("shutdown")
            finally:
                client.close()

        await _run_in_thread(_do)

        # Give the daemon time to shut down
        await asyncio.sleep(0.3)
        assert not sock_path.exists()

    asyncio.run(_run())


def test_client_multiple_commands_same_connection(tmp_path: Path):
    """Client can send multiple commands on a single connection."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    # First command
                    status = client.send("status")
                    assert status["containers"] == 0

                    # Register
                    client.send(
                        "register_container",
                        container="svc1",
                        container_id="aaa",
                        ip="10.0.0.1",
                    )

                    # Second status — should now show 1 container
                    status2 = client.send("status")
                    assert status2["containers"] == 1

                    # List
                    containers = client.send("list_containers")
                    assert len(containers) == 1

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_error_response(tmp_path: Path):
    """Client raises RuntimeError when daemon returns an error."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    try:
                        client.send("get_container")
                        raise AssertionError("Expected RuntimeError")
                    except RuntimeError as exc:
                        assert "Daemon error" in str(exc)

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


# ── Task 4.8: Graceful degradation ──────────────────────────────────────────


def test_client_connect_nonexistent_socket(tmp_path: Path):
    """Connecting to a non-existent socket raises ConnectionError."""
    bad_sock = tmp_path / "nonexistent.sock"
    client = DsmClient(bad_sock)
    with pytest.raises(ConnectionError, match="Cannot connect"):
        client.connect()


def test_client_context_manager_nonexistent_socket(tmp_path: Path):
    """Context manager raises ConnectionError for non-existent socket."""
    bad_sock = tmp_path / "nonexistent.sock"
    with pytest.raises(ConnectionError, match="Cannot connect"):
        with DsmClient(bad_sock) as client:
            client.send("status")


def test_client_send_without_connect():
    """Calling send before connect raises ConnectionError."""
    client = DsmClient(Path("/tmp/no-such.sock"))
    with pytest.raises(ConnectionError, match="Not connected"):
        client.send("status")


# ── Sprint 02 Phase 3: end-to-end CLI flows over the daemon ─────────────────


def _session_payload(sid: str, *, type: str = "local", title: str | None = None,
                     command: list[str] | None = None,
                     container_name: str | None = None,
                     extra: dict | None = None) -> dict:
    """Build a SessionEntry-shaped dict for create_session."""
    now = "2026-05-07T00:00:00+00:00"
    return {
        "id": sid,
        "type": type,
        "title": title if title is not None else sid,
        "description": "",
        "command": command or ["bash"],
        "cwd": "",
        "created_at": now,
        "modified_at": now,
        "container_name": container_name,
        "extra": extra if extra is not None else {},
    }


def _seed_session(daemon: DsmDaemon, **kwargs) -> dict:
    """Register a SessionEntry directly on the test daemon's SessionRegistry.

    Bypasses the wire protocol so tests stay synchronous and tight.
    """
    from dsm.registry import SessionEntry
    payload = _session_payload(**kwargs)
    entry = SessionEntry.from_dict(payload)
    daemon.sessions.register(entry)
    daemon.sessions.persist(entry.id)
    return payload


def _seed_container(daemon: DsmDaemon, name: str, *, session_id: str | None = None,
                    status: str = "running") -> None:
    """Register a ContainerEntry on the daemon's ContainerRegistry."""
    daemon.registry.register(
        name, container_id=f"{name}-cid", ip="10.0.0.1",
        dsm_version="0.12.0-test", session_id=session_id,
    )
    if status != "running":
        daemon.registry.update(name, status=status)
    daemon.registry.persist(name)


def _patch_daemon_socket(monkeypatch, sock: Path, dsm_dir: Path) -> None:
    """Redirect cli's daemon socket and runtime paths to a test directory."""
    from dsm import cli, paths as _paths
    monkeypatch.setattr(cli, "DAEMON_SOCKET", sock)
    monkeypatch.setattr(cli, "DSM_DIR", dsm_dir)
    # _paths is the source of truth for session runtime artifacts (sockets,
    # logs, agent context). Redirect its DSM_HOME so tests don't touch the
    # user's real ~/.dsm/ if the CLI happens to construct a session dir.
    monkeypatch.setattr(_paths, "DSM_HOME", dsm_dir)
    # Bypass auto-spawn — the test daemon is already running.
    monkeypatch.setattr(cli, "ensure_daemon_running", lambda socket_path=None: None)


def test_cmd_ls_round_trip(tmp_path: Path, monkeypatch, capsys):
    """`dsm ls` over a live daemon — sessions reach the user via list_sessions."""
    from dsm import cli

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            _seed_session(daemon, sid="alpha-one", title="alpha-one")
            _seed_session(daemon, sid="boxer", title="boxer", type="container",
                          container_name="dsm_box",
                          extra={"repo_path": "/r", "branch": "main"})
            _seed_container(daemon, "dsm_box", session_id="boxer")

            sock = daemon.socket_path
            _patch_daemon_socket(monkeypatch, sock, tmp_path / "_cli_dsm")
            (tmp_path / "_cli_dsm").mkdir(exist_ok=True)
            monkeypatch.setattr(cli, "container_alive", lambda name: False)

            def _do():
                from types import SimpleNamespace
                cli.cmd_list(SimpleNamespace())

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())
    out = capsys.readouterr().out
    assert "alpha-one" in out
    assert "boxer" in out


def test_cmd_rm_round_trip(tmp_path: Path, monkeypatch, capsys):
    """`dsm rm <id>` removes the session via daemon RPCs."""
    from dsm import cli

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            _seed_session(daemon, sid="charlie", title="charlie")

            sock = daemon.socket_path
            _patch_daemon_socket(monkeypatch, sock, tmp_path / "_cli_dsm")
            (tmp_path / "_cli_dsm").mkdir(exist_ok=True)

            def _do():
                from types import SimpleNamespace
                cli.cmd_rm(SimpleNamespace(id="charlie"))

            await _run_in_thread(_do)

            # Session must be gone from the registry.
            assert daemon.sessions.get("charlie") is None
        finally:
            await daemon.stop()

    asyncio.run(_run())
    assert "charlie" in capsys.readouterr().out


def test_cmd_alias_set_ls_rm_round_trip(tmp_path: Path, monkeypatch, capsys):
    """`dsm alias set/ls/rm` round-trip via the daemon's AliasRegistry."""
    from dsm import cli

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            sock = daemon.socket_path
            _patch_daemon_socket(monkeypatch, sock, tmp_path / "_cli_dsm")
            (tmp_path / "_cli_dsm").mkdir(exist_ok=True)

            def _do_set():
                from types import SimpleNamespace
                cli.cmd_alias(SimpleNamespace(
                    alias_cmd="set", name="prod", target="user@10.0.0.1",
                ))

            def _do_ls():
                from types import SimpleNamespace
                cli.cmd_alias(SimpleNamespace(alias_cmd="ls"))

            def _do_rm():
                from types import SimpleNamespace
                cli.cmd_alias(SimpleNamespace(alias_cmd="rm", name="prod"))

            await _run_in_thread(_do_set)
            assert daemon.aliases.get("prod") == "user@10.0.0.1"

            await _run_in_thread(_do_ls)
            ls_out = capsys.readouterr().out
            assert "prod" in ls_out
            assert "user@10.0.0.1" in ls_out

            await _run_in_thread(_do_rm)
            assert daemon.aliases.get("prod") is None
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_cmd_doctor_classifies_session_linked_container(tmp_path: Path, monkeypatch, capsys):
    """AC-3: doctor classifies a container with a linked session_id non-`unknown`.

    Reproduces the gap that motivated the sprint: a registry-only container is
    classified as ``unknown`` because the CLI used to walk session dirs
    (which won't exist in this scenario) instead of asking the daemon for
    the linked SessionEntry. With the new architecture the daemon's
    list_sessions response carries the meta fields, so doctor can fully
    classify the container.
    """
    import os
    import subprocess

    from dsm import cli

    # Build a real git repo with a feature branch worktree so doctor's
    # classification path runs end-to-end (no mocks).
    def _git(repo: Path, *args: str) -> None:
        env = os.environ.copy()
        env.update({
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "test@example.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "test@example.com",
        })
        subprocess.run(["git", "-C", str(repo), *args], check=True,
                       capture_output=True, env=env)

    origin = tmp_path / "origin.git"
    subprocess.run(["git", "init", "--bare", "-b", "main", str(origin)],
                   check=True, capture_output=True)
    repo = tmp_path / "myrepo"
    repo.mkdir()
    _git(repo, "init", "-b", "main")
    _git(repo, "remote", "add", "origin", str(origin))
    (repo / "README.md").write_text("hello\n")
    _git(repo, "add", ".")
    _git(repo, "commit", "-m", "initial")
    _git(repo, "push", "-u", "origin", "main")
    _git(repo, "remote", "set-head", "origin", "--auto")
    worktrees = tmp_path / "myrepo-worktrees"
    worktrees.mkdir()
    _git(repo, "worktree", "add", "-b", "feat", str(worktrees / "feat"), "origin/main")

    async def _run():
        # Use a separate daemon-state dir so the CLI's DSM_DIR override doesn't
        # collide with the daemon's registry locations.
        daemon_state = tmp_path / "daemon_state"
        daemon_state.mkdir()
        sock = daemon_state / "dsm.sock"
        reg_dir = daemon_state / "registry"
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon.start()
        try:
            sid = "myrepo-feat"
            cname = "dsm_myrepo"
            _seed_session(
                daemon, sid=sid, title=sid, type="container",
                container_name=cname,
                extra={
                    "image": "img:latest",
                    "repo_path": str(repo),
                    "branch": "feat",
                    "ports": [],
                    "volumes": [],
                    "env": [],
                },
            )
            _seed_container(daemon, cname, session_id=sid)

            _patch_daemon_socket(monkeypatch, sock, tmp_path / "_cli_dsm")
            (tmp_path / "_cli_dsm").mkdir(exist_ok=True)

            def _do():
                from types import SimpleNamespace
                cli.cmd_doctor(SimpleNamespace())

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())
    out = capsys.readouterr().out
    # AC-3: container is no longer classified as unknown.
    # Acceptable statuses for a clean feat branch on top of origin/main are
    # clean+merged (no extra commits) — assert not unknown.
    assert "dsm_myrepo" in out
    assert "unknown" not in out, f"AC-3 regression: doctor still classifies as unknown.\n{out}"


