"""Tests for port detection and forwarding (dsm.ports module)."""

import asyncio
import socket
import subprocess
import time
from pathlib import Path
from unittest.mock import MagicMock, call, patch, mock_open

import pytest

from dsm.ports import (
    ForwardHandle,
    ListeningPort,
    PortChange,
    PortWatcher,
    _active_forwards,
    _decode_address,
    _normalize_bind,
    clear_forwards,
    find_available_host_port,
    get_container_ip,
    get_container_pid,
    list_forwards,
    parse_proc_net_tcp,
    scan_container_ports,
    start_forward,
    stop_forward,
)


@pytest.fixture(autouse=True)
def _clean_registry():
    """Clear the forward registry before and after each test."""
    _active_forwards.clear()
    yield
    # Stop any processes that tests may have spawned
    clear_forwards()


# ── parse_proc_net_tcp ────────────────────────────────────────────────────


SAMPLE_PROC_NET_TCP = """\
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode
   0: 00000000:2253 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12345 1 0000000000000000 100 0 0 10 0
   1: 0100007F:0035 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12346 1 0000000000000000 100 0 0 10 0
   2: 00000000:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12347 1 0000000000000000 100 0 0 10 0
   3: 0100007F:C000 00000000:0000 01 00000000:00000000 00:00000000 00000000     0        0 12348 1 0000000000000000 100 0 0 10 0
   4: 00000000:9C40 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12349 1 0000000000000000 100 0 0 10 0
"""
# Line 0: port 0x2253 = 8787, LISTEN on 0.0.0.0
# Line 1: port 0x0035 = 53,   LISTEN on 127.0.0.1
# Line 2: port 0x1F90 = 8080, LISTEN on 0.0.0.0
# Line 3: port 0xC000 = 49152, ESTABLISHED (state 01) — should be skipped
# Line 4: port 0x9C40 = 40000, LISTEN on 0.0.0.0 — ephemeral range, should be skipped


def test_parse_proc_net_tcp_basic():
    result = parse_proc_net_tcp(SAMPLE_PROC_NET_TCP)
    ports = {p.port for p in result}
    assert 8787 in ports
    assert 53 in ports
    assert 8080 in ports


def test_parse_proc_net_tcp_skips_non_listen():
    result = parse_proc_net_tcp(SAMPLE_PROC_NET_TCP)
    ports = {p.port for p in result}
    assert 49152 not in ports  # ESTABLISHED state


def test_parse_proc_net_tcp_skips_ephemeral():
    result = parse_proc_net_tcp(SAMPLE_PROC_NET_TCP)
    ports = {p.port for p in result}
    assert 40000 not in ports  # in ephemeral range


def test_parse_proc_net_tcp_bind_addresses():
    result = parse_proc_net_tcp(SAMPLE_PROC_NET_TCP)
    by_port = {p.port: p for p in result}
    assert by_port[8787].bind_address == "0.0.0.0"
    assert by_port[53].bind_address == "127.0.0.1"


def test_parse_proc_net_tcp_empty():
    assert parse_proc_net_tcp("") == []


def test_parse_proc_net_tcp_header_only():
    header = "  sl  local_address rem_address   st tx_queue rx_queue\n"
    assert parse_proc_net_tcp(header) == []


# ── _decode_address ───────────────────────────────────────────────────────


def test_decode_ipv4_loopback():
    assert _decode_address("0100007F") == "127.0.0.1"


def test_decode_ipv4_any():
    assert _decode_address("00000000") == "0.0.0.0"


def test_decode_ipv6_any():
    result = _decode_address("00000000000000000000000000000000")
    assert result == "::"


def test_decode_ipv6_loopback():
    result = _decode_address("00000000000000000000000001000000")
    assert result == "::1"


# ── _normalize_bind ───────────────────────────────────────────────────────


def test_normalize_ipv4_mapped():
    assert _normalize_bind("::ffff:0.0.0.0") == "0.0.0.0"
    assert _normalize_bind("::ffff:127.0.0.1") == "127.0.0.1"


def test_normalize_ipv6_any():
    assert _normalize_bind("::") == "0.0.0.0"


def test_normalize_passthrough():
    assert _normalize_bind("0.0.0.0") == "0.0.0.0"
    assert _normalize_bind("127.0.0.1") == "127.0.0.1"


# ── get_container_pid ─────────────────────────────────────────────────────


def test_get_container_pid_success():
    mock_result = MagicMock(returncode=0, stdout="12345\n")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        assert get_container_pid("mycontainer") == 12345


def test_get_container_pid_not_found():
    mock_result = MagicMock(returncode=1, stdout="", stderr="Error")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        with pytest.raises(RuntimeError, match="not found"):
            get_container_pid("missing")


def test_get_container_pid_not_running():
    mock_result = MagicMock(returncode=0, stdout="0\n")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        with pytest.raises(RuntimeError, match="not running"):
            get_container_pid("stopped")


# ── scan_container_ports ──────────────────────────────────────────────────


def test_scan_container_ports():
    mock_result = MagicMock(returncode=0, stdout="42\n")
    with patch("dsm.ports.subprocess.run", return_value=mock_result), \
         patch("dsm.ports.Path.exists", return_value=True), \
         patch("dsm.ports.Path.read_text", return_value=SAMPLE_PROC_NET_TCP):
        result = scan_container_ports("mycontainer")
        ports = {p.port for p in result}
        assert 8787 in ports
        assert 8080 in ports


def test_scan_container_ports_deduplicates():
    """tcp and tcp6 may report the same port; should be deduped."""
    tcp_content = """\
  sl  local_address rem_address   st
   0: 00000000:2253 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12345 1 0000000000000000 100 0 0 10 0
"""
    tcp6_content = """\
  sl  local_address rem_address   st
   0: 00000000000000000000000000000000:2253 00000000000000000000000000000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12345 1 0000000000000000 100 0 0 10 0
"""
    mock_result = MagicMock(returncode=0, stdout="42\n")
    call_count = 0

    def fake_read_text(self):
        nonlocal call_count
        call_count += 1
        return tcp_content if call_count == 1 else tcp6_content

    with patch("dsm.ports.subprocess.run", return_value=mock_result), \
         patch("dsm.ports.Path.exists", return_value=True), \
         patch.object(Path, "read_text", fake_read_text):
        result = scan_container_ports("mycontainer")
        # Port 8787 should appear only once despite being in both tcp and tcp6
        assert len([p for p in result if p.port == 8787]) == 1


# ── get_container_ip ──────────────────────────────────────────────────────


def test_get_container_ip_success():
    mock_result = MagicMock(returncode=0, stdout="172.17.0.2\n")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        assert get_container_ip("mycontainer") == "172.17.0.2"


def test_get_container_ip_no_ip():
    mock_result = MagicMock(returncode=0, stdout="\n")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        with pytest.raises(RuntimeError, match="no IP"):
            get_container_ip("mycontainer")


def test_get_container_ip_not_found():
    mock_result = MagicMock(returncode=1, stdout="")
    with patch("dsm.ports.subprocess.run", return_value=mock_result):
        with pytest.raises(RuntimeError, match="not found"):
            get_container_ip("missing")


# ── find_available_host_port ──────────────────────────────────────────────


def test_find_available_port_preferred():
    """Should return preferred port when available."""
    # Mock socket.bind to succeed on first try
    with patch("dsm.ports.socket.socket") as mock_socket_cls:
        mock_sock = MagicMock()
        mock_socket_cls.return_value.__enter__ = MagicMock(return_value=mock_sock)
        mock_socket_cls.return_value.__exit__ = MagicMock(return_value=False)
        result = find_available_host_port(8787)
        assert result == 8787


def test_find_available_port_increments():
    """Should increment when preferred port is taken."""
    call_count = 0

    def fake_bind(addr):
        nonlocal call_count
        call_count += 1
        if call_count <= 2:
            raise OSError("Address already in use")

    with patch("dsm.ports.socket.socket") as mock_socket_cls:
        mock_sock = MagicMock()
        mock_sock.bind = fake_bind
        mock_socket_cls.return_value.__enter__ = MagicMock(return_value=mock_sock)
        mock_socket_cls.return_value.__exit__ = MagicMock(return_value=False)
        result = find_available_host_port(8787)
        assert result == 8789  # 8787 and 8788 fail, 8789 succeeds


def test_find_available_port_skips_reserved():
    """Reserved ports must be skipped without attempting bind()."""
    bind_attempts: list[int] = []

    def fake_bind(addr):
        bind_attempts.append(addr[1])

    with patch("dsm.ports.socket.socket") as mock_socket_cls:
        mock_sock = MagicMock()
        mock_sock.bind = fake_bind
        mock_socket_cls.return_value.__enter__ = MagicMock(return_value=mock_sock)
        mock_socket_cls.return_value.__exit__ = MagicMock(return_value=False)
        result = find_available_host_port(8787, reserved={8787, 8788})
        assert result == 8789
        assert bind_attempts == [8789], "must not bind reserved ports"


def test_find_available_port_exhausted():
    """Should raise when no port available."""
    with patch("dsm.ports.socket.socket") as mock_socket_cls:
        mock_sock = MagicMock()
        mock_sock.bind.side_effect = OSError("Address already in use")
        mock_socket_cls.return_value.__enter__ = MagicMock(return_value=mock_sock)
        mock_socket_cls.return_value.__exit__ = MagicMock(return_value=False)
        with pytest.raises(RuntimeError, match="No available port"):
            find_available_host_port(8787, max_attempts=3)


# ── start_forward / stop_forward ──────────────────────────────────────────


def test_start_forward():
    mock_ip_result = MagicMock(returncode=0, stdout="172.17.0.2\n")
    mock_proc = MagicMock()
    mock_proc.pid = 99999
    mock_proc.poll.return_value = None  # still running

    with patch("dsm.ports.subprocess.run", return_value=mock_ip_result), \
         patch("dsm.ports.subprocess.Popen", return_value=mock_proc), \
         patch("dsm.ports.find_available_host_port", return_value=8787):
        handle = start_forward("mycontainer", 8787)
        assert handle.container_name == "mycontainer"
        assert handle.container_port == 8787
        assert handle.host_port == 8787
        assert handle.alive


def test_start_forward_different_host_port():
    mock_ip_result = MagicMock(returncode=0, stdout="172.17.0.2\n")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None

    with patch("dsm.ports.subprocess.run", return_value=mock_ip_result), \
         patch("dsm.ports.subprocess.Popen", return_value=mock_proc), \
         patch("dsm.ports.find_available_host_port", return_value=9000):
        handle = start_forward("mycontainer", 8787, host_port=9000)
        assert handle.host_port == 9000


def test_stop_forward():
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    handle = ForwardHandle("mycontainer", 8787, 8787, mock_proc)
    _active_forwards["mycontainer"] = [handle]

    stop_forward(handle)

    mock_proc.terminate.assert_called_once()
    assert list_forwards("mycontainer") == []


def test_stop_forward_kill_on_timeout():
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.wait.side_effect = [subprocess.TimeoutExpired("socat", 5), None]
    handle = ForwardHandle("mycontainer", 8787, 8787, mock_proc)
    _active_forwards["mycontainer"] = [handle]

    stop_forward(handle)

    mock_proc.terminate.assert_called_once()
    mock_proc.kill.assert_called_once()


# ── list_forwards / registry ──────────────────────────────────────────────


def test_list_forwards_empty():
    assert list_forwards() == []
    assert list_forwards("nonexistent") == []


def test_list_forwards_filters_by_container():
    proc1 = MagicMock()
    proc1.poll.return_value = None
    proc2 = MagicMock()
    proc2.poll.return_value = None

    h1 = ForwardHandle("container_a", 8787, 8787, proc1)
    h2 = ForwardHandle("container_b", 3000, 3000, proc2)
    _active_forwards["container_a"] = [h1]
    _active_forwards["container_b"] = [h2]

    assert list_forwards("container_a") == [h1]
    assert list_forwards("container_b") == [h2]
    all_forwards = list_forwards()
    assert len(all_forwards) == 2
    assert h1 in all_forwards
    assert h2 in all_forwards


def test_list_forwards_prunes_dead():
    alive_proc = MagicMock()
    alive_proc.poll.return_value = None
    dead_proc = MagicMock()
    dead_proc.poll.return_value = 1  # exited

    h_alive = ForwardHandle("mycontainer", 8787, 8787, alive_proc)
    h_dead = ForwardHandle("mycontainer", 3000, 3000, dead_proc)
    _active_forwards["mycontainer"] = [h_alive, h_dead]

    result = list_forwards("mycontainer")
    assert result == [h_alive]
    # Dead handle should be removed from registry
    assert h_dead not in _active_forwards.get("mycontainer", [])


# ── Forward dedup ────────────────────────────────────────────────────────


def test_start_forward_dedup_returns_existing():
    """start_forward returns existing alive forward instead of spawning a new socat."""
    alive_proc = MagicMock()
    alive_proc.poll.return_value = None  # alive
    existing = ForwardHandle("mycontainer", 8787, 8787, alive_proc)
    _active_forwards["mycontainer"] = [existing]

    with patch("dsm.ports.subprocess.Popen") as mock_popen:
        handle = start_forward("mycontainer", 8787)
        # Should return existing handle, not spawn a new process
        assert handle is existing
        mock_popen.assert_not_called()


def test_start_forward_replaces_dead():
    """start_forward cleans up dead forward and creates a new one."""
    dead_proc = MagicMock()
    dead_proc.poll.return_value = 1  # dead
    dead_handle = ForwardHandle("mycontainer", 8787, 8787, dead_proc)
    _active_forwards["mycontainer"] = [dead_handle]

    new_proc = MagicMock()
    new_proc.pid = 11111
    new_proc.poll.return_value = None
    mock_ip_result = MagicMock(returncode=0, stdout="172.17.0.2\n")

    with patch("dsm.ports.subprocess.run", return_value=mock_ip_result), \
         patch("dsm.ports.subprocess.Popen", return_value=new_proc), \
         patch("dsm.ports.find_available_host_port", return_value=8787):
        handle = start_forward("mycontainer", 8787)
        assert handle is not dead_handle
        assert handle.alive
        # Dead handle should have been cleaned out
        forwards = _active_forwards["mycontainer"]
        assert dead_handle not in forwards


# ── ForwardHandle.alive ──────────────────────────────────────────────────


def test_handle_alive():
    proc = MagicMock()
    proc.poll.return_value = None
    h = ForwardHandle("c", 80, 80, proc)
    assert h.alive is True


def test_handle_dead():
    proc = MagicMock()
    proc.poll.return_value = 0
    h = ForwardHandle("c", 80, 80, proc)
    assert h.alive is False


def test_handle_no_process():
    h = ForwardHandle("c", 80, 80, None)
    assert h.alive is False


# ── IPv6 parsing ──────────────────────────────────────────────────────────


SAMPLE_PROC_NET_TCP6 = """\
  sl  local_address                         remote_address                        st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode
   0: 00000000000000000000000000000000:2253 00000000000000000000000000000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12345 1 0000000000000000 100 0 0 10 0
   1: 00000000000000000000000001000000:0050 00000000000000000000000000000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 12346 1 0000000000000000 100 0 0 10 0
"""
# Line 0: port 0x2253 = 8787, LISTEN on ::
# Line 1: port 0x0050 = 80,   LISTEN on ::1


def test_parse_proc_net_tcp6():
    result = parse_proc_net_tcp(SAMPLE_PROC_NET_TCP6)
    by_port = {p.port: p for p in result}
    assert 8787 in by_port
    assert by_port[8787].bind_address == "::"
    assert by_port[8787].protocol == "tcp6"
    assert 80 in by_port
    assert by_port[80].bind_address == "::1"


# ── PortWatcher ───────────────────────────────────────────────────────────
#
# These tests use _poll_container directly (synchronous) to avoid asyncio
# timing issues. The _run loop is tested via start/stop lifecycle.


def _make_watcher(containers=None, on_change=None, exclude_ports=None):
    """Helper to create a watcher without starting it."""
    return PortWatcher(
        containers=containers or ["testcontainer"],
        interval=0.1,  # fast for tests
        on_change=on_change,
        exclude_ports=exclude_ports,
    )


def _lp(port, bind="0.0.0.0", proto="tcp"):
    return ListeningPort(port=port, bind_address=bind, protocol=proto)


def test_watcher_detects_new_port():
    """New port appears -> auto-forward called."""
    changes = []
    watcher = _make_watcher(on_change=changes.extend)

    mock_proc = MagicMock()
    mock_proc.poll.return_value = None

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(8787)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"), \
         patch("dsm.ports.start_forward", return_value=ForwardHandle("testcontainer", 8787, 8787, mock_proc)) as mock_fwd:
        watcher._poll_container("testcontainer")

    mock_fwd.assert_called_once_with(
        "testcontainer", 8787, registry=None, reserved_host_ports=set()
    )
    assert len(changes) == 1
    assert changes[0].action == "added"
    assert changes[0].port.port == 8787
    assert changes[0].forward is not None


def test_watcher_removes_vanished_port():
    """Port disappears -> auto-unforward called."""
    changes = []
    watcher = _make_watcher(on_change=changes.extend)

    # Seed previous state with port 8787
    watcher._previous["testcontainer"] = {(8787, "0.0.0.0")}
    watcher._container_ips["testcontainer"] = "172.17.0.2"

    # Set up a forward in the registry to be stopped
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    handle = ForwardHandle("testcontainer", 8787, 8787, mock_proc)
    _active_forwards["testcontainer"] = [handle]

    with patch("dsm.ports.scan_container_ports", return_value=[]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"):
        watcher._poll_container("testcontainer")

    mock_proc.terminate.assert_called_once()
    assert len(changes) == 1
    assert changes[0].action == "removed"
    assert changes[0].port.port == 8787


def test_watcher_skips_loopback():
    """Loopback ports are not forwarded."""
    changes = []
    watcher = _make_watcher(on_change=changes.extend)

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(53, "127.0.0.1")]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"), \
         patch("dsm.ports.start_forward") as mock_fwd:
        watcher._poll_container("testcontainer")

    mock_fwd.assert_not_called()
    assert len(changes) == 1
    assert changes[0].action == "added"
    assert changes[0].forward is None  # not forwarded


def test_watcher_skips_excluded():
    """Excluded ports are not forwarded and don't generate changes."""
    changes = []
    watcher = _make_watcher(on_change=changes.extend, exclude_ports={22})

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(22), _lp(8787)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"), \
         patch("dsm.ports.start_forward", return_value=ForwardHandle("testcontainer", 8787, 8787, MagicMock())) as mock_fwd:
        watcher._poll_container("testcontainer")

    # Only port 8787 should be forwarded
    mock_fwd.assert_called_once_with(
        "testcontainer", 8787, registry=None, reserved_host_ports=set()
    )
    # Only port 8787 generates a change (excluded ports are silent)
    assert len(changes) == 1
    assert changes[0].port.port == 8787


def test_watcher_restart_detection():
    """Container IP change triggers re-establishment of forwards."""
    changes = []
    watcher = _make_watcher(on_change=changes.extend)

    # Seed with old IP and previous state
    watcher._container_ips["testcontainer"] = "172.17.0.2"
    watcher._previous["testcontainer"] = {(8787, "0.0.0.0")}

    # Set up existing forward at old IP
    old_proc = MagicMock()
    old_proc.poll.return_value = None
    old_handle = ForwardHandle("testcontainer", 8787, 8787, old_proc)
    _active_forwards["testcontainer"] = [old_handle]

    new_proc = MagicMock()
    new_proc.poll.return_value = None

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(8787)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.3"), \
         patch("dsm.ports.subprocess.Popen", return_value=new_proc), \
         patch("dsm.ports.find_available_host_port", return_value=8787):
        watcher._poll_container("testcontainer")

    # Old forward should have been stopped (IP change cleanup)
    old_proc.terminate.assert_called()
    # New IP should be cached
    assert watcher._container_ips["testcontainer"] == "172.17.0.3"
    # Port should be re-forwarded (appears as "added" since previous was cleared)
    added = [c for c in changes if c.action == "added"]
    assert len(added) == 1
    assert added[0].port.port == 8787


def test_watcher_callback_fires():
    """on_change callback is invoked with correct PortChange list."""
    callback = MagicMock()
    watcher = _make_watcher(on_change=callback)

    mock_proc = MagicMock()
    mock_proc.poll.return_value = None

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(3000)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"), \
         patch("dsm.ports.start_forward", return_value=ForwardHandle("testcontainer", 3000, 3000, mock_proc)):
        watcher._poll_container("testcontainer")

    callback.assert_called_once()
    changes = callback.call_args[0][0]
    assert len(changes) == 1
    assert isinstance(changes[0], PortChange)


def test_watcher_callback_error_doesnt_crash():
    """Callback error should not kill the watcher."""
    def bad_callback(changes):
        raise ValueError("callback boom")

    watcher = _make_watcher(on_change=bad_callback)

    mock_proc = MagicMock()
    mock_proc.poll.return_value = None

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(8787)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"), \
         patch("dsm.ports.start_forward", return_value=ForwardHandle("testcontainer", 8787, 8787, mock_proc)):
        # Should not raise
        watcher._poll_container("testcontainer")


def test_watcher_container_gone():
    """Container stops -> forwards cleaned up + container_gone signal fires."""
    changes = []
    watcher = _make_watcher(containers=["testcontainer"], on_change=changes.extend)

    # Seed previous state
    watcher._previous["testcontainer"] = {(8787, "0.0.0.0")}
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    _active_forwards["testcontainer"] = [ForwardHandle("testcontainer", 8787, 8787, mock_proc)]

    with patch("dsm.ports.scan_container_ports", side_effect=RuntimeError("not running")):
        watcher._poll_container("testcontainer")

    # Forward should be cleaned up
    mock_proc.terminate.assert_called()
    # Per-port removed + container_gone signal
    assert [c.action for c in changes] == ["removed", "container_gone"]
    assert changes[1].port is None
    assert changes[1].container_name == "testcontainer"
    # Ghost dropped from watch list
    assert "testcontainer" not in watcher._containers


def test_watcher_container_gone_no_prior_state():
    """Container disappears before first scan -> still fires container_gone."""
    changes = []
    watcher = _make_watcher(containers=["never_scanned"], on_change=changes.extend)

    with patch("dsm.ports.scan_container_ports", side_effect=RuntimeError("not running")):
        watcher._poll_container("never_scanned")

    assert [c.action for c in changes] == ["container_gone"]
    assert "never_scanned" not in watcher._containers


def test_watcher_add_remove_container():
    """Dynamic container list modification."""
    watcher = _make_watcher(containers=["a"])
    assert "a" in watcher._containers

    watcher.add_container("b")
    assert "b" in watcher._containers

    watcher.add_container("b")  # duplicate — no effect
    assert watcher._containers.count("b") == 1

    watcher.remove_container("a")
    assert "a" not in watcher._containers


def test_watcher_start_stop_lifecycle():
    """Watcher asyncio task starts and stops cleanly."""

    async def _run():
        watcher = _make_watcher(containers=[])
        assert not watcher.running
        await watcher.start()
        assert watcher.running
        await watcher.stop()
        assert not watcher.running

    asyncio.run(_run())


def test_watcher_no_change_no_callback():
    """No changes between polls -> callback not fired."""
    callback = MagicMock()
    watcher = _make_watcher(on_change=callback)

    # Seed with port already known
    watcher._previous["testcontainer"] = {(8787, "0.0.0.0")}
    watcher._container_ips["testcontainer"] = "172.17.0.2"

    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    _active_forwards["testcontainer"] = [ForwardHandle("testcontainer", 8787, 8787, mock_proc)]

    with patch("dsm.ports.scan_container_ports", return_value=[_lp(8787)]), \
         patch("dsm.ports.get_container_ip", return_value="172.17.0.2"):
        watcher._poll_container("testcontainer")

    callback.assert_not_called()
