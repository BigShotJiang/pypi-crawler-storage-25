"""Architectural enforcement tests.

Mechanically blocks reintroduction of CLI-side persistent-state IO. The CLI
must remain a thin client that talks to the daemon over the Unix socket; the
daemon owns every read or write of files under ``~/.dsm/`` outside the
narrow allowlist defined here.

The check is an AST walk over ``src/dsm/cli.py`` only — other modules
(``daemon.py``, ``registry.py``, ``ports.py``, ``paths.py``) legitimately own
state IO and are out of scope.
"""

from __future__ import annotations

import ast
from pathlib import Path

CLI_SOURCE = Path(__file__).parent.parent / "src" / "dsm" / "cli.py"

# A path construction rooted at DSM_DIR is allowed if any constant string
# segment in the chain matches one of these. Only these two literal CLI-owned
# files are permitted; everything else (registry/, sessions/, aliases.json,
# {sid}/...) must be reached via daemon RPCs.
ALLOWED_FINAL_SEGMENTS = {"config.json", "dsm.sock"}

# Path methods that read or mutate filesystem state. ``exists`` is a probe,
# not state IO, and is therefore deliberately absent.
STATE_MUTATING_PATH_METHODS = {
    "iterdir",
    "glob",
    "read_text",
    "write_text",
    "mkdir",
    "unlink",
    "rename",
    "touch",
}


def _is_dsm_dir_name(node: ast.AST) -> bool:
    return isinstance(node, ast.Name) and node.id == "DSM_DIR"


def _is_path_under_dsm_dir(node: ast.AST) -> bool:
    """Return True iff ``node`` is a ``Path`` chain rooted at ``DSM_DIR``.

    Walks ``BinOp(op=Div())`` chains looking for ``ast.Name(id="DSM_DIR")``
    as a leaf on either side. Only ``BinOp`` Div nodes are recursed into;
    any other shape (e.g., ``socket_path.parent``) is not a DSM_DIR-rooted
    chain even if the receiver was originally derived from one — the test
    is purely syntactic, by design.
    """
    if _is_dsm_dir_name(node):
        return True
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        return _is_path_under_dsm_dir(node.left) or _is_path_under_dsm_dir(node.right)
    return False


def _collect_constant_segments(node: ast.AST) -> list[str]:
    """Collect string ``ast.Constant`` segments from a DSM_DIR-rooted chain."""
    segments: list[str] = []
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        segments.append(node.value)
    elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        segments.extend(_collect_constant_segments(node.left))
        segments.extend(_collect_constant_segments(node.right))
    return segments


def _path_is_allowlisted(node: ast.AST) -> bool:
    """True iff any constant string in the chain matches the allowlist."""
    return any(seg in ALLOWED_FINAL_SEGMENTS for seg in _collect_constant_segments(node))


def _is_outermost_dsm_dir_chain(node: ast.AST, parent: ast.AST | None) -> bool:
    """A ``BinOp`` chain rooted at ``DSM_DIR`` is "outermost" when its parent
    is not itself another ``BinOp(op=Div)``. Only outermost chains are
    candidate violations under rule (1); inner BinOp nodes are part of the
    same construction and would otherwise be double-flagged.
    """
    if not (isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div)):
        return False
    if not _is_path_under_dsm_dir(node):
        return False
    if isinstance(parent, ast.BinOp) and isinstance(parent.op, ast.Div):
        return False
    return True


def _violations_in_tree(tree: ast.AST) -> list[tuple[int, str]]:
    """Walk ``tree`` and return a deduplicated list of (lineno, snippet)
    tuples for every architecture-test violation.

    Three rules:
      1. Path chain rooted at ``DSM_DIR`` outside the allowlist (outermost
         BinOp only — sub-chains are not double-flagged).
      2. ``open(...)`` whose first arg is a non-allowlisted DSM_DIR chain.
      3. State-mutating Path method called on a non-allowlisted DSM_DIR
         chain (``iterdir``, ``glob``, ``read_text``, ``write_text``,
         ``mkdir``, ``unlink``, ``rename``, ``touch``).
    """
    raw: list[tuple[int, int, str]] = []  # (lineno, col_offset, snippet)

    # Track each node's parent so rule (1) can scope to outermost BinOp chains.
    parents: dict[int, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[id(child)] = parent

    for node in ast.walk(tree):
        parent = parents.get(id(node))

        # Rule (1): outermost DSM_DIR-rooted Path construction, no allowlist match.
        if _is_outermost_dsm_dir_chain(node, parent):
            if not _path_is_allowlisted(node):
                raw.append((node.lineno, node.col_offset, ast.unparse(node)))

        # Rule (2): open(<DSM_DIR-rooted chain>).
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "open"
            and node.args
            and _is_path_under_dsm_dir(node.args[0])
            and not _path_is_allowlisted(node.args[0])
        ):
            raw.append((node.lineno, node.col_offset, ast.unparse(node)))

        # Rule (3): <DSM_DIR-rooted chain>.<state_method>(...).
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr in STATE_MUTATING_PATH_METHODS
            and _is_path_under_dsm_dir(node.func.value)
            and not _path_is_allowlisted(node.func.value)
        ):
            raw.append((node.lineno, node.col_offset, ast.unparse(node)))

    # De-dup by (lineno, col_offset) so a node can't be flagged twice if it
    # happens to satisfy more than one rule (e.g., an outermost BinOp that is
    # also the receiver of an .iterdir() call).
    seen: set[tuple[int, int]] = set()
    unique: list[tuple[int, str]] = []
    for lineno, col, snippet in raw:
        key = (lineno, col)
        if key in seen:
            continue
        seen.add(key)
        unique.append((lineno, snippet))
    unique.sort(key=lambda t: t[0])
    return unique


def test_cli_does_not_touch_state_files() -> None:
    """The CLI must not read or write files under ``~/.dsm/`` outside the
    fixed allowlist. The daemon owns all persistent state.
    """
    tree = ast.parse(CLI_SOURCE.read_text())
    violations = _violations_in_tree(tree)
    if violations:
        msg = "\n".join(
            f"src/dsm/cli.py:{lineno}: {snippet}" for lineno, snippet in violations
        )
        raise AssertionError(
            f"CLI must not touch state files outside allowlist:\n{msg}"
        )


PLANTED_ITERDIR = '''
from pathlib import Path
DSM_DIR = Path.home() / ".dsm"
def violator():
    return list(DSM_DIR.iterdir())
'''


PLANTED_OPEN = '''
from pathlib import Path
DSM_DIR = Path.home() / ".dsm"
def violator(name):
    with open(DSM_DIR / "registry" / f"{name}.json") as fp:
        return fp.read()
'''


def test_planted_violation_is_caught() -> None:
    """The walker must catch a deliberate ``DSM_DIR.iterdir()`` (rule 3) and
    a deliberate ``open(DSM_DIR / "registry" / ...)`` (rule 2). Without this
    sanity check, a regression in the walker could let real violations slip
    through silently.
    """
    tree = ast.parse(PLANTED_ITERDIR)
    violations = _violations_in_tree(tree)
    assert violations, "walker should have flagged DSM_DIR.iterdir() but did not"
    assert any("iterdir" in snippet for _, snippet in violations), (
        f"expected an iterdir violation; got: {violations}"
    )

    tree = ast.parse(PLANTED_OPEN)
    violations = _violations_in_tree(tree)
    assert violations, (
        "walker should have flagged open(DSM_DIR / 'registry' / ...) but did not"
    )
    assert any("open(" in snippet for _, snippet in violations), (
        f"expected an open() violation; got: {violations}"
    )
