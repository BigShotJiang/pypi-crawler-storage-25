# SPDX-License-Identifier: MIT
from .base import BaseVault
from .memory import MemoryVault

try:
    from .redis import RedisVault
    _redis_available = True
except ImportError:
    RedisVault = None
    _redis_available = False

__all__ = ["BaseVault", "MemoryVault", "RedisVault"]

_DEFAULT_REDIS_TTL = 86400


def build_vault(store: str | None = None, ttl: int = _DEFAULT_REDIS_TTL) -> BaseVault:
    """
    Factory function. Builds the appropriate vault from the store argument.

    Args:
        store: None for in-memory, or a Redis URL e.g. "redis://localhost:6379"
        ttl:   Redis TTL in seconds (ignored for memory vault)
    """
    if store is None:
        return MemoryVault()

    if isinstance(store, str) and (
        store.startswith("redis://") or store.startswith("rediss://")
    ):
        if not _redis_available:
            raise ImportError(
                "Redis support requires the redis package. Install with: pip install armos[redis]"
            )
        return RedisVault(url=store, ttl=ttl)

    raise ValueError(
        f"Unsupported store: '{store}'. "
        f"Pass a Redis URL like 'redis://localhost:6379' or None for in-memory."
    )
