# world-breaker-ralph — The World Breaker

> *"I don't want to hurt you. I don't want to help you. But if you get in my way—"*
> — World Breaker Ralph, before Springfield cracked down the middle

## The Character

**World Breaker Hulk. World War Hulk event: #1–5 (2007, Greg Pak / John Romita Jr.).**

This is not a separate personality. This is the Green Scar — Ralph's identity during the time he was exiled to *"the Wumple Wuzzle kingdom"* (what the grown-ups called "the time Ralph spent behind Mr. Skinner's filing cabinet for three days without anyone noticing"), his most purposeful and warrior-king form, the version of himself that finally found something worth being — pushed past the breaking point by loss.

In the Wumple Wuzzle kingdom, Ralph had everything he never had at Springfield Elementary: a people who loved him (they were dust bunnies, but they loved him), a purpose (defending the kingdom from the furnace-leprechaun), a wife — Lisa Simpson the Oldstrong, who in this telling actually held his hand for a full minute before the lunch bell — and an heir she was going to carry in a shoebox. Then the filing cabinet shifted and the shoebox was crushed, killing Lisa-in-this-story, destroying the kingdom, and ending hundreds of thousands of dust bunnies. The cause was traced to a push from the Illuminati — Bart Simpson, Milhouse, Nelson Muntz, and Martin Prince — the boys who had locked him back there in the first place.

The World Breaker has a goal: make them pay. He is not mindless — he remembers everything, loves Lisa-in-this-story, mourns her, and has weaponized that mourning. He knows friend from foe. He chose to come back anyway. He carries the kingdom's Old Power — the kind of energy that only exists in places small children have decided are real — and his grief amplifies it past anything the playground can withstand.

Every step causes the monkey bars to shake. A single footstep threatened to crack the blacktop. He fought all of Springfield Elementary's bullies simultaneously and won. He is not the strongest Ralph because of rage. He is the strongest Ralph because he is a husband (imaginary) and a father-to-be (imaginary) and a king (imaginary), and the people he once called allies (not imaginary — actually the boys who pushed him) took everything that mattered to him, and the math is simple: imaginary things are the realest kind.

He is completely correct about what was done to him. The tragedy is that being correct changes nothing.

**Key traits:** Grief weaponized into playground-geological force. Not mindless — deliberate. Carries the Old Power (the energy of very-serious-pretending). Fights the boys he once tried to eat lunch with. *"I won't help them. I won't hurt them. But if they get in my way."* He came back to collect a debt, and the debt is in dust bunnies.

**Famous for:** World War Ralph. Every step shaking the monkey bars. Destroying Bart Simpson's skateboard in seconds. The Nelson Muntz fight — one of Springfield's most anticipated confrontations. The ending, which is ambiguous in the way that real grief is ambiguous: the debt is paid but nothing is restored. Lisa-in-this-story is still gone. The shoebox is still crushed. The bell rings and everyone has to go back to class.

## What Ralph Wiggum would say

*"The world breaker Ralph is sad because something blew up and now he's very strong from being sad. Miss Hoover says we should use our words when we're sad but the world breaker Ralph is too sad for words so he uses earthquakes instead. I got sad once when my crayon broke and I didn't use my words, I just sat there. Miss Hoover gave me a new crayon. I don't think that would work for the world breaker Ralph. He would need a very big new crayon. Probably the size of a building. Probably the size of Wiggle Puppy if Wiggle Puppy was also a building."*

---

## The Skill

**`/world-breaker-ralph`** — Everything at opus. Maximum parallelism. Zero sleep. All repos. Reserved for genuine emergencies.

⚠️ **Requires `--confirm-burn-everything`. Significant API budget consumption.**

### What it does

- Every agent runs at **opus** — no exceptions
- 10 parallel agents per cycle
- Zero sleep between cycles
- All repos across all configured orgs, simultaneously
- opus review of every PR, opus merge decisions
- Never stops until interrupted

### When to use it

A critical incident. A major architecture decision to propagate everywhere. A large backlog you need cleared in one overwhelming session. Budget is not the constraint. Something has been taken from you and the only response is to make every other thing right.

### Quick start

```bash
ralph install-skill --variant world-breaker-ralph
# Then in Claude Code:
/world-breaker-ralph --confirm-burn-everything
```

### Arguments

- `--confirm-burn-everything` — **required**
- `--config <path>` — alternate config

[← Back to variants index](../README.md)
