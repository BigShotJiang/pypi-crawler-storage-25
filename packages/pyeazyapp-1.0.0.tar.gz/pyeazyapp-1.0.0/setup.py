from setuptools import setup, find_packages

setup(
    name="pyeazyapp",
    version="1.0.0",
    description="A full-featured GUI framework that fully wraps tkinter, ttk, canvas, events, dialogs, menus, and more.",
    author="Kaoru Yamamoto",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: User Interfaces",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
