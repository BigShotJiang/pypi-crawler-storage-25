# PyEazyApp

PyEazyApp は、**tkinter のすべての機能を完全ラップした GUI フレームワーク**です。  
標準ウィジェット、ttk、Canvas、イベント、ダイアログ、メニュー、画像、タイマー、低レベル API まで  
**tkinter でできることをすべて簡単に扱えるように設計されています。**

---

## ✨ 特徴

### ✔ tkinter の全機能をラップ

- Window（ウィンドウ管理）
- 標準ウィジェット（Button, Label, Entry, Frame, Canvas など）
- ttk ウィジェット（Treeview, Notebook, Combobox, Progressbar など）
- Canvas 完全ラップ（rect, oval, polygon, arc, image, window, tag_bind など）
- Menu（階層メニュー、チェック、ラジオ）
- Dialog（messagebox / filedialog）
- Event（bind / unbind / event_generate）
- Timer（after / after_cancel）
- 画像（PhotoImage / zoom / subsample）
- 変数（StringVar / IntVar / BooleanVar）
- 低レベル API（tk.call / tk.eval）

### ✔ カスタムタイトルバー（枠なしウィンドウ）

- ドラッグ移動
- 最小化 / 最大化 / 閉じるボタン

### ✔ シンプルな API

初心者でも簡単に GUI アプリを作れるように設計。

---

## 📦 インストール

```bash
pip install pyeazyapp
```

使い方:
from pyeazyapp import Window, Widget, TTK, CanvasAPI, Dialog

win = Window(600, 400, "PyEazyApp Demo")
ui = Widget(win)
ttk = TTK(win)
canvas = CanvasAPI(win, 400, 300)

label = ui.label("Hello PyEazyApp!")
label.pack(pady=10)

btn = ttk.button("Click", lambda: Dialog().info("Hello", "Button clicked!"))
btn.pack(pady=10)

canvas.pack()
canvas.rect(50, 50, 200, 150, fill="skyblue")

win.run()
解読してください
わからない部分はソースを参照してください
ライセンス:MIT
再配布,改造,公開すべてOK
