import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# ============================
#  Window クラス
# ============================
class Window:
    def __init__(self, width=400, height=300, title="Window"):
        self.window = tk.Tk()
        self.window.geometry(f"{width}x{height}")
        self.window.title(title)
        try:
            self.window.iconbitmap("pyeazyapp/icon.ico")
        except:
            pass

    # --- Window 操作 ---
    def background(self, color):
        self.window.configure(bg=color)

    def size(self, width, height):
        self.window.geometry(f"{width}x{height}")

    def title(self, title):
        self.window.title(title)

    def move(self, x, y):
        self.window.geometry(f"+{x}+{y}")

    def resize(self, width, height):
        self.window.geometry(f"{width}x{height}")

    def move_resize(self, x, y, width, height):
        self.window.geometry(f"{width}x{height}+{x}+{y}")

    def icon(self, icon_path):
        self.window.iconbitmap(icon_path)

    def state(self, state):
        self.window.state(state)

    def geometry(self, geometry):
        self.window.geometry(geometry)

    def update(self):
        self.window.update()

    def update_idle(self):
        self.window.update_idletasks()

    def minimize(self):
        self.window.iconify()

    def maximize(self):
        self.window.deiconify()

    def focus(self):
        self.window.focus_set()

    def close(self):
        self.window.destroy()

    def quit(self):
        self.window.quit()

    def disable_resize(self):
        self.window.resizable(False, False)

    def enable_resize(self):
        self.window.resizable(True, True)

    def fullscreen(self, value=True):
        self.window.attributes("-fullscreen", value)

    def opacity(self, value: float):
        self.window.attributes("-alpha", value)

    def center(self):
        self.window.update_idletasks()
        w = self.window.winfo_width()
        h = self.window.winfo_height()
        sw = self.window.winfo_screenwidth()
        sh = self.window.winfo_screenheight()
        x = (sw - w) // 2
        y = (sh - h) // 2
        self.window.geometry(f"+{x}+{y}")

    def always_on_top(self, value=True):
        self.window.attributes("-topmost", value)

    def transparent_color(self, color):
        self.window.attributes("-transparentcolor", color)

    def wm_protocol(self, name, func):
        self.window.protocol(name, func)

    # 低レベル
    def tk_call(self, *args):
        return self.window.tk.call(*args)

    def tk_eval(self, script):
        return self.window.tk.eval(script)

    # --- メインループ ---
    def run(self):
        self.window.mainloop()


# ============================
#  変数ラップ
# ============================
class Variables:
    def __init__(self):
        self.StringVar = tk.StringVar
        self.IntVar = tk.IntVar
        self.BooleanVar = tk.BooleanVar
        self.DoubleVar = tk.DoubleVar


# ============================
#  Widget クラス（標準ウィジェット）
# ============================
class Widget:
    def __init__(self, parent: Window):
        self.parent = parent.window

    def statusbar(self, text=""):
        bar = tk.Label(self.parent, text=text, bd=1, relief=tk.SUNKEN, anchor="w")
        bar.pack(side="bottom", fill="x")
        return bar

    def button(self, text, command=None):
        return tk.Button(self.parent, text=text, command=command)

    def label(self, text):
        return tk.Label(self.parent, text=text)

    def entry(self, textvariable=None, show=None):
        return tk.Entry(self.parent, textvariable=textvariable, show=show)

    def frame(self):
        return tk.Frame(self.parent)

    def canvas(self, width, height, bg="white"):
        return tk.Canvas(self.parent, width=width, height=height, bg=bg)

    def listbox(self):
        return tk.Listbox(self.parent)

    def scrollbar(self, orient=tk.VERTICAL, command=None):
        return tk.Scrollbar(self.parent, orient=orient, command=command)

    def menu(self, tearoff=False):
        return tk.Menu(self.parent, tearoff=tearoff)

    def radiobutton(self, text, variable, value):
        return tk.Radiobutton(self.parent, text=text, variable=variable, value=value)

    def checkbutton(self, text, variable):
        return tk.Checkbutton(self.parent, text=text, variable=variable)

    def scale(self, from_, to, orient=tk.HORIZONTAL, variable=None):
        return tk.Scale(self.parent, from_=from_, to=to, orient=orient, variable=variable)

    def spinbox(self, from_, to, textvariable=None):
        return tk.Spinbox(self.parent, from_=from_, to=to, textvariable=textvariable)

    def text(self):
        return tk.Text(self.parent)

    def toplevel(self):
        return tk.Toplevel(self.parent)

    def optionmenu(self, variable, *values):
        return tk.OptionMenu(self.parent, variable, *values)

    def menubutton(self, text):
        return tk.Menubutton(self.parent, text=text)

    def panedwindow(self, orient=tk.HORIZONTAL):
        return tk.PanedWindow(self.parent, orient=orient)

    def labelframe(self, text=""):
        return tk.LabelFrame(self.parent, text=text)


# ============================
#  ttk 完全ラップ
# ============================
class TTK:
    def __init__(self, parent: Window):
        self.parent = parent.window

    def button(self, text, command=None):
        return ttk.Button(self.parent, text=text, command=command)

    def label(self, text):
        return ttk.Label(self.parent, text=text)

    def entry(self, textvariable=None, show=None):
        return ttk.Entry(self.parent, textvariable=textvariable, show=show)

    def combobox(self, values, textvariable=None, state="readonly"):
        return ttk.Combobox(self.parent, values=values, textvariable=textvariable, state=state)

    def progressbar(self, mode="determinate", orient=tk.HORIZONTAL, length=100):
        return ttk.Progressbar(self.parent, mode=mode, orient=orient, length=length)

    def treeview(self, columns, show="headings"):
        tree = ttk.Treeview(self.parent, columns=columns, show=show)
        for col in columns:
            tree.heading(col, text=col)
        return tree

    def notebook(self):
        return ttk.Notebook(self.parent)

    def checkbutton(self, text, variable):
        return ttk.Checkbutton(self.parent, text=text, variable=variable)

    def radiobutton(self, text, variable, value):
        return ttk.Radiobutton(self.parent, text=text, variable=variable, value=value)

    def scale(self, from_, to, orient=tk.HORIZONTAL, variable=None):
        return ttk.Scale(self.parent, from_=from_, to=to, orient=orient, variable=variable)

    def spinbox(self, from_, to, textvariable=None):
        return ttk.Spinbox(self.parent, from_=from_, to=to, textvariable=textvariable)

    def separator(self, orient=tk.HORIZONTAL):
        return ttk.Separator(self.parent, orient=orient)

    def sizegrip(self):
        return ttk.Sizegrip(self.parent)

    def panedwindow(self, orient=tk.HORIZONTAL):
        return ttk.PanedWindow(self.parent, orient=orient)

    def labelframe(self, text=""):
        return ttk.Labelframe(self.parent, text=text)

    def theme_use(self, name=None):
        if name is None:
            return ttk.Style().theme_use()
        else:
            ttk.Style().theme_use(name)


# ============================
#  Canvas 完全ラップ
# ============================
class CanvasAPI:
    def __init__(self, parent: Window, width, height, bg="white"):
        self.canvas = tk.Canvas(parent.window, width=width, height=height, bg=bg)

    def pack(self, **opt):
        self.canvas.pack(**opt)

    def grid(self, **opt):
        self.canvas.grid(**opt)

    def place(self, **opt):
        self.canvas.place(**opt)

    def rect(self, x1, y1, x2, y2, fill=None, outline="black", width=1):
        return self.canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=outline, width=width)

    def oval(self, x1, y1, x2, y2, fill=None, outline="black", width=1):
        return self.canvas.create_oval(x1, y1, x2, y2, fill=fill, outline=outline, width=width)

    def line(self, x1, y1, x2, y2, color="black", width=1, smooth=False):
        return self.canvas.create_line(x1, y1, x2, y2, fill=color, width=width, smooth=smooth)

    def polygon(self, *coords, fill=None, outline="black", width=1):
        return self.canvas.create_polygon(*coords, fill=fill, outline=outline, width=width)

    def arc(self, x1, y1, x2, y2, start=0, extent=90, style=tk.PIESLICE, fill=None, outline="black", width=1):
        return self.canvas.create_arc(x1, y1, x2, y2, start=start, extent=extent,
                                      style=style, fill=fill, outline=outline, width=width)

    def text(self, x, y, text, size=14, color="black", anchor="center"):
        return self.canvas.create_text(x, y, text=text, fill=color, font=("Arial", size), anchor=anchor)

    def image(self, x, y, img, anchor="center"):
        return self.canvas.create_image(x, y, image=img, anchor=anchor)

    def window(self, x, y, widget, anchor="center"):
        return self.canvas.create_window(x, y, window=widget, anchor=anchor)

    def move(self, item, dx, dy):
        self.canvas.move(item, dx, dy)

    def coords(self, item, *coords):
        if coords:
            self.canvas.coords(item, *coords)
        else:
            return self.canvas.coords(item)

    def itemconfig(self, item, **opt):
        self.canvas.itemconfig(item, **opt)

    def delete(self, item):
        self.canvas.delete(item)

    def find_withtag(self, tag):
        return self.canvas.find_withtag(tag)

    def addtag_withtag(self, newtag, tag):
        self.canvas.addtag_withtag(newtag, tag)

    def tag_bind(self, tag, event, callback):
        self.canvas.tag_bind(tag, event, callback)

    def tag_raise(self, tag):
        self.canvas.tag_raise(tag)

    def tag_lower(self, tag):
        self.canvas.tag_lower(tag)


# ============================
#  Dialog ラップ
# ============================
class Dialog:
    def info(self, title, msg):
        messagebox.showinfo(title, msg)

    def warn(self, title, msg):
        messagebox.showwarning(title, msg)

    def error(self, title, msg):
        messagebox.showerror(title, msg)

    def ask_yes_no(self, title, msg):
        return messagebox.askyesno(title, msg)

    def ask_ok_cancel(self, title, msg):
        return messagebox.askokcancel(title, msg)

    def ask_retry_cancel(self, title, msg):
        return messagebox.askretrycancel(title, msg)


# ============================
#  FileDialog ラップ
# ============================
class FileDialog:
    def open_file(self, **opt):
        return filedialog.askopenfilename(**opt)

    def save_file(self, **opt):
        return filedialog.asksaveasfilename(**opt)

    def open_dir(self, **opt):
        return filedialog.askdirectory(**opt)


# ============================
#  Event ラップ
# ============================
class Event:
    def __init__(self, parent: Window):
        self.parent = parent.window

    def bind(self, event, callback):
        self.parent.bind(event, callback)

    def unbind(self, event, funcid=None):
        self.parent.unbind(event, funcid)

    def event_generate(self, sequence, **opt):
        self.parent.event_generate(sequence, **opt)


# ============================
#  Menu 完全ラップ
# ============================
class MenuBar:
    def __init__(self, parent: Window):
        self.root = parent.window
        self.menu = tk.Menu(self.root)
        self.root.config(menu=self.menu)

    def add_menu(self, label):
        m = tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label=label, menu=m)
        return m

    def add_item(self, menu, label, command=None):
        menu.add_command(label=label, command=command)
        return menu

    def add_check(self, menu, label, variable):
        menu.add_checkbutton(label=label, variable=variable)
        return menu

    def add_radio(self, menu, label, variable, value):
        menu.add_radiobutton(label=label, variable=variable, value=value)
        return menu

    def add_separator(self, menu):
        menu.add_separator()
        return menu

    def add_submenu(self, menu, label):
        sub = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label=label, menu=sub)
        return sub


# ============================
#  Timer ラップ
# ============================
class Timer:
    def __init__(self, parent: Window):
        self.parent = parent.window

    def after(self, ms, callback, *args):
        return self.parent.after(ms, callback, *args)

    def after_cancel(self, id_):
        self.parent.after_cancel(id_)


# ============================
#  Image ラップ
# ============================
class ImageLoader:
    def load(self, path):
        return tk.PhotoImage(file=path)

    def subsample(self, img, x, y=None):
        if y is None:
            y = x
        return img.subsample(x, y)

    def zoom(self, img, x, y=None):
        if y is None:
            y = x
        return img.zoom(x, y)


# ============================
#  Custom Titlebar（枠なしウィンドウ）
# ============================
class CustomTitlebar:
    def __init__(self, parent: Window, title="My App"):
        self.parent = parent.window
        parent.window.overrideredirect(True)

        self.bar = tk.Frame(self.parent, bg="#333", height=30)
        self.bar.pack(fill="x")

        self.title = tk.Label(self.bar, text=title, bg="#333", fg="white")
        self.title.pack(side="left", padx=10)

        self.btn_min = tk.Button(self.bar, text="―", bg="#333", fg="white",
                                 relief=tk.FLAT, command=self.minimize)
        self.btn_min.pack(side="right", padx=5)

        self.btn_max = tk.Button(self.bar, text="□", bg="#333", fg="white",
                                 relief=tk.FLAT, command=self.toggle_maximize)
        self.btn_max.pack(side="right", padx=5)

        self.btn_close = tk.Button(self.bar, text="✕", bg="#333", fg="white",
                                   relief=tk.FLAT, command=parent.close)
        self.btn_close.pack(side="right", padx=5)

        self.is_max = False
        self._geom = None

        self.bar.bind("<Button-1>", self.start_move)
        self.bar.bind("<B1-Motion>", self.do_move)

    def start_move(self, e):
        self.x = e.x
        self.y = e.y

    def do_move(self, e):
        self.parent.geometry(f"+{e.x_root - self.x}+{e.y_root - self.y}")

    def minimize(self):
        self.parent.iconify()

    def toggle_maximize(self):
        if not self.is_max:
            self._geom = self.parent.geometry()
            self.parent.state("zoomed")
            self.is_max = True
        else:
            if self._geom:
                self.parent.geometry(self._geom)
            self.is_max = False
