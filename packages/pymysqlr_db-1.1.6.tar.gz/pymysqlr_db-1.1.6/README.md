# pymysqlr-db

Simple Python snippets package for housing rental PyQt6 application generation.

## Installation

To install the package, run:

```bash
pip install pymysqlr-db
```

## Usage

In your Python code, import the package as `pymysqlr_db`.

To generate all files of the application:

```python
import pymysqlr_db
pymysqlr_db.create.all()
```

To generate a specific file (e.g., `main.py`):

```python
import pymysqlr_db
pymysqlr_db.create.main()
```

To view a specific file code in the console (e.g., `models/user.py`):

```python
import pymysqlr_db
pymysqlr_db.show.models_user()
```

### Supported generation methods:
- `create.all()` / `create.main()`
- `create.models_user()` / `create.user()`
- `create.models_booking()` / `create.booking()`
- `create.models_property()` / `create.property()`
- `create.database_repository()` / `create.repository()`
- `create.database_db_txt()` / `create.db_txt()`
- `create.property_widget()`
- `create.property_form_window()`
- `create.properties_window()`
- `create.bookings_window()`
- `create.booking_widget()`
- `create.booking_form_window()`

And corresponding methods on `show` (e.g. `show.main()`).
