from pathlib import Path
import os

_SNIPPETS = {
    'main_py': r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QPushButton, QMessageBox, QApplication, QLabel
from PyQt6.QtGui import QPixmap, QIcon
from PyQt6.QtCore import Qt
from database.repository import Repository
from properties_window import PropertiesWindow
from models.user import User
import sys
import traceback

def exp(a,b,c):
    f = "".join(traceback.format_exception(a,b,c))
    print(f)
    sys.exit(1)

sys.excepthook = exp

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.repo = Repository()

        self.setWindowTitle("Авторизация")
        self.setWindowIcon(QIcon("images/logo.png"))
        self.resize(300, 350)

        main_lay = QVBoxLayout(self)

        self.logo_lbl = QLabel()
        self.logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = QPixmap("images/logo.png")
        if not pix.isNull():
            self.logo_lbl.setPixmap(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            self.logo_lbl.setText("Аренда жилья")
            self.logo_lbl.setStyleSheet("font-size: 20px; font-weight: bold; margin: 10px;")
        main_lay.addWidget(self.logo_lbl)

        self.login = QLineEdit(placeholderText="Логин")
        self.password = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)
        self.en_btn = QPushButton("Войти")
        self.g_btn = QPushButton("Войти как гость")
        self.en_btn.clicked.connect(self.auth)
        self.g_btn.clicked.connect(self.open_guest)

        main_lay.addWidget(self.login)
        main_lay.addWidget(self.password)
        main_lay.addWidget(self.en_btn)
        main_lay.addWidget(self.g_btn)

    def auth(self):
        user = self.repo.find_user(self.login.text(), self.password.text())
        if user: self.open_catalog(user)
        else: QMessageBox.critical(self, "Ошибка", "Такого пользователя нет")

    def open_guest(self):
        self.open_catalog(User.create_guest())

    def open_catalog(self, user):
        self.l = PropertiesWindow(user)
        self.l.show()
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = LoginWindow()
    w.show()
    app.exec()
''',

    'models_user_py': r'''class User:
    def __init__(self, user_id, fio, login, role_name):
        self.user = user_id
        self.fio = fio
        self.login = login
        self.role_name = role_name

    @staticmethod
    def from_db_row(row):
        if not row: return None
        return User(
            user_id=row['user_id'],
            fio=row['fio'],
            login=row['login'],
            role_name=row['role_name']
        )

    @staticmethod
    def create_guest():
        return User(0, "Гость", "guest", "guest")
''',

    'models_booking_py': r'''class Booking:
    def __init__(self, **kwargs):
        for k, v in kwargs.items(): setattr(self, k, v)

    @staticmethod
    def from_db_row(row):
        return Booking(**row) if row else None
''',

    'models_property_py': r'''class Property:
    def __init__(self, **kwargs):
        for k, v in kwargs.items(): setattr(self, k, v)

    @staticmethod
    def from_db_row(row):
        return Property(**row) if row else None
''',

    'database_repository_py': r'''import pymysql
from models.booking import Booking
from models.user import User
from models.property import Property

class Repository:
    def connect_db(self):
        return pymysql.connect(
            host="localhost",
            user="root",
            password="",
            db="housing_rental",
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor
        )

    def find_user(self, login, password):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT u.*, r.role_name
                    FROM users u
                    JOIN roles r ON u.role_id = r.role_id
                    WHERE u.login = %s AND u.password = %s
                """
                cur.execute(sql, (login, password))
                row = cur.fetchone()
                if row: return User.from_db_row(row)
        finally:
            conn.close()

    def get_properties(self, search="", type_name="Все типы", sort="ASC"):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT p.*, c.category_name,
                    t.type_name, l.landlord_name,
                    ip.image_path
                    FROM properties p
                    LEFT JOIN categories c ON p.category_id = c.category_id
                    LEFT JOIN types t ON p.type_id = t.type_id
                    LEFT JOIN landlords l ON p.landlord_id = l.landlord_id
                    LEFT JOIN images ip ON p.image_id = ip.image_id
                    WHERE (
                        p.title LIKE %s OR
                        c.category_name LIKE %s OR
                        t.type_name LIKE %s OR
                        l.landlord_name LIKE %s OR
                        p.description LIKE %s
                    )
                """

                search_param = f'%{search}%'
                params = [search_param] * 5

                if type_name != "Все типы" and type_name != "Все":
                    sql += " AND t.type_name LIKE %s"
                    params.append(type_name)

                sql += f" ORDER BY p.price {sort}"

                cur.execute(sql, params)
                rows = cur.fetchall()
                if rows: return [Property.from_db_row(row) for row in rows]
        finally:
            conn.close()

    def get_categories(self):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT category_name FROM categories")
                return [row['category_name'] for row in cur.fetchall()]
        finally:
            conn.close()

    def get_types(self):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT type_name FROM types")
                return [row['type_name'] for row in cur.fetchall()]
        finally:
            conn.close()

    def get_bookings(self):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT b.booking_id, b.user_id, b.status_id, s.status,
                    b.address, b.booking_date, b.arrival_date,
                    (SELECT property_id FROM booking_properties WHERE booking_id = b.booking_id LIMIT 1) as property_id,
                    GROUP_CONCAT(p.title SEPARATOR ', ') as properties_list
                    FROM bookings b
                    LEFT JOIN statuses s ON b.status_id = s.status_id
                    LEFT JOIN booking_properties bp ON b.booking_id = bp.booking_id
                    LEFT JOIN properties p ON bp.property_id = p.property_id
                    GROUP BY b.booking_id
                    ORDER BY b.booking_date DESC
                """
                cur.execute(sql)
                rows = cur.fetchall()
                if rows: return [Booking.from_db_row(row) for row in rows]
        finally:
            conn.close()

    def delete_booking(self, booking_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM bookings WHERE booking_id = %s", (booking_id,))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def add_booking(self, user_id, status_id, address, booking_date, arrival_date, property_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = "INSERT INTO bookings (user_id, status_id, address, booking_date, arrival_date) VALUES (%s, %s, %s, %s, %s)"
                arr_val = arrival_date if arrival_date else None
                cur.execute(sql, (user_id, status_id, address, booking_date, arr_val))
                booking_id = cur.lastrowid
                
                sql_prop = "INSERT INTO booking_properties (booking_id, property_id) VALUES (%s, %s)"
                cur.execute(sql_prop, (booking_id, property_id))
                
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def update_booking(self, booking_id, user_id, status_id, address, booking_date, arrival_date, property_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = "UPDATE bookings SET user_id=%s, status_id=%s, address=%s, booking_date=%s, arrival_date=%s WHERE booking_id=%s"
                arr_val = arrival_date if arrival_date else None
                cur.execute(sql, (user_id, status_id, address, booking_date, arr_val, booking_id))
                
                cur.execute("DELETE FROM booking_properties WHERE booking_id = %s", (booking_id,))
                sql_prop = "INSERT INTO booking_properties (booking_id, property_id) VALUES (%s, %s)"
                cur.execute(sql_prop, (booking_id, property_id))
                
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def is_property_in_bookings(self, property_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) as cnt FROM booking_properties WHERE property_id = %s", (property_id,))
                row = cur.fetchone()
                return row['cnt'] > 0
        finally:
            conn.close()

    def delete_property(self, property_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM properties WHERE property_id = %s", (property_id,))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def get_or_create_image_id(self, image_path):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT image_id FROM images WHERE image_path = %s", (image_path,))
                row = cur.fetchone()
                if row:
                    return row['image_id']
                cur.execute("INSERT INTO images (image_path) VALUES (%s)", (image_path,))
                conn.commit()
                return cur.lastrowid
        finally:
            conn.close()

    def add_property(self, title, cat_id, type_id, land_id, price, discount, available_rooms, img, desc):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """INSERT INTO properties (title, category_id, type_id, landlord_id, price, discount, available_rooms, image_id, description)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                cur.execute(sql, (title, cat_id, type_id, land_id, price, discount, available_rooms, img, desc))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def update_property(self, property_id, title, cat_id, type_id, land_id, price, discount, available_rooms, img, desc):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    UPDATE properties SET title=%s, category_id=%s, type_id=%s, landlord_id=%s, price=%s, discount=%s,
                    available_rooms=%s, image_id=%s, description=%s WHERE property_id=%s
                """
                cur.execute(sql, (title, cat_id, type_id, land_id, price, discount, available_rooms, img, desc, property_id))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()
''',

    'database_db_txt': r'''create database housing_rental;
use housing_rental;

create table roles (
	role_id int primary key auto_increment,
    role_name varchar(50) not null
);

create table users (
	user_id int primary key auto_increment,
    fio varchar(50) not null,
    login varchar(50) not null,
    password varchar(50) not null,
    role_id int not null,
    foreign key (role_id) references roles (role_id)
);

create table categories (
	category_id int primary key auto_increment,
    category_name varchar(50) not null
);

create table types (
	type_id int primary key auto_increment,
    type_name varchar(50) not null
);

create table landlords (
	landlord_id int primary key auto_increment,
    landlord_name varchar(50) not null
);

create table images (
	image_id int primary key auto_increment,
    image_path text not null
);

create table statuses (
	status_id int primary key auto_increment,
    status varchar(50) not null
);

create table properties (
	property_id int primary key auto_increment,
    title varchar(100) not null,
    category_id int not null,
    type_id int not null,
    landlord_id int not null,
    price decimal(10, 2) not null,
    discount int not null,
    available_rooms int not null,
    image_id int not null,
    description text not null,
    foreign key (category_id) references categories (category_id),
    foreign key (type_id) references types (type_id),
    foreign key (landlord_id) references landlords (landlord_id),
    foreign key (image_id) references images (image_id)
);

create table bookings (
	booking_id int primary key auto_increment,
    user_id int not null,
    status_id int not null,
    address text not null,
    booking_date date not null,
    arrival_date date null,
    foreign key (user_id) references users (user_id),
    foreign key (status_id) references statuses (status_id)
);

create table booking_properties (
	booking_property_id int primary key auto_increment,
    booking_id int not null,
    property_id int not null,
    foreign key (booking_id) references bookings (booking_id) on delete cascade,
    foreign key (property_id) references properties (property_id) on delete cascade
);

INSERT INTO roles (role_name) VALUES
('client'),
('admin'),
('manager');

INSERT INTO users (fio, login, password, role_id) VALUES
('Иванов Иван Иванович', 'client1', 'client1', 1),
('Петров Петр Петрович', 'admin', 'admin123', 2),
('Смирнова Анна Сергеевна', 'manager', 'manager123', 3),
('Сидоров Сидор Алексеевич', 'client2', 'client2', 1);

INSERT INTO categories (category_name) VALUES
('Квартира'),
('Дом/Коттедж'),
('Студия'),
('Комната');

INSERT INTO types (type_name) VALUES
('Комфорт'),
('Люкс'),
('Семейный'),
('Стандарт');

INSERT INTO landlords (landlord_name) VALUES
('ИП Иванов А.В.'),
('ООО Уютный Дом'),
('ИП Смирнова Е.Н.');

INSERT INTO images (image_path) VALUES
('/images/apartment.png'),
('/images/house.png'),
('/images/studio.png'),
('/images/room.png');

INSERT INTO statuses (status) VALUES
('Новое'),
('Подтверждено'),
('В аренде'),
('Завершено'),
('Отменено');

INSERT INTO properties (title, category_id, type_id, landlord_id, price, discount, available_rooms, image_id, description) VALUES
('1-комнатная квартира с видом на парк', 1, 1, 1, 3500.00, 10, 2, 1, 'Просторная квартира в самом центре города. Есть всё необходимое для проживания.'),
('Загородный коттедж с баней', 2, 2, 2, 12000.00, 0, 1, 2, 'Уютный двухэтажный коттедж для семейного отдыха у озера. Мангал, баня, терраса.'),
('Современная студия в стиле лофт', 3, 3, 3, 2500.00, 20, 5, 3, 'Компактная студия со свежим ремонтом. Быстрый интернет, новая мебель.'),
('Уютная комната в коммунальной квартире', 4, 4, 1, 1200.00, 5, 0, 4, 'Светлая комната в историческом центре города. Спокойные соседи.');

INSERT INTO bookings (user_id, status_id, address, booking_date, arrival_date) VALUES
(1, 1, '+79991234567', '2026-05-24', NULL),
(4, 4, '+79119876543', '2026-05-15', '2026-05-20'),
(1, 2, '+79001112233', '2026-05-26', '2026-06-05');

INSERT INTO booking_properties (booking_id, property_id) VALUES
(1, 1),
(1, 3),
(2, 4),
(3, 2);
''',

    'property_widget_py': r'''from PyQt6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMessageBox
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt
from database.repository import Repository

class PropertyWidget(QFrame):
    def __init__(self, p, user, delete_signal):
        super().__init__()
        self.p = p
        self.user = user
        self.role = user.role_name.lower()
        self.delete_signal = delete_signal
        self.repo = Repository()

        shape = QFrame.Shape.Box
        self.setFrameShape(shape)
        self.setFixedHeight(180)

        main_lay = QHBoxLayout(self)
        main_lay.setSpacing(15)

        img_lbl = QLabel()
        img_lbl.setFrameShape(shape)
        img_lbl.setFixedSize(140, 140)
        img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        fname = f"data/images/{p.image_path}" if p.image_path else "picture.png"
        if p.image_path and p.image_path.startswith("/"):
            fname = f"data/images{p.image_path}"
        pix = QPixmap(fname)
        if pix.isNull(): 
            pix = QPixmap("data/images/picture.png")
            if pix.isNull():
                pix = QPixmap("images/picture.png")

        img_lbl.setPixmap(pix.scaled(130, 130, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        main_lay.addWidget(img_lbl)

        info_fr = QFrame()
        info_fr.setFrameShape(shape)
        info_lay = QVBoxLayout(info_fr)
        info_lay.setContentsMargins(10, 5, 10, 5)
        info_lay.setSpacing(3)

        info_lay.addWidget(QLabel(f"<b>Название: {p.title}</b> | {p.category_name}"))
        info_lay.addWidget(QLabel(f"Тип: {p.type_name} | Арендодатель: {p.landlord_name}"))
        
        desc_lbl = QLabel(f"Описание: {p.description}")
        desc_lbl.setWordWrap(True)
        info_lay.addWidget(desc_lbl)
        
        info_lay.addWidget(QLabel(f"Доступно комнат/объектов: {p.available_rooms} | Скидка: {p.discount}%"))

        if p.discount > 0:
            new_price = float(p.price) * (1 - int(p.discount) / 100)
            price_text = f"Цена за сутки: <s style='color:red'>{p.price}</s> <b>{new_price:.2f} руб.</b>"
        else:
            price_text = f"<b>Цена за сутки: {p.price} руб.</b>"
        info_lay.addWidget(QLabel(price_text))
        
        main_lay.addWidget(info_fr, stretch=1)

        disc_fr = QFrame()
        disc_fr.setFrameShape(shape)
        disc_fr.setFixedWidth(200)
        disc_lay = QVBoxLayout(disc_fr)
        disc_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        disc_lay.addWidget(QLabel(f"Действующая скидка: {p.discount}%"))
        if self.role == "admin":
            self.edit_btn = QPushButton("Редактировать")
            self.edit_btn.clicked.connect(self.open_edit_form)
            disc_lay.addWidget(self.edit_btn)

            self.del_btn = QPushButton("Удалить")
            self.del_btn.clicked.connect(self.handle_delete)
            disc_lay.addWidget(self.del_btn)
        elif self.role == "client":
            self.book_btn = QPushButton("Забронировать")
            self.book_btn.clicked.connect(self.handle_booking)
            disc_lay.addWidget(self.book_btn)

        main_lay.addWidget(disc_fr)

        if p.available_rooms == 0:
            self.setStyleSheet("background-color: #d0e8f2; color: #0d47a1;")
        elif p.discount > 15:
            self.setStyleSheet("background-color: #2eb857; color: white;")

    def handle_booking(self):
        if self.role == "guest":
            QMessageBox.warning(None, "Авторизация", "Для бронирования необходимо авторизоваться!")
            return
        from booking_form_window import BookingFormWindow
        self.booking_form = BookingFormWindow(
            booking=None,
            callback=self.delete_signal,
            client_mode_property_id=self.p.property_id,
            client_user_id=self.user.user
        )
        self.booking_form.show()

    def handle_delete(self):
        if self.repo.is_property_in_bookings(self.p.property_id):
            QMessageBox.warning(None, "Предупреждение", "Нельзя удалить, так как этот объект используется в бронированиях!")
            return

        ans = QMessageBox.question(None, "Подтверждение", "Вы точно хотите удалить этот объект недвижимости?")
        if ans == QMessageBox.StandardButton.Yes:
            res = self.repo.delete_property(self.p.property_id)
            if res == "success":
                QMessageBox.information(None, "Успех", "Объект был удален")
                self.delete_signal()
            else:
                QMessageBox.critical(None, "Ошибка", f"Не удалось удалить объект: {res}")

    def open_edit_form(self):
        from property_form_window import PropertyFormWindow
        self.form = PropertyFormWindow(property_item=self.p, callback=self.delete_signal)
        self.form.show()
''',

    'property_form_window_py': r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QFileDialog
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QIcon
from database.repository import Repository
import os
import shutil

class PropertyFormWindow(QWidget):
    _instance = None

    def __init__(self, property_item=None, callback=None):
        if PropertyFormWindow._instance is not None and PropertyFormWindow._instance.isVisible():
            QMessageBox.warning(None, "Предупреждение", "Окно добавления или редактирования уже открыто!")
            PropertyFormWindow._instance.raise_()
            PropertyFormWindow._instance.activateWindow()
            QTimer.singleShot(0, self.close)
            return

        super().__init__()
        PropertyFormWindow._instance = self
        self.property_item = property_item
        self.callback = callback
        self.repo = Repository()

        self.setWindowTitle("Редактировать объект" if property_item else "Добавить объект")
        self.setWindowIcon(QIcon("images/logo.png"))
        self.resize(350, 450)

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        self.fields = {
            "title": QLineEdit(placeholderText="Название (например, 1-к квартира)"),
            "category_id": QLineEdit(placeholderText="ID Категории жилья (1, 2, 3...)"),
            "type_id": QLineEdit(placeholderText="ID Типа (1, 2, 3...)"),
            "landlord_id": QLineEdit(placeholderText="ID Арендодателя (1, 2, 3...)"),
            "price": QLineEdit(placeholderText="Цена за сутки (руб.)"),
            "discount": QLineEdit(placeholderText="Скидка %"),
            "available_rooms": QLineEdit(placeholderText="Количество свободных объектов"),
            "description": QLineEdit(placeholderText="Описание объекта")
        }

        self.selected_file_path = None
        self.selected_image_id = None

        for key, widget in self.fields.items():
            if key == "description":
                self.photo_lay = QHBoxLayout()
                self.photo_btn = QPushButton("Выбрать фото")
                self.photo_label = QLabel("Файл не выбран")
                self.photo_btn.clicked.connect(self.select_photo)
                self.photo_lay.addWidget(self.photo_btn)
                self.photo_lay.addWidget(self.photo_label)
                lay.addLayout(self.photo_lay)
            lay.addWidget(widget)

        if self.property_item:
            for key, widget in self.fields.items():
                widget.setText(str(getattr(self.property_item, key, '')))
            if getattr(self.property_item, "image_path", None):
                self.photo_label.setText(os.path.basename(self.property_item.image_path))
                self.selected_image_id = getattr(self.property_item, "image_id", None)

        self.btn = QPushButton("Сохранить")
        self.btn.clicked.connect(self.save)
        lay.addWidget(self.btn)

    def select_photo(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Выбрать фото", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)"
        )
        if file_path:
            self.selected_file_path = file_path
            self.photo_label.setText(os.path.basename(file_path))

    def save(self):
        d = {k: w.text().strip() for k, w in self.fields.items()}

        if not d["title"] or not d["price"]:
            QMessageBox.warning(self, "Валидация", "Название и Цена обязательны!")
            return

        try:
            price_val = float(d["price"])
            discount_val = int(d["discount"]) if d["discount"] else 0
            available_rooms_val = int(d["available_rooms"]) if d["available_rooms"] else 0

            if price_val < 0 or discount_val < 0 or discount_val > 100 or available_rooms_val < 0:
                raise ValueError()
        except ValueError:
            QMessageBox.warning(self, "Валидация", "Проверьте корректность числовых полей!")
            return

        image_id = self.selected_image_id

        if self.selected_file_path:
            if self.property_item and getattr(self.property_item, "image_path", None):
                old_path = self.property_item.image_path
                if old_path and "picture.png" not in old_path:
                    rel_path = old_path.lstrip("/")
                    full_old_path = os.path.join("data", "images", rel_path)
                    if os.path.exists(full_old_path):
                        try:
                            os.remove(full_old_path)
                        except Exception as e:
                            print(f"Failed to delete old image: {e}")

            dest_dir = os.path.join("data", "images", "images")
            os.makedirs(dest_dir, exist_ok=True)

            default_dir = os.path.join("data", "images")
            os.makedirs(default_dir, exist_ok=True)
            if not os.path.exists(os.path.join(default_dir, "picture.png")):
                if os.path.exists("images/picture.png"):
                    shutil.copy("images/picture.png", os.path.join(default_dir, "picture.png"))

            filename = os.path.basename(self.selected_file_path)
            dest_file_path = os.path.join(dest_dir, filename)
            try:
                shutil.copy(self.selected_file_path, dest_file_path)
            except Exception as e:
                QMessageBox.warning(self, "Ошибка копирования", f"Не удалось скопировать фото: {e}")
                return

            db_image_path = f"/images/{filename}"
            image_id = self.repo.get_or_create_image_id(db_image_path)

        if not image_id:
            image_id = self.repo.get_or_create_image_id("picture.png")

        if self.property_item:
            res = self.repo.update_property(
                self.property_item.property_id, d["title"], d["category_id"], d["type_id"],
                d["landlord_id"], d["price"], d["discount"], d["available_rooms"],
                image_id, d["description"]
            )
        else:
            res = self.repo.add_property(
                d["title"], d["category_id"], d["type_id"],
                d["landlord_id"], d["price"], d["discount"], d["available_rooms"],
                image_id, d["description"]
            )

        if res == "success":
            QMessageBox.information(self, "Успех", "Данные успешно сохранены!")
            if self.callback:
                self.callback()
            self.close()
        else:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось сохранить: {res}")

    def closeEvent(self, event):
        if PropertyFormWindow._instance == self:
            PropertyFormWindow._instance = None
        event.accept()
''',

    'properties_window_py': r'''from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit, QScrollArea, QComboBox, QHBoxLayout, QVBoxLayout, QPushButton
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from database.repository import Repository
from property_widget import PropertyWidget
from bookings_window import BookingsWindow

class PropertiesWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user.role_name.lower()
        self.repo = Repository()

        self.setWindowTitle("Каталог жилья")
        self.setWindowIcon(QIcon("images/logo.png"))
        self.resize(1100, 700)

        main_lay = QVBoxLayout(self)

        header = QHBoxLayout()
        self.info = QLabel(f"Вы зашли как {user.fio} | Роль {user.role_name}")
        self.ex_btn = QPushButton("Выйти")
        self.ex_btn.clicked.connect(self.logout)
        header.addWidget(self.info)
        header.addStretch()
        header.addWidget(self.ex_btn)
        if self.role == "admin":
            self.add_btn = QPushButton("Добавить объект")
            self.add_btn.clicked.connect(self.open_add_form)
            header.addWidget(self.add_btn)

        if self.role in ["admin", "manager"]:
            self.ord_btn = QPushButton("Бронирования")
            self.ord_btn.clicked.connect(self.show_bookings)
            header.addWidget(self.ord_btn)
        main_lay.addLayout(header)

        controls = QHBoxLayout()

        if self.role in ['admin', 'manager']:
            self.search_lbl = QLabel("Поиск:")
            self.search_bar = QLineEdit()
            self.search_bar.textChanged.connect(self.load_data)
            controls.addWidget(self.search_lbl)
            controls.addWidget(self.search_bar)

            self.type_lbl = QLabel("Тип:")
            self.type_bar = QComboBox()
            self.type_bar.addItem("Все типы")
            self.type_bar.addItems(self.repo.get_types())
            self.type_bar.currentTextChanged.connect(self.load_data)
            controls.addWidget(self.type_lbl)
            controls.addWidget(self.type_bar)

            self.sort_lbl = QLabel("Сортировка цен:")
            self.sort_bar = QComboBox()
            self.sort_bar.addItems(["По возрастанию", "По убыванию"])
            self.sort_bar.currentIndexChanged.connect(self.load_data)
            controls.addWidget(self.sort_lbl)
            controls.addWidget(self.sort_bar)

            main_lay.addLayout(controls)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.lay_list = QVBoxLayout(self.container)
        self.lay_list.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.scroll.setWidget(self.container)
        main_lay.addWidget(self.scroll)

        self.load_data()

    def load_data(self):
        while self.lay_list.count():
            item = self.lay_list.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        search = ""
        type_name = "Все типы"
        sort = "ASC"

        if self.role in ['admin', 'manager']:
            search = self.search_bar.text()
            type_name = self.type_bar.currentText()
            if self.sort_bar.currentIndex() == 1:
                sort = "DESC"

        properties = self.repo.get_properties(search, type_name, sort) or []

        for p in properties:
            card = PropertyWidget(p, self.user, self.load_data)
            self.lay_list.addWidget(card)

    def logout(self):
        from main import LoginWindow
        self.close()
        self.i = LoginWindow()
        self.i.show()

    def show_bookings(self):
        self.close()
        self.o = BookingsWindow(self.user)
        self.o.show()

    def open_add_form(self):
        from property_form_window import PropertyFormWindow
        self.form = PropertyFormWindow(property_item=None, callback=self.load_data)
        self.form.show()
''',

    'bookings_window_py': r'''from PyQt6.QtWidgets import QWidget, QLabel, QScrollArea, QHBoxLayout, QVBoxLayout, QPushButton
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from database.repository import Repository
from booking_widget import BookingWidget

class BookingsWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user.role_name.lower()
        self.repo = Repository()

        self.setWindowTitle("Список бронирований")
        self.setWindowIcon(QIcon("images/logo.png"))
        self.resize(1100, 700)

        main_lay = QVBoxLayout(self)

        header = QHBoxLayout()
        self.ex_btn = QPushButton("Назад")
        self.ex_btn.clicked.connect(self.exit)
        header.addWidget(self.ex_btn)
        header.addStretch()
        main_lay.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.lay_list = QVBoxLayout(self.container)
        self.lay_list.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.scroll.setWidget(self.container)
        main_lay.addWidget(self.scroll)

        self.load_bookings()

    def load_bookings(self):
        while self.lay_list.count():
            item = self.lay_list.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        bookings = self.repo.get_bookings() or []

        for o in bookings:
            card = BookingWidget(o, self.user, self.load_bookings)
            self.lay_list.addWidget(card)

    def exit(self):
        from properties_window import PropertiesWindow
        self.close()
        self.i = PropertiesWindow(self.user)
        self.i.show()
''',

    'booking_widget_py': r'''from PyQt6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMessageBox
from PyQt6.QtCore import Qt
from database.repository import Repository

class BookingWidget(QFrame):
    def __init__(self, booking, user, callback):
        super().__init__()
        self.booking = booking
        self.user = user
        self.role = user.role_name.lower()
        self.callback = callback
        self.repo = Repository()

        shape = QFrame.Shape.Box
        self.setFrameShape(shape)
        self.setFixedHeight(180)

        main_lay = QHBoxLayout(self)
        main_lay.setSpacing(15)

        info_fr = QFrame()
        info_fr.setFrameShape(shape)
        info_lay = QVBoxLayout(info_fr)

        info_lay.addWidget(QLabel(f"<b>Номер бронирования: {booking.booking_id}</b>"))
        info_lay.addWidget(QLabel(f"Статус бронирования: {booking.status}"))
        info_lay.addWidget(QLabel(f"Телефон клиента: {booking.address}"))
        info_lay.addWidget(QLabel(f"Дата создания заявки: {booking.booking_date}"))
        info_lay.addWidget(QLabel(f"Выбранное жилье: {booking.properties_list}"))
        main_lay.addWidget(info_fr, stretch=1)

        disc_fr = QFrame()
        disc_fr.setFrameShape(shape)
        disc_fr.setFixedWidth(220)
        disc_lay = QVBoxLayout(disc_fr)
        disc_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        arrival = booking.arrival_date if booking.arrival_date else 'Не назначена'
        lbl = QLabel(f"<b>Дата выезда</b><br>(окончания аренды):<br><span style='color: #0d47a1; font-weight: bold;'>{arrival}</span>")
        lbl.setWordWrap(True)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        disc_lay.addWidget(lbl)

        if self.role == "admin":
            self.edit_btn = QPushButton("Редактировать")
            self.edit_btn.clicked.connect(self.open_edit_form)
            disc_lay.addWidget(self.edit_btn)

            self.del_btn = QPushButton("Удалить")
            self.del_btn.clicked.connect(self.handle_delete)
            disc_lay.addWidget(self.del_btn)

        main_lay.addWidget(disc_fr)

    def handle_delete(self):
        ans = QMessageBox.question(None, "Подтверждение", "Вы точно хотите удалить это бронирование?")
        if ans == QMessageBox.StandardButton.Yes:
            res = self.repo.delete_booking(self.booking.booking_id)
            if res == "success":
                QMessageBox.information(None, "Успех", "Бронирование было удалено")
                self.callback()
            else:
                QMessageBox.critical(None, "Ошибка", f"Не удалось удалить бронирование: {res}")

    def open_edit_form(self):
        from booking_form_window import BookingFormWindow
        self.form = BookingFormWindow(booking=self.booking, callback=self.callback)
        self.form.show()
''',

    'booking_form_window_py': r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QPushButton, QMessageBox, QLabel
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QIcon
from database.repository import Repository
import datetime

class BookingFormWindow(QWidget):
    _instance = None

    def __init__(self, booking=None, callback=None, client_mode_property_id=None, client_user_id=None):
        if BookingFormWindow._instance is not None and BookingFormWindow._instance.isVisible():
            QMessageBox.warning(None, "Предупреждение", "Окно работы с заказом уже открыто!")
            BookingFormWindow._instance.raise_()
            BookingFormWindow._instance.activateWindow()
            QTimer.singleShot(0, self.close)
            return

        super().__init__()
        BookingFormWindow._instance = self
        self.booking = booking
        self.callback = callback
        self.repo = Repository()
        
        self.client_mode = (client_mode_property_id is not None)
        self.client_property_id = client_mode_property_id
        self.client_user_id = client_user_id

        self.setWindowTitle("Редактировать бронирование" if booking else "Создать бронирование")
        self.setWindowIcon(QIcon("images/logo.png"))
        self.resize(350, 400)

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        today_str = datetime.date.today().strftime("%Y-%m-%d")

        self.fields = {}
        
        if self.client_mode:
            self.fields = {
                "address": QLineEdit(placeholderText="Контактный телефон"),
                "booking_date": QLineEdit(today_str, placeholderText="Дата заезда (ГГГГ-ММ-ДД)"),
                "arrival_date": QLineEdit(placeholderText="Дата выезда (ГГГГ-ММ-ДД, не обязательно)")
            }
            lay.addWidget(QLabel(f"<b>Оформление бронирования</b>"))
            lay.addWidget(QLabel(f"ID Выбранного объекта: {self.client_property_id}"))
        else:
            self.fields = {
                "user_id": QLineEdit(placeholderText="ID Клиента"),
                "status_id": QLineEdit(placeholderText="ID Статуса (1-Новое, 2-Подтверждено...)"),
                "address": QLineEdit(placeholderText="Телефон клиента"),
                "booking_date": QLineEdit(today_str, placeholderText="Дата заезда (ГГГГ-ММ-ДД)"),
                "arrival_date": QLineEdit(placeholderText="Дата выезда (ГГГГ-ММ-ДД, не обязательно)"),
                "property_id": QLineEdit(placeholderText="ID Объекта недвижимости")
            }

        for widget in self.fields.values():
            lay.addWidget(widget)

        if self.booking and not self.client_mode:
            for key, widget in self.fields.items():
                val = getattr(self.booking, key, '')
                if val is None:
                    val = ''
                widget.setText(str(val))

        self.btn = QPushButton("Забронировать" if self.client_mode else "Сохранить")
        self.btn.clicked.connect(self.save)
        lay.addWidget(self.btn)

    def save(self):
        d = {k: w.text().strip() for k, w in self.fields.items()}

        if not d["address"] or not d["booking_date"]:
            QMessageBox.warning(self, "Валидация", "Телефон и Дата заезда обязательны!")
            return

        try:
            datetime.datetime.strptime(d["booking_date"], "%Y-%m-%d")
            if d["arrival_date"]:
                datetime.datetime.strptime(d["arrival_date"], "%Y-%m-%d")
        except ValueError:
            QMessageBox.warning(self, "Валидация", "Неверный формат даты! Используйте ГГГГ-ММ-ДД.")
            return

        if self.client_mode:
            res = self.repo.add_booking(
                user_id=self.client_user_id,
                status_id=1,
                address=d["address"],
                booking_date=d["booking_date"],
                arrival_date=d["arrival_date"],
                property_id=self.client_property_id
            )
        else:
            if not d["user_id"] or not d["status_id"] or not d["property_id"]:
                QMessageBox.warning(self, "Валидация", "ID Клиента, ID Статуса и ID Объекта обязательны!")
                return
            
            try:
                user_id_val = int(d["user_id"])
                status_id_val = int(d["status_id"])
                property_id_val = int(d["property_id"])
            except ValueError:
                QMessageBox.warning(self, "Валидация", "ID Клиента, Статуса и Объекта должны быть числами!")
                return

            if self.booking:
                res = self.repo.update_booking(
                    self.booking.booking_id, user_id_val, status_id_val,
                    d["address"], d["booking_date"], d["arrival_date"], property_id_val
                )
            else:
                res = self.repo.add_booking(
                    user_id_val, status_id_val, d["address"],
                    d["booking_date"], d["arrival_date"], property_id_val
                )

        if res == "success":
            msg = "Бронирование успешно оформлено!" if self.client_mode else "Данные бронирования успешно сохранены!"
            QMessageBox.information(self, "Успех", msg)
            if self.callback:
                self.callback()
            self.close()
        else:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось сохранить бронирование: {res}")

    def closeEvent(self, event):
        if BookingFormWindow._instance == self:
            BookingFormWindow._instance = None
        event.accept()
'''
}

_FILES = {
    'main_py': 'main.py',
    'models_user_py': 'models/user.py',
    'models_booking_py': 'models/booking.py',
    'models_property_py': 'models/property.py',
    'database_repository_py': 'database/repository.py',
    'database_db_txt': 'database/db.txt',
    'property_widget_py': 'property_widget.py',
    'property_form_window_py': 'property_form_window.py',
    'properties_window_py': 'properties_window.py',
    'bookings_window_py': 'bookings_window.py',
    'booking_widget_py': 'booking_widget.py',
    'booking_form_window_py': 'booking_form_window.py'
}

def _normalize_key(name):
    return name.replace('/', '_').replace('\\', '_').replace('.', '_')

def _write_file(filename, text):
    path = Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print(f"Создан файл: {filename}")
    return str(path)

def create_file(name):
    key = _normalize_key(name)
    if key in _FILES:
        return _write_file(_FILES[key], _SNIPPETS[key])
    else:
        available = ', '.join(_FILES.values())
        print(f"Ошибка: Файл '{name}' не найден. Доступные файлы: {available}")
        return None

def show_file(name):
    key = _normalize_key(name)
    if key in _FILES:
        print(f"--- Код файла: {_FILES[key]} ---")
        print(_SNIPPETS[key])
        print("-" * 40)
    else:
        available = ', '.join(_FILES.values())
        print(f"Ошибка: Файл '{name}' не найден. Доступные файлы: {available}")

def create_all():
    files = []
    for name, filename in _FILES.items():
        files.append(_write_file(filename, _SNIPPETS[name]))

    # Создаем папки для картинок
    os.makedirs('images', exist_ok=True)
    os.makedirs('data/images/images', exist_ok=True)

    # Вспомогательная функция для создания цветного изображения
    def make_image(path, color_hex):
        if not os.path.exists(path):
            try:
                from PyQt6.QtGui import QPixmap, QColor
                from PyQt6.QtCore import Qt
                from PyQt6.QtWidgets import QApplication
                
                import sys
                app = QApplication.instance()
                if not app:
                    app = QApplication(sys.argv)
                    
                p = QPixmap(200, 200)
                p.fill(QColor(color_hex))
                p.save(path)
                print(f"Создан плейсхолдер: {path}")
            except Exception as e:
                with open(path, 'wb') as f:
                    f.write(b'')
                print(f"Создан пустой файл (ошибка QPixmap): {path} ({e})")

    # Создаем необходимые изображения-заглушки
    make_image('images/logo.png', '#0d47a1')
    make_image('images/picture.png', '#d3d3d3')
    make_image('data/images/picture.png', '#d3d3d3')
    
    make_image('data/images/images/apartment.png', '#ff9999')
    make_image('data/images/images/house.png', '#99ff99')
    make_image('data/images/images/studio.png', '#9999ff')
    make_image('data/images/images/room.png', '#ffff99')

    return files


class CreateHelper:
    def __call__(self, name):
        return create_file(name)

    def all(self):
        return create_all()

    def main(self):
        return create_file('main.py')

    def models_user(self):
        return create_file('models/user.py')

    def user(self):
        return self.models_user()

    def models_booking(self):
        return create_file('models/booking.py')

    def booking(self):
        return self.models_booking()

    def models_property(self):
        return create_file('models/property.py')

    def property(self):
        return self.models_property()

    def database_repository(self):
        return create_file('database/repository.py')

    def repository(self):
        return self.database_repository()

    def database_db_txt(self):
        return create_file('database/db.txt')

    def db_txt(self):
        return self.database_db_txt()

    def property_widget(self):
        return create_file('property_widget.py')

    def property_form_window(self):
        return create_file('property_form_window.py')

    def properties_window(self):
        return create_file('properties_window.py')

    def bookings_window(self):
        return create_file('bookings_window.py')

    def booking_widget(self):
        return create_file('booking_widget.py')

    def booking_form_window(self):
        return create_file('booking_form_window.py')


class ShowHelper:
    def __call__(self, name):
        return show_file(name)

    def main(self):
        return show_file('main.py')

    def models_user(self):
        return show_file('models/user.py')

    def user(self):
        return self.models_user()

    def models_booking(self):
        return show_file('models/booking.py')

    def booking(self):
        return self.models_booking()

    def models_property(self):
        return show_file('models/property.py')

    def property(self):
        return self.models_property()

    def database_repository(self):
        return show_file('database/repository.py')

    def repository(self):
        return self.database_repository()

    def database_db_txt(self):
        return show_file('database/db.txt')

    def db_txt(self):
        return self.database_db_txt()

    def property_widget(self):
        return show_file('property_widget.py')

    def property_form_window(self):
        return show_file('property_form_window.py')

    def properties_window(self):
        return show_file('properties_window.py')

    def bookings_window(self):
        return show_file('bookings_window.py')

    def booking_widget(self):
        return show_file('booking_widget.py')

    def booking_form_window(self):
        return show_file('booking_form_window.py')


create = CreateHelper()
show = ShowHelper()

if __name__ == '__main__':
    create_all()
    print("Все файлы успешно сгенерированы!")
