"""Auto-generated from ALETHEIA data — do not edit manually"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

@dataclass
class CompoundCrossrefs:
    cas: str
    pubchem_cid: int | str
    inchi: str
    inchi_key: str
    smiles: str
    ec: Optional[str] = None
    chebi_id: Optional[str] = None
    drugbank_id: Optional[str] = None
    wikidata_qid: Optional[str] = None
    unii: Optional[str] = None
    dtxsid: Optional[str] = None
    epa_preferred_name: Optional[str] = None
    echa_ec: Optional[str] = None
    dtxcid: Optional[str] = None
    wikipedia_article: Optional[str] = None
    chembl_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundCrossrefs:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundIdentity:
    molecular_formula: str
    molecular_weight: float | str
    iupac_name: str
    synonyms: list[str]
    synonym_count: int
    smiles: str
    exact_mass: Optional[float | str] = None
    common_name: Optional[str] = None
    cas_number: Optional[str] = None
    monoisotopic_mass: Optional[float] = None
    inchi: Optional[str] = None
    common_synonyms: Optional[list[str]] = None
    pubmed_count: Optional[int] = None
    inchi_key: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundIdentity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundProperties:
    chemical_properties: CompoundPropertiesChemicalProperties
    physical_properties: CompoundPropertiesPhysicalProperties
    environmental_fate: CompoundPropertiesEnvironmentalFate
    biological_half_life: CompoundPropertiesBiologicalHalfLife
    physical_state: Optional[str] = None
    color: Optional[str] = None
    odor: Optional[str] = None
    solubility: Optional[CompoundPropertiesSolubility] = None
    melting_point: Optional[CompoundPropertiesMeltingPoint] = None
    hlb: Optional[float] = None
    persistence: Optional[CompoundPropertiesPersistence] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundProperties:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesSolubility:
    water: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesSolubility:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesMeltingPoint:
    value: int
    unit: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesMeltingPoint:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesChemicalProperties:
    molecular_formula: str
    molecular_weight: float | str
    exact_mass: Optional[float | str] = None
    tpsa: Optional[float] = None
    complexity: Optional[float | int] = None
    h_bond_donor_count: Optional[int] = None
    h_bond_acceptor_count: Optional[int] = None
    rotatable_bond_count: Optional[int] = None
    pka: Optional[list[CompoundPropertiesChemicalPropertiesPkaItem]] = None
    log_kow: Optional[float] = None
    bcf: Optional[float] = None
    koc: Optional[float] = None
    biodegradation_half_life_days: Optional[float] = None
    ready_biodegradable: Optional[bool] = None
    fish_biotrans_halflife_days: Optional[float] = None
    log_d_7_4: Optional[float] = None
    log_koa: Optional[float] = None
    aoh_rate: Optional[CompoundPropertiesChemicalPropertiesAohRate] = None
    bcf_experimental: Optional[CompoundPropertiesChemicalPropertiesBcfExperimental] = None
    baf_experimental: Optional[CompoundPropertiesChemicalPropertiesBafExperimental] = None
    koc_experimental: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesChemicalProperties:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesChemicalPropertiesPkaItem:
    value: float
    type_: str
    source: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesChemicalPropertiesPkaItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesChemicalPropertiesAohRate:
    value: float
    unit: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesChemicalPropertiesAohRate:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesChemicalPropertiesBcfExperimental:
    value: float
    unit: str
    n: int
    method: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesChemicalPropertiesBcfExperimental:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesChemicalPropertiesBafExperimental:
    value: float
    unit: str
    n: int
    method: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesChemicalPropertiesBafExperimental:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesPhysicalProperties:
    melting_point_c: Optional[float] = None
    boiling_point_c: Optional[float] = None
    water_solubility: Optional[str] = None
    vapor_pressure: Optional[str] = None
    density: Optional[str] = None
    henry_law_constant: Optional[str] = None
    flash_point_c: Optional[float] = None
    density_g_per_ml: Optional[str] = None
    xlogp3: Optional[float] = None
    tpsa: Optional[float] = None
    complexity: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesPhysicalProperties:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFate:
    bioaccumulation_potential: CompoundPropertiesEnvironmentalFateBioaccumulationPotential | str
    persistence: CompoundPropertiesEnvironmentalFatePersistence | str
    biodegradation: CompoundPropertiesEnvironmentalFateBiodegradation | str
    _derivation: Optional[CompoundPropertiesEnvironmentalFateDerivation] = None
    soil_mobility: Optional[CompoundPropertiesEnvironmentalFateSoilMobility] = None
    volatilization: Optional[CompoundPropertiesEnvironmentalFateVolatilization] = None
    photodegradation: Optional[dict[str, Any]] = None
    hydrolysis: Optional[dict[str, Any]] = None
    transport_pathways: Optional[list[str]] = None
    environmental_concentrations: Optional[dict[str, Any]] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFate:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFateBioaccumulationPotential:
    classification: str
    notes: str
    source: str
    data_quality: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFateBioaccumulationPotential:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFatePersistence:
    classification: str
    evidence: str
    source: str
    data_quality: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFatePersistence:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFateBiodegradation:
    classification: str
    notes: str
    source: str
    data_quality: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFateBiodegradation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFateDerivation:
    method: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFateDerivation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFateSoilMobility:
    classification: str
    notes: str
    data_quality: str
    source: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFateSoilMobility:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesEnvironmentalFateVolatilization:
    classification: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesEnvironmentalFateVolatilization:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesBiologicalHalfLife:
    value: str
    compartment: str
    source: str
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesBiologicalHalfLife:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundPropertiesPersistence:
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundPropertiesPersistence:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundHazardProfile:
    acute_toxicity: CompoundHazardProfileAcuteToxicity
    skin_sensitization: CompoundHazardProfileSkinSensitization
    eye_irritation: CompoundHazardProfileEyeIrritation
    environmental: CompoundHazardProfileEnvironmental

    @classmethod
    def from_dict(cls, data: dict) -> CompoundHazardProfile:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundHazardProfileAcuteToxicity:
    oral_ld50_rat_mg_kg: int
    dermal_ld50_rat_mg_kg: int
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundHazardProfileAcuteToxicity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundHazardProfileSkinSensitization:
    classification: str
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundHazardProfileSkinSensitization:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundHazardProfileEyeIrritation:
    classification: str
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundHazardProfileEyeIrritation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundHazardProfileEnvironmental:
    aquatic_toxicity: str
    biodegradability: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundHazardProfileEnvironmental:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafety:
    contexts: CompoundSafetyContexts
    vulnerable_populations: CompoundSafetyVulnerablePopulations | list[Any]
    endocrine_disruption: CompoundSafetyEndocrineDisruption
    carcinogenicity: CompoundSafetyCarcinogenicity
    ghs: CompoundSafetyGhs
    skin_sensitization: CompoundSafetySkinSensitization
    dose_response: CompoundSafetyDoseResponse
    exposure_limits: CompoundSafetyExposureLimits
    biomonitoring: Optional[CompoundSafetyBiomonitoring] = None
    mixture_effects: Optional[CompoundSafetyMixtureEffects] = None
    iris: Optional[CompoundSafetyIris] = None
    genotoxicity: Optional[CompoundSafetyGenotoxicity] = None
    skin_eye_irritation: Optional[CompoundSafetySkinEyeIrritation] = None
    toxcast: Optional[CompoundSafetyToxcast] = None
    aquatic_toxicity: Optional[CompoundSafetyAquaticToxicity] = None
    tox_predictions: Optional[CompoundSafetyToxPredictions] = None
    skin_eye: Optional[CompoundSafetySkinEye] = None
    bioactivity: Optional[CompoundSafetyBioactivity] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafety:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContexts:
    human_adult: CompoundSafetyContextsHumanAdult
    human_teen: CompoundSafetyContextsHumanTeen
    human_elderly: CompoundSafetyContextsHumanElderly
    human_infant: CompoundSafetyContextsHumanInfant
    human_pregnant: CompoundSafetyContextsHumanPregnant
    exposure_dermal: Optional[CompoundSafetyContextsExposureDermal] = None
    human_child: Optional[CompoundSafetyContextsHumanChild] = None
    exposure_ingestion: Optional[CompoundSafetyContextsExposureIngestion] = None
    exposure_inhalation: Optional[CompoundSafetyContextsExposureInhalation] = None
    dog: Optional[CompoundSafetyContextsDog] = None
    cat: Optional[CompoundSafetyContextsCat] = None
    aquatic_life: Optional[CompoundSafetyContextsAquaticLife] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContexts:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanAdult:
    risk_level: str
    source: Optional[str] = None
    data_quality: Optional[str] = None
    summary: Optional[str] = None
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanAdult:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsExposureDermal:
    risk_level: str
    source: Optional[str] = None
    data_quality: Optional[str] = None
    summary: Optional[str] = None
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsExposureDermal:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanTeen:
    summary: str
    details: str
    action: str
    risk_level: str
    source_refs: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanTeen:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanElderly:
    summary: str
    details: str
    action: str
    risk_level: str
    source_refs: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanElderly:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanInfant:
    risk_level: str
    summary: str
    details: str
    action: str
    source_refs: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanInfant:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanPregnant:
    risk_level: str
    summary: str
    details: Optional[str] = None
    action: Optional[str] = None
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanPregnant:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsHumanChild:
    risk_level: str
    summary: str
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsHumanChild:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsExposureIngestion:
    risk_level: str
    summary: str
    source_refs: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsExposureIngestion:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsExposureInhalation:
    risk_level: str
    summary: str
    source_refs: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsExposureInhalation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsDog:
    risk_level: str
    summary: str
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsDog:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsCat:
    risk_level: str
    summary: str
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsCat:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyContextsAquaticLife:
    risk_level: str
    summary: str
    source_refs: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyContextsAquaticLife:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyVulnerablePopulations:
    children: CompoundSafetyVulnerablePopulationsChildren
    pregnant_women: CompoundSafetyVulnerablePopulationsPregnantWomen
    elderly: Optional[CompoundSafetyVulnerablePopulationsElderly] = None
    sensitized_individuals: Optional[CompoundSafetyVulnerablePopulationsSensitizedIndividuals] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyVulnerablePopulations:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyVulnerablePopulationsChildren:
    risk_modifier: str
    reason: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyVulnerablePopulationsChildren:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyVulnerablePopulationsPregnantWomen:
    risk_modifier: str
    reason: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyVulnerablePopulationsPregnantWomen:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyVulnerablePopulationsElderly:
    risk_modifier: str
    reason: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyVulnerablePopulationsElderly:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyVulnerablePopulationsSensitizedIndividuals:
    risk_modifier: str
    reason: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyVulnerablePopulationsSensitizedIndividuals:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyEndocrineDisruption:
    classification: str
    source: Optional[str] = None
    confidence: Optional[str] = None
    pathways: Optional[list[str]] = None
    potency: Any = None
    critical_windows: Optional[list[Any]] = None
    low_dose_effects: Any = None
    non_monotonic: Any = None
    eu_classification: Any = None
    who_ipcs_criteria: Any = None
    evidence_level: Any = None
    affected_endpoints: Optional[list[Any]] = None
    notes: Optional[str] = None
    source_refs: Optional[list[Any]] = None
    evidence: Optional[str] = None
    mechanism: Optional[str] = None
    date: Optional[str] = None
    endpoints: Optional[list[str]] = None
    sources: Optional[list[CompoundSafetyEndocrineDisruptionSourcesItem]] = None
    search_date: Optional[str] = None
    note: Optional[str] = None
    date_classified: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyEndocrineDisruption:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyEndocrineDisruptionSourcesItem:
    source: str
    classification: str
    notes: str
    confidence: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyEndocrineDisruptionSourcesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyCarcinogenicity:
    iarc_group: str
    iarc_note: Optional[str] = None
    iarc_year: Optional[int] = None
    iarc_monograph: Optional[str] = None
    ntp_classification: Optional[str] = None
    epa_classification: Optional[str] = None
    cancer_sites: Optional[list[str]] = None
    evidence_summary: Optional[dict[str, Any]] = None
    genotoxicity: Optional[dict[str, Any]] = None
    notes: Optional[str] = None
    source_refs: Optional[list[Any]] = None
    iris_cancer_call: Optional[str] = None
    calepa_cancer_call: Optional[str] = None
    cancer_sources: Optional[list[CompoundSafetyCarcinogenicityCancerSourcesItem]] = None
    niosh_cancer_call: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyCarcinogenicity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyCarcinogenicityCancerSourcesItem:
    source: str
    call: str
    route: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyCarcinogenicityCancerSourcesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyGhs:
    hazard_codes: list[str]
    signal_word: Optional[str]
    source: str
    pictograms: Any = None
    source_url: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyGhs:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetySkinSensitization:
    classification: str
    potency: str
    respiratory: bool
    sources: list[str]
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetySkinSensitization:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponse:
    tdi: CompoundSafetyDoseResponseTdi
    rfd: list[CompoundSafetyDoseResponseRfdItem]
    ld50: Optional[list[CompoundSafetyDoseResponseLd50Item]] = None
    lc50: Optional[list[CompoundSafetyDoseResponseLc50Item]] = None
    noael: Optional[list[CompoundSafetyDoseResponseNoaelItem]] = None
    loael: Optional[list[CompoundSafetyDoseResponseLoaelItem]] = None
    bmd: Optional[dict[str, Any]] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponse:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseTdi:
    value: str
    source: str
    basis: str
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseTdi:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseRfdItem:
    value: str
    source: str
    critical_effect: str
    uncertainty_factor: Any
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseRfdItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseLd50Item:
    value: Optional[str]
    data_quality: str
    source_ref: Optional[str] = None
    species: Optional[str] = None
    route: Optional[str] = None
    source: Optional[str] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseLd50Item:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseLc50Item:
    source_ref: str
    duration: str
    value: str
    species: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseLc50Item:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseNoaelItem:
    value_mg_kg_day: Optional[float]
    source: str
    data_quality: str
    note: Optional[str] = None
    units: Optional[str] = None
    species: Optional[str] = None
    route: Optional[str] = None
    study_type: Optional[str] = None
    study_duration: Optional[str] = None
    effect: Optional[str] = None
    source_url: Optional[str] = None
    year: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseNoaelItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyDoseResponseLoaelItem:
    value_mg_kg_day: float
    units: str
    species: str
    route: str
    study_type: str
    source: str
    source_url: str
    study_duration: Optional[str] = None
    effect: Optional[str] = None
    year: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyDoseResponseLoaelItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyExposureLimits:
    osha_pel: CompoundSafetyExposureLimitsOshaPel
    acgih_tlv: CompoundSafetyExposureLimitsAcgihTlv
    niosh_rel: CompoundSafetyExposureLimitsNioshRel
    eu_oel: CompoundSafetyExposureLimitsEuOel
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyExposureLimits:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyExposureLimitsOshaPel:
    value: str
    basis: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyExposureLimitsOshaPel:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyExposureLimitsAcgihTlv:
    value: str
    basis: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyExposureLimitsAcgihTlv:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyExposureLimitsNioshRel:
    value: str
    basis: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyExposureLimitsNioshRel:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyExposureLimitsEuOel:
    value: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyExposureLimitsEuOel:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyBiomonitoring:
    nhanes: CompoundSafetyBiomonitoringNhanes | bool
    notes: str
    breast_milk: Optional[CompoundSafetyBiomonitoringBreastMilk] = None
    cord_blood: Optional[CompoundSafetyBiomonitoringCordBlood] = None
    other_studies: Optional[list[Any]] = None
    detected: Optional[bool] = None
    source: Optional[str] = None
    date: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyBiomonitoring:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyBiomonitoringNhanes:
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyBiomonitoringNhanes:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyBiomonitoringBreastMilk:
    detected: Optional[bool] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyBiomonitoringBreastMilk:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyBiomonitoringCordBlood:
    detected: Optional[bool] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyBiomonitoringCordBlood:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyMixtureEffects:
    documented_synergies: Optional[list[CompoundSafetyMixtureEffectsDocumentedSynergiesItem]] = None
    cumulative_assessment_group: Any = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyMixtureEffects:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyMixtureEffectsDocumentedSynergiesItem:
    description: str
    source_ref: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyMixtureEffectsDocumentedSynergiesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyIris:
    tumor_sites: list[str]
    iris_url: str
    last_significant_revision: str
    critical_effects: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyIris:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyGenotoxicity:
    source: Optional[str] = None
    overall_call: Optional[str] = None
    ames: Optional[str] = None
    reports_positive: Optional[int] = None
    reports_negative: Optional[int] = None
    micronucleus: Optional[str] = None
    reports_other: Optional[int] = None
    data_quality: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyGenotoxicity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetySkinEyeIrritation:
    source: str
    endpoints: list[CompoundSafetySkinEyeIrritationEndpointsItem]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetySkinEyeIrritation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetySkinEyeIrritationEndpointsItem:
    endpoint: str
    classifications: list[dict[str, Any]]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetySkinEyeIrritationEndpointsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyToxcast:
    total_assays: int
    active_assays: int
    percent_active: float
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyToxcast:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyAquaticToxicity:
    source: str
    daphnia_lc50_mol_l: float
    fathead_minnow_lc50_mol_l: float
    tetrahymena_igc50_mol_l: float

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyAquaticToxicity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyToxPredictions:
    source: str
    devtox_score: float
    ames_score: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyToxPredictions:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetySkinEye:
    skin_sensitization: Optional[str]
    eye_irritation: Optional[str]
    skin_irritation: Optional[str]
    source: str
    data_quality: str
    n_studies: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetySkinEye:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSafetyBioactivity:
    source: str
    data_quality: str
    n_active: Optional[int] = None
    n_tested: Optional[int] = None
    activity_ratio: Optional[float] = None
    active_assays: Any = None
    total_assays: Any = None
    hit_rate: Any = None
    note: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSafetyBioactivity:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatory:
    classifications: list[CompoundRegulatoryClassificationsItem]
    listings: CompoundRegulatoryListings
    exposure_limits: Optional[CompoundRegulatoryExposureLimits] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatory:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryClassificationsItem:
    agency: str
    classification: str
    notes: Optional[str] = None
    exposure_route: Optional[str] = None
    source_url: Optional[str] = None
    body: Optional[str] = None
    source: Optional[str] = None
    year: Optional[int] = None
    basis: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryClassificationsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListings:
    california_prop65: CompoundRegulatoryListingsCaliforniaProp65
    eu_reach: Optional[dict[str, Any]] = None
    stockholm_convention: Optional[dict[str, Any]] = None
    rotterdam_convention: Optional[dict[str, Any]] = None
    eu_clp: Optional[dict[str, Any]] = None
    epa_tsca: Optional[dict[str, Any]] = None
    iarc_group: Optional[CompoundRegulatoryListingsIarcGroup] = None
    ntp_roc: Optional[dict[str, Any]] = None
    epa_iris: Optional[CompoundRegulatoryListingsEpaIris] = None
    notes: Optional[str] = None
    canada_dsl: Optional[CompoundRegulatoryListingsCanadaDsl] = None
    edsp_universe: Optional[CompoundRegulatoryListingsEdspUniverse] = None
    efsa_open_food_tox: Optional[CompoundRegulatoryListingsEfsaOpenFoodTox] = None
    epa_biosolids: Optional[CompoundRegulatoryListingsEpaBiosolids] = None
    epa_ccl: Optional[CompoundRegulatoryListingsEpaCcl] = None
    epa_hbsl: Optional[CompoundRegulatoryListingsEpaHbsl] = None
    epa_ucmr: Optional[CompoundRegulatoryListingsEpaUcmr] = None
    osha: Optional[CompoundRegulatoryListingsOsha] = None
    nhanes: Optional[CompoundRegulatoryListingsNhanes] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListings:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsCaliforniaProp65:
    listed: bool
    notes: str
    listing_type: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsCaliforniaProp65:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsIarcGroup:
    group: Optional[str]
    year: Optional[int] = None
    monograph_volume: Optional[str] = None
    cancer_sites: Optional[list[str]] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsIarcGroup:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEpaIris:
    exists: bool
    url: Optional[str] = None
    critical_effects: Optional[str] = None
    tumor_site: Optional[str] = None
    iris_url: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEpaIris:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsCanadaDsl:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsCanadaDsl:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEdspUniverse:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEdspUniverse:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEfsaOpenFoodTox:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEfsaOpenFoodTox:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEpaBiosolids:
    listed: bool
    versions: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEpaBiosolids:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEpaCcl:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEpaCcl:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEpaHbsl:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEpaHbsl:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsEpaUcmr:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsEpaUcmr:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsOsha:
    listed: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsOsha:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryListingsNhanes:
    detected: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryListingsNhanes:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryExposureLimits:
    occupational: list[Any]
    drinking_water: list[CompoundRegulatoryExposureLimitsDrinkingWaterItem]
    daily_intake: list[CompoundRegulatoryExposureLimitsDailyIntakeItem]
    food_contact: list[Any]
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryExposureLimits:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryExposureLimitsDrinkingWaterItem:
    agency: str
    limit_type: str
    value: str
    enforceable: bool

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryExposureLimitsDrinkingWaterItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundRegulatoryExposureLimitsDailyIntakeItem:
    agency: str
    limit_type: str
    value: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundRegulatoryExposureLimitsDailyIntakeItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundFoundInItem:
    category: str
    examples: Optional[list[str]] = None
    detail: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundFoundInItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundMeta:
    schema_version: str
    created: str
    version: int
    last_reviewed: str
    revision_history: list[CompoundMetaRevisionHistoryItem]
    reviewed_by: str
    created_by: str
    status: str
    sources: Optional[list[str]] = None
    last_updated: Optional[str] = None
    ctx_qc_level: Optional[int] = None
    ctx_qc_desc: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundMeta:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundMetaRevisionHistoryItem:
    date: str
    version: Optional[int] = None
    author: Optional[str] = None
    note: Optional[str] = None
    change: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundMetaRevisionHistoryItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundDataGapsItem:
    field: str
    status: str
    reason: Optional[str] = None
    source: Optional[str] = None
    stamped: Optional[str] = None
    audit_tag: Optional[str] = None
    note: Optional[str] = None
    sources_checked: Optional[list[str]] = None
    date_checked: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundDataGapsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundSourcesItem:
    id: Optional[str] = None
    type_: Optional[str] = None
    title: Optional[str] = None
    url: Optional[str] = None
    accessed: Optional[str] = None
    notes: Optional[str] = None
    year: Optional[int] = None
    name: Optional[str] = None
    date: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundSourcesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundAlternatives:
    safer_alternatives: list[CompoundAlternativesSaferAlternativesItem]
    notes: str
    replacement_compounds: Optional[list[Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundAlternatives:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundAlternativesSaferAlternativesItem:
    name: str
    tradeoffs: str
    relative_cost: str
    regulatory_status: str
    notes: Optional[str] = None
    context: Optional[str] = None
    note: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundAlternativesSaferAlternativesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundChemicalClass:
    nature: str
    halogenated: Optional[bool] = None
    aromatic: Optional[bool] = None
    functional_group: Optional[list[str]] = None
    structural_family: Optional[str] = None
    sub_family: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundChemicalClass:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundExposure:
    expocat: CompoundExposureExpocat | list[Any]
    list_presence: CompoundExposureListPresence | list[Any]
    functional_use: CompoundExposureFunctionalUse | list[Any]

    @classmethod
    def from_dict(cls, data: dict) -> CompoundExposure:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundExposureExpocat:
    exposure_expected: bool
    source: str
    median_mg_kg_day: float

    @classmethod
    def from_dict(cls, data: dict) -> CompoundExposureExpocat:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundExposureListPresence:
    source: str
    data_quality: str
    n_documents: Optional[int] = None
    categories: Optional[list[str]] = None
    organizations: Optional[list[str]] = None
    lists: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundExposureListPresence:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundExposureFunctionalUse:
    categories: list[str]
    source: str
    data_quality: str
    n_records: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> CompoundExposureFunctionalUse:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundMitigationStrategiesItem:
    strategy: str
    detail: str
    effectiveness: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundMitigationStrategiesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class CompoundAliasesItem:
    hq_id: str
    name: str
    alias_type: str
    cas: str

    @classmethod
    def from_dict(cls, data: dict) -> CompoundAliasesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class Compound:
    hq_id: str
    name: str
    type_: Optional[str] = None
    category: Optional[str] = None
    crossrefs: Optional[CompoundCrossrefs] = None
    identity: Optional[CompoundIdentity] = None
    properties: Optional[CompoundProperties] = None
    hazard_profile: Optional[CompoundHazardProfile | str] = None
    safety: Optional[CompoundSafety] = None
    regulatory: Optional[CompoundRegulatory] = None
    found_in: Optional[list[CompoundFoundInItem]] = None
    meta: Optional[CompoundMeta] = None
    compound_class: Optional[str] = None
    _data_gaps: Optional[list[CompoundDataGapsItem]] = None
    sources: Optional[list[CompoundSourcesItem]] = None
    alternatives: Optional[CompoundAlternatives] = None
    last_reviewed: Optional[str] = None
    review_source: Optional[str] = None
    risk_level: Optional[str] = None
    chemical_class: Optional[CompoundChemicalClass] = None
    exposure: Optional[CompoundExposure] = None
    no_substitute_reason: Optional[str] = None
    mitigation_strategies: Optional[list[CompoundMitigationStrategiesItem]] = None
    aliases: Optional[list[CompoundAliasesItem]] = None

    @classmethod
    def from_dict(cls, data: dict) -> Compound:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductFormulation:
    form: str
    key_ingredients: list[ProductFormulationKeyIngredientsItem]
    preservative_system: list[str]
    fragrance_system: Optional[str]
    certifications: list[str]
    ph_range: Optional[str] = None
    type_: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductFormulation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductFormulationKeyIngredientsItem:
    hq_id: Optional[str]
    name: str
    role: str
    concentration_pct: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductFormulationKeyIngredientsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMaterials:
    common: list[ProductMaterialsCommonItem]
    concerning: list[ProductMaterialsConcerningItem]
    preferred: list[ProductMaterialsPreferredItem]

    @classmethod
    def from_dict(cls, data: dict) -> ProductMaterials:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMaterialsCommonItem:
    material_id: Optional[str]
    material_name: str
    component: Optional[str]
    prevalence: str
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductMaterialsCommonItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMaterialsConcerningItem:
    material_id: Optional[str]
    concern: str
    compounds_of_concern: list[str]
    source_refs: list[str]
    material_name: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductMaterialsConcerningItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMaterialsPreferredItem:
    material_id: Any
    material_name: str
    why_preferred: str
    tradeoffs: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductMaterialsPreferredItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductCompoundCompositionItem:
    compound_name: str
    hq_id: str
    match_status: str
    match_date: str
    compound_ref: Optional[str] = None
    source: Optional[str] = None
    source_ref: Optional[str] = None
    role: Optional[str] = None
    notes: Optional[str] = None
    typical_concentration: Optional[str] = None
    cas_number: Optional[str] = None
    concentration_range: Optional[str] = None
    hazard_class: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductCompoundCompositionItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductExposure:
    routes: list[str]
    contact_types: list[str]
    users: list[str]
    duration: str
    frequency: str
    scenarios: list[str]
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductExposure:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductHazardSummary:
    sensitive_populations: str
    overall_risk: str
    primary_concerns: list[str]
    exposure_routes: str
    critical_concern: Optional[str] = None
    key_hazards: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductHazardSummary:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafety:
    aggregate_hazard: ProductSafetyAggregateHazard
    vulnerable_populations: list[ProductSafetyVulnerablePopulationsItem]
    use_guidance: ProductSafetyUseGuidance
    mixture_effects: ProductSafetyMixtureEffects
    notes: Optional[str]
    derived_synthesis: ProductSafetyDerivedSynthesis
    carcinogenicity_concern: Optional[ProductSafetyCarcinogenicityConcern] = None
    endocrine_disruption_concern: Optional[ProductSafetyEndocrineDisruptionConcern] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafety:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyAggregateHazard:
    overall_risk_level: str
    primary_concerns: list[str]
    hazard_summary: Optional[str]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyAggregateHazard:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyCarcinogenicityConcern:
    concern_level: Optional[str] = None
    key_carcinogens: Optional[list[ProductSafetyCarcinogenicityConcernKeyCarcinogensItem]] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyCarcinogenicityConcern:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyCarcinogenicityConcernKeyCarcinogensItem:
    compound_ref: str
    compound_name: str
    iarc: Optional[str] = None
    ntp: Optional[str] = None
    calepa: Optional[str] = None
    classification: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyCarcinogenicityConcernKeyCarcinogensItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyEndocrineDisruptionConcern:
    concern_level: Optional[str] = None
    key_disruptors: Optional[list[Any]] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyEndocrineDisruptionConcern:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyVulnerablePopulationsItem:
    population: str
    vulnerability_basis: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyVulnerablePopulationsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyUseGuidance:
    safe_use_conditions: Optional[list[str]] = None
    avoid_conditions: Optional[list[str]] = None
    storage: Optional[str] = None
    disposal: Optional[str] = None
    first_aid: Optional[ProductSafetyUseGuidanceFirstAid] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyUseGuidance:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyUseGuidanceFirstAid:
    ingestion: Optional[str]
    skin_contact: Optional[str]
    eye_contact: Optional[str]
    inhalation: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyUseGuidanceFirstAid:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyMixtureEffects:
    documented_interactions: Optional[list[str]] = None
    formulation_vs_ingredient: Optional[str] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyMixtureEffects:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyDerivedSynthesis:
    derived_risk_level: str
    synthesis_confidence: float | int
    synthesis_method: str
    compounds_resolved: int
    compounds_total: int
    synthesis_date: str
    synthesis_version: str
    context_used: Optional[str] = None
    context_source: Optional[str] = None
    exposure_modifier: Optional[float | int] = None
    aggregate_magnitude: Optional[float] = None
    vulnerability_escalated: Optional[bool] = None
    escalation_reason: Optional[str] = None
    compound_traces: Optional[list[ProductSafetyDerivedSynthesisCompoundTracesItem]] = None
    synthesis_reason: Optional[str] = None
    context_attempted: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyDerivedSynthesis:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSafetyDerivedSynthesisCompoundTracesItem:
    hq_id: str
    compound_name: str
    adjusted_magnitude: float
    compound_confidence: float
    context_used: str
    context_fallback: bool

    @classmethod
    def from_dict(cls, data: dict) -> ProductSafetyDerivedSynthesisCompoundTracesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatory:
    applicable_regulations: list[ProductRegulatoryApplicableRegulationsItem]
    certifications: list[ProductRegulatoryCertificationsItem]
    labeling: ProductRegulatoryLabeling
    recalls: list[str]
    regulatory_gap: Optional[str]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatory:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryApplicableRegulationsItem:
    jurisdiction: str
    regulation: str
    citation: Optional[str]
    requirements: str
    compliance_status: Any
    effective_date: Optional[str]
    enforcing_agency: Optional[str]
    penalties: Any
    source_ref: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryApplicableRegulationsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryCertificationsItem:
    name: str
    issuer: str
    standard: str
    scope: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryCertificationsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryLabeling:
    required_disclosures: Optional[list[str]] = None
    prop65_warning: Optional[ProductRegulatoryLabelingProp65Warning] = None
    ghs_labeling: Optional[ProductRegulatoryLabelingGhsLabeling] = None
    hidden_ingredients: Optional[ProductRegulatoryLabelingHiddenIngredients] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryLabeling:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryLabelingProp65Warning:
    required: Optional[bool]
    chemicals: list[Any]
    endpoint: Any
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryLabelingProp65Warning:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryLabelingGhsLabeling:
    required: Optional[bool]
    signal_word: Any
    pictograms: list[Any]
    hazard_statements: list[Any]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryLabelingGhsLabeling:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRegulatoryLabelingHiddenIngredients:
    trade_secret_protected: Optional[bool]
    categories_hidden: list[Any]
    estimated_count: Optional[int]
    known_concerns: Optional[str]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductRegulatoryLabelingHiddenIngredients:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductConsumerGuidance:
    red_flags: Optional[list[ProductConsumerGuidanceRedFlagsItem]] = None
    green_flags: Optional[list[ProductConsumerGuidanceGreenFlagsItem]] = None
    what_to_ask: Optional[list[ProductConsumerGuidanceWhatToAskItem]] = None
    alternatives: Optional[list[ProductConsumerGuidanceAlternativesItem]] = None
    notes: Optional[str] = None
    usage_warning: Optional[str] = None
    safer_alternatives: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductConsumerGuidance:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductConsumerGuidanceRedFlagsItem:
    indicator: str
    meaning: str
    action: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductConsumerGuidanceRedFlagsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductConsumerGuidanceGreenFlagsItem:
    indicator: str
    meaning: str
    verification: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductConsumerGuidanceGreenFlagsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductConsumerGuidanceWhatToAskItem:
    question: str
    why_it_matters: str
    good_answer: Optional[str] = None
    bad_answer: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductConsumerGuidanceWhatToAskItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductConsumerGuidanceAlternativesItem:
    name: str
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductConsumerGuidanceAlternativesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductLifecycle:
    recyclable: Optional[bool | str]
    disposal_guidance: str
    hazardous_waste: bool
    expected_lifespan: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductLifecycle:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMarketContext:
    prevalence: str
    market_trend: str
    regulatory_pressure: str
    major_brands: list[str]
    market_leaders: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductMarketContext:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductTesting:
    applicable_standards: list[str]
    independent_testing_available: Optional[bool]
    consumer_testing_options: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductTesting:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductSourcesItem:
    type_: str
    id: Optional[str] = None
    title: Optional[str] = None
    year: Optional[int] = None
    url: Optional[str] = None
    accessed: Optional[str] = None
    notes: Optional[str] = None
    name: Optional[str] = None
    date: Optional[str] = None
    jurisdiction: Optional[str] = None
    inherited_from_compound: Optional[str] = None
    citation: Optional[str] = None
    extraction: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductSourcesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductIdentifiers:
    common_names: list[str]
    aliases: list[str]
    manufacturer: Optional[str]
    brands: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductIdentifiers:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMeta:
    created: str
    version: int
    status: str
    last_reviewed: str
    schema_version: str
    revision_history: list[ProductMetaRevisionHistoryItem]
    last_updated: str
    created_by: Optional[str] = None
    reviewed_by: Optional[str] = None
    sources_summary: Optional[list[Any]] = None
    confidence: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> ProductMeta:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductMetaRevisionHistoryItem:
    version: int | str
    date: str
    author: str
    note: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductMetaRevisionHistoryItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductCategory:
    primary: str
    secondary: str
    tags: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> ProductCategory:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductDataGapsItem:
    field: str
    reason: str
    status: str
    priority: str
    date: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductDataGapsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductBrandExamplesItem:
    brand: str
    manufacturer: str
    market_position: str
    notable: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductBrandExamplesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class ProductRiskProfile:
    level: str
    primary_concern: str
    regulatory_status: str
    evidence_gaps: str

    @classmethod
    def from_dict(cls, data: dict) -> ProductRiskProfile:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class Product:
    hq_id: str
    name: str
    type_: Optional[str] = None
    description: Optional[str] = None
    overall_risk_level: Optional[str] = None
    formulation: Optional[ProductFormulation] = None
    materials: Optional[ProductMaterials] = None
    compound_composition: Optional[list[ProductCompoundCompositionItem]] = None
    exposure: Optional[ProductExposure] = None
    hazard_summary: Optional[ProductHazardSummary] = None
    safety: Optional[ProductSafety] = None
    regulatory: Optional[ProductRegulatory] = None
    consumer_guidance: Optional[ProductConsumerGuidance] = None
    lifecycle: Optional[ProductLifecycle] = None
    market_context: Optional[ProductMarketContext] = None
    testing: Optional[ProductTesting] = None
    sources: Optional[list[ProductSourcesItem]] = None
    identifiers: Optional[ProductIdentifiers] = None
    meta: Optional[ProductMeta] = None
    category: Optional[ProductCategory] = None
    product_tier: Optional[str] = None
    product_sub_tier: Optional[str] = None
    product_tier_secondary: Optional[list[Any]] = None
    _data_gaps: Optional[list[ProductDataGapsItem]] = None
    brand_examples: Optional[list[ProductBrandExamplesItem]] = None
    risk_profile: Optional[ProductRiskProfile] = None
    vulnerability_factor: Optional[str] = None
    exposure_route: Optional[list[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> Product:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialComposition:
    additives: list[MaterialCompositionAdditivesItem]
    hazardous_components: list[MaterialCompositionHazardousComponentsItem]
    components: list[MaterialCompositionComponentsItem]
    contaminants: list[MaterialCompositionContaminantsItem]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> MaterialComposition:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialCompositionAdditivesItem:
    name: Optional[str] = None
    compound_id: Any = None
    compound_name: Optional[str] = None
    function: Optional[str] = None
    typical_percentage: Optional[str] = None
    cas: Any = None
    notes: Optional[str] = None
    compound_id_status: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialCompositionAdditivesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialCompositionHazardousComponentsItem:
    name: str
    cas: str
    concern: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialCompositionHazardousComponentsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialCompositionComponentsItem:
    name: Optional[str] = None
    compound_id: Optional[str] = None
    compound_name: Optional[str] = None
    percentage: Optional[str] = None
    cas: Optional[str] = None
    notes: Optional[str] = None
    compound_id_status: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialCompositionComponentsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialCompositionContaminantsItem:
    compound_id: Optional[str]
    compound_name: str
    notes: str
    compound_id_status: Optional[str] = None
    source: Optional[str] = None
    typical_level: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialCompositionContaminantsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehavior:
    leaching: MaterialBehaviorLeaching
    degradation: MaterialBehaviorDegradation
    offgassing: MaterialBehaviorOffgassing
    thermal: MaterialBehaviorThermal
    environmental_persistence: Optional[MaterialBehaviorEnvironmentalPersistence] = None
    bioaccumulation: Optional[MaterialBehaviorBioaccumulation] = None
    groundwater_contamination: Optional[MaterialBehaviorGroundwaterContamination] = None
    water_treatment_resistance: Optional[MaterialBehaviorWaterTreatmentResistance] = None
    scab_children_health_study: Optional[MaterialBehaviorScabChildrenHealthStudy] = None
    environmental_justice_overlap: Optional[MaterialBehaviorEnvironmentalJusticeOverlap] = None
    school_proximity_concern: Optional[MaterialBehaviorSchoolProximityConcern] = None
    concentration_gradient: Optional[MaterialBehaviorConcentrationGradient] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehavior:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorLeaching:
    conditions: list[MaterialBehaviorLeachingConditionsItem]

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorLeaching:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorLeachingConditionsItem:
    condition: str
    compounds_released: list[str]
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorLeachingConditionsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorDegradation:
    biodegradable: Optional[bool]
    degradation_time: str
    degradation_products: list[str]
    microplastic_risk: Optional[bool]
    notes: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorDegradation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorOffgassing:
    vocs_released: list[str]
    conditions: str
    source_refs: list[Any]

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorOffgassing:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorThermal:
    decomposition_temp_c: Optional[int]
    pyrolysis_products: list[str]
    combustion_toxicity: str
    fire_classification: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorThermal:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorEnvironmentalPersistence:
    description: str
    mechanism: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorEnvironmentalPersistence:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorBioaccumulation:
    description: str
    data: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorBioaccumulation:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorGroundwaterContamination:
    description: str
    sources: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorGroundwaterContamination:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorWaterTreatmentResistance:
    description: str
    mechanism: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorWaterTreatmentResistance:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorScabChildrenHealthStudy:
    description: str
    mechanism: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorScabChildrenHealthStudy:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorEnvironmentalJusticeOverlap:
    description: str
    consequence: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorEnvironmentalJusticeOverlap:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorSchoolProximityConcern:
    description: str
    exposure_context: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorSchoolProximityConcern:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialBehaviorConcentrationGradient:
    description: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialBehaviorConcentrationGradient:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialHazardProfile:
    primary_hazards: list[str]
    manufacturing_hazards: list[str]
    use_phase_hazards: list[str]
    end_of_life_hazards: list[str]

    @classmethod
    def from_dict(cls, data: dict) -> MaterialHazardProfile:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialSafetySummary:
    primary_concerns: list[MaterialSafetySummaryPrimaryConcernsItem]
    risk_level: str
    sensitive_populations: list[str]
    notes: str
    regulatory_gap: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialSafetySummary:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialSafetySummaryPrimaryConcernsItem:
    concern: str
    exposure_route: str
    from_compound: Optional[str] = None
    sensitive_populations: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialSafetySummaryPrimaryConcernsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialSafetyContextsItem:
    context: str
    risk_level: str
    notes: str
    route: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialSafetyContextsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatory:
    by_jurisdiction: MaterialRegulatoryByJurisdiction
    classifications: MaterialRegulatoryClassifications | list[Any]
    restrictions: list[Any]
    migration_limits: MaterialRegulatoryMigrationLimits
    certifications: MaterialRegulatoryCertifications | list[Any]
    notes: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatory:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryByJurisdiction:
    eu: str
    us_epa: str
    other: list[str]
    us_osha: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryByJurisdiction:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassifications:
    carcinogenicity_aggregate: MaterialRegulatoryClassificationsCarcinogenicityAggregate
    prop65_listed_compounds: list[MaterialRegulatoryClassificationsProp65ListedCompoundsItem]
    edc_flagged_compounds: list[MaterialRegulatoryClassificationsEdcFlaggedCompoundsItem]
    svhc_candidates: list[MaterialRegulatoryClassificationsSvhcCandidatesItem]
    material_type_frameworks: list[MaterialRegulatoryClassificationsMaterialTypeFrameworksItem]
    source: str
    date: str
    epa_classifications: Optional[list[MaterialRegulatoryClassificationsEpaClassificationsItem]] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassifications:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsCarcinogenicityAggregate:
    highest_iarc_group: Any
    from_compound: Any
    n_compounds_assessed: int

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsCarcinogenicityAggregate:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsProp65ListedCompoundsItem:
    compound_id: str
    name: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsProp65ListedCompoundsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsEdcFlaggedCompoundsItem:
    compound_id: str
    name: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsEdcFlaggedCompoundsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsSvhcCandidatesItem:
    compound_id: str
    name: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsSvhcCandidatesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsMaterialTypeFrameworksItem:
    framework: str
    applicability: str
    key_restrictions: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsMaterialTypeFrameworksItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryClassificationsEpaClassificationsItem:
    compound_id: str
    name: str
    classification: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryClassificationsEpaClassificationsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryMigrationLimits:
    notes: Optional[str]
    eu_framework: Optional[MaterialRegulatoryMigrationLimitsEuFramework] = None
    fda_framework: Optional[MaterialRegulatoryMigrationLimitsFdaFramework] = None
    overall_migration_limit: Optional[str] = None
    specific_limits: Optional[list[Any]] = None
    source: Optional[str] = None
    date: Optional[str] = None
    food_contact: Optional[list[Any]] = None
    drinking_water_contact: Optional[list[Any]] = None
    medical_device: Optional[list[Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryMigrationLimits:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryMigrationLimitsEuFramework:
    framework: str
    scope: str
    overall_migration_limit: str
    test_conditions: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryMigrationLimitsEuFramework:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryMigrationLimitsFdaFramework:
    framework: str
    scope: str
    approach: str
    source: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryMigrationLimitsFdaFramework:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertifications:
    food_contact: MaterialRegulatoryCertificationsFoodContact
    toy_safety: MaterialRegulatoryCertificationsToySafety
    medical_device: MaterialRegulatoryCertificationsMedicalDevice
    building: MaterialRegulatoryCertificationsBuilding
    textile: MaterialRegulatoryCertificationsTextile
    environmental: MaterialRegulatoryCertificationsEnvironmental
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertifications:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsFoodContact:
    approved: Any
    agencies: list[Any]
    regulation_refs: list[Any]
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsFoodContact:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsToySafety:
    compliant: Any
    standards: list[Any]
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsToySafety:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsMedicalDevice:
    biocompatible: Any
    class_: Any
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsMedicalDevice:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsBuilding:
    emission_class: Any
    fire_rating: Any
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsBuilding:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsTextile:
    oeko_tex: Any
    gots: Any
    bluesign: Any
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsTextile:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialRegulatoryCertificationsEnvironmental:
    cradle_to_cradle: Any
    greenscreen: Any
    rohs_compliant: Any
    notes: Any

    @classmethod
    def from_dict(cls, data: dict) -> MaterialRegulatoryCertificationsEnvironmental:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialAlternativesItem:
    material_name: str
    tradeoffs: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialAlternativesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialSourcesItem:
    id: str
    type_: str
    title: Optional[str] = None
    url: Optional[str] = None
    accessed: Optional[str] = None
    year: Optional[int] = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialSourcesItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialEnvironmental:
    end_of_life: MaterialEnvironmentalEndOfLife
    persistence: MaterialEnvironmentalPersistence
    resource_depletion: MaterialEnvironmentalResourceDepletion
    notes: Any = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialEnvironmental:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialEnvironmentalEndOfLife:
    recyclable: Optional[bool] = None
    recycling_code: Any = None
    recycling_challenges: Optional[str] = None
    compostable: Any = None
    compost_standard: Any = None
    incineration_concerns: Optional[str] = None
    landfill_concerns: Optional[str] = None
    notes: Any = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialEnvironmentalEndOfLife:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialEnvironmentalPersistence:
    classification: Optional[str] = None
    degradation_time: Optional[str] = None
    notes: Any = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialEnvironmentalPersistence:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialEnvironmentalResourceDepletion:
    raw_material_source: Optional[str] = None
    supply_chain_concerns: Any = None
    notes: Any = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialEnvironmentalResourceDepletion:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialIdentifiers:
    trade_names: list[str]
    aliases: list[str]
    cas_numbers: list[Any]
    material_subtype: Optional[str] = None
    cas: Optional[str] = None
    resin_code: Any = None
    notes: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialIdentifiers:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialMeta:
    schema_version: str
    created: str
    sources_summary: list[str]
    last_updated: str
    version: int
    status: str
    revision_history: list[MaterialMetaRevisionHistoryItem]
    created_by: str
    reviewed_by: str
    last_reviewed: str
    last_enriched: Optional[str] = None
    enrichment_note: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> MaterialMeta:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialMetaRevisionHistoryItem:
    version: int
    date: str
    author: str
    note: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialMetaRevisionHistoryItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class MaterialDataGapsItem:
    field: str
    reason: str
    source: str
    status: str
    stamped: str

    @classmethod
    def from_dict(cls, data: dict) -> MaterialDataGapsItem:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })


@dataclass
class Material:
    hq_id: str
    name: str
    type_: Optional[str] = None
    description: Optional[str] = None
    overall_risk_level: Optional[str] = None
    composition: Optional[MaterialComposition] = None
    behavior: Optional[MaterialBehavior] = None
    hazard_profile: Optional[MaterialHazardProfile] = None
    safety_summary: Optional[MaterialSafetySummary] = None
    safety_contexts: Optional[list[MaterialSafetyContextsItem]] = None
    regulatory: Optional[MaterialRegulatory] = None
    applications: Optional[list[str]] = None
    found_in: Optional[list[str]] = None
    alternatives: Optional[list[MaterialAlternativesItem]] = None
    sources: Optional[list[MaterialSourcesItem]] = None
    environmental: Optional[MaterialEnvironmental] = None
    identifiers: Optional[MaterialIdentifiers] = None
    meta: Optional[MaterialMeta] = None
    material_tier: Optional[str] = None
    material_sub_tier: Optional[str] = None
    material_tier_secondary: Optional[list[Any]] = None
    _data_gaps: Optional[list[MaterialDataGapsItem]] = None

    @classmethod
    def from_dict(cls, data: dict) -> Material:
        """Create an instance from a raw API dict."""
        if not isinstance(data, dict):
            raise TypeError(f'Expected dict, got {type(data).__name__}')
        return cls(**{
            k: v for k, v in data.items()
            if k in cls.__dataclass_fields__
        })
