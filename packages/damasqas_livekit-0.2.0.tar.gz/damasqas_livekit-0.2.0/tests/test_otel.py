"""Tests for the Damasqas OTel span processor.

Uses a fake ReadableSpan rather than spinning up the LiveKit pipeline —
the contract under test is "given a function_tool span with these
attributes, what event do we ship to the transport".
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import patch

# Ensure we can import damasqas_livekit when running this file directly.
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from damasqas_livekit._otel import (  # noqa: E402
    DamasqasSpanProcessor,
    _build_tool_span_event,
    _reset_for_tests,
    install,
)


class _FakeStatusCode:
    def __init__(self, value: int) -> None:
        self.value = value


class _FakeStatus:
    def __init__(self, value: int) -> None:
        self.status_code = _FakeStatusCode(value)


class _FakeSpanContext:
    def __init__(self, trace_id: int, span_id: int) -> None:
        self.trace_id = trace_id
        self.span_id = span_id


class _FakeParent:
    def __init__(self, span_id: int, is_valid: bool = True) -> None:
        self.span_id = span_id
        self.is_valid = is_valid


class _FakeSpan:
    def __init__(
        self,
        name: str,
        attributes: dict[str, Any],
        start_ns: int = 1_700_000_000_000_000_000,
        end_ns: int = 1_700_000_000_500_000_000,
        status_value: int = 1,  # OK
        trace_id: int = 0xABCDEF0123456789ABCDEF0123456789,
        span_id: int = 0x1234567890ABCDEF,
        parent_span_id: int | None = 0xFEDCBA9876543210,
    ) -> None:
        self.name = name
        self.attributes = attributes
        self.start_time = start_ns
        self.end_time = end_ns
        self.status = _FakeStatus(status_value)
        self._ctx = _FakeSpanContext(trace_id, span_id)
        self.parent = _FakeParent(parent_span_id) if parent_span_id is not None else None

    def get_span_context(self) -> _FakeSpanContext:
        return self._ctx


class _Recorder:
    """Async transport stub that records sent events."""

    def __init__(self) -> None:
        self.sent: list[dict] = []

    async def send(self, event: dict) -> None:
        self.sent.append(event)


def _function_tool_span(**overrides: Any) -> _FakeSpan:
    attrs = {
        "lk.function_tool.id": "call_abc123",
        "lk.function_tool.name": "lookup_inventory",
        "lk.function_tool.arguments": json.dumps({"sku": "WIDGET-1"}),
        "lk.function_tool.output": json.dumps({"qty": 42}),
        "lk.function_tool.is_error": False,
        "lk.speech_id": "speech_42",
        "lk.generation_id": "gen_99",
    }
    attrs.update(overrides.pop("attributes", {}))
    return _FakeSpan("function_tool", attrs, **overrides)


class BuildToolSpanEventTests(unittest.TestCase):
    def test_extracts_core_fields_from_function_tool_span(self) -> None:
        span = _function_tool_span()
        ev = _build_tool_span_event(span, workspace_id="ws1", room_sid="RM_x", room_name="room-x")
        assert ev is not None
        self.assertEqual(ev["type"], "tool_span")
        self.assertEqual(ev["span_name"], "function_tool")
        self.assertEqual(ev["workspace_id"], "ws1")
        self.assertEqual(ev["room_sid"], "RM_x")
        self.assertEqual(ev["tool_name"], "lookup_inventory")
        self.assertEqual(ev["call_id"], "call_abc123")
        self.assertEqual(ev["status"], "ok")
        self.assertEqual(ev["duration_ms"], 500)
        self.assertEqual(ev["start_unix_nano"], "1700000000000000000")
        self.assertEqual(ev["end_unix_nano"], "1700000000500000000")
        self.assertEqual(json.loads(ev["arguments"]), {"sku": "WIDGET-1"})
        self.assertEqual(json.loads(ev["output"]), {"qty": 42})
        self.assertEqual(len(ev["trace_id"]), 32)
        self.assertEqual(len(ev["span_id"]), 16)
        self.assertEqual(ev["parent_span_id"], "fedcba9876543210")
        self.assertEqual(ev["speech_id"], "speech_42")
        self.assertEqual(ev["generation_id"], "gen_99")

    def test_status_error_when_is_error_attribute_set(self) -> None:
        span = _function_tool_span(attributes={"lk.function_tool.is_error": True})
        ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        assert ev is not None
        self.assertEqual(ev["status"], "error")

    def test_redaction_replaces_payload_when_env_set(self) -> None:
        span = _function_tool_span()
        with patch.dict(os.environ, {"DAMASQAS_REDACT_TOOL_IO": "1"}, clear=False):
            ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        assert ev is not None
        self.assertEqual(ev["arguments"], "<redacted>")
        self.assertEqual(ev["output"], "<redacted>")

    def test_oversize_event_is_dropped_not_truncated(self) -> None:
        # 3 MB args — over the 2 MB ceiling. Verifies drop semantics
        # (returns None) rather than silent field truncation.
        big = "x" * (3 * 1024 * 1024)
        span = _function_tool_span(attributes={"lk.function_tool.arguments": big})
        ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        self.assertIsNone(ev)

    def test_full_fidelity_preserved_under_ceiling(self) -> None:
        # 100 KB args — well under the ceiling, must round-trip byte-exact.
        big = "x" * (100 * 1024)
        span = _function_tool_span(attributes={"lk.function_tool.arguments": big})
        ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        assert ev is not None
        self.assertEqual(ev["arguments"], big)

    def test_event_timestamp_is_span_end_time_not_now(self) -> None:
        # The recorded_at column should reflect when the tool actually
        # finished, not when the SDK serialized the event (could be 0–2s
        # later due to batching). Equals end_ns / 1e9.
        span = _function_tool_span()
        ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        assert ev is not None
        self.assertAlmostEqual(ev["timestamp"], 1_700_000_000.5, places=3)

    def test_invalid_parent_context_emits_null_parent_span_id(self) -> None:
        # SpanContext.is_valid=False (or span_id=0) means "no real parent" —
        # don't emit "0000000000000000" as a fake hex parent.
        span = _function_tool_span()
        span.parent = _FakeParent(span_id=0, is_valid=False)
        ev = _build_tool_span_event(span, "ws1", "RM_x", "room-x")
        assert ev is not None
        self.assertIsNone(ev["parent_span_id"])


class SpanProcessorTests(unittest.TestCase):
    def _drive(self, fn) -> None:
        """Run on_end inside a running event loop so ensure_future succeeds."""
        async def runner():
            fn()
            # Drain any tasks created via asyncio.ensure_future.
            tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
        asyncio.run(runner())

    def test_filters_to_function_tool_spans_by_default(self) -> None:
        recorder = _Recorder()
        proc = DamasqasSpanProcessor(
            transport=recorder,
            workspace_id_provider=lambda: "ws1",
            room_provider=lambda: ("RM_x", "room-x"),
        )

        def fire():
            proc.on_end(_function_tool_span())
            proc.on_end(_FakeSpan("llm_node", {"gen_ai.provider.name": "openai"}))

        self._drive(fire)

        self.assertEqual(len(recorder.sent), 1)
        self.assertEqual(recorder.sent[0]["span_name"], "function_tool")

    def test_capture_child_spans_env_expands_allowlist(self) -> None:
        with patch.dict(os.environ, {"DAMASQAS_CAPTURE_CHILD_SPANS": "1"}, clear=False):
            recorder = _Recorder()
            proc = DamasqasSpanProcessor(
                transport=recorder,
                workspace_id_provider="ws1",
                room_provider=lambda: ("RM_x", "room-x"),
            )

            def fire():
                proc.on_end(_FakeSpan("llm_node", {"gen_ai.provider.name": "openai"}))

            self._drive(fire)

            self.assertEqual(len(recorder.sent), 1)
            self.assertEqual(recorder.sent[0]["span_name"], "llm_node")


class InstallIdempotencyTests(unittest.TestCase):
    def setUp(self) -> None:
        _reset_for_tests()

    def tearDown(self) -> None:
        _reset_for_tests()

    def test_repeated_install_does_not_stack_processors(self) -> None:
        # Two monitor() calls in the same process must not cause spans to
        # ship N times for N sessions. install() returns True both times
        # but only registers a processor once.
        from opentelemetry import trace as trace_api
        from opentelemetry.sdk.trace import TracerProvider

        provider = TracerProvider()
        trace_api.set_tracer_provider(provider)
        # Snapshot processor count before install (the global provider
        # may already carry processors from earlier tests in this file
        # that imported the SDK module — measure the delta).
        before = len(getattr(provider, "_active_span_processor", None)._span_processors) \
            if hasattr(provider, "_active_span_processor") else None

        recorder = _Recorder()
        ok1 = install(recorder, lambda: "ws1", lambda: ("RM_x", "room-x"))
        ok2 = install(recorder, lambda: "ws1", lambda: ("RM_x", "room-x"))
        ok3 = install(recorder, lambda: "ws1", lambda: ("RM_x", "room-x"))

        self.assertTrue(ok1)
        self.assertTrue(ok2)
        self.assertTrue(ok3)

        if before is not None:
            after = len(provider._active_span_processor._span_processors)
            self.assertEqual(after - before, 1, "install() must register exactly one processor")


class ThreadDispatchTests(unittest.TestCase):
    def test_on_end_from_foreign_thread_dispatches_via_run_coroutine_threadsafe(self) -> None:
        import threading

        recorder = _Recorder()

        async def main():
            loop = asyncio.get_running_loop()
            proc = DamasqasSpanProcessor(
                transport=recorder,
                workspace_id_provider="ws1",
                room_provider=lambda: ("RM_x", "room-x"),
                loop=loop,
            )

            # Fire on_end from a non-loop thread; the processor should
            # cross-thread schedule the send onto the captured loop.
            def fire_from_thread():
                proc.on_end(_function_tool_span())

            t = threading.Thread(target=fire_from_thread)
            t.start()
            t.join()

            # Yield so the cross-thread-scheduled task runs.
            await asyncio.sleep(0.05)

        asyncio.run(main())

        self.assertEqual(len(recorder.sent), 1)
        self.assertEqual(recorder.sent[0]["span_name"], "function_tool")


if __name__ == "__main__":
    unittest.main()
