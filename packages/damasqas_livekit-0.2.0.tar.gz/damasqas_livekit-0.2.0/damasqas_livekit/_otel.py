"""
OpenTelemetry span processor that extracts LiveKit Agents tool/LLM/STT/TTS
spans and forwards them to the Damasqas ingestion API as authoritative
per-call timing records.

Replaces the approximate per-tool timing previously derived from
``function_tools_executed`` event handler latency.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any, Optional

logger = logging.getLogger("damasqas_livekit")

# 2 MB hard ceiling on serialized event size. LLM-produced tool I/O is
# bounded by the model context window (~1 MB worst case); anything larger
# is a true outlier worth dropping rather than corrupting via truncation.
_MAX_EVENT_BYTES = 2 * 1024 * 1024

# LiveKit Agents 1.5+ span attribute names (see
# livekit.agents.telemetry.trace_types).
_ATTR_TOOL_ID = "lk.function_tool.id"
_ATTR_TOOL_NAME = "lk.function_tool.name"
_ATTR_TOOL_ARGS = "lk.function_tool.arguments"
_ATTR_TOOL_OUTPUT = "lk.function_tool.output"
_ATTR_TOOL_IS_ERROR = "lk.function_tool.is_error"
_ATTR_SPEECH_ID = "lk.speech_id"
_ATTR_GENERATION_ID = "lk.generation_id"

_REDACTED = "<redacted>"

# Default allow-list. Expanded by DAMASQAS_CAPTURE_CHILD_SPANS=1.
_DEFAULT_SPAN_NAMES = frozenset({"function_tool"})
_EXTRA_SPAN_NAMES = frozenset({"llm_node", "tts_node", "eou_detection"})

# Module-level guard so repeated monitor() calls in the same process don't
# stack multiple processors on the same TracerProvider — which would ship
# every span N times for N sessions and corrupt downstream aggregates.
_installed: bool = False


def _truthy_env(name: str) -> bool:
    return os.environ.get(name, "0").strip().lower() in ("1", "true", "yes", "on")


def _redact_enabled() -> bool:
    return _truthy_env("DAMASQAS_REDACT_TOOL_IO")


def _capture_child_spans() -> bool:
    return _truthy_env("DAMASQAS_CAPTURE_CHILD_SPANS")


def _format_span_id(span_id: int) -> str:
    return f"{span_id:016x}"


def _format_trace_id(trace_id: int) -> str:
    return f"{trace_id:032x}"


def _coerce_attr(value: Any) -> Any:
    """OTel attributes can be primitives, sequences, or BoundedAttributes.
    Convert to JSON-serializable form."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_coerce_attr(v) for v in value]
    return str(value)


def _build_tool_span_event(
    span: Any,
    workspace_id: Optional[str],
    room_sid: Optional[str],
    room_name: Optional[str],
) -> Optional[dict]:
    """Convert a ReadableSpan into a tool_span event dict.

    Returns None if the span should be skipped (e.g. payload exceeds the
    2 MB safety ceiling — dropped loudly via warn-log to avoid silent
    field-level corruption).
    """
    attrs = dict(getattr(span, "attributes", {}) or {})

    # Status: prefer explicit is_error attribute over span status, since
    # function_tool spans set is_error=True even when status remains UNSET.
    is_error_attr = attrs.get(_ATTR_TOOL_IS_ERROR)
    if is_error_attr is not None:
        status = "error" if is_error_attr else "ok"
    else:
        status_obj = getattr(span, "status", None)
        status_code = getattr(status_obj, "status_code", None)
        # opentelemetry.trace.StatusCode.ERROR == 2
        status = "error" if status_code is not None and getattr(status_code, "value", 0) == 2 else "ok"

    arguments = attrs.get(_ATTR_TOOL_ARGS)
    output = attrs.get(_ATTR_TOOL_OUTPUT)
    if _redact_enabled():
        if arguments is not None:
            arguments = _REDACTED
        if output is not None:
            output = _REDACTED

    span_ctx = span.get_span_context() if hasattr(span, "get_span_context") else None
    parent = getattr(span, "parent", None)
    parent_span_id: Optional[str] = None
    if parent is not None:
        # ReadableSpan.parent is a SpanContext. An invalid context (no
        # actual parent) reports span_id=0; emit None instead of the
        # nonsensical "0000000000000000" hex.
        is_valid = getattr(parent, "is_valid", True)
        if is_valid and getattr(parent, "span_id", 0):
            parent_span_id = _format_span_id(parent.span_id)

    start_ns = getattr(span, "start_time", 0) or 0
    end_ns = getattr(span, "end_time", 0) or 0
    duration_ms = max(0, int((end_ns - start_ns) / 1_000_000)) if end_ns and start_ns else 0

    # Use the span's end time (actual when-it-finished) as the event
    # timestamp. time.time() at SDK serialization could be 0–2s late
    # because of batching, which would corrupt time-bucketed aggregates.
    timestamp = (end_ns / 1_000_000_000) if end_ns else 0.0

    # Drop verbose attributes that are duplicated as top-level fields, keep
    # the rest as a JSONB blob for verifiability/debugging.
    extra_attrs = {
        k: _coerce_attr(v)
        for k, v in attrs.items()
        if k not in (_ATTR_TOOL_ARGS, _ATTR_TOOL_OUTPUT, _ATTR_TOOL_NAME, _ATTR_TOOL_ID, _ATTR_TOOL_IS_ERROR)
    }

    event = {
        "type": "tool_span",
        "workspace_id": workspace_id,
        "room_sid": room_sid,
        "room_name": room_name,
        "timestamp": timestamp,
        "span_name": span.name,
        "trace_id": _format_trace_id(span_ctx.trace_id) if span_ctx else None,
        "span_id": _format_span_id(span_ctx.span_id) if span_ctx else None,
        "parent_span_id": parent_span_id,
        "start_unix_nano": str(start_ns),
        "end_unix_nano": str(end_ns),
        "duration_ms": duration_ms,
        "status": status,
        "tool_name": attrs.get(_ATTR_TOOL_NAME),
        "call_id": attrs.get(_ATTR_TOOL_ID),
        "speech_id": attrs.get(_ATTR_SPEECH_ID),
        "generation_id": attrs.get(_ATTR_GENERATION_ID),
        "arguments": arguments if isinstance(arguments, str) else (json.dumps(arguments) if arguments is not None else None),
        "output": output if isinstance(output, str) else (json.dumps(output) if output is not None else None),
        "attributes": extra_attrs,
    }

    # Event-level safety ceiling: drop the whole event if it exceeds 2 MB.
    # Truncation is silent corruption and would defeat the verifiability
    # layer that depends on byte-exact arg/output capture.
    try:
        size = len(json.dumps(event, default=str).encode("utf-8"))
    except Exception as e:
        logger.warning(
            "damasqas_livekit: tool_span serialization probe failed (%s) — dropping event",
            e,
        )
        return None
    if size > _MAX_EVENT_BYTES:
        logger.warning(
            "damasqas_livekit: dropped oversize tool_span "
            "(tool_name=%s call_id=%s size_bytes=%d limit=%d)",
            event.get("tool_name"), event.get("call_id"), size, _MAX_EVENT_BYTES,
        )
        return None

    return event


class DamasqasSpanProcessor:
    """OpenTelemetry SpanProcessor that ships LiveKit tool spans to Damasqas.

    The SpanProcessor protocol's ``on_end`` may be invoked from any thread
    (OTel SDK's BatchSpanProcessor uses a worker thread, and even
    SimpleSpanProcessor inherits whatever thread ended the span). To
    safely dispatch to the asyncio transport regardless of caller thread,
    we capture the event loop reference at install time and use
    ``run_coroutine_threadsafe`` from foreign threads or ``create_task``
    when on-loop.
    """

    def __init__(
        self,
        transport: Any,
        workspace_id_provider: Any,
        room_provider: Any,
        loop: Optional[asyncio.AbstractEventLoop] = None,
    ) -> None:
        """
        Args:
            transport: MetricsTransport instance with .send(event).
            workspace_id_provider: callable returning workspace_id (or static value).
            room_provider: callable returning (room_sid, room_name) tuple.
            loop: event loop to dispatch transport.send onto. Captured at
                install-time so the processor is safe to invoke from
                worker threads (e.g. OTel BatchSpanProcessor pool).
        """
        self._transport = transport
        self._workspace_id_provider = workspace_id_provider
        self._room_provider = room_provider
        self._loop = loop
        self._allowed = set(_DEFAULT_SPAN_NAMES)
        if _capture_child_spans():
            self._allowed |= _EXTRA_SPAN_NAMES

    # SpanProcessor protocol
    def on_start(self, span: Any, parent_context: Any = None) -> None:
        return None

    def on_end(self, span: Any) -> None:
        try:
            if span.name not in self._allowed:
                return

            workspace_id = (
                self._workspace_id_provider()
                if callable(self._workspace_id_provider)
                else self._workspace_id_provider
            )
            try:
                room_sid, room_name = (
                    self._room_provider() if callable(self._room_provider) else (None, None)
                )
            except Exception:
                room_sid, room_name = None, None

            event = _build_tool_span_event(span, workspace_id, room_sid, room_name)
            if event is None:
                return

            self._dispatch(event)
        except Exception as e:
            logger.warning("damasqas_livekit: span processor on_end error: %s", e)

    def _dispatch(self, event: dict) -> None:
        """Schedule transport.send(event) on the asyncio loop, regardless
        of which thread on_end was called from."""
        coro = self._transport.send(event)

        # Prefer the loop captured at install time — that's the loop
        # the transport actually runs on.
        loop = self._loop
        if loop is None or loop.is_closed():
            # Fall back to "loop running in this thread" if we're on the
            # same thread as the asyncio agent.
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                logger.debug("damasqas_livekit: no event loop available; dropping span")
                # Close the coroutine to avoid "coroutine was never awaited"
                coro.close()
                return

        try:
            current = asyncio.get_running_loop()
        except RuntimeError:
            current = None

        if current is loop:
            loop.create_task(coro)
        else:
            # Cross-thread dispatch.
            asyncio.run_coroutine_threadsafe(coro, loop)

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True


def install(
    transport: Any,
    workspace_id_provider: Any,
    room_provider: Any,
) -> bool:
    """Install the Damasqas span processor on the active TracerProvider.

    Idempotent across calls in the same process — only the first call
    actually registers a processor. Subsequent calls return True without
    side effects so multi-session processes don't ship every span N
    times. Workspace/room context is provided via callables so each
    session contributes its own context (single processor, multiple
    contexts via the call-site provider — though in practice all sessions
    in a process share the same workspace token).

    If no real TracerProvider is registered (the global is still the
    NoOp/Proxy provider), creates one and installs it globally.

    Returns True if installation succeeded or was already done; False on
    import error.
    """
    global _installed
    if _installed:
        logger.debug("damasqas_livekit: OTel span processor already installed; skipping")
        return True

    try:
        from opentelemetry import trace as trace_api
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        logger.warning(
            "damasqas_livekit: opentelemetry-sdk not installed; "
            "tool span capture disabled"
        )
        return False

    current = trace_api.get_tracer_provider()
    if isinstance(current, TracerProvider):
        provider = current
    else:
        provider = TracerProvider()
        trace_api.set_tracer_provider(provider)

    # Capture the loop the agent runs on so the processor can dispatch
    # transport.send across threads safely. install() is called from
    # monitor() inside the agent's event loop, so get_running_loop()
    # succeeds in production. In test/non-async contexts loop stays None
    # and the processor's _dispatch will fall back to
    # asyncio.get_running_loop() at on_end-time or drop the event.
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    provider.add_span_processor(
        DamasqasSpanProcessor(transport, workspace_id_provider, room_provider, loop=loop)
    )

    # LiveKit caches its tracer on first import, so we must also push the
    # provider into livekit.agents.telemetry to update that cached tracer.
    try:
        from livekit.agents.telemetry import set_tracer_provider as lk_set_tracer
        lk_set_tracer(provider)
    except ImportError:
        # livekit-agents not installed (e.g. in test environments) — fine.
        pass
    except Exception as e:
        logger.warning(
            "damasqas_livekit: failed to register tracer provider with "
            "livekit.agents.telemetry: %s — function_tool spans created "
            "by already-imported LiveKit modules may not be captured",
            e,
        )

    _installed = True
    logger.info("damasqas_livekit: OTel span processor installed")
    return True


def _reset_for_tests() -> None:
    """Test-only: clear the installation guard so each test can re-install."""
    global _installed
    _installed = False
