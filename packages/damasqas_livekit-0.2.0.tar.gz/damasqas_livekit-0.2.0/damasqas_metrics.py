# damasqas_metrics.py -- copy-paste into your LiveKit agent project
#
# Forwards per-turn STT/LLM/TTS metrics from your LiveKit agent to
# Damasqas for infrastructure observability. Fire-and-forget: never
# blocks or slows down the voice pipeline.
#
# Requirements: httpx (pip install httpx)
#
# Usage:
#   import damasqas_metrics
#   damasqas_metrics.attach(session, room.sid, room.name)
#
# Environment variables:
#   DAMASQAS_METRICS_URL  (default: https://connect.damasqas.com/api/v1/metrics)
#   DAMASQAS_TOKEN        (your workspace API key)

import httpx
import os
from livekit.agents import AgentSession

DAMASQAS_URL = os.environ.get(
    "DAMASQAS_METRICS_URL", "https://connect.damasqas.com/api/v1/metrics"
)
DAMASQAS_TOKEN = os.environ.get("DAMASQAS_TOKEN")

_client = httpx.AsyncClient(timeout=5.0)


def attach(session: AgentSession, room_sid: str, room_name: str) -> None:
    """Attach the Damasqas metrics forwarder to a LiveKit AgentSession.

    Each call to attach() creates an independent turn counter scoped to this
    session, so concurrent calls in the same process don't corrupt each
    other's turn indexes.
    """
    turn_counter = 0

    @session.on("metrics_collected")
    async def on_metrics(metrics):
        if not DAMASQAS_TOKEN:
            return
        nonlocal turn_counter
        turn_counter += 1
        try:
            await _client.post(
                DAMASQAS_URL,
                json={
                    "room_sid": room_sid,
                    "room_name": room_name,
                    "turn_index": turn_counter,
                    "timestamp": (
                        metrics.timestamp.isoformat()
                        if hasattr(metrics, "timestamp")
                        else None
                    ),
                    "metrics": metrics.to_dict(),
                },
                headers={"Authorization": f"Bearer {DAMASQAS_TOKEN}"},
            )
        except Exception:
            pass  # fire-and-forget; never block the voice pipeline
