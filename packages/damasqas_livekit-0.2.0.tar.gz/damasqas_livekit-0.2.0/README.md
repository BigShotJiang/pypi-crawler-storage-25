# damasqas_livekit

Voice AI infrastructure monitoring for LiveKit agents. One line to monitor everything.

## Installation

```bash
pip install damasqas_livekit
```

## Usage

```python
import damasqas_livekit

# After starting your AgentSession:
damasqas_livekit.monitor(session)
```

Set `DAMASQAS_TOKEN` as an environment variable (your workspace API key).

## What It Captures

- **Pipeline metrics** — STT, LLM, TTS latencies per turn (grouped by speech_id)
- **Tool calls** — function name, duration, success/failure
- **Transcripts** — user and agent speech text
- **State transitions** — agent lifecycle (listening, thinking, speaking)
- **Session close** — end reason, errors, total turns

All telemetry is batched and sent asynchronously. The SDK never blocks or crashes your voice pipeline.

## Configuration

| Environment Variable | Required | Default |
|---|---|---|
| `DAMASQAS_TOKEN` | Yes | — |
| `DAMASQAS_URL` | No | `https://connect.damasqas.com/api/v1/voice/ingest` |

Or pass them directly:

```python
damasqas_livekit.monitor(session, token="your-token", url="https://...")
```
