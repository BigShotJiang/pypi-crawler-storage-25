# UFRJgic

Ferramentas em Python para acessar os recortes das matrizes insumo-produto anuais estimadas por Passoni & Freitas (2023). Os dados permanecem de Passoni & Freitas, porém o código do pacote foi desenvolvido por Felipe Morellli da Silva. O pacote expõe duas funções (`var` e `var_list`) que trabalham diretamente com os arquivos `.xlsx` distribuídos pelos autores.

## Estrutura preparada para o PyPI
- Código dentro de `src/UFRJgic/` utilizando layout baseado em `src`.
- Dicionário `variaveis_mip.csv` embalado no subpacote `UFRJgic.data` via `package-data`.
- `pyproject.toml` configurado com `setuptools`, dependências (`pandas`/`openpyxl`) e metadados do projeto.
- `passo1.py` mantido apenas por compatibilidade, reexportando o pacote.

## Instalação
### Desenvolvimento local
```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .
```

### PyPI (após publicar)
```bash
pip install UFRJgic
```

## Onde colocar os `.xlsx`
1. O caminho padrão é `./data/` relativo ao diretório onde o seu script é executado.
2. Para definir outro local globalmente, exporte a variável de ambiente `VAR_READER_DATA_DIR`:
```bash
export VAR_READER_DATA_DIR=/caminho/para/os/arquivos
```
3. Também é possível informar `base_dir=` diretamente ao chamar `var`.

## Guia rápido das funções `var` e `var_list`

1) A função `var()` retorna informações das matrizes estimadas por Passoni e Freitas (2023) a partir dos arquivos `.xlsx` localizados em `data/` (ou no diretório configurado).

01.1) Variáveis de entrada
- `ano`: 
  - arquivos com 67 atividades: 2010-2021
  - arquivos com 42 atividades: 2000-2021
  - `PAA` não inclui o ano inicial (2010 para 67 atividades, 2000 para 42 atividades)
- `n_atividade`: número de atividades (`42` ou `67`)
- `nome_aba` (sensível a maiúsculas): `Recursos`, `Usos`, `Usos Nacional`, `Usos Importado`, `Impostos`, `Comércio`*, `Transporte`*, `An`, `Am`, `Z`
  - `*` Abas `Comércio` e `Transporte` não existem nos arquivos `PCT`
- `codigo_variavel`: use `var_list(nome_aba, n_atividade)` para descobrir os códigos disponíveis
- `preco`: `PCR` (preços correntes, padrão), `PAA` (preço do ano anterior) ou `PCT` (unidades totais)

01.2) Exemplo
```python
from UFRJgic import var
ipi = var('2011', '67', 'Recursos', 'IPI', 'PCR')
print(ipi.head())
```

01.3) Limitações atuais
- Somente matrizes quadradas (PCR/PAA/PCT)
- Séries em volume (`PRL`) ainda não incorporadas

2) A função `var_list(nome_aba, n_atividade)` retorna um DataFrame com `codigo_variavel`, `descricao_variavel` e `dimensao` para aquela aba e dimensão. Utilize-a antes de chamar `var` para confirmar os códigos.

## Publicação
1. Atualize a versão em `pyproject.toml` e `UFRJgic.__version__`.
2. Gere os artefatos com `python -m build`.
3. Publique com `twine upload dist/*` (exige configuração da conta PyPI).

---

Fontes dos dados `.xlsx`:
- ALVES-PASSONI, Patieene; FREITAS, Fabio. *Estimação de Matrizes Insumo-Produto anuais para o Brasil no Sistema de Contas Nacionais Referência 2010*. Pesquisa e Planejamento Econômico (PPE), v. 53, n. 1 (jan/abr), 2023. Disponível em: https://repositorio.ipea.gov.br/bitstream/11058/13265/23/PPE_v53_n1_Artigo4_estimacao_de_matrizes.pdf
- ALVES-PASSONI, Patieene; FREITAS, Fabio. *Como deflacionar matrizes insumo-produto? Uma proposta de uma série deflacionada para o Brasil no SCN 2010*. Texto para Discussão 030/2022, Instituto de Economia/IE, UFRJ, 2022. Disponível em: https://www.ie.ufrj.br/images/IE/TDS/2022/TD_IE_030_2022_PASSONI_FREITAS.pdf
