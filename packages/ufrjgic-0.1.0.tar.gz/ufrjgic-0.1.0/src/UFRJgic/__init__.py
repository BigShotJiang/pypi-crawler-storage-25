"""Ferramentas para leitura das matrizes insumo-produto do MIP Brasil."""

from __future__ import annotations

import os
from importlib import resources
from pathlib import Path
from typing import Any, Optional

import pandas as pd

_ENV_VAR = 'VAR_READER_DATA_DIR'
_PCT_MISSING_ABAS = {name.casefold() for name in ('Comércio', 'Transporte')}
_AVAILABLE_RANGES = {67: (2010, 2021), 42: (2000, 2021)}
__version__ = '0.1.0'


def _load_dictionary() -> pd.DataFrame:
    csv_path = resources.files('UFRJgic.data').joinpath('variaveis_mip.csv')
    with csv_path.open('rb') as fp:
        return pd.read_csv(fp)


_DICT = _load_dictionary()


def _default_data_directory() -> Path:
    """Detecta o diretório com os arquivos `.xlsx` ou usa cwd/data."""
    env_path = os.environ.get(_ENV_VAR)
    if env_path:
        return Path(env_path)
    return Path.cwd() / 'data'


_DEFAULT_DATA_DIR = _default_data_directory()


def _resolve_bound(value: Any, n_atividade: int) -> int:
    """Resolve expressões como '6', 'N+5' ou 'N-1' para inteiros."""
    if isinstance(value, (int, float)) and float(value).is_integer():
        return int(value)

    text = str(value).strip().upper()
    if text.startswith('N'):
        if text == 'N':
            return n_atividade
        if text.startswith('N+'):
            return n_atividade + int(text[2:])
        if text.startswith('N-'):
            return n_atividade - int(text[2:])
        raise ValueError(f'Expressao nao suportada: {value!r}')
    return int(text)


def _select_entry(n_atividade: int, nome_aba: str, codigo_variavel: str) -> pd.Series:
    nome_aba_norm = nome_aba.strip().lower()
    codigo_norm = codigo_variavel.strip().upper()

    candidatos = _DICT[_DICT['n_atividade'] == n_atividade]
    candidatos = candidatos[candidatos['nome_aba'].str.lower() == nome_aba_norm]
    candidatos = candidatos[candidatos['codigo_variavel'].str.upper() == codigo_norm]
    if candidatos.empty:
        raise KeyError(
            f'Nao encontrei variavel com codigo "{codigo_variavel}" na aba "{nome_aba}" '
            f'para N={n_atividade}. Verifique variaveis_mip.csv.'
        )
    return candidatos.iloc[0]


def var(
    ano: str | int,
    n_atividade: str | int,
    nome_aba: str,
    codigo_variavel: str,
    preco: str = 'PCR',
    base_dir: Optional[Path | str] = None,
) -> pd.DataFrame:
    """Retorna o recorte solicitado de um arquivo MIP quadrado."""

    n_int = int(n_atividade)
    if n_int not in _AVAILABLE_RANGES:
        raise ValueError(
            f"Nao ha arquivos configurados para N={n_int}. Valores suportados: {sorted(_AVAILABLE_RANGES)}."
        )

    ano_int = int(ano)
    ano_str = str(ano_int)
    start_year, end_year = _AVAILABLE_RANGES[n_int]
    if not (start_year <= ano_int <= end_year):
        raise ValueError(
            f'Ano {ano_int} fora do intervalo [{start_year}, {end_year}] para N={n_int}.'
        )

    if base_dir is None:
        base_dir = _DEFAULT_DATA_DIR
    base_dir = Path(base_dir)

    entry = _select_entry(n_int, nome_aba, codigo_variavel)
    row_start = _resolve_bound(entry['linha_inicial'], n_int)
    row_end = _resolve_bound(entry['linha_final'], n_int)
    col_start = _resolve_bound(entry['coluna_inicial'], n_int)
    col_end = _resolve_bound(entry['coluna_final'], n_int)

    if row_start < 1 or col_start < 1:
        raise ValueError('Indices devem ser maiores ou iguais a 1.')

    preco_code = preco.strip().upper()
    if preco_code not in {'PCR', 'PAA', 'PCT'}:
        raise ValueError("Parametro 'preco' deve ser 'PCR', 'PAA' ou 'PCT'.")
    if preco_code == 'PAA' and ano_int == start_year:
        raise ValueError(
            f'Arquivos PAA nao incluem o ano inicial ({start_year}) para N={n_int}. '
            'Use ano ou preco diferente.'
        )

    aba_casefold = entry['nome_aba'].strip().casefold()
    if preco_code == 'PCT' and aba_casefold in _PCT_MISSING_ABAS:
        raise ValueError(
            'Aba "{0}" nao existe nos arquivos PCT. Use PCR ou PAA.'.format(entry['nome_aba'])
        )

    file_name = f'MIP_{ano_str}_{n_int}_quadrada_{preco_code}.xlsx'
    file_path = base_dir / file_name
    if not file_path.exists():
        raise FileNotFoundError(f'Arquivo {file_path} nao encontrado.')

    sheet_df = pd.read_excel(file_path, sheet_name=entry['nome_aba'], header=None)
    subset = sheet_df.iloc[row_start - 1:row_end, col_start - 1:col_end]
    subset.index = range(row_start, row_start + len(subset))
    subset.columns = range(col_start, col_start + subset.shape[1])
    return subset.reset_index(drop=True)


def var_list(nome_aba: str, n_atividade: str | int = '67') -> pd.DataFrame:
    """Lista as variaveis disponiveis para uma aba e dimensao."""

    aba_norm = nome_aba.strip().lower()
    n_int = int(n_atividade)
    subset = _DICT[
        (_DICT['nome_aba'].str.lower() == aba_norm)
        & (_DICT['n_atividade'] == n_int)
    ]

    if subset.empty:
        raise KeyError(
            f'Nao encontrei variaveis para a aba "{nome_aba}" com N={n_int}. '
            'Confirme o nome ou atualize variaveis_mip.csv.'
        )

    return subset[['codigo_variavel', 'descricao_variavel', 'dimensao']].reset_index(drop=True)


ATIVIDADES_67 = [
    "0191_Agricultura, inclusive o apoio à agricultura e a pós-colheita",
    "0192_Pecuária, inclusive o apoio à pecuária",
    "0280_Produção florestal; pesca e aquicultura",
    "0580_Extração de carvão mineral e de minerais não metálicos",
    "0680_Extração de petróleo e gás, inclusive as atividades de apoio",
    "0791_Extração de minério de ferro, inclusive beneficiamentos e a aglomeração",
    "0792_Extração de minerais metálicos não ferrosos, inclusive beneficiamentos",
    "1091_Abate e produtos de carne, inclusive os produtos do laticínio e da pesca",
    "1092_Fabricação e refino de açúcar",
    "1093_Outros produtos alimentares",
    "1100_Fabricação de bebidas",
    "1200_Fabricação de produtos do fumo",
    "1300_Fabricação de produtos têxteis",
    "1400_Confecção de artefatos do vestuário e acessórios",
    "1500_Fabricação de calçados e de artefatos de couro",
    "1600_Fabricação de produtos da madeira",
    "1700_Fabricação de celulose, papel e produtos de papel",
    "1800_Impressão e reprodução de gravações",
    "1991_Refino de petróleo e coquerias",
    "1992_Fabricação de biocombustíveis",
    "2091_Fabricação de químicos orgânicos e inorgânicos, resinas e elastômeros",
    "2092_Fabricação de defensivos, desinfestantes, tintas e químicos diversos",
    "2093_Fabricação de produtos de limpeza, cosméticos/perfumaria e higiene pessoal",
    "2100_Fabricação de produtos farmoquímicos e farmacêuticos",
    "2200_Fabricação de produtos de borracha e de material plástico",
    "2300_Fabricação de produtos de minerais não metálicos",
    "2491_Produção de ferro gusa/ferroligas, siderurgia e tubos de aço sem costura",
    "2492_Metalurgia de metais não ferosos e a fundição de metais",
    "2500_Fabricação de produtos de metal, exceto máquinas e equipamentos",
    "2600_Fabricação de equipamentos de informática, produtos eletrônicos e ópticos",
    "2700_Fabricação de máquinas e equipamentos elétricos",
    "2800_Fabricação de máquinas e equipamentos mecânicos",
    "2991_Fabricação de automóveis, caminhões e ônibus, exceto peças",
    "2992_Fabricação de peças e acessórios para veículos automotores",
    "3000_Fabricação de outros equipamentos de transporte, exceto veículos automotores",
    "3180_Fabricação de móveis e de produtos de indústrias diversas",
    "3300_Manutenção, reparação e instalação de máquinas e equipamentos",
    "3500_Energia elétrica, gás natural e outras utilidades",
    "3680_Água, esgoto e gestão de resíduos",
    "4180_Construção",
    "4580_Comércio por atacado e varejo",
    "4900_Transporte terrestre",
    "5000_Transporte aquaviário",
    "5100_Transporte aéreo",
    "5280_Armazenamento, atividades auxiliares dos transportes e correio",
    "5500_Alojamento",
    "5600_Alimentação",
    "5800_Edição e edição integrada à impressão",
    "5980_Atividades de televisão, rádio, cinema e gravação/edição de som e imagem",
    "6100_Telecomunicações",
    "6280_Desenvolvimento de sistemas e outros serviços de informação",
    "6480_Intermediação financeira, seguros e previdência complementar",
    "6800_Atividades imobiliárias",
    "6980_Atividades jurídicas, contábeis, consultoria e sedes de empresas",
    "7180_Serviços de arquitetura, engenharia, testes/análises técnicas e P & D",
    "7380_Outras atividades profissionais, científicas e técnicas",
    "7700_Aluguéis não imobiliários e gestão de ativos de propriedade intelectual",
    "7880_Outras atividades administrativas e serviços complementares",
    "8000_Atividades de vigilância, segurança e investigação",
    "8400_Administração pública, defesa e seguridade social",
    "8591_Educação pública",
    "8592_Educação privada",
    "8691_Saúde pública",
    "8692_Saúde privada",
    "9080_Atividades artísticas, criativas e de espetáculos",
    "9480_Organizações associativas e outros serviços pessoais",
    "9700_Serviços domésticos",
]


ATIVIDADES_42 = [
    "AT01_Agricultura, silvicultura, exploração florestal, pecuária e pesca",
    "AT02_Extração de petróleo e gás, inclusive as atividades de apoio",
    "AT03_Extração de minério de ferro, inclusive beneficiamentos e a aglomeração",
    "AT04_Outros da indústria extrativa",
    "AT05_Alimentos e Bebidas",
    "AT06_Fabricação de produtos do fumo",
    "AT07_Fabricação de produtos têxteis",
    "AT08_Confecção de artefatos do vestuário e acessórios",
    "AT09_Fabricação de calçados e de artefatos de couro",
    "AT10_Fabricação de produtos da madeira",
    "AT11_Fabricação de celulose, papel e produtos de papel",
    "AT12_Impressão e reprodução de gravações",
    "AT13_Refino de petróleo e coquerias",
    "AT14_Fabricação de biocombustíveis",
    "AT15_Fabricação de químicos orgânicos e inorgânicos, resinas e elastômeros",
    "AT16_Produtos farmacêuticos",
    "AT17_Perfumaria higiene e limpeza",
    "AT18_Fabricação de defensivos, desinfestantes, tintas e químicos diversos",
    "AT19_Artigos de borracha e plástico",
    "AT20_Cimento e outros produtos de minerais não-metálicos",
    "AT21_Fabricação de aço e derivados",
    "AT22_Metalurgia de metais não-ferrosos",
    "AT23_Produtos de metal - exclusive máquinas e equipamentos",
    "AT24_Máquinas e equipamentos e móveis e produtos das indústrias diversas",
    "AT25_Eletrodomésticos e material eletronico",
    "AT26_Automóveis camionetas caminhões e ônibus",
    "AT27_Peças e acessórios para veículos automotores",
    "AT28_Outros equipamentos de transporte",
    "AT29_Produção e distribuição de eletricidade gás água esgoto e limpeza urbana",
    "AT30_Construção civil",
    "AT31_Comércio",
    "AT32_Transporte armazenagem e correio",
    "AT33_Serviços de alojamento e alimentação",
    "AT34_Serviços de informação",
    "AT35_Intermediação financeira seguros e previdência complementar e serviços relacionados",
    "AT36_Atividades imobiliárias e aluguéis",
    "AT37_Serviços prestados às empresas e às famílias e serviços de manutenção",
    "AT38_Administração pública, defesa e seguridade social",
    "AT39_Educação pública",
    "AT40_Educação privada",
    "AT41_Saúde pública",
    "AT42_Saúde privada",
]


ABAS = [
    'recursos',
    'usos',
    'usos nacional',
    'usos importado',
    'impostos',
    'comércio',
    'transporte',
    'an',
    'am',
    'z',
]


PRECOS = ['PCR', 'PAA', 'PCT']


__all__ = [
    'var',
    'var_list',
    '__version__',
    'ATIVIDADES_42',
    'ATIVIDADES_67',
    'ABAS',
    'PRECOS',
]
