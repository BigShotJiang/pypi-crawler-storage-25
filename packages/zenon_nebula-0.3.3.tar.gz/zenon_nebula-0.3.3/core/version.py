# SPDX-License-Identifier: MIT
"""Nebula version — single source of truth for the installed version.

Read by: CLI (`nebula version`), MCP server, RPC responses, setup.py,
and the auto-updater. Bumped by scripts/release.py or GitHub Actions.
"""

__version__ = "0.3.3"
__version_info__ = (0, 3, 3)

# Protocol version -- bumps ONLY on breaking schema / transport changes.
# Two instances with the same PROTOCOL_VERSION can share findings even if
# their __version__ strings differ (e.g. 0.1.0 and 0.1.5 both speak
# protocol v1 and can safely exchange evidence). Bump this the moment a
# breaking change lands in:
#   - evidence table schema as exposed over transport
#   - NEBULA_RPC wire format
#   - transport.py publish/pull payload structure
PROTOCOL_VERSION = 1

# Build metadata (populated at release time)
BUILD_DATE = "2026-04-10"
BUILD_COMMIT = "unknown"


def get_version() -> str:
    """Return the full version string."""
    return __version__


def get_version_info() -> dict:
    """Return detailed version info for CLI + RPC."""
    return {
        "version": __version__,
        "major": __version_info__[0],
        "minor": __version_info__[1],
        "patch": __version_info__[2],
        "protocol_version": PROTOCOL_VERSION,
        "build_date": BUILD_DATE,
        "build_commit": BUILD_COMMIT,
    }


def is_compatible(other_version: str) -> bool:
    """Return True if this instance can share findings with ``other_version``.

    Compatibility rule: same major version number. We treat a major bump
    as the only kind of change that may break transport / schema contracts.
    Minor and patch versions are always considered compatible within a
    single major line. Callers that need stricter guarantees should check
    ``PROTOCOL_VERSION`` directly.
    """
    if not other_version:
        return False
    try:
        other_major = int(str(other_version).strip().split(".")[0])
        my_major = __version_info__[0]
        return other_major == my_major
    except (ValueError, IndexError):
        return False
