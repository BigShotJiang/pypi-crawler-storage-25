# SPDX-License-Identifier: MIT
"""
Finding persistence: write path for the evidence table.

Owns:
- persist_finding: primary entry point used by every engine
- classify_provenance: re-exported here so tests and callers can patch
- get_findings_by_engine / get_findings_by_domain: read helpers for findings
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from typing import Any

from core.api_fingerprint import classify_provenance
from core.models.finding import Finding
from core.persistence.schema import (
    DEFAULT_DB,
    _get_connection,
    ensure_schema,
)

logger = logging.getLogger(__name__)


# Engine-name → default source_repo registry. Used by ``persist_finding``
# to fill in ``source_repo`` for callers that don't pass it explicitly.
# This was added in v0.2.19 because 117 of 143 persist_finding calls
# in the codebase weren't passing source_repo and the evidence-chains
# trust model couldn't weight findings without it.
#
# Each entry maps an engine name to the repo it primarily scans. Add
# a new entry whenever you ship a new repo-scanning engine. Engines
# that work on live API data (treasury_monitor, market_data, etc.)
# stay out of the registry — they have no repo to attribute findings to.
_ENGINE_DEFAULT_REPO: dict[str, str] = {
    # Security domain — all scan go-zenon embedded contracts
    "adversarial_reviewer": "go-zenon",
    "static_analyzer": "go-zenon",
    "vuln_scanner": "go-zenon",
    "exploit_scanner": "go-zenon",
    "cve_monitor": "go-zenon",
    "attack_simulator": "go-zenon",
    "bridge_scanner": "go-zenon",
    "report_generator": "go-zenon",
    # Quality domain — verifiers and cross-repo checkers
    "spec_verifier": "go-zenon",
    "build_verifier": "go-zenon",
    "test_coverage": "go-zenon",
    "cross_repo_checker": "go-zenon",
    "sdk_verifier": "znn_sdk_dart",
    # Development domain — spec tracking and impl coverage
    "spec_tracker": "knowledge/developer-commons",
    "spec_audit": "knowledge/developer-commons",
    "impl_coverage": "go-zenon",
    "upstream_monitor": "knowledge/developer-commons",
    "spec_drift": "knowledge/developer-commons",
    "dependency_chain": "go-zenon",
    # Education domain
    "doc_quality": "knowledge/wiki",
    "onboarding_tracker": "knowledge/wiki",
    # Standards domain
    "bip_zip_tracker": "bitcoin/bips",
    "crypto_compliance": "go-zenon",
    "deployment_pipeline": "go-zenon",
    # Investigation domain — code archaeology
    "architecture_analyzer": "go-zenon",
    "vision_tracker": "knowledge/developer-commons",
    "historical_scanner": "go-zenon",
    "literature_engine": "knowledge/developer-commons",
    # curiosity_scanner samples every workspace repo and stamps its own
    # source_repo per finding, so it's intentionally absent from the
    # default-repo registry — each hit carries the repo it was sampled
    # from. The comment is here so nobody "fixes" the omission later.
    # Interoperability domain
    "bridge_compat": "go-zenon",
    "evm_readiness": "go-zenon",
    "consensus_monitor": "go-zenon",
}


def persist_finding(
    finding_obj: Finding | dict | None = None,
    *,
    db_path: str = DEFAULT_DB,
    **kwargs: Any,
) -> int:
    """Persist a finding to the evidence table.

    Accepts three call shapes so engines can migrate incrementally:

    1. ``persist_finding(my_finding_obj, db_path=...)`` -- new typed path
       using :class:`core.models.finding.Finding`.
    2. ``persist_finding({"domain": ..., ...}, db_path=...)`` -- plain
       dict, useful for ad-hoc constructors.
    3. ``persist_finding(db_path=..., domain=..., engine=..., finding=..., ...)``
       -- legacy keyword-only shape that every existing engine uses.

    The legacy ``finding`` kwarg is the finding text and is forwarded
    to the impl unchanged. The typed object goes in the positional
    ``finding_obj`` slot so the two never collide.

    Args:
        finding_obj: Optional :class:`Finding` or dict with finding
            fields. When provided, its fields are merged with ``kwargs``
            (kwargs win on conflict so callers can override one field
            at a time).
        db_path: Path to the SQLite database.
        **kwargs: Legacy keyword parameters -- see ``_persist_finding_impl``.

    Returns:
        Row ID of the inserted finding, or an existing ID on dedup.
    """
    data: dict[str, Any] = {}
    if isinstance(finding_obj, Finding):
        data.update(finding_obj.to_dict())
    elif isinstance(finding_obj, dict):
        data.update(finding_obj)
    elif finding_obj is not None:
        raise TypeError(
            "persist_finding expected Finding|dict|None as finding_obj, "
            f"got {type(finding_obj).__name__}"
        )

    # kwargs override any field already set by the Finding/dict so
    # callers can tweak a single attribute inline.
    data.update(kwargs)

    # Only forward keys the impl actually understands -- unknown keys
    # get dropped silently so engines adding new Finding attributes in
    # the future don't blow up the dispatcher.
    impl_kwargs = {key: value for key, value in data.items() if key in _IMPL_PARAMS}
    return _persist_finding_impl(db_path=db_path, **impl_kwargs)


def compute_content_hash(
    engine: str,
    evidence_type: str,
    finding: str,
    source_file: str | None = None,
    source_line: int | None = None,
    source_commit: str | None = None,
) -> str:
    """Return the canonical SHA-256 content hash for a finding.

    v0.3.3 introduces content-addressing so the same finding produced by
    multiple peers resolves to the same hash — a prerequisite for the
    anti-funnel trust model in task #46 (v0.4.0). Two peers finding the
    same bug in the same file at the same line should corroborate each
    other's hypothesis, not be treated as duplicates.

    The hash includes the exact source location (file + line + commit)
    so "same bug description, same file, different line" is correctly a
    different finding. Input fields are all normalized before hashing:
    the same inputs on two machines always produce the same hash.

    The hash is canonical — it's the key the future nebula_attestation
    on-chain contract will hash into attestation state, so changing
    this function after attestations exist would break every existing
    attestation. Treat the hashing logic as load-bearing forever.

    Args:
        engine: Engine that produced the finding.
        evidence_type: The evidence_type field.
        finding: The finding text (human-readable body).
        source_file: Optional source file path (relative to repo).
        source_line: Optional source line number.
        source_commit: Optional source commit hash.

    Returns:
        Hex-encoded SHA-256 digest.
    """
    payload = {
        "engine": engine,
        "evidence_type": evidence_type,
        "finding": finding,
        "source_file": source_file or "",
        "source_line": int(source_line) if source_line else 0,
        "source_commit": source_commit or "",
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _persist_finding_impl(
    db_path: str = DEFAULT_DB,
    domain: str = "system",
    engine: str = "",
    evidence_type: str = "",
    finding: str = "",
    confidence: float = 0.0,
    supports_hypothesis: str | None = None,
    contradicts_hypothesis: str | None = None,
    verification_url: str | None = None,
    raw_data: dict | None = None,
    fingerprints: list[dict] | None = None,
    run_id: str | None = None,
    parent_finding_id: int | None = None,
    source_repo: str | None = None,
    source_file: str | None = None,
    source_commit: str | None = None,
    source_line: int | None = None,
    reproducible_command: str | None = None,
    discoverer_peer_id: str | None = None,
    content_hash: str | None = None,
    signature: str | None = None,
) -> int:
    """Persist a finding to the evidence table.

    Args:
        domain:             Which domain produced this finding.
        engine:             Which engine produced it.
        evidence_type:      Type key (e.g. "blockstream_block", "code_review").
        finding:            Human-readable finding text.
        confidence:         Confidence score 0.0 to 1.0.
        supports_hypothesis: Hypothesis ID this supports.
        contradicts_hypothesis: Hypothesis ID this contradicts.
        verification_url:   URL where finding can be verified.
        raw_data:           Structured data dict.
        fingerprints:       API fingerprints from FingerprintedSession.
        run_id:             Which run produced this finding.
        parent_finding_id:  What finding triggered this investigation.

    Returns:
        Row ID of the inserted finding.
    """
    # Default source_repo by engine name. Pre-v0.2.19, 117 of 143
    # persist_finding calls didn't pass source_repo at all, so the
    # evidence-chains rule was effectively unenforced and the trust
    # model couldn't weight findings by repo provenance.
    #
    # This registry maps each engine that scans a known target to its
    # default repo. Engines that aggregate multiple repos (or work on
    # live API data with no repo) are intentionally absent — they MUST
    # pass source_repo explicitly per call when applicable, or leave
    # it None when there's no repo to attribute the finding to.
    if not source_repo:
        source_repo = _ENGINE_DEFAULT_REPO.get(engine)

    # Normalize source_repo to canonical identity (owner/repo) if it's a path
    if source_repo and "/" in source_repo and not source_repo.startswith("peer:"):
        try:
            import os

            workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
            candidate = os.path.join(workspace, source_repo) if workspace else source_repo
            if os.path.isdir(candidate):
                from core.git_cache import get_repo_identity

                source_repo = get_repo_identity(candidate)
        except Exception as exc:
            logger.debug("Source repo resolution failed for %s: %s", source_repo, exc)

    provenance = classify_provenance(fingerprints or [])
    fp_hash = ""
    if fingerprints:
        fp_hash = hashlib.sha256(json.dumps(fingerprints, sort_keys=True).encode()).hexdigest()

    conn = _get_connection(db_path)
    try:
        ensure_schema(db_path)

        # Plausibility gate: catch implausible findings before they enter the DB
        try:
            from core.plausibility_gate import check_plausibility

            _pg_finding = {
                "domain": domain,
                "engine": engine,
                "evidence_type": evidence_type,
                "finding": finding,
                "confidence": confidence,
                "source_repo": source_repo,
                "source_file": source_file,
            }
            _pg_verdict = check_plausibility(_pg_finding)
            if not _pg_verdict.plausible:
                logger.info(
                    "Plausibility gate REJECTED finding from %s/%s: %s",
                    domain,
                    engine,
                    "; ".join(_pg_verdict.flags[:2]),
                )
                return -1
            if _pg_verdict.adjusted_confidence is not None:
                logger.debug(
                    "Plausibility gate adjusted confidence %.3f -> %.3f",
                    confidence,
                    _pg_verdict.adjusted_confidence,
                )
                confidence = _pg_verdict.adjusted_confidence
        except Exception as _pg_exc:
            logger.debug("Plausibility gate skipped: %s", _pg_exc)

        # Compute content_hash if the caller didn't pass one in. This is
        # the canonical identity of the finding — same engine, same
        # type, same finding text, same source location = same hash on
        # every Nebula instance. Introduced in v0.3.3 as the foundation
        # for the v0.4.0 content-based trust model (task #46): two peers
        # independently producing the same finding no longer dedup each
        # other — they corroborate the same content_hash.
        if content_hash is None:
            content_hash = compute_content_hash(
                engine=engine,
                evidence_type=evidence_type,
                finding=finding,
                source_file=source_file,
                source_line=source_line,
                source_commit=source_commit,
            )

        # Dedup: prefer content_hash for rows that have one (v0.3.3+),
        # fall back to the legacy (engine, evidence_type, finding) key
        # ONLY against rows that have NULL content_hash (legacy rows).
        # This matters: two v0.3.3 findings with same text but
        # different source_file/source_line are DISTINCT findings with
        # different content_hashes, and we must not let the legacy
        # fallback wrongly collapse them. The fallback check
        # specifically targets `content_hash IS NULL` so it only fires
        # for rows written before v0.3.3.
        existing = conn.execute(
            "SELECT id FROM evidence WHERE content_hash = ? AND content_hash IS NOT NULL",
            (content_hash,),
        ).fetchone()
        if not existing:
            existing = conn.execute(
                "SELECT id FROM evidence "
                "WHERE engine = ? AND evidence_type = ? AND finding = ? "
                "AND content_hash IS NULL",
                (engine, evidence_type, finding),
            ).fetchone()
        if existing:
            logger.debug("Dedup: finding already exists as id=%d, skipping", existing[0])
            return existing[0]

        # Resolve discoverer_peer_id — default to the local peer
        # identity from core.transport when the caller didn't pass one.
        # A future v0.3.4 change wires this to the ZENON_PEER_ADDRESS
        # env var (task #39 v1) so every finding stamped on a
        # Zenon-address-configured instance is attributable to that
        # address. For now we fall back to the transport module's
        # random peer_id so the column is always populated.
        if discoverer_peer_id is None:
            try:
                from core.transport import get_local_peer_id

                discoverer_peer_id = get_local_peer_id()
            except Exception as exc:
                logger.debug("local peer_id lookup failed: %s", exc)
                discoverer_peer_id = None

        cursor = conn.execute(
            """INSERT INTO evidence
            (domain, engine, evidence_type, finding, confidence,
             supports_hypothesis, contradicts_hypothesis,
             verification_url, raw_data, provenance, published,
             run_id, parent_finding_id,
             source_repo, source_file, source_commit, source_line,
             reproducible_command,
             discoverer_peer_id, content_hash, signature)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                domain,
                engine,
                evidence_type,
                finding,
                confidence,
                supports_hypothesis,
                contradicts_hypothesis,
                verification_url,
                json.dumps(
                    {
                        "data": raw_data,
                        "provenance": provenance,
                        "fingerprint_hash": fp_hash,
                        "fingerprints": fingerprints or [],
                    }
                ),
                provenance,
                run_id,
                parent_finding_id,
                source_repo,
                source_file,
                source_commit,
                source_line,
                reproducible_command,
                discoverer_peer_id,
                content_hash,
                signature,
            ),
        )
        conn.commit()
        row_id = cursor.lastrowid
        logger.info(
            "Finding persisted: domain=%s engine=%s type=%s confidence=%.2f "
            "provenance=%s id=%d run=%s",
            domain,
            engine,
            evidence_type,
            confidence,
            provenance,
            row_id,
            run_id or "none",
        )

        # Auto-update hypothesis confidence if linked.
        # Lazy import to avoid a circular dependency between
        # persistence.findings and persistence.hypotheses during bootstrap.
        if supports_hypothesis:
            from core.persistence.hypotheses import _update_hypothesis_confidence

            _update_hypothesis_confidence(
                conn,
                supports_hypothesis,
                confidence,
                "support",
            )
        if contradicts_hypothesis:
            from core.persistence.hypotheses import _update_hypothesis_confidence

            _update_hypothesis_confidence(
                conn,
                contradicts_hypothesis,
                confidence,
                "contradict",
            )

        # Auto-archive high-confidence findings to vault
        if confidence >= 0.80:
            try:
                from core.evidence_vault import archive_finding as vault_archive

                vault_archive(
                    phase=f"evidence_{row_id}",
                    analysis_type=evidence_type,
                    fingerprints=fingerprints or [],
                    results_json=raw_data or {"finding": finding},
                    domain=domain,
                )
            except Exception as exc:
                logger.debug("Auto-archive failed: %s", exc)

        return row_id

    finally:
        conn.close()


# Computed once, after ``_persist_finding_impl`` is defined. The dispatcher
# consults this set to decide which keys from a Finding/dict to forward.
_IMPL_PARAMS = frozenset(
    _persist_finding_impl.__code__.co_varnames[: _persist_finding_impl.__code__.co_argcount]
) - {"db_path"}


def get_findings_by_engine(
    db_path: str,
    engine: str,
    domain: str | None = None,
) -> list[dict]:
    """Get all findings from a specific engine, optionally filtered by domain."""
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        if domain:
            rows = conn.execute(
                "SELECT * FROM evidence WHERE engine = ? AND domain = ? ORDER BY timestamp DESC",
                (engine, domain),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM evidence WHERE engine = ? ORDER BY timestamp DESC",
                (engine,),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_findings_by_domain(db_path: str, domain: str) -> list[dict]:
    """Get all findings for a specific domain."""
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT * FROM evidence WHERE domain = ? ORDER BY timestamp DESC",
            (domain,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


__all__ = [
    "classify_provenance",
    "get_findings_by_domain",
    "get_findings_by_engine",
    "persist_finding",
]
