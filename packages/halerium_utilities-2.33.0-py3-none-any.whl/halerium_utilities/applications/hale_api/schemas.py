
from pydantic import BaseModel, Field
from typing import List, Optional, Union, Any, Dict, Literal
import time

# --- Requests ---

class ResponseRequest(BaseModel):
    model: str
    input: str # For now simplified to string, can be list of messages
    instructions: Optional[str] = None
    previous_response_id: Optional[str] = None # Key change: previous_response_id
    stream: Optional[bool] = False
    temperature: Optional[float] = 1.0
    capability_configs: Optional[Dict[str, Dict[str, str]]] = None
    
# --- Responses (Blocking) ---

class ResponseUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class OutputTextContent(BaseModel):
    type: Literal["output_text"] = "output_text"
    text: str
    annotations: Optional[List[Any]] = None
    logprobs: Optional[Any] = None

class ResponseOutputItem(BaseModel):
    type: Literal["message"] = "message"
    role: Literal["assistant"] = "assistant"
    content: List[OutputTextContent] 
    id: Optional[str] = None
    phase: Optional[str] = None
    status: Optional[str] = None

class ResponseObject(BaseModel):
    id: str
    object: Literal["response"] = "response"
    created_at: int = Field(default_factory=lambda: int(time.time()))
    model: str
    output: List[ResponseOutputItem]
    status: Literal["completed", "in_progress", "failed", "cancelled", "incomplete"] = "completed"
    usage: Optional[ResponseUsage] = None
    
    # Optional fields for strict OpenAI SDK schema compatibility
    error: Optional[Any] = None
    truncation: Optional[Any] = None
    parallel_tool_calls: Optional[bool] = None
    prompt: Optional[str] = None
    service_tier: Optional[str] = None
    user: Optional[str] = None
    prompt_cache_key: Optional[str] = None
    reasoning: Optional[Any] = None
    text: Optional[str] = None
    background: Optional[bool] = None
    tools: Optional[List[Any]] = None
    max_output_tokens: Optional[int] = None
    instructions: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None
    conversation: Optional[str] = None
    previous_response_id: Optional[str] = None
    max_tool_calls: Optional[int] = None
    temperature: Optional[float] = None
    top_logprobs: Optional[Any] = None
    completed_at: Optional[int] = None
    top_p: Optional[float] = None
    safety_identifier: Optional[str] = None
    prompt_cache_retention: Optional[str] = None
    tool_choice: Optional[Any] = None
    incomplete_details: Optional[Any] = None

# --- Streaming Events ---

class ResponseTextDeltaEvent(BaseModel):
    type: Literal["response.output_text.delta"] = "response.output_text.delta"
    delta: str
    snapshot: Optional[str] = None # Optional snapshot of total text so far
    response_id: str
    output_index: int = 0
    content_index: int = 0

class ResponseTextDoneEvent(BaseModel):
    type: Literal["response.output_text.done"] = "response.output_text.done"
    text: str # Final text content
    response_id: str
    output_index: int = 0
    content_index: int = 0
    
class ResponseDoneEvent(BaseModel):
    type: Literal["response.done"] = "response.done"
    response: ResponseObject

# --- Chat Completions API (Standard OpenAI) ---

class CreateSessionRequest(BaseModel):
    model: str
    
class CreateSessionResponse(BaseModel):
    session_id: str
    model: str

class ChatMessage(BaseModel):
    role: str
    content: str
    # Note: we omit tool_calls, name, etc., for the basic MVP

class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[ChatMessage]
    stream: Optional[bool] = False
    temperature: Optional[float] = 1.0
    capability_configs: Optional[Dict[str, Dict[str, str]]] = None
    # Additional fields are ignored for now

class ChatCompletionMessage(BaseModel):
    role: str = "assistant"
    content: Optional[str] = None

class ChatCompletionChoice(BaseModel):
    index: int = 0
    message: ChatCompletionMessage
    finish_reason: Optional[str] = None

class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionChoice]
    usage: Optional[ResponseUsage] = None

class ChatCompletionStreamChoiceDelta(BaseModel):
    content: Optional[str] = None
    role: Optional[str] = None

class ChatCompletionStreamChoice(BaseModel):
    index: int = 0
    delta: ChatCompletionStreamChoiceDelta
    finish_reason: Optional[str] = None

class ChatCompletionChunk(BaseModel):
    id: str
    object: str = "chat.completion.chunk"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionStreamChoice]
