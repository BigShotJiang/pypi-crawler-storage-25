
import os
import json
import logging
from typing import Dict, List, Optional
from fastapi import HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger(__name__)

# Security scheme (Bearer token)
security = HTTPBearer()

def get_tokens_config() -> Optional[Dict[str, List[str]]]:
    """
    Attempts to read tokens from a local 'tokens.json' file.
    Expected format: {"token1": ["modelA", "modelB"], "token2": ["*"]}
    """
    config_path = os.getenv("HALE_API_TOKENS_FILE", "tokens.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                else:
                    logger.error(f"Invalid format in {config_path}. Expected a JSON dictionary.")
        except Exception as e:
            logger.error(f"Failed to read {config_path}: {e}")
    return None

def get_allowed_tokens_env() -> list[str]:
    """
    Retrieves allowed API tokens from the environment variable 'HALE_API_TOKENS'.
    Returns a list of tokens.
    """
    tokens_str = os.getenv("HALE_API_TOKENS", "").strip()
    if not tokens_str:
        return []
    return [t.strip() for t in tokens_str.split(",") if t.strip()]

async def verify_api_key(credentials: HTTPAuthorizationCredentials = Security(security)) -> str:
    """
    Verifies the Bearer token against configured tokens.
    Returns the token if valid, raises HTTPException otherwise.
    """
    token = credentials.credentials
    
    # 1. Check tokens.json file mapping
    tokens_config = get_tokens_config()
    if tokens_config is not None:
        if token in tokens_config:
            return token
        else:
            logger.warning(f"Unauthorized access attempt with token: {token[:4]}*** (not in tokens.json)")
            raise HTTPException(
                status_code=401,
                detail="Invalid or missing authentication token",
                headers={"WWW-Authenticate": "Bearer"},
            )
            
    # 2. Fallback to HALE_API_TOKENS env variable
    allowed_tokens = get_allowed_tokens_env()
    if not allowed_tokens:
        # No security configured!
        logger.warning("No API tokens configured (tokens.json and HALE_API_TOKENS missing). Allowing all requests.")
        return token

    if token not in allowed_tokens:
        logger.warning(f"Unauthorized access attempt with token: {token[:4]}***")
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return token

def verify_model_access(token: str, model_name: str):
    """
    Verifies if a specific token is allowed to access the requested model.
    Throws an HTTPException if access is denied.
    """
    tokens_config = get_tokens_config()
    
    if tokens_config is not None:
        # Strict mapping applies
        allowed_models = tokens_config.get(token, [])
        if "*" in allowed_models:
            return # Global access
        if model_name not in allowed_models:
            logger.warning(f"Token {token[:4]}*** denied access to model '{model_name}'. Allowed: {allowed_models}")
            raise HTTPException(
                status_code=403,
                detail=f"Token does not have permission to access model '{model_name}'.",
            )
            
    # If using HALE_API_TOKENS or insecure mode, all models are allowed.
    return
