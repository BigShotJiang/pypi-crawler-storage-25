"""
Document Reading
================
Halerium library – three async utility functions for PDF processing:

    read_pdf_range   – Extract plain text from a page range
    render_pdf_page  – Render a single page as a base64-encoded PNG (LLM-vision ready)
    ocr_pdf_inplace  – OCR a PDF via Google Vision with automatic deskewing

Dependencies (setup_commands):
    pip install pymupdf Pillow
"""

import asyncio
import base64
import io
import math
import os
import shutil
import statistics
import tempfile
from enum import Enum
from json import JSONDecodeError
from typing import Any, cast

import pymupdf
from httpx import HTTPError
from PIL import Image
from halerium_utilities.prompt.models import call_model_async


# ---------------------------------------------------------------------------
# Global constants
# ---------------------------------------------------------------------------

# Every image sent to Google Vision is uniformly scaled so that
# width × height == VISION_TARGET_MPIX.  This ensures consistent OCR quality
# regardless of original page size and avoids quota surprises.
VISION_TARGET_MPIX: int = 10_000_000  # 10 megapixels

# render_pdf_page output: image is scaled so its area equals this value.
# 3 megapixels provides a good balance between detail and payload size for LLM vision.
RENDER_PAGE_TARGET_MPIX: int = 3_000_000

# Maximum number of images per Vision API request.
VISION_BATCH_SIZE: int = 16

# Maximum allowed pixels on the longest side of a rendered page.
# This prevents extreme aspect ratios (e.g. 10000x1) from generating images
# with dimensions that crash the PyMuPDF or Pillow renderers, even if the
# total pixel area is bounded.
MAX_RENDER_SIDE_PX: int = 4000

# Minimum absolute skew angle (degrees) that triggers the deskew pipeline.
DESKEW_THRESHOLD_DEG: float = 0.5

# Number of words sampled per page to estimate the global skew angle.
ANGLE_SAMPLE_SIZE: int = 15

# Maximum number of Vision batches processed concurrently in ocr_pdf_inplace.
MAX_CONCURRENT_BATCHES: int = 4


# ---------------------------------------------------------------------------
# Internal page action states
# ---------------------------------------------------------------------------

class PageAction(str, Enum):
    """Possible processing outcomes for a single page in the OCR pipeline."""

    SKIPPED = "skipped"              # page excluded from OCR by the caller
    COPY_ORIGINAL = "copy_original"  # no text found; insert page as-is
    STRAIGHT = "straight"            # text found, page is level
    DESKEWED = "deskewed"            # text found, page has been rotated
    FAILED = "failed"                # Vision API call failed for this page


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_render_matrix(page: pymupdf.Page, target_mpix: int) -> tuple[pymupdf.Matrix, float]:
    """
    Return a render matrix and the effective scale factor (px / pt) for *page*.

    The scale is calculated so that the rendered image will have roughly
    ``target_mpix`` total pixels. This ensures both tiny and huge pages are
    rendered at an optimal resolution directly by PyMuPDF, preserving vector
    crispness without needing post-render upscaling.

    If the resulting dimensions exceed ``MAX_RENDER_SIDE_PX`` on either side
    due to an extreme aspect ratio, the scale is reduced to cap the longest
    side at that maximum.

    Parameters
    ----------
    page : pymupdf.Page
        The page to compute a render matrix for.
    target_mpix : int
        Target total pixel count (width × height) for the rendered image.

    Returns
    -------
    tuple[pymupdf.Matrix, float]
        ``(matrix, scale)`` where ``scale`` is the effective px-per-pt factor.

    Raises
    ------
    ValueError
        If the page has zero or negative area (malformed MediaBox).
    """
    rect: pymupdf.Rect = page.rect
    area_pt: float = rect.width * rect.height
    if area_pt <= 0:
        raise ValueError(
            f"Page has invalid area {area_pt} pt² "
            f"(rect={rect.width}×{rect.height}); cannot compute render matrix."
        )

    # scale^2 * area_pt = target_mpix  =>  scale = sqrt(target_mpix / area_pt)
    scale: float = math.sqrt(target_mpix / area_pt)

    # Cap the longest side to prevent extreme aspect ratios.
    longest_side_pt: float = max(rect.width, rect.height)
    if longest_side_pt * scale > MAX_RENDER_SIDE_PX:
        scale = MAX_RENDER_SIDE_PX / longest_side_pt

    return pymupdf.Matrix(scale, scale), scale


def _img_to_b64(img: Image.Image) -> str:
    """Encode a PIL Image as PNG and return the raw Base64 string (no data-URI prefix).

    Parameters
    ----------
    img : Image.Image
        The PIL image to encode.

    Returns
    -------
    str
        Raw Base64-encoded PNG data, without a ``data:image/png;base64,`` prefix.
    """
    buf: io.BytesIO = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


async def _call_vision_batch(b64_images: list[str]) -> list[list[dict]]:
    """
    Send a batch of Base64-encoded PNG images to the Halerium Google Vision
    model (``DOCUMENT_TEXT_DETECTION``) and return one ``textAnnotations``
    list per input image.

    The generator may yield one SSE event containing all N responses at once,
    or it may yield N individual SSE events with one response each.  We
    accumulate across all events so both patterns are handled correctly.

    Parameters
    ----------
    b64_images : list[str]
        Base64-encoded PNG images to send. Must not exceed ``VISION_BATCH_SIZE``.

    Returns
    -------
    list[list[dict]]
        One ``textAnnotations`` list per input image. Returns an empty inner
        list for any image where Vision found no text. If fewer responses
        arrive than images were sent, the missing entries are padded with
        empty lists.

    Raises
    ------
    ValueError
        If more images than ``VISION_BATCH_SIZE`` are passed.
    """
    if len(b64_images) > VISION_BATCH_SIZE:
        raise ValueError(
            f"Batch size {len(b64_images)} exceeds the Vision API limit of {VISION_BATCH_SIZE}."
        )

    body: dict[str, Any] = {
        "images": b64_images,
        "features": {"type": "DOCUMENT_TEXT_DETECTION"},
    }

    all_responses: list[dict] = []
    gen = call_model_async("google-vision", body=body, parse_data=True)
    async for sse in gen:
        if sse.data and sse.data.get("responses"):
            all_responses.extend(sse.data["responses"])

    return [
        all_responses[i].get("textAnnotations", []) if i < len(all_responses) else []
        for i in range(len(b64_images))
    ]


def _median_skew_angle(annotations: list[dict]) -> float:
    """
    Estimate the global page skew angle (in radians) from up to
    ``ANGLE_SAMPLE_SIZE`` word-level bounding boxes.

    The median of per-word baseline angles is used to suppress outliers from
    near-vertical tokens (punctuation, single letters) or misdetections.

    Google Vision clockwise vertex convention:
        0 = top-left, 1 = top-right, 2 = bottom-right, 3 = bottom-left

    The baseline vector runs from vertex 3 (bottom-left) → vertex 2
    (bottom-right).  In image coordinates (y increases downward):
        angle > 0  →  text tilted clockwise   (right side lower)
        angle < 0  →  text tilted CCW         (right side higher)
        angle ≈ 0  →  horizontal

    Note: ``atan2(dy, dx)`` is scale-invariant – the angle is the same
    whether computed from render-DPI or Vision-scaled coordinates.

    Parameters
    ----------
    annotations : list[dict]
        Full ``textAnnotations`` list from Vision.  Index 0 is the whole-page
        annotation (skipped); indices 1 … N are per-word annotations.

    Returns
    -------
    float
        Estimated skew angle in radians. Returns ``0.0`` if no reliable
        angle samples could be obtained.
    """
    # Vision returns words in document reading order, which is stable for
    # well-formed documents. Sampling the first ANGLE_SAMPLE_SIZE words is
    # therefore sufficient to estimate the global page skew.
    word_anns: list[dict] = annotations[1 : ANGLE_SAMPLE_SIZE + 1]
    angle_samples: list[float] = []

    for ann in word_anns:
        verts: list[dict] = ann.get("boundingPoly", {}).get("vertices", [])
        if len(verts) < 4:
            continue
        v3, v2 = verts[3], verts[2]
        dx: float = float(v2.get("x", 0)) - float(v3.get("x", 0))
        dy: float = float(v2.get("y", 0)) - float(v3.get("y", 0))
        # Exclude near-vertical tokens (e.g. "." or "I") where dx ≈ 0 makes
        # atan2 unreliable.  5 px is conservative at Vision-API resolution.
        if abs(dx) > 5:
            angle_samples.append(math.atan2(dy, dx))

    return statistics.median(angle_samples) if angle_samples else 0.0


def _deskew_and_crop(img: Image.Image, angle_deg: float) -> Image.Image:
    """
    Rotate *img* by *angle_deg* counter-clockwise and autocrop the resulting
    fill-colour triangles.

    PIL rotates CCW for positive angles.  Our skew angle (from ``atan2`` in
    image/y-down coordinates) is positive for a clockwise tilt, so rotating
    by ``+angle_deg`` CCW exactly cancels the tilt.

    ``expand=True`` enlarges the canvas so no content is clipped.
    The image is converted to greyscale and the result inverted so that all
    non-white pixels become non-zero; ``getbbox`` then locates the tightest
    bounding rectangle, which is used to crop away the fill-in triangles.
    Text and other dark content always produce large luminosity differences
    from white, so the greyscale approximation is lossless in practice.

    Note: pages with a dark or black background will receive white fill-colour
    triangles in the corners after rotation; those triangles fall inside the
    rectangular crop box and therefore remain visible.  This is a known
    limitation; a background-colour detection step would be needed to handle
    them correctly.

    Parameters
    ----------
    img : Image.Image
        The page image to deskew. Expected to have a predominantly white background.
    angle_deg : float
        Clockwise skew angle in degrees (as returned by ``_median_skew_angle`` after
        conversion via ``math.degrees``). A positive value tilts right; passing it
        directly rotates the image CCW to cancel the tilt.

    Returns
    -------
    Image.Image
        The rotated and auto-cropped image.
    """
    rotated: Image.Image = img.rotate(
        angle_deg,
        expand=True,
        resample=Image.Resampling.BICUBIC,
        fillcolor=(255, 255, 255),
    )

    gray: Image.Image = rotated.convert("L")
    mask: Image.Image = gray.point(lambda x: 0 if x == 255 else 255)
    crop_box: tuple[int, int, int, int] | None = mask.getbbox()
    return rotated.crop(crop_box) if crop_box else rotated


async def _call_vision_batch_with_retries(
    b64_images: list[str],
) -> tuple[list[list[dict]], list[bool]]:
    """
    Call ``_call_vision_batch`` with automatic retry logic.

    Attempts the full batch up to three times with a 1-second delay between
    retries.  If all batch attempts fail, each image is retried individually
    so that a single problematic image does not cause the entire batch to fail.

    Parameters
    ----------
    b64_images : list[str]
        Base64-encoded PNG images to send. Must not be empty.

    Returns
    -------
    tuple[list[list[dict]], list[bool]]
        ``(results, failed)`` where ``results[i]`` is the ``textAnnotations``
        list for image *i* and ``failed[i]`` is ``True`` if that image could
        not be processed even after individual retries.

    Raises
    ------
    ValueError
        If ``b64_images`` is empty.
    """
    if not b64_images:
        raise ValueError("b64_images must not be empty.")
    if len(b64_images) > VISION_BATCH_SIZE:
        raise ValueError(
            f"Batch size {len(b64_images)} exceeds the Vision API limit of {VISION_BATCH_SIZE}."
        )

    for attempt in range(3):
        try:
            res: list[list[dict]] = await _call_vision_batch(b64_images)
            return res, [False] * len(b64_images)
        except (HTTPError, JSONDecodeError):
            if attempt < 2:
                await asyncio.sleep(1)

    # Final attempt: retry each image individually to isolate failures.
    results, failed = [], []
    for b64 in b64_images:
        try:
            res = await _call_vision_batch([b64])
            results.append(res[0])
            failed.append(False)
        except (HTTPError, JSONDecodeError):
            results.append([])
            failed.append(True)
    return results, failed


async def _process_batch_vision(batch: list[dict], deskew: bool) -> None:
    """
    Run Vision OCR (and optional deskewing) on all non-skipped pages in *batch*.

    Mutates each page dict in-place, setting the ``"action"`` key and
    attaching ``"final_anns"`` as needed by ``_assemble_batch``.
    For deskewed pages ``"png_bytes"`` is overwritten with the rotated image.

    Parameters
    ----------
    batch : list[dict]
        Page dicts produced by the render loop in ``ocr_pdf_inplace``.
        Dicts with ``action == PageAction.SKIPPED`` are ignored.
    deskew : bool
        When ``True``, pages with a detected skew above ``DESKEW_THRESHOLD_DEG``
        are rotated and re-submitted to Vision for axis-aligned bounding boxes.
    """
    vision_batch: list[dict] = [
        rd for rd in batch if rd.get("action") != PageAction.SKIPPED
    ]
    if not vision_batch:
        return

    b64_pass1: list[str] = []
    for rd in vision_batch:
        with Image.open(io.BytesIO(rd["png_bytes"])) as pil:
            b64_pass1.append(_img_to_b64(pil))

    results_p1, failed_p1 = await _call_vision_batch_with_retries(b64_pass1)
    del b64_pass1

    annotations_pass1: dict[int, list[dict]] = {
        rd["page_idx"]: anns for rd, anns in zip(vision_batch, results_p1)
    }

    needs_pass2: list[dict] = []
    for i, rd in enumerate(vision_batch):
        if failed_p1[i]:
            rd["action"] = PageAction.FAILED
            continue

        anns: list[dict] = annotations_pass1.get(rd["page_idx"], [])
        # Index 0 in textAnnotations is the whole-page annotation; indices 1+
        # are per-word annotations.  Fewer than 2 entries means no words found.
        if len(anns) < 2:
            rd["action"] = PageAction.COPY_ORIGINAL
            continue

        angle_rad: float = _median_skew_angle(anns)
        angle_deg: float = math.degrees(angle_rad)

        if deskew and abs(angle_deg) > DESKEW_THRESHOLD_DEG:
            with Image.open(io.BytesIO(rd["png_bytes"])) as pil_p3:
                deskewed: Image.Image = _deskew_and_crop(pil_p3, angle_deg)
            deskewed_buf: io.BytesIO = io.BytesIO()
            deskewed.save(deskewed_buf, format="PNG")
            rd["png_bytes"] = deskewed_buf.getvalue()
            rd["action"] = PageAction.DESKEWED
            needs_pass2.append(rd)
        else:
            rd["action"] = PageAction.STRAIGHT
            rd["final_anns"] = anns

    if not needs_pass2:
        return

    b64_pass2: list[str] = []
    for rd in needs_pass2:
        with Image.open(io.BytesIO(rd["png_bytes"])) as pil_p4:
            b64_pass2.append(_img_to_b64(pil_p4))

    results_p2, failed_p2 = await _call_vision_batch_with_retries(b64_pass2)
    del b64_pass2

    for i, rd in enumerate(needs_pass2):
        if failed_p2[i]:
            rd["action"] = PageAction.FAILED
        else:
            rd["final_anns"] = results_p2[i] if len(results_p2[i]) >= 2 else []


def _assemble_batch(
    batch: list[dict],
    src_doc: pymupdf.Document,
    out_doc: pymupdf.Document,
    failed_pages: list[int],
) -> None:
    """
    Assemble OCR-processed pages from *batch* into *out_doc*.

    For pages with action ``COPY_ORIGINAL``, ``FAILED``, or ``SKIPPED``,
    the original page is copied verbatim from *src_doc* to preserve any
    existing vector content.  For ``STRAIGHT`` pages, the original vector page
    is reused and the invisible text overlay is written on top.  For
    ``DESKEWED`` pages a new raster page is created from the rotated image,
    then the overlay is applied.

    Parameters
    ----------
    batch : list[dict]
        Page dicts produced and annotated by ``_process_batch_vision``.
    src_doc : pymupdf.Document
        The source PDF (read-only).
    out_doc : pymupdf.Document
        The output PDF being built.
    failed_pages : list[int]
        Extended in-place with the 0-based page indices of pages whose
        Vision OCR call failed.
    """
    for rd in batch:
        action: PageAction = rd.get("action", PageAction.COPY_ORIGINAL)

        if action == PageAction.FAILED:
            failed_pages.append(rd["page_idx"])

        if action in (PageAction.COPY_ORIGINAL, PageAction.FAILED, PageAction.SKIPPED):
            out_doc.insert_pdf(src_doc, from_page=rd["page_idx"], to_page=rd["page_idx"])
            continue

        final_anns: list[dict] = rd.get("final_anns", [])
        # px_per_pt is the render scale used when producing png_bytes.
        # Vision bounding-box coordinates are in that same pixel space, so
        # dividing by px_per_pt converts them back to PDF points.
        px_per_pt: float = rd["render_scale_pt"]

        if action == PageAction.STRAIGHT:
            # Reuse the original vector page to preserve crispness.
            out_doc.insert_pdf(src_doc, from_page=rd["page_idx"], to_page=rd["page_idx"])
            new_page: pymupdf.Page = out_doc[-1]
            orig_page: pymupdf.Page = src_doc[rd["page_idx"]]
            offset_x: float = orig_page.rect.x0
            offset_y: float = orig_page.rect.y0
        else:  # PageAction.DESKEWED
            img_bytes: bytes = rd["png_bytes"]
            with Image.open(io.BytesIO(img_bytes)) as dim_pil:
                page_w_pt: float = dim_pil.width / px_per_pt
                page_h_pt: float = dim_pil.height / px_per_pt
            new_page = out_doc.new_page(width=page_w_pt, height=page_h_pt)
            new_page.insert_image(new_page.rect, stream=img_bytes)
            offset_x = 0.0
            offset_y = 0.0

        for ann in final_anns[1:]:
            word_text: str = ann.get("description", "")
            if not word_text.strip():
                continue
            verts: list[dict] = ann.get("boundingPoly", {}).get("vertices", [])
            if len(verts) < 4:
                continue
            bl, tl = verts[3], verts[0]
            pdf_x: float = offset_x + float(bl.get("x", 0)) / px_per_pt
            pdf_y: float = offset_y + float(bl.get("y", 0)) / px_per_pt
            box_h_px: float = abs(float(bl.get("y", 0)) - float(tl.get("y", 0)))
            font_size_pt: float = max(1.0, box_h_px / px_per_pt)
            try:
                new_page.insert_text(
                    point=pymupdf.Point(pdf_x, pdf_y),
                    text=word_text,
                    fontsize=font_size_pt,
                    fontname="helv",
                    render_mode=3,
                    overlay=False,
                    color=(0, 0, 0),
                )
            except RuntimeError:  # insert_text raises RuntimeError for unsupported glyphs
                continue


# ---------------------------------------------------------------------------
# 1. read_pdf_range
# ---------------------------------------------------------------------------

async def read_pdf_range(
    file_path: str,
    start_page: int,
    end_page: int,
) -> str:
    """
    Extract plain text from a range of PDF pages and return it as a string.

    Useful for quickly reading a PDF before launching a more expensive Vision
    or OCR operation (e.g. for pre-screening or summarisation).

    Parameters
    ----------
    file_path : str
        Absolute or relative path to the PDF file.
    start_page : int
        First page to read, **1-based** (first page of document = index 1).
    end_page : int
        Last page to read, **inclusive** and **1-based**.
        ``end_page=5`` reads pages 1–5.
        Pass ``-1`` or a value larger than the page count to read to the end.

    Returns
    -------
    str
        Concatenated plain text for all requested pages, separated by form-
        feed characters (``\\f``) so callers can split by page if needed.
        On error, a human-readable ``[ERROR]`` string is returned so the LLM
        can relay the message directly to the user.

    Notes
    -----
    ``page.get_text("text", sort=True)`` reorders text spans by vertical
    position first, then horizontal, preserving natural reading order even in
    multi-column layouts where the internal PDF stream order may differ.
    """
    if not os.path.isfile(file_path):
        return f"[ERROR] File not found: {file_path}"

    try:
        doc: pymupdf.Document = pymupdf.open(file_path)
    except RuntimeError as exc:
        return f"[ERROR] Could not open PDF '{file_path}': {exc}"

    page_count: int = doc.page_count

    start_idx = start_page - 1
    if end_page < 0 or end_page > page_count:
        end_idx = page_count
    else:
        end_idx = end_page

    if start_idx < 0 or start_idx >= page_count:
        doc.close()
        return (
            f"[ERROR] start_page={start_page} is out of range "
            f"(document has {page_count} pages, 1-based)."
        )

    if start_idx >= end_idx:
        doc.close()
        return (
            f"[ERROR] Invalid page range: start_page={start_page} must be "
            f"less than or equal to end_page={end_page} (document has {page_count} pages)."
        )

    extracted_pages: list[str] = []
    page_idx: int = start_page
    try:
        for page_idx in range(start_idx, end_idx):
            page: pymupdf.Page = doc[page_idx]
            text: str = cast(str, page.get_text("text", sort=True))
            extracted_pages.append(f"--- Page {page_idx + 1} ---\n{text.strip()}")
    except RuntimeError as exc:
        doc.close()
        return f"[ERROR] Text extraction failed on page {page_idx}: {exc}"

    doc.close()
    return "\f".join(extracted_pages)


# ---------------------------------------------------------------------------
# 2. render_pdf_page
# ---------------------------------------------------------------------------

async def view_pdf_page_as_image(
    file_path: str,
    page_number: int,
) -> dict[str, Any]:
    """
    Render a single PDF page as a PNG image, packaged in the Halerium result
    format ready for LLM vision tasks.

    The page is rendered directly to ``RENDER_PAGE_TARGET_MPIX`` (default 3 MPix)
    to balance detail and token usage for the LLM.

    Parameters
    ----------
    file_path : str
        Path to the PDF file.
    page_number : int
        The page to render, **1-based** (first page = 1).

    Returns
    -------
    dict
        Standard Halerium result format:

            {
                "result": {
                    "data": [
                        {
                            "content": "Page 1 of 5 – Rendered at 1732×1732 px",
                            "image/png": "<base64-encoded PNG, no data-URI prefix>"
                        }
                    ]
                }
            }

        On error, ``"content"`` holds the error message and ``"image/png"``
        is an empty string.
    """
    def _error_result(msg: str) -> dict[str, Any]:
        return {"error": msg}

    if not os.path.isfile(file_path):
        return _error_result(f"[ERROR] File not found: {file_path}")

    try:
        doc: pymupdf.Document = pymupdf.open(file_path)
    except RuntimeError as exc:
        return _error_result(f"[ERROR] Could not open PDF: {exc}")

    page_count: int = doc.page_count

    page_idx = page_number - 1
    if page_idx < 0 or page_idx >= page_count:
        doc.close()
        return _error_result(
            f"[ERROR] page_number={page_number} is out of range "
            f"(document has {page_count} pages, 1-based)."
        )

    page: pymupdf.Page = doc[page_idx]
    try:
        mat, _ = _get_render_matrix(page, RENDER_PAGE_TARGET_MPIX)
        pix: pymupdf.Pixmap = page.get_pixmap(matrix=mat, colorspace=pymupdf.csRGB, alpha=False)
        pil_img: Image.Image = Image.open(io.BytesIO(pix.tobytes("png")))
    except (ValueError, TypeError, OSError) as exc:
        doc.close()
        return _error_result(f"[ERROR] Rendering failed: {exc}")

    render_w, render_h = pix.width, pix.height
    del pix
    content_msg: str = (
        f"Page {page_idx + 1} of {page_count} – "
        f"Rendered at {render_w}×{render_h} px"
    )

    doc.close()
    return {
        "result": {
            "data": [{"content": content_msg, "image/png": _img_to_b64(pil_img)}]
        }
    }


# ---------------------------------------------------------------------------
# 3. ocr_pdf_inplace
# ---------------------------------------------------------------------------

async def ocr_pdf_inplace(
    file_path: str,
    in_place: bool = True,
    deskew: bool = False,
    pages: list[int] | None = None,
) -> str:
    """
    Run Google Vision OCR on a PDF and embed the recognised text as a horizontal
    invisible overlay, making the file fully text-searchable.

    Pages are processed in batches of up to ``VISION_BATCH_SIZE`` images, with
    up to ``MAX_CONCURRENT_BATCHES`` batches submitted to Vision concurrently.

    Parameters
    ----------
    file_path : str
        Path to the PDF file to process.
    in_place : bool, optional
        * ``True`` (default) – overwrite the original file.
        * ``False`` – write a new file with ``_ocr`` before the extension,
          e.g. ``report_ocr.pdf``.
    deskew : bool, optional
        When ``True``, pages with a detected skew above ``DESKEW_THRESHOLD_DEG``
        are rotated and re-submitted to Vision for axis-aligned bounding boxes.
    pages : list[int] | None, optional
        0-based page indices to OCR.  ``None`` (default) processes all pages.

    Returns
    -------
    str
        Human-readable success or error message prefixed with ``[OK]`` or
        ``[ERROR]``.
    """
    if not os.path.isfile(file_path):
        return f"[ERROR] File not found: {file_path}"

    try:
        doc: pymupdf.Document = pymupdf.open(file_path)
    except RuntimeError as exc:
        return f"[ERROR] Could not open PDF: {exc}"

    page_count: int = doc.page_count

    fd, tmp_out_path = tempfile.mkstemp(suffix=".pdf")
    os.close(fd)

    is_first_batch: bool = True
    failed_pages: list[int] = []
    batches_to_run: list[list[dict]] = []
    current_batch: list[dict] = []

    async def _flush_all_pending(
        pending: list[list[dict]],
        first_batch: bool,
    ) -> bool:
        """Process *pending* batches concurrently and assemble into the output PDF.

        Parameters
        ----------
        pending : list[list[dict]]
            Batches to process. Must not exceed ``MAX_CONCURRENT_BATCHES`` in length.
        first_batch : bool
            ``True`` if no output PDF has been written yet; determines whether to
            create a fresh file (``save``) or append incrementally (``saveIncr``).

        Returns
        -------
        bool
            ``False`` after successful processing; the unchanged *first_batch* value
            if *pending* was empty. The caller is responsible for clearing the batch
            list after each call.

        Raises
        ------
        ValueError
            If *pending* contains more batches than ``MAX_CONCURRENT_BATCHES``.
        """
        if not pending:
            return first_batch
        if len(pending) > MAX_CONCURRENT_BATCHES:
            raise ValueError(
                f"pending contains {len(pending)} batches, "
                f"exceeding MAX_CONCURRENT_BATCHES={MAX_CONCURRENT_BATCHES}."
            )

        await asyncio.gather(*[_process_batch_vision(b, deskew) for b in pending])

        out_doc: pymupdf.Document = pymupdf.open() if first_batch else pymupdf.open(tmp_out_path)
        for b in pending:
            _assemble_batch(b, doc, out_doc, failed_pages)

        if first_batch:
            out_doc.save(tmp_out_path, garbage=4, deflate=True)
        else:
            out_doc.saveIncr()
        out_doc.close()

        return False

    for page_idx in range(page_count):
        if pages is not None and page_idx not in pages:
            current_batch.append({"page_idx": page_idx, "action": PageAction.SKIPPED})
            if len(current_batch) >= VISION_BATCH_SIZE:
                batches_to_run.append(current_batch[:VISION_BATCH_SIZE])
                current_batch = current_batch[VISION_BATCH_SIZE:]
            continue

        page: pymupdf.Page = doc[page_idx]
        try:
            mat, render_scale_pt = _get_render_matrix(page, VISION_TARGET_MPIX)
            pix: pymupdf.Pixmap = page.get_pixmap(matrix=mat, colorspace=pymupdf.csRGB, alpha=False)
            png_bytes: bytes = pix.tobytes("png")
        except ValueError as exc:
            doc.close()
            if os.path.exists(tmp_out_path):
                os.remove(tmp_out_path)
            return f"[ERROR] Rendering page {page_idx} failed: {exc}"

        del pix

        current_batch.append({
            "page_idx": page_idx,
            "png_bytes": png_bytes,
            "render_scale_pt": render_scale_pt,
        })

        if len(current_batch) >= VISION_BATCH_SIZE:
            batches_to_run.append(current_batch[:VISION_BATCH_SIZE])
            current_batch = current_batch[VISION_BATCH_SIZE:]

        if len(batches_to_run) >= MAX_CONCURRENT_BATCHES:
            try:
                is_first_batch = await _flush_all_pending(
                    batches_to_run[:MAX_CONCURRENT_BATCHES], is_first_batch
                )
                batches_to_run = batches_to_run[MAX_CONCURRENT_BATCHES:]
            except OSError as exc:
                doc.close()
                if os.path.exists(tmp_out_path):
                    os.remove(tmp_out_path)
                return f"[ERROR] Batch assembly failed: {exc}"

    while current_batch:
        batches_to_run.append(current_batch[:VISION_BATCH_SIZE])
        current_batch = current_batch[VISION_BATCH_SIZE:]
    while batches_to_run:
        try:
            is_first_batch = await _flush_all_pending(
                batches_to_run[:MAX_CONCURRENT_BATCHES], is_first_batch
            )
            batches_to_run = batches_to_run[MAX_CONCURRENT_BATCHES:]
        except OSError as exc:
            doc.close()
            if os.path.exists(tmp_out_path):
                os.remove(tmp_out_path)
            return f"[ERROR] Final assembly failed: {exc}"

    doc.close()

    try:
        if in_place:
            output_path: str = file_path
        else:
            base_name, ext = os.path.splitext(file_path)
            output_path = f"{base_name}_ocr{ext}"

        if not is_first_batch:
            shutil.move(tmp_out_path, output_path)
        elif os.path.exists(tmp_out_path):
            os.remove(tmp_out_path)
    except OSError as exc:
        if os.path.exists(tmp_out_path):
            os.remove(tmp_out_path)
        return f"[ERROR] Could not save OCR PDF: {exc}"

    fail_msg: str = (
        f" ({len(failed_pages)} pages failed OCR: {failed_pages})" if failed_pages else ""
    )
    return (
        f"[OK] OCR complete – {page_count} page(s) processed.{fail_msg} "
        f"Saved to: {output_path}"
    )
