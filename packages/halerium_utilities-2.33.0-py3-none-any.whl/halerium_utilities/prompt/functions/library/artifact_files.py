import os
import datetime
import subprocess
import base64
import re
import tempfile
import mimetypes

import filetype
import pymupdf
from pptx import Presentation
from bs4 import BeautifulSoup

from halerium_utilities.collab.collab_text import CollabTextFile
from halerium_utilities.prompt.models import call_model_with_upload_async


COLLAB_TEXT_FILE_EXTENSIONS = ['py', 'txt', 'md']
TEXT_WHITELIST_EXTENSIONS = ['txt', 'py', 'md', 'csv', 'json', 'yaml', 'yml', 'xml', 'log', 'html', 'htm']

def _is_text_file(file_path, ext):
    if ext in TEXT_WHITELIST_EXTENSIONS:
        return True
    
    # Check mimetypes
    mime_type, _ = mimetypes.guess_type(file_path)
    if mime_type and mime_type.startswith("text/"):
        return True
        
    # Check magic bytes if filetype is installed
    if filetype is not None:
        if os.path.exists(file_path):
            kind = filetype.guess(file_path)
            if kind is None: # If filetype can't guess it, it's often plain text
                # We can do a quick heuristic by reading the first 1024 bytes and checking for null bytes
                try:
                    with open(file_path, 'rb') as f:
                        chunk = f.read(1024)
                        if b'\0' not in chunk:
                            return True
                except Exception:
                    pass
            elif kind.mime.startswith("text/"):
                return True
    else:
        # Simple heuristic fallback
        try:
            if os.path.exists(file_path):
                with open(file_path, 'rb') as f:
                    chunk = f.read(1024)
                    if chunk and b'\0' not in chunk:
                        return True
        except Exception:
            pass

    return False


async def get_file_metrics(file_path):
    if not os.path.exists(file_path):
        return {"error": f"File not found: {file_path}"}

    try:
        stat = os.stat(file_path)
        metrics = {
            "file_path": file_path,
            "size_bytes": stat.st_size,
            "last_modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat()
        }

        ext = file_path.split('.')[-1].lower()
        metrics["is_collab_text_file"] = (ext in COLLAB_TEXT_FILE_EXTENSIONS)
        supported_tools = ["get_file_metrics"]
        workflow = ""

        if _is_text_file(file_path, ext):
            supported_tools.extend(["read_text_file", "edit_text_file"])
            if ext in ['html', 'htm']:
                supported_tools.extend(["read_html_source", "view_html_as_image", "convert_to_pdf"])
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                metrics["total_lines"] = sum(1 for _ in f)

        elif ext == 'pdf' and pymupdf:
            supported_tools.extend(["read_pdf_range", "view_pdf_page_as_image", "ocr_pdf_inplace"])
            try:
                with pymupdf.open(file_path) as doc:
                    metrics["page_count"] = doc.page_count
            except Exception as e:
                metrics["page_count_error"] = str(e)
                
        elif ext in ['ppt', 'pptx'] and Presentation:
            supported_tools.extend(["convert_to_pdf"])
            workflow = "Convert to PDF first using convert_to_pdf, then use read_pdf_range or view_pdf_page_as_image."
            try:
                prs = Presentation(file_path)
                metrics["slide_count"] = len(prs.slides)
            except Exception as e:
                metrics["slide_count_error"] = str(e)
                
        elif ext in ['doc', 'docx']:
            supported_tools.extend(["convert_to_pdf"])
            workflow = "Convert to PDF first using convert_to_pdf, then use read_pdf_range or view_pdf_page_as_image."

        elif ext in ['mp3', 'wav', 'ogg', 'm4a', 'flac']:
            supported_tools.extend(["transcribe_audio"])
            try:
                result = subprocess.run(
                    ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                     "-of", "default=noprint_wrappers=1:nokey=1", file_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                if result.returncode == 0:
                    metrics["duration_seconds"] = float(result.stdout.strip())
                else:
                    metrics["duration_error"] = result.stderr.strip()
            except Exception as e:
                metrics["duration_error"] = str(e)

        metrics["supported_tools"] = supported_tools
        if workflow:
            metrics["recommended_workflow"] = workflow

        return metrics
    except Exception as e:
        return {"error": str(e)}

async def read_text_file(file_path, start_line=1, end_line=1000, show_line_numbers=False):
    if not os.path.exists(file_path):
        return f"Error: File not found: {file_path}"
        
    ext = file_path.split('.')[-1].lower()
    if not _is_text_file(file_path, ext):
        return "Error: Cannot read non-text files as text. Please check supported tools via get_file_metrics (e.g. use convert_to_pdf or read_pdf_range)."

    try:
        if ext in COLLAB_TEXT_FILE_EXTENSIONS:
            collab_file = CollabTextFile(file_path)
            await collab_file.pull_async()
            lines = collab_file.text.splitlines(keepends=True)
            if not lines and collab_file.text:
                lines = [collab_file.text]
        else:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()

        start_idx = max(0, start_line - 1)
        end_idx = min(len(lines), end_line)

        selected_lines = lines[start_idx:end_idx]

        if show_line_numbers:
            result = []
            for i, line in enumerate(selected_lines, start=start_idx + 1):
                line_str = line if line.endswith('\n') else line + '\n'
                result.append(f"{i: >4} | {line_str}")
            return "".join(result)
        else:
            return "".join(selected_lines)
    except Exception as e:
        return f"Error reading file: {str(e)}"

async def edit_text_file(file_path, edit_mode, search_text="", replace_text="", full_content=""):
    ext = file_path.split('.')[-1].lower()
    
    if os.path.exists(file_path) and not _is_text_file(file_path, ext):
        return "Error: Cannot edit non-text files as text."

    try:
        if edit_mode in ["rewrite", "append"]:
            os.makedirs(os.path.dirname(os.path.abspath(file_path)) or '.', exist_ok=True)
        
        if ext in COLLAB_TEXT_FILE_EXTENSIONS:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    f.write("")
            collab_file = CollabTextFile(file_path)
            await collab_file.pull_async()

            if edit_mode == "rewrite":
                current_len = len(collab_file.text)
                if current_len > 0:
                    collab_file.delete(0, current_len)
                if full_content:
                    collab_file.insert(0, full_content)
                await collab_file.push_async()
                return f"Successfully rewrote {file_path} via collab."

            elif edit_mode == "append":
                if full_content:
                    collab_file.append(full_content)
                    await collab_file.push_async()
                return f"Successfully appended to {file_path} via collab."

            elif edit_mode == "search_replace":
                if not search_text:
                    return "Error: `search_text` cannot be empty for search_replace."
                try:
                    collab_file.str_replace(search_text, replace_text)
                    await collab_file.push_async()
                    return f"Successfully replaced text in {file_path} via collab."
                except ValueError as ve:
                    return f"Error during collab search_replace: {ve}"
            else:
                return "Error: Invalid edit_mode. Must be 'rewrite', 'search_replace', or 'append'."
        
        else:
            if edit_mode == "rewrite":
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(full_content)
                return f"Successfully rewrote {file_path}."

            elif edit_mode == "append":
                with open(file_path, 'a', encoding='utf-8') as f:
                    f.write(full_content)
                return f"Successfully appended to {file_path}."

            elif edit_mode == "search_replace":
                if not os.path.exists(file_path):
                    return f"Error: File not found: {file_path}"

                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                occurrences = content.count(search_text)

                if occurrences == 0:
                    return "Error: `search_text` not found in the file."
                elif occurrences > 1:
                    return f"Error: `search_text` found {occurrences} times. Must be unique."

                new_content = content.replace(search_text, replace_text)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)

                return f"Successfully replaced text in {file_path}."
            else:
                return "Error: Invalid edit_mode. Must be 'rewrite', 'search_replace', or 'append'."
    except Exception as e:
        return f"Error editing file: {str(e)}"

async def convert_to_pdf(file_path, output_dir=None):
    if not os.path.exists(file_path):
        return f"Error: File not found: {file_path}"
    
    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(file_path)) or '.'

    try:
        result = subprocess.run(
            ["soffice", "--headless", "--convert-to", "pdf", file_path, "--outdir", output_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        if result.returncode == 0:
            base_name = os.path.splitext(os.path.basename(file_path))[0]
            expected_pdf_path = os.path.join(output_dir, f"{base_name}.pdf")
            if os.path.exists(expected_pdf_path):
                return f"Successfully converted to PDF: {expected_pdf_path}"
            else:
                return f"Conversion seemed successful, but could not find the output PDF at {expected_pdf_path}. stdout: {result.stdout}"
        else:
            return f"Error during conversion: {result.stderr}"
    except Exception as e:
        return f"Error running conversion command: {str(e)}"

async def transcribe_audio(file_path, language=None, diarize=False):
    if not os.path.exists(file_path):
        return f"Error: File not found: {file_path}"
    
    try:
        body = {
            "diarize": diarize,
        }
        if language:
            body["language"] = language

        gen = call_model_with_upload_async("nova2", file_path, body=body, parse_data=True)
        
        combined_transcript = ""
        async for sse in gen:
            if not sse.data:
                continue
            paragraphs = sse.data.get("paragraphs")
            if isinstance(paragraphs, dict):
                transcript = paragraphs.get("transcript")
                if transcript is not None:
                    combined_transcript += transcript

        if not combined_transcript:
            return "Transcription completed but returned no text."

        output_path = os.path.splitext(file_path)[0] + "_transcript.md"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"# Transcription for {os.path.basename(file_path)}\n\n")
            f.write(combined_transcript)
        
        return f"Transcription successful. Saved to {output_path}"
    except Exception as e:
        return f"Error during transcription: {str(e)}"

async def read_html_source(file_path):
    if not os.path.exists(file_path):
        return f"Error: File not found: {file_path}"
    
    if not BeautifulSoup:
        return "Error: BeautifulSoup is not installed."

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        soup = BeautifulSoup(content, 'html.parser')
        for script in soup(["script", "style"]):
            script.decompose()
            
        text = soup.get_text(separator='\n', strip=True)
        text = re.sub(r'\n\s*\n', '\n\n', text)
        return text
    except Exception as e:
        return f"Error parsing HTML: {str(e)}"

async def view_html_as_image(file_path):
    if not os.path.exists(file_path):
        return {"error": f"File not found: {file_path}"}
    
    try:
        abs_path = os.path.abspath(file_path)
        fd, temp_png = tempfile.mkstemp(suffix=".png")
        os.close(fd)
        
        result = subprocess.run(
            ["firefox", "--headless", "--screenshot", temp_png, f"file://{abs_path}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        if result.returncode == 0 and os.path.exists(temp_png):
            with open(temp_png, "rb") as f:
                img_b64 = base64.b64encode(f.read()).decode("utf-8")
            
            os.remove(temp_png)
            
            return {
                "result": {
                    "data": [
                        {
                            "content": f"Rendered HTML view of {os.path.basename(file_path)}",
                            "image/png": img_b64
                        }
                    ]
                }
            }
        else:
            if os.path.exists(temp_png):
                os.remove(temp_png)
            return {"error": f"Failed to render HTML. stdout: {result.stdout}, stderr: {result.stderr}"}
    except Exception as e:
        return {"error": f"Error rendering HTML: {str(e)}"}
