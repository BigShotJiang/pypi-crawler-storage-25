from string import ascii_letters, digits
from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field, model_validator


class ParameterModel(BaseModel):
    type: Literal["string", "number", "boolean", "object"]
    description: str = ""


class ParametersModel(BaseModel):
    properties: Optional[Dict[str, ParameterModel]] = Field(default_factory=dict)
    required: Optional[List[str]] = Field(default_factory=list)


class BaseFunctionModel(BaseModel):
    """
    Base class for function models containing common fields and validators.
    """
    function: str
    pretty_name: str = None
    group: Optional[str] = None
    description: str
    config_parameters: Dict[str, str] = Field(default_factory=dict)

    @model_validator(mode='before')
    def set_pretty_name(cls, values):
        if not values.get("pretty_name"):
            values['pretty_name'] = values.get('function')
        return values

    @model_validator(mode='before')
    def check_function_name(cls, values):
        function_name = values.get("function")
        if not function_name:
            # Pydantic will handle missing required field later
            return values
            
        if len(function_name) > (64-26):  # we reserve 26 chars for capability group id
            raise ValueError(
                f"'function' '{function_name}' is invalid. "
                "It must be at most 38 characters long.")
        allowed_start = ascii_letters + "_"
        allowed = ascii_letters + digits + "_"
        if not all(c in allowed for c in function_name):
            raise ValueError(
                f"'function' '{function_name}' is invalid. "
                "It must only contain ascii letters, numbers, underscores.")

        if not function_name[0] in allowed_start:
            raise ValueError(
                f"'function' '{function_name}' is invalid. "
                "It must start with an ascii letter or underscores.")

        return values


class FunctionModel(BaseFunctionModel):
    parameters: ParametersModel = Field(default_factory=ParametersModel)


class AutoFunctionModel(BaseFunctionModel):
    """
    Model for auto-functions that execute automatically before or after main prompt execution.
    
    Auto-functions are similar to regular functions but include an executeAt field
    that determines when they run relative to the main prompt.
    """
    executeAt: Literal['before', 'after']


class SecretParameterUpdate(BaseModel):
    """
    Model for updating secret configuration parameters.
    
    Allows either setting a new value or preserving the existing encrypted value.
    """
    value: Optional[str] = None  # New plaintext value to encrypt and store
    preserve: Optional[bool] = None  # If True, keep existing encrypted value


class SetupCommand(BaseModel):
    setupCommands: List[str] = Field(default_factory=list)


# Used for validation for create and get capability group methods
class CapabilityGroupModel(BaseModel):
    id: Optional[str] = None
    key: Optional[str] = None
    name: str = ""
    displayName: str = ""
    runnerType: Literal['nano', 'small', 'standard', 'performance', 'highend', 'gpu'] = "nano"
    sharedRunner: bool = False
    setupCommand: SetupCommand = Field(default_factory=SetupCommand)
    sourceCode: Optional[str] = None
    functions: List[FunctionModel] = Field(default_factory=list)
    autoFunctions: Optional[List[AutoFunctionModel]] = Field(default_factory=list)
    globalSystemMessage: Optional[str] = None
    globalConfigParameters: Optional[Dict[str, str]] = Field(default_factory=dict)
    globalSecretConfigParameters: Optional[Dict[str, Union[str, bool]]] = Field(default_factory=dict)

    @model_validator(mode='after')
    def check_unique_function_names(self):
        """Ensure function names are unique across both functions and autoFunctions."""
        func_names = [f.function for f in self.functions]
        auto_func_names = [f.function for f in (self.autoFunctions or [])]
        
        # Check for duplicates within lists (already handled by unique check logic if any, but good to double check)
        if len(func_names) != len(set(func_names)):
            raise ValueError("Duplicate function names found in 'functions' list.")
        
        if len(auto_func_names) != len(set(auto_func_names)):
            raise ValueError("Duplicate function names found in 'autoFunctions' list.")
            
        # Check for collision between lists
        collision = set(func_names) & set(auto_func_names)
        if collision:
            raise ValueError(f"Function names must be unique. The following names appear in both 'functions' and 'autoFunctions': {collision}")
            
        return self


# Used for validation for update capability group method (everything is optional)
class UpdateCapabilityGroupModel(BaseModel):
    name: Optional[str] = None
    displayName: Optional[str] = None
    runnerType: Optional[Literal['nano', 'small', 'standard', 'performance', 'highend', 'gpu']] = None
    sharedRunner: Optional[bool] = None
    setupCommand: Optional[SetupCommand] = None
    sourceCode: Optional[str] = None
    functions: Optional[List[FunctionModel]] = None
    autoFunctions: Optional[List[AutoFunctionModel]] = None
    globalSystemMessage: Optional[str] = None
    globalConfigParameters: Optional[Dict[str, str]] = None
    globalSecretConfigParameters: Optional[Dict[str, Union[str, SecretParameterUpdate]]] = None
    
    @model_validator(mode='after')
    def check_unique_function_names(self):
        """
        Ensure function names are unique across both functions and autoFunctions, 
        IF both are being updated simultaneously.
        """
        if self.functions is not None and self.autoFunctions is not None:
            func_names = [f.function for f in self.functions]
            auto_func_names = [f.function for f in self.autoFunctions]
            
            collision = set(func_names) & set(auto_func_names)
            if collision:
                raise ValueError(f"Function names must be unique. The following names appear in both 'functions' and 'autoFunctions': {collision}")
        
        return self
