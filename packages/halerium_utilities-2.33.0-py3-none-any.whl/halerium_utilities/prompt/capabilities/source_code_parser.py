import ast
import warnings
from typing import Optional, Set, List, Tuple
from halerium_utilities.logging.exceptions import CapabilityGroupException


class ImportUsageAnalyzer(ast.NodeVisitor):
    """
    AST visitor to analyze which names/imports are used by a specific function.
    """

    def __init__(self, function_name: str):
        self.function_name = function_name
        self.used_names = set()
        self.in_target_function = False

    def visit_FunctionDef(self, node):
        """Visit function definition nodes."""
        if node.name == self.function_name:
            self.in_target_function = True
            self.generic_visit(node)
            self.in_target_function = False
        else:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        """Visit async function definition nodes."""
        if node.name == self.function_name:
            self.in_target_function = True
            self.generic_visit(node)
            self.in_target_function = False
        else:
            self.generic_visit(node)

    def visit_Name(self, node):
        """Collect all names used in the target function."""
        if self.in_target_function:
            self.used_names.add(node.id)
        self.generic_visit(node)

    def visit_Attribute(self, node):
        """Collect attribute accesses in the target function."""
        if self.in_target_function and isinstance(node.value, ast.Name):
            self.used_names.add(node.value.id)
        self.generic_visit(node)


class SourceCodeTransformer:
    """
    Handles transformation of Python source code for capability groups.
    """

    @staticmethod
    def _get_import_names(node: ast.Import) -> Set[str]:
        """Extract names imported by an import statement."""
        return {alias.asname or alias.name for alias in node.names}

    @staticmethod
    def _get_importfrom_names(node: ast.ImportFrom) -> Set[str]:
        """Extract names imported by a from...import statement."""
        if node.names[0].name == '*':
            # Can't determine what's imported with star imports
            return set()
        return {alias.asname or alias.name for alias in node.names}

    @staticmethod
    def _parse_source(source_code: str) -> ast.AST:
        """Parse source code and raise informative error on failure."""
        if not source_code or not source_code.strip():
            return ast.parse("")

        try:
            return ast.parse(source_code)
        except SyntaxError as e:
            raise CapabilityGroupException(
                f"Invalid Python syntax in source code at line {e.lineno}: {e.msg}"
            ) from e

    @staticmethod
    def _get_imports_used_only_by_function(tree: ast.AST, function_name: str) -> Set[int]:
        """
        Identify import statements that are only used by the specified function.
        Returns a set of line numbers (0-based) of imports safe to remove.
        """
        # Analyze what names the target function uses
        analyzer = ImportUsageAnalyzer(function_name)
        analyzer.visit(tree)
        function_names = analyzer.used_names

        if not function_names:
            return set()

        # Collect all import information
        import_info = []  # List of (line_num, imported_names, node)
        for node in tree.body:
            if isinstance(node, ast.Import):
                names = SourceCodeTransformer._get_import_names(node)
                import_info.append((node.lineno - 1, names, node))
            elif isinstance(node, ast.ImportFrom):
                names = SourceCodeTransformer._get_importfrom_names(node)
                if names:  # Skip star imports
                    import_info.append((node.lineno - 1, names, node))

        # Check which other functions exist
        other_function_names = set()
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name != function_name:
                    # Analyze this other function
                    other_analyzer = ImportUsageAnalyzer(node.name)
                    other_analyzer.visit(tree)
                    other_function_names.update(other_analyzer.used_names)

        # Determine which imports are only used by target function
        imports_to_remove = set()
        for line_num, imported_names, node in import_info:
            # Check if ANY of the imported names are used ONLY by target function
            used_by_target = imported_names & function_names
            used_by_others = imported_names & other_function_names

            # Only remove if import is used by target AND not used by others
            if used_by_target and not used_by_others:
                # Include all lines of multi-line import
                start_line = node.lineno - 1
                end_line = node.end_lineno - 1 if hasattr(node, 'end_lineno') else start_line
                for line in range(start_line, end_line + 1):
                    imports_to_remove.add(line)

        return imports_to_remove

    @staticmethod
    def validate_and_parse_function(source_code: str, expected_function_name: Optional[str] = None) -> ast.AST:
        """
        Validate that source code contains a valid function definition.

        Parameters
        ----------
        source_code : str
            The source code to validate
        expected_function_name : str, optional
            If provided, verify the function has this name

        Returns
        -------
        ast.AST
            Parsed AST tree

        Raises
        ------
        CapabilityGroupException
            If validation fails
        """
        tree = SourceCodeTransformer._parse_source(source_code)

        # Find function definitions in the source
        functions = [node for node in tree.body
                     if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]

        if not functions:
            raise CapabilityGroupException(
                "Source code must contain at least one function definition"
            )

        if len(functions) > 1:
            warnings.warn(
                f"Source code contains {len(functions)} functions. "
                "Only the first will be registered with the capability group.",
                UserWarning
            )

        if expected_function_name:
            actual_name = functions[0].name
            if actual_name != expected_function_name:
                raise CapabilityGroupException(
                    f"Function name mismatch: expected '{expected_function_name}', "
                    f"found '{actual_name}' in source code"
                )

        return tree

    @staticmethod
    def remove_function_from_source(source_code: str, function_name: str) -> str:
        """
        Remove a function and its exclusive imports from source code.

        Parameters
        ----------
        source_code : str
            The original source code
        function_name : str
            Name of function to remove

        Returns
        -------
        str
            Updated source code with function removed
        """
        if not source_code or not source_code.strip():
            return ""

        tree = SourceCodeTransformer._parse_source(source_code)

        # Find the target function
        target_func = None
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
                target_func = node
                break

        if not target_func:
            warnings.warn(
                f"Function '{function_name}' not found in source code. "
                "Source code unchanged.",
                UserWarning
            )
            return source_code.strip()

        # Get imports that can be safely removed
        imports_to_remove = SourceCodeTransformer._get_imports_used_only_by_function(tree, function_name)

        # Get function line range
        func_start = target_func.lineno - 1
        func_end = target_func.end_lineno - 1 if hasattr(target_func, 'end_lineno') else func_start
        func_lines = set(range(func_start, func_end + 1))

        # Combine lines to remove
        lines_to_remove = func_lines | imports_to_remove

        # Rebuild source code
        lines = source_code.splitlines()
        new_lines = [line for idx, line in enumerate(lines) if idx not in lines_to_remove]

        result = '\n'.join(new_lines).strip()

        # Remove excessive blank lines (more than 2 consecutive)
        import re
        result = re.sub(r'\n\n\n+', '\n\n', result)

        return result

    @staticmethod
    def _extract_imports_as_strings(source: str) -> Set[str]:
        """Extract import statements as normalized strings."""
        if not source.strip():
            return set()
            
        tree = SourceCodeTransformer._parse_source(source)
        imports = set()
        
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                # We normalize by unparsing, which handles formatting differences
                # effectively standardizing them for comparison.
                imports.add(ast.unparse(node))
                
        return imports

    @staticmethod
    def _extract_function_code(source: str) -> str:
        """Extract the function definition code block, preserving comments/decorators."""
        if not source.strip():
            return ""
            
        tree = SourceCodeTransformer._parse_source(source)
        
        # Find the first function definition
        func_node = None
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_node = node
                break
                
        if not func_node:
            # Fallback: if no function node found (e.g. only imports provided?), return empty
            return ""
            
        # Get lines corresponding to the function
        lines = source.splitlines()
        
        # We want to capture decorators too if they exist
        start_line = func_node.lineno - 1
        if func_node.decorator_list:
            # Start from the first decorator
            start_line = func_node.decorator_list[0].lineno - 1
            
        end_line = func_node.end_lineno - 1 if hasattr(func_node, 'end_lineno') else start_line
        
        # Extract lines
        func_lines = lines[start_line:end_line + 1]
        
        return '\n'.join(func_lines)

    @staticmethod
    def add_function_to_source(existing_source: str, new_function_code: str, function_name: str) -> str:
        """
        Add a function to existing source code non-destructively.

        Parameters
        ----------
        existing_source : str
            Existing source code
        new_function_code : str
            Source code of new function (may include imports)
        function_name : str
            Name of the function being added

        Returns
        -------
        str
            Combined source code
        """
        # Validate the new function code
        SourceCodeTransformer.validate_and_parse_function(new_function_code, function_name)

        # Check for duplicate function names
        if existing_source.strip():
            existing_tree = SourceCodeTransformer._parse_source(existing_source)
            existing_func_names = {
                node.name for node in existing_tree.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
            if function_name in existing_func_names:
                raise CapabilityGroupException(
                    f"Function '{function_name}' already exists in capability group. "
                    "Use update instead of add."
                )

        # Identify imports
        existing_imports = SourceCodeTransformer._extract_imports_as_strings(existing_source)
        
        # Parse new code to separate imports and function
        new_tree = SourceCodeTransformer._parse_source(new_function_code)
        new_imports = set()
        new_func_node = None
        
        for node in new_tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                new_imports.add(ast.unparse(node))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not new_func_node:
                new_func_node = node

        # Calculate missing imports
        missing_imports = new_imports - existing_imports
        
        # Extract function code block from new code (preserving formatting)
        # We assume the new code is just imports + function
        function_code = SourceCodeTransformer._extract_function_code(new_function_code)
        
        # Construct result
        parts = []
        
        # 1. Existing Source
        if existing_source.strip():
            parts.append(existing_source.strip())
            
        # 2. Missing Imports (prepend or append? If we append to existing source which might have imports at top...
        # Ideally imports go to top. But prepending to existing_source string is tricky if it has docstrings.
        # However, Python allows imports anywhere. Appending imports *after* existing source but *before* new function 
        # is safe but ugly. Prepending to top is standard.)
        
        # Let's prepend to top for clean style, assuming standard file layout.
        if missing_imports:
            imports_block = '\n'.join(sorted(missing_imports))
            # Insert at the very beginning
            if parts:
                parts.insert(0, imports_block)
            else:
                parts.append(imports_block)

        # 3. New Function
        if function_code:
            parts.append(function_code)
            
        return '\n\n'.join(parts)
