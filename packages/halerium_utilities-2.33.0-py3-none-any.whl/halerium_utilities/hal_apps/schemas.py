from typing import List, Literal, Optional
from pydantic import BaseModel, Field

class CustomAppParams(BaseModel):
    startCmd: List[str]
    workingDirectory: str = "/"

class HalAppConfig(BaseModel):
    name: str
    description: str = ""
    appType: Literal["custom"] = "custom"
    accessType: Literal["workspace", "company", "company-user-groups", "public"] = "workspace"
    # Updated to match exactly the official list from BaseAppConfig.ts
    defaultRunnerType: Literal["nano", "small", "standard", "performance", "highend", "gpu"] = "nano"
    appParams: CustomAppParams

class HalAppPayload(BaseModel):
    appConfig: HalAppConfig
