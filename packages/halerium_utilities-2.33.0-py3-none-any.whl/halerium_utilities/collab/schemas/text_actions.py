from pydantic.v1 import BaseModel, Field, validator
from typing import Dict, List, Literal, Union


class StrReplacePayload(BaseModel):
    """Payload for str_replace action."""
    old_str: str = Field(
        description="The exact text to find and replace (must match exactly once)",
        min_length=1
    )
    new_str: str = Field(
        description="The replacement text"
    )


class InsertPayload(BaseModel):
    """Payload for insert action."""
    index: int = Field(
        description="The position to insert text at",
        ge=0
    )
    text: str = Field(
        description="The text to insert"
    )


class DeletePayload(BaseModel):
    """Payload for delete action."""
    index: int = Field(
        description="The position to start deleting from",
        ge=0
    )
    length: int = Field(
        description="The number of characters to delete",
        ge=0
    )


class AppendPayload(BaseModel):
    """Payload for append action."""
    text: str = Field(
        description="The text to append"
    )


class TextAction(BaseModel):
    """A single text action to perform on a document."""
    type: Literal["str_replace", "insert", "delete", "append"] = Field(
        description=("The type of the specific action to perform. "
                     "Valid values are str_replace, insert, delete, append."),
        example="str_replace"
    )
    payload: Union[Dict, StrReplacePayload, InsertPayload, DeletePayload, AppendPayload] = Field(
        description="The corresponding payload for the action.",
        example={"old_str": "Hello", "new_str": "Hi"}
    )

    @validator("payload")
    def validate_payload(cls, t, values):
        action_type = values.get("type", "str_replace")
        if action_type == "str_replace":
            schema = StrReplacePayload
        elif action_type == "insert":
            schema = InsertPayload
        elif action_type == "delete":
            schema = DeletePayload
        elif action_type == "append":
            schema = AppendPayload
        else:
            raise ValueError(f"Unknown action type: {action_type}")

        return schema.validate(t)


class TextActions(BaseModel):
    """Collection of text actions to perform on a document."""
    actions: List[TextAction] = Field(
        description="The array of text actions to perform",
        min_items=1,
        example=[
            {
                "type": "str_replace",
                "payload": {
                    "old_str": "Hello",
                    "new_str": "Hi"
                }
            }
        ]
    )
