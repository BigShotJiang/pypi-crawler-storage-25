import httpx
import logging
import os
from pathlib import Path
from typing import Any, Dict, Union
from urllib.parse import urljoin, quote

from halerium_utilities.collab import schemas as collab_schemas
from halerium_utilities.utils.api_config import get_api_headers, get_api_base_url
from halerium_utilities.utils.workspace_paths import runner_path_to_workspace_path


class CollabTextFile:
    """
    A class to communicate with the collaboration server for text documents.

    The class provides pull and push methods to keep the in-memory text
    in sync with the one on the collaboration server. The class is designed
    to be used on a runner but can be initialized elsewhere as well with the
    optional arguments in the init.
    """

    def __init__(self, path: Union[str, Path, os.PathLike],
                 url: str = None, headers: Dict[str, Any] = None,
                 pull_on_init: bool = True,
                 check_if_path_exists: bool = True):
        """
        Initialize a CollabTextFile instance.

        Parameters
        ----------
        path : Union[str, Path, os.PathLike]
            The path to the text file.
        url : str, optional
            The URL of the collaboration server. If not provided, it will be
            constructed from environment variables.
        headers : Dict[str, Any], optional
            The headers to use for HTTP requests. If not provided, it will be
            constructed from environment variables.
        pull_on_init : bool, optional
            Whether to pull the text from the collaboration server upon
            initialization. Defaults to True.
        check_if_path_exists : bool, optional
            Whether to check if the text file exists at the specified path.
            Defaults to True.
        """
        self.file_path = Path(path)
        if check_if_path_exists:
            if not self.file_path.exists():
                raise FileNotFoundError(f"{self.file_path} could not be found.")

        if url is None:
            workspace_path = runner_path_to_workspace_path(self.file_path).lstrip("/")
            url = get_api_base_url() + "/collab/docs/" + quote(workspace_path, safe='')

        self.url = url

        if headers is None:
            headers = get_api_headers()
        self.headers = headers

        self._text = ""
        self._actions = []

        if pull_on_init:
            self.pull()

    def __eq__(self, other):
        """
        Check equality between two CollabTextFile instances.

        Parameters
        ----------
        other : CollabTextFile
            The other CollabTextFile instance to compare with.

        Returns
        -------
        bool
            True if both instances are equal, False otherwise.
        """
        if isinstance(other, CollabTextFile):
            return (self._text == other._text and
                    self._actions == other._actions)
        return False

    @property
    def text(self) -> str:
        """
        Get the current text content.

        Returns
        -------
        str
            The current text content.
        """
        return self._text

    def _reapply_actions(self):
        """Reapply pending actions to the text after a pull."""
        for action in self._actions:
            try:
                if action.type == "str_replace":
                    self._apply_str_replace(
                        action.payload.old_str,
                        action.payload.new_str
                    )
                elif action.type == "insert":
                    self._apply_insert(
                        action.payload.index,
                        action.payload.text
                    )
                elif action.type == "delete":
                    self._apply_delete(
                        action.payload.index,
                        action.payload.length
                    )
                elif action.type == "append":
                    self._apply_append(action.payload.text)
                else:
                    raise TypeError(f"Unknown action type {action.type}.")
            except (ValueError, IndexError) as exc:
                logging.warning(f"Action {action} could not be applied ({exc}).")

    def _apply_str_replace(self, old_str: str, new_str: str):
        """Apply str_replace to internal text state."""
        count = self._text.count(old_str)
        if count == 0:
            raise ValueError(f"String '{old_str}' not found in text.")
        if count > 1:
            raise ValueError(f"String '{old_str}' found multiple times in text.")
        self._text = self._text.replace(old_str, new_str, 1)

    def _apply_insert(self, index: int, text: str):
        """Apply insert to internal text state."""
        if index < 0:
            raise ValueError("Index cannot be negative.")
        if index > len(self._text):
            index = len(self._text)
        self._text = self._text[:index] + text + self._text[index:]

    def _apply_delete(self, index: int, length: int):
        """Apply delete to internal text state."""
        if index < 0:
            raise ValueError("Index cannot be negative.")
        if length < 0:
            raise ValueError("Length cannot be negative.")
        self._text = self._text[:index] + self._text[index + length:]

    def _apply_append(self, text: str):
        """Apply append to internal text state."""
        self._text = self._text + text

    def pull(self):
        """
        Pull the latest text data from the collaboration server and update
        the in-memory text.
        """
        with httpx.Client() as httpx_client:
            response = httpx_client.get(self.url, headers=self.headers)
        response.raise_for_status()
        self._text = response.json()["data"]
        self._reapply_actions()

    async def pull_async(self):
        """
        Asynchronously pull the latest text data from the collaboration server
        and update the in-memory text.
        """
        async with httpx.AsyncClient() as httpx_client:
            response = await httpx_client.get(self.url, headers=self.headers)
        response.raise_for_status()
        self._text = response.json()["data"]
        self._reapply_actions()

    def _prepare_actions_data(self) -> Dict:
        """Prepare actions data for pushing to server."""
        data = collab_schemas.TextActions.validate(
            {"actions": self._actions}).dict(exclude_none=True)
        return data

    def _flush_actions(self):
        """Clear the pending actions list."""
        self._actions = []

    def push(self):
        """
        Push the local changes to the collaboration server.
        """
        if len(self._actions) == 0:
            return None

        data = self._prepare_actions_data()
        with httpx.Client() as httpx_client:
            response = httpx_client.post(
                self.url,
                headers=self.headers,
                json=data
            )
        response.raise_for_status()
        self._flush_actions()

    async def push_async(self):
        """
        Asynchronously push the local changes to the collaboration server.
        """
        if len(self._actions) == 0:
            return None

        data = self._prepare_actions_data()
        async with httpx.AsyncClient() as httpx_client:
            response = await httpx_client.post(
                self.url,
                headers=self.headers,
                json=data
            )
        response.raise_for_status()
        self._flush_actions()

    def str_replace(self, old_str: str, new_str: str):
        """
        Replace a unique occurrence of old_str with new_str.

        The old_str must appear exactly once in the document. If it appears
        zero times or more than once, the server will return an error.

        Parameters
        ----------
        old_str : str
            The exact text to find and replace. Must match exactly once.
        new_str : str
            The replacement text.

        Raises
        ------
        ValueError
            If old_str is not found or found multiple times in the text.
        """
        self._apply_str_replace(old_str, new_str)
        action = collab_schemas.TextAction.validate({
            "type": "str_replace",
            "payload": {"old_str": old_str, "new_str": new_str}
        })
        self._actions.append(action)

    def insert(self, index: int, text: str):
        """
        Insert text at the specified index.

        Parameters
        ----------
        index : int
            The position to insert text at (0-based). If index is greater
            than the text length, text is appended at the end.
        text : str
            The text to insert.

        Raises
        ------
        ValueError
            If index is negative.
        """
        self._apply_insert(index, text)
        action = collab_schemas.TextAction.validate({
            "type": "insert",
            "payload": {"index": index, "text": text}
        })
        self._actions.append(action)

    def delete(self, index: int, length: int):
        """
        Delete characters starting at the specified index.

        Parameters
        ----------
        index : int
            The position to start deleting from (0-based).
        length : int
            The number of characters to delete.

        Raises
        ------
        ValueError
            If index or length is negative.
        """
        self._apply_delete(index, length)
        action = collab_schemas.TextAction.validate({
            "type": "delete",
            "payload": {"index": index, "length": length}
        })
        self._actions.append(action)

    def append(self, text: str):
        """
        Append text to the end of the document.

        Parameters
        ----------
        text : str
            The text to append.
        """
        self._apply_append(text)
        action = collab_schemas.TextAction.validate({
            "type": "append",
            "payload": {"text": text}
        })
        self._actions.append(action)

    def get_sharing_link(self) -> str:
        """
        Get a sharing link for the text file.

        Returns
        -------
        str
            The URL for sharing the text file.
        """
        tenant = os.getenv('HALERIUM_TENANT_KEY', '')
        workspace = os.getenv('HALERIUM_PROJECT_ID', '')
        base_url = os.getenv('HALERIUM_BASE_URL', '')

        workspace_path = runner_path_to_workspace_path(self.file_path).lstrip("/")

        url = urljoin(base_url,
                      f"/{quote(tenant, safe='')}"
                      f"/{quote(workspace, safe='')}"
                      "/contents/" +
                      quote(workspace_path, safe=''))
        return url
