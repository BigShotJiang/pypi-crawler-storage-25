"""
Background worker for sync operations.

Processes queued sync operations asynchronously, retrieving BigQuery jobs
and dbt manifests for configured projects.
"""

from __future__ import annotations

import json
import logging
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from typing import Any, Callable

from google.api_core.exceptions import GoogleAPIError
from google.cloud.exceptions import GoogleCloudError
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.configurations.models import ManifestConfiguration
from app.gcp.clients import (
    get_storage_client,
    query_billing_models,
    query_information_schema_jobs_by_ids,
    query_information_schema_jobs,
    query_table_columns,
    query_table_storage,
)
from app.opportunities.detector import DetectionEngine
from app.opportunities.exceptions import DetectionJobExistsError
from app.opportunities.models import DetectionJob
from app.opportunities.service import OpportunityService
from app.setup.runtime import create_github_client, get_runtime_bigquery_region
from app.sync.models import (
    BigQueryJob,
    ManifestVersion,
    SyncError,
    SyncOperation,
    TableColumnMetadata,
    TableStorageMetric,
)
from app.sync.service import extract_dbt_tables, sanitize_error_message
from app.sync.service import (
    build_manifest_table_set,
    classify_bigquery_job_workload,
)

logger = logging.getLogger("app.sync.worker")


class Worker:
    """Background worker for processing sync operations.

    Handles the full sync lifecycle: retrieving BigQuery jobs filtered by dbt tables,
    downloading manifest files from GCS, and tracking errors.
    """

    def __init__(self, db_session_factory: Callable[[], Session]) -> None:
        """Initialize worker with database session factory.

        Args:
            db_session_factory: Callable that returns a new database Session
                                (e.g., SessionLocal from app.db.session)
        """
        self._db_factory = db_session_factory
        from app.core.config import get_settings

        settings = get_settings()
        self._solution_max_workers = settings.solution_concurrency_limit
        self._bigquery_region = get_runtime_bigquery_region()
        self._solution_executor: ThreadPoolExecutor | None = None
        self._solution_futures: set[Future] = set()

    def _get_last_successful_sync(self, config_id: str) -> datetime | None:
        """Get the completion timestamp of the most recent successful sync.

        Args:
            config_id: ID of the manifest configuration

        Returns:
            completed_at timestamp of most recent successful sync, or None if no prior sync

        Used to determine incremental sync starting point. Initial syncs (None) query 180 days.
        """
        db = self._db_factory()
        try:
            last_sync = (
                db.query(SyncOperation)
                .filter(
                    SyncOperation.config_id == config_id,
                    SyncOperation.status == "completed",
                    SyncOperation.triggered_by != "manual_upload",
                )
                .order_by(SyncOperation.completed_at.desc())
                .first()
            )
            return last_sync.completed_at if last_sync else None
        finally:
            db.close()

    def _retrieve_bigquery_jobs(self, sync_operation: SyncOperation) -> None:
        """Retrieve dbt-related BigQuery jobs and store in database.

        This is the core sync operation that:
        1. Loads manifest versions for the config
        2. Extracts dbt table names from manifests
        3. Records which manifest version is used
        4. Queries BigQuery INFORMATION_SCHEMA with dbt table filter
        5. Batch inserts/upserts job records

        Args:
            sync_operation: The SyncOperation to process
        """
        db = self._db_factory()
        try:
            # Fetch configuration
            config = (
                db.query(ManifestConfiguration)
                .filter(ManifestConfiguration.id == sync_operation.config_id)
                .one()
            )

            # Load manifest versions for this config
            manifest_versions = (
                db.query(ManifestVersion)
                .filter(ManifestVersion.config_id == config.id)
                .order_by(ManifestVersion.retrieved_at.desc())
                .all()
            )

            if not manifest_versions:
                logger.warning(
                    "No manifest versions found for config %s, skipping BigQuery job retrieval",
                    config.id,
                )
                return

            # Extract dbt tables from all manifests and combine into single list
            all_dbt_tables: list[str] = []
            used_manifest_version_id: str | None = None

            for manifest_version in manifest_versions:
                dbt_tables = extract_dbt_tables(manifest_version.content)
                if dbt_tables:
                    all_dbt_tables.extend(dbt_tables)
                    # Track the most recent manifest version used
                    if used_manifest_version_id is None:
                        used_manifest_version_id = manifest_version.id
                    logger.debug(
                        "Extracted %d dbt tables from manifest version %s",
                        len(dbt_tables),
                        manifest_version.id,
                    )

            # Remove duplicates while preserving order
            all_dbt_tables = list(dict.fromkeys(all_dbt_tables))
            manifest_table_set = build_manifest_table_set(all_dbt_tables)

            if not all_dbt_tables:
                logger.warning(
                    "No dbt tables found in manifest versions for config %s",
                    config.id,
                )
                return

            logger.info(
                "Found %d unique dbt tables across %d manifest versions for config %s",
                len(all_dbt_tables),
                len(manifest_versions),
                config.id,
            )

            # Set used_manifest_version_id on the sync operation
            if used_manifest_version_id:
                sync_operation.used_manifest_version_id = used_manifest_version_id
                db.merge(sync_operation)
                db.commit()
                logger.info(
                    "Recorded manifest version %s as used for sync %s",
                    used_manifest_version_id,
                    sync_operation.id,
                )

            # Determine timestamp for incremental sync
            last_sync_timestamp = self._get_last_successful_sync(config.id)
            sync_type = "incremental" if last_sync_timestamp else "initial (180 days)"
            logger.info(
                "Starting %s BigQuery job retrieval for config %s (last sync: %s)",
                sync_type,
                config.id,
                last_sync_timestamp,
            )

            job_rows = self._load_bigquery_job_rows_for_sync(
                config=config,
                sync_operation=sync_operation,
                all_dbt_tables=all_dbt_tables,
                last_sync_timestamp=last_sync_timestamp,
            )
            db.merge(sync_operation)
            db.commit()

            if not job_rows:
                logger.info("No dbt-related jobs found for config %s", config.id)
                return

            logger.info(
                "Retrieved %d BigQuery jobs for config %s", len(job_rows), config.id
            )

            # Batch insert with upsert logic (1000 per batch)
            batch_size = 1000
            jobs_inserted = 0
            jobs_updated = 0
            jobs_skipped = 0

            for i in range(0, len(job_rows), batch_size):
                batch = job_rows[i : i + batch_size]

                for job_row in batch:
                    job_row["workload_kind"] = classify_bigquery_job_workload(
                        destination_table=job_row.get("destination_table"),
                        referenced_tables=job_row.get("referenced_tables"),
                        manifest_tables=manifest_table_set,
                    )
                    job_id = job_row["job_id"]

                    # Check if job already exists
                    existing_job = (
                        db.query(BigQueryJob)
                        .filter(BigQueryJob.job_id == job_id)
                        .one_or_none()
                    )

                    if existing_job:
                        # Upsert logic: check if prior sync completed successfully
                        prior_sync = (
                            db.query(SyncOperation)
                            .filter(
                                SyncOperation.id == existing_job.sync_id,
                                SyncOperation.status == "completed",
                            )
                            .one_or_none()
                        )

                        if prior_sync:
                            # Skip: job from successful sync, don't overwrite
                            jobs_skipped += 1
                            continue
                        else:
                            # Update: job from failed sync, update with new data
                            for key, value in job_row.items():
                                if key != "job_id":  # Don't overwrite primary key
                                    setattr(existing_job, key, value)
                            existing_job.sync_id = sync_operation.id
                            existing_job.config_id = config.id
                            jobs_updated += 1
                    else:
                        # Insert new job record
                        new_job = BigQueryJob(
                            config_id=config.id,
                            sync_id=sync_operation.id,
                            **job_row,
                        )
                        db.add(new_job)
                        jobs_inserted += 1

                db.commit()
                logger.debug(
                    "Processed batch %d/%d (size: %d)",
                    i // batch_size + 1,
                    (len(job_rows) + batch_size - 1) // batch_size,
                    len(batch),
                )

            # Update sync operation metrics
            sync_operation.jobs_retrieved_count = jobs_inserted + jobs_updated
            db.merge(sync_operation)
            db.commit()

            logger.info(
                "BigQuery job retrieval complete for sync %s: %d inserted, %d updated, %d skipped",
                sync_operation.id,
                jobs_inserted,
                jobs_updated,
                jobs_skipped,
            )

        except (
            SQLAlchemyError,
            GoogleCloudError,
            GoogleAPIError,
            ValueError,
            KeyError,
        ) as exc:
            # Log error to sync_errors table
            error_message = sanitize_error_message(str(exc))
            sync_error = SyncError(
                sync_id=sync_operation.id,
                error_type=type(exc).__name__,
                error_message=error_message,
                step_context="retrieve_bigquery_jobs",
                related_entity_id=sync_operation.config_id,
            )
            db.add(sync_error)
            db.commit()

            logger.error(
                "Error retrieving BigQuery jobs for sync %s: %s",
                sync_operation.id,
                error_message,
                exc_info=exc,
            )
            raise

        finally:
            db.close()

    @staticmethod
    def _extract_run_results_job_metadata(
        run_results_json: dict | None,
    ) -> tuple[list[str], dict[str, Any]]:
        """Extract BigQuery job IDs and timing metadata from dbt run_results."""
        if not isinstance(run_results_json, dict):
            return [], {}

        metadata = run_results_json.get("metadata")
        metadata_dict = metadata if isinstance(metadata, dict) else {}
        results = run_results_json.get("results")
        if not isinstance(results, list):
            return [], metadata_dict

        job_ids: list[str] = []
        for result in results:
            if not isinstance(result, dict):
                continue
            adapter_response = result.get("adapter_response")
            if not isinstance(adapter_response, dict):
                continue
            job_id = adapter_response.get("job_id")
            if isinstance(job_id, str) and job_id.strip():
                job_ids.append(job_id.strip())

        return list(dict.fromkeys(job_ids)), metadata_dict

    @staticmethod
    def _parse_iso8601(value: Any) -> datetime | None:
        if not isinstance(value, str) or not value.strip():
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    def _query_local_run_window_jobs(
        self,
        *,
        project_id: str,
        dbt_tables: list[str],
        metadata: dict[str, Any],
    ) -> list[dict]:
        """Fallback to a narrow run window derived from dbt invocation metadata."""
        start_time = self._parse_iso8601(metadata.get("invocation_started_at"))
        generated_at = self._parse_iso8601(metadata.get("generated_at"))
        if start_time is None and generated_at is None:
            return []

        window_start = (start_time or generated_at) - timedelta(minutes=5)
        window_end = (generated_at or start_time) + timedelta(minutes=5)
        return query_information_schema_jobs(
            project_id=project_id,
            dbt_tables=dbt_tables,
            region=self._bigquery_region,
            start_time=window_start,
            end_time=window_end,
        )

    def _load_bigquery_job_rows_for_sync(
        self,
        *,
        config: ManifestConfiguration,
        sync_operation: SyncOperation,
        all_dbt_tables: list[str],
        last_sync_timestamp: datetime | None,
    ) -> list[dict]:
        """Load BigQuery jobs for a sync, preferring exact local run correlation."""
        sync_operation.local_evidence_mode = None
        sync_operation.matched_local_job_ids = None
        sync_operation.unmatched_local_job_ids = None

        is_local_config = bool(
            config.local_project_path
            and config.manifest_source in {"manual_upload", "local"}
        )
        if not is_local_config:
            return query_information_schema_jobs(
                project_id=config.gcp_project_id,
                dbt_tables=all_dbt_tables,
                last_sync_timestamp=last_sync_timestamp,
                region=self._bigquery_region,
            )

        run_job_ids, metadata = self._extract_run_results_job_metadata(
            sync_operation.run_results_json
        )
        if not run_job_ids:
            sync_operation.local_evidence_mode = "historical_table_jobs"
            return query_information_schema_jobs(
                project_id=config.gcp_project_id,
                dbt_tables=all_dbt_tables,
                last_sync_timestamp=last_sync_timestamp,
                region=self._bigquery_region,
            )

        exact_rows = query_information_schema_jobs_by_ids(
            project_id=config.gcp_project_id,
            job_ids=run_job_ids,
            region=self._bigquery_region,
        )
        exact_job_ids = [row["job_id"] for row in exact_rows if row.get("job_id")]
        unmatched_job_ids = [
            job_id for job_id in run_job_ids if job_id not in set(exact_job_ids)
        ]

        fallback_rows: list[dict] = []
        if unmatched_job_ids:
            fallback_rows = self._query_local_run_window_jobs(
                project_id=config.gcp_project_id,
                dbt_tables=all_dbt_tables,
                metadata=metadata,
            )
            if not fallback_rows:
                fallback_rows = query_information_schema_jobs(
                    project_id=config.gcp_project_id,
                    dbt_tables=all_dbt_tables,
                    last_sync_timestamp=last_sync_timestamp,
                    region=self._bigquery_region,
                )

        combined_rows = list(exact_rows)
        seen_job_ids = {row.get("job_id") for row in exact_rows if row.get("job_id")}
        for row in fallback_rows:
            job_id = row.get("job_id")
            if job_id and job_id in seen_job_ids:
                continue
            combined_rows.append(row)
            if job_id:
                seen_job_ids.add(job_id)

        if exact_rows and fallback_rows:
            sync_operation.local_evidence_mode = "mixed"
        elif exact_rows:
            sync_operation.local_evidence_mode = "exact_run_jobs"
        else:
            sync_operation.local_evidence_mode = "historical_table_jobs"

        sync_operation.matched_local_job_ids = exact_job_ids or None
        sync_operation.unmatched_local_job_ids = unmatched_job_ids or None
        return combined_rows

    def _get_latest_manifest_version(self, config_id: str) -> ManifestVersion | None:
        """Get the most recent manifest version for a configuration.

        Args:
            config_id: ID of the manifest configuration

        Returns:
            Most recent ManifestVersion record, or None if no prior versions exist

        Used for etag-based change detection to avoid re-downloading unchanged manifests.
        """
        db = self._db_factory()
        try:
            return (
                db.query(ManifestVersion)
                .filter(ManifestVersion.config_id == config_id)
                .order_by(ManifestVersion.retrieved_at.desc())
                .first()
            )
        finally:
            db.close()

    def _sync_local_workspace_artifacts(
        self,
        *,
        db: Session,
        config: ManifestConfiguration,
        sync_operation: SyncOperation,
        latest_version: ManifestVersion | None,
    ) -> None:
        """Load manifest and run_results directly from a configured local dbt path."""
        from app.workspace.detection import read_local_manifest, read_local_run_results

        project_path = config.local_project_path or ""
        manifest_bytes = read_local_manifest(project_path)
        sync_operation.run_results_json = read_local_run_results(project_path)

        if not manifest_bytes:
            sync_operation.manifests_updated_count = 0
            db.merge(sync_operation)
            db.add(
                SyncError(
                    sync_id=sync_operation.id,
                    error_type="LocalManifestMissingError",
                    error_message=(
                        "No target/manifest.json found in the configured local dbt "
                        "project folder."
                    ),
                    step_context="sync_manifests",
                    related_entity_id=config.id,
                )
            )
            db.commit()
            logger.warning(
                "Local project path %s has no manifest for config %s",
                project_path,
                config.id,
            )
            return

        try:
            manifest_content = json.loads(manifest_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            sync_operation.manifests_updated_count = 0
            db.merge(sync_operation)
            db.add(
                SyncError(
                    sync_id=sync_operation.id,
                    error_type=type(exc).__name__,
                    error_message=sanitize_error_message(str(exc)),
                    step_context="sync_manifests",
                    related_entity_id=config.id,
                )
            )
            db.commit()
            logger.warning(
                "Failed to parse local manifest for config %s from %s",
                config.id,
                project_path,
            )
            return

        content_hash = sha256(
            json.dumps(manifest_content, sort_keys=True).encode("utf-8")
        ).hexdigest()

        if latest_version and latest_version.content_hash == content_hash:
            sync_operation.manifests_updated_count = 0
            sync_operation.used_manifest_version_id = latest_version.id
            db.merge(sync_operation)
            db.commit()
            logger.info(
                "Local manifest unchanged for config %s; reusing version %s",
                config.id,
                latest_version.id,
            )
            return

        manifest_version = ManifestVersion(
            config_id=config.id,
            sync_id=sync_operation.id,
            content_hash=content_hash,
            content=manifest_content,
            retrieved_at=datetime.now(timezone.utc),
        )
        db.add(manifest_version)
        db.flush()

        sync_operation.manifests_updated_count = 1
        sync_operation.used_manifest_version_id = manifest_version.id
        db.merge(sync_operation)
        db.commit()
        logger.info(
            "Loaded local manifest for config %s from %s",
            config.id,
            project_path,
        )

    def _sync_manifests(self, sync_operation: SyncOperation) -> None:
        """Download dbt manifest file from GCS with etag-based change detection.

        Each configuration has a single manifest location. Downloads only if changed.

        Args:
            sync_operation: The SyncOperation to process
        """
        db = self._db_factory()
        try:
            # Fetch configuration
            config = (
                db.query(ManifestConfiguration)
                .filter(ManifestConfiguration.id == sync_operation.config_id)
                .one()
            )

            latest_version = self._get_latest_manifest_version(config.id)
            if config.local_project_path and config.manifest_source in {
                "manual_upload",
                "local",
            }:
                self._sync_local_workspace_artifacts(
                    db=db,
                    config=config,
                    sync_operation=sync_operation,
                    latest_version=latest_version,
                )
                return

            if config.manifest_source in {"manual_upload", "local"}:
                sync_operation.manifests_updated_count = 0
                if latest_version:
                    sync_operation.used_manifest_version_id = latest_version.id
                    db.merge(sync_operation)
                    db.commit()
                    logger.info(
                        "Using previously uploaded manifest version %s for config %s",
                        latest_version.id,
                        config.id,
                    )
                    return

                error_message = (
                    "No uploaded manifest is available for this configuration."
                )
                sync_error = SyncError(
                    sync_id=sync_operation.id,
                    error_type="ManualManifestMissingError",
                    error_message=error_message,
                    step_context="sync_manifests",
                    related_entity_id=config.id,
                )
                db.add(sync_error)
                db.commit()
                logger.warning(
                    "Manual-upload config %s has no manifest version to use",
                    config.id,
                )
                return

            storage_client = get_storage_client()
            manifests_updated = 0

            try:
                # Construct GCS object path
                object_path = f"{config.path_prefix}/{config.object_name}".lstrip("/")
                logger.debug(
                    "Checking manifest at gs://%s/%s",
                    config.bucket_name,
                    object_path,
                )

                # Get GCS object metadata
                bucket = storage_client.bucket(config.bucket_name)
                blob = bucket.get_blob(object_path)

                if not blob:
                    raise FileNotFoundError(
                        f"Manifest not found at gs://{config.bucket_name}/{object_path}"
                    )

                # Get etag for change detection
                current_etag = blob.etag

                # Check if manifest has changed
                if latest_version and latest_version.content_hash == current_etag:
                    logger.debug(
                        "Manifest for config %s unchanged (etag: %s), skipping download",
                        config.id,
                        current_etag,
                    )
                    sync_operation.manifests_updated_count = 0
                    db.commit()
                    return

                # Download manifest content
                logger.info(
                    "Downloading changed manifest from gs://%s/%s",
                    config.bucket_name,
                    object_path,
                )
                manifest_text = blob.download_as_text()
                manifest_content = json.loads(manifest_text)

                # Create new manifest version record
                manifest_version = ManifestVersion(
                    config_id=config.id,
                    sync_id=sync_operation.id,
                    content_hash=current_etag,
                    content=manifest_content,
                    retrieved_at=datetime.now(timezone.utc),
                )
                db.add(manifest_version)
                db.commit()

                manifests_updated = 1
                logger.info(
                    "Stored manifest version %s for config %s (etag: %s)",
                    manifest_version.id,
                    config.id,
                    current_etag,
                )

            except (
                SQLAlchemyError,
                GoogleCloudError,
                GoogleAPIError,
                json.JSONDecodeError,
                FileNotFoundError,
                ValueError,
            ) as exc:
                # Log error
                error_message = sanitize_error_message(str(exc))
                sync_error = SyncError(
                    sync_id=sync_operation.id,
                    error_type=type(exc).__name__,
                    error_message=error_message,
                    step_context="sync_manifests",
                    related_entity_id=config.id,
                )
                db.add(sync_error)
                db.commit()

                logger.error(
                    "Error syncing manifest for config %s: %s",
                    config.id,
                    error_message,
                    exc_info=exc,
                )

            # Update sync operation metrics
            sync_operation.manifests_updated_count = manifests_updated
            db.commit()

            logger.info(
                "Manifest sync complete for sync %s: %d updated",
                sync_operation.id,
                manifests_updated,
            )

        finally:
            db.close()

    def _sync_table_storage(self, sync_operation: SyncOperation) -> None:
        """Sync BigQuery TABLE_STORAGE and SCHEMATA_OPTIONS data.

        Queries per-table storage byte counts and dataset billing models,
        then upserts records into table_storage_metrics. Errors are logged
        to sync_errors and do NOT block the rest of the sync pipeline.

        Args:
            sync_operation: The SyncOperation to process
        """
        db = self._db_factory()
        try:
            config = (
                db.query(ManifestConfiguration)
                .filter(ManifestConfiguration.id == sync_operation.config_id)
                .one()
            )

            # Query TABLE_STORAGE for per-table byte counts
            storage_rows = query_table_storage(
                project_id=config.gcp_project_id,
                region=self._bigquery_region,
            )

            if not storage_rows:
                logger.info("No table storage records found for config %s", config.id)
                return

            # Query SCHEMATA_OPTIONS for dataset billing models
            billing_models = query_billing_models(
                project_id=config.gcp_project_id,
                region=self._bigquery_region,
            )

            # Upsert records
            metrics_upserted = 0
            for row in storage_rows:
                dataset_name = row["table_schema"]
                table_name = row["table_name"]
                billing_model = billing_models.get(dataset_name, "LOGICAL")

                total_logical = row.get("total_logical_bytes", 0) or 0
                total_physical = row.get("total_physical_bytes", 0) or 0
                compression_ratio = (
                    total_logical / total_physical if total_physical > 0 else None
                )

                # Check for existing record (upsert)
                existing = (
                    db.query(TableStorageMetric)
                    .filter(
                        TableStorageMetric.config_id == config.id,
                        TableStorageMetric.project_id == config.gcp_project_id,
                        TableStorageMetric.dataset_name == dataset_name,
                        TableStorageMetric.table_name == table_name,
                    )
                    .one_or_none()
                )

                if existing:
                    existing.sync_id = sync_operation.id
                    existing.table_type = row.get("table_type", "BASE TABLE")
                    existing.billing_model = billing_model
                    existing.total_rows = row.get("total_rows")
                    existing.total_partitions = row.get("total_partitions", 0)
                    existing.total_logical_bytes = total_logical
                    existing.active_logical_bytes = (
                        row.get("active_logical_bytes", 0) or 0
                    )
                    existing.long_term_logical_bytes = (
                        row.get("long_term_logical_bytes", 0) or 0
                    )
                    existing.total_physical_bytes = total_physical
                    existing.active_physical_bytes = (
                        row.get("active_physical_bytes", 0) or 0
                    )
                    existing.long_term_physical_bytes = (
                        row.get("long_term_physical_bytes", 0) or 0
                    )
                    existing.time_travel_physical_bytes = (
                        row.get("time_travel_physical_bytes", 0) or 0
                    )
                    existing.fail_safe_physical_bytes = (
                        row.get("fail_safe_physical_bytes", 0) or 0
                    )
                    existing.compression_ratio = compression_ratio
                    existing.synced_at = datetime.now(timezone.utc)
                else:
                    metric = TableStorageMetric(
                        config_id=config.id,
                        sync_id=sync_operation.id,
                        project_id=config.gcp_project_id,
                        dataset_name=dataset_name,
                        table_name=table_name,
                        table_type=row.get("table_type", "BASE TABLE"),
                        billing_model=billing_model,
                        total_rows=row.get("total_rows"),
                        total_partitions=row.get("total_partitions", 0),
                        total_logical_bytes=total_logical,
                        active_logical_bytes=row.get("active_logical_bytes", 0) or 0,
                        long_term_logical_bytes=row.get("long_term_logical_bytes", 0)
                        or 0,
                        total_physical_bytes=total_physical,
                        active_physical_bytes=row.get("active_physical_bytes", 0) or 0,
                        long_term_physical_bytes=row.get("long_term_physical_bytes", 0)
                        or 0,
                        time_travel_physical_bytes=row.get(
                            "time_travel_physical_bytes", 0
                        )
                        or 0,
                        fail_safe_physical_bytes=row.get("fail_safe_physical_bytes", 0)
                        or 0,
                        compression_ratio=compression_ratio,
                        synced_at=datetime.now(timezone.utc),
                    )
                    db.add(metric)

                metrics_upserted += 1

            db.commit()
            logger.info(
                "Table storage sync complete for sync %s: %d metrics upserted",
                sync_operation.id,
                metrics_upserted,
            )

        except (
            SQLAlchemyError,
            GoogleCloudError,
            GoogleAPIError,
            ValueError,
            KeyError,
        ) as exc:
            error_message = sanitize_error_message(str(exc))
            sync_error = SyncError(
                sync_id=sync_operation.id,
                error_type=type(exc).__name__,
                error_message=error_message,
                step_context="sync_table_storage",
                related_entity_id=sync_operation.config_id,
            )
            db.add(sync_error)
            db.commit()

            logger.warning(
                "Table storage sync failed for sync %s (non-blocking): %s",
                sync_operation.id,
                error_message,
            )
            # Do NOT re-raise — error isolation per NFR-2

        finally:
            db.close()

    def _sync_table_columns(self, sync_operation: SyncOperation) -> None:
        """Sync BigQuery INFORMATION_SCHEMA.COLUMNS data.

        Queries per-table column metadata (name, type, position) and upserts
        into table_column_metadata. Errors are logged to sync_errors and do
        NOT block the rest of the sync pipeline.

        Args:
            sync_operation: The SyncOperation to process
        """
        db = self._db_factory()
        try:
            config = (
                db.query(ManifestConfiguration)
                .filter(ManifestConfiguration.id == sync_operation.config_id)
                .one()
            )

            column_rows = query_table_columns(
                project_id=config.gcp_project_id,
                region=self._bigquery_region,
            )

            if not column_rows:
                logger.info("No column metadata found for config %s", config.id)
                return

            # Build set of (dataset, table, column) from fresh data for stale detection
            fresh_keys: set[tuple[str, str, str]] = set()
            columns_upserted = 0

            for row in column_rows:
                dataset_name = row["dataset_name"]
                table_name = row["table_name"]
                column_name = row["column_name"]
                fresh_keys.add((dataset_name, table_name, column_name))

                existing = (
                    db.query(TableColumnMetadata)
                    .filter(
                        TableColumnMetadata.config_id == config.id,
                        TableColumnMetadata.project_id == config.gcp_project_id,
                        TableColumnMetadata.dataset_name == dataset_name,
                        TableColumnMetadata.table_name == table_name,
                        TableColumnMetadata.column_name == column_name,
                    )
                    .one_or_none()
                )

                if existing:
                    existing.sync_id = sync_operation.id
                    existing.data_type = row["data_type"]
                    existing.ordinal_position = row["ordinal_position"]
                else:
                    record = TableColumnMetadata(
                        config_id=config.id,
                        sync_id=sync_operation.id,
                        project_id=config.gcp_project_id,
                        dataset_name=dataset_name,
                        table_name=table_name,
                        column_name=column_name,
                        data_type=row["data_type"],
                        ordinal_position=row["ordinal_position"],
                    )
                    db.add(record)

                columns_upserted += 1

            # Delete stale columns that no longer exist in BigQuery
            stale = (
                db.query(TableColumnMetadata)
                .filter(
                    TableColumnMetadata.config_id == config.id,
                    TableColumnMetadata.sync_id != sync_operation.id,
                )
                .all()
            )
            stale_deleted = 0
            for record in stale:
                key = (record.dataset_name, record.table_name, record.column_name)
                if key not in fresh_keys:
                    db.delete(record)
                    stale_deleted += 1

            db.commit()
            logger.info(
                "Column metadata sync complete for sync %s: %d upserted, %d stale deleted",
                sync_operation.id,
                columns_upserted,
                stale_deleted,
            )

        except (
            SQLAlchemyError,
            GoogleCloudError,
            GoogleAPIError,
            ValueError,
            KeyError,
        ) as exc:
            error_message = sanitize_error_message(str(exc))
            sync_error = SyncError(
                sync_id=sync_operation.id,
                error_type=type(exc).__name__,
                error_message=error_message,
                step_context="sync_table_columns",
                related_entity_id=sync_operation.config_id,
            )
            db.add(sync_error)
            db.commit()

            logger.warning(
                "Column metadata sync failed for sync %s (non-blocking): %s",
                sync_operation.id,
                error_message,
            )
            # Do NOT re-raise — error isolation per NFR-2

        finally:
            db.close()

    def poll_and_claim_task(self) -> SyncOperation | None:
        """Poll for queued sync operations and claim one atomically.

        Uses optimistic locking to ensure only one worker claims each task.
        Tasks are processed in FIFO order (oldest queued_at first).

        Returns:
            SyncOperation if successfully claimed, None if no tasks available
        """
        db = self._db_factory()
        try:
            # Find first queued task (FIFO order)
            sync = (
                db.query(SyncOperation)
                .filter(SyncOperation.status == "queued")
                .order_by(SyncOperation.queued_at.asc())
                .with_for_update(skip_locked=True)  # Skip if locked by another worker
                .first()
            )

            if not sync:
                return None

            # Claim task atomically (optimistic locking via status check)
            sync.status = "in_progress"
            sync.started_at = datetime.now(timezone.utc)
            db.commit()

            logger.info("Claimed sync task %s for config %s", sync.id, sync.config_id)
            return sync

        except SQLAlchemyError as exc:
            logger.error("Error claiming sync task: %s", exc, exc_info=exc)
            db.rollback()
            return None

        finally:
            db.close()

    def process_sync(self, sync_operation: SyncOperation) -> None:
        """Execute full sync operation: manifests + BigQuery jobs.

        Orchestrates the complete sync lifecycle:
        1. Download manifest from GCS (_sync_manifests)
        2. Retrieve BigQuery jobs filtered by dbt tables (_retrieve_bigquery_jobs)
        3. Update status to completed on success, failed on error

        Args:
            sync_operation: The SyncOperation to process
        """
        db = self._db_factory()
        try:
            self._bigquery_region = get_runtime_bigquery_region()
            logger.info(
                "Starting sync %s for config %s",
                sync_operation.id,
                sync_operation.config_id,
            )

            # Step 1: Sync manifest from GCS
            logger.info("Step 1/4: Syncing manifest for sync %s", sync_operation.id)
            self._sync_manifests(sync_operation)

            # Step 2: Sync table storage metrics (error-isolated, non-blocking)
            logger.info(
                "Step 2/4: Syncing table storage metrics for sync %s",
                sync_operation.id,
            )
            self._sync_table_storage(sync_operation)

            # Step 3: Sync column metadata (error-isolated, non-blocking)
            logger.info(
                "Step 3/4: Syncing column metadata for sync %s",
                sync_operation.id,
            )
            self._sync_table_columns(sync_operation)

            # Step 4: Retrieve BigQuery jobs (filtered by dbt tables)
            logger.info(
                "Step 4/4: Retrieving BigQuery jobs for sync %s", sync_operation.id
            )
            self._retrieve_bigquery_jobs(sync_operation)

            # Mark sync as completed
            sync_operation.status = "completed"
            sync_operation.completed_at = datetime.now(timezone.utc)
            db.merge(sync_operation)
            db.commit()

            logger.info(
                "Sync %s completed successfully: %d manifests updated, %d jobs retrieved",
                sync_operation.id,
                sync_operation.manifests_updated_count,
                sync_operation.jobs_retrieved_count,
            )

            # Queue detection job after successful sync completion (FR-001)
            try:
                opportunity_service = OpportunityService(db)
                detection_job = opportunity_service.create_detection_job(
                    config_id=sync_operation.config_id,
                    sync_id=sync_operation.id,
                )
                db.commit()
                logger.info(
                    "Detection job queued: %s for sync %s",
                    detection_job.id,
                    sync_operation.id,
                )
            except DetectionJobExistsError:
                logger.warning(
                    "Detection job already exists for sync %s, skipping",
                    sync_operation.id,
                )
            except (SQLAlchemyError, ValueError, RuntimeError) as detection_exc:
                # Log but don't fail sync for detection job errors
                logger.error(
                    "Failed to queue detection job for sync %s: %s",
                    sync_operation.id,
                    detection_exc,
                    exc_info=detection_exc,
                )

            # Collect PR history from GitHub after sync completes
            try:
                from app.pullrequests.collection import collect_prs

                github_client = create_github_client()
                if github_client is not None:
                    collect_prs(db, github_client)

                    # Apply clearing status after collection
                    from app.pullrequests.clearing import apply_clearing_status

                    apply_clearing_status(db, github_client)
            except (SQLAlchemyError, RuntimeError, ValueError, KeyError) as pr_exc:
                logger.warning(
                    "PR collection after sync %s failed: %s",
                    sync_operation.id,
                    pr_exc,
                )

        except (
            SQLAlchemyError,
            GoogleCloudError,
            GoogleAPIError,
            ValueError,
            KeyError,
            RuntimeError,
        ) as exc:
            # Mark sync as failed and log error
            error_message = sanitize_error_message(str(exc))
            sync_operation.status = "failed"
            sync_operation.completed_at = datetime.now(timezone.utc)
            db.merge(sync_operation)

            sync_error = SyncError(
                sync_id=sync_operation.id,
                error_type=type(exc).__name__,
                error_message=error_message,
                step_context="process_sync",
                related_entity_id=sync_operation.config_id,
            )
            db.add(sync_error)
            db.commit()

            logger.error(
                "Sync %s failed: %s",
                sync_operation.id,
                error_message,
                exc_info=exc,
            )

        finally:
            db.close()

    def poll_and_claim_detection_task(self) -> DetectionJob | None:
        """Poll for queued detection jobs and claim one atomically.

        Uses optimistic locking to ensure only one worker claims each task.
        Tasks are processed in FIFO order (oldest queued_at first).

        Returns:
            DetectionJob if successfully claimed, None if no tasks available
        """
        db = self._db_factory()
        try:
            opportunity_service = OpportunityService(db)
            job = opportunity_service.get_pending_detection_job()

            if job and opportunity_service.claim_detection_job(job.id):
                db.commit()
                logger.info(
                    "Claimed detection task %s for config %s",
                    job.id,
                    job.config_id,
                )
                return job

            return None

        except SQLAlchemyError as exc:
            logger.error("Error claiming detection task: %s", exc, exc_info=exc)
            db.rollback()
            return None

        finally:
            db.close()

    def process_detection(self, detection_job: DetectionJob) -> None:
        """Execute detection job: run all rules and persist opportunities.

        Each configuration is one manifest, so detection runs once per config.

        Args:
            detection_job: The DetectionJob to process
        """
        db = self._db_factory()
        try:
            logger.info(
                "Starting detection job %s for config %s",
                detection_job.id,
                detection_job.config_id,
            )

            # Load BigQuery jobs for this config from the triggering sync
            jobs = (
                db.query(BigQueryJob)
                .filter(BigQueryJob.sync_id == detection_job.sync_id)
                .all()
            )

            logger.info(
                "Loaded %d BigQuery jobs for detection job %s",
                len(jobs),
                detection_job.id,
            )

            # Get the latest manifest version for this config
            manifest_version = (
                db.query(ManifestVersion)
                .filter(ManifestVersion.config_id == detection_job.config_id)
                .order_by(ManifestVersion.retrieved_at.desc())
                .first()
            )

            manifest_content = None
            manifest_version_id = None

            if manifest_version:
                manifest_content = manifest_version.content
                manifest_version_id = manifest_version.id
                logger.info(
                    "Running detection for config %s (manifest version %s)",
                    detection_job.config_id,
                    manifest_version.id,
                )
            else:
                logger.warning(
                    "No manifest version for config %s, running detection without manifest content",
                    detection_job.config_id,
                )

            # Re-fetch detection job in this session
            job_in_session = db.get(DetectionJob, detection_job.id)

            engine = DetectionEngine()

            result = engine.run_detection(
                detection_job=job_in_session,
                jobs=jobs,
                manifest_content=manifest_content,
                config_id=detection_job.config_id,
                manifest_version_id=manifest_version_id,
                db=db,
            )

            # Update detection job with results
            opportunity_service = OpportunityService(db)
            opportunity_service.complete_detection_job(
                detection_job_id=detection_job.id,
                found_count=result.found_count,
                updated_count=result.updated_count,
                resolved_count=result.resolved_count,
            )
            db.commit()

            logger.info(
                "Detection job %s completed: found=%d, updated=%d, resolved=%d",
                detection_job.id,
                result.found_count,
                result.updated_count,
                result.resolved_count,
            )

            # Apply clearing status BEFORE queueing solutions — ensures
            # opportunities affected by merged PRs are marked 'clearing' and
            # won't have solution jobs created for them.
            try:
                from app.pullrequests.clearing import (
                    apply_clearing_status as _apply_clearing,
                )

                _det_gh = create_github_client()
                if _det_gh is not None:
                    clearing_result = _apply_clearing(db, _det_gh)
                    if clearing_result["cleared"]:
                        logger.info(
                            "Clearing status applied before solution queueing: "
                            "cleared=%d, expired=%d",
                            clearing_result["cleared"],
                            clearing_result["expired"],
                        )
            except (
                SQLAlchemyError,
                RuntimeError,
                ValueError,
                KeyError,
            ) as clearing_exc:
                logger.warning(
                    "Failed to apply clearing before solution queueing: %s",
                    clearing_exc,
                )

            # Run cascade analysis to group lineage-connected opportunities
            # and elect root causes before solution queuing (spec 082).
            try:
                from app.opportunities.cascade import CascadeAnalyzer

                if manifest_content:
                    cascade_result = CascadeAnalyzer().analyze(
                        config_id=detection_job.config_id,
                        manifest_content=manifest_content,
                        db=db,
                    )
                    if cascade_result.groups_created:
                        logger.info(
                            "Cascade analysis: %d groups, %d opportunities grouped, "
                            "%d root causes elected",
                            cascade_result.groups_created,
                            cascade_result.opportunities_grouped,
                            cascade_result.root_causes_elected,
                        )
                    db.commit()
            except (
                SQLAlchemyError,
                ValueError,
                KeyError,
                TypeError,
                RuntimeError,
            ) as cascade_exc:
                logger.warning(
                    "Cascade analysis failed, proceeding without: %s",
                    cascade_exc,
                )

            # Queue solution generation jobs after successful detection
            try:
                from app.llm import is_llm_configured

                if is_llm_configured():
                    from app.solutions.service import SolutionService

                    solution_service = SolutionService(db)
                    solution_jobs = solution_service.queue_solutions_for_detection(
                        detection_job_id=detection_job.id,
                        config_id=detection_job.config_id,
                    )
                    if solution_jobs:
                        logger.info(
                            "Queued %d solution generation jobs for detection %s",
                            len(solution_jobs),
                            detection_job.id,
                        )
                else:
                    logger.debug(
                        "LLM not configured, skipping solution job queueing for detection %s",
                        detection_job.id,
                    )
            except (SQLAlchemyError, RuntimeError, ValueError) as sol_exc:
                # Don't fail detection if solution queueing fails
                logger.error(
                    "Failed to queue solution jobs for detection %s: %s",
                    detection_job.id,
                    sol_exc,
                    exc_info=sol_exc,
                )

        except (SQLAlchemyError, ValueError, KeyError, TypeError, RuntimeError) as exc:
            # Mark detection job as failed
            error_message = sanitize_error_message(str(exc))

            try:
                opportunity_service = OpportunityService(db)
                opportunity_service.fail_detection_job(
                    detection_job_id=detection_job.id,
                    error_message=error_message,
                )
                db.commit()
            except SQLAlchemyError as fail_exc:
                logger.error(
                    "Failed to mark detection job %s as failed: %s",
                    detection_job.id,
                    fail_exc,
                )
                db.rollback()

            logger.error(
                "Detection job %s failed: %s",
                detection_job.id,
                error_message,
                exc_info=exc,
            )

        finally:
            db.close()

    def poll_and_claim_solution_task(self):
        """Poll for queued solution jobs and claim one atomically.

        Returns:
            SolutionJob if successfully claimed, None if no tasks available.
        """
        from app.solutions.service import SolutionService

        db = self._db_factory()
        try:
            solution_service = SolutionService(db)
            job = solution_service.get_pending_solution_job()

            if job and solution_service.claim_solution_job(job.id):
                logger.info(
                    "Claimed solution task %s for opportunity %s",
                    job.id,
                    job.opportunity_id,
                )
                return job

            return None

        except SQLAlchemyError as exc:
            logger.error("Error claiming solution task: %s", exc, exc_info=exc)
            db.rollback()
            return None

        finally:
            db.close()

    def process_solution(self, solution_job) -> None:
        """Execute solution generation for a claimed job.

        Loads opportunity, config, and manifest_version from DB.
        Instantiates SolutionGenerator with LLM provider and GitHub client.
        Stores results and updates job status.

        Args:
            solution_job: The SolutionJob to process.
        """
        from app.configurations.models import ManifestConfiguration
        from app.llm import get_llm_provider
        from app.opportunities.models import Opportunity
        from app.solutions.generator import SolutionGenerator
        from app.solutions.models import SolutionJob
        from app.solutions.service import SolutionService

        db = self._db_factory()
        try:
            job_id = solution_job.id
            solution_job = db.get(SolutionJob, job_id)
            if not solution_job:
                raise ValueError(f"Solution job {job_id} not found")

            logger.info(
                "Starting solution generation for job %s (opportunity %s)",
                solution_job.id,
                solution_job.opportunity_id,
            )

            # Load related entities
            opportunity = db.get(Opportunity, solution_job.opportunity_id)
            if not opportunity:
                raise ValueError(f"Opportunity {solution_job.opportunity_id} not found")

            if opportunity.status == "clearing":
                logger.info(
                    "Skipping solution generation for opportunity %s — status is 'clearing'",
                    opportunity.id,
                )
                solution_job.status = "failed"
                solution_job.error_message = "Opportunity is in clearing state; previous changes are still being evaluated"
                solution_job.completed_at = datetime.now(timezone.utc)
                db.commit()
                return

            config = db.get(ManifestConfiguration, solution_job.config_id)
            if not config:
                raise ValueError(f"Config {solution_job.config_id} not found")

            manifest_version = None
            if opportunity.manifest_version_id:
                manifest_version = db.get(
                    ManifestVersion, opportunity.manifest_version_id
                )

            # Get LLM provider
            llm_provider = get_llm_provider()
            if not llm_provider:
                raise RuntimeError("LLM provider not available")

            # Get GitHub client (optional)
            github_client = None
            if config.github_repo:
                try:
                    github_client = create_github_client()
                except (RuntimeError, ValueError) as gh_exc:
                    logger.warning(
                        "Could not create GitHub client for solution job %s: %s",
                        solution_job.id,
                        gh_exc,
                    )

            # Generate solutions
            generator = SolutionGenerator(
                llm_provider=llm_provider,
                github_client=github_client,
            )

            result = generator.generate(opportunity, config, manifest_version, db=db)

            # Store solutions
            solution_service = SolutionService(db)
            for sol_data in result.solutions:
                solution_service.store_solution(
                    opportunity_id=opportunity.id,
                    solution_job_id=solution_job.id,
                    manifest_version_id=(
                        manifest_version.id if manifest_version else None
                    ),
                    solution_data={
                        "resolution_category": sol_data.resolution_category,
                        "explanation": sol_data.explanation,
                        "risk_level": sol_data.risk_level,
                        "risk_justification": sol_data.risk_justification,
                        "file_path": sol_data.file_path,
                        "change_type": sol_data.change_type,
                        "before_content": sol_data.before_content,
                        "after_content": sol_data.after_content,
                        "repository": sol_data.repository,
                        "commit_sha": sol_data.commit_sha,
                        "current_setting_value": sol_data.current_setting_value,
                        "recommended_setting_value": sol_data.recommended_setting_value,
                        "affected_resource": sol_data.affected_resource,
                        "trust_tier": sol_data.trust_tier,
                        "validation_report": sol_data.validation_report,
                        "dry_run_original": sol_data.dry_run_original,
                        "dry_run_modified": sol_data.dry_run_modified,
                        "compiled_after_sql": sol_data.compiled_after_sql,
                    },
                )

            # Complete the job when solution guardrails blocked all proposals.
            # A custom empty allow-list is also a valid configuration outcome:
            # detection can run while solution storage is intentionally disabled.
            if not result.solutions:
                if result.blocked_solutions_count > 0 or (
                    isinstance(config.allowed_solution_policy_tags, list)
                    and len(config.allowed_solution_policy_tags) == 0
                ):
                    solution_service.complete_solution_job(
                        job_id=solution_job.id,
                        solutions_count=0,
                        llm_metadata={
                            "provider": result.metadata.provider,
                            "model": result.metadata.model,
                            "prompt_tokens": result.metadata.prompt_tokens,
                            "completion_tokens": result.metadata.completion_tokens,
                            "latency_ms": result.metadata.latency_ms,
                        },
                        resolution_category=result.resolution_category,
                        trust_tier=None,
                    )
                    logger.info(
                        "Solution job %s completed with 0 stored solutions due to solution guardrails (blocked=%d, tags=%s)",
                        solution_job.id,
                        result.blocked_solutions_count,
                        result.blocked_policy_tags,
                    )
                    return

                solution_service.fail_solution_job(
                    job_id=solution_job.id,
                    error_message=(
                        "LLM returned a response but 0 usable solutions "
                        "were produced after validation"
                    ),
                    error_stage="response_parsing",
                )
                logger.warning(
                    "Solution job %s produced 0 solutions — marked as failed",
                    solution_job.id,
                )
                return

            # Compute aggregate trust tier (lowest across all solutions)
            _TIER_ORDER = {"guaranteed_safe": 0, "validated": 1, "requires_review": 2}
            tiers = [s.trust_tier or "requires_review" for s in result.solutions]
            aggregate_tier = max(tiers, key=lambda t: _TIER_ORDER.get(t, 2))

            # Complete the job
            solution_service.complete_solution_job(
                job_id=solution_job.id,
                solutions_count=len(result.solutions),
                llm_metadata={
                    "provider": result.metadata.provider,
                    "model": result.metadata.model,
                    "prompt_tokens": result.metadata.prompt_tokens,
                    "completion_tokens": result.metadata.completion_tokens,
                    "latency_ms": result.metadata.latency_ms,
                },
                resolution_category=result.resolution_category,
                trust_tier=aggregate_tier,
            )

            # Auto-PR hook: create draft PR if threshold met
            # Re-fetch solution_job from current session — the original object is
            # detached (loaded in poll_and_claim_solution_task's closed session)
            # and won't have the trust_tier set by complete_solution_job above.
            fresh_job = db.get(SolutionJob, solution_job.id)
            if fresh_job:
                self._maybe_auto_create_pr(fresh_job, config, db, github_client)

            logger.info(
                "Solution job %s completed: %d solutions generated (%s)",
                solution_job.id,
                len(result.solutions),
                result.resolution_category,
            )

        except (SQLAlchemyError, RuntimeError, ValueError, KeyError, TypeError) as exc:
            # Determine error stage
            from app.solutions.exceptions import (
                DestructiveChangeError,
                GitHubRetrievalError,
                LLMRequestError,
            )

            error_stage = "storage"
            if isinstance(exc, DestructiveChangeError):
                error_stage = "validation"
            elif isinstance(exc, GitHubRetrievalError):
                error_stage = "github_retrieval"
            elif isinstance(exc, (LLMRequestError,)):
                error_stage = "llm_request"
            elif isinstance(exc.__cause__, Exception) and "parse" in str(exc).lower():
                error_stage = "response_parsing"

            error_message = sanitize_error_message(str(exc))

            try:
                from app.solutions.service import SolutionService

                solution_service = SolutionService(db)
                solution_service.fail_solution_job(
                    job_id=solution_job.id,
                    error_message=error_message,
                    error_stage=error_stage,
                )
            except SQLAlchemyError as fail_exc:
                logger.error(
                    "Failed to mark solution job %s as failed: %s",
                    solution_job.id,
                    fail_exc,
                )
                db.rollback()

            logger.error(
                "Solution job %s failed at stage '%s': %s",
                solution_job.id,
                error_stage,
                error_message,
                exc_info=exc,
            )

        finally:
            db.close()

    def _maybe_auto_create_pr(
        self,
        solution_job,
        config: ManifestConfiguration,
        db: Session,
        github_client,
    ) -> None:
        """Auto-create a draft PR if the solution meets the trust tier threshold.

        Never propagates exceptions — failures are logged but do not affect
        solution job completion.
        """
        try:
            from app.core.config import is_local_mode

            # Guard checks
            if config.status != "active":
                return
            if is_local_mode() and config.local_project_path:
                logger.debug("Skipping auto-PR in local mode for config %s", config.id)
                return
            if not config.github_repo:
                return
            if github_client is None:
                return
            if solution_job.trust_tier is None:
                return

            # Resolve effective threshold: config override → org setting → "disabled"
            effective_threshold = config.auto_pr_trust_tier
            if effective_threshold is None:
                from app.settings.service import OrganisationSettingsService

                org_service = OrganisationSettingsService(db)
                effective_threshold = org_service.get_value(
                    "auto_pr_trust_tier_threshold", "disabled"
                )

            if effective_threshold == "disabled":
                return

            # Evaluate tier ordering
            _TIER_ORDER = {
                "guaranteed_safe": 0,
                "validated": 1,
                "requires_review": 2,
            }
            job_tier_order = _TIER_ORDER.get(solution_job.trust_tier, 99)
            threshold_order = _TIER_ORDER.get(effective_threshold, 99)

            if job_tier_order > threshold_order:
                logger.debug(
                    "Auto-PR skipped for job %s: tier %s does not meet threshold %s",
                    solution_job.id,
                    solution_job.trust_tier,
                    effective_threshold,
                )
                return

            # Get system user
            from app.auth.models import AuditEvent, User

            system_user = (
                db.query(User)
                .filter(User.email == "system@governor.internal")
                .one_or_none()
            )
            if not system_user:
                logger.error("System sentinel user not found for auto-PR")
                return

            # Get latest solution for this job
            from app.solutions.models import Solution
            from app.solutions.validation.report import (
                has_blocking_dbt_verification_issue,
            )

            latest_solution = (
                db.query(Solution)
                .filter(Solution.solution_job_id == solution_job.id)
                .order_by(Solution.version_number.desc())
                .first()
            )
            if not latest_solution:
                logger.warning("No solutions found for job %s", solution_job.id)
                return

            if has_blocking_dbt_verification_issue(latest_solution.validation_report):
                logger.info(
                    "Auto-PR skipped for job %s: dbt verification did not succeed",
                    solution_job.id,
                )
                return

            # Create PR
            from app.pullrequests.service import PullRequestService

            pr_service = PullRequestService(db, github_client)
            pr_record = pr_service.create_pr(
                opportunity_id=solution_job.opportunity_id,
                solution_id=latest_solution.id,
                user_id=system_user.id,
            )

            # Audit: success
            audit = AuditEvent(
                user_id=system_user.id,
                event_type="auto_pr_submitted",
                outcome="success",
                user_agent=f"config={config.id} threshold={effective_threshold}",
            )
            db.add(audit)
            db.commit()

            logger.info(
                "Auto-PR created for job %s: PR %s",
                solution_job.id,
                pr_record.pr_url,
            )

        except (SQLAlchemyError, RuntimeError, ValueError) as exc:
            logger.error(
                "Auto-PR failed for job %s: %s",
                solution_job.id,
                exc,
                exc_info=exc,
            )
            # Rollback failed transaction before attempting audit write
            try:
                db.rollback()
            except SQLAlchemyError:
                pass

            try:
                from app.auth.models import AuditEvent, User

                system_user = (
                    db.query(User)
                    .filter(User.email == "system@governor.internal")
                    .one_or_none()
                )
                audit = AuditEvent(
                    user_id=system_user.id if system_user else None,
                    event_type="auto_pr_failed",
                    outcome="failure",
                    user_agent=str(exc)[:256],
                )
                db.add(audit)
                db.commit()
            except SQLAlchemyError:
                db.rollback()
                logger.error("Failed to log auto-PR failure audit event")

    def run(self, stop_event=None) -> None:
        """Run worker polling loop until stopped.

        Continuously polls for queued sync operations and processes them.
        Polls every 5 seconds. Exits gracefully when stop_event is set.

        Args:
            stop_event: Optional threading.Event to signal shutdown
        """
        import threading

        if stop_event is None:
            stop_event = threading.Event()

        logger.info(
            "Worker started, polling for sync, detection, and solution operations every 5 seconds"
        )

        while not stop_event.is_set():
            try:
                # Priority 1: Poll and claim sync task
                sync = self.poll_and_claim_task()

                if sync:
                    # Process claimed sync
                    self.process_sync(sync)
                    continue

                # Priority 2: Poll and claim detection task
                detection_job = self.poll_and_claim_detection_task()

                if detection_job:
                    # Process claimed detection job
                    self.process_detection(detection_job)
                    continue

                # Priority 3: Solution jobs — submit to thread pool
                # Lazily create executor on first use
                if self._solution_executor is None:
                    self._solution_executor = ThreadPoolExecutor(
                        max_workers=self._solution_max_workers,
                        thread_name_prefix="solution-worker",
                    )

                # Clean completed futures
                done = {f for f in self._solution_futures if f.done()}
                for f in done:
                    exc = f.exception()
                    if exc:
                        logger.error(
                            "Solution worker thread failed: %s", exc, exc_info=exc
                        )
                self._solution_futures -= done

                # Fill available slots
                available = self._solution_max_workers - len(self._solution_futures)
                claimed_any = False
                for _ in range(available):
                    solution_job = self.poll_and_claim_solution_task()
                    if solution_job:
                        future = self._solution_executor.submit(
                            self.process_solution, solution_job
                        )
                        self._solution_futures.add(future)
                        claimed_any = True
                    else:
                        break

                if claimed_any:
                    continue

                # No tasks available, log at debug level to reduce noise
                logger.debug("No queued sync, detection, or solution operations found")

            except Exception as exc:
                # Log unexpected errors but keep worker running
                logger.error(
                    "Unexpected error in worker loop: %s",
                    exc,
                    exc_info=exc,
                )

            # Wait 5 seconds before next poll (or exit if stopped)
            stop_event.wait(5)

        # Shutdown: wait for in-flight solution jobs to finish
        if self._solution_executor:
            logger.info(
                "Waiting for %d in-flight solution jobs to complete...",
                len(self._solution_futures),
            )
            self._solution_executor.shutdown(wait=True, cancel_futures=False)

        logger.info("Worker stopped gracefully")
