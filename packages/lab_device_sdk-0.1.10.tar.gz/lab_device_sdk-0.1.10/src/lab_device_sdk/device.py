"""Minimal Device base class for SDK."""
# pylint: disable=duplicate-code  # Docstring examples intentionally similar to __init__.py

import asyncio
from typing import Any
from typing import ClassVar


class Device:
    """Base class for device drivers.

    This minimal base class provides just enough structure for driver developers
    to create compatible device drivers without heavy dependencies.

    Subclasses must define:
        - device_type_id: Unique identifier for the device type, usually a UUID string
        - manufacturer: Device manufacturer name
        - model: Device model name

    Example:
        class MyDevice(Device):
            device_type_id = "f423f4b7-d389-42c5-bc44-eb3acee3154d"
            manufacturer = "ACME Corp"
            model = "Model X"

            @settings()
            @string_in("host", "localhost", "Device host")
            async def connect(self, host: str):
                # Connection logic
                pass

            @command("GetStatus", "Get device status")
            @string_out("status", "Current device status")
            async def get_status(self) -> str:
                return "OK"
    """

    # These must be defined by subclasses
    device_type_id: str | None = None
    manufacturer: str | None = None
    model: str | None = None

    # Optional class attributes for device metadata
    description: str = ""
    additional_parameters: ClassVar[list[str]] = []

    def __init__(self, device_id: str, configuration: str | None = None):
        """Initialize device with ID and optional configuration.

        Args:
            device_id: Unique identifier for this device instance
            configuration: Optional configuration string (implementation-specific)
        """
        # For cooperative multiple inheritance, try to call super().__init__() with args
        # If there's no parent (standalone usage), object.__init__() will be called
        try:
            super().__init__(device_id, configuration)  # type: ignore[reportCallIssue]
        except TypeError:
            # Parent class (object) doesn't accept arguments - standalone SDK usage
            super().__init__()
        self.device_id = device_id
        self.configuration = configuration
        self._stop_requested = False

        # Validate required class attributes
        if not all([self.device_type_id, self.manufacturer, self.model]):
            missing_attrs = "device_type_id, manufacturer, and model"
            raise ValueError(f"{self.__class__.__name__} must define {missing_attrs}")  # noqa: TRY003

    @property
    def stop_requested(self) -> bool:
        """True if an abort has been requested for the current operation.

        Check this property periodically in long-running commands to support
        graceful abort. Prefer ``cancelable_sleep`` for simple delays.
        """
        return self._stop_requested

    @stop_requested.setter
    def stop_requested(self, value: bool) -> None:
        self._stop_requested = value

    async def cancelable_sleep(self, duration: float) -> None:
        """Sleep that can be cancelled by abort.

        Checks stop_requested every 100ms and raises ``asyncio.CancelledError``
        if an abort is detected. Use this instead of ``asyncio.sleep`` in
        commands that should support abort.

        Args:
            duration: Sleep duration in seconds

        Raises:
            asyncio.CancelledError: If the command is aborted during sleep
        """
        step_size = 0.1
        elapsed = 0.0
        while elapsed < duration:
            if self.stop_requested:
                msg = "Operation was aborted"
                raise asyncio.CancelledError(msg)
            sleep_time = min(step_size, duration - elapsed)
            await asyncio.sleep(sleep_time)
            elapsed += sleep_time

    async def abort(self, command_name: str) -> None:
        """Abort a running command.

        Override this method to implement device-specific abort logic, such as
        sending a stop command to hardware. The base implementation in Device Hub
        handles internal stop-flag management — call ``super().abort(command_name)``
        in your override to preserve that behavior.

        Args:
            command_name: Name of the command being aborted, or ``"*"`` for all
        """

    def on_removed(self) -> None:
        """Clean up resources when the device is removed from Device Hub.

        Override this method to clean up singleton caches, shared resources, or external connections when the device is discarded (e.g. during a
        configuration reload).
        """

    async def disconnect(self) -> None:
        """Disconnect from the device and cleanup resources.

        Override this method to implement device-specific disconnection
        logic.
        This method is called when the device is being disconnected or
        cleaned up.

        Example:
            async def disconnect(self) -> None:
                await self.client.close()
                logger.info("Device disconnected")
        """
        return  # Default implementation does nothing

    @staticmethod
    def get_configurations() -> list[str]:
        """Return device configuration options.

        This method can be overridden to provide custom configuration options. By default, returns an empty list.
        """
        return []

    def get_agent_context(self) -> str:
        """Return context information for AI agent consumers.

        Override this method to provide device-specific context that helps
        AI agents understand how to use this device in workflows.

        Returns:
            Context string for AI agents. Default: "no agent context"
        """
        return "no agent context"

    def get_dynamic_parameter_options(self, command_name: str, parameter_name: str) -> list[str]:  # noqa: ARG002
        """Get dynamic options for a command parameter.

        Override this method to return dynamically-generated options for
        parameters that have ``dynamic_options=True`` set in their
        ``@string_in`` decorator.

        Args:
            command_name: Name of the command
            parameter_name: Name of the parameter

        Returns:
            List of option strings
        """
        return []

    def get_dynamic_simulation_time_sec(self, command_name: str, parameters: dict[str, Any]) -> float:  # noqa: ARG002
        """Get the estimated execution time in seconds for a command.

        Override this method to return a dynamic estimated time based on the
        command name and/or input parameters. The default implementation returns
        the value specified in the command's @command decorator (default_sim_sec).

        Args:
            command_name: Name of the command
            parameters: Resolved input parameters for the command

        Returns:
            Estimated execution time in seconds
        """
        for attr_name in dir(self):
            method = getattr(self, attr_name, None)
            if callable(method) and getattr(method, "_cmd_name", None) == command_name:
                return float(getattr(method, "_cmd_default_sim_sec", 3.0))
        return 3.0
