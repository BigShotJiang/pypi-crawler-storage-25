from __future__ import annotations

import inspect
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine


@dataclass
class ToolResult:
    """The result of a ctx.tools.call() invocation."""

    tool_name: str
    output: Any
    success: bool
    duration_ms: float
    error: str | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class NativeTool:
    """A Python function registered as a Mosesaic tool.

    Created by the @tool decorator. Agent code calls it via ctx.tools.call().
    The function may be sync or async — both are supported.
    """

    def __init__(self, name: str, fn: Callable, description: str = "") -> None:
        self.name = name
        self.fn = fn
        self.description = description
        self._is_async = inspect.iscoroutinefunction(fn)

    async def __call__(self, **kwargs: Any) -> ToolResult:
        start = time.monotonic()
        try:
            if self._is_async:
                output = await self.fn(**kwargs)
            else:
                output = self.fn(**kwargs)
            return ToolResult(
                tool_name=self.name,
                output=output,
                success=True,
                duration_ms=(time.monotonic() - start) * 1000,
            )
        except Exception as exc:
            return ToolResult(
                tool_name=self.name,
                output=None,
                success=False,
                duration_ms=(time.monotonic() - start) * 1000,
                error=str(exc),
            )


def tool(name: str, description: str = "") -> Callable:
    """Decorator that registers a sync or async function as a Mosesaic tool.

    Usage:
        @tool(name="web_search", description="Search the web for information")
        async def web_search(query: str, max_results: int = 5) -> list[str]:
            ...

        @tool(name="add")
        def add(a: int, b: int) -> int:
            return a + b
    """

    def decorator(fn: Callable) -> NativeTool:
        return NativeTool(name=name, fn=fn, description=description)

    return decorator
