from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field


@dataclass
class ToolPolicy:
    """Declarative permission model for tool access.

    Patterns support shell-style wildcards (fnmatch): "delete_*", "stripe.*"

    Usage:
        @agent(name="safe-agent", tool_policy=ToolPolicy(
            deny=["delete_*", "send_email"],
            require_approval=["stripe.*"],
        ))
    """

    deny: list[str] = field(default_factory=list)
    require_approval: list[str] = field(default_factory=list)
    allow_only: list[str] = field(default_factory=list)  # whitelist; empty = allow all

    def is_denied(self, tool_name: str) -> bool:
        """Return True if this tool is explicitly denied."""
        return any(fnmatch.fnmatch(tool_name, pattern) for pattern in self.deny)

    def requires_approval(self, tool_name: str) -> bool:
        """Return True if this tool needs human approval before execution."""
        return any(fnmatch.fnmatch(tool_name, pattern) for pattern in self.require_approval)

    def is_allowed(self, tool_name: str) -> bool:
        """Return True if this tool is permitted under the policy."""
        if self.is_denied(tool_name):
            return False
        if self.allow_only:
            return any(fnmatch.fnmatch(tool_name, pattern) for pattern in self.allow_only)
        return True
