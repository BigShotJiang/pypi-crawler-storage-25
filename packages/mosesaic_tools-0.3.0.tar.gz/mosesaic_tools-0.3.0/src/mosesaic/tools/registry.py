from __future__ import annotations

from mosesaic.tools.tool import NativeTool, ToolResult


class ToolRegistry:
    """Holds all registered tools and dispatches calls by name.

    Usage:
        registry = ToolRegistry()
        registry.register(my_tool)             # NativeTool from @tool decorator
        result = await registry.call("my_tool", query="hello")
    """

    def __init__(self) -> None:
        self._tools: dict[str, NativeTool] = {}

    def register(self, tool: NativeTool) -> None:
        """Register a tool. Overwrites any existing tool with the same name."""
        self._tools[tool.name] = tool

    def get(self, name: str) -> NativeTool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return list(self._tools.keys())

    async def call(self, name: str, **kwargs) -> ToolResult:
        """Call a registered tool by name.

        Returns a ToolResult with success=False and error set if the tool
        is not found or raises an exception.
        """
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(
                tool_name=name,
                output=None,
                success=False,
                duration_ms=0.0,
                error=f"Tool '{name}' is not registered.",
            )
        return await tool(**kwargs)
