from __future__ import annotations

from typing import Any

from mosesaic.tools.policy import ToolPolicy
from mosesaic.tools.registry import ToolRegistry
from mosesaic.tools.tool import ToolResult


class ToolContext:
    """The ``ctx.tools`` interface available to agents.

    Wraps the ToolRegistry and enforces the agent's ToolPolicy.
    Every call is recorded in the tool call log.

    Usage (inside an agent):
        result = await ctx.tools.call("web_search", query="quantum 2026")
        if result.success:
            print(result.output)
        else:
            print(f"Tool failed: {result.error}")
    """

    def __init__(
        self,
        registry: ToolRegistry,
        policy: ToolPolicy | None = None,
        agent_name: str = "unknown",
    ) -> None:
        self._registry = registry
        self._policy = policy or ToolPolicy()
        self._agent_name = agent_name
        self._call_log: list[ToolResult] = []

    async def call(self, name: str, **kwargs: Any) -> ToolResult:
        """Call a tool by name, enforcing the agent's ToolPolicy.

        Returns ToolResult with success=False if:
        - Tool is not registered
        - Tool is denied by policy
        - Tool requires approval (not yet implemented — returns policy error)
        - Tool raises an exception (caught and wrapped)
        """
        if not self._policy.is_allowed(name):
            result = ToolResult(
                tool_name=name,
                output=None,
                success=False,
                duration_ms=0.0,
                error=f"Tool '{name}' is denied by agent policy.",
            )
            self._call_log.append(result)
            return result

        if self._policy.requires_approval(name):
            result = ToolResult(
                tool_name=name,
                output=None,
                success=False,
                duration_ms=0.0,
                error=f"Tool '{name}' requires human approval before execution.",
            )
            self._call_log.append(result)
            return result

        result = await self._registry.call(name, **kwargs)
        self._call_log.append(result)
        return result

    def call_log(self) -> list[ToolResult]:
        """Return all tool calls made through this context."""
        return list(self._call_log)

    def available(self) -> list[str]:
        """Return tool names available under the current policy."""
        return [n for n in self._registry.names() if self._policy.is_allowed(n)]
