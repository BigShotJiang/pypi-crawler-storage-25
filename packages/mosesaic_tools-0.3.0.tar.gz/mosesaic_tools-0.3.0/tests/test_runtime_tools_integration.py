"""Integration: AgentRuntime with tools wired through ctx.tools."""
import anyio
import pytest

from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.core.runtime import AgentRuntime
from mosesaic.tools.policy import ToolPolicy
from mosesaic.tools.registry import ToolRegistry
from mosesaic.tools.tool import tool


def make_registry() -> ToolRegistry:
    registry = ToolRegistry()

    @tool(name="double")
    def double(n: int) -> int:
        return n * 2

    registry.register(double)
    return registry


@pytest.mark.anyio
async def test_agent_calls_tool_via_ctx():
    results = []

    @agent(name="tool-user")
    async def tool_user(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        result = await ctx.tools.call("double", n=msg.payload)
        results.append(result.output)

    runtime = AgentRuntime(tools=make_registry())
    runtime.register(tool_user)

    async with runtime.run():
        await runtime.send("tool-user", payload=21)
        await anyio.sleep(0.1)

    assert results == [42]


@pytest.mark.anyio
async def test_ctx_tools_raises_without_registry():
    accessed = []

    @agent(name="no-tools")
    async def no_tools(ctx: AgentContext) -> None:
        await ctx.receive()
        try:
            _ = ctx.tools
        except RuntimeError as e:
            accessed.append(str(e))

    runtime = AgentRuntime()  # no tools registry
    runtime.register(no_tools)

    async with runtime.run():
        await runtime.send("no-tools", payload="go")
        await anyio.sleep(0.1)

    assert any("No tool registry" in msg for msg in accessed)


@pytest.mark.anyio
async def test_agent_tool_policy_applied():
    results = []

    @agent(name="restricted")
    async def restricted(ctx: AgentContext) -> None:
        await ctx.receive()
        result = await ctx.tools.call("double", n=5)
        results.append(result)

    registry = make_registry()
    policy = ToolPolicy(deny=["double"])
    runtime = AgentRuntime(tools=registry, tool_policy=policy)
    runtime.register(restricted)

    async with runtime.run():
        await runtime.send("restricted", payload="go")
        await anyio.sleep(0.1)

    assert results[0].success is False
    assert "denied" in results[0].error
