"""Tests for @tool decorator, NativeTool, ToolResult."""
import pytest

from mosesaic.tools.tool import NativeTool, ToolResult, tool


def test_tool_decorator_returns_native_tool():
    @tool(name="add", description="Add two numbers")
    def add(a: int, b: int) -> int:
        return a + b

    assert isinstance(add, NativeTool)
    assert add.name == "add"
    assert add.description == "Add two numbers"


@pytest.mark.anyio
async def test_sync_tool_executes():
    @tool(name="multiply")
    def multiply(x: int, y: int) -> int:
        return x * y

    result = await multiply(x=3, y=4)
    assert result.success is True
    assert result.output == 12
    assert result.duration_ms >= 0
    assert result.error is None


@pytest.mark.anyio
async def test_async_tool_executes():
    @tool(name="async_echo")
    async def async_echo(msg: str) -> str:
        return f"echo: {msg}"

    result = await async_echo(msg="hello")
    assert result.success is True
    assert result.output == "echo: hello"


@pytest.mark.anyio
async def test_tool_captures_exception():
    @tool(name="always_fails")
    def always_fails() -> None:
        raise ValueError("boom")

    result = await always_fails()
    assert result.success is False
    assert result.output is None
    assert "boom" in result.error


@pytest.mark.anyio
async def test_tool_result_has_tool_name():
    @tool(name="named")
    def named() -> str:
        return "ok"

    result = await named()
    assert result.tool_name == "named"
