"""Tests for ToolPolicy — allow/deny/require_approval with wildcard patterns."""
from mosesaic.tools.policy import ToolPolicy


def test_default_policy_allows_all():
    policy = ToolPolicy()
    assert policy.is_allowed("anything")
    assert policy.is_allowed("delete_user")
    assert policy.is_denied("anything") is False


def test_deny_exact():
    policy = ToolPolicy(deny=["send_email"])
    assert policy.is_allowed("send_email") is False
    assert policy.is_allowed("send_sms") is True


def test_deny_wildcard():
    policy = ToolPolicy(deny=["delete_*"])
    assert policy.is_allowed("delete_user") is False
    assert policy.is_allowed("delete_record") is False
    assert policy.is_allowed("create_record") is True


def test_deny_namespace_wildcard():
    policy = ToolPolicy(deny=["stripe.*"])
    assert policy.is_allowed("stripe.charge") is False
    assert policy.is_allowed("stripe.refund") is False
    assert policy.is_allowed("paypal.charge") is True


def test_require_approval():
    policy = ToolPolicy(require_approval=["stripe.*"])
    assert policy.requires_approval("stripe.charge") is True
    assert policy.requires_approval("web_search") is False


def test_allow_only_whitelist():
    policy = ToolPolicy(allow_only=["web_search", "read_file"])
    assert policy.is_allowed("web_search") is True
    assert policy.is_allowed("read_file") is True
    assert policy.is_allowed("delete_user") is False


def test_deny_overrides_allow_only():
    policy = ToolPolicy(deny=["web_search"], allow_only=["web_search", "read_file"])
    assert policy.is_allowed("web_search") is False  # deny wins
