"""Tests for ToolRegistry and ToolContext (ctx.tools)."""
import pytest

from mosesaic.tools.context import ToolContext
from mosesaic.tools.policy import ToolPolicy
from mosesaic.tools.registry import ToolRegistry
from mosesaic.tools.tool import tool


def make_registry() -> ToolRegistry:
    registry = ToolRegistry()

    @tool(name="add")
    def add(a: int, b: int) -> int:
        return a + b

    @tool(name="echo")
    async def echo(msg: str) -> str:
        return msg

    @tool(name="delete_all")
    def delete_all() -> str:
        return "deleted"

    registry.register(add)
    registry.register(echo)
    registry.register(delete_all)
    return registry


@pytest.mark.anyio
async def test_registry_call_known_tool():
    registry = make_registry()
    result = await registry.call("add", a=2, b=3)
    assert result.success is True
    assert result.output == 5


@pytest.mark.anyio
async def test_registry_call_unknown_tool():
    registry = make_registry()
    result = await registry.call("nonexistent")
    assert result.success is False
    assert "not registered" in result.error


def test_registry_names():
    registry = make_registry()
    assert "add" in registry.names()
    assert "echo" in registry.names()


@pytest.mark.anyio
async def test_tool_context_call_success():
    ctx = ToolContext(registry=make_registry(), agent_name="test")
    result = await ctx.call("echo", msg="hello")
    assert result.success is True
    assert result.output == "hello"


@pytest.mark.anyio
async def test_tool_context_enforces_deny():
    policy = ToolPolicy(deny=["delete_*"])
    ctx = ToolContext(registry=make_registry(), policy=policy, agent_name="test")
    result = await ctx.call("delete_all")
    assert result.success is False
    assert "denied" in result.error


@pytest.mark.anyio
async def test_tool_context_enforces_require_approval():
    policy = ToolPolicy(require_approval=["delete_*"])
    ctx = ToolContext(registry=make_registry(), policy=policy, agent_name="test")
    result = await ctx.call("delete_all")
    assert result.success is False
    assert "approval" in result.error


@pytest.mark.anyio
async def test_tool_context_call_log():
    ctx = ToolContext(registry=make_registry(), agent_name="test")
    await ctx.call("add", a=1, b=2)
    await ctx.call("echo", msg="hi")
    log = ctx.call_log()
    assert len(log) == 2
    assert log[0].tool_name == "add"
    assert log[1].tool_name == "echo"


def test_tool_context_available_respects_policy():
    policy = ToolPolicy(deny=["delete_*"])
    ctx = ToolContext(registry=make_registry(), policy=policy, agent_name="test")
    available = ctx.available()
    assert "add" in available
    assert "delete_all" not in available
