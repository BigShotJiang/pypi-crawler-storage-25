# setup.py
from setuptools import setup, find_packages

setup(
    name='bn_calculator',  # only lowercase and dashes
    version='0.0.1',
    author='jovi',
    author_email='jo.vinckier@bynubian.com',
    description='Calculator tool for byneuron backend',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://gitlab.com/bynubian/bynode/python_packages/service-calculator',
    # find_packages() will search for all directories with an __init__.py
    packages=find_packages(exclude=["examples", "*.xlsx", "*.ini"]),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.9',
    install_requires=[
        'bn-connector>=0.0.3',
        'bn-byneuron>=0.0.118'
        # dependencies: other packages required
        # eg 'numpy>=1.11.1'
    ]
)
