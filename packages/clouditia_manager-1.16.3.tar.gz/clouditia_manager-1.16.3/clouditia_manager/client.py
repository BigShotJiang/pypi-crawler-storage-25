"""
Clouditia Manager SDK Client

Manage GPU sessions via the Computing API (sk_compute_ keys)
"""

import requests
import time
import sys
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass
from datetime import datetime

from .exceptions import (
    ClouditiaManagerError,
    AuthenticationError,
    SessionNotFoundError,
    InsufficientResourcesError,
    APIError
)


@dataclass
class GPUSession:
    """Represents a GPU session.

    Fields:
        status: Raw server status (running, paused, creating, ...).
        ready: True only if the session is fully usable — status 'running' AND
            any background workspace restore (for resumes from custom env) is
            complete. Use this instead of `status == 'running'` to know if a
            session is actually accessible.
        estimated_ready_in_seconds: Integer ETA until `ready` becomes True
            (0 if already ready, None if unknown).
        workspace_sync: Dict describing the workspace download progress for
            sessions resumed from a custom env. None if no sync is active.
            Keys: in_progress, bytes_done, bytes_total, files_done, pct,
            rate_bps, eta_seconds.
    """
    id: str
    short_id: str
    name: str
    status: str
    gpu_type: str
    gpu_count: int
    gpus: Optional[List[Dict]]
    vcpu: int
    ram: str
    storage: str
    vscode_port: Optional[int]
    jupyter_port: Optional[int]
    password: Optional[str]
    url: str
    created_at: Optional[datetime]
    started_at: Optional[datetime]
    # Auto-stop limits
    cost_limit: Optional[float] = None
    duration_limit: Optional[int] = None
    auto_stop_enabled: bool = False
    # Workspace sync info (populated from the server's session_status_summary)
    ready: bool = False
    estimated_ready_in_seconds: Optional[int] = None
    workspace_sync: Optional[Dict] = None
    # Creation progress (for monitoring session startup)
    creation_step: Optional[str] = None
    creation_error: Optional[str] = None

    def __repr__(self):
        limits = ""
        if self.auto_stop_enabled:
            limits = f", limits=True"
        ready_txt = ""
        if self.workspace_sync and self.workspace_sync.get("in_progress"):
            pct = self.workspace_sync.get("pct", 0)
            ready_txt = f", ws_sync={pct:.0f}%"
        elif self.status == "running" and not self.ready:
            ready_txt = ", ready=False"
        return f"GPUSession(name='{self.name}', id='{self.short_id}', gpus={self.gpu_count}, status='{self.status}'{ready_txt}{limits})"


@dataclass
class GPUInventory:
    """Represents available GPU in marketplace.

    Fields:
        available: GPUs on online nodes, ready to use immediately.
        on_demand: GPUs on offline nodes that can be powered on (~2-5min startup).
        total: available + on_demand + in_use.
        in_use: GPUs currently used by active sessions.
        datacenter: Datacenter location name.
    """
    gpu_type: str
    gpu_name: str
    available: int
    price_per_hour: float
    on_demand: int = 0
    in_use: int = 0
    total: int = 0
    datacenter: Optional[str] = None
    datacenter_code: Optional[str] = None
    datacenter_id: Optional[str] = None
    cluster_name: Optional[str] = None

    def __repr__(self):
        parts = [f"type='{self.gpu_type}'"]
        if self.available:
            parts.append(f"available={self.available}")
        if self.on_demand:
            parts.append(f"on_demand={self.on_demand}")
        if self.datacenter:
            parts.append(f"dc='{self.datacenter}'")
        return f"GPUInventory({', '.join(parts)})"


@dataclass
class Datacenter:
    """Represents a datacenter with GPU resources."""
    datacenter_id: str
    name: str
    is_primary: bool
    gpu_count: int

    def __repr__(self):
        return f"Datacenter(id={self.datacenter_id}, name='{self.name}', gpus={self.gpu_count})"


# Backward compatibility alias
Cluster = Datacenter


@dataclass
class QueueJob:
    """Represents a queued session creation request"""
    queue_id: str
    position: int
    status: str
    status_display: str
    gpu_config: Dict
    vcpu: int
    ram: int
    storage: int
    allow_partial: bool
    attempt_count: int
    last_attempt_at: Optional[datetime]
    last_error: str
    created_at: Optional[datetime]
    created_session_id: Optional[str]

    def __repr__(self):
        return f"QueueJob(id='{self.queue_id[:8]}', position={self.position}, status='{self.status}', attempts={self.attempt_count})"


@dataclass
class QueueAttempt:
    """Represents an attempt to create a session from queue"""
    attempt_id: str
    success: bool
    error_message: str
    available_gpus: List[str]
    unavailable_gpus: List[str]
    attempted_at: Optional[datetime]

    def __repr__(self):
        status = "Success" if self.success else "Failed"
        return f"QueueAttempt(id='{self.attempt_id[:8]}', {status})"


@dataclass
class LambdaResult:
    """Result of a lambda GPU execution"""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    output_files: List[str]
    session_id: str
    duration_seconds: float
    cost: float
    error: Optional[str] = None

    def __repr__(self):
        status = "Success" if self.success else f"Failed(exit={self.exit_code})"
        return f"LambdaResult({status}, duration={self.duration_seconds:.1f}s, cost={self.cost:.2f}EUR)"


@dataclass
class S3Connection:
    """S3 connection configuration for Lambda GPU outputs"""
    bucket: str
    access_key: str
    secret_key: str
    endpoint: str = "https://s3.amazonaws.com"
    region: str = "us-east-1"
    prefix: str = ""

    def __repr__(self):
        return f"S3Connection(bucket='{self.bucket}', endpoint='{self.endpoint}')"


class GPUManager:
    """
    Clouditia GPU Manager Client

    Manage GPU sessions using the Computing API.

    Args:
        api_key: Your sk_compute_ API key
        base_url: API base URL (default: https://clouditia.com/jobs)
        timeout: Request timeout in seconds (default: 60)
    """

    DEFAULT_BASE_URL = "https://clouditia.com/jobs"

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: int = 60
    ):
        if not api_key or not api_key.startswith("sk_compute_"):
            raise AuthenticationError("Invalid API key. Must start with 'sk_compute_'")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "clouditia-manager/1.0.0"
        })

        # Verify API key on init
        self._verify_api_key()

    def _verify_api_key(self):
        """Verify the API key is valid"""
        try:
            response = self._request("GET", "/api/computing/verify/")
            if not response.get("valid"):
                raise AuthenticationError("API key is not valid")
            self.user = response.get("user", {})
        except requests.exceptions.RequestException as e:
            raise APIError(f"Failed to verify API key: {e}")

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Dict = None,
        params: Dict = None,
        request_timeout: int = None
    ) -> Dict:
        """Make an API request"""
        url = f"{self.base_url}{endpoint}"

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=request_timeout or self.timeout
            )

            if response.status_code == 401:
                raise AuthenticationError("Invalid or expired API key")
            elif response.status_code == 403:
                raise AuthenticationError("Access denied")
            elif response.status_code == 404:
                raise SessionNotFoundError("Resource not found")
            elif response.status_code == 400:
                # Return JSON response for 400 errors (may contain availability info)
                try:
                    return response.json()
                except:
                    raise APIError(f"Bad request: {response.text}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.JSONDecodeError:
            return {"raw": response.text}
        except requests.exceptions.RequestException as e:
            raise APIError(f"Request failed: {e}")

    def create_session(
        self,
        gpu_type: str = None,
        gpu_count: int = 1,
        gpus: List[Dict] = None,
        vcpu: int = 4,
        ram: int = 16,
        storage: int = 20,
        wait_ready: bool = True,
        # timeout: Global timeout is no longer used by default.
        # The SDK monitors creation_step changes and only times out if a step
        # is stuck for 300s without progress. Pass timeout=N to force a global limit.
        timeout: int = None,
        verbose: bool = True,
        allow_partial: bool = False,
        auto_add_gpus: bool = False,
        queue_if_unavailable: bool = False,
        cost_limit: float = None,
        duration_limit: int = None,
        extra_config: Dict = None,
        environment_id: str = None,
        datacenter_id: str = None,
        cluster_id: str = None
    ) -> GPUSession:
        """
        Create a new GPU session.

        Args:
            gpu_type: GPU type slug (e.g., 'nvidia-rtx-3090') - for single GPU
            gpu_count: Number of GPUs of same type (default: 1)
            gpus: List of GPU configs for multiple GPU types
                  Example: [{'type': 'nvidia-rtx-3090', 'count': 1},
                           {'type': 'nvidia-rtx-3060-ti', 'count': 1}]
            vcpu: Number of vCPUs (default: 4)
            ram: RAM in GB (default: 16)
            storage: Storage in GB (default: 20)
            wait_ready: Wait for session to be fully ready (default: True)
            timeout: Global max wait time in seconds (default: None = no global limit,
                     the SDK monitors creation steps and times out only if a step is
                     stuck for 300s without progress)
            verbose: Print status messages and creation steps (default: True)
            allow_partial: If True, create session with only available GPUs
                          when some requested GPUs are unavailable. If False (default),
                          raises InsufficientResourcesError when any GPU is unavailable.
            auto_add_gpus: If True (requires allow_partial=True), the SDK will
                          periodically check for missing GPUs and automatically add them
                          to the running session when they become available (default: False)
            queue_if_unavailable: If True, add request to queue when GPUs are unavailable
                                 instead of raising an error (default: False)
            cost_limit: Maximum cost in EUR before auto-stop (default: None = no limit)
            duration_limit: Maximum duration in seconds before auto-stop (default: None = no limit)
            environment_id: Custom environment ID to deploy (default: None = standard image)
            datacenter_id: Target a specific datacenter by ID (default: None = any datacenter)
            cluster_id: Alias for datacenter_id (deprecated)

        Returns:
            GPUSession object with session details
            Or Dict with queue info if queue_if_unavailable=True and request was queued

        Raises:
            InsufficientResourcesError: If requested GPU is not available (and not queued)
            APIError: If session creation fails
        """
        # Build request data
        data = {
            "vcpu": vcpu,
            "ram": ram,
            "storage": storage,
            "allow_partial": allow_partial,
            "queue_if_unavailable": queue_if_unavailable
        }

        # Add environment_id if specified
        if environment_id:
            data["environment_id"] = environment_id

        # Add datacenter_id if specified (cluster_id as fallback for backward compat)
        _dc_id = datacenter_id or cluster_id
        if _dc_id is not None:
            data["cluster_id"] = _dc_id

        # Add limits if specified
        if cost_limit is not None:
            data["cost_limit"] = cost_limit
        if duration_limit is not None:
            data["duration_limit"] = duration_limit

        # Add extra config (for lambda_id tracking, etc.)
        if extra_config:
            data["extra_config"] = extra_config

        # Support both single GPU and multiple GPUs
        if gpus:
            data["gpus"] = gpus
            gpu_desc = ", ".join([f"{g.get('count', 1)}x {g.get('type', 'GPU')}" for g in gpus])
        else:
            gpu_type = gpu_type or "nvidia-rtx-3090"
            data["gpu_type"] = gpu_type
            data["gpu_count"] = gpu_count
            gpu_desc = f"{gpu_count}x {gpu_type}"

        if verbose:
            print(f"Creating GPU session with {gpu_desc}...")
            print(f"Checking GPU availability...")

        # Use 90s timeout for creation (Cloudflare cuts at ~100s)
        # If it timeouts, check if session was created anyway
        try:
            response = self._request("POST", "/api/computing/sessions/create/", data=data, request_timeout=90)
        except APIError as e:
            if "timed out" in str(e).lower() or "timeout" in str(e).lower():
                # Request timed out — session may have been created
                # Check recent sessions to find it
                if verbose:
                    print(f"\n  Request timed out, checking if session was created...")
                time.sleep(5)
                sessions = self.list_sessions(status="running")
                # Find most recent session matching our GPU type
                target_type = gpu_type or (gpus[0].get('type') if gpus else None)
                for s in sorted(sessions, key=lambda x: x.created_at or "", reverse=True):
                    if s.gpu_type == target_type and s.status in ("running", "pending", "creating"):
                        if verbose:
                            print(f"  Found session: {s.short_id}")
                        if wait_ready:
                            return self._wait_for_ready(s.short_id, timeout=timeout, verbose=verbose)
                        return s
                # Session not found, raise original error
                raise
            raise

        # Handle queued response
        if response.get("queued"):
            queue_id = response.get("queue_id")
            position = response.get("position")
            message = response.get("message", "Demande ajoutée à la queue")

            if verbose:
                print(f"\n{'='*50}")
                print(f"  REQUEST QUEUED")
                print(f"{'='*50}")
                print(f"  Queue ID  : {queue_id[:8]}...")
                print(f"  Position  : #{position}")
                print(f"  Message   : {message}")
                unavailable = response.get("unavailable_gpus", [])
                available = response.get("available_gpus", [])
                if unavailable:
                    print(f"  Unavailable GPUs: {', '.join(unavailable)}")
                if available:
                    print(f"  Available GPUs  : {', '.join(available)}")
                print(f"{'='*50}")
                print(f"\nUse manager.get_queue_job('{queue_id[:8]}') to check status")
                print(f"Use manager.cancel_queue_job('{queue_id[:8]}') to cancel\n")

            # Return queue info as dict
            return {
                'queued': True,
                'queue_id': queue_id,
                'position': position,
                'message': message,
                'unavailable_gpus': response.get('unavailable_gpus', []),
                'available_gpus': response.get('available_gpus', [])
            }

        # Handle partial availability response
        if not response.get("success"):
            error = response.get("error", "Unknown error")
            unavailable = response.get("unavailable_gpus", [])
            available = response.get("available_gpus", [])

            if unavailable and available:
                if verbose:
                    print(f"\n{'='*50}")
                    print(f"  GPU AVAILABILITY CHECK")
                    print(f"{'='*50}")
                    print(f"  Unavailable GPUs:")
                    for gpu in unavailable:
                        print(f"    - {gpu}")
                    print(f"  Available GPUs:")
                    for gpu in available:
                        print(f"    - {gpu}")
                    print(f"{'='*50}")

                raise InsufficientResourcesError(
                    f"Some GPUs unavailable: {', '.join(unavailable)}. "
                    f"Available: {', '.join(available)}. "
                    f"Use allow_partial=True to create with available GPUs only."
                )

            # No GPUs available at all
            elif unavailable and not available:
                raise InsufficientResourcesError(
                    f"No GPUs available. Unavailable: {', '.join(unavailable)}"
                )

            # Other error
            if "disponible" in error.lower() or "available" in error.lower():
                raise InsufficientResourcesError(error)
            raise APIError(error)

        session_data = response.get("session", {})
        session = self._parse_session(session_data)

        if verbose:
            print(f"Session created: {session.short_id}")

        # Wait for session to be fully ready
        if wait_ready:
            session = self._wait_for_ready(session.short_id, timeout=timeout, verbose=verbose)

        # Auto-add missing GPUs in background
        if auto_add_gpus and allow_partial and gpus:
            missing = response.get("unavailable_gpus", [])
            if missing and session.short_id:
                import threading
                def _auto_add_worker():
                    self._auto_add_missing_gpus(session.short_id, missing, verbose=verbose)
                t = threading.Thread(target=_auto_add_worker, daemon=True)
                t.start()
                if verbose:
                    print(f"🔄 Auto-add enabled: watching for {', '.join(missing)}")

        return session

    def _auto_add_missing_gpus(self, session_id: str, missing_gpus: List[str],
                               poll_interval: int = 30, max_attempts: int = 60,
                               verbose: bool = True):
        """Background worker: periodically check for missing GPUs and add them."""
        for attempt in range(max_attempts):
            time.sleep(poll_interval)

            # Check if session is still running
            try:
                session = self.get_session(session_id)
                if session.status != "running":
                    if verbose:
                        print(f"🔄 Auto-add stopped: session {session_id} is {session.status}")
                    return
            except Exception:
                return

            # Check inventory for each missing GPU
            still_missing = []
            for gpu_type in missing_gpus:
                try:
                    inventory = self.get_inventory()
                    available = [g for g in inventory if g.gpu_type == gpu_type and g.available > 0]
                    if available:
                        # GPU is now available — try to add it
                        if verbose:
                            print(f"🔄 GPU {gpu_type} now available! Adding to session {session_id}...")
                        try:
                            self._request("POST", "/api/computing/sessions/add-gpu/", data={
                                "session_id": session_id,
                                "gpu_type": gpu_type,
                                "gpu_count": 1
                            })
                            if verbose:
                                print(f"✅ GPU {gpu_type} added to session {session_id}")
                        except Exception as e:
                            if verbose:
                                print(f"⚠️ Failed to add {gpu_type}: {e}")
                            still_missing.append(gpu_type)
                    else:
                        still_missing.append(gpu_type)
                except Exception:
                    still_missing.append(gpu_type)

            missing_gpus = still_missing
            if not missing_gpus:
                if verbose:
                    print(f"✅ All GPUs added to session {session_id}")
                return

        if verbose and missing_gpus:
            print(f"⚠️ Auto-add timed out. Still missing: {', '.join(missing_gpus)}")

    # Step labels for verbose output
    _STEP_LABELS = {
        'queued': 'Queued...',
        'validating': 'Validating...',
        'powering_on': 'Powering on node...',
        'waiting_power': 'Waiting for node to start...',
        'waiting_nodes': 'Waiting for nodes...',
        'waiting_k8s': 'Waiting for K8s node ready...',
        'deploying': 'Deploying GPU session...',
        'waiting_ready': 'Waiting for pod ready...',
        'ready': 'Ready!',
        'error': 'Error',
    }

    def _wait_for_ready(
        self,
        session_id: str,
        timeout: int = None,
        poll_interval: int = 3,
        verbose: bool = True,
        stale_timeout: int = 300
    ) -> GPUSession:
        """
        Wait for session to be ready by monitoring creation steps.

        Instead of a fixed global timeout, this method monitors the creation_step
        field. If the step doesn't change for `stale_timeout` seconds, the session
        is considered stuck. Real errors (failed status, creation_error) are
        returned immediately.

        Args:
            session_id: Session short ID
            timeout: Optional global timeout in seconds (default: None = no global limit)
            poll_interval: Seconds between polls (default: 3)
            verbose: Print step changes (default: True)
            stale_timeout: Max seconds without step change before timeout (default: 300)
        """
        if verbose:
            print(f"Waiting for session {session_id} to be ready...")

        start_time = time.time()
        last_step = None
        last_step_time = time.time()
        ws_progress_shown = False

        while True:
            # Global timeout check (if set)
            if timeout and (time.time() - start_time) > timeout:
                if verbose:
                    print(f"  Global timeout ({timeout}s) reached")
                raise APIError(f"Timeout waiting for session {session_id} to be ready")

            # Stale step check
            if (time.time() - last_step_time) > stale_timeout:
                if verbose:
                    print(f"  No progress for {stale_timeout}s (stuck at step: {last_step})")
                raise APIError(
                    f"Session {session_id} stuck at step '{last_step}' "
                    f"for {stale_timeout}s without progress"
                )

            try:
                session = self.get_session(session_id)

                # Track step changes
                current_step = session.creation_step or session.status
                if current_step != last_step:
                    last_step = current_step
                    last_step_time = time.time()
                    if verbose and current_step != 'ready':
                        label = self._STEP_LABELS.get(current_step, current_step)
                        print(f"  [{current_step}] {label}")

                # Session failed — return error immediately
                if session.status == "failed":
                    error_msg = session.creation_error or "Unknown error"
                    if verbose:
                        print(f"  [error] {error_msg}")
                    raise APIError(f"Session {session_id} failed: {error_msg}")

                # Workspace restore in progress — show live progress
                ws = session.workspace_sync
                if ws and ws.get("in_progress"):
                    if verbose:
                        if not ws_progress_shown:
                            ws_progress_shown = True
                        pct = ws.get("pct", 0) or 0
                        bytes_done = ws.get("bytes_done", 0) or 0
                        bytes_total = ws.get("bytes_total", 0) or 0
                        eta = ws.get("eta_seconds")
                        gb_done = bytes_done / (1024**3)
                        gb_total = bytes_total / (1024**3)
                        eta_txt = f"{int(eta)}s" if eta else "?"
                        bar_len = 30
                        filled = int(bar_len * pct / 100)
                        bar = "█" * filled + "░" * (bar_len - filled)
                        print(f"\r  Workspace restore [{bar}] {pct:5.1f}% "
                              f"{gb_done:.2f}/{gb_total:.2f} GB  ETA {eta_txt}   ",
                              end="", flush=True)
                    # Reset stale timer during active workspace sync
                    last_step_time = time.time()
                    time.sleep(poll_interval)
                    continue

                # Session ready
                if session.ready or session.status == "running":
                    time.sleep(2)
                    if ws_progress_shown and verbose:
                        print()

                    if verbose:
                        print(f"\n{'='*50}")
                        print(f"  SESSION READY")
                        print(f"{'='*50}")
                        print(f"  Name     : {session.name}")
                        print(f"  Short ID : {session.short_id}")
                        print(f"  Status   : {session.status}")
                        if session.gpus and len(session.gpus) > 1:
                            print(f"  GPUs     : {session.gpu_count} total")
                            for gpu in session.gpus:
                                print(f"           - {gpu.get('slug', 'GPU')} x{gpu.get('quantity', 1)}")
                        else:
                            print(f"  GPU      : {session.gpu_type} x{session.gpu_count}")
                        print(f"  vCPU     : {session.vcpu}")
                        print(f"  RAM      : {session.ram}")
                        print(f"  Storage  : {session.storage}")
                        if session.auto_stop_enabled:
                            print(f"  {'-'*46}")
                            print(f"  AUTO-STOP ENABLED")
                            if session.cost_limit:
                                print(f"  Cost Limit     : {session.cost_limit} EUR")
                            if session.duration_limit:
                                hours = session.duration_limit // 3600
                                mins = (session.duration_limit % 3600) // 60
                                print(f"  Duration Limit : {hours}h {mins}m ({session.duration_limit}s)")
                            print(f"  {'-'*46}")
                        print(f"  URL      : {session.url}")
                        print(f"  Password : {session.password}")
                        print(f"{'='*50}\n")

                    return session

            except SessionNotFoundError:
                pass

            time.sleep(poll_interval)

    def stop_session(
        self,
        session_id: str,
        wait_stopped: bool = True,
        timeout: int = 120,
        verbose: bool = True
    ) -> GPUSession:
        """
        Stop a running GPU session.

        Args:
            session_id: Session ID (short or full UUID)
            wait_stopped: Wait for session to be fully stopped (default: True)
            timeout: Max wait time in seconds (default: 120)
            verbose: Print status messages (default: True)

        Returns:
            GPUSession object with final status

        Raises:
            SessionNotFoundError: If session is not found
        """
        # Get session info first
        try:
            session = self.get_session(session_id)
        except SessionNotFoundError:
            raise SessionNotFoundError(f"Session {session_id} not found")

        if verbose:
            print(f"Stopping session {session.short_id}...")

        response = self._request(
            "POST",
            "/api/computing/sessions/stop/",
            data={"session_id": session_id}
        )

        if not response.get("success"):
            error = response.get("error", "Unknown error")
            if "not found" in error.lower() or "non trouvée" in error.lower():
                raise SessionNotFoundError(f"Session {session_id} not found")
            raise APIError(error)

        # Wait for session to be fully stopped
        if wait_stopped:
            session = self._wait_for_stopped(
                session.short_id,
                session_info=session,
                timeout=timeout,
                verbose=verbose
            )

        return session

    def _wait_for_stopped(
        self,
        session_id: str,
        session_info: GPUSession = None,
        timeout: int = 120,
        poll_interval: int = 2,
        verbose: bool = True
    ) -> GPUSession:
        """
        Internal method: Wait for session and pods to be fully stopped.

        GPU resource updates are handled automatically by the server.
        """
        if verbose:
            print(f"Waiting for pod termination...", end="", flush=True)

        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                session = self.get_session(session_id)

                if session.status == "stopped":
                    if verbose:
                        print(" Done!")
                        print(f"\n{'='*50}")
                        print(f"  SESSION STOPPED")
                        print(f"{'='*50}")
                        print(f"  Name     : {session.name}")
                        print(f"  Short ID : {session.short_id}")
                        print(f"  Status   : {session.status}")
                        # Display GPUs
                        if session.gpus and len(session.gpus) > 1:
                            print(f"  GPUs     : {session.gpu_count} released")
                            for gpu in session.gpus:
                                print(f"           - {gpu.get('slug', 'GPU')}")
                        else:
                            print(f"  GPU      : {session.gpu_type} (released)")
                        print(f"{'='*50}\n")

                    return session

            except SessionNotFoundError:
                # Session might be deleted, consider it stopped
                session_name = session_info.name if session_info else f"compute-gpu-{session_id}"
                if verbose:
                    print(" Done!")
                    print(f"\n{'='*50}")
                    print(f"  SESSION STOPPED")
                    print(f"{'='*50}")
                    print(f"  Name     : {session_name}")
                    print(f"  Short ID : {session_id}")
                    print(f"  Status   : stopped (deleted)")
                    print(f"{'='*50}\n")

                if session_info:
                    session_info.status = "stopped"
                    return session_info
                return None

            if verbose:
                print(".", end="", flush=True)

            time.sleep(poll_interval)

        if verbose:
            print(" Timeout!")

        # Return last known state
        try:
            return self.get_session(session_id)
        except:
            if session_info:
                return session_info
            raise APIError(f"Timeout waiting for session {session_id} to stop")

    def get_session(self, session_id: str) -> GPUSession:
        """
        Get details of a specific session.

        Args:
            session_id: Session ID (short or full UUID)

        Returns:
            GPUSession object
        """
        response = self._request(
            "GET",
            "/api/computing/sessions/status/",
            params={"session_id": session_id}
        )

        if not response.get("success"):
            raise SessionNotFoundError(f"Session {session_id} not found")

        return self._parse_session(response.get("session", {}))

    def list_sessions(self, status: str = None) -> List[GPUSession]:
        """
        List all GPU sessions.

        Args:
            status: Filter by status ('running', 'stopped', 'pending')

        Returns:
            List of GPUSession objects
        """
        params = {}
        if status:
            params["status"] = status

        response = self._request("GET", "/api/computing/sessions/", params=params)

        sessions = []
        for session_data in response.get("sessions", []):
            sessions.append(self._parse_session(session_data))

        return sessions

    def get_inventory(self, datacenter_id: str = None) -> List[GPUInventory]:
        """
        Get available GPU inventory.

        Args:
            datacenter_id: Filter inventory by datacenter ID (default: None = all datacenters)

        Returns:
            List of GPUInventory objects with real-time availability:
            - available: GPUs ready to use immediately (nodes online)
            - on_demand: GPUs on offline nodes (~2-5min startup)
            - in_use: GPUs currently used by active sessions
            - total: available + on_demand + in_use
        """
        params = {}
        if datacenter_id is not None:
            params["cluster_id"] = datacenter_id  # API param name kept for backward compat

        response = self._request("GET", "/api/computing/inventory/", params=params)

        inventory = []
        for item in response.get("inventory", []):
            inventory.append(GPUInventory(
                gpu_type=item.get("gpu_type", ""),
                gpu_name=item.get("gpu_name", ""),
                available=item.get("available", 0),
                on_demand=item.get("on_demand", 0),
                in_use=item.get("in_use", 0),
                total=item.get("total", 0),
                datacenter=item.get("datacenter"),
                datacenter_code=item.get("datacenter_code"),
                price_per_hour=item.get("price_per_hour", 0.0),
                datacenter_id=item.get("cluster_id"),
                cluster_name=item.get("cluster_name")
            ))

        return inventory

    def list_datacenters(self) -> List[Datacenter]:
        """
        List available datacenters.

        Returns:
            List of Datacenter objects
        """
        response = self._request("GET", "/api/computing/clusters/")

        datacenters = []
        for item in response.get("clusters", []):
            datacenters.append(Datacenter(
                datacenter_id=item.get("cluster_id", ""),
                name=item.get("name", ""),
                is_primary=item.get("is_primary", False),
                gpu_count=item.get("gpu_count", 0)
            ))

        return datacenters

    # Backward compatibility
    def list_clusters(self) -> List[Datacenter]:
        """Alias for list_datacenters() (deprecated, use list_datacenters instead)."""
        return self.list_datacenters()

    def generate_sdk_key(self, session_id: str, name: str = "SDK Key") -> str:
        """
        Generate an sk_live_ API key for a session.

        This key can be used with the 'clouditia' SDK to execute code.

        Args:
            session_id: Session ID
            name: Key name (default: "SDK Key")

        Returns:
            The generated sk_live_ API key
        """
        response = self._request(
            "POST",
            "/api/computing/sessions/generate-key/",
            data={"session_id": session_id, "name": name}
        )

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to generate key"))

        return response.get("api_key")

    def rename_session(self, session_id: str, new_name: str) -> GPUSession:
        """
        Rename a GPU session.

        Args:
            session_id: Session ID (short or full UUID)
            new_name: New name for the session

        Returns:
            GPUSession object with updated name
        """
        response = self._request(
            "POST",
            "/api/computing/sessions/rename/",
            data={"session_id": session_id, "name": new_name}
        )

        if not response.get("success"):
            error = response.get("error", "Failed to rename session")
            if "not found" in error.lower():
                raise SessionNotFoundError(f"Session {session_id} not found")
            raise APIError(error)

        # Get updated session
        return self.get_session(session_id)

    def get_balance(self) -> Dict:
        """
        Get user's credit balance.

        Returns:
            Dict with 'balance' (float) and 'currency' (str)
        """
        response = self._request("GET", "/api/computing/balance/")

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to get balance"))

        return {
            'balance': response.get('balance', 0.0),
            'currency': response.get('currency', 'EUR')
        }

    def get_session_cost(self, session_id: str) -> Dict:
        """
        Get cost and duration of a specific session.

        Args:
            session_id: Session ID (short or full UUID)

        Returns:
            Dict with session cost details:
            - session_id: Full session ID
            - short_id: Short session ID (8 chars)
            - name: Session name
            - status: Session status
            - cost: Current cost in EUR
            - hourly_rate: Hourly rate in EUR
            - duration_seconds: Duration in seconds
            - duration_hours: Duration in hours
            - duration_display: Human readable duration (e.g., "2h 30m 15s")
            - started_at: Start time (ISO format)
            - ended_at: End time (ISO format) or None if still running
        """
        response = self._request(
            "GET",
            "/api/computing/sessions/cost/",
            params={"session_id": session_id}
        )

        if not response.get("success"):
            error = response.get("error", "Failed to get session cost")
            if "not found" in error.lower():
                raise SessionNotFoundError(f"Session {session_id} not found")
            raise APIError(error)

        return {
            'session_id': response.get('session_id'),
            'short_id': response.get('short_id'),
            'name': response.get('name'),
            'status': response.get('status'),
            'cost': response.get('cost', 0.0),
            'hourly_rate': response.get('hourly_rate', 0.0),
            'duration_seconds': response.get('duration_seconds', 0),
            'duration_hours': response.get('duration_hours', 0.0),
            'duration_display': response.get('duration_display', '0h 0m 0s'),
            'started_at': response.get('started_at'),
            'ended_at': response.get('ended_at'),
            'currency': response.get('currency', 'EUR')
        }

    def get_session_duration(self, session_id: str) -> Dict:
        """
        Get duration of a specific session.

        Args:
            session_id: Session ID (short or full UUID)

        Returns:
            Dict with duration details:
            - duration_seconds: Duration in seconds
            - duration_hours: Duration in hours
            - duration_display: Human readable duration (e.g., "2h 30m 15s")
            - started_at: Start time (ISO format)
            - ended_at: End time (ISO format) or None if still running
        """
        cost_info = self.get_session_cost(session_id)
        return {
            'duration_seconds': cost_info['duration_seconds'],
            'duration_hours': cost_info['duration_hours'],
            'duration_display': cost_info['duration_display'],
            'started_at': cost_info['started_at'],
            'ended_at': cost_info['ended_at']
        }

    def get_sessions_cost(self, session_ids: List[str]) -> Dict:
        """
        Get cost of multiple sessions.

        Args:
            session_ids: List of session IDs (short or full UUIDs)

        Returns:
            Dict with:
            - sessions: List of session cost details
            - session_count: Number of sessions
            - total_cost: Total cost in EUR
            - total_duration_seconds: Total duration in seconds
            - total_duration_display: Human readable total duration
        """
        response = self._request(
            "POST",
            "/api/computing/sessions/costs/",
            data={"session_ids": session_ids}
        )

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to get sessions cost"))

        return {
            'sessions': response.get('sessions', []),
            'session_count': response.get('session_count', 0),
            'total_cost': response.get('total_cost', 0.0),
            'total_duration_seconds': response.get('total_duration_seconds', 0),
            'total_duration_display': response.get('total_duration_display', '0h 0m'),
            'currency': response.get('currency', 'EUR')
        }

    def get_active_sessions_cost(self) -> Dict:
        """
        Get cost of all active (running) sessions.

        Returns:
            Dict with:
            - sessions: List of active session cost details
            - session_count: Number of active sessions
            - total_cost: Total cost of all active sessions in EUR
            - total_duration_seconds: Total duration in seconds
            - total_duration_display: Human readable total duration
        """
        response = self._request(
            "GET",
            "/api/computing/sessions/costs/",
            params={"active_only": "true"}
        )

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to get active sessions cost"))

        return {
            'sessions': response.get('sessions', []),
            'session_count': response.get('session_count', 0),
            'total_cost': response.get('total_cost', 0.0),
            'total_duration_seconds': response.get('total_duration_seconds', 0),
            'total_duration_display': response.get('total_duration_display', '0h 0m'),
            'currency': response.get('currency', 'EUR')
        }

    def _parse_session(self, data: Dict) -> GPUSession:
        """Parse session data into GPUSession object"""
        session_id = data.get("id", "")
        short_id = session_id[:8] if session_id else ""

        # Parse limits
        limits = data.get("limits", {})
        cost_limit = limits.get("cost_limit")
        duration_limit = limits.get("duration_limit")
        auto_stop_enabled = limits.get("auto_stop_enabled", False)

        return GPUSession(
            id=session_id,
            short_id=short_id,
            name=data.get("name", f"compute-gpu-{short_id}"),
            status=data.get("status", "unknown"),
            gpu_type=data.get("gpu_type", ""),
            gpu_count=data.get("gpu_count", 1),
            gpus=data.get("gpus"),
            vcpu=data.get("vcpu", 0),
            ram=data.get("ram", ""),
            storage=data.get("storage", ""),
            vscode_port=data.get("vscode_port"),
            jupyter_port=data.get("jupyter_port"),
            password=data.get("password"),
            url=data.get("url", f"https://clouditia.com/code-editor/{session_id}/"),
            created_at=self._parse_datetime(data.get("created_at")),
            started_at=self._parse_datetime(data.get("started_at")),
            cost_limit=cost_limit,
            duration_limit=duration_limit,
            auto_stop_enabled=auto_stop_enabled,
            ready=data.get("ready", False),
            estimated_ready_in_seconds=data.get("estimated_ready_in_seconds"),
            workspace_sync=data.get("workspace_sync"),
            creation_step=data.get("creation_step"),
            creation_error=data.get("creation_error"),
        )

    def _parse_queue_job(self, data: Dict) -> QueueJob:
        """Parse queue job data into QueueJob object"""
        return QueueJob(
            queue_id=data.get("queue_id", ""),
            position=data.get("position", 0),
            status=data.get("status", "unknown"),
            status_display=data.get("status_display", ""),
            gpu_config=data.get("gpu_config", {}),
            vcpu=data.get("vcpu", 4),
            ram=data.get("ram", 16),
            storage=data.get("storage", 20),
            allow_partial=data.get("allow_partial", False),
            attempt_count=data.get("attempt_count", 0),
            last_attempt_at=self._parse_datetime(data.get("last_attempt_at")),
            last_error=data.get("last_error", ""),
            created_at=self._parse_datetime(data.get("created_at")),
            created_session_id=data.get("created_session_id")
        )

    def _parse_queue_attempt(self, data: Dict) -> QueueAttempt:
        """Parse queue attempt data into QueueAttempt object"""
        return QueueAttempt(
            attempt_id=data.get("attempt_id", ""),
            success=data.get("success", False),
            error_message=data.get("error_message", ""),
            available_gpus=data.get("available_gpus", []),
            unavailable_gpus=data.get("unavailable_gpus", []),
            attempted_at=self._parse_datetime(data.get("attempted_at"))
        )

    @staticmethod
    def _parse_datetime(value) -> Optional[datetime]:
        """Parse datetime string"""
        if not value:
            return None
        if isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            return None

    # ==================== QUEUE METHODS ====================

    def list_queue_jobs(self, status: str = None) -> List[QueueJob]:
        """
        List user's queued session creation requests.

        Args:
            status: Filter by status ('pending', 'processing', 'completed', 'failed', 'cancelled')

        Returns:
            List of QueueJob objects
        """
        params = {}
        if status:
            params["status"] = status

        response = self._request("GET", "/api/computing/queue/", params=params)

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to list queue jobs"))

        jobs = []
        for job_data in response.get("queue_jobs", []):
            jobs.append(self._parse_queue_job(job_data))

        return jobs

    def get_queue_job(self, queue_id: str, verbose: bool = False) -> Dict:
        """
        Get details of a specific queued job with attempt history.

        Args:
            queue_id: Queue job ID (short or full UUID)
            verbose: Print details to console (default: False)

        Returns:
            Dict with:
            - job: QueueJob object
            - attempts: List of QueueAttempt objects
            - attempts_count: Number of attempts
        """
        response = self._request(
            "GET",
            "/api/computing/queue/job/",
            params={"queue_id": queue_id}
        )

        if not response.get("success"):
            error = response.get("error", "Failed to get queue job")
            if "not found" in error.lower():
                raise SessionNotFoundError(f"Queue job {queue_id} not found")
            raise APIError(error)

        job = self._parse_queue_job(response.get("queue_job", {}))
        attempts = [
            self._parse_queue_attempt(a)
            for a in response.get("attempts", [])
        ]

        if verbose:
            print(f"\n{'='*50}")
            print(f"  QUEUE JOB DETAILS")
            print(f"{'='*50}")
            print(f"  Queue ID    : {job.queue_id[:8]}...")
            print(f"  Position    : #{job.position}")
            print(f"  Status      : {job.status_display}")
            print(f"  GPU Config  : {job.gpu_config}")
            print(f"  vCPU        : {job.vcpu}")
            print(f"  RAM         : {job.ram}GB")
            print(f"  Storage     : {job.storage}GB")
            print(f"  Attempts    : {job.attempt_count}")
            if job.last_attempt_at:
                print(f"  Last Tested : {job.last_attempt_at}")
            if job.last_error:
                print(f"  Last Error  : {job.last_error}")
            if job.created_session_id:
                print(f"  Session ID  : {job.created_session_id[:8]}...")
            print(f"{'='*50}")

            if attempts:
                print(f"\n  ATTEMPT HISTORY ({len(attempts)} attempts)")
                print(f"  {'-'*46}")
                for i, attempt in enumerate(attempts, 1):
                    status = "✓ Success" if attempt.success else "✗ Failed"
                    print(f"  {i}. [{status}] {attempt.attempted_at}")
                    if attempt.error_message:
                        print(f"     Error: {attempt.error_message[:50]}...")
                    if attempt.unavailable_gpus:
                        print(f"     Unavailable: {', '.join(attempt.unavailable_gpus)}")
                print()

        return {
            'job': job,
            'attempts': attempts,
            'attempts_count': len(attempts)
        }

    def cancel_queue_job(self, queue_id: str, verbose: bool = True) -> bool:
        """
        Cancel a queued session creation request.

        Args:
            queue_id: Queue job ID (short or full UUID)
            verbose: Print status message (default: True)

        Returns:
            True if cancelled successfully

        Raises:
            SessionNotFoundError: If queue job is not found
            APIError: If cancellation fails
        """
        response = self._request(
            "POST",
            "/api/computing/queue/cancel/",
            data={"queue_id": queue_id}
        )

        if not response.get("success"):
            error = response.get("error", "Failed to cancel queue job")
            if "not found" in error.lower():
                raise SessionNotFoundError(f"Queue job {queue_id} not found")
            raise APIError(error)

        if verbose:
            print(f"Queue job {queue_id[:8]}... cancelled successfully")

        return True

    # ==================== S3 CONNECTION & OUTPUT ====================

    def s3_connect(
        self,
        bucket: str,
        access_key: str,
        secret_key: str,
        endpoint: str = "https://s3.amazonaws.com",
        region: str = "us-east-1",
        prefix: str = ""
    ) -> S3Connection:
        """
        Create an S3 connection configuration for Lambda GPU outputs.

        Args:
            bucket: S3 bucket name
            access_key: AWS Access Key ID (or S3-compatible)
            secret_key: AWS Secret Access Key (or S3-compatible)
            endpoint: S3 endpoint URL (default: AWS S3, can be MinIO, Wasabi, etc.)
            region: AWS region (default: us-east-1)
            prefix: Key prefix for all uploaded files (e.g., "lambda-outputs/")

        Returns:
            S3Connection object to pass to lambda_output methods

        Example:
            s3 = manager.s3_connect(
                bucket="my-bucket",
                access_key="AKIAIOSFODNN7EXAMPLE",
                secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
            )
            manager.lambda_output("model.pt", model_data, s3=s3)
        """
        return S3Connection(
            bucket=bucket,
            access_key=access_key,
            secret_key=secret_key,
            endpoint=endpoint,
            region=region,
            prefix=prefix
        )

    def lambda_output(
        self,
        filename: str,
        data: Any,
        s3: S3Connection,
        verbose: bool = True
    ) -> str:
        """
        Save a Python object to S3 for Lambda GPU outputs.

        Supports various data types:
        - PyTorch tensors/models (.pt)
        - NumPy arrays (.npy)
        - JSON-serializable objects (.json)
        - Pickle objects (.pkl)
        - Raw bytes/strings

        Args:
            filename: Output filename (e.g., "model.pt", "results.json")
            data: Python object to save
            s3: S3Connection from s3_connect()
            verbose: Print upload status (default: True)

        Returns:
            S3 URL of the uploaded file

        Raises:
            APIError: If upload fails

        Example:
            s3 = manager.s3_connect(bucket="my-bucket", ...)
            url = manager.lambda_output("model.pt", model.state_dict(), s3=s3)
        """
        import io
        import json
        import pickle

        # Prepare data based on type and filename
        buffer = io.BytesIO()

        if filename.endswith('.pt') or filename.endswith('.pth'):
            # PyTorch model/tensor
            try:
                import torch
                torch.save(data, buffer)
            except ImportError:
                pickle.dump(data, buffer)
        elif filename.endswith('.npy') or filename.endswith('.npz'):
            # NumPy array
            try:
                import numpy as np
                np.save(buffer, data)
            except ImportError:
                pickle.dump(data, buffer)
        elif filename.endswith('.json'):
            # JSON
            json_str = json.dumps(data, indent=2, default=str)
            buffer.write(json_str.encode('utf-8'))
        elif filename.endswith('.pkl') or filename.endswith('.pickle'):
            # Pickle
            pickle.dump(data, buffer)
        elif isinstance(data, bytes):
            buffer.write(data)
        elif isinstance(data, str):
            buffer.write(data.encode('utf-8'))
        else:
            # Default: pickle
            pickle.dump(data, buffer)

        buffer.seek(0)

        # Upload to S3
        return self._upload_to_s3(filename, buffer.getvalue(), s3, verbose)

    def lambda_output_file(
        self,
        filepath: str,
        s3: S3Connection,
        remote_filename: str = None,
        verbose: bool = True
    ) -> str:
        """
        Upload an existing file to S3 for Lambda GPU outputs.

        Args:
            filepath: Local file path to upload
            s3: S3Connection from s3_connect()
            remote_filename: Custom filename for S3 (default: use original filename)
            verbose: Print upload status (default: True)

        Returns:
            S3 URL of the uploaded file

        Raises:
            FileNotFoundError: If local file doesn't exist
            APIError: If upload fails

        Example:
            s3 = manager.s3_connect(bucket="my-bucket", ...)
            url = manager.lambda_output_file("/tmp/results.csv", s3=s3)
        """
        import os

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")

        filename = remote_filename or os.path.basename(filepath)

        with open(filepath, 'rb') as f:
            data = f.read()

        return self._upload_to_s3(filename, data, s3, verbose)

    def _upload_to_s3(
        self,
        filename: str,
        data: bytes,
        s3: S3Connection,
        verbose: bool = True
    ) -> str:
        """Internal method to upload data to S3"""
        try:
            import boto3
            from botocore.config import Config

            # Create S3 client
            s3_client = boto3.client(
                's3',
                aws_access_key_id=s3.access_key,
                aws_secret_access_key=s3.secret_key,
                endpoint_url=s3.endpoint if s3.endpoint != "https://s3.amazonaws.com" else None,
                region_name=s3.region,
                config=Config(signature_version='s3v4')
            )

            # Build key with prefix
            key = f"{s3.prefix.rstrip('/')}/{filename}" if s3.prefix else filename
            key = key.lstrip('/')

            # Upload
            s3_client.put_object(
                Bucket=s3.bucket,
                Key=key,
                Body=data
            )

            # Build URL
            if s3.endpoint and "amazonaws.com" not in s3.endpoint:
                url = f"{s3.endpoint.rstrip('/')}/{s3.bucket}/{key}"
            else:
                url = f"https://{s3.bucket}.s3.{s3.region}.amazonaws.com/{key}"

            if verbose:
                print(f"Uploaded: {filename} -> {url}")

            return url

        except ImportError:
            raise APIError("boto3 is required for S3 uploads. Install with: pip install boto3")
        except Exception as e:
            raise APIError(f"S3 upload failed: {e}")

    # ==================== EMAIL ====================

    def send_email(self, subject: str, message: str, to: str = None, verbose: bool = True) -> bool:
        """
        Send an email notification.

        By default sends to the authenticated user's email address.
        Optionally specify a custom recipient.

        Args:
            subject: Email subject (max 200 characters)
            message: Email body text (max 10000 characters)
            to: Recipient email address (default: your account email)
            verbose: Print status message (default: True)

        Returns:
            True if email sent successfully

        Raises:
            APIError: If email sending fails

        Example:
            # Send to yourself
            manager.send_email(
                subject="Training Complete",
                message="Your model training has finished successfully!"
            )

            # Send to a specific recipient
            manager.send_email(
                subject="Training Complete",
                message="Accuracy: 95%",
                to="colleague@company.com"
            )
        """
        data = {"subject": subject, "message": message}
        if to:
            data["to"] = to

        response = self._request(
            "POST",
            "/api/computing/email/",
            data=data
        )

        if not response.get("success"):
            raise APIError(response.get("error", "Failed to send email"))

        if verbose:
            recipient = response.get("recipient", self.user.get("email", ""))
            print(f"Email sent to {recipient}")

        return True

    # ==================== RUN AND STOP (formerly lambda_gpu) ====================

    def run_and_stop(
        self,
        script: str,
        gpu_type: str = None,
        gpu_count: int = 1,
        gpus: List[Dict] = None,
        vcpu: int = 4,
        ram: int = 16,
        storage: int = 20,
        input_files: List[str] = None,
        output_files: List[str] = None,
        s3_bucket: str = None,
        s3_prefix: str = "",
        s3_access_key: str = None,
        s3_secret_key: str = None,
        s3_endpoint: str = None,
        s3_region: str = "us-east-1",
        lambda_id: str = None,
        queue_if_unavailable: bool = True,
        verbose: bool = True
    ) -> LambdaResult:
        """
        Execute a script on a GPU session and auto-stop when complete (run_and_stop).

        This creates a full GPU session via the SDK, uploads input files,
        runs the script, uploads output files to S3, and stops the session.
        All in one blocking call. Requires the 'clouditia' SDK to be installed.

        For a lighter serverless execution without S3 or file management,
        see the lambda_gpu() method instead.

        Args:
            script: Command/script to execute (e.g., "python train.py")
            gpu_type: GPU type slug (e.g., 'nvidia-rtx-3090')
            gpu_count: Number of GPUs (default: 1)
            gpus: List of GPU configs for multiple GPU types
            vcpu: Number of vCPUs (default: 4)
            ram: RAM in GB (default: 16)
            storage: Storage in GB (default: 20)
            input_files: List of local files to upload before execution
            output_files: List of remote files to upload to S3 after execution
            s3_bucket: S3 bucket for output files (required if output_files)
            s3_prefix: S3 key prefix for output files (default: "")
            s3_access_key: S3 access key (or use AWS_ACCESS_KEY_ID env var)
            s3_secret_key: S3 secret key (or use AWS_SECRET_ACCESS_KEY env var)
            s3_endpoint: Custom S3 endpoint (for S3-compatible storage)
            lambda_id: Unique identifier for this lambda (prevents duplicates in queue)
            queue_if_unavailable: Add to queue if GPUs unavailable (default: True)
            verbose: Print status messages (default: True)

        Returns:
            LambdaResult with execution results (output_files contains S3 URLs)

        Example:
            result = manager.run_and_stop(
                script="python train.py --epochs 10",
                gpu_type="nvidia-rtx-3090",
                input_files=["train.py", "data.csv"],
                output_files=["model.pt", "logs/"],
                s3_bucket="my-bucket",
                s3_prefix="training-results/run-001/",
                lambda_id="training-job-001"
            )
            print(f"Exit code: {result.exit_code}")
            print(f"Output files: {result.output_files}")  # S3 URLs
            print(f"Cost: {result.cost} EUR")
        """
        import os
        import hashlib
        start_time = time.time()
        session = None
        sdk_key = None

        # Validate S3 config if output_files are requested
        if output_files and not s3_bucket:
            raise ValueError("s3_bucket is required when output_files are specified")

        # Get S3 credentials from env if not provided
        s3_access_key = s3_access_key or os.environ.get('AWS_ACCESS_KEY_ID')
        s3_secret_key = s3_secret_key or os.environ.get('AWS_SECRET_ACCESS_KEY')

        if output_files and (not s3_access_key or not s3_secret_key):
            raise ValueError(
                "S3 credentials required. Provide s3_access_key/s3_secret_key "
                "or set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY env vars"
            )

        # Generate lambda_id if not provided (hash of script + gpu config)
        if not lambda_id:
            config_str = f"{script}:{gpu_type}:{gpu_count}:{gpus}:{vcpu}:{ram}"
            lambda_id = hashlib.md5(config_str.encode()).hexdigest()[:12]

        try:
            # Check for duplicate lambda in queue and cancel it
            if queue_if_unavailable:
                try:
                    queue_jobs = self.list_queue_jobs(status='pending')
                    for job in queue_jobs:
                        job_lambda_id = job.gpu_config.get('lambda_id')
                        if job_lambda_id == lambda_id:
                            if verbose:
                                print(f"Cancelling previous lambda job in queue: {str(job.queue_id)[:8]}...")
                            self.cancel_queue_job(str(job.queue_id)[:8], verbose=False)
                except Exception as e:
                    if verbose:
                        print(f"Warning: Could not check/cancel duplicate jobs: {e}")

            # Step 1: Create session
            if verbose:
                print(f"\n{'='*50}")
                print(f"  RUN AND STOP")
                print(f"{'='*50}")
                print(f"  Script: {script}")
                print(f"  Lambda ID: {lambda_id}")
                print(f"{'='*50}")
                print(f"\n[1/5] Creating GPU session...")

            # Add lambda_id to gpu_config for tracking
            extra_config = {'lambda_id': lambda_id}

            session_result = self.create_session(
                gpu_type=gpu_type,
                gpu_count=gpu_count,
                gpus=gpus,
                vcpu=vcpu,
                ram=ram,
                storage=storage,
                wait_ready=True,
                verbose=False,
                queue_if_unavailable=queue_if_unavailable,
                extra_config=extra_config
            )

            # Check if queued
            if isinstance(session_result, dict) and session_result.get('queued'):
                queue_id = session_result['queue_id']
                if verbose:
                    print(f"  Request queued at position #{session_result['position']}")
                    print(f"  Waiting for session to be created...")

                # Poll queue until session is created
                while True:
                    queue_info = self.get_queue_job(queue_id)
                    job = queue_info['job']

                    if job.status == 'completed' and job.created_session_id:
                        session = self.get_session(job.created_session_id)
                        if verbose:
                            print(f"  Session created: {session.short_id}")
                        break
                    elif job.status in ['failed', 'cancelled']:
                        raise APIError(f"Queue job {job.status}: {job.last_error}")

                    time.sleep(5)
            else:
                session = session_result
                if verbose:
                    print(f"  Session created: {session.short_id}")

            # Step 2: Generate SDK key
            if verbose:
                print(f"[2/5] Generating execution key...")

            sdk_key = self.generate_sdk_key(session.short_id, name="lambda-gpu")
            if verbose:
                print(f"  Key generated: sk_live_...{sdk_key[-8:]}")

            # Step 3: Import clouditia SDK and connect
            if verbose:
                print(f"[3/5] Connecting to session...")

            try:
                from clouditia import GPUSession as ClouditiaGPU
            except ImportError:
                raise APIError(
                    "clouditia SDK not installed. "
                    "Install with: pip install clouditia"
                )

            gpu = ClouditiaGPU(api_key=sdk_key)
            if verbose:
                print(f"  Connected to {session.name}")

            # Step 4: Upload input files
            uploaded_files = []
            if input_files:
                if verbose:
                    print(f"[3.5/5] Uploading {len(input_files)} input file(s)...")

                for file_path in input_files:
                    if os.path.exists(file_path):
                        try:
                            remote_path = f"/home/coder/workspace/{os.path.basename(file_path)}"
                            gpu.upload(file_path, remote_path)
                            uploaded_files.append(file_path)
                            if verbose:
                                print(f"  Uploaded: {file_path} -> {remote_path}")
                        except Exception as e:
                            if verbose:
                                print(f"  Warning: Failed to upload {file_path}: {e}")
                    else:
                        if verbose:
                            print(f"  Warning: File not found: {file_path}")

            # Step 5: Execute script
            if verbose:
                print(f"[4/5] Executing script...")
                print(f"  $ {script}")

            try:
                exec_result = gpu.shell(f"cd /home/coder/workspace && {script}")
                stdout = exec_result.output if hasattr(exec_result, 'output') else str(exec_result)
                stderr = exec_result.error if hasattr(exec_result, 'error') else ''
                exit_code = exec_result.exit_code if hasattr(exec_result, 'exit_code') else 0
            except Exception as e:
                stdout = ''
                stderr = str(e)
                exit_code = 1

            if verbose:
                if exit_code == 0:
                    print(f"  Execution completed (exit code: 0)")
                else:
                    print(f"  Execution failed (exit code: {exit_code})")

            # Step 6: Upload output files to S3
            s3_output_urls = []
            if output_files and s3_bucket:
                if verbose:
                    print(f"[4.5/5] Uploading {len(output_files)} output file(s) to S3...")

                # Install s3 upload script on the GPU
                s3_upload_script = f'''
import boto3
import os
from botocore.config import Config

s3 = boto3.client(
    's3',
    aws_access_key_id='{s3_access_key}',
    aws_secret_access_key='{s3_secret_key}',
    endpoint_url={repr(s3_endpoint) if s3_endpoint else 'None'},
    region_name='{s3_region}',
    config=Config(signature_version='s3v4')
)

bucket = '{s3_bucket}'
prefix = '{s3_prefix}'.rstrip('/') + '/' if '{s3_prefix}' else ''

output_files = {repr(output_files)}
uploaded = []

for f in output_files:
    if os.path.isfile(f):
        key = prefix + os.path.basename(f)
        s3.upload_file(f, bucket, key)
        uploaded.append(f's3://{s3_bucket}/' + key)
        print(f'Uploaded: {{f}} -> s3://{s3_bucket}/{{key}}')
    elif os.path.isdir(f):
        for root, dirs, files in os.walk(f):
            for name in files:
                local_path = os.path.join(root, name)
                rel_path = os.path.relpath(local_path, f)
                key = prefix + os.path.basename(f) + '/' + rel_path
                s3.upload_file(local_path, bucket, key)
                uploaded.append(f's3://{s3_bucket}/' + key)
                print(f'Uploaded: {{local_path}} -> s3://{s3_bucket}/{{key}}')
    else:
        print(f'Warning: {{f}} not found')

print('UPLOADED_FILES=' + ','.join(uploaded))
'''
                # Write and execute the S3 upload script
                try:
                    gpu.shell("pip install boto3 -q")
                    # Execute S3 upload as Python code directly
                    s3_result = gpu.run(s3_upload_script, stream=False)
                    s3_stdout = s3_result.output if hasattr(s3_result, 'output') else str(s3_result)

                    # Parse uploaded URLs from output
                    for line in s3_stdout.split('\n'):
                        if line.startswith('UPLOADED_FILES='):
                            urls = line.replace('UPLOADED_FILES=', '').strip()
                            if urls:
                                s3_output_urls = urls.split(',')
                            break
                        elif line.startswith('Uploaded:'):
                            if verbose:
                                print(f"  {line}")

                except Exception as e:
                    if verbose:
                        print(f"  Warning: Failed to upload to S3: {e}")

            # Step 7: Stop session then get final cost
            if verbose:
                print(f"[5/5] Stopping session...")

            self.stop_session(session.short_id, verbose=False)

            # Wait for terminate to calculate final cost
            time.sleep(3)
            try:
                cost_info = self.get_session_cost(session.short_id)
                cost = cost_info.get('cost', 0)
            except:
                cost = 0

            duration = time.time() - start_time

            if verbose:
                print(f"  Session stopped")
                print(f"\n{'='*50}")
                print(f"  RUN AND STOP COMPLETE")
                print(f"{'='*50}")
                print(f"  Exit Code : {exit_code}")
                print(f"  Duration  : {duration:.1f}s")
                print(f"  Cost      : {cost:.4f} EUR")
                if s3_output_urls:
                    print(f"  Output    : {len(s3_output_urls)} file(s) on S3")
                    for url in s3_output_urls[:3]:
                        print(f"            : {url}")
                    if len(s3_output_urls) > 3:
                        print(f"            : ... and {len(s3_output_urls) - 3} more")
                print(f"{'='*50}\n")

            return LambdaResult(
                success=(exit_code == 0),
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                output_files=s3_output_urls,
                session_id=session.short_id if session else '',
                duration_seconds=duration,
                cost=cost,
                error=stderr if exit_code != 0 else None
            )

        except Exception as e:
            duration = time.time() - start_time

            # Try to stop session if it was created
            if session:
                try:
                    self.stop_session(session.short_id, verbose=False)
                    if verbose:
                        print(f"  Session stopped after error")
                except:
                    pass

            if verbose:
                print(f"\n{'='*50}")
                print(f"  RUN AND STOP FAILED")
                print(f"{'='*50}")
                print(f"  Error: {str(e)}")
                print(f"{'='*50}\n")

            return LambdaResult(
                success=False,
                exit_code=1,
                stdout='',
                stderr=str(e),
                output_files=[],
                session_id=session.short_id if session else '',
                duration_seconds=duration,
                cost=0,
                error=str(e)
            )

    # ==================== LAMBDA GPU (serverless execution) ====================

    def lambda_gpu(
        self,
        script: str,
        gpu_type: str = 'nvidia-rtx-3090',
        vcpu: int = 4,
        ram: int = 16,
        storage: int = 20,
        environment_id: str = None,
        lambda_id: str = None,
        timeout: int = 3600,
        verbose: bool = True
    ) -> LambdaResult:
        """
        Execute a script on a serverless GPU via the Lambda GPU API.

        This submits a script for execution on a GPU without managing
        sessions directly. The server handles session creation, execution,
        and cleanup. Supports custom environments via environment_id.

        Args:
            script: Command/script to execute (e.g., "python train.py")
            gpu_type: GPU type slug (e.g., 'nvidia-rtx-3090')
            vcpu: Number of vCPUs (default: 4)
            ram: RAM in GB (default: 16)
            storage: Storage in GB (default: 20)
            environment_id: Custom environment ID to use (default: None = standard env)
            lambda_id: Unique identifier for this lambda (auto-generated if not provided)
            timeout: Max execution time in seconds (default: 3600)
            verbose: Print status messages (default: True)

        Returns:
            LambdaResult with execution results

        Example:
            result = manager.lambda_gpu(
                script="python train.py --epochs 10",
                gpu_type="nvidia-rtx-3090",
                vcpu=8,
                ram=32,
                lambda_id="training-job-001"
            )
            print(f"Exit code: {result.exit_code}")
            print(f"Output: {result.stdout}")
            print(f"Cost: {result.cost} EUR")
        """
        import hashlib
        start_time = time.time()

        # Generate lambda_id if not provided
        if not lambda_id:
            config_str = f"{script}:{gpu_type}:{vcpu}:{ram}"
            lambda_id = hashlib.md5(config_str.encode()).hexdigest()[:12]

        if verbose:
            print(f"\n{'='*50}")
            print(f"  LAMBDA GPU")
            print(f"{'='*50}")
            print(f"  Script: {script}")
            print(f"  Lambda ID: {lambda_id}")
            if environment_id:
                print(f"  Environment: {environment_id}")
            print(f"{'='*50}")
            print(f"\n[1/3] Submitting lambda job...")

        # Build request payload
        payload = {
            "script": script,
            "gpu_type": gpu_type,
            "vcpu": vcpu,
            "ram": ram,
            "storage": storage,
            "lambda_id": lambda_id,
            "timeout": timeout,
        }
        if environment_id:
            payload["environment_id"] = environment_id

        try:
            response = self._request(
                "POST",
                "/api/computing/lambda/execute/",
                data=payload
            )

            if not response.get("success"):
                raise APIError(response.get("error", "Lambda execution failed"))

            queued = response.get("queued", False)
            queue_id = response.get("queue_id")
            result_lambda_id = response.get("lambda_id", lambda_id)

            if queued:
                if verbose:
                    print(f"  Queued at position #{response.get('position', '?')}")
                    print(f"\n[2/3] Waiting for queue processing...")

                # Poll queue status
                while True:
                    status_resp = self._request(
                        "GET",
                        "/api/computing/lambda/status/",
                        params={"queue_id": queue_id}
                    )

                    status = status_resp.get("status", "pending")
                    if status == "completed":
                        created_session_id = status_resp.get("created_session_id")
                        if verbose:
                            print(f"  Queue processed, session created: {created_session_id}")
                        break
                    elif status in ["failed", "cancelled"]:
                        error_msg = status_resp.get("error", f"Queue job {status}")
                        raise APIError(error_msg)

                    if verbose:
                        pos = status_resp.get("position", "?")
                        print(f"  Queue position: #{pos}, status: {status}")

                    time.sleep(5)
            else:
                if verbose:
                    session_id = response.get("session_id", "")
                    print(f"  Job started (session: {session_id})")

            # Poll for results
            if verbose:
                step = "3" if queued else "2"
                print(f"\n[{step}/3] Waiting for results...")

            poll_interval = 5
            max_polls = timeout // poll_interval + 1
            for i in range(max_polls):
                try:
                    result_resp = self._request(
                        "GET",
                        f"/api/computing/lambda/result/{result_lambda_id}/"
                    )

                    status = result_resp.get("status", "running")
                    if status == "completed":
                        duration = time.time() - start_time
                        exit_code = result_resp.get("exit_code", 0)

                        # Wait for final cost calculation (terminate_session_async)
                        time.sleep(3)
                        final_resp = self._request(
                            "GET",
                            f"/api/computing/lambda/result/{result_lambda_id}/"
                        )
                        cost = float(final_resp.get("cost", 0) or result_resp.get("cost", 0))

                        if verbose:
                            print(f"  Execution completed (exit code: {exit_code})")
                            print(f"\n{'='*50}")
                            print(f"  LAMBDA GPU COMPLETE")
                            print(f"{'='*50}")
                            print(f"  Exit Code : {exit_code}")
                            print(f"  Duration  : {duration:.1f}s")
                            print(f"  Cost      : {cost:.4f} EUR")
                            print(f"{'='*50}\n")

                        return LambdaResult(
                            success=(exit_code == 0),
                            exit_code=exit_code,
                            stdout=final_resp.get("stdout", result_resp.get("stdout", "")),
                            stderr=final_resp.get("stderr", result_resp.get("stderr", "")),
                            output_files=final_resp.get("output_files", result_resp.get("output_files", [])),
                            session_id=final_resp.get("session_id", response.get("session_id", "")),
                            duration_seconds=duration,
                            cost=cost,
                            error=final_resp.get("stderr", "") if exit_code != 0 else None
                        )
                    elif status == "failed":
                        duration = time.time() - start_time
                        stderr = result_resp.get("stderr", "Execution failed")

                        if verbose:
                            print(f"\n{'='*50}")
                            print(f"  LAMBDA GPU FAILED")
                            print(f"{'='*50}")
                            print(f"  Error: {stderr}")
                            print(f"{'='*50}\n")

                        return LambdaResult(
                            success=False,
                            exit_code=result_resp.get("exit_code", 1),
                            stdout=result_resp.get("stdout", ""),
                            stderr=stderr,
                            output_files=[],
                            session_id=response.get("session_id", ""),
                            duration_seconds=duration,
                            cost=float(result_resp.get("cost", 0)),
                            error=stderr
                        )

                except SessionNotFoundError:
                    # Result not ready yet, keep polling
                    pass

                if verbose and i > 0 and i % 12 == 0:
                    elapsed = time.time() - start_time
                    print(f"  Still running... ({elapsed:.0f}s elapsed)")

                time.sleep(poll_interval)

            # Timeout
            duration = time.time() - start_time
            if verbose:
                print(f"\n{'='*50}")
                print(f"  LAMBDA GPU TIMEOUT")
                print(f"{'='*50}")
                print(f"  Timeout after {duration:.1f}s")
                print(f"{'='*50}\n")

            return LambdaResult(
                success=False,
                exit_code=1,
                stdout="",
                stderr=f"Lambda execution timed out after {timeout}s",
                output_files=[],
                session_id=response.get("session_id", ""),
                duration_seconds=duration,
                cost=0,
                error=f"Timeout after {timeout}s"
            )

        except Exception as e:
            if isinstance(e, (APIError, AuthenticationError)):
                raise

            duration = time.time() - start_time
            if verbose:
                print(f"\n{'='*50}")
                print(f"  LAMBDA GPU FAILED")
                print(f"{'='*50}")
                print(f"  Error: {str(e)}")
                print(f"{'='*50}\n")

            return LambdaResult(
                success=False,
                exit_code=1,
                stdout="",
                stderr=str(e),
                output_files=[],
                session_id="",
                duration_seconds=duration,
                cost=0,
                error=str(e)
            )

    def __repr__(self):
        return f"GPUManager(user='{self.user.get('username', 'unknown')}')"
