# better-auth-beanie

Beanie ODM adapter package scaffold for `better-auth-py`.

This package reserves the public distribution and import namespace. Runtime
adapter support will be added when the Beanie storage API is implemented.
