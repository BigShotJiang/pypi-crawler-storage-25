"""Beanie ODM adapter namespace."""
