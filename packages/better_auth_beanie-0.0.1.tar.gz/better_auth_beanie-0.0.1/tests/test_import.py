import better_auth.beanie


def test_import():
    assert better_auth.beanie.__name__ == "better_auth.beanie"
