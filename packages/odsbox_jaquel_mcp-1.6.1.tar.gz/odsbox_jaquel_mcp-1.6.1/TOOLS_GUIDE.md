"""TOOLS_GUIDE.md - Complete Guide to Jaquel MCP Server Tools."""

# Jaquel MCP Server - Complete Tools Guide

This document provides a comprehensive guide to all tools available in the ASAM ODS Jaquel MCP Server.

## Table of Contents

1. [Overview](#overview)
2. [Tool Reference](#tool-reference)
3. [Common Use Cases](#common-use-cases)
4. [Query Examples](#query-examples)
5. [Operator Reference](#operator-reference)
6. [Tips & Best Practices](#tips--best-practices)

---

## Overview

The MCP Server provides tools for working with ASAM ODS servers using queries and bulk/timeseries data access:

### ODS Connection & Data Access Tools
| Tool | Purpose | Input | Output |
|------|---------|-------|--------|
| [ods_connect](#ods_connect) | Connect to ODS server | URL, credentials | Connection status |
| [ods_connect_using_env](#ods_connect_using_env) | Connect to ODS server using env vars | env vars (e.g. ODSBOX_MCP_URL) | Connection status |
| [ods_disconnect](#ods_disconnect) | Disconnect from server | None | Status |
| [ods_get_connection_info](#ods_get_connection_info) | Get connection details | None | Connection info |

### Schema Inspection Tools
| [schema_list_entities](#schema_list_entities) | List all entities | None | Entity list |
| [schema_test_to_measurement_hierarchy](#schema_test_to_measurement_hierarchy) | Get AoTest->AoMeasurement chain | None | Hierarchy chain |
| [schema_get_entity](#schema_get_entity) | Get entity fields | Entity name | Field list |
| [schema_field_exists](#schema_field_exists) | Check field (attribute or relationship) exists | Entity name, field name | Validation result |

### Jaquel Query Tools
| Tool | Purpose | Input | Output |
|------|---------|-------|--------|
| [query_validate](#query_validate) | Validate complete query | Query dict | Validation result |
| [query_describe](#query_describe) | Explain in English | Query dict | Text explanation |
| [query_execute](#query_execute) | Execute Jaquel query | Query dict | Query results |
| [query_get_operator_docs](#query_get_operator_docs) | Get operator docs | Operator name | Documentation |
| [query_get_pattern](#query_get_pattern) | Get pattern template | Pattern name | Pattern object |
| [query_list_patterns](#query_list_patterns) | List all patterns | None | List of patterns |
| [query_generate_skeleton](#query_generate_skeleton) | Create query skeleton | Entity name, operation | Query skeleton |

### Timeseries/Submatrix Data Access Tools
| Tool | Purpose | Input | Output |
|------|---------|-------|--------|
| [data_get_quantities](#data_get_quantities) | List measurement quantities | Submatrix ID | Quantity list |
| [data_read_submatrix](#data_read_submatrix) | Read timeseries data | Submatrix ID, patterns | DataFrame data |
| [data_generate_fetcher_script](#data_generate_fetcher_script) | Generate Python fetcher scripts | Submatrix ID, script type | Python script |

### Notebook & Visualization Tools
| Tool | Purpose | Input | Output |
|------|---------|-------|--------|
| [plot_comparison_notebook](#plot_comparison_notebook) | Generate Jupyter notebook | Query, quantities, ODS credentials | Notebook or .ipynb file |
| [plot_generate_code](#plot_generate_code) | Generate matplotlib code | Quantities, count, plot type | Python code string |

---

## Tool Reference

### query_validate

**Purpose**: Validate a complete Jaquel query structure.

**Input**:
```json
{
    "query": {
        "EntityName": {...},
        "$attributes": {...}
    }
}
```

**Output**:
```json
{
    "valid": true,
    "errors": [],
    "warnings": [],
    "suggestions": []
}
```

**Checks**:
- ✓ Entity name exists and is non-$key
- ✓ Entity query value is dict, int, or string
- ✓ Special keys ($attributes, $orderby, etc.) are valid
- ✓ $attributes is a dictionary
- ✓ $orderby and $groupby are dictionaries
- ✓ $rowlimit and $rowskip are integers

**Example**:
```python
query = {
    "AoMeasurement": {"name": "Test"},
    "$attributes": {"id": 1, "name": 1},
    "$options": {"$rowlimit": 10}
}
result = JaquelValidator.query_validate(query)
# Returns: {"valid": true, "errors": [], ...}
```

---

### query_get_operator_docs

**Purpose**: Get detailed documentation for a Jaquel operator.

**Input**:
```json
{
    "operator": "$eq"
}
```

**Output**:
```json
{
    "category": "comparison",
    "description": "Equal comparison",
    "example": "{\"name\": {\"$eq\": \"MyTest\"}}",
    "options": "Use $options: 'i' for case-insensitive"
}
```

**Supported Operators**:
- Comparison: $eq, $neq, $lt, $gt, $lte, $gte, $in, $like, $between, $null, $notnull
- Logical: $and, $or, $not
- Aggregates: $distinct, $min, $max

**Example**:
```python
doc = JaquelValidator.get_operator_info("$like")
# Returns:
# {
#   "category": "comparison",
#   "description": "Wildcard match (* and ?)",
#   "example": '{"name": {"$like": "Test*"}}',
#   "options": "Use $options: 'i' for case-insensitive"
# }
```

---

### query_get_pattern

**Purpose**: Get a template for a common query pattern.

**Input**:
```json
{
    "pattern": "case_insensitive_search"
}
```

**Output**:
```json
{
    "template": "{\n    \"EntityName\": {\n        \"name\": {\n            \"$like\": \"Search*\",\n            \"$options\": \"i\"\n        }\n    }\n}",
    "description": "Case-insensitive wildcard search",
    "explanation": "$like uses * and ? wildcards. $options: 'i' = case-insensitive"
}
```

**Available Patterns**:
- `get_all_instances` - Get all entities
- `get_by_id` - Get by ID shorthand
- `get_by_name` - Get by name filter
- `case_insensitive_search` - Wildcard search
- `time_range` - Date/time range query
- `inner_join` - Join with related entities
- `outer_join` - Outer join for sparse data
- `aggregates` - Aggregate functions

**Example**:
```python
pattern = JaquelExamples.get_pattern("time_range")
print(pattern["template"])
```

---

### query_list_patterns

**Purpose**: List all available query patterns.

**Input**: None (empty object)

**Output**:
```json
{
    "available_patterns": [
        "get_all_instances",
        "get_by_id",
        "get_by_name",
        "case_insensitive_search",
        "time_range",
        "inner_join",
        "outer_join",
        "aggregates"
    ],
    "description": "Use query_get_pattern tool with one of these names"
}
```

**Example**:
```python
patterns = JaquelExamples.list_patterns()
# Returns list of available pattern names
```

---

### query_generate_skeleton

**Purpose**: Generate a query skeleton for an entity.

**Input**:
```json
{
    "entity_name": "AoMeasurement",
    "operation": "search_and_select"
}
```

**Output**:
```json
{
    "AoMeasurement": {"name": {"$like": "Search*"}},
    "$attributes": {"id": 1, "name": 1, "description": 1},
    "$orderby": {"name": 1},
    "$options": {"$rowlimit": 10}
}
```

**Available Operations**:
- `get_all` - Get all instances (simple)
- `get_by_id` - Query by ID
- `get_by_name` - Query by name
- `search_and_select` - Search with specific attributes

**Example**:
```python
skeleton = JaquelExamples.query_generate_skeleton(
    "AoMeasurement",
    "search_and_select"
)
```

---

### query_describe

**Purpose**: Explain what a query does in plain English.

**Input**:
```json
{
    "query": {
        "AoMeasurement": {"name": "Profile_62"},
        "$attributes": {"id": 1, "name": 1},
        "$orderby": {"name": 1},
        "$options": {"$rowlimit": 10}
    }
}
```

**Output**:
```
Query for entity: AoMeasurement

Filter conditions:
  - name: Profile_62

Attributes to retrieve:
  - id
  - name

Query options:
  - Limit results to 10 rows

Ordering:
  - name: ascending
```

**Example**:
```python
query = {...}
explanation = JaquelExplain.query_describe(query)
print(explanation)
```

---


### schema_get_entity

**Purpose**: Get available fields for an entity from the ODS model schema.

**Input**:
```json
{
    "entity_name": "AoMeasurement"
}
```

**Output**:
```json
{
    "entity_name": "AoMeasurement",
    "fields": [
        {
            "name": "id",
            "type": "integer",
            "description": "Unique identifier"
        },
        {
            "name": "name",
            "type": "string",
            "description": "Measurement name"
        },
        {
            "name": "description",
            "type": "string",
            "description": "Measurement description"
        }
    ],
    "field_count": 3
}
```

**Requirements**: Active ODS server connection.

**Example**:
```python
schema = schema_get_entity("AoMeasurement")
print(f"Entity has {schema['field_count']} fields")
for field in schema['fields']:
    print(f"- {field['name']}: {field['type']}")
```

---

### schema_field_exists

**Purpose**: Check if a field exists in an entity's schema.

**Input**:
```json
{
    "entity_name": "AoMeasurement",
    "field_name": "measurement_begin"
}
```

**Output**:
```json
{
    "entity_name": "AoMeasurement",
    "field_name": "measurement_begin",
    "exists": true,
    "field_info": {
        "type": "datetime",
        "description": "Start time of measurement"
    }
}
```

**Requirements**: Active ODS server connection.

**Example**:
```python
result = schema_field_exists("AoMeasurement", "measurement_begin")
if result["exists"]:
    print(f"Field exists: {result['field_info']['type']}")
else:
    print("Field does not exist")
```

---

### ods_connect

**Purpose**: Establish connection to ASAM ODS server for live model inspection and data access.

**Input**:
```json
{
    "url": "http://localhost:8087/api",
    "username": "sa",
    "password": "sa"
}
```

**Output**:
```json
{
    "message": "Connected to ODS server",
    "connection": {
        "url": "http://localhost:8087/api",
        "username": "sa",
        "con_i_url": "http://localhost:8087/api/con_i/12345"
    }
}
```

**Requirements**: Valid ODS server URL and credentials.

---

### ods_connect_using_env

**Purpose**: Establish connection to ASAM ODS server using environment variables.

Supports three authentication modes controlled by `{PREFIX}_MODE` (default: `basic`). The default prefix is `ODSBOX_MCP`; all variables also fall back to the `ODS_` legacy prefix.

You can override the prefix using either:
- tool argument: `env_prefix`
- environment variable: `ODSBOX_MCP_ENV_PREFIX`

#### Mode: basic (default)

| Variable | Required | Description |
|---|---|---|
| `{PREFIX}_URL` / `{PREFIX}_API_URL` | Yes | ODS server API URL |
| `{PREFIX}_USERNAME` / `{PREFIX}_USER` | Yes | Username |
| `{PREFIX}_PASSWORD` / `{PREFIX}_PWD` | Yes* | Password |
| `{PREFIX}_VERIFY` | No | TLS verification (`true`/`false`, default `true`) |

#### Mode: m2m (machine-to-machine)

Set `{PREFIX}_MODE=m2m`.

| Variable | Required | Description |
|---|---|---|
| `{PREFIX}_URL` | Yes | ODS server API URL |
| `{PREFIX}_M2M_TOKEN_ENDPOINT` | Yes | OAuth2 token endpoint URL |
| `{PREFIX}_M2M_CLIENT_ID` | Yes | Client ID |
| `{PREFIX}_M2M_CLIENT_SECRET` | Yes* | Client secret |
| `{PREFIX}_M2M_SCOPE` | No | Comma-separated scopes |
| `{PREFIX}_VERIFY` | No | TLS verification |

#### Mode: oidc (interactive browser login)

Set `{PREFIX}_MODE=oidc`.

| Variable | Required | Description |
|---|---|---|
| `{PREFIX}_URL` | Yes | ODS server API URL |
| `{PREFIX}_OIDC_CLIENT_ID` | Yes | Client ID |
| `{PREFIX}_OIDC_REDIRECT_URI` | Yes | Redirect URI (e.g., `http://127.0.0.1:1234`) |
| `{PREFIX}_OIDC_CLIENT_SECRET` | No | Client secret (not needed for public clients) |
| `{PREFIX}_OIDC_AUTHORIZATION_ENDPOINT` | No | Explicit authorization URL (skips WebFinger) |
| `{PREFIX}_OIDC_TOKEN_ENDPOINT` | No | Explicit token URL (skips WebFinger) |
| `{PREFIX}_OIDC_WEBFINGER_PATH_PREFIX` | No | WebFinger path prefix |
| `{PREFIX}_OIDC_REDIRECT_INSECURE` | No | Allow HTTP redirect (`true`/`false`) |
| `{PREFIX}_OIDC_LOGIN_TIMEOUT` | No | Browser login timeout in seconds (default `60`) |
| `{PREFIX}_OIDC_SCOPE` | No | Comma-separated scopes |
| `{PREFIX}_VERIFY` | No | TLS verification |

> **Keyring fallback**: Secrets marked with \* fall back to the system keyring when the env var is absent.
> Store secrets with `keyring set '<service>' '<username>'`:
> - Basic: `keyring set '<URL>' '<username>'`
> - M2M: `keyring set '<token_endpoint>' '<client_id>'`
> - OIDC: `keyring set '<URL>' '<client_id>'` (optional for public clients)

**Input**:
```json
{}
```

**Output**:
```json
{
    "message": "Connected to ODS server",
    "connection": {
        "url": "http://localhost:8087/api",
        "username": "sa",
        "con_i_url": "http://localhost:8087/api/ods/12345"
    }
}
```

**Requirements**: Environment variables must be set for connection information.

---

### ods_disconnect

**Purpose**: Close connection to ODS server.

**Input**:
```json
{}
```

**Output**:
```json
{
    "message": "Disconnected from ODS server"
}
```

---

### ods_get_connection_info

**Purpose**: Get current ODS connection information.

**Input**:
```json
{}
```

**Output**:
```json
{
    "url": "http://localhost:8087/api",
    "username": "sa",
    "con_i_url": "http://localhost:8087/api/con_i/12345",
    "status": "connected"
}
```

---

### schema_list_entities

**Purpose**: Return a list of existing entities from the ODS server ModelCache with their relationships.

**Input**:
```json
{}
```

**Output**:
```json
{
    "entities": [
        {
            "name": "AoUnit",
            "basename": "AoUnit",
            "description": "Represents information about a specific physical unit (e.g., Newton, Kelvin).",
            "related_entities": [
                {
                    "name": "AoQuantity",
                    "relationship": "1:n",
                    "relation_name": "quantity"
                }
            ]
        }
    ],
    "count": 1
}
```

**Requirements**: Must be connected to ODS server first using `ods_connect`.

**Entity Information**:
- `name`: Entity name
- `basename`: Base entity name
- `description`: Human-readable description
- `related_entities`: Array of related entities with relationship types (1:n, n:1, n:m)

---

### schema_test_to_measurement_hierarchy

**Purpose**: Get the hierarchical entity chain from AoTest to AoMeasurement via the 'children' relation.

This is the main ASAM ODS hierarchy for accessing test data:
- **Root**: AoTest (test campaign or program)
- **Intermediate**: AoSubTest (optional, may appear multiple times)
- **Leaf**: AoMeasurement (individual measurement/test case)

**Input**:
```json
{}
```

**Output**:
```json
{
    "hierarchy_chain": [
        {
            "name": "Test",
            "base_name": "AoTest",
            "parent_relation": null,
            "description": "The root entity of the test hierarchy representing test campaigns or programs..."
        },
        {
            "name": "SubTest",
            "base_name": "AoSubTest",
            "parent_relation": "parent_test",
            "description": "An intermediate level in the test hierarchy that enables the organization of complex test scenarios..."
        },
        {
            "name": "Measurement",
            "base_name": "AoMeasurement",
            "parent_relation": "test",
            "description": "The primary container for a complete measurement or test case..."
        }
    ],
    "depth": 3,
    "note": "This is the main AoTest to AoMeasurement hierarchy in this ASAM ODS server"
}
```

**Requirements**: Must be connected to ODS server first using `ods_connect`.

**Usage**:
Use this tool to understand the entity hierarchy for building Jaquel queries that navigate from tests down to measurements. This helps LLMs and users understand the proper entity traversal path.

**Example Query Pattern**:
After getting this hierarchy, you can build queries like:
```python
# Navigate from AoTest through hierarchy to AoMeasurement
query = {
    "AoMeasurement": {
        "name": "MyMeas1",
        "test": {
            "name": "SubTest1",
            "parent_test": {
                "name" : "MyProject1"
            }
        }
    }
}
```

---

### query_execute

**Purpose**: Execute a Jaquel query directly on connected ODS server.

**Input**:
```json
{
    "query": {
        "AoUnit": {},
        "$attributes": {"id": 1, "name": 1}
    }
}
```

**Output**:
```json
{
    "result": "<DataFrame>"
}
```

**Note**: Returns DataFrame object (may not be serializable in JSON response).

---

### data_get_quantities

**Purpose**: Get available measurement quantities for a submatrix.

**Input**:
```json
{
    "submatrix_id": 123
}
```

**Output**:
```json
{
    "submatrix_id": 123,
    "measurement_quantities": [
        {
            "id": 456,
            "name": "Time",
            "measurement_quantity": "Time",
            "unit": "s",
            "sequence_representation": 1,
            "independent": true
        },
        {
            "id": 457,
            "name": "Temperature",
            "measurement_quantity": "Temperature",
            "unit": "°C",
            "sequence_representation": 1,
            "independent": false
        }
    ],
    "count": 2
}
```

**Requirements**: Active ODS server connection.

---

### data_read_submatrix

**Purpose**: Read timeseries data from a submatrix using bulk data access.

**Input**:
```json
{
    "submatrix_id": 123,
    "measurement_quantity_patterns": ["Time", "Temp*"],
    "case_insensitive": false,
    "date_as_timestamp": true,
    "set_independent_as_index": true
}
```

**Output**:
```json
{
    "submatrix_id": 123,
    "columns": ["Time", "Temperature", "Pressure"],
    "row_count": 1000,
    "data_preview": [
        {"Time": 0.0, "Temperature": 25.0, "Pressure": 1013.25},
        {"Time": 0.1, "Temperature": 25.1, "Pressure": 1013.20}
    ],
    "note": "Full DataFrame returned (may be large)"
}
```

**Requirements**: Active ODS server connection.

---

### data_generate_fetcher_script

**Purpose**: Generate Python script examples for fetching submatrix data with proper error handling and data processing.

**Input**:
```json
{
    "submatrix_id": 123,
    "script_type": "basic",
    "measurement_quantity_patterns": ["Time", "Temp*"],
    "output_format": "csv",
    "include_visualization": false,
    "include_analysis": false
}
```

**Output**:
```json
{
    "submatrix_id": 123,
    "script_type": "basic",
    "output_format": "csv",
    "measurement_quantities": ["Time", "Temperature"],
    "script": "#!/usr/bin/env python3\\n... (complete Python script)",
    "instructions": "Copy the script above into a Python file and run it. Make sure to install required packages: pip install odsbox pandas matplotlib seaborn"
}
```

**Script Types**:
- `"basic"`: Simple data fetching script
- `"advanced"`: Full-featured script with logging, error handling, and data validation
- `"batch"`: Script for processing multiple submatrices in parallel
- `"analysis"`: Script with comprehensive data analysis and visualization

**Parameters**:
- `script_type`: Type of script to generate (required)
- `measurement_quantity_patterns`: Column patterns to include (optional, auto-detected if not provided)
- `output_format`: Data output format - "csv", "json", "parquet", "excel", or "dataframe"
- `include_visualization`: Include matplotlib/seaborn plotting code
- `include_analysis`: Include basic statistical analysis

**Requirements**: Active ODS server connection.

**Example Generated Script** (basic type):
```python
#!/usr/bin/env python3
"""
Basic Submatrix Data Fetcher
Fetches data from submatrix 123
"""

import pandas as pd
from odsbox import ConI

def main():

    try:
    # Connect to ODS server
        with ConI(url="http://localhost:8087/api",  # Update with your ODS server URL
            auth=("your_username", "your_password")) as con_i:

            # Fetch data from submatrix
            df = con_i.bulk.data_read(
                submatrix_iid=123,
                column_patterns=["Time", "Temp*"],
                date_as_timestamp=True,
                set_independent_as_index=True
            )

        print(f"Loaded data with shape: {{df.shape}}")
        print(f"Columns: {{list(df.columns)}}")
        print("\\nFirst 5 rows:")
        print(df.head())

        # Save to file
        df.to_csv("submatrix_123_data.csv", index=True)
        print("\\nData saved successfully!")

    except Exception as e:
        print(f"Error fetching data: {{e}}")

if __name__ == "__main__":
    main()
```

---

## Common Use Cases

### Validate User Query

```python
# User provides a query, validate it
user_query = {
    "AoMeasurement": {
        "name": {"$like": "Test*"}
    },
    "$attributes": {"id": 1, "name": 1},
    "$options": {"$rowlimit": 50}
}

result = JaquelValidator.query_validate(user_query)
if result["valid"]:
    print("Query is valid!")
else:
    print("Errors:", result["errors"])
```

### Learn Operator Usage

```python
# User wants to know how to use an operator
doc = JaquelValidator.get_operator_info("$between")
print(f"Description: {doc['description']}")
print(f"Example: {doc['example']}")
```

### Generate Query from Scratch

```python
# Generate template, then customize it
skeleton = JaquelExamples.query_generate_skeleton(
    "AoMeasurement",
    "search_and_select"
)

# Modify skeleton as needed
skeleton["AoMeasurement"]["name"] = {"$like": "Profile*"}
skeleton["$options"]["$rowlimit"] = 5

# Validate
result = JaquelValidator.query_validate(skeleton)
```

---

## Query Examples

### Simple ID Lookup

```json
{
    "AoMeasurement": 4711
}
```

### Name Search

```json
{
    "AoMeasurement": {
        "name": {"$like": "Profile*", "$options": "i"}
    },
    "$attributes": {"id": 1, "name": 1},
    "$options": {"$rowlimit": 10}
}
```

### Time Range Query

```json
{
    "AoMeasurement": {
        "measurement_begin": {
            "$between": ["2023-01-01T00:00:00Z", "2023-12-31T23:59:59Z"]
        }
    },
    "$attributes": {"id": 1, "name": 1, "measurement_begin": 1}
}
```

### Multiple Conditions

```json
{
    "AoMeasurement": {
        "$and": [
            {"status": "active"},
            {"measurement_begin": {"$gte": "2023-01-01T00:00:00Z"}},
            {"measurement_end": {"$lte": "2023-12-31T23:59:59Z"}}
        ]
    },
    "$attributes": {"id": 1, "name": 1},
    "$orderby": {"measurement_begin": 0}
}
```

### Inner Join

```json
{
    "AoMeasurementQuantity": {},
    "$attributes": {
        "name": 1,
        "unit.name": 1,
        "quantity.name": 1
    },
    "$options": {"$rowlimit": 5}
}
```

### Outer Join

```json
{
    "AoMeasurementQuantity": {},
    "$attributes": {
        "name": 1,
        "unit:OUTER.name": 1,
        "quantity:OUTER.name": 1
    }
}
```

### Aggregates

```json
{
    "AoUnit": {},
    "$attributes": {
        "factor": {"$min": 1, "$max": 1, "$avg": 1},
        "description": {"$distinct": 1, "$dcount": 1}
    }
}
```

---

## Operator Reference

### Comparison Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `$eq` | Equal | `{"name": {"$eq": "Test"}}` |
| `$neq` | Not equal | `{"status": {"$neq": "inactive"}}` |
| `$lt` | Less than | `{"value": {"$lt": 100}}` |
| `$gt` | Greater than | `{"value": {"$gt": 0}}` |
| `$lte` | Less or equal | `{"value": {"$lte": 100}}` |
| `$gte` | Greater or equal | `{"value": {"$gte": 0}}` |
| `$in` | In array | `{"id": {"$in": [1, 2, 3]}}` |
| `$like` | Wildcard match | `{"name": {"$like": "Test*"}}` |
| `$between` | Between values | `{"date": {"$between": [..., ...]}}` |
| `$null` | Is null | `{"field": {"$null": 1}}` |
| `$notnull` | Not null | `{"field": {"$notnull": 1}}` |

### Logical Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `$and` | Logical AND | `{"$and": [{...}, {...}]}` |
| `$or` | Logical OR | `{"$or": [{...}, {...}]}` |
| `$not` | Logical NOT | `{"$not": {...}}` |

### Aggregate Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `$min` | Minimum value | `{"field": {"$min": 1}}` |
| `$max` | Maximum value | `{"field": {"$max": 1}}` |
| `$avg` | Average value | `{"field": {"$avg": 1}}` |
| `$count` | Count rows | `{"field": {"$count": 1}}` |
| `$dcount` | Distinct count | `{"field": {"$dcount": 1}}` |
| `$distinct` | Unique values | `{"field": {"$distinct": 1}}` |
| `$sum` | Sum values | `{"field": {"$sum": 1}}` |
| `$stddev` | Standard deviation | `{"field": {"$stddev": 1}}` |

### Special Options

| Key | Description | Example |
|-----|-------------|---------|
| `$attributes` | Select attributes | `{"$attributes": {"id": 1}}` |
| `$orderby` | Sort results | `{"$orderby": {"name": 1}}` |
| `$groupby` | Group results | `{"$groupby": {"id": 1}}` |
| `$options` | Query options | `{"$options": {"$rowlimit": 10}}` |
| `$unit` | Specify unit | `{"$unit": 123}` |

---

## Tips & Best Practices

### Always Validate Before Using

```python
result = JaquelValidator.query_validate(query)
if not result["valid"]:
    raise ValueError(result["errors"])
```

### Use Patterns as Starting Points

```python
# Start with a pattern, then customize
pattern = JaquelExamples.get_pattern("time_range")
query = json.loads(pattern["template"])
# Modify as needed
```

### Use Case-Insensitive for User Searches

```python
# Bad: Case-sensitive, might miss data
{"name": "TestProfile"}

# Good: Case-insensitive with wildcard
{"name": {"$like": "Test*", "$options": "i"}}
```

### Set Row Limits for Large Queries

```python
# Good: Prevents large result sets
"$options": {"$rowlimit": 1000}

# Better: Combine with paging
"$options": {"$rowlimit": 1000, "$rowskip": 0}
```

### Use Inner Joins for Required Data

```python
# Inner join - related data must exist
"unit.name": 1

# Outer join - handles missing related data
"unit:OUTER.name": 1
```

### Simplify Verbose Queries

```python
# Verbose
{"AoUnit": {"id": {"$eq": 123}}}

# Simplified
{"AoUnit": 123}
```

### Document Complex Conditions

```python
# Use query_describe to understand queries
explanation = JaquelExplain.query_describe(complex_query)
print(explanation)  # Share with team for clarity
```

### Test Operators Before Using

```python
# Verify operator syntax
info = JaquelValidator.get_operator_info("$like")
print(info["example"])  # See correct usage
```

### Use Explicit $and for Complex Logic

```python
# Better for readability
"$and": [
    {"status": "active"},
    {"value": {"$gte": 100}},
    {"date": {"$gt": "2023-01-01"}}
]

# Instead of nested conditions
```

---

## Error Handling

### Common Validation Errors

```python
# Missing entity name
{
    "$attributes": {"id": 1}
}
# Error: "Query must contain an entity name (non-$ key)"

# Invalid $rowlimit
{
    "AoUnit": {},
    "$options": {"$rowlimit": "10"}
}
# Error: "$rowlimit must be an integer"

# Unknown operator
{
    "name": {"$invalid": "value"}
}
# Error: "Unknown operator: $invalid"
```

### Debugging Tips

1. **Use query_validate** to find syntax errors
2. **Use query_describe** to understand complex queries
3. **Use query_get_operator_docs** to verify operator syntax

---

## Notebook & Visualization Tools (NEW)

### plot_comparison_notebook

**Purpose**: Generate a complete Jupyter notebook for comparing measurements with automatic data retrieval, preparation, and visualization.

**Input**:
```json
{
    "measurement_query_conditions": {
        "Name": {"$like": "Profile_*"},
        "TestStep.Test.Name": {"$in": ["Campaign_03", "Campaign_04"]}
    },
    "measurement_quantity_names": ["Motor_speed", "Torque"],
    "ods_url": "https://ods.example.com/api",
    "ods_username": "user",
    "ods_password": "password",
    "available_quantities": ["Motor_speed", "Torque", "Temperature", "Coolant"],
    "plot_type": "scatter",
    "title": "Motor Performance Comparison",
    "output_path": "/path/to/notebook.ipynb"
}
```

**Output**:
```json
{
    "title": "Motor Performance Comparison",
    "plot_type": "scatter",
    "measurement_quantities": ["Motor_speed", "Torque"],
    "num_cells": 9,
    "status": "Notebook generated successfully",
    "saved_to": "/path/to/notebook.ipynb"
}
```

**Features**:
- ✓ Query definition cell with ODS credentials
- ✓ Data retrieval code using odsbox library
- ✓ Automatic data preparation with helper functions
- ✓ Matplotlib visualization code
- ✓ Configurable plot types: scatter, line, or subplots
- ✓ Unit extraction and label formatting
- ✓ Optional file output

**Plot Types**:
- `scatter` - 2D scatter plots with independent column as color mapping
- `line` - Multi-line time series plots
- `subplots` - Separate subplots for each quantity

**Example Generated Notebook Structure**:
1. Title and description
2. Available quantities documentation
3. Query definition cell
4. ODS data retrieval code
5. Data preparation with helper functions
6. Visualization code

---

### plot_generate_code

**Purpose**: Generate standalone matplotlib plotting code for measurement visualization.

**Input**:
```json
{
    "measurement_quantity_names": ["Speed", "Torque", "Temperature"],
    "submatrices_count": 6,
    "plot_type": "line"
}
```

**Output**:
```json
{
    "plot_type": "line",
    "measurement_quantities": ["Speed", "Torque", "Temperature"],
    "submatrices_count": 6,
    "code": "import matplotlib.pyplot as plt\n...",
    "description": "Generated line plot code for 3 quantities and 6 submatrices"
}
```

**Plot Types**:

**Scatter Plot** (requires 2+ quantities):
- 2D scatter plots
- Color mapping by independent column (e.g., time)
- Configurable subplot layout (default: 3 per row)
- Automatic axis labeling

**Line Plot** (any number of quantities):
- Multiple line series per plot
- Legend, grid, and marker styling
- Configurable subplot layout
- Good for time series data

**Subplots Per Measurement**:
- One subplot row per quantity
- Multiple columns for each measurement
- Best for detailed quantity-by-measurement analysis

**Example**:
```python
code = plot_generate_code(
    measurement_quantity_names=["Speed", "Torque"],
    submatrices_count=9,
    plot_type="scatter"
)
# Returns executable matplotlib code
```

---

## Integration Examples

### With Python odsbox Library

```python
from odsbox import ConI
from odsbox_jaquel_mcp import JaquelValidator

# Build and validate query
query = {
    "AoMeasurement": {"name": "Profile_62"},
    "$attributes": {"id": 1, "name": 1}
}

result = JaquelValidator.query_validate(query)
if result["valid"]:
    # Use with odsbox
    with ConI(...) as con_i:
        data = con_i.query(query)
```

### With AI Assistants (Claude)

```
User: "Help me create a query for all measurements in 2023"

Assistant uses tools:
1. query_list_patterns() → Shows available patterns
2. query_get_pattern("time_range") → Gets time range template
3. query_generate_skeleton("AoMeasurement", "get_all") → Creates skeleton
4. query_describe() → Explains the result
```

---

## AI Guidance Tools

### help_bulk_api

**Purpose**: Get contextual help on bulk API usage for loading timeseries data efficiently. This tool provides step-by-step guidance for AI models learning to use the bulk data access system.

**Input**:
```json
{
    "topic": "3-step-rule",
    "tool": "data_read_submatrix"
}
```

**Output**:
```json
{
    "topic": "3-step-rule",
    "help_text": "The bulk API follows a 3-step workflow:\n\n1. CONNECT: Establish ODS connection with ods_connect\n   - URL: ODS server API endpoint\n   - Credentials: username/password for authentication\n\n2. DISCOVER: Find submatrix IDs and quantities\n   - List measurements with query_execute\n   - Get quantities with data_get_quantities\n\n3. LOAD: Read timeseries data efficiently\n   - Use data_read_submatrix for bulk data access\n   - Specify column patterns for filtering\n   - Get DataFrame with all rows instantly\n\nKey Benefits:\n- No pagination loops needed - all data loaded at once\n- Column filtering reduces memory usage\n- Pattern matching for flexible column selection\n- Automatic format conversion (dates, etc.)",
    "examples_count": 3,
    "related_tools": ["ods_connect", "data_get_quantities", "data_read_submatrix"]
}
```

**Available Topics**:

1. **3-step-rule** - Core workflow: CONNECT → DISCOVER → LOAD
   - Explains fundamental pattern
   - Shows when to use each step
   - Includes decision points

2. **quick-start** - Getting started guide
   - Import statements
   - Connection code
   - Discovery code
   - Data loading code

3. **bulk-vs-jaquel** - When to use bulk API vs Jaquel queries
   - Bulk: Fast for known measurements, loads all data at once
   - Jaquel: For discovery, filtering, complex queries
   - Decision tree for tool selection

4. **patterns** - Column matching patterns
   - Wildcard patterns: `"Time*"`, `"*Temp*"`, `"*Speed"`
   - Exact match: `"Temperature"`
   - Multiple patterns: `["Time", "Motor_*", "*Pressure"]`
   - Case sensitivity options

5. **decision-tree** - How to choose the right approach
   - "I know measurement IDs" → Use bulk API
   - "I need to search" → Use Jaquel query first
   - "I want timeseries data" → Bulk API after discovery
   - "I need to filter" → Combine Jaquel query + bulk

6. **mistakes** - Top AI mistakes and fixes
   - Trying to query metadata with bulk API
   - Forgetting to connect first
   - Using wrong column names
   - Not using pattern matching for flexibility

7. **step-by-step** - Detailed step-by-step workflow walkthrough
   - Full annotated walkthrough of the 3-step process
   - Includes intermediate results at each step

8. **response-template** - Template for structuring AI responses
   - Structured response format for bulk API interactions
   - How to present results to users

9. **troubleshooting** - Common errors and recovery
   - "Submatrix not found" - Check measurement IDs
   - "No quantities available" - Verify connected and ID is valid
   - "Pattern matches nothing" - Review available quantity names
   - Timeout issues and workarounds

10. **tool-patterns** - Tool-specific usage patterns
    - When to use MCP tools vs direct library
    - Integration patterns
    - Trade-offs and benefits

11. **all** - Returns all help topics combined

**Parameters**:

- `topic` (required): Help topic to retrieve. One of:
  - `"3-step-rule"` - Core workflow
  - `"quick-start"` - Getting started
  - `"bulk-vs-jaquel"` - Tool selection
  - `"patterns"` - Column patterns
  - `"decision-tree"` - Decision making
  - `"mistakes"` - Error avoidance
  - `"step-by-step"` - Detailed walkthrough
  - `"response-template"` - Response formatting
  - `"troubleshooting"` - Error recovery
  - `"tool-patterns"` - Tool usage patterns
  - `"all"` - All topics combined

- `tool` (optional): Get contextual help for a specific tool:
  - `"ods_connect"` - Connection help
  - `"data_get_quantities"` - Discovery help
  - `"data_read_submatrix"` - Data loading help
  - `"data_generate_fetcher_script"` - Script generation help
  - `"plot_comparison_notebook"` - Notebook generation help

**Examples**:

### Get fundamental workflow:
```python
result = help_bulk_api(topic="3-step-rule")
print(result["help_text"])
# Returns: CONNECT → DISCOVER → LOAD workflow with benefits
```

### Get contextual help for specific tool:
```python
result = help_bulk_api(
    topic="quick-start",
    tool="data_read_submatrix"
)
# Returns: Quick start guide with data loading focus
```

### Decide between tools:
```python
result = help_bulk_api(topic="decision-tree")
# Returns: Decision tree for tool selection
```

### Learn error recovery:
```python
result = help_bulk_api(topic="troubleshooting")
# Returns: Common errors and how to fix them
```

**Use Cases**:

1. **AI Learning**: When AI model encounters bulk API for first time
   - Call: `help_bulk_api(topic="3-step-rule")`
   - Then: Follow the 3-step pattern

2. **Tool Selection**: Unsure whether to use bulk or Jaquel
   - Call: `help_bulk_api(topic="decision-tree")`
   - Then: Choose appropriate approach

3. **Error Recovery**: Data loading failed
   - Call: `help_bulk_api(topic="troubleshooting")`
   - Then: Apply suggested fix

4. **Pattern Matching**: Unsure about column selection
   - Call: `help_bulk_api(topic="patterns")`
   - Then: Use correct pattern syntax

5. **Step-by-Step**: Need detailed guidance
   - Call: `help_bulk_api(topic="step-by-step")`
   - Then: Follow annotated walkthrough

---

## Additional Resources

- [Jaquel Documentation](https://peak-solution.github.io/odsbox/jaquel.html)
- [Jaquel Examples](https://peak-solution.github.io/odsbox/jaquel_examples.html)
- [ODSBox GitHub](https://github.com/peak-solution/odsbox)
- [ASAM ODS Standard](https://www.asam.net/)

---

**Last Updated**: December 2025
