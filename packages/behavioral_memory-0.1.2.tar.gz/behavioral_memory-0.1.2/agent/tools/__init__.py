"""Agent-specific tool wrappers."""
