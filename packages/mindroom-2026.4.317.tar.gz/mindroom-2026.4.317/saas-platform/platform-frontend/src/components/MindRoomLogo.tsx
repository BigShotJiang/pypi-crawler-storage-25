import Image from 'next/image'

interface MindRoomLogoProps {
  className?: string
  size?: number
}

export function MindRoomLogo({ className = '', size = 32 }: MindRoomLogoProps) {
  return (
    <Image
      src="/logo.png"
      alt="MindRoom logo"
      width={size}
      height={size}
      className={className}
    />
  )
}
