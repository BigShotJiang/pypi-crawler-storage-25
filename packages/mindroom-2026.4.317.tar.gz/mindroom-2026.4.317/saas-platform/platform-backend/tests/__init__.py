"""Platform backend tests."""
