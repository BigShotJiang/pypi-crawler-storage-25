"""Thin wrapper distribution for the DefectDojo CLI."""

__version__ = '2.56.4.post1'
