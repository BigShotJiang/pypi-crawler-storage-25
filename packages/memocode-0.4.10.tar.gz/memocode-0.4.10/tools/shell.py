"""
Built-in tool: shell_exec
Executes a shell command and returns stdout/stderr.

Output is written to a temp file. The process runs detached (new session).
- If the command finishes within `timeout` seconds: read file, return output normally.
- If the command is still running after `timeout`: do NOT kill it — return PID + log path.

This means long-running commands (servers, watchers) automatically become
background processes. The model never needs to decide.

Shell selection (detected once at import time):
  Unix/macOS  → system shell (shell=True)
  Windows     → WSL > PowerShell 7 (pwsh) > PowerShell 5 > cmd
"""
import os
import sys
import shutil
import subprocess
import tempfile
import threading
import time
from typing import Callable
from .registry import Tool, ToolSchema


# ---------------------------------------------------------------------------
# Shell detection (once at import time)
# ---------------------------------------------------------------------------

def _detect_shell() -> tuple[str, list[str]]:
    """
    Returns (shell_name, prefix_args).
    On Unix: ("unix", []) — uses shell=True.
    On Windows: PowerShell 7 > PowerShell 5 > cmd.
    """
    if sys.platform != "win32":
        return "unix", []
    if shutil.which("pwsh"):
        return "pwsh", ["pwsh", "-NoProfile", "-NonInteractive", "-Command"]
    if shutil.which("powershell"):
        return "powershell", ["powershell", "-NoProfile", "-NonInteractive", "-Command"]
    return "cmd", []


_SHELL_TYPE, _SHELL_PREFIX = _detect_shell()


def _wrap_command(command: str) -> tuple[str | list, bool]:
    """
    Returns (args, use_shell) for subprocess.Popen.
    PowerShell: prepend UTF-8 encoding setup so output is always readable.
    """
    if _SHELL_TYPE == "unix" or _SHELL_TYPE == "cmd":
        return command, True
    if _SHELL_TYPE in ("pwsh", "powershell"):
        # Force UTF-8: PowerShell console + Python subprocess output
        utf8_prefix = (
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
            "$env:PYTHONUTF8 = '1'; "
        )
        return _SHELL_PREFIX + [utf8_prefix + command], False
    return _SHELL_PREFIX + [command], False  # unreachable on current platforms


def _popen_session_kwargs() -> dict:
    """Platform-appropriate process isolation flags."""
    if sys.platform == "win32":
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def _bg_hint(pid: int, log_path: str) -> str:
    """Return platform-appropriate background process info."""
    if sys.platform == "win32":
        tail = f"Get-Content -Wait '{log_path}'" if _SHELL_TYPE in ("pwsh", "powershell") else ""
        stop = f"Stop-Process -Id {pid}" if _SHELL_TYPE in ("pwsh", "powershell") else f"taskkill /PID {pid} /F"
        lines = [f"[background] PID={pid}", f"log:  {log_path}"]
        if tail:
            lines.append(f"tail: {tail}")
        lines.append(f"stop: {stop}")
        return "\n".join(lines)
    return (
        f"[background] PID={pid}\n"
        f"log:  {log_path}\n"
        f"tail: tail -f {log_path}\n"
        f"stop: kill {pid}"
    )


# ---------------------------------------------------------------------------
# Tool implementation
# ---------------------------------------------------------------------------

def _shell_exec(
    command: str,
    cwd: str | None = None,
    timeout: int = 120,
    _line_cb: Callable[[str], None] | None = None,
) -> str:
    log_fd, log_path = tempfile.mkstemp(prefix="mcode_bg_", suffix=".log")
    os.close(log_fd)

    args, use_shell = _wrap_command(command)
    with open(log_path, "w", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            args,
            shell=use_shell,
            stdout=log_file,
            stderr=log_file,
            cwd=cwd,
            **_popen_session_kwargs(),
        )

    # Tail the log file in a thread so live output reaches the user
    _tail_stop = threading.Event()
    if _line_cb:
        def _tail():
            with open(log_path, encoding="utf-8", errors="replace") as f:
                while not _tail_stop.is_set():
                    line = f.readline()
                    if line:
                        _line_cb(line.rstrip())
                    else:
                        time.sleep(0.05)
                # Drain any remaining lines after stop signal
                for line in f:
                    _line_cb(line.rstrip())

        tail_thread = threading.Thread(target=_tail, daemon=True)
        tail_thread.start()

    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        # Still running → detach, return PID + log (do NOT kill)
        _tail_stop.set()
        return _bg_hint(proc.pid, log_path)
    except KeyboardInterrupt:
        proc.kill()
        proc.wait()
        _tail_stop.set()
        raise
    finally:
        _tail_stop.set()
        if _line_cb:
            tail_thread.join(timeout=1)

    with open(log_path, encoding="utf-8", errors="replace") as f:
        output = f.read()
    try:
        os.unlink(log_path)
    except OSError:
        pass

    if proc.returncode != 0:
        return f"[exit {proc.returncode}]\n{output}" if output else f"[exit {proc.returncode}]"
    return output or "(no output)"


# ---------------------------------------------------------------------------
# Tool description (includes shell environment for LLM awareness)
# ---------------------------------------------------------------------------

_SHELL_NOTE = {
    "unix": "",
    "pwsh": " Shell: PowerShell 7 (pwsh).",
    "powershell": " Shell: Windows PowerShell 5.",
    "cmd": " Shell: Windows cmd.exe.",
}.get(_SHELL_TYPE, "")

SHELL_TOOL = Tool(
    schema=ToolSchema(
        name="shell_exec",
        description=(
            "Execute a shell command. Returns stdout+stderr."
            + _SHELL_NOTE
            + " Commands that finish within 120s return output normally. "
            "Commands that run longer (servers, watchers) are automatically kept "
            "in the background — returns PID and log path instead of blocking.\n"
            "IMPORTANT: Do NOT add & nohup setsid or any backgrounding to the command — "
            "this tool handles it automatically. Just pass the plain command."
        ),
        parameters={
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute",
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory (optional, defaults to project work_dir)",
                },
            },
            "required": ["command"],
        },
    ),
    fn=_shell_exec,
    supports_streaming=True,
)
