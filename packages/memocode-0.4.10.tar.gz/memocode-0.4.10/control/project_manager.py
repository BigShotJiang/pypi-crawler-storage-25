"""
ProjectManager: manages project directory structure.

Layout:
  control/
  ├── core.db               ← core_memory, shared across all projects
  ├── projects.json         ← registry: current project + per-project metadata
  └── projects/
      └── <project>.db      ← one DB per project (active_session + recent_memory)

Auto-named projects follow the pattern sess-YYYYMMDD-HHMMSS.
They are automatically cleaned up after STALE_DAYS days if never renamed.
User-named projects are never auto-deleted.
"""
from __future__ import annotations
import json
import os
import re
import time

_DATA_DIR = os.path.expanduser("~/.mcode")
_PROJECTS_DIR = os.path.join(_DATA_DIR, "projects")
_CORE_DB = os.path.join(_DATA_DIR, "core.db")
_REGISTRY_FILE = os.path.join(_DATA_DIR, "projects.json")

DEFAULT_PROJECT = "default"
_AUTO_PATTERN = re.compile(r"^sess-\d{8}-\d{6}$")
STALE_DAYS = 7


def _load_registry() -> dict:
    if os.path.exists(_REGISTRY_FILE):
        with open(_REGISTRY_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {
        "current": DEFAULT_PROJECT,
        "projects": {DEFAULT_PROJECT: {"work_dir": os.getcwd(), "created_at": time.time()}},
    }


def _save_registry(reg: dict):
    with open(_REGISTRY_FILE, "w", encoding="utf-8") as f:
        json.dump(reg, f, indent=2)


def _project_db(project: str) -> str:
    return os.path.join(_PROJECTS_DIR, f"{project}.db")


class ProjectManager:
    def __init__(self):
        os.makedirs(_PROJECTS_DIR, exist_ok=True)
        self._reg = _load_registry()
        # Ensure current project exists in registry
        cur = self._reg["current"]
        if cur not in self._reg["projects"]:
            self._reg["projects"][cur] = {"work_dir": None, "created_at": time.time()}
            _save_registry(self._reg)

    # ------------------------------------------------------------------
    # Current state
    # ------------------------------------------------------------------

    @property
    def current_project(self) -> str:
        return self._reg["current"]

    @property
    def core_db_path(self) -> str:
        return _CORE_DB

    @property
    def project_db_path(self) -> str:
        return _project_db(self.current_project)

    @property
    def work_dir(self) -> str:
        """Working directory for shell commands in the current project.
        Defaults to cwd at startup if not explicitly set."""
        wd = self._reg["projects"].get(self.current_project, {}).get("work_dir")
        if wd:
            return os.path.expanduser(wd)
        return os.getcwd()

    @property
    def backup_dir(self) -> str | None:
        """Backup directory under the project's work_dir. None if work_dir not set."""
        wd = self.work_dir
        if wd:
            return os.path.join(wd, "autobackup")
        return None

    # ------------------------------------------------------------------
    # Project operations
    # ------------------------------------------------------------------

    def list_projects(self) -> list[dict]:
        """Return list of {name, work_dir, created_at, auto} sorted by name."""
        return sorted(
            [
                {
                    "name": name,
                    "work_dir": meta.get("work_dir"),
                    "created_at": meta.get("created_at", 0.0),
                    "auto": is_auto_named(name),
                }
                for name, meta in self._reg["projects"].items()
            ],
            key=lambda x: x["name"],
        )

    def new_project(self, name: str, work_dir: str | None = None) -> str:
        self._validate_name(name)
        if name in self._reg["projects"]:
            raise FileExistsError(f"Project already exists: {name}")
        resolved = os.path.abspath(os.path.expanduser(work_dir)) if work_dir else os.getcwd()
        self._reg["projects"][name] = {"work_dir": resolved, "created_at": time.time()}
        _save_registry(self._reg)
        return name

    def new_auto_project(self) -> str:
        """Create and register a timestamped auto-named project. Returns its name."""
        name = "sess-" + time.strftime("%Y%m%d-%H%M%S")
        self._reg["projects"][name] = {"work_dir": os.getcwd(), "created_at": time.time()}
        _save_registry(self._reg)
        return name

    def find_or_create_for_cwd(self, cwd: str | None = None) -> str:
        """
        Find a project whose work_dir matches cwd exactly, or create a new
        sess-* temporary project. Switches to it and returns the project name.
        Permanent projects only exist when the user explicitly names them.
        """
        cwd = os.path.abspath(cwd or os.getcwd())

        # Collect all matching projects, prefer most recently modified
        matches = [
            (name, meta)
            for name, meta in self._reg["projects"].items()
            if meta.get("work_dir") and os.path.abspath(meta["work_dir"]) == cwd
        ]
        if matches:
            # Sort by DB mtime (most recent first), fall back to created_at
            def _mtime(item):
                name, meta = item
                db = _project_db(name)
                if os.path.exists(db):
                    return os.path.getmtime(db)
                return meta.get("created_at", 0.0)
            name = max(matches, key=_mtime)[0]
            self._reg["current"] = name
            _save_registry(self._reg)
            return name

        # No match — create a temporary session
        name = "sess-" + time.strftime("%Y%m%d-%H%M%S")
        self._reg["projects"][name] = {"work_dir": cwd, "created_at": time.time()}
        self._reg["current"] = name
        _save_registry(self._reg)
        return name

    def delete_project(self, name: str):
        if name == self.current_project:
            raise ValueError("Cannot delete the active project. Switch first.")
        if name not in self._reg["projects"]:
            raise FileNotFoundError(f"Project not found: {name}")
        db = _project_db(name)
        if os.path.exists(db):
            os.remove(db)
        del self._reg["projects"][name]
        _save_registry(self._reg)

    def rename_project(self, old: str, new: str):
        self._validate_name(new)
        if old not in self._reg["projects"]:
            raise FileNotFoundError(f"Project not found: {old}")
        if new in self._reg["projects"]:
            raise FileExistsError(f"Project already exists: {new}")
        old_db = _project_db(old)
        new_db = _project_db(new)
        if os.path.exists(old_db):
            os.rename(old_db, new_db)
        self._reg["projects"][new] = self._reg["projects"].pop(old)
        if self._reg["current"] == old:
            self._reg["current"] = new
        _save_registry(self._reg)

    def switch_project(self, name: str):
        if name not in self._reg["projects"]:
            raise FileNotFoundError(f"Project not found: {name}")
        self._reg["current"] = name
        _save_registry(self._reg)

    def set_work_dir(self, work_dir: str | None):
        """Set the work_dir for the current project. Relative paths are resolved to absolute.
        The directory is created if it does not exist."""
        if work_dir is not None:
            work_dir = os.path.abspath(os.path.expanduser(work_dir))
            os.makedirs(work_dir, exist_ok=True)
        self._reg["projects"][self.current_project]["work_dir"] = work_dir
        _save_registry(self._reg)

    def cleanup_stale(self, days: int = STALE_DAYS) -> list[str]:
        """
        Delete auto-named projects (sess-*) not modified in `days` days.
        Skips the current project. Returns list of deleted names.
        """
        cutoff = time.time() - days * 86400
        deleted = []
        for name, meta in list(self._reg["projects"].items()):
            if name == self.current_project:
                continue
            if not is_auto_named(name):
                continue
            # Use DB mtime if exists, else created_at
            db = _project_db(name)
            mtime = os.path.getmtime(db) if os.path.exists(db) else meta.get("created_at", 0.0)
            if mtime < cutoff:
                if os.path.exists(db):
                    os.remove(db)
                del self._reg["projects"][name]
                deleted.append(name)
        if deleted:
            _save_registry(self._reg)
        return deleted

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_name(name: str):
        if not name or not name.replace("_", "").replace("-", "").isalnum():
            raise ValueError(f"Invalid name '{name}': use letters, digits, - or _")


def is_auto_named(name: str) -> bool:
    return bool(_AUTO_PATTERN.match(name))
