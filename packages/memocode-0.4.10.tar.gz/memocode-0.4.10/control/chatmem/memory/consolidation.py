"""
Consolidation task (sleep-consolidation analogue).
Runs asynchronously every N sessions.
Observes patterns across recent sessions → writes stable traits to core memory.

Complements the per-compression judge:
  judge        → real-time, single conversation signal
  consolidation → holistic, cross-session pattern detection
"""

from typing import TYPE_CHECKING

from ..compressor import _is_chinese, _llm_complete, _extract_json_array

if TYPE_CHECKING:
    from .recent_memory import RecentMemory
    from .core_memory import CoreMemory


_CONSOLIDATION_PROMPT = """You are a memory consolidation assistant. Analyze the following summaries from recent conversation sessions and extract stable cross-session patterns for long-term memory.

Dimensions to update:
- interaction_style: HOW the user writes — language (Chinese/English/mixed), message length (terse/verbose), tone (formal/casual/blunt), format (bullets/prose/code blocks). NEVER record WHAT they talk about.
- delegation: How much decision authority is delegated — "just do it" = high; "give me options" = medium; "I decided X, implement it" = executor mode. Only record clear repeated patterns, not single instances.

Recent session summaries (chronological):
{text}

Rules:
- Only record patterns that appear consistently across MULTIPLE sessions
- SKIP if evidence is weak or only seen once
- Return ONLY dimensions with strong cross-session evidence

Return a JSON array (empty array if nothing to update):
[{{"key": "<dimension_name>", "value": "<observed pattern>", "dimension": "<dimension_name>"}}]
Dimension must be one of: "interaction_style", "delegation"

Output JSON only:"""

_CONSOLIDATION_PROMPT_ZH = """你是一个记忆巩固助手。分析以下近期对话摘要，提取跨会话的稳定模式，写入长期记忆。

需要更新的维度：
- interaction_style：用户**怎么写**——语言（中文/英文/混合）、消息长度（简短/详细）、语气（正式/随意/直接）、格式（列表/段落/代码块）。严禁记录话题内容。
- delegation：授权程度——"你决定"/"直接做"=高授权；"给我几个方案"=中等授权；"我已决定X，帮我实现"=执行模式。只记录多次出现的清晰模式，单次不算。

近期对话摘要（时间顺序）：
{text}

规则：
- 只记录在多个会话中**一致出现**的模式
- 证据不足或只出现一次则跳过
- 只返回有跨会话强力证据的维度

返回JSON数组（无内容则返回空数组）：
[{{"key": "<维度名>", "value": "<观察到的模式>", "dimension": "<维度名>"}}]
维度必须是以下之一："interaction_style", "delegation"

只输出JSON："""


class ConsolidationTask:
    """
    Periodic consolidation: cross-session pattern detection → core memory.
    Run via run() after every N sessions (recommended: every 5 sessions).
    Reads the most recent `lookback` session summaries for a holistic view.
    """

    def __init__(
        self,
        recent_memory: "RecentMemory",
        core_memory: "CoreMemory",
        api_key: str,
        model: str,
        base_url: str | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
        lookback: int = 20,
    ):
        self.recent = recent_memory
        self.core = core_memory
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body
        self.provider = provider
        self.lookback = lookback

    def run(self) -> list[dict]:
        """
        Extract stable cross-session patterns and write to core memory.
        Returns list of consolidated entries.
        """
        entries = self.recent.get_recent_entries(limit=self.lookback)
        if not entries:
            return []

        recent_text = "\n\n---\n\n".join(entries)
        prompt = _CONSOLIDATION_PROMPT_ZH if _is_chinese(recent_text) else _CONSOLIDATION_PROMPT
        raw = _llm_complete(
            [{"role": "user", "content": prompt.format(text=recent_text)}],
            self.api_key, self.model, self.base_url, self.extra_body, self.provider,
        )
        items = _extract_json_array(raw)

        consolidated = []
        for item in items:
            if "key" in item and "value" in item:
                dimension = item.get("dimension", "communication")
                if dimension not in ("interaction_style", "delegation"):
                    continue
                self.core.set(item["key"], item["value"], dimension=dimension, stability=40.0)
                consolidated.append(item)

        return consolidated
