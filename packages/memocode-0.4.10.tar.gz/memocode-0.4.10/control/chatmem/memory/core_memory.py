"""
Core memory: persistent personality/role/user traits.
Structure: 7-dimension key-value store, each dimension has its own stability profile.
Hot-loaded + Prompt Cache eligible (static prefix).
Updated via: (1) user explicit trigger, (2) async LLM judge (every 5 turns).
Conflicts resolved by forgetting mechanism (interference + decay).

Dimensions and default stability:
  identity      → Who I am         (stability=50, rarely changes)
  values        → What I believe   (stability=40)
  goals         → What I want      (stability=30)
  preferences   → Likes/Dislikes   (stability=25)
  capabilities  → What I can do    (stability=30)
  emotional     → How I react      (stability=20)
  autobiography → Key experiences  (stability=35)
"""

import sqlite3
import time
from typing import Any

from ..config import ContextConfig, DEFAULT_DIMENSIONS, DimensionConfig
from ..compressor import _is_chinese, _llm_complete, _extract_json_array


def _build_judge_prompt(dimensions: dict[str, DimensionConfig]) -> str:
    dim_lines = "\n".join(
        f"- {name}: {cfg.label}" for name, cfg in dimensions.items()
    )
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""You are a memory editor. Review the conversation and update the user's persistent memory profile.

Core memory dimensions:
{dim_lines}

Dimension extraction guidance:
- interaction_style: Record HOW the user communicates and expects AI to behave. Valid signals: language (Chinese/English/mixed), message length (terse/verbose), tone (formal/casual/blunt), format (bullets/prose/code blocks); whether user wants AI to proactively suggest/challenge or just execute; verification habits (e.g. always demands tool confirmation, mistrusts AI-stated facts, repeatedly asks same question); questioning patterns (e.g. asks in series rather than all at once). EXCLUDE any domain content, project names, tech stack, or decision content.
- delegation: Record ONLY explicit delegation signals. Levels:
  HIGH — "just do it"/"your call"/"decide for me": AI chooses and executes. When context is sufficient, act immediately. When context is missing, ask the minimum necessary question then execute — do NOT give options or ask for approval.
  MEDIUM — "give me options"/"what are the tradeoffs": AI advises, user decides. Present choices concisely.
  EXECUTOR — "I've decided X, implement it": user owns all decisions, AI only implements. Never suggest alternatives.
  NOTE: all levels still require sufficient context before acting — high delegation means "execute without offering options", not "execute without understanding the task".
  Must be a clear repeated pattern or explicit statement, not a single instance.

Existing memory:
{{existing}}

New conversation:
{{text}}

Rules:
- ONLY record what is directly observable or explicitly stated. Never infer, extrapolate, or generalise from a single instance.
- For each dimension, choose one action:
  SKIP — not enough evidence, or already captured, or a one-off that may not reflect a stable pattern.
  SUPPLEMENT — new observable fact extends existing (merge into a single updated value).
  UPDATE — user explicitly contradicts or replaces existing (e.g. "from now on answer in English").
- When in doubt between SUPPLEMENT and SKIP, prefer SKIP for these dimensions — false entries are worse than missing ones.
- Return ONLY entries that changed. Omit SKIPped ones.

Return a JSON array of changed entries (empty array if nothing changed):
[{{"key": "<dimension_name>", "value": "<merged or new value>", "dimension": "<dimension_name>"}}]
Dimension name must be one of: {dim_names}

Output JSON only:"""


def _build_judge_prompt_zh(dimensions: dict[str, DimensionConfig]) -> str:
    dim_lines = "\n".join(
        f"- {name}: {cfg.label}" for name, cfg in dimensions.items()
    )
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""你是一个记忆编辑器。审查对话内容，更新用户的持久化记忆档案。

核心信息维度：
{dim_lines}

维度提取指导：
- interaction_style：记录用户**如何沟通**以及期望AI**如何回应**。有效信号：使用语言（中文/英文/混合）、消息长度（简短/详细）、语气（正式/随意/直接）、格式（列表/段落/代码块）；是否希望AI主动建议/质疑还是只执行；验证习惯（如总要求工具确认、不信任AI直接给出的信息、重复追问同一问题）；提问模式（如连续追问而非一次完整提问）。严禁包含领域内容、项目名称、技术栈或决策内容。
- delegation：只记录明确的授权信号。等级定义：
  高委托 — "你决定"/"直接做"/"你来定"：AI自行决策并执行。上下文充足时立即行动；上下文不足时问最少的必要问题然后执行——不给选项、不要求审批。
  中等委托 — "给我几个方案"/"有什么tradeoff"：AI提供建议，用户决策。简洁呈现选项。
  执行模式 — "我已经决定X，帮我实现"：用户掌握所有决策，AI只负责实现，不提替代方案。
  注意：所有等级都需要足够的上下文才能行动——高委托意味着"执行时不给选项"，不是"不理解任务也执行"。
  必须是明确的重复模式或明确陈述，单次出现不算。

当前记忆：
{{existing}}

新对话：
{{text}}

规则：
- 只记录直接可观察或明确陈述的内容。严禁从单次表现推断、外推或泛化。
- 对每个维度，选择以下操作之一：
  跳过 — 证据不足、已被记录、或是一次性表现不代表稳定模式。
  补充 — 新的可观察事实对已有内容的扩展（将两者合并为一条记录）。
  修正 — 用户明确推翻已有内容（如"以后用英文回答我"）。
- 在补充和跳过之间不确定时，这两个维度优先跳过——错误记录比缺失更糟糕。
- 只返回发生变化的条目，跳过的不返回。

返回发生变化的条目的JSON数组（无变化则返回空数组）：
[{{"key": "<维度名>", "value": "<合并后或新的内容>", "dimension": "<维度名>"}}]
维度名必须是以下之一：{dim_names}

只输出JSON："""


class CoreMemory:
    """
    Key-value store for persistent user traits and agent persona.
    Entries: [{key, value, stability, score, created_at}]
    """

    def __init__(
        self,
        db_path: str,
        api_key: str,
        model: str,
        base_url: str | None = None,
        dimensions: dict[str, DimensionConfig] | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
        context_label: str = "Core Memory",
        enable_history: bool = False,
    ):
        self.db_path = db_path
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body
        self.provider = provider
        self.context_label = context_label
        self.dimensions = dimensions or dict(DEFAULT_DIMENSIONS)
        self.enable_history = enable_history
        self._judge_prompt_en = _build_judge_prompt(self.dimensions)
        self._judge_prompt_zh = _build_judge_prompt_zh(self.dimensions)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS core_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL UNIQUE,
                    value TEXT NOT NULL,
                    dimension TEXT NOT NULL DEFAULT 'preferences',
                    stability REAL DEFAULT 25.0,
                    score REAL DEFAULT 1.0,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                )
            """)
            try:
                conn.execute("ALTER TABLE core_memory ADD COLUMN dimension TEXT NOT NULL DEFAULT 'preferences'")
            except Exception:
                pass
            if self.enable_history:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS memory_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT NOT NULL,
                        value TEXT NOT NULL,
                        dimension TEXT NOT NULL,
                        archived_at REAL NOT NULL
                    )
                """)

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def set(self, key: str, value: str, dimension: str = "preferences", stability: float | None = None):
        """
        Write or update a core memory entry.
        Stability defaults to the dimension's profile if not specified.
        If enable_history=True, archives the old value before overwriting.
        """
        dim_stability = self.dimensions[dimension].stability if dimension in self.dimensions else 25.0
        effective_stability = stability if stability is not None else dim_stability
        max_stability = dim_stability * 2.0
        now = time.time()
        with self._conn() as conn:
            if self.enable_history:
                row = conn.execute(
                    "SELECT value, dimension FROM core_memory WHERE key = ?", (key,)
                ).fetchone()
                if row and row["value"] != value:
                    conn.execute(
                        "INSERT INTO memory_history (key, value, dimension, archived_at) VALUES (?, ?, ?, ?)",
                        (key, row["value"], row["dimension"], now),
                    )
            conn.execute(
                """INSERT INTO core_memory (key, value, dimension, stability, score, created_at, updated_at)
                   VALUES (?, ?, ?, ?, 1.0, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET
                       value = excluded.value,
                       dimension = excluded.dimension,
                       stability = MIN(core_memory.stability * 1.1, ?),
                       score = 1.0,
                       updated_at = excluded.updated_at""",
                (key, value, dimension, effective_stability, now, now, max_stability),
            )

    def judge_and_update(self, conversation_text: str) -> list[dict]:
        """
        Memory editor: read existing memory, then decide what to supplement/update/skip/delete.
        Returns list of dicts that were written or deleted.
        """
        existing = self.get_all()
        if existing:
            existing_str = "\n".join(
                f"- {e['key']} (stability={e['stability']:.0f}): {e['value']}"
                for e in existing
            )
        else:
            existing_str = "(empty)"

        judge_prompt = self._judge_prompt_zh if _is_chinese(conversation_text) else self._judge_prompt_en
        prompt = (judge_prompt
                  .replace("{existing}", existing_str)
                  .replace("{text}", conversation_text))
        raw = _llm_complete(
            [{"role": "user", "content": prompt}],
            self.api_key, self.model, self.base_url, self.extra_body, self.provider,
        )
        entries = _extract_json_array(raw)

        written = []
        for entry in entries:
            if "key" not in entry:
                continue
            action = entry.get("action", "").lower()
            if action == "delete":
                self.delete(entry["key"])
                written.append({**entry, "action": "delete"})
            elif "value" in entry:
                self.set(
                    entry["key"], entry["value"],
                    dimension=entry.get("dimension", "preferences"),
                )
                written.append(entry)
        return written

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, key: str) -> str | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT value FROM core_memory WHERE key = ? AND score > 0.1",
                (key,),
            ).fetchone()
        return row["value"] if row else None

    def get_all(self) -> list[dict]:
        """Return all active core memory entries (score > 0.1)."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM core_memory WHERE score > 0.1 ORDER BY stability DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def get_history(self, key: str | None = None) -> list[dict]:
        """Return archived (historical) values, newest first. Requires enable_history=True."""
        if not self.enable_history:
            return []
        with self._conn() as conn:
            if key:
                rows = conn.execute(
                    "SELECT * FROM memory_history WHERE key = ? ORDER BY archived_at DESC",
                    (key,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM memory_history ORDER BY archived_at DESC"
                ).fetchall()
        return [dict(r) for r in rows]

    def to_context_string(self) -> str:
        """
        Format core memory grouped by dimension for context injection.
        Used as static prefix eligible for Prompt Cache.
        """
        entries = self.get_all()
        if not entries:
            return ""

        fallback = next(iter(self.dimensions))
        by_dim: dict[str, list] = {d: [] for d in self.dimensions}
        for e in entries:
            dim = e.get("dimension", fallback)
            if dim not in by_dim:
                dim = fallback
            by_dim[dim].append(e)

        import time as _time
        now = _time.time()
        lines = [f"[{self.context_label}]"]
        for dim, dim_entries in by_dim.items():
            if not dim_entries:
                continue
            label = self.dimensions[dim].label
            lines.append(f"  [{label}]")
            for e in dim_entries:
                days = (now - e["updated_at"]) / 86400.0
                if days < 1:
                    age = "today"
                elif days < 2:
                    age = "1 day ago"
                else:
                    age = f"{int(days)}d ago"
                lines.append(f"    - {e['key']}: {e['value']}  ({age})")
        return "\n".join(lines)

    def delete(self, key: str) -> bool:
        """Remove a core memory entry by key. Returns True if deleted."""
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM core_memory WHERE key = ?", (key,))
        return cur.rowcount > 0

    def clear(self) -> int:
        """Delete all entries from core_memory. Returns number of deleted rows."""
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM core_memory")
        return cur.rowcount

    # ------------------------------------------------------------------
    # Score management (called by ForgettingManager)
    # ------------------------------------------------------------------

    def update_score(self, key: str, new_score: float):
        with self._conn() as conn:
            conn.execute(
                "UPDATE core_memory SET score = ? WHERE key = ?",
                (new_score, key),
            )

    def get_all_with_scores(self) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM core_memory").fetchall()
        return [dict(r) for r in rows]
