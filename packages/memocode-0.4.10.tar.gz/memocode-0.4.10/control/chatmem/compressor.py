"""
Compression strategy: LLM structured summarization.
Captures decisions, rationale, and context — not code or config values.

Compatible with any OpenAI-compatible API.
"""

import re
from typing import Any

from openai import OpenAI


# ---------------------------------------------------------------------------
# Unified LLM completion (OpenAI-compatible or Anthropic native)
# ---------------------------------------------------------------------------

def _llm_complete(
    messages: list[dict],
    api_key: str,
    model: str,
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
) -> str:
    if provider == "anthropic":
        import anthropic
        system = None
        filtered = []
        for m in messages:
            if m["role"] == "system":
                system = m["content"]
            else:
                filtered.append(m)
        # Anthropic requires max_tokens; use a generous default
        kwargs: dict = dict(model=model, max_tokens=4096, messages=filtered)
        if system:
            kwargs["system"] = system
        client = anthropic.Anthropic(api_key=api_key, base_url=base_url)
        response = client.messages.create(**kwargs)
        raw = "".join(b.text for b in response.content if b.type == "text").strip()
    else:
        client = OpenAI(api_key=api_key, base_url=base_url)
        kwargs = dict(model=model, messages=messages)
        if extra_body:
            kwargs["extra_body"] = extra_body
        response = client.chat.completions.create(**kwargs)
        raw = (response.choices[0].message.content or "").strip()
    return re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_json_array(raw: str) -> list:
    """Extract a JSON array from raw LLM output that may contain <think> reasoning blocks."""
    import json
    clean = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
    m = re.search(r"\[.*\]", clean, re.DOTALL)
    if not m:
        return []
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return []


def _detect_compression_mode(text: str) -> str:
    """
    Detect whether text is code-related or plan/discussion.
    Returns 'code' or 'plan'. Local heuristics, no LLM needed.

    Code signals:
      - Fenced code blocks (```)
      - File extensions (.py .js .ts .go .java .rs .cpp .sh .yaml .json ...)
      - Stack traces / error messages
      - import / require / #include statements
      - function / class / def / const definitions
      - Shell prompts ($ )
    If none found → 'plan'
    """
    import re

    # Fenced code blocks
    if "```" in text:
        return "code"

    # Inline backticks (skip single chars like `x`)
    if re.search(r"`[^`]{4,}`", text):
        return "code"

    # File extensions
    if re.search(
        r"\b\w[\w/.-]*\.(py|js|ts|go|java|rs|cpp|c|h|sh|bash|yaml|yml|json|toml|tf|jsx|tsx|vue|rb|php|swift|kt)\b",
        text,
    ):
        return "code"

    # Stack traces
    if re.search(r"(Traceback \(most recent|^\s+File \".*\", line \d+|Error:|Exception:|at line \d+)", text, re.MULTILINE):
        return "code"

    # Import / require / include
    if re.search(r"^(import |from \S+ import |require\(|#include\s*[<\"])", text, re.MULTILINE):
        return "code"

    # Function / class / variable definitions
    if re.search(r"^(def |async def |class |function |const |let |var |fn |pub fn |func )", text, re.MULTILINE):
        return "code"

    # Shell prompts
    if re.search(r"^\$ ", text, re.MULTILINE):
        return "code"

    return "plan"


def _is_chinese(text: str, threshold: float = 0.3) -> bool:
    """
    Return True if Chinese characters make up >= threshold of non-whitespace chars.
    threshold=0.3 catches mixed Chinese+code conversations while excluding pure English.
    """
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    total_chars = len(text.replace(" ", "").replace("\n", ""))
    return total_chars > 0 and (chinese_chars / total_chars) >= threshold


# ---------------------------------------------------------------------------
# Structured session context summarization
# ---------------------------------------------------------------------------

_SESSION_CONTEXT_PROMPT = """You are a conversation summarization assistant. Compress the following conversation into a structured summary for restoring context in subsequent conversations.

Rules:
- Focus on decisions, rationale, context, and outcomes — not implementation details
- EXCLUDE: code snippets, config file contents, file paths, specific values that can be looked up locally in the project
- INCLUDE: why decisions were made, what was agreed on, what problems were encountered
- Use concise bullet points, no long paragraphs
- Output only the following structure, omit sections with no content:
  [Topics] Main topics and tasks covered
  [Decisions/Conclusions] Confirmed plans, choices, conclusions — include rationale.
    For each item write one of:
      "Chose X — reason"              (active decision)
      "Changed from X to Y — reason"  (reversal)
      "Rejected X — reason"           (explicit rejection)
    Never omit rejections or reversals — they are as important as active choices.
  [Progress] What was completed, current stage
  [Pending] Unresolved issues, next steps
  [Key Context] Background, constraints, and non-obvious facts not findable in local files
- Omit small talk, transitional content, and anything already in project files
- Failed attempts / errors: one line max — "Tried X — failed: reason". Do NOT detail stack traces or repeated retries.
- If an attempt ultimately succeeded, only record the successful outcome, not the failed steps leading to it.
- Goal: preserve knowledge that would otherwise be lost between sessions

Conversation:
{text}

Structured summary:"""

_SESSION_CONTEXT_PROMPT_ZH = """你是一个对话摘要助手。请将以下对话内容压缩为结构化摘要，用于后续对话的上下文恢复。

规则：
- 聚焦于决策、理由、背景和结论——不是实现细节
- 排除：代码片段、配置文件内容、文件路径、可以在本地项目中查到的具体数值
- 包含：决策的原因、达成的共识、遇到的问题
- 用简洁要点，不要长段落
- 只输出以下结构，没有内容的section直接省略：
  【话题】涉及的主要话题和任务
  【决策/结论】已确定的方案、选择、结论——包含理由。
    每条写成以下格式之一：
      "选择X——原因"          （当前有效决策）
      "从X改为Y——原因"       （决策反转）
      "放弃X——原因"          （明确拒绝的方案）
    放弃和反转的记录与采纳的决策同等重要，不可省略。
  【进展】完成了什么、进行到哪一步
  【待解决】未解决的问题、下一步计划
  【关键背景】背景信息、约束条件、在本地文件里找不到的非显而易见的事实
- 忽略闲聊、过渡性内容、以及项目文件里已有的内容
- 失败尝试/报错：最多一行，格式"尝试X——失败：原因"。不记录 stack trace 或反复重试的细节。
- 如果某个尝试最终成功，只记录成功结果，不记录中间失败步骤。
- 目标：保留跨会话后否则会丢失的知识

对话内容：
{text}

结构化摘要："""


_SESSION_CONTEXT_PROMPT_PLAN = """You are a conversation summarization assistant. Compress the following conversation into a structured summary for restoring context in subsequent conversations.

Rules:
- Focus on decisions, rationale, context, outcomes, and concrete facts
- EXCLUDE: code snippets, repeated error traces
- PRESERVE: specific values, dates, names, URLs, identifiers, config parameters — these only exist in the conversation and must not be lost
- Use concise bullet points, no long paragraphs
- Output only the following structure, omit sections with no content:
  [Topics] Main topics and tasks covered
  [Decisions/Conclusions] Confirmed plans, choices, conclusions — include rationale and specific parameters.
    For each item write one of:
      "Chose X — reason"
      "Changed from X to Y — reason"
      "Rejected X — reason"
    Never omit rejections or reversals.
  [Key Facts] Specific values, dates, names, identifiers, URLs worth remembering
  [Progress] What was completed, current stage
  [Pending] Unresolved issues, next steps
- Omit small talk and transitional content
- Goal: preserve all meaningful information from the conversation, especially details not recorded elsewhere

Conversation:
{text}

Structured summary:"""

_SESSION_CONTEXT_PROMPT_PLAN_ZH = """你是一个对话摘要助手。请将以下对话内容压缩为结构化摘要，用于后续对话的上下文恢复。

规则：
- 聚焦于决策、理由、背景、结论和具体事实
- 排除：代码片段、重复的报错信息
- 保留：具体数值、日期、人名、URL、标识符、配置参数——这些信息只存在于对话中，不可丢弃
- 用简洁要点，不要长段落
- 只输出以下结构，没有内容的section直接省略：
  【话题】涉及的主要话题和任务
  【决策/结论】已确定的方案、选择、结论——包含理由和具体参数。
    每条写成以下格式之一：
      "选择X——原因"
      "从X改为Y——原因"
      "放弃X——原因"
    放弃和反转的记录与采纳的决策同等重要，不可省略。
  【关键事实】需要记住的具体数值、日期、人员、标识符、URL等
  【进展】完成了什么、进行到哪一步
  【待解决】未解决的问题、下一步计划
- 忽略闲聊、过渡性内容
- 目标：保留对话中所有有意义的信息，尤其是不在其他地方记录的细节

对话内容：
{text}

结构化摘要："""


def compress_session_context(
    text: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    base_url: str | None = None,
    extra_body: dict | None = None,
    provider: str = "openai",
    mode: str = "auto",
) -> str:
    """
    Structured summary for in-session compression events and session-end storage.
    Preserves topics, decisions, progress, pending issues, key context.
    Prompt language is auto-selected based on content language.
    mode: "auto" (default) | "code" | "plan"
      auto — detects from text: code signals → code mode, otherwise → plan mode
    """
    if not text.strip():
        return text

    effective_mode = _detect_compression_mode(text) if mode == "auto" else mode
    if effective_mode == "plan":
        prompt = _SESSION_CONTEXT_PROMPT_PLAN_ZH if _is_chinese(text) else _SESSION_CONTEXT_PROMPT_PLAN
    else:
        prompt = _SESSION_CONTEXT_PROMPT_ZH if _is_chinese(text) else _SESSION_CONTEXT_PROMPT
    return _llm_complete(
        [{"role": "user", "content": prompt.format(text=text)}],
        api_key, model, base_url, extra_body, provider,
    )


class Compressor:
    """
    Compression interface.
    compress_for_session_context(): structured summary (~800 tokens).
      Used for both in-session history compression and cross-session recent_memory storage.
    Prompt language is automatically selected based on content language.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        base_url: str | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
    ):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body
        self.provider = provider

    def compress_for_session_context(self, text: str, mode: str = "auto") -> str:
        """
        Structured compression for in-session history and session-end recent_memory storage.
        mode="auto" (default): detects from text — code signals → code mode, otherwise → plan mode
        mode="code": always use code mode (exclude specific values/paths)
        mode="plan": always use plan mode (preserve all specific values, dates, URLs, identifiers)
        """
        return compress_session_context(text, self.api_key, self.model, self.base_url, self.extra_body, self.provider, mode=mode)
