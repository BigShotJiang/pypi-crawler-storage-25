"""vgis_ai - AI operators library for VGis platform."""

__version__ = "1.7.41"
__author__ = "gisfanmachel"
