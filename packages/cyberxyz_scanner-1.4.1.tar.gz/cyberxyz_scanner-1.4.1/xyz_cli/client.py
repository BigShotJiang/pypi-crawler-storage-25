"""
XYZ API Client
HTTP client for interacting with the XYZ Vulnerability API
"""

import requests
import json
import os
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configuration file path
CONFIG_DIR = os.path.expanduser("~/.xyz")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

class XYZAPIClient:
    """Client for XYZ Vulnerability API"""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the XYZ API client
        
        Args:
            api_key: API key for authentication (can also be set via XYZ_API_KEY env var)
            base_url: Base URL for the API (can also be set via XYZ_API_URL env var)
        """
        self.base_url = base_url or os.getenv('XYZ_API_URL', 'https://api.cyberxyz.io/')
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'xyz-cli/1.0.0'
        })
        
        # Load credentials from config file or fallback to API key
        self._load_credentials()
        
        if 'Authorization' not in self.session.headers:
            # Fallback to legacy API key if no token is loaded
            self.api_key = api_key or os.getenv('XYZ_API_KEY')
            if self.api_key:
                if not self.api_key.startswith('sk_xyz_'):
                    raise ValueError("Invalid API key format. Must start with 'sk_xyz_'.")
                self.session.headers['Authorization'] = f'Bearer {self.api_key}'
            else:
                # No credentials found at all
                pass # Don't raise error here, let commands handle it
    
    def _load_credentials(self):
        """Load credentials from config file"""
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                token = config.get('access_token')
                if token:
                    self.session.headers['Authorization'] = f'Bearer {token}'

    def _save_credentials(self, config: Dict):
        """Save credentials to config file"""
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        os.chmod(CONFIG_FILE, 0o600) # Secure permissions

    def login(self, email: str, password: str) -> Dict[str, Any]:
        """Login to get access token"""
        url = f"{self.base_url.rstrip('/')}/api/v1/auth/login"
        try:
            response = self.session.post(url, data={'username': email, 'password': password})
            response.raise_for_status()
            
            data = response.json()
            self._save_credentials(data)
            self.session.headers['Authorization'] = f"Bearer {data['access_token']}"
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                raise ValueError("Login failed: Incorrect email or password.")
            else:
                raise ValueError(f"Login failed: {e.response.text}")
        except Exception as e:
            raise ValueError(f"An error occurred during login: {e}")

    def logout(self):
        """Logout and clear credentials"""
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        if 'Authorization' in self.session.headers:
            del self.session.headers['Authorization']

    def get_user_info(self) -> Optional[Dict[str, Any]]:
        """Get current user info from config file"""
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return config.get('user_info')
        return None

    def _make_request(self, method: str, endpoint: str, params: Optional[Dict] = None,
                     data: Optional[Dict] = None, files: Optional[Dict] = None,
                     extra_headers: Optional[Dict] = None,
                     timeout: Optional[int] = 30) -> Dict[str, Any]:
        """
        Make HTTP request to the API
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (without base URL)
            params: Query parameters
            data: Request body data
            files: Files for multipart/form-data upload
            extra_headers: Additional headers to merge into the request
            
        Returns:
            Response data as dictionary
            
        Raises:
            requests.exceptions.RequestException: For HTTP errors
            ValueError: For invalid responses
        """
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        try:
            if files:
                response = self.session.request(
                    method=method, url=url, params=params,
                    files=files, headers=extra_headers or {}, timeout=timeout,
                )
            else:
                response = self.session.request(
                    method=method, url=url, params=params,
                    json=data, headers=extra_headers or {}, timeout=timeout,
                )
            response.raise_for_status()
            
            if response.status_code == 204:  # No content
                return {}
            
            return response.json()
            
        except requests.exceptions.HTTPError as e:
            # Try to extract error message from response
            try:
                error_data = response.json()
                error_msg = error_data.get('detail', error_data.get('error', str(e)))
            except:
                error_msg = str(e)
            
            if response.status_code == 401:
                raise ValueError(f"Authentication failed: {error_msg}")
            elif response.status_code == 403:
                raise ValueError(f"Permission denied: {error_msg}")
            elif response.status_code == 429:
                raise ValueError(f"Rate limit exceeded: {error_msg}")
            else:
                raise ValueError(f"API request failed: {error_msg}")
                
        except requests.exceptions.ConnectionError:
            raise ValueError(f"Failed to connect to API at {self.base_url}. Is the API server running?")
        except requests.exceptions.Timeout:
            raise ValueError("API request timed out")
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Request failed: {str(e)}")
    
    def health_check(self) -> Dict[str, Any]:
        """Check API health status"""
        return self._make_request('GET', '/health')
    
    def get_api_info(self) -> Dict[str, Any]:
        """Get API information and capabilities"""
        return self._make_request('GET', '/api/v1/info')
    
    # Vulnerability Search Methods
    def search_vulnerability_by_id(self, vuln_id: str, include_exploits: bool = False) -> Dict[str, Any]:
        """
        Search for a vulnerability by ID (CVE, GHSA, OSV, etc.)
        
        Args:
            vuln_id: Vulnerability ID
            include_exploits: Include exploit information
            
        Returns:
            Vulnerability data
        """
        params = {'include_exploits': include_exploits}
        return self._make_request('GET', f'/api/v1/vulnerabilities/{vuln_id}', params=params)
    
    def search_vulnerabilities(self, query: str, ecosystem: Optional[str] = None, 
                             severity: Optional[str] = None, limit: int = 50, 
                             offset: int = 0, include_exploits: bool = False) -> Dict[str, Any]:
        """
        Search vulnerabilities with flexible criteria
        
        Args:
            query: Search query
            ecosystem: Ecosystem filter
            severity: Severity filter
            limit: Maximum results
            offset: Pagination offset
            include_exploits: Include exploit information
            
        Returns:
            Search results
        """
        params = {
            'q': query,
            'limit': limit,
            'offset': offset,
            'include_exploits': include_exploits
        }
        if ecosystem:
            params['ecosystem'] = ecosystem
        if severity:
            params['severity'] = severity
        
        return self._make_request('GET', '/api/v1/vulnerabilities/search', params=params)
    
    def get_recent_vulnerabilities(self, days: int = 7, limit: int = 50, 
                                 include_exploits: bool = False) -> Dict[str, Any]:
        """
        Get recent vulnerabilities
        
        Args:
            days: Number of days to look back
            limit: Maximum results
            include_exploits: Include exploit information
            
        Returns:
            Recent vulnerabilities
        """
        params = {
            'days': days,
            'limit': limit,
            'include_exploits': include_exploits
        }
        return self._make_request('GET', '/api/v1/vulnerabilities/recent', params=params)
    
    # Package Search Methods
    def search_package_vulnerabilities(self, package_name: str, ecosystem: Optional[str] = None,
                                     version: Optional[str] = None, severity: Optional[str] = None,
                                     limit: int = 50, offset: int = 0,
                                     include_exploits: bool = False, machine_name: str = None,
                                     os_type: str = None, computer_name: str = None,
                                     scan_command: str = None) -> Dict[str, Any]:
        """
        Search for vulnerabilities affecting a specific package
        
        Args:
            package_name: Package name
            package_name: Package name
            ecosystem: Ecosystem filter
            version: Package version
            severity: Severity filter
            limit: Maximum results
            offset: Pagination offset
            include_exploits: Include exploit information
            machine_name: Name of the machine being scanned
            os_type: OS type of the machine being scanned
            computer_name: Computer name of the machine being scanned
            scan_command: The command that was run to initiate the scan
            
        Returns:
            Package vulnerability data
        """
        params = {
            'q': package_name,
            'limit': limit,
            'offset': offset,
            'include_exploits': include_exploits,
            'machine_name': machine_name,
            'os_type': os_type,
            'computer_name': computer_name,
            'scan_command': scan_command
        }
        if ecosystem:
            params['ecosystem'] = ecosystem
        if version:
            params['version'] = version
        if severity:
            params['severity'] = severity
        
        return self._make_request('GET', '/api/v1/packages/search', params=params, timeout=60)
    
    def get_package_vulnerabilities(self, package_name: str, ecosystem: Optional[str] = None,
                                  include_exploits: bool = False) -> Dict[str, Any]:
        """
        Get all vulnerabilities for a specific package
        
        Args:
            package_name: Package name
            ecosystem: Ecosystem filter
            include_exploits: Include exploit information
            
        Returns:
            Package vulnerability data
        """
        params = {'include_exploits': include_exploits}
        if ecosystem:
            params['ecosystem'] = ecosystem
        
        return self._make_request('GET', f'/api/v1/packages/{package_name}', params=params)
    
    # System Scanning Methods
    def scan_python_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """
        Scan installed Python packages for vulnerabilities
        
        Args:
            include_exploits: Include exploit information
            machine_name: Name of the machine being scanned
            os_type: OS type of the machine being scanned
            computer_name: Computer name of the machine being scanned
            
        Returns:
            Scan results
        """
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/python', params=params)
    
    def scan_npm_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """
        Scan npm packages for vulnerabilities
        
        Args:
            include_exploits: Include exploit information
            machine_name: Name of the machine being scanned
            os_type: OS type of the machine being scanned
            computer_name: Computer name of the machine being scanned
            
        Returns:
            Scan results
        """
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/npm', params=params)

    def scan_java_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """Scan installed Java packages for vulnerabilities"""
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/java', params=params)

    def scan_go_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """Scan installed Go packages for vulnerabilities"""
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/go', params=params)

    def scan_php_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """Scan installed PHP packages for vulnerabilities"""
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/php', params=params)

    def scan_microsoft_packages(self, include_exploits: bool = False, machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """Scan installed Microsoft packages for vulnerabilities"""
        params = {'include_exploits': include_exploits, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('POST', '/api/v1/system/scan/microsoft', params=params)

    def list_packages(self, package_types: List[str], machine_name: str = None, os_type: str = None, computer_name: str = None) -> Dict[str, Any]:
        """List installed packages"""
        params = {'package_types': package_types, 'machine_name': machine_name, 'os_type': os_type, 'computer_name': computer_name}
        return self._make_request('GET', '/api/v1/system/packages', params=params)
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information and scanning capabilities"""
        return self._make_request('GET', '/api/v1/system/info')

    def send_go_audit(self, audit_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send Go audit data to the backend"""
        # Extract metadata fields, use the rest as scan_results
        metadata_fields = {"machine_name", "os_type", "computer_name", "scan_command"}
        scan_results = {k: v for k, v in audit_data.items() if k not in metadata_fields}
        
        return self._make_request('POST', '/api/v1/scans', data={
            "scan_type": "go_audit",
            "scan_command": audit_data.get("scan_command", "xyz audit go"),
            "scan_results": scan_results,
            "machine_name": audit_data.get("machine_name"),
            "os_type": audit_data.get("os_type"),
            "computer_name": audit_data.get("computer_name")
        })
    
    def send_python_audit(self, audit_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send Python audit data to the backend"""
        return self._make_request('POST', '/api/v1/scans', data={
            "scan_type": "python",
            "scan_command": "xyz audit python",
            "scan_results": audit_data.get("scan_results"),
            "machine_name": audit_data.get("machine_name"),
            "os_type": audit_data.get("os_type"),
            "computer_name": audit_data.get("computer_name")
        })

    def send_npm_audit(self, audit_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send npm audit data to the backend"""
        metadata_fields = {"machine_name", "os_type", "computer_name", "scan_command"}
        scan_results = {k: v for k, v in audit_data.items() if k not in metadata_fields}
        return self._make_request('POST', '/api/v1/scans', data={
            "scan_type": "npm_audit",
            "scan_command": audit_data.get("scan_command", "xyz audit npm"),
            "scan_results": scan_results,
            "machine_name": audit_data.get("machine_name"),
            "os_type": audit_data.get("os_type"),
            "computer_name": audit_data.get("computer_name"),
        })

    def send_package_scan(self, scan_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send package scan data to the backend"""
        # Extract metadata fields, use the rest as scan_results
        metadata_fields = {"machine_name", "os_type", "computer_name", "scan_command"}
        scan_results = {k: v for k, v in scan_data.items() if k not in metadata_fields}
        
        return self._make_request('POST', '/api/v1/scans', data={
            "scan_type": "package_scan",
            "scan_command": scan_data.get("scan_command", "xyz package scan"),
            "scan_results": scan_results,
            "machine_name": scan_data.get("machine_name"),
            "os_type": scan_data.get("os_type"),
            "computer_name": scan_data.get("computer_name")
        })

    # Statistics Methods
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        return self._make_request('GET', '/api/v1/vulnerabilities/stats')
    
    def get_ecosystem_stats(self) -> Dict[str, Any]:
        """Get ecosystem statistics"""
        return self._make_request('GET', '/api/v1/packages/ecosystems/stats')
    
    # Log Viewer Methods
    def list_log_files(self, file_type: Optional[str] = None, status: str = 'active', 
                      limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """List log files with optional filtering"""
        params = {
            'status': status,
            'limit': limit,
            'offset': offset
        }
        if file_type:
            params['file_type'] = file_type
        return self._make_request('GET', '/api/v1/logs/', params=params)
    
    def get_log_file(self, log_id: int) -> Dict[str, Any]:
        """Get log file metadata"""
        return self._make_request('GET', f'/api/v1/logs/{log_id}')
    
    def get_log_entries(self, log_id: int, level: Optional[str] = None, 
                       search: Optional[str] = None, start_time: Optional[str] = None,
                       end_time: Optional[str] = None, limit: int = 100, 
                       offset: int = 0) -> Dict[str, Any]:
        """Get log entries with filtering options"""
        params = {
            'limit': limit,
            'offset': offset
        }
        if level:
            params['level'] = level
        if search:
            params['search'] = search
        if start_time:
            params['start_time'] = start_time
        if end_time:
            params['end_time'] = end_time
        return self._make_request('GET', f'/api/v1/logs/{log_id}/entries', params=params)
    
    def upload_log_file(self, file_path: str, filename: Optional[str] = None,
                       file_type: Optional[str] = None) -> Dict[str, Any]:
        """Upload a log file for analysis"""
        import os
        from pathlib import Path
        
        if not os.path.exists(file_path):
            raise ValueError(f"File not found: {file_path}")
        
        file_path_obj = Path(file_path)
        if not filename:
            filename = file_path_obj.name
        if not file_type:
            file_type = file_path_obj.suffix.lstrip('.').lower()
            if file_type not in ['csv', 'evtx', 'txt', 'log', 'json']:
                file_type = 'txt'
        
        file_size = file_path_obj.stat().st_size
        
        # Read file content for upload
        with open(file_path, 'rb') as f:
            file_content = f.read()
        
        # Prepare multipart/form-data file upload
        files = {
            'file': (filename, file_content, 'application/octet-stream')
        }
        
        return self._make_request('POST', '/api/v1/logs/upload', files=files)
    
    def delete_log_file(self, log_id: int) -> Dict[str, Any]:
        """Delete a log file and all its entries"""
        return self._make_request('DELETE', f'/api/v1/logs/{log_id}')
    
    def clear_log_entries(self, log_id: int) -> Dict[str, Any]:
        """Clear all entries from a log file but keep the file metadata"""
        return self._make_request('POST', f'/api/v1/logs/{log_id}/clear')
    
    def download_log_file(self, log_id: int, format: str = 'original') -> Dict[str, Any]:
        """Download log file in specified format"""
        params = {'format': format}
        return self._make_request('GET', f'/api/v1/logs/{log_id}/download', params=params)
    
    def get_log_stats(self, log_id: int) -> Dict[str, Any]:
        """Get statistics for a specific log file"""
        return self._make_request('GET', f'/api/v1/logs/{log_id}/stats')
    
    def search_logs(self, query: str, file_type: Optional[str] = None,
                   level: Optional[str] = None, limit: int = 100) -> Dict[str, Any]:
        """Search across all log files"""
        params = {
            'q': query,
            'limit': limit
        }
        if file_type:
            params['file_type'] = file_type
        if level:
            params['level'] = level
        return self._make_request('GET', '/api/v1/logs/search', params=params)
    
    # Scan History Methods
    def get_scan_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get scan history for the organization"""
        return self._make_request('GET', '/api/v1/scans', params={'limit': limit})
    
    def get_scan_details(self, scan_id: int) -> Dict[str, Any]:
        """Get detailed information about a specific scan"""
        return self._make_request('GET', f'/api/v1/scans/{scan_id}')

    # Proxy Check Methods (Sprint 13.1 / 11.2)
    def proxy_check(self, package: str, version: str, ecosystem: str = "npm",
                    machine_name: str = None, os_type: str = None) -> Dict[str, Any]:
        """Run a proxy safety check for a single package@version."""
        import socket as _sock
        hostname = _sock.gethostname()
        headers = {}
        if machine_name:
            headers["X-Machine-Name"] = machine_name
        if os_type:
            headers["X-Client-UA"] = f"xyz-cli/1.0.0 ({os_type}; {hostname})"
        headers["X-Hostname"] = hostname
        return self._make_request(
            "POST",
            "/api/v1/proxy/check",
            data={"package": package, "version": version, "ecosystem": ecosystem},
            extra_headers=headers or None,
        )

    def proxy_check_batch(self, packages: List[Dict[str, str]],
                          machine_name: str = None, os_type: str = None) -> List[Dict[str, Any]]:
        """
        Run proxy checks for multiple packages in a SINGLE API call.
        Each dict must have keys: package, version, and optionally ecosystem.
        Much faster than individual checks — N packages → 1 HTTP round-trip.
        """
        def _ascii_safe(s: str) -> str:
            return (s.replace('\u2018', "'").replace('\u2019', "'")
                     .replace('\u201c', '"').replace('\u201d', '"')
                     .replace('\u2014', '-').replace('\u2013', '-')
                     .encode('ascii', errors='replace').decode('ascii'))

        import socket as _sock
        hostname = _sock.gethostname()
        headers = {}
        if machine_name:
            headers["X-Machine-Name"] = _ascii_safe(machine_name)
        if os_type:
            headers["X-Client-UA"] = f"xyz-cli/1.0.0 ({_ascii_safe(os_type)}; {hostname})"
        headers["X-Hostname"] = hostname

        payload_pkgs = [
            {"package": p["package"], "version": p["version"],
             "ecosystem": p.get("ecosystem", "npm")}
            for p in packages
        ]
        try:
            # Chunk into batches of 500 (server limit)
            BATCH_SIZE = 500
            all_results = []
            for i in range(0, len(payload_pkgs), BATCH_SIZE):
                chunk = payload_pkgs[i:i + BATCH_SIZE]
                resp = self._make_request(
                    "POST",
                    "/api/v1/proxy/check/batch",
                    data={"packages": chunk, "machine_name": machine_name, "os_type": os_type},
                    extra_headers=headers or None,
                    timeout=120,
                )
                all_results.extend(resp.get("results", []))
            return all_results
        except Exception as batch_err:
            # Fallback to individual checks if batch endpoint unavailable
            import sys
            print(f"\n[warning] Batch check failed ({batch_err}), falling back to individual checks...", file=sys.stderr)
            results = []
            for pkg in packages:
                try:
                    r = self.proxy_check(
                        pkg["package"], pkg["version"], pkg.get("ecosystem", "npm"),
                        machine_name=machine_name, os_type=os_type,
                    )
                    results.append(r)
                except Exception as e:
                    results.append({"error": str(e), "signals": []})
            return results

    def get_proxy_install_log(
        self,
        limit: int = 50,
        offset: int = 0,
        decision: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Query the proxy install log."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if decision:
            params["decision"] = decision
        return self._make_request("GET", "/api/v1/proxy/log", params=params)

    def get_proxy_install_summary(self, days: int = 7) -> Dict[str, Any]:
        """Get install log summary: by-machine, top-blocked, trend."""
        return self._make_request(
            "GET", "/api/v1/proxy/log/summary", params={"days": days}
        )

    def upload_inventory_sbom(self, sbom: Dict[str, Any],
                               source_ref: Optional[str] = None) -> Dict[str, Any]:
        """Upload a Syft / CycloneDX JSON SBOM and get an exposure summary.

        Returns the inventory_id, accepted/rejected counts, sbom_format, and
        an exposure summary (total / known_malicious / advisory_critical /
        advisory_high) — see api/endpoints/inventory.py.
        """
        return self._make_request(
            "POST", "/api/v1/inventory/upload",
            data={"sbom": sbom, "source_ref": source_ref},
            timeout=180,
        )

    def get_inventory_exposure(self, inventory_id: str,
                                only_flagged: bool = True) -> Dict[str, Any]:
        """Fetch per-row exposure for a previously-uploaded inventory."""
        return self._make_request(
            "GET", f"/api/v1/inventory/{inventory_id}/exposure",
            params={"only_flagged": str(only_flagged).lower()},
            timeout=60,
        )
