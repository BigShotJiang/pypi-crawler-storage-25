"""Decorator for Uptime Robot"""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from functools import wraps
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, ParamSpec, TypeVar, cast

import aiohttp

from pyuptimerobot import exceptions

from .const import (
    API_BASE_URL,
    LOGGER,
)
from .models import UptimeRobotApiResponse

if TYPE_CHECKING:
    from .uptimerobot import UptimeRobot

P = ParamSpec("P")
ResponseDataT = TypeVar("ResponseDataT")


def api_request(
    api_path: str, method: str = "GET"
) -> Callable[
    [Callable[P, Coroutine[Any, Any, UptimeRobotApiResponse[ResponseDataT]]]],
    Callable[P, Coroutine[Any, Any, UptimeRobotApiResponse[ResponseDataT]]],
]:
    """Decorator for Uptime Robot API request"""

    def decorator(
        _func: Callable[P, Coroutine[Any, Any, UptimeRobotApiResponse[ResponseDataT]]],
    ) -> Callable[P, Coroutine[Any, Any, UptimeRobotApiResponse[ResponseDataT]]]:
        """Decorator"""

        @wraps(_func)
        async def wrapper(
            *args: P.args, **kwargs: P.kwargs
        ) -> UptimeRobotApiResponse[ResponseDataT]:
            """Wrapper"""
            client = cast("UptimeRobot", args[0])
            url = f"{API_BASE_URL}{api_path}"
            if (monitor_id := kwargs.pop("monitor_id", None)) is not None:
                url = url.format(monitor_id=monitor_id)

            LOGGER.debug("Requesting %s with payload %s", url, kwargs)
            try:
                request = await client._session.request(
                    method=method,
                    url=url,
                    headers={
                        "Authorization": f"Bearer {client._api_key}",
                        "Content-Type": "application/json",
                    },
                    json=kwargs,
                    timeout=aiohttp.ClientTimeout(total=10),
                )

                if request.status not in (
                    HTTPStatus.OK,
                    HTTPStatus.CREATED,
                ):
                    if request.status == HTTPStatus.UNAUTHORIZED:
                        raise exceptions.UptimeRobotAuthenticationException(
                            f"Authentication failed for '{url}'"
                            f" with status code '{request.status}'"
                        )
                    raise exceptions.UptimeRobotConnectionException(
                        f"Request for '{url}' failed with status code '{request.status}'"
                    )

                result = await request.json()
            except aiohttp.ClientError as exception:
                raise exceptions.UptimeRobotConnectionException(
                    f"Request exception for '{url}' with - {exception}"
                ) from exception

            except TimeoutError:
                raise exceptions.UptimeRobotConnectionException(
                    f"Request timeout for '{url}'"
                ) from None

            except exceptions.UptimeRobotException:
                raise

            except Exception as exception:
                raise exceptions.UptimeRobotException(
                    f"Unexpected exception for '{url}' with - {exception}"
                ) from exception

            LOGGER.debug("Requesting %s returned %s", url, result)

            return UptimeRobotApiResponse.from_dict(
                {**result, "_api_path": api_path, "_method": method}
            )

        return wrapper

    return decorator
