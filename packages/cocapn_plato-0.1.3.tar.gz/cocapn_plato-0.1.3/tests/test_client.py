"""Tests for PlatoClient high-level API."""
import json
import pytest
from unittest.mock import patch, MagicMock
from plato import PlatoClient


class TestPlatoClient:
    def test_default_url(self):
        client = PlatoClient()
        assert "cocapn.ai" in client.base_url

    def test_custom_url(self):
        client = PlatoClient(base_url="http://custom:8847")
        assert client.base_url == "http://custom:8847"

    @patch("plato.urllib.request.urlopen")
    def test_search(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "results": [{"domain": "test", "question": "q", "answer": "a", "confidence": 0.9}]
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = PlatoClient(base_url="https://example.com/api/plato")
        results = client.search("test query")
        assert len(results) == 1

    @patch("plato.urllib.request.urlopen")
    def test_submit_tile(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "status": "ok", "hash": "abc123"
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = PlatoClient(base_url="https://example.com/api/plato")
        result = client.submit(domain="test", question="q?", answer="a", confidence=0.9)
        assert result["status"] == "ok"

    @patch("plato.urllib.request.urlopen")
    def test_explore_rooms(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "rooms": {"forge": {"tile_count": 10}, "library": {"tile_count": 20}}
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = PlatoClient(base_url="https://example.com/api/plato")
        rooms = client.explore()
        assert "rooms" in rooms

    def test_version(self):
        import plato
        assert plato.__version__
        parts = plato.__version__.split(".")
        assert len(parts) == 3
