"""Tests for FleetConnection — the core SDK class."""
import json
import pytest
from unittest.mock import patch, MagicMock
from urllib.parse import urlencode

from plato import FleetConnection


def make_mock_response(data):
    """Create a mock urllib response."""
    resp = MagicMock()
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    resp.read.return_value = json.dumps(data).encode()
    return resp


MOCK_CONNECT = {
    "room": "harbor", "description": "The Harbor — where all agents arrive.",
    "exits": ["forge", "observatory", "dry-dock"], "objects": ["harbor-bell"],
    "agents_present": [], "job": "scholar"
}

MOCK_LOOK = {
    "room": "harbor", "description": "The Harbor.", "exits": ["forge"],
    "objects": ["harbor-bell"], "agents_present": ["scholar-42"], "tiles": 12165
}

MOCK_MOVE = {
    "room": "forge", "description": "The Forge — where raw material becomes knowledge.",
    "exits": ["harbor", "crucible"], "objects": ["anvil", "crucible"]
}

MOCK_EXAMINE = {
    "target": "crucible", "description": "A vessel where raw observations crystallize.",
    "hint": "submit_tile() to forge a Tile."
}

MOCK_SUBMIT = {
    "status": "accepted", "tile_hash": "19edad428945", "trace_id": "trace-abc", "provenance": "signed"
}


class TestConnect:
    """Test FleetConnection.connect()."""

    @patch("plato.urllib.request.urlopen")
    def test_connect_returns_self(self, mock_urlopen):
        """Connect returns FleetConnection (self), not a dict."""
        mock_urlopen.return_value = make_mock_response(MOCK_CONNECT)
        fleet = FleetConnection(agent="test", job="scholar")
        result = fleet.connect()
        assert result is fleet  # Returns self for chaining
        assert fleet._room == "harbor"
        assert fleet._connected is True

    @patch("plato.urllib.request.urlopen")
    def test_connect_urlencodes_params(self, mock_urlopen):
        """Connect must urlencode params to prevent injection."""
        mock_urlopen.return_value = make_mock_response(MOCK_CONNECT)
        fleet = FleetConnection(agent="test & evil", job="scholar")
        fleet.connect()

        req = mock_urlopen.call_args[0][0]
        url = req.full_url if hasattr(req, 'full_url') else str(req)
        # Should NOT contain raw "&" that could inject extra params
        query_part = url.split("?")[1]
        # The agent value should be encoded (either + or %20 for space, %26 for &)
        assert "test+" in query_part or "test%20" in query_part


class TestMove:
    @patch("plato.urllib.request.urlopen")
    def test_move_returns_room_data(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(MOCK_MOVE)
        fleet = FleetConnection(agent="test")
        result = fleet.move_to("forge")
        assert result["room"] == "forge"
        assert "anvil" in result["objects"]


class TestLook:
    @patch("plato.urllib.request.urlopen")
    def test_look_returns_room_state(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(MOCK_LOOK)
        fleet = FleetConnection(agent="test")
        result = fleet.look()
        assert result["room"] == "harbor"
        assert "objects" in result
        assert "exits" in result


class TestExamine:
    @patch("plato.urllib.request.urlopen")
    def test_examine_target(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(MOCK_EXAMINE)
        fleet = FleetConnection(agent="test")
        result = fleet.examine("crucible")
        assert result["target"] == "crucible"


class TestSubmitTile:
    @patch("plato.urllib.request.urlopen")
    def test_submit_returns_hash(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(MOCK_SUBMIT)
        fleet = FleetConnection(agent="test")
        result = fleet.submit_tile(domain="ai", question="What?", answer="Something")
        assert result["status"] == "accepted"
        assert "tile_hash" in result


class TestErrorHandling:
    """Network errors must return error dicts, never crash."""

    @patch("plato.urllib.request.urlopen")
    def test_http_500(self, mock_urlopen):
        import urllib.error
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="http://test", code=500, msg="Server Error", hdrs=None, fp=None
        )
        fleet = FleetConnection(agent="test")
        result = fleet.look()
        assert "error" in result
        assert "500" in result["error"]

    @patch("plato.urllib.request.urlopen")
    def test_connection_timeout(self, mock_urlopen):
        import urllib.error
        mock_urlopen.side_effect = urllib.error.URLError("Connection timed out")
        fleet = FleetConnection(agent="test")
        result = fleet.look()
        assert "error" in result

    @patch("plato.urllib.request.urlopen")
    def test_invalid_json(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response_raw(b"not json at all")
        fleet = FleetConnection(agent="test")
        result = fleet.look()
        assert "error" in result


def make_mock_response_raw(raw_bytes):
    resp = MagicMock()
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    resp.read.return_value = raw_bytes
    return resp


class TestURLInjection:
    @patch("plato.urllib.request.urlopen")
    def test_injection_prevented(self, mock_urlopen):
        """agent='evil&job=admin' must NOT inject extra params."""
        mock_urlopen.return_value = make_mock_response(MOCK_CONNECT)
        fleet = FleetConnection(agent="evil&job=admin", job="scholar")
        fleet.connect()

        req = mock_urlopen.call_args[0][0]
        url = req.full_url if hasattr(req, 'full_url') else str(req)
        query = url.split("?")[1]
        # The injected "job=admin" must NOT appear as a separate param
        params = query.split("&")
        job_params = [p for p in params if p.startswith("job=")]
        assert len(job_params) == 1  # Only one job param (the real one)
        assert job_params[0] == "job=scholar"
