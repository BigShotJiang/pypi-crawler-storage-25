"""Tests for PLATO decomposition engine (unit + integration)."""
import json
import pytest
from unittest.mock import patch, MagicMock
from plato import PlatoClient


class TestDecompositionUnit:
    """Unit tests for decomposition client methods."""

    def test_api_method_exists(self):
        client = PlatoClient(base_url="https://cocapn.ai/api/plato")
        assert hasattr(client, "_api")

    @patch("plato.urllib.request.urlopen")
    def test_decompose_creates_session(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "room": "decompose-test123", "status": "active", "max_depth": 5
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = PlatoClient(base_url="https://example.com/api/plato")
        result = client._api("/decompose", {"mode": "fast", "agent": "test"})
        assert result["room"].startswith("decompose-")
        assert result["status"] == "active"

    @patch("plato.urllib.request.urlopen")
    def test_submit_atom(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "atom_id": "P1", "atom_type": "premise", "depth": 0,
            "session_status": "active", "room": "decompose-test"
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = PlatoClient(base_url="https://example.com/api/plato")
        result = client._api("/decompose/test/atom", {
            "atom_id": "P1", "content": "test", "atom_type": "premise",
            "confidence": 0.9
        })
        assert result["atom_type"] == "premise"
        assert result["depth"] == 0


class TestDecompositionIntegration:
    """Integration tests against live PLATO server."""

    @pytest.fixture
    def client(self):
        return PlatoClient(base_url="http://localhost/api/plato")

    def test_create_session(self, client):
        result = client._api("/decompose", {"mode": "fast", "agent": "test-suite"})
        assert "room" in result
        assert result["status"] == "active"
        assert result["max_depth"] == 5

    def test_full_five_atom_chain(self, client):
        session = client._api("/decompose", {"mode": "fast", "agent": "test-suite"})
        room = session["room"]

        # Submit full P→R→H→V→C chain
        atoms = [
            {"atom_id": "P1", "content": "Test premise", "atom_type": "premise", "confidence": 0.9},
            {"atom_id": "R1", "content": "Test reasoning", "atom_type": "reasoning", "depends_on": ["P1"], "confidence": 0.85},
            {"atom_id": "H1", "content": "Test hypothesis", "atom_type": "hypothesis", "depends_on": ["R1"], "confidence": 0.8},
            {"atom_id": "V1", "content": "Test verification", "atom_type": "verification", "depends_on": ["H1"], "is_verified": True, "confidence": 0.9},
            {"atom_id": "C1", "content": "Test conclusion", "atom_type": "conclusion", "depends_on": ["V1"], "is_verified": True, "confidence": 0.95},
        ]

        results = []
        for atom in atoms:
            r = client._api(f"/decompose/{room}/atom", {**atom, "agent": "test-suite"})
            results.append(r)

        assert len(results) == 5
        assert results[-1]["session_status"] == "completed"
        for i, r in enumerate(results):
            assert r["depth"] == i

    def test_get_sessions(self, client):
        result = client._api("/decompose/sessions", {})
        assert "sessions" in result
        assert isinstance(result["sessions"], list)

    def test_get_graph(self, client):
        # Create session with atoms first
        session = client._api("/decompose", {"mode": "fast", "agent": "test-suite"})
        room = session["room"]
        client._api(f"/decompose/{room}/atom", {
            "atom_id": "G1", "content": "Graph test", "atom_type": "premise", "confidence": 0.9
        })

        graph = client._api(f"/decompose/{room}/graph", {})
        assert "nodes" in graph
        assert "links" in graph
        assert len(graph["nodes"]) >= 1
