"""Tests for plato.wrap(agent)."""
import json
import pytest
from unittest.mock import patch, MagicMock
from plato import PlatoClient
from plato.wrapper import WrappedAgent, ATOM_PROMPTS


class MockAgent:
    name = "test-agent"


class TestWrappedAgent:
    def test_wrapped_agent_creation(self):
        client = PlatoClient(base_url="https://example.com/api/plato")
        agent = MockAgent()
        wrapped = WrappedAgent(agent, client, mode="fast")
        assert wrapped.agent is agent
        assert wrapped.mode == "fast"
        assert wrapped.sessions == []
        assert wrapped.reasoning_fn is None

    def test_template_generate_five_types(self):
        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client)
        for atom_type in ["premise", "reasoning", "hypothesis", "verification", "conclusion"]:
            result = wrapped._template_generate("What is PLATO?", None, atom_type)
            assert isinstance(result, str)
            assert len(result) > 0

    def test_template_generate_with_context(self):
        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client)
        result = wrapped._template_generate("query", "custom context", "premise")
        assert result == "custom context"

    def test_generate_uses_reasoning_fn(self):
        def custom_fn(query, ctx, atom_type, chain):
            return f"CUSTOM:{atom_type}"

        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client, reasoning_fn=custom_fn)
        result = wrapped._generate_atom("q", None, "premise", [])
        assert result == "CUSTOM:premise"

    def test_generate_falls_to_template(self):
        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client)
        result = wrapped._generate_atom("test query", None, "hypothesis", [])
        assert "test query" in result

    def test_atom_prompts_complete(self):
        assert set(ATOM_PROMPTS.keys()) == {"premise", "reasoning", "hypothesis", "verification", "conclusion"}

    def test_get_history_empty(self):
        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client)
        assert wrapped.get_history() == []

    @patch.object(PlatoClient, "_api")
    def test_reason_full_flow(self, mock_api):
        mock_api.side_effect = [
            {"room": "decompose-wrapped-test", "status": "active", "max_depth": 5},
            {"atom_id": "P1", "atom_type": "premise", "depth": 0, "session_status": "active"},
            {"atom_id": "R1", "atom_type": "reasoning", "depth": 1, "session_status": "active"},
            {"atom_id": "H1", "atom_type": "hypothesis", "depth": 2, "session_status": "active"},
            {"atom_id": "V1", "atom_type": "verification", "depth": 3, "session_status": "active"},
            {"atom_id": "C1", "atom_type": "conclusion", "depth": 4, "session_status": "completed",
             "best_conclusion": {"content": "Test conclusion", "confidence": 0.92}},
        ]

        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client)
        result = wrapped.reason("What is PLATO?")

        assert result["chain_length"] == 5
        assert result["conclusion"] is not None
        assert result["status"] == "completed"
        assert len(wrapped.sessions) == 1
        assert mock_api.call_count == 6

    @patch.object(PlatoClient, "_api")
    def test_reason_with_custom_fn(self, mock_api):
        def my_fn(q, ctx, atype, chain):
            return f"[{atype}] analyzing {q}"

        mock_api.side_effect = [
            {"room": "decompose-custom", "status": "active"},
            {"atom_id": "P1", "atom_type": "premise", "depth": 0, "session_status": "active"},
            {"atom_id": "R1", "atom_type": "reasoning", "depth": 1, "session_status": "active"},
            {"atom_id": "H1", "atom_type": "hypothesis", "depth": 2, "session_status": "active"},
            {"atom_id": "V1", "atom_type": "verification", "depth": 3, "session_status": "active"},
            {"atom_id": "C1", "atom_type": "conclusion", "depth": 4, "session_status": "completed",
             "best_conclusion": {"content": "Use PLATO", "confidence": 0.95}},
        ]

        client = PlatoClient(base_url="https://example.com/api/plato")
        wrapped = WrappedAgent(MockAgent(), client, reasoning_fn=my_fn)
        result = wrapped.reason("test query")

        assert result["status"] == "completed"
        # Verify the custom fn was used (check the atom payloads)
        first_call_args = mock_api.call_args_list[1]  # Second call = first atom
        assert "analyzing test query" in str(first_call_args)

    @patch.object(PlatoClient, "_api")
    def test_reason_dependency_chain(self, mock_api):
        """Verify atoms have correct depends_on links."""
        mock_api.side_effect = [
            {"room": "decompose-deps", "status": "active"},
            {"atom_id": "P1", "atom_type": "premise", "depth": 0, "session_status": "active"},
            {"atom_id": "R1", "atom_type": "reasoning", "depth": 1, "session_status": "active"},
            {"atom_id": "H1", "atom_type": "hypothesis", "depth": 2, "session_status": "active"},
            {"atom_id": "V1", "atom_type": "verification", "depth": 3, "session_status": "active"},
            {"atom_id": "C1", "atom_type": "conclusion", "depth": 4, "session_status": "completed",
             "best_conclusion": {"content": "Done", "confidence": 0.9}},
        ]

        client = PlatoClient(base_url="https://example.com/api/plato")
        WrappedAgent(MockAgent(), client).reason("test")

        # Check each atom call has correct depends_on
        for i, call in enumerate(mock_api.call_args_list[1:]):
            data = call[0][1] if len(call[0]) > 1 else call[1].get("data", {})
            if i == 0:  # premise — no depends_on
                assert "depends_on" not in data or data.get("depends_on") is None
            else:  # all others depend on previous
                assert "depends_on" in data
                assert len(data["depends_on"]) == 1
