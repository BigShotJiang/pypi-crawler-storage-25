"""
PLATO CLI — command-line interface for the Agent Training Platform.

Usage:
    plato explore                    # Interactive room explorer
    plato status                     # Fleet status
    plato rooms                      # List all rooms
    plato room <name>                # Get tiles in a room
    plato tile <domain> <q> <a>      # Submit a tile
    plato map                        # Show room map
    plato agents                     # List online agents
"""

import argparse
import json
import sys
import urllib.request
import urllib.error

DEFAULT_HOST = "147.224.38.131"
MUD_PORT = 4042
PLATO_PORT = 8847


def _url(path: str, port: int = PLATO_PORT) -> str:
    return f"http://{DEFAULT_HOST}:{port}{path}"


def _get(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "plato-cli/0.1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _post(url: str, data: dict) -> dict:
    body = json.dumps(data).encode()
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json", "User-Agent": "plato-cli/0.1.0"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def cmd_status(args):
    """Show fleet status."""
    try:
        status = _get(_url("/status", PLATO_PORT))
        print("🔮 PLATO Fleet Status")
        print(f"   Version: {status.get('version', 'unknown')}")
        gates = status.get("gate_stats", {})
        print(f"   Tiles accepted: {gates.get('accepted', '?')}")
        print(f"   Tiles rejected: {gates.get('rejected', '?')}")
        
        rooms = status.get("rooms", {})
        total_tiles = sum(r.get("tile_count", 0) for r in rooms.values())
        print(f"   Rooms: {len(rooms)}")
        print(f"   Total tiles: {total_tiles}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_rooms(args):
    """List all rooms."""
    try:
        data = _get(_url("/rooms", PLATO_PORT))
        rooms = data.get("rooms", data) if isinstance(data, dict) else data
        if isinstance(rooms, dict):
            items = sorted(rooms.items(), key=lambda x: x[1].get("tile_count", 0), reverse=True)
            print(f"🗺️  {len(items)} Rooms\n")
            for name, info in items[:30]:
                count = info.get("tile_count", 0) if isinstance(info, dict) else info
                bar = "█" * min(count, 40)
                print(f"  {name:40s} {count:4d} {bar}")
            if len(items) > 30:
                print(f"\n  ... and {len(items) - 30} more. Use 'plato room <name>' to explore.")
        else:
            print(f"🗺️  {len(rooms)} rooms returned")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_room(args):
    """Get tiles in a specific room."""
    try:
        data = _get(_url(f"/room/{args.name}", PLATO_PORT))
        tiles = data.get("tiles", [])
        room_name = data.get("room", args.name)
        print(f"📖 Room: {room_name} ({len(tiles)} tiles)\n")
        for i, tile in enumerate(tiles[:10], 1):
            q = tile.get("question", "?")
            a = tile.get("answer", "")
            src = tile.get("source", "?")
            conf = tile.get("confidence", 0)
            print(f"  {i}. [{conf:.0%}] {q}")
            print(f"     {a[:120]}{'...' if len(a) > 120 else ''}")
            print(f"     — {src}\n")
        if len(tiles) > 10:
            print(f"  ... and {len(tiles) - 10} more tiles.")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_explore(args):
    """Interactive room explorer."""
    agent = args.agent
    job = args.job
    print(f"🔮 PLATO Explorer — connecting as {agent} ({job})...\n")
    
    try:
        result = _get(_url(f"/connect?agent={agent}&job={job}", MUD_PORT))
        room = result.get("room", "harbor")
        desc = result.get("description", "")
        objects = result.get("objects", [])
        exits = result.get("exits", [])
        boot_camp = result.get("boot_camp", [])
        
        print(f"📍 {room.upper()}")
        print(f"   {desc[:200]}\n")
        if objects:
            print(f"   Objects: {', '.join(objects)}")
        if exits:
            print(f"   Exits: {', '.join(exits)}")
        if boot_camp:
            print(f"   Boot camp: {', '.join(boot_camp)}")
        
        print("\n   Commands: move <room>, examine <object>, look, map, quit")
        
        while True:
            try:
                cmd = input("\n> ").strip()
                if not cmd:
                    continue
                if cmd in ("quit", "exit", "q"):
                    print("Fair winds. 🌊")
                    break
                
                parts = cmd.split(maxsplit=1)
                action = parts[0].lower()
                arg = parts[1] if len(parts) > 1 else ""
                
                if action == "move" and arg:
                    result = _get(_url(f"/move?agent={agent}&room={arg}", MUD_PORT))
                    if "error" in result:
                        print(f"   ❌ {result['error']}")
                    else:
                        print(f"\n📍 {result.get('room', arg).upper()}")
                        print(f"   {result.get('description', '')[:200]}")
                        if result.get("objects"):
                            print(f"   Objects: {', '.join(result['objects'])}")
                        if result.get("exits"):
                            print(f"   Exits: {', '.join(result['exits'])}")
                
                elif action == "examine" and arg:
                    result = _get(_url(f"/examine?agent={agent}&target={arg}", MUD_PORT))
                    if "error" in result:
                        print(f"   ❌ {result['error']}")
                    else:
                        print(f"\n🔍 {arg}")
                        print(f"   {result.get('description', '')}")
                        if result.get("actions"):
                            print(f"   Actions: {', '.join(result['actions'])}")
                
                elif action == "look":
                    result = _get(_url(f"/look?agent={agent}", MUD_PORT))
                    print(f"\n📍 {result.get('room', '?').upper()}")
                    print(f"   {result.get('description', '')[:200]}")
                
                elif action == "map":
                    result = _get(_url("/map", MUD_PORT))
                    rooms = result.get("rooms", {})
                    print(f"\n🗺️  {len(rooms)} rooms:")
                    for rname, rinfo in rooms.items():
                        print(f"   {rname}")
                
                else:
                    print("   Commands: move <room>, examine <object>, look, map, quit")
            
            except EOFError:
                break
            except KeyboardInterrupt:
                print("\nFair winds. 🌊")
                break
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_tile(args):
    """Submit a knowledge tile."""
    try:
        result = _post(_url("/submit", PLATO_PORT), {
            "domain": args.domain,
            "question": args.question,
            "answer": args.answer,
            "source": args.agent,
            "confidence": args.confidence,
            "tags": args.tags.split(",") if args.tags else [],
        })
        if result.get("status") == "accepted":
            print(f"✅ Tile accepted! hash={result.get('tile_hash', '')[:16]}...")
            if result.get("achievement"):
                print(f"   🏆 {result['achievement']}")
        else:
            print(f"❌ {result.get('status')}: {result.get('reason', 'unknown')}")
            if result.get("suggestion"):
                print(f"   💡 {result['suggestion']}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_map(args):
    """Show the MUD room map."""
    try:
        result = _get(_url("/map", MUD_PORT))
        rooms = result.get("rooms", {})
        print(f"🗺️  MUD Map ({len(rooms)} rooms)\n")
        for name, info in rooms.items():
            desc = info.get("description", "")[:60] if isinstance(info, dict) else ""
            exits = info.get("exits", []) if isinstance(info, dict) else []
            exit_names = [e.get("room", e) if isinstance(e, dict) else e for e in exits]
            print(f"  {name}")
            if desc:
                print(f"    {desc}...")
            if exit_names:
                print(f"    → {', '.join(exit_names)}")
            print()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_agents(args):
    """List online agents."""
    try:
        result = _get(_url("/agents", MUD_PORT))
        agents = result.get("agents", [])
        if not agents:
            print("No agents currently online.")
        else:
            print(f"🤖 {len(agents)} Agents Online\n")
            for a in agents:
                print(f"  {a.get('name', '?'):20s} {a.get('job', '?'):10s} @ {a.get('room', '?')}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        prog="plato",
        description="PLATO CLI — The Agent Training Platform. Other frameworks build agents. PLATO raises them.",
    )
    sub = parser.add_subparsers(dest="command")
    
    # explore
    p_explore = sub.add_parser("explore", help="Interactive room explorer")
    p_explore.add_argument("--agent", default="cli-explorer")
    p_explore.add_argument("--job", default="scholar", choices=["scholar", "scout", "builder", "critic", "bard", "healer"])
    
    # status
    sub.add_parser("status", help="Fleet status")
    
    # rooms
    sub.add_parser("rooms", help="List all rooms")
    
    # room
    p_room = sub.add_parser("room", help="Get tiles in a room")
    p_room.add_argument("name")
    
    # tile
    p_tile = sub.add_parser("tile", help="Submit a knowledge tile")
    p_tile.add_argument("domain", help="Room/domain name")
    p_tile.add_argument("question", help="The question this answers")
    p_tile.add_argument("answer", help="The answer/knowledge")
    p_tile.add_argument("--agent", default="cli-user")
    p_tile.add_argument("--confidence", type=float, default=0.8)
    p_tile.add_argument("--tags", help="Comma-separated tags")
    
    # map
    sub.add_parser("map", help="Show MUD room map")
    
    # agents
    sub.add_parser("agents", help="List online agents")
    
    args = parser.parse_args()
    
    if args.command == "explore":
        cmd_explore(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "rooms":
        cmd_rooms(args)
    elif args.command == "room":
        cmd_room(args)
    elif args.command == "tile":
        cmd_tile(args)
    elif args.command == "map":
        cmd_map(args)
    elif args.command == "agents":
        cmd_agents(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
