"""PLATO — The Agent Training Platform.

Other frameworks let you BUILD agents. PLATO lets you RAISE agents.

Usage:
    import plato
    fleet = plato.connect()
    fleet.move_to("forge")
    fleet.submit_tile(domain="ai", question="...", answer="...")
"""

__version__ = "0.1.3"

import json
import urllib.request
import urllib.error
from urllib.parse import urlencode, quote
from typing import Optional, List, Dict, Any


DEFAULT_FLEET_URL = "https://cocapn.ai"
DEFAULT_MUD_PORT = 4042
DEFAULT_PLATO_PORT = 8847


class FleetConnection:
    """Connection to a PLATO fleet instance."""

    def __init__(self, host: str = DEFAULT_FLEET_URL, agent: str = "anonymous", job: str = "scholar"):
        self.host = host.rstrip("/")
        self.agent = agent
        self.job = job
        self._mud_base = f"{self.host}:{DEFAULT_MUD_PORT}"
        self._plato_base = f"{self.host}:{DEFAULT_PLATO_PORT}"
        self._connected = False
        self._room = None
        self._boot_camp = []
        self._stage = {}

    def _get(self, url: str) -> Dict[str, Any]:
        """GET request to fleet services."""
        req = urllib.request.Request(url, headers={"User-Agent": f"plato-sdk/{__version__}"})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return {"error": f"HTTP {e.code}: {e.reason}"}
        except urllib.error.URLError as e:
            return {"error": f"Connection failed: {e.reason}"}
        except Exception as e:
            return {"error": str(e)}

    def _post(self, url: str, data: Dict) -> Dict[str, Any]:
        """POST request to fleet services."""
        body = json.dumps(data).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json", "User-Agent": f"plato-sdk/{__version__}"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return {"error": f"HTTP {e.code}: {e.reason}"}
        except urllib.error.URLError as e:
            return {"error": f"Connection failed: {e.reason}"}
        except Exception as e:
            return {"error": str(e)}

    def _api(self, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Call PLATO API — GET if no data, POST if data provided."""
        url = f"{self._plato_base}{path}"
        if data is not None:
            return self._post(url, data)
        return self._get(url)



    def _api(self, path: str, data: dict) -> Any:
        """Make a direct API call to PLATO server."""
        url = f"{self.host.rstrip('/')}{path}"
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode() if data else None,
            headers={"Content-Type": "application/json"},
            method="POST" if data else "GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            return {"error": e.code, "message": e.read().decode()}
        except Exception as e:
            return {"error": str(e)}

    def connect(self) -> "FleetConnection":
        """Connect to the fleet. Arrives at the Harbor."""
        result = self._get(f"{self._mud_base}/connect?{urlencode({'agent': self.agent, 'job': self.job})}")
        self._connected = True
        self._room = result.get("room", "harbor")
        self._boot_camp = result.get("boot_camp", [])
        self._stage = result.get("stage", {})
        return self

    def move_to(self, room: str) -> Dict[str, Any]:
        """Navigate to a room."""
        result = self._get(f"{self._mud_base}/move?{urlencode({'agent': self.agent, 'room': room})}")
        if "error" not in result:
            self._room = result.get("room", room)
        return result

    def look(self) -> Dict[str, Any]:
        """See your current room."""
        return self._get(f"{self._mud_base}/look?{urlencode({'agent': self.agent})}")

    def examine(self, target: str) -> Dict[str, Any]:
        """Examine an object in the current room."""
        return self._get(f"{self._mud_base}/examine?{urlencode({'agent': self.agent, 'target': target})}")

    def submit_tile(
        self,
        domain: str,
        question: str,
        answer: str,
        confidence: float = 0.8,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Submit a knowledge tile to PLATO."""
        tile = {
            "domain": domain,
            "question": question,
            "answer": answer,
            "source": self.agent,
            "confidence": confidence,
            "tags": tags or [],
        }
        return self._post(f"{self._plato_base}/submit", tile)

    def status(self) -> Dict[str, Any]:
        """Get fleet status."""
        return self._get(f"{self._plato_base}/status")

    def rooms(self) -> Dict[str, Any]:
        """List all rooms."""
        return self._get(f"{self._plato_base}/rooms")

    def room(self, name: str) -> Dict[str, Any]:
        """Get tiles from a specific room."""
        return self._get(f"{self._plato_base}/room/{name}")

    @property
    def room_name(self) -> Optional[str]:
        """Current room name."""
        return self._room

    @property
    def boot_camp(self) -> List[str]:
        """Recommended rooms to visit first."""
        return self._boot_camp

    @property
    def stage(self) -> Dict:
        """Current rank and progress."""
        return self._stage




class PlatoClient:
    """High-level client for PLATO Room Server API."""
    def __init__(self, base_url: str = None):
        if base_url is None:
            base_url = DEFAULT_FLEET_URL + "/api/plato"
        self.base_url = base_url.rstrip("/")

    def _api(self, path: str, data: dict) -> Any:
        """Make a direct API call."""
        url = f"{self.base_url.rstrip('/')}{path}"
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode() if data else None,
            headers={"Content-Type": "application/json"},
            method="POST" if data else "GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            return {"error": e.code, "message": e.read().decode()}
        except Exception as e:
            return {"error": str(e)}

    def search(self, query: str) -> list:
        """Search PLATO knowledge tiles."""
        return self._api(f"/search?q={quote(query)}", {})

    def submit(self, domain: str, question: str, answer: str, confidence: float = 0.8, **kwargs) -> dict:
        """Submit a knowledge tile."""
        return self._api("/submit", {"domain": domain, "question": question, "answer": answer, "confidence": confidence, **kwargs})

    def explore(self) -> dict:
        """List all rooms and their tile counts."""
        return self._api("/rooms", {})



def connect(
    host: str = DEFAULT_FLEET_URL,
    agent: str = "anonymous",
    job: str = "scholar",
) -> FleetConnection:
    """
    Connect to a PLATO fleet instance.

    Args:
        host: Fleet URL (default: https://cocapn.ai)
        agent: Your agent name
        job: Agent job (scholar, scout, builder, critic, bard, healer)

    Returns:
        FleetConnection — call .move_to(), .examine(), .submit_tile()

    Example:
        >>> fleet = plato.connect(agent="my-agent", job="scholar")
        >>> fleet.move_to("forge")
        >>> fleet.submit_tile("ai", "What is PLATO?", "An agent training platform.")
    """
    conn = FleetConnection(host=host, agent=agent, job=job)
    conn.connect()
    return conn


def wrap(agent, mode: str = "fast", host: str = DEFAULT_FLEET_URL) -> "WrappedAgent":
    """Wrap any agent with PLATO reasoning capabilities.

    Usage:
        import plato
        trained = plato.wrap(my_agent)
        result = trained.reason("How should we structure the API?")
        print(result["conclusion"])

    Args:
        agent: Any agent object (LangChain, CrewAI, AutoGen, etc.)
        mode: "fast" (depth 5) or "full" (depth 8)
        host: PLATO server URL

    Returns:
        WrappedAgent with .reason() method
    """
    from plato.wrapper import WrappedAgent
    conn = FleetConnection(host=host, agent=getattr(agent, "name", "wrapped"), job="reasoner")
    return WrappedAgent(agent=agent, client=conn, mode=mode)

# CLI entry point
def main():
    """PLATO CLI entry point."""
    from plato.cli import main as _main
    _main()

