"""plato.wrap(agent) — Turn any agent into a PLATO-trained agent.

Usage:
    from plato import PlatoClient

    plato = PlatoClient()
    trained = plato.wrap(my_agent)
    result = trained.reason("How should we structure the microservices?")
"""
import json
import urllib.request
from typing import Any, Callable, Dict, List, Optional


# Default prompts for each atom type
ATOM_PROMPTS = {
    "premise": "Given this question, state the key premise(s) and established facts. Be concise.",
    "reasoning": "Based on the premise, apply logical reasoning step by step. Identify assumptions and implications.",
    "hypothesis": "From the reasoning, propose a specific, testable hypothesis or approach.",
    "verification": "Verify the hypothesis. Check for logical consistency, edge cases, and potential failures.",
    "conclusion": "State a verified conclusion with confidence level. If the verification found issues, note them.",
}


class WrappedAgent:
    """An agent wrapped with PLATO reasoning capabilities.

    The wrapper doesn't modify the original agent. Instead, it:
    1. Creates a PLATO decomposition session
    2. Calls the reasoning_fn (or the agent's LLM) for each atom
    3. Persists the full chain as PLATO tiles
    4. Returns the best conclusion
    """

    def __init__(
        self,
        agent: Any,
        client: "PlatoClient",
        mode: str = "fast",
        reasoning_fn: Optional[Callable] = None,
        llm_url: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_api_key: Optional[str] = None,
    ):
        self.agent = agent
        self.client = client
        self.mode = mode
        self.reasoning_fn = reasoning_fn
        self.llm_url = llm_url
        self.llm_model = llm_model
        self.llm_api_key = llm_api_key
        self.sessions: List[Dict] = []

    def reason(self, query: str, context: Optional[str] = None) -> Dict:
        """Run a structured reasoning chain through PLATO.

        Args:
            query: The question or problem to reason about.
            context: Optional additional context.

        Returns:
            Dict with conclusion, confidence, room, and full chain.
        """
        session = self.client._api("/decompose", {
            "mode": self.mode,
            "agent": getattr(self.agent, "name", "wrapped-agent"),
        })
        room = session["room"]

        chain = []
        conclusion = None
        prev_id = None

        for i, atom_type in enumerate(["premise", "reasoning", "hypothesis", "verification", "conclusion"]):
            atom_id = f"{atom_type[0].upper()}{i+1}"

            # Generate content using LLM, reasoning_fn, or template fallback
            content = self._generate_atom(query, context, atom_type, chain)

            # Build atom payload
            atom_data = {
                "atom_id": atom_id,
                "content": content,
                "atom_type": atom_type,
                "confidence": 0.85,
            }
            if prev_id:
                atom_data["depends_on"] = [prev_id]
            if atom_type == "conclusion":
                atom_data["is_verified"] = True
                atom_data["confidence"] = 0.92

            result = self.client._api(f"/decompose/{room}/atom", {
                **atom_data,
                "agent": getattr(self.agent, "name", "wrapped-agent"),
            })
            chain.append(result)
            prev_id = atom_id

            if result.get("best_conclusion"):
                conclusion = result["best_conclusion"]
                break

        self.sessions.append({
            "room": room,
            "query": query,
            "chain": chain,
            "conclusion": conclusion,
        })

        return {
            "query": query,
            "conclusion": conclusion,
            "room": room,
            "chain_length": len(chain),
            "status": chain[-1].get("session_status", "active") if chain else "active",
        }

    def _generate_atom(
        self,
        query: str,
        context: Optional[str],
        atom_type: str,
        previous_chain: List[Dict],
    ) -> str:
        """Generate atom content using available methods.

        Priority: reasoning_fn > LLM API > template scaffold
        """
        # Method 1: Custom reasoning function
        if self.reasoning_fn:
            return self.reasoning_fn(query, context, atom_type, previous_chain)

        # Method 2: LLM API call
        if self.llm_url:
            return self._llm_generate(query, context, atom_type, previous_chain)

        # Method 3: Template scaffold (fallback)
        return self._template_generate(query, context, atom_type)

    def _llm_generate(
        self,
        query: str,
        context: Optional[str],
        atom_type: str,
        previous_chain: List[Dict],
    ) -> str:
        """Call an OpenAI-compatible LLM API to generate atom content."""
        system = f"You are a structured reasoning engine. Generate a {atom_type} for the following query."
        prompt = ATOM_PROMPTS[atom_type]
        
        # Build context from previous chain
        chain_text = ""
        if previous_chain:
            chain_text = "\n\nPrevious reasoning chain:\n"
            for atom in previous_chain:
                chain_text += f"- [{atom.get('atom_type','?').upper()}] {atom.get('content','')}\n"

        user_msg = f"Query: {query}\n{f'Context: {context}' if context else ''}\n{prompt}{chain_text}"

        payload = {
            "model": self.llm_model or "deepseek-v4-flash",
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_msg},
            ],
            "max_tokens": 500,
            "temperature": 0.3,
        }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.llm_api_key}",
        }

        req = urllib.request.Request(
            self.llm_url,
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
                return result["choices"][0]["message"]["content"].strip()
        except Exception as e:
            return f"[LLM error: {e}] {self._template_generate(query, context, atom_type)}"

    def _template_generate(
        self,
        query: str,
        context: Optional[str],
        atom_type: str,
    ) -> str:
        """Template-based scaffold for when no LLM is available."""
        templates = {
            "premise": context or f"Key premises and established facts regarding: {query}",
            "reasoning": f"Step-by-step analysis of: {query}",
            "hypothesis": f"Proposed approach for: {query}",
            "verification": f"Verification and edge-case analysis for: {query}",
            "conclusion": f"Verified conclusion for: {query}",
        }
        return templates[atom_type]

    def get_history(self) -> List[Dict]:
        """Return all reasoning sessions for this wrapped agent."""
        return self.sessions
