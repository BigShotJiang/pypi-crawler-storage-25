"""
This module implements an SSH server done using
paramiko as the SSH connection library.
"""

import io
import logging
from pathlib import Path
import socket
import threading
import time
from typing import Any

import paramiko
import paramiko.rsakey

from simnos.core.nos import Nos
from simnos.core.servers import _SHUTDOWN_TIMEOUT, TCPServerBase
from simnos.plugins.servers.tap_io import TapIO, process_tap_line

log = logging.getLogger(__name__)

# DH Group Exchange algorithms to disable when server moduli are unavailable.
# Workaround for Paramiko server-mode bug where GEX algorithms are advertised
# in KEXINIT despite the server being unable to handle them without moduli,
# causing MessageOrderError when a client selects GEX.
_DISABLED_GEX_ALGORITHMS = {
    "kex": [
        "diffie-hellman-group-exchange-sha256",
        "diffie-hellman-group-exchange-sha1",
    ]
}

# Path to bundled moduli file (concatenated 2048 + 3072-bit primes).
# Used as fallback when no system moduli (e.g. /etc/ssh/moduli) is available
# — typically on Windows / macOS hosts. 4096-bit primes are not bundled;
# see docs/development/regenerate_moduli.md for the rotation procedure and
# rationale.
_BUNDLED_MODULI = Path(__file__).parent / "moduli"


class ParamikoSshServerInterface(paramiko.ServerInterface):
    """
    Class to implement the SSH server interface
    using paramiko as the SSH connection library.
    """

    def __init__(
        self,
        ssh_banner: str = "SIMNOS Paramiko SSH Server",
        username: str | None = None,
        password: str | None = None,
        allow_auth_none: bool = False,
        authorized_keys: set[tuple[str, str]] | None = None,
    ):
        self.ssh_banner = ssh_banner
        self.username = username
        self.password = password
        self.allow_auth_none = allow_auth_none
        self.authorized_keys = authorized_keys
        self.auth_method_used: str | None = None

    def check_channel_request(self, kind, chanid):
        """
        This will allow the SSH server to provide a channel for the client
        to communicate over. By default, this will return
        OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED, so we have to override it
        to return OPEN_SUCCEEDED when the kind of channel
        requested is "session".
        """
        if kind == "session":
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_channel_pty_request(self, channel, term, width, height, pixelwidth, pixelheight, modes):
        """
        AFAIK, pty (pseudo-tty (TeleTYpewriter))
        will allow our client to interact with our shell.
        """
        return True

    def check_channel_shell_request(self, channel):
        """
        This allows us to provide the channel
        with a shell we can connect to it.
        """
        return True

    def get_allowed_auths(self, username):
        """Return the authentication methods supported by this server."""
        methods = "password,keyboard-interactive"
        if self.authorized_keys:
            methods = "publickey," + methods
        if self.allow_auth_none:
            methods = "none," + methods
        return methods

    def check_auth_none(self, username):
        """Allow auth_none if configured (e.g. for Dell PowerConnect)."""
        if self.allow_auth_none:
            self.auth_method_used = "none"
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_auth_publickey(self, username, key):
        """Validate public key authentication."""
        if not self.authorized_keys:
            return paramiko.AUTH_FAILED
        if not self._match_username(username):
            return paramiko.AUTH_FAILED
        if (key.get_name(), key.get_base64()) in self.authorized_keys:
            self.auth_method_used = "publickey"
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def _match_username(self, username: str) -> bool:
        """Check whether *username* matches the configured username.

        Tries an exact match first.  If that fails, strips a MikroTik-style
        ``+`` suffix (e.g. ``admin+ct511w4098h``) and retries so that
        usernames containing ``+`` as a legitimate character are never
        falsely truncated.
        """
        if username == self.username:
            return True
        base, sep, _ = username.partition("+")
        return bool(sep) and base == self.username

    def check_auth_password(self, username, password):
        """Validate username/password for standard password authentication."""
        if self._match_username(username) and (password == self.password):
            self.auth_method_used = "password"
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_auth_interactive(self, username, submethods):
        """Begin keyboard-interactive authentication by sending a password prompt."""
        if self._match_username(username):
            query = paramiko.InteractiveQuery()
            query.add_prompt("Password: ", echo=False)
            return query
        return paramiko.AUTH_FAILED

    def check_auth_interactive_response(self, responses):
        """Validate the password response from keyboard-interactive authentication."""
        if len(responses) == 1 and responses[0] == self.password:
            self.auth_method_used = "keyboard-interactive"
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def get_banner(self):
        """
        String that will display when a client connects,
        before authentication has happened. This is different
        than the shell's intro property, which is displayed
        after the authentication.
        """
        return (self.ssh_banner + "\r\n", "en-US")


def channel_to_shell_tap(
    channel: paramiko.Channel,
    shell_stdin: TapIO,
    shell_replied_event: threading.Event,
    run_srv: threading.Event,
    *,
    initial_skip_lf: bool = False,
    shell_stdout: TapIO | None = None,
) -> None:
    """Read bytes from SSH channel and forward complete lines to shell stdin.

    When *shell_stdout* is provided, the newline echo (``\\r\\n``) for
    line-ending bytes is written to *shell_stdout* instead of being sent
    directly to the channel.  ``shell_to_channel_tap`` then batches the
    echo together with the shell's response into a single ``sendall()``,
    preventing a GIL-scheduling race where the client reads the echo and
    the prompt as separate SSH packets (#87).
    """
    buffer: io.BytesIO = io.BytesIO()
    skip_lf = initial_skip_lf
    while run_srv.is_set():
        try:
            byte: bytes = channel.recv(1)
        except TimeoutError:
            continue
        except (OSError, EOFError, paramiko.SSHException):
            log.debug("ssh_server.channel_to_shell_tap channel read closed")
            break
        log.debug("ssh_server.channel_to_shell_tap received from channel: %s", [byte])

        # EOF / channel closed
        if byte in (b"", None):
            break

        # Drop NUL bytes completely (don't echo, don't buffer).
        # Unlike Telnet (RFC 854), SSH has no CR NUL convention,
        # so skip_lf is intentionally preserved across NUL bytes.
        if byte == b"\x00":
            continue

        # Consume the LF half of a CR LF pair.
        if skip_lf:
            skip_lf = False
            if byte == b"\n":
                continue

        # Wait for the shell to reply, but check run_srv periodically
        # so that shutdown is not blocked for the full wait duration.
        while not shell_replied_event.wait(timeout=_SHUTDOWN_TIMEOUT):
            if not run_srv.is_set():
                break
        if not run_srv.is_set():
            break
        if not channel.active:
            log.error("SSH channel is not active. Exiting.")
            break
        try:
            if byte in (b"\r", b"\n"):
                skip_lf = byte == b"\r"
                if shell_stdout is not None:
                    shell_stdout.write("\r\n")
                else:
                    channel.sendall(b"\r\n")
                log.debug(
                    "ssh_server.channel_to_shell_tap echoing new line to channel: %s",
                    [b"\r\n"],
                )
                buffer.write(byte)
                buffer.seek(0)
                line = buffer.read().decode(encoding="utf-8")
                buffer.seek(0)
                buffer.truncate()
                log.debug("ssh_server.channel_to_shell_tap sending line to shell: %s", [line])
                shell_stdin.write(line)
                shell_replied_event.clear()
            else:
                channel.sendall(byte)
                log.debug(
                    "ssh_server.channel_to_shell_tap echoing byte to channel: %s",
                    [byte],
                )
                buffer.write(byte)
        except (OSError, EOFError, paramiko.SSHException) as e:
            log.error("ssh_server.channel_to_shell_tap channel write error: %s", e)
            break

    run_srv.clear()


def shell_to_channel_tap(
    channel: paramiko.Channel,
    shell_stdout: TapIO,
    shell_replied_event: threading.Event,
    run_srv: threading.Event,
) -> None:
    """Read lines from shell stdout and send them to the SSH channel.

    After reading the first available line, a brief coalescing pause
    (1 ms) allows the shell to enqueue additional output (e.g. a prompt
    following a newline echo).  All available lines are then sent in a
    single ``sendall()`` call so the client receives them in one SSH
    packet, avoiding a GIL-scheduling race in paramiko (#87).

    When the first line is whitespace-only (a newline echo from
    ``channel_to_shell_tap``), the function blocks on a second
    ``readline()`` instead of sending the echo alone.  This guarantees
    the echo and the prompt that follows it are always delivered in the
    same ``sendall()`` call, even when the shell is slow (e.g. hot
    reload YAML re-parse in ``precmd()``).
    """
    while run_srv.is_set():
        if channel.closed:
            break
        line = shell_stdout.readline()
        if not line:
            break

        # Coalesce: brief pause lets the shell enqueue the prompt
        # after the newline echo, so both are sent in one packet.
        time.sleep(0.001)

        batch = process_tap_line(line)
        drained = shell_stdout.drain()

        if not drained and batch.strip() == "":
            # Echo-only batch (e.g. "\r\n") with nothing else queued.
            # The shell hasn't produced the prompt yet — block until it
            # does so we never send a bare echo as a separate packet.
            next_line = shell_stdout.readline()
            if next_line:
                batch += process_tap_line(next_line)
                # Drain any extra items that arrived alongside the prompt.
                time.sleep(0.001)
                drained = shell_stdout.drain()

        for extra in drained:
            # Separate consecutive lines that don't end with a newline
            # (e.g. prompts: "SimNOS>") so they aren't concatenated into
            # "SimNOS>SimNOS>..." which breaks netmiko's find_prompt().
            if batch and not batch.endswith("\n"):
                batch += "\r\n"
            batch += process_tap_line(extra)

        log.debug("ssh_server.shell_to_channel_tap sending batch to channel %s", [batch])
        written = False
        while run_srv.is_set() and not written:
            try:
                channel.sendall(batch.encode(encoding="utf-8"))
                written = True
            except TimeoutError:
                log.debug("ssh_server.shell_to_channel_tap write timeout, retrying")
                continue
            except (OSError, EOFError, paramiko.SSHException) as e:
                log.error("ssh_server.shell_to_channel_tap channel write error: %s", e)
                break
        if not written:
            break
        shell_replied_event.set()

    run_srv.clear()


class ParamikoSshServer(TCPServerBase):
    """
    Class to implement an SSH server using paramiko
    as the SSH connection library.
    """

    _moduli_loaded: bool | None = None
    _moduli_lock: threading.Lock = threading.Lock()
    _default_key: paramiko.rsakey.RSAKey | None = None
    _default_key_lock: threading.Lock = threading.Lock()
    _KNOWN_KEY_TYPES = (
        "ssh-rsa",
        "ssh-ed25519",
        "ssh-dss",
        "ecdsa-sha2-",
        "sk-ssh-ed25519",
        "sk-ecdsa-sha2-",
    )

    def __init__(
        self,
        shell: type,
        nos: Nos,
        nos_inventory_config: dict,
        port: int,
        username: str,
        password: str,
        ssh_key_file: str | None = None,
        ssh_key_file_password: str | None = None,
        ssh_banner: str = "SIMNOS Paramiko SSH Server",
        shell_configuration: dict | None = None,
        address: str = "127.0.0.1",
        timeout: int = 1,
        watchdog_interval: float = 1,
        authorized_keys: str | None = None,
    ):
        super().__init__(address=address, port=port, timeout=timeout)

        self.nos: Nos = nos
        self.nos_inventory_config: dict = nos_inventory_config
        self.shell: type = shell
        self.shell_configuration: dict = shell_configuration or {}
        self.ssh_banner: str = ssh_banner
        self.username: str = username
        self.password: str = password
        self.watchdog_interval: float = watchdog_interval
        self._authorized_keys = self._load_authorized_keys(authorized_keys) if authorized_keys else None

        if ssh_key_file:
            self._ssh_server_key: paramiko.rsakey.RSAKey = paramiko.RSAKey.from_private_key_file(
                ssh_key_file, ssh_key_file_password
            )
        else:
            with ParamikoSshServer._default_key_lock:
                if ParamikoSshServer._default_key is None:
                    ParamikoSshServer._default_key = paramiko.RSAKey.generate(2048)
            self._ssh_server_key = ParamikoSshServer._default_key
            log.warning(
                "Using auto-generated SSH host key. This key is not persisted and "
                "will change on restart. Provide a custom key via ssh_key_file "
                "for non-local use."
            )

        # Load SSH moduli once for DH Group Exchange (GEX) support in server mode.
        # Prefer system moduli (live, distro-rotated) when available; fall back to
        # the moduli file bundled with the package on hosts without /etc/ssh/moduli
        # (Windows / macOS). Result is cached at the class level under a lock.
        #
        # `_moduli_lock` only serializes SIMNOS-internal init; the underlying
        # `paramiko.Transport._modulus_pack` is a paramiko-global state and is
        # not lockable from here. If another thread loads moduli via paramiko
        # directly (outside SIMNOS), it can still race. Mirrors the
        # `_default_key_lock` pattern in scope, not in coverage.
        with ParamikoSshServer._moduli_lock:
            if ParamikoSshServer._moduli_loaded is None:
                ok = paramiko.Transport.load_server_moduli()
                if not ok:
                    # `is_file()` returns False for missing path, directory, or
                    # broken symlink. The latter two are extreme edge cases for
                    # a package-bundled file; treating them as "missing" is fine.
                    if _BUNDLED_MODULI.is_file():
                        ok = paramiko.Transport.load_server_moduli(filename=str(_BUNDLED_MODULI))
                        if not ok:
                            log.error(
                                "Bundled moduli at %s exists but failed to load "
                                "(possibly corrupted or unreadable). Falling back "
                                "to GEX-disable workaround.",
                                _BUNDLED_MODULI,
                            )
                    else:
                        log.error(
                            "Bundled moduli file missing at %s — falling back to "
                            "GEX-disable workaround. This indicates a packaging "
                            "regression, please report.",
                            _BUNDLED_MODULI,
                        )
                ParamikoSshServer._moduli_loaded = ok

    @staticmethod
    def _load_authorized_keys(path: str) -> set[tuple[str, str]]:
        """Parse an OpenSSH authorized_keys file.

        Supports bare key lines and lines with leading options.
        Skips comment lines, blank lines, and @marker lines.
        File not found / permission errors propagate as-is (fail-fast).

        Returns a set of (key_type, base64_data) tuples.
        """
        keys: set[tuple[str, str]] = set()
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("@"):
                    log.warning("Skipping unsupported marker line: %s", line)
                    continue
                parts = line.split()
                for i, part in enumerate(parts):
                    if any(part.startswith(prefix) for prefix in ParamikoSshServer._KNOWN_KEY_TYPES):
                        if i + 1 < len(parts):
                            keys.add((part, parts[i + 1]))
                        else:
                            log.warning("Key type found but base64 data missing, skipping line: %s", line)
                        break
                else:
                    log.warning("No known key type found, skipping line: %s", line)
        return keys

    def watchdog(
        self,
        is_running: threading.Event,
        run_srv: threading.Event,
        session: paramiko.Transport,
        shell: Any,
    ):
        """
        Method to monitor server liveness and recover where possible.
        """
        while run_srv.is_set():
            if not session.is_alive():
                log.warning("ParamikoSshServer.watchdog - session not alive, stopping shell")
                break

            if not is_running.is_set():
                break

            time.sleep(min(self.watchdog_interval, _SHUTDOWN_TIMEOUT))

        shell.stop()

    def _read_channel_line(
        self,
        channel,
        echo: bool = True,
        skip_lf: bool = False,
    ) -> tuple[str, bool]:
        """
        Read a single line from the channel byte-by-byte.

        :param channel: paramiko Channel
        :param echo: if True, echo each byte back to the client
        :param skip_lf: if True, consume a leading LF left over from a previous CR
        :return: (line without trailing CR/LF, whether next call should skip LF)
        """
        channel.settimeout(self.timeout)
        buf = b""
        while True:
            try:
                byte = channel.recv(1)
            except TimeoutError:
                continue
            except (OSError, EOFError, paramiko.SSHException):
                break
            if byte in (b"", None):
                break
            if skip_lf:
                skip_lf = False
                if byte == b"\n":
                    continue
            if byte == b"\r":
                if echo:
                    channel.sendall(b"\r\n")
                return buf.decode("utf-8", errors="replace"), True
            if byte == b"\n":
                if echo:
                    channel.sendall(b"\r\n")
                return buf.decode("utf-8", errors="replace"), False
            if echo:
                channel.sendall(byte)
            buf += byte
        return buf.decode("utf-8", errors="replace"), False

    def _channel_login(self, channel) -> tuple[bool, bool]:
        """
        Perform channel-level login for auth_none platforms (e.g. Dell PowerConnect).

        Sends "User Name:" / "Password:" prompts and validates credentials.

        :param channel: paramiko Channel
        :return: (authenticated, skip_lf) — skip_lf should be forwarded to
                 channel_to_shell_tap so it can consume a trailing LF after
                 the final CR of the password line.
        """
        channel.sendall(b"\r\nUser Name:")
        username, skip_lf = self._read_channel_line(channel, echo=True, skip_lf=False)
        channel.sendall(b"\r\nPassword:")
        password, skip_lf = self._read_channel_line(channel, echo=False, skip_lf=skip_lf)
        channel.sendall(b"\r\n")

        if username == self.username and password == self.password:
            log.debug("Channel login succeeded for user %s", username)
            return True, skip_lf

        log.warning("Channel login failed for user %s", username)
        return False, skip_lf

    def connection_function(self, client: socket.socket, is_running: threading.Event):
        shell_replied_event = threading.Event()
        run_srv = threading.Event()
        run_srv.set()

        # determine if this NOS requires auth_none
        allow_auth_none = getattr(self.nos, "auth", None) == "none"

        # create the SSH transport object
        session = paramiko.Transport(client)
        if not ParamikoSshServer._moduli_loaded:
            session.disabled_algorithms = _DISABLED_GEX_ALGORITHMS
        session.add_server_key(self._ssh_server_key)
        session.banner_timeout = _SHUTDOWN_TIMEOUT
        session.handshake_timeout = _SHUTDOWN_TIMEOUT

        try:
            # create the server
            server = ParamikoSshServerInterface(
                ssh_banner=self.ssh_banner,
                username=self.username,
                password=self.password,
                allow_auth_none=allow_auth_none,
                authorized_keys=self._authorized_keys,
            )

            # start the SSH server — may raise SSHException if the client
            # disconnects during handshake or if stop() races with accept.
            try:
                session.start_server(server=server)
            except paramiko.SSHException as e:
                log.debug("SSH handshake failed (likely client disconnect or stop): %s", e)
                return

            # wait for the client to open a channel
            channel = None
            while channel is None and is_running.is_set() and session.is_alive():
                channel = session.accept(_SHUTDOWN_TIMEOUT)
            if channel is None:
                log.warning("session.accept() returned None or server stopping, closing transport")
                return

            # For auth_none platforms (e.g. Dell PowerConnect), perform channel-level
            # login before starting the shell.  When publickey auth is also configured,
            # clients that authenticate via publickey bypass this channel-level login
            # intentionally — SSH-level publickey auth already verified the identity.
            skip_lf = False
            if server.auth_method_used == "none":
                authenticated, skip_lf = self._channel_login(channel)
                if not authenticated:
                    log.warning("Channel login failed, closing connection")
                    return

            channel.settimeout(self.timeout)

            # create stdio for the shell
            shell_stdin, shell_stdout = TapIO(run_srv), TapIO(run_srv)

            # start intermediate thread to tap into
            # the channel->shell_stdin bytes stream
            channel_to_shell_tapper = threading.Thread(
                target=channel_to_shell_tap,
                args=(channel, shell_stdin, shell_replied_event, run_srv),
                kwargs={"initial_skip_lf": skip_lf, "shell_stdout": shell_stdout},
                daemon=True,
            )
            channel_to_shell_tapper.start()

            # start intermediate thread to tap into
            # the shell_stdout->channel bytes stream
            shell_to_channel_tapper = threading.Thread(
                target=shell_to_channel_tap,
                args=(channel, shell_stdout, shell_replied_event, run_srv),
                daemon=True,
            )
            shell_to_channel_tapper.start()

            # create the client shell
            client_shell = self.shell(
                stdin=shell_stdin,
                stdout=shell_stdout,
                nos=self.nos,
                nos_inventory_config=self.nos_inventory_config,
                is_running=is_running,
                **self.shell_configuration,
            )

            # start watchdog thread
            watchdog_thread = threading.Thread(
                target=self.watchdog, args=(is_running, run_srv, session, client_shell), daemon=True
            )
            watchdog_thread.start()

            # running this command will block this function until shell exits
            client_shell.start()
            log.debug("ParamikoSshServer.connection_function stopped shell thread")

        finally:
            # Stop all server threads
            run_srv.clear()
            log.debug("ParamikoSshServer.connection_function stopped server threads")

            session.close()
            log.debug("ParamikoSshServer.connection_function closed transport %s", session)
