---
name: Consumer Agent: Explain
intent: EXPLAIN
description: user asks how a feature is calculated, computed, or what logic produces it
argument-hint: [feature name]
allowed-tools: Read, Grep, Glob
---

Explain how a feature is calculated by fetching the process view DDL and having the LLM translate the SQL logic into plain business language, with an optional formula and a per-column source map.

## Queries

1. `get_list_entity()` → `get_feature_versions()` → process catalog to resolve VIEW_NAME
2. `SHOW VIEW "{schema}"."{view_name}"` — retrieves the full SQL DDL of the process view
3. LLM (structured output via `ExplainOutput` Pydantic model) — translates DDL to business explanation + extracts formula and source columns

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature name |
| `process_view` | str | Process view name whose DDL was analysed |
| `explanation` | str | Plain business-language explanation (max 6 sentences, no SQL jargon) |
| `calculation_sql` | str | SQL expression extracted from the SELECT list (drills through subquery nesting) |
| `calculation_latex` | str | LaTeX formula — populated only when the user explicitly asked for one |
| `source_columns` | list | `{column_name, source_table}` for each column in the formula |
| `process_view_sql` | str | Full DDL — included only when the user asked for the SQL/code |
| `docs_sources` | list | Sources consulted |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` |

## Notes

- `source_columns` is written into `resolved_column_sources` by the graph node so that a follow-up "what is `<col>`?" question can drill into the DEFINITION skill for that specific column.
- This skill answers "how is this computed?" — for upstream data dependencies, use the LINEAGE skill.
