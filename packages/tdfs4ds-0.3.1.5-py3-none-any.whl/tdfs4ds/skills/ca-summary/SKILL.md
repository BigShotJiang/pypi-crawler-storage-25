---
name: Consumer Agent: Summary
intent: SUMMARY
description: user asks for an overview of available features for a domain
argument-hint: [data domain (optional)]
allowed-tools: Read, Grep, Glob
---

Return a high-level inventory of all features available in the active data domain, grouped by entity and annotated with themes from the business dictionary.

## Queries

- `get_list_entity()` + `get_available_features()` — full feature catalog for the DATA_DOMAIN
- `FS_BUSINESS_DICTIONARY_SECTIONS` (FEATURE_THEMES, OVERVIEW) — thematic documentation
- `FS_BUSINESS_DICTIONARY_OBJECTS` — object-level descriptions

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `domain` | str | DATA_DOMAIN filter applied (or `'all'`) |
| `total_features` | int | Total feature count |
| `by_granularity` | dict | `{entity_name: count}` |
| `feature_names` | list | All feature names |
| `feature_names_by_entity` | dict | `{entity_name: [feature_name, ...]}` |
| `themes_summary` | str | LLM-generated overview of available features by theme |
| `docs_sources` | list | Sources consulted |

## Notes

- Themes come from `FEATURE_THEMES` sections written by `document_dataset_incremental` or manually uploaded via `upload_business_dictionary_sections`.
- `feature_names_by_entity` is persisted across turns (`resolved_entity_name`, `resolved_feature_list`) to enable follow-up questions without re-specifying the domain.
