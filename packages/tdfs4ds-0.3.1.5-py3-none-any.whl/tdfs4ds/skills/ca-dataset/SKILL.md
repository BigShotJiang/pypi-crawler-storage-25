---
name: Consumer Agent: Dataset
intent: DATASET
description: user asks whether a feature is available in a dataset, or which dataset exposes it
argument-hint: [feature name]
allowed-tools: Read, Grep, Glob
---

Look up which datasets expose a given feature, or guide the user through a 4-step flow to create a new dataset if none exists yet.

## Queries (step 0 — initial lookup)

- `feature_catalog()` → `dataset_catalog()` — finds datasets that include the requested feature
- `get_dataset_features()` — feature versions per dataset view

## 4-step creation flow

When no dataset is found, the skill enters a multi-turn flow:

| Step | `pending_action` | What happens |
|------|-----------------|--------------|
| 0 | — | Lookup; if no dataset → propose creation |
| 1 | `awaiting_feature_selection` | LLM proposes top-20 relevant features for the use case |
| 2 | `awaiting_feature_confirmation` | User confirms or requests all features |
| 3 | `awaiting_dataset_name` | User provides a name; `skill_check_dataset_name` validates it |

## Returns (step 0)

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature name |
| `datasets` | list | Datasets that expose the feature `{view_name, entity_name, comment}` |
| `status` | str | `'found'` or `'no_dataset'` |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` |
| `docs_sources` | list | Sources consulted |

## Notes

- The dataset creation flow is orchestrated by the graph node (`node_skill_dataset`), not by this skill function directly.
- After a successful name check (`status: name_available`), the proposed features and selection context are passed to the caller for downstream `build_dataset` code generation.
