---
name: Consumer Agent: Definition
intent: DEFINITION
description: user asks what a specific feature or dataset means
argument-hint: [feature or dataset name]
allowed-tools: Read, Grep, Glob
---

Explain what a specific feature, column, or dataset is in plain business language, by resolving it through the feature catalog and business dictionary.

## Queries

Resolution chain (in order, falling back at each step):

1. `get_list_entity()` → `get_list_features(entity)` → `get_feature_versions(entity, features)` → process catalog → `FS_BUSINESS_DICTIONARY_COLUMNS` (column doc on the process view)
2. `FS_BUSINESS_DICTIONARY_COLUMNS` — direct column lookup (for non-feature columns); uses `hint_table_name` from a prior EXPLAIN turn when available
3. `FS_BUSINESS_DICTIONARY_OBJECTS` + `FS_BUSINESS_DICTIONARY_SECTIONS` — dataset or view-level descriptions
4. Vector index — semantic fallback

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Resolved name (may differ from input if fuzzy-matched) |
| `explanation` | str | Plain business-language definition |
| `columns` | list | Related columns `{name, table, description}` |
| `docs_sources` | list | Sources consulted |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` when resolved |

## Notes

- `hint_entity_name` (from a prior turn) auto-disambiguates features that exist under multiple entities without prompting the user.
- `hint_table_name` (from a prior EXPLAIN turn) narrows the BD_COLUMNS lookup for column references found in a formula.
