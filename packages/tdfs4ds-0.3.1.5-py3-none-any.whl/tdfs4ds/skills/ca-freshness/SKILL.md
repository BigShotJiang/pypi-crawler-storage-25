---
name: Consumer Agent: Freshness
intent: FRESHNESS
description: user asks whether a feature/dataset is up to date or reliable
argument-hint: [feature or dataset name]
allowed-tools: Read, Grep, Glob
---

Check whether a feature or dataset is current and reliable by inspecting the execution history of its registered process.

## Queries

1. `get_list_entity()` → `get_feature_versions()` → process catalog to resolve PROCESS_ID
2. `follow_up_report(process_id)` — execution history; STATUS = `'COMPLETED'` for last successful run, `'FAILED,...'` for recent failures
3. `FS_BUSINESS_DICTIONARY_SECTIONS` (OVERVIEW) — process context

## Returns

| Key | Type | Description |
|-----|------|-------------|
| `object_name` | str | Feature or dataset name |
| `last_successful_run` | str | Timestamp of last COMPLETED execution |
| `days_since_update` | int | Days elapsed since last successful run |
| `has_recent_failure` | bool | Whether any FAILED status exists in history |
| `reliability_assessment` | str | Plain business-language freshness assessment |
| `docs_sources` | list | Sources consulted |
| `resolved_triplet` | dict | `{feature_name, entity_name, process_id, view_name}` |

## Error cases

| `error` value | Meaning |
|---------------|---------|
| `ambiguous_feature` | Feature exists for multiple entities; clarification needed |
| `feature_not_found_did_you_mean` | Not found; `candidates` list provided |
| `no_execution_history` | Feature registered but never executed |

## Notes

- A stale `RUNNING` status after a crash means `followup_close` did not record `FAILED` — treat as potentially incomplete data.
- `hint_entity_name` (from a prior turn) auto-disambiguates without prompting.
