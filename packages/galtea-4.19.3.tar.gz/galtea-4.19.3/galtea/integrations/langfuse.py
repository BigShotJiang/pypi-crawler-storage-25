"""
Langfuse integration for Galtea SDK.

Provides two wrappers that bridge Langfuse and Galtea tracing:

  1. ``observe`` — drop-in replacement for ``langfuse.observe`` (decorator API)
  2. ``start_as_current_observation`` — drop-in replacement for
     ``langfuse.Langfuse.start_as_current_observation`` (context manager API)

Both wrappers are **transparent to Langfuse** — they do NOT inject
``langfuse_trace_id``, ``trace_context``, or any other Langfuse-specific
attribute. Langfuse sees exactly the same traces it would without Galtea.

Galtea-side correlation is handled entirely by the
``InferenceContextStampingProcessor`` (registered in ``initialize_telemetry``),
which stamps ``galtea.inference_result.id`` on every span at creation time.

The wrappers' only addition is optional ``inference_result_id`` context
lifecycle management: ``set_context()`` before the span starts and
``clear_context(flush=True)`` after it ends.

Requires: langfuse>=3.0.0,<5.0.0 (optional dependency)
"""

import contextlib
import functools
import logging
from typing import Any, Callable, Optional, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

_logger = logging.getLogger(__name__)


def _ensure_langfuse():
    """Import and return Langfuse, raising a clear error if not installed."""
    try:
        from langfuse import Langfuse

        return Langfuse
    except ImportError as e:
        raise ImportError(
            "langfuse is required for galtea.integrations.langfuse. Install it with: pip install 'galtea[langfuse]'"
        ) from e


def observe(**langfuse_kwargs: Any) -> Callable[[F], F]:
    """Drop-in replacement for ``langfuse.observe`` that adds Galtea correlation.

    Transparent to Langfuse — does not inject ``langfuse_trace_id`` or modify
    any Langfuse behavior. Langfuse generates its own trace IDs naturally.

    Usage::

        from galtea.integrations.langfuse import observe


        @observe(name="my-agent")
        def my_agent(input: str) -> str: ...

    Context management:
        Pass ``inference_result_id`` as a kwarg to let the wrapper manage
        ``set_context`` / ``clear_context`` automatically::

            result = my_agent("hello", inference_result_id="ir-123")
    """

    def decorator(func: F) -> F:
        _ensure_langfuse()
        from langfuse import observe as _langfuse_observe

        langfuse_wrapped = _langfuse_observe(**langfuse_kwargs)(func)

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            from galtea.utils.tracing import clear_context, get_inference_result_id, set_context

            ir_id_from_kwarg = kwargs.pop("inference_result_id", None)
            context_token = None

            if ir_id_from_kwarg and not get_inference_result_id():
                context_token = set_context(inference_result_id=ir_id_from_kwarg)

            try:
                return langfuse_wrapped(*args, **kwargs)
            finally:
                if context_token is not None:
                    clear_context(context_token)

        return wrapper  # type: ignore[return-value]

    return decorator


@contextlib.contextmanager
def start_as_current_observation(
    *,
    inference_result_id: Optional[str] = None,
    **langfuse_kwargs: Any,
):
    """Drop-in replacement for ``langfuse.Langfuse.start_as_current_observation``.

    Transparent to Langfuse — does not inject ``trace_context`` or modify
    any Langfuse behavior. Langfuse generates its own trace IDs naturally.

    Usage::

        from galtea.integrations.langfuse import start_as_current_observation

        with start_as_current_observation(name="process-query", as_type="span") as span:
            span.update(output=result)

        # With Galtea correlation:
        with start_as_current_observation(
            name="process-query",
            inference_result_id="ir-123",
        ) as span:
            ...  # spans inside are stamped with inference_result_id
    """
    _ensure_langfuse()
    from langfuse import get_client

    from galtea.utils.tracing import clear_context, get_inference_result_id, set_context

    context_token = None
    if inference_result_id and not get_inference_result_id():
        context_token = set_context(inference_result_id=inference_result_id)

    try:
        langfuse_client = get_client()
        with langfuse_client.start_as_current_observation(**langfuse_kwargs) as span:
            yield span
    finally:
        if context_token is not None:
            clear_context(context_token)
