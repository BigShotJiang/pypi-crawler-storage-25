from enum import Enum
from typing import Optional

from pydantic import Field

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class UserGroupType(CaseInsensitiveEnumMixin, str, Enum):
    EVALUATOR = "EVALUATOR"


class UserGroupBase(FromCamelCaseBaseModel):
    name: str
    type: UserGroupType = UserGroupType.EVALUATOR
    description: Optional[str] = None


class UserGroup(UserGroupBase):
    id: str
    organization_id: str
    user_ids: list[str] = Field(default_factory=list)
    metric_ids: list[str] = Field(default_factory=list)
    created_at: str
    deleted_at: Optional[str] = None
