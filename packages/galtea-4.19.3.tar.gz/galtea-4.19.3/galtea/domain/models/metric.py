from enum import Enum
from typing import Optional

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class MetricSource(CaseInsensitiveEnumMixin, str, Enum):
    SELF_HOSTED = "SELF_HOSTED"
    FULL_PROMPT = "FULL_PROMPT"
    PARTIAL_PROMPT = "PARTIAL_PROMPT"
    HUMAN_EVALUATION = "HUMAN_EVALUATION"
    GEVAL = "GEVAL"
    DEEPEVAL = "DEEPEVAL"
    DETERMINISTIC = "DETERMINISTIC"


class MetricBase(FromCamelCaseBaseModel):
    name: str
    evaluator_model_name: Optional[str] = None
    evaluation_params: Optional[list[str]] = None
    judge_prompt: Optional[str] = None
    tags: Optional[list[str]] = None
    source: Optional[MetricSource] = None
    description: Optional[str] = None
    documentation_url: Optional[str] = None
    legacy_at: Optional[str] = None
    user_group_ids: Optional[list[str]] = None


class Metric(MetricBase):
    id: str
    organization_id: Optional[str] = None
    created_at: str
    deleted_at: Optional[str] = None
