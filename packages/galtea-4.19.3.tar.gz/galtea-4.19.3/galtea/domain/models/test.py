from enum import Enum
from typing import Any, Optional

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class TestStatus(CaseInsensitiveEnumMixin, str, Enum):
    PENDING = "PENDING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    AUGMENTING = "AUGMENTING"


class TestBase(FromCamelCaseBaseModel):
    product_id: Optional[str] = None
    name: str
    type: Optional[str] = None
    language_code: Optional[str] = None
    ground_truth_uri: Optional[str] = None
    few_shot: Optional[str] = None
    custom_user_persona: Optional[str] = None
    variants: Optional[list[str]] = None
    strategies: Optional[list[str]] = None
    custom_variant_description: Optional[str] = None
    max_test_cases: Optional[int] = None
    uri: Optional[str] = None
    status: Optional[TestStatus] = None
    metadata: Optional[Any] = None
    specification_id: Optional[str] = None


class Test(TestBase):
    id: str
    created_at: str
    deleted_at: Optional[str] = None
