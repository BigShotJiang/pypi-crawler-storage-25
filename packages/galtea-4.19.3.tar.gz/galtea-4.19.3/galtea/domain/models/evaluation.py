from enum import Enum
from typing import Optional

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel

__all__ = [
    "Evaluation",
    "EvaluationStatus",
]


class EvaluationStatus(CaseInsensitiveEnumMixin, str, Enum):
    PENDING = "PENDING"
    PENDING_HUMAN = "PENDING_HUMAN"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class Evaluation(FromCamelCaseBaseModel):
    id: str
    metric_id: str
    session_id: Optional[str] = None
    inference_result_id: Optional[str] = None
    score: Optional[float] = None
    reason: Optional[str] = None
    status: EvaluationStatus
    conversation_simulator_version: Optional[str] = None
    created_at: str
    deleted_at: Optional[str] = None
    evaluated_at: Optional[str] = None
    retries_attempted: int = 0
    can_retry: bool = False
    human_evaluator_id: Optional[str] = None
    human_evaluator_started_at: Optional[str] = None
    metric_legacy_at: Optional[str] = None
