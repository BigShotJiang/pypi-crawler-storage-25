"""
OpenTelemetry TracerProvider factory for Galtea SDK.

This module provides a configured TracerProvider with appropriate span
processors for exporting traces to Galtea.
"""

import logging
from dataclasses import dataclass
from typing import Any, Optional

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider

from galtea.infrastructure.telemetry.processors.context_stamping_processor import (
    InferenceContextStampingProcessor,
)
from galtea.infrastructure.telemetry.processors.galtea_processor import GalteaSpanProcessor

# Global tracer provider instance
_tracer_provider: Optional[TracerProvider] = None
_logger = logging.getLogger(__name__)


@dataclass
class TelemetryConfig:
    """Configuration for Galtea telemetry.

    Attributes:
            http_client: Galtea HTTP client for API requests.
            service_name: Name of the service for resource identification.
            batch_mode: If True, batch spans until flush. If False, export immediately.
    """

    http_client: Any
    service_name: str = "galtea-sdk"
    batch_mode: bool = True


def initialize_telemetry(config: TelemetryConfig) -> TracerProvider:
    """Initialize the OpenTelemetry TracerProvider with Galtea processors.

    If a real TracerProvider already exists globally (e.g. set by Langfuse),
    Galtea reuses it and adds its processors. This eliminates initialization
    order dependencies — Galtea and Langfuse can be initialized in any order
    and will share the same provider.

    Args:
            config: Telemetry configuration.

    Returns:
            The configured TracerProvider.
    """
    global _tracer_provider

    if _tracer_provider is not None:
        _logger.warning("Telemetry already initialized, returning existing provider")
        return _tracer_provider

    # Check if a real TracerProvider already exists (e.g. set by Langfuse or
    # another OTel-based library). If so, reuse it instead of creating a new one.
    existing_provider = trace.get_tracer_provider()
    if isinstance(existing_provider, TracerProvider) and not isinstance(existing_provider, trace.ProxyTracerProvider):
        _tracer_provider = existing_provider
        _logger.info("Reusing existing TracerProvider (shared with other OTel libraries)")
    else:
        # No real provider exists — create one
        resource = Resource.create(
            {
                "service.name": config.service_name,
                "service.version": "1.0.0",
                "telemetry.sdk.name": "galtea",
                "telemetry.sdk.language": "python",
            }
        )
        _tracer_provider = TracerProvider(resource=resource)
        trace.set_tracer_provider(_tracer_provider)

    # Add context stamping processor FIRST — stamps galtea.inference_result.id
    # on all spans (including those from external libraries like Langfuse)
    _tracer_provider.add_span_processor(InferenceContextStampingProcessor())

    # Add Galtea processor — filters by galtea.inference_result.id and exports
    galtea_processor = GalteaSpanProcessor(
        http_client=config.http_client,
        batch_mode=config.batch_mode,
    )
    _tracer_provider.add_span_processor(galtea_processor)
    _logger.info("Galtea span processors registered (stamping + export)")

    return _tracer_provider


def get_tracer(name: str = "galtea") -> trace.Tracer:
    """Get a tracer from the global tracer provider.

    Args:
            name: Name for the tracer.

    Returns:
            A Tracer instance.

    Raises:
            RuntimeError: If telemetry has not been initialized.
    """
    global _tracer_provider

    if _tracer_provider is None:
        # Return a no-op tracer if not initialized
        return trace.get_tracer(name)

    return _tracer_provider.get_tracer(name)


def get_tracer_provider() -> Optional[TracerProvider]:
    """Get the global tracer provider.

    Returns:
            The TracerProvider or None if not initialized.
    """
    return _tracer_provider


def shutdown_telemetry() -> None:
    """Shutdown the telemetry system and flush pending spans."""
    global _tracer_provider

    if _tracer_provider is not None:
        _tracer_provider.shutdown()
        _tracer_provider = None
        _logger.info("Telemetry shutdown complete")


def flush_telemetry(timeout_millis: Optional[int] = None) -> bool:
    """Force flush all pending spans.

    Args:
            timeout_millis: Optional timeout in milliseconds.

    Returns:
            True if flush was successful.
    """
    global _tracer_provider

    if _tracer_provider is not None:
        return _tracer_provider.force_flush(timeout_millis if timeout_millis is not None else 30000)
    return True


def flush_inference(inference_result_id: str) -> None:
    """Flush spans for a specific inference result.

    Args:
            inference_result_id: The inference result ID to flush.
    """
    global _tracer_provider

    if _tracer_provider is None:
        return

    # Find and flush the Galtea processor
    for processor in _tracer_provider._active_span_processor._span_processors:
        if isinstance(processor, GalteaSpanProcessor):
            processor.flush_inference(inference_result_id)
            break
