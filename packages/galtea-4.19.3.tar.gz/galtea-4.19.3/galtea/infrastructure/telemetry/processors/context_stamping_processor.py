"""
Inference Context Stamping Processor for OpenTelemetry.

Stamps galtea.inference_result.id onto every span created while
set_context() is active. This allows spans from external libraries
(e.g. Langfuse's @observe) to be captured by GalteaSpanProcessor
when sharing the same TracerProvider.
"""

import logging
from typing import Any, Optional

from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor

from galtea.infrastructure.telemetry.attributes import (
    GALTEA_ATTR_INFERENCE_RESULT_ID,
    GALTEA_ATTR_SESSION_ID,
)

_logger = logging.getLogger(__name__)


class InferenceContextStampingProcessor(SpanProcessor):
    """Stamps Galtea context attributes onto every span at creation time.

    When set_context(inference_result_id=...) is active, this processor reads
    the inference_result_id from OTel context and sets it as a span attribute.
    This enables GalteaSpanProcessor (which filters by this attribute) to
    capture spans created by any library sharing the same TracerProvider.
    """

    def on_start(self, span, parent_context: Optional[Any] = None) -> None:
        from galtea.utils.tracing import get_inference_result_id, get_session_id

        if not span.is_recording():
            return

        # Only stamp if the span doesn't already have the attribute
        # (e.g. Galtea's own @trace decorator already sets it via _build_span_attributes)
        existing = span.attributes.get(GALTEA_ATTR_INFERENCE_RESULT_ID) if span.attributes else None
        if not existing:
            inference_id = get_inference_result_id()
            if inference_id:
                span.set_attribute(GALTEA_ATTR_INFERENCE_RESULT_ID, inference_id)

            session_id = get_session_id()
            if session_id:
                span.set_attribute(GALTEA_ATTR_SESSION_ID, session_id)

    def on_end(self, span: ReadableSpan) -> None:
        pass
