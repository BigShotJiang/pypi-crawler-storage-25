import os
import re
import sys
import json
import shutil
import threading
import time
from rich.console import Console
from rich.panel import Panel
from agents.reader import run_reader
from agents.analyzer import run_analyzer
from agents.writer import run_writer
from agents.reporter import run_reporter
from agents.planner import run_planner
from model_loader import start_server, ask_model, print_typewriter
from security import verify_checksums, print_checksum_report

console = Console()

original_contents = {}
fixed_contents = {}
lock = threading.Lock()

# ── Conversation history ──────────────────────────────────
conversation_history = []

# ── Current mode ─────────────────────────────────────────
current_mode = "code"  # default mode
MODE_LABELS = {
    "code":      "[bold green][CODE][/bold green]",
    "ask":       "[bold cyan][ASK][/bold cyan]",
    "architect": "[bold magenta][ARCH][/bold magenta]",
}
MODE_DESCRIPTIONS = {
    "code":      "Full pipeline — Planner → Reader → Analyzer → Writer → Reporter",
    "ask":       "Answer only — No files touched, just conversation",
    "architect": "Design only — Planner discusses structure, no code written",
}


def add_to_history(role: str, content: str):
    conversation_history.append({
        "role": role,
        "content": content,
        "timestamp": time.strftime("%H:%M:%S")
    })

def get_history_context() -> str:
    if not conversation_history:
        return ""
    recent = conversation_history[-10:]
    context = "\n".join([f"{m['role'].upper()} [{m['timestamp']}]: {m['content']}" for m in recent])
    return f"\n\nConversation history:\n{context}"

SOURCE_EXTENSIONS = (
    ".py", ".java", ".js", ".ts", ".cpp", ".c",
    ".cs", ".go", ".rs", ".md", ".txt", ".html", ".css"
)


def handle_mode_switch(user_input: str) -> bool:
    """
    Check if user typed a mode command.
    Returns True if mode was switched, False otherwise.
    """
    global current_mode

    cmd = user_input.strip().lower()

    if cmd == "/code":
        current_mode = "code"
        console.print(f"\n[bold green][HDFC_AI][/bold green] Switched to CODE mode")
        console.print(f"[dim]{MODE_DESCRIPTIONS['code']}[/dim]\n")
        return True

    elif cmd == "/ask":
        current_mode = "ask"
        console.print(f"\n[bold cyan][HDFC_AI][/bold cyan] Switched to ASK mode")
        console.print(f"[dim]{MODE_DESCRIPTIONS['ask']}[/dim]\n")
        return True

    elif cmd == "/architect":
        current_mode = "architect"
        console.print(f"\n[bold magenta][HDFC_AI][/bold magenta] Switched to ARCHITECT mode")
        console.print(f"[dim]{MODE_DESCRIPTIONS['architect']}[/dim]\n")
        return True

    elif cmd == "/mode":
        # Show current mode
        console.print(f"\n[bold white][HDFC_AI][/bold white] Current mode: {MODE_LABELS[current_mode]}")
        console.print(f"[dim]{MODE_DESCRIPTIONS[current_mode]}[/dim]")
        console.print(f"\n[dim]Available modes: /code  /ask  /architect[/dim]\n")
        return True

    elif cmd == "/help":
        console.print(f"""
[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ HDFC_AI HELP ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]

[bold green]/code[/bold green]         → Full pipeline: Planner → Reader → Analyzer → Writer → Reporter
[bold cyan]/ask[/bold cyan]          → Answer questions without touching any files
[bold magenta]/architect[/bold magenta]    → Discuss design and structure without writing code
[bold white]/mode[/bold white]         → Show current mode
[bold white]/help[/bold white]         → Show this help
[bold white]/checksums[/bold white]    → Show file checksums for verification
[bold white]exit[/bold white]          → Quit HDFC_AI

[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]
""")
        return True
    
    elif cmd == "/checksums":
        print_checksum_report()
        return True

    return False


def get_prompt_label() -> str:
    """Returns colored mode label for input prompt."""
    labels = {
        "code":      "CODE",
        "ask":       "ASK",
        "architect": "ARCH",
    }
    return labels[current_mode]


def detect_intent(user_prompt: str) -> str:
    input_files = os.listdir(".") if os.path.exists(".") else []
    context = f"Files in project: {input_files}"
    history = get_history_context()

    result = ask_model(
        prompt=f"""A developer is using HDFC_AI, a smart coding assistant like aider.
The tool has these 4 modes:
1. conversational - ONLY for greetings, small talk, or asking about files/project
2. generate - user wants to write brand new code from scratch
3. readonly - user ONLY wants to read, view, show, display, or summarize existing files
4. pipeline - user wants to analyze, fix, refactor, test, review, or improve existing code

{context}
{history}

User message: "{user_prompt}"

Reply with ONLY one word: conversational, generate, readonly, or pipeline""",
        system="""You are an intent classifier. Reply with exactly one word only.
- conversational: ONLY greetings or questions about the project/files
- generate: user wants new code written from scratch
- readonly: user wants to read, view, open, show, display, or summarize files
- pipeline: user wants to analyze, fix, test, refactor, improve existing code
One word. No punctuation. No explanation. No other text."""
    )

    clean = re.sub(r'[^a-zA-Z]', ' ', result.strip()).split()
    intent = clean[0].lower() if clean else "pipeline"
    if intent not in ("conversational", "generate", "readonly", "pipeline"):
        intent = "pipeline"

    console.print(f"[bold bright_blue][ORCHESTRATOR][/bold bright_blue] Detected intent: [yellow]{intent}[/yellow]")
    return intent


def build_project_context() -> str:
    context_lines = []
    for item in os.listdir("."):
        if item.startswith(".") or item in ("__pycache__", "node_modules", "target", "build", "venv", ".venv"):
            continue
        item_path = os.path.join(".", item)
        if os.path.isdir(item_path):
            subfiles = []
            for root, dirs, files in os.walk(item_path):
                dirs[:] = [d for d in dirs if not d.startswith(".")
                           and d not in ("__pycache__", "node_modules", "target", "build", "venv", ".venv")]
                for f in files:
                    if f.endswith(SOURCE_EXTENSIONS):
                        rel = os.path.relpath(os.path.join(root, f), ".")
                        subfiles.append(rel)
            if subfiles:
                context_lines.append(f"📁 {item}/ ({len(subfiles)} files)")
                for sf in subfiles:
                    context_lines.append(f"   - {sf}")
        else:
            if item.endswith(SOURCE_EXTENSIONS):
                context_lines.append(f"📄 {item}")
    return "\n".join(context_lines) if context_lines else "No source files found."


def find_file(filename: str) -> str | None:
    """Search for a file by name in current directory recursively."""
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if not d.startswith(".")
                   and d not in ("__pycache__", "node_modules", "venv", ".venv")]
        for f in files:
            if f.lower() == filename.lower():
                return os.path.join(root, f)
    return None


def process_pipeline(user_prompt: str):
    """Full pipeline: Planner → Reader → Analyzer → Writer → Reporter"""
    history = get_history_context()

    # ── Step 1: Planner ──
    plan = run_planner(user_prompt, build_project_context(), history)
    if not plan:
        return

    # ── Step 2: Find relevant files ──
    console.print("\n[bold bright_blue][ORCHESTRATOR][/bold bright_blue] Identifying relevant files...")
    relevant_files = []
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if not d.startswith(".")
                   and d not in ("__pycache__", "node_modules", "venv", ".venv")]
        for f in files:
            if f.endswith(SOURCE_EXTENSIONS):
                filepath = os.path.join(root, f)
                if f.lower() in user_prompt.lower() or f.lower() in plan.lower():
                    relevant_files.append(filepath)

    # If no specific files found, use all
    if not relevant_files:
        for root, dirs, files in os.walk("."):
            dirs[:] = [d for d in dirs if not d.startswith(".")
                       and d not in ("__pycache__", "node_modules", "venv", ".venv")]
            for f in files:
                if f.endswith(SOURCE_EXTENSIONS):
                    relevant_files.append(os.path.join(root, f))

    # ── Step 3: Read relevant files ──
    all_content = ""
    for filepath in relevant_files[:5]:
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            console.print(f"[bold cyan][READER][/bold cyan] → Loaded: {filepath} ({len(content.splitlines())} lines)")
            all_content += f"\n\n--- FILE: {filepath} ---\n{content}"
        except Exception as e:
            console.print(f"[bold cyan][READER][/bold cyan] ⚠️ Could not read {filepath}: {e}")

    # ── Step 4: Analyzer ──
    analysis = run_analyzer(all_content, user_prompt)

    # ── Step 5: Writer ──
    fixed_code = run_writer(analysis, user_prompt, plan=plan)

    # ── Step 6: Reporter ──
    applied = run_reporter(all_content, fixed_code, analysis, relevant_files, user_prompt)

    if applied:
        add_to_history("assistant", f"Applied changes based on: {user_prompt}")
    else:
        add_to_history("assistant", f"Changes discarded for: {user_prompt}")


def process_ask(user_prompt: str):
    """ASK mode — answer questions without touching files."""
    context = build_project_context()
    history = get_history_context()

    # Read relevant file content for context if file mentioned
    file_context = ""
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if not d.startswith(".")
                   and d not in ("__pycache__", "node_modules", "venv", ".venv")]
        for f in files:
            if f.lower() in user_prompt.lower():
                filepath = os.path.join(root, f)
                try:
                    with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                        content = fh.read()
                    file_context += f"\n\n--- FILE: {filepath} ---\n{content[:3000]}"
                    console.print(f"[bold cyan][READER][/bold cyan] → Reading: {filepath} for context")
                except:
                    pass

    answer = ask_model(
        prompt=f"""Project structure:
{context}
{file_context}
{history}

User asked: {user_prompt}""",
        system="""You are HDFC_AI in ASK mode.
Answer the user's question clearly and helpfully.
You can read and discuss code but NEVER suggest modifying files.
Use the project context and file contents provided.
Be thorough but concise."""
    )

    console.print(f"\n{MODE_LABELS['ask']} [bold white][HDFC_AI][/bold white] ", end="")
    print_typewriter(answer)
    print()
    add_to_history("assistant", answer)


def process_architect(user_prompt: str):
    """ARCHITECT mode — planning and design only, no code written."""
    history = get_history_context()
    context = build_project_context()

    console.print(f"\n{MODE_LABELS['architect']} [bold blue][PLANNER][/bold blue] Thinking about architecture...\n")

    plan = ask_model(
        prompt=f"""Project structure:
{context}
{history}

User request: {user_prompt}

As a senior software architect discuss:
1. High level design approach
2. Which components/files are involved
3. Recommended architecture or pattern
4. Potential risks or considerations
5. Step by step implementation plan

Do NOT write actual code. Focus on design decisions and architecture.""",
        system="""You are HDFC_AI in ARCHITECT mode — a senior software architect.
Discuss design, patterns, and structure at a high level.
Never write actual implementation code.
Focus on architecture decisions, trade-offs, and recommendations.
Be thorough and specific about file names and components."""
    )

    console.print(f"\n{MODE_LABELS['architect']} [bold white][HDFC_AI][/bold white] ", end="")
    print_typewriter(plan)
    print()
    add_to_history("assistant", plan)


def main():
    global current_mode

    # ── Handle CLI flags ──
    if "--checksums" in sys.argv:
        print_checksum_report()
        return

    if "--version" in sys.argv:
        console.print("[bold white]HDFC_AI version 1.0.8[/bold white]")
        return

    if "--reset" in sys.argv:
        config_path = os.path.join(os.path.expanduser("~"), ".hdfc_ai", "config.json")
        if os.path.exists(config_path):
            os.remove(config_path)
            console.print("[bold green]✅ Config reset. Run hdfc_ai again to reconfigure.[/bold green]")
        return

    # ── Security check ──
    ok, changed = verify_checksums()
    if not ok and changed:
        console.print("\n[bold red]⚠️  WARNING: Some files have been modified:[/bold red]")
        for f in changed:
            console.print(f"[bold red]   {f}[/bold red]")
        console.print("[bold red]   This may indicate tampering. Proceed with caution.[/bold red]\n")
        confirm = input("Continue anyway? (Y/N): ").strip().lower()
        if confirm != "y":
            sys.exit(0)

    project_dir = os.getcwd()

    console.print(Panel.fit(
        f"[bold white]🤖 HDFC_AI — Smart Coding Assistant[/bold white]\n"
        f"[dim]Powered by Gemma 4 E4B + AWS Strands[/dim]\n"
        f"[dim cyan]Project: {project_dir}[/dim cyan]",
        border_style="bright_blue"
    ))

    console.print("\n[bold bright_blue][HDFC_AI][/bold bright_blue] Scanning project...\n")
    context = build_project_context()
    console.print(context)
    console.print(f"\n[dim]Default mode: /code | Type /help for all commands | 'exit' to quit[/dim]\n")

    start_server()

    while True:
        mode_label = get_prompt_label()
        user_prompt = input(f"\n💬 [{mode_label}] You: ").strip()

        if not user_prompt:
            continue

        if user_prompt.lower() in ("exit", "quit", "bye"):
            console.print("\n[bold bright_blue]👋 Goodbye![/bold bright_blue]\n")
            break

        # ── Check for mode switch or command ──
        if user_prompt.startswith("/"):
            if handle_mode_switch(user_prompt):
                continue

        add_to_history("user", user_prompt)

        # ── Route based on current mode ──

        # ── ASK MODE ──
        if current_mode == "ask":
            process_ask(user_prompt)
            continue

        # ── ARCHITECT MODE ──
        if current_mode == "architect":
            process_architect(user_prompt)
            continue

        # ── CODE MODE ──
        intent = detect_intent(user_prompt)

        # ── Conversational ──
        if intent == "conversational":
            context = build_project_context()
            history = get_history_context()
            answer = ask_model(
                prompt=f"""Project structure:
{context}
{history}

User asked: {user_prompt}""",
                system="""You are HDFC_AI, a smart coding assistant like aider.
Answer using the project context and conversation history.
Be short, direct, and accurate."""
            )
            console.print(f"\n[bold white][HDFC_AI][/bold white] ", end="")
            print_typewriter(answer)
            print()
            add_to_history("assistant", answer)
            continue

        # ── Readonly ──
        if intent == "readonly":
            console.print("[bold bright_blue][ORCHESTRATOR][/bold bright_blue] Reading files only — no modifications\n")

            # Extract filename from user prompt using model
            filename_guess = ask_model(
                prompt=f"""User said: "{user_prompt}"
Extract ONLY the filename the user wants to read.
Return ONLY the filename with extension (e.g. main.py, auth.py, models.py).
If no specific file mentioned return: ALL""",
                system="You are a filename extractor. Return only the filename or ALL. Nothing else."
            ).strip().strip('"').strip("'")

            clean_filename = re.sub(r'[^a-zA-Z0-9._\-]', '', filename_guess)

            if clean_filename and clean_filename.upper() != "ALL":
                # Search for that specific file
                specific_file = None
                for root, dirs, files in os.walk("."):
                    dirs[:] = [d for d in dirs if not d.startswith(".")
                               and d not in ("__pycache__", "node_modules", "venv", ".venv")]
                    for f in files:
                        if f.lower() == clean_filename.lower():
                            specific_file = os.path.join(root, f)
                            break
                    if specific_file:
                        break

                if specific_file:
                    try:
                        with open(specific_file, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                        console.print(f"[bold cyan][READER][/bold cyan] → Loaded: {specific_file} ({len(content.splitlines())} lines)")
                        summary = ask_model(
                            prompt=f"File: {specific_file}\n\nContent:\n{content[:4000]}\n\nUser request: {user_prompt}\n\nAnswer the user's request about this file.",
                            system="You are HDFC_AI. Read the file and answer the user's request clearly and concisely."
                        )
                        console.print(f"\n[bold white][HDFC_AI][/bold white] ", end="")
                        print_typewriter(summary)
                        print()
                        add_to_history("assistant", summary)
                    except Exception as e:
                        console.print(f"[bold red][HDFC_AI][/bold red] Could not read file: {e}")
                else:
                    console.print(f"[bold red][HDFC_AI][/bold red] ❌ File '{clean_filename}' not found in this project.\n")
            else:
                content, summary = run_reader(".")
                console.print(f"\n[bold white][HDFC_AI][/bold white] ", end="")
                print_typewriter(summary)
                print()
                add_to_history("assistant", summary)
            continue

        # ── Generate ──
        if intent == "generate":
            history = get_history_context()
            start = time.time()

            # Ask model to return JSON with file structure
            import json

            structure = ask_model(
                prompt=f"""User request: {user_prompt}

                Return a JSON object where:
                - keys are file paths (e.g. "app/main.py", "app/models.py")
                - values are the complete file contents

                Example format:
                {{
                "main.py": "print('hello')",
                "utils/helper.py": "def helper(): pass"
                }}

                Return ONLY valid JSON. No explanations. No markdown fences.""",
                system="You are an expert code generator. Return only a valid JSON object with filepath as key and file content as value."
            )

            # Clean and parse JSON
            structure = structure.strip()
            if structure.startswith("```"):
                structure = "\n".join(structure.split("\n")[1:])
            if structure.endswith("```"):
                structure = "\n".join(structure.split("\n")[:-1])
            structure = structure.strip()

            try:
                files = json.loads(structure)
            except json.JSONDecodeError:
                console.print("[bold red][WRITER][/bold red] ❌ Could not parse file structure. Try again.")
                continue

            # Create all files and folders
            created = []
            for filepath, content in files.items():
                full_path = os.path.join(os.getcwd(), filepath)
                parent = os.path.dirname(full_path)
                if parent:
                    os.makedirs(parent, exist_ok=True)

                if os.path.exists(full_path):
                    import shutil
                    shutil.copy2(full_path, full_path + ".bak")
                    console.print(f"[bold yellow][WRITER][/bold yellow] ⚠️  Backed up → {full_path}.bak")

                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content)

                console.print(f"[bold green][WRITER][/bold green] ✅ Created → {filepath}")
                created.append(filepath)

            elapsed = round(time.time() - start, 1)
            console.print(f"\n[bold white][HDFC_AI][/bold white] ", end="")
            print_typewriter(f"Created {len(created)} files in {elapsed}s.")
            print()
            add_to_history("assistant", f"Generated structure: {created}")
            continue

        # ── Pipeline ──
        start = time.time()
        process_pipeline(user_prompt)
        elapsed = round(time.time() - start, 1)

        console.print(Panel(
            f"[bold cyan]🧠 Planner[/bold cyan]     ✅ Plan created\n"
            f"[bold cyan]📖 Reader[/bold cyan]      ✅ Files loaded\n"
            f"[bold yellow]🔍 Analyzer[/bold yellow]    ✅ Issues found\n"
            f"[bold green]✍️  Writer[/bold green]     ✅ Changes prepared\n"
            f"[bold magenta]📝 Reporter[/bold magenta]   ✅ Diff shown\n\n"
            f"[dim]Total time: {elapsed}s[/dim]",
            title="[bold white]HDFC_AI Complete[/bold white]",
            border_style="bright_green"
        ))


if __name__ == "__main__":
    main()