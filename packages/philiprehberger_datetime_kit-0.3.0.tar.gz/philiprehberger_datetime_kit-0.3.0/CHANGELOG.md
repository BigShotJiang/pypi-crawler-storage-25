# Changelog

## 0.3.0 (2026-04-06)

- Add `add_business_days(start, days, holidays)` to add N business days to a date
- Add `time_ago(dt, now)` for human-readable relative time strings
- Add `format_duration(seconds)` to format durations as compact strings

## 0.2.0 (2026-04-04)

- Add `is_weekend` function to check if a date falls on Saturday or Sunday
- Add `next_business_day` function to find the next weekday excluding holidays

## 0.1.2 (2026-03-31)

- Standardize README to 3-badge format with emoji Support section
- Update CI checkout action to v5 for Node.js 24 compatibility
- Add GitHub issue templates, dependabot config, and PR template

## 0.1.1 (2026-03-22)

- Add Changelog URL to project URLs
- Add `#readme` anchor to Homepage URL
- Add pytest and mypy configuration

## 0.1.0 (2026-03-21)

- Initial release
- Business day counting with optional holiday exclusion
- Date range generator with configurable step
- Relative datetime from UTC now
- Start-of and end-of period helpers (day, week, month, year)
