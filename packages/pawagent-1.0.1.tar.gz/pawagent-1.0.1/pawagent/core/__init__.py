"""Core abstractions for PawAgent."""
