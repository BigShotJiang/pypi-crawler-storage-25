"""Audio capability package."""
