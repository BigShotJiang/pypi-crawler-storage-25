"""Ollama local model provider."""
from __future__ import annotations

import logging
import os

import requests

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.drafter.prompt import _ANALYSIS_PROMPT
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

# Ollama context window varies by model (typically 8K–128K tokens).
# Use a conservative limit so large sessions are chunked safely.
_CHUNK_CHARS = 100_000


class OllamaProvider(AIProvider):
    """Calls local Ollama instance via HTTP. Uses SMRITIX_OLLAMA_MODEL and SMRITIX_OLLAMA_URL."""

    @classmethod
    def name(cls) -> str:
        return "api_ollama"

    def analyze(self, conversation_text: str) -> str:
        model = os.getenv("SMRITIX_OLLAMA_MODEL", "llama3.2")
        ollama_url = os.getenv("SMRITIX_OLLAMA_URL", "http://localhost:11434")

        chunks = prepare_chunks(conversation_text, _CHUNK_CHARS)
        logger.info(
            "api_ollama: conversation %d chars → %d chunk(s) (max %d chars each)",
            len(conversation_text), len(chunks), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.debug("api_ollama: chunk %d/%d (%d chars)", i + 1, len(chunks), len(chunk))
            resp = requests.post(
                f"{ollama_url}/api/chat",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": _ANALYSIS_PROMPT.format(conversation=chunk)}],
                    "stream": False,
                },
                timeout=120,
            )
            resp.raise_for_status()
            responses.append(resp.json()["message"]["content"])

        return merge_chunk_responses(responses)

    @classmethod
    def list_models(cls) -> list[str]:
        ollama_url = os.getenv("SMRITIX_OLLAMA_URL", "http://localhost:11434")
        try:
            resp = requests.get(f"{ollama_url}/api/tags", timeout=5)
            resp.raise_for_status()
            return [m["name"] for m in resp.json().get("models", [])]
        except Exception:
            return ["llama3.2", "llama3.1", "mistral", "gemma2"]

    @classmethod
    def default_model(cls) -> str:
        return os.getenv("SMRITIX_OLLAMA_MODEL", "llama3.2")

    def validate(self) -> None:
        ollama_url = os.getenv("SMRITIX_OLLAMA_URL", "http://localhost:11434")
        try:
            resp = requests.get(f"{ollama_url}/api/tags", timeout=5)
            resp.raise_for_status()
        except Exception as exc:
            raise ProviderValidationError(
                f"Ollama not reachable at {ollama_url}: {exc}\n  Ensure Ollama is running."
            )
