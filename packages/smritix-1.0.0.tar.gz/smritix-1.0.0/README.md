<div align="center">
  <img src="smritix/portal/static/favicon.svg" width="80" height="80" alt="Smritix logo"/>
  <h1>Smritix</h1>
</div>

<div align="center">

[![PyPI version](https://img.shields.io/pypi/v/smritix)](https://pypi.org/project/smritix/)
[![GitHub stars](https://img.shields.io/github/stars/ParagPatil96/smritix?style=social)](https://github.com/ParagPatil96/smritix/stargazers)
[![License](https://img.shields.io/github/license/ParagPatil96/smritix)](LICENSE)
[![CI](https://github.com/ParagPatil96/smritix/actions/workflows/ci.yml/badge.svg)](https://github.com/ParagPatil96/smritix/actions/workflows/ci.yml)

</div>

**Your AI coding assistant remembers nothing between sessions. Smritix fixes that.**

It captures decisions, preferences, and corrections from your Claude Code and Codex sessions, and surfaces them automatically at the start of every task — so your AI always knows how you work.

> *smṛti* (Sanskrit) — memory, recollection

---

## How It Works

```mermaid
flowchart LR
    A([You code\nwith Claude]) --> B[Session ends]
    B --> C{smritix\nextracts memories}
    C --> D[You approve\nor skip]
    D --> E[(Local DB\n~/.smritix)]
    E --> F([Next session\nstarts])
    F --> G[Relevant memories\ninjected automatically]
    G --> A
```

**Nothing is stored without your approval.** Smritix queues extracted memories for your review — you approve, edit, or reject each one. Everything stays on your machine.

---

## Architecture

```mermaid
flowchart TB
    subgraph agents["AI Agents (your tools)"]
        cc["Claude Code"]
        codex["Codex CLI"]
    end

    subgraph serve["smritix serve  :8666"]
        mcp["MCP Server /mcp\n(get_memories, add_memory…)"]
        portal["Web Portal /\n(review, approve, search)"]
        subgraph watcher["Background Jobs (JobExecutor)"]
            inc["IncrementalSyncJob\nevery 15 min"]
            hist["HistoricalSyncJob\nruns once to completion"]
            auto["AutoApproveJob\nevery 1 hour"]
        end
    end

    subgraph providers["AI Providers (smritix/providers/)"]
        p1["sub_claude\n(Claude CLI)"]
        p2["api_anthropic\n(SDK)"]
        p3["api_ollama / gemini / openai"]
    end

    subgraph storage["Local Storage  ~/.smritix/"]
        db[("DuckDB\nmemories\npending_memories\nsync_state\nsession_cursors")]
        embed["Embeddings\nHNSW Index"]
    end

    cc -->|"HTTP MCP"| mcp
    codex -->|"HTTP MCP"| mcp
    mcp --> db

    cc -->|"session JSONL files"| inc
    codex -->|"session JSONL files"| inc
    inc --> providers
    hist --> providers
    providers -->|"extract memories"| db
    auto -->|"approve / expire"| db

    db --> embed
    portal --> db
```

**Key design points:**
- **One shared server** — all Claude/Codex sessions connect via HTTP → no DB lock conflicts
- **Three background jobs** — incremental sync (ongoing), historical sync (one-time backfill), auto-approve (hourly housekeeping)
- **Resumable cursors** — `sync_state` + `session_cursors` in DuckDB; jobs survive server restarts
- **Pluggable AI providers** — subscription (CLI subprocess) or API key (Anthropic/Ollama/Gemini/OpenAI)
- **Hooks are read-only** — inject memories into Claude; all writes come from the watcher

---

## Quick Start

```bash
# 1. Install
pip install smritix

# 2. Set up (run from your project directory)
cd /your/project
smritix init          # configures Claude Code + your AI provider

# 3. Start the server (keep this running)
smritix serve

# 4. Open Claude Code — memory is now active
```

That's it. Smritix hooks into Claude Code automatically. At the start of each session, relevant memories are injected before you even type.

---

## What Gets Remembered

Smritix only saves **corrections** and **preferences** — things that would change how your AI behaves in future sessions:

| Saved ✓ | Not saved ✗ |
|---------|------------|
| "We use DuckDB, not SQLite" | Discovered that a function exists |
| "Always use integration tests, not mocks" | Fixed a bug in file X |
| "I prefer trunk-based development" | Session summary / task log |
| "Don't add docstrings to unchanged code" | One-off task completion |

---

## Supported Tools

| Tool | Session Reading | MCP | Status |
|------|----------------|-----|--------|
| **Claude Code** | ✅ | ✅ | Fully supported |
| **Codex CLI** | ✅ | ✅ | Fully supported |
| Gemini CLI, Cursor, OpenCode | — | ✅ | MCP-only (planned) |

---

<details>
<summary><strong>📋 CLI Reference</strong></summary>

```bash
smritix init                # Set up: DB, model, Claude Code hooks, AI provider
smritix serve               # Start MCP server + portal on :8666 — run before Claude Code
smritix provider            # Change your AI provider
smritix review              # Review pending memories in the terminal
smritix status              # Show memory database stats
smritix cleanup             # Purge memories by type or age
smritix upgrade             # Upgrade to latest version
smritix --version           # Show current version
smritix reset               # Reset sync cursors or wipe everything
smritix stop                # Stop the running smritix serve process
smritix watch               # Run sync jobs standalone (without portal/MCP server)
```

### `smritix serve`

Starts the MCP server and web portal together on port 8666. Run this once before opening Claude Code.

```bash
smritix serve           # http://localhost:8666
smritix serve --debug   # verbose logging
```

If already running: prints a message and exits cleanly — safe to run again.

### `smritix init`

Run once after install. Safe to re-run — merges with existing config, never overwrites.

```
$ smritix init
Initializing Smritix...
  Database: ~/.smritix/smritix.duckdb
  Model ready.
  Claude Code: MCP registered (HTTP)
  Claude Code: session hooks registered

Before opening Claude Code, start the server:
  smritix serve
```

### `smritix review`

Review pending memories in the terminal without opening the browser.

```
$ smritix review
[1/3]  PREFERENCE  (87%)
  Always use integration tests not mocks
  Evidence: "we got burned last time with mocked tests"

(a)pprove / (r)eject / (e)dit / (s)kip / (q)uit:
```

### `smritix cleanup`

```bash
smritix cleanup --pending --days=3               # delete pending older than 3 days
smritix cleanup --session-summaries --all        # purge session_summary entries (pending + confirmed)
smritix cleanup --pending --permanent --all      # wipe all pending and confirmed memories
```

### `smritix reset`

```bash
smritix reset --cursor --all      # re-process all sessions from scratch (keeps memories)
smritix reset --all               # wipe everything: memories, pending, embeddings, sync state
```

For age/type-based pruning use `smritix cleanup` instead.

### `smritix status`

```
Memories : 142
Pending  : 3
Hot vecs : 12
Cold vecs: 130
```

</details>

---

<details>
<summary><strong>🔧 Manual MCP Registration</strong></summary>

`smritix init` handles this automatically. Only needed if auto-registration fails.

**Claude Code** — add to `~/.claude.json`:
```json
{
  "mcpServers": {
    "smritix": {
      "type": "sse",
      "url": "http://localhost:8666/mcp"
    }
  }
}
```

**Codex:**
```bash
codex mcp add smritix --type http http://localhost:8666/mcp
```

**Cursor / OpenCode / Antigravity** — add MCP config pointing to `http://localhost:8666/mcp`.

</details>

---

<details>
<summary><strong>🌐 Multi-session Support</strong></summary>

`smritix serve` runs a single shared HTTP server. All Claude Code sessions, Codex sessions, and any other agents connect to the same server on port 8666. They all share one database connection — full read/write for every session simultaneously.

```
smritix serve (one process on :8666)
  Claude session A → http://localhost:8666/mcp → read + write ✓
  Claude session B → http://localhost:8666/mcp → read + write ✓
  Codex session   → http://localhost:8666/mcp → read + write ✓
```

No lock conflicts. No read-only fallbacks.

</details>

---

<details>
<summary><strong>⚙️ Configuration (Environment Variables)</strong></summary>

Set in your shell or in `~/.smritix/.env`.

### Core

| Variable | Default | Description |
|----------|---------|-------------|
| `SMRITIX_DATA_DIR` | `~/.smritix` | Where database and logs are stored |
| `SMRITIX_MCP_PORT` | `8666` | Port for MCP server + portal |
| `SMRITIX_TOKEN_BUDGET` | `500` | Max tokens injected per `get_memories` call |
| `SMRITIX_SESSION_LOOKBACK_DAYS` | `7` | Days of history to process on first run (`0` = all) |

### Background processing (optional)

Configure via `smritix init` or set manually in `~/.smritix/.env`.

| Variable | Default | Description |
|----------|---------|-------------|
| `SMRITIX_PROVIDERS` | — | Comma-separated AI providers, e.g. `sub_claude,api_anthropic` |
| `SMRITIX_DRAFTER_MODEL` | `claude-haiku-4-5-20251001` | Model used for session analysis |
| `SMRITIX_OLLAMA_MODEL` | `llama3.2` | Ollama model (if `api_ollama` in providers) |
| `SMRITIX_OLLAMA_URL` | `http://localhost:11434` | Ollama server URL |

**API key security:** Smritix never stores API keys on disk. During `smritix init` you provide the **name** of an environment variable that holds your key (e.g. `ANTHROPIC_API_KEY`). That name is stored; the key itself is read from your shell at runtime.

| Variable | Default | Description |
|----------|---------|-------------|
| `SMRITIX_ANTHROPIC_KEY_VAR` | `ANTHROPIC_API_KEY` | Name of env var holding your Anthropic key |
| `SMRITIX_GEMINI_KEY_VAR` | `GEMINI_API_KEY` | Name of env var holding your Gemini key |
| `SMRITIX_OPENAI_KEY_VAR` | `OPENAI_API_KEY` | Name of env var holding your OpenAI key |

Set the actual key in your shell profile (e.g. `export ANTHROPIC_API_KEY=sk-ant-...`), not in `~/.smritix/.env`.

### Auto-approve

| Variable | Default | Description |
|----------|---------|-------------|
| `SMRITIX_AUTO_APPROVE_HOURS` | `24` | Auto-approve pending memories older than this |
| `SMRITIX_AUTO_APPROVE_THRESHOLD` | `0.75` | Minimum confidence to auto-approve |
| `SMRITIX_EXPIRE_DAYS` | `30` | Auto-reject pending memories older than this |

### Session file locations

| Variable | Default | Description |
|----------|---------|-------------|
| `SMRITIX_CLAUDE_SESSIONS_DIR` | `~/.claude/projects` | Claude Code session files |
| `SMRITIX_CODEX_SESSIONS_DIR` | `~/.codex` | Codex CLI session files |

</details>

---

<details>
<summary><strong>🛡️ Data & Privacy</strong></summary>

Everything stays on your machine:

- **Database:** `~/.smritix/smritix.duckdb` — back it up with `cp`
- **Embedding model:** `~/.smritix/models/` — downloaded once (~300MB), no internet needed after
- **No telemetry, no cloud sync**
- Background session analysis uses an AI API call (Claude Haiku by default) — the only external call

</details>

---

<details>
<summary><strong>💡 Tips — Getting the Most Out of Smritix</strong></summary>

**Say things out loud to your AI:**
- "No, we use DuckDB, not Postgres" → captured as correction
- "I always prefer trunk-based development" → captured as preference
- "Remember this: never mock the database in tests" → immediately saved

**At session start:**
- Smritix shows pending memories — say "all good" to approve all at once
- Or: "remove the second one" to reject specific items

**Don't:**
- Don't skip pending review for weeks — memories expire after 30 days
- Don't share `~/.smritix/` — it's your personal memory, not for teams
- Don't expect it to capture things you only think, not say

</details>

---

<details>
<summary><strong>🔌 MCP Tools Reference</strong></summary>

Smritix exposes 5 MCP tools. Your AI calls them automatically — you don't need to.

| Tool | When called | What it does |
|------|-------------|--------------|
| `get_memories` | Before every task | Returns relevant memories within 500-token budget |
| `list_pending_memories` | Session start | Shows memories awaiting your confirmation |
| `confirm_memory_tool` | After you review | Approves, rejects, or edits a pending memory |
| `add_memory` | "remember this" | Saves immediately, bypasses the queue |
| `delete_memory` | "remove this memory" | Archives a memory so it no longer appears in searches |

Session analysis (extracting memories from past sessions) is handled automatically by the background watcher — no MCP tools needed for that.

</details>

---

<details>
<summary><strong>👩‍💻 Contributing</strong></summary>

### Setup

```bash
git clone https://github.com/ParagPatil96/smritix
cd smritix
pip install -e ".[dev]"
```

### Tests & lint

```bash
hatch run test          # all tests
hatch run test -k name  # filter by name
hatch run lint          # ruff linter
```

### Run locally

```bash
smritix serve --debug          # verbose server logs
duckdb ~/.smritix/smritix.duckdb -ui   # inspect DB at http://localhost:4213
smritix reset --all            # wipe test data
```

### Adding a new AI tool reader

1. Create `smritix/agents/your_tool.py` — extend `AIAgentReader`
2. Implement `is_available()`, `list_sessions()`, `get_messages()`
3. Add to `_register()` in `smritix/agents/__init__.py`
4. Add tests in `tests/agents/test_your_tool.py`

### Submitting a PR

- Tests must pass: `hatch run test`
- Lint must pass: `hatch run lint`
- Add tests for new behaviour

### Reporting issues

- **Bug:** include `smritix serve --debug` output
- **Feature:** describe the problem you're solving

</details>

---

## Star History

<a href="https://star-history.com/#ParagPatil96/smritix&Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=ParagPatil96/smritix&type=Date&theme=dark"/>
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=ParagPatil96/smritix&type=Date"/>
    <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=ParagPatil96/smritix&type=Date"/>
  </picture>
</a>

---

*If Smritix is useful to you, a ⭐ helps others find it.*
