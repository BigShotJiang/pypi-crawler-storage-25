import uuid
import hashlib
import os
from typing import Optional, Union, Sequence, Dict, List
from brock.log import get_logger
from brock.config.config import Config
from brock.exception import ExecutorError, ConfigError


class Executor:
    '''Abstract class for all executors

    Provides the common functions all executors must implement or use default
    implementation defined here.
    '''

    def __init__(self, config: Config, name: str):
        self._log = get_logger()

        self._name = name

        self._base_dir = config.base_dir
        self._executor_hash = hashlib.sha256(f"{self._base_dir}-{uuid.getnode()}".encode()).hexdigest()
        self._conf = config.executors.get(name)
        self._default_shell = None

        self._env_vars = {
            'BROCK_HOST_PATH': config.work_dir,
            'BROCK_HOST_PROJECT_PATH': config.base_dir,
            'BROCK_RELATIVE_PATH': config.work_dir_rel,
        }

        self._help = ''

        if self._conf is not None:
            self._default_shell = self._conf.get('default_shell')
            self._help = self._conf.get('help', '')

    @property
    def name(self) -> str:
        return self._name

    @property
    def help(self) -> str:
        return self._help

    @property
    def default_shell(self) -> Optional[str]:
        return self._default_shell

    @property
    def env_vars(self) -> Dict:
        return self._env_vars

    def sync_in(self):
        '''Synchronizes local data to executor if needed'''
        pass

    def sync_out(self):
        '''Synchronizes local data out of executor if needed'''
        pass

    def status(self) -> str:
        return 'Idle'

    def start(self) -> int:
        return 0

    def stop(self):
        pass

    def restart(self) -> int:
        self.stop()
        return self.start()

    def update(self):
        pass

    def exec_in_shell(
        self,
        command: Union[str, Sequence[str]],
        shell: Optional[str] = None,
        work_dir: Optional[str] = None,
        env_options: dict = {}
    ) -> int:
        command_shell = Executor.get_shell_command(command, shell)
        return self.exec(command_shell, work_dir, env_options)

    def exec(self, command: Union[str, Sequence[str]], work_dir: Optional[str] = None, env_options: dict = {}) -> int:
        raise NotImplementedError

    def shell(self) -> int:
        '''Opens a shell session, if available'''
        raise ExecutorError("This executor doesn't support direct shell access")

    @staticmethod
    def get_shell_command(command, shell) -> List[str]:
        if shell is None:
            return command
        elif shell in ('sh', 'bash', 'zsh', 'powershell'):
            command_shell = [shell, '-c']
            separator = '; '
        elif shell == 'powershell':
            command_shell = [shell, '-Command']
            separator = '; '
        elif shell == 'cmd':
            command_shell = [shell, '/C']
            separator = ' & '
        else:
            raise ConfigError(f'Unsupported shell: {shell}')

        lines = [ln.strip() for ln in command.splitlines() if ln.strip()]
        command_shell.append(separator.join(lines))

        return command_shell

    def _process_env_vars(self):
        '''Process environment variables defined in config'''
        env_config = self._conf.get('env', {})

        for env_var, value in env_config.items():
            if isinstance(value, dict):
                description = value.get('description')
                default = value.get('default')
                to_prompt = value.get('prompt')

                env_val = default

                if to_prompt is True:
                    env_val = self._prompt_env_var(env_var, description, default)
                elif to_prompt is False:
                    if env_var in os.environ:
                        env_val = os.environ[env_var]
                else:
                    # to_prompt is None
                    if env_var in os.environ:
                        env_val = os.environ[env_var]
                    else:
                        env_val = self._prompt_env_var(env_var, description, default)

                if env_val is None:
                    raise ConfigError(f'Environment variable {env_var} is missing value')
                else:
                    self._env_vars[env_var] = env_val
            else:
                self._env_vars[env_var] = value

    def _prompt_env_var(self, var: str, description: Optional[str] = None, default: Optional[str] = None) -> str:
        '''Prompts for an environment variable'''
        prompt_str = f'>> Enter value for environment variable "{var}"'

        if description is not None:
            prompt_str += f' [{description}]'

        if default is not None:
            prompt_str += f' (default: {default})'

        try:
            val = input(f'{prompt_str}: ').strip()
            if val == '' and default is not None:
                return default
            else:
                return val
        except KeyboardInterrupt:
            raise ExecutorError(f'Environment variable {var} is missing value')
