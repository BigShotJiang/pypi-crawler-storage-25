import os
import sys
import subprocess
import docker
import time
import re
import click

from abc import ABC
from typing import Optional, Union, Sequence, Dict, List, Any, Iterator
from brock.log import get_logger
from brock.executors import Executor
from brock.config.config import Config
from brock.exception import ExecutorError
from paramiko.ssh_exception import AuthenticationException, SSHException
from socket import gaierror as SocketGaierror

DOCKER_SOCK_PATH = '/var/run/docker.sock'


class Container:
    '''Docker container abstraction'''

    def __init__(
        self,
        name: str,
        platform: Optional[str] = 'linux',
        image: Optional[str] = None,
        dockerfile: Optional[str] = None,
        env: Dict[str, Any] = {},
        mac_address: Optional[str] = None,
        ports: Dict[Union[str, int], int] = {},
        privileged: bool = False,
        devices: List[str] = [],
        volumes: Dict[str, Dict[str, Any]] = {},
        host_container_id: Optional[str] = None,
        docker_host: Optional[str] = None
    ):
        self.name = name
        self._platform = platform
        self._dockerfile = dockerfile
        self._env = env
        self._mac_address = mac_address
        self._ports = ports
        self._privileged = privileged
        self._devices = devices
        self._volumes = volumes
        self._host_container_id = host_container_id
        self._docker_host = docker_host

        self._log = get_logger()

        if self._dockerfile:
            image_parts = [self.name]
        elif image:
            image_parts = image.split(':')
        else:
            raise ExecutorError('Image or dockerfile must be defined')

        if len(image_parts) == 2:
            self._image_name = image_parts[0]
            self._image_tag = image_parts[1]
        elif len(image_parts) == 1:
            self._image_name = image_parts[0]
            self._image_tag = 'latest'
        else:
            raise ExecutorError('Invalid docker image')

    @property
    def _docker(self) -> docker.DockerClient:
        try:
            if self._docker_host:
                return docker.DockerClient(base_url=self._docker_host)
            else:
                return docker.from_env()
        except docker.errors.DockerException as ex:
            raise ExecutorError(f'Docker engine is not running: {ex}')
        except (AuthenticationException, SSHException) as ex:
            raise ExecutorError(f'Failed to authenticate with Docker engine ({self._docker_host}): {ex}')
        except SocketGaierror as ex:
            raise ExecutorError(f'Invalid or unreachable Docker host ({self._docker_host}): {ex}')

    @property
    def _container(self):
        try:
            return self._docker.containers.get(self.name)
        except docker.errors.NotFound:
            raise ExecutorError('Docker container not found')

    @property
    def _image(self):
        try:
            return self._docker.images.get(f'{self._image_name}:{self._image_tag}')
        except docker.errors.ImageNotFound:
            return None

    @property
    def _isolation(self) -> Optional[str]:
        if self._platform == 'windows':
            if self._image is None:
                raise ExecutorError('Docker is probably switched to incorrect platform')
            image_version = self._image.attrs['OsVersion'].split('.')[:3]
            info = self._docker.info()
            os_version = info['OSVersion'].split('.')[:3]
            if '.'.join(image_version) == '.'.join(os_version):
                return 'process'
            return 'hyperv'
        return None

    def is_running(self) -> bool:
        try:
            self._docker.containers.get(self.name)
        except docker.errors.NotFound as ex:
            return False
        return True

    def start(self) -> None:
        if self.is_running():
            return

        if self._image is None:
            self.update()

        self._log.info(f'Starting container {self.name}')
        self._create_volumes()
        try:
            res = self._docker.containers.run(
                image=f'{self._image_name}:{self._image_tag}',
                name=self.name,
                auto_remove=True,
                detach=True,
                stdin_open=True,
                environment=self._env,
                mac_address=self._mac_address,
                ports=self._ports,
                privileged=self._privileged,
                platform=self._platform,
                isolation=self._isolation,
                devices=self._devices,
                volumes=self._volumes,
            )
            self._log.debug(res)
        except docker.errors.APIError as ex:
            raise ExecutorError(f'Failed to start container: {ex}')

    def stop(self, delete_volumes: bool = True) -> None:
        if not self.is_running():
            return
        self._log.info(f'Stopping container {self.name}')
        try:
            container = self._container
            container.stop()
            container.wait(timeout=60, condition='removed')
        except (ExecutorError, docker.errors.NotFound):
            pass
        if delete_volumes:
            self._delete_volumes()

    def update(self) -> None:
        if self._dockerfile:
            self._build()
        else:
            self._pull()

        if self.is_running():
            self.stop()

    def exec(
        self,
        command: Union[str, Sequence[str]],
        work_dir: Optional[str] = None,
        env_options: dict = {},
        user: Optional[str] = None
    ) -> int:
        if not self.is_running():
            self.start()

        flags = '-it' if sys.stdin.isatty() else '-i'
        cli_cmd = ['exec', flags]
        if work_dir:
            cli_cmd.extend(['-w', work_dir])
        if user:
            cli_cmd.extend(['-u', user])
        for k, v in env_options.items():
            cli_cmd.extend(['-e', f'{k}={v}'])
        cli_cmd.append(self.name)
        cli_cmd.extend([command] if isinstance(command, str) else command)

        cli_env = os.environ.copy()
        cli_env['DOCKER_CLI_HINTS'] = 'false'

        self._log.extra_info(f'Executing command in container {self.name}: {command}')
        if work_dir:
            self._log.debug(f'Work dir: {work_dir}')

        ret = self._docker_cli(cli_cmd, cli_env)
        return ret.returncode

    def shell(self, shell: str, work_dir: str) -> int:
        return self.exec(shell, work_dir)

    def inc_active_sessions_cnt(self) -> int:
        inc = (
            'cnt=$(cat /tmp/brock.cnt 2>/dev/null || echo 0);'
            'cnt=$((cnt + 1));'
            'echo $cnt > /tmp/brock.cnt;'
            'echo $cnt'
        )
        command = ['exec', '-it', self.name, 'flock', '/tmp/brock.lock', '-c', inc]
        try:
            cnt = int(self._docker_cli(command, capture_output=True).stdout)
            self._log.debug(f'Incrementing number of active sessions to {cnt}')
            return cnt
        except:
            return 0

    def dec_active_sessions_cnt(self) -> int:
        dec = (
            'cnt=$(cat /tmp/brock.cnt 2>/dev/null || echo 0);'
            'cnt=$((cnt > 0 ? cnt - 1 : 0));'
            'echo $cnt > /tmp/brock.cnt;'
            'echo $cnt'
        )
        command = ['exec', '-it', self.name, 'flock', '/tmp/brock.lock', '-c', dec]
        try:
            cnt = int(self._docker_cli(command, capture_output=True).stdout)
            self._log.debug(f'Decrementing number of active sessions to {cnt}')
            return cnt
        except:
            return 0

    def get_active_sessions_cnt(self) -> int:
        command = ['exec', '-it', self.name, 'flock', '/tmp/brock.lock', '-c', 'cat /tmp/brock.cnt']
        try:
            return int(self._docker_cli(command, capture_output=True).stdout)
        except:
            return 0

    def _docker_cli(
        self, command: Sequence[str], env: dict = {}, capture_output: bool = False
    ) -> subprocess.CompletedProcess:
        self._log.debug(f'Executing Docker CLI command: {command}')
        cli_env = env.copy()
        if self._docker_host:
            cli_env['DOCKER_HOST'] = self._docker_host

        try:
            return subprocess.run(['docker'] + list(command), env=cli_env, capture_output=capture_output)
        except subprocess.SubprocessError as ex:
            raise ExecutorError(f'Failed to execute Docker CLI command: {ex}')

    def _create_volumes(self) -> None:
        '''Creates named volumes used by the container'''
        try:
            volumes = [x.name for x in self._docker.volumes.list()]
        except docker.errors.APIError as ex:
            raise ExecutorError(f'Failed to list volumes: {ex}')

        if self._host_container_id is not None:
            # Docker in Docker - all volumes tied to host container must be remapped to the host paths,
            # becasue DinD uses the host Docker engine
            try:
                res = self._docker.api.inspect_container(self._host_container_id)
                dind_mounts = res.get('Mounts', [])
            except docker.errors.APIError as ex:
                raise ExecutorError(f'Failed to inspect container: {ex}')
        else:
            dind_mounts = []

        new_volumes = self._volumes.copy()
        for name in self._volumes:
            host_mount = False
            for mount in dind_mounts:
                src_path = mount['Source']
                to_path = mount['Destination']
                if os.path.commonpath((name, to_path)) == to_path:
                    # volume tied to host container mount - remap the volume to the host path
                    new_path = name.replace(to_path, src_path)
                    self._log.debug(f'Volume {name} is tied to host container path {new_path}')
                    del new_volumes[name]
                    new_volumes[new_path] = self._volumes[name]
                    host_mount = True
                    break
            if host_mount or os.path.exists(name) or name == DOCKER_SOCK_PATH:
                # volume tied to host container or physical path
                continue

            if name not in volumes:
                self._log.extra_info(f'Creating volume {name}')
                try:
                    self._docker.volumes.create(name)
                except docker.errors.APIError as ex:
                    raise ExecutorError(f'Failed to create volume: {ex}')
        self._volumes = new_volumes

    def _delete_volumes(self) -> None:
        '''Deletes named volumes used by the container'''
        try:
            volumes = [x.name for x in self._docker.volumes.list()]
        except docker.errors.APIError as ex:
            raise ExecutorError(f'Failed to list volumes: {ex}')

        for name in self._volumes:
            if name not in volumes:
                continue

            self._log.extra_info(f'Deleting volume {name}')
            try:
                self._docker.volumes.get(name).remove(force=True)
            except docker.errors.APIError as ex:
                raise ExecutorError(f'Failed to delete volume: {ex}')

    def _build(self):
        self._log.info(f'Building Docker image from {self._dockerfile}')
        if not os.path.exists(self._dockerfile):
            raise ExecutorError(f'Dockerfile not found: {self._dockerfile}')

        dockerdir = os.path.dirname(self._dockerfile)
        try:
            generator = self._docker.api.build(
                dockerfile=self._dockerfile,
                path=dockerdir,
                platform=self._platform,
                tag=f'{self._image_name}:{self._image_tag}',
                decode=True
            )
            try:
                for chunk in generator:
                    if 'stream' in chunk:
                        print(chunk['stream'], end='')
            except KeyboardInterrupt:
                self._log.warning('Execution interrupted')

        except (docker.errors.BuildError, docker.errors.APIError) as e:
            raise ExecutorError(f'Unable to build image: {str(e)}')

    def _pull(self):
        self._log.info(f'Pulling image {self._image_name}:{self._image_tag}')
        try:
            generator = self._docker.api.pull(
                self._image_name, self._image_tag, platform=self._platform, stream=True, decode=True
            )
            try:
                for chunk in generator:
                    if 'progress' not in chunk and 'status' in chunk:
                        print(f"{chunk.get('id', '')} -> {chunk['status']}")
            except KeyboardInterrupt:
                self._log.warning('Execution interrupted')

        except docker.errors.APIError as ex:
            raise ExecutorError(f'Failed to pull image: {ex}')


class MutagenBase(ABC):
    '''Base class for Mutagen session management'''

    @staticmethod
    def _run(cmd: List[str], env: Optional[Dict[str, str]] = None) -> subprocess.CompletedProcess:
        sync_env = os.environ.copy()
        if env:
            sync_env.update(env)

        return subprocess.run(cmd, env=sync_env, capture_output=True, text=True)

    @staticmethod
    def check_installed():
        '''Check if Mutagen is installed and available in PATH.'''
        try:
            subprocess.run(['mutagen', 'version'], check=True, capture_output=True, text=True)
        except FileNotFoundError:
            raise FileNotFoundError('Mutagen CLI is not found in PATH.')


class MutagenSync(MutagenBase):
    '''Mutagen sync session management'''

    _MUTAGEN_DEFAULT_OPTIONS = [
        '--permissions-mode=manual',
        '--default-file-mode-beta=0744',
        '--default-directory-mode-beta=0755',
    ]

    @staticmethod
    def create(
        session_name: str, local_path: str, target: str, options: List[str] = [], env: Optional[Dict[str, str]] = None
    ):
        '''Creates a new Mutagen sync session.'''

        run_options = MutagenSync._MUTAGEN_DEFAULT_OPTIONS.copy()
        if options:
            run_options.extend(options)

        cmd = ['mutagen', 'sync', 'create', '--name', session_name] + run_options + [local_path, target]

        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to create Mutagen sync session: {ret.stderr}')

    @staticmethod
    def list(env: Optional[Dict[str, str]] = None) -> Iterator[Dict[str, Any]]:
        '''Returns a list of all active Mutagen sync sessions.'''
        cmd = ['mutagen', 'sync', 'list']
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError('Failed to list Mutagen sync sessions')

        session: Dict[str, Any] = {}

        for line in ret.stdout.splitlines():
            line = line.strip()
            if line.startswith('Name:'):
                if session:
                    # we reached next session -> yield current session
                    yield session
                    session = {}
                session['name'] = line.split(':', 1)[1].strip()
            elif line.startswith('Identifier:'):
                session['identifier'] = line.split(':', 1)[1].strip()
            elif line.startswith('Alpha:'):
                session['alpha'] = {}
            elif line.startswith('Beta:'):
                session['beta'] = {}
            elif line.startswith('Status:'):
                status = line.split(':', 1)[1].strip()
                session['status'] = status
            elif line.startswith('Staging progress:'):
                match = re.search(r'(\d+)%', line)
                if match:
                    session['progress'] = int(match.group(1))
            elif line.startswith('URL:') and 'alpha' in session and 'beta' not in session:
                session['alpha']['url'] = line.split(':', 1)[1].strip()
            elif line.startswith('Connected:') and 'alpha' in session and 'beta' not in session:
                session['alpha']['connected'] = line.split(':', 1)[1].strip() == 'Yes'
            elif line.startswith('URL:') and 'beta' in session:
                session['beta']['url'] = line.split(':', 1)[1].strip()
            elif line.startswith('Connected:') and 'beta' in session:
                session['beta']['connected'] = line.split(':', 1)[1].strip() == 'Yes'
            elif line.startswith('Conflicts:'):
                session['conflicts'] = int(line.split(':', 1)[1].strip())

        if session:
            # yield the last session
            yield session

    @staticmethod
    def get(session_name: str, env: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
        '''Returns a specific Mutagen sync session by name.'''
        try:
            return next((s for s in MutagenSync.list(env=env) if s['name'] == session_name), None)
        except (KeyError, StopIteration):
            return None

    @staticmethod
    def wait(session_name: str, timeout: int = 900, env: Optional[Dict[str, str]] = None):
        '''Waits for a specific Mutagen sync session to complete sync.'''
        start = time.time()
        with click.progressbar(length=100, label='Mutagen sync', show_percent=True) as bar:
            while True:
                if time.time() - start > timeout:
                    raise ExecutorError('Mutagen sync timed out')
                session = MutagenSync.get(session_name, env=env)
                if not session:
                    raise ExecutorError('Mutagen sync session not found')

                status = session.get('status', '')
                progress = session.get('progress', 0)

                bar.label = f'Mutagen sync progress:'
                bar.update(progress - bar.pos)

                if status == 'Watching for changes':
                    bar.update(100 - bar.pos)
                    break
                time.sleep(1)

    @staticmethod
    def terminate(session_name: str, env: Optional[Dict[str, str]] = None):
        '''Terminates a specific Mutagen sync session.'''
        cmd = ['mutagen', 'sync', 'terminate', session_name]
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to terminate Mutagen sync session: {ret.stderr}')

    @staticmethod
    def flush(session_name: str, env: Optional[Dict[str, str]] = None):
        '''Flushes a specific Mutagen sync session.'''
        cmd = ['mutagen', 'sync', 'flush', session_name]
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to flush Mutagen sync session: {ret.stderr}')

    @staticmethod
    def pause(session_name: str, env: Optional[Dict[str, str]] = None):
        '''Pauses a specific Mutagen sync session.'''
        cmd = ['mutagen', 'sync', 'pause', session_name]
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to pause Mutagen sync session: {ret.stderr}')

    @staticmethod
    def resume(session_name: str, env: Optional[Dict[str, str]] = None):
        '''Resumes a specific Mutagen sync session.'''
        cmd = ['mutagen', 'sync', 'resume', session_name]
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to resume Mutagen sync session: {ret.stderr}')


class MutagenForward(MutagenBase):
    '''Mutagen forward session management'''

    @staticmethod
    def create(
        session_name: str,
        source: str,
        destination: str,
        options: List[str] = [],
        env: Optional[Dict[str, str]] = None
    ):
        '''Creates a new Mutagen forward session with retries.'''

        cmd = ['mutagen', 'forward', 'create', '--name', session_name] + [source, destination] + options

        # Retry up to 3 times as the ports might not be available right after container start
        for _ in range(3):
            ret = MutagenBase._run(cmd, env)
            if ret.returncode == 0:
                return
            time.sleep(2)

        raise ExecutorError(f'Failed to create Mutagen forward session: {ret.stderr}')

    @staticmethod
    def list(env: Optional[Dict[str, str]] = None) -> Iterator[Dict[str, Any]]:
        '''Returns a list of all active Mutagen forward sessions.'''
        cmd = ['mutagen', 'forward', 'list']
        ret = MutagenBase._run(cmd, env)

        if ret.returncode != 0:
            raise ExecutorError('Failed to list Mutagen forward sessions')

        session: Dict[str, Any] = {}

        for line in ret.stdout.splitlines():
            line = line.strip()
            if line.startswith('Name:'):
                if session:
                    # we reached next session -> yield current session
                    yield session
                    session = {}
                session['name'] = line.split(':', 1)[1].strip()
            elif line.startswith('Identifier:'):
                session['identifier'] = line.split(':', 1)[1].strip()
            elif line.startswith('Status:'):
                status = line.split(':', 1)[1].strip()
                session['status'] = status

        if session:
            # yield the last session
            yield session

    @staticmethod
    def get(session_name: str, env: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
        '''Returns a specific Mutagen forward session by name.'''
        try:
            return next((s for s in MutagenForward.list(env=env) if s['name'] == session_name), None)
        except (KeyError, StopIteration):
            return None

    @staticmethod
    def terminate(session_name: str, env: Optional[Dict[str, str]] = None):
        '''Terminates a specific Mutagen forward session.'''
        cmd = ['mutagen', 'forward', 'terminate', session_name]
        ret = MutagenBase._run(cmd, env)
        if ret.returncode != 0:
            raise ExecutorError(f'Failed to terminate Mutagen forward session: {ret.stderr}')


class DockerExecutor(Executor):
    '''Executor for docker based toolchains

    The executor launches the docker container automatically when needed. If the
    image is not found, it's pulled before first run.
    '''
    _HOST_PATH = '/host'
    _RSYNC_PATH = '/rsync_volume'

    def __init__(self, config: Config, name: str):
        '''Initializes Docker executor

        :param config: A whole brock configuration
        :param name: Name of the executor
        '''
        super().__init__(config, name)
        self._docker_host = self._resolve_docker_host(self._conf.get('host'), self._conf.get('username'))
        self._platform = self._conf.get('platform', 'linux')
        self._prepare = self._conf.get('prepare', [])

        self._host_container_id = None
        if self._platform == 'linux':
            # detect if we are running inside a container - try to extract container ID from /proc/self/mountinfo
            # Docker in Docker can only be used on Linux hosts
            try:
                with open('/proc/self/mountinfo', 'rb') as f:
                    hostname_mount = re.compile(r'/containers/([a-z0-9]{64})/hostname')
                    for line in f.readlines():
                        m = hostname_mount.search(line.decode())
                        if m:
                            self._host_container_id = m.group(1)
                            self._log.debug(f'Brock is running inside container {self._host_container_id[:12]}')
                            break
            except FileNotFoundError:
                pass

        if self._default_shell is None:
            if self._platform == 'windows':
                self._default_shell = 'cmd'
            else:
                self._default_shell = 'sh'

        if self._platform == 'windows':
            self._mount_dir = f'C:{self._HOST_PATH}'
        else:
            self._mount_dir = self._HOST_PATH
        self._work_dir_rel = config.work_dir_rel.replace('\\', '/')
        self._work_dir = os.path.join(self._mount_dir, self._work_dir_rel).replace('\\', '/')

        if 'sync' in self._conf:
            self._sync_options = self._conf.sync.get('options', None)
            self._sync_filter = self._conf.sync.get('filter', [])
            self._sync_include = self._conf.sync.get('include', [])
            self._sync_exclude = self._conf.sync.get('exclude', [])
            self._sync_type = self._conf.sync.type
        else:
            self._sync_type = None

        self._sync_forward = None
        self._sync_container = None
        self._synced_in = False
        if self._sync_type == 'rsync':
            self._sync_exclude = self._conf.sync.get('exclude', [])

            self._sync_volume_name = f'brock-{config.project}-rsync-volume-{self._executor_hash}'

            self._sync_container = Container(
                f'brock-{config.project}-rsync-{self._executor_hash}',
                platform='linux',
                image='eeacms/rsync:2.3',
                volumes={
                    self._sync_volume_name: {
                        'bind': self._RSYNC_PATH,
                        'mode': 'rw'
                    },
                    self._base_dir: {
                        'bind': self._HOST_PATH,
                        'mode': 'rw'
                    }
                }
            )
            volumes = {self._sync_volume_name: {'bind': self._mount_dir, 'mode': 'rw'}}
        elif self._sync_type == 'mutagen':
            self._sync_auto_pause = self._conf.sync.get('auto_pause', True)
            try:
                MutagenBase.check_installed()
                self._sync_volume_name = f'brock-{config.project}-{self.name}-mutagen-volume-{self._executor_hash}'
                volumes = {self._sync_volume_name: {'bind': self._mount_dir, 'mode': 'rw'}}
                self._sync_forward = self._init_sync_forward()
            except FileNotFoundError:
                self._log.warning(
                    'Mutagen is not installed. Install it from https://mutagen.io/documentation/introduction/installation/.'
                )
                self._log.info(f'Disabling Mutagen sync for executor {self.name}')
                self._sync_type = None
                volumes = {self._base_dir: {'bind': self._mount_dir, 'mode': 'rw'}}
        else:
            volumes = {self._base_dir: {'bind': self._mount_dir, 'mode': 'rw'}}

        if self._platform == 'linux':
            # for Docker in Docker, we need to mount the docker socket from the host
            volumes[DOCKER_SOCK_PATH] = {'bind': DOCKER_SOCK_PATH, 'mode': 'rw'}

        dockerfile = None
        if 'dockerfile' in self._conf:
            dockerfile = os.path.join(self._base_dir, self._conf['dockerfile'])

        self._container = Container(
            f'brock-{config.project}-{name}-{self._executor_hash}',
            platform=self._platform,
            image=self._conf.get('image'),
            dockerfile=dockerfile,
            env=self.env_vars,
            mac_address=self._conf.get('mac_address', None),
            ports=self._conf.get('ports'),
            privileged=self._conf.get('privileged', False),
            devices=self._conf.get('devices', []),
            volumes=volumes,
            host_container_id=self._host_container_id,
            docker_host=self._docker_host,
        )

    @property
    def _mutagen_env(self) -> Dict[str, str]:
        '''Set Docker host variable according to https://mutagen.io/documentation/transports/docker/#environment-variables/.'''
        env = {}
        if self._docker_host:
            env['DOCKER_HOST'] = self._docker_host  # Mutagen forward host
            env['MUTAGEN_BETA_DOCKER_HOST'] = self._docker_host  # Mutagen sync host
        return env

    def sync_in(self):
        if not self._container.is_running():
            self._log.info('Executor not running -> starting')
            self.start()

        if self._sync_type is None:
            return

        if self._sync_type == 'rsync':
            if self._sync_container is None:
                return
            self._log.extra_info(f'Rsyncing data into docker volume')
            self._rsync(self._HOST_PATH, self._RSYNC_PATH)
        elif self._sync_type == 'mutagen':
            try:
                if not MutagenSync.get(self._sync_volume_name, env=self._mutagen_env):
                    self._create_mutagen_session()
                    MutagenSync.wait(self._sync_volume_name, env=self._mutagen_env)
                else:
                    self._log.extra_info('Resuming Mutagen sync')
                    MutagenSync.resume(self._sync_volume_name, env=self._mutagen_env)
                    self._log.extra_info('Flushing Mutagen sync')
                    MutagenSync.flush(self._sync_volume_name, env=self._mutagen_env)

                for i, forward in enumerate(self._sync_forward):
                    session_name = f'{self._sync_volume_name}-forward-{i}'
                    if not MutagenForward.get(session_name, env=self._mutagen_env):
                        self._create_mutagen_forward_session(session_name, forward)

                sync = MutagenSync.get(self._sync_volume_name, env=self._mutagen_env)
                if sync and 'conflicts' in sync:
                    self._log.warning(f'Mutagen sync has {sync["conflicts"]} conflicts')
            except ExecutorError as ex:
                self._log.warning(ex.message)
            except (AuthenticationException, SSHException) as ex:
                raise ExecutorError(f'Failed to authenticate with remote host: {ex}')
        else:
            raise ExecutorError('Unknown sync type')

        self._synced_in = True

    def sync_out(self):
        if not self._synced_in:
            return

        if self._sync_type == 'rsync':
            if self._sync_container is None:
                return
            self._log.extra_info(f'Rsyncing data out of docker volume')
            self._rsync(self._RSYNC_PATH, self._HOST_PATH)
        elif self._sync_type == 'mutagen':
            try:
                self._log.extra_info('Flushing mutagen sync')
                MutagenSync.flush(self._sync_volume_name, env=self._mutagen_env)
                if self._container.get_active_sessions_cnt() == 0:
                    if self._sync_auto_pause:
                        self._log.extra_info('Pausing Mutagen sync')
                        MutagenSync.pause(self._sync_volume_name, env=self._mutagen_env)
            except ExecutorError as ex:
                self._log.warning(ex.message)
        else:
            raise ExecutorError('Unknown sync type')

        self._synced_in = False

    def status(self) -> str:
        res = 'Stopped'
        if self._container.is_running() and (self._sync_container is None or self._sync_container.is_running()):
            res = 'Running'
        res += f'\n\t{self._container.name}'
        if self._sync_container is not None:
            res += f'\n\t{self._sync_container.name}'
        return res

    def start(self) -> int:
        if self._container.is_running():
            return 0

        self._process_env_vars()

        self._container.start()

        if self._sync_type is not None and self._platform == 'linux':
            self._set_sync_permissions()

        if not self._synced_in:
            self.sync_in()

        for command in self._prepare:
            shell_command = [self.default_shell, '-c', command] if self.default_shell else command
            exit_code = self._container.exec(shell_command, self._mount_dir)
            if exit_code != 0:
                self._log.error('Failed to execute prepare steps')
                self._container.stop()
                return exit_code
        return 0

    def stop(self):
        if 'sync' in self._conf:
            if self._sync_type == 'rsync' and self._sync_container:
                self._sync_container.stop(delete_volumes=False)
            elif self._sync_type == 'mutagen':
                try:
                    if MutagenSync.get(self._sync_volume_name, env=self._mutagen_env):
                        self._log.extra_info(f'Terminating Mutagen sync session {self._sync_volume_name}')
                        MutagenSync.terminate(self._sync_volume_name, env=self._mutagen_env)

                    for i, _ in enumerate(self._sync_forward):
                        session_name = f'{self._sync_volume_name}-forward-{i}'
                        if MutagenForward.get(session_name, env=self._mutagen_env):
                            self._log.extra_info(f'Terminating Mutagen forward session {session_name}')
                            MutagenForward.terminate(session_name, env=self._mutagen_env)

                except ExecutorError as ex:
                    self._log.warning(ex.message)

        self._container.stop()

    def update(self):
        self._container.update()

    def exec(self, command: Union[str, Sequence[str]], chdir: Optional[str] = None, env_options: dict = {}) -> int:
        if not self._container.is_running():
            self._log.info('Executor not running -> starting')
            exit_code = self.start()
            if exit_code != 0:
                return exit_code

        self._container.inc_active_sessions_cnt()

        if not self._synced_in:
            self.sync_in()

        directory = self._work_dir
        if chdir:
            directory = self._mount_dir + '/' + chdir
        ret = self._container.exec(command, directory, env_options)

        self._container.dec_active_sessions_cnt()

        return ret

    def shell(self) -> int:
        shell = self.default_shell
        if shell is None:
            raise ExecutorError('Shell is not defined')

        if not self._container.is_running():
            self._log.info('Executor not running -> starting')
            self.start()

        self._container.inc_active_sessions_cnt()

        if not self._synced_in:
            self.sync_in()

        ret = self._container.shell(shell, self._work_dir)

        self._container.dec_active_sessions_cnt()

        return ret

    def _init_sync_forward(self) -> List[str]:
        '''Initializes port forwarding for Mutagen sessions.'''
        forward = []
        if self._docker_host is not None and self._sync_type == 'mutagen':
            # Automatically forward ports for remote hosts
            ports = self._conf.get('ports', {})
            for container_port, host_port in ports.items():
                protocol = 'tcp'
                if isinstance(container_port, str) and '/' in container_port:
                    container_port, protocol = container_port.split('/')

                if protocol.lower() == 'udp':
                    self._log.warning(f'Port {container_port}/udp cannot be forwarded (Mutagen only supports TCP)')
                    continue

                forward.append(f'{host_port}:{container_port}')
        return forward

    def _create_mutagen_session(self):
        '''According to https://mutagen.io/documentation/transports/docker/.'''
        self._log.info('Creating Mutagen sync session')

        options = list(self._sync_options or [])

        # Configure as two-way-resolved by default
        if not any('--sync-mode' in opt for opt in options):
            options.append('--sync-mode=two-way-resolved')

        if self._sync_exclude:
            options.append(f'--ignore={"/*,".join(self._sync_exclude)}/*')

        target = f'docker://{self._container.name}{self._mount_dir}'

        MutagenSync.create(self._sync_volume_name, self._base_dir, target, options, env=self._mutagen_env)

    def _create_mutagen_forward_session(self, session_name: str, forward: str):
        '''Creates a Mutagen forward session.'''

        parts = forward.split(':')
        source = f'tcp:localhost:{parts[0]}'
        destination = f'docker://{self._container.name}:tcp:localhost:{parts[1]}'

        self._log.info(f'Creating Mutagen forward session for {forward}')
        self._log.debug(f'{source} <-> {destination}')

        MutagenForward.create(session_name, source, destination, env=self._mutagen_env)

    def _set_sync_permissions(self):
        self._log.debug(f'Setting correct permissions for sync volume {self._sync_volume_name}')
        try:
            self._container.exec(['chmod', '-R', '777', self._mount_dir], user='root')
        except Exception as ex:
            self._log.warning(f'Failed to set correct permissions for sync volume {self._sync_volume_name}: {ex}')

    def _resolve_docker_host(self, host: Optional[str], username: Optional[str]) -> Optional[str]:
        '''
        Resolve docker host to adhere to required format in case of remote host.

        If username is provided, prepend 'username@' prefix.
        '''
        SSH_PREFIX = 'ssh://'

        if host is not None and not host.startswith(SSH_PREFIX):
            username_prefix = f'{username}@' if username else ''
            return f'{SSH_PREFIX}{username_prefix}{host}'

        return host

    def _rsync(self, src: str, dest: str):
        if self._sync_container is None:
            return 0

        if self._sync_options is not None:
            options = []
            for option in self._sync_options:
                options.extend(option.split(' '))
        else:
            # use default options
            options = ['-a', '--delete']

        for filter_ in self._sync_filter:
            options.extend(['--filter', filter_])
        for include in self._sync_include:
            options.extend(['--include', include])
        for exclude in self._sync_exclude:
            options.extend(['--exclude', exclude])

        command = ['rsync'] + options + [f'{src}/', f'{dest}/']
        exit_code = self._sync_container.exec(command, '/')
        if exit_code != 0:
            raise ExecutorError(f'Failed to rsync data')
        return exit_code
