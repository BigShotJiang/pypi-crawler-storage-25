import os
import yaml
from copy import deepcopy
from schema import Schema, And, Or, Use, Optional, Regex, SchemaError
import typing as t
from munch import Munch
from pathlib import Path

from brock import __version__
from brock.exception import ConfigError
from brock.log import get_logger


class Config(Munch):
    '''
    Manages loading, validation, and access to Brock configurations.

    This class scans for hierarchical configuration files (e.g., .brock.yml),
    merges them, validates against a schema, and provides dot-notation access
    to the resulting configuration values, inheriting from Munch.
    '''

    SCHEMA_ENV = {
        str:
            Or(
                str, int, float, bool, {
                    Optional('description'): str,
                    Optional('prompt'): bool,
                    Optional('default'): Or(str, int, float, bool),
                }
            )
    }

    SCHEMA_DOCKER_EXECUTOR_BASE = {
        'type': 'docker',
        Optional('help'): str,
        Or('image', 'dockerfile', only_one=True): str,
        Optional('platform'): str,
        Optional('privileged', default=False): bool,
        Optional('env'): SCHEMA_ENV,
        Optional('mac_address'): And(str, Regex(r'^([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})$')),
        Optional('ports', default={}): {
            Or(int, And(str, Regex(r'^\d+/(tcp|udp|sctp)'))): int
        },
        Optional('devices'): [str],
        Optional('prepare'): [str],
        Optional('default_shell'): str,
        Optional('extends'): str,
    }

    SCHEMA_SYNC_RSYNC = {
        'type': 'rsync',
        Optional('options'): [str],
        Optional('filter'): [str],
        Optional('include'): [str],
        Optional('exclude'): [str],
    }

    SCHEMA_SYNC_MUTAGEN = {
        'type': 'mutagen',
        Optional('options'): [str],
        Optional('exclude'): [str],
        Optional('auto_pause', default=True): bool,
    }

    SCHEMA = {
        'version': And(str, Regex(r'^[0-9]+.[0-9]+.[0-9]+$')),
        'project': str,
        Optional('help'): str,
        Optional('default_cmd'): str,
        Optional('commands', default={}): {
            Optional('default'): str,
            str: {
                Optional('default_executor'): str,
                Optional('chdir'): str,
                Optional('help'): str,
                Optional('depends_on'): [str],
                Optional('options'): {
                    Optional(str):
                        Or({
                            'flag': Use(str),
                            Optional('default'): any,
                            Optional('short_name'): any,
                            Optional('variable'): str,
                            Optional('help'): str
                        }, {
                            'argument': Use(str),
                            Optional('default'): any,
                            Optional('required'): bool,
                            Optional('choices'): [any],
                            Optional('variable'): str,
                            Optional('help'): str
                        }, {
                            Optional('option', default=True): Use(str),
                            Optional('default'): any,
                            Optional('short_name'): any,
                            Optional('choices'): [any],
                            Optional('variable'): str,
                            Optional('required'): bool,
                            Optional('help'): str
                        })
                },
                Optional('steps'): [Or(str, {
                    Optional('executor'): str,
                    Optional('shell'): str,
                    'script': str
                })],
            }
        },
        Optional('executors', default={}): {
            Optional('default'):
                str,
            Optional(str):
                Or({
                    **SCHEMA_DOCKER_EXECUTOR_BASE,
                    Optional('sync'): Or({**SCHEMA_SYNC_RSYNC}, {**SCHEMA_SYNC_MUTAGEN}),
                }, {
                    **SCHEMA_DOCKER_EXECUTOR_BASE,
                    'sync': SCHEMA_SYNC_MUTAGEN,
                    'host': And(str, len),
                    Optional('username'): str,
                }, {
                    'type': 'ssh',
                    Optional('help'): str,
                    'host': And(str, len),
                    Optional('username'): str,
                    Optional('password'): Use(str),
                    Optional('extends'): str,
                })
        }
    }

    def __init__(self, configs: t.Optional[t.List[str]] = None, config_file_names: t.Optional[t.List[str]] = None):
        '''
        Initializes the Config object by loading, merging, and validating configurations.

        :param configs: An optional list of configuration file paths or YAML strings.
                        If not provided, the configuration is scanned from the file system.
        :param config_file_names: An optional list of names for the configuration files
                                  to be discovered during scanning.
        '''
        self._log = get_logger()

        self.work_dir = os.getcwd().replace('\\', '/')

        if configs is None:
            all_configs = self._scan_files(config_file_names)
            configs = self._scan_project_files(all_configs)

        merged_config = self._load(configs)
        resolved_config = self._resolve_templates(merged_config)
        validated_config = self._validate(resolved_config)

        self.update(Munch.fromDict(validated_config))

    def _load(self, configs: t.List[str]) -> Munch:
        '''
        Loads and merges a list of configuration files or strings.

        It also sets up the base and working directories based on the configuration files' locations.

        :param configs: A list of configuration file paths or YAML strings.
        :return: A Munch object representing the merged configuration.
        :raises ConfigError: If there's an issue with loading or merging the configurations.
        '''
        try:
            self._log.extra_info('Merging config files')
            self._log.debug(configs)
            config = self._load_configs(configs)
            self._log.debug(f'Merged config: {config}')
        except Exception as ex:
            raise ConfigError(f'Failed to process config files: {ex}')

        if config is None:
            raise ConfigError('Invalid config file: Config file is empty')

        if os.path.exists(configs[0]):
            self.base_dir = os.path.dirname(configs[0]).replace('\\', '/')
        else:
            self.base_dir = self.work_dir
        self._log.debug(f'Base dir: {self.base_dir}')

        common_prefix = os.path.commonprefix([self.work_dir, self.base_dir])
        self.work_dir_rel = os.path.relpath(self.work_dir, common_prefix).replace('\\', '/')
        self._log.debug(f'Relative work dir: {self.work_dir_rel}')

        return config

    def _resolve_templates(self, config: t.Dict) -> t.Dict:
        '''
        Resolves template definitions by handling hidden executors (starting with '.') and 'extends' keyword.

        :param config: The configuration dictionary to process.
        :return: The configuration dictionary with resolved extensions.
        '''
        if 'executors' not in config:
            return config

        executors = config['executors']

        def _resolve(name, visited):
            if name in visited:
                raise ConfigError(f"Circular template extension detected: {' -> '.join(visited)} -> {name}")

            curr_exec = executors[name]
            if isinstance(curr_exec, dict) and 'extends' in curr_exec:
                parent_name = curr_exec['extends']
                if parent_name not in executors:
                    raise ConfigError(f"Executor '{name}' extends unknown executor '{parent_name}'")

                parent_exec = _resolve(parent_name, visited + [name])
                # merge with inherited executor
                merged_exec = self._merge_configs(parent_exec, curr_exec)
                del merged_exec['extends']
                executors[name] = merged_exec
                return merged_exec

            return curr_exec

        for name in list(executors.keys()):
            if name == 'default':
                continue
            _resolve(name, [])

        # Remove templates (keys starting with .)
        config['executors'] = {k: v for k, v in executors.items() if not k.startswith('.')}

        self._log.debug(f'Resolved config: {config}')

        return config

    def _validate(self, config: t.Dict) -> t.Dict:
        '''
        Validates the configuration against the predefined schema and version requirements.

        :param config: The configuration dictionary to validate.
        :return: The validated configuration dictionary.
        :raises ConfigError: If the configuration is invalid or does not meet version requirements.
        '''
        try:
            config_schema = Schema(self.SCHEMA)
            config = config_schema.validate(config)
        except SchemaError as ex:
            raise ConfigError(f'Invalid config file: {ex}')

        current_ver = __version__.split('.')
        config_ver = str(config['version']).split('.')
        for pos, val in enumerate(current_ver[0:3]):
            if int(config_ver[pos]) < int(val):
                break
            if int(config_ver[pos]) > int(val):
                raise ConfigError(
                    f'Current config requires Brock of version at least {config["version"]}, you are using {__version__}'
                )

        return config

    def _scan_files(self, file_names: t.Optional[t.List[str]] = None) -> t.List[str]:
        '''
        Scans for configuration files up the directory tree from the current working directory.

        :param file_names: An optional list of configuration file names to look for.
                           If not provided, a default list is used.
        :return: A list of paths to the found configuration files, ordered from the root-most to the nearest.
        :raises ConfigError: If no configuration file is found or if multiple are found in the same directory.
        '''
        if file_names is None:
            file_names = ['.brock.yml', 'brock.yml', '.brock.yaml', 'brock.yaml']

        self._log.extra_info(f'Scanning config files, work dir: {self.work_dir}')

        config_files = []
        path_parts = self._split_path(self.work_dir)

        for i in range(1, len(path_parts) + 1):
            found = 0
            for config_file_name in file_names:
                path = Path('').joinpath(*path_parts[:i], config_file_name)

                if path.is_file():
                    self._log.debug(f'Found config file: {path.as_posix()}')
                    config_files.append(path.as_posix())
                    found += 1

            if found > 1:
                raise ConfigError(
                    f"Multiple brock config files found in '{Path('').joinpath(*path_parts[:i]).as_posix()}'"
                )

        if not config_files:
            raise ConfigError(
                f"No config file ({', '.join(file_names)}) found in '{self.work_dir}' or parent directories"
            )

        return config_files

    def _scan_project_files(self, configs: t.List[str]) -> t.List[str]:
        '''
        Scan config files from the current working dir to the top until a config
        with a project name is found. Continue further as long as the project name
        is the same. Otherwise, break the loop and return the config files from
        the last one with the specified project to the working dir.

        :param configs: A list of configuration file paths, ordered from nearest to root-most.
        :return: A filtered list of configuration files belonging to the identified project.
        '''

        self._log.extra_info('Scanning project config files')

        project = None
        project_configs: t.List[str] = []
        try:
            for i in range(len(configs) - 1, -1, -1):
                config = self._load_configs([configs[i]])
                if config:
                    if 'project' in config:
                        self._log.debug(f'Found project {config["project"]} in config file {configs[i]}')
                        if project is None or project == config['project']:
                            project = config['project']
                            project_configs = configs[i:]
                        else:
                            break
        except Exception as ex:
            raise ConfigError(f'Failed to process config file: {ex}')

        return project_configs

    @classmethod
    def _merge_configs(cls, a: t.Optional[t.Dict[str, t.Any]], b: t.Dict[str, t.Any]) -> t.Dict[str, t.Any]:
        '''
        Recursively merge two dictionaries.

        Merges b into a. If a key in b is None, it removes the key from the result.

        :param a: The base dictionary.
        :param b: The dictionary to merge in.
        :return: The merged dictionary.
        '''
        if a is None:
            return b
        result = deepcopy(a)  # it will be modified
        for k, v in b.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = cls._merge_configs(result[k], v)
            elif k in result and v is None:
                # unset value
                del result[k]
            else:
                result[k] = v
        return result

    @classmethod
    def _load_configs(cls, configs: t.List[str]) -> t.Optional[t.Dict[str, t.Any]]:
        '''
        Load and merge multiple configuration files or strings.

        :param configs: A list of file paths or YAML strings.
        :return: A merged configuration dictionary, or None if no configs were provided.
        '''

        merged_config: t.Optional[t.Dict[str, t.Any]] = None
        for cfg in configs:
            if os.path.exists(cfg):
                with open(cfg, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
            else:
                config = yaml.safe_load(cfg)
            merged_config = cls._merge_configs(merged_config, config)

        return merged_config

    @classmethod
    def _split_path(cls, path):
        '''
        Splits a file system path into its constituent parts.

        :param path: The path to split.
        :return: A list of strings, where each string is a part of the path.
        '''
        all_parts = []
        while True:
            parts = os.path.split(path)
            if parts[0] == path:  # sentinel for absolute paths
                all_parts.insert(0, parts[0])
                break
            elif parts[1] == path:  # sentinel for relative paths
                all_parts.insert(0, parts[1])
                break
            else:
                path = parts[0]
                all_parts.insert(0, parts[1])

        return all_parts
