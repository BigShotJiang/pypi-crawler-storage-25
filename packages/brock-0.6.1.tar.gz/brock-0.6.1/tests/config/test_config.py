import pytest
import textwrap

from brock import __version__
from brock.config.config import Config
from brock.exception import ConfigError


def test_example_config():
    '''Test the config attached as an example.'''
    config = Config(['example_brock.yml'])
    assert str(config.version) == '0.6.0'
    assert config.project == 'someprojectname'
    assert config.help == 'brock --help message'

    assert len(config.commands.keys()) == 5
    assert config.commands.default == 'build'

    assert config.commands.clean.default_executor == 'atollic'
    assert config.commands.clean.chdir == 'foo/bar'
    assert config.commands.clean.help == 'Help message for this command'
    assert config.commands.clean.steps == ['make clean']

    assert config.commands.build.depends_on == ['clean']
    options = config.commands.build.options
    assert len(options) == 4
    assert options['very-fast'].argument == '1'
    assert options['very-fast'].default == 'fast'
    assert options['very-fast'].help == 'I am fast'
    assert options['fast_as_lightning'].argument == '*'
    assert options['fast_as_lightning'].default == 'fastest'
    assert options['fast_as_lightning'].help == 'I am the fastest'
    assert options['very-slow'].flag == '--slow'
    assert options['very-slow'].short_name == '-s'
    assert options['speed'].help == 'I am neither flag nor argument'
    assert options['speed'].choices == ['very_slow', 'slow', 'medium', 'fast', 'fastaf']
    assert config.commands.build.steps == [
        '@atollic make', 'make tests', '@host echo \'Building finished\'', 'run ${VERY_FAST}', 'run ${VERY_SLOW}',
        'run ${SPEED}'
    ]

    assert config.commands.rebuild.depends_on == ['clean', 'build']

    assert len(config.commands.service.steps) == 1
    assert config.commands.service.steps[0].executor == 'atollic'
    assert config.commands.service.steps[0].shell == 'powershell'
    assert config.commands.service.steps[0].script == \
        '$ServiceName = \'EventLog\'\n$ServiceInfo = Get-Service -Name $ServiceName\nWrite-Output $ServiceInfo\n'

    assert len(config.executors.keys()) == 6
    assert '.python_base' not in config.executors

    assert config.executors.default == 'python'

    assert config.executors.atollic.type == 'docker'
    assert config.executors.atollic.help == 'Executor --help message'
    assert config.executors.atollic.dockerfile == 'path/to/Dockerfile'
    assert config.executors.atollic.platform == 'windows'
    assert config.executors.atollic.privileged == True
    assert len(config.executors.atollic.env.keys()) == 2
    assert config.executors.atollic.env.SOME_VAR == 'foo'
    assert config.executors.atollic.env.OTHER_VAR == 123
    assert config.executors.atollic.mac_address == '88:99:aa:bb:cc:dd'
    assert config.executors.atollic.ports == {5000: 5000, '6000/udp': 6000}
    assert config.executors.atollic.devices == ['class/{interface class GUID}']
    assert config.executors.atollic.default_shell == 'powershell'

    assert config.executors.python.type == 'docker'
    assert config.executors.python.image == 'python:3.9'
    assert len(config.executors.python.env.keys()) == 4
    assert config.executors.python.env.PIN == 1234
    assert config.executors.python.env.FOO.default == 'foo'
    assert config.executors.python.env.FOO.description == 'Foo foo'
    assert config.executors.python.env.FOO.prompt == True
    assert config.executors.python.env.BAR.prompt == False
    assert config.executors.python.env.BAZ.description == 'Baz baz'
    assert config.executors.python.sync.type == 'rsync'
    assert config.executors.python.sync.options == ['-avm']
    assert config.executors.python.sync.filter == ['+ foo/', '+ foo/**/', '+ foo/**.c', '+ foo/src/**', '- *']
    assert config.executors.python.sync.include == ['foo/bar']
    assert config.executors.python.sync.exclude == ['foo/bar']
    assert config.executors.python.devices == ['/dev/ttyUSB0:/dev/ttyUSB0:rwm']
    assert config.executors.python.prepare == [
        'pip install -r requirements.txt',
        'echo "Foo bar"',
    ]

    assert config.executors.gcc.type == 'docker'
    assert config.executors.gcc.image == 'gcc'
    assert config.executors.gcc.sync.type == 'mutagen'
    assert config.executors.gcc.sync.options == ['--ignore-vcs', '--sync-mode=two-way-safe']
    assert config.executors.gcc.sync.exclude == ['foo/bar']
    assert config.executors.gcc.sync.auto_pause == False

    assert config.executors.remote.type == 'ssh'
    assert config.executors.remote.host == 'somesite.example.com:1235'
    assert config.executors.remote.username == 'foobar'
    assert config.executors.remote.password == 'strongpassword'

    assert config.executors.remote_docker.type == 'docker'
    assert config.executors.remote_docker.host == 'somesite.example.com'
    assert config.executors.remote_docker.username == 'foobar'
    assert config.executors.remote_docker.sync.type == 'mutagen'
    assert config.executors.remote_docker.ports == {8080: 80}
    assert config.executors.remote_docker.image == 'python:3.9'
    assert config.executors.remote_docker.prepare == ['pip install -r requirements.txt']


def test_empty_config():
    '''Test empty config raises error (#5813).'''
    with pytest.raises(ConfigError) as ex:
        Config(['\n'])
    assert ex.value.message == 'Invalid config file: Config file is empty'


def test_invalid_version():
    '''Test invalid config version raises error - config version must be lower or equal to brock version.'''
    config_str = textwrap.dedent('''
        version: 5.0.0
        project: test
    ''')
    with pytest.raises(ConfigError) as ex:
        Config([config_str])
    assert ex.value.message.startswith('Current config requires Brock of version at least')


@pytest.mark.parametrize(
    'config_str, key_errors, required_strings', [
        (
            textwrap.dedent('''
                version: '1.2'
                project: test
            '''),
            ['version'],
            ["'1.2' does not match '^[0-9]+.[0-9]+.[0-9]+$'"],
        ),
        (
            textwrap.dedent('''
                version: 0.2.0
            '''),
            [],
            ["Missing key: 'project'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                commands:
                my_command: "a string instead of a dict"
            '''
            ),
            ['commands'],
            ["should be instance of 'dict'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                commands:
                  my_command:
                    depends_on: "not-a-list"
            '''
            ),
            ['commands'],
            ["Key 'depends_on' error", "should be instance of 'list'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                commands:
                  my_command:
                    options:
                      - not-a-dict
            '''
            ),
            ['commands', 'options'],
            ["should be instance of 'dict'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                commands:
                  my_command:
                    steps: "not-a-list"
            '''
            ),
            ['commands', 'steps'],
            ["should be instance of 'list'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    dockerfile: path/to/Dockerfile
            '''
            ),
            ['executors', 'my_docker'],
            ['multiple keys present'],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    ports:
                      - "8080:8080"
            '''
            ),
            ['executors', 'my_docker', 'ports'],
            ["should be instance of 'dict'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    ports:
                      "8080/http": 8080
            '''
            ),
            ['executors', 'my_docker', 'ports'],
            ['does not match'],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    ports:
                      8080: "8080"
            '''
            ),
            ['executors', 'my_docker', 'ports'],
            ["should be instance of 'int'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    mac_address: "not-a-mac"
            '''
            ),
            ['executors', 'my_docker', 'mac_address'],
            ['does not match'],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
                    image: my-image
                    sync:
                      type: "not-rsync-or-mutagen"
            '''
            ),
            ['executors', 'my_docker', 'sync', 'type'],
            ["does not match 'not-rsync-or-mutagen'"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_docker:
                    type: docker
            '''
            ),
            ['executors', 'my_docker'],
            ["Missing key: Or('image', 'dockerfile')"],
        ),
        (
            textwrap.dedent(
                '''
                version: 0.2.0
                project: test
                executors:
                  my_ssh:
                    type: ssh
                    username: "user"
            '''
            ),
            ['executors', 'my_ssh'],
            ["Missing key: 'host'"],
        ),
    ]
)
def test_invalid_options(config_str, key_errors, required_strings):
    '''Test that invalid options raises a ConfigError.'''
    with pytest.raises(ConfigError) as ex:
        Config([config_str])

    assert 'Invalid config file:' in str(ex.value)
    for key in key_errors:
        assert f"Key '{key}' error" in str(ex.value)
    for string in required_strings:
        assert string in str(ex.value)


def test_multiple_configs_in_one_dir():
    '''Test multiple config files in one directory raises error.'''
    with pytest.raises(ConfigError) as ex:
        Config(config_file_names=['example_brock.yml', '.brock.yml'])
    assert ex.value.message.startswith('Multiple brock config files found in')


def test_empty_executors():
    '''Test executors config section is empty or missing.'''
    config_str = textwrap.dedent('''
        version: 0.0.6
        project: test
        executors: {}
    ''')
    config = Config([config_str])
    assert len(config.executors) == 0

    config_str = textwrap.dedent('''
        version: 0.0.6
        project: test
    ''')
    config = Config([config_str])
    assert len(config.executors) == 0


def test_hierarchical_configs():
    '''Test that hierarchical configs are merged correctly.'''
    config_str_1 = textwrap.dedent(
        '''
        version: 0.2.0
        project: test-project
        executors:
          e1:
            type: docker
            image: image1
          e2:
            type: docker
            image: image2
        commands:
          c1:
            steps:
              - "@e1 step1"
            help: "original help"
    '''
    )
    config_str_2 = textwrap.dedent(
        '''
        executors:
          e1:
            type: docker
            image: image1-override
          e3:
            type: ssh
            host: localhost
        commands:
          c1:
            help: null
          c2:
            steps:
              - "@e2 step2"
    '''
    )
    config = Config([config_str_1, config_str_2])
    assert str(config.version) == '0.2.0'
    assert config.project == 'test-project'
    assert config.executors.e1.type == 'docker'
    assert config.executors.e1.image == 'image1-override'
    assert config.executors.e2.type == 'docker'
    assert config.executors.e2.image == 'image2'
    assert config.executors.e3.type == 'ssh'
    assert config.executors.e3.host == 'localhost'
    assert config.commands.c1.steps == ['@e1 step1']
    assert 'help' not in config.commands.c1
    assert config.commands.c2.steps == ['@e2 step2']


def test_extends_config():
    '''Test the extends functionality in executor definitions.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          .base:
            type: docker
            privileged: true
          python:
            extends: .base
            image: python:3.9
    '''
    )
    config = Config([config_str])

    assert len(config.executors) == 1
    assert 'python' in config.executors
    assert '.base' not in config.executors

    python = config.executors.python
    assert python.type == 'docker'
    assert python.privileged is True
    assert python.image == 'python:3.9'
