import pytest
import textwrap

from brock.config.config import Config
from brock.exception import ConfigError


def test_basic_extends():
    '''Test simple executor extension from a template.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          .base:
            type: docker
            privileged: true
          python:
            extends: .base
            image: python:3.9
    '''
    )
    config = Config([config_str])

    assert len(config.executors) == 1
    assert 'python' in config.executors
    assert '.base' not in config.executors

    python = config.executors.python
    assert python.type == 'docker'
    assert python.privileged is True
    assert python.image == 'python:3.9'


def test_nested_extends():
    '''Test multiple levels of template inheritance.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          .root:
            type: docker
          .base:
            extends: .root
            privileged: true
          python:
            extends: .base
            image: python:3.9
    '''
    )
    config = Config([config_str])

    assert 'python' in config.executors
    assert '.root' not in config.executors
    assert '.base' not in config.executors

    python = config.executors.python
    assert python.type == 'docker'
    assert python.privileged is True
    assert python.image == 'python:3.9'


def test_extends_override():
    '''Test that child executor can override template values.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          .base:
            type: docker
            image: alpine
            privileged: true
          python:
            extends: .base
            image: python:3.9
            privileged: false
    '''
    )
    config = Config([config_str])

    python = config.executors.python
    assert python.image == 'python:3.9'  # Overridden
    assert python.privileged is False  # Overridden
    assert python.type == 'docker'  # Inherited


def test_extends_regular_executor():
    '''Test simple executor extension from a regular executor.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          base:
            type: docker
            image: alpine
            privileged: true
          python:
            extends: base
            image: python:3.9
    '''
    )
    config = Config([config_str])

    assert len(config.executors) == 2
    assert 'python' in config.executors
    assert 'base' in config.executors

    python = config.executors.python
    assert python.type == 'docker'
    assert python.privileged is True
    assert python.image == 'python:3.9'


def test_extends_unknown_executor():
    '''Test that extending a non-existent executor fails.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          python:
            extends: .nonexistent
            image: python:3.9
    '''
    )
    with pytest.raises(ConfigError) as ex:
        Config([config_str])
    assert "extends unknown executor '.nonexistent'" in str(ex.value)


def test_extends_circular():
    '''Test that circular inheritance detection works.'''
    config_str = textwrap.dedent(
        '''
        version: 0.5.0
        project: test
        executors:
          .a:
            extends: .b
          .b:
            extends: .a
          python:
            extends: .a
            type: docker
            image: python:3.9
    '''
    )
    with pytest.raises(ConfigError) as ex:
        Config([config_str])
    assert 'Circular template extension detected' in str(ex.value)
