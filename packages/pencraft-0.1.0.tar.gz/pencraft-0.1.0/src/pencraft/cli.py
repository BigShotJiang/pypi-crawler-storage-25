"""Command-line interface for Pencraft."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

app = typer.Typer(
    name="pencraft",
    help="AI-powered blog writing toolkit",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        from pencraft import __version__

        console.print(f"[bold blue]Pencraft[/bold blue] version [green]{__version__}[/green]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """Pencraft - AI-powered blog writing toolkit.

    Generate professional, well-researched blog posts with AI.
    """
    pass


@app.command()
def write(
    topic: Annotated[str, typer.Argument(help="Topic for the blog post")],
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Output directory"),
    ] = Path("./output"),
    words: Annotated[
        int,
        typer.Option("--words", "-w", help="Target word count"),
    ] = 2000,
    tags: Annotated[
        str | None,
        typer.Option("--tags", "-t", help="Comma-separated tags"),
    ] = None,
    categories: Annotated[
        str | None,
        typer.Option("--categories", "-c", help="Comma-separated categories"),
    ] = None,
    author: Annotated[
        str | None,
        typer.Option("--author", "-a", help="Author name"),
    ] = None,
    draft: Annotated[
        bool,
        typer.Option("--draft", "-d", help="Mark as draft"),
    ] = False,
    skip_research: Annotated[
        bool,
        typer.Option("--skip-research", help="Skip research phase"),
    ] = False,
    cover_image: Annotated[
        str | None,
        typer.Option("--cover-image", help="Cover image URL"),
    ] = None,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", help="Path to config file"),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Enable verbose output"),
    ] = False,
    debug: Annotated[
        bool,
        typer.Option("--debug", help="Enable debug mode"),
    ] = False,
) -> None:
    """Generate a complete blog post on the given topic.

    Example:
        pencraft write "Introduction to Python" --words 3000 --tags python,programming
    """
    from pencraft.config.settings import load_settings
    from pencraft.generator import BlogGenerator
    from pencraft.utils.logging import configure_logging

    # Configure logging
    configure_logging(verbose=verbose, debug=debug)

    # Parse tags and categories
    tag_list = [t.strip() for t in tags.split(",")] if tags else None
    category_list = [c.strip() for c in categories.split(",")] if categories else None

    # Load settings
    settings = load_settings(config_file=config_file, verbose=verbose, debug=debug)

    console.print(
        Panel(
            f"[bold]Generating blog post[/bold]\n\n"
            f"Topic: [cyan]{topic}[/cyan]\n"
            f"Target: [yellow]{words}[/yellow] words\n"
            f"Output: [green]{output}[/green]",
            title="[bold blue]Pencraft[/bold blue]",
            border_style="blue",
        )
    )

    try:
        generator = BlogGenerator(settings=settings)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Generating blog post...", total=None)

            def update_spinner(msg: str) -> None:
                """Update spinner description."""
                progress.update(task, description=msg)

            blog = generator.generate(
                topic=topic,
                target_word_count=words,
                tags=tag_list,
                categories=category_list,
                author=author,
                draft=draft,
                output_dir=output,
                skip_research=skip_research,
                cover_image=cover_image,
                progress_callback=update_spinner,
            )

            progress.update(task, completed=True)

        # Display results
        console.print()
        console.print(
            Panel(
                f"[bold green]✓ Blog post generated successfully![/bold green]\n\n"
                f"Title: [bold]{blog.title}[/bold]\n"
                f"Words: [yellow]{blog.word_count}[/yellow]\n"
                f"Time: [cyan]{blog.generation_time:.2f}s[/cyan]\n"
                f"File: [blue]{blog.file_path}[/blue]",
                title="[bold green]Complete[/bold green]",
                border_style="green",
            )
        )

        if blog.sources:
            console.print(f"\n[dim]Sources used: {len(blog.sources)}[/dim]")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(code=1) from e


@app.command()
def research(
    topic: Annotated[str, typer.Argument(help="Topic to research")],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Save research to file"),
    ] = None,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", help="Path to config file"),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Enable verbose output"),
    ] = False,
) -> None:
    """Research a topic without generating a blog post.

    Example:
        pencraft research "Machine Learning trends 2024"
    """
    from pencraft.config.settings import load_settings
    from pencraft.generator import BlogGenerator
    from pencraft.utils.logging import configure_logging

    configure_logging(verbose=verbose)
    settings = load_settings(config_file=config_file)

    console.print(f"[bold]Researching:[/bold] [cyan]{topic}[/cyan]\n")

    try:
        generator = BlogGenerator(settings=settings)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Researching...", total=None)

            def update_spinner(msg: str) -> None:
                """Update spinner description."""
                progress.update(task, description=msg)

            research_summary = generator.research_only(
                topic,
                progress_callback=update_spinner,
            )

        console.print(Panel(research_summary, title="Research Summary", border_style="blue"))

        if output:
            output.write_text(research_summary, encoding="utf-8")
            console.print(f"\n[green]Saved to:[/green] {output}")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(code=1) from e


@app.command()
def outline(
    topic: Annotated[str, typer.Argument(help="Topic for the outline")],
    words: Annotated[
        int,
        typer.Option("--words", "-w", help="Target word count"),
    ] = 2000,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Save outline to file"),
    ] = None,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", help="Path to config file"),
    ] = None,
) -> None:
    """Generate a blog outline without writing content.

    Example:
        pencraft outline "Getting Started with Docker" --words 3000
    """
    from pencraft.config.settings import load_settings
    from pencraft.generator import BlogGenerator
    from pencraft.utils.logging import configure_logging

    configure_logging()
    settings = load_settings(config_file=config_file)

    console.print(f"[bold]Creating outline for:[/bold] [cyan]{topic}[/cyan]\n")

    try:
        generator = BlogGenerator(settings=settings)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Creating outline...", total=None)

            def update_spinner(msg: str) -> None:
                """Update spinner description."""
                progress.update(task, description=msg)

            blog_outline = generator.outline_only(
                topic,
                target_word_count=words,
                progress_callback=update_spinner,
            )

        console.print(Panel(blog_outline.to_markdown(), title="Blog Outline", border_style="blue"))

        if output:
            output.write_text(blog_outline.to_markdown(), encoding="utf-8")
            console.print(f"\n[green]Saved to:[/green] {output}")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(code=1) from e


@app.command(name="config")
def show_config(
    show: Annotated[
        bool,
        typer.Option("--show", "-s", help="Show current configuration"),
    ] = True,
    init: Annotated[
        bool,
        typer.Option("--init", "-i", help="Create a new config file"),
    ] = False,
    path: Annotated[
        Path,
        typer.Option("--path", "-p", help="Config file path for init"),
    ] = Path("pencraft.yaml"),
) -> None:
    """Show or create configuration.

    Example:
        pencraft config --show
        pencraft config --init --path my-config.yaml
    """
    from pencraft.config.settings import Settings

    if init:
        settings = Settings()
        settings.save_to_file(path)
        console.print(f"[green]Config file created:[/green] {path}")
        return

    if show:
        settings = Settings()

        table = Table(title="Pencraft Configuration", show_header=True)
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")

        # LLM settings
        table.add_row("LLM Base URL", settings.llm.base_url)
        table.add_row("LLM Model", settings.llm.model)
        table.add_row("LLM Temperature", str(settings.llm.temperature))
        table.add_row("LLM Max Tokens", str(settings.llm.max_tokens))

        table.add_row("", "")  # Spacer

        # Research settings
        table.add_row("Max Search Results", str(settings.research.max_search_results))
        table.add_row("Max Sources", str(settings.research.max_sources))

        table.add_row("", "")  # Spacer

        # Output settings
        table.add_row("Output Directory", settings.output.directory)
        table.add_row("Output Format", settings.output.format)

        table.add_row("", "")  # Spacer

        # Blog settings
        table.add_row("Min Word Count", str(settings.blog.min_word_count))
        table.add_row("Max Word Count", str(settings.blog.max_word_count))
        table.add_row("Include TOC", str(settings.blog.include_toc))
        table.add_row("Include Citations", str(settings.blog.include_citations))

        console.print(table)


@app.command()
def enhance(
    path: Annotated[Path, typer.Argument(help="File or directory to enhance")],
    words: Annotated[
        int,
        typer.Option("--words", "-w", help="Minimum target word count"),
    ] = 3000,
    recursive: Annotated[
        bool,
        typer.Option("--recursive", "-r", help="Process subdirectories"),
    ] = False,
    no_backup: Annotated[
        bool,
        typer.Option("--no-backup", help="Skip backup of original files"),
    ] = False,
    no_trends: Annotated[
        bool,
        typer.Option("--no-trends", help="Skip Google Trends lookup"),
    ] = False,
    no_seo: Annotated[
        bool,
        typer.Option("--no-seo", help="Skip SEO optimization"),
    ] = False,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", help="Path to config file"),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Enable verbose output"),
    ] = False,
) -> None:
    """Enhance existing blog posts for SEO, quality, and revenue.

    Can process a single file or an entire directory of markdown files.

    Example:
        pencraft enhance ./my-blog.md --words 4000
        pencraft enhance ./blogs/ --recursive --words 3000
    """
    from pencraft.config.settings import load_settings
    from pencraft.enhancer import BlogEnhancer
    from pencraft.utils.logging import configure_logging

    configure_logging(verbose=verbose)
    settings = load_settings(config_file=config_file)

    path = Path(path)

    if not path.exists():
        console.print(f"[bold red]Error:[/bold red] Path not found: {path}")
        raise typer.Exit(code=1)

    console.print(
        Panel(
            f"[bold]Enhancing blog posts[/bold]\n\n"
            f"Path: [cyan]{path}[/cyan]\n"
            f"Target: [yellow]{words}[/yellow] words minimum\n"
            f"Backup: [{'green' if not no_backup else 'red'}]{'Enabled' if not no_backup else 'Disabled'}[/]\n"
            f"Trends: [{'green' if not no_trends else 'red'}]{'Enabled' if not no_trends else 'Disabled'}[/]\n"
            f"SEO: [{'green' if not no_seo else 'red'}]{'Enabled' if not no_seo else 'Disabled'}[/]",
            title="[bold blue]Pencraft Enhance[/bold blue]",
            border_style="blue",
        )
    )

    try:
        # Progress callback for spinner
        def on_progress(msg: str) -> None:
            console.print(f"  [dim]►[/dim] {msg}")

        enhancer = BlogEnhancer(settings=settings, on_progress=on_progress)

        if path.is_file():
            # Single file enhancement
            console.print(f"\n[bold]Enhancing:[/bold] {path.name}")

            result = enhancer.enhance(
                path,
                target_word_count=words,
                improve_seo=not no_seo,
                use_trends=not no_trends,
                backup=not no_backup,
            )

            if result.error:
                console.print(f"[bold red]Error:[/bold red] {result.error}")
                raise typer.Exit(code=1)

            # Display results
            console.print()
            console.print(
                Panel(
                    f"[bold green]✓ Enhancement complete![/bold green]\n\n"
                    f"File: [blue]{result.file_path.name}[/blue]\n"
                    f"Words: [yellow]{result.original_word_count}[/yellow] → "
                    f"[green]{result.enhanced_word_count}[/green]\n"
                    f"Backup: [dim]{result.backup_path}[/dim]\n\n"
                    f"[bold]Improvements:[/bold]\n"
                    + "\n".join(f"  • {imp}" for imp in result.improvements_made),
                    title="[bold green]Complete[/bold green]",
                    border_style="green",
                )
            )

        else:
            # Directory enhancement
            console.print(f"\n[bold]Enhancing directory:[/bold] {path}")

            results = enhancer.enhance_directory(
                path,
                recursive=recursive,
                target_word_count=words,
                improve_seo=not no_seo,
                use_trends=not no_trends,
                backup=not no_backup,
            )

            # Summary table
            successful = [r for r in results if not r.error]
            failed = [r for r in results if r.error]

            if successful:
                table = Table(title="Enhanced Files", show_header=True)
                table.add_column("File", style="cyan")
                table.add_column("Before", justify="right")
                table.add_column("After", justify="right", style="green")
                table.add_column("Change", justify="right")

                for r in successful:
                    change = r.enhanced_word_count - r.original_word_count
                    change_str = f"+{change}" if change > 0 else str(change)
                    table.add_row(
                        r.file_path.name,
                        str(r.original_word_count),
                        str(r.enhanced_word_count),
                        change_str,
                    )

                console.print()
                console.print(table)

            if failed:
                console.print(f"\n[bold red]Failed ({len(failed)}):[/bold red]")
                for r in failed:
                    console.print(f"  • {r.file_path.name}: {r.error}")

            # Final summary
            total_before = sum(r.original_word_count for r in successful)
            total_after = sum(r.enhanced_word_count for r in successful)
            console.print(
                f"\n[bold]Summary:[/bold] {len(successful)} enhanced, {len(failed)} failed"
            )
            console.print(f"[bold]Total words:[/bold] {total_before} → {total_after}")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(code=1) from e


if __name__ == "__main__":
    app()
