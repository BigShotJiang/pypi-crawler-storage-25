"""Minimal MCP server exposing a demo hello tool."""

from mcp.server.fastmcp import FastMCP

SERVER_NAME = "vulndify-demo"

mcp = FastMCP(name=SERVER_NAME)


def hello() -> str:
    """Return the fixed response used by the demo tool."""
    return "hello"


@mcp.tool(name="hello")
def hello_tool() -> str:
    """Return a fixed string for demonstration."""
    return hello()


def main() -> None:
    """Start the MCP server using the default transport."""
    mcp.run()


if __name__ == "__main__":
    main()
