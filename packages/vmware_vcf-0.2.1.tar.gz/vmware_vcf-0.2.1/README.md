# vmware-vcf — Python SDK for VMware Cloud Foundation

A comprehensive Python SDK for programmatically managing VMware Cloud Foundation (VCF) infrastructure — SDDC Manager, NSX-T, and vCenter. Also includes an Ansible collection.

```bash
pip install vmware-vcf
```

## Clients

| Client | API | Auth |
|--------|-----|------|
| `SDDCManager` | SDDC Manager REST API (100% of Broadcom spec) | JWT with auto-refresh |
| `NSXManager` | NSX-T Policy API | HTTP Basic |
| `VCenter` | vCenter REST API | Session-based |
| `CloudBuilder` | Cloud Builder API | HTTP Basic |

## Quick Start

```python
from vcf_sdk import SDDCManager, NSXManager, VCenter

# SDDC Manager
with SDDCManager("sddc.lab.dev", "admin@local", "password") as sddc:
    # List hosts
    hosts = sddc.hosts.list(status="COMMISSIONED")
    
    # Commission new hosts (validates first, then executes)
    task = sddc.hosts.commission([{
        "fqdn": "esxi-05.lab.dev",
        "username": "root",
        "password": "password",
        "storageType": "VSAN_ESA",
        "networkPoolId": "pool-uuid"
    }])
    
    # Wait for completion
    sddc.tasks.wait_for_completion(task.id, timeout=3600)
    
    # Manage identity providers
    providers = sddc.identity_providers.list()
    
    # Configure certificates
    sddc.certificates.set_microsoft_ca(
        server_url="https://ca.lab.dev/certsrv",
        username="admin", password="pass", template_name="VMware"
    )

# NSX-T
with NSXManager("nsx.lab.dev", "admin", "password") as nsx:
    # Create a segment (PATCH = idempotent)
    nsx.segments.create_or_update("web-segment", {
        "display_name": "Web Segment",
        "transport_zone_path": "/infra/sites/default/enforcement-points/default/transport-zones/tz-overlay",
        "connectivity_path": "/infra/tier-1s/t1-gateway",
        "subnets": [{"gateway_address": "192.168.1.1/24"}]
    })
    
    # Create firewall policy with rules
    nsx.security_policies.create_or_update("app-policy", {
        "display_name": "App Isolation",
        "category": "Application",
        "rules": [{
            "id": "allow-https",
            "action": "ALLOW",
            "source_groups": ["/infra/domains/default/groups/web-servers"],
            "services": ["/infra/services/HTTPS"]
        }]
    })

# vCenter
with VCenter("vcenter.lab.dev", "administrator@vsphere.local", "password") as vc:
    vms = vc.vms.list(power_states="POWERED_ON")
    datastores = vc.infrastructure.list_datastores()
    vc.tagging.attach("tag-id", "VirtualMachine", "vm-42")
```

## SDDC Manager — 34 Managers

Hosts, clusters, domains, tasks, credentials, certificates, identity providers, network pools, licenses, bundles/upgrades, users/roles, DNS/NTP, backup, compliance, federation, Aria Suite, edge clusters, AVNs, ALB clusters, brownfield import, check sets, compatibility matrices, config drift, manifests, notifications, product catalogs, resource functionalities, trusted certificates, VASA providers, VCF components, version aliases, vSAN HCL/health, system config.

## NSX-T Policy API — 44 Managers

**Networking:** Segments + ports, Tier-0/Tier-1 gateways (locale services, interfaces, static routes, BGP, OSPF, prefix/community lists, route maps, redistribution).

**Security:** Groups, distributed firewall policies/rules, gateway policies, services, context profiles, IDS/IPS, firewall exclude list, cluster security, predefined policies.

**Load Balancing:** Services, virtual servers, pools, monitors, application profiles, persistence profiles, SSL profiles.

**VPN:** IPSec (services, sessions, endpoints, IKE/tunnel/DPD profiles), L2 VPN.

**Network Services:** NAT, DHCP server/relay, DNS forwarder zones.

**IP Management:** IP pools + subnets + allocations, IP blocks + block subnets.

**Fabric:** Transport zones, edge clusters/nodes, host/edge transport nodes, TN collections/profiles, host switch profiles, edge HA profiles, sites, enforcement points, compute sub-clusters.

**Multi-tenancy:** Projects, VPCs (subnets, ports, groups, security/gateway policies, NAT, routes, IP allocations, DHCP bindings).

**Profiles:** IP/MAC discovery, spoof guard, segment security, QoS, gateway QoS, flood protection + bindings.

**EVPN:** Config, tenants, tunnel endpoints.

## vCenter REST API — 11 Managers

VMs (lifecycle + power), content library (local + subscribed), namespace management (Tanzu/VKS), tagging (categories + tags + associations), infrastructure (clusters, datacenters, datastores, hosts, networks, resource pools, storage policies), OVF deployment, VM hardware (disks, NICs, CPU, memory), snapshots, DRS rules, folders, guest customization.

## Version Awareness

The SDK auto-detects VCF and NSX versions on connect and warns when accessing endpoints not available on the connected version.

```python
sddc = SDDCManager("sddc.lab.dev", "admin@local", "password")
print(sddc.version)  # "9.0.2.0"
# Accessing VPC features on NSX < 4.1.1 logs a warning
```

## Ansible Collection

```bash
ansible-galaxy collection install ./ansible_collections/darrylcauldwell/vcf
```

Modules: `vcf_host`, `vcf_cluster`, `vcf_domain`, `vcf_credential`, `vcf_dns`, `vcf_certificate`, `vcf_identity_provider`, `vcf_nsx_segment`, `vcf_nsx_gateway`, `vcf_nsx_firewall`, `vcf_nsx_nat`.

```yaml
- name: Commission hosts
  darrylcauldwell.vcf.vcf_host:
    sddc_hostname: sddc-manager.lab.dev
    sddc_username: admin@local
    sddc_password: "{{ vault_sddc_password }}"
    state: present
    host_spec:
      - fqdn: esxi-05.lab.dev
        username: root
        password: "{{ vault_esxi_password }}"
        storageType: VSAN_ESA
        networkPoolId: "{{ network_pool_id }}"
```

## Development

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest tests/ -v --cov=vcf_sdk
ruff check vcf_sdk/ tests/
```

## License

MIT
