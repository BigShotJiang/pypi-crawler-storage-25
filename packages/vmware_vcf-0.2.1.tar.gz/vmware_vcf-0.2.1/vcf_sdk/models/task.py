"""Task model for SDDC Manager API responses."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

# Known terminal statuses — not exhaustive; the API may return other values.
_TERMINAL_STATUSES = {"SUCCESSFUL", "FAILED", "CANCELLED"}


class Task(BaseModel):
    """SDDC Manager task response model."""

    id: str = Field(description="Task ID")
    status: str = Field(description="Task status")
    progress: Optional[int] = Field(default=None, description="Progress percentage")
    description: Optional[str] = Field(default=None, description="Task description")
    message: Optional[str] = Field(default=None, description="Task message")
    errors: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Error details",
    )
    sub_tasks: Optional[List["Task"]] = Field(
        default=None,
        alias="subTasks",
        description="Nested subtasks",
    )
    creation_time_millis: Optional[int] = Field(
        default=None,
        alias="creationTimeMillis",
        description="Task creation timestamp (ms)",
    )
    start_time_millis: Optional[int] = Field(
        default=None,
        alias="startTimeMillis",
        description="Task start timestamp (ms)",
    )
    end_time_millis: Optional[int] = Field(
        default=None,
        alias="endTimeMillis",
        description="Task end timestamp (ms)",
    )

    model_config = ConfigDict(populate_by_name=True)

    @property
    def is_terminal(self) -> bool:
        """Check if task is in terminal state."""
        return self.status in _TERMINAL_STATUSES

    @property
    def is_successful(self) -> bool:
        """Check if task completed successfully."""
        return self.status == "SUCCESSFUL"

    @property
    def is_failed(self) -> bool:
        """Check if task failed."""
        return self.status in ("FAILED", "CANCELLED")


# Update forward references
Task.model_rebuild()
