"""Tests for full SDDC Manager API coverage — new categories and sub-endpoints."""

from unittest.mock import MagicMock

from vcf_sdk.managers.alb_clusters import ALBClusterManager
from vcf_sdk.managers.brownfield import BrownfieldManager
from vcf_sdk.managers.check_sets import CheckSetManager
from vcf_sdk.managers.compatibility import CompatibilityManager
from vcf_sdk.managers.config_drift import ConfigDriftManager
from vcf_sdk.managers.manifests import ManifestManager
from vcf_sdk.managers.notifications import NotificationManager
from vcf_sdk.managers.product_catalogs import ProductBinaryManager, ProductVersionCatalogManager
from vcf_sdk.managers.repository_images import RepositoryImageManager
from vcf_sdk.managers.resource_functionalities import ResourceFunctionalityManager
from vcf_sdk.managers.trusted_certs import TrustedCertificateManager
from vcf_sdk.managers.vasa_providers import VASAProviderManager
from vcf_sdk.managers.vcf_components import VCFComponentManager
from vcf_sdk.managers.version_aliases import VersionAliasManager
from vcf_sdk.managers.vsan import VSANManager
from vcf_sdk.managers.clusters import ClusterManager
from vcf_sdk.managers.domains import DomainManager
from vcf_sdk.managers.hosts import HostManager
from vcf_sdk.managers.tasks import TaskManager
from vcf_sdk.managers.users import UserManager
from vcf_sdk.managers.licensing import LicenseManager
from vcf_sdk.managers.bundles import BundleManager
from vcf_sdk.managers.system import SystemManager


def _m():
    client = MagicMock()
    auth = MagicMock()
    auth.get_auth_headers.return_value = {"Authorization": "Bearer t"}
    return client, auth


# --- New category managers ---

class TestALBClusterManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"id": "alb-1"}]}
        assert len(ALBClusterManager(c, a).list()) == 1

    def test_get_form_factors(self):
        c, a = _m()
        c.get.return_value = {"formFactors": []}
        ALBClusterManager(c, a).get_form_factors()
        assert "/v1/alb-clusters/form-factors" in c.get.call_args[0][0]


class TestBrownfieldManager:
    def test_start_import(self):
        c, a = _m()
        c.post.return_value = {"id": "import-1"}
        result = BrownfieldManager(c, a).start_import({"spec": "data"})
        assert result["id"] == "import-1"

    def test_synchronize(self):
        c, a = _m()
        c.post.return_value = {"id": "sync-1"}
        BrownfieldManager(c, a).synchronize("domain-1")
        assert "synchronizations" in c.post.call_args[0][0]


class TestCheckSetManager:
    def test_trigger_run(self):
        c, a = _m()
        c.post.return_value = {"id": "run-1"}
        CheckSetManager(c, a).trigger_run()
        assert "/v1/system/check-sets" in c.post.call_args[0][0]

    def test_get_run(self):
        c, a = _m()
        c.get.return_value = {"id": "run-1", "status": "COMPLETED"}
        result = CheckSetManager(c, a).get_run("run-1")
        assert result["status"] == "COMPLETED"


class TestCompatibilityManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"matrices": []}
        CompatibilityManager(c, a).list()
        assert "/v1/compatibility-matrices" in c.get.call_args[0][0]


class TestConfigDriftManager:
    def test_get_drifts(self):
        c, a = _m()
        c.get.return_value = {"drifts": []}
        ConfigDriftManager(c, a).get_drifts()

    def test_reconcile(self):
        c, a = _m()
        c.post.return_value = {"id": "task-1"}
        ConfigDriftManager(c, a).reconcile({"spec": "data"})


class TestManifestManager:
    def test_get(self):
        c, a = _m()
        c.get.return_value = {"version": "1.0"}
        result = ManifestManager(c, a).get()
        assert result["version"] == "1.0"


class TestNotificationManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"id": "n-1", "message": "test"}]}
        notifs = NotificationManager(c, a).list()
        assert len(notifs) == 1


class TestProductManagers:
    def test_binary_upload(self):
        c, a = _m()
        c.post.return_value = {"id": "upload-1"}
        ProductBinaryManager(c, a).upload({"path": "/tmp/bin"})

    def test_catalog_get(self):
        c, a = _m()
        c.get.return_value = {"content": []}
        ProductVersionCatalogManager(c, a).get()


class TestRepositoryImageManager:
    def test_query(self):
        c, a = _m()
        c.post.return_value = {"id": "q-1"}
        RepositoryImageManager(c, a).query({"spec": "data"})


class TestResourceFunctionalityManager:
    def test_get(self):
        c, a = _m()
        c.get.return_value = {"functionalities": []}
        ResourceFunctionalityManager(c, a).get()

    def test_list_warnings(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        ResourceFunctionalityManager(c, a).list_warnings()


class TestTrustedCertificateManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"alias": "cert-1"}]}
        certs = TrustedCertificateManager(c, a).list()
        assert len(certs) == 1

    def test_add(self):
        c, a = _m()
        c.post.return_value = {"alias": "new-cert"}
        TrustedCertificateManager(c, a).add({"certificate": "PEM data"})

    def test_delete(self):
        c, a = _m()
        c.delete.return_value = {}
        TrustedCertificateManager(c, a).delete("cert-1")


class TestVASAProviderManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"id": "vasa-1"}]}
        assert len(VASAProviderManager(c, a).list()) == 1

    def test_list_containers(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"id": "sc-1"}]}
        containers = VASAProviderManager(c, a).list_containers("vasa-1")
        assert len(containers) == 1

    def test_list_users(self):
        c, a = _m()
        c.get.return_value = {"elements": [{"id": "u-1"}]}
        VASAProviderManager(c, a).list_users("vasa-1")


class TestVCFComponentManager:
    def test_list(self):
        c, a = _m()
        c.get.return_value = {"components": []}
        VCFComponentManager(c, a).list()

    def test_get_latest_task(self):
        c, a = _m()
        c.get.return_value = {"id": "task-1"}
        VCFComponentManager(c, a).get_latest_task()


class TestVersionAliasManager:
    def test_get(self):
        c, a = _m()
        c.get.return_value = {"aliases": []}
        VersionAliasManager(c, a).get()

    def test_delete_by_type(self):
        c, a = _m()
        c.delete.return_value = {}
        VersionAliasManager(c, a).delete_by_type("VCENTER")


class TestVSANManager:
    def test_get_hcl_attributes(self):
        c, a = _m()
        c.get.return_value = {"lastUpdated": "2024-01-01"}
        result = VSANManager(c, a).get_hcl_attributes()
        assert "lastUpdated" in result

    def test_get_health_check(self):
        c, a = _m()
        c.get.return_value = {"status": "GREEN"}
        result = VSANManager(c, a).get_health_check("domain-1")
        assert result["status"] == "GREEN"

    def test_sync_umds(self):
        c, a = _m()
        c.request.return_value = {}
        VSANManager(c, a).sync_umds()


# --- Sub-endpoint gaps in existing managers ---

class TestClusterSubEndpoints:
    def test_get_tags(self):
        c, a = _m()
        c.get.return_value = {"tags": []}
        ClusterManager(c, a).get_tags("c-1")
        assert "/v1/clusters/c-1/tags" in c.get.call_args[0][0]

    def test_get_datastores(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        ClusterManager(c, a).get_datastores("c-1")

    def test_get_image_compliance(self):
        c, a = _m()
        c.get.return_value = {"status": "COMPLIANT"}
        ClusterManager(c, a).get_image_compliance("c-1")

    def test_query_network(self):
        c, a = _m()
        c.post.return_value = {"network": {}}
        ClusterManager(c, a).query_network("c-1", {"type": "MANAGEMENT"})


class TestDomainSubEndpoints:
    def test_get_capabilities(self):
        c, a = _m()
        c.get.return_value = {"capabilities": []}
        DomainManager(c, a).get_capabilities("d-1")

    def test_get_datacenters(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        DomainManager(c, a).get_datacenters("d-1")

    def test_isolation_precheck(self):
        c, a = _m()
        c.post.return_value = {"id": "pre-1"}
        DomainManager(c, a).isolation_precheck("d-1")


class TestHostSubEndpoints:
    def test_get_tags(self):
        c, a = _m()
        c.get.return_value = {"tags": []}
        HostManager(c, a).get_tags("h-1")

    def test_get_criteria(self):
        c, a = _m()
        c.get.return_value = {"criteria": []}
        HostManager(c, a).get_criteria()


class TestTaskCancel:
    def test_cancel(self):
        c, a = _m()
        c.delete.return_value = {}
        TaskManager(c, a).cancel("task-1")
        assert "/v1/tasks/task-1" in c.delete.call_args[0][0]


class TestUserSubEndpoints:
    def test_get_local_admin(self):
        c, a = _m()
        c.get.return_value = {"username": "admin@local"}
        UserManager(c, a).get_local_admin()

    def test_list_sso_domains(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        UserManager(c, a).list_sso_domains()

    def test_list_sso_entities(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        UserManager(c, a).list_sso_entities("vsphere.local")
        assert "vsphere.local" in c.get.call_args[0][0]


class TestLicensingSubEndpoints:
    def test_get_system_licensing(self):
        c, a = _m()
        c.get.return_value = {"mode": "PERPETUAL"}
        LicenseManager(c, a).get_system_licensing()

    def test_get_product_types(self):
        c, a = _m()
        c.get.return_value = {"types": []}
        LicenseManager(c, a).get_product_types()


class TestBundleSubEndpoints:
    def test_schedule_upgrade(self):
        c, a = _m()
        c.request.return_value = {"id": "up-1", "status": "SCHEDULED"}
        BundleManager(c, a).schedule_upgrade("up-1")

    def test_preview_upgrade(self):
        c, a = _m()
        c.get.return_value = {"preview": {}}
        BundleManager(c, a).preview_upgrade(domainId="d-1")

    def test_get_domain_upgradables(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        BundleManager(c, a).get_domain_upgradables("d-1")


class TestSystemSubEndpoints:
    def test_get_system_config(self):
        c, a = _m()
        c.get.return_value = {"config": {}}
        SystemManager(c, a).get_system_config()

    def test_get_appliance_info(self):
        c, a = _m()
        c.get.return_value = {"version": "5.2.0"}
        SystemManager(c, a).get_appliance_info()

    def test_get_depot_sync_info(self):
        c, a = _m()
        c.get.return_value = {"syncStatus": "SYNCED"}
        SystemManager(c, a).get_depot_sync_info()

    def test_scale_out_nsxt(self):
        c, a = _m()
        c.post.return_value = {"id": "task-1"}
        SystemManager(c, a).scale_out_nsxt("nsx-1", {"spec": "data"})

    def test_get_nsxt_transport_zones(self):
        c, a = _m()
        c.get.return_value = {"elements": []}
        SystemManager(c, a).get_nsxt_transport_zones("nsx-1")

    def test_get_system_release(self):
        c, a = _m()
        c.get.return_value = {"version": "5.2.0"}
        SystemManager(c, a).get_system_release()

    def test_get_future_releases(self):
        c, a = _m()
        c.get.return_value = {"releases": []}
        SystemManager(c, a).get_future_releases("d-1")


class TestSDDCManagerHasAllManagers:
    def test_all_34_managers(self):
        from unittest.mock import patch
        from vcf_sdk.sddc_manager import SDDCManager

        with patch.object(SDDCManager, '__init__', lambda self, *a, **kw: None):
            sddc = SDDCManager.__new__(SDDCManager)
            sddc.client = MagicMock()
            sddc.auth = MagicMock()

            # Wire up all managers manually
            sddc.alb_clusters = ALBClusterManager(sddc.client, sddc.auth)
            sddc.brownfield = BrownfieldManager(sddc.client, sddc.auth)
            sddc.check_sets = CheckSetManager(sddc.client, sddc.auth)
            sddc.compatibility = CompatibilityManager(sddc.client, sddc.auth)
            sddc.config_drift = ConfigDriftManager(sddc.client, sddc.auth)
            sddc.manifests = ManifestManager(sddc.client, sddc.auth)
            sddc.notifications = NotificationManager(sddc.client, sddc.auth)
            sddc.product_binaries = ProductBinaryManager(sddc.client, sddc.auth)
            sddc.product_catalogs = ProductVersionCatalogManager(sddc.client, sddc.auth)
            sddc.repository_images = RepositoryImageManager(sddc.client, sddc.auth)
            sddc.resource_functionalities = ResourceFunctionalityManager(sddc.client, sddc.auth)
            sddc.trusted_certificates = TrustedCertificateManager(sddc.client, sddc.auth)
            sddc.vasa_providers = VASAProviderManager(sddc.client, sddc.auth)
            sddc.vcf_components = VCFComponentManager(sddc.client, sddc.auth)
            sddc.version_aliases = VersionAliasManager(sddc.client, sddc.auth)
            sddc.vsan = VSANManager(sddc.client, sddc.auth)

            assert isinstance(sddc.alb_clusters, ALBClusterManager)
            assert isinstance(sddc.vasa_providers, VASAProviderManager)
            assert isinstance(sddc.vsan, VSANManager)
            assert isinstance(sddc.config_drift, ConfigDriftManager)
            assert isinstance(sddc.trusted_certificates, TrustedCertificateManager)
