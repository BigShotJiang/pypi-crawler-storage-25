"""Tests for vCenter REST API models."""

from vcf_sdk.models.vcenter import (
    VM, VMDetail,
    Library, LibraryItem,
    SupervisorCluster, Namespace, NamespaceAccess,
    TagCategory, Tag,
    Cluster, Datacenter, Datastore, HostSummary, Network, ResourcePool, StoragePolicy,
    OVFDeployResult,
)


class TestVM:
    def test_vm_summary(self):
        vm = VM(vm="vm-42", name="web-01", power_state="POWERED_ON",
                cpu_count=4, memory_size_MiB=8192)
        assert vm.vm == "vm-42"
        assert vm.power_state == "POWERED_ON"
        assert vm.memory_size_MiB == 8192

    def test_vm_detail(self):
        detail = VMDetail(name="web-01", power_state="POWERED_ON",
                          guest_OS="RHEL_8_64",
                          cpu={"count": 4, "cores_per_socket": 1},
                          memory={"size_MiB": 8192})
        assert detail.guest_OS == "RHEL_8_64"
        assert detail.cpu["count"] == 4


class TestContentLibrary:
    def test_library(self):
        lib = Library(id="lib-1", name="templates", type="LOCAL",
                      storage_backings=[{"datastore_id": "ds-10", "type": "DATASTORE"}])
        assert lib.name == "templates"
        assert lib.type == "LOCAL"

    def test_library_item(self):
        item = LibraryItem(id="item-1", library_id="lib-1", name="rhel-template",
                           type="ovf", size=1073741824)
        assert item.type == "ovf"
        assert item.size == 1073741824


class TestNamespace:
    def test_supervisor_cluster(self):
        sc = SupervisorCluster(cluster="domain-c8", cluster_name="Cluster-01",
                               config_status="RUNNING", kubernetes_status="READY")
        assert sc.kubernetes_status == "READY"

    def test_namespace(self):
        ns = Namespace(namespace="dev-ns", cluster="domain-c8",
                       description="Dev namespace",
                       config_status="RUNNING",
                       storage_specs=[{"policy": "policy-1"}])
        assert ns.namespace == "dev-ns"
        assert len(ns.storage_specs) == 1

    def test_namespace_access(self):
        access = NamespaceAccess(subject_type="USER",
                                 subject="admin@vsphere.local",
                                 domain="vsphere.local", role="EDIT")
        assert access.role == "EDIT"


class TestTagging:
    def test_tag_category(self):
        cat = TagCategory(id="cat-1", name="Environment",
                          cardinality="SINGLE",
                          associable_types=["VirtualMachine", "Datastore"])
        assert cat.cardinality == "SINGLE"
        assert len(cat.associable_types) == 2

    def test_tag(self):
        tag = Tag(id="tag-1", name="Production", category_id="cat-1")
        assert tag.category_id == "cat-1"


class TestInfrastructure:
    def test_cluster(self):
        c = Cluster(cluster="domain-c8", name="Cluster-01",
                    ha_enabled=True, drs_enabled=True)
        assert c.drs_enabled is True

    def test_datacenter(self):
        dc = Datacenter(datacenter="datacenter-2", name="DC-01")
        assert dc.name == "DC-01"

    def test_datastore(self):
        ds = Datastore(datastore="datastore-10", name="vsanDatastore",
                       type="VSAN", free_space=1099511627776, capacity=2199023255552)
        assert ds.type == "VSAN"
        assert ds.free_space > 0

    def test_host_summary(self):
        h = HostSummary(host="host-15", name="esxi-01.lab.dev",
                        connection_state="CONNECTED", power_state="POWERED_ON")
        assert h.connection_state == "CONNECTED"

    def test_network(self):
        n = Network(network="dvportgroup-20", name="VM Network",
                    type="DISTRIBUTED_PORTGROUP")
        assert n.type == "DISTRIBUTED_PORTGROUP"

    def test_resource_pool(self):
        rp = ResourcePool(resource_pool="resgroup-9", name="Resources")
        assert rp.resource_pool == "resgroup-9"

    def test_storage_policy(self):
        sp = StoragePolicy(policy="policy-1", name="vSAN Default Storage Policy")
        assert sp.name == "vSAN Default Storage Policy"


class TestOVF:
    def test_deploy_success(self):
        result = OVFDeployResult(
            succeeded=True,
            resource_id={"type": "VirtualMachine", "id": "vm-100"},
        )
        assert result.succeeded is True
        assert result.resource_id["id"] == "vm-100"

    def test_deploy_failure(self):
        result = OVFDeployResult(
            succeeded=False,
            error={"messages": [{"default_message": "Deployment failed"}]},
        )
        assert result.succeeded is False
        assert result.error is not None
