"""Tests for extended NSX-T coverage: core networking, IP blocks, fabric, VPC."""

from unittest.mock import MagicMock

from vcf_sdk.nsx.tier0 import Tier0Manager
from vcf_sdk.nsx.tier1 import Tier1Manager
from vcf_sdk.nsx.segments import SegmentManager
from vcf_sdk.nsx.ip_pools import IPPoolManager
from vcf_sdk.nsx.fabric import (
    HostTransportNodeManager, TransportNodeCollectionManager,
    TransportNodeProfileManager, EdgeTransportNodeManager,
    HostSwitchProfileManager, EdgeHAProfileManager,
    SiteManager, ComputeSubClusterManager,
)
from vcf_sdk.nsx.vpc import ProjectManager, VPCManager
from vcf_sdk.models.nsx import (
    OSPFConfig, PrefixList, SegmentPort,
    IPBlock, HostTransportNode, HostSwitchProfile,
    Site, Project, VPC, VPCSubnet,
)


def _mc():
    c = MagicMock()
    c.get.return_value = {"results": []}
    c.patch.return_value = {}
    c.delete.return_value = {}
    return c


# --- Core Networking ---

class TestTier0OSPF:
    def test_get_ospf(self):
        c = _mc()
        c.get.return_value = {"enabled": True, "ecmp": True}
        result = Tier0Manager(c).get_ospf("t0", "default")
        assert result.enabled is True

    def test_list_ospf_areas(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "area-0", "area_type": "NORMAL"}]}
        areas = Tier0Manager(c).list_ospf_areas("t0", "default")
        assert areas[0].area_type == "NORMAL"

    def test_create_ospf_area(self):
        c = _mc()
        Tier0Manager(c).create_or_update_ospf_area("t0", "default", "area-0", {"area_type": "NSSA"})
        assert "ospf/areas/area-0" in c.patch.call_args[0][0]


class TestTier0PrefixLists:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "pl-1", "prefixes": []}]}
        pls = Tier0Manager(c).list_prefix_lists("t0")
        assert len(pls) == 1

    def test_create(self):
        c = _mc()
        Tier0Manager(c).create_or_update_prefix_list("t0", "pl-1", {"prefixes": [{"network": "10.0.0.0/8", "action": "PERMIT"}]})
        assert "prefix-lists/pl-1" in c.patch.call_args[0][0]


class TestTier0CommunityLists:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "cl-1", "communities": ["65001:100"]}]}
        cls = Tier0Manager(c).list_community_lists("t0")
        assert cls[0].communities == ["65001:100"]


class TestTier0RouteMaps:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "rm-1"}]}
        rms = Tier0Manager(c).list_route_maps("t0")
        assert rms[0].id == "rm-1"

    def test_create(self):
        c = _mc()
        Tier0Manager(c).create_or_update_route_map("t0", "rm-1", {"entries": []})
        assert "route-maps/rm-1" in c.patch.call_args[0][0]


class TestTier1PrefixLists:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "pl-1"}]}
        pls = Tier1Manager(c).list_prefix_lists("t1")
        assert len(pls) == 1


class TestSegmentPorts:
    def test_list_ports(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "port-1"}]}
        ports = SegmentManager(c).list_ports("seg-1")
        assert ports[0].id == "port-1"

    def test_create_port(self):
        c = _mc()
        SegmentManager(c).create_or_update_port("seg-1", "port-1", {"attachment": {"type": "VIF"}})
        assert "ports/port-1" in c.patch.call_args[0][0]


# --- IP Blocks ---

class TestIPBlocks:
    def test_list_blocks(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "block-1", "cidr": "10.0.0.0/16"}]}
        blocks = IPPoolManager(c).list_blocks()
        assert blocks[0].cidr == "10.0.0.0/16"

    def test_create_block(self):
        c = _mc()
        IPPoolManager(c).create_or_update_block("block-1", {"cidr": "10.0.0.0/16"})
        assert "ip-blocks/block-1" in c.patch.call_args[0][0]

    def test_list_block_subnets(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "sub-1", "cidr": "10.0.1.0/24"}]}
        subs = IPPoolManager(c).list_block_subnets("block-1")
        assert subs[0].cidr == "10.0.1.0/24"


# --- Fabric ---

class TestHostTransportNodes:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "htn-1"}]}
        nodes = HostTransportNodeManager(c).list()
        assert len(nodes) == 1

    def test_create(self):
        c = _mc()
        HostTransportNodeManager(c).create_or_update("htn-1", {"host_switch_spec": {}})
        assert "host-transport-nodes/htn-1" in c.patch.call_args[0][0]


class TestTransportNodeCollections:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "tnc-1"}]}
        collections = TransportNodeCollectionManager(c).list()
        assert len(collections) == 1


class TestTransportNodeProfiles:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "tnp-1"}]}
        profiles = TransportNodeProfileManager(c).list()
        assert len(profiles) == 1


class TestEdgeTransportNodes:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "etn-1"}]}
        nodes = EdgeTransportNodeManager(c).list()
        assert len(nodes) == 1


class TestHostSwitchProfiles:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "hsp-1", "transport_vlan": 100}]}
        profiles = HostSwitchProfileManager(c).list()
        assert profiles[0].transport_vlan == 100


class TestEdgeHAProfiles:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "eha-1"}]}
        EdgeHAProfileManager(c).list()


class TestSites:
    def test_list_sites(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "default"}]}
        sites = SiteManager(c).list_sites()
        assert sites[0].id == "default"

    def test_list_enforcement_points(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "default"}]}
        eps = SiteManager(c).list_enforcement_points("default")
        assert len(eps) == 1


class TestComputeSubClusters:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "csc-1"}]}
        ComputeSubClusterManager(c).list()


# --- VPC Multi-tenancy ---

class TestProjects:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "proj-1", "short_id": "p1"}]}
        projects = ProjectManager(c).list()
        assert projects[0].short_id == "p1"

    def test_create(self):
        c = _mc()
        ProjectManager(c).create_or_update("proj-1", {"display_name": "Project 1"})
        assert "projects/proj-1" in c.patch.call_args[0][0]

    def test_delete(self):
        c = _mc()
        ProjectManager(c).delete("proj-1")
        assert "projects/proj-1" in c.delete.call_args[0][0]


class TestVPCs:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "vpc-1"}]}
        VPCManager(c).list("proj-1")
        assert "projects/proj-1/vpcs" in c.get.call_args[0][0]

    def test_create(self):
        c = _mc()
        VPCManager(c).create_or_update("proj-1", "vpc-1", {"display_name": "My VPC"})
        assert "vpcs/vpc-1" in c.patch.call_args[0][0]

    def test_list_subnets(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "subnet-1", "access_mode": "Private"}]}
        subnets = VPCManager(c).list_subnets("proj-1", "vpc-1")
        assert subnets[0].access_mode == "Private"

    def test_create_subnet(self):
        c = _mc()
        VPCManager(c).create_or_update_subnet("proj-1", "vpc-1", "subnet-1", {"ipv4_subnet_size": 64})
        assert "subnets/subnet-1" in c.patch.call_args[0][0]

    def test_list_groups(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "grp-1"}]}
        groups = VPCManager(c).list_groups("proj-1", "vpc-1")
        assert len(groups) == 1

    def test_create_security_policy(self):
        c = _mc()
        VPCManager(c).create_or_update_security_policy("proj-1", "vpc-1", "pol-1", {"category": "Application"})
        assert "security-policies/pol-1" in c.patch.call_args[0][0]

    def test_create_nat_rule(self):
        c = _mc()
        VPCManager(c).create_or_update_nat_rule("proj-1", "vpc-1", "snat-1", {"action": "SNAT"})
        assert "nat-rules/snat-1" in c.patch.call_args[0][0]

    def test_create_static_route(self):
        c = _mc()
        VPCManager(c).create_or_update_static_route("proj-1", "vpc-1", "route-1", {"network": "0.0.0.0/0"})
        assert "static-routes/route-1" in c.patch.call_args[0][0]

    def test_list_gateway_policies(self):
        c = _mc()
        c.get.return_value = {"results": []}
        VPCManager(c).list_gateway_policies("proj-1", "vpc-1")

    def test_dhcp_bindings(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "bind-1"}]}
        bindings = VPCManager(c).list_dhcp_bindings("proj-1", "vpc-1", "subnet-1")
        assert len(bindings) == 1


class TestNSXManagerAllManagers:
    def test_new_managers_present(self):
        from unittest.mock import patch
        from vcf_sdk.nsx_manager import NSXManager

        with patch.object(NSXManager, '__init__', lambda self, *a, **kw: None):
            nsx = NSXManager.__new__(NSXManager)
            nsx.client = MagicMock()
            nsx._auth = ("admin", "pass")

            nsx.host_transport_nodes = HostTransportNodeManager(nsx)
            nsx.transport_node_collections = TransportNodeCollectionManager(nsx)
            nsx.transport_node_profiles = TransportNodeProfileManager(nsx)
            nsx.edge_transport_nodes = EdgeTransportNodeManager(nsx)
            nsx.host_switch_profiles = HostSwitchProfileManager(nsx)
            nsx.edge_ha_profiles = EdgeHAProfileManager(nsx)
            nsx.sites = SiteManager(nsx)
            nsx.compute_sub_clusters = ComputeSubClusterManager(nsx)
            nsx.projects = ProjectManager(nsx)
            nsx.vpcs = VPCManager(nsx)

            assert isinstance(nsx.host_transport_nodes, HostTransportNodeManager)
            assert isinstance(nsx.projects, ProjectManager)
            assert isinstance(nsx.vpcs, VPCManager)
            assert isinstance(nsx.sites, SiteManager)


class TestNSXModels:
    def test_ospf_config(self):
        cfg = OSPFConfig(enabled=True, ecmp=True)
        assert cfg.enabled

    def test_prefix_list(self):
        pl = PrefixList(id="pl-1", prefixes=[{"network": "10.0.0.0/8", "action": "PERMIT"}])
        assert len(pl.prefixes) == 1

    def test_ip_block(self):
        block = IPBlock(id="blk-1", cidr="10.0.0.0/16")
        assert block.cidr == "10.0.0.0/16"

    def test_project(self):
        proj = Project(id="proj-1", short_id="p1", tier0s=["/infra/tier-0s/t0"])
        assert proj.short_id == "p1"

    def test_vpc(self):
        vpc = VPC(id="vpc-1", ip_address_type="IPV4")
        assert vpc.ip_address_type == "IPV4"

    def test_vpc_subnet(self):
        sub = VPCSubnet(id="sub-1", access_mode="Private", ipv4_subnet_size=64)
        assert sub.ipv4_subnet_size == 64

    def test_segment_port(self):
        port = SegmentPort(id="port-1", attachment={"type": "VIF", "id": "vif-1"})
        assert port.attachment["type"] == "VIF"

    def test_host_transport_node(self):
        htn = HostTransportNode(id="htn-1", maintenance_mode="DISABLED")
        assert htn.maintenance_mode == "DISABLED"

    def test_site(self):
        site = Site(id="default", site_type="DEFAULT")
        assert site.site_type == "DEFAULT"

    def test_host_switch_profile(self):
        hsp = HostSwitchProfile(id="hsp-1", transport_vlan=100)
        assert hsp.transport_vlan == 100
