"""Tests for version checking framework."""

import warnings

import pytest

from vcf_sdk.versions import parse_version, check_version, SDDC_MANAGER_VERSIONS, NSX_MANAGER_VERSIONS
from vcf_sdk.version_check import (
    UnsupportedVersionError,
    DeprecatedFeatureWarning,
    requires_version,
    check_manager_version,
)


class TestParseVersion:
    def test_standard(self):
        assert parse_version("9.0.2") == (9, 0, 2)

    def test_four_part(self):
        assert parse_version("9.0.2.0") == (9, 0, 2)

    def test_empty(self):
        assert parse_version("") == (0, 0, 0)

    def test_two_part(self):
        assert parse_version("4.2") == (4, 2)


class TestCheckVersion:
    def test_meets_requirement(self):
        assert check_version("9.0.2", "5.0.0") is True

    def test_exact_match(self):
        assert check_version("5.2.0", "5.2.0") is True

    def test_below_requirement(self):
        assert check_version("4.5.0", "5.0.0") is False

    def test_none_requirement(self):
        assert check_version("1.0.0", None) is True


class TestRequiresVersionDecorator:
    def test_passes_when_version_sufficient(self):
        class FakeManager:
            _api_version = "9.0.2"

            @requires_version("5.0.0", "brownfield import")
            def do_import(self):
                return "ok"

        assert FakeManager().do_import() == "ok"

    def test_raises_when_version_insufficient(self):
        class FakeManager:
            _api_version = "4.3.0"

            @requires_version("5.0.0", "brownfield import")
            def do_import(self):
                return "ok"

        with pytest.raises(UnsupportedVersionError) as exc_info:
            FakeManager().do_import()
        assert "5.0.0" in str(exc_info.value)
        assert "4.3.0" in str(exc_info.value)

    def test_passes_when_no_version_set(self):
        class FakeManager:
            _api_version = None

            @requires_version("5.0.0", "brownfield import")
            def do_import(self):
                return "ok"

        assert FakeManager().do_import() == "ok"

    def test_docstring_annotated(self):
        class FakeManager:
            _api_version = "9.0.0"

            @requires_version("5.2.0", "compliance", product="VCF")
            def check(self):
                """Run compliance check."""
                pass

        assert "5.2.0" in FakeManager.check.__doc__


class TestCheckManagerVersion:
    def test_no_warning_when_version_sufficient(self, caplog):
        with caplog.at_level("WARNING"):
            check_manager_version("compliance", "9.0.0", SDDC_MANAGER_VERSIONS, product="VCF")
        assert "compliance" not in caplog.text

    def test_warning_when_version_insufficient(self, caplog):
        with caplog.at_level("WARNING"):
            check_manager_version("compliance", "4.5.0", SDDC_MANAGER_VERSIONS, product="VCF")
        assert "compliance" in caplog.text
        assert "5.2.0" in caplog.text

    def test_no_warning_for_core_managers(self, caplog):
        with caplog.at_level("WARNING"):
            check_manager_version("tasks", "3.0.0", SDDC_MANAGER_VERSIONS, product="VCF")
        assert caplog.text == ""

    def test_deprecated_warning(self):
        from vcf_sdk.versions import SDDC_DEPRECATED
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            check_manager_version(
                "identity_providers", "9.0.0",
                SDDC_MANAGER_VERSIONS, SDDC_DEPRECATED, product="VCF"
            )
            deprecation_warnings = [x for x in w if issubclass(x.category, DeprecatedFeatureWarning)]
            assert len(deprecation_warnings) == 1
            assert "deprecated" in str(deprecation_warnings[0].message).lower()

    def test_no_deprecated_warning_on_older_version(self):
        from vcf_sdk.versions import SDDC_DEPRECATED
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            check_manager_version(
                "identity_providers", "5.0.0",
                SDDC_MANAGER_VERSIONS, SDDC_DEPRECATED, product="VCF"
            )
            deprecation_warnings = [x for x in w if issubclass(x.category, DeprecatedFeatureWarning)]
            assert len(deprecation_warnings) == 0

    def test_skips_when_no_version(self, caplog):
        with caplog.at_level("WARNING"):
            check_manager_version("compliance", None, SDDC_MANAGER_VERSIONS, product="VCF")
        assert caplog.text == ""


class TestNSXVersions:
    def test_core_managers_have_versions(self):
        assert NSX_MANAGER_VERSIONS["segments"] == "2.4.0"
        assert NSX_MANAGER_VERSIONS["tier0"] == "2.4.0"

    def test_vpc_requires_411(self):
        assert NSX_MANAGER_VERSIONS["vpcs"] == "4.1.1"

    def test_ids_requires_31(self):
        assert NSX_MANAGER_VERSIONS["ids_ips"] == "3.1.0"

    def test_warning_for_vpc_on_old_nsx(self, caplog):
        with caplog.at_level("WARNING"):
            check_manager_version("vpcs", "3.2.0", NSX_MANAGER_VERSIONS, product="NSX")
        assert "vpcs" in caplog.text
        assert "4.1.1" in caplog.text


class TestSDDCVersions:
    def test_core_managers_have_no_version(self):
        assert SDDC_MANAGER_VERSIONS["tasks"] is None
        assert SDDC_MANAGER_VERSIONS["hosts"] is None

    def test_alb_requires_52(self):
        assert SDDC_MANAGER_VERSIONS["alb_clusters"] == "5.2.0"

    def test_brownfield_requires_50(self):
        assert SDDC_MANAGER_VERSIONS["brownfield"] == "5.0.0"


class TestVersionConstants:
    def test_all_sddc_managers_have_entries(self):
        """Every SDDC manager attribute should have a version entry."""
        expected_managers = {
            "tasks", "hosts", "clusters", "domains", "networks", "images",
            "credentials", "certificates", "system", "licenses", "bundles",
            "users", "compliance", "federation", "aria", "edge_clusters",
            "identity_providers", "avns", "alb_clusters", "brownfield",
            "check_sets", "compatibility", "config_drift", "manifests",
            "notifications", "product_binaries", "product_catalogs",
            "repository_images", "resource_functionalities",
            "trusted_certificates", "vasa_providers", "vcf_components",
            "version_aliases", "vsan",
        }
        for mgr in expected_managers:
            assert mgr in SDDC_MANAGER_VERSIONS, f"Missing version entry for SDDC manager: {mgr}"

    def test_all_nsx_managers_have_entries(self):
        """Every NSX manager attribute should have a version entry."""
        from vcf_sdk.nsx_manager import _NSX_MANAGERS
        for mgr in _NSX_MANAGERS:
            assert mgr in NSX_MANAGER_VERSIONS, f"Missing version entry for NSX manager: {mgr}"
