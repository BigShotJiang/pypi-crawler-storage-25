"""Tests for authentication and token refresh."""

import base64
import json
import time

import pytest

from vcf_sdk.auth import SDDCAuth


def _make_jwt(exp: float) -> str:
    """Create a minimal JWT with given expiry for testing."""
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256"}).encode()).decode().rstrip("=")
    payload = base64.urlsafe_b64encode(json.dumps({"exp": exp}).encode()).decode().rstrip("=")
    sig = base64.urlsafe_b64encode(b"fakesig").decode().rstrip("=")
    return f"{header}.{payload}.{sig}"


class TestJWTDecoding:
    def test_decode_valid_jwt(self):
        auth = SDDCAuth("sddc.lab.dev")
        future_exp = time.time() + 3600
        token = _make_jwt(future_exp)
        expiry = auth._decode_jwt_expiry(token)
        assert abs(expiry - future_exp) < 1

    def test_decode_invalid_token(self):
        auth = SDDCAuth("sddc.lab.dev")
        assert auth._decode_jwt_expiry("not-a-jwt") == 0
        assert auth._decode_jwt_expiry("a.b") == 0


class TestTokenExpiry:
    def test_token_not_expiring(self):
        auth = SDDCAuth("sddc.lab.dev")
        auth._access_token = _make_jwt(time.time() + 3600)
        assert not auth._is_token_expiring()

    def test_token_expiring_soon(self):
        auth = SDDCAuth("sddc.lab.dev")
        auth._access_token = _make_jwt(time.time() + 60)  # < 120s threshold
        assert auth._is_token_expiring()

    def test_token_already_expired(self):
        auth = SDDCAuth("sddc.lab.dev")
        auth._access_token = _make_jwt(time.time() - 100)
        assert auth._is_token_expiring()

    def test_no_token_is_expiring(self):
        auth = SDDCAuth("sddc.lab.dev")
        assert auth._is_token_expiring()


class TestAuthHeaders:
    def test_get_auth_headers_with_valid_token(self):
        auth = SDDCAuth("sddc.lab.dev")
        auth._access_token = _make_jwt(time.time() + 3600)
        headers = auth.get_auth_headers()
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Bearer ")

    def test_get_auth_headers_without_token_raises(self):
        auth = SDDCAuth("sddc.lab.dev")
        from vcf_sdk.exceptions import AuthenticationError
        with pytest.raises(AuthenticationError):
            auth.get_auth_headers()
