"""Tests for vCenter REST API managers."""

from unittest.mock import MagicMock

from vcf_sdk.vcenter.vms import VMManager
from vcf_sdk.vcenter.content_library import ContentLibraryManager
from vcf_sdk.vcenter.namespaces import NamespaceManager
from vcf_sdk.vcenter.tagging import TaggingManager
from vcf_sdk.vcenter.infrastructure import InfrastructureManager
from vcf_sdk.vcenter.ovf import OVFManager


def _mock_client():
    client = MagicMock()
    client.get.return_value = []
    client.post.return_value = None
    client.patch.return_value = None
    client.put.return_value = None
    client.delete.return_value = None
    return client


class TestVMManager:
    def test_list_vms(self):
        client = _mock_client()
        client.get.return_value = [
            {"vm": "vm-42", "name": "web-01", "power_state": "POWERED_ON", "cpu_count": 4},
            {"vm": "vm-43", "name": "db-01", "power_state": "POWERED_OFF"},
        ]
        mgr = VMManager(client)
        vms = mgr.list()
        assert len(vms) == 2
        assert vms[0].name == "web-01"

    def test_list_vms_with_filter(self):
        client = _mock_client()
        client.get.return_value = [{"vm": "vm-42", "name": "web-01", "power_state": "POWERED_ON"}]
        mgr = VMManager(client)
        mgr.list(names="web-01")
        call_url = client.get.call_args[0][0]
        assert "filter.names=web-01" in call_url

    def test_get_vm(self):
        client = _mock_client()
        client.get.return_value = {"name": "web-01", "power_state": "POWERED_ON", "guest_OS": "RHEL_8_64"}
        mgr = VMManager(client)
        vm = mgr.get("vm-42")
        assert vm.guest_OS == "RHEL_8_64"

    def test_power_on(self):
        client = _mock_client()
        mgr = VMManager(client)
        mgr.power_on("vm-42")
        client.post.assert_called_with("/vcenter/vm/vm-42/power?action=start", data=None)

    def test_power_off(self):
        client = _mock_client()
        mgr = VMManager(client)
        mgr.power_off("vm-42")
        client.post.assert_called_with("/vcenter/vm/vm-42/power?action=stop", data=None)

    def test_create_vm(self):
        client = _mock_client()
        client.post.return_value = "vm-100"
        mgr = VMManager(client)
        vm_id = mgr.create({"name": "new-vm", "guest_OS": "RHEL_8_64"})
        assert vm_id == "vm-100"

    def test_delete_vm(self):
        client = _mock_client()
        mgr = VMManager(client)
        mgr.delete("vm-42")
        client.delete.assert_called_with("/vcenter/vm/vm-42")


class TestContentLibraryManager:
    def test_list_local_libraries(self):
        client = _mock_client()
        client.get.return_value = ["lib-1", "lib-2"]
        mgr = ContentLibraryManager(client)
        ids = mgr.list_local_libraries()
        assert ids == ["lib-1", "lib-2"]

    def test_get_local_library(self):
        client = _mock_client()
        client.get.return_value = {"id": "lib-1", "name": "templates", "type": "LOCAL"}
        mgr = ContentLibraryManager(client)
        lib = mgr.get_local_library("lib-1")
        assert lib.name == "templates"

    def test_create_local_library(self):
        client = _mock_client()
        client.post.return_value = "lib-new"
        mgr = ContentLibraryManager(client)
        lib_id = mgr.create_local_library({
            "name": "my-lib",
            "storage_backings": [{"datastore_id": "ds-10", "type": "DATASTORE"}],
        })
        assert lib_id == "lib-new"

    def test_list_items(self):
        client = _mock_client()
        client.get.return_value = ["item-1", "item-2"]
        mgr = ContentLibraryManager(client)
        items = mgr.list_items("lib-1")
        assert len(items) == 2

    def test_get_item(self):
        client = _mock_client()
        client.get.return_value = {"id": "item-1", "name": "rhel-ovf", "type": "ovf"}
        mgr = ContentLibraryManager(client)
        item = mgr.get_item("item-1")
        assert item.type == "ovf"


class TestNamespaceManager:
    def test_list_supervisors(self):
        client = _mock_client()
        client.get.return_value = [
            {"cluster": "domain-c8", "config_status": "RUNNING"},
        ]
        mgr = NamespaceManager(client)
        supervisors = mgr.list_supervisors()
        assert supervisors[0].config_status == "RUNNING"

    def test_enable_supervisor(self):
        client = _mock_client()
        mgr = NamespaceManager(client)
        mgr.enable_supervisor("domain-c8", {"size_hint": "SMALL"})
        call_url = client.post.call_args[0][0]
        assert "action=enable" in call_url

    def test_create_namespace(self):
        client = _mock_client()
        mgr = NamespaceManager(client)
        mgr.create_namespace({"namespace": "dev-ns", "cluster": "domain-c8"})
        client.post.assert_called_once()

    def test_list_namespaces(self):
        client = _mock_client()
        client.get.return_value = [
            {"namespace": "dev-ns", "cluster": "domain-c8", "config_status": "RUNNING"},
        ]
        mgr = NamespaceManager(client)
        namespaces = mgr.list_namespaces()
        assert namespaces[0].namespace == "dev-ns"

    def test_set_access(self):
        client = _mock_client()
        mgr = NamespaceManager(client)
        mgr.set_access("dev-ns", "vsphere.local", "admin", {"role": "EDIT"})
        call_url = client.put.call_args[0][0]
        assert "dev-ns/access/vsphere.local/admin" in call_url


class TestTaggingManager:
    def test_list_categories(self):
        client = _mock_client()
        client.get.return_value = ["cat-1", "cat-2"]
        mgr = TaggingManager(client)
        cats = mgr.list_categories()
        assert cats == ["cat-1", "cat-2"]

    def test_create_category(self):
        client = _mock_client()
        client.post.return_value = "cat-new"
        mgr = TaggingManager(client)
        cat_id = mgr.create_category({"name": "Environment", "cardinality": "SINGLE"})
        assert cat_id == "cat-new"

    def test_create_tag(self):
        client = _mock_client()
        client.post.return_value = "tag-new"
        mgr = TaggingManager(client)
        tag_id = mgr.create_tag({"name": "Production", "category_id": "cat-1"})
        assert tag_id == "tag-new"

    def test_attach_tag(self):
        client = _mock_client()
        mgr = TaggingManager(client)
        mgr.attach("tag-1", "VirtualMachine", "vm-42")
        data = client.post.call_args[1]["data"]
        assert data["tag_id"] == "tag-1"
        assert data["object_id"]["type"] == "VirtualMachine"

    def test_list_attached_tags(self):
        client = _mock_client()
        client.post.return_value = ["tag-1", "tag-2"]
        mgr = TaggingManager(client)
        tags = mgr.list_attached_tags("VirtualMachine", "vm-42")
        assert tags == ["tag-1", "tag-2"]


class TestInfrastructureManager:
    def test_list_clusters(self):
        client = _mock_client()
        client.get.return_value = [
            {"cluster": "domain-c8", "name": "Cluster-01", "ha_enabled": True, "drs_enabled": True},
        ]
        mgr = InfrastructureManager(client)
        clusters = mgr.list_clusters()
        assert clusters[0].drs_enabled is True

    def test_list_datastores(self):
        client = _mock_client()
        client.get.return_value = [
            {"datastore": "ds-10", "name": "vsanDatastore", "type": "VSAN", "capacity": 2199023255552},
        ]
        mgr = InfrastructureManager(client)
        datastores = mgr.list_datastores()
        assert datastores[0].type == "VSAN"

    def test_list_hosts(self):
        client = _mock_client()
        client.get.return_value = [
            {"host": "host-15", "name": "esxi-01.lab", "connection_state": "CONNECTED"},
        ]
        mgr = InfrastructureManager(client)
        hosts = mgr.list_hosts()
        assert hosts[0].connection_state == "CONNECTED"

    def test_list_networks(self):
        client = _mock_client()
        client.get.return_value = [
            {"network": "dvpg-20", "name": "VM Network", "type": "DISTRIBUTED_PORTGROUP"},
        ]
        mgr = InfrastructureManager(client)
        networks = mgr.list_networks()
        assert networks[0].type == "DISTRIBUTED_PORTGROUP"

    def test_list_storage_policies(self):
        client = _mock_client()
        client.get.return_value = [
            {"policy": "pol-1", "name": "vSAN Default"},
        ]
        mgr = InfrastructureManager(client)
        policies = mgr.list_storage_policies()
        assert policies[0].name == "vSAN Default"

    def test_list_with_filters(self):
        client = _mock_client()
        client.get.return_value = []
        mgr = InfrastructureManager(client)
        mgr.list_clusters(names="Cluster-01")
        call_url = client.get.call_args[0][0]
        assert "filter.names=Cluster-01" in call_url


class TestOVFManager:
    def test_deploy(self):
        client = _mock_client()
        client.post.return_value = {
            "succeeded": True,
            "resource_id": {"type": "VirtualMachine", "id": "vm-100"},
        }
        mgr = OVFManager(client)
        result = mgr.deploy("item-1", {
            "target": {"resource_pool_id": "resgroup-9"},
            "deployment_spec": {"name": "deployed-vm"},
        })
        assert result.succeeded is True
        assert result.resource_id["id"] == "vm-100"

    def test_get_deploy_options(self):
        client = _mock_client()
        client.post.return_value = {"networks": [], "storage_groups": []}
        mgr = OVFManager(client)
        opts = mgr.get_deploy_options("item-1", {"resource_pool_id": "resgroup-9"})
        assert "networks" in opts


class TestVCenterComposition:
    def test_all_managers_present(self):
        from unittest.mock import patch
        from vcf_sdk.vcenter_client import VCenter

        with patch.object(VCenter, '__init__', lambda self, *a, **kw: None):
            vc = VCenter.__new__(VCenter)
            vc.client = MagicMock()
            vc.auth = MagicMock()

            vc.vms = VMManager(vc)
            vc.content_library = ContentLibraryManager(vc)
            vc.namespaces = NamespaceManager(vc)
            vc.tagging = TaggingManager(vc)
            vc.infrastructure = InfrastructureManager(vc)
            vc.ovf = OVFManager(vc)

            assert isinstance(vc.vms, VMManager)
            assert isinstance(vc.content_library, ContentLibraryManager)
            assert isinstance(vc.namespaces, NamespaceManager)
            assert isinstance(vc.tagging, TaggingManager)
            assert isinstance(vc.infrastructure, InfrastructureManager)
            assert isinstance(vc.ovf, OVFManager)
