"""Tests for NSX-T advanced security and infrastructure profiles."""

from unittest.mock import MagicMock

from vcf_sdk.nsx.advanced_security import (
    ContextProfileManager, L7AccessProfileManager, IDSIPSManager,
    FirewallExcludeListManager, ClusterSecurityConfigManager,
)
from vcf_sdk.nsx.profiles import (
    IPDiscoveryProfileManager, MACDiscoveryProfileManager,
    SpoofGuardProfileManager, SegmentSecurityProfileManager,
    QoSProfileManager, GatewayQoSProfileManager,
    GatewayFloodProtectionProfileManager,
)
from vcf_sdk.models.nsx import (
    ContextProfile, IntrusionServicePolicy,
    IPDiscoveryProfile, MACDiscoveryProfile, SpoofGuardProfile,
    SegmentSecurityProfile, QoSProfile, FloodProtectionProfile,
)


def _mc():
    c = MagicMock()
    c.get.return_value = {"results": []}
    c.patch.return_value = {}
    c.delete.return_value = {}
    return c


# --- Advanced Security ---

class TestContextProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "cp-1", "attributes": []}]}
        profiles = ContextProfileManager(c).list()
        assert profiles[0].id == "cp-1"

    def test_create(self):
        c = _mc()
        ContextProfileManager(c).create_or_update("cp-1", {"attributes": [{"key": "APP_ID"}]})
        assert "context-profiles/cp-1" in c.patch.call_args[0][0]

    def test_list_custom_attributes(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "attr-1"}]}
        ContextProfileManager(c).list_custom_attributes()


class TestL7AccessProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "l7-1"}]}
        L7AccessProfileManager(c).list()

    def test_create(self):
        c = _mc()
        L7AccessProfileManager(c).create_or_update("l7-1", {"l7_access_entries": []})
        assert "l7-access-profiles/l7-1" in c.patch.call_args[0][0]


class TestIDSIPSManager:
    def test_list_policies(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ids-pol-1"}]}
        policies = IDSIPSManager(c).list_policies()
        assert len(policies) == 1

    def test_create_policy(self):
        c = _mc()
        IDSIPSManager(c).create_or_update_policy("ids-pol-1", {"rules": []})
        assert "intrusion-service-policies/ids-pol-1" in c.patch.call_args[0][0]

    def test_list_gateway_policies(self):
        c = _mc()
        c.get.return_value = {"results": []}
        IDSIPSManager(c).list_gateway_policies()

    def test_get_settings(self):
        c = _mc()
        c.get.return_value = {"auto_update": True}
        settings = IDSIPSManager(c).get_settings()
        assert settings.auto_update is True

    def test_list_signature_versions(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "sig-v1"}]}
        IDSIPSManager(c).list_signature_versions()


class TestFirewallExcludeList:
    def test_get(self):
        c = _mc()
        c.get.return_value = {"members": []}
        FirewallExcludeListManager(c).get()

    def test_update(self):
        c = _mc()
        FirewallExcludeListManager(c).update({"members": ["/infra/domains/default/groups/grp-1"]})


class TestClusterSecurityConfig:
    def test_get(self):
        c = _mc()
        c.get.return_value = {"id": "cluster-1"}
        ClusterSecurityConfigManager(c).get("cluster-1")

    def test_update(self):
        c = _mc()
        ClusterSecurityConfigManager(c).update("cluster-1", {"dfw_enabled": True})


# --- Infrastructure Profiles ---

class TestIPDiscoveryProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ipd-1", "arp_nd_binding_timeout": 600}]}
        profiles = IPDiscoveryProfileManager(c).list()
        assert profiles[0].arp_nd_binding_timeout == 600

    def test_create(self):
        c = _mc()
        IPDiscoveryProfileManager(c).create_or_update("ipd-1", {"arp_nd_binding_timeout": 600})
        assert "ip-discovery-profiles/ipd-1" in c.patch.call_args[0][0]


class TestMACDiscoveryProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "mac-1", "mac_learning_enabled": True}]}
        profiles = MACDiscoveryProfileManager(c).list()
        assert profiles[0].mac_learning_enabled is True


class TestSpoofGuardProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "sg-1", "address_binding_allowlist": True}]}
        profiles = SpoofGuardProfileManager(c).list()
        assert profiles[0].address_binding_allowlist is True

    def test_create(self):
        c = _mc()
        SpoofGuardProfileManager(c).create_or_update("sg-1", {"address_binding_allowlist": True})
        assert "spoofguard-profiles/sg-1" in c.patch.call_args[0][0]


class TestSegmentSecurityProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ssp-1", "dhcp_server_block_enabled": True}]}
        profiles = SegmentSecurityProfileManager(c).list()
        assert profiles[0].dhcp_server_block_enabled is True


class TestQoSProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "qos-1", "class_of_service": 3}]}
        profiles = QoSProfileManager(c).list()
        assert profiles[0].class_of_service == 3


class TestGatewayQoSProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "gw-qos-1"}]}
        GatewayQoSProfileManager(c).list()
        assert "gateway-qos-profiles" in c.get.call_args[0][0]


class TestFloodProtectionProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "fp-1", "tcp_half_open_conn_limit": 1000, "rst_spoofing_enabled": True},
        ]}
        profiles = GatewayFloodProtectionProfileManager(c).list()
        assert profiles[0].tcp_half_open_conn_limit == 1000

    def test_create(self):
        c = _mc()
        GatewayFloodProtectionProfileManager(c).create_or_update("fp-1", {
            "resource_type": "GatewayFloodProtectionProfile",
            "tcp_half_open_conn_limit": 1000,
        })
        assert "flood-protection-profiles/fp-1" in c.patch.call_args[0][0]

    def test_tier0_binding(self):
        c = _mc()
        GatewayFloodProtectionProfileManager(c).set_tier0_binding("t0-gw", "bind-1", {
            "profile_path": "/infra/flood-protection-profiles/fp-1",
        })
        assert "tier-0s/t0-gw/flood-protection-profile-bindings/bind-1" in c.patch.call_args[0][0]


# --- Models ---

class TestAdvancedSecurityModels:
    def test_context_profile(self):
        cp = ContextProfile(id="cp-1", attributes=[{"key": "APP_ID", "value": ["SSL"]}])
        assert cp.attributes[0]["key"] == "APP_ID"

    def test_intrusion_policy(self):
        p = IntrusionServicePolicy(id="ids-1", stateful=True, sequence_number=10)
        assert p.stateful is True


class TestProfileModels:
    def test_ip_discovery(self):
        p = IPDiscoveryProfile(id="ipd-1", arp_nd_binding_timeout=600)
        assert p.arp_nd_binding_timeout == 600

    def test_mac_discovery(self):
        p = MACDiscoveryProfile(id="mac-1", mac_learning_enabled=True, mac_limit=4096)
        assert p.mac_limit == 4096

    def test_spoofguard(self):
        p = SpoofGuardProfile(id="sg-1", address_binding_allowlist=True)
        assert p.address_binding_allowlist is True

    def test_segment_security(self):
        p = SegmentSecurityProfile(id="ssp-1", dhcp_server_block_enabled=True, ra_guard_enabled=True)
        assert p.ra_guard_enabled is True

    def test_qos(self):
        p = QoSProfile(id="qos-1", class_of_service=3)
        assert p.class_of_service == 3

    def test_flood_protection(self):
        p = FloodProtectionProfile(id="fp-1", tcp_half_open_conn_limit=1000, rst_spoofing_enabled=True)
        assert p.rst_spoofing_enabled is True
