"""Tests for all Pydantic models."""


from vcf_sdk.models import (
    Task, TaskStatus,
    Host, HostSpec,
    Domain, DomainSpec,
    Cluster, VDS, Validation,
    Credential, CredentialTask,
    CertificateAuthority, CSR,
    DNSConfiguration, NTPConfiguration, BackupConfiguration,
    DepotConfiguration, ProxyConfiguration, HealthSummary,
    LicenseKey, LicensingInfo,
    Bundle, Upgradable, Upgrade,
    User, Role,
    Federation, FederationMember,
    ComplianceConfiguration, ComplianceAudit,
    AriaLifecycle, AriaOperations, AriaOperationsLogs, AriaAutomation,
    NetworkPool, Personality,
)


# --- Task ---

class TestTask:
    def test_task_creation(self):
        task = Task(id="task-123", status="RUNNING", progress=50, description="Commissioning hosts")
        assert task.id == "task-123"
        assert task.status == TaskStatus.RUNNING
        assert task.progress == 50
        assert not task.is_terminal
        assert not task.is_successful

    def test_task_successful_state(self):
        task = Task(id="task-123", status="SUCCESSFUL")
        assert task.is_terminal
        assert task.is_successful
        assert not task.is_failed

    def test_task_failed_state(self):
        task = Task(id="task-123", status="FAILED", message="Host validation failed",
                    errors=[{"message": "Not enough capacity disks"}])
        assert task.is_terminal
        assert not task.is_successful
        assert task.is_failed

    def test_task_cancelled_state(self):
        task = Task(id="task-123", status="CANCELLED")
        assert task.is_terminal
        assert task.is_failed

    def test_task_pending_state(self):
        task = Task(id="task-123", status="PENDING")
        assert not task.is_terminal

    def test_task_with_subtasks(self):
        task = Task(id="task-1", status="RUNNING", subTasks=[
            {"id": "sub-1", "status": "SUCCESSFUL"},
        ])
        assert task.sub_tasks is not None
        assert len(task.sub_tasks) == 1

    def test_task_timestamps(self):
        task = Task(id="t-1", status="SUCCESSFUL",
                    creationTimeMillis=1000, startTimeMillis=2000, endTimeMillis=3000)
        assert task.creation_time_millis == 1000
        assert task.start_time_millis == 2000
        assert task.end_time_millis == 3000


# --- Host ---

class TestHostSpec:
    def test_host_spec_creation(self):
        spec = HostSpec(fqdn="esxi-05.lab.dev", username="root", password="password",
                        storageType="VSAN_ESA", networkPoolId="pool-123")
        assert spec.fqdn == "esxi-05.lab.dev"
        assert spec.storage_type == "VSAN_ESA"
        assert spec.network_pool_id == "pool-123"

    def test_host_spec_snake_case(self):
        spec = HostSpec(fqdn="esxi.lab", username="root", password="pw",
                        storage_type="VSAN", network_pool_id="p-1")
        assert spec.storage_type == "VSAN"


class TestHost:
    def test_host_creation(self):
        host = Host(id="host-123", fqdn="esxi-05.lab.dev", status="COMMISSIONED",
                    storageType="VSAN_ESA", ipv4Address="10.0.10.15")
        assert host.id == "host-123"
        assert host.storage_type == "VSAN_ESA"
        assert host.ipv4_address == "10.0.10.15"

    def test_host_with_cluster(self):
        host = Host(id="h-1", fqdn="esxi.lab", status="ASSIGNED",
                    clusterId="c-1", clusterName="cluster-01")
        assert host.cluster_id == "c-1"
        assert host.cluster_name == "cluster-01"


# --- Domain ---

class TestDomain:
    def test_domain_creation(self):
        domain = Domain(id="d-1", name="workload-01", status="ACTIVE",
                        clusterCount=2, hostCount=8)
        assert domain.name == "workload-01"
        assert domain.cluster_count == 2
        assert domain.host_count == 8

    def test_domain_with_nsx(self):
        domain = Domain(id="d-1", name="wld", status="ACTIVE",
                        nsxT={"id": "nsx-1", "fqdn": "nsx.lab"})
        assert domain.nsx_t["fqdn"] == "nsx.lab"


class TestDomainSpec:
    def test_domain_spec(self):
        spec = DomainSpec(domainName="wld-01",
                          vcenterSpec={"name": "vc01"},
                          computeSpec={"clusterSpecs": []},
                          nsxTSpec={"nsxManagerSpecs": []})
        assert spec.domain_name == "wld-01"


# --- Cluster ---

class TestCluster:
    def test_cluster_creation(self):
        cluster = Cluster(id="c-1", name="cluster-01", status="ACTIVE",
                          primaryDatastoreName="vsanDatastore",
                          primaryDatastoreType="VSAN",
                          isDefault=True, isStretched=False, hostCount=4,
                          domainId="d-1")
        assert cluster.name == "cluster-01"
        assert cluster.primary_datastore_name == "vsanDatastore"
        assert cluster.is_default is True
        assert cluster.host_count == 4
        assert cluster.domain_id == "d-1"


class TestVDS:
    def test_vds_creation(self):
        vds = VDS(id="vds-1", name="sfo-m01-cl01-vds01", mtu=9000, isUsed=True)
        assert vds.mtu == 9000
        assert vds.is_used is True


class TestValidation:
    def test_validation_success(self):
        v = Validation(id="v-1", executionStatus="COMPLETED", resultStatus="SUCCEEDED")
        assert v.is_complete
        assert v.is_successful

    def test_validation_failed(self):
        v = Validation(id="v-1", executionStatus="COMPLETED", resultStatus="FAILED",
                       validationChecks=[{"severity": "ERROR", "message": "Bad spec"}])
        assert v.is_complete
        assert not v.is_successful

    def test_validation_in_progress(self):
        v = Validation(id="v-1", executionStatus="IN_PROGRESS")
        assert not v.is_complete
        assert not v.is_successful


# --- Credential ---

class TestCredential:
    def test_credential_creation(self):
        cred = Credential(id="cred-1", resourceName="vc01.lab.dev",
                          resourceType="VCENTER", credentialType="SSH",
                          accountType="USER", username="root")
        assert cred.resource_name == "vc01.lab.dev"
        assert cred.resource_type == "VCENTER"
        assert cred.credential_type == "SSH"

    def test_credential_task(self):
        task = CredentialTask(id="ct-1", status="COMPLETED", credentialType="SSH")
        assert task.credential_type == "SSH"


# --- Certificate ---

class TestCertificate:
    def test_certificate_authority(self):
        ca = CertificateAuthority(id="ca-1", serverUrl="https://ca.lab.dev",
                                  username="admin", caType="Microsoft")
        assert ca.server_url == "https://ca.lab.dev"
        assert ca.ca_type == "Microsoft"

    def test_csr(self):
        csr = CSR(csrString="-----BEGIN CERTIFICATE REQUEST-----\n...",
                  resource={"fqdn": "vc01.lab.dev"})
        assert csr.csr_string.startswith("-----BEGIN")


# --- System ---

class TestSystemModels:
    def test_dns_config(self):
        dns = DNSConfiguration(dnsServers=[{"ipAddress": "10.0.0.1"}],
                               searchDomains=["lab.dev"])
        assert dns.dns_servers[0]["ipAddress"] == "10.0.0.1"
        assert dns.search_domains == ["lab.dev"]

    def test_ntp_config(self):
        ntp = NTPConfiguration(ntpServers=[{"ipAddress": "10.0.0.2"}])
        assert ntp.ntp_servers[0]["ipAddress"] == "10.0.0.2"

    def test_backup_config(self):
        backup = BackupConfiguration(server="backup.lab.dev", port=22,
                                     protocol="SFTP", username="admin",
                                     directory="/backups")
        assert backup.server == "backup.lab.dev"
        assert backup.port == 22

    def test_depot_config(self):
        depot = DepotConfiguration(vmwareAccount={"username": "user@vmware.com"})
        assert depot.vmware_account["username"] == "user@vmware.com"

    def test_proxy_config(self):
        proxy = ProxyConfiguration(host="proxy.lab.dev", port=8080, isEnabled=True)
        assert proxy.is_enabled is True

    def test_health_summary(self):
        health = HealthSummary(id="hs-1", status="COMPLETED", healthCheckCount=15)
        assert health.health_check_count == 15


# --- License ---

class TestLicense:
    def test_license_key(self):
        lic = LicenseKey(key="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX",
                         productType="VCENTER", licenseKeyStatus="ACTIVE")
        assert lic.product_type == "VCENTER"
        assert lic.license_key_status == "ACTIVE"

    def test_licensing_info(self):
        info = LicensingInfo(licensingMode="PERPETUAL")
        assert info.licensing_mode == "PERPETUAL"


# --- Bundle ---

class TestBundle:
    def test_bundle_creation(self):
        bundle = Bundle(id="b-1", bundleType="PATCH", version="9.0.2",
                        downloadStatus="AVAILABLE")
        assert bundle.bundle_type == "PATCH"
        assert bundle.download_status == "AVAILABLE"

    def test_upgradable(self):
        u = Upgradable(resourceId="r-1", resourceName="vc01",
                       resourceType="VCENTER", currentVersion="8.0",
                       targetVersion="9.0", status="UPGRADABLE")
        assert u.current_version == "8.0"
        assert u.target_version == "9.0"

    def test_upgrade(self):
        up = Upgrade(id="up-1", status="IN_PROGRESS")
        assert up.status == "IN_PROGRESS"


# --- User ---

class TestUser:
    def test_user_creation(self):
        user = User(id="u-1", name="admin@local", domain="local",
                    type="USER", creationTime="2024-01-01T00:00:00Z")
        assert user.name == "admin@local"
        assert user.creation_time == "2024-01-01T00:00:00Z"

    def test_role(self):
        role = Role(id="r-1", name="ADMIN", description="Administrator role")
        assert role.name == "ADMIN"


# --- Federation ---

class TestFederation:
    def test_federation(self):
        fed = Federation(controllerRole="CONTROLLER",
                         sddcManagers=[{"fqdn": "sddc.lab.dev"}])
        assert fed.controller_role == "CONTROLLER"
        assert len(fed.sddc_managers) == 1

    def test_federation_member(self):
        member = FederationMember(id="m-1", fqdn="sddc2.lab.dev",
                                  role="MEMBER", status="ACTIVE")
        assert member.fqdn == "sddc2.lab.dev"


# --- Compliance ---

class TestCompliance:
    def test_compliance_audit(self):
        audit = ComplianceAudit(id="a-1", status="COMPLETED",
                                auditResults=[{"result": "PASS"}])
        assert audit.audit_results[0]["result"] == "PASS"

    def test_compliance_config(self):
        config = ComplianceConfiguration(id="cc-1",
                                         configurations=[{"name": "stig"}])
        assert config.configurations[0]["name"] == "stig"


# --- Aria ---

class TestAria:
    def test_aria_lifecycle(self):
        aria = AriaLifecycle(id="al-1", fqdn="aria.lab.dev",
                             status="ACTIVE", version="8.16", apiUrl="https://aria.lab.dev/api")
        assert aria.api_url == "https://aria.lab.dev/api"

    def test_aria_operations(self):
        ops = AriaOperations(id="ao-1", fqdn="vrops.lab.dev", status="ACTIVE",
                             nodes=[{"fqdn": "node1.lab.dev"}])
        assert len(ops.nodes) == 1

    def test_aria_logs(self):
        logs = AriaOperationsLogs(id="al-1", fqdn="vrli.lab.dev", status="ACTIVE")
        assert logs.fqdn == "vrli.lab.dev"

    def test_aria_automation(self):
        auto = AriaAutomation(id="aa-1", fqdn="vra.lab.dev", status="ACTIVE")
        assert auto.fqdn == "vra.lab.dev"


# --- Network ---

class TestNetworkPool:
    def test_network_pool(self):
        pool = NetworkPool(id="np-1", name="mgmt-pool", hostsCount=4)
        assert pool.hosts_count == 4

    def test_personality(self):
        p = Personality(personalityId="p-1",
                        personalityName="Management-Domain-ESXi-Personality",
                        baseImageVersion="9.0.2-24000000")
        assert p.personality_name == "Management-Domain-ESXi-Personality"
        assert p.base_image_version.startswith("9.0.2")
