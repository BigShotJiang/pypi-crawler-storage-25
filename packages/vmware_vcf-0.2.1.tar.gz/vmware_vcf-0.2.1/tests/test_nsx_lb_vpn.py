"""Tests for NSX-T Load Balancing and VPN managers."""

from unittest.mock import MagicMock

from vcf_sdk.nsx.load_balancer import (
    LBServiceManager, LBVirtualServerManager, LBPoolManager,
    LBMonitorProfileManager, LBAppProfileManager,
    LBPersistenceProfileManager, LBSSLProfileManager,
)
from vcf_sdk.nsx.vpn import IPSecVPNManager, L2VPNManager
from vcf_sdk.models.nsx import (
    LBService, LBVirtualServer, LBPool, LBMonitorProfile,
    LBPersistenceProfile, LBSSLProfile,
    IPSecVPNService, IPSecVPNSession, IPSecVPNIKEProfile,
    IPSecVPNTunnelProfile, IPSecVPNDPDProfile,
    L2VPNService, L2VPNSession,
)


def _mc():
    c = MagicMock()
    c.get.return_value = {"results": []}
    c.patch.return_value = {}
    c.delete.return_value = {}
    return c


# --- Load Balancing ---

class TestLBServiceManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "lb-svc-1", "enabled": True, "size": "SMALL"}]}
        services = LBServiceManager(c).list()
        assert services[0].size == "SMALL"

    def test_create(self):
        c = _mc()
        LBServiceManager(c).create_or_update("lb-svc-1", {
            "connectivity_path": "/infra/tier-1s/t1-gw", "size": "SMALL",
        })
        assert "lb-services/lb-svc-1" in c.patch.call_args[0][0]


class TestLBVirtualServerManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "vs-1", "ip_address": "10.0.0.100", "ports": ["443"]},
        ]}
        servers = LBVirtualServerManager(c).list()
        assert servers[0].ip_address == "10.0.0.100"

    def test_create(self):
        c = _mc()
        LBVirtualServerManager(c).create_or_update("vs-1", {
            "ip_address": "10.0.0.100", "ports": ["443"],
            "pool_path": "/infra/lb-pools/pool-1",
        })
        assert "lb-virtual-servers/vs-1" in c.patch.call_args[0][0]


class TestLBPoolManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "pool-1", "algorithm": "ROUND_ROBIN",
             "members": [{"ip_address": "10.0.1.10", "port": "8080"}]},
        ]}
        pools = LBPoolManager(c).list()
        assert pools[0].algorithm == "ROUND_ROBIN"
        assert len(pools[0].members) == 1

    def test_create(self):
        c = _mc()
        LBPoolManager(c).create_or_update("pool-1", {
            "algorithm": "LEAST_CONNECTION",
            "members": [{"ip_address": "10.0.1.10", "port": "8080"}],
        })
        assert "lb-pools/pool-1" in c.patch.call_args[0][0]


class TestLBMonitorProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "mon-http", "resource_type": "LBHttpMonitorProfile",
             "request_url": "/health", "response_status_codes": [200]},
        ]}
        monitors = LBMonitorProfileManager(c).list()
        assert monitors[0].request_url == "/health"

    def test_create_http_monitor(self):
        c = _mc()
        LBMonitorProfileManager(c).create_or_update("mon-http", {
            "resource_type": "LBHttpMonitorProfile",
            "request_url": "/health", "interval": 5, "timeout": 15,
        })
        assert "lb-monitor-profiles/mon-http" in c.patch.call_args[0][0]


class TestLBAppProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "app-http", "idle_timeout": 60}]}
        profiles = LBAppProfileManager(c).list()
        assert profiles[0].idle_timeout == 60


class TestLBPersistenceProfileManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "persist-cookie", "cookie_name": "SERVERID", "cookie_mode": "INSERT"},
        ]}
        profiles = LBPersistenceProfileManager(c).list()
        assert profiles[0].cookie_name == "SERVERID"


class TestLBSSLProfileManager:
    def test_list_client(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ssl-client", "protocols": ["TLS_V1_2"]}]}
        profiles = LBSSLProfileManager(c).list_client()
        assert profiles[0].protocols == ["TLS_V1_2"]

    def test_list_server(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ssl-server"}]}
        LBSSLProfileManager(c).list_server()
        assert "lb-server-ssl-profiles" in c.get.call_args[0][0]


# --- IPSec VPN ---

class TestIPSecVPNManager:
    def test_list_services(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "vpn-svc-1", "enabled": True}]}
        services = IPSecVPNManager(c).list_services("tier-0s", "t0-gw")
        assert services[0].enabled is True
        assert "tier-0s/t0-gw/ipsec-vpn-services" in c.get.call_args[0][0]

    def test_create_service(self):
        c = _mc()
        IPSecVPNManager(c).create_or_update_service("tier-0s", "t0-gw", "vpn-svc", {"enabled": True})
        assert "ipsec-vpn-services/vpn-svc" in c.patch.call_args[0][0]

    def test_list_sessions(self):
        c = _mc()
        c.get.return_value = {"results": [
            {"id": "session-1", "peer_address": "203.0.113.1", "authentication_mode": "PSK"},
        ]}
        sessions = IPSecVPNManager(c).list_sessions("tier-0s", "t0-gw", "vpn-svc")
        assert sessions[0].peer_address == "203.0.113.1"

    def test_create_session(self):
        c = _mc()
        IPSecVPNManager(c).create_or_update_session("tier-0s", "t0-gw", "vpn-svc", "sess-1", {
            "resource_type": "RouteBasedIPSecVpnSession",
            "peer_address": "203.0.113.1", "authentication_mode": "PSK", "psk": "secret",
        })
        assert "sessions/sess-1" in c.patch.call_args[0][0]

    def test_list_local_endpoints(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ep-1", "local_address": "10.0.0.1"}]}
        eps = IPSecVPNManager(c).list_local_endpoints("tier-0s", "t0-gw", "vpn-svc")
        assert eps[0].local_address == "10.0.0.1"

    def test_ike_profiles(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "ike-1", "ike_version": "IKE_V2"}]}
        profiles = IPSecVPNManager(c).list_ike_profiles()
        assert profiles[0].ike_version == "IKE_V2"

    def test_tunnel_profiles(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "tun-1"}]}
        IPSecVPNManager(c).list_tunnel_profiles()
        assert "ipsec-vpn-tunnel-profiles" in c.get.call_args[0][0]

    def test_dpd_profiles(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "dpd-1", "dpd_probe_mode": "PERIODIC"}]}
        profiles = IPSecVPNManager(c).list_dpd_profiles()
        assert profiles[0].dpd_probe_mode == "PERIODIC"


# --- L2 VPN ---

class TestL2VPNManager:
    def test_list_services(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "l2vpn-svc", "mode": "SERVER"}]}
        services = L2VPNManager(c).list_services("tier-0s", "t0-gw")
        assert services[0].mode == "SERVER"

    def test_create_session(self):
        c = _mc()
        L2VPNManager(c).create_or_update_session("tier-0s", "t0-gw", "l2vpn-svc", "sess-1", {
            "transport_tunnels": ["/infra/tier-0s/t0-gw/ipsec-vpn-services/vpn/sessions/ipsec-sess"],
        })
        assert "l2vpn-services/l2vpn-svc/sessions/sess-1" in c.patch.call_args[0][0]


# --- Models ---

class TestLBModels:
    def test_lb_service(self):
        svc = LBService(id="lb-1", enabled=True, size="SMALL")
        assert svc.size == "SMALL"

    def test_lb_virtual_server(self):
        vs = LBVirtualServer(id="vs-1", ip_address="10.0.0.100", ports=["443", "80"])
        assert len(vs.ports) == 2

    def test_lb_pool(self):
        pool = LBPool(id="pool-1", algorithm="ROUND_ROBIN",
                       members=[{"ip_address": "10.0.1.10", "port": "8080"}])
        assert pool.algorithm == "ROUND_ROBIN"

    def test_lb_monitor(self):
        mon = LBMonitorProfile(id="mon-1", resource_type="LBHttpMonitorProfile",
                                request_url="/health", interval=5)
        assert mon.request_url == "/health"

    def test_lb_persistence(self):
        p = LBPersistenceProfile(id="p-1", cookie_name="SRV", cookie_mode="INSERT")
        assert p.cookie_name == "SRV"

    def test_lb_ssl(self):
        ssl = LBSSLProfile(id="ssl-1", protocols=["TLS_V1_2", "TLS_V1_3"])
        assert len(ssl.protocols) == 2


class TestVPNModels:
    def test_ipsec_service(self):
        svc = IPSecVPNService(id="vpn-1", enabled=True, ike_log_level="INFO")
        assert svc.ike_log_level == "INFO"

    def test_ipsec_session(self):
        sess = IPSecVPNSession(
            id="sess-1", peer_address="203.0.113.1",
            authentication_mode="PSK", psk="secret123",
        )
        assert sess.peer_address == "203.0.113.1"

    def test_ike_profile(self):
        ike = IPSecVPNIKEProfile(id="ike-1", ike_version="IKE_V2",
                                  encryption_algorithms=["AES_256"])
        assert ike.encryption_algorithms == ["AES_256"]

    def test_tunnel_profile(self):
        tun = IPSecVPNTunnelProfile(id="tun-1", enable_perfect_forward_secrecy=True)
        assert tun.enable_perfect_forward_secrecy is True

    def test_dpd_profile(self):
        dpd = IPSecVPNDPDProfile(id="dpd-1", dpd_probe_mode="PERIODIC", dpd_probe_interval=60)
        assert dpd.dpd_probe_interval == 60

    def test_l2vpn_service(self):
        svc = L2VPNService(id="l2-1", mode="SERVER", enabled=True)
        assert svc.mode == "SERVER"

    def test_l2vpn_session(self):
        sess = L2VPNSession(id="l2sess-1", transport_tunnels=["/path/to/tunnel"])
        assert len(sess.transport_tunnels) == 1
