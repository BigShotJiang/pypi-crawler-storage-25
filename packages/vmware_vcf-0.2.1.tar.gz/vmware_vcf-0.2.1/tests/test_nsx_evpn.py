"""Tests for NSX-T EVPN managers."""

from unittest.mock import MagicMock

from vcf_sdk.nsx.evpn import EVPNManager
from vcf_sdk.models.nsx import EVPNConfig, EVPNTenant, EVPNTunnelEndpoint


def _mc():
    c = MagicMock()
    c.get.return_value = {"results": []}
    c.patch.return_value = {}
    c.delete.return_value = {}
    return c


class TestEVPNManager:
    def test_get_config(self):
        c = _mc()
        c.get.return_value = {"mode": "INLINE", "encapsulation": "VXLAN"}
        config = EVPNManager(c).get_config("t0-gw", "default")
        assert config.mode == "INLINE"

    def test_set_config(self):
        c = _mc()
        EVPNManager(c).set_config("t0-gw", "default", {"mode": "INLINE"})
        assert "evpn" in c.patch.call_args[0][0]

    def test_list_tenants(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "tenant-1", "transport_vni": 75000}]}
        tenants = EVPNManager(c).list_tenants()
        assert tenants[0].transport_vni == 75000

    def test_create_tenant(self):
        c = _mc()
        EVPNManager(c).create_or_update_tenant("tenant-1", {"transport_vni": 75000})
        assert "evpn-tenant-configs/tenant-1" in c.patch.call_args[0][0]

    def test_list_tunnel_endpoints(self):
        c = _mc()
        c.get.return_value = {"results": [{"id": "tep-1"}]}
        teps = EVPNManager(c).list_tunnel_endpoints("t0-gw", "default")
        assert len(teps) == 1

    def test_create_tunnel_endpoint(self):
        c = _mc()
        EVPNManager(c).create_or_update_tunnel_endpoint("t0-gw", "default", "tep-1", {
            "external_interface_path": "/infra/tier-0s/t0-gw/locale-services/default/interfaces/uplink-1",
        })
        assert "tunnel-endpoints/tep-1" in c.patch.call_args[0][0]


class TestEVPNModels:
    def test_evpn_config(self):
        cfg = EVPNConfig(mode="INLINE", encapsulation="VXLAN")
        assert cfg.mode == "INLINE"

    def test_evpn_tenant(self):
        t = EVPNTenant(id="t-1", transport_vni=75000)
        assert t.transport_vni == 75000

    def test_evpn_tunnel_endpoint(self):
        tep = EVPNTunnelEndpoint(id="tep-1", external_interface_path="/path/to/interface")
        assert tep.external_interface_path.endswith("interface")
