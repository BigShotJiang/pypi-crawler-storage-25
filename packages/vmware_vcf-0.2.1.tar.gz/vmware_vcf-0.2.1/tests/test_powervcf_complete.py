"""Tests for PowerVCF-complete functionality: identity providers, AVNs, Cloud Builder, enhancements."""

from unittest.mock import MagicMock, patch

from vcf_sdk.managers.identity_providers import IdentityProviderManager
from vcf_sdk.managers.avns import AVNManager
from vcf_sdk.managers.certificates import CertificateManager
from vcf_sdk.managers.users import UserManager
from vcf_sdk.managers.bundles import BundleManager
from vcf_sdk.managers.hosts import HostManager
from vcf_sdk.cloud_builder import CloudBuilder


def _mock_sddc():
    client = MagicMock()
    auth = MagicMock()
    auth.get_auth_headers.return_value = {"Authorization": "Bearer test"}
    return client, auth


# --- Identity Providers ---

class TestIdentityProviderManager:
    def test_list(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"elements": [
            {"id": "idp-1", "type": "Embedded"},
        ]}
        mgr = IdentityProviderManager(client, auth)
        providers = mgr.list()
        assert len(providers) == 1
        assert providers[0]["type"] == "Embedded"

    def test_get(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"id": "idp-1", "type": "Embedded"}
        mgr = IdentityProviderManager(client, auth)
        provider = mgr.get("idp-1")
        assert provider["id"] == "idp-1"

    def test_create_external_idp(self):
        client, auth = _mock_sddc()
        client.post.return_value = {"id": "idp-2"}
        mgr = IdentityProviderManager(client, auth)
        result = mgr.create({"type": "Microsoft ADFS", "name": "corp-adfs"})
        client.post.assert_called_once()
        assert result["id"] == "idp-2"

    def test_update_external_idp(self):
        client, auth = _mock_sddc()
        client.request.return_value = {}
        mgr = IdentityProviderManager(client, auth)
        mgr.update("idp-2", {"name": "updated-adfs"})
        client.request.assert_called_once()

    def test_delete_external_idp(self):
        client, auth = _mock_sddc()
        client.delete.return_value = {}
        mgr = IdentityProviderManager(client, auth)
        mgr.delete("idp-2")
        call_url = client.delete.call_args[0][0]
        assert "identity-providers/idp-2" in call_url

    def test_add_identity_source(self):
        client, auth = _mock_sddc()
        client.post.return_value = {"domainName": "corp.lab.dev"}
        mgr = IdentityProviderManager(client, auth)
        mgr.add_identity_source("idp-1", {
            "domainName": "corp.lab.dev",
            "domainAlias": "CORP",
            "ldapDetails": {"hostname": "dc01.corp.lab.dev"},
        })
        call_url = client.post.call_args[0][0]
        assert "identity-providers/idp-1/identity-sources" in call_url

    def test_update_identity_source(self):
        client, auth = _mock_sddc()
        client.request.return_value = {}
        mgr = IdentityProviderManager(client, auth)
        mgr.update_identity_source("idp-1", "corp.lab.dev", {"ldapDetails": {}})
        call_url = client.request.call_args[0][1]
        assert "identity-sources/corp.lab.dev" in call_url

    def test_remove_identity_source(self):
        client, auth = _mock_sddc()
        client.delete.return_value = {}
        mgr = IdentityProviderManager(client, auth)
        mgr.remove_identity_source("idp-1", "corp.lab.dev")
        call_url = client.delete.call_args[0][0]
        assert "identity-sources/corp.lab.dev" in call_url


# --- AVNs ---

class TestAVNManager:
    def test_list(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"elements": [
            {"id": "avn-1", "name": "sfo-m01-seg01"},
        ]}
        mgr = AVNManager(client, auth)
        avns = mgr.list()
        assert len(avns) == 1

    def test_list_with_region_filter(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"elements": []}
        mgr = AVNManager(client, auth)
        mgr.list(region_type="REGION_A")
        call_url = client.get.call_args[0][0]
        assert "regionType=REGION_A" in call_url

    def test_create_with_validation(self):
        client, auth = _mock_sddc()
        # Validation POST → poll → success, then create
        client.post.side_effect = [
            {"id": "val-1"},  # POST /v1/avns/validations
            {"id": "avn-new"},  # POST /v1/avns
        ]
        client.get.side_effect = [
            {"id": "val-1", "executionStatus": "COMPLETED", "resultStatus": "SUCCEEDED"},
        ]
        mgr = AVNManager(client, auth)
        result = mgr.create({"avnSpecs": []}, validate=True)
        assert result["id"] == "avn-new"


# --- Certificate CA Helpers ---

class TestCertificateCAHelpers:
    def test_set_microsoft_ca(self):
        client, auth = _mock_sddc()
        client.put.return_value = {}
        mgr = CertificateManager(client, auth)
        mgr.set_microsoft_ca(
            server_url="https://ca.lab.dev/certsrv",
            username="admin", password="pass", template_name="VMware",
        )
        data = client.put.call_args[1]["data"]
        assert "microsoftCertificateAuthoritySpec" in data
        assert data["microsoftCertificateAuthoritySpec"]["templateName"] == "VMware"

    def test_set_openssl_ca(self):
        client, auth = _mock_sddc()
        client.put.return_value = {}
        mgr = CertificateManager(client, auth)
        mgr.set_openssl_ca(
            common_name="sddc.lab.dev", organization="Lab",
            organization_unit="IT", locality="London",
            state="London", country="GB",
        )
        data = client.put.call_args[1]["data"]
        assert "openSSLCertificateAuthoritySpec" in data
        assert data["openSSLCertificateAuthoritySpec"]["country"] == "GB"


# --- User Group Creation ---

class TestUserGroupCreation:
    def test_create_group(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"elements": [
            {"id": "role-1", "name": "ADMIN", "description": "Administrator"},
        ]}
        client.post.return_value = {"elements": [{"name": "vcf-admins", "type": "GROUP"}]}
        mgr = UserManager(client, auth)
        mgr.create_group("vcf-admins", "corp.lab.dev", "ADMIN")
        data = client.post.call_args[1]["data"]
        assert data[0]["type"] == "GROUP"
        assert data[0]["domain"] == "CORP.LAB.DEV"
        assert data[0]["role"]["id"] == "role-1"


# --- Bundle Upload ---

class TestBundleUpload:
    def test_upload(self):
        client, auth = _mock_sddc()
        client.post.return_value = {"id": "bundle-upload-1"}
        mgr = BundleManager(client, auth)
        result = mgr.upload({"bundleFilePath": "/tmp/bundle.tar"})
        assert result["id"] == "bundle-upload-1"


# --- Host FQDN Filter ---

class TestHostFQDNFilter:
    def test_list_with_fqdn(self):
        client, auth = _mock_sddc()
        client.get.return_value = {"elements": [
            {"id": "h-1", "fqdn": "esxi-01.lab.dev", "status": "COMMISSIONED"},
            {"id": "h-2", "fqdn": "esxi-02.lab.dev", "status": "COMMISSIONED"},
        ]}
        mgr = HostManager(client, auth)
        hosts = mgr.list(fqdn="esxi-01.lab.dev")
        assert len(hosts) == 1
        assert hosts[0].fqdn == "esxi-01.lab.dev"


# --- Cloud Builder ---

class TestCloudBuilder:
    def test_list_sddcs(self):
        with patch.object(CloudBuilder, '__init__', lambda self, *a, **kw: None):
            cb = CloudBuilder.__new__(CloudBuilder)
            cb.client = MagicMock()
            cb._auth = ("admin", "pass")
            cb.client.request.return_value = {"elements": [
                {"id": "sddc-1", "status": "COMPLETED"},
            ]}
            sddcs = cb.list_sddcs()
            assert len(sddcs) == 1

    def test_start_bringup(self):
        with patch.object(CloudBuilder, '__init__', lambda self, *a, **kw: None):
            cb = CloudBuilder.__new__(CloudBuilder)
            cb.client = MagicMock()
            cb._auth = ("admin", "pass")
            cb.hostname = "cb.lab.dev"
            cb.client.request.return_value = {"id": "bringup-1"}
            result = cb.start_bringup({"sddcId": "sddc-spec"})
            assert result["id"] == "bringup-1"

    def test_start_validation(self):
        with patch.object(CloudBuilder, '__init__', lambda self, *a, **kw: None):
            cb = CloudBuilder.__new__(CloudBuilder)
            cb.client = MagicMock()
            cb._auth = ("admin", "pass")
            cb.client.request.return_value = {"id": "val-1"}
            cb.start_validation({"spec": "data"}, validation_type="JSON_SPEC_VALIDATION")
            call_url = cb.client.request.call_args[0][1]
            assert "name=JSON_SPEC_VALIDATION" in call_url

    def test_retry_bringup(self):
        with patch.object(CloudBuilder, '__init__', lambda self, *a, **kw: None):
            cb = CloudBuilder.__new__(CloudBuilder)
            cb.client = MagicMock()
            cb._auth = ("admin", "pass")
            cb.client.request.return_value = {"id": "sddc-1"}
            cb.retry_bringup("sddc-1")
            call_method = cb.client.request.call_args[0][0]
            assert call_method == "PATCH"

    def test_stop_validation(self):
        with patch.object(CloudBuilder, '__init__', lambda self, *a, **kw: None):
            cb = CloudBuilder.__new__(CloudBuilder)
            cb.client = MagicMock()
            cb._auth = ("admin", "pass")
            cb.client.request.return_value = {}
            cb.stop_validation("val-1")
            call_method = cb.client.request.call_args[0][0]
            assert call_method == "DELETE"


# --- SDDCManager has new managers ---

class TestSDDCManagerNewManagers:
    def test_identity_providers_present(self):
        from unittest.mock import patch as mock_patch
        from vcf_sdk.sddc_manager import SDDCManager

        with mock_patch.object(SDDCManager, '__init__', lambda self, *a, **kw: None):
            sddc = SDDCManager.__new__(SDDCManager)
            sddc.client = MagicMock()
            sddc.auth = MagicMock()
            sddc.identity_providers = IdentityProviderManager(sddc.client, sddc.auth)
            sddc.avns = AVNManager(sddc.client, sddc.auth)
            assert isinstance(sddc.identity_providers, IdentityProviderManager)
            assert isinstance(sddc.avns, AVNManager)
