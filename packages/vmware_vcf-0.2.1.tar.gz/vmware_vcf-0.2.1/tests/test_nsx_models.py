"""Tests for NSX-T Policy API models."""

from vcf_sdk.models.nsx import (
    Segment, SegmentSubnet,
    Tier0Gateway, Tier1Gateway, LocaleService, GatewayInterface,
    StaticRoute, BGPConfig, BGPNeighbor,
    Group, SecurityPolicy, FirewallRule, GatewayPolicy,
    Service, ServiceEntry,
    NATRule,
    DHCPServerConfig, DHCPRelayConfig, DNSForwarderZone,
    IPPool, IPPoolSubnet, IPAllocation,
    TransportZone, EdgeCluster, EdgeNode,
)


class TestSegment:
    def test_overlay_segment(self):
        seg = Segment(
            id="web-seg", display_name="Web Segment",
            transport_zone_path="/infra/sites/default/enforcement-points/default/transport-zones/tz-1",
            connectivity_path="/infra/tier-1s/t1-gw",
            subnets=[SegmentSubnet(gateway_address="192.168.1.1/24")],
            admin_state="UP",
        )
        assert seg.id == "web-seg"
        assert not seg.is_vlan
        assert seg.subnets[0].gateway_address == "192.168.1.1/24"

    def test_vlan_segment(self):
        seg = Segment(id="vlan-seg", vlan_ids=["100", "200"])
        assert seg.is_vlan

    def test_nsx_resource_common_fields(self):
        seg = Segment(
            id="s1", display_name="Test", description="desc",
            resource_type="Segment", path="/infra/segments/s1",
            tags=[{"scope": "env", "tag": "prod"}],
            _revision=3,
        )
        assert seg.revision == 3
        assert seg.tags[0]["scope"] == "env"


class TestGateways:
    def test_tier0(self):
        gw = Tier0Gateway(
            id="t0-gw", display_name="Tier-0",
            ha_mode="ACTIVE_STANDBY", failover_mode="NON_PREEMPTIVE",
            transit_subnets=["100.64.0.0/16"],
        )
        assert gw.ha_mode == "ACTIVE_STANDBY"

    def test_tier1(self):
        gw = Tier1Gateway(
            id="t1-gw", tier0_path="/infra/tier-0s/t0-gw",
            route_advertisement_types=["TIER1_CONNECTED", "TIER1_NAT"],
        )
        assert gw.tier0_path == "/infra/tier-0s/t0-gw"
        assert len(gw.route_advertisement_types) == 2

    def test_locale_service(self):
        ls = LocaleService(
            id="default",
            edge_cluster_path="/infra/sites/default/enforcement-points/default/edge-clusters/ec-1",
        )
        assert ls.edge_cluster_path.endswith("ec-1")

    def test_interface(self):
        iface = GatewayInterface(
            id="uplink-1", type="EXTERNAL",
            segment_path="/infra/segments/uplink-seg",
            subnets=[{"ip_addresses": ["10.0.0.1"], "prefix_len": 24}],
        )
        assert iface.type == "EXTERNAL"

    def test_static_route(self):
        route = StaticRoute(
            id="default-route", network="0.0.0.0/0",
            next_hops=[{"ip_address": "10.0.0.254", "admin_distance": 1}],
        )
        assert route.network == "0.0.0.0/0"

    def test_bgp_config(self):
        bgp = BGPConfig(local_as_num="65001", enabled=True, ecmp=True)
        assert bgp.local_as_num == "65001"

    def test_bgp_neighbor(self):
        nbr = BGPNeighbor(
            id="nbr-1", neighbor_address="10.0.0.254",
            remote_as_num="65002", hold_down_time=180,
        )
        assert nbr.remote_as_num == "65002"


class TestSecurity:
    def test_group_with_tag_expression(self):
        grp = Group(
            id="web-servers", display_name="Web Servers",
            expression=[
                {"resource_type": "Condition", "member_type": "VirtualMachine",
                 "key": "Tag", "operator": "EQUALS", "value": "web|tier"},
            ],
        )
        assert grp.expression[0]["key"] == "Tag"

    def test_security_policy_with_rules(self):
        policy = SecurityPolicy(
            id="app-policy", category="Application",
            stateful=True, sequence_number=10,
            rules=[
                FirewallRule(id="r-1", action="ALLOW", direction="IN_OUT",
                             source_groups=["ANY"], destination_groups=["ANY"],
                             services=["/infra/services/HTTPS"]),
            ],
        )
        assert policy.category == "Application"
        assert policy.rules[0].action == "ALLOW"

    def test_firewall_rule(self):
        rule = FirewallRule(
            id="block-all", action="DROP", direction="IN",
            logged=True, disabled=False,
            ip_protocol="IPV4_IPV6", sequence_number=999,
        )
        assert rule.action == "DROP"
        assert rule.logged is True

    def test_gateway_policy(self):
        gp = GatewayPolicy(id="gw-pol", category="LocalGatewayRules")
        assert gp.category == "LocalGatewayRules"

    def test_service(self):
        svc = Service(
            id="my-app", display_name="My App Ports",
            service_entries=[
                ServiceEntry(id="tcp-8080", l4_protocol="TCP",
                             destination_ports=["8080"]),
            ],
        )
        assert svc.service_entries[0].l4_protocol == "TCP"


class TestNAT:
    def test_snat_rule(self):
        rule = NATRule(
            id="snat-1", action="SNAT",
            source_network="192.168.1.0/24",
            translated_network="10.0.0.100",
            enabled=True, sequence_number=100,
        )
        assert rule.action == "SNAT"
        assert rule.translated_network == "10.0.0.100"

    def test_dnat_rule(self):
        rule = NATRule(id="dnat-1", action="DNAT",
                       destination_network="10.0.0.100",
                       translated_network="192.168.1.10",
                       translated_ports="443")
        assert rule.action == "DNAT"


class TestNetworkServices:
    def test_dhcp_server(self):
        dhcp = DHCPServerConfig(
            id="dhcp-1", server_address="100.96.0.1/30",
            lease_time=86400,
        )
        assert dhcp.lease_time == 86400

    def test_dhcp_relay(self):
        relay = DHCPRelayConfig(id="relay-1", server_addresses=["10.0.0.53"])
        assert relay.server_addresses[0] == "10.0.0.53"

    def test_dns_zone(self):
        zone = DNSForwarderZone(
            id="corp-dns", dns_domain_names=["corp.lab.dev"],
            upstream_servers=["10.0.0.53", "10.0.0.54"],
        )
        assert len(zone.upstream_servers) == 2


class TestIPPool:
    def test_ip_pool(self):
        pool = IPPool(id="tep-pool", display_name="TEP Pool")
        assert pool.id == "tep-pool"

    def test_ip_pool_subnet(self):
        subnet = IPPoolSubnet(
            id="subnet-1", cidr="192.168.250.0/24",
            gateway_ip="192.168.250.1",
            allocation_ranges=[{"start": "192.168.250.10", "end": "192.168.250.200"}],
        )
        assert subnet.gateway_ip == "192.168.250.1"

    def test_ip_allocation(self):
        alloc = IPAllocation(id="alloc-1", allocation_ip="192.168.250.15")
        assert alloc.allocation_ip == "192.168.250.15"


class TestFabric:
    def test_transport_zone_overlay(self):
        tz = TransportZone(id="tz-1", tz_type="OVERLAY_STANDARD", is_default=True)
        assert tz.is_overlay
        assert not tz.is_vlan

    def test_transport_zone_vlan(self):
        tz = TransportZone(id="tz-2", tz_type="VLAN_BACKED")
        assert tz.is_vlan
        assert not tz.is_overlay

    def test_edge_cluster(self):
        ec = EdgeCluster(id="ec-1", display_name="Edge Cluster",
                         member_node_type="EDGE_NODE", deployment_type="VIRTUAL_MACHINE")
        assert ec.deployment_type == "VIRTUAL_MACHINE"

    def test_edge_node(self):
        node = EdgeNode(id="en-1", display_name="Edge Node 1", nsx_id="uuid-123")
        assert node.nsx_id == "uuid-123"
