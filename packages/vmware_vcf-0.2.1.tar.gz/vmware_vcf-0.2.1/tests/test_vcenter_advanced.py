"""Tests for vCenter advanced operations — VM hardware, snapshots, DRS, folders."""

from unittest.mock import MagicMock

from vcf_sdk.vcenter.vm_hardware import VMHardwareManager
from vcf_sdk.vcenter.snapshots import SnapshotManager
from vcf_sdk.vcenter.advanced import DRSRuleManager, FolderManager, GuestCustomizationManager
from vcf_sdk.models.vcenter import Snapshot, DRSRule, Folder


def _mc():
    c = MagicMock()
    c.get.return_value = []
    c.post.return_value = None
    c.patch.return_value = None
    c.delete.return_value = None
    return c


# --- VM Hardware ---

class TestVMHardwareManager:
    def test_list_disks(self):
        c = _mc()
        c.get.return_value = [{"disk": "2000", "label": "Hard disk 1"}]
        disks = VMHardwareManager(c).list_disks("vm-42")
        assert len(disks) == 1
        assert disks[0]["label"] == "Hard disk 1"

    def test_create_disk(self):
        c = _mc()
        c.post.return_value = "2001"
        disk_id = VMHardwareManager(c).create_disk("vm-42", {"new_vmdk": {"capacity": 42949672960}})
        assert disk_id == "2001"

    def test_list_nics(self):
        c = _mc()
        c.get.return_value = [{"nic": "4000", "label": "Network adapter 1"}]
        nics = VMHardwareManager(c).list_nics("vm-42")
        assert len(nics) == 1

    def test_create_nic(self):
        c = _mc()
        c.post.return_value = "4001"
        VMHardwareManager(c).create_nic("vm-42", {"backing": {"type": "DISTRIBUTED_PORTGROUP"}})

    def test_connect_nic(self):
        c = _mc()
        VMHardwareManager(c).connect_nic("vm-42", "4000")
        assert "action=connect" in c.post.call_args[0][0]

    def test_list_cdroms(self):
        c = _mc()
        c.get.return_value = [{"cdrom": "3000"}]
        cdroms = VMHardwareManager(c).list_cdroms("vm-42")
        assert len(cdroms) == 1

    def test_get_cpu(self):
        c = _mc()
        c.get.return_value = {"count": 4, "cores_per_socket": 2}
        cpu = VMHardwareManager(c).get_cpu("vm-42")
        assert cpu["count"] == 4

    def test_update_memory(self):
        c = _mc()
        VMHardwareManager(c).update_memory("vm-42", {"size_MiB": 16384})
        assert "memory" in c.patch.call_args[0][0]

    def test_get_boot(self):
        c = _mc()
        c.get.return_value = {"type": "BIOS"}
        boot = VMHardwareManager(c).get_boot("vm-42")
        assert boot["type"] == "BIOS"


# --- Snapshots ---

class TestSnapshotManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = [{"snapshot": "snap-1", "name": "before-upgrade"}]
        snapshots = SnapshotManager(c).list("vm-42")
        assert snapshots[0].name == "before-upgrade"

    def test_create(self):
        c = _mc()
        c.post.return_value = "snap-new"
        snap_id = SnapshotManager(c).create("vm-42", {
            "name": "pre-patch", "description": "Before patching", "memory": False,
        })
        assert snap_id == "snap-new"

    def test_delete(self):
        c = _mc()
        SnapshotManager(c).delete("vm-42", "snap-1")
        assert "snap-1" in c.delete.call_args[0][0]

    def test_revert(self):
        c = _mc()
        SnapshotManager(c).revert("vm-42", "snap-1")
        assert "action=revert" in c.post.call_args[0][0]


# --- DRS Rules ---

class TestDRSRuleManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = {"drs_rules": [
            {"rule": "rule-1", "name": "keep-together", "type": "AFFINITY", "enabled": True},
        ]}
        rules = DRSRuleManager(c).list("domain-c8")
        assert rules[0].name == "keep-together"
        assert rules[0].type == "AFFINITY"

    def test_list_empty(self):
        c = _mc()
        c.get.return_value = {"name": "Cluster-01"}
        rules = DRSRuleManager(c).list("domain-c8")
        assert rules == []


# --- Folders ---

class TestFolderManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = [
            {"folder": "group-v3", "name": "vm", "type": "VIRTUAL_MACHINE"},
        ]
        folders = FolderManager(c).list()
        assert folders[0].type == "VIRTUAL_MACHINE"

    def test_list_with_filter(self):
        c = _mc()
        c.get.return_value = []
        FolderManager(c).list(type="VIRTUAL_MACHINE")
        assert "filter.type=VIRTUAL_MACHINE" in c.get.call_args[0][0]

    def test_create(self):
        c = _mc()
        c.post.return_value = "group-v100"
        folder_id = FolderManager(c).create({"name": "new-folder", "type": "VIRTUAL_MACHINE"})
        assert folder_id == "group-v100"

    def test_delete(self):
        c = _mc()
        FolderManager(c).delete("group-v3")
        c.delete.assert_called_with("/vcenter/folder/group-v3")


# --- Guest Customization ---

class TestGuestCustomizationManager:
    def test_list(self):
        c = _mc()
        c.get.return_value = [{"name": "linux-spec"}]
        specs = GuestCustomizationManager(c).list()
        assert len(specs) == 1

    def test_create(self):
        c = _mc()
        c.post.return_value = "linux-spec-2"
        GuestCustomizationManager(c).create({"name": "linux-spec-2"})


# --- Models ---

class TestAdvancedModels:
    def test_snapshot(self):
        s = Snapshot(snapshot="snap-1", name="before-upgrade", description="Safe point")
        assert s.name == "before-upgrade"

    def test_drs_rule(self):
        r = DRSRule(rule="rule-1", name="keep-together", type="AFFINITY",
                    enabled=True, vms=["vm-1", "vm-2"])
        assert len(r.vms) == 2

    def test_folder(self):
        f = Folder(folder="group-v3", name="vm", type="VIRTUAL_MACHINE")
        assert f.type == "VIRTUAL_MACHINE"
