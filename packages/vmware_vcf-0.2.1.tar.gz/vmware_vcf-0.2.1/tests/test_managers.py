"""Tests for manager base patterns and SDDCManager composition."""

from unittest.mock import MagicMock, patch

from vcf_sdk.managers.base import BaseManager



class TestBaseManager:
    def _make_manager(self):
        client = MagicMock()
        auth = MagicMock()
        auth.get_auth_headers.return_value = {"Authorization": "Bearer test"}
        return BaseManager(client, auth)

    def test_get_passes_auth_headers(self):
        mgr = self._make_manager()
        mgr.client.get.return_value = {"id": "123"}
        result = mgr._get("/v1/test")
        mgr.client.get.assert_called_once_with(
            "/v1/test", headers={"Authorization": "Bearer test"}
        )
        assert result["id"] == "123"

    def test_post_passes_data_and_headers(self):
        mgr = self._make_manager()
        mgr.client.post.return_value = {"id": "456"}
        result = mgr._post("/v1/test", data={"key": "val"})
        mgr.client.post.assert_called_once_with(
            "/v1/test", data={"key": "val"}, headers={"Authorization": "Bearer test"}
        )
        assert result["id"] == "456"

    def test_delete_passes_auth(self):
        mgr = self._make_manager()
        mgr.client.delete.return_value = {}
        mgr._delete("/v1/test/123")
        mgr.client.delete.assert_called_once()


class TestSDDCManagerComposition:
    @patch("vcf_sdk.sddc_manager.SDDCAuth")
    @patch("vcf_sdk.sddc_manager.BaseClient")
    def test_all_managers_initialized(self, mock_client_cls, mock_auth_cls):
        mock_auth = MagicMock()
        mock_auth_cls.return_value = mock_auth

        from vcf_sdk.sddc_manager import SDDCManager
        sddc = SDDCManager.__new__(SDDCManager)
        sddc.auth = mock_auth
        sddc.client = mock_client_cls.return_value

        from vcf_sdk.managers import (
            TaskManager, HostManager, ClusterManager, DomainManager,
            NetworkManager, ImageManager, CredentialManager, CertificateManager,
            SystemManager, LicenseManager, BundleManager, UserManager,
            ComplianceManager, FederationManager, AriaManager, EdgeClusterManager,
        )
        sddc.tasks = TaskManager(sddc.client, sddc.auth)
        sddc.hosts = HostManager(sddc.client, sddc.auth)
        sddc.clusters = ClusterManager(sddc.client, sddc.auth)
        sddc.domains = DomainManager(sddc.client, sddc.auth)
        sddc.networks = NetworkManager(sddc.client, sddc.auth)
        sddc.images = ImageManager(sddc.client, sddc.auth)
        sddc.credentials = CredentialManager(sddc.client, sddc.auth)
        sddc.certificates = CertificateManager(sddc.client, sddc.auth)
        sddc.system = SystemManager(sddc.client, sddc.auth)
        sddc.licenses = LicenseManager(sddc.client, sddc.auth)
        sddc.bundles = BundleManager(sddc.client, sddc.auth)
        sddc.users = UserManager(sddc.client, sddc.auth)
        sddc.compliance = ComplianceManager(sddc.client, sddc.auth)
        sddc.federation = FederationManager(sddc.client, sddc.auth)
        sddc.aria = AriaManager(sddc.client, sddc.auth)
        sddc.edge_clusters = EdgeClusterManager(sddc.client, sddc.auth)

        assert isinstance(sddc.tasks, TaskManager)
        assert isinstance(sddc.clusters, ClusterManager)
        assert isinstance(sddc.credentials, CredentialManager)
        assert isinstance(sddc.certificates, CertificateManager)
        assert isinstance(sddc.system, SystemManager)
        assert isinstance(sddc.licenses, LicenseManager)
        assert isinstance(sddc.bundles, BundleManager)
        assert isinstance(sddc.users, UserManager)
        assert isinstance(sddc.compliance, ComplianceManager)
        assert isinstance(sddc.federation, FederationManager)
        assert isinstance(sddc.aria, AriaManager)
        assert isinstance(sddc.edge_clusters, EdgeClusterManager)


class TestManagerOperations:
    """Test manager methods with mocked HTTP client."""

    def _make_sddc(self):
        client = MagicMock()
        auth = MagicMock()
        auth.get_auth_headers.return_value = {"Authorization": "Bearer test"}
        return client, auth

    def test_host_list_with_status_filter(self):
        from vcf_sdk.managers import HostManager
        client, auth = self._make_sddc()
        client.get.return_value = {"elements": [
            {"id": "h-1", "fqdn": "esxi1.lab", "status": "COMMISSIONED"},
        ]}
        mgr = HostManager(client, auth)
        hosts = mgr.list(status="COMMISSIONED")
        client.get.assert_called_with(
            "/v1/hosts?status=COMMISSIONED",
            headers={"Authorization": "Bearer test"},
        )
        assert len(hosts) == 1
        assert hosts[0].fqdn == "esxi1.lab"

    def test_cluster_list(self):
        from vcf_sdk.managers import ClusterManager
        client, auth = self._make_sddc()
        client.get.return_value = {"elements": [
            {"id": "c-1", "name": "cl-01", "status": "ACTIVE"},
            {"id": "c-2", "name": "cl-02", "status": "ACTIVE"},
        ]}
        mgr = ClusterManager(client, auth)
        clusters = mgr.list()
        assert len(clusters) == 2
        assert clusters[0].name == "cl-01"

    def test_domain_create_with_validation(self):
        from vcf_sdk.managers import DomainManager
        client, auth = self._make_sddc()

        # Validation POST returns ID, then GET shows completed+succeeded
        client.post.side_effect = [
            {"id": "val-1"},  # POST /v1/domains/validations
            {"id": "task-1"},  # POST /v1/domains
        ]
        client.get.side_effect = [
            {"id": "val-1", "executionStatus": "COMPLETED", "resultStatus": "SUCCEEDED"},
            {"id": "task-1", "status": "RUNNING", "progress": 0},
        ]

        mgr = DomainManager(client, auth)
        task = mgr.create({"domainName": "wld-01"}, validate=True)
        assert task.id == "task-1"

    def test_credential_list_with_filters(self):
        from vcf_sdk.managers import CredentialManager
        client, auth = self._make_sddc()
        client.get.return_value = {"elements": [
            {"id": "cr-1", "resourceName": "vc01.lab", "resourceType": "VCENTER",
             "username": "root"},
        ]}
        mgr = CredentialManager(client, auth)
        mgr.list(resource_type="VCENTER")
        call_args = client.get.call_args[0][0]
        assert "resourceType=VCENTER" in call_args

    def test_license_add(self):
        from vcf_sdk.managers import LicenseManager
        client, auth = self._make_sddc()
        client.post.return_value = {
            "key": "XXXXX-XXXXX", "productType": "VCENTER",
            "licenseKeyStatus": "ACTIVE",
        }
        mgr = LicenseManager(client, auth)
        lic = mgr.add({"key": "XXXXX-XXXXX", "productType": "VCENTER"})
        assert lic.product_type == "VCENTER"
