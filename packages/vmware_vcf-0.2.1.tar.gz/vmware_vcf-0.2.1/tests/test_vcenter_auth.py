"""Tests for vCenter session authentication."""

from vcf_sdk.vcenter_auth import VCenterAuth
from vcf_sdk.exceptions import AuthenticationError

import pytest


class TestVCenterAuth:
    def test_session_headers_without_login_raises(self):
        auth = VCenterAuth("vc.lab.dev")
        with pytest.raises(AuthenticationError):
            auth.get_session_headers()

    def test_session_headers_with_token(self):
        auth = VCenterAuth("vc.lab.dev")
        auth._session_id = "test-session-token"
        headers = auth.get_session_headers()
        assert headers == {"vmware-api-session-id": "test-session-token"}

    def test_session_id_property(self):
        auth = VCenterAuth("vc.lab.dev")
        assert auth.session_id is None
        auth._session_id = "token-123"
        assert auth.session_id == "token-123"

    def test_logout_clears_session(self):
        auth = VCenterAuth("vc.lab.dev")
        auth._session_id = "token-123"
        auth.logout()
        assert auth._session_id is None
