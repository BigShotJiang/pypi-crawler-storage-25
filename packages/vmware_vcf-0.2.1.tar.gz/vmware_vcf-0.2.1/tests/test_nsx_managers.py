"""Tests for NSX-T Policy API managers."""

from unittest.mock import MagicMock

from vcf_sdk.nsx.segments import SegmentManager
from vcf_sdk.nsx.tier0 import Tier0Manager
from vcf_sdk.nsx.tier1 import Tier1Manager
from vcf_sdk.nsx.security import GroupManager, SecurityPolicyManager
from vcf_sdk.nsx.services import ServiceManager
from vcf_sdk.nsx.nat import NATManager
from vcf_sdk.nsx.dhcp import DHCPManager
from vcf_sdk.nsx.dns import DNSManager
from vcf_sdk.nsx.ip_pools import IPPoolManager
from vcf_sdk.nsx.fabric import TransportZoneManager, EdgeClusterManager


def _mock_client():
    client = MagicMock()
    client.get.return_value = {"results": []}
    client.patch.return_value = {}
    client.delete.return_value = {}
    return client


class TestSegmentManager:
    def test_list(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "seg-1", "display_name": "Web Segment", "admin_state": "UP"},
        ]}
        mgr = SegmentManager(client)
        segments = mgr.list()
        client.get.assert_called_with("/infra/segments")
        assert len(segments) == 1
        assert segments[0].id == "seg-1"

    def test_create_or_update(self):
        client = _mock_client()
        mgr = SegmentManager(client)
        mgr.create_or_update("web-seg", {
            "display_name": "Web Segment",
            "transport_zone_path": "/infra/sites/default/enforcement-points/default/transport-zones/tz-1",
        })
        call_args = client.patch.call_args
        assert call_args[0][0] == "/infra/segments/web-seg"
        assert call_args[1]["data"]["id"] == "web-seg"

    def test_delete(self):
        client = _mock_client()
        mgr = SegmentManager(client)
        mgr.delete("web-seg")
        client.delete.assert_called_with("/infra/segments/web-seg")

    def test_tier1_segments(self):
        client = _mock_client()
        client.get.return_value = {"results": [{"id": "t1-seg"}]}
        mgr = SegmentManager(client)
        mgr.list_tier1_segments("my-t1")
        client.get.assert_called_with("/infra/tier-1s/my-t1/segments")


class TestTier0Manager:
    def test_list(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "t0-gw", "ha_mode": "ACTIVE_STANDBY"},
        ]}
        mgr = Tier0Manager(client)
        gateways = mgr.list()
        assert gateways[0].ha_mode == "ACTIVE_STANDBY"

    def test_create_or_update(self):
        client = _mock_client()
        mgr = Tier0Manager(client)
        mgr.create_or_update("t0-gw", {"ha_mode": "ACTIVE_STANDBY"})
        client.patch.assert_called_with(
            "/infra/tier-0s/t0-gw",
            data={"id": "t0-gw", "ha_mode": "ACTIVE_STANDBY"},
        )

    def test_static_routes(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "route-1", "network": "0.0.0.0/0"},
        ]}
        mgr = Tier0Manager(client)
        routes = mgr.list_static_routes("t0-gw")
        assert routes[0].network == "0.0.0.0/0"

    def test_bgp_config(self):
        client = _mock_client()
        client.get.return_value = {"local_as_num": "65001", "enabled": True}
        mgr = Tier0Manager(client)
        bgp = mgr.get_bgp("t0-gw", "default")
        assert bgp.local_as_num == "65001"

    def test_bgp_neighbors(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "nbr-1", "neighbor_address": "10.0.0.254", "remote_as_num": "65002"},
        ]}
        mgr = Tier0Manager(client)
        neighbors = mgr.list_bgp_neighbors("t0-gw", "default")
        assert neighbors[0].remote_as_num == "65002"


class TestTier1Manager:
    def test_create_with_tier0_path(self):
        client = _mock_client()
        mgr = Tier1Manager(client)
        mgr.create_or_update("t1-gw", {
            "tier0_path": "/infra/tier-0s/t0-gw",
            "route_advertisement_types": ["TIER1_CONNECTED"],
        })
        data = client.patch.call_args[1]["data"]
        assert data["tier0_path"] == "/infra/tier-0s/t0-gw"


class TestGroupManager:
    def test_list_groups(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "web-servers", "expression": [{"resource_type": "Condition"}]},
        ]}
        mgr = GroupManager(client)
        groups = mgr.list()
        client.get.assert_called_with("/infra/domains/default/groups")
        assert groups[0].id == "web-servers"

    def test_create_group(self):
        client = _mock_client()
        mgr = GroupManager(client)
        mgr.create_or_update("web-servers", {
            "display_name": "Web Servers",
            "expression": [{"resource_type": "IPAddressExpression",
                            "ip_addresses": ["10.0.1.0/24"]}],
        })
        client.patch.assert_called_once()


class TestSecurityPolicyManager:
    def test_list_policies(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "app-pol", "category": "Application"},
        ]}
        mgr = SecurityPolicyManager(client)
        policies = mgr.list()
        assert policies[0].category == "Application"

    def test_create_rule(self):
        client = _mock_client()
        mgr = SecurityPolicyManager(client)
        mgr.create_or_update_rule("app-pol", "allow-https", {
            "action": "ALLOW", "services": ["/infra/services/HTTPS"],
        })
        call_path = client.patch.call_args[0][0]
        assert "security-policies/app-pol/rules/allow-https" in call_path


class TestServiceManager:
    def test_list(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "HTTP", "service_entries": [{"l4_protocol": "TCP", "destination_ports": ["80"]}]},
        ]}
        mgr = ServiceManager(client)
        services = mgr.list()
        assert services[0].id == "HTTP"


class TestNATManager:
    def test_create_tier0_snat(self):
        client = _mock_client()
        mgr = NATManager(client)
        mgr.create_or_update_tier0_rule("t0-gw", "snat-1", {
            "action": "SNAT", "source_network": "192.168.1.0/24",
            "translated_network": "10.0.0.100",
        })
        call_path = client.patch.call_args[0][0]
        assert "tier-0s/t0-gw/nat/USER/nat-rules/snat-1" in call_path

    def test_list_tier1_rules(self):
        client = _mock_client()
        client.get.return_value = {"results": [{"id": "dnat-1", "action": "DNAT"}]}
        mgr = NATManager(client)
        rules = mgr.list_tier1_rules("t1-gw")
        assert rules[0].action == "DNAT"


class TestDHCPManager:
    def test_list_servers(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "dhcp-1", "server_address": "100.96.0.1/30"},
        ]}
        mgr = DHCPManager(client)
        servers = mgr.list_servers()
        assert servers[0].server_address == "100.96.0.1/30"


class TestDNSManager:
    def test_list_zones(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "corp-dns", "dns_domain_names": ["corp.lab.dev"]},
        ]}
        mgr = DNSManager(client)
        zones = mgr.list_zones()
        assert zones[0].dns_domain_names == ["corp.lab.dev"]


class TestIPPoolManager:
    def test_create_pool(self):
        client = _mock_client()
        mgr = IPPoolManager(client)
        mgr.create_or_update("tep-pool", {"display_name": "TEP Pool"})
        client.patch.assert_called_with(
            "/infra/ip-pools/tep-pool",
            data={"id": "tep-pool", "display_name": "TEP Pool"},
        )

    def test_list_subnets(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "sub-1", "cidr": "192.168.250.0/24"},
        ]}
        mgr = IPPoolManager(client)
        subnets = mgr.list_subnets("tep-pool")
        assert subnets[0].cidr == "192.168.250.0/24"


class TestFabricManagers:
    def test_list_transport_zones(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "tz-1", "tz_type": "OVERLAY_STANDARD", "is_default": True},
        ]}
        mgr = TransportZoneManager(client)
        zones = mgr.list()
        assert zones[0].is_overlay

    def test_list_edge_clusters(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "ec-1", "member_node_type": "EDGE_NODE"},
        ]}
        mgr = EdgeClusterManager(client)
        clusters = mgr.list()
        assert clusters[0].member_node_type == "EDGE_NODE"

    def test_list_edge_nodes(self):
        client = _mock_client()
        client.get.return_value = {"results": [
            {"id": "en-1", "display_name": "Edge Node 1"},
        ]}
        mgr = EdgeClusterManager(client)
        nodes = mgr.list_nodes("ec-1")
        assert nodes[0].display_name == "Edge Node 1"


class TestNSXManagerComposition:
    def test_all_managers_present(self):
        """Test NSXManager wires up all sub-managers."""
        from unittest.mock import patch
        from vcf_sdk.nsx_manager import NSXManager

        with patch.object(NSXManager, '__init__', lambda self, *a, **kw: None):
            nsx = NSXManager.__new__(NSXManager)
            nsx.client = MagicMock()
            nsx._auth = ("admin", "pass")

            # Manually init managers like __init__ does
            from vcf_sdk.nsx import (
                SegmentManager, Tier0Manager, Tier1Manager,
                GroupManager, SecurityPolicyManager, GatewayPolicyManager,
                ServiceManager, NATManager, DHCPManager, DNSManager,
                IPPoolManager, NSXEdgeClusterManager, TransportZoneManager,
            )
            nsx.segments = SegmentManager(nsx)
            nsx.tier0 = Tier0Manager(nsx)
            nsx.tier1 = Tier1Manager(nsx)
            nsx.groups = GroupManager(nsx)
            nsx.security_policies = SecurityPolicyManager(nsx)
            nsx.gateway_policies = GatewayPolicyManager(nsx)
            nsx.services = ServiceManager(nsx)
            nsx.nat = NATManager(nsx)
            nsx.dhcp = DHCPManager(nsx)
            nsx.dns = DNSManager(nsx)
            nsx.ip_pools = IPPoolManager(nsx)
            nsx.transport_zones = TransportZoneManager(nsx)
            nsx.edge_clusters = NSXEdgeClusterManager(nsx)

            assert isinstance(nsx.segments, SegmentManager)
            assert isinstance(nsx.tier0, Tier0Manager)
            assert isinstance(nsx.groups, GroupManager)
            assert isinstance(nsx.security_policies, SecurityPolicyManager)
            assert isinstance(nsx.nat, NATManager)
            assert isinstance(nsx.transport_zones, TransportZoneManager)
