# spark-logical-plan-capture

Python package for connecting the Spark extension
`io.github.mt.logicplan.LogicalPlanCaptureExtension` via `spark-submit`
or from PySpark code.

## Install

```bash
pip install spark-logical-plan-capture
```

## Usage in PySpark

```python
from pyspark.sql import SparkSession
from spark_logical_plan_capture import get_spark_conf, get_jar_path

conf = get_spark_conf()

spark = (
    SparkSession.builder
    .config("spark.sql.extensions", conf["spark.sql.extensions"])
    .config("spark.jars", conf["spark.jars"])
    .getOrCreate()
)
```

## Usage with spark-submit

```bash
spark-submit \
  --conf "spark.sql.extensions=io.github.mt.logicplan.LogicalPlanCaptureExtension" \
  --jars "$(python -c 'from spark_logical_plan_capture import get_jar_path; print(get_jar_path())')" \
  your_job.py
```
