"""Derivation and decomposition getter owners."""

from __future__ import annotations

import logging
import os

from obra.config.typed_schema import DecompositionConfig, DerivationConfig
from obra.exceptions import ConfigurationError

from .. import _core, _defaults
from ._helpers import _resolve_config_value, resolve_float_config

logger = logging.getLogger(__name__)
# Rule D: declare locally, do NOT import from _defaults
_DERIVATION_LOOKBACK_DEPRECATION_LOGGED = False

__all__ = [
    "get_decomposition_failure_threshold",
    "get_decomposition_context_max_chars",
    "get_decomposition_warning_threshold_ratio",
    "get_decomposition_warning_threshold_s",
    "get_derivation_auto_decompose_config",
    "get_derivation_budget_config",
    "get_derivation_exploration_lookback_minutes",
    "get_derivation_serialize_max_concurrent",
    "get_derivation_stall_threshold",
    "get_derivation_step1_tier",
    "get_derivation_step2_tier",
    "get_derivation_step3_tier",
    "get_derivation_step_tier",
    "get_derivation_step_timeout",
    "get_derivation_task_config",
    "get_refinement_parallel_max_workers",
    "get_refinement_regression_min_delta",
    "get_refinement_regression_threshold_multiplier",
    "get_refinement_straggler_alert_threshold",
    "get_execute_decomposition_stream_idle_timeout_s",
    "is_decomposition_enabled",
]


def _positive_config_getter(
    *,
    env_key: str | None,
    config_path: str,
    default: int | float,
    coerce_fn,
    log_name: str,
    minimum: int | float = 0,
) -> int | float:
    """Resolve a positive numeric config value with fallback logging."""
    if env_key:
        raw_env = os.environ.get(env_key)
        if raw_env:
            try:
                coerced = coerce_fn(raw_env)
            except (TypeError, ValueError):
                coerced = None
            else:
                if _positive_config_value_is_valid(coerced, minimum):
                    return coerced
                _log_invalid_positive_value(log_name, minimum, coerced)

    value = _load_config_path_value(config_path, default)
    try:
        coerced = coerce_fn(value)
    except (TypeError, ValueError):
        return default
    if _positive_config_value_is_valid(coerced, minimum):
        return coerced
    _log_invalid_positive_value(log_name, minimum, coerced)
    return default


def get_decomposition_context_max_chars() -> int:
    """Get the LLM-facing decomposition context excerpt limit."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        value = config["orchestration"]["decomposition"]["context_max_chars"]
    except (KeyError, TypeError) as exc:
        raise ConfigurationError(
            "orchestration.decomposition.context_max_chars not found in config"
        ) from exc
    try:
        resolved = int(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            "orchestration.decomposition.context_max_chars must be an integer"
        ) from exc
    if resolved <= 0:
        raise ConfigurationError("orchestration.decomposition.context_max_chars must be > 0")
    return resolved


def _load_config_path_value(config_path: str, default: int | float) -> int | float:
    """Load a scalar value from layered config without keyword args."""
    try:
        config, _, _ = _core.load_layered_config()
    except Exception:
        return default

    current: object = config
    for part in config_path.split("."):
        if not isinstance(current, dict):
            return default
        current = current.get(part)
        if current is None:
            return default
    return current if isinstance(current, int | float | str) else default


def _positive_config_value_is_valid(value: int | float, minimum: int | float) -> bool:
    """Return whether a positive config value satisfies the configured floor."""
    if minimum == 0:
        return value > 0
    return value >= minimum


def _log_invalid_positive_value(log_name: str, minimum: int | float, value: int | float) -> None:
    """Log an invalid positive/floored config value."""
    comparator = ">=" if minimum else ">"
    logger.warning("%s must be %s %s (got %s)", log_name, comparator, minimum, value)


def _load_typed_decomposition_config() -> DecompositionConfig:
    config, _, _ = _core.load_layered_config()
    orchestration = config.get("orchestration", {})
    section = orchestration.get("decomposition", {}) if isinstance(orchestration, dict) else {}
    return DecompositionConfig.model_validate(section)


def _load_typed_derivation_config() -> DerivationConfig:
    config, _, _ = _core.load_layered_config()
    return DerivationConfig.model_validate(config.get("derivation", {}))


def is_decomposition_enabled() -> bool:
    """Check whether adaptive decomposition is enabled.

    Requires both features.userplan.auto_decompose.enabled and
    orchestration.decomposition.enabled (or legacy orchestration.auto_decompose_on_timeout).
    """
    config, _, _ = _core.load_layered_config()

    auto_decompose_enabled = True
    features_config = config.get("features", {})
    if isinstance(features_config, dict):
        userplan_config = features_config.get("userplan", {})
        if isinstance(userplan_config, dict):
            auto_decompose_config = userplan_config.get("auto_decompose", {})
            if isinstance(auto_decompose_config, dict):
                enabled = auto_decompose_config.get("enabled")
                if enabled is not None:
                    auto_decompose_enabled = bool(enabled)

    decomposition_enabled = _defaults.DEFAULT_DECOMPOSITION_ENABLED
    try:
        decomposition_enabled = bool(_load_typed_decomposition_config().enabled)
    except Exception:
        enabled = None
        orch_config = config.get("orchestration", {})
        if isinstance(orch_config, dict):
            decomposition_config = orch_config.get("decomposition", {})
            if isinstance(decomposition_config, dict):
                enabled = decomposition_config.get("enabled")
                if enabled is not None:
                    decomposition_enabled = bool(enabled)
            if enabled is None:
                legacy_enabled = orch_config.get("auto_decompose_on_timeout")
                if legacy_enabled is not None:
                    decomposition_enabled = bool(legacy_enabled)

    return auto_decompose_enabled and decomposition_enabled


def get_decomposition_failure_threshold() -> int:
    """Get the canonical repeated-failure decomposition threshold."""
    config, _, _ = _core.load_layered_config()

    orchestration = config.get("orchestration", {})
    if isinstance(orchestration, dict):
        decomposition = orchestration.get("decomposition", {})
        if isinstance(decomposition, dict):
            raw_threshold = decomposition.get("failure_threshold")
            if raw_threshold is not None:
                try:
                    threshold = int(raw_threshold)
                    if threshold > 0:
                        return threshold
                except (TypeError, ValueError):
                    pass

    derivation = config.get("derivation", {})
    if isinstance(derivation, dict):
        auto_decompose = derivation.get("auto_decompose", {})
        if isinstance(auto_decompose, dict):
            raw_threshold = auto_decompose.get("failure_threshold")
            if raw_threshold is not None:
                try:
                    threshold = int(raw_threshold)
                    if threshold > 0:
                        return threshold
                except (TypeError, ValueError):
                    pass

    return _defaults.DEFAULT_DECOMPOSITION_FAILURE_THRESHOLD


def _load_decomposition_config() -> dict:
    """Load the orchestration.decomposition config section if present."""
    try:
        return _load_typed_decomposition_config().model_dump()
    except Exception:
        return {}


def _resolve_optional_int_override(
    *,
    env_key: str | None,
    config_key: str,
    label: str,
    minimum: int = 0,
) -> int | None:
    """Resolve an optional integer override from env/config, returning None when unset."""
    raw_env = os.environ.get(env_key) if env_key else None
    if raw_env is not None and raw_env != "":
        try:
            value = int(raw_env)
        except (TypeError, ValueError):
            logger.warning("%s env override %s is invalid: %r", label, env_key, raw_env)
        else:
            if value >= minimum:
                return value
            logger.warning(
                "%s env override %s must be >= %s (got %s)", label, env_key, minimum, value
            )

    decomposition = _load_decomposition_config()
    raw_value = decomposition.get(config_key)
    if raw_value is None:
        return None

    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        logger.warning(
            "%s config value orchestration.decomposition.%s is invalid: %r",
            label,
            config_key,
            raw_value,
        )
        return None

    if value < minimum:
        logger.warning(
            "%s config value orchestration.decomposition.%s must be >= %s (got %s)",
            label,
            config_key,
            minimum,
            value,
        )
        return None
    return value


def get_decomposition_warning_threshold_ratio() -> float:
    """Get the derived warning-threshold ratio used when warning_threshold_s is unset."""
    return resolve_float_config(
        env_key="OBRA_DECOMPOSE_WARNING_RATIO",
        config_path="orchestration.decomposition.warning_threshold_ratio",
        default=0.8,
        min_val=0.0,
        max_val=1.0,
        label="Adaptive decomposition warning-threshold ratio",
    )


def get_decomposition_warning_threshold_s() -> int:
    """Get the effective execute-time decomposition warning threshold in seconds."""
    explicit_threshold = _resolve_optional_int_override(
        env_key="OBRA_DECOMPOSE_WARNING_S",
        config_key="warning_threshold_s",
        label="Adaptive decomposition warning threshold",
        minimum=0,
    )
    if explicit_threshold is not None:
        return explicit_threshold

    duration_threshold_s = _defaults.DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S
    try:
        from .. import get_decomposition_duration_threshold_s

        duration_threshold_s = int(get_decomposition_duration_threshold_s())
    except Exception:
        duration_threshold_s = _defaults.DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S

    ratio = get_decomposition_warning_threshold_ratio()
    return max(0, int(duration_threshold_s * ratio))


def get_execute_decomposition_stream_idle_timeout_s() -> int:
    """Get the effective execute-time stream idle timeout in seconds."""
    explicit_timeout = _resolve_optional_int_override(
        env_key="OBRA_DECOMPOSE_EXECUTE_STREAM_IDLE_S",
        config_key="execute_stream_idle_s",
        label="Adaptive decomposition execute stream idle timeout",
        minimum=0,
    )
    if explicit_timeout is not None:
        return explicit_timeout

    duration_threshold_s = _defaults.DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S
    try:
        from .. import get_decomposition_duration_threshold_s

        duration_threshold_s = int(get_decomposition_duration_threshold_s())
    except Exception:
        duration_threshold_s = _defaults.DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S
    return max(0, duration_threshold_s)


def get_derivation_step_timeout(step_name: str) -> int:
    """Get timeout for a specific derivation step in seconds.

    .. deprecated::
        ISSUE-DERIVE-001: This function has been superseded and will be removed.
        Post-hoc timeout checks cannot detect actual stalls - only duration
        after completion. Real stall detection is handled by MonitoringThread
        during CLI subprocess execution. The CLI subprocess timeout (7200s)
        is the authoritative timeout mechanism.

    Args:
        step_name: Name of the derivation step (structure, tasks, serialize)

    Returns:
        Timeout in seconds (600s default, but value is unused)
    """
    import warnings

    warnings.warn(
        "get_derivation_step_timeout has been superseded per ISSUE-DERIVE-001. "
        "Post-hoc timeout checks were removed; use CLI subprocess timeout instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return 600


def get_derivation_stall_threshold() -> int:
    """Get stall warning threshold for derivation in seconds.

    Resolution order:
    1. derivation.pipeline.stall_warning_threshold from config file
    2. Default 30 seconds

    Returns:
        Stall warning threshold in seconds
    """
    return _positive_config_getter(
        env_key=None,
        config_path="derivation.pipeline.stall_warning_threshold",
        default=30,
        coerce_fn=int,
        log_name="derivation.pipeline.stall_warning_threshold",
    )


def get_derivation_serialize_max_concurrent() -> int:
    """Get max concurrent workers for Step 3 per-epic JSON serialization.

    Resolution order:
    1. OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT environment variable
    2. derivation.serialize.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    return _positive_config_getter(
        env_key="OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT",
        config_path="derivation.serialize.max_concurrent",
        default=4,
        coerce_fn=int,
        log_name="derivation.serialize.max_concurrent",
    )


def get_refinement_parallel_max_workers() -> int:
    """Get max concurrent workers for parallel refinement batch dispatch.

    Resolution order:
    1. OBRA_REFINEMENT_PARALLEL_MAX_WORKERS environment variable
    2. refinement.parallel.max_workers from config file
    3. Default: 4

    Returns:
        Max concurrent workers for refinement examination/revision batches.
    """
    return _positive_config_getter(
        env_key="OBRA_REFINEMENT_PARALLEL_MAX_WORKERS",
        config_path="refinement.parallel.max_workers",
        default=4,
        coerce_fn=int,
        log_name="refinement.parallel.max_workers",
    )


def get_refinement_straggler_alert_threshold() -> float:
    """Get straggler alert threshold for parallel refinement telemetry.

    Resolution order:
    1. OBRA_REFINEMENT_STRAGGLER_ALERT_THRESHOLD environment variable
    2. refinement.straggler_alert_threshold from config file
    3. Default: 1.5
    """
    return _positive_config_getter(
        env_key="OBRA_REFINEMENT_STRAGGLER_ALERT_THRESHOLD",
        config_path="refinement.straggler_alert_threshold",
        default=_defaults.DEFAULT_REFINEMENT_STRAGGLER_ALERT_THRESHOLD,
        coerce_fn=float,
        log_name="refinement.straggler_alert_threshold",
    )


def get_refinement_regression_threshold_multiplier() -> float:
    """Get blocking-issue regression threshold multiplier for post-revise guardrails.

    Resolution order:
    1. OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER environment variable
    2. OBRA_REFINEMENT_REGRESSION_THRESHOLD (legacy env name)
    3. refinement.regression_threshold_multiplier from config file
    4. Default: 3.0
    """
    default = _defaults.DEFAULT_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER
    legacy_env = "OBRA_REFINEMENT_REGRESSION_THRESHOLD"

    # Check legacy env var first; if set, use it with a deprecation warning
    legacy_val = os.environ.get(legacy_env)
    if (
        legacy_val is not None
        and os.environ.get("OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER") is None
    ):
        logger.warning(
            "%s is deprecated; use OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER",
            legacy_env,
        )
        try:
            value = float(legacy_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER must be > 0 (got %s)",
                legacy_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER must be a float (got %s)",
                legacy_val,
            )

    # Primary env → config → default
    return _positive_config_getter(
        env_key="OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER",
        config_path="refinement.regression_threshold_multiplier",
        default=default,
        coerce_fn=float,
        log_name="refinement.regression_threshold_multiplier",
    )


def get_refinement_regression_min_delta() -> int:
    """Get minimum blocking-issue increase required for regression escalation.

    Resolution order:
    1. OBRA_REFINEMENT_REGRESSION_MIN_DELTA environment variable
    2. refinement.regression_min_delta from config file
    3. Default: 3
    """
    return _positive_config_getter(
        env_key="OBRA_REFINEMENT_REGRESSION_MIN_DELTA",
        config_path="refinement.regression_min_delta",
        default=_defaults.DEFAULT_REFINEMENT_REGRESSION_MIN_DELTA,
        coerce_fn=int,
        log_name="refinement.regression_min_delta",
        minimum=1,
    )


def get_derivation_step_tier(step: int) -> str:
    """Get the orchestrator tier for a derivation step.

    Args:
        step: Step number (1, 2, or 3)

    Returns:
        Tier name: 'fast', 'medium', or 'high'

    Raises:
        ValueError: If step is not 1, 2, or 3
    """
    if step not in (1, 2, 3):
        raise ValueError(f"Invalid derivation step: {step}. Must be 1, 2, or 3.")

    step_key = f"step{step}_tier"
    env_var = f"OBRA_DERIVATION_STEP{step}_TIER"
    default_tiers = {1: "high", 2: "high", 3: "fast"}

    env_val = os.environ.get(env_var)
    if env_val:
        tier = env_val.lower()
        if tier in ("fast", "medium", "high"):
            return tier
        logger.warning(
            "%s must be fast, medium, or high (got %s)",
            env_var,
            env_val,
        )

    try:
        config_tier = str(_load_typed_derivation_config().steps.model_dump()[step_key]).lower()
        if config_tier in ("fast", "medium", "high"):
            return config_tier
        logger.warning(
            "derivation.steps.%s must be fast, medium, or high (got %s)",
            step_key,
            config_tier,
        )
    except Exception:
        pass

    return default_tiers[step]


def get_derivation_step1_tier() -> str:
    """Get orchestrator tier for Step 1 (epic derivation).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(1)


def get_derivation_step2_tier() -> str:
    """Get orchestrator tier for Step 2 (story/task expansion).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(2)


def get_derivation_step3_tier() -> str:
    """Get orchestrator tier for Step 3 (JSON serialization).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'fast')
    """
    return get_derivation_step_tier(3)


def get_derivation_exploration_lookback_minutes() -> int:
    """Get exploration lookback window in minutes.

    Deprecated alias for ``orchestration.exploration.skip.recent_exploration_hours``.

    Returns:
        Minutes to look back for recent exploration artifacts (default: 180)
    """
    global _DERIVATION_LOOKBACK_DEPRECATION_LOGGED
    default = _defaults.DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES

    # Preferred path: hours-based config (with deprecation warning for this getter)
    hours_value = _resolve_config_value(
        env_key=None,
        config_path="orchestration.exploration.skip.recent_exploration_hours",
        default=None,
        coerce_fn=None,
    )
    if hours_value is not None:
        try:
            hours = int(hours_value)
            if not _DERIVATION_LOOKBACK_DEPRECATION_LOGGED:
                logger.warning(
                    "get_derivation_exploration_lookback_minutes() is deprecated; "
                    "use orchestration.exploration.skip.recent_exploration_hours."
                )
                _DERIVATION_LOOKBACK_DEPRECATION_LOGGED = True
            return hours * 60
        except (TypeError, ValueError):
            pass

    # Legacy fallback: minutes-based config
    minutes_value = _resolve_config_value(
        env_key=None,
        config_path="derivation.exploration_lookback_minutes",
        default=default,
        coerce_fn=None,
    )
    try:
        return int(minutes_value)
    except (TypeError, ValueError):
        return default


def get_derivation_auto_decompose_config() -> dict:
    """Get derivation auto-decompose configuration.

    Returns:
        Dict with failure_threshold, max_depth keys
    """
    try:
        auto_decompose_config = _load_typed_derivation_config().auto_decompose
        return {
            "failure_threshold": get_decomposition_failure_threshold(),
            "max_depth": auto_decompose_config.max_depth,
        }
    except Exception:
        pass
    result = _defaults.DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG.copy()
    result["failure_threshold"] = get_decomposition_failure_threshold()
    return result


def get_derivation_budget_config() -> dict:
    """Get derivation budget configuration.

    Returns:
        Dict with decompose_threshold, warning_threshold, min_subtask_ratio keys
    """
    try:
        budget_config = _load_typed_derivation_config().budget
        return {
            "decompose_threshold": budget_config.decompose_threshold,
            "warning_threshold": budget_config.warning_threshold,
            "min_subtask_ratio": budget_config.min_subtask_ratio,
        }
    except Exception:
        pass
    return _defaults.DEFAULT_DERIVATION_BUDGET_CONFIG.copy()


def get_derivation_task_config() -> dict:
    """Get derivation task budget configuration.

    Returns:
        Dict with token_budget, cost_budget_usd keys
    """
    try:
        task_config = _load_typed_derivation_config().task
        return {
            "token_budget": task_config.token_budget,
            "cost_budget_usd": task_config.cost_budget_usd,
        }
    except Exception:
        pass
    return _defaults.DEFAULT_DERIVATION_TASK_CONFIG.copy()
