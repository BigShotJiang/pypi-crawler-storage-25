"""Simulation-specific config getter owners."""

from __future__ import annotations

import sys
from typing import Any

from obra.config.loaders import _core
from obra.exceptions import ConfigurationError

__all__ = [
    "get_nightly_simulation_config",
    "get_campaign_simulation_config",
    "get_local_emulator_config",
    "get_local_port_service_catalog",
    "get_persona_harness_config",
    "get_simulation_runtime_config",
]

_LOCAL_PORT_SERVICE_IDS = (
    "firebase_auth",
    "firestore",
    "functions",
    "emulator_ui",
    "hosting",
    "studio_gateway",
    "studio_web",
)

_LOCAL_PORT_REQUIRED_FIELDS = (
    "display_name",
    "host",
    "port",
    "override_env_var",
    "auto_range_start",
    "auto_range_end",
    "manifest_exports",
)

_LAYER_PRIORITY = {"default": 0, "derived": 0, "user": 1, "workspace": 2, "session": 3}


def _require_mapping(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigurationError(f"{path} section is required")
    return value


def _coerce_tcp_port(value: Any, path: str) -> int:
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"{path} must be an integer") from exc
    if not 0 < port < 65536:
        raise ConfigurationError(f"{path} must be a valid TCP port")
    return port


def _coerce_manifest_exports(value: Any, path: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ConfigurationError(f"{path} must be a non-empty list")
    exports = [str(item).strip() for item in value]
    if any(not item for item in exports):
        raise ConfigurationError(f"{path} must not contain empty values")
    return exports


def _origin_priority(origins: dict[str, str], path: str) -> int:
    return _LAYER_PRIORITY.get(origins.get(path, "default"), 0)


def get_nightly_simulation_config() -> dict[str, Any]:
    """Return the nightly simulation runner config as one validated dict."""
    parent_module = sys.modules.get("obra.config.loaders")
    if parent_module is None:
        raise RuntimeError("obra.config.loaders must be imported before simulation getters")

    return {
        "wait_poll_interval_s": parent_module.get_nightly_wait_poll_interval_s(),
        "max_total_loops": parent_module.get_nightly_max_total_loops(),
        "max_target_retries": parent_module.get_nightly_max_target_retries(),
        "max_fix_loops": parent_module.get_nightly_max_fix_loops(),
        "max_repair_attempts": parent_module.get_nightly_max_repair_attempts(),
        "repair_cooldown_s": parent_module.get_nightly_repair_cooldown_s(),
        "worker_timeout_s": parent_module.get_nightly_worker_timeout_s(),
        "analysis_tier": parent_module.get_nightly_analysis_tier(),
        "fix_tier": parent_module.get_nightly_fix_tier(),
        "enable_llm_fixes": parent_module.get_nightly_enable_llm_fixes(),
        "enable_session_repair": parent_module.get_nightly_enable_session_repair(),
        "allow_force_complete": parent_module.get_nightly_allow_force_complete(),
    }


def get_campaign_simulation_config() -> dict[str, Any]:
    """Return the campaign runner config as one validated dict."""
    parent_module = sys.modules.get("obra.config.loaders")
    if parent_module is None:
        raise RuntimeError("obra.config.loaders must be imported before simulation getters")

    return {
        "child_poll_interval_s": parent_module.get_campaign_child_poll_interval_s(),
        "bootstrap_ready_timeout_s": parent_module.get_campaign_bootstrap_ready_timeout_s(),
        "max_fix_loops": parent_module.get_campaign_max_fix_loops(),
        "confirmation_reruns": parent_module.get_campaign_confirmation_reruns(),
        "worker_timeout_s": parent_module.get_campaign_worker_timeout_s(),
        "analysis_tier": parent_module.get_campaign_analysis_tier(),
        "fix_tier": parent_module.get_campaign_fix_tier(),
        "enable_llm_fixes": parent_module.get_campaign_enable_llm_fixes(),
        "transcript_retention_runs": parent_module.get_campaign_transcript_retention_runs(),
        "tool_availability_timeout_s": parent_module.get_campaign_tool_availability_timeout_s(),
    }


def get_persona_harness_config() -> dict[str, Any]:
    """Return validated persona-driven Studio harness settings."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        gateway = config["gateway"]
    except KeyError as exc:
        raise ConfigurationError("gateway section is required") from exc
    if not isinstance(gateway, dict):
        raise ConfigurationError("gateway section must be a mapping")
    try:
        assistant = gateway["assistant"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant section is required") from exc
    if not isinstance(assistant, dict):
        raise ConfigurationError("gateway.assistant section must be a mapping")
    try:
        driver_model = assistant["persona_driver_model"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_driver_model is required") from exc
    try:
        judge_model = assistant["persona_judge_model"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_judge_model is required") from exc
    try:
        runs_per_night = assistant["persona_runs_per_night"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night is required") from exc
    try:
        normalized_runs = int(runs_per_night)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night must be an integer") from exc
    if normalized_runs < 1:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night must be >= 1")
    return {
        "persona_driver_model": str(driver_model),
        "persona_judge_model": str(judge_model),
        "persona_runs_per_night": normalized_runs,
    }


def get_simulation_runtime_config() -> dict[str, int | float]:
    """Return validated local simulation runtime limits."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    simulation = config.get("simulation")
    if not isinstance(simulation, dict):
        raise ConfigurationError("simulation section is required")
    try:
        log_tail_lines = int(simulation["log_tail_lines"])
        tcp_probe_timeout_s = float(simulation["tcp_probe_timeout_s"])
    except KeyError as exc:
        raise ConfigurationError(f"simulation.{exc.args[0]} is required") from exc
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("simulation runtime values must be numeric") from exc
    if log_tail_lines <= 0:
        raise ConfigurationError("simulation.log_tail_lines must be > 0")
    if tcp_probe_timeout_s <= 0:
        raise ConfigurationError("simulation.tcp_probe_timeout_s must be > 0")
    return {
        "log_tail_lines": log_tail_lines,
        "tcp_probe_timeout_s": tcp_probe_timeout_s,
    }


def get_local_emulator_config() -> dict[str, int]:
    """Return validated local Firebase emulator ports from the canonical catalog."""
    catalog = get_local_port_service_catalog()
    return {
        "firestore_port": int(catalog["services"]["firestore"]["port"]),
        "functions_port": int(catalog["services"]["functions"]["port"]),
    }


def get_local_port_service_catalog() -> dict[str, Any]:
    """Return the validated local port service catalog.

    The legacy ``local.emulator`` Firestore/Functions keys are compatibility
    aliases into this catalog. When a later config layer sets a legacy key but
    leaves the canonical service key at default, the legacy value is projected
    into the service entry so old local config files continue to work without
    becoming a second runtime owner.
    """
    config, origins, _ = _core.load_layered_config(include_defaults=True)
    local = _require_mapping(config.get("local"), "local")
    ports = _require_mapping(local.get("ports"), "local.ports")
    services = _require_mapping(ports.get("services"), "local.ports.services")

    auto_ports_enabled = ports.get("auto_ports_enabled")
    if not isinstance(auto_ports_enabled, bool):
        raise ConfigurationError("local.ports.auto_ports_enabled must be a boolean")

    legacy_aliases = {
        "firestore": "local.emulator.firestore_port",
        "functions": "local.emulator.functions_port",
    }
    resolved_services: dict[str, dict[str, Any]] = {}
    for service_id in _LOCAL_PORT_SERVICE_IDS:
        raw_service = _require_mapping(
            services.get(service_id),
            f"local.ports.services.{service_id}",
        )
        missing = [
            field
            for field in _LOCAL_PORT_REQUIRED_FIELDS
            if field not in raw_service
        ]
        if missing:
            raise ConfigurationError(
                f"local.ports.services.{service_id} missing required keys: {', '.join(missing)}"
            )

        service_path = f"local.ports.services.{service_id}"
        port_path = f"{service_path}.port"
        port = _coerce_tcp_port(raw_service["port"], port_path)
        legacy_path = legacy_aliases.get(service_id)
        if legacy_path is not None:
            legacy_value = _core._get_nested_value(config, legacy_path)
            if legacy_value is not None:
                legacy_port = _coerce_tcp_port(legacy_value, legacy_path)
                if _origin_priority(origins, legacy_path) > _origin_priority(origins, port_path):
                    port = legacy_port

        auto_range_start = _coerce_tcp_port(
            raw_service["auto_range_start"],
            f"{service_path}.auto_range_start",
        )
        auto_range_end = _coerce_tcp_port(
            raw_service["auto_range_end"],
            f"{service_path}.auto_range_end",
        )
        if auto_range_start > auto_range_end:
            raise ConfigurationError(
                f"{service_path}.auto_range_start must be <= {service_path}.auto_range_end"
            )

        display_name = str(raw_service["display_name"]).strip()
        host = str(raw_service["host"]).strip()
        override_env_var = str(raw_service["override_env_var"]).strip()
        if not display_name:
            raise ConfigurationError(f"{service_path}.display_name must not be empty")
        if not host:
            raise ConfigurationError(f"{service_path}.host must not be empty")
        if not override_env_var:
            raise ConfigurationError(f"{service_path}.override_env_var must not be empty")

        resolved_services[service_id] = {
            "service_id": service_id,
            "display_name": display_name,
            "host": host,
            "port": port,
            "override_env_var": override_env_var,
            "config_key": port_path,
            "auto_range_start": auto_range_start,
            "auto_range_end": auto_range_end,
            "manifest_exports": _coerce_manifest_exports(
                raw_service["manifest_exports"],
                f"{service_path}.manifest_exports",
            ),
        }

    return {
        "auto_ports_enabled": auto_ports_enabled,
        "services": resolved_services,
    }
