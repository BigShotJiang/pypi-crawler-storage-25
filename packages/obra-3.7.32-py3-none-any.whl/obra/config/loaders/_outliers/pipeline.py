"""Pipeline getter owners."""

from __future__ import annotations

import os
from typing import Any

from obra.config.typed_schema import ExecutionConfig
from obra.exceptions import ConfigurationError

from .. import _core

__all__ = [
    "get_mcp_servers_config",
    "get_execution_limits",
    "get_filesystem_preflight_config",
    "get_bulk_template_gen_config",
    "get_pipeline_custom_stages",
    "get_pipeline_max_iterations",
    "get_pipeline_registered_runners",
    "get_pipeline_runner_kind_timeout_floors",
    "get_pipeline_stage_defaults",
    "get_pipeline_stage_timeout",
    "get_prompt_enricher_limits",
    "get_stage_runner_limits",
]


def get_pipeline_custom_stages() -> list[dict[str, Any]]:
    """Get enabled custom pipeline stages from configuration.

    Resolution order:
    1. pipeline.custom_stages from config file

    Returns:
        List of enabled stage configurations (filtered to enabled=True only)
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")
    custom_stages = pipeline_config.get("custom_stages", [])
    if not isinstance(custom_stages, list):
        raise ConfigurationError("pipeline.custom_stages must be a list")
    return [stage for stage in custom_stages if stage.get("enabled", True)]


def get_pipeline_registered_runners() -> list[dict[str, Any]]:
    """Get enabled canonical project-overlay Python runners in loader format."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")

    runner_catalog = pipeline_config.get("runner_catalog", {})
    if runner_catalog is not None and not isinstance(runner_catalog, dict):
        raise ConfigurationError("pipeline.runner_catalog must be a dictionary")

    project_overlay = (
        runner_catalog.get("project_overlay", {}) if isinstance(runner_catalog, dict) else {}
    )
    if project_overlay is not None and not isinstance(project_overlay, dict):
        raise ConfigurationError("pipeline.runner_catalog.project_overlay must be a dictionary")

    overlay_entries = (
        project_overlay.get("entries", []) if isinstance(project_overlay, dict) else []
    )
    if not isinstance(overlay_entries, list):
        raise ConfigurationError("pipeline.runner_catalog.project_overlay.entries must be a list")

    normalized_runners: list[dict[str, Any]] = []
    for entry in overlay_entries:
        if not isinstance(entry, dict) or not entry.get("enabled", True):
            continue
        if entry.get("kind") != "python_runner":
            continue
        activation = entry.get("activation", {})
        if not isinstance(activation, dict):
            continue
        factory = activation.get("factory")
        if not factory:
            continue
        normalized_runners.append(
            {
                "id": entry.get("id"),
                "factory": factory,
                "enabled": bool(entry.get("enabled", True)),
                "version": entry.get("version"),
            }
        )

    return normalized_runners


def get_pipeline_stage_defaults() -> dict[str, int]:
    """Get validated default pipeline-stage settings from configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")

    defaults = pipeline_config.get("defaults")
    if not isinstance(defaults, dict):
        raise ConfigurationError("pipeline.defaults section not found in config")

    timeout_value = defaults.get("timeout_s")
    if timeout_value is None:
        raise ConfigurationError("pipeline.defaults.timeout_s not found in config")
    try:
        timeout_s = int(timeout_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("pipeline.defaults.timeout_s must be an integer") from exc
    if timeout_s < 600:
        raise ConfigurationError("pipeline.defaults.timeout_s must be >= 600")

    max_iterations_value = defaults.get("max_iterations")
    if max_iterations_value is None:
        raise ConfigurationError("pipeline.defaults.max_iterations not found in config")
    try:
        max_iterations = int(max_iterations_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("pipeline.defaults.max_iterations must be an integer") from exc

    return {
        "max_iterations": max_iterations,
        "timeout_s": timeout_s,
    }


def get_pipeline_runner_kind_timeout_floors() -> dict[str, int]:
    """Get validated pipeline runner-kind timeout floors."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")
    floors = pipeline_config.get("runner_kind_timeout_floors")
    if not isinstance(floors, dict):
        raise ConfigurationError("pipeline.runner_kind_timeout_floors section not found in config")
    required = {"default", "command_runner", "python_runner", "http_runner", "builtin_agent_adapter"}
    missing = sorted(required - set(floors))
    if missing:
        raise ConfigurationError(
            "pipeline.runner_kind_timeout_floors missing required keys: "
            + ", ".join(missing)
        )
    return {str(key): int(value) for key, value in floors.items()}


def get_stage_runner_limits() -> dict[str, int]:
    """Get validated stage-runner byte limits from typed configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    stages = config.get("stages")
    if not isinstance(stages, dict):
        raise ConfigurationError("stages section not found in config")
    http = stages.get("http")
    command = stages.get("command")
    if not isinstance(http, dict):
        raise ConfigurationError("stages.http section not found in config")
    if not isinstance(command, dict):
        raise ConfigurationError("stages.command section not found in config")

    required = {
        "http_max_response_bytes": ("stages.http.max_response_bytes", http, "max_response_bytes"),
        "command_stdout_max_bytes": ("stages.command.stdout_max_bytes", command, "stdout_max_bytes"),
        "command_stderr_max_bytes": ("stages.command.stderr_max_bytes", command, "stderr_max_bytes"),
    }
    limits: dict[str, int] = {}
    for output_key, (config_path, section, key) in required.items():
        if key not in section:
            raise ConfigurationError(f"{config_path} not found in config")
        try:
            value = int(section[key])
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"{config_path} must be an integer") from exc
        if value <= 0:
            raise ConfigurationError(f"{config_path} must be > 0")
        limits[output_key] = value
    return limits


def get_prompt_enricher_limits() -> dict[str, int]:
    """Get validated prompt-enricher context limits."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    prompt_enricher = config.get("prompt_enricher")
    if not isinstance(prompt_enricher, dict):
        raise ConfigurationError("prompt_enricher section not found in config")
    required = {
        "max_files": "max_files",
        "max_recent_commits": "max_recent_commits",
        "max_recent_errors": "max_recent_errors",
    }
    limits: dict[str, int] = {}
    for output_key, config_key in required.items():
        if config_key not in prompt_enricher:
            raise ConfigurationError(f"prompt_enricher.{config_key} not found in config")
        try:
            value = int(prompt_enricher[config_key])
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"prompt_enricher.{config_key} must be an integer") from exc
        if value <= 0:
            raise ConfigurationError(f"prompt_enricher.{config_key} must be > 0")
        limits[output_key] = value
    return limits


def get_bulk_template_gen_config() -> dict[str, int]:
    """Get validated bulk-template-generation pipeline settings."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")
    bulk_config = pipeline_config.get("bulk_template_gen")
    if not isinstance(bulk_config, dict):
        raise ConfigurationError("pipeline.bulk_template_gen section not found in config")
    if "review_preview_max_chars" not in bulk_config:
        raise ConfigurationError(
            "pipeline.bulk_template_gen.review_preview_max_chars not found in config"
        )
    try:
        review_preview_max_chars = int(bulk_config["review_preview_max_chars"])
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            "pipeline.bulk_template_gen.review_preview_max_chars must be an integer"
        ) from exc
    if review_preview_max_chars <= 0:
        raise ConfigurationError(
            "pipeline.bulk_template_gen.review_preview_max_chars must be > 0"
        )
    return {"review_preview_max_chars": review_preview_max_chars}


def get_filesystem_preflight_config() -> dict[str, int]:
    """Get validated filesystem preflight probe settings."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    preflight = config.get("preflight")
    if not isinstance(preflight, dict):
        raise ConfigurationError("preflight section not found in config")
    required = {
        "probe_timeout_s": "probe_timeout_s",
        "probe_error_max_chars": "probe_error_max_chars",
    }
    resolved: dict[str, int] = {}
    for output_key, config_key in required.items():
        if config_key not in preflight:
            raise ConfigurationError(f"preflight.{config_key} not found in config")
        try:
            value = int(preflight[config_key])
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"preflight.{config_key} must be an integer") from exc
        if value <= 0:
            raise ConfigurationError(f"preflight.{config_key} must be > 0")
        resolved[output_key] = value
    return resolved


def get_execution_limits() -> dict[str, int]:
    """Get validated execution prompt and delivered-summary limits."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    execution = config.get("execution")
    if not isinstance(execution, dict):
        raise ConfigurationError("execution section not found in config")
    delivered_summary = execution.get("delivered_summary")
    if not isinstance(delivered_summary, dict):
        raise ConfigurationError("execution.delivered_summary section not found in config")
    keys = {
        "inline_prompt_max_chars": ("execution.inline_prompt_max_chars", execution, "inline_prompt_max_chars"),
        "delivered_summary_max_files": ("execution.delivered_summary.max_files", delivered_summary, "max_files"),
        "delivered_summary_max_tests": ("execution.delivered_summary.max_tests", delivered_summary, "max_tests"),
        "delivered_summary_max_docs": ("execution.delivered_summary.max_docs", delivered_summary, "max_docs"),
    }
    resolved: dict[str, int] = {}
    for output_key, (config_path, section, key) in keys.items():
        if key not in section:
            raise ConfigurationError(f"{config_path} not found in config")
        try:
            value = int(section[key])
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"{config_path} must be an integer") from exc
        if value <= 0:
            raise ConfigurationError(f"{config_path} must be > 0")
        resolved[output_key] = value
    return resolved


def get_pipeline_stage_timeout(stage_name: str) -> int:
    """Get timeout for a specific pipeline stage.

    Resolution order:
    1. OBRA_PIPELINE_STAGE_TIMEOUT_S environment variable
    2. Stage-specific timeout from config (if defined)
    3. pipeline.defaults.timeout_s from config
    """
    env_val = os.environ.get("OBRA_PIPELINE_STAGE_TIMEOUT_S")
    if env_val:
        try:
            timeout_s = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_STAGE_TIMEOUT_S"
            raise ConfigurationError(msg) from None
        if timeout_s < 600:
            raise ConfigurationError("OBRA_PIPELINE_STAGE_TIMEOUT_S must be >= 600")
        return timeout_s

    custom_stages = get_pipeline_custom_stages()
    for stage in custom_stages:
        if stage.get("name") == stage_name and "timeout_s" in stage:
            try:
                timeout_s = int(stage["timeout_s"])
            except (TypeError, ValueError) as exc:
                raise ConfigurationError(
                    f"pipeline.custom_stages[{stage_name}].timeout_s must be an integer"
                ) from exc
            if timeout_s < 600:
                raise ConfigurationError(
                    f"pipeline.custom_stages[{stage_name}].timeout_s must be >= 600"
                )
            return timeout_s

    return get_pipeline_stage_defaults()["timeout_s"]


def get_pipeline_max_iterations() -> int:
    """Get maximum re-validate iterations for pipeline stages.

    Resolution order:
    1. OBRA_PIPELINE_MAX_ITERATIONS environment variable
    2. pipeline.defaults.max_iterations from config
    3. 3 (default)
    """
    env_val = os.environ.get("OBRA_PIPELINE_MAX_ITERATIONS")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_MAX_ITERATIONS"
            raise ConfigurationError(msg) from None

    return get_pipeline_stage_defaults()["max_iterations"]


def get_mcp_servers_config() -> list[dict[str, Any]]:
    """Get MCP server definitions for agent sessions.

    Returns validated server entries from execution.mcp_servers.servers.
    Each entry must have an 'id' and either 'command' (stdio) or 'url' (HTTP).
    Returns empty list when execution.mcp_servers.enabled is false.
    """
    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
        execution = ExecutionConfig.model_validate(config.get("execution", {}))
        mcp_config = execution.mcp_servers
    except Exception:
        return []
    if not mcp_config.enabled:
        return []

    validated: list[dict[str, Any]] = []
    for entry in mcp_config.servers:
        if not entry.id or (not entry.command and not entry.url):
            continue
        payload = entry.model_dump(exclude_none=True)
        validated.append(payload)
    return validated
