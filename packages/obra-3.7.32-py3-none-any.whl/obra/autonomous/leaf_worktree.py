"""Per-attempt git worktree isolation for autonomous fix workers.

Each campaign fix attempt edits a short-lived worktree under the Obra runtime
directory. Gates inspect that worktree, accepted fixes are committed there and
cherry-picked back to the operator checkout, and rejected fixes are discarded
without touching main. The run id is derived from existing campaign identity
and result-root context because campaign state does not expose a stable
``run_id`` field today.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from obra.utils.obra_home import get_runtime_dir

_SAFE_SEGMENT_RE = re.compile(r"[^A-Za-z0-9_.-]+")


def _safe_segment(value: str) -> str:
    segment = _SAFE_SEGMENT_RE.sub("-", value.strip()).strip(".-")
    return segment or "run"


def resolve_worktree_run_id(campaign_id: str, result_root: Path) -> str:
    """Return a filesystem-safe id for worktree and deferred-patch storage."""
    return _safe_segment(f"{campaign_id}-{Path(result_root).name}")


def prune_worktrees(repo_root: Path) -> None:
    """Prune stale git worktree metadata for *repo_root*."""
    subprocess.run(
        ["git", "worktree", "prune"],
        check=False,
        capture_output=True,
        text=True,
        cwd=repo_root,
    )


@dataclass
class LeafWorktree:
    """Context manager for one isolated fix-worker attempt."""

    run_id: str
    leaf_id: str
    attempt: int
    repo_root: Path
    base_dir: Path | None = None

    def __post_init__(self) -> None:
        root = self.base_dir or (get_runtime_dir() / "worktrees")
        self.path = root / _safe_segment(self.run_id) / (
            f"{_safe_segment(self.leaf_id)}-{self.attempt:03d}"
        )
        self._preserve = False
        self._entered = False

    def __enter__(self) -> Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["git", "worktree", "add", "--detach", str(self.path), "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            cwd=self.repo_root,
        )
        self._entered = True
        return self.path

    def __exit__(self, exc_type, exc, tb) -> bool:
        if exc_type is not None:
            self._preserve = True
        if self._entered and not self._preserve:
            self.discard()
        return False

    def commit_attempt(self, paths_to_stage: list[str], message: str) -> str:
        """Stage selected paths and create the accepted worker commit."""
        unique_paths = [path for path in dict.fromkeys(paths_to_stage) if path]
        if not unique_paths:
            return ""
        subprocess.run(
            ["git", "add", "--", *unique_paths],
            check=True,
            capture_output=True,
            text=True,
            cwd=self.path,
        )
        subprocess.run(
            ["git", "commit", "-m", message],
            check=True,
            capture_output=True,
            text=True,
            cwd=self.path,
        )
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            cwd=self.path,
        )
        return result.stdout.strip()

    def commit_to_main(self, commit_sha: str) -> str:
        """Cherry-pick *commit_sha* onto the main checkout and return its sha."""
        if not commit_sha:
            return ""
        try:
            subprocess.run(
                ["git", "cherry-pick", commit_sha],
                check=True,
                capture_output=True,
                text=True,
                cwd=self.repo_root,
            )
        except subprocess.CalledProcessError:
            self._preserve = True
            raise
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            cwd=self.repo_root,
        )
        return result.stdout.strip()

    def discard(self) -> None:
        """Remove this worktree without cherry-picking any changes."""
        subprocess.run(
            ["git", "worktree", "remove", "--force", str(self.path)],
            check=False,
            capture_output=True,
            text=True,
            cwd=self.repo_root,
        )
        self._entered = False
