"""Scrubbed transcript capture for autonomous fix-worker invocations."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

DEFAULT_SECRET_PATTERNS: tuple[str, ...] = (
    r"AKIA[0-9A-Z]{16}",
    r"gh[pousr]_[A-Za-z0-9]{36,}",
    r"sk-ant-[A-Za-z0-9-_]{20,}",
    r"sk-[A-Za-z0-9]{32,}",
    r"eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+",
)

_SECRET_FILE_RE = re.compile(r"(^|/)(\.env[^/]*|credentials[^/]*)$", re.IGNORECASE)


class WorkerTranscriptCapture:
    """Append scrubbed stream-json lines to ``fix-worker/transcript.jsonl``."""

    def __init__(
        self,
        attempt_dir: Path,
        secret_patterns: tuple[str, ...] = DEFAULT_SECRET_PATTERNS,
    ) -> None:
        self.attempt_dir = attempt_dir
        self.fix_worker_dir = attempt_dir / "fix-worker"
        self.fix_worker_dir.mkdir(parents=True, exist_ok=True)
        self.transcript_path = self.fix_worker_dir / "transcript.jsonl"
        self._patterns = tuple(re.compile(pattern) for pattern in secret_patterns)

    def on_stream_line(self, line: str) -> None:
        """Scrub and append one raw provider stream line."""
        scrubbed = self.scrub(line.rstrip("\n"))
        with self.transcript_path.open("a", encoding="utf-8") as handle:
            handle.write(scrubbed + "\n")

    def scrub(self, text: str) -> str:
        """Elide secret-looking values and sensitive file payloads."""
        scrubbed = text
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            payload = self._scrub_json_value(payload)
            scrubbed = json.dumps(payload, sort_keys=True)
        for pattern in self._patterns:
            scrubbed = pattern.sub("<elided>", scrubbed)
        return scrubbed

    def _scrub_json_value(self, value):
        if isinstance(value, dict):
            path = str(value.get("path") or value.get("file") or value.get("filename") or "")
            if path and _SECRET_FILE_RE.search(path):
                cleaned = dict(value)
                for key in ("content", "text", "result", "value"):
                    if key in cleaned:
                        cleaned[key] = "<elided: secrets-pattern file>"
                return cleaned
            return {key: self._scrub_json_value(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._scrub_json_value(item) for item in value]
        if isinstance(value, str):
            for pattern in self._patterns:
                value = pattern.sub("<elided>", value)
            return value
        return value


def prune_transcripts(base_dir: Path, keep_last_n_runs: int) -> int:
    """Remove transcript run directories older than the newest configured runs."""
    if keep_last_n_runs < 0:
        raise ValueError("keep_last_n_runs must be >= 0")
    if not base_dir.exists():
        return 0
    run_dirs = [path for path in base_dir.iterdir() if path.is_dir()]
    run_dirs.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    removed = 0
    for old_dir in run_dirs[keep_last_n_runs:]:
        shutil.rmtree(old_dir)
        removed += 1
    return removed
