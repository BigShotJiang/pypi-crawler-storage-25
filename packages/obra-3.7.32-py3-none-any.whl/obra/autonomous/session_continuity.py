"""Hypothesis-scoped fix-worker session continuity."""

from __future__ import annotations

import hashlib
from typing import Any


def hypothesis_id_for_focus(fix_focus: str) -> str:
    """Return a stable id for the analyzer's fix-focus hypothesis."""
    normalized = " ".join((fix_focus or "").strip().lower().split())
    if not normalized:
        return ""
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def resolve_session_continuity(
    state: dict[str, Any],
    leaf: dict[str, Any],
    worker_action: dict[str, Any],
) -> tuple[str | None, bool, str]:
    """Resolve ``(session_id, resume_session, hypothesis_id)`` for a fix attempt.

    Continuity is bounded to one leaf and one analyzer hypothesis. Cross-leaf
    or cross-hypothesis session reuse is intentionally rejected so stale tool
    traces do not anchor a new investigation to a disproven root cause.
    """
    hypothesis_id = hypothesis_id_for_focus(str(worker_action.get("fix_focus", "") or ""))
    if not hypothesis_id:
        return None, False, ""
    leaf_id = str(leaf.get("leaf_id", "") or "")
    for raw_entry in reversed(list(state.get("step_fix_attempts_history") or [])):
        if not isinstance(raw_entry, dict):
            continue
        if str(raw_entry.get("leaf_id", "") or "") != leaf_id:
            continue
        if str(raw_entry.get("hypothesis_id", "") or "") != hypothesis_id:
            continue
        session_id = str(raw_entry.get("session_id", "") or "").strip()
        if session_id:
            return session_id, True, hypothesis_id
    return None, False, hypothesis_id
