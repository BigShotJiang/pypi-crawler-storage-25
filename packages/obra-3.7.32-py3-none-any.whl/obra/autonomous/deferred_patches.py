"""Deferred fix-worker patches that could not be validated in-harness."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

from obra.autonomous.validation_outcome import OUTCOME_SKIPPED, SuiteResult
from obra.hybrid.tooling_discovery import ToolingDiscovery
from obra.utils.obra_home import get_runtime_dir


class DeferredPatchStore:
    """Filesystem-backed store for confirmed-skipped worktree diffs."""

    def __init__(self, run_id: str, base_dir: Path | None = None) -> None:
        self.run_id = run_id
        self.base_dir = base_dir or (get_runtime_dir() / "simulations" / "campaign")

    def store(
        self,
        *,
        leaf_id: str,
        patch_diff: str,
        transcript_path: Path | None,
        validation_outcome: dict[str, Any],
        why: str,
    ) -> Path:
        entry_dir = self.base_dir / self.run_id / "deferred" / str(leaf_id)
        entry_dir.mkdir(parents=True, exist_ok=True)
        (entry_dir / "patch.diff").write_text(patch_diff, encoding="utf-8")
        (entry_dir / "validation_outcome.json").write_text(
            json.dumps(validation_outcome, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        (entry_dir / "why.md").write_text(why.strip() + "\n", encoding="utf-8")
        if transcript_path is not None:
            (entry_dir / "transcript_link").write_text(str(transcript_path), encoding="utf-8")
        return entry_dir

    def list_for_run(self, run_id: str | None = None) -> list[dict[str, Any]]:
        target_run_id = run_id or self.run_id
        deferred_root = self.base_dir / target_run_id / "deferred"
        if not deferred_root.exists():
            return []
        entries: list[dict[str, Any]] = []
        for leaf_dir in sorted(path for path in deferred_root.iterdir() if path.is_dir()):
            validation_path = leaf_dir / "validation_outcome.json"
            validation: dict[str, Any] = {}
            if validation_path.exists():
                try:
                    loaded = json.loads(validation_path.read_text(encoding="utf-8"))
                    if isinstance(loaded, dict):
                        validation = loaded
                except json.JSONDecodeError:
                    validation = {}
            entries.append(
                {
                    "run_id": target_run_id,
                    "leaf_id": leaf_dir.name,
                    "entry_dir": str(leaf_dir),
                    "patch_path": str(leaf_dir / "patch.diff"),
                    "validation_outcome": validation,
                    "why_path": str(leaf_dir / "why.md"),
                    "transcript_link_path": str(leaf_dir / "transcript_link"),
                }
            )
        return entries

    def prune(self, keep_last_n_runs: int = 10) -> int:
        if keep_last_n_runs < 0:
            raise ValueError("keep_last_n_runs must be >= 0")
        if not self.base_dir.exists():
            return 0
        run_dirs = [path for path in self.base_dir.iterdir() if path.is_dir()]
        run_dirs.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        removed = 0
        for old_dir in run_dirs[keep_last_n_runs:]:
            shutil.rmtree(old_dir)
            removed += 1
        return removed


def _suite_command(suite_name: str) -> list[str]:
    if suite_name.startswith("playwright:"):
        return ["npx", "playwright", "--version"]
    if suite_name == "vitest":
        return ["npx", "vitest", "--version"]
    if suite_name == "tsc":
        return ["npx", "tsc", "--version"]
    if suite_name == "pytest":
        return ["python", "-m", "pytest", "--version"]
    if suite_name == "ruff":
        return ["python", "-m", "ruff", "--version"]
    if suite_name == "mypy":
        return ["python", "-m", "mypy", "--version"]
    return [suite_name, "--version"]


def verify_tool_availability(
    suites: tuple[SuiteResult, ...],
    working_dir: Path,
    timeout_s: float,
) -> dict[str, bool]:
    """Check whether skipped-suite tools are runnable from the harness env."""
    try:
        ToolingDiscovery(working_dir, {}).discover()
    except Exception:
        pass
    results: dict[str, bool] = {}
    for suite in suites:
        if suite.outcome != OUTCOME_SKIPPED:
            continue
        try:
            completed = subprocess.run(
                _suite_command(suite.name),
                check=False,
                capture_output=True,
                text=True,
                cwd=working_dir,
                timeout=timeout_s,
            )
        except (OSError, subprocess.TimeoutExpired):
            results[suite.name] = False
            continue
        results[suite.name] = completed.returncode == 0
    return results
