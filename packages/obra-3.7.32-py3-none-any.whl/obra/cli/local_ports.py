"""Canonical local development port resolver."""

from __future__ import annotations

import argparse
import json
import os
import shlex
import socket
import subprocess
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from obra.config.loaders import get_local_port_service_catalog
from obra.exceptions import ConfigurationError
from obra.utils.obra_home import resolve_runtime_dir

FIREBASE_SERVICE_IDS = ("firebase_auth", "firestore", "functions", "emulator_ui", "hosting")
CORE_FIREBASE_SERVICE_IDS = ("firebase_auth", "firestore", "functions", "emulator_ui")
BROWSER_RIG_SERVICE_IDS = ("studio_gateway", "studio_web")
SERVICE_ORDER = (*FIREBASE_SERVICE_IDS, *BROWSER_RIG_SERVICE_IDS)
MANIFEST_VERSION = "1"


@dataclass(frozen=True)
class LocalPortServiceSpec:
    """Validated service catalog row used by the resolver."""

    service_id: str
    display_name: str
    host: str
    default_port: int
    override_env_var: str
    config_key: str
    auto_range_start: int
    auto_range_end: int
    manifest_exports: tuple[str, ...]


@dataclass(frozen=True)
class ListenerInfo:
    """Best-effort listener metadata for conflict diagnostics."""

    pid: str
    command: str


@dataclass(frozen=True)
class LocalPortDiagnostic:
    """Structured local port conflict diagnostic."""

    error_code: str
    service_id: str
    display_name: str
    host: str
    requested_port: int
    listener_pid: str | None
    listener_command: str | None
    override_env_var: str
    config_key: str
    auto_port_retry_command: str

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON/API-ready diagnostic payload."""
        return {
            "error_code": self.error_code,
            "service_id": self.service_id,
            "display_name": self.display_name,
            "host": self.host,
            "requested_port": self.requested_port,
            "listener_pid": self.listener_pid,
            "listener_command": self.listener_command,
            "override_env_var": self.override_env_var,
            "config_key": self.config_key,
            "auto_port_retry_command": self.auto_port_retry_command,
            "message": self.render(),
        }

    def render(self) -> str:
        """Return a compact terminal/frontend message."""
        listener = "unknown listener"
        if self.listener_pid or self.listener_command:
            listener = (
                f"pid {self.listener_pid or 'unknown'}"
                f" ({self.listener_command or 'command unavailable'})"
            )
        return (
            f"{self.display_name} cannot bind {self.host}:{self.requested_port}; "
            f"the port is already used by {listener}. "
            f"Set {self.override_env_var}, update {self.config_key}, or retry with "
            f"{self.auto_port_retry_command}."
        )


@dataclass(frozen=True)
class ResolvedLocalPort:
    """Resolved service listener."""

    spec: LocalPortServiceSpec
    host: str
    port: int
    source: str
    auto_selected: bool = False


class LocalPortResolutionError(RuntimeError):
    """Raised when deterministic local port resolution detects a conflict."""

    def __init__(self, diagnostic: LocalPortDiagnostic) -> None:
        super().__init__(diagnostic.render())
        self.diagnostic = diagnostic


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _dev_ports_dir() -> Path:
    path = resolve_runtime_dir().path / "dev-ports"
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    return path


def latest_manifest_path() -> Path:
    """Return the stable latest-manifest path."""
    return _dev_ports_dir() / "latest.env"


def _catalog_specs() -> tuple[bool, dict[str, LocalPortServiceSpec]]:
    catalog = get_local_port_service_catalog()
    services = catalog["services"]
    specs: dict[str, LocalPortServiceSpec] = {}
    for service_id in SERVICE_ORDER:
        raw = services[service_id]
        specs[service_id] = LocalPortServiceSpec(
            service_id=service_id,
            display_name=str(raw["display_name"]),
            host=str(raw["host"]),
            default_port=int(raw["port"]),
            override_env_var=str(raw["override_env_var"]),
            config_key=str(raw["config_key"]),
            auto_range_start=int(raw["auto_range_start"]),
            auto_range_end=int(raw["auto_range_end"]),
            manifest_exports=tuple(str(item) for item in raw["manifest_exports"]),
        )
    return bool(catalog["auto_ports_enabled"]), specs


def _parse_bool_env(value: str | None) -> bool | None:
    if value is None or not value.strip():
        return None
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ConfigurationError(f"Invalid boolean value for OBRA_LOCAL_AUTO_PORTS: {value!r}")


def _parse_port(value: str, source: str) -> int:
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"{source} must be an integer TCP port") from exc
    if not 0 < port < 65536:
        raise ConfigurationError(f"{source} must be a valid TCP port")
    return port


def _parse_host_port(value: str) -> tuple[str, int] | None:
    if ":" not in value:
        return None
    host, raw_port = value.rsplit(":", 1)
    if not host:
        return None
    try:
        return host, int(raw_port)
    except ValueError:
        return None


def _parse_url_host_port(value: str) -> tuple[str, int] | None:
    parsed = urlparse(value)
    if parsed.hostname and parsed.port:
        return parsed.hostname, parsed.port
    return None


def read_manifest(path: Path | None = None) -> dict[str, str]:
    """Read a resolver shell manifest as key/value strings."""
    manifest_path = path or latest_manifest_path()
    if not manifest_path.exists():
        return {}
    values: dict[str, str] = {}
    for raw_line in manifest_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :]
        try:
            parts = shlex.split(line, posix=True)
        except ValueError:
            continue
        if not parts or "=" not in parts[0]:
            continue
        key, value = parts[0].split("=", 1)
        values[key] = value
    return values


def _listener_pids(port: int) -> list[str]:
    try:
        result = subprocess.run(
            ["lsof", f"-tiTCP:{port}", "-sTCP:LISTEN", "-n", "-P"],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return []
    if result.returncode not in (0, 1):
        return []
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def _process_command(pid: str) -> str:
    try:
        result = subprocess.run(
            ["ps", "-p", pid, "-o", "command="],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def port_has_listener(host: str, port: int) -> bool:
    """Return whether a TCP listener occupies the target port."""
    if _listener_pids(port):
        return True
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.2)
        try:
            probe.bind((host, port))
        except OSError:
            return True
    return False


def _first_listener(port: int) -> ListenerInfo | None:
    pids = _listener_pids(port)
    if not pids:
        return None
    pid = pids[0]
    return ListenerInfo(pid=pid, command=_process_command(pid))


def _source_from_environment(spec: LocalPortServiceSpec, env: dict[str, str]) -> tuple[str, int, str] | None:
    raw_port = env.get(spec.override_env_var, "").strip()
    if raw_port:
        return spec.host, _parse_port(raw_port, spec.override_env_var), "env"

    if spec.service_id == "firestore":
        parsed = _parse_host_port(env.get("FIRESTORE_EMULATOR_HOST", "").strip())
        if parsed:
            return parsed[0], parsed[1], "env"
    if spec.service_id == "functions":
        parsed = _parse_url_host_port(env.get("OBRA_API_BASE_URL", "").strip())
        if parsed:
            return parsed[0], parsed[1], "env"
    if spec.service_id == "studio_gateway":
        parsed = _parse_url_host_port(
            env.get("OBRA_STUDIO_GATEWAY_URL", "").strip()
            or env.get("VITE_WORKFLOW_STUDIO_API_BASE_URL", "").strip()
        )
        if parsed:
            return parsed[0], parsed[1], "env"
    if spec.service_id == "studio_web":
        parsed = _parse_url_host_port(env.get("OBRA_STUDIO_WEB_URL", "").strip())
        if parsed:
            return parsed[0], parsed[1], "env"
    return None


def _source_from_manifest(spec: LocalPortServiceSpec, manifest: dict[str, str]) -> tuple[str, int, str] | None:
    if spec.service_id == "firestore":
        parsed = _parse_host_port(manifest.get("FIRESTORE_EMULATOR_HOST", ""))
        if parsed:
            return parsed[0], parsed[1], "manifest"
    if spec.service_id == "functions":
        parsed = _parse_url_host_port(manifest.get("OBRA_API_BASE_URL", ""))
        if parsed:
            return parsed[0], parsed[1], "manifest"
    if spec.service_id == "studio_gateway":
        parsed = _parse_url_host_port(
            manifest.get("OBRA_STUDIO_GATEWAY_URL", "")
            or manifest.get("VITE_WORKFLOW_STUDIO_API_BASE_URL", "")
        )
        if parsed:
            return parsed[0], parsed[1], "manifest"
    if spec.service_id == "studio_web":
        parsed = _parse_url_host_port(manifest.get("OBRA_STUDIO_WEB_URL", ""))
        if parsed:
            return parsed[0], parsed[1], "manifest"

    port_key = spec.override_env_var
    raw_port = manifest.get(port_key, "").strip()
    if raw_port:
        return spec.host, _parse_port(raw_port, port_key), "manifest"
    return None


def _auto_port_retry_command(mode: str) -> str:
    if mode == "browser-rig":
        return "./scripts/dev/start_workflow_studio_web_browser_rig.sh --auto-ports"
    return "./scripts/dev/start-emulators.sh --auto-ports"


def _conflict_diagnostic(
    spec: LocalPortServiceSpec,
    *,
    host: str,
    port: int,
    mode: str,
) -> LocalPortDiagnostic:
    listener = _first_listener(port)
    return LocalPortDiagnostic(
        error_code="local_port_unavailable",
        service_id=spec.service_id,
        display_name=spec.display_name,
        host=host,
        requested_port=port,
        listener_pid=listener.pid if listener else None,
        listener_command=listener.command if listener else None,
        override_env_var=spec.override_env_var,
        config_key=spec.config_key,
        auto_port_retry_command=_auto_port_retry_command(mode),
    )


def _select_auto_port(spec: LocalPortServiceSpec, host: str) -> int | None:
    for candidate in range(spec.auto_range_start, spec.auto_range_end + 1):
        if not port_has_listener(host, candidate):
            return candidate
    return None


def _resolve_one(
    spec: LocalPortServiceSpec,
    *,
    env: dict[str, str],
    manifest: dict[str, str],
    selected: bool,
    check_ports: bool,
    auto_ports_enabled: bool,
    mode: str,
) -> ResolvedLocalPort:
    source = _source_from_environment(spec, env)
    if source is None and not selected:
        source = _source_from_manifest(spec, manifest)
    if source is None:
        source = (spec.host, spec.default_port, "config")

    host, port, source_name = source
    if not selected or not check_ports:
        return ResolvedLocalPort(spec=spec, host=host, port=port, source=source_name)

    if not port_has_listener(host, port):
        return ResolvedLocalPort(spec=spec, host=host, port=port, source=source_name)

    if auto_ports_enabled and source_name != "env":
        auto_port = _select_auto_port(spec, host)
        if auto_port is not None:
            return ResolvedLocalPort(
                spec=spec,
                host=host,
                port=auto_port,
                source="auto",
                auto_selected=True,
            )

    raise LocalPortResolutionError(
        _conflict_diagnostic(spec, host=host, port=port, mode=mode)
    )


def _service_ids_for_mode(mode: str, *, with_hosting: bool) -> tuple[str, ...]:
    if mode == "emulators":
        return FIREBASE_SERVICE_IDS if with_hosting else CORE_FIREBASE_SERVICE_IDS
    if mode == "browser-rig":
        return BROWSER_RIG_SERVICE_IDS
    return SERVICE_ORDER


def resolve_local_ports(
    *,
    project_id: str,
    mode: str,
    with_hosting: bool = False,
    auto_ports: bool | None = None,
    check_ports: bool = True,
    env: dict[str, str] | None = None,
    manifest_path: Path | None = None,
) -> dict[str, ResolvedLocalPort]:
    """Resolve local service ports for one startup mode."""
    source_env = env or dict(os.environ)
    config_auto_enabled, specs = _catalog_specs()
    env_auto_enabled = _parse_bool_env(source_env.get("OBRA_LOCAL_AUTO_PORTS"))
    auto_ports_enabled = (
        bool(auto_ports)
        if auto_ports is not None
        else env_auto_enabled
        if env_auto_enabled is not None
        else config_auto_enabled
    )
    selected = set(_service_ids_for_mode(mode, with_hosting=with_hosting))
    manifest = read_manifest(manifest_path)
    resolved: dict[str, ResolvedLocalPort] = {}
    for service_id in SERVICE_ORDER:
        resolved[service_id] = _resolve_one(
            specs[service_id],
            env=source_env,
            manifest=manifest,
            selected=service_id in selected,
            check_ports=check_ports,
            auto_ports_enabled=auto_ports_enabled,
            mode=mode,
        )
    return resolved


def _http_url(resolved: ResolvedLocalPort) -> str:
    return f"http://{resolved.host}:{resolved.port}"


def build_api_base_url(resolved: dict[str, ResolvedLocalPort], project_id: str) -> str:
    """Build the Functions emulator base URL from resolved values."""
    functions = resolved["functions"]
    return f"{_http_url(functions)}/{project_id}/us-central1"


def _manifest_values(
    *,
    project_id: str,
    resolved: dict[str, ResolvedLocalPort],
    mode: str,
    with_hosting: bool,
    generated_firebase_config: Path | None,
) -> dict[str, str]:
    firestore = resolved["firestore"]
    functions = resolved["functions"]
    firebase_auth = resolved["firebase_auth"]
    emulator_ui = resolved["emulator_ui"]
    hosting = resolved["hosting"]
    gateway = resolved["studio_gateway"]
    web = resolved["studio_web"]
    emulator_specs = [
        f"auth:{firebase_auth.port}",
        f"firestore:{firestore.port}",
        f"functions:{functions.port}",
        f"ui:{emulator_ui.port}",
    ]
    if with_hosting:
        emulator_specs.append(f"hosting:{hosting.port}")
    values = {
        "OBRA_LOCAL_PORTS_MANIFEST_VERSION": MANIFEST_VERSION,
        "OBRA_LOCAL_PORTS_MODE": mode,
        "OBRA_LOCAL_PORTS_PROJECT_ID": project_id,
        "OBRA_LOCAL_PORTS_INCLUDE_HOSTING": "true" if with_hosting else "false",
        "OBRA_FIREBASE_EMULATOR_PROJECT_ID": project_id,
        "GOOGLE_CLOUD_PROJECT": project_id,
        "GCLOUD_PROJECT": project_id,
        "FIREBASE_AUTH_EMULATOR_HOST": f"{firebase_auth.host}:{firebase_auth.port}",
        "FIRESTORE_EMULATOR_HOST": f"{firestore.host}:{firestore.port}",
        "OBRA_API_BASE_URL": build_api_base_url(resolved, project_id),
        "OBRA_FIREBASE_AUTH_EMULATOR_URL": _http_url(firebase_auth),
        "OBRA_FIRESTORE_EMULATOR_URL": _http_url(firestore),
        "OBRA_FUNCTIONS_EMULATOR_URL": _http_url(functions),
        "OBRA_FIREBASE_EMULATOR_UI_URL": _http_url(emulator_ui),
        "OBRA_FIREBASE_HOSTING_URL": _http_url(hosting),
        "OBRA_STUDIO_GATEWAY_URL": _http_url(gateway),
        "VITE_WORKFLOW_STUDIO_API_BASE_URL": _http_url(gateway),
        "OBRA_STUDIO_WEB_URL": _http_url(web),
        "WORKFLOW_STUDIO_FRONTEND_ORIGIN": _http_url(web),
        "OBRA_FIREBASE_AUTH_PORT": str(firebase_auth.port),
        "OBRA_FIRESTORE_PORT": str(firestore.port),
        "OBRA_FUNCTIONS_PORT": str(functions.port),
        "OBRA_FIREBASE_EMULATOR_UI_PORT": str(emulator_ui.port),
        "OBRA_FIREBASE_HOSTING_PORT": str(hosting.port),
        "OBRA_STUDIO_GATEWAY_PORT": str(gateway.port),
        "OBRA_STUDIO_WEB_PORT": str(web.port),
        "OBRA_EMULATOR_PORT_SPECS": ",".join(emulator_specs),
        "OBRA_BROWSER_RIG_PORT_SPECS": f"gateway:{gateway.port},web:{web.port}",
    }
    if generated_firebase_config is not None:
        values["OBRA_FIREBASE_CONFIG_PATH"] = str(generated_firebase_config)
    return values


def _write_generated_firebase_config(
    *,
    resolved: dict[str, ResolvedLocalPort],
    with_hosting: bool,
    session_id: str,
) -> Path:
    source_path = _repo_root() / "firebase.json"
    payload = json.loads(source_path.read_text(encoding="utf-8"))
    emulators = payload.setdefault("emulators", {})
    for service_id, firebase_key in (
        ("firebase_auth", "auth"),
        ("firestore", "firestore"),
        ("functions", "functions"),
        ("emulator_ui", "ui"),
    ):
        block = emulators.setdefault(firebase_key, {})
        block["port"] = resolved[service_id].port
    if with_hosting:
        block = emulators.setdefault("hosting", {})
        block["port"] = resolved["hosting"].port
    target = _dev_ports_dir() / f"{session_id}.firebase.json"
    target.write_text(json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    return target


def _write_shell_manifest(values: dict[str, str], *, session_id: str) -> Path:
    path = _dev_ports_dir() / f"{session_id}.env"
    lines = [
        "# Generated by obra.cli.local_ports; source this file for resolved local ports.",
        f"export OBRA_LOCAL_PORT_MANIFEST={shlex.quote(str(path))}",
    ]
    for key in sorted(values):
        lines.append(f"export {key}={shlex.quote(values[key])}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    latest = latest_manifest_path()
    tmp_latest = latest.with_suffix(".tmp")
    tmp_latest.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    tmp_latest.replace(latest)
    return path


def write_resolved_manifest(
    *,
    project_id: str,
    mode: str,
    with_hosting: bool,
    resolved: dict[str, ResolvedLocalPort],
    generate_firebase_config: bool,
) -> Path:
    """Write a shell manifest and optional generated Firebase config."""
    timestamp = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%SZ")
    session_id = f"local-ports-{timestamp}-{os.getpid()}"
    firebase_config = (
        _write_generated_firebase_config(
            resolved=resolved,
            with_hosting=with_hosting,
            session_id=session_id,
        )
        if generate_firebase_config
        else None
    )
    values = _manifest_values(
        project_id=project_id,
        resolved=resolved,
        mode=mode,
        with_hosting=with_hosting,
        generated_firebase_config=firebase_config,
    )
    return _write_shell_manifest(values, session_id=session_id)


def resolve_and_write_manifest(
    *,
    project_id: str,
    mode: str,
    with_hosting: bool = False,
    auto_ports: bool | None = None,
) -> Path:
    """Resolve local ports and persist the runtime manifest."""
    resolved = resolve_local_ports(
        project_id=project_id,
        mode=mode,
        with_hosting=with_hosting,
        auto_ports=auto_ports,
    )
    return write_resolved_manifest(
        project_id=project_id,
        mode=mode,
        with_hosting=with_hosting,
        resolved=resolved,
        generate_firebase_config=mode in {"emulators", "all"},
    )


def _print_error(exc: Exception) -> int:
    if isinstance(exc, LocalPortResolutionError):
        print(exc.diagnostic.render(), file=sys.stderr)
        print(json.dumps(exc.diagnostic.to_dict(), sort_keys=True), file=sys.stderr)
        return 2
    print(str(exc), file=sys.stderr)
    return 1


def _cmd_resolve(args: argparse.Namespace) -> int:
    try:
        manifest = resolve_and_write_manifest(
            project_id=args.project_id,
            mode=args.mode,
            with_hosting=args.with_hosting,
            auto_ports=True if args.auto_ports else None,
        )
    except Exception as exc:  # pragma: no cover - exercised through shell tests
        return _print_error(exc)
    print(manifest)
    return 0


def _cmd_print_base_url(args: argparse.Namespace) -> int:
    try:
        resolved = resolve_local_ports(
            project_id=args.project_id,
            mode="emulators",
            with_hosting=args.with_hosting,
            auto_ports=False,
            check_ports=False,
            env={**os.environ, "OBRA_LOCAL_PORTS_PRINT_ONLY": "1"},
        )
    except Exception as exc:  # pragma: no cover - exercised through shell tests
        return _print_error(exc)
    print(build_api_base_url(resolved, args.project_id))
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Build the local port resolver CLI parser."""
    parser = argparse.ArgumentParser(description="Resolve Obra local development ports")
    subparsers = parser.add_subparsers(dest="command", required=True)

    resolve = subparsers.add_parser("resolve")
    resolve.add_argument("--project-id", required=True)
    resolve.add_argument("--mode", choices=("emulators", "browser-rig", "all"), default="all")
    resolve.add_argument("--with-hosting", action="store_true")
    resolve.add_argument("--auto-ports", action="store_true")
    resolve.set_defaults(func=_cmd_resolve)

    base_url = subparsers.add_parser("print-base-url")
    base_url.add_argument("--project-id", required=True)
    base_url.add_argument("--with-hosting", action="store_true")
    base_url.set_defaults(func=_cmd_print_base_url)
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
