"""Test execution agent for running project-discovered tests.

This module provides TestExecutionAgent, which executes a project-discovered
test runner synchronously and reports failures as issues.

Unlike TestingAgent (which analyzes test coverage using LLM), this agent
actually runs tests and reports concrete failures.

Checks Performed:
    - Executes the discovered project test runner
    - Parses pytest-style output for failures when present
    - Reports failed tests as issues with test name and error message
    - Supports configurable timeout

Execution Modes:
    - Synchronous: Runs pytest and waits for completion (default)
    - Asynchronous: Returns immediately with pending status (for LLM orchestration)

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/agents/testing.py (LLM-based coverage analysis)
    - BUG-76536c57: Fixed signature to match BaseAgent (llm_config parameter)
"""

import logging
import re
import shlex
import subprocess
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.api.protocol import AgentType, Priority
from obra.domains.capabilities import Capability
from obra.hybrid.tooling_discovery import ToolingDiscovery

logger = logging.getLogger(__name__)

_TEST_COMMAND_PUNCTUATION = "&|;()<>"
_UNSUPPORTED_TEST_COMMAND_TOKENS = {
    "&",
    "&&&",
    "|",
    "||",
    ";",
    "(",
    ")",
    "<",
    "<<",
    ">",
    ">>",
}


@register_agent(AgentType.TEST_EXECUTION, capabilities=[Capability.TEST_EXECUTION])
class TestExecutionAgent(BaseAgent):
    """Test execution agent that requires ``Capability.TEST_EXECUTION``.

    This agent executes the project-discovered test runner synchronously and
    reports test failures as concrete issues. It does not use LLM directly - it
    reports actual test failures.

    Execution Modes:
        - Synchronous (default): Runs the discovered test runner and waits
        - Asynchronous: Returns immediately with pending status

    Example:
        >>> agent = TestExecutionAgent(Path("/workspace"))
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     timeout_ms=60000
        ... )
        >>> for issue in result.issues:
        ...     print(f"{issue.title}: {issue.description}")
    """

    agent_type = AgentType.TEST_EXECUTION

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        domain: Any = None,
        async_mode: bool = False,
        pytest_args: list[str] | None = None,
    ) -> None:
        """Initialize test execution agent.

        Args:
            working_dir: Working directory containing tests
            llm_config: Optional LLM configuration dict (unused - test execution doesn't need LLM)
            log_event: Optional callback for event logging
            domain: Optional domain module for file filters (unused)
            async_mode: If True, returns immediately with pending status
            pytest_args: Explicit pytest arguments for legacy callers. When omitted,
                the agent resolves the project's test runner through ToolingDiscovery.

        Note:
            This agent doesn't run an LLM itself. ``llm_config`` is passed to
            ToolingDiscovery when a project-specific runner must be resolved.
        """
        super().__init__(
            working_dir,
            llm_config=llm_config,
            log_event=log_event,
            domain=domain,
        )
        self._async_mode = async_mode
        self._pytest_args_explicit = pytest_args is not None
        self._pytest_args = pytest_args or ["tests/", "-v", "--tb=short"]

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Execute project tests and report failures.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, runs all tests.
                          If provided, runs tests for specified files.
                          NOTE: This parameter is currently unused - tests run regardless.
                          Kept for BaseAgent contract compatibility.
            timeout_ms: If None, uses config-based timeout.
                       If provided, MUST be positive integer.

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed (unused - runs all tests)
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with test failure issues
        """
        if self._domain is not None and not self._domain.supports(Capability.TEST_EXECUTION):
            msg = (
                f"Domain {getattr(self._domain, 'name', '<unknown>')!r} does not "
                "support test execution"
            )
            raise RuntimeError(msg)

        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"TestExecutionAgent analyzing {item_id}")

        # Async mode: return immediately with pending status
        if self._async_mode:
            logger.info("TestExecutionAgent running in async mode (returning pending)")
            return AgentResult(
                agent_type=self.agent_type,
                status="pending",
                issues=[],
                scores={},
                execution_time_ms=0,
                metadata={
                    "mode": "async",
                    "item_id": item_id,
                },
            )

        # Synchronous mode: run the project-discovered test runner and wait
        return self._execute_pytest_sync(item_id, start_time, timeout_ms)

    def _execute_pytest_sync(
        self,
        _item_id: str,
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Execute the resolved test runner synchronously and parse results.

        Args:
            item_id: Plan item ID
            start_time: Analysis start time
            timeout_ms: Maximum execution time in milliseconds

        Returns:
            AgentResult with issues from test failures
        """
        timeout_s = timeout_ms / 1000
        try:
            resolved_command = self._resolve_test_command()
        except ValueError as exc:
            execution_time = int((time.time() - start_time) * 1000)
            return AgentResult(
                agent_type=self.agent_type,
                status="error",
                issues=[],
                scores={},
                execution_time_ms=execution_time,
                error=f"Invalid test runner command: {exc}",
                metadata={"mode": "sync"},
            )
        if resolved_command is None:
            return self._tooling_unavailable_result(
                start_time,
                detected_stack=None,
                reason="No project test runner was discovered.",
            )
        commands, display_command, command_source, detected_stack = resolved_command

        logger.info("Running test command from %s: %s", command_source, display_command)
        logger.debug(f"Timeout: {timeout_s}s")

        try:
            result: subprocess.CompletedProcess[str] | None = None
            stdout_fragments: list[str] = []
            stderr_fragments: list[str] = []
            for command_argv in commands:
                # MONITORING EXEMPTION: Test execution with explicit timeout
                result = subprocess.run(
                    list(command_argv),
                    check=False,
                    cwd=self._working_dir,
                    capture_output=True,
                    text=True,
                    timeout=timeout_s,
                )
                stdout_fragments.append(result.stdout or "")
                stderr_fragments.append(result.stderr or "")
                if result.returncode != 0:
                    break

            if result is None:
                return self._tooling_unavailable_result(
                    start_time,
                    detected_stack=detected_stack,
                    reason="Resolved test runner command contained no executable steps.",
                )

            execution_time = int((time.time() - start_time) * 1000)
            stdout = "\n".join(stdout_fragments)
            stderr = "\n".join(stderr_fragments)

            # Parse pytest output for failures
            issues = self._parse_pytest_output(stdout, stderr)

            # Success if no failures
            if result.returncode == 0:
                logger.info(f"All tests passed ({execution_time}ms)")
                return AgentResult(
                    agent_type=self.agent_type,
                    status="complete",
                    issues=[],
                    scores={"tests_passed": 1.0},
                    execution_time_ms=execution_time,
                    metadata={
                        "mode": "sync",
                        "command": display_command,
                        "command_source": command_source,
                        "detected_stack": detected_stack,
                        "exit_code": 0,
                        "tests_passed": True,
                    },
                )

            # Tests failed - return issues
            logger.info(f"Found {len(issues)} test failures ({execution_time}ms)")
            return AgentResult(
                agent_type=self.agent_type,
                status="complete",
                issues=issues,
                scores={"tests_passed": 0.0},
                execution_time_ms=execution_time,
                metadata={
                    "mode": "sync",
                    "command": display_command,
                    "command_source": command_source,
                    "detected_stack": detected_stack,
                    "exit_code": result.returncode,
                    "tests_passed": False,
                    "failure_count": len(issues),
                },
            )

        except subprocess.TimeoutExpired:
            execution_time = int((time.time() - start_time) * 1000)
            logger.warning("Test command timed out after %ss: %s", timeout_s, display_command)
            return AgentResult(
                agent_type=self.agent_type,
                status="timeout",
                issues=[],
                scores={},
                execution_time_ms=execution_time,
                error="Test runner execution timed out",
                metadata={
                    "mode": "sync",
                    "command": display_command,
                    "command_source": command_source,
                    "detected_stack": detected_stack,
                    "timeout_ms": timeout_ms,
                },
            )

        except FileNotFoundError as exc:
            missing_executable = getattr(exc, "filename", None)
            logger.info(
                "Test command unavailable: %s",
                missing_executable or display_command,
            )
            return self._tooling_unavailable_result(
                start_time,
                detected_stack=detected_stack,
                reason="Resolved test runner command is not available on PATH.",
                command=display_command,
                command_source=command_source,
                missing_executable=str(missing_executable or ""),
            )

        except Exception as e:
            execution_time = int((time.time() - start_time) * 1000)
            logger.exception(f"Test runner execution failed: {e}")
            return AgentResult(
                agent_type=self.agent_type,
                status="error",
                issues=[],
                scores={},
                execution_time_ms=execution_time,
                error=f"Test runner execution failed: {e}",
                metadata={
                    "mode": "sync",
                    "command": display_command,
                    "command_source": command_source,
                    "detected_stack": detected_stack,
                },
            )

    def _resolve_test_command(
        self,
    ) -> tuple[tuple[tuple[str, ...], ...], str, str, str | None] | None:
        """Resolve the concrete test command to run."""
        if self._pytest_args_explicit:
            command = ("pytest", *self._pytest_args)
            return ((command,), shlex.join(command), "explicit_pytest_args", None)

        discovery = ToolingDiscovery(self._working_dir, self._llm_config or {})
        tooling = discovery.discover()
        command = self._test_command_from_tooling(tooling)
        if not command:
            tooling = discovery.discover_fast()
            command = self._test_command_from_tooling(tooling)
        if not command:
            return None

        commands = self._split_test_command_sequence(command)
        display = " && ".join(shlex.join(command_argv) for command_argv in commands)
        return (
            commands,
            display,
            self._test_command_source(tooling),
            self._detected_stack(tooling),
        )

    @staticmethod
    def _test_command_from_tooling(tooling: dict[str, Any] | None) -> str | None:
        if not isinstance(tooling, dict):
            return None
        verification = tooling.get("verification")
        if not isinstance(verification, dict):
            return None
        test_entry = verification.get("test")
        if not isinstance(test_entry, dict):
            return None
        command = test_entry.get("command")
        if not isinstance(command, str):
            return None
        command = command.strip()
        return command or None

    @staticmethod
    def _test_command_source(tooling: dict[str, Any] | None) -> str:
        if not isinstance(tooling, dict):
            return "tooling_discovery"
        verification = tooling.get("verification")
        test_entry = verification.get("test") if isinstance(verification, dict) else None
        if isinstance(test_entry, dict):
            source = str(test_entry.get("discovery_source") or "").strip()
            if source:
                return f"tooling_discovery:{source}"
        meta = tooling.get("_meta")
        if isinstance(meta, dict):
            source = str(meta.get("source") or meta.get("discovery_method") or "").strip()
            if source:
                return f"tooling_discovery:{source}"
        return "tooling_discovery"

    @staticmethod
    def _detected_stack(tooling: dict[str, Any] | None) -> str | None:
        if not isinstance(tooling, dict):
            return None
        languages = tooling.get("languages")
        if not isinstance(languages, dict):
            return None
        primary = str(languages.get("primary") or "").strip()
        if not primary or primary.lower() == "unknown":
            return None
        return primary

    @staticmethod
    def _split_test_command_sequence(command: str) -> tuple[tuple[str, ...], ...]:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=_TEST_COMMAND_PUNCTUATION)
        lexer.whitespace_split = True
        lexer.commenters = ""
        tokens = list(lexer)
        if not tokens:
            raise ValueError("test command is empty after parsing")

        commands: list[tuple[str, ...]] = []
        current: list[str] = []
        for token in tokens:
            if token == "&&":
                if not current:
                    raise ValueError("test command has an empty step around '&&'")
                commands.append(tuple(current))
                current = []
                continue
            if token in _UNSUPPORTED_TEST_COMMAND_TOKENS:
                raise ValueError(
                    f"unsupported shell syntax {token!r}; only '&&' command chains are allowed"
                )
            current.append(token)
        if not current:
            raise ValueError("test command cannot end with '&&'")
        commands.append(tuple(current))
        return tuple(commands)

    def _tooling_unavailable_result(
        self,
        start_time: float,
        *,
        detected_stack: str | None,
        reason: str,
        command: str | None = None,
        command_source: str | None = None,
        missing_executable: str | None = None,
    ) -> AgentResult:
        execution_time = int((time.time() - start_time) * 1000)
        metadata: dict[str, Any] = {
            "mode": "sync",
            "skip_reason": "tooling_unavailable",
            "skip_classification": "expected_no_tooling",
            "detected_stack": detected_stack,
            "reason": reason,
        }
        if command:
            metadata["command"] = command
        if command_source:
            metadata["command_source"] = command_source
        if missing_executable:
            metadata["missing_executable"] = missing_executable
        return AgentResult(
            agent_type=self.agent_type,
            status="skipped",
            issues=[],
            scores={},
            execution_time_ms=execution_time,
            metadata=metadata,
        )

    def _parse_pytest_output(self, stdout: str, stderr: str) -> list[AgentIssue]:
        """Parse pytest output to extract test failures.

        Parses pytest verbose output format to extract:
        - Test name (file::class::method or file::function)
        - Error message
        - File path and line number

        Args:
            stdout: Pytest stdout output
            stderr: Pytest stderr output

        Returns:
            List of AgentIssue objects for each failed test
        """
        issues: list[AgentIssue] = []

        # Combine stdout and stderr for parsing
        full_output = stdout + "\n" + stderr

        # Pattern for pytest failure lines: "FAILED tests/test_foo.py::test_bar - AssertionError: ..."
        # Also handles: "FAILED tests/test_foo.py::TestClass::test_method - ..."
        # Capture file path (stop at first ::), then everything until " - ", then error message
        failure_pattern = re.compile(
            r"FAILED\s+([^:]+\.\w+)::(.*?)\s+-\s+(.+?)(?=\nFAILED|\n={3,}|$)",
            re.DOTALL,
        )

        matches = failure_pattern.findall(full_output)
        for idx, (file_path, test_name, error_msg) in enumerate(matches):
            # Clean up error message (remove leading/trailing whitespace)
            error_msg = error_msg.strip()

            # Extract just the error summary (first line usually)
            error_summary = error_msg.split("\n")[0][:200]

            issues.append(
                AgentIssue(
                    id=self._generate_issue_id("TEST", idx + 1),
                    title=f"Test failure: {test_name}",
                    description=f"Test {test_name} failed with:\n{error_summary}",
                    priority=Priority.P1,  # Test failures are high priority
                    file_path=file_path,
                    line_number=None,  # pytest doesn't always include line numbers
                    dimension="test_execution",
                    suggestion=f"Fix the failing test in {file_path}::{test_name}",
                    metadata={
                        "test_name": test_name,
                        "full_error": error_msg[:1000],  # Truncate for storage
                    },
                )
            )

        return issues


__all__ = ["TestExecutionAgent"]
