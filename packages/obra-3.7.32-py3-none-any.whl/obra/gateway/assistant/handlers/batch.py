"""Atomic batch workflow mutation handlers for the studio assistant."""

from __future__ import annotations

import copy
import logging
from collections.abc import Callable
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.adapter_runtime import apply_workflow_candidate_via_adapter
from obra.gateway.assistant.handlers.metadata import apply_metadata_updates_to_candidate
from obra.gateway.assistant.handlers.quality_gate import (
    apply_quality_gate_to_candidate,
    build_quality_loop_payload,
)
from obra.gateway.assistant.handlers.structural import (
    apply_stage_update_to_candidate,
    connect_stages_in_candidate,
    disconnect_stages_in_candidate,
    insert_stage_into_candidate,
    remove_stage_from_candidate,
)
from obra.gateway.assistant.handlers.template_edit import apply_template_update_to_candidate
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.gateway.workflow_studio.workflow_actions import canonical_sync_fields
from obra.workflow.stage_instruction_assets import (
    PendingStageInstructionAssetWrite,
    canonicalize_template_role,
    commit_pending_stage_instruction_asset_writes,
)
from obra.workflow.template_asset_store import TemplateAssetStore

OperationApplyResult = (
    dict[str, Any] | tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]
)

logger = logging.getLogger(__name__)

_SUPPORTED_OPERATIONS = {
    "insert_stage",
    "remove_stage",
    "connect",
    "disconnect",
    "update_stage",
    "update_workflow_metadata",
    "set_quality_gate",
    "edit_template",
}


def _batch_insert_stage(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    stage_definition = operation.get("stage_definition")
    if not isinstance(stage_definition, dict) or not stage_definition:
        raise ValueError("insert_stage requires stage_definition.")
    insert_stage_into_candidate(
        candidate,
        after_stage_id=operation.get("after_stage_id"),
        stage_definition=stage_definition,
    )
    return {"operation": operation_name, "stage_definition": stage_definition}


def _batch_remove_stage(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    stage_id = str(operation.get("stage_id") or "").strip()
    if not stage_id:
        raise ValueError("remove_stage requires stage_id.")
    remove_stage_from_candidate(candidate, stage_id)
    return {"operation": operation_name, "stage_id": stage_id}


def _batch_connect(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    source_stage_id = str(operation.get("source_stage_id") or "").strip()
    target_stage_id = str(operation.get("target_stage_id") or "").strip()
    if not source_stage_id or not target_stage_id:
        raise ValueError("connect requires source_stage_id and target_stage_id.")
    connect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
    return {
        "operation": operation_name,
        "source_stage_id": source_stage_id,
        "target_stage_id": target_stage_id,
    }


def _batch_disconnect(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    source_stage_id = str(operation.get("source_stage_id") or "").strip()
    target_stage_id = str(operation.get("target_stage_id") or "").strip()
    if not source_stage_id or not target_stage_id:
        raise ValueError("disconnect requires source_stage_id and target_stage_id.")
    disconnect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
    return {
        "operation": operation_name,
        "source_stage_id": source_stage_id,
        "target_stage_id": target_stage_id,
    }


def _batch_update_stage(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    stage_id = str(operation.get("stage_id") or "").strip()
    updates = operation.get("updates")
    remove_fields = operation.get("remove_fields")
    normalized_updates = updates if isinstance(updates, dict) else {}
    if not stage_id:
        raise ValueError("update_stage requires stage_id.")
    if not isinstance(normalized_updates, dict):
        raise ValueError("update_stage updates must be an object.")
    if remove_fields is not None and not isinstance(remove_fields, list):
        raise ValueError("remove_fields must be an array.")
    if not normalized_updates and not remove_fields:
        raise ValueError(f"No workflow changes to apply for {operation_name}:{stage_id}.")
    apply_stage_update_to_candidate(
        candidate,
        stage_id,
        normalized_updates,
        remove_fields=remove_fields if isinstance(remove_fields, list) else None,
    )
    payload = {
        "operation": operation_name,
        "stage_id": stage_id,
        "updates": dict(normalized_updates),
    }
    if isinstance(remove_fields, list):
        payload["remove_fields"] = list(remove_fields)
    return payload


def _batch_update_workflow_metadata(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    updates = operation.get("updates")
    if not isinstance(updates, dict):
        raise ValueError("update_workflow_metadata requires updates.")
    normalized_updates = apply_metadata_updates_to_candidate(candidate, updates)
    return {"operation": operation_name, "updates": normalized_updates}


def _batch_edit_template(
    candidate: dict[str, Any],
    operation: dict[str, Any],
    operation_name: str,
    *,
    store: TemplateAssetStore,
    author_id: str,
) -> tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]:
    stage_id = str(operation.get("stage_id") or "").strip()
    template_role = canonicalize_template_role(str(operation.get("template_role") or "purpose"))
    proposed_content = str(operation.get("proposed_content") or "")
    if not stage_id or not proposed_content.strip():
        raise ValueError("edit_template requires stage_id and proposed_content.")
    pending_writes = apply_template_update_to_candidate(
        candidate,
        stage_id,
        template_role,
        proposed_content,
        store=store,
        author_id=author_id,
    )
    return {
        "operation": operation_name,
        "stage_id": stage_id,
        "template_role": template_role,
        "proposed_content": proposed_content,
    }, pending_writes


def _batch_set_quality_gate(
    candidate: dict[str, Any], operation: dict[str, Any], operation_name: str
) -> dict[str, Any]:
    stage_id = str(operation.get("stage_id") or "").strip()
    if not stage_id:
        raise ValueError("set_quality_gate requires stage_id.")
    quality_loop = operation.get("quality_loop")
    if not isinstance(quality_loop, dict):
        quality_loop = build_quality_loop_payload(
            candidate,
            stage_id=stage_id,
            loop_back_to=str(operation.get("loop_back_to") or "").strip() or None,
            evaluators=operation.get("evaluators"),
            thresholds=operation.get("thresholds"),
        )
    apply_quality_gate_to_candidate(candidate, stage_id, quality_loop)
    return {"operation": operation_name, "stage_id": stage_id, "quality_loop": quality_loop}


_OPERATION_DISPATCH: dict[
    str,
    Callable[[dict[str, Any], dict[str, Any], str], OperationApplyResult],
] = {
    "insert_stage": _batch_insert_stage,
    "remove_stage": _batch_remove_stage,
    "connect": _batch_connect,
    "disconnect": _batch_disconnect,
    "update_stage": _batch_update_stage,
    "update_workflow_metadata": _batch_update_workflow_metadata,
    "set_quality_gate": _batch_set_quality_gate,
}


def normalize_batch_operation(candidate: dict[str, Any], operation: dict[str, Any]) -> dict[str, Any]:
    operation_name = str(operation.get("operation") or operation.get("op") or "").strip()
    if not operation_name:
        raise ValueError("Batch operations must declare operation.")
    if operation_name not in _SUPPORTED_OPERATIONS:
        raise ValueError(f"Unsupported batch operation: {operation_name}")
    if operation_name == "edit_template":
        return {
            "operation": operation_name,
            "stage_id": str(operation.get("stage_id") or "").strip(),
            "template_role": canonicalize_template_role(
                str(operation.get("template_role") or "purpose")
            ),
            "proposed_content": str(operation.get("proposed_content") or ""),
        }
    handler = _OPERATION_DISPATCH[operation_name]
    result = handler(candidate, operation, operation_name)
    if isinstance(result, tuple):
        normalized, _pending_writes = result
        return normalized
    return result


def _normalize_operation_with_pending(
    candidate: dict[str, Any],
    operation: dict[str, Any],
    *,
    store: TemplateAssetStore,
    author_id: str,
) -> tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]:
    operation_name = str(operation.get("operation") or operation.get("op") or "").strip()
    if not operation_name:
        raise ValueError("Batch operations must declare operation.")
    if operation_name not in _SUPPORTED_OPERATIONS:
        raise ValueError(f"Unsupported batch operation: {operation_name}")
    result: OperationApplyResult
    if operation_name == "edit_template":
        result = _batch_edit_template(
            candidate,
            operation,
            operation_name,
            store=store,
            author_id=author_id,
        )
    else:
        handler = _OPERATION_DISPATCH[operation_name]
        result = handler(candidate, operation, operation_name)
    if isinstance(result, tuple):
        normalized, pending_writes = result
        return normalized, list(pending_writes)
    return result, []


def _simulate_batch(
    workflow: dict[str, Any],
    operations: list[dict[str, Any]],
    *,
    store: TemplateAssetStore,
    author_id: str,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[PendingStageInstructionAssetWrite]]:
    candidate = copy.deepcopy(workflow)
    normalized_operations: list[dict[str, Any]] = []
    pending_asset_writes: list[PendingStageInstructionAssetWrite] = []
    for operation in operations:
        if not isinstance(operation, dict):
            raise ValueError("Batch operations must be objects.")
        normalized, pending_writes = _normalize_operation_with_pending(
            candidate,
            operation,
            store=store,
            author_id=author_id,
        )
        normalized_operations.append(normalized)
        pending_asset_writes.extend(pending_writes)
    return candidate, normalized_operations, pending_asset_writes


def propose_batch(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose one atomic batch of workflow mutations."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    operations = inputs.get("operations")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not isinstance(operations, list) or not operations:
        return {"outcome": "invalid", "detail": "Batch mutation requires at least one operation."}

    try:
        store = resolve_template_asset_store(ctx.app_state, project_root=ctx.project_root)
        _, normalized_operations, pending_writes = _simulate_batch(
            workflow,
            operations,
            store=store,
            author_id=ctx.user_id or "assistant",
        )
        _release_reserved_stage_instruction_writes(pending_writes, store)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    return build_proposal_record(
        action_id="execute_batch_mutation",
        action_type="propose_batch_mutation",
        action_inputs={
            "workflow_id": wf_id,
            "operations": normalized_operations,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        workflow_id=wf_id,
        operations=normalized_operations,
        operation_count=len(normalized_operations),
    )


def execute_batch(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply one atomic batch of workflow mutations."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    operations = inputs.get("operations")
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not isinstance(operations, list) or not operations:
        return {"outcome": "invalid", "detail": "Batch mutation requires at least one operation."}

    try:
        store = resolve_template_asset_store(ctx.app_state, project_root=ctx.project_root)
        candidate, _, pending_asset_writes = _simulate_batch(
            workflow,
            operations,
            store=store,
            author_id=ctx.user_id or "assistant",
        )
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = apply_workflow_candidate_via_adapter(
        ctx,
        workflow_id=wf_id,
        candidate=candidate,
        expected_revision_id=expected_revision_id,
        action_name="assistant_batch_mutation_apply",
        prompt="Validate this accepted Studio atomic batch workflow candidate.",
        pending_stage_instruction_writes=pending_asset_writes,
    )
    outcome = result.get("outcome", "")
    if outcome == "conflict":
        _release_reserved_stage_instruction_writes(pending_asset_writes, store)
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
            **canonical_sync_fields(result),
        }
    if outcome == "invalid":
        _release_reserved_stage_instruction_writes(pending_asset_writes, store)
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
            **canonical_sync_fields(result),
        }
    committed_assets = []
    if pending_asset_writes:
        logger.info(
            "Applying Studio batch template asset writes",
            extra={
                "workflow_id": wf_id,
                "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                "stage_ids": [write.stage_id for write in pending_asset_writes],
                "write_count": len(pending_asset_writes),
            },
        )
        try:
            committed_assets = commit_pending_stage_instruction_asset_writes(
                pending_asset_writes,
                store,
                author_id=ctx.user_id or "assistant",
            )
        except Exception:
            logger.exception(
                "Failed applying Studio batch template asset writes",
                extra={
                    "workflow_id": wf_id,
                    "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                    "stage_ids": [write.stage_id for write in pending_asset_writes],
                    "write_count": len(pending_asset_writes),
                },
            )
            raise
        logger.info(
            "Applied Studio batch template asset writes",
            extra={
                "workflow_id": wf_id,
                "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                "committed_asset_count": len(committed_assets),
                "stage_ids": [str(asset.get("stage_id") or "") for asset in committed_assets],
            },
        )
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
        "template_assets": committed_assets,
        **canonical_sync_fields(result),
    }


def _release_reserved_stage_instruction_writes(
    writes: list[PendingStageInstructionAssetWrite],
    store: TemplateAssetStore,
) -> None:
    for write in writes:
        if write.reservation_id:
            store.release_reserved_revision(write.reservation_id)
