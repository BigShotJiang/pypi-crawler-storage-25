"""Restart workflow handler — replace an existing workflow from a scaffold."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.adapter_runtime import run_derive_quality_gate_via_adapter
from obra.gateway.assistant.handlers.draft import _resolve_domain_id
from obra.gateway.workflow_studio.workflow_actions import canonical_sync_fields


def _current_head_revision_id(workflow: dict[str, Any]) -> str:
    return str(
        workflow.get("head_revision_id")
        or workflow.get("latest_revision_id")
        or workflow.get("revision_id")
        or ""
    ).strip()


def _apply_result_to_action_response(
    result: dict[str, Any],
    *,
    workflow_id: str,
) -> dict[str, Any]:
    outcome = str(result.get("outcome") or "").strip().lower()
    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": workflow_id,
            **canonical_sync_fields(result),
        }
    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": workflow_id,
            **canonical_sync_fields(result),
        }
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": workflow_id,
        **canonical_sync_fields(result),
    }


def execute_restart(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: replace an existing workflow head from a scaffold definition."""
    wf_id = str(workflow_id or inputs.get("workflow_id") or "").strip()
    if not wf_id:
        return {"outcome": "invalid", "detail": "workflow_id not found"}

    current = ctx.repository.get_workflow(wf_id)
    if current is None:
        return {"outcome": "invalid", "detail": "workflow_id not found"}
    current_head_revision_id = _current_head_revision_id(current)
    if not current_head_revision_id:
        return {"outcome": "invalid", "detail": "workflow_id not found"}

    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})
    stages = scaffold_definition.get("stages", [])
    if not stages:
        return {"outcome": "invalid", "detail": "scaffold_definition must have at least one stage"}
    title = str(scaffold_definition.get("title") or "").strip()
    if not title:
        return {"outcome": "invalid", "detail": "scaffold_definition must have a title"}

    domain_id = _resolve_domain_id(
        inputs,
        scaffold_definition,
        ctx=ctx,
        source="restart_workflow_execute",
    )
    workflow_definition = {
        **dict(scaffold_definition),
        "workflow_id": wf_id,
        "domain_id": domain_id,
    }
    payload: dict[str, Any] = {
        "workflow_id": wf_id,
        "title": title,
        "domain_id": domain_id,
        "workflow_definition": workflow_definition,
    }
    if scaffold_definition.get("description"):
        payload["description"] = str(scaffold_definition.get("description") or "")

    run_derive_quality_gate_via_adapter(
        ctx,
        action_name="execute_restart_workflow_from_thread",
        inputs=inputs,
        objective=str(
            inputs.get("objective")
            or scaffold_definition.get("description")
            or scaffold_definition.get("title")
            or ""
        ),
    )

    result = ctx.action_service.apply_workflow(
        workflow_id=wf_id,
        candidate=payload,
        expected_revision_id=str(
            inputs.get("expected_revision_id") or current_head_revision_id
        ),
    )
    return _apply_result_to_action_response(result, workflow_id=wf_id)
