"""Helpers for consistent assistant proposal records."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_registry import V1_ACTIONS


def build_proposal_record(
    *,
    action_id: str,
    action_type: str,
    action_inputs: dict[str, Any],
    preview_type: str | None = None,
    proposal_group: str | None = None,
    **fields: Any,
) -> dict[str, Any]:
    """Return a normalized proposal record payload."""
    record: dict[str, Any] = {
        "action_id": action_id,
        "action_type": action_type,
        "action_inputs": action_inputs,
        "status": "pending",
    }
    if preview_type:
        record["preview_type"] = preview_type
    if proposal_group:
        record["proposal_group"] = proposal_group
    action = V1_ACTIONS.get(action_id)
    if action is not None and action.command is not None:
        record["command"] = action.command.to_dict()
    record.update(fields)
    return record
