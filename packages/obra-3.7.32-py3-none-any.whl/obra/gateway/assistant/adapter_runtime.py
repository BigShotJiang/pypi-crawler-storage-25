"""Runtime primitives shared by assistant mutation adapters."""

from __future__ import annotations

import threading
from collections.abc import Iterator
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from typing import Any

_LOCKS_GUARD = threading.RLock()
_WORKFLOW_LOCKS: dict[str, threading.RLock] = {}


def _normalize_workflow_id(workflow_id: str | None) -> str:
    normalized = str(workflow_id or "").strip()
    return normalized or "__workflow_unscoped__"


def workflow_apply_lock(workflow_id: str | None) -> threading.RLock:
    """Return the process-local apply lock for one workflow identifier."""
    normalized = _normalize_workflow_id(workflow_id)
    with _LOCKS_GUARD:
        lock = _WORKFLOW_LOCKS.get(normalized)
        if lock is None:
            lock = threading.RLock()
            _WORKFLOW_LOCKS[normalized] = lock
        return lock


@contextmanager
def workflow_apply_critical_section(workflow_id: str | None) -> Iterator[None]:
    """Serialize candidate apply/create work for one workflow."""
    lock = workflow_apply_lock(workflow_id)
    with lock:
        yield


def adapter_working_dir(ctx: Any) -> Path:
    """Return the working directory for a gateway assistant adapter."""
    working_dir = getattr(ctx, "adapter_working_dir", None) or getattr(ctx, "project_root", None)
    if working_dir is None:
        return Path.cwd()
    return Path(working_dir)


def adapter_session_id(ctx: Any) -> str | None:
    """Return the session id passed to TemplateEditPipeline."""
    session_id = str(getattr(ctx, "adapter_session_id", "") or "").strip()
    return session_id or None


_CANDIDATE_SCHEMA_DIRECTIVE = (
    'Return JSON with this exact shape: {"candidate": {"workflow_id": <string>, '
    '"title": <string>, "domain_id": <string>, '
    '"workflow_definition": <object with stages list>}}. Preserve every input '
    "field unchanged unless this prompt explicitly supplies a corrected value."
)


def _compose_schema_aware_prompt(prompt: str) -> str:
    """Append the candidate envelope schema to a gateway adapter prompt."""
    normalized = str(prompt or "").strip()
    if _CANDIDATE_SCHEMA_DIRECTIVE in normalized:
        return normalized
    if not normalized:
        return _CANDIDATE_SCHEMA_DIRECTIVE
    return f"{normalized}\n\n{_CANDIDATE_SCHEMA_DIRECTIVE}"


def _public_adapter_fields(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        str(key): deepcopy(value)
        for key, value in payload.items()
        if isinstance(key, str) and key and not key.startswith("_")
    }


def _build_adapter_payload(
    *,
    workflow_id: str,
    candidate: dict[str, Any],
    template_content: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the flat candidate payload seen by the adapter LLM.

    The LLM input never includes a nested input-side ``candidate`` key.  Explicit
    template content may carry context fields such as ``stage_id`` and
    ``template_role``; those are preserved, while ``template_content["candidate"]``
    is flattened into the top-level workflow envelope.
    """
    fallback_candidate = _public_adapter_fields(candidate)
    payload: dict[str, Any] = {"workflow_id": workflow_id, **fallback_candidate}
    if not isinstance(template_content, dict):
        return payload

    template_payload = _public_adapter_fields(template_content)
    explicit_candidate = template_payload.pop("candidate", None)
    if isinstance(explicit_candidate, dict):
        payload = {
            **template_payload,
            **_public_adapter_fields(explicit_candidate),
        }
    else:
        payload = {
            **template_payload,
            **fallback_candidate,
        }
    payload["workflow_id"] = str(
        payload.get("workflow_id")
        or workflow_id
        or fallback_candidate.get("workflow_id")
        or ""
    )
    return payload


def _candidate_envelope_is_valid(envelope: dict[str, Any]) -> bool:
    """Return whether an adapter candidate has the engine-required shape."""
    if "candidate" in envelope:
        return False
    workflow_definition = envelope.get("workflow_definition")
    if not isinstance(workflow_definition, dict):
        return False
    stages = workflow_definition.get("stages")
    return isinstance(stages, list) and bool(stages)


def run_candidate_adapter_pipeline(
    ctx: Any,
    *,
    action_name: str,
    workflow_id: str,
    prompt: str,
    candidate: dict[str, Any],
    template_content: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate a workflow candidate through the gateway-callable pipeline.

    The adapter owns construction of Python objects such as pending asset
    writes. The pipeline boundary receives a flat JSON workflow candidate plus
    optional context fields and returns ``{"candidate": <flat candidate>}``,
    preserving the existing gateway response contract while routing proposal
    applies through the shared LLM JSON machinery.
    """
    fallback_candidate = deepcopy(candidate)
    if getattr(ctx, "app_state", None) is None:
        _emit_adapter_pipeline_events(ctx, action_name, workflow_id, "completed", fallback=True)
        return fallback_candidate

    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.assistant.pipelines.llm import build_pipeline_llm_config
    from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline

    payload = _build_adapter_payload(
        workflow_id=workflow_id,
        candidate=fallback_candidate,
        template_content=template_content,
    )

    def validator(data: dict | str) -> tuple[bool, str | None]:
        if not isinstance(data, dict):
            return False, "Adapter candidate output must be an object."
        output_candidate = data.get("candidate")
        if not isinstance(output_candidate, dict):
            return False, "Adapter candidate output must include candidate object."
        if "candidate" in output_candidate:
            return False, "Adapter candidate output must not nest a candidate key."
        workflow_definition = output_candidate.get("workflow_definition")
        if not isinstance(workflow_definition, dict):
            return False, "Adapter candidate must include workflow_definition object."
        stages = workflow_definition.get("stages")
        if not isinstance(stages, list) or not stages:
            return (
                False,
                "Adapter candidate workflow_definition.stages must be a non-empty list.",
            )
        return True, None

    def fallback() -> dict[str, Any]:
        return {"candidate": fallback_candidate}

    log_event = getattr(ctx, "log_event", None)
    _emit(log_event, "pipeline_started", pipeline_id=action_name, workflow_id=workflow_id)
    _emit(log_event, "step_started", step_id=action_name, status="running")
    cancellation_event = getattr(ctx, "adapter_cancellation_event", None)
    if getattr(cancellation_event, "is_set", lambda: False)():
        _emit(log_event, "pipeline_cancelled", pipeline_id=action_name, status="cancelled")
        return fallback_candidate

    from obra.gateway.workflow_studio.assistant_stub_responses import (
        is_browser_rig_stub_mount_enabled,
        is_stub_enabled,
    )

    if is_stub_enabled() and is_browser_rig_stub_mount_enabled():
        _emit(
            log_event,
            "asst.pipeline_step_stub",
            action_name=action_name,
            stub=True,
        )
        _emit(log_event, "step_completed", step_id=action_name, status="completed", output={})
        _emit(log_event, "pipeline_done", pipeline_id=action_name, status="completed", proposal_count=0)
        return fallback_candidate

    pipeline = build_preexecution_pipeline(
        working_dir=adapter_working_dir(ctx),
        action_name=action_name,
        log_event=log_event,
        cancellation_event=cancellation_event,
        session_id=adapter_session_id(ctx),
    )
    assistant_config = get_gateway_assistant_config()["pipelines"]
    result, _metadata = pipeline.execute(
        base_prompt=_compose_schema_aware_prompt(prompt),
        template_content=payload,
        validator=validator,
        fallback_fn=fallback,
        llm_config=build_pipeline_llm_config(ctx.app_state),
        timeout_s=int(assistant_config["per_step_timeout_budget_s"]),
        allow_unchanged=False,
        # Workflow candidates intentionally carry domain-specific extension
        # fields. Provider-native strict schemas cannot express that open
        # envelope without rejecting current OpenAI/Codex structured output
        # validation, so this adapter relies on the prompt, parser, validator,
        # retry loop, and fallback for shape safety.
        output_schema=None,
    )
    _emit(log_event, "step_completed", step_id=action_name, status="completed", output={})
    _emit(log_event, "pipeline_done", pipeline_id=action_name, status="completed", proposal_count=0)
    result_candidate = result.get("candidate") if isinstance(result, dict) else None
    if not isinstance(result_candidate, dict) or not _candidate_envelope_is_valid(
        result_candidate
    ):
        return fallback_candidate
    return deepcopy(result_candidate)


def apply_workflow_candidate_via_adapter(
    ctx: Any,
    *,
    workflow_id: str,
    candidate: dict[str, Any],
    expected_revision_id: str | None,
    action_name: str,
    prompt: str,
    pending_stage_instruction_writes: list[Any] | None = None,
    template_content: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run candidate JSON through the adapter pipeline, then apply it."""
    adapted_candidate = run_candidate_adapter_pipeline(
        ctx,
        action_name=action_name,
        workflow_id=workflow_id,
        prompt=prompt,
        candidate=candidate,
        template_content=template_content,
    )
    with workflow_apply_critical_section(workflow_id):
        return ctx.action_service.apply_workflow(
            workflow_id,
            adapted_candidate,
            expected_revision_id=expected_revision_id,
            pending_stage_instruction_writes=pending_stage_instruction_writes,
        )


def create_workflow_via_adapter(
    ctx: Any,
    *,
    workflow_id: str | None,
    candidate: dict[str, Any],
    action_name: str,
    prompt: str,
    pending_stage_instruction_writes: list[Any] | None = None,
) -> dict[str, Any]:
    """Run a new workflow candidate through the adapter pipeline, then create it.

    Per ADR-115, the canonical mutation engine owns workflow_id assignment on
    create via ``_new_workflow_id()``. The adapter must not seed the pipeline
    with a title-derived identifier, since the LLM-validated candidate is fed
    back into the engine and a non-empty workflow_id short-circuits ID
    assignment. ``lock_id`` may still fall back to title for the per-workflow
    critical section, where it only scopes a process-local lock.
    """
    pipeline_workflow_id = str(workflow_id or "")
    lock_id = pipeline_workflow_id or str(
        candidate.get("workflow_id") or candidate.get("title") or ""
    )
    adapted_candidate = run_candidate_adapter_pipeline(
        ctx,
        action_name=action_name,
        workflow_id=pipeline_workflow_id,
        prompt=prompt,
        candidate=candidate,
    )
    with workflow_apply_critical_section(lock_id):
        return ctx.action_service.create_workflow(
            adapted_candidate,
            pending_stage_instruction_writes=pending_stage_instruction_writes,
        )


def run_derive_quality_gate_via_adapter(
    ctx: Any,
    *,
    action_name: str,
    inputs: dict[str, Any],
    objective: str,
) -> dict[str, Any]:
    """Run the derive quality gate for scaffold-derivation actions when linked.

    Studio draft/clone execution receives a materialized scaffold candidate.
    When the upstream action also supplies the UserPlan identity that produced
    that scaffold, this seam routes the quality-gate portion through
    ``DeriveHandler`` so gateway and CLI derivation share the same assessment
    lifecycle without re-running full plan derivation during apply.
    """
    userplan_id = _derive_userplan_id(inputs)
    if userplan_id is None:
        _emit(
            getattr(ctx, "log_event", None),
            "asst.derive_quality_gate_skipped",
            action_name=action_name,
            reason="missing_userplan_id",
        )
        return {"status": "skipped", "reason": "missing_userplan_id"}

    from obra.hybrid.handlers.derive._handler import DeriveHandler

    log_event = getattr(ctx, "log_event", None)
    monitoring_context = {}
    session_id = adapter_session_id(ctx)
    if session_id:
        monitoring_context["session_id"] = session_id

    llm_config: dict[str, Any] = {}
    if getattr(ctx, "app_state", None) is not None:
        from obra.gateway.assistant.pipelines.llm import build_pipeline_llm_config

        llm_config = build_pipeline_llm_config(ctx.app_state)

    def on_progress(action: str, payload: dict[str, Any]) -> None:
        _emit(log_event, f"derive.{action}", action=action, **dict(payload))

    handler = DeriveHandler(
        working_dir=adapter_working_dir(ctx),
        on_progress=on_progress,
        llm_config=llm_config,
        log_event=log_event,
        monitoring_context=monitoring_context,
        cancellation_event=getattr(ctx, "adapter_cancellation_event", None),
        api_client=_quality_gate_api_client(ctx),
    )
    handler._quality_gate.run(userplan_id)
    _emit(
        log_event,
        "asst.derive_quality_gate_completed",
        action_name=action_name,
        userplan_id=userplan_id,
        objective_preview=objective[:120],  # truncation: bounded telemetry preview
    )
    return {"status": "completed", "userplan_id": userplan_id}


def _derive_userplan_id(inputs: dict[str, Any]) -> str | None:
    for key in ("userplan_id", "derive_userplan_id"):
        value = str(inputs.get(key) or "").strip()
        if value:
            return value
    derivation = inputs.get("derivation")
    if isinstance(derivation, dict):
        value = str(derivation.get("userplan_id") or "").strip()
        if value:
            return value
    return None


def _quality_gate_api_client(ctx: Any) -> Any | None:
    action_service = getattr(ctx, "action_service", None)
    getter = getattr(action_service, "_get_client_or_none", None)
    if not callable(getter):
        return None
    return getter()


def _emit_adapter_pipeline_events(
    ctx: Any,
    action_name: str,
    workflow_id: str,
    status: str,
    *,
    fallback: bool = False,
) -> None:
    log_event = getattr(ctx, "log_event", None)
    _emit(log_event, "pipeline_started", pipeline_id=action_name, workflow_id=workflow_id)
    _emit(log_event, "step_started", step_id=action_name, status="running")
    _emit(log_event, "step_completed", step_id=action_name, status=status, output={})
    _emit(
        log_event,
        "pipeline_done",
        pipeline_id=action_name,
        status=status,
        proposal_count=0,
        fallback=fallback,
    )


def _emit(log_event: Any, event_type: str, **payload: Any) -> None:
    if log_event is None:
        return
    try:
        log_event(event_type, **payload)
    except Exception:
        return
