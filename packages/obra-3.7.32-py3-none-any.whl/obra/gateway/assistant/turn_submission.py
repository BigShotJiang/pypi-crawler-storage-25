"""Route-adjacent assistant turn preparation.

This module owns pre-stream setup for assistant turns without importing the
route-local request model. The opaque request object is expected to expose
top-level ``message``, ``context``, and ``model_id`` attributes; safety,
workspace, UI, and attachment fields are read from ``body.context`` and project
identity from the persisted thread.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, MutableMapping

from fastapi import HTTPException, Request, status

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.routes.assistant_context import resolve_assistant_project_root_or_none
from obra.gateway.workflow_studio.assistant_provider import ensure_assistant_runtime
from obra.gateway.workflow_studio.assistant_repository import AssistantRepository
from obra.gateway.workflow_studio.assistant_session_logger import AssistantSessionLogger
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.safety import enforce_safety_mode
from obra.workflow.normalization import slugify


@dataclass(frozen=True)
class AssistantTurnSubmissionContext:
    """Prepared assistant-turn state consumed by the streaming route."""

    repository: AssistantRepository
    ws_repository: WorkflowStudioRepository
    thread: Any
    user_turn: Any
    session_logger: AssistantSessionLogger
    assistant_config: dict[str, Any]
    project_root: Path | None
    turn_context: dict[str, Any]
    image_attachments: list[dict[str, Any]]
    is_new_session: bool


def _normalize_nonempty_string(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _media_type_from_data_url(data_url: str) -> str | None:
    prefix = data_url.split(",", 1)[0]
    if not prefix.startswith("data:") or ";" not in prefix:
        return None
    return prefix[len("data:") :].split(";", 1)[0]


def _normalize_image_attachment(item: Mapping[str, Any]) -> dict[str, Any] | None:
    kind = str(item.get("kind") or item.get("type") or "").strip().lower()
    data = item.get("data") or item.get("data_url") or item.get("content")
    if kind != "image" or not isinstance(data, str) or not data.strip():
        return None
    media_type = str(item.get("media_type") or _media_type_from_data_url(data) or "").strip()
    if not media_type.startswith("image/"):
        return None
    return {
        "kind": "image",
        "media_type": media_type,
        "data": data,
        "source": str(item.get("source") or "user_message").strip() or "user_message",
    }


def _image_attachments_from_context(context: Any) -> list[dict[str, Any]]:
    attachments: list[dict[str, Any]] = []
    raw_attachments = context.attachments if isinstance(context.attachments, list) else []
    for item in raw_attachments:
        if isinstance(item, dict):
            normalized = _normalize_image_attachment(item)
            if normalized is not None:
                attachments.append(normalized)
    screenshot = (
        context.ui_state.get("screenshot")
        if isinstance(context.ui_state, dict)
        and isinstance(context.ui_state.get("screenshot"), str)
        else None
    )
    if isinstance(screenshot, str) and screenshot.startswith("data:image/"):
        normalized = _normalize_image_attachment(
            {
                "kind": "image",
                "data": screenshot,
                "media_type": _media_type_from_data_url(screenshot),
                "source": "editor_screenshot",
            }
        )
        if normalized is not None and normalized not in attachments:
            attachments.append(normalized)
    return attachments


def _prepare_turn_context(body: Any) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    turn_context = body.context.model_dump()
    image_attachments = _image_attachments_from_context(body.context)
    if image_attachments:
        turn_context["attachments"] = image_attachments
    return turn_context, image_attachments


def _ensure_thread_display_slug(
    *,
    request: Request,
    repository: AssistantRepository,
    thread: Any,
    thread_id: str,
    body: Any,
) -> Any:
    if thread.display_slug is not None or not body.message.strip():
        return thread
    baseline_text: str | None = None
    wf_id = _normalize_nonempty_string(thread.workflow_id) or _normalize_nonempty_string(
        body.context.workflow_id
    )
    if wf_id:
        try:
            workflow = WorkflowStudioRepository.from_request(request).get_workflow(wf_id)
        except Exception:
            workflow = None
        if isinstance(workflow, dict):
            baseline_text = _normalize_nonempty_string(workflow.get("title"))
    if not baseline_text:
        baseline_text = body.message[:60]
    display_slug = (
        f"{slugify(baseline_text[:60], default='untitled-thread')}-"
        f"{thread_id.split('-', maxsplit=1)[0][:6].lower()}"
    )
    updated_thread = repository.update_thread(
        thread_id,
        display_slug=display_slug,
        display_slug_source="auto",
    )
    return updated_thread if updated_thread is not None else thread


def _ensure_thread_session_id(
    *,
    repository: AssistantRepository,
    thread: Any,
    thread_id: str,
) -> tuple[Any, bool]:
    if thread.session_id is not None:
        return thread, False
    sid = AssistantSessionLogger.generate_session_id(thread_id, display_slug=thread.display_slug)
    updated_thread = repository.update_thread(thread_id, session_id=sid)
    return (updated_thread if updated_thread is not None else thread), True


def _resolve_session_logger(
    *,
    thread: Any,
    thread_id: str,
    assistant_config: dict[str, Any],
    session_loggers: MutableMapping[str, AssistantSessionLogger],
) -> AssistantSessionLogger:
    logging_config = assistant_config.get("logging", {})
    if thread.session_id not in session_loggers:
        session_logger = AssistantSessionLogger(
            thread.session_id,
            config=logging_config,
        )
        session_logger.set_thread_context(thread_id)
        session_loggers[thread.session_id] = session_logger
        return session_logger
    return session_loggers[thread.session_id]


def prepare_assistant_turn_submission(
    thread_id: str,
    body: Any,
    request: Request,
    session_loggers: MutableMapping[str, AssistantSessionLogger],
) -> AssistantTurnSubmissionContext:
    """Prepare assistant turn state before the route builds streaming context."""
    ensure_assistant_runtime(request.app.state)
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )

    enforce_safety_mode(body.context.safety_mode)
    turn_context, image_attachments = _prepare_turn_context(body)
    user_turn = repository.append_turn(
        thread_id,
        role="user",
        message=body.message,
        context=turn_context,
    )
    assistant_config = get_gateway_assistant_config()
    thread = _ensure_thread_display_slug(
        request=request,
        repository=repository,
        thread=thread,
        thread_id=thread_id,
        body=body,
    )
    thread, is_new_session = _ensure_thread_session_id(
        repository=repository,
        thread=thread,
        thread_id=thread_id,
    )
    session_logger = _resolve_session_logger(
        thread=thread,
        thread_id=thread_id,
        assistant_config=assistant_config,
        session_loggers=session_loggers,
    )
    ws_repository = WorkflowStudioRepository.from_request(request)
    project_root = resolve_assistant_project_root_or_none(
        request,
        project_id=thread.project_id,
        working_dir=body.context.working_dir,
        thread_last_context=thread.last_context if isinstance(thread.last_context, dict) else None,
    )
    return AssistantTurnSubmissionContext(
        repository=repository,
        ws_repository=ws_repository,
        thread=thread,
        user_turn=user_turn,
        session_logger=session_logger,
        assistant_config=assistant_config,
        project_root=project_root,
        turn_context=turn_context,
        image_attachments=image_attachments,
        is_new_session=is_new_session,
    )
