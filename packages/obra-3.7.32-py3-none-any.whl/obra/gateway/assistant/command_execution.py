"""Execution helpers for internal assistant command intents."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.adapter_runtime import create_workflow_via_adapter
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore
from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService
from obra.workflow.readiness import validate_seed_document


def _workflow_action_service(app_state: Any) -> WorkflowActionService:
    client_factory = getattr(app_state, "workflow_studio_client_factory", None)
    local_store = getattr(app_state, "local_workflow_store", None)
    gateway_config = getattr(app_state, "gateway_config", {}) or {}
    workflow_storage = (
        str(
            getattr(app_state, "workflow_storage", gateway_config.get("workflow_storage", "cloud"))
            or "cloud"
        )
        .strip()
        .lower()
    )
    return WorkflowActionService(
        client_factory=client_factory,
        local_store=local_store if isinstance(local_store, LocalWorkflowStore) else None,
        workflow_storage=workflow_storage,
        gateway_config=gateway_config,
    )


def _seed_from_scaffold_definition(workflow_definition: dict[str, Any]) -> dict[str, Any]:
    """Build the persisted seed used by readiness for direct-created scaffolds."""
    metadata = workflow_definition.get("metadata")
    if isinstance(metadata, dict) and isinstance(metadata.get("seed"), dict):
        return validate_seed_document(metadata["seed"])
    intent = str(
        workflow_definition.get("description") or workflow_definition.get("title") or ""
    ).strip()
    if not intent:
        intent = "Build a workflow from the assistant scaffold."
    requirements: list[dict[str, str]] = []
    stages = workflow_definition.get("stages")
    if isinstance(stages, list):
        for index, stage in enumerate(stages, start=1):
            if not isinstance(stage, dict):
                continue
            description = str(stage.get("purpose") or stage.get("title") or "").strip()
            if not description:
                continue
            requirements.append({"id": f"REQ-{index}", "description": description})
    seed: dict[str, Any] = {"intent": intent}
    if requirements:
        seed["requirements"] = requirements
    return validate_seed_document(seed)


def execute_internal_assistant_command(
    *,
    command: dict[str, Any],
    repository: Any,
    thread: Any,
    turn_id: str,
    app_state: Any,
    log_event: Any | None = None,
) -> dict[str, Any] | None:
    """Execute a translator-emitted internal command intent.

    Returns the final assistant-turn fields to persist, or ``None`` when the
    command is not an auto-executable command owned by this layer.
    """
    if not isinstance(command, dict):
        return None
    command_id = str(command.get("command_id") or "").strip()
    if command_id != "create_fresh_workflow_from_scaffold" or not bool(command.get("auto_execute")):
        return None
    action_inputs = command.get("action_inputs")
    if not isinstance(action_inputs, dict):
        action_inputs = {}
    workflow_definition = action_inputs.get("workflow_definition") or action_inputs.get(
        "scaffold_definition"
    )
    if not isinstance(workflow_definition, dict):
        return {
            "outcome": "invalid",
            "message": "The workflow scaffold command did not include a workflow definition.",
            "metadata": {"command_id": command_id},
        }
    domain_id = str(
        action_inputs.get("domain_id") or workflow_definition.get("domain_id") or "business"
    ).strip()
    candidate = {
        "title": str(action_inputs.get("title") or workflow_definition.get("title") or ""),
        "domain_id": domain_id,
        "workflow_definition": dict(workflow_definition),
        "metadata": {"seed": _seed_from_scaffold_definition(workflow_definition)},
    }
    ctx = HandlerContext(
        repository=repository,
        action_service=_workflow_action_service(app_state),
        run_action_service=WorkflowRunActionService(
            getattr(app_state, "session_manager", None),
            workflow_repository=repository,
            app_state=app_state,
        )
        if getattr(app_state, "session_manager", None) is not None
        else None,
        thread_id=str(getattr(thread, "thread_id", "") or ""),
        user_id="current-user",
        turn_id=turn_id,
        app_state=app_state,
        log_event=log_event if callable(log_event) else None,
        adapter_session_id=str(getattr(thread, "session_id", "") or turn_id),
        adapter_working_dir=(
            Path(str(action_inputs["working_dir"]))
            if isinstance(action_inputs.get("working_dir"), str)
            and str(action_inputs.get("working_dir")).strip()
            else None
        ),
    )
    result = create_workflow_via_adapter(
        ctx,
        workflow_id=None,
        candidate=candidate,
        action_name="assistant_fresh_scaffold_create",
        prompt="Validate this fresh Studio workflow scaffold candidate.",
    )
    workflow = result.get("workflow") if isinstance(result, dict) else None
    workflow = workflow if isinstance(workflow, dict) else {}
    workflow_id = str(workflow.get("workflow_id") or result.get("workflow_id") or "").strip()
    revision_ref = result.get("resulting_revision_ref") if isinstance(result, dict) else None
    metadata = {
        "command_id": command_id,
        "workflow_id": workflow_id or None,
        "resulting_revision_ref": revision_ref if isinstance(revision_ref, dict) else None,
    }
    if workflow_id:
        repository.update_thread(thread.thread_id, workflow_id=workflow_id)
    if callable(log_event):
        log_event(
            "asst.command_executed",
            turn_id=turn_id,
            command_id=command_id,
            outcome="applied",
            workflow_id=workflow_id or None,
        )
    return {
        "outcome": "applied",
        "message": "Created the workflow from your scaffold.",
        "metadata": metadata,
    }
