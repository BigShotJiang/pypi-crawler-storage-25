"""Re-apply orchestration for terminal proposal operations."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any
from uuid import uuid4

from obra.gateway.assistant.action_batch_execution import ActionBatchRecord
from obra.gateway.assistant.proposal_operations import (
    CurrentWorkflowResolver,
    ProposalBatchExecutor,
    ProposalOperation,
    ProposalOperationRecordRef,
    WorkflowRevisionResolver,
    _conflict_response_for_refs,
    _finalize_apply_response,
    _normalize,
    _operation_workflow_id,
    _terminal_operation_response,
    _workflow_revision_id,
)
from obra.gateway.assistant.proposal_rebase import NONE_STRATEGY, resolve_strategy


class ProposalOperationReapplyNotSupportedError(ValueError):
    """Raised when a proposal operation cannot be replayed safely."""


async def re_apply_proposal_operation(
    *,
    repository: Any,
    writer: Any | None = None,
    operation: ProposalOperation,
    safety_mode: str,
    working_dir: str | None,
    revision_override: str | None,
    record_indexes: Iterable[int] | None = None,
    execute_batch: ProposalBatchExecutor,
    resolve_current_revision: CurrentWorkflowResolver | None = None,
    resolve_workflow_revision: WorkflowRevisionResolver | None = None,
    log_event: Any | None = None,
) -> dict[str, Any]:
    """Replay a bulk-template proposal operation through the apply pipeline."""
    if not operation.source_refs or any(
        ref.action_id != "execute_template_edit" for ref in operation.source_refs
    ):
        raise ProposalOperationReapplyNotSupportedError(
            "Re-apply is only supported for bulk template-edit proposal operations."
        )

    idempotency_key = f"reapply-{uuid4().hex}"
    target_indexes = _target_indexes(record_indexes)
    executable_refs = [
        ref
        for ref in operation.source_refs
        if not target_indexes or ref.source_record_index in target_indexes
    ]
    if not executable_refs:
        return _terminal_operation_response(operation, operation.status)

    if log_event is not None:
        log_event(
            "asst.proposal_reapply",
            operation_id=operation.operation_id,
            turn_id=operation.turn_id,
            workflow_id=_operation_workflow_id(operation, executable_refs),
            prior_status=operation.status,
            prior_attempt_count=operation.attempt_count,
            minted_idempotency_key=idempotency_key,
        )

    refs_for_execution: list[ProposalOperationRecordRef] = executable_refs
    if revision_override is None:
        current_workflow = None
        current_revision_id = ""

        def workflow_revision_resolver(
            _workflow_id: str,
            _revision_id: str,
        ) -> Mapping[str, Any] | None:
            return None

        if resolve_current_revision is None or resolve_workflow_revision is None:
            strategy = NONE_STRATEGY
        else:
            workflow_id = _operation_workflow_id(operation, executable_refs)
            current_workflow = resolve_current_revision(workflow_id) if workflow_id else None
            current_revision_id = _workflow_revision_id(current_workflow)
            action_ids = {ref.action_id for ref in executable_refs}
            strategy = (
                resolve_strategy(executable_refs[0].action_id)
                if len(action_ids) == 1
                else NONE_STRATEGY
            )
            workflow_revision_resolver = resolve_workflow_revision
        outcome = strategy.maybe_rebase(
            executable_refs,
            current_workflow=current_workflow,
            current_revision_id=current_revision_id,
            resolve_workflow_revision=workflow_revision_resolver,
        )
        if log_event is not None:
            log_event(
                "asst.proposal_rebase",
                operation_id=operation.operation_id,
                turn_id=operation.turn_id,
                workflow_id=_operation_workflow_id(operation, executable_refs),
                action_ids=sorted({ref.action_id for ref in executable_refs}),
                outcome=outcome.kind,
                current_revision_id=outcome.current_revision_id,
                conflict_summary=outcome.conflict_summary,
            )
        if outcome.kind == "conflict" and outcome.conflict_summary is not None:
            response = _conflict_response_for_refs(executable_refs, outcome.conflict_summary)
            return _finalize_apply_response(
                response,
                repository=repository,
                writer=writer,
                operation=operation,
                executable_refs=executable_refs,
                idempotency_key=idempotency_key,
            )
        if outcome.kind == "rebased" and outcome.rebased_refs is not None:
            refs_for_execution = outcome.rebased_refs

    records = []
    for ref in refs_for_execution:
        action_inputs = dict(ref.action_inputs)
        if revision_override:
            action_inputs["expected_revision_id"] = revision_override
        records.append(
            ActionBatchRecord(
                source_record_index=ref.source_record_index,
                action_id=ref.action_id,
                action_inputs=action_inputs,
                workflow_id=ref.workflow_id,
                expected_revision_id=revision_override
                or _normalize(action_inputs.get("expected_revision_id")),
                working_dir=working_dir,
            )
        )
    response = await execute_batch(
        operation.thread_id,
        operation.turn_id,
        safety_mode,
        working_dir,
        records,
    )
    return _finalize_apply_response(
        response,
        repository=repository,
        writer=writer,
        operation=operation,
        executable_refs=executable_refs,
        idempotency_key=idempotency_key,
    )


def _target_indexes(record_indexes: Iterable[int] | None) -> set[int]:
    target_indexes: set[int] = set()
    for index in record_indexes or []:
        try:
            normalized_index = int(index)
        except (TypeError, ValueError):
            continue
        if normalized_index >= 0:
            target_indexes.add(normalized_index)
    return target_indexes
