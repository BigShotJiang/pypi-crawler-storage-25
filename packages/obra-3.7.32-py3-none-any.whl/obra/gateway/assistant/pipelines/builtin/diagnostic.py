"""Diagnostic pipeline for failed or degraded workflow runs."""

from __future__ import annotations

import json
from typing import Any
from uuid import uuid4

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.assistant.handlers.quality_gate import (
    build_quality_gate_proposal,
    build_quality_loop_payload,
)
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.assistant.handlers.template_edit import build_template_edit_proposal
from obra.gateway.assistant.pipelines.engine import PipelineEngine
from obra.gateway.assistant.pipelines.llm import run_structured_json
from obra.gateway.assistant.pipelines.types import (
    PipelineDefinition,
    PipelineResult,
    StepDefinition,
    StepResult,
)

PIPELINE_ID = "pipeline_diagnose_run"
QUALITY_THRESHOLD = 3
"""Root-cause threshold on the diagnostic quality_score scale, where 0 is worst and 10 is best."""


def _workflow_stages(workflow_context: dict[str, Any]) -> list[dict[str, Any]]:
    stages = workflow_context.get("stages")
    if isinstance(stages, list):
        return [stage for stage in stages if isinstance(stage, dict)]
    return _get_stages(workflow_context)


def build_diagnostic_steps(workflow_context: dict[str, Any]) -> list[StepDefinition]:
    """Create one diagnostic step per stage."""
    return [
        StepDefinition(
            step_id=f"diagnose_{str(stage.get('stage_id') or stage.get('id') or '').strip()}",
            description=f"Diagnose stage: {stage.get('title') or stage.get('id') or 'stage'!s}",
            step_type="diagnose",
        )
        for stage in _workflow_stages(workflow_context)
        if str(stage.get("stage_id") or stage.get("id") or "").strip()
    ]


def execute_diagnostic_step(
    engine: PipelineEngine,
    step: StepDefinition,
    workflow_context: dict[str, Any],
    predecessors: list[dict[str, Any]],
) -> dict[str, Any]:
    """Diagnose one stage's output quality and degradation cause."""
    stage_id = step.step_id.removeprefix("diagnose_")
    stages = _workflow_stages(workflow_context)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")
    run_outputs = workflow_context.get("run_outputs", {})
    prompt = (
        f"Stage: {json.dumps(stage, sort_keys=True)}\n"
        f"Stage output: {json.dumps(run_outputs.get(stage_id), sort_keys=True)}\n"
        f"Predecessor diagnostics: {json.dumps(predecessors, sort_keys=True)}\n"
        "Return JSON with quality_score, meets_purpose, degradation_cause, suggested_fixes."
    )
    template = {
        "quality_score": 5,
        "meets_purpose": True,
        "degradation_cause": None,
        "suggested_fixes": [],
        "_instructions": "Return one stage diagnostic assessment.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not isinstance(data.get("quality_score"), int):
            return (False, "quality_score must be an integer")
        if not 0 <= int(data["quality_score"]) <= 10:
            return (False, "quality_score must be between 0 and 10")
        return (True, None)

    return run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_{stage_id}",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "quality_score": 5,
            "meets_purpose": True,
            "degradation_cause": None,
            "suggested_fixes": [],
        },
    )


def build_causal_narrative(step_results: list[StepResult]) -> dict[str, Any]:
    """Identify the root-cause stage and downstream impact chain."""
    root_cause: StepResult | None = None
    downstream: list[str] = []
    for result in step_results:
        output = result.output or {}
        quality_score = int(output.get("quality_score") or 0)
        meets_purpose = bool(output.get("meets_purpose", False))
        stage_id = result.step_id.removeprefix("diagnose_")
        if root_cause is None and (quality_score < QUALITY_THRESHOLD or not meets_purpose):
            root_cause = result
            continue
        if root_cause is not None:
            downstream.append(stage_id)
    root_stage_id = root_cause.step_id.removeprefix("diagnose_") if root_cause else None
    narrative = (
        f"Root cause stage: {root_stage_id or 'none identified'}."
        if not downstream
        else f"Root cause stage: {root_stage_id}. Downstream impact: {', '.join(downstream)}."
    )
    return {
        "root_cause_stage_id": root_stage_id,
        "downstream_impacted_stage_ids": downstream,
        "narrative": narrative,
    }


def _diagnostic_proposals(
    step_results: list[StepResult],
    workflow_context: dict[str, Any],
) -> list[dict[str, Any]]:
    workflow_id = str(workflow_context.get("workflow_id") or "")
    proposal_group = str(uuid4())
    proposals: list[dict[str, Any]] = []
    for result in step_results:
        output = result.output or {}
        stage_id = result.step_id.removeprefix("diagnose_")
        for fix in output.get("suggested_fixes", []):
            if isinstance(fix, dict) and str(fix.get("type") or "") == "quality_gate":
                quality_loop = build_quality_loop_payload(workflow_context, stage_id=stage_id)
                proposals.append(
                    build_quality_gate_proposal(
                        workflow=workflow_context,
                        workflow_id=workflow_id,
                        stage_id=stage_id,
                        quality_loop=quality_loop,
                        proposal_group=proposal_group,
                    )
                )
                continue
            if isinstance(fix, dict):
                proposed_content = str(fix.get("proposed_content") or "").strip()
            else:
                proposed_content = str(fix).strip()
            if not proposed_content:
                continue
            proposals.append(
                build_template_edit_proposal(
                    workflow=workflow_context,
                    workflow_id=workflow_id,
                    stage_id=stage_id,
                    template_role="purpose",
                    proposed_content=proposed_content,
                    proposal_group=proposal_group,
                )
            )
    return proposals


async def run_diagnostic_pipeline(engine: PipelineEngine) -> Any:
    """Execute stage diagnostics and assemble fix proposals."""
    engine.set_step_handler(
        lambda step, workflow_context, predecessors, _review_feedback=None: execute_diagnostic_step(
            engine,
            step,
            workflow_context,
            predecessors,
        )
    )
    steps = build_diagnostic_steps(engine.workflow_context)
    for step in steps:
        for event in await engine.execute_step_with_events(step):
            yield event
        if engine.cancelled:
            remaining = steps[steps.index(step) + 1 :]
            engine.mark_pending_steps_skipped(remaining)
            engine.set_result(
                PipelineResult(
                    pipeline_id=PIPELINE_ID,
                    status="cancelled",
                    step_results=engine.step_results,
                    proposals=[],
                    summary_message="Run diagnostics were cancelled.",
                )
            )
            return
    narrative = build_causal_narrative(engine.step_results)
    proposals = _diagnostic_proposals(engine.step_results, engine.workflow_context)
    engine.set_result(
        PipelineResult(
            pipeline_id=PIPELINE_ID,
            status="completed",
            step_results=engine.step_results,
            proposals=proposals,
            summary_message=str(narrative.get("narrative") or "Run diagnostics completed."),
        )
    )


def create_definition() -> PipelineDefinition:
    """Create the registered diagnostic pipeline definition."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    return PipelineDefinition(
        pipeline_id=PIPELINE_ID,
        display_name="Run Diagnostics",
        trigger_mode="semi_auto",
        timeout_s=int(pipeline_config["diagnostic_timeout_s"]),
        steps_factory=build_diagnostic_steps,
        runner=run_diagnostic_pipeline,
    )
