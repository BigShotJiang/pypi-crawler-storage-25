"""Bulk template generation pipeline."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from obra.config.loaders import get_bulk_template_gen_config, get_gateway_assistant_config
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.assistant.handlers.template_edit import build_template_edit_proposal
from obra.gateway.assistant.pipelines.engine import PipelineEngine
from obra.gateway.assistant.pipelines.llm import run_structured_json
from obra.gateway.assistant.pipelines.types import (
    PipelineDefinition,
    PipelineResult,
    QualityVerdict,
    StepDefinition,
    StepResult,
)
from obra.gateway.assistant.proposal_operation_writer import ProposalOperationWriter
from obra.gateway.assistant.proposal_operations import (
    ProposalOperation,
    ProposalOperationRecordRef,
    proposal_operation_id_for_records,
)
from obra.gateway.workflow_studio.assistant_prompts import _load_context_file
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.workflow.stage_instruction_assets import PRIMARY_STAGE_INSTRUCTION_ROLE
from obra.workflow.template_asset_store import TemplateAssetStore
from obra.utils.truncation import emit_truncation_marker

PIPELINE_ID = "pipeline_generate_templates"
REVIEW_STEP_ID = "review_generated_templates"
REVIEW_STEP_DESCRIPTION = "Review generated templates across stages"
logger = logging.getLogger(__name__)


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _workflow_stages(workflow_context: dict[str, Any]) -> list[dict[str, Any]]:
    stages = workflow_context.get("stages")
    if isinstance(stages, list):
        return [stage for stage in stages if isinstance(stage, dict)]
    return _get_stages(workflow_context)


def _requested_stage_ids(params: dict[str, Any] | None) -> set[str]:
    raw_stage_ids = (params or {}).get("stage_ids")
    if not isinstance(raw_stage_ids, list):
        return set()
    return {str(stage_id).strip() for stage_id in raw_stage_ids if str(stage_id).strip()}


def build_steps(
    workflow_context: dict[str, Any],
    params: dict[str, Any] | None = None,
) -> list[StepDefinition]:
    """Create one template-generation step per workflow stage plus review."""
    steps: list[StepDefinition] = []
    requested_stage_ids = _requested_stage_ids(params)
    for stage in _workflow_stages(workflow_context):
        stage_id = str(stage.get("stage_id") or stage.get("id") or "").strip()
        if not stage_id:
            continue
        if requested_stage_ids and stage_id not in requested_stage_ids:
            continue
        label = str(stage.get("title") or stage.get("name") or stage_id)
        steps.append(
            StepDefinition(
                step_id=f"gen_template_{stage_id}",
                description=f"Generate template for stage: {label}",
                step_type="generate",
            )
        )
    if steps:
        steps.append(
            StepDefinition(
                step_id=REVIEW_STEP_ID,
                description=REVIEW_STEP_DESCRIPTION,
                step_type="review",
            )
        )
    return steps


def _stage_label(stage: dict[str, Any], fallback: str) -> str:
    return str(stage.get("title") or stage.get("name") or fallback)


def _stage_purpose(stage: dict[str, Any]) -> str:
    return str(stage.get("purpose") or stage.get("description") or "").strip()


def execute_template_step(
    engine: PipelineEngine,
    step: StepDefinition,
    workflow_context: dict[str, Any],
    predecessors: list[dict[str, Any]],
    review_feedback: str | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Generate one executable main template with neighboring stage context."""
    stage_id = step.step_id.removeprefix("gen_template_")
    stages = _workflow_stages(workflow_context)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")

    params = dict(params or {})
    index = next((idx for idx, item in enumerate(stages) if _find_stage([item], stage_id)), 0)
    previous_stage = stages[index - 1] if index > 0 else None
    next_stage = stages[index + 1] if index + 1 < len(stages) else None
    user_context = str(params.get("user_context") or "").strip()
    stage_label = _stage_label(stage, stage_id)
    if review_feedback:
        engine.emit_progress(
            step.step_id,
            f"Revising template for stage: {stage_label}",
        )
    else:
        engine.emit_progress(
            step.step_id,
            f"Generating template for stage: {stage_label}",
        )
    prompt_sections = [
        "You are authoring the main executable template for one workflow stage.",
        "Write comprehensive stage execution instructions following the Template Authoring Guidelines.",
        "Template Authoring Guidelines:",
        _load_context_file("template-authoring-guidelines.md"),
        f"Target stage id: {stage_id}",
        f"Target stage title: {_stage_label(stage, stage_id)}",
        f"Target stage purpose: {_stage_purpose(stage)}",
        f"Target stage metadata: {json.dumps(stage, sort_keys=True)}",
        f"Previous stage metadata: {json.dumps(previous_stage or {}, sort_keys=True)}",
        f"Next stage metadata: {json.dumps(next_stage or {}, sort_keys=True)}",
        f"Predecessor summaries: {json.dumps(predecessors, sort_keys=True)}",
        f"Review feedback: {review_feedback or 'none'}",
    ]
    if user_context:
        prompt_sections.append(f"User-provided context: {user_context}")
    prompt_sections.append("Return JSON with keys stage_id, template_role, proposed_content.")
    prompt = "\n".join(prompt_sections)
    template = {
        "stage_id": stage_id,
        "template_role": "main",
        "proposed_content": "",
        "_instructions": (
            "Write comprehensive stage execution instructions following the Template "
            "Authoring Guidelines. Include: role definition, input contract, "
            "step-by-step instructions, output format, and quality criteria."
        ),
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        emitted_stage_id = str(data.get("stage_id") or "").strip()
        if not emitted_stage_id:
            return (False, "stage_id is required")
        if emitted_stage_id != stage_id:
            return (False, f"stage_id must match target stage {stage_id!r}")
        if not str(data.get("proposed_content") or "").strip():
            return (False, "proposed_content is required")
        return (True, None)

    return run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_{stage_id}",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "stage_id": stage_id,
            "template_role": "main",
            "proposed_content": _stage_purpose(stage),
        },
    )


def execute_review_step(
    engine: PipelineEngine,
    step_results: list[StepResult],
    workflow_context: dict[str, Any],
    *,
    step_id: str = REVIEW_STEP_ID,
) -> dict[str, Any]:
    """Execute the explicit cross-stage review step."""
    preview_chars = get_bulk_template_gen_config()["review_preview_max_chars"]
    summaries = [
        {
            "stage_id": str((result.output or {}).get("stage_id") or ""),
            "preview": emit_truncation_marker(
                str((result.output or {}).get("proposed_content") or ""),
                preview_chars,
                label="generated template review preview",
            ),
        }
        for result in step_results
        if result.output
    ]
    template_count = len(summaries)
    engine.emit_progress(
        step_id,
        f"Reviewing {template_count} generated template{'s' if template_count != 1 else ''} for cross-stage consistency",
    )
    prompt = (
        f"Workflow stages: {json.dumps(_workflow_stages(workflow_context), sort_keys=True)}\n"
        f"Generated templates: {json.dumps(summaries, sort_keys=True)}\n"
        "Review terminology consistency, handoff clarity, and scope overlap.\n"
        "Return JSON with verdict, issues, affected_stages, suggestions. "
        "The verdict must be exactly pass or revise."
    )
    template = {
        "verdict": "pass",
        "issues": [],
        "affected_stages": [],
        "suggestions": [],
        "_instructions": (
            "Return advisory review feedback for the generated stage templates. "
            "Use verdict pass only when no revision is needed; use revise when any "
            "template needs changes."
        ),
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        verdict = str(data.get("verdict") or "").strip()
        if verdict not in {"pass", "revise"}:
            return (False, "verdict must be pass or revise")
        return (True, None)

    data = run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_review",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "verdict": "pass",
            "issues": [],
            "affected_stages": [],
            "suggestions": [],
        },
    )
    return {
        "verdict": "revise" if data.get("verdict") == "revise" else "pass",
        "issues": [str(item) for item in data.get("issues", []) if str(item).strip()],
        "affected_stages": [
            str(item) for item in data.get("affected_stages", []) if str(item).strip()
        ],
        "suggestions": [str(item) for item in data.get("suggestions", []) if str(item).strip()],
    }


def _quality_verdict_from_review_output(output: dict[str, Any] | None) -> QualityVerdict:
    """Map the stored review-step output into the pipeline verdict object."""
    data = output or {}
    affected_stages = [str(item) for item in data.get("affected_stages", []) if str(item).strip()]
    return QualityVerdict(
        verdict="revise" if data.get("verdict") == "revise" else "pass",
        affected_step_ids=[f"gen_template_{stage_id}" for stage_id in affected_stages],
        issues=[str(item) for item in data.get("issues", []) if str(item).strip()],
        suggestions=[str(item) for item in data.get("suggestions", []) if str(item).strip()],
    )


def review_templates(
    engine: PipelineEngine,
    step_results: list[StepResult],
    workflow_context: dict[str, Any],
) -> QualityVerdict:
    """Review generated templates for cross-stage consistency."""
    return _quality_verdict_from_review_output(
        execute_review_step(engine, step_results, workflow_context)
    )


def build_template_proposals(
    pipeline_result: PipelineResult,
    workflow_context: dict[str, Any],
    *,
    store: TemplateAssetStore | None = None,
    writer: ProposalOperationWriter | None = None,
    thread_id: str = "",
    turn_id: str = "",
    created_by: str | None = None,
) -> list[dict[str, Any]]:
    """Build assistant proposal records from generated templates."""
    workflow_id = str(workflow_context.get("workflow_id") or "")
    proposal_group = str(uuid4())
    proposals: list[dict[str, Any]] = []
    workflow_like = (
        workflow_context
        if isinstance(workflow_context.get("workflow_definition"), dict)
        else {
            "workflow_definition": {
                **workflow_context,
                "stages": _workflow_stages(workflow_context),
            }
        }
    )
    expected_revision_id = _expected_revision_id(workflow_context)
    for result in pipeline_result.step_results:
        if result.status != "completed" or not result.output:
            continue
        stage_id = str(result.output.get("stage_id") or "").strip()
        proposed_content = str(result.output.get("proposed_content") or "").strip()
        template_role = PRIMARY_STAGE_INSTRUCTION_ROLE
        if not stage_id or not proposed_content:
            continue
        proposal = build_template_edit_proposal(
            workflow=workflow_like,
            workflow_id=workflow_id,
            stage_id=stage_id,
            template_role=template_role,
            proposed_content=proposed_content,
            proposal_group=proposal_group,
            store=store,
        )
        if expected_revision_id:
            proposal.setdefault("action_inputs", {})["expected_revision_id"] = expected_revision_id
            proposal["expected_revision_id"] = expected_revision_id
        proposals.append(proposal)
    operation_id = proposal_operation_id_for_records(
        workflow_id=workflow_id,
        thread_id=thread_id,
        turn_id=turn_id,
        proposal_group=proposal_group,
        source_record_indexes=range(len(proposals)),
        records=proposals,
    )
    for index, proposal in enumerate(proposals):
        proposal["proposal_operation_id"] = operation_id
        action_inputs = proposal.setdefault("action_inputs", {})
        action_inputs["proposal_operation_id"] = operation_id
        if store is not None:
            store.write_proposed_asset(
                workflow_id=workflow_id,
                stage_id=str(action_inputs.get("stage_id") or ""),
                role=str(action_inputs.get("template_role") or PRIMARY_STAGE_INSTRUCTION_ROLE),
                content=str(action_inputs.get("proposed_content") or ""),
                operation_id=operation_id,
                proposal_group=proposal_group,
                source_record_index=index,
                action_kind=str(proposal.get("action_id") or "execute_template_edit"),
                metadata={
                    "proposal_group": proposal_group,
                    "source_record_index": index,
                    "action_id": str(proposal.get("action_id") or "execute_template_edit"),
                    "thread_id": thread_id,
                    "turn_id": turn_id,
                    "created_by": created_by,
                },
            )
    if writer is not None and proposals:
        now = _utc_now()
        source_refs = [
            ProposalOperationRecordRef(
                thread_id=thread_id,
                turn_id=turn_id,
                source_record_index=index,
                action_id=str(proposal.get("action_id") or "execute_template_edit"),
                action_inputs=dict(proposal.get("action_inputs") or {}),
                workflow_id=workflow_id,
                status=str(proposal.get("status") or "pending"),
                proposal_group=proposal_group,
                preview_type=str(proposal.get("preview_type") or "") or None,
                stage_ids=[
                    str(stage_id)
                    for stage_id in [
                        (proposal.get("action_inputs") or {}).get("stage_id")
                        if isinstance(proposal.get("action_inputs"), dict)
                        else None
                    ]
                    if str(stage_id or "").strip()
                ],
                draft_backed=True,
            )
            for index, proposal in enumerate(proposals)
        ]
        operation = ProposalOperation(
            operation_id=operation_id,
            workflow_id=workflow_id,
            thread_id=thread_id,
            turn_id=turn_id,
            proposal_group=proposal_group,
            status="pending",
            source_refs=source_refs,
            attempt_count=0,
            last_attempt=None,
            preview_summary=f"{len(source_refs)} proposed changes",
            stage_ids=[stage_id for ref in source_refs for stage_id in ref.stage_ids if stage_id],
            created_at=now,
            updated_at=now,
            attempt_history=[],
            created_by=created_by,
        )
        if writer.store.get(operation_id) is None:
            writer.create(operation)
    return proposals


def _expected_revision_id(workflow_context: dict[str, Any]) -> str | None:
    for key in (
        "expected_revision_id",
        "revision_id",
        "head_revision_id",
        "latest_revision_id",
    ):
        normalized = str(workflow_context.get(key) or "").strip()
        if normalized and normalized != "unset":
            return normalized
    workflow = workflow_context.get("workflow")
    if isinstance(workflow, dict):
        for key in ("expected_revision_id", "revision_id", "head_revision_id"):
            normalized = str(workflow.get(key) or "").strip()
            if normalized and normalized != "unset":
                return normalized
    return None


async def run_bulk_template_pipeline(engine: PipelineEngine) -> Any:
    """Execute the full generate -> review -> revise -> present flow."""

    def _step_handler(step, workflow_context, predecessors, review_feedback=None):  # type: ignore[no-untyped-def]
        if step.step_id == REVIEW_STEP_ID:
            generated_results = [
                result
                for result in engine.step_results
                if result.step_id.startswith("gen_template_")
            ]
            return execute_review_step(
                engine,
                generated_results,
                workflow_context,
                step_id=step.step_id,
            )
        return execute_template_step(
            engine,
            step,
            workflow_context,
            predecessors,
            review_feedback,
            engine.params,
        )

    engine.set_step_handler(_step_handler)
    steps = build_steps(engine.workflow_context, engine.params)
    review_step = next((step for step in steps if step.step_id == REVIEW_STEP_ID), None)
    generation_steps = [step for step in steps if step.step_id != REVIEW_STEP_ID]

    if not generation_steps:
        engine.set_result(
            PipelineResult(
                pipeline_id=PIPELINE_ID,
                status="completed",
                step_results=[],
                proposals=[],
                summary_message="No stages required generation.",
            )
        )
        return

    for step in generation_steps:
        for event in await engine.execute_step_with_events(
            step,
        ):
            yield event
        if engine.cancelled:
            remaining = generation_steps[generation_steps.index(step) + 1 :]
            if review_step is not None:
                remaining = [*remaining, review_step]
            engine.mark_pending_steps_skipped(remaining)
            engine.set_result(
                PipelineResult(
                    pipeline_id=PIPELINE_ID,
                    status="cancelled",
                    step_results=engine.step_results,
                    proposals=[],
                    summary_message="Bulk template generation was cancelled.",
                )
            )
            return

    verdict = QualityVerdict(verdict="pass", affected_step_ids=[], issues=[], suggestions=[])
    if review_step is not None:
        for event in await engine.execute_step_with_events(review_step):
            yield event
        review_result = engine.get_step_result(review_step.step_id)
        verdict = _quality_verdict_from_review_output(
            review_result.output if review_result else None
        )

    if verdict.verdict == "revise":
        feedback = "\n".join(verdict.issues + verdict.suggestions)
        for step_id in verdict.affected_step_ids:
            step = next((item for item in steps if item.step_id == step_id), None)
            if step is None:
                continue
            stage_id = step.step_id.removeprefix("gen_template_")
            yield {
                "event": "step_review",
                "step_id": step.step_id,
                "message": (
                    f"Review requested revisions for {stage_id}: "
                    f"{'; '.join(verdict.suggestions or verdict.issues)}"
                ),
                "issues": verdict.issues,
                "suggestions": verdict.suggestions,
            }
            for event in await engine.execute_step_with_events(
                step,
                review_feedback=feedback,
            ):
                yield event

    final_status = (
        "failed"
        if any(result.status == "failed" for result in engine.step_results)
        else "completed"
    )
    pipeline_result = PipelineResult(
        pipeline_id=PIPELINE_ID,
        status=final_status,
        step_results=engine.step_results,
        proposals=[],
        summary_message=(
            "Bulk template generation failed."
            if final_status == "failed"
            else f"Prepared {len(generation_steps)} template updates across the workflow."
        ),
    )
    proposals = []
    if final_status == "completed":
        store = resolve_template_asset_store(
            engine.app_state,
            working_dir=engine.working_dir,
        )
        try:
            proposals = build_template_proposals(
                pipeline_result,
                engine.workflow_context,
                store=store,
                writer=engine.proposal_operation_writer,
                thread_id=engine.thread_id,
                turn_id=engine.turn_id,
                created_by=engine.created_by,
            )
        except Exception:
            logger.exception(
                "Bulk template pipeline failed to persist proposed template assets",
                extra={
                    "workflow_id": str(engine.workflow_context.get("workflow_id") or ""),
                    "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                    "stage_ids": [
                        stage.stage_id
                        for stage in pipeline_result.template_generations
                        if stage.stage_id
                    ],
                },
            )
            raise
        logger.info(
            "Bulk template pipeline persisted proposed template assets",
            extra={
                "workflow_id": str(engine.workflow_context.get("workflow_id") or ""),
                "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                "proposal_count": len(proposals),
            },
        )
    engine.set_result(
        PipelineResult(
            pipeline_id=PIPELINE_ID,
            status=final_status,
            step_results=engine.step_results,
            proposals=proposals,
            summary_message=(
                "Bulk template generation failed."
                if final_status == "failed"
                else f"Prepared {len(proposals)} template proposals."
            ),
        )
    )


def create_definition() -> PipelineDefinition:
    """Create the registered bulk-template pipeline definition."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    return PipelineDefinition(
        pipeline_id=PIPELINE_ID,
        display_name="Bulk Template Generation",
        trigger_mode="semi_auto",
        timeout_s=int(pipeline_config["bulk_template_timeout_s"]),
        steps_factory=build_steps,
        runner=run_bulk_template_pipeline,
    )
