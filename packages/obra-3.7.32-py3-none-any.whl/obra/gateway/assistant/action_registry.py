"""Action allowlist registry for the assistant action broker (TR-3.1).

Defines the V1 action set and provides lookup/enumeration functions.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

from obra.gateway.assistant.command_contract import AssistantCommand


@dataclass(frozen=True)
class ActionDefinition:
    """Immutable definition of a registered assistant action."""

    action_id: str
    label: str
    category: str
    mutates: bool
    required_safety_mode: str
    input_schema: dict
    handler_ref: str
    preview_type: str | None
    command: AssistantCommand | None = None


V1_ACTIONS: dict[str, ActionDefinition] = {
    "explain_workflow": ActionDefinition(
        action_id="explain_workflow",
        label="Explain workflow",
        category="read",
        mutates=False,
        required_safety_mode="advisory",
        input_schema={"workflow_id": {"type": "string", "required": True}},
        handler_ref="obra.gateway.assistant.handlers.explain.explain_workflow",
        preview_type="text",
    ),
    "explain_stage": ActionDefinition(
        action_id="explain_stage",
        label="Explain stage",
        category="read",
        mutates=False,
        required_safety_mode="advisory",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.explain.explain_stage",
        preview_type="text",
    ),
    "propose_template_edit": ActionDefinition(
        action_id="propose_template_edit",
        label="Propose template edit",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string"},
            "template_role": {"type": "string", "required": True},
            "proposed_content": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.template_edit.propose",
        preview_type="diff",
    ),
    "propose_stage_insert": ActionDefinition(
        action_id="propose_stage_insert",
        label="Propose stage insert",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "after_stage_id": {"type": "string"},
            "stage_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_insert",
        preview_type="scaffold",
    ),
    "propose_stage_remove": ActionDefinition(
        action_id="propose_stage_remove",
        label="Propose stage removal",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_remove",
        preview_type="diff",
    ),
    "propose_stage_update": ActionDefinition(
        action_id="propose_stage_update",
        label="Propose stage update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
            "updates": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_update",
        preview_type="diff",
    ),
    "propose_stage_reorder": ActionDefinition(
        action_id="propose_stage_reorder",
        label="Propose stage reorder",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "ordered_stage_ids": {"type": "array", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_reorder",
        preview_type="diff",
    ),
    "propose_connection_add": ActionDefinition(
        action_id="propose_connection_add",
        label="Propose connection add",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "source_stage_id": {"type": "string", "required": True},
            "target_stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_connect",
        preview_type="diff",
    ),
    "propose_connection_remove": ActionDefinition(
        action_id="propose_connection_remove",
        label="Propose connection remove",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "source_stage_id": {"type": "string", "required": True},
            "target_stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.propose_disconnect",
        preview_type="diff",
    ),
    "propose_workflow_metadata_update": ActionDefinition(
        action_id="propose_workflow_metadata_update",
        label="Propose workflow metadata update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "updates": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.metadata.propose_update",
        preview_type="diff",
    ),
    "propose_quality_gate_set": ActionDefinition(
        action_id="propose_quality_gate_set",
        label="Propose quality gate update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
            "quality_loop": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.quality_gate.propose_set",
        preview_type="diff",
    ),
    "propose_batch_mutation": ActionDefinition(
        action_id="propose_batch_mutation",
        label="Propose batch workflow mutation",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "operations": {"type": "array", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.batch.propose_batch",
        preview_type="diff",
    ),
    "propose_pipeline_execution": ActionDefinition(
        action_id="propose_pipeline_execution",
        label="Propose pipeline execution",
        category="pipeline",
        mutates=False,
        required_safety_mode="guided",
        input_schema={
            "pipeline_id": {"type": "string", "required": True},
            "workflow_id": {"type": "string", "required": True},
            "params": {"type": "object"},
        },
        handler_ref="obra.gateway.assistant.handlers.pipeline_dispatch.propose_pipeline",
        preview_type="pipeline_proposal",
    ),
    "clone_and_adapt": ActionDefinition(
        action_id="clone_and_adapt",
        label="Clone and adapt workflow",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "source_workflow_id": {"type": "string", "required": True},
            "adapted_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.clone.propose_adaptation",
        preview_type="scaffold",
    ),
    "draft_workflow_from_thread": ActionDefinition(
        action_id="draft_workflow_from_thread",
        label="Draft workflow from conversation",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "scaffold_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.draft.propose_draft",
        preview_type="scaffold",
    ),
    "execute_draft_workflow_from_thread": ActionDefinition(
        action_id="execute_draft_workflow_from_thread",
        label="Execute draft workflow creation",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "scaffold_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.draft.execute_draft",
        preview_type=None,
    ),
    "execute_restart_workflow_from_thread": ActionDefinition(
        action_id="execute_restart_workflow_from_thread",
        label="Execute workflow restart",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "expected_revision_id": {"type": "string"},
            "scaffold_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.restart.execute_restart",
        preview_type=None,
    ),
    "execute_clone_and_adapt": ActionDefinition(
        action_id="execute_clone_and_adapt",
        label="Execute clone and adapt",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "source_workflow_id": {"type": "string", "required": True},
            "adapted_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.clone.execute_adaptation",
        preview_type=None,
    ),
    "execute_template_edit": ActionDefinition(
        action_id="execute_template_edit",
        label="Execute template edit",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "template_role": {"type": "string", "required": True},
            "proposed_content": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.template_edit.execute",
        preview_type=None,
    ),
    "execute_stage_insert": ActionDefinition(
        action_id="execute_stage_insert",
        label="Execute stage insert",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_definition": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_insert",
        preview_type=None,
    ),
    "execute_stage_remove": ActionDefinition(
        action_id="execute_stage_remove",
        label="Execute stage removal",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_remove",
        preview_type=None,
    ),
    "execute_stage_update": ActionDefinition(
        action_id="execute_stage_update",
        label="Execute stage update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
            "updates": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_update",
        preview_type=None,
    ),
    "execute_stage_reorder": ActionDefinition(
        action_id="execute_stage_reorder",
        label="Execute stage reorder",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "ordered_stage_ids": {"type": "array", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_reorder",
        preview_type=None,
    ),
    "execute_connection_add": ActionDefinition(
        action_id="execute_connection_add",
        label="Execute connection add",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "source_stage_id": {"type": "string", "required": True},
            "target_stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_connect",
        preview_type=None,
    ),
    "execute_connection_remove": ActionDefinition(
        action_id="execute_connection_remove",
        label="Execute connection remove",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "source_stage_id": {"type": "string", "required": True},
            "target_stage_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.structural.execute_disconnect",
        preview_type=None,
    ),
    "execute_workflow_metadata_update": ActionDefinition(
        action_id="execute_workflow_metadata_update",
        label="Execute workflow metadata update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "updates": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.metadata.execute_update",
        preview_type=None,
    ),
    "execute_quality_gate_set": ActionDefinition(
        action_id="execute_quality_gate_set",
        label="Execute quality gate update",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "stage_id": {"type": "string", "required": True},
            "quality_loop": {"type": "object", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.quality_gate.execute_set",
        preview_type=None,
    ),
    "execute_batch_mutation": ActionDefinition(
        action_id="execute_batch_mutation",
        label="Execute batch workflow mutation",
        category="workflow",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "operations": {"type": "array", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.batch.execute_batch",
        preview_type=None,
    ),
    "execute_launch_run": ActionDefinition(
        action_id="execute_launch_run",
        label=(
            "Execute run launch. Outputs land in a workflow-named folder under the "
            "projects root; the resolved path is returned in working_dir."
        ),
        category="run",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "objective": {"type": "string", "required": True},
            "project_id": {"type": "string", "required": True},
            "workflow_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.run_actions.execute_launch_run",
        preview_type=None,
    ),
    "execute_approve_operator_review": ActionDefinition(
        action_id="execute_approve_operator_review",
        label="Execute operator approval",
        category="run",
        mutates=True,
        required_safety_mode="guided",
        input_schema={"run_id": {"type": "string", "required": True}},
        handler_ref="obra.gateway.assistant.handlers.run_actions.execute_approve_operator_review",
        preview_type=None,
    ),
    "execute_resolve_escalation": ActionDefinition(
        action_id="execute_resolve_escalation",
        label="Execute escalation resolution",
        category="run",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "run_id": {"type": "string", "required": True},
            "escalation_id": {"type": "string", "required": True},
            "choice": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.assistant.handlers.run_actions.execute_resolve_escalation",
        preview_type=None,
    ),
    "generate_test_data": ActionDefinition(
        action_id="generate_test_data",
        label="Generate test input files",
        category="project_files",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.workflow_studio.file_actions.generate_test_data",
        preview_type=None,
    ),
    "generate_documentation": ActionDefinition(
        action_id="generate_documentation",
        label="Generate workflow documentation",
        category="read",
        mutates=False,
        required_safety_mode="advisory",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.workflow_studio.file_actions.generate_documentation",
        preview_type=None,
    ),
    "save_documentation": ActionDefinition(
        action_id="save_documentation",
        label="Save documentation to project",
        category="project_files",
        mutates=True,
        required_safety_mode="guided",
        input_schema={
            "workflow_id": {"type": "string", "required": True},
            "markdown_content": {"type": "string", "required": True},
        },
        handler_ref="obra.gateway.workflow_studio.file_actions.save_documentation",
        preview_type=None,
    ),
}


def _state_refresh_for_action(action: ActionDefinition) -> list[str]:
    if action.category == "pipeline" or action.action_id == "propose_pipeline_execution":
        return ["pipelines_active", "pending_proposals"]
    if action.category == "run":
        return ["workflow_runs"]
    if action.mutates:
        return ["workflow_head", "pending_proposals"]
    return []


def _async_behavior_for_action(action: ActionDefinition) -> str:
    if action.category == "pipeline" or action.action_id == "propose_pipeline_execution":
        return "pipeline_long_running"
    if action.category == "run":
        return "session_long_running"
    return "sync"


def _command_route_for_action(action: ActionDefinition) -> str | None:
    if action.action_id == "propose_pipeline_execution":
        return "/api/assistant/pipelines/execute"
    if action.action_id.startswith("execute_"):
        return f"/api/assistant/actions/{action.action_id}/execute"
    return None


def _request_adapter_for_action(action: ActionDefinition) -> str:
    if action.action_id == "propose_pipeline_execution":
        return "pipeline_execute"
    return "action_execute"


def _with_command_descriptors(
    actions: dict[str, ActionDefinition],
) -> dict[str, ActionDefinition]:
    updated: dict[str, ActionDefinition] = {}
    for action_id, action in actions.items():
        route = _command_route_for_action(action)
        if route is None:
            updated[action_id] = action
            continue
        updated[action_id] = replace(
            action,
            command=AssistantCommand(
                command_id=action.action_id,
                route=route,
                request_adapter=_request_adapter_for_action(action),  # type: ignore[arg-type]
                action_inputs_schema=dict(action.input_schema or {}),
                idempotency_key=(
                    "pipeline_session:{workflow_id}:{pipeline_id}"
                    if action.action_id == "propose_pipeline_execution"
                    else None
                ),
                async_behavior=_async_behavior_for_action(action),  # type: ignore[arg-type]
                state_refresh=_state_refresh_for_action(action),  # type: ignore[arg-type]
            ),
        )
    return updated


V1_ACTIONS = _with_command_descriptors(V1_ACTIONS)


def get_action(action_id: str) -> ActionDefinition | None:
    """Return the action definition for *action_id*, or ``None``."""
    return V1_ACTIONS.get(action_id)


def list_actions() -> list[ActionDefinition]:
    """Return all registered V1 action definitions."""
    return list(V1_ACTIONS.values())


def project_action_catalog(definitions: list[ActionDefinition]) -> list[dict[str, Any]]:
    """Project registered actions into the public action-catalog contract.

    The returned keys are the stable API surface for ``GET /api/assistant/actions``.
    Internal implementation details such as handler references are intentionally
    omitted.
    """
    return [
        {
            "action_id": definition.action_id,
            "label": definition.label,
            "category": definition.category,
            "mutates": definition.mutates,
            "required_safety_mode": definition.required_safety_mode,
            "inputs_schema": dict(definition.input_schema),
            "preview_type": definition.preview_type,
            "command": definition.command.to_dict() if definition.command is not None else None,
        }
        for definition in definitions
    ]
