"""Mutation gateway for durable proposal operations.

All proposal operation mutations go through ``ProposalOperationWriter``.
The writer preserves the frozen dataclass contract by constructing fresh
instances and replacing them in the store; callers never mutate stored
``ProposalOperation`` objects in place. Template asset writes remain owned by
the existing asset store call sites and are intentionally outside this writer.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import Any

from obra.gateway.assistant.proposal_operation_store import (
    FilesystemProposalOperationStore,
    ProposalOperationStore,
)
from obra.gateway.assistant.proposal_operations import (
    ProposalOperation,
    ProposalOperationAttempt,
    ProposalOperationRecordRef,
    ProposalOperationStatus,
    _classify_record_outcome,
    _status_from_batch_response,
)

_TERMINAL_STATUSES = {"applied", "consumed", "rejected"}


class ProposalOperationWriter:
    """Write façade for durable proposal operations."""

    def __init__(self, store: ProposalOperationStore) -> None:
        self._store = store

    @classmethod
    def from_app_state(cls, app_state: object) -> "ProposalOperationWriter":
        """Extract or lazily create the writer from app state."""
        writer = getattr(app_state, "proposal_operation_writer", None)
        if writer is not None:
            return writer
        store = FilesystemProposalOperationStore.from_app_state(app_state)
        writer = cls(store)
        app_state.proposal_operation_writer = writer
        return writer

    @property
    def store(self) -> ProposalOperationStore:
        """Return the underlying store for read-side wiring."""
        return self._store

    def create(self, operation: ProposalOperation) -> None:
        """Persist a new operation, rejecting duplicate ids."""
        if self._store.get(operation.operation_id) is not None:
            raise ValueError(f"Proposal operation already exists: {operation.operation_id}")
        now = _utc_now()
        next_operation = replace(
            operation,
            created_at=operation.created_at or now,
            updated_at=operation.updated_at or now,
            attempt_count=operation.attempt_count or len(operation.attempt_history),
            last_attempt=operation.last_attempt
            or (operation.attempt_history[-1] if operation.attempt_history else None),
        )
        self._store.put(next_operation)

    def append_attempt(
        self,
        operation_id: str,
        attempt: ProposalOperationAttempt,
        source_record_indexes: Iterable[int] | None = None,
    ) -> ProposalOperation:
        """Append an apply attempt and update affected source references."""
        source_record_indexes = list(source_record_indexes or [])

        def updater(operation: ProposalOperation) -> ProposalOperation:
            history = [*operation.attempt_history, attempt]
            response = attempt.response if isinstance(attempt.response, Mapping) else {}
            refs = self._refs_with_batch_results(operation, response, source_record_indexes)
            status = _status_from_batch_response(response) if response else attempt.status
            return replace(
                operation,
                source_refs=refs,
                status=status,
                attempt_history=history,
                last_attempt=attempt,
                attempt_count=len(history),
                updated_at=_utc_now(),
                last_error=attempt.error_detail,
                conflict_summary=attempt.conflict_summary,
                resulting_revision_ref=attempt.resulting_revision_ref,
                canonical_sync_status=_canonical_response_value(
                    response,
                    "canonical_sync_status",
                    operation.canonical_sync_status,
                ),
                canonical_sync_error_code=_canonical_response_value(
                    response,
                    "canonical_sync_error_code",
                    operation.canonical_sync_error_code,
                ),
                canonical_sync_message=_canonical_response_value(
                    response,
                    "canonical_sync_message",
                    operation.canonical_sync_message,
                ),
                canonical_sync_operation_id=_canonical_response_value(
                    response,
                    "canonical_sync_operation_id",
                    operation.canonical_sync_operation_id,
                ),
                canonical_sync_failure_mode=_canonical_response_value(
                    response,
                    "canonical_sync_failure_mode",
                    operation.canonical_sync_failure_mode,
                ),
            )

        return self._store.mutate(operation_id, updater)

    def update_record_status(
        self,
        operation_id: str,
        source_record_index: int,
        status: str,
        **field_updates: Any,
    ) -> ProposalOperation:
        """Update one source reference immutably."""

        def updater(operation: ProposalOperation) -> ProposalOperation:
            refs: list[ProposalOperationRecordRef] = []
            for ref in operation.source_refs:
                if ref.source_record_index != source_record_index:
                    refs.append(ref)
                    continue
                updates = {"status": status, **field_updates}
                refs.append(replace(ref, **updates))
            return replace(
                operation,
                source_refs=refs,
                status=_derive_operation_status(refs, operation.status),
                updated_at=_utc_now(),
            )

        return self._store.mutate(operation_id, updater)

    def dismiss(
        self,
        operation_id: str,
        target_indexes: set[int] | None = None,
    ) -> ProposalOperation:
        """Mark targeted retryable records rejected."""

        def updater(operation: ProposalOperation) -> ProposalOperation:
            refs: list[ProposalOperationRecordRef] = []
            for ref in operation.source_refs:
                if target_indexes is not None and ref.source_record_index not in target_indexes:
                    refs.append(ref)
                    continue
                if ref.status in {"applied", "accepted"}:
                    refs.append(ref)
                    continue
                refs.append(replace(ref, status="rejected"))
            return replace(
                operation,
                source_refs=refs,
                status=_derive_operation_status(refs, "rejected"),
                updated_at=_utc_now(),
            )

        return self._store.mutate(operation_id, updater)

    def consume(
        self,
        operation_id: str,
        target_indexes: set[int] | None = None,
    ) -> ProposalOperation:
        """Mark pending source records consumed by an execution path."""

        def updater(operation: ProposalOperation) -> ProposalOperation:
            refs: list[ProposalOperationRecordRef] = []
            for ref in operation.source_refs:
                if target_indexes is not None and ref.source_record_index not in target_indexes:
                    refs.append(ref)
                    continue
                if ref.status != "pending":
                    refs.append(ref)
                    continue
                refs.append(replace(ref, status="consumed"))
            return replace(
                operation,
                source_refs=refs,
                status=_derive_operation_status(refs, "consumed"),
                updated_at=_utc_now(),
            )

        return self._store.mutate(operation_id, updater)

    def delete_for_workflow(self, workflow_id: str) -> int:
        """Delete every operation under one workflow."""
        normalized = str(workflow_id or "").strip()
        return self._store.delete_where(
            lambda operation: str(operation.workflow_id or "").strip() == normalized
        )

    def delete_for_user(self, user_id: str) -> int:
        """Delete every operation created by one user."""
        normalized = str(user_id or "").strip()
        return self._store.delete_where(
            lambda operation: str(operation.created_by or "").strip() == normalized
        )

    def expire_terminal_older_than(
        self,
        threshold_at: str,
        terminal_threshold_days: int = 90,
        conflict_threshold_days: int = 30,
    ) -> int:
        """Expire terminal operations older than configured thresholds."""
        threshold = _parse_ts(threshold_at) or datetime.now(tz=timezone.utc)
        terminal_cutoff = threshold - timedelta(days=terminal_threshold_days)
        conflict_cutoff = threshold - timedelta(days=conflict_threshold_days)

        def should_delete(operation: ProposalOperation) -> bool:
            status = str(operation.status or "").strip().lower()
            if status not in {*_TERMINAL_STATUSES, "conflict"}:
                return False
            updated_at = _parse_ts(operation.updated_at or operation.created_at)
            if updated_at is None:
                return False
            cutoff = conflict_cutoff if status == "conflict" else terminal_cutoff
            return updated_at < cutoff

        return self._store.delete_where(should_delete)

    def _require(self, operation_id: str) -> ProposalOperation:
        operation = self._store.get(operation_id)
        if operation is None:
            raise KeyError(f"Proposal operation not found: {operation_id}")
        return operation

    def _refs_with_batch_results(
        self,
        operation: ProposalOperation,
        response: Mapping[str, Any],
        source_record_indexes: Iterable[int] | None,
    ) -> list[ProposalOperationRecordRef]:
        target_indexes: set[int] = set()
        for index in source_record_indexes or []:
            try:
                normalized_index = int(index)
            except (TypeError, ValueError):
                continue
            if normalized_index >= 0:
                target_indexes.add(normalized_index)
        results_by_index: dict[int, Mapping[str, Any]] = {}
        results = response.get("results")
        for result in results if isinstance(results, list) else []:
            if not isinstance(result, Mapping):
                continue
            try:
                source_record_index = int(result.get("source_record_index"))
            except (TypeError, ValueError):
                continue
            results_by_index[source_record_index] = result
            target_indexes.add(source_record_index)

        refs: list[ProposalOperationRecordRef] = []
        for ref in operation.source_refs:
            if target_indexes and ref.source_record_index not in target_indexes:
                refs.append(ref)
                continue
            result = results_by_index.get(ref.source_record_index)
            if result is None:
                refs.append(ref)
                continue
            refs.append(_ref_from_result(ref, result))
        return refs


def _ref_from_result(
    ref: ProposalOperationRecordRef,
    result: Mapping[str, Any],
) -> ProposalOperationRecordRef:
    classification = _classify_record_outcome(result)
    outcome = str(classification.get("status") or "failed").strip().lower()
    payload = result.get("payload") if isinstance(result.get("payload"), Mapping) else {}
    return replace(
        ref,
        status=outcome or ref.status,
        audit_id=_normalize(result.get("audit_id") or payload.get("audit_id")),
        resulting_revision_ref=result.get("resulting_revision_ref")
        or payload.get("resulting_revision_ref")
        or ref.resulting_revision_ref,
        conflict_summary=result.get("conflict_summary")
        if isinstance(result.get("conflict_summary"), dict)
        else ref.conflict_summary,
        conflict_reason=_normalize(classification.get("conflict_reason")) or ref.conflict_reason,
        target_stage_id=_normalize(classification.get("target_stage_id")) or ref.target_stage_id,
        binding_summary=classification.get("binding_summary")
        if isinstance(classification.get("binding_summary"), dict)
        else ref.binding_summary,
        last_error=_result_error_detail(result),
    )


def _derive_operation_status(
    refs: list[ProposalOperationRecordRef],
    fallback: ProposalOperationStatus,
) -> ProposalOperationStatus:
    statuses = {str(ref.status or "").strip().lower() for ref in refs}
    if statuses and statuses <= {"consumed"}:
        return "consumed"
    if statuses and statuses <= {"applied", "accepted"}:
        return "applied"
    if statuses and statuses <= {"rejected"}:
        return "rejected"
    if statuses & {"applied", "accepted", "consumed"}:
        return "partial"
    if "conflict" in statuses:
        return "conflict"
    if "invalid" in statuses:
        return "invalid"
    if "failed" in statuses:
        return "failed"
    if "applying" in statuses:
        return "applying"
    if "pending" in statuses:
        return "pending"
    return fallback


def _result_error_detail(result: Mapping[str, Any]) -> str | None:
    detail = result.get("detail") or result.get("error") or result.get("validation_summary")
    if detail is None:
        return None
    return str(detail) if isinstance(detail, str) else repr(detail)


def _canonical_response_value(
    response: Mapping[str, Any],
    key: str,
    fallback: str | None,
) -> str | None:
    if key not in response:
        return fallback
    return _normalize(response.get(key))


def _parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _normalize(value: Any) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None
