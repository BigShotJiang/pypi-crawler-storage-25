"""Gateway-owned assistant command descriptor contract.

The gateway is the sole owner of execution routes and request-shape mapping.
Proposal records and CTAs emit serialized ``AssistantCommand`` dictionaries;
clients and harnesses consume those dictionaries instead of branching on
action ids. ``ActionDefinition`` describes a callable handler, while this
descriptor describes execution intent for a UI or automation consumer.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, get_args

RequestAdapter = Literal["action_execute", "pipeline_execute", "proposal_apply_all"]
AsyncBehavior = Literal["sync", "pipeline_long_running", "session_long_running"]
RefreshTarget = Literal[
    "workflow_head",
    "pending_proposals",
    "pipelines_active",
    "workflow_runs",
]

_ALLOWED_REQUEST_ADAPTERS = frozenset(get_args(RequestAdapter))
_ALLOWED_ASYNC_BEHAVIORS = frozenset(get_args(AsyncBehavior))
_ALLOWED_REFRESH_TARGETS = frozenset(get_args(RefreshTarget))


def _require_mapping(payload: Any) -> Mapping[str, Any]:
    if not isinstance(payload, Mapping):
        raise ValueError("AssistantCommand payload must be an object")
    return payload


def _required_string(payload: Mapping[str, Any], field_name: str) -> str:
    if field_name not in payload:
        raise ValueError(f"AssistantCommand.{field_name} is required")
    value = payload[field_name]
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"AssistantCommand.{field_name} must be a non-empty string")
    return value.strip()


@dataclass(frozen=True)
class AssistantCommand:
    """Serialized command descriptor emitted across the gateway API boundary."""

    command_id: str
    route: str
    request_adapter: RequestAdapter
    action_inputs_schema: dict[str, Any]
    async_behavior: AsyncBehavior
    state_refresh: list[RefreshTarget]
    method: Literal["POST"] = "POST"
    idempotency_key: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.command_id, str) or not self.command_id.strip():
            raise ValueError("AssistantCommand.command_id must be non-empty")
        if not isinstance(self.route, str) or not self.route.strip():
            raise ValueError("AssistantCommand.route must be non-empty")
        if self.method != "POST":
            raise ValueError("AssistantCommand.method must be POST")
        if self.request_adapter not in _ALLOWED_REQUEST_ADAPTERS:
            raise ValueError(f"AssistantCommand.request_adapter is invalid: {self.request_adapter}")
        if not isinstance(self.action_inputs_schema, dict):
            raise ValueError("AssistantCommand.action_inputs_schema must be an object")
        if self.async_behavior not in _ALLOWED_ASYNC_BEHAVIORS:
            raise ValueError(f"AssistantCommand.async_behavior is invalid: {self.async_behavior}")
        if not isinstance(self.state_refresh, list):
            raise ValueError("AssistantCommand.state_refresh must be a list")
        unknown_refresh = [
            item for item in self.state_refresh if item not in _ALLOWED_REFRESH_TARGETS
        ]
        if unknown_refresh:
            raise ValueError(
                "AssistantCommand.state_refresh contains invalid targets: "
                + ", ".join(str(item) for item in unknown_refresh)
            )
        if self.idempotency_key is not None and not isinstance(self.idempotency_key, str):
            raise ValueError("AssistantCommand.idempotency_key must be a string or null")

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe descriptor dictionary."""
        return {
            "command_id": self.command_id,
            "route": self.route,
            "method": self.method,
            "request_adapter": self.request_adapter,
            "action_inputs_schema": {
                str(key): dict(value) if isinstance(value, dict) else value
                for key, value in self.action_inputs_schema.items()
            },
            "idempotency_key": self.idempotency_key,
            "async_behavior": self.async_behavior,
            "state_refresh": list(self.state_refresh),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "AssistantCommand":
        """Build a command descriptor from a serialized dictionary."""
        source = _require_mapping(payload)
        method = _required_string(source, "method")
        request_adapter = _required_string(source, "request_adapter")
        async_behavior = _required_string(source, "async_behavior")
        raw_schema = source.get("action_inputs_schema")
        if not isinstance(raw_schema, Mapping):
            raise ValueError("AssistantCommand.action_inputs_schema must be an object")
        raw_refresh = source.get("state_refresh")
        if not isinstance(raw_refresh, list):
            raise ValueError("AssistantCommand.state_refresh must be a list")
        idempotency_key = source.get("idempotency_key")
        if idempotency_key is not None and not isinstance(idempotency_key, str):
            raise ValueError("AssistantCommand.idempotency_key must be a string or null")
        return cls(
            command_id=_required_string(source, "command_id"),
            route=_required_string(source, "route"),
            method=method,  # type: ignore[arg-type]
            request_adapter=request_adapter,  # type: ignore[arg-type]
            action_inputs_schema={
                str(key): dict(value) if isinstance(value, dict) else value
                for key, value in raw_schema.items()
            },
            idempotency_key=idempotency_key,
            async_behavior=async_behavior,  # type: ignore[arg-type]
            state_refresh=raw_refresh,  # type: ignore[arg-type]
        )


SYNTHETIC_CTA_COMMANDS: dict[str, AssistantCommand] = {
    "apply_pending_proposals": AssistantCommand(
        command_id="apply_pending_proposals",
        route="/api/assistant/proposals/operations/apply-all",
        request_adapter="proposal_apply_all",
        action_inputs_schema={
            "workflow_id": {"type": "string", "required": True},
            "working_dir": {"type": "string"},
        },
        idempotency_key=None,
        async_behavior="pipeline_long_running",
        state_refresh=["workflow_head", "pending_proposals", "pipelines_active"],
    )
}


def get_synthetic_command(command_id: str) -> AssistantCommand | None:
    """Return a gateway-owned descriptor for a CTA-only command."""
    return SYNTHETIC_CTA_COMMANDS.get(command_id)
