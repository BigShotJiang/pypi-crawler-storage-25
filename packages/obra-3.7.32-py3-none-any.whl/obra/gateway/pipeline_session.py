"""Background session manager for assistant pipeline executions."""

from __future__ import annotations

import asyncio
import contextvars
import inspect
import threading
from dataclasses import asdict, dataclass, is_dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Literal
from uuid import uuid4

from obra.gateway.event_bus import SessionEventBus


def _utc_now() -> datetime:
    return datetime.now(tz=timezone.utc)


@dataclass
class PipelineSessionRecord:
    """Tracks state for one background assistant pipeline execution."""

    id: str
    thread_id: str
    turn_id: str
    pipeline_id: str
    display_name: str | None
    status: Literal["running", "completed", "failed", "cancelled", "partial"]
    trigger_source: str
    event_bus: SessionEventBus
    cancel_event: threading.Event
    thread: threading.Thread
    created_at: datetime
    workflow_id: str | None = None
    revision_id: str | None = None
    cancel_reason: str | None = None
    chat_suppressed: bool = False
    result: dict[str, Any] | None = None
    terminal_payload: dict[str, Any] | None = None


class PipelineSessionLimitError(Exception):
    """Raised when the configured concurrent pipeline session limit is exceeded."""

    def __init__(self, max_pipeline_sessions: int) -> None:
        self.max_pipeline_sessions = max_pipeline_sessions
        super().__init__(
            f"Pipeline session limit reached: maximum {max_pipeline_sessions} concurrent sessions"
        )


class PipelineAlreadyRunningError(Exception):
    """Raised when the same workflow already has this pipeline in flight."""

    def __init__(
        self,
        *,
        operation_id: str,
        started_at: datetime,
        trigger_source: str,
    ) -> None:
        self.operation_id = operation_id
        self.started_at = started_at
        self.trigger_source = trigger_source
        super().__init__(
            f"Pipeline already running: operation_id={operation_id} "
            f"started_at={started_at.isoformat()} trigger_source={trigger_source}"
        )


class PipelineSessionManager:
    """Manage assistant pipeline executions in background threads."""

    _ACTIVE_STATUSES = {"pending", "running"}

    def __init__(
        self,
        max_pipeline_sessions: int,
        eviction_ttl_seconds: int,
        gateway_config: dict | None = None,
    ) -> None:
        self._sessions: dict[str, PipelineSessionRecord] = {}
        self._lock = threading.Lock()
        self._max_pipeline_sessions = int(max_pipeline_sessions)
        self._eviction_ttl_seconds = int(eviction_ttl_seconds)
        self._gateway_config = dict(gateway_config or {})
        self._terminal_marked_at: dict[str, datetime] = {}
        self._lifecycle_event_bus: SessionEventBus | None = None

    def create_session(
        self,
        thread_id: str,
        turn_id: str,
        pipeline_id: str,
        engine: Any,
        display_name: str | None,
        result_callback: Any,
        trigger_source: str,
        workflow_id: str | None = None,
        revision_id: str | None = None,
    ) -> str:
        """Create and start a background pipeline execution session."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            existing = self._active_for_pipeline_locked(workflow_id, pipeline_id)
            if existing is not None:
                raise PipelineAlreadyRunningError(
                    operation_id=existing.id,
                    started_at=existing.created_at,
                    trigger_source=existing.trigger_source,
                )
            running = sum(1 for existing in self._sessions.values() if existing.status == "running")
            if running >= self._max_pipeline_sessions:
                raise PipelineSessionLimitError(self._max_pipeline_sessions)

            session_id = uuid4().hex[:12]
            cancel_event = threading.Event()
            event_bus = SessionEventBus(
                session_id=session_id,
                max_queue_size=int(self._gateway_config["max_event_queue_size"]),
            )
            # Pipeline runs in a worker thread, so the request-scoped
            # ContextVars (e.g. browser-rig stub mode) must be copied
            # explicitly — they do not propagate across Thread boundaries.
            parent_context = contextvars.copy_context()
            thread = threading.Thread(
                target=parent_context.run,
                args=(
                    self._run_pipeline_in_thread,
                    session_id,
                    engine,
                    event_bus,
                    cancel_event,
                    result_callback,
                    trigger_source,
                ),
                name=f"assistant-pipeline-{session_id}",
                daemon=False,
            )
            record = PipelineSessionRecord(
                id=session_id,
                thread_id=thread_id,
                turn_id=turn_id,
                pipeline_id=pipeline_id,
                display_name=display_name,
                status="running",
                trigger_source=trigger_source,
                event_bus=event_bus,
                cancel_event=cancel_event,
                thread=thread,
                created_at=_utc_now(),
                workflow_id=workflow_id,
                revision_id=revision_id,
            )
            self._sessions[session_id] = record

        try:
            self._emit_lifecycle_event("pipeline_lifecycle.started", record)
            thread.start()
        except Exception:
            with self._lock:
                self._sessions.pop(session_id, None)
            raise
        return session_id

    def get_session(self, session_id: str) -> PipelineSessionRecord:
        """Return one tracked session or raise KeyError if not found."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            record = self._sessions.get(session_id)
            if record is None:
                raise KeyError(session_id)
            return record

    def cancel_session(
        self,
        session_id: str,
        reason: str | None = None,
        *,
        silent: bool = False,
    ) -> str | None:
        """Request cancellation for one tracked session.

        Returns the resulting status string (``"cancelling"``, ``"completed"``,
        ``"failed"``, etc.) or ``None`` when the session is unknown.
        """
        with self._lock:
            record = self._sessions.get(session_id)
            if record is None:
                return None
            current_status = record.status
            if current_status == "running":
                record.cancel_reason = str(reason or "").strip() or record.cancel_reason
                if silent:
                    record.chat_suppressed = True
                record.cancel_event.set()
        if current_status != "running":
            return current_status
        record.event_bus.push_event(
            "pipeline_cancel_requested",
            {
                "event": "pipeline_cancel_requested",
                "pipeline_id": record.pipeline_id,
                "thread_id": record.thread_id,
                "turn_id": record.turn_id,
                "detail": record.cancel_reason,
                "chat_suppressed": record.chat_suppressed,
            },
        )
        return "cancelling"

    def _cancel_reason(self, session_id: str) -> str | None:
        with self._lock:
            record = self._sessions.get(session_id)
            return record.cancel_reason if record is not None else None

    def _cancel_chat_suppressed(self, session_id: str) -> bool:
        with self._lock:
            record = self._sessions.get(session_id)
            return bool(record.chat_suppressed) if record is not None else False

    def list_active(
        self,
        thread_id: str | None = None,
        workflow_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return pipeline session summaries in authoritative newest-first order."""
        filtered = self.list_records(thread_id=thread_id, workflow_id=workflow_id)
        filtered.sort(
            key=lambda record: (
                0 if record.status == "running" else 1,
                -record.created_at.timestamp(),
            )
        )
        return [
            {
                "id": record.id,
                "pipeline_id": record.pipeline_id,
                "thread_id": record.thread_id,
                "turn_id": record.turn_id,
                "workflow_id": record.workflow_id,
                "revision_id": record.revision_id,
                "display_name": record.display_name,
                "status": record.status,
                "trigger_source": record.trigger_source,
                "event_count": max(record.event_bus.latest_sequence() + 1, 0),
                "created_at": record.created_at.isoformat(),
                "started_at_iso": record.created_at.isoformat(),
            }
            for record in filtered
        ]

    def list_active_for_pipeline(
        self,
        workflow_id: str | None,
        pipeline_id: str,
    ) -> list[PipelineSessionRecord]:
        """Return active sessions for one workflow/pipeline pair."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            return [
                record
                for record in self._sessions.values()
                if self._is_active_for_pipeline(record, workflow_id, pipeline_id)
            ]

    def list_records(
        self,
        thread_id: str | None = None,
        workflow_id: str | None = None,
    ) -> list[PipelineSessionRecord]:
        """Return the tracked pipeline records for shutdown coordination."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            records = list(self._sessions.values())
        return [
            record
            for record in records
            if (thread_id is None or record.thread_id == thread_id)
            and (workflow_id is None or record.workflow_id == workflow_id)
        ]

    def get_lifecycle_event_bus(self) -> SessionEventBus:
        """Return the topic bus for assistant pipeline lifecycle events."""
        with self._lock:
            if self._lifecycle_event_bus is None:
                self._lifecycle_event_bus = SessionEventBus(
                    session_id="pipeline_lifecycle",
                    max_queue_size=int(self._gateway_config["max_event_queue_size"]),
                )
            return self._lifecycle_event_bus

    def _active_for_pipeline_locked(
        self,
        workflow_id: str | None,
        pipeline_id: str,
    ) -> PipelineSessionRecord | None:
        if workflow_id is None:
            return None
        return next(
            (
                record
                for record in self._sessions.values()
                if self._is_active_for_pipeline(record, workflow_id, pipeline_id)
            ),
            None,
        )

    def _is_active_for_pipeline(
        self,
        record: PipelineSessionRecord,
        workflow_id: str | None,
        pipeline_id: str,
    ) -> bool:
        return (
            record.status in self._ACTIVE_STATUSES
            and record.workflow_id == workflow_id
            and record.pipeline_id == pipeline_id
        )

    def _emit_lifecycle_event(
        self,
        event_name: str,
        record: PipelineSessionRecord,
        **payload: Any,
    ) -> None:
        event_payload = {
            "event": event_name,
            "pipeline_session_id": record.id,
            "operation_id": record.id,
            "pipeline_id": record.pipeline_id,
            "thread_id": record.thread_id,
            "turn_id": record.turn_id,
            "workflow_id": record.workflow_id,
            "revision_id": record.revision_id,
            "status": record.status,
            "trigger_source": record.trigger_source,
            "started_at_iso": record.created_at.isoformat(),
            **payload,
        }
        self.get_lifecycle_event_bus().push_event(event_name, event_payload)

    def _evict_terminal_sessions_locked(self) -> None:
        if self._eviction_ttl_seconds <= 0:
            return
        cutoff = _utc_now() - timedelta(seconds=self._eviction_ttl_seconds)
        to_remove = [
            session_id
            for session_id, marked_at in self._terminal_marked_at.items()
            if marked_at <= cutoff
        ]
        for session_id in to_remove:
            self._terminal_marked_at.pop(session_id, None)
            self._sessions.pop(session_id, None)

    def _run_pipeline_in_thread(
        self,
        session_id: str,
        engine: Any,
        event_bus: SessionEventBus,
        cancel_event: threading.Event,
        result_callback: Any,
        trigger_source: str,
    ) -> None:
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            loop.run_until_complete(
                self._execute_pipeline_async(
                    session_id,
                    engine,
                    event_bus,
                    cancel_event,
                    result_callback,
                    trigger_source,
                )
            )
        finally:
            asyncio.set_event_loop(None)
            loop.close()

    async def _execute_pipeline_async(
        self,
        session_id: str,
        engine: Any,
        event_bus: SessionEventBus,
        cancel_event: threading.Event,
        result_callback: Any,
        trigger_source: str,
    ) -> None:
        terminal_status: Literal["completed", "failed", "cancelled", "partial"] = "completed"
        terminal_payload: dict[str, Any] | None = None
        terminal_callback_completed = False
        try:
            async for payload in engine.run(trigger_source=trigger_source):
                event_name = str(payload.get("event") or "pipeline_message")
                if cancel_event.is_set():
                    engine.cancel()
                if event_name == "pipeline_done":
                    if cancel_event.is_set():
                        terminal_status = "cancelled"
                        payload = {
                            **payload,
                            "status": "cancelled",
                            "detail": payload.get("detail") or self._cancel_reason(session_id),
                            "chat_suppressed": self._cancel_chat_suppressed(session_id),
                        }
                    else:
                        terminal_status = self._normalize_terminal_status(payload.get("status"))
                    persisted_turn = None
                    if not terminal_callback_completed:
                        callback_result = result_callback(payload)
                        if inspect.isawaitable(callback_result):
                            persisted_turn = await callback_result
                        else:
                            persisted_turn = callback_result
                        terminal_callback_completed = True
                    # Re-check cancel after potentially long result_callback.
                    if cancel_event.is_set() and terminal_status != "cancelled":
                        terminal_status = "cancelled"
                        payload = {
                            **payload,
                            "status": "cancelled",
                            "detail": payload.get("detail") or self._cancel_reason(session_id),
                            "chat_suppressed": self._cancel_chat_suppressed(session_id),
                        }
                    if persisted_turn is not None:
                        payload = {**payload, "turn": persisted_turn}
                    terminal_payload = dict(payload)
                elif event_name == "pipeline_cancelled":
                    terminal_status = "cancelled"
                    payload = {
                        **payload,
                        "status": "cancelled",
                        "detail": payload.get("detail") or self._cancel_reason(session_id),
                        "chat_suppressed": self._cancel_chat_suppressed(session_id),
                    }
                    persisted_turn = None
                    if not terminal_callback_completed:
                        callback_result = result_callback(payload)
                        if inspect.isawaitable(callback_result):
                            persisted_turn = await callback_result
                        else:
                            persisted_turn = callback_result
                        terminal_callback_completed = True
                    if persisted_turn is not None:
                        payload = {**payload, "turn": persisted_turn}
                    terminal_payload = dict(payload)
                event_bus.push_event(event_name, payload)
        except Exception as exc:
            terminal_status = "failed"
            payload = {
                    "event": "pipeline_done",
                    "pipeline_id": getattr(
                        getattr(engine, "pipeline_def", None), "pipeline_id", ""
                    ),
                    "status": "failed",
                    "detail": str(exc),
                    "proposal_count": 0,
                    "workflow_id": (
                        getattr(engine, "workflow_context", {}) or {}
                    ).get("workflow_id"),
                    "thread_id": getattr(engine, "thread_id", None),
                    "turn_id": getattr(engine, "turn_id", None),
            }
            persisted_turn = None
            if not terminal_callback_completed:
                callback_result = result_callback(payload)
                if inspect.isawaitable(callback_result):
                    persisted_turn = await callback_result
                else:
                    persisted_turn = callback_result
                terminal_callback_completed = True
            if persisted_turn is not None:
                payload = {**payload, "turn": persisted_turn}
            terminal_payload = dict(payload)
            event_bus.push_event("pipeline_done", payload)
        finally:
            with self._lock:
                record = self._sessions.get(session_id)
                if record is not None:
                    record.status = terminal_status
                    result = getattr(engine, "result", None)
                    if result is not None:
                        record.result = self._serialize_result(result)
                    if terminal_payload is not None:
                        record.terminal_payload = dict(terminal_payload)
                    self._terminal_marked_at[session_id] = _utc_now()
            if record is not None:
                self._emit_lifecycle_event(
                    f"pipeline_lifecycle.{terminal_status}",
                    record,
                    terminal_payload=dict(terminal_payload or {}),
                )
            event_bus.close()

    def _normalize_terminal_status(
        self,
        value: Any,
    ) -> Literal["completed", "failed", "cancelled", "partial"]:
        status = str(value or "").strip().lower()
        if status == "failed":
            return "failed"
        if status == "cancelled":
            return "cancelled"
        if status == "partial":
            return "partial"
        return "completed"

    def _serialize_result(self, result: Any) -> dict[str, Any] | None:
        if result is None:
            return None
        if is_dataclass(result):
            return asdict(result)
        if isinstance(result, dict):
            return dict(result)
        return {"value": result}
