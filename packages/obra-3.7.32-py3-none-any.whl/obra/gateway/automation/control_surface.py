"""Automation-facing control surface layered above canonical gateway owners."""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Literal

from fastapi import Request
from starlette.responses import StreamingResponse

from obra.gateway.automation.workspaces import resolve_gateway_workspace
from obra.gateway.workflow_studio.derivation_actions import WorkflowDerivationActionService
from obra.gateway.workflow_studio.events import build_event_envelope
from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

AutomationResourceKind = Literal["workflow_run", "workflow_derivation"]


class GatewayAutomationControlSurface:
    """Normalized automation API layered over canonical workflow-native owners."""

    def __init__(
        self,
        *,
        request: Request,
        repository: WorkflowStudioRepository,
        run_actions: WorkflowRunActionService,
        derivation_actions: WorkflowDerivationActionService,
    ) -> None:
        self._request = request
        self._repository = repository
        self._run_actions = run_actions
        self._derivation_actions = derivation_actions
        self._session_manager = request.app.state.session_manager
        client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
        self._client_factory = client_factory if callable(client_factory) else None

    @classmethod
    def from_request(cls, request: Request) -> "GatewayAutomationControlSurface":
        repository = WorkflowStudioRepository.from_request(request)
        return cls(
            request=request,
            repository=repository,
            run_actions=WorkflowRunActionService(
                request.app.state.session_manager,
                workflow_repository=repository,
                app_state=request.app.state,
            ),
            derivation_actions=WorkflowDerivationActionService(request.app.state.session_manager),
        )

    def launch_run(
        self,
        *,
        objective: str,
        project_id: str | None,
        working_dir: str | None,
        workflow_id: str | None,
        revision_id: str | None,
        domain_id: str | None,
        input_manifest: list[str] | None = None,
        input_payload: dict[str, str] | None = None,
        idempotency_key: str,
    ) -> dict[str, Any]:
        workspace = self._resolve_workspace(project_id=project_id, working_dir=working_dir)
        launched = self._run_actions.launch(
            objective=objective,
            project_id=workspace.project_id,
            working_dir=workspace.working_dir,
            workflow_id=workflow_id,
            revision_id=revision_id,
            domain_id=domain_id,
            input_manifest=input_manifest,
            input_payload=input_payload,
            idempotency_key=idempotency_key,
            repository=self._repository,
            client_factory=self._client_factory,
        )
        workflow_run = launched.get("workflow_run") or {}
        run_id = str(workflow_run.get("workflow_run_id") or workflow_run.get("run_id") or "")
        return self.get_resource(
            "workflow_run",
            run_id,
            workspace=workspace.to_payload(),
        )

    def launch_derivation(
        self,
        *,
        request_payload: dict[str, Any],
        project_id: str | None,
        working_dir: str | None,
        idempotency_key: str,
    ) -> dict[str, Any]:
        workspace = self._resolve_workspace(project_id=project_id, working_dir=working_dir)
        result = self._derivation_actions.create(
            request_payload=request_payload,
            idempotency_key=idempotency_key,
            project_id=workspace.project_id,
            working_dir=workspace.working_dir,
        )
        derivation_id = str(result.get("derivation_id") or "")
        return self.get_resource(
            "workflow_derivation",
            derivation_id,
            workspace=workspace.to_payload(),
            action_result=result,
        )

    def get_resource(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
        *,
        workspace: dict[str, Any] | None = None,
        action_result: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        record, canonical_resource = self._resolve_resource(resource_kind, resource_id)
        return {
            "automation_resource": {
                "resource_kind": resource_kind,
                "resource_id": resource_id,
                "status": record.status,
                "project_id": record.project_id,
                "working_dir": str(record.request_context.get("working_dir") or ""),
                "workflow_id": record.workflow_id,
                "workflow_revision_id": record.workflow_revision_id,
                "domain_id": record.domain_id,
                "workspace": workspace
                or {
                    "project_id": record.project_id,
                    "working_dir": str(record.request_context.get("working_dir") or ""),
                    "source": "existing_record",
                    "stored_working_dir": None,
                },
                "links": self._build_links(resource_kind, resource_id),
                "canonical_resource": canonical_resource,
                "action_result": action_result,
            }
        }

    def watch_resource(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
        *,
        filter_names: set[str] | None = None,
        after_sequence: int | None = None,
    ) -> StreamingResponse:
        record, event_bus = self._resolve_event_source(resource_kind, resource_id)
        return StreamingResponse(
            self._watch_generator(
                resource_kind=resource_kind,
                resource_id=resource_id,
                record=record,
                event_bus=event_bus,
                filter_names=filter_names,
                after_sequence=after_sequence,
            ),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
        )

    def cancel_resource(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
        *,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        if resource_kind == "workflow_run":
            result = self._run_actions.cancel(
                resource_id,
                client_request_id=client_request_id,
            )
        else:
            result = self._derivation_actions.cancel(resource_id)
        return {"automation_action": result}

    def dispatch_action(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
        *,
        action: str,
        payload: dict[str, Any],
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        if resource_kind == "workflow_run":
            result = self._run_actions.dispatch(
                resource_id,
                action=action,
                payload=payload,
                client_request_id=client_request_id,
            )
        else:
            result = self._derivation_actions.dispatch(
                resource_id,
                action=action,
                payload=payload,
            )
        return {"automation_action": result}

    def build_bootstrap_template(self) -> dict[str, Any]:
        """Return a generic private-automation integration contract template."""
        gateway_config = getattr(self._request.app.state, "gateway_config", {})
        return self.build_bootstrap_template_from_config(gateway_config)

    @staticmethod
    def build_bootstrap_template_from_config(
        gateway_config: dict[str, Any],
    ) -> dict[str, Any]:
        """Return a generic bootstrap contract from gateway config."""
        host = str(gateway_config.get("host") or "127.0.0.1")
        port = int(gateway_config.get("port") or 18790)
        return {
            "profile": "private-automation",
            "base_url": f"http://{host}:{port}",
            "auth": {
                "env_var": "OBRA_GATEWAY_AUTH_TOKEN",
                "header": "Authorization: Bearer <token>",
            },
            "workspace_resolution": [
                "explicit working_dir",
                "project metadata working_directory",
                "allowed_working_dir_base/<project_id> when it already exists",
            ],
            "automation_routes": {
                "launch_run": "/api/automation/runs",
                "launch_derivation": "/api/automation/derivations",
                "inspect_run": "/api/automation/runs/{run_id}",
                "inspect_derivation": "/api/automation/derivations/{derivation_id}",
                "watch_run": "/api/automation/runs/{run_id}/events",
                "watch_derivation": "/api/automation/derivations/{derivation_id}/events",
                "cancel_run": "/api/automation/runs/{run_id}/cancel",
                "cancel_derivation": "/api/automation/derivations/{derivation_id}/cancel",
                "run_actions": "/api/automation/runs/{run_id}/actions",
                "derivation_actions": "/api/automation/derivations/{derivation_id}/actions",
                "bootstrap_template": "/api/automation/bootstrap-template",
            },
        }

    def _resolve_workspace(
        self,
        *,
        project_id: str | None,
        working_dir: str | None,
    ) -> Any:
        gateway_config = getattr(self._request.app.state, "gateway_config", {})
        from pathlib import Path

        return resolve_gateway_workspace(
            project_id=project_id,
            working_dir=working_dir,
            allowed_base=Path(
                str(gateway_config.get("allowed_working_dir_base", "~/obra-projects"))
            ),
            client_factory=self._client_factory,
        )

    def _resolve_resource(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
    ) -> tuple[Any, dict[str, Any]]:
        if resource_kind == "workflow_run":
            record = self._session_manager.get_session(resource_id)
            canonical_resource = self._repository.get_run(resource_id)
        else:
            record = self._session_manager.get_session_by_derivation_id(resource_id)
            canonical_resource = self._repository.get_derivation(resource_id)
        if canonical_resource is None:
            raise KeyError(resource_id)
        return record, canonical_resource

    def _resolve_event_source(
        self,
        resource_kind: AutomationResourceKind,
        resource_id: str,
    ) -> tuple[Any, Any]:
        if resource_kind == "workflow_run":
            record = self._session_manager.get_session(resource_id)
            return record, record.event_bus
        record = self._session_manager.get_session_by_derivation_id(resource_id)
        return record, record.event_bus

    async def _watch_generator(
        self,
        *,
        resource_kind: AutomationResourceKind,
        resource_id: str,
        record: Any,
        event_bus: Any,
        filter_names: set[str] | None,
        after_sequence: int | None,
    ) -> AsyncIterator[str]:
        async for event in event_bus.subscribe(after_sequence=after_sequence):
            envelope = build_event_envelope(
                event,
                run_id=record.workflow_run_id,
                record=record,
                resource_type=resource_kind,
            )
            if filter_names and str(envelope.get("event_name")) not in filter_names:
                continue
            payload = {
                "resource_kind": resource_kind,
                "resource_id": resource_id,
                "event": envelope,
            }
            yield f"data: {json.dumps(payload)}\n\n"
        yield "data: [DONE]\n\n"

    @staticmethod
    def _build_links(
        resource_kind: AutomationResourceKind,
        resource_id: str,
    ) -> dict[str, str]:
        plural = "runs" if resource_kind == "workflow_run" else "derivations"
        canonical_plural = (
            "workflow-runs" if resource_kind == "workflow_run" else "workflow-derivations"
        )
        return {
            "self": f"/api/automation/{plural}/{resource_id}",
            "events": f"/api/automation/{plural}/{resource_id}/events",
            "actions": f"/api/automation/{plural}/{resource_id}/actions",
            "canonical": f"/api/{canonical_plural}/{resource_id}",
        }
