"""Canonical Workflow Studio event-stream routes."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from datetime import UTC, datetime
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status
from starlette.responses import StreamingResponse
from websockets.exceptions import ConnectionClosed

from obra.gateway.auth import (
    authenticate_request,
    authenticate_websocket_credentials,
    build_studio_websocket_principal,
)
from obra.gateway.security.client_ip import (
    extract_client_ip_from_request,
    extract_client_ip_from_websocket,
)
from obra.gateway.security.scopes import GatewayScope, insufficient_scope_detail
from obra.gateway.studio_browser import (
    is_studio_browser_authenticated_websocket,
)
from obra.gateway.workflow_studio.events import build_event_envelope

logger = logging.getLogger(__name__)

_SSE_KEEPALIVE_INTERVAL_S = 15.0
_DEFAULT_MAX_SSE_CONNECTIONS_TOTAL = 200
_DEFAULT_MAX_SSE_CONNECTIONS_PER_IP = 20
_MAX_WS_SUBSCRIPTIONS_PER_CONNECTION = 50
_DEFAULT_WORKFLOW_EVENTS_HEARTBEAT_SECONDS = 15.0
_DEFAULT_WORKFLOW_EVENTS_STALE_AFTER_MISSED_HEARTBEATS = 3

router = APIRouter(tags=["workflow-studio"])


class SSEConnectionTracker:
    """Track active SSE connections with per-IP admission limits."""

    def __init__(self) -> None:
        self._total: int = 0
        self._per_ip: dict[str, int] = {}

    def try_acquire(self, client_ip: str, *, max_total: int, max_per_ip: int) -> bool:
        if self._total >= max_total:
            return False
        if self._per_ip.get(client_ip, 0) >= max_per_ip:
            return False
        self._total += 1
        self._per_ip[client_ip] = self._per_ip.get(client_ip, 0) + 1
        return True

    def release(self, client_ip: str) -> None:
        self._total = max(0, self._total - 1)
        remaining = self._per_ip.get(client_ip, 0) - 1
        if remaining > 0:
            self._per_ip[client_ip] = remaining
        else:
            self._per_ip.pop(client_ip, None)


def _sse_connection_tracker(app: Any) -> SSEConnectionTracker:
    tracker = getattr(app.state, "_sse_connection_tracker", None)
    if isinstance(tracker, SSEConnectionTracker):
        return tracker
    tracker = SSEConnectionTracker()
    app.state._sse_connection_tracker = tracker
    return tracker


def _check_sse_admission(request: Request) -> str:
    """Check SSE connection limits; raise 429 if exceeded.  Returns client_ip."""
    gateway_config = getattr(request.app.state, "gateway_config", {})
    trusted_proxy_cidrs = list(gateway_config.get("trusted_proxy_cidrs", []))
    client_ip = extract_client_ip_from_request(request, trusted_proxy_cidrs)
    max_total = int(gateway_config.get("max_sse_connections_total", _DEFAULT_MAX_SSE_CONNECTIONS_TOTAL))
    max_per_ip = int(gateway_config.get("max_sse_connections_per_ip", _DEFAULT_MAX_SSE_CONNECTIONS_PER_IP))
    tracker = _sse_connection_tracker(request.app)
    if not tracker.try_acquire(client_ip, max_total=max_total, max_per_ip=max_per_ip):
        reason = (
            "global_limit"
            if tracker._total >= max_total
            else "per_ip_limit"
        )
        logger.warning(
            "obra_gateway_sse_rejected_total reason=%s client_ip=%s",
            reason,
            client_ip,
        )
        raise HTTPException(status_code=429, detail="Too many SSE connections")
    return client_ip


class EventStreamConnectionManager:
    """Track canonical event-stream connections and per-IP admission limits."""

    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()
        self._connection_ips: dict[int, str] = {}
        self._connection_client_ids: dict[int, str] = {}
        self._connections_by_client_id: dict[str, WebSocket] = {}
        self._connections_per_ip: dict[str, int] = {}

    def connect(
        self,
        ws: WebSocket,
        client_ip: str,
        client_id: str,
        *,
        max_total: int,
        max_per_ip: int,
    ) -> tuple[bool, str | None, WebSocket | None]:
        replaced = self._connections_by_client_id.get(client_id)
        if replaced is not None and replaced is not ws:
            self.disconnect(replaced)
        if len(self.connections) >= max_total:
            return False, "Too many WebSocket connections", None
        if self._connections_per_ip.get(client_ip, 0) >= max_per_ip:
            return False, "Too many WebSocket connections from this IP", None

        self.connections.add(ws)
        key = id(ws)
        self._connection_ips[key] = client_ip
        self._connection_client_ids[key] = client_id
        self._connections_by_client_id[client_id] = ws
        self._connections_per_ip[client_ip] = self._connections_per_ip.get(client_ip, 0) + 1
        return True, None, replaced

    def disconnect(self, ws: WebSocket) -> None:
        self.connections.discard(ws)
        key = id(ws)
        client_ip = self._connection_ips.pop(key, None)
        client_id = self._connection_client_ids.pop(key, None)
        if client_id is not None and self._connections_by_client_id.get(client_id) is ws:
            self._connections_by_client_id.pop(client_id, None)
        if client_ip is None:
            return
        remaining = self._connections_per_ip.get(client_ip, 0) - 1
        if remaining > 0:
            self._connections_per_ip[client_ip] = remaining
        else:
            self._connections_per_ip.pop(client_ip, None)


def _event_stream_transport_state(app: Any) -> dict[str, Any] | None:
    state = getattr(app.state, "workflow_event_stream_transport_state", None)
    return state if isinstance(state, dict) else None


def _event_stream_connection_manager(app: Any) -> EventStreamConnectionManager:
    manager = getattr(app.state, "workflow_event_stream_connection_manager", None)
    if isinstance(manager, EventStreamConnectionManager):
        return manager
    manager = EventStreamConnectionManager()
    app.state.workflow_event_stream_connection_manager = manager
    return manager


def _register_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.add(ws)


def _unregister_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.discard(ws)


def _event_stream_transport_enabled(ws: WebSocket) -> bool:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return True
    return bool(state.get("enabled", True))


def _event_stream_send_delay_s(ws: WebSocket) -> float:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return 0.0
    delay_ms = max(0, int(state.get("ws_send_delay_ms", 0) or 0))
    return delay_ms / 1000


def _event_stream_auth_timeout_s(ws: WebSocket) -> float:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return float(gateway_config.get("ws_auth_timeout_s", 5.0))


def _event_stream_heartbeat_seconds(ws: WebSocket) -> float:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return float(
        gateway_config.get(
            "workflow_events_heartbeat_seconds",
            _DEFAULT_WORKFLOW_EVENTS_HEARTBEAT_SECONDS,
        )
    )


def _event_stream_stale_after_missed_heartbeats(ws: WebSocket) -> int:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return int(
        gateway_config.get(
            "workflow_events_stale_after_missed_heartbeats",
            _DEFAULT_WORKFLOW_EVENTS_STALE_AFTER_MISSED_HEARTBEATS,
        )
    )


def _event_stream_connection_limits(ws: WebSocket) -> tuple[int, int]:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return (
        int(gateway_config.get("max_ws_connections_total", 200)),
        int(gateway_config.get("max_ws_connections_per_ip", 20)),
    )


def _allow_event_stream_control_message(ws: WebSocket) -> bool:
    limiter = getattr(ws.app.state, "ws_rate_limiter", None)
    if limiter is None:
        return True
    client_ip = str(ws.scope.get("gateway_client_ip", "0.0.0.0"))
    return limiter.allow(client_ip)


def _event_stream_send_lock(ws: WebSocket) -> asyncio.Lock:
    lock = getattr(ws.state, "workflow_event_stream_send_lock", None)
    if lock is None:
        lock = asyncio.Lock()
        ws.state.workflow_event_stream_send_lock = lock
    return lock


async def _ensure_http_auth(request: Request) -> None:
    principal = await authenticate_request(
        request,
        token=str(request.app.state.gateway_token),
        token_registry=list(getattr(request.app.state, "gateway_token_registry", [])),
    )
    if GatewayScope.READ.value not in principal.scopes:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=insufficient_scope_detail(GatewayScope.READ),
        )


async def _event_generator(
    event_bus: Any,
    record: Any | None,
    resource_id: str,
    filter_names: set[str] | None = None,
    after_sequence: int | None = None,
    *,
    resource_type: str = "workflow_run",
) -> AsyncIterator[str]:
    subscription = event_bus.subscribe(after_sequence=after_sequence).__aiter__()
    while True:
        try:
            event = await asyncio.wait_for(
                subscription.__anext__(),
                timeout=_SSE_KEEPALIVE_INTERVAL_S,
            )
        except asyncio.TimeoutError:
            yield ":keepalive\n\n"
            continue
        except StopAsyncIteration:
            break
        payload = build_event_envelope(
            event,
            run_id=(record.workflow_run_id if record is not None else resource_id),
            record=record,
            resource_type=resource_type,
        )
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        yield f"data: {json.dumps(payload)}\n\n"

    yield "data: [DONE]\n\n"


def _resolve_http_event_source(
    request: Request,
    resource_id: str,
    *,
    resource_type: str,
) -> tuple[Any | None, Any]:
    session_manager = request.app.state.session_manager
    try:
        if resource_type == "workflow_derivation":
            record = session_manager.get_session_by_derivation_id(resource_id)
            return record, record.event_bus
        if resource_type == "workflow":
            return None, session_manager.get_workflow_event_bus(resource_id)
        record = session_manager.get_session(resource_id)
        return record, record.event_bus
    except Exception as exc:
        detail = (
            "Workflow derivation not found"
            if resource_type == "workflow_derivation"
            else ("Workflow not found" if resource_type == "workflow" else "Workflow run not found")
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail) from exc


@router.get("/api/workflow-runs/{run_id}/events")
async def stream_workflow_run_events(
    run_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    client_ip = _check_sse_admission(request)
    record, event_bus = _resolve_http_event_source(
        request,
        run_id,
        resource_type="workflow_run",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None

    async def _tracked_generator() -> AsyncIterator[str]:
        try:
            async for chunk in _event_generator(event_bus, record, run_id, filter_names, after_sequence):
                yield chunk
        finally:
            _sse_connection_tracker(request.app).release(client_ip)

    return StreamingResponse(
        _tracked_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflow-derivations/{derivation_id}/events")
async def stream_workflow_derivation_events(
    derivation_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    client_ip = _check_sse_admission(request)
    record, event_bus = _resolve_http_event_source(
        request,
        derivation_id,
        resource_type="workflow_derivation",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None

    async def _tracked_generator() -> AsyncIterator[str]:
        try:
            async for chunk in _event_generator(
                event_bus, record, derivation_id, filter_names, after_sequence,
                resource_type="workflow_derivation",
            ):
                yield chunk
        finally:
            _sse_connection_tracker(request.app).release(client_ip)

    return StreamingResponse(
        _tracked_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflows/{workflow_id}/events")
async def stream_workflow_events(
    workflow_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    client_ip = _check_sse_admission(request)
    record, event_bus = _resolve_http_event_source(
        request,
        workflow_id,
        resource_type="workflow",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None

    async def _tracked_generator() -> AsyncIterator[str]:
        try:
            async for chunk in _event_generator(
                event_bus, record, workflow_id, filter_names, after_sequence,
                resource_type="workflow",
            ):
                yield chunk
        finally:
            _sse_connection_tracker(request.app).release(client_ip)

    return StreamingResponse(
        _tracked_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


def _validate_ws_origin(ws: WebSocket) -> bool:
    """Reject WebSocket upgrades from unexpected origins (CSWSH defense)."""
    origin = (ws.headers.get("origin") or "").strip().lower()
    if not origin:
        return True  # Non-browser clients (CLI, MCP) don't send Origin
    from urllib.parse import urlparse

    parsed = urlparse(origin)
    host = parsed.hostname or ""
    # Allow loopback origins (localhost, 127.x, ::1)
    if host in ("localhost", "127.0.0.1", "[::1]", "::1") or host.startswith("127."):
        return True
    # Allow same-host origin (gateway's own address)
    server_host = (ws.headers.get("host") or "").split(":")[0].strip().lower()
    if host == server_host:
        return True
    return False


async def _admit_event_stream_connection(
    ws: WebSocket,
) -> tuple[str, EventStreamConnectionManager] | None:
    """Validate origin/client_id/IP and reserve a connection slot.

    Returns (client_id, manager) on success, or None if the connection was
    rejected (an appropriate close frame has already been sent).
    """
    if not _validate_ws_origin(ws):
        await ws.close(code=4003, reason="Origin not allowed")
        return None
    await ws.accept()
    try:
        client_id = _require_client_id(ws.query_params)
    except ValueError as exc:
        await _close_with_error(ws, str(exc), 4400)
        return None
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    trusted_proxy_cidrs = list(gateway_config.get("trusted_proxy_cidrs", []))
    client_ip = extract_client_ip_from_websocket(ws, trusted_proxy_cidrs)
    ws.scope["gateway_client_ip"] = client_ip
    max_total_connections, max_connections_per_ip = _event_stream_connection_limits(ws)
    manager = _event_stream_connection_manager(ws.app)
    accepted, error, replaced_socket = manager.connect(
        ws,
        client_ip,
        client_id,
        max_total=max_total_connections,
        max_per_ip=max_connections_per_ip,
    )
    if not accepted:
        await _close_with_error(ws, error or "Too many WebSocket connections", 4003)
        return None
    if replaced_socket is not None:
        with contextlib.suppress(Exception):
            await replaced_socket.close(code=1012, reason="Superseded by newer client connection")
    return client_id, manager


async def _authenticate_event_stream(ws: WebSocket) -> tuple[bool, str | None]:
    """Perform the websocket auth handshake.

    Returns (authenticated, first_control_message_or_None). When authentication
    fails, a close frame has already been sent and ``authenticated`` is False.
    For the browser-authenticated path, a non-auth first frame is kept as the
    first control message so the caller can use it as the initial subscribe.
    """
    if is_studio_browser_authenticated_websocket(ws):
        try:
            first_control_message: str | None = await asyncio.wait_for(
                ws.receive_text(),
                timeout=_event_stream_auth_timeout_s(ws),
            )
        except asyncio.TimeoutError:
            await _close_with_error(ws, "Subscription timeout", 4001)
            return False, None
        except WebSocketDisconnect:
            return False, None
        if _is_auth_frame(first_control_message):
            try:
                authenticate_websocket_credentials(
                    ws,
                    first_control_message,
                    token=str(ws.app.state.gateway_token),
                    token_registry=list(getattr(ws.app.state, "gateway_token_registry", [])),
                )
                first_control_message = None
            except HTTPException as exc:
                await _close_with_error(ws, str(exc.detail), 4001)
                return False, None
        else:
            build_studio_websocket_principal(ws)
        return True, first_control_message

    try:
        auth_raw = await asyncio.wait_for(
            ws.receive_text(),
            timeout=_event_stream_auth_timeout_s(ws),
        )
    except asyncio.TimeoutError:
        await _close_with_error(ws, "Authentication timeout", 4001)
        return False, None
    except WebSocketDisconnect:
        return False, None
    try:
        authenticate_websocket_credentials(
            ws,
            auth_raw,
            token=str(ws.app.state.gateway_token),
            token_registry=list(getattr(ws.app.state, "gateway_token_registry", [])),
        )
    except HTTPException as exc:
        await _close_with_error(ws, str(exc.detail), 4001)
        return False, None
    return True, None


async def _apply_initial_subscribe(
    ws: WebSocket,
    *,
    send_lock: asyncio.Lock,
    first_control_message: str | None,
    replace_subscription: Any,
) -> bool:
    """Process the initial subscribe frame. Returns True on success."""
    if first_control_message is None:
        subscribe_raw = await ws.receive_text()
    else:
        subscribe_raw = first_control_message
    if not _allow_event_stream_control_message(ws):
        await _close_with_error(ws, "Rate limit exceeded", 4008)
        return False
    try:
        control_type, subscriptions = _parse_subscription_message(
            subscribe_raw,
            query_params=ws.query_params,
        )
    except ValueError as exc:
        await _close_with_error(ws, str(exc), 4400)
        return False
    if control_type != "subscribe" or not subscriptions:
        await _close_with_error(
            ws,
            "run_id, derivation_id, workflow_id, workflow_collection_id, or topic is required",
            4400,
        )
        return False

    try:
        for subscription in subscriptions:
            await replace_subscription(subscription)
    except Exception as exc:
        await _close_with_error(ws, str(exc), 4400)
        return False

    if _message_declares_type(subscribe_raw):
        await _send_control_message(
            ws,
            send_lock,
            {
                "type": "subscribed",
                "subscriptions": [_subscription_payload(item) for item in subscriptions],
            },
        )
    return True


async def _handle_control_frame(
    ws: WebSocket,
    control_raw: str,
    *,
    send_lock: asyncio.Lock,
    client_id: str,
    heartbeat_state: dict[str, Any],
    replace_subscription: Any,
    remove_subscription: Any,
) -> None:
    """Process a single post-subscribe control frame."""
    if not _allow_event_stream_control_message(ws):
        await _send_control_message(
            ws, send_lock, {"type": "error", "detail": "Rate limit exceeded"}
        )
        return
    try:
        control_payload = _parse_control_payload(control_raw)
    except ValueError as exc:
        await _send_control_message(ws, send_lock, {"type": "error", "detail": str(exc)})
        return
    control_payload_type = str(control_payload.get("type") or "subscribe").strip().lower()
    if control_payload_type == "heartbeat_ack":
        if not _acknowledge_heartbeat(
            payload=control_payload,
            client_id=client_id,
            heartbeat_state=heartbeat_state,
        ):
            await _send_control_message(
                ws,
                send_lock,
                {"type": "error", "detail": "Invalid heartbeat acknowledgement"},
            )
        return
    try:
        control_type, subscriptions = _parse_subscription_message(control_raw)
    except ValueError as exc:
        await _send_control_message(ws, send_lock, {"type": "error", "detail": str(exc)})
        return
    if control_type == "ping":
        await _send_control_message(ws, send_lock, {"type": "pong"})
        return
    if not subscriptions:
        await _send_control_message(
            ws, send_lock, {"type": "error", "detail": "No subscriptions supplied"}
        )
        return
    try:
        if control_type == "subscribe":
            for subscription in subscriptions:
                await replace_subscription(subscription)
            await _send_control_message(
                ws,
                send_lock,
                {
                    "type": "subscribed",
                    "subscriptions": [
                        _subscription_payload(item) for item in subscriptions
                    ],
                },
            )
        elif control_type == "unsubscribe":
            for subscription in subscriptions:
                await remove_subscription(subscription)
            await _send_control_message(
                ws,
                send_lock,
                {
                    "type": "unsubscribed",
                    "subscriptions": [
                        _subscription_payload(item) for item in subscriptions
                    ],
                },
            )
    except Exception as exc:
        await _send_control_message(ws, send_lock, {"type": "error", "detail": str(exc)})


@router.websocket("/api/events/stream")
async def workflow_event_stream(ws: WebSocket) -> None:
    admission = await _admit_event_stream_connection(ws)
    if admission is None:
        return
    client_id, manager = admission

    _register_event_stream_socket(ws)
    subscription_tasks: dict[str, asyncio.Task[None]] = {}
    send_lock = _event_stream_send_lock(ws)
    heartbeat_state: dict[str, Any] = {
        "pending_heartbeat_id": None,
        "missed_heartbeats": 0,
    }
    heartbeat_task: asyncio.Task[None] | None = None

    try:
        if not _event_stream_transport_enabled(ws):
            await ws.close(code=1013, reason="Workflow event stream temporarily unavailable")
            return

        authenticated, first_control_message = await _authenticate_event_stream(ws)
        if not authenticated:
            return

        if not _websocket_has_scope(ws, GatewayScope.READ):
            await _close_with_error(ws, f"Required scope: {GatewayScope.READ.value}", 4403)
            return

        async def _replace_subscription(subscription: dict[str, Any]) -> None:
            key = _subscription_key(subscription)
            existing = subscription_tasks.pop(key, None)
            if existing is not None:
                await _cancel_subscription(existing)
            elif len(subscription_tasks) >= _MAX_WS_SUBSCRIPTIONS_PER_CONNECTION:
                async with send_lock:
                    await ws.send_text(json.dumps({
                        "type": "error",
                        "error": "subscription_limit_exceeded",
                        "message": f"Maximum {_MAX_WS_SUBSCRIPTIONS_PER_CONNECTION} subscriptions per connection",
                    }))
                return

            session_manager = ws.app.state.session_manager
            record, event_bus, run_ref = _resolve_event_bus(
                ws.app,
                session_manager,
                subscription["resource_type"],
                subscription["resource_id"],
            )
            subscription_tasks[key] = asyncio.create_task(
                _stream_subscription(
                    ws,
                    subscription=subscription,
                    send_lock=send_lock,
                    event_bus=event_bus,
                    record=record,
                    run_ref=run_ref,
                )
            )

        async def _remove_subscription(subscription: dict[str, Any]) -> None:
            task = subscription_tasks.pop(_subscription_key(subscription), None)
            if task is not None:
                await _cancel_subscription(task)

        if not await _apply_initial_subscribe(
            ws,
            send_lock=send_lock,
            first_control_message=first_control_message,
            replace_subscription=_replace_subscription,
        ):
            return

        heartbeat_task = asyncio.create_task(
            _event_stream_heartbeat_loop(
                ws,
                send_lock=send_lock,
                client_id=client_id,
                heartbeat_state=heartbeat_state,
            )
        )

        while True:
            control_raw = await ws.receive_text()
            await _handle_control_frame(
                ws,
                control_raw,
                send_lock=send_lock,
                client_id=client_id,
                heartbeat_state=heartbeat_state,
                replace_subscription=_replace_subscription,
                remove_subscription=_remove_subscription,
            )
    except (WebSocketDisconnect, ConnectionClosed):
        pass
    finally:
        if heartbeat_task is not None:
            await _cancel_subscription(heartbeat_task)
        _unregister_event_stream_socket(ws)
        manager.disconnect(ws)
        for task in subscription_tasks.values():
            await _cancel_subscription(task)


def _message_declares_type(raw_message: str) -> bool:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and isinstance(payload.get("type"), str)


def _is_auth_frame(raw_message: str) -> bool:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and str(payload.get("type") or "").strip().lower() == "auth"


def _websocket_has_scope(ws: WebSocket, scope: GatewayScope) -> bool:
    configured_scopes = getattr(ws.state, "gateway_scopes", frozenset())
    if not isinstance(configured_scopes, frozenset):
        configured_scopes = frozenset(configured_scopes or [])
    return scope.value in configured_scopes


def _parse_subscription_message(
    raw_message: str,
    *,
    query_params: Any | None = None,
) -> tuple[str, list[dict[str, Any]]]:
    payload = _parse_control_payload(raw_message)

    control_type = str(payload.get("type") or "subscribe").strip().lower()
    if control_type == "ping":
        return "ping", []
    if control_type not in {"subscribe", "unsubscribe"}:
        raise ValueError(f"Unsupported control message type: {control_type}")

    subscriptions = _normalize_subscriptions(payload, query_params=query_params)
    return control_type, subscriptions


def _normalize_subscriptions(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> list[dict[str, Any]]:
    if isinstance(payload.get("subscriptions"), list):
        subscriptions = [
            _parse_subscription_payload(item)
            for item in payload["subscriptions"]
            if isinstance(item, dict)
        ]
    else:
        subscriptions = [_parse_subscription_payload(payload, query_params=query_params)]
    return [item for item in subscriptions if item is not None]


def _parse_subscription_payload(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> dict[str, Any] | None:
    run_id = str(payload.get("run_id") or _query_value(query_params, "run_id") or "").strip()
    derivation_id = str(
        payload.get("derivation_id") or _query_value(query_params, "derivation_id") or ""
    ).strip()
    workflow_id = str(
        payload.get("workflow_id") or _query_value(query_params, "workflow_id") or ""
    ).strip()
    workflow_collection_id = str(
        payload.get("workflow_collection_id")
        or _query_value(query_params, "workflow_collection_id")
        or ""
    ).strip()
    topic = str(payload.get("topic") or _query_value(query_params, "topic") or "").strip()
    provided = [
        ("workflow_run", run_id),
        ("workflow_derivation", derivation_id),
        ("workflow", workflow_id),
        ("workflow_collection", workflow_collection_id),
        ("topic", topic),
    ]
    selected = [
        (resource_type, resource_id) for resource_type, resource_id in provided if resource_id
    ]
    if not selected:
        return None
    if len(selected) > 1:
        raise ValueError(
            "Exactly one of run_id, derivation_id, workflow_id, workflow_collection_id, or topic is allowed"
        )

    resource_type, resource_id = selected[0]
    if resource_type == "topic" and resource_id not in {"pipeline_lifecycle", "run_lifecycle"}:
        raise ValueError("Unsupported topic subscription")
    return {
        "resource_type": resource_type,
        "resource_id": resource_id,
        "after_sequence": _normalize_after_sequence(payload.get("after_sequence")),
        "filter_names": _normalize_filter_names(payload.get("filter")),
    }


def _normalize_after_sequence(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip():
        return int(value)
    return None


def _normalize_filter_names(value: Any) -> set[str] | None:
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, list):
        items = [str(item).strip() for item in value]
    else:
        return None
    normalized = {item for item in items if item}
    return normalized or None


def _query_value(query_params: Any | None, key: str) -> str | None:
    if query_params is None:
        return None
    getter = getattr(query_params, "get", None)
    if callable(getter):
        value = getter(key)
        if value is not None:
            return str(value)
    return None


def _require_client_id(query_params: Any | None) -> str:
    client_id = str(_query_value(query_params, "client_id") or "").strip()
    if not client_id:
        raise ValueError("client_id is required")
    return client_id


def _parse_control_payload(raw_message: str) -> dict[str, Any]:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError as exc:
        raise ValueError("Invalid event-stream control message") from exc

    if not isinstance(payload, dict):
        raise ValueError("Control message must be a JSON object")
    return payload


def _heartbeat_payload(
    *,
    client_id: str,
    heartbeat_id: int,
    interval_s: float,
    stale_after_missed_heartbeats: int,
) -> dict[str, Any]:
    return {
        "type": "heartbeat",
        "client_id": client_id,
        "heartbeat_id": heartbeat_id,
        "interval_seconds": interval_s,
        "stale_after_missed_heartbeats": stale_after_missed_heartbeats,
        "ts": datetime.now(tz=UTC).isoformat(),
    }


def _acknowledge_heartbeat(
    *,
    payload: dict[str, Any],
    client_id: str,
    heartbeat_state: dict[str, Any],
) -> bool:
    ack_client_id = str(payload.get("client_id") or "").strip()
    if ack_client_id != client_id:
        return False
    ack_heartbeat_id = payload.get("heartbeat_id")
    pending_heartbeat_id = heartbeat_state.get("pending_heartbeat_id")
    if pending_heartbeat_id is None or ack_heartbeat_id != pending_heartbeat_id:
        return False
    heartbeat_state["pending_heartbeat_id"] = None
    heartbeat_state["missed_heartbeats"] = 0
    return True


def _resolve_event_bus(
    app: Any,
    session_manager: Any,
    resource_type: str,
    resource_id: str,
) -> tuple[Any | None, Any, str]:
    if resource_type == "topic":
        if resource_id == "pipeline_lifecycle":
            pipeline_session_manager = app.state.pipeline_session_manager
            return None, pipeline_session_manager.get_lifecycle_event_bus(), resource_id
        return None, session_manager.get_topic_event_bus(resource_id), resource_id
    if resource_type == "workflow_derivation":
        record = session_manager.get_session_by_derivation_id(resource_id)
        return record, record.event_bus, record.workflow_run_id
    if resource_type == "workflow":
        return None, session_manager.get_workflow_event_bus(resource_id), resource_id
    if resource_type == "workflow_collection":
        return None, session_manager.get_workflow_collection_event_bus(resource_id), resource_id
    record = session_manager.get_session(resource_id)
    return record, record.event_bus, record.workflow_run_id


async def _stream_subscription(
    ws: WebSocket,
    *,
    subscription: dict[str, Any],
    send_lock: asyncio.Lock,
    event_bus: Any,
    record: Any,
    run_ref: str,
) -> None:
    async for event in event_bus.subscribe(after_sequence=subscription.get("after_sequence")):
        if subscription["resource_type"] == "topic":
            payload = _build_topic_event_envelope(event, topic=run_ref)
        else:
            payload = build_event_envelope(
                event,
                run_id=run_ref,
                record=record,
                resource_type=subscription["resource_type"],
            )
        filter_names = subscription.get("filter_names")
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        payload.update(
            {
                "stream_resource_type": subscription["resource_type"],
                "stream_resource_id": subscription["resource_id"],
                "subscription_id": _subscription_key(subscription),
            }
        )
        await _send_control_message(ws, send_lock, payload)


def _build_topic_event_envelope(event: dict[str, Any], *, topic: str) -> dict[str, Any]:
    raw_payload = event.get("payload")
    payload = dict(raw_payload) if isinstance(raw_payload, dict) else {}
    event_name = str(event.get("event_type") or payload.get("event") or f"{topic}.event")
    workflow_run_id = str(
        payload.get("workflow_run_id")
        or payload.get("run_id")
        or payload.get("pipeline_session_id")
        or ""
    ).strip()
    return {
        "resource_type": "workflow_event",
        "event_id": event.get("event_id") or f"{topic}:{event.get('sequence', 0)}",
        "event_name": event_name,
        "sequence": event.get("sequence", 0),
        "timestamp": event.get("timestamp"),
        "workflow_run_id": workflow_run_id or None,
        "workflow_derivation_id": None,
        "payload": payload,
        "correlation": {
            "topic": topic,
            "workflow_run_id": workflow_run_id or None,
            "workflow_id": payload.get("workflow_id"),
            "workflow_revision_id": payload.get("workflow_revision_id")
            or payload.get("revision_id"),
            "pipeline_session_id": payload.get("pipeline_session_id"),
            "operation_id": payload.get("operation_id"),
            "thread_id": payload.get("thread_id"),
            "turn_id": payload.get("turn_id"),
        },
    }


async def _broadcast_presence_stale(
    app: Any,
    *,
    client_id: str,
    detail: str,
    exclude_ws: WebSocket | None = None,
) -> None:
    payload = {
        "type": "presence.stale",
        "client_id": client_id,
        "detail": detail,
        "ts": datetime.now(tz=UTC).isoformat(),
    }
    manager = _event_stream_connection_manager(app)
    failed_sockets: list[WebSocket] = []
    for socket in tuple(manager.connections):
        if socket is exclude_ws:
            continue
        try:
            await _send_control_message(socket, _event_stream_send_lock(socket), payload)
        except Exception:
            failed_sockets.append(socket)
    for socket in failed_sockets:
        manager.disconnect(socket)


async def _event_stream_heartbeat_loop(
    ws: WebSocket,
    *,
    send_lock: asyncio.Lock,
    client_id: str,
    heartbeat_state: dict[str, Any],
) -> None:
    heartbeat_seconds = _event_stream_heartbeat_seconds(ws)
    stale_after_missed_heartbeats = _event_stream_stale_after_missed_heartbeats(ws)
    heartbeat_id = 0
    while True:
        await asyncio.sleep(heartbeat_seconds)
        if heartbeat_state.get("pending_heartbeat_id") is not None:
            heartbeat_state["missed_heartbeats"] = int(heartbeat_state.get("missed_heartbeats", 0)) + 1
        if int(heartbeat_state.get("missed_heartbeats", 0)) >= stale_after_missed_heartbeats:
            await _broadcast_presence_stale(
                ws.app,
                client_id=client_id,
                detail="Workflow event stream heartbeat timed out",
                exclude_ws=ws,
            )
            try:
                await ws.close(code=1013, reason="Workflow event stream heartbeat timed out")
            except Exception:
                pass
            return
        heartbeat_id += 1
        heartbeat_state["pending_heartbeat_id"] = heartbeat_id
        await _send_control_message(
            ws,
            send_lock,
            _heartbeat_payload(
                client_id=client_id,
                heartbeat_id=heartbeat_id,
                interval_s=heartbeat_seconds,
                stale_after_missed_heartbeats=stale_after_missed_heartbeats,
            ),
        )


def _subscription_key(subscription: dict[str, Any]) -> str:
    return f"{subscription['resource_type']}:{subscription['resource_id']}"


def _subscription_payload(subscription: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "subscription_id": _subscription_key(subscription),
        "resource_type": subscription["resource_type"],
        "resource_id": subscription["resource_id"],
    }
    if subscription.get("after_sequence") is not None:
        payload["after_sequence"] = subscription["after_sequence"]
    if subscription.get("filter_names"):
        payload["filter"] = sorted(subscription["filter_names"])
    return payload


async def _send_control_message(
    ws: WebSocket,
    send_lock: asyncio.Lock,
    payload: dict[str, Any],
) -> None:
    async with send_lock:
        delay_s = _event_stream_send_delay_s(ws)
        if delay_s > 0:
            await asyncio.sleep(delay_s)
        await ws.send_text(json.dumps(payload))


async def _cancel_subscription(task: asyncio.Task[None]) -> None:
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task


async def _close_with_error(ws: WebSocket, detail: str, code: int) -> None:
    try:
        await ws.send_text(json.dumps({"type": "error", "detail": detail}))
        await ws.close(code=code)
    except Exception:
        pass
