"""Google Gemini CLI provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import re
import subprocess
from typing import Any

from obra.config.cli_resolution import (
    excerpt_diagnostic_text,
    resolve_cli_path,
    verify_provider_binary,
)
from obra.config.loaders import get_gateway_onboarding_config
from obra.execution.os_compat import build_subprocess_env
from obra.gateway.providers._terminal_handoff import open_command_in_terminal

# Gemini CLI's ``--version`` output is a bare semver string (``0.38.2``) with
# no app signature. We match against ``--help`` instead, which reliably
# contains the phrase ``Gemini CLI``. The version is captured from
# ``--version`` separately so we can still surface it.
_GEMINI_CLI_SIGNATURE = re.compile(r"Gemini CLI", re.IGNORECASE)


def detect_gemini_cli() -> dict[str, Any]:
    """Detect whether the Gemini CLI binary is installed.

    Returns a dict with ``installed`` and either ``path``/``version`` on
    success, or ``install_issue`` + diagnostic fields on a binary-name
    collision or execution failure. See :func:`claude_code.detect_claude_code`
    for the full payload shape contract.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
            "install_command": "npm install -g @google/gemini-cli",
        }

    verification = verify_provider_binary(
        binary_path,
        probe_args=("--help",),
        signature_pattern=_GEMINI_CLI_SIGNATURE,
        timeout_s=timeout,
    )
    if not verification.matched:
        return {
            "installed": False,
            "install_issue": verification.issue,
            "binary_path": binary_path,
            "probe_output": verification.probe_output,
            "probe_exit_code": verification.exit_code,
            "install_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
            "install_command": "npm install -g @google/gemini-cli",
        }

    # Signature matched; capture the bare version separately. Best-effort;
    # on failure we still report the CLI as installed with unknown version.
    version = "unknown"
    try:
        version_result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if version_result.returncode == 0:
            version = version_result.stdout.strip() or "unknown"
    except (subprocess.TimeoutExpired, OSError):
        pass

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def check_google_auth() -> dict[str, Any]:
    """Check whether Gemini CLI is authenticated with Google.

    Function named ``check_google_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``google``.

    Uses ``gemini --list-sessions`` (not ``gemini auth status`` which does
    not exist — the CLI would interpret it as a chat prompt). The check is
    intentionally token-blind: Obra does not read or decode
    ``~/.gemini/oauth_creds.json`` and lets the provider CLI own its
    credential state.

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "--list-sessions"],
            capture_output=True,
            text=True,
            timeout=timeout,
            env=build_subprocess_env("oauth", provider="google"),
        )
    except subprocess.TimeoutExpired:
        return {
            "authenticated": False,
            "auth_issue": "connection_failed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"timed out after {timeout}s",
        }
    except OSError as err:
        return {
            "authenticated": False,
            "auth_issue": "not_installed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"{type(err).__name__}: {err}",
        }

    combined_lower = result.stdout.lower() + result.stderr.lower()
    if result.returncode == 0 and "expired" not in combined_lower:
        return {"authenticated": True, "auth_issue": None}

    auth_issue = "expired" if "expired" in combined_lower else "not_authenticated"
    return {
        "authenticated": False,
        "auth_issue": auth_issue,
        "binary_path": binary_path,
        "check_exit_code": result.returncode,
        "check_stderr_excerpt": excerpt_diagnostic_text(result.stderr or result.stdout),
    }


def authenticate_gemini_cli() -> dict[str, Any]:
    """Trigger Gemini CLI authentication via a terminal handoff.

    Gemini CLI has no dedicated ``auth login`` subcommand — the OAuth
    browser flow is triggered on first interactive use. We open an
    interactive ``gemini`` session in the user's terminal; the first
    prompt will trigger Google sign-in. If no terminal is available we
    fall back to manual instructions.
    """
    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"triggered": False, "error": "Gemini CLI is not installed"}

    handoff = open_command_in_terminal([binary_path])
    if handoff["launched"]:
        return {
            "triggered": True,
            "handoff": True,
            "terminal": handoff["terminal"],
            "method": handoff["method"],
        }
    return {
        "triggered": False,
        "manual_action_required": True,
        "handoff_error": handoff.get("error"),
        "instructions": (
            "Run `gemini` in a terminal to authenticate with Google. A browser "
            "window opens on first use. We'll pick up the change automatically."
        ),
    }
