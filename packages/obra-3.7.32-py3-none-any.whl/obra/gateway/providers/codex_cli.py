"""OpenAI Codex CLI provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import contextlib
import re
import subprocess
import threading
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from obra.config.cli_resolution import (
    excerpt_diagnostic_text,
    resolve_cli_path,
    verify_provider_binary,
)
from obra.config.loaders import get_gateway_onboarding_config
from obra.execution.os_compat import build_popen_kwargs, is_interactive_context
from obra.gateway.providers._auth_process import (
    register_auth_process,
    terminate_auth_process,
    unregister_auth_process,
)
from obra.gateway.providers._terminal_handoff import open_command_in_terminal

# Module-level state for the background auth subprocess.
_auth_process: subprocess.Popen | None = None
_auth_lock = threading.Lock()


def _clear_completed_auth_process() -> None:
    global _auth_process
    if _auth_process is not None and _auth_process.poll() is not None:
        unregister_auth_process(_auth_process)
        _auth_process = None


# OpenAI Codex CLI reports itself via ``codex-cli <version>``. Other binaries
# named ``codex`` (historical research tools) exist; this signature keeps us
# honest. The Ollama provider also resolves the same binary but doesn't need
# verification — the Ollama path checks endpoint reachability separately.
CODEX_CLI_SIGNATURE = re.compile(r"codex-cli", re.IGNORECASE)


@contextlib.contextmanager
def _codex_refresh_lock() -> Iterator[None]:
    """Hold the openai codex refresh-boundary lock around a gateway codex call.

    Both ``codex login status`` (read; may trigger an internal refresh when
    near expiry) and ``codex --login`` (rewrites ``~/.codex/auth.json``) can
    race with concurrent codex inference calls served by
    ``obra.llm.execution.codex._run_codex_command``. Sharing the same lock
    keeps the gateway-initiated flows in the same serialization domain.

    The lock is a no-op outside the refresh window (see
    ``obra.llm.execution.codex_refresh_lock.near_refresh_boundary``).
    """
    from obra.config.loaders import get_governor_config
    from obra.llm.execution.codex_refresh_lock import codex_refresh_lock

    lock_cfg = get_governor_config().providers["openai"].codex_refresh_lock
    if lock_cfg is None:
        raise RuntimeError("Missing openai codex_refresh_lock governor config")
    with codex_refresh_lock(
        Path.home() / ".codex" / "auth.json",
        lock_window_s=lock_cfg.lock_window_s,
        assumed_validity_s=lock_cfg.assumed_validity_s,
        max_call_duration_s=lock_cfg.max_call_duration_s,
        safety_margin_s=lock_cfg.safety_margin_s,
        enabled=lock_cfg.enabled,
    ):
        yield


def detect_codex_cli() -> dict[str, Any]:
    """Detect whether the Codex CLI binary is installed.

    Returns a dict with ``installed`` and either ``path``/``version`` on
    success, or ``install_issue`` + diagnostic fields on a binary-name
    collision or execution failure. See :func:`claude_code.detect_claude_code`
    for the full payload shape contract.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("codex")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://openai.com/codex/",
            "install_command": "npm install -g @openai/codex",
        }

    verification = verify_provider_binary(
        binary_path,
        probe_args=("--version",),
        signature_pattern=CODEX_CLI_SIGNATURE,
        timeout_s=timeout,
    )
    if not verification.matched:
        return {
            "installed": False,
            "install_issue": verification.issue,
            "binary_path": binary_path,
            "probe_output": verification.probe_output,
            "probe_exit_code": verification.exit_code,
            "install_url": "https://openai.com/codex/",
            "install_command": "npm install -g @openai/codex",
        }

    return {
        "installed": True,
        "path": binary_path,
        "version": verification.probe_output,
    }


def check_openai_auth() -> dict[str, Any]:
    """Check whether Codex CLI is authenticated with OpenAI.

    Function named ``check_openai_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``openai``. Uses ``codex login status`` (``codex auth status``
    does not exist in the Codex CLI).

    On failure, includes diagnostic fields (``binary_path``,
    ``check_exit_code``, ``check_stderr_excerpt``) so the UI and support
    can triage from the status payload alone.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    _clear_completed_auth_process()
    binary_path = resolve_cli_path("codex")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        with _codex_refresh_lock():
            result = subprocess.run(
                [binary_path, "login", "status"],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
    except subprocess.TimeoutExpired:
        return {
            "authenticated": False,
            "auth_issue": "connection_failed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"timed out after {timeout}s",
        }
    except OSError as err:
        return {
            "authenticated": False,
            "auth_issue": "not_installed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"{type(err).__name__}: {err}",
        }

    combined_lower = result.stdout.lower() + result.stderr.lower()
    if result.returncode == 0 and "expired" not in combined_lower:
        return {"authenticated": True, "auth_issue": None}

    auth_issue = "expired" if "expired" in combined_lower else "not_authenticated"
    return {
        "authenticated": False,
        "auth_issue": auth_issue,
        "binary_path": binary_path,
        "check_exit_code": result.returncode,
        "check_stderr_excerpt": excerpt_diagnostic_text(result.stderr or result.stdout),
    }


def authenticate_codex_cli() -> dict[str, Any]:
    """Trigger Codex CLI OAuth login flow.

    See :func:`claude_code.authenticate_claude_code` for the contract —
    interactive spawn when a TTY is present, terminal handoff otherwise.
    """
    global _auth_process

    config = get_gateway_onboarding_config()
    auth_timeout = config["auth_timeout_s"]

    binary_path = resolve_cli_path("codex")
    if not binary_path:
        return {"triggered": False, "error": "Codex CLI is not installed"}

    if not is_interactive_context():
        handoff = open_command_in_terminal([binary_path, "--login"])
        if handoff["launched"]:
            return {
                "triggered": True,
                "handoff": True,
                "terminal": handoff["terminal"],
                "method": handoff["method"],
            }
        return {
            "triggered": False,
            "needs_tty": True,
            "manual_action_required": True,
            "handoff_error": handoff.get("error"),
            "instructions": (
                "Run `codex --login` in a terminal to sign in. We'll pick up "
                "the change automatically once you're done."
            ),
        }

    with _auth_lock:
        _clear_completed_auth_process()
        if _auth_process is not None:
            terminate_auth_process(_auth_process)
            _auth_process = None

        try:
            with _codex_refresh_lock():
                _auth_process = subprocess.Popen(
                    [binary_path, "--login"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    **build_popen_kwargs(),
                )
            register_auth_process(_auth_process, "codex-login")
        except OSError as e:
            return {"triggered": False, "error": str(e)}

    def _timeout_killer():
        global _auth_process
        with _auth_lock:
            if _auth_process is not None:
                terminate_auth_process(_auth_process)
                _auth_process = None

    timer = threading.Timer(auth_timeout, _timeout_killer)
    timer.daemon = True
    timer.start()

    return {"triggered": True}
