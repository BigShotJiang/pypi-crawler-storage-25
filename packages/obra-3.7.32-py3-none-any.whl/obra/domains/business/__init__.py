"""Business workflow domain module.

This domain provides specialized configuration for business process
automation workflows including document processing, approval workflows,
and compliance reviews.

Usage:
    >>> from obra.domains.business import BusinessDomain
    >>> domain = BusinessDomain()
    >>> print(domain.name)
    business
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    5

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
import json
import os
from collections.abc import Callable
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

from obra.domains.capabilities import Capability, DomainCapabilities
from obra.domains.constraints import DomainPlanningConstraints
from obra.domains.interface import FileFilterConfig, QualityDimension
from obra.domains.lifecycle import (
    ACTIVE_STATE,
    DERIVE_CAPABILITY,
    EXECUTE_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    SKIPPED_STATE,
    STORY0_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
    DomainLifecyclePolicy,
)
from obra.domains.vocabulary import (
    DomainHelpCopy,
    DomainVocabulary,
    VocabularyLane,
    VocabularyPipelineStage,
)
from obra.workflow.quality_loop import collect_stage_quality_loop_issues
from obra.workflow.stage_contract import collect_stage_contract_issues

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)

INTERFACE_VERSION = "v3"

# Local prompt-file mapping for runtime quality keys expected by active review agents.
_QUALITY_PROMPT_FILES: dict[str, str] = {
    "code_quality": "document_quality",
    "docs_analysis": "docs_analysis",
    "testing_coverage": "data_consistency",
    "security_sweep": "process_compliance",
    "security_deep": "security_deep",
}

_BUSINESS_STAGE_TIMEOUT_S = 600
_BUSINESS_STAGE_COMMAND_RUNNER_ID = "business.stage.command"
_BUSINESS_STAGE_WORKFLOW_RUNNER_ID = "business.stage.workflow"
_BUSINESS_STAGE_LLM_INVOKE_RUNNER_ID = "business.stage.llm_invoke"
_STAGE_OUTPUT_TEXT_DIR = ".obra-biz/stage-outputs"
_STAGE_OUTPUT_TEXT_EXCERPT_CHARS = 4000
_PRIOR_OUTPUT_EXCERPT_DEFAULT_CHARS = 8000
_PRIOR_OUTPUT_TOTAL_DEFAULT_CHARS = 48000
_PRIOR_OUTPUT_FULL_RECENT_DEFAULT_COUNT = 1

_WORKFLOW_PLAN_FILENAME = "WORKFLOW_PLAN.json"
_COMPILED_WORKFLOWS_SUBDIR = Path(".obra-biz") / "workflows"
_DEFAULT_INPUT_TEMPLATE = "input_template.md"


class _PipelineStageInputError(ValueError):
    """Raised when the pipeline-stage context lacks the inputs required to delegate."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "PIPELINE_STAGE_CONTEXT_INVALID",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.metadata = dict(metadata or {})


class _ResolvedPipelineStageInputs:
    """Container for canonical-executor inputs resolved from a stage request."""

    __slots__ = ("input_path", "plan_path", "workflow_dir", "workflow_id")

    def __init__(
        self,
        *,
        workflow_id: str,
        workflow_dir: Path,
        plan_path: Path | None,
        input_path: Path,
    ) -> None:
        self.workflow_id = workflow_id
        self.workflow_dir = workflow_dir
        self.plan_path = plan_path
        self.input_path = input_path


def _declared_runner_specs(request: Any) -> list[dict[str, Any]]:
    """Return the declared runner specs from the stage request context."""
    runner_specs = getattr(request.context, "runner_specs", None)
    if not isinstance(runner_specs, list):
        return []
    return [dict(spec) for spec in runner_specs if isinstance(spec, dict)]


def _resolve_session_plan_only(request: Any) -> bool:
    """Return whether the originating session was started with --plan-only."""
    runtime_metadata = getattr(request.context, "runtime_metadata", None)
    if not isinstance(runtime_metadata, dict):
        return False
    return bool(runtime_metadata.get("session_plan_only", False))


def _select_workflow_baseline_ref(request: Any) -> Any | None:
    """Return the workflow_baseline ref from ``workflow_artifact_refs``.

    The server ships a mixed list: a session-derived ``mission:<session_id>``
    summary ref alongside the client-sent ``workflow_baseline`` ref that
    carries the compiled workflow's identity and plan_source_path. The
    business runtime only cares about the workflow_baseline entry, so we
    filter explicitly instead of trusting list order.
    """
    refs = getattr(request.context, "workflow_artifact_refs", None) or []
    for ref in refs:
        artifact_type = str(getattr(ref, "target_artifact_type", "") or "").strip()
        if artifact_type == "workflow_baseline":
            return ref
    for ref in refs:
        metadata = getattr(ref, "metadata", None)
        if isinstance(metadata, dict) and metadata.get("source") == "imported_plan":
            return ref
    return None


def _workflow_baseline_ref_metadata(request: Any) -> dict[str, Any]:
    """Return the metadata of the workflow_baseline ref, or an empty dict."""
    ref = _select_workflow_baseline_ref(request)
    if ref is None:
        return {}
    metadata = getattr(ref, "metadata", None)
    return dict(metadata) if isinstance(metadata, dict) else {}


def _first_execution_input_ref_metadata(request: Any) -> dict[str, Any]:
    """Return the metadata of the first execution_input_artifact_ref, or an empty dict."""
    refs = getattr(request.context, "execution_input_artifact_refs", None) or []
    for ref in refs:
        metadata = getattr(ref, "metadata", None)
        if isinstance(metadata, dict):
            return metadata
    return {}


def _resolve_workflow_id(request: Any, workflow_ref_metadata: dict[str, Any]) -> str:
    """Resolve the workflow identifier from available sources in the request."""
    workflow_refs = getattr(request.context, "workflow_refs", None) or {}
    workflow_id = str(workflow_refs.get("workflow_id") or "").strip()
    if workflow_id:
        return workflow_id

    workflow_id = str(workflow_ref_metadata.get("workflow_id") or "").strip()
    if workflow_id:
        return workflow_id

    baseline_ref = _select_workflow_baseline_ref(request)
    if baseline_ref is not None:
        candidate = str(getattr(baseline_ref, "target_artifact_id", "") or "").strip()
        if candidate:
            return candidate

    msg = (
        "Pipeline stage request is missing a workflow_id. Populate "
        "project_context.workflow_artifact_refs or workflow_refs before "
        "dispatching the on_start stage."
    )
    raise _PipelineStageInputError(msg, code="MISSING_WORKFLOW_ID")


def _resolve_workflow_dir(
    *,
    working_directory: Path,
    workflow_id: str,
    workflow_ref_metadata: dict[str, Any],
) -> tuple[Path, Path | None]:
    """Resolve the workflow directory and (when known) the authoritative plan path."""
    raw_plan_source = str(workflow_ref_metadata.get("plan_source_path") or "").strip()
    if raw_plan_source:
        plan_source = Path(raw_plan_source).expanduser()
        if not plan_source.is_absolute():
            plan_source = (working_directory / plan_source).resolve()
        else:
            plan_source = plan_source.resolve()
        return plan_source.parent, plan_source

    fallback = (working_directory / _COMPILED_WORKFLOWS_SUBDIR / workflow_id).resolve()
    return fallback, None


def _resolve_input_path(
    *,
    working_directory: Path,
    workflow_dir: Path,
    execution_input_metadata: dict[str, Any],
) -> Path:
    """Resolve the input document path using ref metadata or convention fallback."""
    raw_path = str(execution_input_metadata.get("path") or "").strip()
    if raw_path:
        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = (working_directory / candidate).resolve()
        else:
            candidate = candidate.resolve()
        if candidate.is_file():
            return candidate

    fallback = workflow_dir / _DEFAULT_INPUT_TEMPLATE
    if fallback.is_file():
        return fallback

    msg = (
        f"No input document found for delegated execution. Expected "
        f"{fallback} or a readable path declared via "
        "execution_input_artifact_refs[].metadata.path."
    )
    raise _PipelineStageInputError(msg, code="INPUT_DOC_MISSING")


def _resolve_pipeline_stage_inputs(request: Any) -> _ResolvedPipelineStageInputs:
    """Resolve the canonical-executor inputs for a business pipeline stage."""
    working_directory_raw = str(
        getattr(request.context, "working_directory", "") or ""
    ).strip()
    if not working_directory_raw:
        msg = (
            "Pipeline stage request is missing a working_directory. The session "
            "must be started with project_context.working_directory set."
        )
        raise _PipelineStageInputError(msg, code="MISSING_WORKING_DIRECTORY")
    working_directory = Path(working_directory_raw).expanduser().resolve()

    workflow_ref_metadata = _workflow_baseline_ref_metadata(request)
    workflow_id = _resolve_workflow_id(request, workflow_ref_metadata)
    workflow_dir, plan_path = _resolve_workflow_dir(
        working_directory=working_directory,
        workflow_id=workflow_id,
        workflow_ref_metadata=workflow_ref_metadata,
    )
    if not workflow_dir.is_dir():
        msg = (
            f"Workflow directory not found: {workflow_dir}. Compile the "
            f"workflow or pass its WORKFLOW_PLAN.json explicitly."
        )
        raise _PipelineStageInputError(msg, code="WORKFLOW_DIR_NOT_FOUND")
    if plan_path is not None and not plan_path.is_file():
        msg = (
            f"Workflow plan not found: {plan_path}. Recompile the "
            f"workflow or pass a readable WORKFLOW_PLAN.json explicitly."
        )
        raise _PipelineStageInputError(msg, code="WORKFLOW_PLAN_MISSING")

    input_path = _resolve_input_path(
        working_directory=working_directory,
        workflow_dir=workflow_dir,
        execution_input_metadata=_first_execution_input_ref_metadata(request),
    )

    return _ResolvedPipelineStageInputs(
        workflow_id=workflow_id,
        workflow_dir=workflow_dir,
        plan_path=plan_path,
        input_path=input_path,
    )


def _context_mapping(value: Any) -> dict[str, Any]:
    """Return ``value`` as a plain mapping when possible."""
    if isinstance(value, dict):
        return value
    return {}


def _object_value(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def _coerce_mapping_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _artifact_target_id(value: Any) -> str:
    return str(
        _object_value(value, "target_artifact_id")
        or _object_value(value, "artifact_id")
        or ""
    ).strip()


def _artifact_metadata(value: Any) -> dict[str, Any]:
    metadata = _object_value(value, "metadata")
    return dict(metadata) if isinstance(metadata, dict) else {}


def _safe_stage_output_filename(stage_execution_id: str) -> str:
    safe = "".join(
        char if char.isalnum() or char in {"-", "_"} else "_"
        for char in str(stage_execution_id or "stage-output")
    ).strip("_")
    return f"{safe or 'stage-output'}.md"


def _write_stage_output_text(
    *,
    workflow_dir: Path,
    stage_execution_id: str,
    output_text: str,
) -> str:
    output_dir = workflow_dir / _STAGE_OUTPUT_TEXT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / _safe_stage_output_filename(stage_execution_id)
    output_path.write_text(output_text, encoding="utf-8")
    return output_path.relative_to(workflow_dir).as_posix()


def _read_stage_output_text_from_path(
    *,
    workflow_dir: Path,
    raw_path: str,
) -> str:
    if not raw_path.strip():
        return ""
    candidate = Path(raw_path).expanduser()
    if not candidate.is_absolute():
        candidate = workflow_dir / candidate
    candidate = candidate.resolve()
    workflow_root = workflow_dir.resolve()
    try:
        candidate.relative_to(workflow_root)
    except ValueError:
        return ""
    if not candidate.is_file():
        return ""
    return candidate.read_text(encoding="utf-8").strip()


def _artifact_output_text(request: Any, artifact: dict[str, Any]) -> str:
    metadata = _artifact_metadata(artifact)
    output_text = str(metadata.get("output_text") or "").strip()
    if output_text:
        return output_text

    raw_path = str(metadata.get("output_text_path") or artifact.get("path") or "").strip()
    excerpt = str(metadata.get("output_text_excerpt") or "").strip()
    if not raw_path:
        if excerpt:
            return excerpt
        artifact_id = _artifact_target_id(artifact)
        raise _PipelineStageInputError(
            f"Selected prior stage output artifact body is not locally materialized for artifact_id={artifact_id}",
            code="prior_stage_output_unavailable",
        )

    raw_workflow_dir = str(metadata.get("workflow_dir") or "").strip()
    if not raw_workflow_dir:
        raw_workflow_dir = str(
            getattr(getattr(request, "context", None), "working_directory", "") or ""
        ).strip()
    if not raw_workflow_dir:
        if excerpt:
            return excerpt
        artifact_id = _artifact_target_id(artifact)
        raise _PipelineStageInputError(
            f"Selected prior stage output artifact body is not locally materialized for artifact_id={artifact_id}",
            code="prior_stage_output_unavailable",
        )

    text = _read_stage_output_text_from_path(
        workflow_dir=Path(raw_workflow_dir).expanduser().resolve(),
        raw_path=raw_path,
    )
    if text:
        return text
    if excerpt:
        return excerpt
    artifact_id = _artifact_target_id(artifact)
    raise _PipelineStageInputError(
        f"Selected prior stage output artifact body is not locally materialized for artifact_id={artifact_id}",
        code="prior_stage_output_unavailable",
    )


def _collect_stage_output_artifacts(request: Any) -> dict[str, dict[str, Any]]:
    """Collect materialized stage-output artifacts available on the request."""
    context = getattr(request, "context", None)
    payload = _context_mapping(getattr(context, "payload", None))
    history = getattr(context, "history", None)
    sources: list[Any] = [
        getattr(context, "stage_output_artifacts", None),
        getattr(context, "candidate_stage_output_artifacts", None),
        payload.get("stage_output_artifacts"),
        payload.get("candidate_stage_output_artifacts"),
        getattr(request, "stage_output_artifacts", None),
        getattr(request, "candidate_stage_output_artifacts", None),
    ]
    if isinstance(history, list):
        for entry in history:
            if not isinstance(entry, dict):
                continue
            last_result = entry.get("last_result")
            if isinstance(last_result, dict):
                sources.extend(
                    [
                        last_result.get("stage_output_artifacts"),
                        last_result.get("candidate_stage_output_artifacts"),
                    ]
                )

    artifacts: dict[str, dict[str, Any]] = {}
    for source in sources:
        for artifact in _coerce_mapping_list(source):
            artifact_id = _artifact_target_id(artifact)
            if artifact_id and artifact_id not in artifacts:
                artifacts[artifact_id] = artifact
    return artifacts


def _clip_prior_output_text(text: str, max_chars: int) -> tuple[str, bool]:
    """Return text clipped to ``max_chars`` and whether clipping occurred."""
    if max_chars <= 0:
        return "", bool(text)
    if len(text) <= max_chars:
        return text, False
    omitted = len(text) - max_chars
    suffix = f"\n\n[truncated: {omitted} characters omitted from prior stage output]"
    if len(suffix) >= max_chars:
        return text[:max_chars], True
    return text[: max_chars - len(suffix)].rstrip() + suffix, True


def _context_policy_dict(context_policy: Any) -> dict[str, Any]:
    """Return the resolved context policy as a plain dict."""
    if hasattr(context_policy, "to_dict"):
        payload = context_policy.to_dict()
    elif isinstance(context_policy, dict):
        payload = dict(context_policy)
    else:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    include = payload.get("include", [])
    payload["include"] = [
        str(item).strip()
        for item in include
        if str(item).strip()
    ] if isinstance(include, list) else []
    payload["mode"] = str(payload.get("mode") or "selected_refs")
    payload["hydrate"] = str(payload.get("hydrate") or "full")
    return payload


def _positive_policy_int(policy: dict[str, Any], key: str, default: int) -> int:
    try:
        value = int(policy.get(key) or 0)
    except (TypeError, ValueError):
        value = 0
    return value if value > 0 else default


def _context_hydration_report(
    *,
    policy: dict[str, Any],
    selected_ref_count: int,
    hydrated_ref_count: int = 0,
    skipped_reasons: list[str] | None = None,
    context_budget_chars: int,
    context_used_chars: int = 0,
    clipped: bool = False,
) -> dict[str, Any]:
    reasons = list(dict.fromkeys(skipped_reasons or []))
    skipped_ref_count = max(selected_ref_count - hydrated_ref_count, 0)
    return {
        "policy_mode": str(policy.get("mode") or "selected_refs"),
        "hydrate": str(policy.get("hydrate") or "full"),
        "selected_ref_count": selected_ref_count,
        "hydrated_ref_count": hydrated_ref_count,
        "skipped_ref_count": skipped_ref_count,
        "skipped_reasons": reasons,
        "context_budget_chars": context_budget_chars,
        "context_used_chars": context_used_chars,
        "clipped": clipped,
    }


def _policy_selected_outputs_for_prompt(
    request: Any,
    *,
    excerpt_chars: int = _PRIOR_OUTPUT_EXCERPT_DEFAULT_CHARS,
    total_chars: int = _PRIOR_OUTPUT_TOTAL_DEFAULT_CHARS,
    full_recent_count: int = _PRIOR_OUTPUT_FULL_RECENT_DEFAULT_COUNT,
) -> tuple[list[tuple[str, str, str]], dict[str, Any]]:
    """Return bounded policy-selected outputs and hydration telemetry."""
    context = getattr(request, "context", None)
    policy = _context_policy_dict(getattr(context, "context_policy", None))
    resolved_excerpt_chars = _positive_policy_int(policy, "excerpt_chars", excerpt_chars)
    resolved_total_chars = _positive_policy_int(policy, "total_chars", total_chars)
    resolved_full_recent_count = _positive_policy_int(
        policy,
        "full_recent_count",
        full_recent_count,
    )
    refs = list(getattr(context, "policy_selected_stage_output_artifact_refs", None) or [])
    selected_ref_count = len(refs)
    if policy["mode"] in {"none", "blind_review"}:
        return [], _context_hydration_report(
            policy=policy,
            selected_ref_count=selected_ref_count,
            skipped_reasons=[f"policy_{policy['mode']}"],
            context_budget_chars=resolved_total_chars,
        )
    if policy["hydrate"] == "none":
        return [], _context_hydration_report(
            policy=policy,
            selected_ref_count=selected_ref_count,
            skipped_reasons=["hydrate_none"],
            context_budget_chars=resolved_total_chars,
        )

    artifacts_by_id = _collect_stage_output_artifacts(request)

    outputs: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    raw_outputs: list[tuple[str, str, str]] = []
    skipped_reasons: list[str] = []
    for ref in refs:
        artifact_id = _artifact_target_id(ref)
        if not artifact_id or artifact_id in seen:
            continue
        seen.add(artifact_id)
        artifact = artifacts_by_id.get(artifact_id)
        if artifact is None:
            report = _context_hydration_report(
                policy=policy,
                selected_ref_count=selected_ref_count,
                hydrated_ref_count=len(raw_outputs),
                skipped_reasons=["missing_artifact_body"],
                context_budget_chars=resolved_total_chars,
                context_used_chars=sum(len(item[2]) for item in raw_outputs),
            )
            raise _PipelineStageInputError(
                f"Selected prior stage output artifact body is not locally materialized for artifact_id={artifact_id}",
                code="prior_stage_output_unavailable",
                metadata={"context_hydration_report": report},
            )
        try:
            output_text = _artifact_output_text(request, artifact)
        except _PipelineStageInputError as exc:
            if "context_hydration_report" not in exc.metadata:
                report = _context_hydration_report(
                    policy=policy,
                    selected_ref_count=selected_ref_count,
                    hydrated_ref_count=len(raw_outputs),
                    skipped_reasons=["missing_artifact_body"],
                    context_budget_chars=resolved_total_chars,
                    context_used_chars=sum(len(item[2]) for item in raw_outputs),
                )
                exc.metadata["context_hydration_report"] = report
            raise
        stage_name = str(
            artifact.get("stage_name")
            or _artifact_metadata(ref).get("stage_name")
            or artifact_id
        ).strip()
        raw_outputs.append((stage_name, artifact_id, output_text))

    if not raw_outputs:
        return [], _context_hydration_report(
            policy=policy,
            selected_ref_count=selected_ref_count,
            skipped_reasons=skipped_reasons,
            context_budget_chars=resolved_total_chars,
        )

    recent_start = max(0, len(raw_outputs) - max(resolved_full_recent_count, 0))
    remaining = max(resolved_total_chars, 0)
    clipped = False
    used_chars = 0
    for index, (stage_name, artifact_id, output_text) in enumerate(raw_outputs):
        if remaining <= 0:
            skipped_reasons.append("budget_exhausted")
            continue
        stage_budget = (
            remaining if index >= recent_start else min(resolved_excerpt_chars, remaining)
        )
        clipped_text, was_clipped = _clip_prior_output_text(output_text, stage_budget)
        if was_clipped:
            clipped = True
        outputs.append((stage_name, artifact_id, clipped_text))
        used_chars += len(clipped_text)
        remaining -= len(clipped_text)
    return outputs, _context_hydration_report(
        policy=policy,
        selected_ref_count=selected_ref_count,
        hydrated_ref_count=len(outputs),
        skipped_reasons=skipped_reasons,
        context_budget_chars=resolved_total_chars,
        context_used_chars=used_chars,
        clipped=clipped,
    )


def _payload_text(request: Any, key: str) -> str:
    context = getattr(request, "context", None)
    payload = _context_mapping(getattr(context, "payload", None))
    return str(payload.get(key) or "").strip()


def _build_llm_invoke_prompt(
    *,
    template_content: str,
    request: Any,
    resolved: _ResolvedPipelineStageInputs,
    context_budget_excerpt_chars: int = _PRIOR_OUTPUT_EXCERPT_DEFAULT_CHARS,
    context_budget_total_chars: int = _PRIOR_OUTPUT_TOTAL_DEFAULT_CHARS,
    context_budget_full_recent_count: int = _PRIOR_OUTPUT_FULL_RECENT_DEFAULT_COUNT,
) -> tuple[str, dict[str, Any]]:
    """Build a self-contained prompt for a business llm_invoke stage."""
    sections = [template_content.rstrip()]

    sections.extend(
        [
            "",
            "## Runtime Execution Context",
            "",
            "Use this context as the authoritative runtime input for the stage. "
            "Do not rely on hidden files or unstated prior results.",
        ]
    )

    workflow_objective = _payload_text(request, "workflow_objective") or _payload_text(
        request, "objective"
    )
    if workflow_objective:
        sections.extend(["", "### Workflow Objective", "", workflow_objective])

    try:
        input_text = resolved.input_path.read_text(encoding="utf-8").strip()
    except OSError:
        input_text = ""
    sections.extend(
        [
            "",
            "### Execution Input",
            "",
            f"Path: {resolved.input_path}",
            "",
            "```text",
            input_text or "NOT PROVIDED BY RUNTIME INPUT",
            "```",
        ]
    )

    context_policy = _context_policy_dict(
        getattr(getattr(request, "context", None), "context_policy", None)
    )
    prior_outputs, hydration_report = _policy_selected_outputs_for_prompt(
        request,
        excerpt_chars=context_budget_excerpt_chars,
        total_chars=context_budget_total_chars,
        full_recent_count=context_budget_full_recent_count,
    )
    if context_policy["mode"] not in {"none", "blind_review"} and prior_outputs:
        sections.extend(["", "### Accepted Prior Stage Outputs"])
        sections.extend(
            [
                "",
                "The following prior outputs are bounded runtime context. "
                "If an entry says it was truncated, preserve the concrete "
                "details shown and avoid inventing missing specifics.",
            ]
        )
        for stage_name, artifact_id, output_text in prior_outputs:
            sections.extend(
                [
                    "",
                    f"#### {stage_name}",
                    "",
                    f"Artifact: {artifact_id}",
                    "",
                    "```text",
                    output_text,
                    "```",
                ]
            )

    return "\n".join(sections).strip() + "\n", hydration_report


def _build_stage_failure_result(
    *,
    request: Any,
    title: str,
    description: str,
    code: str,
    priority: str = "P1",
    metadata: dict[str, Any] | None = None,
) -> Any:
    """Build a PipelineStageResult that blocks the session with a diagnostic finding.

    ``loop_verdict`` is set to the canonical ``block`` value so the server's
    quality-loop evaluator (`stage_quality_loop._resolve_canonical_verdict`)
    routes via ``on_block`` → ``block_stage`` instead of falling into the
    has_findings heuristic that classifies the result as ``revise_required``.
    Without the explicit verdict the router would re-dispatch the stage on
    every reported finding, producing an infinite redispatch loop until the
    client hits MAX_ITERATIONS.
    """
    from obra.api.protocol import PipelineStageResult

    runner_id = request.runner_id or _BUSINESS_STAGE_COMMAND_RUNNER_ID
    result_metadata: dict[str, Any] = {
        "error_code": code,
        "declared_runner_specs": _declared_runner_specs(request),
    }
    if metadata:
        result_metadata.update(metadata)

    return PipelineStageResult(
        stage_name=request.stage_name,
        stage_execution_id=request.stage_execution_id,
        execution_status="failed",
        outcome="error",
        findings=[
            {
                "id": code,
                "code": code,
                "title": title,
                "description": description,
                "priority": priority,
            }
        ],
        routing_signal={"recommended_action": "block", "reason": title},
        loop_signal={
            "recommended_action": "block",
            "current_iteration": request.iteration,
            "max_iterations": request.max_iterations,
        },
        runner_id=runner_id,
        runner_version=request.runner_version,
        runner_selector=request.runner_selector,
        verdict="issues",
        loop_verdict="block",
        iteration=request.iteration,
        metadata=result_metadata,
    )


def _business_runner_catalog_entries(*, source_type: str, package: str) -> list[dict[str, Any]]:
    base = {
        "version": "1.0.0",
        "scope": "domain",
        "domain_ids": ["business"],
        "portability": "portable",
        "source": {"source_type": source_type, "package": package},
    }
    return [
        {
            **base,
            "id": _BUSINESS_STAGE_COMMAND_RUNNER_ID,
            "display_name": "Business Stage Command Runner",
            "kind": "command_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                "stage_archetypes": ["delegate", "workflow_runtime"],
                "platforms": ["linux", "darwin", "win32"],
                "required_executables": ["obra"],
            },
            "activation": {
                "command": ["obra", "stage", "execute"],
                # Slim env_contract: OBRA_* keys propagate via pattern in
                # _build_restricted_env (ADR-101), and
                # OBRA_STAGE_CONTEXT_PATH is injected unconditionally
                # from the stage_context_path param. This list only
                # declares non-OBRA_* cross-cutting standards the
                # nested obra run needs.
                "env_contract": [
                    "ANTHROPIC_API_KEY",
                    "OPENAI_API_KEY",
                    "GEMINI_API_KEY",
                    "GOOGLE_APPLICATION_CREDENTIALS",
                    "FIRESTORE_EMULATOR_HOST",
                    "GOOGLE_CLOUD_PROJECT",
                    "GCLOUD_PROJECT",
                ],
            },
            "description": "Dispatch a business pipeline stage through the Obra runtime.",
            "tags": ["business", "pipeline", "command"],
            # Successful dispatch of the on_start delegation wrapper counts
            # as one completed work unit (the business workflow invocation).
            # See ADR-101.
            "work_bearing": True,
            # ``obra stage execute`` writes an authoritative
            # PipelineStageResult as a trailing JSON line on stdout.
            "emits_structured_result": True,
        },
        {
            **base,
            "id": _BUSINESS_STAGE_WORKFLOW_RUNNER_ID,
            "display_name": "Business Stage Workflow Runner",
            "kind": "workflow_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                "stage_archetypes": ["workflow_runtime"],
            },
            "activation": {
                "workflow_id": "business.workflow.stage",
                "revision_id": "current",
            },
            "description": "Launch a nested business workflow from a pipeline stage.",
            "tags": ["business", "pipeline", "workflow"],
            # A nested-workflow invocation is a user-visible work unit.
            "work_bearing": True,
            # workflow_runner kinds dispatch through the nested-workflow
            # protocol, not ``obra stage execute``; no trailing-JSON contract.
            "emits_structured_result": False,
        },
        {
            **base,
            "id": _BUSINESS_STAGE_LLM_INVOKE_RUNNER_ID,
            "display_name": "Business Stage LLM Invoke Runner",
            "kind": "command_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                # ADR-101 Invariant 1 makes this runner the per-story
                # default for *any* compiled business story: one authored
                # template → one LLM invocation, regardless of the story's
                # canonical stage archetype (generate / output / classify /
                # transform / etc.). The runner is type-erasing across
                # archetypes, so it declares no ``stage_archetypes`` filter
                # — gating on archetype here would block legitimate
                # per-story dispatches whose stage_type normalizes to
                # ``GENERATE``, ``OUTPUT``, etc. Selection is by explicit
                # ``runner_id`` per ADR-101, not by archetype lookup.
                "platforms": ["linux", "darwin", "win32"],
                "required_executables": ["obra"],
            },
            "activation": {
                "command": ["obra", "stage", "execute"],
                # Slim env_contract: OBRA_* keys propagate via pattern in
                # _build_restricted_env (ADR-101), and
                # OBRA_STAGE_CONTEXT_PATH is injected unconditionally
                # from the stage_context_path param. Non-OBRA_*
                # cross-cutting standards only.
                "env_contract": [
                    "ANTHROPIC_API_KEY",
                    "OPENAI_API_KEY",
                    "GEMINI_API_KEY",
                    "GOOGLE_APPLICATION_CREDENTIALS",
                    "FIRESTORE_EMULATOR_HOST",
                    "GOOGLE_CLOUD_PROJECT",
                    "GCLOUD_PROJECT",
                ],
            },
            "description": (
                "Execute a business pipeline stage as a single LLM call "
                "against the authored instruction template, using the "
                "per-stage binding from OBRA_STAGE_MODEL_BINDINGS_PATH. "
                "See ADR-100 (inline-execution model) and ADR-101 "
                "(business-domain execute path) for the contract."
            ),
            "tags": ["business", "pipeline", "llm_invoke"],
            # Each successful llm_invoke dispatch is one completed story.
            "work_bearing": True,
            # Activation is ``obra stage execute`` — trailing-JSON contract.
            "emits_structured_result": True,
        },
        {
            **base,
            "id": "business.workflow.delegate",
            "display_name": "Business Workflow Delegate Runner",
            "kind": "command_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                "stage_archetypes": ["delegate"],
                "platforms": ["linux", "darwin", "win32"],
                "required_executables": ["obra"],
            },
            "activation": {
                "command": ["obra", "run", "--domain", "business"],
                "env_contract": [
                    "ANTHROPIC_API_KEY",
                    "OPENAI_API_KEY",
                    "GEMINI_API_KEY",
                    "GOOGLE_APPLICATION_CREDENTIALS",
                    "FIRESTORE_EMULATOR_HOST",
                    "GOOGLE_CLOUD_PROJECT",
                    "GCLOUD_PROJECT",
                ],
            },
            "description": (
                "Delegate a business workflow invocation to the Obra runtime. "
                "Canonical business domain command_runner preset (ADR-088)."
            ),
            "tags": ["business", "workflow", "delegate"],
            "work_bearing": True,
            "emits_structured_result": True,
        },
        {
            **base,
            "id": "business.http.webhook",
            "display_name": "Business HTTP Webhook Runner",
            "kind": "http_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result"],
                "stage_archetypes": ["webhook"],
            },
            "activation": {},
            "description": (
                "Invoke a business-system HTTP webhook from a pipeline "
                "stage. Canonical business domain http_runner preset."
            ),
            "tags": ["business", "http", "webhook"],
        },
    ]


_STAGE_MODEL_BINDINGS_PATH_ENV = "OBRA_STAGE_MODEL_BINDINGS_PATH"
_DELEGATION_DEPTH_SIGNAL_ENV = "OBRA_DELEGATION_DEPTH"


def _resolve_llm_invoke_story(
    *,
    plan_path: Path | None,
    workflow_dir: Path,
    stage_id: str,
) -> dict[str, Any]:
    """Return the compiled-plan story whose canonical stage_id matches.

    The compiler emits both ``story.id`` (the 1-indexed plan-story
    identifier, e.g. ``S1``) and ``story.stage_id`` (the 0-indexed
    canonical identifier from the workflow source, e.g. ``S0``). The
    per-story dispatch threads the canonical stage_id through
    ``runtime_metadata['stage_id']`` and ``stage_model_bindings.json``
    is also keyed by it, so matching prefers ``story.stage_id`` and only
    falls back to ``story.id`` for hand-authored plans that omit the
    canonical field.
    """
    from obra_business.runtime.canonical_executor import RuntimeDelegationError

    resolved_plan_path = plan_path
    if resolved_plan_path is None:
        resolved_plan_path = (workflow_dir / _WORKFLOW_PLAN_FILENAME).resolve()
    if not resolved_plan_path.is_file():
        raise RuntimeDelegationError(
            f"Compiled workflow plan not found for llm_invoke stage: {resolved_plan_path}"
        )

    try:
        payload = json.loads(resolved_plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeDelegationError(
            f"Compiled workflow plan is not readable: {resolved_plan_path}"
        ) from exc
    if not isinstance(payload, dict):
        raise RuntimeDelegationError(
            f"Compiled workflow plan must be a JSON object: {resolved_plan_path}"
        )

    epics = payload.get("epics")
    if not isinstance(epics, list):
        raise RuntimeDelegationError(
            f"Compiled workflow plan has no epics: {resolved_plan_path}"
        )
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories")
        if not isinstance(stories, list):
            continue
        for story in stories:
            if not isinstance(story, dict):
                continue
            candidate_id = str(story.get("stage_id") or story.get("id") or "").strip()
            if candidate_id == stage_id:
                return story
    raise RuntimeDelegationError(
        f"Stage {stage_id!r} not found in compiled plan {resolved_plan_path}"
    )


def _load_stage_model_binding(
    *,
    bindings_path: Path,
    stage_id: str,
) -> tuple[dict[str, Any], str]:
    """Return the per-stage binding dict and workflow_content_hash."""
    from obra_business.runtime.canonical_executor import RuntimeDelegationError

    try:
        payload = json.loads(bindings_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeDelegationError(
            f"Stage model bindings file is not readable: {bindings_path}"
        ) from exc
    if not isinstance(payload, dict):
        raise RuntimeDelegationError(
            f"Stage model bindings payload must be a JSON object: {bindings_path}"
        )
    workflow_content_hash = str(payload.get("workflow_content_hash") or "").strip()
    raw_bindings = payload.get("bindings")
    if not isinstance(raw_bindings, list):
        raise RuntimeDelegationError(
            f"Stage model bindings payload has no ``bindings`` list: {bindings_path}"
        )
    for entry in raw_bindings:
        if not isinstance(entry, dict):
            continue
        candidate_id = str(entry.get("stage_id") or "").strip()
        if candidate_id == stage_id:
            return entry, workflow_content_hash
    raise RuntimeDelegationError(
        f"No stage model binding for {stage_id!r} in {bindings_path}"
    )


def _stage_model_binding_from_story(story: dict[str, Any]) -> dict[str, Any]:
    """Build a stage override payload from imported-plan story metadata."""
    return {
        "provider": story.get("provider"),
        "model": story.get("model"),
        "model_tier": story.get("model_tier"),
        "reasoning_level": story.get("reasoning_level"),
        "auth_method": story.get("auth_method"),
        "source": "imported_plan",
    }


def _workflow_content_hash_from_plan(plan_path: Path | None) -> str:
    """Return the compiled workflow content hash when available."""
    if plan_path is None:
        return ""
    try:
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("workflow_content_hash") or "").strip()


def _execute_llm_invoke_stage(
    request: Any,
    *,
    log_event: Callable[..., None] | None = None,
) -> Any:
    """Execute a business pipeline stage as a single LLM call.

    Canonical contract (ADR-101): one LLM invocation against the authored
    instruction template identified by the compiled story's
    ``instruction_file``, using the per-stage binding resolved by the
    canonical executor and persisted at
    ``OBRA_STAGE_MODEL_BINDINGS_PATH``. No spike/execute/review cycle.
    """
    from obra_business.config.loader import get_config_value, load_config
    from obra_business.runtime.canonical_executor import (
        RuntimeDelegationError,
        _coerce_model_tier,
    )

    from obra.api.protocol import (
        PipelineStageResult,
        ProducedArtifactPayload,
    )
    from obra.config.tier_resolution import resolve_stage_llm_config
    from obra.execution.errors import LLMInvocationTimeoutError
    from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
    from obra.schemas.stage_llm_override import StageLLMOverride

    try:
        resolved = _resolve_pipeline_stage_inputs(request)
    except _PipelineStageInputError as exc:
        return _build_stage_failure_result(
            request=request,
            title="Pipeline stage context missing required inputs",
            description=str(exc),
            code=exc.code,
        )

    # Per ADR-101 per-story dispatch: ``request.stage_name`` is the
    # synthesized ``story_NNN_<slug>`` execution identity that the
    # pipeline router matches against
    # ``workflow_derivation_state["active_story_stage_definition"].name``
    # when the runner reports back. The canonical stage_id (the one keyed
    # in ``stage_model_bindings.json`` and the compiled WORKFLOW_PLAN.json
    # story) is a different value (``S0`` / ``S1`` etc.) and lives on
    # ``request.context.runtime_metadata['stage_id']``. The server's
    # stage_request_builder populates that field for every dispatch.
    #
    # ``stage_id`` below is reserved for the canonical id (binding /
    # story / instruction-file lookups, observability events, metadata
    # provenance). The result's ``stage_name`` and ``ProducedArtifactPayload.stage_name``
    # must keep using ``request.stage_name`` so the router can route the
    # result back to the dispatched stage. Native (non-synthesized) stages
    # keep working because their stage_name already equals their canonical
    # stage_id.
    runtime_metadata = getattr(request.context, "runtime_metadata", {}) or {}
    canonical_stage_id = str(runtime_metadata.get("stage_id") or "").strip()
    stage_id = canonical_stage_id or request.stage_name
    result_stage_name = request.stage_name or stage_id
    try:
        story = _resolve_llm_invoke_story(
            plan_path=resolved.plan_path,
            workflow_dir=resolved.workflow_dir,
            stage_id=stage_id,
        )
        bindings_raw = os.environ.get(_STAGE_MODEL_BINDINGS_PATH_ENV, "").strip()
        if bindings_raw:
            bindings_path = Path(bindings_raw).expanduser().resolve()
            if not bindings_path.is_file():
                return _build_stage_failure_result(
                    request=request,
                    title="Stage model bindings file missing",
                    description=(
                        f"{_STAGE_MODEL_BINDINGS_PATH_ENV}={bindings_path} does not "
                        "point to a readable file. The canonical executor writes "
                        "this file before dispatching the nested run."
                    ),
                    code="stage_model_bindings_path_missing",
                )
            binding_entry, workflow_content_hash = _load_stage_model_binding(
                bindings_path=bindings_path,
                stage_id=stage_id,
            )
        else:
            binding_entry = _stage_model_binding_from_story(story)
            workflow_content_hash = _workflow_content_hash_from_plan(
                resolved.plan_path or resolved.workflow_dir / _WORKFLOW_PLAN_FILENAME
            )
    except RuntimeDelegationError as exc:
        return _build_stage_failure_result(
            request=request,
            title="Stage resolution failed",
            description=str(exc),
            code="llm_invoke_stage_resolution_failed",
            metadata={"workflow_id": resolved.workflow_id, "stage_id": stage_id},
        )

    instruction_ref = str(story.get("instruction_file") or "").strip()
    if not instruction_ref:
        return _build_stage_failure_result(
            request=request,
            title="Stage missing instruction_file",
            description=(
                "The llm_invoke runner requires an authored instruction "
                f"template. Stage {stage_id!r} has no instruction_file."
            ),
            code="llm_invoke_missing_instruction_file",
            metadata={"workflow_id": resolved.workflow_id, "stage_id": stage_id},
        )
    instruction_path = Path(instruction_ref).expanduser()
    if not instruction_path.is_absolute():
        instruction_path = (resolved.workflow_dir / instruction_path).resolve()
    else:
        instruction_path = instruction_path.resolve()
    if not instruction_path.is_file():
        return _build_stage_failure_result(
            request=request,
            title="Instruction template not found",
            description=(
                f"Instruction template {instruction_path} declared by stage "
                f"{stage_id!r} is not readable."
            ),
            code="llm_invoke_instruction_missing",
            metadata={"workflow_id": resolved.workflow_id, "stage_id": stage_id},
        )
    override = StageLLMOverride(
        provider=_nonempty_str(binding_entry.get("provider")),
        model=_nonempty_str(binding_entry.get("model")),
        model_tier=_nonempty_str(binding_entry.get("model_tier")),
        reasoning_level=_nonempty_str(binding_entry.get("reasoning_level")),
        auth_method=_nonempty_str(binding_entry.get("auth_method")),
    )

    config = load_config()
    fallback_tier = _coerce_model_tier(get_config_value(config, "business.llm.execution_tier"))
    if fallback_tier is None:
        return _build_stage_failure_result(
            request=request,
            title="business.llm.execution_tier unresolved",
            description="Configuration must provide business.llm.execution_tier.",
            code="llm_invoke_execution_tier_unresolved",
        )
    llm_config = resolve_stage_llm_config(
        stage_override=override,
        fallback_tier=fallback_tier,
        role="implementation",
    )
    execution_timeout_raw = get_config_value(config, "business.llm.execution_timeout_s")
    try:
        execution_timeout_s = int(execution_timeout_raw)
    except (TypeError, ValueError):
        return _build_stage_failure_result(
            request=request,
            title="business.llm.execution_timeout_s invalid",
            description="Configuration must provide an integer business.llm.execution_timeout_s.",
            code="llm_invoke_execution_timeout_invalid",
            metadata={
                "workflow_id": resolved.workflow_id,
                "stage_id": stage_id,
                "configured_value": execution_timeout_raw,
            },
        )
    if execution_timeout_s < 600:
        return _build_stage_failure_result(
            request=request,
            title="business.llm.execution_timeout_s too low",
            description="business.llm.execution_timeout_s must be at least 600 seconds.",
            code="llm_invoke_execution_timeout_too_low",
            metadata={
                "workflow_id": resolved.workflow_id,
                "stage_id": stage_id,
                "configured_timeout_s": execution_timeout_s,
            },
        )

    def _read_positive_int_config(
        key: str,
        *,
        minimum: int,
        default: int,
    ) -> int:
        raw_value = get_config_value(config, key)
        try:
            value = int(raw_value)
        except (TypeError, ValueError):
            return default
        return value if value >= minimum else default

    context_budget_excerpt_chars = _read_positive_int_config(
        "business.llm.context_budget.excerpt_chars",
        minimum=1000,
        default=_PRIOR_OUTPUT_EXCERPT_DEFAULT_CHARS,
    )
    context_budget_total_chars = _read_positive_int_config(
        "business.llm.context_budget.total_chars",
        minimum=context_budget_excerpt_chars,
        default=max(_PRIOR_OUTPUT_TOTAL_DEFAULT_CHARS, context_budget_excerpt_chars),
    )
    context_budget_full_recent_count = _read_positive_int_config(
        "business.llm.context_budget.full_recent_count",
        minimum=0,
        default=_PRIOR_OUTPUT_FULL_RECENT_DEFAULT_COUNT,
    )

    template_content = instruction_path.read_text(encoding="utf-8")
    try:
        stage_prompt, hydration_report = _build_llm_invoke_prompt(
            template_content=template_content,
            request=request,
            resolved=resolved,
            context_budget_excerpt_chars=context_budget_excerpt_chars,
            context_budget_total_chars=context_budget_total_chars,
            context_budget_full_recent_count=context_budget_full_recent_count,
        )
    except _PipelineStageInputError as exc:
        metadata = {
            "workflow_id": resolved.workflow_id,
            "stage_id": stage_id,
            **exc.metadata,
        }
        if "context_hydration_report" not in metadata:
            metadata["context_hydration_report"] = _context_hydration_report(
                policy=_context_policy_dict(
                    getattr(getattr(request, "context", None), "context_policy", None)
                ),
                selected_ref_count=len(
                    getattr(
                        getattr(request, "context", None),
                        "policy_selected_stage_output_artifact_refs",
                        [],
                    )
                    or []
                ),
                skipped_reasons=["missing_artifact_body"],
                context_budget_chars=context_budget_total_chars,
            )
        return _build_stage_failure_result(
            request=request,
            title="Prior stage output unavailable",
            description=str(exc),
            code=exc.code,
            priority="P1",
            metadata=metadata,
        )

    # TemplateEditPipeline(output_format="text", write_scope="safe_output_only")
    # matches the authored-template contract for business stages: a prose
    # instruction document rendered as the base prompt, the LLM's freeform
    # response captured via stdout, no on-disk template editing. The
    # ``build_preexecution_pipeline`` factory forces JSON output via
    # ``output_format="json"`` which doesn't fit authored stage templates,
    # so we construct TemplateEditPipeline directly here.
    max_retries_raw = get_config_value(config, "business.complexity.estimator.max_retries")
    try:
        max_retries = int(max_retries_raw) if max_retries_raw is not None else 1
    except (TypeError, ValueError):
        max_retries = 1

    pipeline = TemplateEditPipeline(
        working_dir=resolved.workflow_dir,
        action_name="business_stage_llm_invoke",
        output_format="text",
        write_scope="safe_output_only",
        log_event=log_event,
        max_retries=max_retries,
    )

    def _validator(data: Any) -> tuple[bool, str | None]:
        # Business stage output is the authored LLM response; accept any
        # non-empty string. Authored templates that require stricter
        # validation can emit validator-compatible structure; when that
        # lands the contract becomes per-stage opt-in.
        if isinstance(data, str) and data.strip():
            return (True, None)
        return (False, "LLM response was empty")

    def _fallback() -> str:
        return ""

    try:
        result_data, _metadata = pipeline.execute(
            base_prompt=stage_prompt,
            template_content=template_content,
            validator=_validator,
            fallback_fn=_fallback,
            llm_config=llm_config,
            timeout_s=execution_timeout_s,
            allow_unchanged=True,
        )
    except LLMInvocationTimeoutError as exc:
        return _build_stage_failure_result(
            request=request,
            title="LLM invocation timed out",
            description=str(exc),
            code="llm_invoke_pipeline_timeout",
            metadata={
                "workflow_id": resolved.workflow_id,
                "stage_id": stage_id,
                "configured_timeout_s": execution_timeout_s,
                "provider": llm_config.get("provider"),
                "model": llm_config.get("model"),
            },
        )
    except Exception as exc:
        return _build_stage_failure_result(
            request=request,
            title="LLM invocation failed",
            description=str(exc),
            code="llm_invoke_pipeline_failed",
            metadata={"workflow_id": resolved.workflow_id, "stage_id": stage_id},
        )

    output_text = result_data if isinstance(result_data, str) else str(result_data or "")

    if log_event is not None:
        log_event(
            "stage_model_binding_resolved",
            stage_id=stage_id,
            provider=llm_config.get("provider"),
            model=llm_config.get("model"),
            reasoning_level=llm_config.get("reasoning_level"),
            source=_nonempty_str(binding_entry.get("source")),
            workflow_content_hash=workflow_content_hash,
        )

    output_text_path = _write_stage_output_text(
        workflow_dir=resolved.workflow_dir,
        stage_execution_id=request.stage_execution_id or result_stage_name,
        output_text=output_text,
    )
    runner_id = request.runner_id or _BUSINESS_STAGE_LLM_INVOKE_RUNNER_ID
    artifact = ProducedArtifactPayload(
        artifact_type="stage_output",
        artifact_id=f"llm_invoke:{request.stage_execution_id}",
        version="v1",
        producer_kind="runtime",
        producer_id=runner_id,
        stage_name=result_stage_name,
        path=output_text_path,
        operation_kind="executed",
        metadata={
            "runner_kind": "command_runner",
            "domain_id": "business",
            "workflow_id": resolved.workflow_id,
            "workflow_dir": str(resolved.workflow_dir),
            "instruction_file": str(instruction_path),
            "provider": llm_config.get("provider"),
            "model": llm_config.get("model"),
            "reasoning_level": llm_config.get("reasoning_level"),
            "binding_source": _nonempty_str(binding_entry.get("source")),
            "workflow_content_hash": workflow_content_hash,
            "output_text_path": output_text_path,
            "output_text_excerpt": output_text[:_STAGE_OUTPUT_TEXT_EXCERPT_CHARS],
            "declared_runner_specs": _declared_runner_specs(request),
        },
    )

    return PipelineStageResult(
        stage_name=result_stage_name,
        stage_execution_id=request.stage_execution_id,
        execution_status="complete",
        outcome="passed",
        findings=[],
        stage_output_artifacts=[artifact],
        candidate_stage_output_artifacts=[artifact],
        routing_signal={"recommended_action": "continue"},
        loop_signal={
            "recommended_action": "continue",
            "current_iteration": request.iteration,
            "max_iterations": request.max_iterations,
        },
        runner_id=runner_id,
        runner_version=request.runner_version,
        runner_selector=request.runner_selector,
        verdict="sound",
        loop_verdict="pass",
        iteration=request.iteration,
        metadata={
            "workflow_id": resolved.workflow_id,
            "stage_id": stage_id,
            "provider": llm_config.get("provider"),
            "model": llm_config.get("model"),
            "reasoning_level": llm_config.get("reasoning_level"),
            "binding_source": _nonempty_str(binding_entry.get("source")),
            "workflow_content_hash": workflow_content_hash,
            "declared_runner_specs": _declared_runner_specs(request),
            "context_hydration_report": hydration_report,
        },
    )


def _nonempty_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _is_delegated_run_context() -> bool:
    """Return whether the current process is already inside a delegated business run.

    ``obra_business.runtime.canonical_executor.build_delegated_environment``
    seeds ``OBRA_DELEGATION_DEPTH`` in every nested ``obra run`` it
    spawns, incrementing it one layer at a time. Any value > 0 means
    the current process IS the delegation — the on_start shim would
    otherwise re-enter ``prepare_delegated_run`` and spawn another
    subprocess, producing an unbounded recursion of nested obra runs.
    Skipping the shim here lets the nested process execute the
    workflow plan's stories directly via the pipeline-stage path
    (ADR-101). ``OBRA_STAGE_MODEL_BINDINGS_PATH`` is no longer used
    as the delegation-context signal; it reverts to its single
    purpose of carrying the bindings file path.
    """
    raw = os.environ.get(_DELEGATION_DEPTH_SIGNAL_ENV, "0").strip() or "0"
    try:
        return int(raw) > 0
    except ValueError:
        return False


def _business_default_pipeline_config() -> dict[str, Any]:
    if _is_delegated_run_context():
        # Nested delegated runs skip the on_start shim — see
        # ``_is_delegated_run_context`` for the base-case rationale. No
        # custom stages means ``_resolve_pipeline_only`` returns False and
        # the nested run goes through the normal imported-plan item-execution
        # path rather than re-dispatching the delegation shim.
        return {"custom_stages": []}
    config = {
        "custom_stages": [
            {
                "name": "business_pipeline_execute",
                "trigger": "on_start",
                "input": "derived_plan",
                "timeout_s": _BUSINESS_STAGE_TIMEOUT_S,
                "runner": {"runner_id": _BUSINESS_STAGE_COMMAND_RUNNER_ID},
                "archetype": "workflow_runtime",
                "quality_loop": _default_stage_quality_loop(
                    checkpoint="business-pipeline-execute-loop",
                    max_total_findings=3,
                ),
            }
        ]
    }
    issues = [
        issue
        for stage in config["custom_stages"]
        for issue in collect_stage_contract_issues(stage)
    ]
    if issues:
        msg = f"business domain pipeline defaults are invalid: {issues[0]}"
        raise ValueError(msg)
    return config


def _default_stage_quality_loop(
    *,
    checkpoint: str,
    max_total_findings: int,
) -> dict[str, Any]:
    quality_loop = {
        "entry": {"when": "after_stage_runner"},
        "routing": {
            "on_pass": "continue",
            "on_advisory_pass": "continue_with_findings",
            "on_revise_required": "revise_same_stage",
            "on_block": "block_stage",
            "on_escalate": "escalate",
            "on_pending_manual": "wait_for_manual_action",
            "on_manual_resume": "resume_stage",
        },
        "evaluators": [
            {
                "runner": "quality.sense_check",
                "subject": "current_stage_output",
                "required": True,
            }
        ],
        "aggregation": {"strategy": "all_required_pass"},
        "thresholds": {"max_total_findings": max_total_findings},
        "pending_manual": {
            "required_action": "approve_revision",
            "resume": {"checkpoint": checkpoint, "strategy": "resume_stage"},
        },
    }
    issues = collect_stage_quality_loop_issues({"quality_loop": quality_loop})
    if issues:
        msg = f"business domain quality_loop default is invalid: {issues[0]['message']}"
        raise ValueError(msg)
    return quality_loop


class BusinessDomain:
    """Domain module for business workflow automation.

    Provides work types, quality prompts, and file filters optimized for
    business process automation tasks.
    """

    def __init__(
        self,
        *,
        log_event: Callable[..., None] | None = None,
    ) -> None:
        # Optional observability channel used by the ``llm_invoke`` branch
        # of ``execute_pipeline_stage`` to emit ``stage_model_binding_resolved``
        # events, mirroring the pattern at
        # ``obra/hybrid/handlers/execute/_handler.py`` where
        # ``self._log_event(...)`` is called for the same event. The domain
        # loader instantiates BusinessDomain() with no args, so ``set_log_event``
        # is the supported late-binding path for the stage worker to plumb a
        # HybridEventLogger-backed callable.
        self._log_event: Callable[..., None] | None = log_event

    def set_log_event(self, log_event: Callable[..., None] | None) -> None:
        """Install (or clear) the observability callback for stage events."""
        self._log_event = log_event

    @property
    def name(self) -> str:
        """Return domain name."""
        return "business"

    @property
    def display_name(self) -> str:
        """Return human-readable domain name."""
        return "Business Workflows"

    @property
    def description(self) -> str:
        """Return short description for this domain."""
        return "Orchestration for document processing and approval workflows"

    @property
    def example_objectives(self) -> list[str]:
        """Return representative objective examples."""
        return [
            "Process quarterly invoices",
            "Review compliance documents",
            "Generate financial report",
        ]

    @property
    def requires_git(self) -> bool:
        """Return whether this domain requires a git repository."""
        return False

    @property
    def default_sandbox_policy(self) -> str:
        """Return default sandbox policy for this domain."""
        return "WORKSPACE_WRITE"

    @property
    def closeout_key(self) -> str:
        """Return closeout template key for this domain."""
        return self.name

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.business")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for business workflows.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for business workflows.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality assessment dimensions for business workflows."""
        return [
            QualityDimension(
                id="code_quality",
                display_name="Document Quality",
                description="Review document completeness and execution readiness",
                default_enabled=True,
            ),
            QualityDimension(
                id="security_sweep",
                display_name="Process Compliance",
                description="Validate workflow compliance and policy adherence",
                default_enabled=True,
            ),
            QualityDimension(
                id="testing_coverage",
                display_name="Data Consistency",
                description="Detect conflicting values across business artifacts",
                default_enabled=False,
            ),
            QualityDimension(
                id="docs_analysis",
                display_name="Documentation",
                description="Review business-document clarity and delivery readiness",
                default_enabled=False,
            ),
        ]

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.business.prompts")
        prompts: dict[str, str] = {}

        for prompt_key, file_stem in _QUALITY_PROMPT_FILES.items():
            prompts[prompt_key] = (files / f"{file_stem}.txt").read_text()

        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for business projects.

        Returns:
            FileFilterConfig with business-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_stage_quality_loop_defaults(
        self,
        archetype: str | None = None,
    ) -> dict[str, Any] | None:
        """Return canonical quality-loop defaults for eligible stage archetypes."""
        normalized = str(archetype or "").strip().lower()
        if normalized == "decide":
            return _default_stage_quality_loop(
                checkpoint="business-decide-loop",
                max_total_findings=2,
            )
        if normalized == "generate":
            return _default_stage_quality_loop(
                checkpoint="business-generate-loop",
                max_total_findings=3,
            )
        return None

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for business workflows.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return workflow-lifecycle defaults for business workflows."""
        return DomainLifecyclePolicy(
            capability_states={
                DERIVE_CAPABILITY: ACTIVE_STATE,
                EXECUTE_CAPABILITY: ACTIVE_STATE,
                STORY0_CAPABILITY: SKIPPED_STATE,
                PREFLIGHT_CAPABILITY: SKIPPED_STATE,
                REVIEW_CAPABILITY: SKIPPED_STATE,
                WAIT_RESUME_CAPABILITY: ACTIVE_STATE,
                GIT_REQUIRED_CAPABILITY: SKIPPED_STATE,
                TOOLING_VERIFICATION_CAPABILITY: SKIPPED_STATE,
            }
        )

    def get_capabilities(self) -> DomainCapabilities:
        """Return stage-gating capabilities for business workflows."""
        return DomainCapabilities(
            spike_first_applicable=False,
            scaffolded_enrichment_applicable=False,
            intent_alignment_applicable=False,
            test_generation_supported=False,
            test_execution_supported=False,
            test_writer_supported=False,
            review_agents_supported=False,
            requires_git=False,
        )

    def supports(self, capability: Capability) -> bool:
        """Return whether business workflows support one capability."""
        return self.get_capabilities().supports(capability)

    def get_planning_constraints(self) -> DomainPlanningConstraints:
        """Return planning constraints for business workflows."""
        return DomainPlanningConstraints(default_work_type="general_business")

    def get_vocabulary(self) -> DomainVocabulary:
        """Return user-facing vocabulary labels for business workflows."""
        return DomainVocabulary(
            phase_labels={
                "intent": "Intent",
                "derive": "Workflow",
                "execute": "Execute",
                "review": "Review",
                "USERPLAN_GENERATION": "plan — defining the workflow",
                "SPIKE": "spike — validating workflow assumptions",
                "DERIVATION": "derive — detailing the workflow plan",
                "REFINEMENT": "revise — refining the workflow",
                "REVIEW": "review — preparing business review",
                "EXECUTION": "execute — running workflow stages",
            },
            work_type_labels={
                "workflow": "Workflow",
                "document": "Document",
                "approval": "Approval",
                "compliance": "Compliance",
                "audit_trail": "Audit Trail",
            },
            quality_dimension_labels={
                "code_quality": "Document Quality",
                "security_sweep": "Process Compliance",
                "testing_coverage": "Data Consistency",
                "docs_analysis": "Documentation",
                "security_deep": "Deep Compliance Review",
            },
            pipeline_stage_labels={
                "intent_generation": "intent_generation — capturing the business request",
                "assumptions": "assumptions — resolving workflow details",
                "analogues": "analogues — checking comparable processes",
                "brief": "brief — consolidating workflow intent",
                "derive": "derive — detailing the workflow",
                "revise": "revise — refining the workflow",
                "intent_alignment": "intent_alignment — checking workflow coverage",
                "review": "review — preparing business review",
                "execute": "execute — running workflow stages",
                "validator": "validator — validating workflow output",
            },
            pipeline_definition=[
                VocabularyPipelineStage("Define", ["assumptions", "analogues", "brief"]),
                VocabularyPipelineStage("Design", ["derive", "examine", "revise"]),
                VocabularyPipelineStage("Prepare", ["dependencies", "prerequisites"]),
                VocabularyPipelineStage("Run"),
                VocabularyPipelineStage("Review"),
                VocabularyPipelineStage("Fix"),
            ],
            stage_to_pipeline={
                "assumptions": "Define",
                "analogues": "Define",
                "brief": "Define",
                "derive": "Design",
                "examine": "Design",
                "revise": "Design",
                "dependencies": "Prepare",
                "prerequisites": "Prepare",
                "execute": "Run",
                "review": "Review",
                "fix": "Fix",
            },
            phase_to_pipeline={
                "USERPLAN_GENERATION": "Define",
                "REFINEMENT": "Design",
                "STORY0": "Prepare",
                "EXECUTION": "Run",
                "REVIEW": "Review",
            },
            lanes=[
                VocabularyLane("intake", "Intake and prep", ["intake"]),
                VocabularyLane("automation", "Automation", ["automation"]),
                VocabularyLane("review", "Review", ["review", "quality"]),
                VocabularyLane("approval", "Approval", ["approval"]),
                VocabularyLane("documents", "Documents", ["document"]),
                VocabularyLane("delivery", "Delivery", ["delivery"]),
            ],
            domain_help_copy=DomainHelpCopy(
                title="Business Workflows",
                description=self.description,
                lifecycle_heading="Business workflow lifecycle",
                lifecycle_steps=[
                    "Describe the business process and success criteria.",
                    "Derive workflow stages, dependencies, and review checkpoints.",
                    "Execute compiled workflow stages and capture the handoff summary.",
                ],
                example_invocations=[
                    f'obra run --domain business "{example}"'
                    for example in self.example_objectives[:3]
                ],
            ),
        )

    def get_stage_llm_tiering(self, plan_context: dict[str, Any]) -> dict[str, Any]:
        """Return business stage-type LLM tiering defaults."""
        try:
            from obra_business.config.loader import (
                get_config_value,
                load_config,
                normalize_stage_type_tiers,
            )

            config = load_config()
            return {
                "execution_tier": str(
                    get_config_value(config, "business.llm.execution_tier") or ""
                ).strip(),
                "stage_type_tiers": normalize_stage_type_tiers(
                    get_config_value(config, "business.llm.stage_type_tiers")
                ),
            }
        except Exception:
            return {}

    def get_plan_export_handler(self) -> Callable[..., None] | None:
        """Return the business workflow-plan export refresh handler."""
        from obra_business.compilation.runtime_plan_export import refresh_workflow_plan_export

        return refresh_workflow_plan_export

    def get_closeout_validator(self) -> None:
        """Return no domain-specific closeout validator yet."""
        return None

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Return catalog-backed runner declarations for the business domain."""
        return _business_runner_catalog_entries(source_type="obra_builtin", package="obra")

    def get_default_pipeline_config(self) -> dict[str, Any] | None:
        """Return direct-execution pipeline defaults for compiled business workflows."""
        return _business_default_pipeline_config()

    def get_default_runner_for_archetype(self, archetype: str) -> str | None:
        """Return the Studio-facing default runner for legacy business archetypes."""
        normalized = str(archetype or "").strip().lower()
        if normalized in {"delegate", "workflow_runtime"}:
            return _BUSINESS_STAGE_COMMAND_RUNNER_ID
        return None

    def execute_pipeline_stage(self, request: Any) -> Any:
        """Dispatch a compiled business workflow via the canonical runtime.

        Routing:

        * ``business.stage.llm_invoke`` (per-story) → single LLM call
          against the authored instruction template using the per-stage
          binding carried in ``OBRA_STAGE_MODEL_BINDINGS_PATH``. See
          ADR-101 for the execution invariant.
        * ``business.stage.command`` (on_start delegation wrapper) →
          resolves per-stage bindings, confirms the workflow crosswalk,
          and delegates execution to a nested ``obra run`` subprocess
          through :mod:`obra_business.runtime.canonical_executor`. The
          stage result mirrors the delegated exit code so the pipeline
          router can complete or fail the session accordingly.
        """
        if request.runner_id == _BUSINESS_STAGE_LLM_INVOKE_RUNNER_ID:
            return _execute_llm_invoke_stage(request, log_event=self._log_event)

        from obra.api.protocol import (
            PipelineStageResult,
            ProducedArtifactPayload,
        )

        try:
            from obra_business.crosswalk.model_crosswalk import (
                CrossWalkConfirmationRequired,
            )
            from obra_business.runtime.canonical_executor import (
                RuntimeDelegationError,
                execute_delegated_run,
                prepare_delegated_run,
            )
        except ImportError as exc:
            return _build_stage_failure_result(
                request=request,
                title="obra_business runtime not available",
                description=(
                    "Compiled business workflows require the obra-business package. "
                    f"Import failed: {exc}"
                ),
                code="obra_business_missing",
            )

        try:
            resolved = _resolve_pipeline_stage_inputs(request)
        except _PipelineStageInputError as exc:
            return _build_stage_failure_result(
                request=request,
                title="Pipeline stage context missing required inputs",
                description=str(exc),
                code=exc.code,
            )

        dry_run = _resolve_session_plan_only(request)
        try:
            prepared = prepare_delegated_run(
                workflow_dir=resolved.workflow_dir,
                workflow_id=resolved.workflow_id,
                input_path=resolved.input_path,
                dry_run=dry_run,
                raw_plan_path=resolved.plan_path,
            )
        except CrossWalkConfirmationRequired as exc:
            crosswalk_path = getattr(exc, "path", None)
            return _build_stage_failure_result(
                request=request,
                title="Crosswalk confirmation required",
                description=(
                    f"Workflow {resolved.workflow_id} cannot execute until the "
                    f"runtime crosswalk is confirmed. Review {crosswalk_path} and "
                    "rerun `obra business run`."
                ),
                code="crosswalk_confirmation_required",
                priority="P2",
                metadata={
                    "workflow_id": resolved.workflow_id,
                    "crosswalk_path": str(crosswalk_path) if crosswalk_path else "",
                },
            )
        except RuntimeDelegationError as exc:
            return _build_stage_failure_result(
                request=request,
                title="Delegated execution could not be prepared",
                description=str(exc),
                code="prepare_delegated_run_failed",
                metadata={"workflow_id": resolved.workflow_id},
            )

        try:
            delegated = execute_delegated_run(
                command=prepared.command,
                workflow_dir=resolved.workflow_dir,
                copied_input_path=prepared.copied_input_path,
                environment=prepared.environment,
            )
        except RuntimeDelegationError as exc:
            return _build_stage_failure_result(
                request=request,
                title="Delegated execution failed to start",
                description=str(exc),
                code="execute_delegated_run_failed",
                metadata={"workflow_id": resolved.workflow_id},
            )

        exit_code = int(delegated.exit_code)
        runner_id = request.runner_id or _BUSINESS_STAGE_COMMAND_RUNNER_ID
        declared_runner_specs = _declared_runner_specs(request)

        # loop_verdict is the canonical signal the server's quality-loop
        # evaluator (stage_quality_loop._resolve_canonical_verdict) routes on.
        # Setting it explicitly keeps the router from falling into the
        # has_findings heuristic that would otherwise route a failed
        # delegation to revise_same_stage and cause an infinite redispatch
        # loop on every reported finding.
        if exit_code == 0:
            outcome = "passed"
            recommended_action = "continue"
            verdict = "sound"
            loop_verdict = "pass"
            findings: list[dict[str, Any]] = []
        else:
            outcome = "issues_found"
            recommended_action = "block"
            verdict = "issues"
            loop_verdict = "block"
            findings = [
                {
                    "id": "delegated_run_nonzero_exit",
                    "title": (
                        f"Delegated business workflow exited with code {exit_code}"
                    ),
                    "description": (
                        f"Subprocess `obra run` for workflow "
                        f"{resolved.workflow_id} exited with code {exit_code}. "
                        "Inspect the delegated session logs for the root cause."
                    ),
                    "priority": "P1",
                }
            ]

        # ``operation_kind="executed"`` is the canonical ArtifactOperationKind
        # for a stage whose work has been performed. The delegation-specific
        # semantic (that the work was performed by a nested ``obra run``
        # subprocess rather than an in-process runner) is carried in metadata
        # via ``dispatch_target="obra.run"`` — the server's ArtifactOperationKind
        # enum does not distinguish delegated vs. direct execution, and adding
        # a new enum value would be a cross-boundary contract change for a
        # detail already expressed in metadata.
        artifact = ProducedArtifactPayload(
            artifact_type="stage_output",
            artifact_id=f"delegated_run:{request.stage_execution_id}",
            version="v1",
            producer_kind="runtime",
            producer_id=runner_id,
            stage_name=request.stage_name,
            operation_kind="executed",
            metadata={
                "runner_kind": "command_runner",
                "dispatch_target": "obra.run",
                "domain_id": "business",
                "workflow_id": resolved.workflow_id,
                "workflow_dir": str(resolved.workflow_dir),
                "plan_path": str(prepared.plan_path),
                "input_path": str(prepared.copied_input_path),
                "exit_code": exit_code,
                "objective": prepared.objective,
                "dry_run": dry_run,
                "declared_runner_specs": declared_runner_specs,
            },
        )

        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status="complete",
            outcome=outcome,
            findings=findings,
            stage_output_artifacts=[artifact],
            candidate_stage_output_artifacts=[artifact],
            routing_signal={"recommended_action": recommended_action},
            loop_signal={
                "recommended_action": recommended_action,
                "current_iteration": request.iteration,
                "max_iterations": request.max_iterations,
            },
            runner_id=runner_id,
            runner_version=request.runner_version,
            runner_selector=request.runner_selector,
            verdict=verdict,
            loop_verdict=loop_verdict,
            iteration=request.iteration,
            metadata={
                "workflow_id": resolved.workflow_id,
                "workflow_dir": str(resolved.workflow_dir),
                "exit_code": exit_code,
                "declared_runner_specs": declared_runner_specs,
                # Carry the nested run's work-bearing-stage count so the
                # parent's dispatcher can plumb it into the parent
                # invocation counter, replacing the default +1 increment
                # for this work-bearing dispatch. Without this, the
                # parent's completion notice always reports
                # ``items_completed=1`` for any business workflow run
                # regardless of how many stories the nested run actually
                # executed. ``0`` means the nested didn't report (older
                # client, sidecar write failure) and the dispatcher falls
                # back to the +1 default.
                "delegated_items_completed": int(delegated.items_completed),
            },
        )


def build_code_quality_prompt() -> str:
    """Return business-domain prompt for code-quality review slot."""
    return BusinessDomain().get_quality_prompts()["code_quality"]


def build_testing_coverage_prompt() -> str:
    """Return business-domain prompt for testing-coverage review slot."""
    return BusinessDomain().get_quality_prompts()["testing_coverage"]


def build_docs_analysis_prompt() -> str:
    """Return business-domain prompt for docs-analysis review slot."""
    return BusinessDomain().get_quality_prompts()["docs_analysis"]


def build_security_sweep_prompt() -> str:
    """Return business-domain prompt for fast security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_sweep"]


def build_security_deep_prompt() -> str:
    """Return business-domain prompt for deep security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_deep"]
