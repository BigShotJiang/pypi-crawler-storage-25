import os
import sys
import json
import subprocess
import datetime
import shutil
import urllib.request
import re
import math

SCRIPT_VERSION = "2.1.0"

# 兼容性处理 tomllib
try:
    import tomllib
except ImportError:
    import pip._vendor.tomli as tomllib

SETTINGS_FILE = 'env_settings.json'
PYTHON_VERSION_FILE = '.python-version'
PYPROJECT_FILE = 'pyproject.toml'
VENV_DIR = '.venv'
LOCK_FILE = 'uv.lock'


# 终端颜色代码（提升 UI 体验）
class Color:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'


def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"{Color.YELLOW}⚠ 警告: 配置文件 {SETTINGS_FILE} 损坏，已恢复默认设置。{Color.RESET}")
        except Exception:
            pass
    return {"selected_mirror_name": "PyPI", "package_metadata": {}}


def save_settings(settings):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)


def enable_windows_ansi():
    """强制开启 Windows 控制台对 ANSI 颜色代码的支持"""
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32
        # -11 是标准输出设备 (STD_OUTPUT_HANDLE)
        handle = kernel32.GetStdHandle(-11)

        mode = wintypes.DWORD()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            # 0x0004 是 ENABLE_VIRTUAL_TERMINAL_PROCESSING
            # 允许控制台解释 ANSI 转义序列
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)


class UVEnvManager:
    def __init__(self):
        # 启用颜色支持
        try:
            enable_windows_ansi()
        except Exception:
            # 如果调用失败，尝试最后的保底方案
            os.system('')
        self.settings = load_settings()
        self.mirrors = {
            "阿里": "https://mirrors.aliyun.com/pypi/simple/",
            "清华大学": "https://pypi.tuna.tsinghua.edu.cn/simple/",
            "PyPI": "https://pypi.org/simple",
        }
        self._check_uv_installation()
        self._auto_pin_existing_env()

    def _check_uv_installation(self):
        try:
            subprocess.run(["uv", "--version"], capture_output=True, check=True)
        except (FileNotFoundError, subprocess.CalledProcessError):
            print(f"\n{Color.RED}❌ 错误: 当前环境中未检测到 uv 工具。{Color.RESET}")
            ans = input(f"{Color.CYAN}是否尝试使用当前 Python (pip) 自动安装 uv? [Y/n]: {Color.RESET}").strip().lower()
            if ans != 'n':
                print(">> 正在安装 uv...")
                try:
                    subprocess.run([sys.executable, "-m", "pip", "install", "uv"], check=True)
                    print(f"{Color.GREEN}✔ uv 安装成功！\n{Color.RESET}")
                except Exception as e:
                    print(f"{Color.RED}❌ 安装失败: {e}\n请手动运行 'pip install uv' 后重试。{Color.RESET}")
                    sys.exit(1)
            else:
                sys.exit(1)

    def _get_venv_python_version(self):
        if not os.path.exists(VENV_DIR):
            return "unknown"
        py_exe = os.path.join(VENV_DIR, "Scripts", "python.exe") if os.name == "nt" else os.path.join(VENV_DIR, "bin", "python")
        if os.path.exists(py_exe):
            try:
                res = subprocess.run([py_exe, "--version"], capture_output=True, text=True, check=True)
                return res.stdout.strip().split(" ")[1]
            except Exception:
                pass
        return "unknown"

    def _auto_pin_existing_env(self):
        if os.path.exists(VENV_DIR) and not os.path.exists(PYTHON_VERSION_FILE):
            ver = self._get_venv_python_version()
            if ver != "unknown":
                with open(PYTHON_VERSION_FILE, "w") as f:
                    f.write(ver)
                print(f"{Color.GREEN}ℹ 检测到已有虚拟环境，已自动锁定 Python 版本为: {ver}{Color.RESET}")

    def _backup_existing_venv(self):
        if not os.path.exists(VENV_DIR):
            return
        ver = self._get_venv_python_version()
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{VENV_DIR}_backup_{ver}_{ts}"
        try:
            os.rename(VENV_DIR, backup_name)
            print(f"{Color.GREEN}✔ 原有虚拟环境已成功备份至: {backup_name}{Color.RESET}")
        except Exception as e:
            print(f"{Color.RED}❌ 备份虚拟环境失败: {e}{Color.RESET}")

    def _run_uv(self, args, capture=False):
        env = os.environ.copy()
        if self.settings["selected_mirror_name"] != "PyPI":
            env["UV_INDEX_URL"] = self.mirrors[self.settings["selected_mirror_name"]]

        # 强制 uv 使用标准的输出方式，减少特殊符号冲突
        env["UV_SHOW_PROGRESS"] = "never" if capture else "auto"
        env["UV_HTTP_TIMEOUT"] = "30"
        env["PYTHONIOENCODING"] = "utf-8"

        try:
            if capture:
                # 关键改进：显式指定 encoding='utf-8' 和 errors='replace'
                res = subprocess.run(
                    ["uv"] + args,
                    env=env,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    check=True
                )
                return res.stdout
            else:
                # 非捕获模式下直接运行
                res = subprocess.run(["uv"] + args, env=env)
                return res.returncode == 0
        except subprocess.CalledProcessError as e:
            # 捕获异常时也安全处理 stderr
            stderr_msg = e.stderr if e.stderr else str(e)
            print(f"\n{Color.RED}[uv 报错]:\n{stderr_msg}{Color.RESET}")
            return False
        except Exception as e:
            print(f"\n{Color.RED}[执行异常]: {e}{Color.RESET}")
            return False

    def _fetch_pypi_repo_url(self, package_name):
        """从 PyPI 官方 API 获取库的源码/主页地址"""
        url = f"https://pypi.org/pypi/{package_name}/json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                urls = data.get("info", {}).get("project_urls") or {}

                # 优先级匹配：源码 > 仓库 > 主页
                for key in ["Source", "Source Code", "Repository", "Homepage"]:
                    if key in urls and urls[key]:
                        return urls[key]
                return data.get("info", {}).get("project_url", "")
        except Exception:
            return ""

    def _fetch_pypi_versions(self, package_name):
        """从 PyPI 获取按发布时间倒序排列的前10个版本号"""
        url = f"https://pypi.org/pypi/{package_name}/json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                releases = data.get("releases", {})

                version_times = []
                for ver, files in releases.items():
                    # 以该版本第一个文件的上传时间作为版本发布时间
                    upload_time = files[0].get("upload_time", "") if files else ""
                    version_times.append((ver, upload_time))

                # 按时间倒序排序（最新的在前）
                version_times.sort(key=lambda x: x[1], reverse=True)

                # 过滤并仅返回前10个
                return [v[0] for v in version_times[:10]]
        except Exception:
            return []

    def _get_dependency_types(self):
        """获取生产和开发依赖名列表"""
        prod_names, dev_names = [], []
        if os.path.exists(PYPROJECT_FILE):
            try:
                with open(PYPROJECT_FILE, "rb") as f:
                    data = tomllib.load(f)
                    p_raw = data.get("project", {}).get("dependencies", [])
                    d_raw = data.get("dependency-groups", {}).get("dev", [])
                    prod_names = [re.split(r'[=><\[~^]', p)[0].strip().lower() for p in p_raw]
                    dev_names = [re.split(r'[=><\[~^]', p)[0].strip().lower() for p in d_raw]
            except:
                pass
        return prod_names, dev_names

    def _try_update_to_best_version(self, pkg_name, current_version, is_dev=False):
        """
        尝试将包更新到兼容的最高版本
        如果最新版不兼容（Python版本冲突），则按时间倒序尝试之前的版本
        """
        print(f"\n{Color.CYAN}>> 正在为 {pkg_name} 寻找最佳兼容版本...{Color.RESET}")

        # 获取所有历史版本（按发布时间倒序）
        all_versions = self._fetch_pypi_versions(pkg_name)
        if not all_versions:
            print(f"{Color.RED}❌ 无法从 PyPI 获取版本列表。{Color.RESET}")
            return False

        # 筛选出比当前版本“新”的版本
        # 注意：这里简单通过索引处理，因为 all_versions 已经按时间倒序
        try:
            curr_idx = all_versions.index(current_version)
            candidate_versions = all_versions[:curr_idx]  # 比当前更晚发布的版本
        except ValueError:
            # 如果当前版本不在前10/20里，尝试全部候选
            candidate_versions = all_versions

        if not candidate_versions:
            print(f"{Color.YELLOW}  {pkg_name} 当前版本 {current_version} 已经是最新或没有更优选。{Color.RESET}")
            return True

        # 逐个尝试安装（从最新开始）
        success = False
        for ver in candidate_versions:
            print(f"  尝试版本:  {pkg_name}=={ver} ... ", end="", flush=True)

            pkg_spec = f"{pkg_name}=={ver}"
            cmd = ["add", "--dev", pkg_spec] if is_dev else ["add", pkg_spec]

            # 执行安装（不打印 uv 内部的冗长报错，只看结果）
            if self._run_uv(cmd, capture=True) is not False:
                print(f"{Color.GREEN}成功!{Color.RESET}")
                success = True
                # 记录元数据
                self._auto_fetch_and_save_repo(pkg_name)
                break
            else:
                print(f"{Color.YELLOW}不兼容，跳过。{Color.RESET}")

        if not success:
            print(f"{Color.YELLOW}⚠ 未能找到比 {current_version} 更高且兼容当前环境的版本。{Color.RESET}")

        return success

    def _universal_pkg_manager(self, title, action_callback):
        """通用包管理引擎"""
        search_kw = ""
        current_page = 1
        page_size = 20
        outdated_map = {}
        installed_pkgs = []

        def fetch_data():
            nonlocal outdated_map, installed_pkgs
            print(f"{Color.CYAN}正在同步环境信息...{Color.RESET}", end="\r")
            out_list = self._run_uv(["pip", "list", "--format=json"], capture=True)
            installed_pkgs = json.loads(out_list) if out_list else []
            out_json = self._run_uv(["pip", "list", "--outdated", "--format=json"], capture=True)
            if out_json:
                try:
                    data = json.loads(out_json)
                    outdated_map = {p['name'].lower(): p['latest_version'] for p in data}
                except:
                    outdated_map = {}
            else:
                outdated_map = {}

        fetch_data()

        while True:
            filtered = [p for p in installed_pkgs if search_kw in p['name'].lower()]
            total_items = len(filtered)
            total_pages = max(1, math.ceil(total_items / page_size))
            if current_page > total_pages: current_page = total_pages

            print(f"\n{Color.BOLD}{Color.CYAN}╔" + "═" * 70 + "╗")
            print(f"  {title}")
            print(f"╚" + "═" * 70 + "╝")

            search_display = f"'{search_kw}'" if search_kw else "全部"
            print(f"搜索: {Color.YELLOW}{search_display:<15}{Color.RESET} | 总数: {Color.GREEN}{total_items}{Color.RESET} | 页码: {current_page}/{total_pages}")
            print("-" * 72)

            start_idx = (current_page - 1) * page_size
            end_idx = min(start_idx + page_size, total_items)
            page_items = filtered[start_idx:end_idx]

            if not page_items:
                print(f"\n      {Color.RED}⚠ 未找到匹配的库。{Color.RESET}\n")
            else:
                for i, p in enumerate(page_items, start_idx + 1):
                    name = p['name']
                    curr_v = p['version']
                    latest_v = outdated_map.get(name.lower())

                    if latest_v and latest_v != curr_v:
                        v_str = f"v{curr_v:<10} -> {Color.GREEN}新版:{latest_v:<10}{Color.RESET}"
                    else:
                        v_str = f"v{curr_v:<25}"

                    meta = self.settings["package_metadata"].get(name, {})
                    note_tag = f" {Color.CYAN}📝{Color.RESET}" if meta.get("notes") else ""
                    url_tag = f" {Color.CYAN}🔗{Color.RESET}" if meta.get("repo_url") else ""
                    print(f" {i:>3}. {Color.BOLD}{name:<25}{Color.RESET} {v_str}{note_tag}{url_tag}")

            print("-" * 72)
            print(f"{Color.YELLOW}指令: [编号]操作 | [/]搜索 | [n/p]翻页 | [r]刷新 | [c]清空搜索 | [q]返回{Color.RESET}")
            cmd = input(f"{Color.BOLD}请输入指令: {Color.RESET}").strip().lower()

            if cmd == 'q':
                break
            elif cmd == 'n':
                if current_page < total_pages: current_page += 1
            elif cmd == 'p':
                if current_page > 1: current_page -= 1
            elif cmd == 'c':
                search_kw = ""
                current_page = 1
            elif cmd == 'r':
                fetch_data()
            elif cmd == '/':
                search_kw = input("输入搜索关键词: ").strip().lower()
                current_page = 1
            elif cmd.isdigit():
                idx = int(cmd)
                if 1 <= idx <= total_items:
                    # 执行子菜单动作
                    action_callback(filtered[idx - 1])
                    # 动作执行完（无论是否 break 出来），都刷新大列表数据
                    fetch_data()
                else:
                    print(f"{Color.RED}⚠ 编号超出范围{Color.RESET}")

    def manage_packages_unified(self):
        """实现操作后停留在子菜单，并实时刷新子菜单信息"""

        def sub_menu_action(initial_pkg):
            # 使用列表包装，以便在内部函数中修改当前显示的库对象
            state = {'pkg': initial_pkg}
            # 预先解析依赖归属
            prod_names, dev_names = self._get_dependency_types()

            while True:
                pkg = state['pkg']
                full_name = pkg['name']
                curr_v = pkg['version']
                pure_name = re.split(r'[=><\[]', full_name)[0].strip()
                meta = self.settings["package_metadata"].get(full_name, {})

                print(f"\n{Color.CYAN}┏" + "━" * 55 + "┓")
                print(f"  📦 库名: {Color.BOLD}{full_name}{Color.RESET}")
                print(f"  📌 版本: {Color.GREEN}{curr_v}{Color.RESET}")
                print(f"  📝 备注: {Color.YELLOW}{meta.get('notes', '无')}{Color.RESET}")
                print(f"  🔗 源码: {Color.BLUE}{meta.get('repo_url', '无')}{Color.RESET}")
                print(f"┗" + "━" * 55 + "┛")
                print(" 1. 升级至最新版")
                print(" 2. 切换指定版本")
                print(" 3. 修改备注/源码链接")
                print(" 4. 删除当前库")
                print(" b. 返回列表")

                choice = input(f"\n{Color.BOLD}请选择动作: {Color.RESET}").strip().lower()

                if choice == 'b':
                    break

                # 定义一个内部刷新函数，用于更新子菜单显示的当前库信息
                def refresh_current_pkg_info():
                    print(f"{Color.CYAN}正在刷新库状态...{Color.RESET}")
                    out = self._run_uv(["pip", "list", "--format=json"], capture=True)
                    if out:
                        all_pkgs = json.loads(out)
                        new_info = next((p for p in all_pkgs if p['name'].lower() == full_name.lower()), None)
                        if new_info:
                            state['pkg'] = new_info

                if choice == '1':
                    # 自动判定环境类型
                    is_dev = full_name.lower() in dev_names
                    # 调用通用更新方法
                    if self._try_update_to_best_version(pure_name, curr_v, is_dev):
                        self._run_uv(["sync"])
                        refresh_current_pkg_info()

                elif choice == '2':
                    versions = self._fetch_pypi_versions(pure_name)
                    if versions:
                        print(f"\n{Color.CYAN}--- {pure_name} 历史版本 ---{Color.RESET}")
                        for i, v in enumerate(versions, 1): print(f" [{i}] {v}")
                        sel = input("选择编号或直接输入版本号 (q返回): ").strip()
                        if sel.lower() != 'q':
                            ver = versions[int(sel) - 1] if (sel.isdigit() and 1 <= int(sel) <= len(versions)) else sel
                            if self._run_uv(["add", f"{full_name}=={ver}"]):
                                print(f"{Color.GREEN}✔ 已切换至版本 {ver}{Color.RESET}")
                                self._run_uv(["sync"])
                                refresh_current_pkg_info()  # 留在子菜单并刷新版本显示
                    else:
                        print(f"{Color.RED}❌ 无法获取版本记录。{Color.RESET}")

                elif choice == '3':
                    info = self.settings["package_metadata"].setdefault(full_name, {"repo_url": "", "notes": ""})
                    info["notes"] = input(f"新备注 [{info['notes']}]: ").strip() or info["notes"]
                    info["repo_url"] = input(f"新链接 [{info['repo_url']}]: ").strip() or info["repo_url"]
                    save_settings(self.settings)
                    print(f"{Color.GREEN}✔ 本地信息已更新。{Color.RESET}")
                    # 修改备注不涉及环境变化，不需要 refresh_current_pkg_info

                elif choice == '4':
                    if input(f"{Color.RED}确认移除 {full_name}？[y/N]: {Color.RESET}").lower() == 'y':
                        if self._run_uv(["remove", full_name]):
                            print(f"{Color.GREEN}✔ 已卸载。{Color.RESET}")
                            if full_name in self.settings["package_metadata"]:
                                del self.settings["package_metadata"][full_name]
                                save_settings(self.settings)
                            self._run_uv(["sync"])
                            break  # 库被删了，必须 break 回到列表页

        self._universal_pkg_manager("项目库管理", sub_menu_action)

    def get_project_status(self):
        status = {"has_toml": os.path.exists(PYPROJECT_FILE), "has_venv": os.path.exists(VENV_DIR),
                  "project_name": "未命名", "dep_count": 0, "dev_dep_count": 0, "python_pinned": "未锁定"}
        if status["has_toml"]:
            try:
                with open(PYPROJECT_FILE, "rb") as f:
                    data = tomllib.load(f)
                    status["project_name"] = data.get("project", {}).get("name", "未命名")
                    status["dep_count"] = len(data.get("project", {}).get("dependencies", []))
                    status["dev_dep_count"] = len(data.get("dependency-groups", {}).get("dev", []))
            except:
                pass
        if os.path.exists(PYTHON_VERSION_FILE):
            try:
                with open(PYTHON_VERSION_FILE, "r") as f:
                    status["python_pinned"] = f.read().strip()
            except:
                pass
        return status

    def sync_environment(self):
        print(f"\n{Color.CYAN}--- 环境同步选项 ---{Color.RESET}")
        print("1. 同步【全部】依赖 (基础生产库 + Dev 开发库) [默认]")
        print("2. 仅同步【基础库】 (不包含 Dev 开发库)")
        print("3. 深度修复 (强制重新安装所有包)")
        choice = input(f"请输入选项 [{Color.BOLD}1{Color.RESET}] (输入 q 取消): ").strip()

        if choice.lower() == 'q':
            return

        args = ["sync"]
        if choice == '2':
            args.append("--no-dev")
            print(">> 正在执行同步 (仅基础生产依赖)...")
        elif choice == '3':
            args.append("--reinstall")  # 解决 RECORD missing 等损坏问题的利器
            print(f"{Color.YELLOW}>> 正在执行深度修复安装...{Color.RESET}")
        else:
            print(">> 正在执行同步 (包含所有依赖)...")

        if self._run_uv(args):
            print(f"{Color.GREEN}✔ 环境同步完成。{Color.RESET}")
        else:
            print(f"{Color.RED}❌ 环境同步失败。{Color.RESET}")

    def init_or_recreate_project(self):
        print(f"\n{Color.CYAN}" + "-" * 40)
        print(" [项目初始化 / 重建工具]")
        print("-" * 40 + f"{Color.RESET}")

        if os.path.exists(PYPROJECT_FILE) or os.path.exists(VENV_DIR):
            print(f"{Color.YELLOW}⚠ 警告: 当前目录已存在项目文件或虚拟环境。{Color.RESET}")
            ans = input("是否要【备份现有环境并重新创建】一个纯净的项目？[y/N] (直接回车取消): ").strip().lower()
            if ans != 'y':
                print(">> 操作已取消。")
                return

            if os.path.exists(PYPROJECT_FILE):
                ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_toml = f"{PYPROJECT_FILE}.backup_{ts}"
                shutil.copy2(PYPROJECT_FILE, backup_toml)
                os.remove(PYPROJECT_FILE)
                print(f"{Color.GREEN}✔ 配置文件已备份为: {backup_toml}{Color.RESET}")

            if os.path.exists(LOCK_FILE): os.remove(LOCK_FILE)
            self._backup_existing_venv()

        name = input("请输入新项目名称 (留空则使用当前目录名): ").strip()
        args = ["init"] + (["--name", name] if name else [])

        if self._run_uv(args):
            print(f"{Color.GREEN}✔ pyproject.toml 初始化成功。{Color.RESET}")
            print(">> 正在创建全新的虚拟环境...")
            if self._run_uv(["venv"]):
                print(f"{Color.GREEN}✔ 空虚拟环境 (.venv) 创建成功！{Color.RESET}")
                self._auto_pin_existing_env()
        else:
            print(f"{Color.RED}❌ 初始化失败。{Color.RESET}")

    def migrate_requirements(self):
        print(f"\n{Color.CYAN}" + "-" * 30)
        print(" [迁移工具] 正在导入依赖...")
        print("-" * 30 + f"{Color.RESET}")

        if os.path.exists(LOCK_FILE):
            if input(f"{Color.YELLOW}检测到 uv.lock，是否删除以重新解析依赖？[y/N]: {Color.RESET}").strip().lower() == 'y':
                os.remove(LOCK_FILE)

        if os.path.exists("requirements.txt"):
            print(">> 正在导入生产依赖...")
            if self._run_uv(["add", "--requirements", "requirements.txt"]):
                print(f"{Color.GREEN}✔ 生产依赖导入完成。{Color.RESET}")
            else:
                return print(f"{Color.RED}❌ 生产环境导入失败。{Color.RESET}")

        if os.path.exists("requirements_dev.txt"):
            print("\n>> 正在处理开发依赖...")
            with open("requirements_dev.txt", "r") as f:
                clean_lines = [l.strip() for l in f if l.strip() and not l.startswith(("#", "-r"))]
            if clean_lines:
                temp_dev = "temp_dev_reqs.txt"
                with open(temp_dev, "w") as f:
                    f.write("\n".join(clean_lines))
                success = self._run_uv(["add", "--dev", "--requirements", temp_dev])
                os.remove(temp_dev)
                if success:
                    print(f"{Color.GREEN}✔ 开发依赖导入完成。{Color.RESET}")

        self.sync_environment()
        print(f"\n{Color.GREEN}--- 迁移任务成功结束 ---{Color.RESET}")

    def upgrade_all_packages(self):
        """批量更新：调用通用引擎实现逐个库的兼容性探测更新"""
        print(f"\n{Color.CYAN}>> 正在扫描过期库...{Color.RESET}")
        outdated_out = self._run_uv(["pip", "list", "--outdated", "--format=json"], capture=True)
        if not outdated_out or outdated_out.strip() == "[]":
            print(f"{Color.GREEN}✔ 所有库均已是最新兼容版本。{Color.RESET}")
            return

        outdated_list = json.loads(outdated_out)

        # 预先解析依赖归属
        prod_names, dev_names = self._get_dependency_types()

        print(f"\n{Color.YELLOW}将尝试为 {len(outdated_list)} 个库寻找最佳版本...{Color.RESET}")

        for p in outdated_list:
            name = p['name']
            curr_v = p['version']
            is_dev = name.lower() in dev_names

            # 调用通用更新引擎
            self._try_update_to_best_version(name, curr_v, is_dev)

        self._run_uv(["lock", "--upgrade"])
        self._run_uv(["sync"])
        print(f"\n{Color.GREEN}✔ 批量更新流程结束。{Color.RESET}")

    def _auto_fetch_and_save_repo(self, pkg_string):
        """内部辅助函数：获取链接并保存备注"""
        # 使用正则提取纯粹的包名 (去除 ==, >=, <=, [extras] 等)
        pure_name = re.split(r'[=><\[]', pkg_string)[0].strip()
        self.settings["package_metadata"].setdefault(pure_name, {"notes": "", "repo_url": ""})

        print(f">> 正在尝试从 PyPI 获取 {pure_name} 的源码地址...")
        repo_url = self._fetch_pypi_repo_url(pure_name)
        if repo_url:
            self.settings["package_metadata"][pure_name]["repo_url"] = repo_url
            print(f"{Color.GREEN}✔ 自动提取并保存了项目地址: {repo_url}{Color.RESET}")
            save_settings(self.settings)
        else:
            print(f"{Color.YELLOW}ℹ 未能在 PyPI 找到该库的源码地址。{Color.RESET}")
        return pure_name

    def install_package(self):
        pkg = input("\n请输入库名 (如 django 、requests==2.31.0 或 drf-spectacular[sidecar]) [直接回车取消]: ").strip()
        if not pkg: return

        print(f"\n请选择安装目标:")
        print("1. 基础生产依赖 (常规安装)")
        print("2. 开发依赖 (Dev - 仅开发测试使用)")
        choice = input(f"请输入选项 [{Color.BOLD}1{Color.RESET}] (输入 q 取消): ").strip()

        if choice.lower() == 'q':
            return

        is_dev = (choice == '2')
        args = ["add", "--dev", pkg] if is_dev else ["add", pkg]

        print(f">> 正在执行: uv {' '.join(args)}")

        if self._run_uv(args):
            pure_name = self._auto_fetch_and_save_repo(pkg)

            note = input(f"为 {pure_name} 添加本地备注 (留空跳过): ").strip()
            if note:
                self.settings["package_metadata"][pure_name]["notes"] = note
                save_settings(self.settings)

    def quick_remove_package(self):
        """快速删除"""

        def fast_remove(pkg):
            name = pkg['name']
            if input(f"{Color.RED}直接删除 {name}？[y/N]: {Color.RESET}").lower() == 'y':
                self._run_uv(["remove", name])
                self._run_uv(["sync"])

        self._universal_pkg_manager("快速删除模式", fast_remove)

    def change_python_version(self):
        """切换 Python 版本时，提示重建虚拟环境"""
        ver = input("请输入目标 Python 版本 (如 3.11, 3.12) [直接回车取消]: ").strip()
        if not ver: return

        if self._run_uv(["python", "pin", ver]):
            print(f"{Color.GREEN}✔ .python-version 已更新为 {ver}{Color.RESET}")
            if os.path.exists(VENV_DIR):
                print(f"\n{Color.YELLOW}⚠ 切换 Python 版本后，当前的虚拟环境 (.venv) 可能不再兼容。{Color.RESET}")
                if input("是否备份旧环境并使用新版本重新创建虚拟环境？[Y/n]: ").strip().lower() != 'n':
                    self._backup_existing_venv()
                    self._run_uv(["venv"])
                    self.sync_environment()
                    print(f"{Color.GREEN}✔ 基于 Python {ver} 的新环境已准备就绪。{Color.RESET}")

    def export_requirements(self):
        """默认导出无哈希值的清爽版，并询问是否导出 Dev"""
        print(">> 正在导出 requirements.txt (已自动去除 Hash 值使其更整洁)...")
        self._run_uv(["export", "--no-hashes", "--output-file", "requirements_exported.txt"])

        if input("是否还要导出开发依赖 (Dev)? [y/N]: ").strip().lower() == 'y':
            self._run_uv(["export", "--dev", "--no-hashes", "--output-file", "requirements_dev_exported.txt"])
        print(f"{Color.GREEN}✔ 导出完成。{Color.RESET}")

    def main_menu(self):
        while True:
            st = self.get_project_status()

            # 使用 ANSI 颜色美化状态显示
            toml_status = f"{Color.GREEN}已就绪{Color.RESET}" if st['has_toml'] else f"{Color.RED}缺失{Color.RESET}"
            venv_status = f"{Color.GREEN}已就绪{Color.RESET}" if st['has_venv'] else f"{Color.RED}缺失{Color.RESET}"

            print(f"\n{Color.CYAN}{Color.BOLD}" + "=" * 65)
            print(f" UV 环境管理助手 v{SCRIPT_VERSION}")
            print("=" * 65 + f"{Color.RESET}")
            print(f" 项目名称: {Color.BOLD}{st['project_name']}{Color.RESET}")
            print(f" 依赖统计: 生产 [{Color.GREEN}{st['dep_count']}{Color.RESET}] | 开发(Dev) [{Color.GREEN}{st['dev_dep_count']}{Color.RESET}]")
            print(f" 当前环境: Python {Color.YELLOW}{st['python_pinned']}{Color.RESET} | 镜像: {Color.YELLOW}{self.settings['selected_mirror_name']}{Color.RESET}")
            print(f" 配置文件 (pyproject.toml): {toml_status}")
            print(f" 虚拟环境 (.venv):         {venv_status}")
            print(f"{Color.CYAN}" + "=" * 65 + f"{Color.RESET}")

            print("0. 初始化项目 / 重建纯净环境 (uv init & venv)")
            print("1. 项目库管理")
            print("2. 安装新库 (Prod/Dev)")
            print("3. 删除库（快速模式）")  # 新增
            print("4. 升级【所有库】至最新版")
            print("5. Python 版本切换与锁定")
            print("6. 同步环境 (uv sync)")
            print("7. 切换镜像源")
            print("8. 导出 requirements.txt")
            print("9. 【迁移】从 requirements.txt 导入")
            print("e. 退出")

            c = input(f"\n{Color.BOLD}请输入指令: {Color.RESET}").strip().lower()
            if c == '0':
                self.init_or_recreate_project()
            elif c == '1':
                self.manage_packages_unified()
            elif c == '2':
                self.install_package()
            elif c == '3':
                self.quick_remove_package()
            elif c == '4':
                self.upgrade_all_packages()
            elif c == '5':
                self.change_python_version()
            elif c == '6':
                self.sync_environment()
            elif c == '7':
                names = list(self.mirrors.keys())
                for i, n in enumerate(names, 1): print(f"{i}. {n}")
                idx = input("选择 [直接回车跳过]: ").strip()
                if idx.isdigit() and 1 <= int(idx) <= len(names):
                    self.settings["selected_mirror_name"] = names[int(idx) - 1]
                    save_settings(self.settings)
            elif c == '8':
                self.export_requirements()
            elif c == '9':
                self.migrate_requirements()
            elif c == 'e':
                break


if __name__ == "__main__":
    manager = UVEnvManager()
    manager.main_menu()
