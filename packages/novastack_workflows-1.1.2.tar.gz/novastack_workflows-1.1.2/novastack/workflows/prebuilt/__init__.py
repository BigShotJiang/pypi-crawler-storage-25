try:
    import novastack.core  # noqa: F401

except ImportError as e:
    raise ImportError(
        "Missing dependency 'novastack-core' required for prebuilt workflows. "
        "Install with `pip install novastack-workflows[prebuilt]`."
    ) from e


from novastack.workflows.prebuilt.document_ingestion import DocumentIngestionWorkflow

__all__ = ["DocumentIngestionWorkflow"]
