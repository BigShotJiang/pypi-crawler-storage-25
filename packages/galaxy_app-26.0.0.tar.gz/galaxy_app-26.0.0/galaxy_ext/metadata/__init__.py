"""Work with Galaxy metadata"""
