#!/bin/sh

# This script installs uv if it's not already installed in the user account.
# It then runs uv inside Galaxy's root directory, potentially updating
# pyproject.toml and uv.lock, and the pinned requirements files.

set -e

this_directory="$(cd "$(dirname "$0")" > /dev/null && pwd)"

usage() {
    printf "Usage: %s: [-p pkg]\n" "${0##*/}" >&2
}

pkg=
while getopts 'p:h' OPTION
do
    case $OPTION in
        p) pkg="$OPTARG"
           ;;
        h) usage
           exit 0
           ;;
        ?) usage
           exit 2
           ;;
    esac
done
shift $((OPTIND - 1))

# Create a virtual environment in a tmp directory and install uv into it
if command -v uv >/dev/null; then
    uv="$(command -v uv)"
else
    uv_venv=$(mktemp -d "${TMPDIR:-/tmp}/uv_venv.XXXXXXXXXX")
    python3 -m venv "${uv_venv}"
    "${uv_venv}/bin/python" -m pip install uv
    uv="${uv_venv}/bin/uv"
fi

# Run uv (this may update pyproject.toml and uv.lock).
if [ -n "$pkg" ]; then
    ${uv} lock --upgrade-package "$pkg"
else
    ${uv} lock --upgrade
fi

# Update pinned requirements files.
UV_EXPORT_OPTIONS='--frozen --no-annotate --no-hashes'
# shellcheck disable=SC2086
${uv} export ${UV_EXPORT_OPTIONS} --no-dev > "$this_directory/pinned-requirements.txt"
# shellcheck disable=SC2086
${uv} export ${UV_EXPORT_OPTIONS} --only-group=test > "$this_directory/pinned-test-requirements.txt"
# shellcheck disable=SC2086
${uv} export ${UV_EXPORT_OPTIONS} --only-group=dev > "$this_directory/dev-requirements.txt"
# shellcheck disable=SC2086
${uv} export ${UV_EXPORT_OPTIONS} --only-group=typecheck > "$this_directory/pinned-typecheck-requirements.txt"
