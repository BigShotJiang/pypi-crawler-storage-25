from __future__ import annotations
from typing import Any, Dict, List, Optional
import re as _re
import urllib.parse
import uuid as _uuid_mod
import sys as _sys

_ISO8601_RE = _re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$")

def _srv(): return _sys.modules['mnemo_mcp.server']

from mnemo_mcp.server import _MAX_TOOL_LIMIT, _THREAD_STATUS_ALIASES
from mnemo_mcp.tools._format import table, confirm, warn, quota_notice, _trunc, _short_id

# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _handle_annotate_decision_outcome(*a, **kw): return _srv()._handle_annotate_decision_outcome(*a, **kw)
def _handle_annotate_thread_outcome_proxy(*a, **kw): return _srv()._handle_annotate_thread_outcome(*a, **kw)
def _handle_close_project_proxy(*a, **kw): return _srv()._handle_close_project(*a, **kw)
def _handle_escalate_thread_proxy(*a, **kw): return _srv()._handle_escalate_thread(*a, **kw)
def _handle_get_open_threads_proxy(*a, **kw): return _srv()._handle_get_open_threads(*a, **kw)
def _handle_get_overdue_threads_proxy(*a, **kw): return _srv()._handle_get_overdue_threads(*a, **kw)
def _handle_log_execution_event_proxy(*a, **kw): return _srv()._handle_log_execution_event(*a, **kw)
def _profile_path(*a, **kw): return _srv()._profile_path(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _resolve_profile_write(*a, **kw): return _srv()._resolve_profile_write(*a, **kw)
def _resolve_project(*a, **kw): return _srv()._resolve_project(*a, **kw)
def _validate_project_slug(*a, **kw): return _srv()._validate_project_slug(*a, **kw)
def _safe_scrub(*a, **kw): return _srv()._safe_scrub(*a, **kw)


def _handle_thread_action(args: Dict[str, Any]) -> str:
    """Dispatcher for thread_action tool (list / escalate / overdue)."""
    action = str(args.get("action") or "list").strip().lower()
    if action == "list":
        return _handle_get_open_threads_proxy(args)
    if action == "escalate":
        return _handle_escalate_thread_proxy(args)
    if action == "overdue":
        return _handle_get_overdue_threads_proxy(args)
    return f"Error: unknown action '{action}'. Must be list, escalate, or overdue."


def _handle_threads(args: Dict[str, Any]) -> str:
    """Consolidated threads tool dispatcher."""
    action = str(args.get("action") or "").strip().lower()
    if action == "list":
        mapped = dict(args)
        return _handle_get_open_threads(mapped)
    if action == "open":
        title = str(args.get("title") or "").strip()
        if not title:
            return "Error: title is required for action='open'."
        mapped = dict(args)
        return _handle_open_thread(mapped)
    if action == "escalate":
        thread_id = str(args.get("thread_id") or "").strip()
        if not thread_id:
            return "Error: thread_id is required for action='escalate'."
        deadline = str(args.get("deadline") or "").strip()
        if not deadline:
            return "Error: deadline is required for action='escalate'."
        mapped = dict(args)
        return _handle_escalate_thread(mapped)
    if action == "list_overdue":
        mapped = dict(args)
        return _handle_get_overdue_threads(mapped)
    return "Error: unknown action. Use one of: list, open, escalate, list_overdue."


def _handle_annotate_outcome(args: Dict[str, Any]) -> str:
    """Dispatcher for annotate_outcome tool (decision / thread / project)."""
    type_ = str(args.get("type") or "").strip().lower()
    if type_ == "decision":
        mapped = dict(args)
        if "id" in mapped and "decision_id" not in mapped:
            mapped["decision_id"] = mapped["id"]
        result = _handle_annotate_decision_outcome(mapped)
        # When event_type is provided alongside resolved, also log the execution milestone.
        event_type = str(args.get("event_type") or "").strip()
        outcome_status = str(args.get("outcome_status") or "").strip().lower()
        if event_type and outcome_status == "resolved" and "Error" not in result:
            description = str(args.get("outcome_notes") or "").strip()
            if not description:
                description = f"Decision {args.get('id', '')} resolved"
            try:
                _handle_log_execution_event_proxy({
                    "event_type": event_type,
                    "description": description,
                    "project": args.get("project", ""),
                    # Do not pass linked_decision_id: annotate_outcome already handled the resolution.
                })
                result += f"\nExecution event logged: [{event_type}] {description[:80]}"
            except (OSError, IOError, RuntimeError, TimeoutError):
                # Best-effort: I/O and runtime failures must not block the outcome annotation.
                # TypeError/AttributeError (programming errors) are intentionally NOT caught here.
                pass
        return result
    if type_ == "thread":
        mapped = dict(args)
        if "id" in mapped and "thread_id" not in mapped:
            mapped["thread_id"] = mapped["id"]
        return _handle_annotate_thread_outcome_proxy(mapped)
    if type_ == "project":
        project_slug = str(args.get("id") or "").strip()
        if not project_slug:
            return "Error: id (project slug) is required for type='project'."
        outcome_status = str(args.get("outcome_status") or "").strip().lower()
        if outcome_status not in {"archived", "completed", "abandoned"}:
            return "Error: outcome_status for type='project' must be archived, completed, or abandoned."
        mapped = dict(args)
        mapped["project"] = project_slug
        # Pass outcome_status as reason so the archive endpoint records the intent.
        if not mapped.get("reason"):
            notes = str(args.get("outcome_notes") or "").strip()
            mapped["reason"] = notes or outcome_status
        return _handle_close_project_proxy(mapped)
    return "Error: type must be 'decision', 'thread', or 'project'."


def _handle_get_open_threads(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 10)), _MAX_TOOL_LIMIT)
    requested_status = str(args.get("status", "open")).strip().lower()
    status = _THREAD_STATUS_ALIASES.get(requested_status, requested_status)
    if status not in {"open", "deferred", "resolved", "dormant", "all"}:
        return (
            "Error: status must be one of open, deferred, resolved, dormant, all "
            "(aliases: monitoring, abandoned)."
        )
    requested_project = str(args.get("project") or "").strip().lower()
    # 'all' is a reserved keyword meaning cross-project; pass it through directly.
    # _resolve_project is skipped so a project literally named 'all' cannot be queried by name.
    if requested_project == "all":
        project = "all"
        explicit_project = True
    else:
        project = _resolve_project(args)
        explicit_project = bool(args.get("project"))
    params: Dict[str, Any] = {"status": status, "limit": limit, "project": project}
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/threads')}?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"list_threads failed: {result['error']}. Check your status and project filters. [code: LIST_THREADS_FAILED]"
    threads = result if isinstance(result, list) else result.get("threads", [])

    usage_resp = _record_mcp_usage("get_open_threads")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not threads:
        hint = (
            f" No threads in project '{project}' — try project='all' to search across all projects, or specify a project name."
            if not explicit_project
            else ""
        )
        return f"No open threads found.{hint}" + quota_notice
    rows = [
        [_trunc(t.get("title", "?")), str(t.get("recurrence_count", 1)) + "x", str(t.get("last_mentioned", "?"))[:10], _short_id(t.get("thread_id", ""))]
        for t in threads
    ]
    out = f"Open threads ({len(threads)}):\n" + table(["Thread", "Seen", "Last", "ID"], rows)
    return out + quota_notice


def _open_thread_single(item: Dict[str, Any]) -> Dict[str, Any]:
    """Open one thread via the single-item endpoint. Returns a result dict."""
    title = _safe_scrub(str(item.get("title", "")).strip())
    if not title:
        return {"status": "error", "detail": "title is required"}
    importance = str(item.get("importance", "medium")).strip().lower()
    if importance not in {"low", "medium", "high", "critical"}:
        importance = "medium"
    body: Dict[str, Any] = {"title": title, "priority": importance}
    thread_body = _safe_scrub(str(item.get("body") or "").strip())
    if thread_body:
        body["body"] = thread_body
    project = _resolve_project(item)
    project_err = _validate_project_slug(project)
    if project_err:
        return {"status": "error", "detail": project_err}
    if project and project != "General":
        body["linked_project_id"] = project
    profile = _resolve_profile_write(item)
    idem_key: str = str(item.get("idempotency_key") or _uuid_mod.uuid4())
    _extra = {"Idempotency-Key": idem_key}
    _ctx_decision_id = _srv()._agent_decision_context.get(profile, "")
    if _ctx_decision_id:
        _extra["X-Mnemo-Agent-Decision-Id"] = _ctx_decision_id
        _extra["X-Mnemo-Agent-Id"] = _srv()._CLIENT_HINT
    result = _api_call(
        "POST",
        f"/profile/{urllib.parse.quote(profile)}/threads",
        body,
        extra_headers=_extra,
    )
    if "error" in result:
        return {"status": "error", "detail": result["error"]}
    thread_id = str(result.get("thread_id", "?"))
    deadline = str(item.get("deadline", "")).strip()
    if deadline:
        patch_result = _api_call(
            "PATCH",
            f"/profile/{urllib.parse.quote(profile)}/threads/{urllib.parse.quote(thread_id)}",
            {"deadline": deadline},
        )
        if "error" in patch_result:
            return {"status": "ok", "id": thread_id, "title": title, "deadline_error": str(patch_result["error"])}
        return {"status": "ok", "id": thread_id, "title": title, "deadline": deadline}
    return {"status": "ok", "id": thread_id, "title": title}


def _handle_open_thread(args: Dict[str, Any]) -> str:
    """Backward-compat wrapper — routes through _handle_open_threads."""
    if not str(args.get("title", "")).strip():
        return "Error: title is required."
    return _handle_open_threads({"threads": [args]})


def _handle_annotate_thread_outcome(args: Dict[str, Any]) -> str:
    thread_id = str(args.get("thread_id", "")).strip()
    if not thread_id:
        return "Error: thread_id is required."
    requested_status = str(args.get("outcome_status", args.get("status", ""))).strip().lower()
    status = _THREAD_STATUS_ALIASES.get(requested_status, requested_status)
    if status not in {"resolved", "deferred", "dormant"}:
        return (
            "Error: outcome_status must be resolved, deferred, or dormant "
            "(aliases: monitoring→deferred, abandoned→dormant)."
        )
    outcome_notes = str(args.get("outcome_notes", args.get("resolution_note", "")) or "").strip()
    profile = _resolve_profile_write(args)

    body: Dict[str, Any] = {"status": status}
    if outcome_notes:
        body["outcome"] = outcome_notes

    result = _api_call(
        "PATCH",
        f"/profile/{profile}/threads/{urllib.parse.quote(thread_id)}",
        body,
    )
    _record_mcp_usage("annotate_thread_outcome")
    if "error" in result:
        return "Error updating thread: unable to save status change. [code: THREAD_UPDATE_FAILED]"
    return confirm("Thread", thread_id, status, outcome_notes[:100] if outcome_notes else None)


def _escalate_thread_single(item: Dict[str, Any]) -> Dict[str, Any]:
    """Set a deadline on one thread via PATCH. Returns a result dict."""
    thread_id = str(item.get("thread_id") or "").strip()
    deadline = str(item.get("deadline") or "").strip()
    if not thread_id:
        return {"status": "error", "detail": "thread_id is required"}
    if not deadline:
        return {"status": "error", "detail": "deadline is required (ISO 8601)"}
    if not _ISO8601_RE.match(deadline):
        return {"status": "error", "detail": f"deadline must be ISO 8601 (e.g. '2026-05-01T17:00:00Z'). Got: {deadline[:40]}"}
    idem_key: str = str(item.get("idempotency_key") or _uuid_mod.uuid4())
    result = _api_call(
        "PATCH",
        _profile_path(f"/threads/{urllib.parse.quote(thread_id, safe='')}"),
        {"deadline": deadline},
        extra_headers={"Idempotency-Key": idem_key},
    )
    if isinstance(result, dict) and "error" in result:
        return {"status": "error", "detail": result["error"]}
    return {"status": "ok", "id": thread_id, "deadline": deadline}


def _handle_escalate_thread(args: Dict[str, Any]) -> str:
    """Backward-compat wrapper — routes through _handle_escalate_threads."""
    thread_id = str(args.get("thread_id") or "").strip()
    deadline = str(args.get("deadline") or "").strip()
    if not thread_id:
        return "Error: thread_id is required."
    if not deadline:
        return "Error: deadline is required (ISO 8601 datetime, e.g. '2026-04-18T17:00:00Z')."
    return _handle_escalate_threads({"items": [{"thread_id": thread_id, "deadline": deadline}]})


def _handle_get_overdue_threads(args: Dict[str, Any]) -> str:
    """Return open threads past their deadline."""
    limit = min(int(args.get("limit") or 20), _MAX_TOOL_LIMIT)
    params: Dict[str, Any] = {"overdue": "true", "limit": limit}
    # Only scope by project when caller explicitly passes one; otherwise return global overdue list.
    explicit_project = str(args.get("project") or "").strip()
    if explicit_project:
        params["project"] = explicit_project
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", _profile_path(f"/threads?{qs}"))
    if isinstance(result, dict) and "error" in result:
        return "Error fetching overdue threads. Check your filters and try again. [code: OVERDUE_FETCH_FAILED]"
    threads = result if isinstance(result, list) else result.get("threads", [])
    if not threads:
        return "No overdue threads — all deadlines are clear."
    rows = [
        [
            _trunc(t.get("content") or t.get("title") or t.get("body") or "?"),
            str(t.get("deadline") or "")[:16].replace("T", " "),
            _short_id(t.get("thread_id", "")),
        ]
        for t in threads
    ]
    _record_mcp_usage("get_overdue_threads")
    return f"Overdue Threads ({len(threads)}):\n" + table(["Thread", "Deadline", "ID"], rows)


def _handle_open_threads(args: Dict[str, Any]) -> str:
    """Open one or more threads. Loops over _open_thread_single — full feature parity including correlation headers."""
    threads_raw = args.get("threads")
    if not threads_raw or not isinstance(threads_raw, list):
        return "Error: threads must be a non-empty array."
    if len(threads_raw) > 25:
        return "Error: maximum 25 threads per call."

    _record_mcp_usage("open_threads")
    results = []
    for i, raw in enumerate(threads_raw):
        if not isinstance(raw, dict):
            results.append({"index": i, "status": "error", "detail": "item must be an object"})
            continue
        r = _open_thread_single(raw)
        r["index"] = i
        results.append(r)

    ok = sum(1 for r in results if r.get("status") == "ok")
    total = len(results)
    failed = [r for r in results if r.get("status") != "ok"]
    if not failed:
        ids = [r.get("id", "?") for r in results]
        return f"Opened {ok} thread(s): {', '.join(_short_id(i) for i in ids[:5])}{'...' if len(ids) > 5 else ''}."
    fail_summary = "; ".join(f"[{r['index']}] {r.get('detail', r.get('status','error'))}" for r in failed)
    return f"Partial: {ok}/{total} opened. Failed: {fail_summary}."


def _handle_escalate_threads(args: Dict[str, Any]) -> str:
    """Escalate one or more threads. Loops over _escalate_thread_single — full feature parity."""
    items_raw = args.get("items")
    if not items_raw or not isinstance(items_raw, list):
        return "Error: items must be a non-empty array of {thread_id, deadline} objects."
    if len(items_raw) > 25:
        return "Error: maximum 25 items per call."

    _record_mcp_usage("escalate_threads")
    results = []
    for i, raw in enumerate(items_raw):
        if not isinstance(raw, dict):
            results.append({"index": i, "status": "error", "detail": "item must be an object"})
            continue
        r = _escalate_thread_single(raw)
        r["index"] = i
        results.append(r)

    ok = sum(1 for r in results if r.get("status") == "ok")
    total = len(results)
    failed = [r for r in results if r.get("status") != "ok"]
    if not failed:
        return f"Escalated {ok} thread(s) with deadline(s)."
    fail_summary = "; ".join(f"[{r['index']}] {r.get('id', r.get('detail','?'))} {r.get('status','error')}" for r in failed)
    return f"Partial: {ok}/{total} escalated. Failed: {fail_summary}."
