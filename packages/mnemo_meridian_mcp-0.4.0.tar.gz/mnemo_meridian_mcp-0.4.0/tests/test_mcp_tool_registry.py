"""
tests/test_mcp_tool_registry.py

Assert that the MCP server registers at least 70 tools and that every tool
has a non-empty name and description.

Imports mnemo_mcp.server with all HTTP/backend dependencies mocked so the test
runs without a live API or database.
"""
from __future__ import annotations

import os
import sys
import types
import unittest.mock as mock

import pytest


# ── Stub heavy optional imports before mnemo_mcp.server is loaded ─────────────

def _stub_backend_modules():
	"""Install lightweight stubs for backend.* modules that server.py imports."""
	stubs = {
		"backend": types.ModuleType("backend"),
		"backend.agent_classifier": types.ModuleType("backend.agent_classifier"),
		"backend.metrics_collector": types.ModuleType("backend.metrics_collector"),
		"backend.pii_scrubber": types.ModuleType("backend.pii_scrubber"),
		"backend.feature_gates": types.ModuleType("backend.feature_gates"),
	}
	# agent_classifier stub
	stubs["backend.agent_classifier"].classify_wrap_session_decisions = None
	# metrics_collector stub — track_mcp_call must be a context manager factory
	import contextlib
	@contextlib.asynccontextmanager
	async def _noop_track(*_a, **_kw):
		yield None
	stubs["backend.metrics_collector"].track_mcp_call = _noop_track
	# pii_scrubber stub
	stubs["backend.pii_scrubber"].scrub_pii = lambda t: (t, [])
	# feature_gates stub
	stubs["backend.feature_gates"].FEATURE_GATES = {}
	stubs["backend.feature_gates"].check_feature = lambda *_a, **_kw: False

	for name, mod in stubs.items():
		if name not in sys.modules:
			sys.modules[name] = mod


_stub_backend_modules()

# Set required env var so module-level code doesn't complain
os.environ.setdefault("MNEMO_API_URL", "https://api.mnemomcp.com")
os.environ.setdefault("MNEMO_API_TOKEN", "test-token")

from mnemo_mcp.server import MNEMO_TOOLS, build_mcp_server, _handle_open_thread  # noqa: E402

import mnemo_mcp.server as _server  # noqa: E402 — used for patching


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_tool_count_at_least_20():
	"""MNEMO_TOOLS must define at least 20 tools."""
	assert len(MNEMO_TOOLS) >= 20, (
		f"Expected >= 20 tools, found {len(MNEMO_TOOLS)}. "
		"If new tools were removed, update this threshold."
	)


def test_every_tool_has_non_empty_name():
	"""Every tool dict must have a non-empty 'name' field."""
	bad = [t for t in MNEMO_TOOLS if not (t.get("name") or "").strip()]
	assert bad == [], f"Tools with empty/missing name: {bad}"


def test_every_tool_has_non_empty_description():
	"""Every tool dict must have a non-empty 'description' field."""
	bad = [t.get("name", "<unnamed>") for t in MNEMO_TOOLS
		   if not (t.get("description") or "").strip()]
	assert bad == [], f"Tools with empty/missing description: {bad}"


def test_tool_names_are_unique():
	"""Tool names must be unique within the registry."""
	names = [t.get("name") for t in MNEMO_TOOLS]
	seen: dict = {}
	dupes = []
	for n in names:
		if n in seen:
			dupes.append(n)
		seen[n] = True
	assert dupes == [], f"Duplicate tool names: {dupes}"


def test_every_tool_has_input_schema():
	"""Every tool must declare an inputSchema dict."""
	bad = [t.get("name", "<unnamed>") for t in MNEMO_TOOLS
		   if not isinstance(t.get("inputSchema"), dict)]
	assert bad == [], f"Tools missing inputSchema: {bad}"


def test_build_mcp_server_returns_server():
	"""build_mcp_server() must return a Server instance without raising."""
	try:
		from mcp.server import Server
		server = build_mcp_server()
		assert server is not None
		assert isinstance(server, Server)
	except ImportError:
		pytest.skip("mcp package not installed in this environment")


# ── open_thread handler tests ─────────────────────────────────────────────────

def test_open_thread_happy_path():
	"""open_thread returns thread_id and title on a successful POST."""
	with (
		mock.patch.object(_server, "_api_call", return_value={"thread_id": "thr_abc123", "title": "Scale concern"}),
		mock.patch.object(_server, "_record_mcp_usage", return_value={}),
		mock.patch.object(_server, "_active_profile", return_value="testuser"),
		mock.patch.object(_server, "_infer_project_from_cwd", return_value=""),
	):
		result = _handle_open_thread({"title": "Scale concern", "importance": "high"})
	assert "Opened 1 thread(s)" in result
	assert "thr_abc1" in result


def test_open_thread_missing_title():
	"""open_thread returns an error when title is absent."""
	result = _handle_open_thread({})
	assert result.startswith("Error: title is required.")


def test_regression_open_thread_deadline_triggers_patch():
	"""open_thread with a deadline fires POST then PATCH to set the deadline."""
	calls: list[tuple] = []

	def _fake_api_call(method: str, path: str, body=None, **_kw):
		calls.append((method, path))
		if method == "POST":
			return {"thread_id": "thr_dead001", "title": "Deadline thread"}
		return {"thread_id": "thr_dead001", "status": "open"}  # PATCH response

	with (
		mock.patch.object(_server, "_api_call", side_effect=_fake_api_call),
		mock.patch.object(_server, "_record_mcp_usage", return_value={}),
		mock.patch.object(_server, "_active_profile", return_value="testuser"),
		mock.patch.object(_server, "_infer_project_from_cwd", return_value=""),
	):
		result = _handle_open_thread({"title": "Deadline thread", "deadline": "2026-04-30T17:00:00Z"})

	methods = [m for m, _ in calls]
	assert methods == ["POST", "PATCH"], f"Expected POST then PATCH, got: {methods}"
	assert "Opened 1 thread(s)" in result
	assert "thr_dead" in result


def test_search_memory_scope_is_default():
	search = next(t for t in MNEMO_TOOLS if t["name"] == "search")
	assert search["inputSchema"]["properties"]["scope"]["default"] == "memory"


def test_regression_search_memory_deprecated_in_tools_list():
	server = build_mcp_server()
	tool_names = [t["name"] for t in MNEMO_TOOLS]
	assert "search" in tool_names
	assert "search_memory" not in tool_names
