# moss-classify

Python SDK for the Moss question classifier and normalizer service.

## Installation

```bash
pip install moss-classify
```

## Quick Start

```python
import asyncio
from moss_classify_rest import MossClassifyClient

async def main():
    client = MossClassifyClient(
        project_id="your-project-id",
        project_key="your-project-key",
    )

    # Classify an utterance
    result = await client.classify("What is your pricing?")
    print(result.label)       # "question"
    print(result.confidence)  # 0.92
    print(result.is_question) # True

    # Classify + normalize with conversation context
    result = await client.classify(
        "you use aws right?",
        context=["Agent: We provide cloud infrastructure.", "Customer: yeah so like"],
    )
    print(result.normalized_question)  # "Do you use AWS?"

    await client.close()

asyncio.run(main())
```

## Context Manager

```python
async with MossClassifyClient(project_id="...", project_key="...") as client:
    result = await client.classify("What is the pricing?")
```

## API Reference

### `MossClassifyClient(project_id, project_key, *, base_url, timeout)`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `project_id` | `str` | required | Your Moss project ID |
| `project_key` | `str` | required | Your Moss project key |
| `base_url` | `str` | `https://service.usemoss.dev` | Service URL |
| `timeout` | `float` | `30.0` | Request timeout in seconds |

### `await client.classify(text, *, context) -> ClassifyResult`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `text` | `str` | required | Utterance to classify |
| `context` | `list[str]` | `None` | Conversation context for normalization |

### `ClassifyResult`

| Field | Type | Description |
|-------|------|-------------|
| `label` | `str` | Predicted label |
| `confidence` | `float` | Confidence (0-1) |
| `is_question` | `bool` | Shortcut for `label == "question"` |
| `normalized_question` | `str \| None` | Cleaned question (when context provided) |

## Authentication

The client authenticates lazily on the first `classify()` call — it exchanges your `project_id` and `project_key` for a short-lived JWT token (1 hour). The token is cached and refreshed automatically before it expires. You can also call `await client.init()` to pre-authenticate.

