"""Moss Classify REST SDK"""

from moss_classify_rest.client import MossClassifyClient, ClassifyResult

__version__ = "0.1.0"

__all__ = ["MossClassifyClient", "ClassifyResult"]
