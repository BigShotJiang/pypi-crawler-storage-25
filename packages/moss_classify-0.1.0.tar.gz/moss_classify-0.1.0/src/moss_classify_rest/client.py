"""
Moss Classify REST client.

Usage::

    import asyncio
    from moss_classify_rest import MossClassifyClient

    async def main():
        client = MossClassifyClient(
            project_id="proj-abc",
            project_key="key-xyz",
        )

        # Auth happens lazily on first request
        result = await client.classify("What is the pricing?")
        print(result.label, result.confidence)

        # With conversation context (enables question normalization)
        result = await client.classify(
            "you use aws right?",
            context=["Agent: We provide cloud infrastructure."],
        )
        print(result.normalized_question)  # "Do you use AWS?"

        await client.close()

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Optional

import httpx

_DEFAULT_BASE_URL = "https://service.usemoss.dev"


@dataclass
class ClassifyResult:
    """Result from the classify endpoint."""

    label: str
    """Predicted label (e.g. "question" or "statement")."""

    confidence: float
    """Confidence score for the predicted label (0-1)."""

    latency_ms: float
    """Server-side classification latency in milliseconds."""

    normalized_question: Optional[str] = None
    """Cleaned-up question text. Only present when the utterance
    is classified as a question and context was provided."""

    normalization_latency_ms: Optional[float] = None
    """Server-side normalization latency in milliseconds."""

    normalization_error: Optional[str] = None
    """Error message if normalization failed."""

    @property
    def is_question(self) -> bool:
        return self.label == "question"


class MossClassifyClient:
    """Client for the Moss question classifier service.

    Handles JWT token exchange and auto-refresh. Tokens are cached and
    refreshed automatically when they expire.

    Args:
        project_id: Your Moss project ID.
        project_key: Your Moss project key.
        base_url: Service base URL. Defaults to ``https://service.usemoss.dev``.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        project_id: str,
        project_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._project_id = project_id
        self._project_key = project_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout)

        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0
        self._auth_lock = asyncio.Lock()

    # -- Token management -----------------------------------------------------

    def _token_valid(self) -> bool:
        # Refresh 5 minutes before expiry to avoid any chance of 401
        return self._token is not None and time.time() < self._token_expires_at - 300

    async def _authenticate(self) -> None:
        """Exchange project credentials for a JWT."""
        resp = await self._client.post(
            f"{self._base_url}/classify/auth/token",
            json={"projectId": self._project_id, "projectKey": self._project_key},
        )
        if resp.status_code == 401:
            raise AuthenticationError("Invalid project credentials")
        resp.raise_for_status()
        data = resp.json()
        self._token = data["token"]
        self._token_expires_at = time.time() + data["expiresIn"]

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}

    async def _ensure_auth(self) -> None:
        if not self._token_valid():
            async with self._auth_lock:
                # Double-check after acquiring lock — another task may have refreshed
                if not self._token_valid():
                    await self._authenticate()

    async def init(self) -> None:
        """Pre-authenticate with the service.

        Optional — if not called, authentication happens lazily on the
        first ``classify()`` call.
        """
        await self._ensure_auth()

    # -- Classify --------------------------------------------------------------

    async def classify(
        self,
        text: str,
        *,
        context: Optional[list[str]] = None,
        labels: Optional[list[str]] = None,
    ) -> ClassifyResult:
        """Classify an utterance.

        Args:
            text: The utterance to classify.
            context: Conversation context for question normalization.
            labels: Classification labels. Defaults to
                ``["question", "statement"]``.

        Returns:
            A :class:`ClassifyResult` with classification and optional
            normalization output.
        """
        await self._ensure_auth()
        payload: dict = {"text": text}
        if context is not None:
            payload["context"] = context
        if labels is not None:
            payload["labels"] = labels

        resp = await self._client.post(
            f"{self._base_url}/classify",
            json=payload,
            headers=self._auth_headers(),
        )
        if resp.status_code == 401:
            # Token may have expired mid-flight — retry once with lock
            await self._ensure_auth()
            resp = await self._client.post(
                f"{self._base_url}/classify",
                json=payload,
                headers=self._auth_headers(),
            )
        resp.raise_for_status()
        return _parse_result(resp.json())

    # -- Lifecycle -------------------------------------------------------------

    async def close(self) -> None:
        """Close underlying HTTP connections."""
        await self._client.aclose()

    async def __aenter__(self) -> MossClassifyClient:
        await self.init()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()


class AuthenticationError(Exception):
    """Raised when project credentials are invalid."""


def _parse_result(data: dict) -> ClassifyResult:
    return ClassifyResult(
        label=data["label"],
        confidence=data["confidence"],
        latency_ms=data["latency_ms"],
        normalized_question=data.get("normalized_question"),
        normalization_latency_ms=data.get("normalization_latency_ms"),
        normalization_error=data.get("normalization_error"),
    )
