"""
Integration tests for the Moss Classify REST SDK.

Test cases use synthetic sales-call utterances with conversation context
and verify that the service classifies them correctly and returns
normalized forms where applicable.
"""

import time

import pytest

from moss_classify_rest import MossClassifyClient


def _log_result(utterance, result, elapsed_ms, context=None):
    """Print input/output for every test case."""
    print()
    print(f"  INPUT:      {utterance}")
    if context:
        print(f"  CONTEXT:")
        for turn in context:
            print(f"              {turn}")
    print(f"  LABEL:      {result.label} ({result.confidence:.0%})")
    if result.normalized_question:
        print(f"  NORMALIZED: {result.normalized_question}")
    if result.normalization_error:
        print(f"  ERROR:      {result.normalization_error}")
    print(f"  LATENCY:    {elapsed_ms:.0f}ms")


# ---------------------------------------------------------------------------
# Test cases from table.tsv
# ---------------------------------------------------------------------------

TSV_QUESTION_CASES = [
    {
        "utterance": "Nice. Do you have other customers or in Sydney, do you have customers in West Australia? Because I'm based in Western Australia. Having customers across Australia?",
        "context": [
            "Others: I think it's important to define it very well, because Propeller, they do everything to the marketplace. They have enterprises, they have a private price agreement with us. Did they receive some benefits? And also they can offset part of the commitment through marketplace, and that's why they usually will try to procure everything through marketplace. Okay.",
            "Others: It's important for you to share this information with them if they are not aware about you or they are going to ask you during the process. But if you also can talk about that, it's good because then you can have a competitive advantage.",
            "Others: Because all the solutions, they are not in the marketplace as well.",
            "Others: Okay?",
        ],
    },
    {
        "utterance": "What is the usually ticket? Average ticket.",
        "context": [
            "Others: Nice. And then you have this a layer of technology on top of your PCRMs that provide automation benefits regarding procurement.",
            "Patrick Warr: Yeah, I'd say that's good point. But, yeah, there's definitely multiple aspects to it that if we were to give, like, a demo, the BA Team would do a lot better than I would because I'm just, like, the voice that sort of tries. To get the meaning.",
            "Others: starting",
        ],
    },
    {
        "utterance": "what you're selling? What is your average ticket when you sell? When you close a deal, you'll be $100,000, $200,000.",
        "context": [
            "Others: starting",
            "Others: What is the usually ticket? Average ticket.",
            "Others: That will be at the summary about your service.",
            "Patrick Warr: I don't think we have enough volume just yet to give an average, but it depends on the size of the company, so we base it on a transactions amount. So if you're processing 10,000 transactions versus 50,000 transactions, it scales.",
        ],
    },
    {
        "utterance": "When you run your software, you run in a customer environment, or is it like a SaaS solution? It's",
        "context": [
            "Patrick Warr: For a mid market",
            "Others: $200,000.",
            "Patrick Warr: And then for mid market, 75,000 per annum. But that only gives you up to 10,000 transactions. So if you are a mid market wanting to add more transactions, you can do that to get an extra to get up to 50,000 extra, 45,000 a year.",
            "Patrick Warr: a SaaS solution.",
        ],
    },
    {
        "utterance": "Currently. Do you know where in which cloud are you running on AWS or Azure or Google? Do you have an idea or center?",
        "context": [
            "Others: Okay?",
            "Others: But okay.",
            "Others: Nice.",
            "Patrick Warr: I wouldn't be sure. It's something I can take and ask one of the execs who will be more familiar with the space, but personally I would be unsure.",
        ],
    },
    {
        "utterance": "you use us as your cloud platform?",
        "context": [
            "Others: the power",
            "Patrick Warr: Okay.",
            "Others: Nice. Amazing. Next steps for us would be maybe if you can have a little bit of chat to understand, which if you need support on our side as a SaaS solution. I don't have too much in my hands to help you, but I'm really keen to try to understand better and see if maybe you can engage with other customers as well. Yeah, well, if you run on aws or not.",
        ],
    },
    {
        "utterance": "I can find you on my marketplace. I put RedOwl I didn't find. Maybe you have a product, a solution. You have a different solution or a RedOwl Security radio AI how is your solution?",
        "context": [
            "Others: Oh, okay. But you can be usually a SaaS company or they use a data center.",
            "Others: Can be next to C Maguire or they are running on it on Google or AWS or Azure. Okay, got you. If you are running on us, I will help you.",
            "Patrick Warr: you saying you can't find us on yours?",
            "Others: Are",
        ],
    },
    {
        "utterance": "what you can do for us. I need to understand if you are running on us, if you have a SaaS offer if you are going to be in the marketplace or not. You know, I need to double check it and then I can help you.",
        "context": [
            "Others: About how he can work together in this account would be amazing.",
            "Others: Okay. Okay. Because I need some more information. Because what I'm asking that, you know I can provide some credits, you know, that you can run a consumption park with them.",
            "Patrick Warr: So for future conversations on your end, we're missing information that will provide you what you need to know about how we operate or",
            "Others: But I need to understand where you are. You know, too much consumption here, you know.",
        ],
    },
    {
        "utterance": "And how exactly do you help us in this situation?",
        "context": [
            "Patrick Warr: So for future conversations on your end, we're missing information that will provide you what you need to know about how we operate or",
            "Others: But I need to understand where you are. You know, too much consumption here, you know.",
            "Others: what you can do for us. I need to understand if you are running on us, if you have a SaaS offer if you are going to be in the marketplace or not. You know, I need to double check it and then I can help you.",
            "Others: Okay.",
        ],
    },
]

STATEMENT_CASES = [
    {
        "utterance": "I'll send that over after the call.",
        "context": [],
    },
    {
        "utterance": "Our contract renews in September.",
        "context": [],
    },
]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAuth:
    @pytest.mark.asyncio
    async def test_authentication(self, client):
        """Client authenticates and gets a valid token."""
        t0 = time.monotonic()
        result = await client.classify("Hello")
        elapsed = (time.monotonic() - t0) * 1000
        _log_result("Hello", result, elapsed)
        assert result.label in ("question", "statement")

    @pytest.mark.asyncio
    async def test_invalid_credentials(self):
        """Invalid credentials raise AuthenticationError."""
        from moss_classify_rest.client import AuthenticationError

        bad_client = MossClassifyClient(
            project_id="invalid-id",
            project_key="invalid-key",
        )
        t0 = time.monotonic()
        with pytest.raises(AuthenticationError) as exc_info:
            await bad_client.init()
        elapsed = (time.monotonic() - t0) * 1000
        print(f"\n  INPUT:   invalid credentials")
        print(f"  OUTPUT:  AuthenticationError — {exc_info.value}")
        print(f"  LATENCY: {elapsed:.0f}ms")
        await bad_client.close()


class TestQuestionDetection:
    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "case",
        TSV_QUESTION_CASES,
        ids=[c["utterance"][:60] for c in TSV_QUESTION_CASES],
    )
    async def test_question_classified(self, client, case):
        """Utterances from the TSV that are questions should be classified as questions."""
        t0 = time.monotonic()
        result = await client.classify(case["utterance"])
        elapsed = (time.monotonic() - t0) * 1000
        _log_result(case["utterance"], result, elapsed)
        assert result.label == "question", (
            f"Expected 'question' but got '{result.label}' "
            f"(confidence={result.confidence:.4f}) for: {case['utterance'][:80]}"
        )
        assert result.is_question is True
        assert result.confidence > 0.5

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "case",
        STATEMENT_CASES,
        ids=[c["utterance"][:60] for c in STATEMENT_CASES],
    )
    async def test_statement_classified(self, client, case):
        """Statements should not be classified as questions."""
        t0 = time.monotonic()
        result = await client.classify(case["utterance"])
        elapsed = (time.monotonic() - t0) * 1000
        _log_result(case["utterance"], result, elapsed)
        assert result.label == "statement", (
            f"Expected 'statement' but got '{result.label}' "
            f"(confidence={result.confidence:.4f}) for: {case['utterance'][:80]}"
        )
        assert result.is_question is False


class TestNormalization:
    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "case",
        [c for c in TSV_QUESTION_CASES if c["context"]],
        ids=[c["utterance"][:60] for c in TSV_QUESTION_CASES if c["context"]],
    )
    async def test_question_normalized_with_context(self, client, case):
        """Questions with context should return a normalized_question."""
        t0 = time.monotonic()
        result = await client.classify(case["utterance"], context=case["context"])
        elapsed = (time.monotonic() - t0) * 1000
        _log_result(case["utterance"], result, elapsed, context=case["context"])
        assert result.label == "question"
        assert result.normalized_question is not None, (
            f"Expected normalized_question but got None for: {case['utterance'][:80]}"
        )
        assert len(result.normalized_question) > 0

    @pytest.mark.asyncio
    async def test_no_normalization_without_context(self, client):
        """Questions without context should not return a normalized_question."""
        t0 = time.monotonic()
        result = await client.classify("What is your pricing?")
        elapsed = (time.monotonic() - t0) * 1000
        _log_result("What is your pricing?", result, elapsed)
        assert result.label == "question"
        assert result.normalized_question is None

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "case",
        STATEMENT_CASES,
        ids=[c["utterance"][:60] for c in STATEMENT_CASES],
    )
    async def test_statement_not_normalized_with_context(self, client, case):
        """Statements should not be normalized even when context is provided."""
        context = [
            "Agent: Thanks for joining the call today.",
            "Customer: Yeah thanks, so we've been looking at a few vendors.",
            "Agent: Happy to walk you through what we offer.",
        ]
        t0 = time.monotonic()
        result = await client.classify(case["utterance"], context=context)
        elapsed = (time.monotonic() - t0) * 1000
        _log_result(case["utterance"], result, elapsed, context=context)
        assert result.label == "statement", (
            f"Expected 'statement' but got '{result.label}' "
            f"(confidence={result.confidence:.4f}) for: {case['utterance'][:80]}"
        )
        assert result.normalized_question is None


class TestResponseShape:
    @pytest.mark.asyncio
    async def test_result_fields(self, client):
        """ClassifyResult should have all expected fields."""
        t0 = time.monotonic()
        result = await client.classify("What is your pricing?")
        elapsed = (time.monotonic() - t0) * 1000
        _log_result("What is your pricing?", result, elapsed)
        assert isinstance(result.label, str)
        assert isinstance(result.confidence, float)
        assert isinstance(result.latency_ms, float)
        assert 0.0 <= result.confidence <= 1.0
