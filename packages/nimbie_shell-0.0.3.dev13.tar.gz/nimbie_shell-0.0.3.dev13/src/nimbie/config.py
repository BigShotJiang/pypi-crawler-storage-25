"""Config loading and normalization for the nimbie CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib.util
import json
import logging
import os
from pathlib import Path
import sys
from typing import Any
import uuid

LOGGER = logging.getLogger(__name__)


class APIType:
    """Well-known upstream API families."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"
    OLLAMA = "ollama"


@dataclass(slots=True)
class ProviderConfig:
    """Resolved provider definition."""

    name: str
    default_model: str
    api_base: str
    api_key: str | None = None
    description: str | None = None
    api_type: str = APIType.OPENAI
    litellm_provider: str | None = None
    extra_headers: dict[str, str] | None = None
    extra_query_params: dict[str, str] | None = None
    debug_request: bool = False
    debug_sse: bool = False
    debug_tools: bool = False


@dataclass(slots=True)
class ModelConfig:
    """Per-model tuning knobs."""

    temperature: float = 0.7
    max_tokens: int | None = None
    max_output_tokens: int | None = 8192
    timeout: int = 60
    extra_body: dict[str, Any] | None = None


@dataclass(slots=True)
class AgentConfig:
    """Agent loop defaults."""

    max_steps: int = 100
    user_name: str = "User"
    email: str | None = None


@dataclass(slots=True)
class UIConfig:
    """Terminal and web UI defaults."""

    show_reasoning: bool = False
    streaming: bool = True
    auto_allow_safe_bash: bool = True
    fold_bash_output: bool = True
    web_token: str | None = None


@dataclass(slots=True)
class Config:
    """Application config after normalization."""

    providers: list[ProviderConfig] = field(default_factory=list)
    default_provider: str | None = None
    models: dict[str, ModelConfig] = field(default_factory=dict)
    agent: AgentConfig = field(default_factory=AgentConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    user_name: str = "User"
    email: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Config":
        """Normalize an OpenClaw-style config dictionary into runtime config."""

        parser = _OpenClawConfigParser(data)
        providers, default_provider, models = parser.parse()
        return cls(
            providers=providers,
            default_provider=default_provider,
            models=models,
            agent=_coerce_dataclass(AgentConfig, data.get("agent")),
            ui=_coerce_dataclass(UIConfig, data.get("ui")),
            user_name=str(data.get("user_name") or "User"),
            email=_optional_text(data.get("email")),
        )

    @classmethod
    def load(cls, config_path: Path | None = None) -> "Config":
        """Load config from the first available candidate path."""

        chosen = config_path or _first_existing_config_path()
        if chosen is None or not chosen.exists():
            return cls()
        try:
            raw_payload = _read_config_payload(chosen)
        except Exception:
            LOGGER.exception("Failed to load config from %s", chosen)
            raise
        return cls.from_dict(raw_payload)


def provider_model_prefix(provider: ProviderConfig) -> str:
    """Return the canonical LiteLLM provider prefix for a provider config."""

    return str(provider.litellm_provider or provider.name)


def normalize_model_name(provider: ProviderConfig, explicit_model: str | None) -> str:
    """Normalize a user/config model ref into the LiteLLM-facing canonical form."""

    chosen = str(explicit_model or provider.default_model or "").strip()
    prefix = provider_model_prefix(provider)
    if "/" not in chosen:
        return f"{prefix}/{chosen}" if chosen else prefix
    raw_prefix, model_id = _split_model_ref(chosen)
    if raw_prefix == provider.name and model_id:
        return f"{prefix}/{model_id}"
    return chosen


def model_ref_matches_provider(model_ref: str, provider: ProviderConfig) -> bool:
    """Return whether a model ref belongs to the provider by local name or LiteLLM prefix."""

    raw_prefix, _ = _split_model_ref(model_ref)
    if raw_prefix is None:
        return False
    return raw_prefix in {provider.name, provider_model_prefix(provider)}


def _first_existing_config_path() -> Path | None:
    candidates = (
        Path.home() / ".nimbie" / "config.py",
        Path.home() / ".nimbie" / "config.json",
        Path.home() / ".openclaw" / "openclaw.json",
        Path.cwd() / ".nimbie_config.py",
        Path.cwd() / ".nimbie_config.json",
    )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _read_config_payload(config_path: Path) -> dict[str, Any]:
    if config_path.suffix.lower() == ".json":
        return _read_json_payload(config_path)
    return _read_python_payload(config_path)


def _read_json_payload(config_path: Path) -> dict[str, Any]:
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON config must be an object: {config_path}")
    return payload


def _read_python_payload(config_path: Path) -> dict[str, Any]:
    module_name = f"nimbie_config_{config_path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, config_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot import config module: {config_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
        payload = getattr(module, "CONFIG")
        if not isinstance(payload, dict):
            raise ValueError(f"CONFIG must be a dict: {config_path}")
        return payload
    finally:
        sys.modules.pop(module_name, None)


def _coerce_dataclass(cls: type[Any], raw_value: Any) -> Any:
    if not isinstance(raw_value, dict):
        return cls()
    return cls(**raw_value)


def _optional_text(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


class _OpenClawConfigParser:
    def __init__(self, raw: dict[str, Any]) -> None:
        self.raw = raw
        models_root = raw.get("models")
        if not isinstance(models_root, dict):
            raise ValueError("OpenClaw-style config requires a top-level 'models' object")
        providers_root = models_root.get("providers")
        if not isinstance(providers_root, dict):
            raise ValueError("OpenClaw-style config requires 'models.providers'")
        self.models_root = models_root
        self.providers_root = providers_root
        self.agent_defaults = ((raw.get("agents") or {}).get("defaults") or {}) if isinstance(raw.get("agents"), dict) else {}
        self.primary_provider, self.primary_model_id = _split_model_ref(
            (((self.agent_defaults.get("model") or {}).get("primary")) or "") if isinstance(self.agent_defaults.get("model"), dict) else ""
        )
        self._provider_names = {
            provider_name
            for provider_name, provider_payload in providers_root.items()
            if isinstance(provider_name, str) and isinstance(provider_payload, dict)
        }
        self._provider_prefixes = {
            provider_name: _resolve_litellm_provider(provider_name, provider_payload)
            for provider_name, provider_payload in providers_root.items()
            if isinstance(provider_name, str) and isinstance(provider_payload, dict)
        }

    def parse(self) -> tuple[list[ProviderConfig], str | None, dict[str, ModelConfig]]:
        providers: list[ProviderConfig] = []
        model_map: dict[str, ModelConfig] = {}
        for provider_name, provider_payload in self.providers_root.items():
            if not isinstance(provider_payload, dict):
                continue
            models = self._extract_model_entries(provider_payload)
            providers.append(self._build_provider(provider_name, provider_payload, models))
            model_map.update(self._build_model_map(provider_name, models))
        self._merge_agent_model_params(model_map)
        default_name = self.primary_provider or (providers[0].name if providers else None)
        return providers, default_name, model_map

    def _extract_model_entries(self, provider_payload: dict[str, Any]) -> list[dict[str, Any]]:
        entries = provider_payload.get("models")
        if not isinstance(entries, list):
            return []
        return [entry for entry in entries if isinstance(entry, dict)]

    def _build_provider(
        self,
        provider_name: str,
        provider_payload: dict[str, Any],
        model_entries: list[dict[str, Any]],
    ) -> ProviderConfig:
        litellm_provider = self._provider_prefixes.get(provider_name, provider_name)
        default_model = self._pick_default_model(provider_name, litellm_provider, model_entries)
        return ProviderConfig(
            name=provider_name,
            default_model=default_model,
            api_base=str(provider_payload.get("baseUrl") or ""),
            api_key=_resolve_provider_api_key(self.raw, provider_name),
            description=_optional_text(provider_payload.get("api")),
            api_type=_map_api_family(provider_payload.get("api")),
            litellm_provider=litellm_provider,
            extra_headers=_resolve_provider_extra_headers(self.raw, provider_name),
            extra_query_params=_resolve_provider_extra_query_params(self.raw, provider_name),
        )

    def _pick_default_model(self, provider_name: str, litellm_provider: str, model_entries: list[dict[str, Any]]) -> str:
        primary_matches_local = self.primary_provider == provider_name
        primary_matches_prefix = (
            self.primary_provider == litellm_provider and self.primary_provider not in self._provider_names
        )
        if (primary_matches_local or primary_matches_prefix) and self.primary_model_id:
            return f"{litellm_provider}/{self.primary_model_id}"
        for entry in model_entries:
            model_id = _optional_text(entry.get("id"))
            if model_id:
                return f"{litellm_provider}/{model_id}"
        return litellm_provider

    def _build_model_map(self, provider_name: str, model_entries: list[dict[str, Any]]) -> dict[str, ModelConfig]:
        output: dict[str, ModelConfig] = {}
        litellm_provider = self._provider_prefixes.get(provider_name, provider_name)
        for entry in model_entries:
            model_id = _optional_text(entry.get("id"))
            if not model_id:
                continue
            max_tokens = entry.get("maxTokens")
            timeout = entry.get("timeout")
            config = ModelConfig(
                max_output_tokens=int(max_tokens) if isinstance(max_tokens, int) else 8192,
                timeout=int(timeout) if isinstance(timeout, int) else 60,
            )
            output[f"{litellm_provider}/{model_id}"] = config
            if litellm_provider != provider_name:
                output[f"{provider_name}/{model_id}"] = config
        return output

    def _merge_agent_model_params(self, model_map: dict[str, ModelConfig]) -> None:
        raw_models = self.agent_defaults.get("models")
        if not isinstance(raw_models, dict):
            return
        for model_ref, payload in raw_models.items():
            if not isinstance(model_ref, str) or "/" not in model_ref:
                continue
            if not isinstance(payload, dict):
                continue
            params = payload.get("params")
            if not isinstance(params, dict):
                continue
            canonical_ref = self._canonical_model_ref(model_ref)
            base = model_map.get(canonical_ref, model_map.get(model_ref, ModelConfig()))
            base.extra_body = dict(params)
            model_map[canonical_ref] = base
            model_map[model_ref] = base

    def _canonical_model_ref(self, model_ref: str) -> str:
        provider_name, model_id = _split_model_ref(model_ref)
        if provider_name is None or model_id is None:
            return model_ref
        litellm_provider = self._provider_prefixes.get(provider_name)
        if litellm_provider:
            return f"{litellm_provider}/{model_id}"
        return model_ref


def _split_model_ref(value: str) -> tuple[str | None, str | None]:
    if "/" not in value:
        return None, None
    provider, model = value.split("/", 1)
    provider = provider.strip()
    model = model.strip()
    if not provider or not model:
        return None, None
    return provider, model


def _map_api_family(raw_value: Any) -> str:
    marker = str(raw_value or "").strip().lower()
    if marker == "anthropic-messages":
        return APIType.ANTHROPIC
    if marker == "ollama":
        return APIType.OLLAMA
    if marker == "local":
        return APIType.LOCAL
    return APIType.OPENAI


def _resolve_litellm_provider(provider_name: str, provider_payload: dict[str, Any]) -> str:
    explicit = _optional_text(
        provider_payload.get("litellmProvider")
        or provider_payload.get("litellm_provider")
        or provider_payload.get("modelPrefix")
        or provider_payload.get("model_prefix")
    )
    if explicit:
        return explicit
    api_type = _map_api_family(provider_payload.get("api"))
    if api_type == APIType.ANTHROPIC:
        return APIType.ANTHROPIC
    if api_type == APIType.OLLAMA:
        return APIType.OLLAMA
    if api_type == APIType.LOCAL:
        return APIType.LOCAL
    if api_type == APIType.OPENAI:
        return APIType.OPENAI
    return provider_name


def _resolve_provider_api_key(data: dict[str, Any], provider_name: str) -> str | None:
    profiles = ((data.get("auth") or {}).get("profiles") or {}) if isinstance(data.get("auth"), dict) else {}
    if not isinstance(profiles, dict):
        return None
    for profile in profiles.values():
        if not isinstance(profile, dict):
            continue
        if str(profile.get("provider") or "").strip() != provider_name:
            continue
        key = profile.get("apiKey") or profile.get("api_key")
        return _optional_text(key)
    return None


def _resolve_provider_extra_headers(data: dict[str, Any], provider_name: str) -> dict[str, str] | None:
    provider_payload = (
        (((data.get("models") or {}).get("providers") or {}).get(provider_name) or {})
        if isinstance((data.get("models") or {}).get("providers"), dict)
        else {}
    )
    profiles = ((data.get("auth") or {}).get("profiles") or {}) if isinstance(data.get("auth"), dict) else {}
    if not isinstance(profiles, dict):
        profiles = {}
    for profile in profiles.values():
        if not isinstance(profile, dict):
            continue
        if str(profile.get("provider") or "").strip() != provider_name:
            continue
        key = _optional_text(profile.get("apiKey") or profile.get("api_key"))
        api_key_header = _optional_text(profile.get("apiKeyHeader") or profile.get("api_key_header"))
        extra_headers = profile.get("extraHeaders") or profile.get("extra_headers")
        resolved: dict[str, str] = {}
        if isinstance(extra_headers, dict):
            for header_name, header_value in extra_headers.items():
                if not isinstance(header_name, str):
                    continue
                if header_value is None:
                    continue
                resolved[header_name] = str(header_value)
        if key and api_key_header:
            marker = api_key_header.strip().lower()
            if marker == "authorization_bearer":
                resolved["Authorization"] = f"Bearer {key}"
            else:
                resolved[api_key_header] = key
        if _truthy(
            profile.get("fakeClaudeCode")
            or profile.get("fake_claude_code")
            or (provider_payload.get("fakeClaudeCode") if isinstance(provider_payload, dict) else None)
            or (provider_payload.get("fake_claude_code") if isinstance(provider_payload, dict) else None)
        ):
            resolved = _merge_fake_claude_code_headers(resolved)
        return resolved or None
    if isinstance(provider_payload, dict) and _truthy(
        provider_payload.get("fakeClaudeCode") or provider_payload.get("fake_claude_code")
    ):
        return _merge_fake_claude_code_headers({})
    return None


def _resolve_provider_extra_query_params(data: dict[str, Any], provider_name: str) -> dict[str, str] | None:
    provider_payload = (
        (((data.get("models") or {}).get("providers") or {}).get(provider_name) or {})
        if isinstance((data.get("models") or {}).get("providers"), dict)
        else {}
    )
    profiles = ((data.get("auth") or {}).get("profiles") or {}) if isinstance(data.get("auth"), dict) else {}
    if not isinstance(profiles, dict):
        profiles = {}
    base: dict[str, str] = {}
    if isinstance(provider_payload, dict):
        base.update(
            _coerce_string_dict(
                provider_payload.get("extraQueryParams") or provider_payload.get("extra_query_params")
            )
        )
    for profile in profiles.values():
        if not isinstance(profile, dict):
            continue
        if str(profile.get("provider") or "").strip() != provider_name:
            continue
        merged = dict(base)
        merged.update(
            _coerce_string_dict(profile.get("extraQueryParams") or profile.get("extra_query_params"))
        )
        return merged or None
    return base or None


def _merge_fake_claude_code_headers(existing: dict[str, str]) -> dict[str, str]:
    resolved = dict(existing)
    session_id = (
        _optional_text(os.getenv("NIMBIE_CLAUDE_CODE_SESSION_ID"))
        or _optional_text(os.getenv("CLAUDE_CODE_SESSION_ID"))
        or str(uuid.uuid4())
    )
    user_agent = (
        _optional_text(os.getenv("NIMBIE_CLAUDE_CODE_USER_AGENT"))
        or "claude-cli/1.0.0 (NODE, cli)"
    )
    resolved.setdefault("x-app", "cli")
    resolved.setdefault("User-Agent", user_agent)
    resolved.setdefault("X-Claude-Code-Session-Id", session_id)
    container_id = _optional_text(os.getenv("CLAUDE_CODE_CONTAINER_ID"))
    remote_session_id = _optional_text(os.getenv("CLAUDE_CODE_REMOTE_SESSION_ID"))
    client_app = _optional_text(os.getenv("CLAUDE_AGENT_SDK_CLIENT_APP"))
    additional_protection = _optional_text(os.getenv("CLAUDE_CODE_ADDITIONAL_PROTECTION"))
    if container_id:
        resolved.setdefault("x-claude-remote-container-id", container_id)
    if remote_session_id:
        resolved.setdefault("x-claude-remote-session-id", remote_session_id)
    if client_app:
        resolved.setdefault("x-client-app", client_app)
    if additional_protection:
        resolved.setdefault("x-anthropic-additional-protection", additional_protection)
    return resolved


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return False


def _coerce_string_dict(raw_value: Any) -> dict[str, str]:
    if not isinstance(raw_value, dict):
        return {}
    resolved: dict[str, str] = {}
    for key, value in raw_value.items():
        if not isinstance(key, str) or value is None:
            continue
        resolved[key] = str(value)
    return resolved
