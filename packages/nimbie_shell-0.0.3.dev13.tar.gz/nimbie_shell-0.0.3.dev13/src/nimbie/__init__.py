"""nimbie: Lightweight context manager CLI built standalone.

This nested package exists to satisfy uv_build's src-layout.
"""
__all__ = []
