from __future__ import annotations
from shutil import get_terminal_size
from typing import Callable
try:
    from wcwidth import wcswidth as _wcswidth
except Exception:
    _wcswidth = None

class StreamingTail:
    """Single-line tail buffer with left-trim and no newline.

    - Accumulates text and exposes a truncated 'display' that keeps the rightmost
      portion within a max width, prefixing with '…' when truncated.
    - Does NOT write to stdout itself; caller decides how to render (e.g. rich Status).
    """

    def __init__(self, *, max_width: int | None=None, reserve_right: int=2, width_provider: Callable[[], int] | None=None) -> None:
        self.buffer: list[str] = []
        self._display: str = ''
        self.reserve_right = max(0, reserve_right)
        self.width_provider = width_provider or (lambda: get_terminal_size(fallback=(120, 24)).columns)
        self.config_max = max_width or 240

    def _term_width(self) -> int:
        try:
            w = int(self.width_provider())
        except Exception:
            w = 120
        return max(20, w)

    @staticmethod
    def _norm_text(s: str) -> str:
        s = s.replace('\r', ' ').replace('\n', ' ')
        return s

    @staticmethod
    def _vis_len(s: str) -> int:
        if _wcswidth is None:
            return len(s)
        w = _wcswidth(s)
        return w if w >= 0 else len(s)

    def _truncate_right(self, s: str, maxw: int) -> str:
        if self._vis_len(s) <= maxw:
            return s
        target = max(1, maxw)
        if _wcswidth is None:
            return '…' + s[-(target - 1):] if target > 1 else '…'
        out_rev: list[str] = []
        w = 0
        for ch in reversed(s):
            cw = self._vis_len(ch)
            if w + cw >= target - 1:
                break
            out_rev.append(ch)
            w += cw
        shown = ''.join(reversed(out_rev))
        return '…' + shown

    def update(self, text: str) -> str:
        if not text:
            return self._display
        self.buffer.append(self._norm_text(text))
        raw = ''.join(self.buffer)
        avail = max(8, min(self.config_max, self._term_width()) - self.reserve_right)
        self._display = self._truncate_right(raw, avail)
        return self._display

    def display(self) -> str:
        return self._display

    def clear(self) -> None:
        self.buffer.clear()
        self._display = ''
