from __future__ import annotations
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as ThreadTimeoutError
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from ...connect import ConnectContext, ConnectResult, get_connect_provider_registry

class RemoteShellSupport:
    """
    Shell initialization and execution adapter to avoid duplicated shell logic in run_loop.
    """

    def __init__(self, opts: Any) -> None:
        self.opts = opts
        self.shell = None
        self._output_sink = None
        self._flash_interp = None
        self._flash_executor = None
        self._remote_ssh_host: Optional[str] = None
        self._remote_ssh_user: Optional[str] = None
        self._remote_ssh_port: Optional[int] = None
        self._remote_executor_path: Optional[str] = None
        self._remote_ssh_config_path: Optional[str] = None
        self._remote_supports_started_event: Optional[bool] = None
        self._remote_identity_user: Optional[str] = None
        self._remote_identity_host: Optional[str] = None
        self._remote_home: Optional[str] = None
        self._remote_login_pwd: Optional[str] = None
        self._remote_path_snapshot: Optional[str] = None
        self._remote_env_snapshot: Dict[str, str] = {}
        self._remote_initial_commands: set[str] = set()
        self._remote_transport_stdin_fd: Optional[int] = None
        self._remote_transport_stdout_fd: Optional[int] = None
        self._remote_transport_stderr_fd: Optional[int] = None
        self._remote_transport_pid: Optional[int] = None
        self._remote_transport_process: Any = None
        self._prompt_error_reported = False
        self._prompt_build_executor = ThreadPoolExecutor(max_workers=1)
        self._prompt_env_cache: Dict[str, str] = {}
        self._prompt_env_cache_backend: str = ''
        self._flash_executor_kind: Optional[str] = None

    def set_output_sink(self, sink) -> None:
        self._output_sink = sink

    def _executor_debug_enabled(self) -> bool:
        v = str(os.getenv('NIMBIE_EXECUTOR_DEBUG', '')).strip().lower()
        return v in {'1', 'true', 'yes', 'on'}

    def _executor_debug_verbose(self) -> bool:
        v = str(os.getenv('NIMBIE_EXECUTOR_DEBUG_VERBOSE', '')).strip().lower()
        return v in {'1', 'true', 'yes', 'on'}

    def _emit_executor_debug(self, msg: str) -> None:
        if not self._executor_debug_enabled():
            return
        line = f'[executor][debug] {msg}'
        sink = self._output_sink
        if callable(sink):
            try:
                sink('executor_debug', line + '\n', False, False)
                return
            except TypeError:
                try:
                    sink('executor_debug', line + '\n', False)
                    return
                except Exception:
                    pass
            except Exception:
                pass
        try:
            sys.stdout.write(line + '\n')
            sys.stdout.flush()
        except Exception:
            pass

    def _build_prompt_impl(self) -> str:
        t0 = time.monotonic()
        try:
            import nimbie_flash as flash
        except Exception as e:
            raise RuntimeError(f'failed to import nimbie_flash for prompt rendering: {e}') from e
        self._sync_flash_backend_env()
        executor = self._ensure_flash_executor(flash, remote=(self._build_remote_ssh_command() is not None))
        if not hasattr(flash, 'build_prompt_from_env'):
            raise RuntimeError('nimbie_flash.build_prompt_from_env is not available')
        backend_key = str(self.remote_status_text() or 'local')
        env_map: Dict[str, str]
        if self._prompt_env_cache and self._prompt_env_cache_backend == backend_key:
            env_map = dict(self._prompt_env_cache)
        else:
            env_map = dict(os.environ)
            source = 'local_env'
            try:
                maybe = executor.get_env()
                if isinstance(maybe, dict):
                    env_map = {str(k): str(v) for k, v in maybe.items()}
                    source = 'executor_env_once'
            except Exception:
                source = 'local_env_fallback'
            self._prompt_env_cache = dict(env_map)
            self._prompt_env_cache_backend = backend_key
            self._emit_executor_debug(f'prompt env cache synced source={source} backend={backend_key}')
        cwd = None
        try:
            if self._flash_interp is not None and hasattr(self._flash_interp, 'cwd'):
                cwd = getattr(self._flash_interp, 'cwd')
        except Exception:
            cwd = None
        if not isinstance(cwd, str) or not cwd:
            cwd = os.getcwd()
        p = flash.build_prompt_from_env(cwd, env_map)
        if not isinstance(p, str) or not p:
            raise RuntimeError(f'invalid prompt returned by flash: {p!r}')
        self._emit_executor_debug(f'build_prompt ok backend={self.remote_status_text()} cwd={cwd} elapsed_ms={(time.monotonic() - t0) * 1000:.1f}')
        return p

    def build_prompt(self) -> str:
        timeout_s = 3.0
        try:
            timeout_s = max(0.2, float(os.getenv('NIMBIE_PROMPT_TIMEOUT_S', '3')))
        except Exception:
            timeout_s = 3.0
        fut = self._prompt_build_executor.submit(self._build_prompt_impl)
        try:
            return str(fut.result(timeout=timeout_s))
        except ThreadTimeoutError as e:
            fut.cancel()
            self._emit_executor_debug(f'build_prompt timeout after {timeout_s:.1f}s')
            raise RuntimeError(f'prompt build timed out after {timeout_s:.1f}s') from e

    def _executor_meta_from_path(self, path: Path) -> Dict[str, str]:
        s = str(path)
        sl = s.lower()
        meta: Dict[str, str] = {'arch': '', 'os': '', 'libc': '', 'glibc_min': ''}
        triples = ['x86_64-unknown-linux-musl', 'x86_64-unknown-linux-gnu', 'aarch64-unknown-linux-musl', 'aarch64-unknown-linux-gnu', 'armv7-unknown-linux-musleabihf', 'armv7-unknown-linux-gnueabihf', 'x86_64-apple-darwin', 'aarch64-apple-darwin']
        for t in triples:
            if t in s:
                parts = t.split('-')
                meta['arch'] = parts[0]
                if 'apple-darwin' in t:
                    meta['os'] = 'darwin'
                    meta['libc'] = 'darwin'
                else:
                    meta['os'] = 'linux'
                    meta['libc'] = 'musl' if 'musl' in t else 'glibc'
                return meta
        if 'openwrt' in sl:
            meta['os'] = 'openwrt'
        if 'darwin' in sl or 'macos' in sl:
            meta['os'] = meta['os'] or 'darwin'
        if 'musl' in sl:
            meta['libc'] = meta['libc'] or 'musl'
        if 'glibc' in sl or '-gnu' in sl:
            meta['libc'] = meta['libc'] or 'glibc'
        m = re.search('(?:glibc|gnu)[-_]?(\\d+\\.\\d+)', sl)
        if m:
            meta['glibc_min'] = m.group(1)
        return meta

    def _collect_local_stdio_executor_binaries(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        seen: set[str] = set()

        def _add_candidate(p: Path, source: str) -> None:
            try:
                rp = str(p.expanduser().resolve())
            except Exception:
                rp = str(p.expanduser())
            if rp in seen:
                return
            pp = Path(rp)
            try:
                if not (pp.is_file() and os.access(pp, os.X_OK)):
                    return
            except Exception:
                return
            seen.add(rp)
            meta = self._executor_meta_from_path(pp)
            out.append({'path': pp, 'source': source, 'meta': meta})
        local_override = os.getenv('NIMBIE_FLASH_STDIO_EXECUTOR_LOCAL_BIN', '').strip()
        if local_override:
            _add_candidate(Path(local_override), 'env:NIMBIE_FLASH_STDIO_EXECUTOR_LOCAL_BIN')
        flash_override = os.getenv('FLASH_STDIO_EXECUTOR_LOCAL_BIN', '').strip()
        if flash_override:
            _add_candidate(Path(flash_override), 'env:FLASH_STDIO_EXECUTOR_LOCAL_BIN')
        try:
            import nimbie_flash
        except Exception:
            nimbie_flash = None
        if nimbie_flash is not None:
            try:
                bundled = nimbie_flash.bundled_stdio_executor_path()
            except Exception:
                bundled = None
            if bundled is not None:
                _add_candidate(Path(bundled), 'python-package:nimbie_flash')
        multi = os.getenv('FLASH_STDIO_EXECUTOR_CANDIDATES', '').strip()
        if multi:
            for item in multi.split(os.pathsep):
                it = item.strip()
                if it:
                    _add_candidate(Path(it), 'env:FLASH_STDIO_EXECUTOR_CANDIDATES')
        repo_root = Path(__file__).resolve().parents[4]
        candidates = [repo_root / 'flash' / 'target' / 'x86_64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'x86_64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'aarch64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'aarch64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'x86_64-apple-darwin' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'aarch64-apple-darwin' / 'release' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'maturin' / 'flash-stdio-executor', repo_root / 'flash' / 'target' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'x86_64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'x86_64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'aarch64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'aarch64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'x86_64-apple-darwin' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'aarch64-apple-darwin' / 'release' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'maturin' / 'flash-stdio-executor', Path.cwd() / 'flash' / 'target' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'x86_64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'x86_64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'aarch64-unknown-linux-musl' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'aarch64-unknown-linux-gnu' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'x86_64-apple-darwin' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'aarch64-apple-darwin' / 'release' / 'flash-stdio-executor', Path.cwd() / 'target' / 'maturin' / 'flash-stdio-executor', Path.cwd() / 'target' / 'release' / 'flash-stdio-executor']
        for c in candidates:
            _add_candidate(c, 'auto-discovery')
        which = shutil.which('flash-stdio-executor')
        if which:
            _add_candidate(Path(which), 'PATH')
        return out

    def _resolve_local_stdio_executor_binary(self) -> Tuple[Optional[str], Dict[str, Any]]:
        info: Dict[str, Any] = {
            'explicit_bin': os.getenv('FLASH_STDIO_EXECUTOR_BIN', '').strip(),
            'nimbie_local_override': os.getenv('NIMBIE_FLASH_STDIO_EXECUTOR_LOCAL_BIN', '').strip(),
            'flash_local_override': os.getenv('FLASH_STDIO_EXECUTOR_LOCAL_BIN', '').strip(),
            'bundled_path': None,
            'bundled_exists': False,
            'bundled_executable': False,
            'bundled_error': '',
            'selected_source': '',
            'candidates': [],
        }
        selected = info['explicit_bin'] or info['nimbie_local_override'] or info['flash_local_override']
        if info['explicit_bin']:
            info['selected_source'] = 'env:FLASH_STDIO_EXECUTOR_BIN'
        elif info['nimbie_local_override']:
            info['selected_source'] = 'env:NIMBIE_FLASH_STDIO_EXECUTOR_LOCAL_BIN'
        elif info['flash_local_override']:
            info['selected_source'] = 'env:FLASH_STDIO_EXECUTOR_LOCAL_BIN'
        try:
            import nimbie_flash
        except Exception as e:
            info['bundled_error'] = str(e)
            nimbie_flash = None
        if nimbie_flash is not None:
            try:
                bundled = nimbie_flash.bundled_stdio_executor_path()
            except Exception as e:
                bundled = None
                info['bundled_error'] = str(e)
            if bundled is not None:
                bundled_path = Path(bundled)
                info['bundled_path'] = str(bundled_path)
                try:
                    info['bundled_exists'] = bundled_path.exists()
                    info['bundled_executable'] = os.access(bundled_path, os.X_OK)
                except Exception:
                    info['bundled_exists'] = False
                    info['bundled_executable'] = False
                if (not selected) and info['bundled_exists'] and info['bundled_executable']:
                    selected = str(bundled_path)
                    info['selected_source'] = 'python-package:nimbie_flash'
        candidates = self._collect_local_stdio_executor_binaries()
        info['candidates'] = [{'path': str(item.get('path')), 'source': str(item.get('source') or '')} for item in candidates]
        return (str(selected) if selected else None, info)

    def _rank_executor_candidates(self, candidates: List[Dict[str, Any]], *, remote_arch: str, remote_libc: str, remote_os: str, remote_glibc_version: str) -> List[Dict[str, Any]]:

        def _parse_ver(v: str) -> Tuple[int, ...]:
            try:
                return tuple((int(x) for x in v.split('.')))
            except Exception:
                return tuple()

        def _score(c: Dict[str, Any]) -> Tuple[int, int, int]:
            meta = c.get('meta') or {}
            arch = str(meta.get('arch', '') or '')
            libc = str(meta.get('libc', '') or '')
            os_name = str(meta.get('os', '') or '')
            glibc_min = str(meta.get('glibc_min', '') or '')
            arch_score = 3 if arch and arch == remote_arch else 1 if not arch else 0
            libc_score = 3 if libc and libc == remote_libc else 1 if not libc else 0
            if remote_libc == 'glibc' and libc == 'glibc' and glibc_min and remote_glibc_version and (_parse_ver(glibc_min) > _parse_ver(remote_glibc_version)):
                libc_score = 0
            if os_name and os_name == remote_os:
                os_score = 3
            elif os_name == 'linux' and remote_os == 'openwrt':
                os_score = 2
            else:
                os_score = 1 if not os_name else 0
            return (arch_score, libc_score, os_score)
        return sorted(candidates, key=_score, reverse=True)

    def _build_remote_ssh_command(self) -> Optional[Tuple[str, List[str]]]:
        if not self._remote_executor_path or not self._remote_ssh_host:
            return None
        args: List[str] = ['-T', '-o', 'BatchMode=yes', '-o', 'NumberOfPasswordPrompts=0', '-o', 'StrictHostKeyChecking=accept-new', '-o', 'ConnectTimeout=8']
        if self._remote_ssh_config_path:
            args.extend(['-F', self._remote_ssh_config_path])
        if self._remote_ssh_port:
            args.extend(['-p', str(int(self._remote_ssh_port))])
        if self._remote_ssh_user:
            args.extend(['-l', self._remote_ssh_user])
        args.append(self._remote_ssh_host)
        args.append(self._remote_executor_path)
        return ('ssh', args)

    def _build_remote_ssh_probe_base(self) -> Optional[List[str]]:
        if not self._remote_ssh_host:
            return None
        args: List[str] = ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'NumberOfPasswordPrompts=0', '-o', 'StrictHostKeyChecking=accept-new', '-o', 'ConnectTimeout=2']
        if self._remote_ssh_config_path:
            args.extend(['-F', self._remote_ssh_config_path])
        if self._remote_ssh_port:
            args.extend(['-p', str(int(self._remote_ssh_port))])
        if self._remote_ssh_user:
            args.extend(['-l', self._remote_ssh_user])
        args.append(self._remote_ssh_host)
        return args

    def _remote_command_exists(self, name: str) -> bool:
        base = self._build_remote_ssh_probe_base()
        if base is None:
            return False
        if not name:
            return False
        cmd_check = f'command -v -- {shlex.quote(name)} >/dev/null 2>&1'
        path_snapshot = str(self._remote_path_snapshot or '').strip()
        if path_snapshot:
            remote_cmd = f'env PATH={shlex.quote(path_snapshot)} sh -lc {shlex.quote(cmd_check)}'
        else:
            remote_cmd = f'sh -lc {shlex.quote(cmd_check)}'
        try:
            p = subprocess.run([*base, remote_cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=False, timeout=1.5)
            rc = getattr(p, 'returncode', 1)
            try:
                rc_i = int(rc)
            except Exception:
                rc_i = 1
            ok = rc_i == 0
            if ok:
                self._remote_initial_commands.add(name)
            return ok
        except Exception:
            return False

    def remote_status_text(self) -> str:
        if not self._remote_executor_path or not self._remote_ssh_host:
            return 'local'
        user_prefix = f'{self._remote_ssh_user}@' if self._remote_ssh_user else ''
        port_suffix = f':{self._remote_ssh_port}' if self._remote_ssh_port else ''
        return f'ssh({user_prefix}{self._remote_ssh_host}{port_suffix})'

    def _sync_flash_backend_env(self) -> None:
        cmd = self._build_remote_ssh_command()
        if cmd is None:
            os.environ.pop('FLASH_STDIO_EXECUTOR_BIN', None)
            os.environ.pop('FLASH_STDIO_EXECUTOR_ARGS_JSON', None)
            os.environ.pop('FLASH_REMOTE_USER', None)
            os.environ.pop('FLASH_REMOTE_HOSTNAME', None)
            os.environ.pop('FLASH_REMOTE_HOME', None)
            os.environ.pop('FLASH_REMOTE_LOGIN_PWD', None)
            os.environ.pop('FLASH_REMOTE_PATH', None)
            os.environ.pop('FLASH_REMOTE_ENV_JSON', None)
            os.environ.pop('FLASH_DISABLE_BACKEND_IDENTITY_PROBE', None)
            return
        bin_name, args = cmd
        os.environ['FLASH_STDIO_EXECUTOR_BIN'] = str(bin_name)
        os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = json.dumps(args)
        if self._remote_identity_user:
            os.environ['FLASH_REMOTE_USER'] = str(self._remote_identity_user)
        else:
            os.environ.pop('FLASH_REMOTE_USER', None)
        if self._remote_identity_host:
            os.environ['FLASH_REMOTE_HOSTNAME'] = str(self._remote_identity_host)
        else:
            os.environ.pop('FLASH_REMOTE_HOSTNAME', None)
        if self._remote_home:
            os.environ['FLASH_REMOTE_HOME'] = str(self._remote_home)
        else:
            os.environ.pop('FLASH_REMOTE_HOME', None)
        if self._remote_login_pwd:
            os.environ['FLASH_REMOTE_LOGIN_PWD'] = str(self._remote_login_pwd)
        else:
            os.environ.pop('FLASH_REMOTE_LOGIN_PWD', None)
        if self._remote_path_snapshot:
            os.environ['FLASH_REMOTE_PATH'] = str(self._remote_path_snapshot)
        else:
            os.environ.pop('FLASH_REMOTE_PATH', None)
        if self._remote_env_snapshot:
            try:
                os.environ['FLASH_REMOTE_ENV_JSON'] = json.dumps(self._remote_env_snapshot)
            except Exception:
                os.environ.pop('FLASH_REMOTE_ENV_JSON', None)
        else:
            os.environ.pop('FLASH_REMOTE_ENV_JSON', None)
        os.environ['FLASH_DISABLE_BACKEND_IDENTITY_PROBE'] = '1'

    def _ensure_flash_executor(self, flash: Any, *, remote: bool) -> Any:
        want = 'stdio' if remote else 'local'
        if self._flash_executor is not None and self._flash_executor_kind == want:
            return self._flash_executor
        if remote:
            if not hasattr(flash, 'StdioExecutor'):
                raise RuntimeError('nimbie_flash.StdioExecutor is not available')
            use_fd_backend = (
                hasattr(flash.StdioExecutor, 'from_fds')
                and self._remote_transport_stdin_fd is not None
                and self._remote_transport_stdout_fd is not None
            )
            if use_fd_backend:
                try:
                    self._flash_executor = flash.StdioExecutor.from_fds(
                        int(self._remote_transport_stdin_fd),
                        int(self._remote_transport_stdout_fd),
                        (int(self._remote_transport_stderr_fd) if self._remote_transport_stderr_fd is not None else None),
                        (int(self._remote_transport_pid) if self._remote_transport_pid is not None else None),
                    )
                except Exception as e:
                    self._emit_executor_debug(f'from_fds failed, fallback to env stdio: {e}')
                    self._flash_executor = flash.StdioExecutor()
            else:
                self._flash_executor = flash.StdioExecutor()
        else:
            self._flash_executor = flash.LocalExecutor()
        self._flash_executor_kind = want
        return self._flash_executor

    def disconnect_ssh(self) -> None:
        self._emit_executor_debug('disconnect ssh backend')
        self._remote_ssh_host = None
        self._remote_ssh_user = None
        self._remote_ssh_port = None
        self._remote_executor_path = None
        self._remote_ssh_config_path = None
        self._remote_supports_started_event = None
        self._remote_identity_user = None
        self._remote_identity_host = None
        self._remote_home = None
        self._remote_login_pwd = None
        self._remote_path_snapshot = None
        self._remote_env_snapshot = {}
        self._remote_initial_commands.clear()
        self._remote_transport_stdin_fd = None
        self._remote_transport_stdout_fd = None
        self._remote_transport_stderr_fd = None
        self._remote_transport_pid = None
        proc = self._remote_transport_process
        self._remote_transport_process = None
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass
            try:
                proc.wait(timeout=0.2)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        self._sync_flash_backend_env()
        self._flash_interp = None
        self._flash_executor = None
        self._flash_executor_kind = None
        self._prompt_env_cache = {}
        self._prompt_env_cache_backend = ''

    def close(self) -> None:
        try:
            self._prompt_build_executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass

    async def connect_with_provider(self, provider_name: str, target: str, *, force_upload: bool=False) -> str:
        self._emit_executor_debug(
            f'connect provider={provider_name} target={target} force_upload={int(bool(force_upload))}'
        )
        registry = get_connect_provider_registry()
        provider = registry.get(provider_name)
        ctx = ConnectContext(
            force_upload=force_upload,
            collect_local_candidates=self._collect_local_stdio_executor_binaries,
            rank_candidates=lambda cands, arch, libc, os_name, glibc: self._rank_executor_candidates(
                cands,
                remote_arch=arch,
                remote_libc=libc,
                remote_os=os_name,
                remote_glibc_version=glibc,
            ),
            emit_debug=self._emit_executor_debug,
            ssh_config_path=(Path.home() / '.ssh' / 'config'),
        )
        result = await provider.connect(target, ctx)
        self._apply_connect_result(result)
        return str(result.status_message or f'connected via provider={result.provider}')

    async def connect(self, target_spec: str, *, force_upload: bool=False) -> str:
        spec = str(target_spec or '').strip()
        if not spec:
            raise ValueError('missing connect target')
        registry = get_connect_provider_registry()
        for name in registry.names():
            prefix = f'{name}:'
            if spec.startswith(prefix):
                return await self.connect_with_provider(name, spec[len(prefix):], force_upload=force_upload)
        return await self.connect_with_provider('ssh', spec, force_upload=force_upload)

    async def connect_ssh(self, target: str, *, force_upload: bool=False) -> str:
        return await self.connect_with_provider('ssh', target, force_upload=force_upload)

    def _apply_connect_result(self, result: ConnectResult) -> None:
        t = result.transport
        self._remote_ssh_host = result.ssh_host
        self._remote_ssh_user = result.ssh_user
        self._remote_ssh_port = result.ssh_port
        self._remote_executor_path = result.uploaded.remote_path
        self._remote_ssh_config_path = result.ssh_config_path
        self._remote_supports_started_event = bool(result.uploaded.supports_started_event)
        self._remote_identity_user = result.identity.user
        self._remote_identity_host = result.identity.host
        self._remote_home = result.identity.home
        self._remote_login_pwd = result.identity.login_pwd
        self._remote_path_snapshot = result.identity.path
        self._remote_env_snapshot = dict(result.identity.env or {})
        self._remote_initial_commands = set(result.command_cache or set())
        self._remote_transport_stdin_fd = t.stdin_fd
        self._remote_transport_stdout_fd = t.stdout_fd
        self._remote_transport_stderr_fd = t.stderr_fd
        self._remote_transport_pid = t.pid
        md = dict(t.metadata or {})
        self._remote_transport_process = md.get('process')
        if t.bin_name:
            os.environ['FLASH_STDIO_EXECUTOR_BIN'] = str(t.bin_name)
        if t.args:
            os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = json.dumps(list(t.args))
        self._sync_flash_backend_env()
        self._flash_interp = None
        self._flash_executor = None
        self._flash_executor_kind = None
        self._prompt_env_cache = {}
        self._prompt_env_cache_backend = ''
