from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Any
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.text import Text
from rich.style import Style
from ..incremental_markdown import IncrementalMarkdownBuffer
from ..terminal_markdown import TerminalMarkdownTheme, detect_terminal_background, resolve_code_theme

class RenderState(str, Enum):
    OFF = 'off'
    LIVE_TRANSIENT = 'live_transient'
    LIVE_NON_TRANSIENT = 'live_non_transient'
    MARKDOWN_STREAMING = 'markdown_streaming'

@dataclass
class RendererConfig:
    refresh_per_second: int = 16
    code_theme: str = 'auto'
    show_reasoning_header: bool = True
    reasoning_header_text: str = 'Reasoning:\n'
    reasoning_header_style: str = 'dim italic'

class Renderer:
    """
    Renderer states: OFF / LIVE_TRANSIENT / LIVE_NON_TRANSIENT / MARKDOWN_STREAMING

    Semantics:
    - OFF: prompt input mode, no active Rich Live instance
    - LIVE_TRANSIENT: ephemeral spinner/status UI (cleared on stop)
    - LIVE_NON_TRANSIENT: pinned UI for tool preview/call state
    - MARKDOWN_STREAMING: line-by-line markdown delta output
    """

    def __init__(self, console: Console, cfg: Optional[RendererConfig]=None) -> None:
        self.console = console
        self.cfg = cfg or RendererConfig()
        self.state: RenderState = RenderState.OFF
        self._live: Optional[Live] = None
        self._reasoning_stream: Optional[IncrementalMarkdownBuffer] = None
        self._content_stream: Optional[IncrementalMarkdownBuffer] = None
        self._reasoning_started = False
        self._content_started = False
        self._redirect_callback: Optional[callable] = None
        self._original_stdout: Optional[Any] = None
        self._original_stderr: Optional[Any] = None
        self._redirect_active: bool = False

    def redirect_stdout_stderr(self, callback: callable) -> None:
        """Redirect stdout/stderr to a callback function."""
        import sys
        self._redirect_callback = callback
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        self._redirect_active = True
        orig_stdout_isatty = sys.stdout.isatty() if hasattr(sys.stdout, 'isatty') else False
        orig_stderr_isatty = sys.stderr.isatty() if hasattr(sys.stderr, 'isatty') else False

        class RedirectWriter:

            def __init__(self, original, callback, name, get_active, orig_isatty):
                self._original = original
                self._callback = callback
                self._name = name
                self._get_active = get_active
                self._orig_isatty = orig_isatty

            def write(self, text):
                if text and text.strip() and self._get_active():
                    self._callback(text)
                self._original.write(text)

            def flush(self):
                self._original.flush()

            def isatty(self):
                return True

            def __getattr__(self, name):
                return getattr(self._original, name)
        sys.stdout = RedirectWriter(self._original_stdout, lambda t: callback(t, 'stdout'), 'stdout', lambda: self._redirect_active, orig_stdout_isatty)
        sys.stderr = RedirectWriter(self._original_stderr, lambda t: callback(t, 'stderr'), 'stderr', lambda: self._redirect_active, orig_stderr_isatty)

    def restore_stdout_stderr(self) -> None:
        """Restore original stdout/stderr."""
        import sys
        self._redirect_active = False
        if self._original_stdout:
            sys.stdout = self._original_stdout
        if self._original_stderr:
            sys.stderr = self._original_stderr
        self._redirect_callback = None

    def enter_prompt(self) -> None:
        self._finalize_streaming_if_any()
        self._stop_live_if_any(drop=True)
        self.state = RenderState.OFF

    def show_live(self, renderable: Any, *, transient: bool=True) -> None:
        """
        Render content in Rich Live mode.
        If transient mode changes, restart Live to preserve consistency.
        """
        self._finalize_streaming_if_any()
        desired_state = self._desired_live_state(transient)
        if self._is_live_state(self.state) and self.state != desired_state:
            self._stop_live_if_any(drop=True)
        self._ensure_live_started(transient=transient)
        assert self._live is not None
        self._live.update(renderable)
        self.state = desired_state

    def show_spinner(self, renderable: Any) -> None:
        self.show_live(renderable, transient=True)

    def show_tool_preview(self, markdown_text: str, *, header: str='') -> None:
        self.show_live(Markdown((header or '') + (markdown_text or '')), transient=False)

    def stream_delta(self, kind: str, delta: str) -> None:
        if not delta:
            return
        self._ensure_streaming_mode()
        stream = self._get_stream(kind)
        if kind == 'reasoning' and (not self._reasoning_started):
            self._reasoning_started = True
            if self.cfg.show_reasoning_header:
                self.console.print(Text(self.cfg.reasoning_header_text, style=self.cfg.reasoning_header_style))
        if kind == 'content' and (not self._content_started):
            self._content_started = True
        stream.push_delta(delta)
        for line in stream.commit_complete_lines():
            self.console.print(line)

    def end_streaming_turn(self) -> None:
        was_streaming = self.state == RenderState.MARKDOWN_STREAMING
        self._finalize_streaming_if_any()
        if was_streaming:
            self.state = RenderState.OFF

    def print_warning(self, text: str) -> None:
        if self._is_live_state(self.state):
            self._stop_live_if_any(drop=True)
            self.state = RenderState.OFF
        self.console.print(text, style='yellow')

    def print_error(self, text: str) -> None:
        if self._is_live_state(self.state):
            self._stop_live_if_any(drop=True)
            self.state = RenderState.OFF
        self.console.print(text, style='red')

    def print_info(self, text: str) -> None:
        if self._is_live_state(self.state):
            self._stop_live_if_any(drop=True)
            self.state = RenderState.OFF
        self.console.print(text)

    def close(self) -> None:
        self._finalize_streaming_if_any()
        self._stop_live_if_any(drop=True)
        self.state = RenderState.OFF

    def get_status_info(self) -> dict:
        state_emoji = {RenderState.OFF: '⌨️', RenderState.LIVE_TRANSIENT: '⏳', RenderState.LIVE_NON_TRANSIENT: '📌', RenderState.MARKDOWN_STREAMING: '📺'}
        state_desc = {RenderState.OFF: 'Prompt input', RenderState.LIVE_TRANSIENT: 'Transient live UI', RenderState.LIVE_NON_TRANSIENT: 'Pinned live UI', RenderState.MARKDOWN_STREAMING: 'Streaming markdown output'}
        return {'state': self.state.value, 'state_emoji': state_emoji.get(self.state, '❓'), 'state_description': state_desc.get(self.state, 'Unknown'), 'has_live': self._live is not None, 'live_started': self._live.is_started if self._live else False, 'streaming_active': self.state == RenderState.MARKDOWN_STREAMING, 'reasoning_active': self._reasoning_stream is not None, 'content_active': self._content_stream is not None}

    @staticmethod
    def _is_live_state(state: RenderState) -> bool:
        return state in (RenderState.LIVE_TRANSIENT, RenderState.LIVE_NON_TRANSIENT)

    @staticmethod
    def _desired_live_state(transient: bool) -> RenderState:
        return RenderState.LIVE_TRANSIENT if transient else RenderState.LIVE_NON_TRANSIENT

    def _ensure_live_started(self, *, transient: bool) -> None:
        if self._live is None:
            self._live = Live(refresh_per_second=self.cfg.refresh_per_second, console=self.console, transient=transient, auto_refresh=True)
        self._live.transient = transient
        if not self._live.is_started:
            try:
                self._live.start()
            except Exception:
                self._live = None
                self.state = RenderState.OFF

    def _stop_live_if_any(self, *, drop: bool=False) -> None:
        if self._live is not None and self._live.is_started:
            try:
                self._live.stop()
            except Exception:
                pass
        if drop:
            self._live = None

    def _ensure_streaming_mode(self) -> None:
        if self.state != RenderState.MARKDOWN_STREAMING:
            if self._is_live_state(self.state):
                self._stop_live_if_any(drop=True)
            self.state = RenderState.MARKDOWN_STREAMING

    def _finalize_streaming_if_any(self) -> None:
        if self._reasoning_stream is not None:
            for line in self._reasoning_stream.finalize_and_drain():
                self.console.print(line)
        if self._content_stream is not None:
            for line in self._content_stream.finalize_and_drain():
                self.console.print(line)
        self._reasoning_stream = None
        self._content_stream = None
        self._reasoning_started = False
        self._content_started = False

    def _get_stream(self, kind: str) -> IncrementalMarkdownBuffer:
        mode = detect_terminal_background()
        code_theme = resolve_code_theme(self.cfg.code_theme)
        content_paragraph = Style(color='black') if mode == 'light' else Style()
        reasoning_paragraph = Style(color='grey27', dim=True) if mode == 'light' else Style(color='grey70', dim=True)
        if kind == 'reasoning':
            if self._reasoning_stream is None:
                reasoning_cfg = TerminalMarkdownTheme(code_theme=code_theme, paragraph_style=reasoning_paragraph, code_block_style=Style(dim=True), heading_style=Style(bold=True, dim=True), h1_style=Style(bold=True, underline=True, dim=True), h2_style=Style(bold=True, dim=True), h3_style=Style(bold=True, italic=True, dim=True), blockquote_style=Style(color='green', dim=True), bullet_style=Style(dim=True), number_style=Style(color='cyan', dim=True))
                self._reasoning_stream = IncrementalMarkdownBuffer(console=self.console, config=reasoning_cfg)
            return self._reasoning_stream
        if self._content_stream is None:
            content_cfg = TerminalMarkdownTheme(code_theme=code_theme, paragraph_style=content_paragraph)
            self._content_stream = IncrementalMarkdownBuffer(console=self.console, config=content_cfg)
        return self._content_stream
