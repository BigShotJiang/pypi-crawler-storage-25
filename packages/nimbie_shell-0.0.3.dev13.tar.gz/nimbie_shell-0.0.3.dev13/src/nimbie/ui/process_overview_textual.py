from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from rich.markdown import Markdown
from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Footer, Static


@dataclass(frozen=True, slots=True)
class ProcessSnapshot:
    command_id: str
    command: str
    status: str
    runtime: str
    pid: str
    retcode: str | None
    stdout: str
    stderr: str


class ProcessOverviewApp(App[None]):
    CSS = """
    Screen {
        align: center top;
    }

    #process-scroll {
        height: 1fr;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("r", "reload", "Refresh", show=True),
    ]

    def __init__(self, snapshot_provider: Callable[[], list[dict[str, Any]]]) -> None:
        super().__init__()
        self._snapshot_provider = snapshot_provider
        self._snapshots: list[ProcessSnapshot] = []

    def compose(self) -> ComposeResult:
        yield Vertical(VerticalScroll(id="process-scroll"))
        yield Footer()

    def on_mount(self) -> None:
        self._reload_snapshots()

    def action_quit(self) -> None:
        self.exit()

    def action_reload(self) -> None:
        self._reload_snapshots()

    def _reload_snapshots(self) -> None:
        self._snapshots = self._read_snapshots()
        container = self.query_one("#process-scroll", VerticalScroll)
        container.remove_children()
        if not self._snapshots:
            container.mount(Static(Text("[no background processes]", style="dim")))
            return
        for snapshot in self._snapshots:
            container.mount(Static(Markdown(self._render_snapshot(snapshot))))
            container.mount(Static(Text("")))

    def _read_snapshots(self) -> list[ProcessSnapshot]:
        try:
            payloads = self._snapshot_provider()
        except Exception:
            return []
        snapshots: list[ProcessSnapshot] = []
        for payload in payloads:
            snapshots.append(self._coerce_snapshot(payload))
        return snapshots

    @staticmethod
    def _coerce_snapshot(payload: dict[str, Any]) -> ProcessSnapshot:
        return ProcessSnapshot(
            command_id=str(payload.get("id", "-")),
            command=str(payload.get("command", "") or ""),
            status=str(payload.get("status", "running") or "running"),
            runtime=str(payload.get("runtime", "-") or "-"),
            pid=str(payload.get("pid", "-") or "-"),
            retcode=None if payload.get("retcode") is None else str(payload.get("retcode")),
            stdout=str(payload.get("stdout", "") or ""),
            stderr=str(payload.get("stderr", "") or ""),
        )

    @staticmethod
    def _render_snapshot(snapshot: ProcessSnapshot) -> str:
        lines = [
            f"## PGID {snapshot.command_id}",
            f"- command: {snapshot.command or '(empty)'}",
            f"- status: {snapshot.status}",
            f"- runtime: {snapshot.runtime}",
            f"- pid: {snapshot.pid}",
        ]
        if snapshot.retcode is not None:
            lines.append(f"- retcode: {snapshot.retcode}")
        if snapshot.status != "completed":
            return "\n".join(lines)
        stdout = snapshot.stdout or "(empty)"
        stderr = snapshot.stderr or "(empty)"
        return "\n".join(
            [
                *lines,
                "",
                "**STDOUT**",
                "",
                "```",
                stdout,
                "```",
                "",
                "**STDERR**",
                "",
                "```",
                stderr,
                "```",
            ]
        )
