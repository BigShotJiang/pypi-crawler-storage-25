"""Tool to store a summary result for non-interactive runs."""
from __future__ import annotations
from typing import Any, Dict, Optional
from pydantic import BaseModel, ValidationError
from ..tool_runtime import BaseTool, ToolResult, ToolType

class _SetResultArgs(BaseModel):
    result: str

class SetResultTool(BaseTool):
    auto_register = False
    name = 'set_result'
    description = 'Store a summary result for the current round.'

    @property
    def tool_type(self) -> ToolType:
        return ToolType.SYNC

    @property
    def schema(self) -> Dict[str, Any]:
        return self.get_schema()

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        return {'type': 'function', 'function': {'name': cls.name, 'description': cls.description, 'parameters': {'type': 'object', 'properties': {'result': {'type': 'string', 'description': 'Summary result.'}}, 'required': ['result']}}}

    @classmethod
    def validate_arguments(cls, args: Dict[str, Any]) -> Optional[str]:
        try:
            _SetResultArgs.model_validate(args)
        except ValidationError as exc:
            return str(exc)
        return None

    @classmethod
    def get_preview(cls, args: Dict[str, Any]) -> Optional[str]:
        try:
            parsed = _SetResultArgs.model_validate(args)
        except ValidationError:
            return None
        text = parsed.result
        if len(text) > 400:
            text = text[:400] + '...'
        return f'```\n{text}\n```'

    @staticmethod
    def execute(**kwargs) -> Any:
        parsed = _SetResultArgs.model_validate(kwargs)
        return {'result': parsed.result}

    @classmethod
    def get_response_template(cls, item) -> Optional[str]:
        return '# [tool: set_result]\n\n{.content:code-block-json}\n\n'
