from __future__ import annotations

import asyncio
import hashlib
import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Any, Optional

import click

from ..types import ConnectContext, ConnectResult, RemoteIdentity, TransportHandle, UploadedBinary

try:
    import asyncssh
except Exception:
    asyncssh = None


class SSHProvider:
    name = "ssh"

    async def connect(self, target: str, ctx: ConnectContext) -> ConnectResult:
        ctx.emit_debug(f"[connect.ssh] start target={target!r} force_upload={int(bool(ctx.force_upload))}")
        if asyncssh is None:
            raise RuntimeError("asyncssh not available")

        t = (target or "").strip()
        if not t:
            raise ValueError("missing ssh target, usage: /connect-ssh [user@]host[:port]")

        user: Optional[str] = None
        host_port = t
        if "@" in t:
            user, host_port = t.split("@", 1)
            user = user.strip() or None

        host = host_port
        port: Optional[int] = None
        if host_port.count(":") == 1:
            h, p = host_port.rsplit(":", 1)
            if p.isdigit():
                host = h
                port = int(p)
        host = host.strip()
        if not host:
            raise ValueError("invalid ssh target")

        local_bins = ctx.collect_local_candidates()
        if not local_bins:
            raise RuntimeError("flash-stdio-executor not found, install nimbie_flash or build the executor first")

        remote_dir = ".nimbie/flash-stdio-executor"
        ssh_cfg = ctx.ssh_config_path
        connect_kwargs: dict[str, Any] = {}
        if user:
            connect_kwargs["username"] = user
        if port:
            connect_kwargs["port"] = int(port)
        if ssh_cfg and ssh_cfg.exists():
            connect_kwargs["config"] = [ssh_cfg]

        conn = None
        try:
            conn = await asyncssh.connect(host, **connect_kwargs)
        except Exception as first_err:
            try:
                password = await asyncio.to_thread(
                    click.prompt,
                    f"SSH password for {t}",
                    hide_input=True,
                    default="",
                    show_default=False,
                )
                conn = await asyncssh.connect(host, password=password, **connect_kwargs)
            except Exception as second_err:
                raise RuntimeError(f"ssh connect failed: {first_err}; retry failed: {second_err}") from second_err

        if conn is None:
            raise RuntimeError("ssh connect failed")

        selected = None
        remote_identity_user: Optional[str] = None
        remote_identity_host: Optional[str] = None
        remote_home: Optional[str] = None
        remote_login_pwd: Optional[str] = None
        remote_path_snapshot: Optional[str] = None
        remote_env_snapshot: dict[str, str] = {}
        remote_initial_commands: set[str] = set()

        try:
            home_res = await conn.run('printf %s "$HOME"', check=True)
            remote_home = str(getattr(home_res, "stdout", "") or "").strip() or "/tmp"

            login_pwd_probe_cmd = (
                'sh -lc \'s="${SHELL:-/bin/sh}"; '
                '("$s" -l -c "pwd" 2>/dev/null || "$s" -lc "pwd" 2>/dev/null || pwd) | head -n 1\''
            )
            login_pwd_res = await conn.run(login_pwd_probe_cmd, check=False)
            remote_login_pwd = str(getattr(login_pwd_res, "stdout", "") or "").strip()
            if not remote_login_pwd.startswith("/"):
                remote_login_pwd = remote_home

            remote_dir_abs = f"{remote_home}/{remote_dir}"
            await conn.run(f"mkdir -p {shlex.quote(remote_dir_abs)}", check=True)

            identity_probe_cmd = (
                'printf \'__FLASH_USER=%s\\n\' "$USER"; '
                'printf \'__FLASH_HOSTNAME=%s\\n\' "${HOSTNAME:-$(hostname 2>/dev/null)}"'
            )
            identity_probe = await conn.run(identity_probe_cmd, check=False)
            for raw in str(getattr(identity_probe, "stdout", "") or "").splitlines():
                line = raw.strip()
                if line.startswith("__FLASH_USER="):
                    v = line.split("=", 1)[1].strip()
                    if v:
                        remote_identity_user = v
                elif line.startswith("__FLASH_HOSTNAME="):
                    v = line.split("=", 1)[1].strip()
                    if v:
                        remote_identity_host = v

            if not remote_identity_user:
                remote_identity_user = user
            if not remote_identity_user:
                parts = [p for p in remote_home.split("/") if p]
                remote_identity_user = parts[-1] if parts else None
            if not remote_identity_host:
                remote_identity_host = host

            runtime_probe_cmd = (
                "uname -m 2>/dev/null || true; "
                "uname -s 2>/dev/null || true; "
                '(. /etc/os-release >/dev/null 2>&1; printf \'%s\\n\' "$ID") 2>/dev/null || true; '
                "ldd --version 2>&1 | head -n 1 || true"
            )
            runtime_probe = await conn.run(runtime_probe_cmd, check=False)
            runtime_lines = [x.strip().lower() for x in str(getattr(runtime_probe, "stdout", "") or "").splitlines()]
            remote_arch = runtime_lines[0] if len(runtime_lines) >= 1 and runtime_lines[0] else ""
            remote_uname_os = runtime_lines[1] if len(runtime_lines) >= 2 and runtime_lines[1] else ""
            remote_os_id = runtime_lines[2] if len(runtime_lines) >= 3 and runtime_lines[2] else ""
            remote_ldd = runtime_lines[3] if len(runtime_lines) >= 4 and runtime_lines[3] else ""
            remote_os = "openwrt" if "openwrt" in remote_os_id else "linux" if "linux" in remote_uname_os else ""
            remote_libc = "musl" if "musl" in remote_ldd else "glibc" if "glibc" in remote_ldd else ""
            if "darwin" in remote_uname_os:
                remote_os = "darwin"
                remote_libc = "darwin"
            m_glibc = re.search(r"glibc[^0-9]*([0-9]+\.[0-9]+)", remote_ldd, flags=re.IGNORECASE)
            remote_glibc_version = m_glibc.group(1) if m_glibc else ""

            cmd_inventory = (
                'sh -lc \'printf "__PATH=%s\\n" "$PATH"; '
                'IFS=":"; for d in $PATH; do [ -d "$d" ] || continue; '
                'for f in "$d"/*; do [ -f "$f" ] || continue; [ -x "$f" ] || continue; '
                'b=${f##*/}; printf "%s\\n" "$b"; done; done\''
            )
            inv_res = await conn.run(cmd_inventory, check=False)
            for raw in str(getattr(inv_res, "stdout", "") or "").splitlines():
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("__PATH="):
                    v = line.split("=", 1)[1].strip()
                    if v:
                        remote_path_snapshot = v
                    continue
                if "/" not in line:
                    remote_initial_commands.add(line)

            env_res = await conn.run("env", check=False)
            for raw in str(getattr(env_res, "stdout", "") or "").splitlines():
                if "=" not in raw:
                    continue
                k, v = raw.split("=", 1)
                k = k.strip()
                if k:
                    remote_env_snapshot[k] = v
            if remote_home:
                remote_env_snapshot.setdefault("HOME", remote_home)
            if remote_identity_user:
                remote_env_snapshot.setdefault("USER", remote_identity_user)
                remote_env_snapshot.setdefault("LOGNAME", remote_identity_user)
            if remote_identity_host:
                remote_env_snapshot.setdefault("HOSTNAME", remote_identity_host)
            if remote_path_snapshot:
                remote_env_snapshot.setdefault("PATH", remote_path_snapshot)
            if remote_login_pwd:
                remote_env_snapshot["PWD"] = remote_login_pwd

            ranked_bins = ctx.rank_candidates(
                local_bins,
                remote_arch,
                remote_libc,
                remote_os,
                remote_glibc_version,
            )
            probe_req = '{"type":"run.ast","ast":{"Command":{"name":"true","args":[],"redirects":[]}},"cwd":"/tmp","env":{}}'
            attempt_errors: list[str] = []

            for cand in ranked_bins:
                local_bin: Path = cand["path"]
                file_md5 = hashlib.md5(local_bin.read_bytes()).hexdigest()
                remote_bin = f"{remote_dir}/{file_md5}"
                remote_bin_abs = f"{remote_home}/{remote_bin}"
                upload_mode = "cached"
                try:
                    exists = await conn.run(f"test -x {shlex.quote(remote_bin_abs)}", check=False)
                    if ctx.force_upload or int(getattr(exists, "exit_status", 1)) != 0:
                        tmp_remote = f"{remote_bin_abs}.tmp"
                        try:
                            async with conn.start_sftp_client() as sftp:
                                await sftp.put(str(local_bin), tmp_remote)
                            upload_mode = "sftp"
                        except Exception:
                            proc = await conn.create_process(f"cat > {shlex.quote(tmp_remote)}", encoding=None)
                            with open(local_bin, "rb") as f:
                                proc.stdin.write(f.read())
                            proc.stdin.write_eof()
                            await proc.wait()
                            if int(getattr(proc, "exit_status", 1)) != 0:
                                raise RuntimeError("stdin upload failed")
                            upload_mode = "stdin"

                        await conn.run(
                            f"chmod 755 {shlex.quote(tmp_remote)} && mv {shlex.quote(tmp_remote)} {shlex.quote(remote_bin_abs)}",
                            check=True,
                        )

                    probe_cmd = f"printf '%s\\n' {shlex.quote(probe_req)} | {shlex.quote(remote_bin_abs)}"
                    probe = await conn.run(probe_cmd, check=False)
                    probe_stdout = str(getattr(probe, "stdout", "") or "")
                    probe_stderr = str(getattr(probe, "stderr", "") or "")
                    probe_code = int(getattr(probe, "exit_status", 1))
                    if probe_code != 0:
                        msg = (probe_stderr or probe_stdout).strip()
                        attempt_errors.append(f"{local_bin} -> probe failed (exit={probe_code}): {msg or 'unknown error'}")
                        continue
                    if '"exit_code":0' not in probe_stdout:
                        msg = (probe_stdout or probe_stderr).strip()
                        attempt_errors.append(f"{local_bin} -> probe payload invalid: {msg or 'empty'}")
                        continue
                    supports_started = '"type":"started"' in probe_stdout
                    selected = (local_bin, file_md5, remote_bin, remote_bin_abs, upload_mode, supports_started)
                    break
                except Exception as e:
                    attempt_errors.append(f"{local_bin} -> {e}")

            if selected is None:
                detail = "; ".join(attempt_errors) if attempt_errors else "no compatible executor found"
                raise RuntimeError(f"failed to select remote executor: {detail}")
        finally:
            conn.close()
            await conn.wait_closed()

        assert selected is not None
        selected_local_bin, selected_md5, selected_remote_bin, selected_remote_bin_abs, selected_upload_mode, selected_supports_started = selected
        user_prefix = f"{user}@" if user else ""
        port_suffix = f":{port}" if port else ""
        mode_note = "force-upload" if ctx.force_upload else selected_upload_mode
        status_message = (
            f"connected: {user_prefix}{host}{port_suffix}, executor=~/{selected_remote_bin}, "
            f"local={selected_local_bin}, md5={selected_md5}, mode={mode_note}, "
            f"stream_started={(1 if selected_supports_started else 0)}, "
            f"identity_cached={int(bool(remote_identity_user and remote_identity_host))}, "
            f"cmd_cache={len(remote_initial_commands)}"
        )

        transport = TransportHandle(
            bin_name="ssh",
            args=self._build_ssh_exec_args(host, selected_remote_bin_abs, user=user, port=port, ssh_config=ssh_cfg),
            metadata={"kind": "ssh"},
        )
        proc = subprocess.Popen(
            [transport.bin_name, *transport.args],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            bufsize=0,
        )
        if proc.stdin is None or proc.stdout is None:
            proc.kill()
            raise RuntimeError("failed to open ssh transport stdio")
        transport.stdin_fd = os.dup(proc.stdin.fileno())
        transport.stdout_fd = os.dup(proc.stdout.fileno())
        transport.stderr_fd = os.dup(proc.stderr.fileno()) if proc.stderr is not None else None
        transport.pid = int(proc.pid) if proc.pid is not None else None
        transport.metadata = {"kind": "ssh", "process": proc}
        uploaded = UploadedBinary(
            remote_path=selected_remote_bin_abs,
            digest=selected_md5,
            upload_mode=mode_note,
            supports_started_event=bool(selected_supports_started),
            local_path=str(selected_local_bin),
        )
        identity = RemoteIdentity(
            user=remote_identity_user,
            host=remote_identity_host,
            home=remote_home,
            login_pwd=remote_login_pwd,
            path=remote_path_snapshot,
            env=remote_env_snapshot,
        )
        return ConnectResult(
            provider=self.name,
            transport=transport,
            uploaded=uploaded,
            identity=identity,
            command_cache=set(remote_initial_commands),
            ssh_host=host,
            ssh_user=user,
            ssh_port=port,
            ssh_config_path=(str(ssh_cfg) if ssh_cfg and ssh_cfg.exists() else None),
            status_message=status_message,
        )

    async def disconnect(self) -> None:
        return None

    @staticmethod
    def _build_ssh_exec_args(
        host: str,
        remote_executor_path: str,
        *,
        user: Optional[str],
        port: Optional[int],
        ssh_config: Optional[Path],
    ) -> list[str]:
        args: list[str] = [
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "NumberOfPasswordPrompts=0",
            "-o",
            "StrictHostKeyChecking=accept-new",
            "-o",
            "ConnectTimeout=8",
        ]
        if ssh_config and ssh_config.exists():
            args.extend(["-F", str(ssh_config)])
        if port:
            args.extend(["-p", str(int(port))])
        if user:
            args.extend(["-l", user])
        args.append(host)
        args.append(remote_executor_path)
        return args
