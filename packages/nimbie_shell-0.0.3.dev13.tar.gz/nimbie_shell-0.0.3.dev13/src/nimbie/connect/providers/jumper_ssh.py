from __future__ import annotations

import asyncio
import hashlib
import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Optional

from ..types import ConnectContext, ConnectResult, RemoteIdentity, TransportHandle, UploadedBinary


class JumperSSHProvider:
    """
    SSH provider via a jump host.

    `target` format: [user@]host[:port]
    jump host is read from env `NIMBIE_JUMPER_SSH_TARGET`, e.g. `user@jumper.example.com`.
    """

    name = "jumper-ssh"

    async def connect(self, target: str, ctx: ConnectContext) -> ConnectResult:
        jumper_target = (Path.home().joinpath(".nimbie_jumper_target").read_text().strip() if Path.home().joinpath(".nimbie_jumper_target").exists() else "").strip()
        if not jumper_target:
            import os
            jumper_target = str(os.getenv("NIMBIE_JUMPER_SSH_TARGET", "")).strip()
        if not jumper_target:
            raise RuntimeError("missing jump host config: set NIMBIE_JUMPER_SSH_TARGET")

        t = (target or "").strip()
        if not t:
            raise ValueError("missing ssh target, usage: /connect jumper-ssh:[user@]host[:port]")

        user: Optional[str] = None
        host_port = t
        if "@" in t:
            user, host_port = t.split("@", 1)
            user = user.strip() or None
        host = host_port
        port: Optional[int] = None
        if host_port.count(":") == 1:
            h, p = host_port.rsplit(":", 1)
            if p.isdigit():
                host = h
                port = int(p)
        host = host.strip()
        if not host:
            raise ValueError("invalid ssh target")

        remote_target = f"{user}@{host}" if user else host
        local_bins = ctx.collect_local_candidates()
        if not local_bins:
            raise RuntimeError("flash-stdio-executor not found, install nimbie_flash or build the executor first")

        remote_home = (await self._run_remote(remote_target, "printf %s \"$HOME\"", jumper_target, port=port)).strip() or "/tmp"
        remote_dir = ".nimbie/flash-stdio-executor"
        remote_dir_abs = f"{remote_home}/{remote_dir}"
        await self._run_remote(remote_target, f"mkdir -p {shlex.quote(remote_dir_abs)}", jumper_target, port=port)

        runtime_probe = await self._run_remote(
            remote_target,
            "uname -m 2>/dev/null || true; uname -s 2>/dev/null || true; "
            "(. /etc/os-release >/dev/null 2>&1; printf '%s\\n' \"$ID\") 2>/dev/null || true; "
            "ldd --version 2>&1 | head -n 1 || true",
            jumper_target,
            port=port,
        )
        runtime_lines = [x.strip().lower() for x in runtime_probe.splitlines()]
        remote_arch = runtime_lines[0] if len(runtime_lines) >= 1 else ""
        remote_uname_os = runtime_lines[1] if len(runtime_lines) >= 2 else ""
        remote_os_id = runtime_lines[2] if len(runtime_lines) >= 3 else ""
        remote_ldd = runtime_lines[3] if len(runtime_lines) >= 4 else ""
        remote_os = "openwrt" if "openwrt" in remote_os_id else "linux" if "linux" in remote_uname_os else ""
        remote_libc = "musl" if "musl" in remote_ldd else "glibc" if "glibc" in remote_ldd else ""
        m_glibc = re.search(r"glibc[^0-9]*([0-9]+\.[0-9]+)", remote_ldd, flags=re.IGNORECASE)
        remote_glibc_version = m_glibc.group(1) if m_glibc else ""

        ranked_bins = ctx.rank_candidates(local_bins, remote_arch, remote_libc, remote_os, remote_glibc_version)
        probe_req = '{"type":"run.ast","ast":{"Command":{"name":"true","args":[],"redirects":[]}},"cwd":"/tmp","env":{}}'
        selected = None
        errors: list[str] = []
        for cand in ranked_bins:
            local_bin: Path = cand["path"]
            digest = hashlib.md5(local_bin.read_bytes()).hexdigest()
            remote_bin = f"{remote_dir}/{digest}"
            remote_bin_abs = f"{remote_home}/{remote_bin}"
            upload_mode = "cached"
            try:
                rc = await self._run_remote_rc(remote_target, f"test -x {shlex.quote(remote_bin_abs)}", jumper_target, port=port)
                if ctx.force_upload or rc != 0:
                    tmp_remote = f"{remote_bin_abs}.tmp"
                    await self._upload_via_stdin(local_bin, remote_target, tmp_remote, jumper_target, port=port)
                    await self._run_remote(
                        remote_target,
                        f"chmod 755 {shlex.quote(tmp_remote)} && mv {shlex.quote(tmp_remote)} {shlex.quote(remote_bin_abs)}",
                        jumper_target,
                        port=port,
                    )
                    upload_mode = "stdin"
                out = await self._run_remote(
                    remote_target,
                    f"printf '%s\\n' {shlex.quote(probe_req)} | {shlex.quote(remote_bin_abs)}",
                    jumper_target,
                    port=port,
                )
                if '"exit_code":0' not in out:
                    errors.append(f"{local_bin} -> invalid probe output")
                    continue
                supports_started = '"type":"started"' in out
                selected = (local_bin, digest, remote_bin_abs, upload_mode, supports_started, remote_bin)
                break
            except Exception as e:
                errors.append(f"{local_bin} -> {e}")

        if selected is None:
            detail = "; ".join(errors) if errors else "no compatible executor found"
            raise RuntimeError(f"failed to select remote executor via jumper: {detail}")

        local_bin, digest, remote_bin_abs, upload_mode, supports_started, remote_bin = selected
        login_pwd = (await self._run_remote(remote_target, "pwd", jumper_target, port=port)).strip() or remote_home
        identity_user = user
        identity_host = host
        path_snapshot = (await self._run_remote(remote_target, "printf %s \"$PATH\"", jumper_target, port=port)).strip()
        env_blob = await self._run_remote(remote_target, "env", jumper_target, port=port)
        env_map: dict[str, str] = {}
        for line in env_blob.splitlines():
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            if k:
                env_map[k] = v

        transport = TransportHandle(
            bin_name="ssh",
            args=self._build_exec_args(jumper_target, remote_target, remote_bin_abs, port=port),
            metadata={"kind": "jumper-ssh", "jumper_target": jumper_target},
        )
        proc = subprocess.Popen(
            [transport.bin_name, *transport.args],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            bufsize=0,
        )
        if proc.stdin is None or proc.stdout is None:
            proc.kill()
            raise RuntimeError("failed to open jumper ssh transport stdio")
        transport.stdin_fd = os.dup(proc.stdin.fileno())
        transport.stdout_fd = os.dup(proc.stdout.fileno())
        transport.stderr_fd = os.dup(proc.stderr.fileno()) if proc.stderr is not None else None
        transport.pid = int(proc.pid) if proc.pid is not None else None
        transport.metadata = {"kind": "jumper-ssh", "jumper_target": jumper_target, "process": proc}
        uploaded = UploadedBinary(
            remote_path=remote_bin_abs,
            digest=digest,
            upload_mode=upload_mode,
            supports_started_event=supports_started,
            local_path=str(local_bin),
        )
        identity = RemoteIdentity(
            user=identity_user,
            host=identity_host,
            home=remote_home,
            login_pwd=login_pwd,
            path=path_snapshot,
            env=env_map,
        )
        status_message = (
            f"connected via jumper: target={remote_target}, jumper={jumper_target}, "
            f"executor=~/{remote_bin}, local={local_bin}, md5={digest}, mode={upload_mode}"
        )
        return ConnectResult(
            provider=self.name,
            transport=transport,
            uploaded=uploaded,
            identity=identity,
            command_cache=set(),
            ssh_host=host,
            ssh_user=user,
            ssh_port=port,
            ssh_config_path=None,
            status_message=status_message,
        )

    async def disconnect(self) -> None:
        return None

    @staticmethod
    async def _run_remote(target: str, command: str, jumper_target: str, *, port: Optional[int]) -> str:
        cmd = JumperSSHProvider._build_remote_cmd(target, command, jumper_target, port=port)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out_b, err_b = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError((err_b.decode("utf-8", errors="ignore") or out_b.decode("utf-8", errors="ignore")).strip())
        return out_b.decode("utf-8", errors="ignore")

    @staticmethod
    async def _run_remote_rc(target: str, command: str, jumper_target: str, *, port: Optional[int]) -> int:
        cmd = JumperSSHProvider._build_remote_cmd(target, command, jumper_target, port=port)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        return int(proc.returncode or 0)

    @staticmethod
    async def _upload_via_stdin(local_bin: Path, target: str, remote_tmp: str, jumper_target: str, *, port: Optional[int]) -> None:
        cmd = JumperSSHProvider._build_remote_cmd(target, f"cat > {shlex.quote(remote_tmp)}", jumper_target, port=port)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        data = await asyncio.to_thread(local_bin.read_bytes)
        assert proc.stdin is not None
        proc.stdin.write(data)
        await proc.stdin.drain()
        proc.stdin.close()
        out_b, err_b = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(
                (err_b.decode("utf-8", errors="ignore") or out_b.decode("utf-8", errors="ignore") or "stdin upload failed").strip()
            )

    @staticmethod
    def _build_remote_cmd(target: str, command: str, jumper_target: str, *, port: Optional[int]) -> list[str]:
        base = [
            "ssh",
            "-o",
            "StrictHostKeyChecking=accept-new",
            "-J",
            jumper_target,
        ]
        if port:
            base.extend(["-p", str(int(port))])
        base.append(target)
        base.append(command)
        return base

    @staticmethod
    def _build_exec_args(jumper_target: str, target: str, remote_executor_path: str, *, port: Optional[int]) -> list[str]:
        args = [
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "NumberOfPasswordPrompts=0",
            "-o",
            "StrictHostKeyChecking=accept-new",
            "-o",
            "ConnectTimeout=8",
            "-J",
            jumper_target,
        ]
        if port:
            args.extend(["-p", str(int(port))])
        args.append(target)
        args.append(remote_executor_path)
        return args
