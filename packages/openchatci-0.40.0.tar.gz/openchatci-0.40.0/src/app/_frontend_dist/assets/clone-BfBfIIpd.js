import{b as r}from"./_baseUniq-Cajl2BC9.js";var e=4;function a(o){return r(o,e)}export{a as c};
