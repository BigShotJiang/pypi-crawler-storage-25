"""LattifAI Auth - Cross-platform device fingerprinting and HMAC-SHA256 authentication.

Functions:
    get_device_id() -> str
        Returns the SHA-256 device fingerprint (64-char hex).
        Based on hardware ID + architecture + compile-time salt.
        Raises RuntimeError if the device ID cannot be retrieved.

    get_device_name() -> str
        Returns the device hostname, or "unknown-device" on failure.

    get_device_info() -> dict
        Returns {"device_id": str, "device_name": str, "device_id_source": "hardware"}.
        Convenience function combining get_device_id() and get_device_name().

    generate_auth_payload(api_key: str) -> str
        Returns ``{json}.{signature}`` with a unique nonce.
        The nonce enables replay detection when verified server-side.
        Raises ValueError if api_key is empty.

    generate_auth_payload_parts(api_key: str) -> dict
        Returns a dict with keys: payload_json, signature, device_id,
        timestamp, nonce, platform, version.

    obfuscate_key(api_key: str) -> str
        Obfuscate an API key for local storage. This is lightweight
        obfuscation (not encryption) with integrity protection.
        The result is device-bound and tamper-detectable.

    deobfuscate_key(obfuscated: str) -> str
        Recover an API key obfuscated on the same device.
        Raises RuntimeError if the key was tampered with or
        obfuscated on a different device.
"""

from ._lattifai_auth import deobfuscate_key_py as deobfuscate_key
from ._lattifai_auth import generate_auth_payload_parts_py as generate_auth_payload_parts
from ._lattifai_auth import generate_auth_payload_py as generate_auth_payload
from ._lattifai_auth import get_device_id_py as get_device_id
from ._lattifai_auth import get_device_info_py as get_device_info
from ._lattifai_auth import get_device_name_py as get_device_name
from ._lattifai_auth import obfuscate_key_py as obfuscate_key

__all__ = [
    "get_device_id",
    "get_device_name",
    "get_device_info",
    "generate_auth_payload",
    "generate_auth_payload_parts",
    "obfuscate_key",
    "deobfuscate_key",
]
