from typing import TypedDict

class AuthPayloadParts(TypedDict):
    """Structured auth payload with individual fields."""
    payload_json: str
    signature: str
    device_id: str
    timestamp: int
    nonce: str
    platform: str
    version: str

class DeviceInfo(TypedDict):
    """Device identification info for auth flows."""
    device_id: str
    device_name: str
    device_id_source: str

def get_device_id() -> str:
    """Return the SHA-256 device fingerprint (64-char lowercase hex).

    Raises:
        RuntimeError: If the device ID cannot be retrieved.
    """
    ...

def get_device_name() -> str:
    """Return the device hostname, or ``"unknown-device"`` on failure."""
    ...

def get_device_info() -> DeviceInfo:
    """Return device identification info for auth flows.

    Raises:
        RuntimeError: If the device ID cannot be retrieved.
    """
    ...

def generate_auth_payload(api_key: str) -> str:
    """Generate ``{json}.{signature}`` with a unique nonce.

    The nonce enables replay detection when verified server-side.

    Args:
        api_key: The API key used as the HMAC-SHA256 signing secret.

    Raises:
        ValueError: If api_key is empty.
        RuntimeError: If device ID is unavailable.
    """
    ...

def generate_auth_payload_parts(api_key: str) -> AuthPayloadParts:
    """Generate auth payload and return structured parts as a dict.

    Args:
        api_key: The API key used as the HMAC-SHA256 signing secret.

    Raises:
        ValueError: If api_key is empty.
        RuntimeError: If device ID is unavailable.
    """
    ...

def obfuscate_key(api_key: str) -> str:
    """Obfuscate an API key for local storage (not encryption).

    The result is device-bound with integrity protection.
    Tampered or cross-device keys will be detected on deobfuscation.

    Args:
        api_key: The plaintext API key to obfuscate.

    Raises:
        ValueError: If api_key is empty.
    """
    ...

def deobfuscate_key(obfuscated: str) -> str:
    """Recover an API key previously obfuscated on this device.

    Args:
        obfuscated: The obfuscated key string from ``obfuscate_key``.

    Raises:
        RuntimeError: If the key was tampered with or obfuscated
                      on a different device.
        ValueError: If the format is invalid.
    """
    ...
