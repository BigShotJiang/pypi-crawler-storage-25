# Axiom is best coding assistant for you.

**Your terminal, but with AI. Edit files, run commands, chat with AI - all in one session.**

## Install in 30 seconds
```bash
pip install axiomai-cli
axiomai chat
```
OR
```bash
git clone https://github.com/Mustafa-Kayra/axiom.git
cd axiom
# For Windows:
python -m venv .venv
.venv\Scripts\activate.bat
# For Linux: (bash)
python3 -m venv .venv
source .venv/bin/activate
pip install requirements.txt
pip install -e .
axiomai chat
```

## What it does

```bash
$ axiomai chat
> fix the bug in server.py
✓ Fixed undefined variable on line 42

> vim server.py
[opens real vim, returns to chat after]

> refactor: make it async
✓ Updated server.py with async/await

> pytest
✗ Tests fail

> restore
✓ Reverted last changes

```

**No copy-pasting. No context switching. AI edits your files directly.**

## Why developers love it

- **Zero config** - Automatically reads your project files (respects .gitignore)
- **Instant undo** - `restore` command reverts any AI changes immediately  
- **Real shell** - Run `git`, `pytest`, even `vim` without leaving the chat
- **100% local backups** - Your code is safe, changes stored in `.aye/`
- **No prefixes** - Just type. Commands run, everything else goes to AI

#### Instant undo with Axiom's `Restore`
Axiom's `restore` command provides an instant and reliable safety net for any changes made by the AI. Developers can forge ahead and experiment knowing that application restore is just one simple command away.  

**Restore offers fine-grained control:**
- `restore <ordinal>`:  Lets users revert to a specific historical snapshot (e.g., `001`). This is useful for stepping back through multiple AI interactions.
- `restore <ordinal> <file>`:  Allows restoring a *specific file* from a particular snapshot. This is incredibly powerful for selectively reverting changes without affecting other files that might have been correctly updated.

**Restore works best when used alongside other commands:**
- `history`: to view available snapshots
- `diff`: to compare current files with previous versions

These commands provide a comprehensive system for reviewing, managing, and reverting code changes, keeping you in control. 

## Quick examples

```bash
# In your project directory:
axiomai chat

> refactor this to use dependency injection
> pytest
> fix what broke  
> git commit -m "refactored DI"
```

## Get started

1. **Install**: `pip install axiomai-cli`
2. **Start chatting**: `axiomai chat` in any project folder




### Starting a Session

```bash
axiomai chat                          # Start chat with auto-detected files
axiomai chat --root ./src             # Specify a different project root
axiomai chat --include "*.js,*.css"   # Manually specify which files to include
```

### In-Chat Commands

Your input is handled in this order:
1. **Built-in Commands** (like `restore` or `model`)
2. **Shell Commands** (like `ls -la` or `git status`)
3. **AI Prompt** (everything else)

**Session & Model Control**
- `new` - Start a fresh chat session
- `model` - Select a different AI model
- `verbose [on|off]` - Toggle verbose output on or off
- `exit`, `quit`, `Ctrl+D` - Exit the chat
- `help` - Show available commands

**Reviewing & Undoing AI Changes**
- `restore`, `undo` - Instantly undo the last set of changes made by AI
- `history` - Show the history of changes made by AI
- `diff <file>` - Compare current version against last change

**Shell Commands**
- Run any command: `ls -la`, `git status`, `docker ps`
- Interactive programs work: `vim`, `nano`, `less`, `top`

</details>

<details>
<summary>⚙️ Configuration & Privacy</summary>

## Configuration

- Axiom respects `.gitignore` and `.ayeignore` - private files are never touched
- Change history and backups stored locally in `.aye/` folder
- Configure default model and preferences in `~/.ayecfg`

## Privacy & Security

- All file backups are local only
- API calls only include files you explicitly work with
- No telemetry or usage tracking
- Open source - audit the code yourself

</details>

<details>
<summary>🤖 AGENTS.md (repo instructions)</summary>

## AGENTS.md inclusion

Axiom can automatically include **`AGENTS.md`** as extra *system context* for a repo — perfect for team conventions, architecture notes, and "how we do things here".

**Discovery (first match wins):**
- `./.aye/AGENTS.md` (highest precedence)
- then walking up from the current directory: `.aye/AGENTS.md` or `AGENTS.md`

Tip: keep it short and actionable — it’s treated as instructions for the assistant. 

See more details on https://agents.md/

</details>

<details>
<summary>🧩 Plugins & Extensions</summary>

## Extensible via Plugins

The core experience is enhanced by plugins:
- Shell execution plugin
- Autocompletion plugin  
- Custom command plugins
- Model provider plugins

</details>
                                                                                                                                                             
<details>
<summary>🐧 NixOS/Nix Installation</summary>

```bash
# Run directly without installing
nix run github:Mustafa-Kayra/Axiom

# Or install to your profile
nix profile install github:Mustafa-Kayra/Axiom
```

</details>

## Contributing

Axiom is open source! We welcome contributions.

- **Report bugs**: [GitHub Issues](https://github.com/acrotron/aye-chat/issues)
- **Submit PRs**: Fork and contribute
- **Get help**: [Discord Community](https://discord.gg/ZexraQYH77)

## License

MIT License - see [LICENSE](LICENSE) file

## Disclaimer

review the [DISCLAIMER](DISCLAIMER) before using this software.

---

**Ready to code with AI without leaving your terminal?**

```bash
pip install ayechat && Axiom
```

[Wiki](https://github.com/acrotron/aye-chat/wiki) • [Discord](https://discord.gg/ZexraQYH77) • [GitHub](https://github.com/acrotron/aye-chat)
