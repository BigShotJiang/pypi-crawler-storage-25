"""Local-first terminal-agent orchestration MVP."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.14.0"

