# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.12.8] - 2026-04-30

### Added
- 多核服务器性能优化：`TCPServer` 替换为 `ThreadingTCPServer` 多线程模式，默认工作线程数 = CPU 核数 x 2，支持 `-w`/`--workers` CLI 参数、`PYFILESERV_WORKERS` 环境变量和 YAML 配置

## [0.12.7] - 2026-04-30

### Fixed
- 修复 Linux 下 Excel/PPT 预览报错 "Cannot found font installed on the system." 时仅显示"解析失败"的问题，现返回包含字体安装指引的友好错误页面（Debian/Ubuntu/CentOS 各发行版命令）

## [0.12.6] - 2026-04-29

### Added
- 静态资源强缓存：新增 ETag（基于 mtime_ns + file_size）和 `If-None-Match` 条件请求支持，`Cache-Control` 升级为 `max-age=31536000, immutable`，重复访问 304 零传输
- HTTP Range 请求支持：`_handle_download` 支持 `Range: bytes=...` 头和 206 Partial Content 响应，浏览器可 seek 音频/视频而不需下载完整文件
- MIME 类型自动推断：下载处理器使用 `mimetypes.guess_type()` 替代写死的 `application/octet-stream`，Range 请求时使用 `inline` 而非 `attachment` disposition
- 音频/视频懒加载：进入预览页不再自动下载媒体文件，改为显示占位符 + "▶ 播放" 按钮，点击后才加载
- 日志文件支持：新增 `--log-file` CLI 参数和 `PYFILESERV_LOG_FILE` 环境变量，默认写入 `serve_dir/pyfileserv.log`
- `ServerConfig` 新增 `log_file` 配置字段，支持 YAML 配置文件和相对路径解析

### Changed
- 音频模板 MIME 类型根据文件扩展名动态推断（mp3/wav/ogg/flac/aac/m4a/wma/opus）
- 视频模板 MIME 类型根据文件扩展名动态推断（mp4/webm/avi/mov/mkv/ogv/flv/wmv）

## [0.12.5] - 2026-04-29

### Added
- Draw.io (.drawio) 文件预览支持：基于 viewer.diagrams.net iframe 渲染，多标签页切换 + 源码双视图
- Edraw Max (.eddx) 文件预览支持：SVG 矢量图渲染（矩形/菱形/胶囊形/文档形/Document 六种形状），CPoint 连接点精确定位，多行文本左对齐，图表/源码双视图，缩放控制（放大/缩小/适应）
- Markdown 预览支持 Mermaid 图表渲染（流程图、时序图等）：服务端正则预处理提取 mermaid 代码块，避免 codehilite 错误高亮
- 新增 `template/preview/drawio.py` 和 `template/preview/eddx.py` 预览模板

### Changed
- 重构 `do_GET()` 路由分发：增加 try/except 异常保护，提高服务器稳健性
- `utils.py` 新增 `DRAWIO_EXTENSIONS`、`EDDX_EXTENSIONS`，更新 `detect_file_type` 和 `PREVIEWABLE_EXTENSIONS`
- `template/file_list.py` 文件类型筛选新增 `.drawio` 和 `.eddx` 扩展名

### Testing
- 新增 42 个 EDDX 转换器 + DrawIO/Eddx 分发单元测试（测试总数：536+，17 个跳过）

## [0.12.4] - 2026-04-29

### Fixed
- 修复 Word 文档预览图片不显示的问题：所有图片（PNG/JPEG/GIF 等）嵌入为 base64 data URI，EMF/WMF 元文件通过 Pillow 自动转换为 PNG

### Added
- 新增 `pillow>=10.4.0` 为核心依赖，用于 Word 文档图片处理与 EMF/WMF 格式转换
- 新增 `_docx_image_converter()` Mammoth 图片转换器，`_emf_to_png_datauri()` EMF 转换函数，`_placeholder_svg()` SVG 占位图生成函数

## [0.12.3] - 2026-04-29

### Changed
- **Word 文档预览**由 `python-docx` 替换为 `mammoth`，支持图片、列表、链接、表格、标题等完整格式渲染
- **Excel 表格预览**由 `openpyxl` 替换为 `Spire.Xls.Free`，完整渲染表格样式、颜色和格式
- **PowerPoint 演示文稿预览**由 `python-pptx` 替换为 `Spire.Presentation.Free`，使用 iframe + srcdoc 幻灯片导航浏览
- Excel 表格内容区（`.sheet-content`）固定浅色模式，避免深色背景下有色单元格不可读
- Excel 表格悬停高亮由整行改为仅当前单元格（`td:hover`）
- PPT 预览从卡片式纯文本改为 iframe 嵌入完整幻灯片渲染

### Fixed
- 修复登录认证失败时错误消息被通用消息覆盖的 bug（`else` 分支缺少 `return`）
- 修复 PPT 预览幻灯片内容显示 "undefined"（Spire `Stream.ToArray()` Python.NET 转换兼容性问题，改用临时文件）
- 修复 Excel 预览 CSS 偶数行背景色规则覆盖 Spire 生成的单元格格式

### Added
- 新增 `jinja2>=3.1.6` 为核心依赖

### Testing
- 新增 ~42 个测试用例：`Authenticator`（完整认证流程）、`AuthMixin`（login/logout 14 个场景）、`Session` 序列化、`PasswordHasher`/`UserStore`/`SessionManager`/`LoginAttemptTracker` 边界情况、`_is_safe_path`/`_sanitize_filename`/`_resolve_safe_path` 安全函数测试、`_parse_multipart` 边界路径

## [0.12.1] - 2026-04-29

### Removed
- 移除 `base.py` 中 6 个已外置的冗余 CSS 常量（`CSS_COMMON`、`CSS_FORM_INPUTS`、`CSS_BUTTON_PRIMARY`、`CSS_ERROR`、`CSS_TOAST`、`CSS_MODAL`）
- 移除 `FAVICON_SVG` 内嵌 SVG 常量（所有模板已改用 `/static/favicon.svg`）
- 删除已弃用的 `templates.py` 兼容垫片

### Changed
- 更新项目结构文档，反映 `core/`、`handle/`、`template/` 子包架构
- `base.py` 从 348 行精简至约 130 行（-62%）

## [0.12.0] - 2026-04-29

### Added
- CSS/JS 外置：23 个模板文件的样式和脚本提取至 `static/css/`（7 个文件）和 `static/js/`（5 个文件）
- 新增 `static/favicon.svg` 和 `static/logo.svg`
- 新增 `css_links()` 和 `js_scripts()` 辅助函数，集中管理静态资源引用
- 文件类型筛选支持全部 12 种可预览类型（图片/音频/视频/PDF/文本/Markdown/XMind/JSON/Word/Excel/PowerPoint/其他）

### Changed
- 代码重构：`handle/`、`template/`、`core/` 子包拆分，模块职责更清晰
- 模板渲染函数签名从 4 个独立列表改为 `files_by_type` 字典
- `file_list.py` 筛选下拉框由 `files_by_type` 动态生成

### Fixed
- 修复 Markdown 复选框正则表达式（raw string 中多余反斜杠）
- 修复 Office 文档预览显示 `\n` 字面字符（`'\\n'` 改为 `'\n'`）
- 修复深色模式页面切换闪现浅色主题（FIT）：`css_links()` 注入阻塞内联脚本
- 修复 HTML 预览 iframe sandbox 阻止脚本执行导致空白页面
- 修复类型筛选时文件夹数量、文件数量、总大小未同步更新

### Testing
- 迁移 431 个测试用例，适配新模块路径和函数签名

## [0.11.0] - 2026-04-28

### Added
- Word (.docx) 文档预览：提取段落和表格，支持标题、粗体、斜体、下划线等格式渲染
- Excel (.xlsx) 表格预览：支持多工作表标签切换，最多显示 200 行
- PowerPoint (.pptx) 演示文稿预览：卡片式幻灯片内容展示
- 新增 `office` 可选依赖组：`pip install pyfileserv[office]`
- `full` 安装组包含 Office 预览依赖（python-docx、openpyxl、python-pptx）
- 未安装依赖库时显示友好的安装提示

### Changed
- `PREVIEWABLE_EXTENSIONS` 扩展为包含 .docx/.xlsx/.pptx
- `detect_file_type()` 新增 'docx'/'xlsx'/'pptx' 类型识别

## [0.10.0] - 2026-04-28

### Added
- 文件分享功能：支持创建带密码、过期时间、下载次数限制的分享链接
- 分享管理页面（/shares）：状态分类展示（活跃/过期/已删除），支持修改过期时间、复制链接
- 分享 API：`POST /api/share/create`、`/api/share/update/{id}`、`/api/share/permanent-delete/{id}`
- 分享存储双后端：JSON 文件存储（`ShareStore`）和 PostgreSQL 数据库存储（`DatabaseShareStore`）
- 分享密码使用 bcrypt 哈希加密存储，自动迁移旧明文密码
- 软删除机制：删除分享后管理页面仍可查看，支持永久删除
- 过期分享保留显示，支持管理和删除
- Markdown 预览页面新增一键导出 PDF 按钮
- 用户管理页面新增深色模式切换支持

### Changed
- ShareManager 重构为业务逻辑层，委托 ShareStore/DatabaseShareStore 处理持久化
- `share.json` 存储位置从 config_dir 移至 serve_dir
- 分享删除行为从硬删除改为软删除

### Fixed
- 修复 Markdown 任务列表（`- [ ]`/`- [x]`）无法正确渲染的问题
- 修复 Markdown 预览 checkbox 样式在 PDF 导出时不一致的问题
- 修复分享访问页面密码输入框缺失问题（`has_password` 字段适配）
- 修复 add_user() 方法签名变更导致的测试失败

### Testing
- 新增 test_share_store.py：ShareStore 单元测试（25个用例）
- 新增 test_share.py：ShareManager 业务逻辑测试（25个用例）
- 新增 test_share_db.py：DatabaseShareStore 单元测试（15个用例，需 PostgreSQL）

## [0.9.7] - 2026-04-28

### Added
- 管理员权限控制系统：基于 `is_admin` 字段的角色管理
- UserStore 和 DatabaseUserStore 支持管理员状态管理
- 只有管理员用户才能访问 `/admin` 用户管理页面
- 管理员可以创建、删除用户，修改密码，设置其他用户的管理员状态
- CLI 新增 `user admin` 命令用于设置/取消用户管理员身份
- CLI `user create` 命令支持创建时指定管理员身份
- CLI `user list` 命令显示用户管理员标记 `[管理员]`
- 前端根据用户权限动态显示/隐藏“⚙️ 用户管理”入口
- 所有管理员 API 端点增加严格的权限验证（返回 403 Forbidden）
- 非管理员尝试访问管理功能时记录警告日志
- 完整的单元测试覆盖（84个测试用例）

### Changed
- UserStore.add_user() 新增 `is_admin` 参数（默认 False）
- UserStore 新增 `is_admin()` 和 `set_admin_status()` 方法
- DatabaseUserStore 对应方法同步更新
- PostgreSQL users 表添加 `is_admin BOOLEAN DEFAULT FALSE` 列
- AdminHandler 所有处理方法增加管理员权限检查
- render_file_list_page() 新增 `is_admin` 参数控制管理入口显示

### Security
- 前后端双重权限验证，防止越权访问
- 所有管理员操作需要显式的管理员身份
- 详细的审计日志记录非管理员的非法访问尝试

### Testing
- 新增 test_admin_auth.py：UserStore 管理员功能测试（15个用例）
- 新增 test_admin_db.py：DatabaseUserStore 管理员功能测试（13个用例）
- 新增 test_admin_handlers.py：AdminHandler 权限控制测试（20个用例）
- 新增 test_admin_cli.py：CLI 管理员命令测试（19个用例）
- 新增 test_admin_templates.py：模板渲染权限控制测试（17个用例）
- 新增 quick_test_admin.py：快速验证脚本
- 新增 ADMIN_TESTS_README.md：详细测试文档

### Fixed
- 向后兼容旧用户数据（缺少 is_admin 字段时默认为 False）

## [0.9.6] - 2026-04-27

### Fixed
- 修复重命名、复制、移动操作报错"源文件不存在"的问题
- 修复文件列表路径构造错误（根目录时路径带前导斜杠）
- 修复文件操作按钮使用 URL 编码路径导致后端无法匹配文件
- 重命名、复制、移动处理器添加路径标准化（与删除处理器一致）

## [0.9.5] - 2026-04-27

### Fixed
- 删除文件报错


## [0.9.4] - 2026-04-27

### Added
-  添加命令行工具支持查看版本

### Fixed
- psycopg2安装报错


## [0.9.3] - 2026-04-27

### Added
- 实现连续登录失败账号锁定机制

## [0.9.2] - 2026-04-24

### Added
- Redis 会话存储支持，可配置会话存储方式（内存或 Redis）
- `SessionStorage` 抽象接口，支持扩展不同的存储后端
- `MemorySessionStorage` - 默认内存存储实现
- `RedisSessionStorage` - Redis 存储实现，支持多实例共享会话
- `RedisConfig` 配置类，支持完整的 Redis 连接配置
- 会话存储配置选项：`session.storage` (memory/redis)
- Redis 配置项：host, port, db, password, key_prefix
- 环境变量支持：`PYFILESERV_SESSION_STORAGE`, `PYFILESERV_REDIS_*`

### Changed
- `SessionManager` 现在接受可选的 `storage` 参数
- `Session` 数据类新增 `to_dict()` 和 `from_dict()` 方法用于序列化
- Redis 从必需依赖移至可选依赖
- 更新 `pyproject.toml` 添加 `redis` 可选依赖组

### Fixed
- Redis 连接失败时自动回退到内存存储，避免服务中断

### Security
- Redis 支持密码保护
- 可配置键前缀避免与其他应用冲突
- 建议使用专用 Redis 数据库编号

## [0.9.1] - 2026-04-24

### Added
- PDF 预览功能：支持 PDF 文件在线预览，内嵌浏览器查看器
- 所有预览页面完全支持深色/浅色主题切换（代码、HTML、Markdown、JSON）

### Changed
- 优化上传页面布局："返回文件列表"按钮移至表单底部与"上传文件"按钮并列
- 优化文件列表搜索框布局：采用双行设计（搜索筛选行 + 操作按钮行）
- 改进预览页面视觉体验：添加主题适配的边框和背景色

### Fixed
- 修复 PDF 预览页面变量未正确渲染的问题
- 修复 PDF 预览时自动下载的问题（改为内嵌显示）
- 修复预览页面部分区域不支持主题切换的问题

## [0.9.0] - 2026-04-24

### Added
- 图片预览功能：支持 JPG、PNG、GIF、WebP、SVG 等格式在线预览
- 音频预览功能：支持 MP3、WAV、OGG、FLAC 等格式在线播放
- 视频预览功能：支持 MP4、WebM、AVI、MOV、MKV 等格式在线播放
- 文本/代码预览功能：支持多种编程语言语法高亮显示
- Markdown 预览功能：实时渲染 MD 文件，支持代码块高亮
- HTML 预览功能：沙箱 iframe 渲染，支持效果/源码双视图
- XMind 预览功能：树形结构展示思维导图，支持节点展开/折叠
- JSON 预览功能：格式化显示，支持效果/源码双视图
- 所有预览页面均支持深色/浅色主题切换
- 媒体文件支持同目录下多个文件的导航（上一首/下一首）
- 预览页面支持下载原始文件
- 文件列表根据文件类型动态显示"点击查看"或"点击下载"

### Changed
- 优化文件分类浏览体验
- 改进预览页面的用户界面和交互

## [0.8.1] - 2026-04-23

### Fixed
- 文件删除功能：可删除文件和目录
- 文件重命名功能：可重命名文件和目录
- 文件移动功能：可移动文件到其他目录
- 文件复制功能：可复制文件和目录
- 创建目录功能：可在任意位置创建新目录

## [0.8.0] - 2026-04-22

### Added
- 文件删除功能：可删除文件和目录
- 文件重命名功能：可重命名文件和目录
- 文件移动功能：可移动文件到其他目录
- 文件复制功能：可复制文件和目录
- 创建目录功能：可在任意位置创建新目录
- 文件操作 API 接口：`/api/delete/`, `/api/rename`, `/api/move`, `/api/copy`, `/api/mkdir`, `/api/directories`
- 所有文件操作均有完整的安全验证和日志记录

### Fixed
- 文件操作 API 路径安全验证：使用 _resolve_safe_path 防止路径遍历攻击
- 文件名清理：使用 _sanitize_filename 清理危险字符

## [0.7.1] - 2026-04-22

### Fixed
- 修复 SSL 证书路径在工作目录切换后的解析问题
- 改进 SSL 证书文件检查和错误提示
- YAML 配置文件中的相对路径现在相对于配置文件目录解析

## [0.7.0] - 2026-04-22

### Added
- PostgreSQL 数据库支持，可选择使用数据库存储用户信息
- YAML 配置文件支持，所有配置项可持久化
- 环境变量配置支持
- `config init` 命令生成默认配置文件
- `cert generate` 命令生成自签名 SSL 证书
- 配置优先级：CLI 参数 > 配置文件 > 环境变量 > 默认值
- 数据库连接池配置
- 添加 `--config-file` 和 `--config-dir` 全局参数
- 数据库用户存储 (DatabaseUserStore)
- 自动创建数据库表结构
- 单元测试覆盖配置模块
- 单元测试覆盖数据库模块
- 单元测试覆盖 CLI 命令

### Changed
- `_from_env()` 重命名为 `load_from_env()`，现在直接修改当前对象
- SSL 配置使用新的 SSLContext API，支持 Python 3.12+
- 移除 cli.py 中的 emoji 表情，避免 Windows 控制台编码问题
- 子命令缺少参数时给出友好提示
- 用户管理命令支持数据库后端

### Fixed
- 修复 CLI 参数解析问题，子命令可以正确使用全局配置参数
- 修复 ssl.wrap_socket 在 Python 3.12+ 中已移除的问题
- 修复证书生成时 ipaddress 导入问题
- 修复配置加载时的优先级问题

### Security
- 数据库密码配置存储在配置文件中

## [0.6.3] - 2026-04-20

### Fixed
- 修复 JSON 详情页面复制内容报错的问题
- 对 JSON 内容进行 HTML 转义防止 XSS 和显示错误
- 使用 data-raw-json 属性存储原始 JSON 确保复制正确性
- 添加复制降级方案使用 execCommand 作为兼容备份

## [0.6.2] - 2026-04-20

### Fixed
- 修复多级子目录导航路径问题（路径缺少前导斜杠导致相对路径解析错误）
- 优化 quote_path 函数，新增 leading_slash 参数区分页面链接和下载链接

## [0.6.1] - 2026-04-20

### Fixed
- 面包屑样式添加 max-width: 1200px 居中显示
- 修复二级子目录访问 404 问题（路径编码错误导致斜杠被转义）

## [0.6.0] - 2026-04-20

### Added
- 多级目录浏览支持，可进入子目录
- 面包屑导航显示当前路径
- 文件修改时间显示
- 按时间排序功能
- 目录列表独立显示
- 搜索功能同时支持目录和文件
- 日志中记录访问路径

### Changed
- 文件排序现在支持 name/size/time 三种方式
- 文件列表数据结构增加 mtime 字段
- 子目录中的文件下载/查看路径正确处理

### Fixed
- 子目录文件下载路径问题
- 子目录 JSON 文件查看路径问题

## [0.5.3] - 2026-04-17

### Refactor
- 优化导入顺序

## [0.5.2] - 2026-04-17

### Fixed
- Fixed bug

## [0.5.1] - 2026-04-17

### Fixed
- Fixed bug 

## [0.5.0] - 2026-04-17

### Added
- File categories now split into 4 sections: HTML, XMind, JSON, and Others
- JSON file viewer with syntax highlighting
- Copy JSON content to clipboard functionality
- Download JSON file from viewer page
- JSON to XMind conversion (uses `project.name` from JSON as XMind filename)
- XMind files shown in dedicated section with distinct styling

### Changed
- File list page reorganized with 4 category sections
- Each file type has distinct color styling

## [0.4.4] - 2026-04-17

### Security
- Removed server path disclosure from page title and footer
- Page title now shows "文件列表" instead of full filesystem path
- Removed "当前路径" display from file list page

## [0.4.3] - 2026-04-17

### Changed
- **Python version support**: Now supports Python 3.6+ (previously required 3.13+)
- Added `dataclasses` backport dependency for Python 3.6 compatibility
- Relaxed bcrypt version requirement to `>=4.0.0`

## [0.4.2] - 2026-04-17

### Fixed
- File upload not working due to JavaScript removing file input element before submission

## [0.4.0] - 2026-04-17

### Added
- File upload functionality with multipart/form-data parsing
- Drag-and-drop file upload support
- Multiple file selection and upload
- Automatic filename conflict resolution (adds sequence number)
- Upload entry button in file list page header
- File size limit (100MB max)
- Filename sanitization to prevent path traversal attacks

### Security
- Filename sanitization removes dangerous characters and path components
- File upload path validation prevents directory traversal
- File size limit prevents DoS via large uploads

## [0.3.0] - 2026-04-16

### Added
- Logo and favicon SVG icons for branding
- File search/filter functionality in file list page
- File sorting by name or size
- File count and total size display
- Responsive toolbar with search and sort controls
- Unit tests for path security validation

### Changed
- Improved LAN IP detection for Windows (more reliable UDP socket method)
- Extracted common CSS styles to reduce code duplication
- Extracted password validation to shared function in CLI

### Fixed
- **Security**: Path traversal vulnerability in file download
  - Added `_is_safe_path()` function to validate file paths
  - Prevents `../` attacks from accessing files outside serve directory
- **Security**: User data file now sets restrictive permissions (0o600)
  - Prevents other users from reading password hashes

### Security
- Path traversal attack prevention in file download endpoint
- Restrictive file permissions on user data storage

## [0.2.0] - 2024-01-01

### Added
- User authentication system with bcrypt password hashing
- Session management with cookie-based sessions
- File browsing with HTML/other file separation
- File download support
- User management CLI (create, list, delete, passwd)
- Configurable port, directory, and session timeout

## [0.1.0] - 2024-01-01

### Added
- Initial release

[0.12.8]: https://github.com/yzutyc/pyfileserv/compare/v0.12.7...v0.12.8
[0.12.7]: https://github.com/yzutyc/pyfileserv/compare/v0.12.6...v0.12.7
[0.12.6]: https://github.com/yzutyc/pyfileserv/compare/v0.12.5...v0.12.6
[0.12.5]: https://github.com/yzutyc/pyfileserv/compare/v0.12.4...v0.12.5
[0.12.4]: https://github.com/yzutyc/pyfileserv/compare/v0.12.3...v0.12.4
[0.12.3]: https://github.com/yzutyc/pyfileserv/compare/v0.12.1...v0.12.3
[0.12.1]: https://github.com/yzutyc/pyfileserv/compare/v0.12.0...v0.12.1
[0.12.0]: https://github.com/yzutyc/pyfileserv/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/yzutyc/pyfileserv/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/yzutyc/pyfileserv/compare/v0.9.7...v0.10.0
[0.9.7]: https://github.com/yzutyc/pyfileserv/compare/v0.9.6...v0.9.7
[0.9.6]: https://github.com/yzutyc/pyfileserv/compare/v0.9.5...v0.9.6
[0.9.5]: https://github.com/yzutyc/pyfileserv/compare/v0.9.4...v0.9.5
[0.9.2]: https://github.com/yzutyc/pyfileserv/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/yzutyc/pyfileserv/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/yzutyc/pyfileserv/compare/v0.8.1...v0.9.0
[0.7.0]: https://github.com/yzutyc/pyfileserv/compare/v0.6.3...v0.7.0
[0.6.3]: https://github.com/yzutyc/pyfileserv/compare/v0.6.2...v0.6.3
[0.6.2]: https://github.com/yzutyc/pyfileserv/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/yzutyc/pyfileserv/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/yzutyc/pyfileserv/compare/v0.5.3...v0.6.0
[0.5.3]: https://github.com/yzutyc/pyfileserv/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.2
[0.5.1]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.1
[0.5.0]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.0
[0.4.4]: https://github.com/yzutyc/pyfileserv/compare/v0.4.3...v0.4.4
[0.4.3]: https://github.com/yzutyc/pyfileserv/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/yzutyc/pyfileserv/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/yzutyc/pyfileserv/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/yzutyc/pyfileserv/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/yzutyc/pyfileserv/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/yzutyc/pyfileserv/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/yzutyc/pyfileserv/releases/tag/v0.1.0
