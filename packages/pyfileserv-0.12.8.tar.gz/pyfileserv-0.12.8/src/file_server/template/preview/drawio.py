"""drawio preview template"""
import json
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_drawio_preview_page(username: str, file_path: str, file_name: str,
                               raw_xml: str, diagrams: list, is_admin: bool = False) -> str:
    """渲染 draw.io 预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        raw_xml: 原始 XML 内容（用于源码视图）
        diagrams: [{'name': str, 'xml': str}] 每个图表的 mxGraph XML
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # JSON-encode diagram data for JavaScript
    diagrams_json = json.dumps(diagrams, ensure_ascii=False)

    # Build source view
    escaped_xml = _escape_html(raw_xml)
    lines = raw_xml.split('\n')
    line_numbers = '\n'.join(str(i + 1) for i in range(len(lines)))

    # Generate diagram tabs
    tab_buttons = ''
    tab_panes = ''
    for i, d in enumerate(diagrams):
        active = 'active' if i == 0 else ''
        safe_name = _escape_html(d['name'] or f'Page-{i+1}')
        tab_buttons += f'<button class="tab-btn {active}" onclick="switchDiagram({i}, this)">{safe_name}</button>\n'
        tab_panes += f'<div class="tab-pane {active}" id="diagramPane{i}"><div class="diagram-frame"><iframe id="viewer{i}" class="viewer-iframe" sandbox="allow-scripts allow-same-origin" loading="lazy"></iframe></div></div>\n'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - Draw.io 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
            word-wrap: break-word;
            word-break: break-all;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .tab-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex;
            gap: 0;
            flex-wrap: wrap;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .tab-btn {{
            padding: 12px 25px;
            background: transparent;
            color: var(--text-secondary);
            border: none;
            border-bottom: 3px solid transparent;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .tab-btn.active {{
            color: #667eea;
            border-bottom-color: #667eea;
        }}
        .tab-btn:hover {{
            color: var(--text-primary);
        }}
        .tab-content {{
            background: var(--bg-secondary);
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }}
        .tab-pane {{
            display: none;
        }}
        .tab-pane.active {{
            display: block;
        }}
        .diagram-frame {{
            width: 100%;
            height: 75vh;
            background: #ffffff;
        }}
        .viewer-iframe {{
            width: 100%;
            height: 100%;
            border: none;
        }}
        .source-body {{
            display: flex;
            overflow: auto;
            max-height: 75vh;
            background: #1e1e1e;
        }}
        .line-numbers {{
            padding: 15px 12px;
            background: #1e1e1e;
            color: #636d83;
            text-align: right;
            user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            border-right: 1px solid #333;
            min-width: 50px;
            white-space: pre;
        }}
        .source-content {{
            padding: 15px 20px;
            flex: 1;
            overflow: visible;
            background: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>Draw.io 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📐 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>
            {f'<a href="/admin" class="btn btn-primary" target="_blank">⚙️ 管理</a>' if is_admin else ''}
        </div>

        <div class="tab-bar" id="diagramTabs">
            {tab_buttons}
            <button class="tab-btn" id="sourceTabBtn" onclick="switchTabSource(event)">源码</button>
        </div>
        <div class="tab-content">
            {tab_panes}
            <div class="tab-pane" id="sourcePane">
                <div class="source-body">
                    <div class="line-numbers">{line_numbers}</div>
                    <div class="source-content" id="sourceContent">{escaped_xml}</div>
                </div>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        var diagramData = {diagrams_json};

        function switchDiagram(index, btnEl) {{
            document.querySelectorAll('#diagramTabs .tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btnEl.classList.add('active');
            var pane = document.getElementById('diagramPane' + index);
            if (pane) pane.classList.add('active');
            loadDiagram(index);
        }}

        function switchTabSource(evt) {{
            document.querySelectorAll('#diagramTabs .tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            evt.target.classList.add('active');
            document.getElementById('sourcePane').classList.add('active');
        }}

        function loadDiagram(index) {{
            var iframe = document.getElementById('viewer' + index);
            if (!iframe || iframe.dataset.loaded) return;
            var xml = diagramData[index].xml;
            if (!xml) return;
            // 使用 viewer.diagrams.net 渲染（需要网络连接）
            var encoded = encodeURIComponent(xml);
            iframe.src = 'https://viewer.diagrams.net/?lightbox=1&highlight=0&edit=_blank&layers=1&nav=1#R' + encoded;
            iframe.dataset.loaded = '1';
        }}

        function loadActiveDiagram() {{
            var activePane = document.querySelector('.tab-pane.active');
            if (activePane && activePane.id && activePane.id.startsWith('diagramPane')) {{
                var index = parseInt(activePane.id.replace('diagramPane', ''));
                loadDiagram(index);
            }}
        }}

        // Sync scroll for source view
        document.addEventListener('DOMContentLoaded', function() {{
            var sourceBody = document.querySelector('.source-body');
            var lineNumbers = document.querySelector('.line-numbers');
            if (sourceBody && lineNumbers) {{
                sourceBody.addEventListener('scroll', function() {{
                    lineNumbers.scrollTop = sourceBody.scrollTop;
                }});
            }}
            // 加载当前活动的图表
            loadActiveDiagram();
        }});

        initTheme();
    </script>
</body>
</html>
"""


__all__ = ['render_drawio_preview_page']
