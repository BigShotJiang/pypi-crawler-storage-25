"""audio preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_audio_preview_page(username: str, file_path: str, file_name: str,
                              audio_urls: list, current_index: int, is_admin: bool = False) -> str:
    """渲染音频预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        audio_urls: 同目录下所有音频文件的路径列表
        current_index: 当前音频在列表中的索引
    """
    total = len(audio_urls)
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    # 使用 /download/ 路由获取原始音频数据，而不是 /preview/ （后者返回HTML页面）
    audio_url = f'/download/{quote_path(file_path, leading_slash=False)}'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # 根据文件扩展名推断 MIME 类型
    ext = os.path.splitext(file_name)[1].lower()
    _AUDIO_MIME = {'.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg',
                   '.flac': 'audio/flac', '.aac': 'audio/aac', '.m4a': 'audio/mp4',
                   '.wma': 'audio/x-ms-wma', '.opus': 'audio/opus', '.weba': 'audio/webm'}
    audio_mime = _AUDIO_MIME.get(ext, 'audio/mpeg')

    # Build navigation URLs as JS array - 使用 /download/ 路由
    audio_urls_json = ','.join(f'"/download/{quote_path(p, leading_slash=False)}"' for p in audio_urls)
    audio_names_json = ','.join(f'"{_escape_html(os.path.basename(p.replace(os.sep, "/")))}"' for p in audio_urls)

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - 音频预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .audio-player-container {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            text-align: center;
        }}
        .audio-placeholder {{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }}
        .audio-placeholder-icon {{
            font-size: 80px;
            margin-bottom: 15px;
            opacity: 0.6;
        }}
        .audio-name {{
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 20px;
        }}
        .btn-play {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 44px;
            font-size: 16px;
            font-weight: 600;
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .btn-play:hover {{
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
        }}
        .btn-play:active {{
            transform: translateY(0);
        }}
        audio {{
            width: 100%;
            max-width: 600px;
            margin-bottom: 20px;
            border-radius: 8px;
        }}
        .audio-nav {{
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin-top: 20px;
        }}
        .nav-btn-audio {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }}
        .nav-btn-audio:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .nav-btn-audio:disabled {{
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }}
        .audio-counter {{
            color: var(--text-secondary);
            font-size: 14px;
            min-width: 60px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>音频预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2 id="audioTitle">🎵 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-primary" id="downloadBtn" download>⬇️ 下载</a>

        </div>

        <div class="audio-player-container">
            <div class="audio-placeholder" id="audioPlaceholder">
                <div class="audio-placeholder-icon">🎧</div>
                <div class="audio-name" id="audioPlaceholderName">{_escape_html(file_name)}</div>
                <button class="btn-play" onclick="loadAudio()">▶ 播放音频</button>
            </div>
            <audio id="audioPlayer" controls style="display:none;" preload="none">
                <source src="" type="{audio_mime}">
                您的浏览器不支持音频播放。
            </audio>
            <div class="audio-nav">
                <button class="nav-btn-audio" id="prevBtn" onclick="navigateAudio(-1)">◀ 上一首</button>
                <span class="audio-counter" id="audioCounter">{current_index + 1} / {total}</span>
                <button class="nav-btn-audio" id="nextBtn" onclick="navigateAudio(1)">下一首 ▶</button>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        const audioUrls = [{audio_urls_json}];
        const audioNames = [{audio_names_json}];
        let currentIndex = {current_index};
        let audioLoaded = false;

        function loadAudio() {{
            if (audioLoaded) return;
            const placeholder = document.getElementById('audioPlaceholder');
            const player = document.getElementById('audioPlayer');
            placeholder.style.display = 'none';
            player.style.display = 'block';
            player.src = audioUrls[currentIndex];
            player.play();
            audioLoaded = true;
        }}

        function navigateAudio(direction) {{
            currentIndex += direction;
            if (currentIndex < 0 || currentIndex >= audioUrls.length) {{
                currentIndex -= direction;
                return;
            }}
            const player = document.getElementById('audioPlayer');
            document.getElementById('audioTitle').textContent = '🎵 ' + audioNames[currentIndex];
            document.getElementById('audioCounter').textContent = (currentIndex + 1) + ' / ' + audioUrls.length;
            document.getElementById('downloadBtn').href = audioUrls[currentIndex];
            document.getElementById('audioPlaceholderName').textContent = audioNames[currentIndex];
            if (audioLoaded) {{
                player.src = audioUrls[currentIndex];
                player.play();
            }}
            updateNavButtons();
        }}

        function updateNavButtons() {{
            document.getElementById('prevBtn').disabled = currentIndex === 0;
            document.getElementById('nextBtn').disabled = currentIndex === audioUrls.length - 1;
        }}

        initTheme();
        updateNavButtons();
    </script>
</body>
</html>
"""

__all__ = ['render_audio_preview_page']
