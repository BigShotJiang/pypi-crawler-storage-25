"""预览模板子包"""
from .audio import render_audio_preview_page
from .docx import render_docx_preview_page
from .drawio import render_drawio_preview_page
from .eddx import render_eddx_preview_page
from .html import render_html_preview_page
from .image import render_image_preview_page
from .json_preview import render_json_preview_page
from .json_view import render_json_view_page
from .markdown import render_markdown_preview_page
from .pdf import render_pdf_preview_page
from .pptx import render_pptx_preview_page
from .text import render_text_preview_page
from .video import render_video_preview_page
from .xlsx import render_xlsx_preview_page
from .xmind import render_xmind_preview_page

__all__ = [
    'render_image_preview_page',
    'render_text_preview_page',
    'render_html_preview_page',
    'render_markdown_preview_page',
    'render_docx_preview_page',
    'render_drawio_preview_page',
    'render_eddx_preview_page',
    'render_xlsx_preview_page',
    'render_pptx_preview_page',
    'render_xmind_preview_page',
    'render_audio_preview_page',
    'render_pdf_preview_page',
    'render_video_preview_page',
    'render_json_preview_page',
    'render_json_view_page',
]
