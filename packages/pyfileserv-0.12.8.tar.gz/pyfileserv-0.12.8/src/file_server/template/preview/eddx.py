"""eddx preview template"""
import json
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_eddx_preview_page(username: str, file_path: str, file_name: str,
                             pages: list, page_svgs: list, page_xmls: list,
                             is_admin: bool = False) -> str:
    """渲染 Edraw Max (eddx) 预览页面 — SVG 图表 + XML 源码

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        pages: [{'name': str}]
        page_svgs: [svg_str] 与 pages 一一对应
        page_xmls: [xml_str] 与 pages 一一对应
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # Serialize for JS
    page_data = []
    for i in range(len(pages)):
        page_data.append({
            'name': pages[i]['name'],
            'svg': page_svgs[i],
            'xml': page_xmls[i],
        })
    pages_json = json.dumps(page_data, ensure_ascii=False)

    # Build tab buttons
    tab_buttons = ''
    for i, p in enumerate(pages):
        active = 'active' if i == 0 else ''
        safe_name = _escape_html(p['name'] or f'Page-{i+1}')
        tab_buttons += f'<button class="tab-btn {active}" onclick="switchPage({i}, this)">{safe_name}</button>\n'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - Edraw 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{ font-size: 20px; margin: 0; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex; gap: 15px; flex-wrap: wrap; align-items: center;
        }}
        .toolbar h2 {{
            margin: 0; font-size: 18px; color: var(--text-primary); flex: 1;
            word-wrap: break-word; word-break: break-all;
        }}
        .btn {{
            padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600;
            cursor: pointer; transition: all 0.3s; text-decoration: none;
            display: inline-flex; align-items: center; gap: 6px; border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY}; color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px); box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary); color: #667eea; border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{ background: #667eea; color: white; }}
        .view-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex; gap: 0; flex-wrap: wrap; align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .tab-btn {{
            padding: 12px 25px; background: transparent; color: var(--text-secondary);
            border: none; border-bottom: 3px solid transparent;
            font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s;
        }}
        .tab-btn.active {{ color: #667eea; border-bottom-color: #667eea; }}
        .tab-btn:hover {{ color: var(--text-primary); }}
        .view-mode-btn {{
            margin-left: auto; padding: 8px 18px;
            background: transparent; color: var(--text-secondary);
            border: 1px solid var(--border-color); border-radius: 6px;
            font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s;
        }}
        .view-mode-btn:hover {{ background: rgba(102,126,234,0.1); }}
        .view-mode-btn.active {{ background: #667eea; color: white; border-color: #667eea; }}
        .tab-content {{
            background: var(--bg-secondary);
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05); overflow: hidden;
        }}
        .tab-pane {{ display: none; }}
        .tab-pane.active {{ display: block; }}
        .svg-container {{
            width: 100%; max-height: 75vh; overflow: auto;
            background: #f5f5f5; position: relative;
        }}
        .svg-container svg {{
            display: block; min-width: 100%;
        }}
        .source-body {{
            display: flex; overflow: auto; max-height: 70vh; background: #1e1e1e;
        }}
        .line-numbers {{
            padding: 15px 12px; background: #1e1e1e; color: #636d83;
            text-align: right; user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px; line-height: 1.6; border-right: 1px solid #333;
            min-width: 50px; white-space: pre;
        }}
        .source-content {{
            padding: 15px 20px; flex: 1; overflow: visible;
            background: #1e1e1e; color: #d4d4d4;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px; line-height: 1.6; white-space: pre;
        }}
        .zoom-controls {{
            position: sticky; top: 10px; right: 10px; float: right;
            display: flex; gap: 4px; z-index: 10;
            background: rgba(255,255,255,0.9); border-radius: 8px;
            padding: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }}
        .zoom-btn {{
            width: 32px; height: 32px; border: none; border-radius: 6px;
            background: white; color: #333; font-size: 16px; font-weight: bold;
            cursor: pointer; display: flex; align-items: center; justify-content: center;
            transition: all 0.15s;
        }}
        .zoom-btn:hover {{ background: #667eea; color: white; }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>Edraw Max 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📊 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>
            {f'<a href="/admin" class="btn btn-primary" target="_blank">⚙️ 管理</a>' if is_admin else ''}
        </div>

        <div class="view-bar">
            {tab_buttons}
            <button class="view-mode-btn active" id="btnSvg" onclick="setViewMode('svg')">图表</button>
            <button class="view-mode-btn" id="btnXml" onclick="setViewMode('xml')">源码</button>
        </div>
        <div class="tab-content">
            <div id="svgPanes"></div>
            <div id="xmlPanes" style="display:none;"></div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        var pageData = {pages_json};
        var currentPage = 0;
        var viewMode = 'svg';  // 'svg' or 'xml'
        var zoomLevel = 1.0;

        function buildAllPanes() {{
            var svgDiv = document.getElementById('svgPanes');
            var xmlDiv = document.getElementById('xmlPanes');
            svgDiv.innerHTML = '';
            xmlDiv.innerHTML = '';

            pageData.forEach(function(p, i) {{
                var active = i === 0 ? ' active' : '';

                // SVG pane
                var svgPane = document.createElement('div');
                svgPane.className = 'tab-pane' + active;
                svgPane.id = 'svgPane' + i;
                if (p.svg) {{
                    svgPane.innerHTML = '<div class="svg-container" id="svgContainer' + i + '">'
                        + '<div class="zoom-controls">'
                        + '<button class="zoom-btn" onclick="zoomIn()" title="放大">+</button>'
                        + '<button class="zoom-btn" onclick="zoomOut()" title="缩小">−</button>'
                        + '<button class="zoom-btn" onclick="zoomFit()" title="适应">⊡</button>'
                        + '</div>'
                        + p.svg
                        + '</div>';
                }} else {{
                    svgPane.innerHTML = '<div class="tab-pane' + active + '" style="padding:40px;text-align:center;color:var(--text-secondary);">'
                        + '<p>此页面无法渲染为 SVG。</p></div>';
                }}
                svgDiv.appendChild(svgPane);

                // XML pane
                var xmlLines = p.xml.split('\\n');
                var lineNums = '';
                for (var j = 0; j < xmlLines.length; j++) {{ lineNums += (j+1) + '\\n'; }}
                var escXml = escapeHtml(p.xml);
                var xmlPane = document.createElement('div');
                xmlPane.className = 'tab-pane' + active;
                xmlPane.id = 'xmlPane' + i;
                xmlPane.innerHTML = '<div class="source-body">'
                    + '<div class="line-numbers">' + lineNums + '</div>'
                    + '<div class="source-content">' + escXml + '</div>'
                    + '</div>';
                xmlDiv.appendChild(xmlPane);
            }});

            // Sync scroll for XML views
            document.querySelectorAll('.source-body').forEach(function(sb) {{
                var ln = sb.querySelector('.line-numbers');
                if (ln) {{
                    sb.addEventListener('scroll', function() {{ ln.scrollTop = sb.scrollTop; }});
                }}
            }});
        }}

        function switchPage(index, btnEl) {{
            currentPage = index;
            document.querySelectorAll('.view-bar .tab-btn').forEach(function(b) {{ b.classList.remove('active'); }});
            btnEl.classList.add('active');
            refreshView();
        }}

        function setViewMode(mode) {{
            viewMode = mode;
            document.getElementById('btnSvg').classList.toggle('active', mode === 'svg');
            document.getElementById('btnXml').classList.toggle('active', mode === 'xml');
            refreshView();
        }}

        function refreshView() {{
            var svgPanes = document.querySelectorAll('#svgPanes .tab-pane');
            var xmlPanes = document.querySelectorAll('#xmlPanes .tab-pane');
            svgPanes.forEach(function(p) {{ p.classList.remove('active'); }});
            xmlPanes.forEach(function(p) {{ p.classList.remove('active'); }});

            document.getElementById('svgPanes').style.display = viewMode === 'svg' ? '' : 'none';
            document.getElementById('xmlPanes').style.display = viewMode === 'xml' ? '' : 'none';

            var prefix = viewMode === 'svg' ? 'svgPane' : 'xmlPane';
            var pane = document.getElementById(prefix + currentPage);
            if (pane) pane.classList.add('active');
        }}

        function zoomIn() {{
            zoomLevel = Math.min(zoomLevel * 1.25, 5);
            applyZoom();
        }}

        function zoomOut() {{
            zoomLevel = Math.max(zoomLevel / 1.25, 0.2);
            applyZoom();
        }}

        function zoomFit() {{
            zoomLevel = 1.0;
            applyZoom();
        }}

        function applyZoom() {{
            var container = document.getElementById('svgContainer' + currentPage);
            if (!container) return;
            var svg = container.querySelector('svg');
            if (!svg) return;
            svg.style.width = (zoomLevel * 100) + '%';
            svg.style.height = 'auto';
        }}

        function escapeHtml(text) {{
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }}

        document.addEventListener('DOMContentLoaded', function() {{
            buildAllPanes();
            refreshView();
        }});

        initTheme();
    </script>
</body>
</html>
"""


__all__ = ['render_eddx_preview_page']
