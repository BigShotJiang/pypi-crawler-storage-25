"""markdown preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_markdown_preview_page(username: str, file_path: str, file_name: str,
                                 content: str, rendered_html: str, is_admin: bool = False) -> str:
    """渲染Markdown预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        content: Markdown源文件内容
        rendered_html: 渲染后的HTML内容
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'
    escaped_content = _escape_html(content)

    # Build line numbers for source view
    lines = content.split('\n')
    line_numbers = '\n'.join(str(i + 1) for i in range(len(lines)))

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - Markdown预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <script src="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"></script>
    <script>
        mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
    </script>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .tab-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex;
            gap: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .tab-btn {{
            padding: 12px 25px;
            background: transparent;
            color: var(--text-secondary);
            border: none;
            border-bottom: 3px solid transparent;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .tab-btn.active {{
            color: #667eea;
            border-bottom-color: #667eea;
        }}
        .tab-btn:hover {{
            color: var(--text-primary);
        }}
        .tab-content {{
            background: var(--bg-secondary);
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }}
        .tab-pane {{
            display: none;
        }}
        .tab-pane.active {{
            display: block;
        }}
        .preview-pane {{
            padding: 30px;
            color: var(--text-primary);
            line-height: 1.8;
            max-height: 75vh;
            overflow-y: auto;
        }}
        .preview-pane h1, .preview-pane h2, .preview-pane h3,
        .preview-pane h4, .preview-pane h5, .preview-pane h6 {{
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            color: var(--text-primary);
        }}
        .preview-pane h1 {{ font-size: 2em; border-bottom: 1px solid var(--border-color); padding-bottom: 8px; }}
        .preview-pane h2 {{ font-size: 1.5em; border-bottom: 1px solid var(--border-color); padding-bottom: 6px; }}
        .preview-pane h3 {{ font-size: 1.25em; }}
        .preview-pane p {{ margin-bottom: 16px; }}
        .preview-pane pre {{
            background: #f8f9fa;
            color: #333;
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
            margin-bottom: 16px;
        }}
        [data-theme="dark"] .preview-pane pre {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
        .preview-pane code {{
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
        }}
        .preview-pane :not(pre) > code {{
            background: rgba(102, 126, 234, 0.1);
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.9em;
        }}
        .preview-pane blockquote {{
            border-left: 4px solid #667eea;
            padding: 10px 20px;
            margin: 16px 0;
            background: rgba(102, 126, 234, 0.05);
            color: var(--text-secondary);
        }}
        .preview-pane table {{
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 16px;
        }}
        .preview-pane th, .preview-pane td {{
            border: 1px solid var(--border-color);
            padding: 8px 12px;
        }}
        .preview-pane th {{
            background: rgba(102, 126, 234, 0.1);
        }}
        .preview-pane img {{
            max-width: 100%;
            border-radius: 8px;
        }}
        .preview-pane ul, .preview-pane ol {{
            padding-left: 25px;
            margin-bottom: 16px;
        }}
        .preview-pane .task-list-item {{
            list-style: none;
            margin-left: -20px;
        }}
        .preview-pane .task-list-item input[type="checkbox"] {{
            appearance: none;
            -webkit-appearance: none;
            margin-right: 8px;
            width: 16px;
            height: 16px;
            border: 2px solid #bdbdbd;
            border-radius: 3px;
            cursor: default;
            vertical-align: middle;
            position: relative;
            transition: all 0.2s;
        }}
        .preview-pane .task-list-item input[type="checkbox"]:checked {{
            background: #4caf50;
            border-color: #4caf50;
        }}
        .preview-pane .task-list-item input[type="checkbox"]:checked::after {{
            content: '';
            position: absolute;
            left: 3px;
            top: 1px;
            width: 5px;
            height: 9px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }}
        .preview-pane a {{
            color: #667eea;
            text-decoration: none;
        }}
        .preview-pane a:hover {{
            text-decoration: underline;
        }}
        .mermaid-container {{
            margin: 16px 0;
            padding: 16px;
            background: var(--bg-primary, #fff);
            border-radius: 8px;
            border: 1px solid var(--border-color, #e0e0e0);
            overflow-x: auto;
        }}
        .mermaid-container svg {{
            display: block;
            max-width: 100%;
            height: auto;
            margin: 0 auto;
        }}
        .source-body {{
            display: flex;
            overflow: auto;
            max-height: 75vh;
            background: #f8f9fa;
        }}
        [data-theme="dark"] .source-body {{
            background: #1e1e1e;
        }}
        .line-numbers {{
            padding: 15px 12px 15px 12px;
            background: #f8f9fa;
            color: #6c757d;
            text-align: right;
            user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            border-right: 1px solid #dee2e6;
            min-width: 50px;
            white-space: pre;
        }}
        [data-theme="dark"] .line-numbers {{
            background: #1e1e1e;
            color: #636d83;
            border-right-color: #333;
        }}
        .source-content {{
            padding: 15px 20px 15px 20px;
            flex: 1;
            overflow: visible;
            background: #f8f9fa;
            color: #333;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre;
            word-break: normal;
            overflow-wrap: normal;
        }}
        [data-theme="dark"] .source-content {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
        @media print {{
            .header, .toolbar, .tab-bar, .theme-btn, .toast-container {{
                display: none !important;
            }}
            body {{
                background: white !important;
                padding: 0 !important;
            }}
            .container {{
                max-width: 100% !important;
                margin: 0 !important;
            }}
            .tab-content {{
                box-shadow: none !important;
                background: white !important;
            }}
            .preview-pane {{
                max-height: none !important;
                overflow: visible !important;
                padding: 10px 0 !important;
                color: #000 !important;
                font-size: 13px !important;
                line-height: 1.6 !important;
            }}
            .preview-pane pre {{
                background: #f5f5f5 !important;
                color: #333 !important;
                border: 1px solid #ddd !important;
            }}
            .preview-pane blockquote {{
                background: #f9f9f9 !important;
                color: #555 !important;
            }}
            .preview-pane .task-list-item input[type="checkbox"] {{
                appearance: auto !important;
                -webkit-appearance: auto !important;
                width: auto !important;
                height: auto !important;
                border: none !important;
                border-radius: 0 !important;
                background: none !important;
                position: static !important;
            }}
            .preview-pane .task-list-item input[type="checkbox"]:checked {{
                background: none !important;
                border: none !important;
            }}
            .preview-pane .task-list-item input[type="checkbox"]:checked::after {{
                content: none !important;
            }}
            .source-body, #sourcePane, #sourcePane.active, .tab-pane:not(#previewPane) {{
                display: none !important;
            }}
            #previewPane {{
                display: block !important;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>Markdown 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📄 {_escape_html(file_name)}</h2>
            <button onclick="copySource()" class="btn btn-primary">📋 复制源码</button>
            <button onclick="exportPDF()" class="btn btn-primary">📄 导出PDF</button>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>

        </div>

        <div class="tab-bar">
            <button class="tab-btn active" onclick="switchTab('preview', this)">预览</button>
            <button class="tab-btn" onclick="switchTab('source', this)">源码</button>
        </div>
        <div class="tab-content">
            <div class="tab-pane active" id="previewPane">
                <div class="preview-pane">
                    {rendered_html}
                </div>
            </div>
            <div class="tab-pane" id="sourcePane">
                <div class="source-body">
                    <div class="line-numbers">{line_numbers}</div>
                    <div class="source-content" id="sourceContent">{escaped_content}</div>
                </div>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function switchTab(tabName, btnEl) {{
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btnEl.classList.add('active');
            document.getElementById(tabName + 'Pane').classList.add('active');
        }}

        function copySource() {{
            const source = document.getElementById('sourceContent').textContent;
            copyToClipboard(source);
        }}

        function exportPDF() {{
            showToast('正在准备导出PDF...', 'info');
            const previewBtn = document.querySelector('.tab-btn');
            const previewPane = document.getElementById('previewPane');
            const sourcePane = document.getElementById('sourcePane');
            const wasPreviewActive = previewPane.classList.contains('active');

            if (!wasPreviewActive) {{
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
                previewBtn.classList.add('active');
                previewPane.classList.add('active');
            }}

            setTimeout(() => {{
                window.print();
                showToast('已打开打印对话框，请选择"另存为PDF"', 'success');
            }}, 300);
        }}

        // Sync scroll for source view
        document.addEventListener('DOMContentLoaded', () => {{
            const sourceBody = document.querySelector('.source-body');
            const lineNumbers = document.querySelector('.line-numbers');

            if (sourceBody && lineNumbers) {{
                sourceBody.addEventListener('scroll', () => {{
                    lineNumbers.scrollTop = sourceBody.scrollTop;
                }});
            }}

        }});

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_markdown_preview_page']
