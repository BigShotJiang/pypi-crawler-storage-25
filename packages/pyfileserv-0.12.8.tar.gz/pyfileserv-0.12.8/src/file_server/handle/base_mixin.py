"""基础功能 Mixin"""
import json
import logging
import mimetypes
from pathlib import Path
from typing import Optional


logger = logging.getLogger(__name__)


class BaseMixin:
    """基础功能方法（IP检查、JSON响应、静态文件、HTTP路由分发）"""

    config = None
    authenticator = None
    session_manager = None
    user_store = None
    admin_handler = None

    def _get_session_id(self) -> Optional[str]:
        """从 Cookie 获取 session_id"""
        if 'Cookie' in self.headers:
            cookies = self.headers['Cookie'].split(';')
            for cookie in cookies:
                if cookie.strip().startswith('session_id='):
                    return cookie.strip()[11:]
        return None

    def log_request_info(self, method: str) -> None:
        """记录请求信息"""
        client_ip = self.client_address[0]
        client_port = self.client_address[1]
        logger.info(f"[{method}] {client_ip}:{client_port} - {self.path}")

    def get_current_username(self) -> Optional[str]:
        """获取当前登录用户名"""
        session_id = self._get_session_id()
        if session_id and self.session_manager:
            return self.session_manager.get_username(session_id)
        return None

    def is_authenticated(self) -> bool:
        """检查是否已认证"""
        session_id = self._get_session_id()
        if session_id and self.session_manager:
            valid, _ = self.session_manager.validate_session(session_id)
            return valid
        return False

    def _check_ip_restriction(self) -> bool:
        """检查 IP 限制"""
        if not self.config:
            return True

        client_ip = self.client_address[0]
        if not self.config.is_ip_allowed(client_ip):
            logger.warning(f"IP 被拒绝访问: {client_ip}")
            self.send_error(403, "Access Denied")
            return False
        return True

    def _check_same_origin(self) -> bool:
        """CSRF 防护: 验证 Origin/Referer 头匹配预期主机"""
        # 登录和分享访问不需要 CSRF 检查
        if self.path in ('/do_login', '/do_logout') or self.path.startswith('/share/access/'):
            return True
        # 构造期望的 origin
        protocol = 'https' if (self.config and self.config.use_https) else 'http'
        host = self.headers.get('Host', '')
        expected_origin = f'{protocol}://{host}'
        # 检查 Origin 头
        origin = self.headers.get('Origin', '')
        if origin and origin == expected_origin:
            return True
        # 回退: 检查 Referer 头
        referer = self.headers.get('Referer', '')
        if referer and referer.startswith(expected_origin):
            return True
        # 无 Origin/Referer 的请求（如 curl）放行，但记录日志
        if not origin and not referer:
            return True
        logger.warning(
            f"CSRF 检查失败 - Origin: {origin}, Referer: {referer}, "
            f"Expected: {expected_origin}"
        )
        self._send_error_response('CSRF validation failed', 403)
        return False

    def _send_json_response(self, data: dict, status_code: int = 200):
        """发送 JSON 响应"""
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def _send_error_response(self, message: str, status_code: int = 400):
        """发送错误响应"""
        self._send_json_response({'success': False, 'error': message}, status_code)

    def _send_svg_response(self, svg_content: str) -> None:
        """发送 SVG 响应"""
        content = svg_content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-type', 'image/svg+xml')
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'public, max-age=86400')
        self.end_headers()
        self.wfile.write(content)

    def _send_html_response(self, html: str) -> None:
        """发送 HTML 响应"""
        content = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _handle_static(self) -> None:
        """处理静态文件请求 - 从磁盘 static/ 目录提供文件，支持 ETag 条件请求和长缓存"""
        static_file = self.path[len('/static/'):]
        # 确定静态资源根目录
        static_root = (Path(__file__).parent.parent / 'static').resolve()
        file_path = (static_root / static_file).resolve()
        # 路径遍历保护
        try:
            file_path.relative_to(static_root)
        except ValueError:
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "Static file not found")
            return

        # 确定 MIME 类型
        mime_type, _ = mimetypes.guess_type(str(file_path))
        if mime_type is None:
            mime_type = 'application/octet-stream'

        stat = file_path.stat()
        file_size = stat.st_size
        # ETag: W/"mtime-ns.size" — 纳秒级修改时间 + 文件大小保证唯一性
        etag = f'W/"{stat.st_mtime_ns}-{file_size}"'

        # 检查条件请求：If-None-Match
        if_none_match = self.headers.get('If-None-Match', '')
        if if_none_match and if_none_match == etag:
            self.send_response(304)
            self.send_header('Cache-Control', 'public, max-age=31536000, immutable')
            self.end_headers()
            return

        # 发送完整响应
        self.send_response(200)
        self.send_header('Content-Type', mime_type)
        self.send_header('Content-Length', str(file_size))
        self.send_header('ETag', etag)
        self.send_header('Cache-Control', 'public, max-age=31536000, immutable')
        self.end_headers()

        with open(file_path, 'rb') as f:
            self.copyfile(f, self.wfile)

    def _handle_admin_page(self) -> None:
        """处理管理员页面"""
        if not self.admin_handler:
            self.send_error(500, "Admin handler not configured")
            return

        self.admin_handler.handle_admin_page(self)

    def _handle_admin_create_user(self) -> None:
        """处理创建用户API"""
        if not self.admin_handler:
            self._send_error_response("Admin handler not configured", 500)
            return

        self.admin_handler.handle_create_user(self)

    def do_GET(self) -> None:
        """处理 GET 请求"""
        try:
            self.log_request_info('GET')

            # IP 限制检查
            if not self._check_ip_restriction():
                return

            # 分享链接不需要认证，优先处理
            if self.path.startswith('/share/access/'):
                self._handle_share_access()
                return
            elif self.path.startswith('/share/download/'):
                self._handle_share_download()
                return
            elif self.path.startswith('/share/file/'):
                self._handle_share_file_download()
                return
            elif self.path.startswith('/share/list/'):
                self._handle_share_list()
                return

            # 未认证用户只能访问登录页和静态资源
            if not self.is_authenticated():
                if self.path in ('/login', '/do_login'):
                    self._handle_login_page()
                elif self.path.startswith('/static/'):
                    self._handle_static()
                else:
                    self._redirect_to_login()
                return

            # 已认证用户的路由
            if self.path == '/logout':
                self._handle_logout()
            elif self.path == '/admin':
                self._handle_admin_page()
            elif self.path == '/upload':
                self._handle_upload_page()
            elif self.path.startswith('/view/'):
                self._handle_view_json()
            elif self.path.startswith('/preview/'):
                self._handle_preview()
            elif self.path.startswith('/download/'):
                self._handle_download()
            elif self.path.startswith('/static/'):
                self._handle_static()
            elif self.path == '/trash':
                self._handle_trash_page()
            elif self.path == '/shares':
                self._handle_share_management()
            elif self.path.startswith('/api/directories'):
                self._handle_list_directories()
            else:
                import http.server
                http.server.SimpleHTTPRequestHandler.do_GET(self)
        except ConnectionAbortedError:
            pass
        except Exception as e:
            logger.error(e.args)

    def do_POST(self) -> None:
        """处理 POST 请求"""
        try:
            self.log_request_info('POST')

            # IP 限制检查
            if not self._check_ip_restriction():
                return

            # CSRF 检查
            if not self._check_same_origin():
                return

            # 分享链接不需要认证，优先处理
            if self.path.startswith('/share/access/'):
                self._handle_share_access()
                return

            if not self.is_authenticated() and self.path not in ('/do_login',):
                self._send_error_response('未认证', 403)
                return

            if self.path == '/do_login':
                self._handle_login()
            elif self.path == '/do_logout':
                self._handle_logout()
            elif self.path == '/upload':
                self._handle_upload()
            elif self.path.startswith('/api/delete/'):
                self._handle_delete()
            elif self.path == '/api/rename':
                self._handle_rename()
            elif self.path == '/api/move':
                self._handle_move()
            elif self.path == '/api/copy':
                self._handle_copy()
            elif self.path == '/api/mkdir':
                self._handle_mkdir()
            elif self.path == '/api/share':
                self._handle_create_share()
            elif self.path.startswith('/api/share/delete/'):
                self._handle_delete_share()
            elif self.path.startswith('/api/share/update/'):
                self._handle_update_share()
            elif self.path.startswith('/api/share/permanent-delete/'):
                self._handle_permanent_delete_share()
            elif self.path == '/api/trash/restore':
                self._handle_trash_restore()
            elif self.path.startswith('/api/trash/delete/'):
                self._handle_trash_permanent_delete()
            elif self.path == '/api/trash/empty':
                self._handle_trash_empty()
            elif self.path == '/api/zip-download':
                self._handle_zip_download()
            elif self.path.startswith('/convert/'):
                self._handle_convert_json()
            elif self.path == '/api/admin/users':
                self._handle_admin_create_user()
            else:
                self.send_error(404, "Not Found")
        except ConnectionAbortedError:
            pass
        except Exception as e:
            logger.error(e.args)

    def do_PUT(self) -> None:
        """处理 PUT 请求"""
        import urllib.parse
        self.log_request_info('PUT')

        # IP 限制检查
        if not self._check_ip_restriction():
            return

        # CSRF 检查
        if not self._check_same_origin():
            return

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        # 管理员 API: 修改密码
        if self.path.startswith('/api/admin/users/') and self.path.endswith('/password'):
            # 提取用户名: /api/admin/users/{username}/password
            parts = self.path.split('/')
            if len(parts) >= 5:
                username = urllib.parse.unquote(parts[4])
                if self.admin_handler:
                    self.admin_handler.handle_change_password(self, username)
                else:
                    self._send_error_response("Admin handler not configured", 500)
            else:
                self.send_error(404, "Not Found")
        else:
            self.send_error(404, "Not Found")

    def do_DELETE(self) -> None:
        """处理 DELETE 请求"""
        import urllib.parse
        self.log_request_info('DELETE')

        # IP 限制检查
        if not self._check_ip_restriction():
            return

        # CSRF 检查
        if not self._check_same_origin():
            return

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        # 管理员 API: 删除用户
        if self.path.startswith('/api/admin/users/'):
            # 提取用户名: /api/admin/users/{username}
            parts = self.path.split('/')
            if len(parts) >= 5:
                username = urllib.parse.unquote(parts[4])
                if self.admin_handler:
                    self.admin_handler.handle_delete_user(self, username)
                else:
                    self._send_error_response("Admin handler not configured", 500)
            else:
                self.send_error(404, "Not Found")
        else:
            self.send_error(404, "Not Found")
