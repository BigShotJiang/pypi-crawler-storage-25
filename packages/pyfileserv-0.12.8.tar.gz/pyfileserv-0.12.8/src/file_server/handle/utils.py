"""HTTP 处理器 - 工具函数模块"""
import logging
import os
import re
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 文件类型检测
IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.ico'}
AUDIO_EXTENSIONS = {'.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma'}
VIDEO_EXTENSIONS = {'.mp4', '.webm', '.avi', '.mov', '.mkv'}
PDF_EXTENSIONS = {'.pdf'}
TEXT_EXTENSIONS = {'.txt', '.log', '.cfg', '.ini', '.conf', '.yaml', '.yml', '.toml', '.py', '.js', '.ts', '.jsx',
    '.tsx', '.java', '.c', '.cpp', '.h', '.hpp', '.cs', '.go', '.rs', '.rb', '.php', '.swift', '.kt', '.scala', '.html',
    '.htm', '.css', '.scss', '.less', '.xml', '.sql', '.sh', '.bash', '.zsh', '.bat', '.ps1', '.dockerfile',
    '.makefile', '.cmake', '.r', '.R', '.m', '.pl', '.lua', }
MARKDOWN_EXTENSIONS = {'.md', '.markdown'}
XMIND_EXTENSIONS = {'.xmind'}
DOCX_EXTENSIONS = {'.docx', '.doc'}
XLSX_EXTENSIONS = {'.xlsx', '.xls'}
PPTX_EXTENSIONS = {'.pptx', '.ppt'}
DRAWIO_EXTENSIONS = {'.drawio'}
EDDX_EXTENSIONS = {'.eddx'}
PREVIEWABLE_EXTENSIONS = (
        IMAGE_EXTENSIONS | AUDIO_EXTENSIONS | VIDEO_EXTENSIONS | PDF_EXTENSIONS | TEXT_EXTENSIONS | MARKDOWN_EXTENSIONS | XMIND_EXTENSIONS | DOCX_EXTENSIONS | XLSX_EXTENSIONS | PPTX_EXTENSIONS | DRAWIO_EXTENSIONS | EDDX_EXTENSIONS)


def detect_file_type(filename: str) -> str:
    """检测文件类型

    Returns:
        'image', 'audio', 'video', 'pdf', 'text', 'markdown', 'xmind', 'json',
        'docx', 'xlsx', 'pptx', 'drawio', 'eddx', or 'other'
    """
    lower = filename.lower()
    ext = os.path.splitext(lower)[1]
    if ext in IMAGE_EXTENSIONS:
        return 'image'
    if ext in AUDIO_EXTENSIONS:
        return 'audio'
    if ext in VIDEO_EXTENSIONS:
        return 'video'
    if ext in PDF_EXTENSIONS:
        return 'pdf'
    if ext in MARKDOWN_EXTENSIONS:
        return 'markdown'
    if ext in XMIND_EXTENSIONS:
        return 'xmind'
    if ext in DOCX_EXTENSIONS:
        return 'docx'
    if ext in XLSX_EXTENSIONS:
        return 'xlsx'
    if ext in PPTX_EXTENSIONS:
        return 'pptx'
    if ext in DRAWIO_EXTENSIONS:
        return 'drawio'
    if ext in EDDX_EXTENSIONS:
        return 'eddx'
    if ext == '.json':
        return 'json'
    if ext in TEXT_EXTENSIONS:
        return 'text'
    return 'other'


def _is_safe_path(base_dir: Path, target_path: Path) -> bool:
    """检查目标路径是否在基础目录范围内，防止路径遍历攻击

    使用 Path.relative_to() 进行规范化路径检查，能正确处理
    大小写不敏感文件系统（Windows）和 Unicode 规范化差异。
    """
    try:
        target_path.resolve().relative_to(base_dir.resolve())
        return True
    except (ValueError, OSError):
        return False


def _parse_multipart(content: bytes, boundary: str) -> List[Dict]:
    """解析 multipart/form-data 数据

    Returns:
        List of dicts with keys: 'name', 'filename', 'data', 'content_type'
    """
    parts = []
    boundary_bytes = f'--{boundary}'.encode('utf-8')
    end_boundary = f'--{boundary}--'.encode('utf-8')

    # 分割各个部分
    raw_parts = content.split(boundary_bytes)

    for raw_part in raw_parts[1:]:  # 跳过第一个空部分
        if raw_part.startswith(b'--'):
            continue  # 结束边界

        # 去除前后的 CRLF
        raw_part = raw_part.strip(b'\r\n')
        if not raw_part:
            continue

        # 分离 headers 和 body
        header_end = raw_part.find(b'\r\n\r\n')
        if header_end == -1:
            continue

        headers_raw = raw_part[:header_end].decode('utf-8', errors='replace')
        body = raw_part[header_end + 4:]

        # 解析 headers
        content_disp = None
        content_type = None

        for line in headers_raw.split('\r\n'):
            if line.lower().startswith('content-disposition:'):
                content_disp = line
            elif line.lower().startswith('content-type:'):
                content_type = line.split(':', 1)[1].strip()

        if not content_disp:
            continue

        # 提取 name 和 filename
        name_match = re.search(r'name="([^"]+)"', content_disp)
        filename_match = re.search(r'filename="([^"]+)"', content_disp)

        part_info = {'name': name_match.group(1) if name_match else '',
            'filename': filename_match.group(1) if filename_match else None, 'data': body,
            'content_type': content_type or 'application/octet-stream'}

        # 去除 body 末尾可能的多余数据
        if body.endswith(b'\r\n'):
            part_info['data'] = body[:-2]

        parts.append(part_info)

    return parts


def _sanitize_filename(filename: str) -> str:
    """清理文件名，移除危险字符"""
    # 只保留文件名，移除路径
    filename = os.path.basename(filename)
    # 移除危险字符
    filename = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', filename)
    # 移除开头的点和空格
    filename = filename.lstrip('. ')
    # 如果清理后为空，使用默认名称
    if not filename:
        filename = 'unnamed_file'
    return filename


def _resolve_safe_path(base_dir: Path, relative_path: str) -> Optional[Path]:
    """解析并验证路径安全

    使用 Path.relative_to() 替代字符串前缀比较，
    正确处理大小写不敏感文件系统和 Unicode 规范化。
    """
    try:
        target_path = (base_dir / relative_path).resolve()
        target_path.relative_to(base_dir.resolve())
        return target_path
    except (ValueError, OSError) as e:
        logger.error(f"_resolve_safe_path - 异常: {e}")
        return None


__all__ = ['IMAGE_EXTENSIONS', 'AUDIO_EXTENSIONS', 'VIDEO_EXTENSIONS', 'PDF_EXTENSIONS', 'TEXT_EXTENSIONS',
    'MARKDOWN_EXTENSIONS', 'XMIND_EXTENSIONS', 'DOCX_EXTENSIONS', 'XLSX_EXTENSIONS', 'PPTX_EXTENSIONS',
    'DRAWIO_EXTENSIONS', 'EDDX_EXTENSIONS', 'PREVIEWABLE_EXTENSIONS', 'detect_file_type', '_is_safe_path',
    '_parse_multipart', '_sanitize_filename', '_resolve_safe_path', ]
