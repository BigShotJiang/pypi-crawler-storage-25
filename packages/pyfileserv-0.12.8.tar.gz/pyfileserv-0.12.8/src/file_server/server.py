"""文件服务器主模块"""
import logging
import os
import socket
import socketserver
import ssl
import threading
from importlib.metadata import version
from pathlib import Path

from .config import ServerConfig
from .core.auth import Authenticator, PasswordHasher, SessionManager, UserStore, MemorySessionStorage, \
    RedisSessionStorage, LoginAttemptTracker
from .core.share import ShareManager
from .core.trash import TrashManager
from .handle.admin import AdminHandler
from .handlers import SecureHTTPRequestHandler

logger = logging.getLogger(__name__)


class ThreadPoolTCPServer(socketserver.ThreadingTCPServer):
    """多线程 TCP 服务器，支持限制最大工作线程数"""

    def __init__(self, server_address, RequestHandlerClass,
                 max_workers=0, bind_and_activate=True):
        self._max_workers = max_workers
        self._sem = threading.BoundedSemaphore(max_workers) if max_workers > 0 else None
        super().__init__(server_address, RequestHandlerClass, bind_and_activate)

    def process_request(self, request, client_address):
        if self._sem:
            self._sem.acquire()
        t = threading.Thread(target=self._handle_request,
                             args=(request, client_address))
        t.daemon = self.daemon_threads
        t.start()

    def _handle_request(self, request, client_address):
        try:
            self.process_request_thread(request, client_address)
        finally:
            if self._sem:
                self._sem.release()


def run_server(config: ServerConfig) -> None:
    """启动文件服务器"""
    logger.info("=" * 60)
    logger.info(f"启动服务器: version: {version('pyfileserv')}")
    logger.info(f"启动服务器: port: {config.port}")

    # 检查 SSL 证书文件
    if config.use_https:
        if not config.ssl_cert or not config.ssl_cert.exists():
            logger.error(f"SSL 证书文件不存在: {config.ssl_cert}")
            logger.error("请使用 'pyfileserv cert generate' 生成证书，或检查证书路径")
            raise SystemExit(1)
        if not config.ssl_key or not config.ssl_key.exists():
            logger.error(f"SSL 私钥文件不存在: {config.ssl_key}")
            logger.error("请使用 'pyfileserv cert generate' 生成证书，或检查证书路径")
            raise SystemExit(1)
        logger.info(f"HTTPS 已启用")
        logger.info(f"  证书: {config.ssl_cert}")
        logger.info(f"  私钥: {config.ssl_key}")

    # 初始化用户存储
    if config.use_database:
        # PostgreSQL 数据库存储
        from .db import DatabaseConnection, DatabaseUserStore
        logger.info(f"使用数据库存储: {config.database.type}")
        db = DatabaseConnection(
            host=config.database.host,
            port=config.database.port,
            database=config.database.database,
            username=config.database.username,
            password=config.database.password,
        )
        db.initialize_tables()
        user_store = DatabaseUserStore(db)
    else:
        # JSON 文件存储
        logger.info(f"使用文件存储: {config.get_users_file_path()}")
        user_store = UserStore(config.get_users_file_path())

    # 初始化其他组件
    hasher = PasswordHasher(rounds=config.bcrypt_rounds)
    
    # 根据配置创建会话存储
    if config.session_storage == "redis":
        logger.info(f"使用 Redis 会话存储: {config.redis.host}:{config.redis.port}")
        try:
            session_storage = RedisSessionStorage(
                host=config.redis.host,
                port=config.redis.port,
                db=config.redis.db,
                password=config.redis.password,
                key_prefix=config.redis.key_prefix,
            )
        except Exception as e:
            logger.error(f"Redis 会话存储初始化失败，回退到内存存储: {e}")
            session_storage = MemorySessionStorage()
    else:
        logger.info("使用内存会话存储")
        session_storage = MemorySessionStorage()
    
    session_manager = SessionManager(timeout_seconds=config.session_timeout, storage=session_storage)
    
    # 创建登录尝试跟踪器（从配置读取）
    login_tracker = LoginAttemptTracker(
        max_attempts=config.login_max_attempts,
        lockout_duration=config.login_lockout_duration
    )
    lockout_minutes = config.login_lockout_duration // 60
    logger.info(f"登录保护已启用: {config.login_max_attempts}次失败后锁定{lockout_minutes}分钟")
    
    authenticator = Authenticator(user_store, hasher, session_manager, login_tracker)

    # 确定服务目录
    serve_dir = config.static_dir or config.serve_dir or Path.cwd()

    # 初始化分享管理器
    if config.use_database:
        from .db import DatabaseShareStore
        share_store = DatabaseShareStore(db)
    else:
        from .core.share_store import ShareStore
        share_data_file = serve_dir / 'shares.json'
        share_store = ShareStore(share_data_file, hasher)
    share_manager = ShareManager(share_store, hasher)

    # 初始化回收站管理器
    trash_manager = TrashManager(serve_dir)

    # 初始化管理员处理器
    admin_handler = AdminHandler(user_store)

    # 检查用户文件（仅 JSON 存储时）
    if not config.use_database and not config.get_users_file_path().exists():
        logger.warning(f"用户文件不存在: {config.get_users_file_path()}")
        logger.info("请先运行 'python -m file_server user create' 创建用户")
        return

    if not serve_dir.exists():
        logger.error(f"文件服务目录不存在: {serve_dir}")
        return

    # 配置请求处理器
    SecureHTTPRequestHandler.authenticator = authenticator
    SecureHTTPRequestHandler.session_manager = session_manager
    SecureHTTPRequestHandler.config = config
    SecureHTTPRequestHandler.directory = str(serve_dir)
    SecureHTTPRequestHandler.share_manager = share_manager
    SecureHTTPRequestHandler.trash_manager = trash_manager
    SecureHTTPRequestHandler.user_store = user_store
    SecureHTTPRequestHandler.admin_handler = admin_handler

    # 打印启动信息
    _print_startup_info(config, serve_dir)

    # 配置 SSL（如果启用）- 在切换工作目录之前完成
    ssl_context = None
    if config.use_https:
        # 使用新的 SSLContext API（兼容 Python 3.12+）
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_context.load_cert_chain(
            certfile=str(config.ssl_cert),
            keyfile=str(config.ssl_key)
        )

    # 切换工作目录
    os.chdir(serve_dir)

    # 启动服务器（多线程模式）
    max_workers = config.workers if config.workers > 0 else (os.cpu_count() or 2) * 2
    httpd = ThreadPoolTCPServer((config.host, config.port), SecureHTTPRequestHandler,
                               max_workers=max_workers)
    if config.workers > 0:
        logger.info(f"工作线程数: {max_workers}（手动指定）")
    else:
        logger.info(f"工作线程数: {max_workers}（自动，CPU 核数 x 2）")

    # 应用 SSL 上下文（如果有）
    if ssl_context:
        httpd.socket = ssl_context.wrap_socket(
            httpd.socket,
            server_side=True
        )

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("服务器已停止")
    finally:
        httpd.server_close()


def _print_startup_info(config: ServerConfig, serve_dir: Path) -> None:
    """打印启动信息"""
    protocol = "https" if config.use_https else "http"
    logger.info(f"文件服务目录: {serve_dir.absolute()}")
    logger.info(f"配置文件目录: {config.config_dir or '当前目录'}")
    if config.use_database:
        logger.info(f"用户存储: 数据库 ({config.database.type})")
    else:
        logger.info(f"用户存储: 文件 ({config.get_users_file_path()})")
    logger.info(f"访问地址: {protocol}://localhost:{config.port}")

    # 获取局域网 IP
    try:
        lan_ip = _get_lan_ip()
        logger.info(f"局域网访问: {protocol}://{lan_ip}:{config.port}")
    except Exception as e:
        logger.warning(f"获取局域网IP失败: {e}")

    logger.info("按 Ctrl+C 停止服务器")
    logger.info("=" * 60)


def _get_lan_ip() -> str:
    """获取局域网 IP

    使用 UDP socket 连接方式获取真实网络接口 IP，
    这种方式在 Windows 和 Linux 上都可靠。
    注意：不会实际发送数据，只是获取 socket 绑定的本地地址。
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # 连接到公共 DNS 服务器，不会实际发送数据
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        # 回退：尝试从主机名解析
        hostname = socket.gethostname()
        return socket.gethostbyname(hostname)
