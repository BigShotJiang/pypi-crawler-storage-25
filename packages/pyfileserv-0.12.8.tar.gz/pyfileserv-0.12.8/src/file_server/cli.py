"""命令行工具 - 服务器启动和用户管理"""
import argparse
import getpass
import logging
import socket
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Tuple, Optional

from .config import ServerConfig, get_default_config_yaml, MIN_PASSWORD_LENGTH
from .core.auth import PasswordHasher, UserStore
from .server import run_server


def _get_version() -> str:
    """获取版本号"""
    try:
        from importlib.metadata import version
        return version("pyfileserv")
    except Exception :
        from . import __version__
        return __version__

def _validate_password(password: str, confirm_password: str = None) -> Tuple[bool, Optional[str]]:
    """验证密码强度和一致性

    Args:
        password: 密码
        confirm_password: 确认密码 (可选)

    Returns:
        (是否有效, 错误信息)
    """
    if len(password) < MIN_PASSWORD_LENGTH:
        return False, f"密码长度至少为{MIN_PASSWORD_LENGTH}位"

    if confirm_password is not None and password != confirm_password:
        return False, "两次密码不一致"

    return True, None


def _prompt_password(confirm: bool = True) -> tuple[None, str | None] | tuple[str, None]:
    """交互式密码输入

    Args:
        confirm: 是否需要确认密码

    Returns:
        (密码, 错误信息) - 密码为 None 时表示输入失败
    """
    password = getpass.getpass("密码: ")
    valid, error = _validate_password(password)
    if not valid:
        return None, error

    if confirm:
        confirm_pwd = getpass.getpass("确认密码: ")
        valid, error = _validate_password(password, confirm_pwd)
        if not valid:
            return None, error

    return password, None


def _get_user_store(config: ServerConfig):
    """获取用户存储实例"""
    if config.use_database:
        from .db import DatabaseConnection, DatabaseUserStore
        db = DatabaseConnection(
            host=config.database.host,
            port=config.database.port,
            database=config.database.database,
            username=config.database.username,
            password=config.database.password,
        )
        db.initialize_tables()
        return DatabaseUserStore(db)
    else:
        return UserStore(config.get_users_file_path())


def _load_config_from_args() -> Tuple[ServerConfig, argparse.Namespace]:
    """从命令行参数加载配置，同时处理全局配置参数和子命令

    Returns:
        (config, args)
    """
    # 第一步：提取全局配置参数
    config_file = None
    config_dir = None
    remaining_argv = []

    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg in ('-f', '--config-file'):
            if i + 1 < len(sys.argv):
                config_file = sys.argv[i + 1]
                i += 2
            else:
                i += 1
        elif arg.startswith('--config-file='):
            config_file = arg[14:]
            i += 1
        elif arg in ('-c', '--config-dir'):
            if i + 1 < len(sys.argv):
                config_dir = sys.argv[i + 1]
                i += 2
            else:
                i += 1
        elif arg.startswith('--config-dir='):
            config_dir = arg[13:]
            i += 1
        else:
            remaining_argv.append(arg)
            i += 1

    # 第二步：解析剩余参数
    parser = argparse.ArgumentParser(
        description='带登录认证的文件服务器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m file_server                    # 启动 HTTP 服务器
  python -m file_server -p 9000            # 指定端口
  python -m file_server user create        # 创建用户
  python -m file_server user list          # 列出用户
  python -m file_server cert generate      # 生成自签名证书
  python -m file_server config init        # 生成默认配置文件
  python -m file_server -f config.yml user list  # 使用配置文件
  python -m file_server --ssl-cert cert.pem --ssl-key key.pem  # 启动 HTTPS
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='子命令')

    # 服务器命令 (默认)
    parser.add_argument('-p', '--port', type=int, default=8000,
                        help='端口号 (默认: 8000)')
    parser.add_argument('-d', '--directory', default='.',
                        help='文件服务目录')
    parser.add_argument('-s', '--static-dir',
                        help='静态文件目录')
    parser.add_argument('--ssl-cert',
                        help='SSL 证书文件路径 (启用 HTTPS)')
    parser.add_argument('--ssl-key',
                        help='SSL 私钥文件路径 (启用 HTTPS)')
    parser.add_argument('--ip-whitelist',
                        help='IP 白名单（逗号分隔，支持单个 IP 或 CIDR）')
    parser.add_argument('--ip-blacklist',
                        help='IP 黑名单（逗号分隔，支持单个 IP 或 CIDR）')
    parser.add_argument('-l', '--log-file',
                        help='日志文件路径（默认: serve_dir/pyfileserv.log）')
    parser.add_argument('-w', '--workers', type=int, default=0,
                        help='工作线程数（0 = CPU 核数 x 2）')
    parser.add_argument('-v', '--version', action='version',
                        version=f'%(prog)s {_get_version()}')

    # 配置管理命令
    config_parser = subparsers.add_parser('config', help='配置管理')
    config_subparsers = config_parser.add_subparsers(dest='config_command')

    # config init
    config_init_parser = config_subparsers.add_parser('init', help='生成默认配置文件')
    config_init_parser.add_argument('-o', '--output', default='config.yml',
                                    help='输出文件路径 (默认: config.yml)')

    # 证书管理命令
    cert_parser = subparsers.add_parser('cert', help='证书管理')
    cert_subparsers = cert_parser.add_subparsers(dest='cert_command')

    # cert generate
    cert_gen_parser = cert_subparsers.add_parser('generate', help='生成自签名证书')
    cert_gen_parser.add_argument('--cert', default='cert.pem',
                                 help='证书文件路径 (默认: cert.pem)')
    cert_gen_parser.add_argument('--key', default='key.pem',
                                 help='私钥文件路径 (默认: key.pem)')
    cert_gen_parser.add_argument('--cn',
                                 help='通用名称 (默认: 主机名)')
    cert_gen_parser.add_argument('--days', type=int, default=365,
                                 help='有效期天数 (默认: 365)')

    # 用户管理命令
    user_parser = subparsers.add_parser('user', help='用户管理')
    user_subparsers = user_parser.add_subparsers(dest='user_command')

    # user create
    create_parser = user_subparsers.add_parser('create', help='创建用户')
    create_parser.add_argument('-u', '--username', help='用户名')

    # user list
    user_subparsers.add_parser('list', help='列出用户')

    # user delete
    delete_parser = user_subparsers.add_parser('delete', help='删除用户')
    delete_parser.add_argument('-u', '--username', help='用户名')

    # user passwd
    passwd_parser = user_subparsers.add_parser('passwd', help='修改密码')
    passwd_parser.add_argument('-u', '--username', help='用户名')

    # user admin
    admin_parser = user_subparsers.add_parser('admin', help='设置管理员状态')
    admin_parser.add_argument('-u', '--username', help='用户名')

    # 解析参数
    if remaining_argv:
        args = parser.parse_args(remaining_argv)
    else:
        args = parser.parse_args([])
        args.command = None

    # 将全局配置参数添加到 args
    args.config_file = config_file
    args.config_dir = config_dir

    # 加载配置
    config = ServerConfig()
    if config_file:
        config_path = Path(config_file)
    elif config_dir:
        config.config_dir = Path(config_dir)
        config_path = config.get_config_file_path()
    else:
        # 检查默认配置文件位置
        config_path = config.get_config_file_path()
    # 从环境变量加载

    if config_path and config_path.exists():
        config = ServerConfig.from_yaml(config_path)
        config.config_dir = config_path.parent
    config.load_from_env()

    # 命令行参数覆盖（仅 serve 命令）
    if args.command is None:
        if hasattr(args, 'port') and args.port != 8000:
            config.port = args.port
        if hasattr(args, 'directory') and args.directory != '.':
            config.serve_dir = Path(args.directory)
        if hasattr(args, 'static_dir') and args.static_dir:
            config.static_dir = Path(args.static_dir)
        if hasattr(args, 'ssl_cert') and args.ssl_cert:
            config.ssl_cert = Path(args.ssl_cert)
        if hasattr(args, 'ssl_key') and args.ssl_key:
            config.ssl_key = Path(args.ssl_key)
        if hasattr(args, 'ip_whitelist') and args.ip_whitelist:
            config.ip_whitelist = [ip.strip() for ip in args.ip_whitelist.split(',') if ip.strip()]
        if hasattr(args, 'ip_blacklist') and args.ip_blacklist:
            config.ip_blacklist = [ip.strip() for ip in args.ip_blacklist.split(',') if ip.strip()]
        if hasattr(args, 'log_file') and args.log_file:
            config.log_file = Path(args.log_file)
        if hasattr(args, 'workers') and args.workers != 0:
            config.workers = args.workers
        if config_dir:
            config.config_dir = Path(config_dir)

    return config, args


def _setup_file_logging(config) -> None:
    """配置日志文件输出"""
    if config.log_file:
        log_path = Path(config.log_file)
    else:
        serve_dir = config.serve_dir or Path.cwd()
        log_path = serve_dir / 'pyfileserv.log'

    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(str(log_path), encoding='utf-8')
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    logging.getLogger().addHandler(fh)
    logging.getLogger(__name__).info("日志文件: %s", log_path)


def main() -> None:
    """主入口"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    config, args = _load_config_from_args()

    if args.command == 'config':
        if not args.config_command:
            print("错误: 请指定配置命令 (init)")
            print("使用 --help 查看帮助")
            return
        _handle_config_command(args)
    elif args.command == 'user':
        if not args.user_command:
            print("错误: 请指定用户命令 (create/list/delete/passwd/admin)")
            print("使用 --help 查看帮助")
            return
        _handle_user_command(args, config)
    elif args.command == 'cert':
        if not args.cert_command:
            print("错误: 请指定证书命令 (generate)")
            print("使用 --help 查看帮助")
            return
        _handle_cert_command(args)
    elif args.command is None:
        _setup_file_logging(config)
        run_server(config)
    else:
        # 显示帮助
        parser = argparse.ArgumentParser(
            description='带登录认证的文件服务器',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        parser.print_help()


def _handle_config_command(args) -> None:
    """处理配置管理命令"""
    if args.config_command == 'init':
        output_path = Path(args.output)
        if output_path.exists():
            print(f"错误: 文件已存在: {output_path}")
            return

        content = get_default_config_yaml()
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"配置文件已生成: {output_path}")
        print(f"\n使用方法:")
        print(f"  python -m file_server -f {output_path}")
        print(f"\n或者编辑配置文件后:")
        print(f"  python -m file_server")
    else:
        print("未知配置命令，使用 --help 查看帮助")


def _handle_user_command(args, config: ServerConfig) -> None:
    """处理用户管理命令"""
    user_store = _get_user_store(config)
    hasher = PasswordHasher()

    if args.user_command == 'create':
        _create_user(user_store, hasher, args.username)
    elif args.user_command == 'list':
        _list_users(user_store)
    elif args.user_command == 'delete':
        _delete_user(user_store, args.username)
    elif args.user_command == 'passwd':
        _change_password(user_store, hasher, args.username)
    elif args.user_command == 'admin':
        _set_admin_status(user_store, args.username)
    else:
        print("未知用户命令，使用 --help 查看帮助")


def _create_user(user_store, hasher: PasswordHasher,
                 username: str = None) -> None:
    """创建用户"""
    if not username:
        username = input("用户名: ").strip()

    if not username:
        print("错误: 用户名不能为空")
        return

    if user_store.user_exists(username):
        print(f"错误: 用户 '{username}' 已存在")
        return

    password, error = _prompt_password()
    if error:
        print(f"错误: {error}")
        return

    # 询问是否为管理员
    is_admin_input = input("是否为管理员? (yes/no, 默认no): ").strip().lower()
    is_admin = is_admin_input in ['yes', 'y']

    password_hash = hasher.hash_password(password)
    user_store.add_user(username, password_hash, is_admin)
    admin_text = " [管理员]" if is_admin else ""
    print(f"用户 '{username}' 创建成功{admin_text}")


def _list_users(user_store) -> None:
    """列出用户"""
    users = user_store.load_users()
    if not users:
        print("暂无用户")
        return

    print("\n用户列表:")
    for username, data in users.items():
        is_admin = data.get('is_admin', False)
        admin_mark = " [管理员]" if is_admin else ""
        print(f"  - {username}{admin_mark}")


def _delete_user(user_store, username: str = None) -> None:
    """删除用户"""
    if not username:
        username = input("要删除的用户名: ").strip()

    if not user_store.user_exists(username):
        print(f"错误: 用户 '{username}' 不存在")
        return

    confirm = input(f"确认删除用户 '{username}'? (yes/no): ").strip().lower()
    if confirm == 'yes':
        user_store.delete_user(username)
        print(f"用户 '{username}' 已删除")
    else:
        print("已取消")


def _change_password(user_store, hasher: PasswordHasher,
                     username: str = None) -> None:
    """修改密码"""
    if not username:
        username = input("用户名: ").strip()

    user_data = user_store.get_user(username)
    if not user_data:
        print(f"错误: 用户 '{username}' 不存在")
        return

    old_password = getpass.getpass("原密码: ")
    if not hasher.verify_password(old_password, user_data['password']):
        print("错误: 原密码不正确")
        return

    new_password, error = _prompt_password()
    if error:
        print(f"错误: {error}")
        return

    user_store.update_password(username, hasher.hash_password(new_password))
    print("密码修改成功")


def _set_admin_status(user_store, username: str = None) -> None:
    """设置用户管理员状态"""
    if not username:
        username = input("用户名: ").strip()

    if not user_store.user_exists(username):
        print(f"错误: 用户 '{username}' 不存在")
        return

    # 获取当前状态
    user_data = user_store.get_user(username)
    current_is_admin = user_data.get('is_admin', False)
    status_text = "是" if current_is_admin else "否"
    print(f"当前管理员状态: {status_text}")

    # 询问新状态
    new_status_input = input("设置为管理员? (yes/no): ").strip().lower()
    if new_status_input in ['yes', 'y']:
        new_status = True
    elif new_status_input in ['no', 'n']:
        new_status = False
    else:
        print("错误: 请输入 yes 或 no")
        return

    if new_status == current_is_admin:
        print("管理员状态未改变")
        return

    success = user_store.set_admin_status(username, new_status)
    if success:
        status_text = "管理员" if new_status else "普通用户"
        print(f"用户 '{username}' 已设置为{status_text}")
    else:
        print("设置失败")


def _handle_cert_command(args) -> None:
    """处理证书管理命令"""
    if args.cert_command == 'generate':
        generate_self_signed_cert(
            cert_path=Path(args.cert),
            key_path=Path(args.key),
            common_name=args.cn,
            valid_days=args.days
        )
    else:
        print("未知证书命令，使用 --help 查看帮助")


def generate_self_signed_cert(cert_path: Path, key_path: Path,
                               common_name: str = None,
                               valid_days: int = 365) -> None:
    """生成自签名 SSL 证书

    Args:
        cert_path: 证书文件路径
        key_path: 私钥文件路径
        common_name: 通用名称（默认使用主机名）
        valid_days: 证书有效期（天）
    """
    try:
        import ipaddress
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
    except ImportError:
        print("错误: 需要安装 cryptography 库")
        print("请运行: pip install cryptography")
        return

    if common_name is None:
        common_name = socket.gethostname()

    print(f"生成自签名证书...")
    print(f"  通用名称 (CN): {common_name}")
    print(f"  有效期: {valid_days} 天")
    print(f"  证书文件: {cert_path}")
    print(f"  私钥文件: {key_path}")

    # 生成私钥
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )

    # 生成证书主题
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "CN"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, "Local"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "pyfileserv"),
        x509.NameAttribute(NameOID.COMMON_NAME, common_name),
    ])

    # 构建证书
    cert = x509.CertificateBuilder().subject_name(
        subject
    ).issuer_name(
        issuer
    ).public_key(
        private_key.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.utcnow()
    ).not_valid_after(
        datetime.utcnow() + timedelta(days=valid_days)
    ).add_extension(
        x509.SubjectAlternativeName([
            x509.DNSName(common_name),
            x509.DNSName("localhost"),
            x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        ]),
        critical=False,
    ).sign(private_key, hashes.SHA256())

    # 保存私钥
    with open(key_path, "wb") as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))

    # 保存证书
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(encoding=serialization.Encoding.PEM))

    # 设置文件权限（仅用户可读）
    try:
        key_path.chmod(0o600)
        cert_path.chmod(0o644)
    except OSError:
        pass  # Windows 或权限不足时忽略

    print("\n证书生成成功！")
    print(f"\n使用以下命令启动 HTTPS 服务器:")
    print(f"  python -m file_server --ssl-cert {cert_path} --ssl-key {key_path}")


if __name__ == "__main__":
    main()
