"""测试 file_server.handle.preview PreviewMixin 预览分发逻辑"""
import sys
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestPreviewDispatch:
    """测试预览请求分发到正确的处理器方法"""

    @pytest.fixture
    def handler(self):
        """创建一个模拟的 handler 实例"""
        # 动态组装一个类，包含 PreviewMixin 和必要的依赖
        from file_server.handle.preview import PreviewMixin

        class MockHandler(PreviewMixin):
            def __init__(self):
                self.directory = None
                self.path = '/preview/'
                self.config = None
                self.session_manager = None
                self.user_store = None
                self._wfile = Mock()
                self._sent_response = None

            def is_authenticated(self):
                return True

            def get_current_username(self):
                return 'testuser'

            def send_error(self, code, msg):
                self._sent_response = ('error', code, msg)

            def _send_html_response(self, html):
                self._sent_response = ('html', html)

            def _serve_raw_file(self, file_path):
                self._sent_response = ('raw', str(file_path))

        return MockHandler()

    def _setup_handler(self, handler, filename, directory):
        """设置 handler 来模拟预览请求"""
        handler.directory = str(directory)
        handler.path = f'/preview/{filename}'

    def test_dispatch_to_image_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            img = dir_path / 'photo.jpg'
            img.write_bytes(b'fake-jpeg')
            self._setup_handler(handler, 'photo.jpg', dir_path)

            with patch.object(handler, '_handle_image_preview') as mock_img:
                handler._handle_preview()
                mock_img.assert_called_once()

    def test_dispatch_to_video_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            vid = dir_path / 'movie.mp4'
            vid.write_bytes(b'fake-mp4')
            self._setup_handler(handler, 'movie.mp4', dir_path)

            with patch.object(handler, '_handle_video_preview') as mock_vid:
                handler._handle_preview()
                mock_vid.assert_called_once()

    def test_dispatch_to_audio_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            aud = dir_path / 'song.mp3'
            aud.write_bytes(b'fake-mp3')
            self._setup_handler(handler, 'song.mp3', dir_path)

            with patch.object(handler, '_handle_audio_preview') as mock_aud:
                handler._handle_preview()
                mock_aud.assert_called_once()

    def test_dispatch_to_pdf_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'doc.pdf'
            f.write_bytes(b'fake-pdf')
            self._setup_handler(handler, 'doc.pdf', dir_path)

            with patch.object(handler, '_handle_pdf_preview') as mock_pdf:
                handler._handle_preview()
                mock_pdf.assert_called_once()

    def test_dispatch_to_markdown_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'README.md'
            f.write_bytes(b'# Hello')
            self._setup_handler(handler, 'README.md', dir_path)

            with patch.object(handler, '_handle_markdown_preview') as mock_md:
                handler._handle_preview()
                mock_md.assert_called_once()

    def test_dispatch_to_xmind_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'mindmap.xmind'
            f.write_bytes(b'fake-xmind')
            self._setup_handler(handler, 'mindmap.xmind', dir_path)

            with patch.object(handler, '_handle_xmind_preview') as mock_xm:
                handler._handle_preview()
                mock_xm.assert_called_once()

    def test_dispatch_to_docx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'report.docx'
            f.write_bytes(b'fake-docx')
            self._setup_handler(handler, 'report.docx', dir_path)

            with patch.object(handler, '_handle_docx_preview') as mock_docx:
                handler._handle_preview()
                mock_docx.assert_called_once()

    def test_dispatch_to_xlsx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'data.xlsx'
            f.write_bytes(b'fake-xlsx')
            self._setup_handler(handler, 'data.xlsx', dir_path)

            with patch.object(handler, '_handle_xlsx_preview') as mock_xlsx:
                handler._handle_preview()
                mock_xlsx.assert_called_once()

    def test_dispatch_to_pptx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'slides.pptx'
            f.write_bytes(b'fake-pptx')
            self._setup_handler(handler, 'slides.pptx', dir_path)

            with patch.object(handler, '_handle_pptx_preview') as mock_pptx:
                handler._handle_preview()
                mock_pptx.assert_called_once()

    def test_dispatch_to_json_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'config.json'
            f.write_bytes(b'{"key": "value"}')
            self._setup_handler(handler, 'config.json', dir_path)

            with patch.object(handler, '_handle_json_preview') as mock_json:
                handler._handle_preview()
                mock_json.assert_called_once()

    def test_dispatch_to_text_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'script.py'
            f.write_bytes(b'print("hello")')
            self._setup_handler(handler, 'script.py', dir_path)

            with patch.object(handler, '_handle_text_preview') as mock_text:
                handler._handle_preview()
                mock_text.assert_called_once()

    def test_dispatch_to_html_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'test.html'
            f.write_bytes(b'<h1>Test</h1>')
            self._setup_handler(handler, 'test.html', dir_path)

            with patch.object(handler, '_handle_html_preview') as mock_html:
                handler._handle_preview()
                mock_html.assert_called_once()

    def test_dispatch_other_type_raw_serve(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'archive.zip'
            f.write_bytes(b'fake-zip')
            self._setup_handler(handler, 'archive.zip', dir_path)

            handler._handle_preview()
            assert handler._sent_response is not None
            assert handler._sent_response[0] == 'raw'

    def test_unauthenticated_rejected(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'test.txt'
            f.write_bytes(b'hello')
            self._setup_handler(handler, 'test.txt', dir_path)
            handler.is_authenticated = lambda: False

            handler._handle_preview()
            assert handler._sent_response == ('error', 403, 'Forbidden')

    def test_path_traversal_rejected(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            handler.directory = str(dir_path)
            handler.path = '/preview/../../../etc/passwd'

            handler._handle_preview()
            assert handler._sent_response == ('error', 403, 'Forbidden')

    def test_nonexistent_file_returns_404(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            handler.directory = str(dir_path)
            handler.path = '/preview/nonexistent.txt'

            handler._handle_preview()
            assert handler._sent_response == ('error', 404, 'File not found')


class TestMediaPreviewDispatch:
    """测试 _handle_media_preview 通用方法"""

    @pytest.fixture
    def handler(self):
        from file_server.handle.preview import PreviewMixin

        class MockHandler(PreviewMixin):
            def __init__(self):
                self.directory = None
                self.config = None
                self.session_manager = None
                self.user_store = None
                self._html = None

            def _send_html_response(self, html):
                self._html = html

        return MockHandler()

    def test_media_preview_collects_sibling_files(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            (dir_path / 'photo1.jpg').write_bytes(b'')
            (dir_path / 'photo2.jpg').write_bytes(b'')
            (dir_path / 'not_an_image.txt').write_bytes(b'')
            handler.directory = str(dir_path)

            def render_func(username, file_path, file_name, urls, index, is_admin):
                assert len(urls) == 2
                assert 'photo1.jpg' in urls[0]
                assert 'photo2.jpg' in urls[1]
                assert urls
                return '<html>test</html>'

            handler._handle_media_preview('user', 'photo1.jpg', 'photo1.jpg',
                                          'image', render_func)
            assert handler._html == '<html>test</html>'

    def test_media_preview_gets_current_index(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            (dir_path / 'a.jpg').write_bytes(b'')
            (dir_path / 'b.jpg').write_bytes(b'')
            (dir_path / 'c.jpg').write_bytes(b'')
            handler.directory = str(dir_path)

            def render_func(username, file_path, file_name, urls, index, is_admin):
                assert index == 1  # b.jpg is the second image
                return '<html>ok</html>'

            handler._handle_media_preview('user', 'b.jpg', 'b.jpg',
                                          'image', render_func)
            assert handler._html == '<html>ok</html>'


# ——— EDDX 转换器单元测试 ———
import xml.etree.ElementTree as ET
from file_server.handle.preview import (
    _eddx_eval_cp_value,
    _eddx_parse_color,
    _eddx_shape_bounds,
    _eddx_boundary_in_direction,
    _eddx_get_cpoint_pos,
    _eddx_shape_to_svg,
    _eddx_page_to_svg,
    _EDDX_SCALE,
)


class TestEddxEvalCpValue:
    """测试 _eddx_eval_cp_value — R/M 属性解析"""

    def test_absolute_value_no_rm(self):
        el = ET.fromstring('<X V="50"/>')
        assert _eddx_eval_cp_value(el, 100, 44) == 50.0

    def test_r_with_m1_width(self):
        el = ET.fromstring('<X V="50" R="0.5" M="1"/>')
        assert _eddx_eval_cp_value(el, 100, 44) == 50.0  # 100 * 0.5

    def test_r_with_m2_height(self):
        el = ET.fromstring('<Y V="22" R="0.5" M="2"/>')
        assert _eddx_eval_cp_value(el, 100, 44) == 22.0  # 44 * 0.5

    def test_r_full_width(self):
        el = ET.fromstring('<X V="100" R="1" M="1"/>')
        assert _eddx_eval_cp_value(el, 120, 60) == 120.0

    def test_r_full_height(self):
        el = ET.fromstring('<Y V="60" R="1" M="2"/>')
        assert _eddx_eval_cp_value(el, 120, 60) == 60.0

    def test_no_r_has_m_returns_v(self):
        el = ET.fromstring('<X V="42" M="1"/>')
        assert _eddx_eval_cp_value(el, 100, 44) == 42.0

    def test_default_zero(self):
        el = ET.fromstring('<X/>')
        assert _eddx_eval_cp_value(el, 100, 44) == 0.0


class TestEddxParseColor:
    """测试 _eddx_parse_color — ARGB → RGB 转换"""

    def test_full_argb_to_rgb(self):
        assert _eddx_parse_color('#ff191919') == '#191919'

    def test_argb_white(self):
        assert _eddx_parse_color('#ffffffff') == '#ffffff'

    def test_short_rgb_unchanged(self):
        assert _eddx_parse_color('#333333') == '#333333'

    def test_empty_returns_default(self):
        assert _eddx_parse_color('') == '#333333'

    def test_none_returns_default(self):
        assert _eddx_parse_color(None) == '#333333'


class TestEddxShapeBounds:
    """测试 _eddx_shape_bounds — 包围盒计算"""

    def test_simple_rect(self):
        shape_xml = '''
        <Shape Type="Shape" ID="1" NameU="Process">
            <Transform>
                <Width V="100"/>
                <Height V="44"/>
                <GPinX V="439.26"/>
                <GPinY V="355.701"/>
                <LocPinX V="50" R="0.5" M="1"/>
                <LocPinY V="22" R="0.5" M="2"/>
            </Transform>
        </Shape>'''
        shape = ET.fromstring(shape_xml)
        bounds = _eddx_shape_bounds(shape, 4.0)
        assert bounds is not None
        x, y, w, h = bounds
        assert pytest.approx(x) == (439.26 - 50) * 4  # LocPin = 100*0.5=50
        assert pytest.approx(y) == (355.701 - 22) * 4  # LocPin = 44*0.5=22
        assert w == 400
        assert h == 176

    def test_shape_without_transform(self):
        shape = ET.fromstring('<Shape Type="Shape" ID="1"/>')
        assert _eddx_shape_bounds(shape, 4.0) is None

    def test_absolute_locpin(self):
        shape_xml = '''
        <Shape Type="Shape" ID="2">
            <Transform>
                <Width V="200"/>
                <Height V="100"/>
                <GPinX V="0"/>
                <GPinY V="0"/>
                <LocPinX V="0"/>
                <LocPinY V="0"/>
            </Transform>
        </Shape>'''
        shape = ET.fromstring(shape_xml)
        bounds = _eddx_shape_bounds(shape, 2.0)
        assert bounds == (0, 0, 400, 200)


class TestEddxBoundaryInDirection:
    """测试 _eddx_boundary_in_direction — 边界交点计算"""

    def _make_shape(self, w_mm, h_mm, gx, gy, name_u='Process'):
        xml = f'''
        <Shape Type="Shape" ID="1" NameU="{name_u}">
            <Transform>
                <Width V="{w_mm}"/>
                <Height V="{h_mm}"/>
                <GPinX V="{gx}"/>
                <GPinY V="{gy}"/>
                <LocPinX V="{w_mm/2}" R="0.5" M="1"/>
                <LocPinY V="{h_mm/2}" R="0.5" M="2"/>
            </Transform>
        </Shape>'''
        return ET.fromstring(xml)

    def test_rect_right_edge(self):
        s = self._make_shape(100, 60, 200, 150)
        x, y = _eddx_boundary_in_direction(s, 4.0, 400, 0)
        # center at (200,150)*4=(800,600), width=400 → right edge at 800+200=1000
        assert pytest.approx(x, abs=1) == 1000
        assert pytest.approx(y, abs=1) == 600

    def test_rect_top_edge(self):
        s = self._make_shape(100, 60, 200, 150)
        x, y = _eddx_boundary_in_direction(s, 4.0, 0, -400)
        assert pytest.approx(x, abs=1) == 800
        assert pytest.approx(y, abs=1) == 480  # 600 - 120

    def test_rect_diagonal(self):
        s = self._make_shape(100, 60, 200, 150)
        x, y = _eddx_boundary_in_direction(s, 4.0, 200, 120)
        # dx=200, dy=120: tx=200/200=1.0, ty=120/120=1.0 → t=1.0
        assert pytest.approx(x, abs=2) == 1000
        assert pytest.approx(y, abs=2) == 720

    def test_diamond_boundary(self):
        s = self._make_shape(100, 100, 200, 200, 'Decision')
        # center at (800,800), half_w=half_h=200
        x, y = _eddx_boundary_in_direction(s, 4.0, 200, 0)
        # t = 1/(200/200 + 0/200) = 1
        assert pytest.approx(x, abs=1) == 1000  # 800+200
        assert pytest.approx(y, abs=1) == 800

    def test_diamond_diagonal(self):
        s = self._make_shape(100, 100, 200, 200, 'Decision')
        x, y = _eddx_boundary_in_direction(s, 4.0, 200, 200)
        # t = 1/(200/200 + 200/200) = 0.5
        # So: 800 + 200*0.5 = 900, 800 + 200*0.5 = 900
        assert pytest.approx(x, abs=1) == 900
        assert pytest.approx(y, abs=1) == 900

    def test_zero_direction_returns_center(self):
        s = self._make_shape(100, 60, 200, 150)
        x, y = _eddx_boundary_in_direction(s, 4.0, 0, 0)
        assert pytest.approx(x, abs=0.1) == 800
        assert pytest.approx(y, abs=0.1) == 600


class TestEddxGetCpointPos:
    """测试 _eddx_get_cpoint_pos — CPoint 查找"""

    def _make_shape_with_cpoints(self, cpoints_xml):
        xml = f'''
        <Shape Type="Shape" ID="1" NameU="Process">
            <Transform>
                <Width V="100"/>
                <Height V="100"/>
                <GPinX V="100"/>
                <GPinY V="100"/>
                <LocPinX V="50" R="0.5" M="1"/>
                <LocPinY V="50" R="0.5" M="2"/>
            </Transform>
            <CPoints>
                {cpoints_xml}
            </CPoints>
        </Shape>'''
        return ET.fromstring(xml)

    def test_find_by_id(self):
        s = self._make_shape_with_cpoints('''
            <CPoint Name="Pt1" ID="1"><X V="0"/><Y V="0"/></CPoint>
            <CPoint Name="Pt2" ID="2"><X V="100" R="1" M="1"/><Y V="50" R="0.5" M="2"/></CPoint>
        ''')
        pt = _eddx_get_cpoint_pos(s, '1', 4.0)
        assert pt == (200, 200)  # sx=200,sy=200 + 0,0

    def test_find_by_name(self):
        s = self._make_shape_with_cpoints('''
            <CPoint Name="Pt2" ID="2"><X V="100" R="1" M="1"/><Y V="50" R="0.5" M="2"/></CPoint>
        ''')
        pt = _eddx_get_cpoint_pos(s, 'Pt2', 4.0)
        assert pytest.approx(pt[0]) == 200 + 400  # 100*1*4
        assert pytest.approx(pt[1]) == 200 + 200  # 100*0.5*4

    def test_not_found_returns_none(self):
        s = self._make_shape_with_cpoints('''
            <CPoint Name="Pt1" ID="1"><X V="0"/><Y V="0"/></CPoint>
        ''')
        assert _eddx_get_cpoint_pos(s, 'Pt99', 4.0) is None

    def test_no_cpoints_returns_none(self):
        s = self._make_shape_with_cpoints('')
        assert _eddx_get_cpoint_pos(s, 'Pt1', 4.0) is None


class TestEddxShapeToSvg:
    """测试 _eddx_shape_to_svg — 形状 → SVG 元素"""

    def _make_shape_xml(self, name_u, w=100, h=44, fill='#ffffffff', stroke='#ff101843', text=''):
        text_block = ''
        if text:
            text_block = f'''
            <Texts>
                <Text ID="1" Name="T1">
                    <TextBlock>
                        <Color V="#ff191919"/>
                        <Character IX="0" Family="Microsoft YaHei" Size="10" Color="#191919"/>
                        <Paragraph IX="0" SpLine="100" Align="4"/>
                        <Text>
                            <pp PX="0" CX="0"><tp CX="0">{text}</tp></pp>
                        </Text>
                    </TextBlock>
                </Text>
            </Texts>'''
        xml = f'''
        <Shape Type="Shape" ID="1" NameU="{name_u}">
            <Transform>
                <Width V="{w}"/>
                <Height V="{h}"/>
                <GPinX V="100"/>
                <GPinY V="100"/>
                <LocPinX V="{w/2}" R="0.5" M="1"/>
                <LocPinY V="{h/2}" R="0.5" M="2"/>
                <Angle V="0"/>
            </Transform>
            <ShapeFormat QuickMask="51">
                <FillFormat Type="Solid"><Color V="{fill}"/></FillFormat>
                <LineFormat>
                    <LineWeight V="1"/>
                    <LineFill Type="Solid"><Color V="{stroke}"/></LineFill>
                </LineFormat>
            </ShapeFormat>
            {text_block}
        </Shape>'''
        return ET.fromstring(xml)

    def test_rect_process(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Process'), {}, 4.0)
        assert '<rect ' in svg
        assert 'fill="#ffffff"' in svg
        assert 'stroke="#101843"' in svg

    def test_diamond_decision(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Decision', 100, 100), {}, 4.0)
        assert '<polygon ' in svg
        assert 'points=' in svg

    def test_pill_start_terminator(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Start or Terminator'), {}, 4.0)
        assert '<rect ' in svg
        assert 'rx=' in svg

    def test_document_shape(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Document'), {}, 4.0)
        assert '<path ' in svg

    def test_rect_sub_predefined_process(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Predefined Process'), {}, 4.0)
        assert svg.count('<line ') == 2  # double border lines

    def test_unknown_type_rect_fallback(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('UnknownType'), {}, 4.0)
        assert '<rect ' in svg

    def test_connectline_returns_empty(self):
        xml = '''
        <Shape Type="ConnectLine" ID="1" NameU="ConnectLine">
            <Transform><Width V="0"/><Height V="0"/><GPinX V="0"/><GPinY V="0"/>
            <LocPinX V="0"/><LocPinY V="0"/><Angle V="0"/></Transform>
        </Shape>'''
        s = ET.fromstring(xml)
        assert _eddx_shape_to_svg(s, {}, 4.0) == ''

    def test_text_content(self):
        svg = _eddx_shape_to_svg(self._make_shape_xml('Process', text='测试'), {}, 4.0)
        assert '<foreignObject' in svg
        assert '测试' in svg

    def test_multiline_text(self):
        xml = f'''
        <Shape Type="Shape" ID="1" NameU="Process">
            <Transform>
                <Width V="100"/><Height V="44"/>
                <GPinX V="100"/><GPinY V="100"/>
                <LocPinX V="50" R="0.5" M="1"/>
                <LocPinY V="22" R="0.5" M="2"/>
                <Angle V="0"/>
            </Transform>
            <ShapeFormat QuickMask="51">
                <FillFormat Type="Solid"><Color V="#ffffffff"/></FillFormat>
                <LineFormat><LineWeight V="1"/><LineFill Type="Solid"><Color V="#ff101843"/></LineFill></LineFormat>
            </ShapeFormat>
            <Texts><Text ID="1" Name="T1"><TextBlock>
                <Color V="#ff191919"/><Character IX="0" Family="Microsoft YaHei" Size="10" Color="#191919"/>
                <Text>
                    <pp PX="0" CX="0"><tp CX="0">Line1</tp></pp>
                    <pp PX="0" CX="0"><tp CX="0">Line2</tp></pp>
                </Text>
            </TextBlock></Text></Texts>
        </Shape>'''
        s = ET.fromstring(xml)
        svg = _eddx_shape_to_svg(s, {}, 4.0)
        assert 'Line1<br/>Line2' in svg

    def test_rotation(self):
        xml = f'''
        <Shape Type="Shape" ID="1" NameU="Process">
            <Transform>
                <Width V="100"/><Height V="44"/>
                <GPinX V="100"/><GPinY V="100"/>
                <LocPinX V="50" R="0.5" M="1"/>
                <LocPinY V="22" R="0.5" M="2"/>
                <Angle V="45"/>
            </Transform>
            <ShapeFormat QuickMask="51">
                <FillFormat Type="Solid"><Color V="#ffffffff"/></FillFormat>
                <LineFormat><LineWeight V="1"/><LineFill Type="Solid"><Color V="#ff101843"/></LineFill></LineFormat>
            </ShapeFormat>
        </Shape>'''
        s = ET.fromstring(xml)
        svg = _eddx_shape_to_svg(s, {}, 4.0)
        assert 'transform="rotate(45.0' in svg

    def test_position_with_locpin_offset(self):
        s = self._make_shape_xml('Process', w=100, h=60)
        svg = _eddx_shape_to_svg(s, {}, 4.0)
        # GPinX=100, LocPinX=50 → x = 100-50=50, *4 = 200
        assert 'x="200' in svg or 'x="200.' in svg

    def test_fill_color_stripped_alpha(self):
        s = self._make_shape_xml('Process', fill='#ffccddff')
        svg = _eddx_shape_to_svg(s, {}, 4.0)
        assert 'fill="#ccddff"' in svg


class TestEddxPageToSvg:
    """测试 _eddx_page_to_svg — 完整页面转换"""

    def test_minimal_page(self):
        xml = '''
        <Page ID="100" Type="Page">
            <PageProps>
                <Width V="210"/>
                <Height V="297"/>
            </PageProps>
            <Shape Type="Shape" ID="1" NameU="Process">
                <Transform>
                    <Width V="50"/>
                    <Height V="30"/>
                    <GPinX V="50"/>
                    <GPinY V="50"/>
                    <LocPinX V="25" R="0.5" M="1"/>
                    <LocPinY V="15" R="0.5" M="2"/>
                    <Angle V="0"/>
                </Transform>
                <ShapeFormat>
                    <FillFormat Type="Solid"><Color V="#ffffffff"/></FillFormat>
                    <LineFormat><LineWeight V="1"/><LineFill Type="Solid"><Color V="#ff000000"/></LineFill></LineFormat>
                </ShapeFormat>
            </Shape>
            <Shape Type="Shape" ID="2" NameU="Decision">
                <Transform>
                    <Width V="50"/>
                    <Height V="50"/>
                    <GPinX V="50"/>
                    <GPinY V="100"/>
                    <LocPinX V="25" R="0.5" M="1"/>
                    <LocPinY V="25" R="0.5" M="2"/>
                    <Angle V="0"/>
                </Transform>
                <ShapeFormat>
                    <FillFormat Type="Solid"><Color V="#ffffffff"/></FillFormat>
                    <LineFormat><LineWeight V="1"/><LineFill Type="Solid"><Color V="#ff000000"/></LineFill></LineFormat>
                </ShapeFormat>
            </Shape>
            <Connects>
                <Connect FromShape="10" FromPart="9" ToShape="1" ToPart="3" ToName="Pt3"/>
                <Connect FromShape="10" FromPart="12" ToShape="2" ToPart="1" ToName="Pt1"/>
            </Connects>
        </Page>'''
        svg = _eddx_page_to_svg(xml)
        assert '<svg ' in svg
        assert 'viewBox=' in svg
        assert svg.count('<g id="shape-') == 2
        assert '<line ' in svg  # connector between shapes

    def test_page_viewbox_uses_pageprops(self):
        xml = '''
        <Page ID="1">
            <PageProps><Width V="300"/><Height V="200"/></PageProps>
        </Page>'''
        svg = _eddx_page_to_svg(xml)
        assert 'viewBox="0 0 1200.0 800.0"' in svg  # 300*4, 200*4

    def test_empty_page(self):
        xml = '<Page ID="1"><PageProps><Width V="100"/><Height V="100"/></PageProps></Page>'
        svg = _eddx_page_to_svg(xml)
        assert '<svg ' in svg
        assert '<defs>' in svg  # arrow marker still included


class TestDrawioEddxDispatch:
    """测试 drawio 和 eddx 文件预览分发"""

    @pytest.fixture
    def handler(self):
        from file_server.handle.preview import PreviewMixin

        class MockHandler(PreviewMixin):
            def __init__(self):
                self.directory = None
                self.path = '/preview/'
                self.config = None
                self.session_manager = None
                self.user_store = None
                self._sent_response = None

            def is_authenticated(self):
                return True

            def get_current_username(self):
                return 'testuser'

            def send_error(self, code, msg):
                self._sent_response = ('error', code, msg)

            def _send_html_response(self, html):
                self._sent_response = ('html', html)

            def _serve_raw_file(self, file_path):
                self._sent_response = ('raw', str(file_path))

        return MockHandler()

    def _setup_handler(self, handler, filename, directory):
        handler.directory = str(directory)
        handler.path = f'/preview/{filename}'

    def test_dispatch_to_drawio_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'diagram.drawio'
            f.write_text('<mxfile><diagram name="p1">graph</diagram></mxfile>', encoding='utf-8')
            self._setup_handler(handler, 'diagram.drawio', dir_path)

            with patch.object(handler, '_handle_drawio_preview') as mock_d:
                handler._handle_preview()
                mock_d.assert_called_once()

    def test_dispatch_to_eddx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'chart.eddx'
            f.write_bytes(b'PK\x03\x04')  # ZIP magic bytes
            self._setup_handler(handler, 'chart.eddx', dir_path)

            with patch.object(handler, '_handle_eddx_preview') as mock_e:
                handler._handle_preview()
                mock_e.assert_called_once()
