from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType
from yta_validation.parameter import ParameterValidator


class CPUNumpyArrayFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a numpy array.

    The `.frame` attribute is a `np.ndarray`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.frame.shape[1]
    
    @property
    def height(
        self
    ) -> int:
        return self.frame.shape[0]
    
    @property
    def format(
        self
    ) -> str:
        return str(self.frame.dtype)
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.CPU

    def __init__(
        self,
        frame: 'np.ndarray',
        render_context: 'RenderContext'
    ):
        ParameterValidator.validate_mandatory_numpy_array('frame', frame)

        super().__init__(
            frame = frame,
            render_context = render_context
        )

    def release(
        self
    ):
        pass

    def copy(
        self
    ) -> 'CPUNumpyArrayFrameResource':
        """
        Get a copy of this frame resource.
        """
        copy = self.frame.copy()

        return CPUNumpyArrayFrameResource(
            frame = copy,
            render_context = self.render_context
        )