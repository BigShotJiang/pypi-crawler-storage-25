from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType
from yta_editor_pools.render_target import RenderTarget
from yta_editor_frame.utils import copy_texture
from yta_validation.parameter import ParameterValidator


class RenderTargetFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a render target.

    The `.frame` attribute is a `RenderTarget`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.frame.width
    
    @property
    def height(
        self
    ) -> int:
        return self.frame.height
    
    @property
    def format(
        self
    ) -> str:
        return self.frame.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU_RENDER_TARGET

    def __init__(
        self,
        frame: 'RenderTarget',
        render_context: 'RenderContext'
    ):
        ParameterValidator.validate_mandatory_instance_of('frame', frame, 'RenderTarget')

        super().__init__(
            frame = frame,
            render_context = render_context
        )

    def release(
        self
    ):
        self.render_context.gpu.texture.release(self.frame)

    def copy(
        self
    ) -> 'RenderTargetFrameResource':
        """
        Get a copy of this frame resource.
        """
        texture_copy = copy_texture(
            texture = self.frame.texture,
            render_context = self.render_context,
            do_get_from_pool = True
        )

        copy = RenderTarget(
            context = self.render_context,
            texture = texture_copy
        )

        return RenderTargetFrameResource(
            frame = copy,
            render_context = self.render_context
        )