from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType
from yta_editor_frame.utils import copy_texture
from yta_validation.parameter import ParameterValidator


class GPUTextureFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a texture.

    The `.frame` attribute is a `moderngl.Texture`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.frame.width
    
    @property
    def height(
        self
    ) -> int:
        return self.frame.height
    
    @property
    def format(
        self
    ) -> str:
        return self.frame.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU

    def __init__(
        self,
        frame: 'moderngl.Texture',
        render_context: 'RenderContext'
    ):
        ParameterValidator.validate_mandatory_instance_of('frame', frame, 'Texture')

        super().__init__(
            frame = frame,
            render_context = render_context
        )

    def release(
        self
    ):
        self.render_context.gpu.texture.release(self.frame)

    def copy(
        self
    ) -> 'GPUTextureFrameResource':
        """
        Get a copy of this frame resource.
        """
        copy = copy_texture(
            texture = self.frame,
            render_context = self.render_context,
            do_get_from_pool = True
        )

        return GPUTextureFrameResource(
            frame = copy,
            render_context = self.render_context
        )
        