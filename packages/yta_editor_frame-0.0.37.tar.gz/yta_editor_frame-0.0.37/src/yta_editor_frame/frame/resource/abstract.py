from yta_validation.parameter import ParameterValidator
from abc import abstractmethod, ABC


class FrameResourceABC(ABC):
    """
    Abstract method to represent a frame resource.
    """

    @property
    @abstractmethod
    def width(
        self
    ) -> int:
        """
        The width of the frame resource, in pixels.
        """
        pass

    @property
    @abstractmethod
    def height(
        self
    ) -> int:
        """
        The height of the frame resource, in pixels.
        """
        pass

    @property
    @abstractmethod
    def format(
        self
    ) -> int:
        """
        The format of the frame resource.

        TODO: Is this useful (?)
        """
        pass

    @property
    @abstractmethod
    def type(
        self
    ) -> 'FrameResourceType':
        """
        The type of frame resource.
        """
        pass

    def __init__(
        self,
        # TODO: Set the types
        frame: any,
        render_context: 'RenderContext'
    ):
        ParameterValidator.validate_mandatory_instance_of('render_context', render_context, 'RenderContext')

        # TODO: Set the types
        self.frame: any = frame
        """
        The frame itself.
        """
        self.render_context: 'RenderContext' = render_context
        """
        *For internal use only*

        The `RenderContext` instance, useful to release
        the resources when needed.
        """

    @abstractmethod
    def release(
        self
    ):
        """
        Release the resource, if needed.
        """
        raise NotImplementedError
    
    @abstractmethod
    def copy(
        self
    ):
        """
        Get a copy of this frame resource.
        """
        raise NotImplementedError