"""Deployment event handling."""
