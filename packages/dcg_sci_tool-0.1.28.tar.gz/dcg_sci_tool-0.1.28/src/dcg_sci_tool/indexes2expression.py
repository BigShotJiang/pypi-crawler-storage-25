
def indexes2expression(indexes_list):
    """
    打印将原子索引列表转换为ExpressionSelectionModifier的表达式字符串。
    """
    exprssion_str = "ParticleIndex == " + str(indexes_list[0])
    for i in indexes_list[1:]:
        exprssion_str = exprssion_str + "||" + "ParticleIndex == " + str(i)
    print("ExpressionSelectionModifier的表达式字符串:")
    print(exprssion_str)