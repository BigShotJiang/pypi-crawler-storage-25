
from collections import defaultdict

def split_xyz_by_elements(filename:str):
    """
    按元素组合分割轨迹文件
    
    Args:
        filename (str): 输入的.xyz轨迹文件地址
    
    """
    with open(filename) as f:
        lines = f.readlines()
    
    frames_by_comb = defaultdict(list)  # 按元素组合分组
    i, frame_idx = 0, 0
    
    while i < len(lines):
        if not lines[i].strip():  # 跳过空行
            i += 1
            continue
        
        # 读取原子数
        try:
            n_atoms = int(lines[i].strip())
        except:
            i += 1
            continue
        
        # 获取当前帧的所有元素种类
        elements = set()
        for j in range(2, 2 + n_atoms):
            if i + j < len(lines):
                parts = lines[i + j].strip().split()
                if parts:
                    elements.add(parts[0])
        
        # 排序并转换为字符串作为组合标识
        comb_key = tuple(sorted(elements))
        
        # 保存当前帧
        frame_content = "".join(lines[i:i+2+n_atoms])
        frames_by_comb[comb_key].append(frame_content)
        
        i += 2 + n_atoms
        frame_idx += 1
    
    # 输出结果
    base = filename.rsplit('.', 1)[0]
    print(f"总帧数: {frame_idx}")
    print(f"元素组合数: {len(frames_by_comb)}")
    
    for comb, frames in frames_by_comb.items():
        # 生成文件名
        comb_str = "_".join(comb) or "empty"
        outfile = f"{base}_{comb_str}_{len(frames)}.xyz"
        
        # 写入文件
        with open(outfile, 'w') as f:
            f.write("".join(frames))
        
        print(f"  {comb_str}: {len(frames)}帧 -> {outfile}")

