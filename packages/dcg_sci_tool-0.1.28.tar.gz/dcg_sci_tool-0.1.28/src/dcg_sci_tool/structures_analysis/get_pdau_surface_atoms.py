from ovito.data import CutoffNeighborFinder
from dcg_sci_tool import *


def get_pdau_surface_atoms(data, type_names_order, cutoff=4.0, CN_threshold=12):
    """
    获取位于 PdAu 簇表面的原子索引列表，基于配位数。

    对于致密、严格对称的结构（如代码生成的PdAu标准正二十面体团簇）：

        cutoff = 3.5, CN_threshold = 12

    对于MD或者MD帧优化得到的结构：
    
        cutoff = 4.0, CN_thershold = 12

    Args:
        data (DataCollection): OVITO 数据对象，包含原子结构信息
        type_names_order (list): 原子类型名称顺序列表
        cutoff (float): 配位数计算的截断距离，单位为 Å（默认 4.0 Å，可取范围内尽量取大，增大适用范围）
        CN_thershold (int): 体相配位数阈值，用于判断原子是否位于表面（默认 12）

    Returns:
        surface_atoms (list): 位于 PdAu 簇表面的原子索引列表
    """
    positions = data.particles.positions[...]
    types = data.particles.particle_types[...]

    if positions is None or types is None:
        raise ValueError("数据对象不包含粒子位置或类型信息")

    if len(positions) != len(types):
        raise ValueError("原子位置和类型数量不匹配")

    if not type_names_order:
        raise ValueError("type_names_order 列表不能为空")

    symbols = [type_names_order[t - 1] for t in types]

    pdau_indices = [i for i, symbol in enumerate(symbols) if symbol in ["Pd", "Au"]]
    surface_atoms = []

    for i in pdau_indices:
        pdau_neighbors = []
        # 计算与 PdAu 簇中其他原子的配位数
        neighbor_finder = CutoffNeighborFinder(cutoff, data)
        neighbors = neighbor_finder.find(i)
        for neighbor in neighbors:
            if neighbor.index in pdau_indices:
                pdau_neighbors.append(neighbor.index)

        # 根据配位数判断是否为表面原子
        if len(pdau_neighbors) < CN_threshold:  # 体相配位数为 CN_thershold
            surface_atoms.append(i)

    return surface_atoms
