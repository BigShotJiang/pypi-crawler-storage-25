import numpy as np
from ovito.data import DataCollection

def get_pdau_cluster_center(data: DataCollection, type_names_order: list):
    """
    基于 OVITO 数据对象和原子类型顺序计算 PdAu 簇的几何中心坐标。

    Args:
        data (DataCollection): OVITO 数据对象，包含原子结构信息
        type_names_order (list): 原子类型名称顺序列表

    Returns:
        np.ndarray: PdAu 簇的几何中心坐标，形状为 (3,)
    
    Raises:
        ValueError: 如果未找到 Pd 或 Au 原子
    """
    # 获取原子位置和类型
    positions = data.particles.positions[...]
    types = data.particles.particle_types[...]  # 类型索引数组，从 1 开始
    
    # 检查数据完整性
    if positions is None or types is None:
        raise ValueError("数据对象不包含粒子位置或类型信息")
    
    if len(positions) != len(types):
        raise ValueError("原子位置和类型数量不匹配")
    
    if not type_names_order:
        raise ValueError("type_names_order 列表不能为空")
    
    # 创建原子符号数组
    symbols = [type_names_order[t-1] for t in types]  # 注意：OVITO 类型索引从 1 开始
    
    # 查找 Pd 和 Au 原子
    pdau_indices = []
    for i, symbol in enumerate(symbols):
        if symbol in ["Pd", "Au"]:
            pdau_indices.append(i)
    
    if not pdau_indices:
        raise ValueError("在结构中未找到 Pd 或 Au 原子")
    
    # 提取 Pd 和 Au 原子的位置
    pdau_positions = positions[pdau_indices]
    
    # 计算几何中心
    pdau_center = np.mean(pdau_positions, axis=0)
    
    return pdau_center