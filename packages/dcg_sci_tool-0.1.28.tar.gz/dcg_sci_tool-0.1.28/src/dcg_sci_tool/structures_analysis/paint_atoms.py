from ovito.io import import_file, export_file

from ovito.modifiers import ExpressionSelectionModifier, AssignColorModifier
import os

def color_atoms_in_trajectory(trajectory_file: str, rgb_color: list, atom_indices: list, output_file: str = None):
    """
    将指定原子序号列表中的原子染成指定的RGB颜色，并生成新的轨迹文件
    
    Args:
        trajectory_file (str): 输入轨迹文件的路径 (xyz格式)
        rgb_color (list): RGB颜色值列表，范围[0.0, 1.0]，如[1.0, 0.0, 0.0]表示红色
        atom_indices (list): 要染色的原子序号列表
        output_file (str): 输出文件路径。如果不指定，则在原文件名后添加"_colored"
    
    Returns:
        output_file (str): 输出文件路径
    """
    # 验证输入参数
    if len(rgb_color) != 3:
        raise ValueError("RGB颜色必须是包含3个值的列表，如[1.0, 0.0, 0.0]")
    
    for value in rgb_color:
        if value < 0.0 or value > 1.0:
            raise ValueError("RGB颜色值必须在[0.0, 1.0]范围内")
    
    if not atom_indices:
        raise ValueError("原子序号列表不能为空")
    
    # 设置输出文件名
    if output_file is None:
        base_name = os.path.splitext(trajectory_file)[0]
        output_file = f"{base_name}_colored.xyz"
    
    # 加载轨迹文件
    print(f"加载轨迹文件: {trajectory_file}")
    pipeline = import_file(trajectory_file)
    
    # 创建原子选择表达式
    # 将原子序号列表转换为ParticleIndex选择表达式
    expr_parts = []
    for atom_idx in atom_indices:
        # 转换为字符串
        expr_parts.append(f"ParticleIndex == {atom_idx}")
    
    # 如果原子列表为空，则选择所有原子
    if not expr_parts:
        selection_expr = "1"  # 选择所有原子
    else:
        # 用"或"操作符连接所有条件
        selection_expr = " || ".join(expr_parts)
    
    print(f"选择表达式: {selection_expr}")
    print(f"要染色的原子数: {len(atom_indices)}")
    
    # 创建并添加选择修改器
    selection_modifier = ExpressionSelectionModifier(expression=selection_expr)
    pipeline.modifiers.append(selection_modifier)
    
    # 创建并添加颜色修改器
    # AssignColorModifier默认只对选中的原子染色
    color_modifier = AssignColorModifier(color=rgb_color)
    pipeline.modifiers.append(color_modifier)
    
    # 导出染色后的轨迹
    print(f"正在导出染色后的轨迹到: {output_file}")
    export_file(
        pipeline,
        output_file,
        "xyz",
        multiple_frames=True,
        columns=["Particle Identifier", "Particle Type", 
                "Position.X", "Position.Y", "Position.Z", "Color"]
    )
    
    print(f"轨迹文件已成功导出: {output_file}")
    return output_file

def color_atoms_in_trajectory_multicolor(trajectory_file: str, atom_color_map: dict, output_file: str = None):
    """
    将轨迹中不同原子染成不同颜色
    
    Args:
        trajectory_file (str): 输入轨迹文件的路径 (xyz格式)
        atom_color_map (dict): 字典，键为原子序号，值为RGB颜色列表
            示例: {0: [1.0, 0.0, 0.0], 1: [0.0, 1.0, 0.0]}
        output_file (str): 输出文件路径
    
    Returns:
        output_file (str): 输出文件路径
    """
    if not atom_color_map:
        raise ValueError("原子颜色映射字典不能为空")
    
    # 设置输出文件名
    if output_file is None:
        base_name = os.path.splitext(trajectory_file)[0]
        output_file = f"{base_name}_multicolored.xyz"
    
    # 加载轨迹文件
    print(f"加载轨迹文件: {trajectory_file}")
    pipeline = import_file(trajectory_file)
    
    # 为每个原子创建单独的选择和染色
    for atom_idx, rgb_color in atom_color_map.items():
        # 验证颜色
        if len(rgb_color) != 3:
            raise ValueError(f"原子{atom_idx}的RGB颜色必须是包含3个值的列表")
        
        for value in rgb_color:
            if value < 0.0 or value > 1.0:
                raise ValueError(f"原子{atom_idx}的RGB颜色值必须在[0.0, 1.0]范围内")
        
        # 创建选择表达式
        selection_expr = f"ParticleIndex == {atom_idx}"
        
        # 创建并添加选择修改器
        selection_modifier = ExpressionSelectionModifier(expression=selection_expr)
        pipeline.modifiers.append(selection_modifier)
        
        # 创建并添加颜色修改器
        color_modifier = AssignColorModifier(color=rgb_color)
        pipeline.modifiers.append(color_modifier)
    
    # 导出染色后的轨迹
    print(f"正在导出多色轨迹到: {output_file}")
    print(f"染色原子数: {len(atom_color_map)}")
    export_file(
        pipeline,
        output_file,
        "xyz",
        multiple_frames=True,
        columns=["Particle Identifier", "Particle Type", 
                "Position.X", "Position.Y", "Position.Z", "Color"]
    )
    
    print(f"多色轨迹文件已成功导出: {output_file}")
    return output_file

# 示例使用
if __name__ == "__main__":
    # 示例1: 将原子0, 1, 2染成红色
    trajectory_file = "example_trajectory.xyz"
    
    # 方法1: 单一颜色
    red_color = [1.0, 0.0, 0.0]  # 红色
    atoms_to_color = [0, 1, 2]  # 原子序号列表
    
    print("示例1: 单一颜色染色")
    colored_file = color_atoms_in_trajectory(trajectory_file, red_color, atoms_to_color)
    print(f"输出文件: {colored_file}\n")
    
    # 方法2: 多色
    print("示例2: 多色染色")
    atom_color_dict = {
        0: [1.0, 0.0, 0.0],  # 原子0: 红色
        1: [0.0, 1.0, 0.0],  # 原子1: 绿色
        2: [0.0, 0.0, 1.0],  # 原子2: 蓝色
        3: [1.0, 1.0, 0.0],  # 原子3: 黄色
    }
    
    multicolored_file = color_atoms_in_trajectory_multicolor(trajectory_file, atom_color_dict)
    print(f"输出文件: {multicolored_file}\n")
    
    # 方法3: 从文件中读取原子序号
    print("示例3: 从文件中读取原子序号")
    def load_atom_indices_from_file(filename: str):
        """从文件中加载原子序号列表"""
        with open(filename, 'r') as f:
            # 假设每行一个原子序号
            indices = []
            for line in f:
                line = line.strip()
                if line:  # 跳过空行
                    try:
                        index = int(line)
                        indices.append(index)
                    except ValueError:
                        print(f"警告: 无法解析 '{line}' 为整数")
            return indices
    
    # 假设有一个包含原子序号的文件
    indices_file = "atom_indices.txt"
    if os.path.exists(indices_file):
        print(f"从文件 {indices_file} 加载原子序号...")
        atoms_from_file = load_atom_indices_from_file(indices_file)
        print(f"加载了 {len(atoms_from_file)} 个原子序号")
        
        # 将这些原子染成青色
        cyan_color = [0.0, 1.0, 1.0]  # 青色
        file_colored_file = color_atoms_in_trajectory(trajectory_file, cyan_color, atoms_from_file, "selected_atoms_colored.xyz")
        print(f"输出文件: {file_colored_file}")