import os
import re
from typing import List

def find_matching_files(directory: str, pattern: str = None) -> List[str]:
    """
    查找目录下所有满足模式的文件名（不支持shell通配符，只支持正则表达式）
    注意：正则表达式（regex）与shell的通配符（wildcard）语法完全不同！
 
    Args:

        directory (str): 要搜索的目录路径
        pattern (str): 正则表达式

    Returns:

        matching_files (List[str]): 匹配的文件名列表
    """
    if pattern is None:
        print("No pattern provided")
        return []  

    # 编译正则表达式
    try:
        regex = re.compile(pattern)
    except re.error as e:
        print(f"正则表达式编译错误: {e}")
        return []
    
    matching_files = []
    
    # 只搜索当前目录，不使用os.walk
    try:
        # 获取指定目录中的所有文件和子目录
        items = os.listdir(directory)
        
        for item in items:
            # 构建完整路径
            item_path = os.path.join(directory, item)
            
            # 检查是否是文件（不是目录）
            if os.path.isfile(item_path):
                # 检查文件名是否匹配正则表达式
                if regex.fullmatch(item):
                    matching_files.append(item)
    except FileNotFoundError:
        print(f"目录不存在: {directory}")
    except PermissionError:
        print(f"没有权限访问目录: {directory}")
    except Exception as e:
        print(f"读取目录时发生错误: {e}")
    
    return matching_files