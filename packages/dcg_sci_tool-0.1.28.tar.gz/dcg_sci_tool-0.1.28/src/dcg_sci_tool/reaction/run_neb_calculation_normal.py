import os
import shutil
from pathlib import Path
from dcg_sci_tool.reaction.neb_post_process import *
from dcg_sci_tool.reaction.auto_neb_refine import auto_neb_refine

def run_neb_calculation_normal(minimized_is_path, target_atom_list,mpi_partition="40x1",neb_max_refine_rounds = 3, co2_indexes = None):
    """
    运行 NEB 计算
    """
    print("\n" + "=" * 60)
    print("步骤 3: 运行 NEB 计算")
    print("=" * 60)
    
    # 创建工作目录
    neb_dir = create_workspace("2.neb", ["nep.txt", "in.lammps_neb"])
    original_dir = Path.cwd()
    
    try:
        os.chdir(neb_dir)
        
        # 1. 构建初态数据文件
        print("构建初态数据文件...")
        traj2iniData(
            traj_file=str(minimized_is_path),
            specorder=['C', 'O', 'Pd', 'Au'],
            start_frame=0,
            end_frame=0
        )
        
        if Path("0.data").exists():
            Path("0.data").rename("IS.data")
            print("已创建 IS.data")
        
        # 2. 构建末态数据文件
        print("构建末态数据文件...")
        atoms_fs = construct_CO2_formation_FS(str(minimized_is_path), target_atom_list)
        atoms2lmps_resultData(atoms=atoms_fs, output_file="FS.data")
        print("已创建 FS.data")
        
        # 3. 运行 NEB 计算
        print("运行 LAMMPS NEB 计算...")
        mpirun_lammps(input_file="in.lammps_neb", partition=mpi_partition)
        
        # 4. 提取轨迹和绘图
        print("提取 NEB 轨迹...")
        neb_get_traj()
        
        print("生成 NEB 能垒图...")
        Ea, dH, isConverged = plot_neb_graph(src_file="neb_mep.dat", output_file="neb_graph.png")
        

        found_local_minima, left_idx, right_idx = get_local_minima_sides_of_peak(
        mep_data_file="neb_mep.dat", 
        neb_traj_file="result.xyz"
    )

        if found_local_minima:
            # 5. 自动优化 NEB
            print(f"发现中间态，开始 NEB 自动优化 (最多 {neb_max_refine_rounds} 轮)...")

            Ea, dH, final_neb_dir, isConverged = auto_neb_refine(lammps_in_file="in.lammps_neb", left_idx=left_idx, right_idx=right_idx, max_round_num=neb_max_refine_rounds)
        else:
            
            final_neb_dir = f"{original_dir}/{neb_dir}"

        # 判断是否收敛
        if isConverged == False:
            print("neb结束，力未收敛")

        # 将最终neb轨迹和MEP图像复制到主目录
        shutil.copy(f'{final_neb_dir}/result.xyz', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.xyz')
        shutil.copy(f'{final_neb_dir}/neb_graph.png', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.png')


    finally:
        os.chdir(original_dir)
    
    print("NEB 计算完成！")