import dcg_sci_tool
from dcg_sci_tool.reaction.neb_post_process import *
from dcg_sci_tool.reaction.find_and_preprocess_input import *
from dcg_sci_tool.reaction.find_and_preprocess_input_no_ads import *
from dcg_sci_tool.reaction.run_initial_state_minimization import *
from dcg_sci_tool.reaction.run_neb_calculation_normal import *
from dcg_sci_tool.reaction.run_each_neb_calculation import *
from dcg_sci_tool.reaction.construct_final_state import construct_final_state


def setup_logging():
    """设置日志和版本信息"""
    print("=" * 60)
    print(f"dcg_sci_tool version: {dcg_sci_tool.__version__}")
    print("=" * 60)


def onekey_run_neb_normal(mode = "ads", mpi_partition="40x1", neb_max_refine_rounds=3):
    """
    对于ads模式：提取单个MD反应快照（反应物原子需要染成兰色），计算neb过程的能垒，
    包括气体分子删除、初态优化、末态构建、NEB计算过程
    对于no_ads模式：或者根据已经优化好的有吸附物的neb轨迹，计算无吸附物的neb过程。
    包括反应位点附近吸附态原子删除、初态优化、末态构建、NEB 计过程。
    Args:
        mode (str): 计算模式，"ads"或"no_ads"

        mpi_partition (str): 跑lammps的neb环境配置参数

        neb_max_refine_rounds (int): neb单峰优化过程最大迭代轮数

    """
    try:
        # 1. 初始化
        setup_logging()
        
        # 2. 查找并预处理输入文件
        if mode == "ads":
            cleaned_atoms, target_atom_list, md_file, co2_indexes = find_and_preprocess_input()
        elif mode == "no_ads":
            cleaned_atoms, target_atom_list, md_file, co2_indexes = find_and_preprocess_input_no_ads()
        
        
        # 3. 初态结构优化
        minimized_is_path = run_initial_state_minimization()
        print(f"minimized_is_path值：{minimized_is_path}")
        
        # 4. 构建末态结构
        atoms_fs, fs_path = construct_final_state(minimized_is_path, target_atom_list)
        
        # 5. 运行 NEB 计算
        run_neb_calculation_normal(minimized_is_path, target_atom_list, mpi_partition, neb_max_refine_rounds, co2_indexes)
        
        print("\n" + "=" * 60)
        print("所有计算步骤完成！")
        print(f"初态优化结果: {minimized_is_path}")
        print(f"末态结构: {fs_path}")
        print(f"NEB 计算结果目录: 2.neb/")
        print("=" * 60)
        
    except FileNotFoundError as e:
        print(f"错误: 文件未找到 - {e}")
        return 1
    except Exception as e:
        print(f"错误: 计算过程中发生异常 - {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0