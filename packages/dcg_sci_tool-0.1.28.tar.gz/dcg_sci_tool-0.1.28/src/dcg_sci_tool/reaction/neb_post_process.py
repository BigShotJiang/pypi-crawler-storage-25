from dcg_sci_tool import *
from dcg_sci_tool.plot.plot_basic_graph import plot_basic_graph
from ase.io import read, write
import re
import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np

def neb_get_traj():
    """
    对NEB轨迹文件进行后处理
    
    功能：
    1. 查找所有dump.neb.*.lmpstrj轨迹文件
    2. 按编号排序
    3. 提取每个轨迹的首尾结构
    4. 分别保存为check.xyz和result.xyz文件
    """
    
    # 查找并排序轨迹文件
    dump_files = find_matching_files("./", "dump.neb.*.lmpstrj")
    dump_files.sort(key=lambda x: int(re.search(r'\.(\d+)\.', x).group(1)))
    
    # 存储结果
    check_structures = []
    result_structures = []
    
    # 处理每个轨迹文件
    for i, traj_file in enumerate(dump_files, 1):
        # 读取轨迹中的所有结构
        structures = read(traj_file, ":")
        
        if len(structures) > 0:
            # 取第一个和最后一个结构
            check_structures.append(structures[0])
            result_structures.append(structures[-1])
            
            print(f"已处理 {i}/{len(dump_files)}: {traj_file} "
                  f"(包含 {len(structures)} 个结构)")
    
    # 保存结果
    if check_structures:
        write("check.xyz", check_structures)
        print(f"已保存检查结构: check.xyz ({len(check_structures)} 个结构)")
    
    if result_structures:
        write("result.xyz", result_structures)
        print(f"已保存结果结构: result.xyz ({len(result_structures)} 个结构)")
    

def parse_neb_last_line(last_line: str, f_threshold = 0.05):
    """解析最后一行，提取反应坐标和能量"""
    tokens = last_line.split()
    rc, e = [], []
    isConverged = False
    
    last_force=float(tokens[1])
    if last_force < f_threshold:
        isConverged = True
    # 提取交替的RC和E值
    for i in range(9, len(tokens), 2):
        try:
            rc.append(float(tokens[i]))
            e.append(float(tokens[i+1]))
        except (IndexError, ValueError):
            break
    
    return rc[:len(e)], e[:len(rc)], isConverged

def write_neb_mep_data(neb_mep_data_file = "neb_mep.dat"):
    # 读取最后一行
    with open("log.lammps", "r") as f:
        last_line = f.readlines()[-1].strip()
    
    # 提取数据
    rc_array, e_array, is_converged = parse_neb_last_line(last_line)
    
    if not rc_array:
        print("未找到有效数据")
        sys.exit(1)
    
    # 计算相对能量
    delta_e_array = [e - e_array[0] for e in e_array]
    
    # 写入文件
    with open(neb_mep_data_file, "w") as f:
        f.write("# Index\tReaction_Coordinate\tAbsolute_Energy\tRelative_Energy\n")
        for i, (rc, e, de) in enumerate(zip(rc_array, e_array, delta_e_array)):
            f.write(f"{i}\t{rc:.6f}\t{e:.6f}\t{de:.6f}\n")
    
    print(f"已生成 {len(rc_array)} 个数据点")

    return is_converged


def plot_neb_graph(src_file ='neb_mep.dat', output_file = "neb_graph.png"):
    """
    绘制MEP能量曲线图，返回能垒、焓变和是否收敛的元组
    """

    is_converged = write_neb_mep_data(src_file)
    plot_basic_graph(src_file=f'{src_file}',x_col=0,y_cols=[3])

    data = pd.read_csv(f'{src_file}', header=None, sep=r'\s+|,', engine='python',comment="#")
    # 提取指定列的数据
    x_data = data.iloc[:, 0]
    y_data = data.iloc[:, 3]
    # 找到纵坐标最大值点并标注
    max_idx = np.argmax(y_data)
    max_x = x_data.iloc[max_idx]
    max_y = y_data.iloc[max_idx]

    # 标注最大值点
    plt.annotate(f'Max: {max_y:.2f}', 
                 xy=(max_x, max_y),
                 xytext=(max_x, max_y + (y_data.max()-y_data.min())*0.05),
                 fontsize=12,
                 ha='center',
                 arrowprops=dict(facecolor='red', shrink=0.05))

    # 找到最后一个数据点并标注（不带箭头）
    last_x = x_data.iloc[-1]
    last_y = y_data.iloc[-1]

    # 标注最后一个点（仅文本，不带箭头）
    plt.text(last_x, last_y - (y_data.max()-y_data.min())*0.05, 
             f'End: {last_y:.2f}',
             fontsize=12,
             ha='center',
             color='green')
    # 保存图片
    plt.savefig(f"{output_file}", dpi=300, bbox_inches='tight')
    print(f'折线图已保存至: {output_file}')
    # 显示图表（可选）
    # plt.show()
    # 返回能垒和焓变信息
    return max_y, last_y, is_converged
