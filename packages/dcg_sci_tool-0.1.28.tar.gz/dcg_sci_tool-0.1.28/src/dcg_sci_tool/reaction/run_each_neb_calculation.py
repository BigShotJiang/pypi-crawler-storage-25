import os
import shutil
from pathlib import Path
from dcg_sci_tool.reaction.neb_post_process import *


def run_each_neb_calculation(target_atom_list,mpi_partition="40x1",co2_indexes = None):
    """
    在自动截取MD轨迹的算能垒的自动化流程中，基于NEB zbl基础继续运行 EACH NEB 计算
    
    Args:
        target_atom_list (list): 目标原子列表
        mpi_partition (str, optional): MPI 分区名称，默认 "40x1"
        co2_indexes (list, optional): CO2 索引列表，默认 None
    
    Returns:
        None
    """
    print("\n" + "=" * 60)
    print("步骤 4: 运行 EACH NEB 计算")
    print("=" * 60)
    
    # 创建工作目录
    neb_dir = create_workspace("3.neb_each", ["nep.txt", "in.lammps_neb_each"]) 
    original_dir = Path.cwd()
    
    try:
        os.chdir(neb_dir)
        
        # 1. 构建初态数据文件
        print("构建初态数据文件...")
        getEachfromXYZ(f'{original_dir}/2.neb_zbl/zbl_final_results.xyz')
        
        # 3. 运行 NEB 计算
        print("运行 LAMMPS EACH NEB 计算...")
        mpirun_lammps(input_file="in.lammps_neb_each", partition=mpi_partition)
        
        # 4. 提取轨迹和绘图
        print("提取 EACH NEB 轨迹...")
        neb_get_traj()
        
        print("生成 EACH NEB 能垒图...")
        Ea, dH, isConverged = plot_neb_graph(src_file="neb_mep.dat", output_file="neb_graph.png")
        
        # 判断是否收敛
        if isConverged == False:
            print("neb_each 结束，力未收敛")

        # 将最终neb轨迹和MEP图像复制到主目录
        shutil.copy(f'result.xyz', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.xyz')
        shutil.copy(f'neb_graph.png', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.png')

        
    finally:
        os.chdir(original_dir)
    
    print("EACH NEB 计算完成！")