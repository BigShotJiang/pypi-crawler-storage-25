import numpy as np
from ovito.data import CutoffNeighborFinder
from ovito.io import import_file

from dcg_sci_tool.extract_atom_types import extract_atom_types

def get_reactants_ad_config(input_file, c_index, o_index, c_pd_cutoff = 2.5, o_pd_cutoff = 2.1, c_au_cutoff = 2.5, o_au_cutoff = 2.2):
    """
    Get the adsorption configuration of reactant atoms.

    Args:
        input_file (str): Path to the input file containing the structure and related data
                
        c_index (int): Index of the C atom in the reactant CO molecule
        
        o_index (int): Index of the O atom in the reactant CO molecule
        
        c_pd_cutoff (float): Cutoff distance for C atom coordination with Pd, default is 2.5 Å
        
        o_pd_cutoff (float): Cutoff distance for O atom coordination with Pd, default is 2.1 Å

        c_au_cutoff (float): Cutoff distance for C atom coordination with Au, default is 2.5 Å

        o_au_cutoff (float): Cutoff distance for O atom coordination with Au, default is 2.2 Å

    Returns:

        tuple: Adsorption configuration information
        
            c_pdau_info (str): Adsorption configuration information for the C atom, including element type and geometry
            
            o_pdau_info (str): Adsorption configuration information for the O atom, including element type and geometry
    
    """
    # Load the structure and related data from the input file
    pipeline = import_file(input_file)
    data = pipeline.compute(frame=0)  # 只根据第一帧获取要保留的原子索引和旋转目标向量，后续帧使用相同的索引进行处理
    type_names_order = extract_atom_types(input_file)


    particles = data.particles

    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 分别计算C原子和O原子使用的邻居列表
    # O原子：使用较短的阈值 (o_cutoff)
    finder_o_pd = CutoffNeighborFinder(o_pd_cutoff, data)
    # C原子：使用较长的阈值 (c_cutoff)
    finder_c_pd = CutoffNeighborFinder(c_pd_cutoff, data)
    finder_o_au = CutoffNeighborFinder(o_au_cutoff, data)
    finder_c_au = CutoffNeighborFinder(c_au_cutoff, data)
    


    num_atoms = particles.count
    neighbors_o_pd = {i: [] for i in range(num_atoms)}
    neighbors_c_pd = {i: [] for i in range(num_atoms)}
    neighbors_o_au = {i: [] for i in range(num_atoms)}
    neighbors_c_au = {i: [] for i in range(num_atoms)}
    
    # 生成邻居列表
    for i in range(num_atoms):
        # O原子阈值邻居列表
        for neighbor in finder_o_pd.find(i):
            if symbols[neighbor.index] == 'Pd':
                neighbors_o_pd[i].append(neighbor.index)
        # C原子阈值邻居列表
        for neighbor in finder_c_pd.find(i):
            if symbols[neighbor.index] == 'Pd':
                neighbors_c_pd[i].append(neighbor.index)
        # O原子与Au的邻居列表
        for neighbor in finder_o_au.find(i):
            if symbols[neighbor.index] == 'Au':
                neighbors_o_au[i].append(neighbor.index)
        # C原子与Au的邻居列表
        for neighbor in finder_c_au.find(i):
            if symbols[neighbor.index] == 'Au':
                neighbors_c_au[i].append(neighbor.index)



    c_pd_cn = len(neighbors_c_pd[c_index])
    o_pd_cn = len(neighbors_o_pd[o_index])
    c_au_cn = len(neighbors_c_au[c_index])
    o_au_cn = len(neighbors_o_au[o_index])

    if c_pd_cn + c_au_cn == 1:
        geometry_info = 'top'
        element_info = 'Pd' if c_pd_cn == 1 else 'Au'
    elif c_pd_cn + c_au_cn == 2:
        geometry_info = 'bridge'
        if c_pd_cn == 2:
            element_info = 'Pd2'
        elif c_pd_cn == 1:
            element_info = 'PdAu'
        else:
            element_info = 'Au2'
    elif c_pd_cn + c_au_cn == 3:
        geometry_info = 'hollow'
        if c_pd_cn == 3:
            element_info = 'Pd3'
        elif c_pd_cn == 2:
            element_info = 'Pd2Au'
        elif c_pd_cn == 1:
            element_info = 'PdAu2'
        else:
            element_info = 'Au3'

    c_pdau_info = f"{element_info} {geometry_info}" 

    if o_pd_cn + o_au_cn== 1:
        geometry_info = 'top'
        element_info = 'Pd' if o_pd_cn == 1 else 'Au'
    elif o_pd_cn + o_au_cn == 2:
        geometry_info = 'bridge'
        if o_pd_cn == 2:
            element_info = 'Pd2'
        elif o_pd_cn == 1:
            element_info = 'PdAu'
        else:
            element_info = 'Au2'
    elif o_pd_cn + o_au_cn == 3:
        geometry_info = 'hollow'
        if o_pd_cn == 3:
            element_info = 'Pd3'
        elif o_pd_cn == 2:
            element_info = 'Pd2Au'
        elif o_pd_cn == 1:
            element_info = 'PdAu2'
        else:
            element_info = 'Au3'

    o_pdau_info = f"{element_info} {geometry_info}"

    return c_pdau_info, o_pdau_info

