import os

def parse_nebTraj_file_name(file_name):
    """
    解析NEB轨迹文件名，提取Ea、dE、C_idx和O_idx信息

    Args:

        file_name (str): NEB轨迹文件名，格式为"反应前CO2数-反应后CO2数_Ea_dE_Cidx_Oidx.xyz"

    Returns:

        tuple: neb过程信息

            co2_indexes (list): 生成的CO2的序号列表

            Ea (float): 能垒

            dE (float): 焓变

            C_idx (int): 参与反应的CO的C原子索引

            O_idx (int): 参与反应的氧原子索引

    """
    name_without_ext, _ = os.path.splitext(file_name)
    info = name_without_ext.split("_")
    co2_indexes = info[0].split("-")
    Ea = float(info[1])
    dE = float(info[2])
    C_idx= int(info[3])
    O_idx= int(info[4])
    return co2_indexes, Ea, dE, C_idx, O_idx