import numpy as np
from ase import Atoms

def ovito2atoms(data, type_names_order):
    """
    从 OVITO 的 data 对象创建 ASE Atoms 对象
    
    Args:

        data: OVITO 的 DataCollection 对象

        type_names_order: 类型名称列表，索引对应 particle_type
    
    Returns:

        ase_atoms: ASE 的 Atoms 对象
    """
    # 1. 获取原子信息
    particles = data.particles
    
    # 原子位置
    positions = particles.positions[...].copy()  # shape: (N, 3)
    
    # 原子类型
    particle_types = particles.particle_types[...]  # shape: (N,)
    
    # 将类型索引转换为元素符号
    symbols = [type_names_order[t-1] for t in particle_types]  # 注意：OVITO 类型索引从1开始
    
    # 2. 获取晶胞信息
    cell_matrix = data.cell[...]  # shape: (4, 3)
    cell = cell_matrix[:, :3]  # 晶胞向量
    origin = cell_matrix[:, 3]  # 晶胞原点
    # 3. 处理周期性边界条件
    pbc_flags = data.cell.pbc  # 从 OVITO 获取 PBC 标志
    
    # 4. 创建 ASE Atoms 对象
    ase_atoms = Atoms(
        symbols=symbols,
        positions=positions - origin,  # 调整到晶胞原点
        cell=cell,
        pbc=pbc_flags
    )
    
    return ase_atoms