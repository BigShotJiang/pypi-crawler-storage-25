import os
from dcg_sci_tool import traj2iniData
from dcg_sci_tool import atoms2lmps_resultData
from ase.io import read,write

def getEachfromXYZ(input_file: str):
    """
    从XYZ文件中提取每个帧的结构数据，并生成可用来跑each模式的neb的对应的data文件
    
    Args:
        input_file (str): 输入文件路径，包含XYZ格式的轨迹数据
    """

    
    # 拆分.XYZ轨迹：第一帧和其他帧
    IS_traj = read(input_file, index="0")
    neb_images_besides_IS = read(input_file, index="1:")
    
    # 产生IS.data文件
    write("IS_temp.xyz",format="extxyz",images=IS_traj)  
    traj2iniData(traj_file = "IS_temp.xyz", specorder=["C", "O", "Pd", "Au"])
    # 重命名文件
    if os.path.exists("0.data"):
        os.rename("0.data", "IS.data")
    
    # 产生其他帧的data文件
    for i, atoms in enumerate(neb_images_besides_IS):
        print(i+1)
        atoms2lmps_resultData(atoms, f"each_{i+1}.data")