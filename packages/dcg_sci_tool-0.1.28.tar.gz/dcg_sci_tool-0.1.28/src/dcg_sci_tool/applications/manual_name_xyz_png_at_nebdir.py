import os
import re
from pathlib import Path
from dcg_sci_tool import *

def find_nearest_log_file(current_dir):
    """
    从当前目录开始向上查找最近的 python.log 文件
    和最近的满足 "[0-9]+to[0-9]+" 名称的父目录
    """
    current_path = Path(current_dir).resolve()
    
    nearest_log = None
    nearest_pattern_dir = None
    found_log = False
    found_pattern = False
    
    # 从当前目录开始向上查找
    for path in [current_path] + list(current_path.parents):
        # 检查当前目录是否包含 python.log
        if not found_log:
            log_file = path / "python.log"
            if log_file.is_file():
                nearest_log = str(log_file)
                found_log = True
        
        # 检查当前目录名是否匹配模式
        if not found_pattern:
            if re.match(r'^[0-9]+to[0-9]+$', path.name):
                nearest_pattern_dir = str(path)
                found_pattern = True
        
        # 如果两者都找到了，提前退出
        if found_log and found_pattern:
            break
    
    return nearest_log, nearest_pattern_dir

def manual_name_xyz_png_at_nebdir():
    """
    将neb目录下的neb_graph.png和result.xyz重命名，使包含CO2序号、能垒、焓变、目标原子序号的信息
    """
    # 获取当前目录
    current_dir = os.getcwd()
    print(f"当前目录: {current_dir}")
    
    # 查找文件
    log_file, pattern_dir = find_nearest_log_file(current_dir)
    
    if log_file:
        print(f"找到最近的 python.log 文件: {log_file}")
    else:
        print("未找到 python.log 文件")
    
    if pattern_dir:
        print(f"找到最近的满足模式 [0-9]+to[0-9]+ 的目录: {pattern_dir}")
    else:
        print("未找到满足模式 [0-9]+to[0-9]+ 的目录")

    Ea, dH = get_Ea_dH_from_file()
    c_idx, o_idx = get_target_atoms_from_file(log_file)
    co2_indexes = pattern_dir.split('/')[-1].split('to')
    final_name = f"{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{c_idx}_{o_idx}"
    os.rename("result.xyz", f"{final_name}.xyz")
    os.rename("neb_graph.png", f"{final_name}.png")