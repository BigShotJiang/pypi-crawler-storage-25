"""
自动批量处理NEB计算文件
功能：
1. 识别符合 CO2_formation_frame<正整数>_CO2_<整数A>to<整数B>.xyz 格式的文件
或者r'^[0-9]+-[0-9]+_[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+\.xyz$'格式的文件内
2. 为每个 <整数A>to<整数B> 创建对应的目录
3. 将XYZ文件移动到对应目录
4. 复制配置文件到每个目录
5. 提交计算作业
"""

import os
import re
import shutil
from pathlib import Path
import subprocess

def parse_xyz_filename(filename):
    """
    解析XYZ文件名，提取整数A和整数B
    
    参数：
    filename: 文件名
    
    返回：
    tuple: (整数A, 整数B) 或 None（如果格式不匹配）
    """
    # 用于计算MD快照中的neb
    # pattern = r"CO2_formation_frame\d+_CO2_(\d+)to(\d+)\.xyz"

    # 用于基于已经完成的neb轨迹，进行附近无第三方吸附物时的neb
    pattern = r'^([0-9]+)-([0-9]+)_[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+\.xyz$'
    match = re.match(pattern, filename)
    
    if match:
        a = int(match.group(1))
        b = int(match.group(2))
        return a, b
    return None

def get_file_groups(current_dir="."):
    """
    获取当前目录下所有符合条件的文件，并按AtoB分组
    
    返回：
    dict: 键为"AtoB"字符串，值为该组文件列表
    """
    file_groups = {}
    current_path = Path(current_dir)
    
    for file_path in current_path.glob("*.xyz"):
        if file_path.is_file():
            result = parse_xyz_filename(file_path.name)
            if result:
                a, b = result
                group_name = f"{a}to{b}"
                if group_name not in file_groups:
                    file_groups[group_name] = []
                file_groups[group_name].append(file_path)
    
    return file_groups

def get_required_config_files():
    """返回需要复制的配置文件列表"""
    return [
        "in.lammps_neb",
        "in.lammps_min", 
        "nep.txt",
        "run_neb.py",
        "run-lmps.lsf"
    ]

def create_directory_and_move_files(group_name, xyz_files, config_files):
    """
    为每个分组创建目录，移动文件，并复制配置文件
    
    参数：
    group_name: 组名，如 "123to456"
    xyz_files: 该组的XYZ文件列表
    config_files: 需要复制的配置文件列表
    """
    print(f"\n处理组: {group_name}")
    
    # 1. 创建目录
    target_dir = Path(group_name)
    if not target_dir.exists():
        target_dir.mkdir()
        print(f"  创建目录: {target_dir}")
    else:
        print(f"  目录已存在: {target_dir}")
    
    # 2. 移动XYZ文件
    moved_count = 0
    for xyz_file in xyz_files:
        target_path = target_dir / xyz_file.name
        if not target_path.exists():
            shutil.move(str(xyz_file), str(target_path))
            moved_count += 1
            print(f"  移动文件: {xyz_file.name} -> {target_dir}/{xyz_file.name}")
        else:
            print(f"  警告: 目标文件已存在，跳过: {target_path}")
    
    # 3. 复制配置文件
    copied_count = 0
    for config_file in config_files:
        source_path = Path(config_file)
        if source_path.exists():
            target_path = target_dir / config_file
            if not target_path.exists():
                shutil.copy2(str(source_path), str(target_path))
                copied_count += 1
                print(f"  复制配置: {config_file} -> {target_dir}/{config_file}")
            else:
                print(f"  配置已存在: {target_dir}/{config_file}")
        else:
            print(f"  警告: 配置文件不存在: {config_file}")
    
    return target_dir, moved_count, copied_count

def submit_job(directory, job_script="run-lmps.lsf"):
    """
    进入指定目录并提交作业
    
    参数：
    directory: 目标目录
    job_script: 作业脚本文件名
    """
    original_dir = os.getcwd()
    
    try:
        os.chdir(directory)
        print(f"  进入目录: {directory}")
        
        job_path = Path(job_script)
        if job_path.exists():
            # 构建命令字符串，确保重定向操作符能被shell正确解析
            cmd_str = f"bsub < {job_script}"
            print(f"  提交作业: {cmd_str}")
            
            # 使用字符串格式执行命令
            result = subprocess.run(cmd_str, 
                                  shell=True, 
                                  capture_output=True, 
                                  text=True)
            
            # 等待命令完成并获取返回码
            if result.returncode == 0:
                print(f"  作业提交成功: {result.stdout.strip()}")
            else:
                print(f"  作业提交失败: {result.stderr.strip()}")
        else:
            print(f"  警告: 作业脚本不存在: {job_path}")
    
    finally:
        os.chdir(original_dir)

def main():
    """主函数"""
    print("=" * 60)
    print("NEB计算文件自动处理脚本")
    print("=" * 60)
    
    # 1. 获取配置文件和XYZ文件
    config_files = get_required_config_files()
    
    # 检查配置文件是否存在
    missing_configs = []
    for config in config_files:
        if not Path(config).exists():
            missing_configs.append(config)
    
    if missing_configs:
        print("警告: 以下配置文件不存在:")
        for config in missing_configs:
            print(f"  - {config}")
        print("是否继续? (y/n): ", end="")
        if input().lower() != 'y':
            print("操作已取消")
            return
    
    # 2. 获取并按组整理XYZ文件
    print("\n扫描目录中的XYZ文件...")
    file_groups = get_file_groups()
    
    if not file_groups:
        print("未找到符合格式的XYZ文件!")
        print("期望格式: CO2_formation_frame<正整数>_CO2_<整数A>to<整数B>.xyz")
        return
    
    print(f"找到 {len(file_groups)} 个组:")
    for group_name, files in file_groups.items():
        print(f"  {group_name}: {len(files)} 个文件")
    
    # 3. 询问用户确认
    print(f"\n将创建 {len(file_groups)} 个目录，并提交作业")
    print("是否继续? (y/n): ", end="")
    if input().lower() != 'y':
        print("操作已取消")
        return
    
    # 4. 处理每个组
    processed_groups = 0
    submitted_jobs = 0
    
    for group_name, xyz_files in file_groups.items():
        # 创建目录、移动文件、复制配置
        target_dir, moved_count, copied_count = create_directory_and_move_files(
            group_name, xyz_files, config_files
        )
        
        # 提交作业
        print("  提交作业...")
        submit_job(target_dir)
        submitted_jobs += 1
        
        processed_groups += 1
    
    # 5. 汇总结果
    print("\n" + "=" * 60)
    print("处理完成!")
    print("=" * 60)
    print(f"已处理组数: {processed_groups}")
    print(f"已提交作业: {submitted_jobs}")
    print(f"配置目录: {[group for group in file_groups.keys()]}")

if __name__ == "__main__":
    main()