from dcg_sci_tool import *
import numpy as np
from ovito.io import import_file

def get_traj_focusing_reaction_site(traj_file, c_index, o_index, cutoff=6.0, target_vector=None, new_cell=None):
   """
   输入原始MD-neb结构文件，输出经过处理后的结构文件，将反应局部结构聚焦到小晶胞中，
   并使ovito观察视线方向（Y轴）经过反应区域和团簇中心
   输出聚焦后的结构文件（ASE ATOMS类）
   
   参数:
   ----------
   traj_file : str
      原始MD-neb结构文件路径
   c_index : int
      反应物CO的C原子的索引
   o_index : int
      反应物O原子的索引
   cutoff : float
      截止距离，单位为Å，默认为6.0
   target_vector : np.ndarray 或 list/tuple
      目标向量，形状为(3,)，旋转后当前向量将与此向量同向
   new_cell : np.ndarray 或 list/tuple
      新的晶胞尺寸，形状为(3,)，如 [a, b, c]
   
   返回:
   ----------
      返回旋转并平移后的neb轨迹对象
   focused_traj : list of Atoms
      旋转并平移后的ASE Atoms对象列表
   new_indexes : list
      旋转并平移后的结构中，原始索引old_indexes对应的新的原子索引列表
   """
   pipeline = import_file(traj_file)
   data = pipeline.compute(frame=0)  # 只根据第一帧获取要保留的原子索引和旋转目标向量，后续帧使用相同的索引进行处理
   type_names_order = extract_atom_types(traj_file)

   focused_traj = []
   # 获取PdAu簇中心
   cluster_center = get_pdau_cluster_center(data, type_names_order)
   # 获取反应局部结构的原子索引
   keep_indexes = get_reaction_local_atoms_list(data, type_names_order, c_index, o_index, cutoff)
   # 以目标C和目标O连线中点为旋转向量的终点
   vector_endpoint = (data.particles.positions[o_index] + data.particles.positions[c_index]) / 2
   for frame in range(pipeline.source.num_frames):
      data = pipeline.compute(frame=frame)
      filtered_struct, new_indexes = create_filtered_structure(data, type_names_order, keep_indexes, old_indexes=[c_index, o_index])
      # 将结构旋转，使得目标向量与-Y轴同向
      rotated_struct = rotate_v1_around_p_to_v2(
          atoms=filtered_struct,
          rotation_center=cluster_center,
          vector_endpoint=vector_endpoint,  # Use first atom position as vector endpoint
          target_vector=target_vector
      )
      # 将旋转后的结构平移，使得簇中心位于新晶胞的中心
      rotated_struct.set_cell(new_cell)
      rotated_struct.set_pbc([True, True, True])
      rotated_translated_struct = translate_structure_center(rotated_struct, np.array(new_cell)/2)
      focused_traj.append(rotated_translated_struct)
   return focused_traj, new_indexes