from ase.io import read, write
from ase.geometry import *
import numpy as np

def construct_CO2_formation_FS(input_file: str, atom_indices: list):
    """
    调整轨迹结构第一帧，使反应物的吸附态CO和吸附态O相向移动，生成吸附态CO2；
    具体：
    1.确定距离吸附态CO的C和吸附态O连线中点最近的Pd或Au原子：middle_metal。
    2.使反应物的吸附态CO和吸附态O相向移动，使C和吸附O距离缩短到1.25Å，
    3.调整吸附态CO中O的位置，使吸附态CO的C-O键长恢复到1.25Å，
    4.整体平移这三个原子，使C和middle_metal距离调整到2.0Å
    
    Args:

        input_file (str): 输入结构文件

        atom_indices (list): 两个原子序号的列表 [C_idx, O_ads_idx]

    Returns:

        atoms (Atoms): 构造的末态结构

    """
    
    # 读取结构第一帧
    atoms = read(input_file, index = 0)
    
    # 确保提供了2个原子序号
    if len(atom_indices) != 2:
        raise ValueError("需要 exactly 两个原子序号: C_idx, O_ads_idx")
    
    C_idx, O_ads_idx = atom_indices

    # 寻找反应CO的O原子的索引
    # 使用ASE的get_distances函数
    for i in range(len(atoms)):
        if atoms[i].symbol == 'O':
            # 计算考虑PBC的距离
            distance = atoms.get_distance(i, C_idx, mic=True)  # mic=True表示考虑最小镜像约定
            if distance < 1.25:
                O_CO_idx = i

    c_o_middle = (atoms[C_idx].position + atoms[O_ads_idx].position) / 2

    # 寻找距离目标C, O中点距离最近的金属原子的索引
    min_to_pdau_distance = float('inf')# inf在数学上表示一个比所有实数都大的数
    nearest_pdau_index = 0
    for i in range(len(atoms)):
        if atoms[i].symbol in ['Pd', 'Au']:
            # 计算考虑PBC的距离
            distance = get_distances(
                atoms[i].position, 
                c_o_middle, 
                cell=atoms.cell, 
                pbc=atoms.pbc
            )[1][0, 0]  # 返回的是距离矩阵，取(0,0)元素
            
            if distance < min_to_pdau_distance:
                min_to_pdau_distance = distance
                nearest_pdau_index = i
    middle_metal_idx = nearest_pdau_index


    # 获取初始位置
    pos = atoms.positions.copy()
    middle_metal_pos = pos[middle_metal_idx].copy()  # 中心金属原子位置保持不变
    
    # 第一步：移动C、O_CO、O_ads三个原子
    print("=== 第一步：调整C-O_ads距离和CO键长 ===")
    
    C_pos = pos[C_idx]
    O_CO_pos = pos[O_CO_idx]
    O_ads_pos = pos[O_ads_idx]
    
    # 计算当前C与吸附O之间的距离
    current_C_O_ads_dist = np.linalg.norm(C_pos - O_ads_pos)
    print(f"当前C-O_ads距离: {current_C_O_ads_dist:.3f} Å")
    
    # 目标距离
    target_C_O_ads_dist = 1.25  # Å
    
    # 计算C到吸附O的方向向量
    C_to_O_ads = O_ads_pos - C_pos
    if np.linalg.norm(C_to_O_ads) > 0:
        direction = C_to_O_ads / np.linalg.norm(C_to_O_ads)
    else:
        direction = np.array([1.0, 0.0, 0.0])
    
    # 计算需要移动的总距离
    move_distance_total = current_C_O_ads_dist - target_C_O_ads_dist
    
    if move_distance_total < 0:
        print("警告: 当前距离已经小于目标距离，将增加距离")
        direction = -direction
        move_distance_total = abs(move_distance_total)
    
    print(f"需要移动的总距离: {move_distance_total:.3f} Å")
    
    # C原子和吸附O原子各移动一半的距离（相向移动）
    move_distance_half = move_distance_total / 2
    
    # 移动C原子（向吸附O方向移动一半距离）
    C_move = direction * move_distance_half
    pos[C_idx] += C_move
    
    # 移动吸附O原子（向C方向移动一半距离）
    O_ads_move = -direction * move_distance_half
    pos[O_ads_idx] += O_ads_move
    
    # 移动CO中的O原子（跟随C原子移动相同的距离）
    pos[O_CO_idx] += C_move
    
    # 调整CO键长到1.25Å
    # 此时的CO方向已经不是原始的了，因为C原子发生了移动，整体上看类似于CO发生了旋转
    CO_vector = pos[O_CO_idx] - pos[C_idx]
    if np.linalg.norm(CO_vector) > 0:
        CO_direction = CO_vector / np.linalg.norm(CO_vector)
    else:
        CO_direction = np.array([0.0, 1.0, 0.0])
    
    # 设置CO中的O原子到C原子的距离为1.25Å
    pos[O_CO_idx] = pos[C_idx] + CO_direction * 1.25
    
    # 第一步完成，验证结果
    final_C_O_ads_dist_step1 = np.linalg.norm(pos[C_idx] - pos[O_ads_idx])
    final_CO_dist_step1 = np.linalg.norm(pos[C_idx] - pos[O_CO_idx])
    
    print(f"第一步后C-O_ads距离: {final_C_O_ads_dist_step1:.3f} Å")
    print(f"第一步后C-O_CO距离: {final_CO_dist_step1:.3f} Å")
    
    # 第二步：整体平移前三个原子来调整C到中心金属距离
    print("\n=== 第二步：调整C-Pd距离 ===")
    
    # 计算当前C到中心金属的距离
    current_C_middle_metal_dist = np.linalg.norm(pos[C_idx] - middle_metal_pos)
    print(f"当前C-Pd距离: {current_C_middle_metal_dist:.3f} Å")
    
    # 目标距离
    target_C_middle_metal_dist = 2.00  # Å
    
    # 计算需要移动的距离
    move_distance_Pd = target_C_middle_metal_dist - current_C_middle_metal_dist
    print(f"需要移动的距离: {move_distance_Pd:.3f} Å")
    
    # 关键修正：计算正确的移动方向
    # 如果move_distance_Pd为正，需要增加距离，C应该远离中心金属原子
    # 如果move_distance_Pd为负，需要减少距离，C应该靠近中心金属原子
    
    # 计算C到中心金属原子的方向向量（从C指向中心金属原子）
    C_to_middle_metal = middle_metal_pos - pos[C_idx]
    if np.linalg.norm(C_to_middle_metal) > 0:
        middle_metal_direction = C_to_middle_metal / np.linalg.norm(C_to_middle_metal)
    else:
        middle_metal_direction = np.array([1.0, 0.0, 0.0])
    
    print(f"C指向中心金属原子的方向向量: {middle_metal_direction}")
    
    # 根据移动距离的正负决定移动方向
    if move_distance_Pd > 0:
        # 需要增加距离，C应该远离Pd（与Pd方向相反）
        actual_move_direction = -middle_metal_direction
        print("移动方向：远离中心金属原子（与C->中心金属原子方向相反）")
    else:
        # 需要减少距离，C应该靠近Pd（与Pd方向相同）
        actual_move_direction = middle_metal_direction
        print("移动方向：靠近中心金属原子（与C->中心金属原子方向相同）")
    
    # 计算移动向量
    middle_metal_move = actual_move_direction * abs(move_distance_Pd)
    print(f"实际移动向量: {middle_metal_move}")
    
    # 整体平移前三个原子
    pos[C_idx] += middle_metal_move
    pos[O_CO_idx] += middle_metal_move
    pos[O_ads_idx] += middle_metal_move
    
    # 更新原子位置
    atoms.positions = pos
    
    # 最终验证结果
    final_C_O_ads_dist = np.linalg.norm(atoms.positions[C_idx] - atoms.positions[O_ads_idx])
    final_CO_dist = np.linalg.norm(atoms.positions[C_idx] - atoms.positions[O_CO_idx])
    final_C_middle_metal_dist = np.linalg.norm(atoms.positions[C_idx] - atoms.positions[middle_metal_idx])
    
    print(f"\n=== 最终结果 ===")
    print(f"调整后C-O_ads距离: {final_C_O_ads_dist:.3f} Å")
    print(f"调整后C-O_CO距离: {final_CO_dist:.3f} Å")
    print(f"调整后C-中心金属原子距离: {final_C_middle_metal_dist:.3f} Å")
    
    # 检查是否满足要求
    if (abs(final_C_O_ads_dist - 1.25) < 0.01 and 
        abs(final_CO_dist - 1.25) < 0.01 and 
        abs(final_C_middle_metal_dist - 2.00) < 0.01):
        print("所有距离要求均已满足！")
    else:
        print("警告：某些距离要求未完全满足")
        if abs(final_C_O_ads_dist - 1.25) >= 0.01:
            print(f"  C-O_ads距离误差: {abs(final_C_O_ads_dist - 1.25):.3f} Å")
        if abs(final_CO_dist - 1.25) >= 0.01:
            print(f"  C-O_CO距离误差: {abs(final_CO_dist - 1.25):.3f} Å")
        if abs(final_C_middle_metal_dist - 2.00) >= 0.01:
            print(f"  C-中心金属原子距离误差: {abs(final_C_middle_metal_dist - 2.00):.3f} Å")
    
    
    return atoms