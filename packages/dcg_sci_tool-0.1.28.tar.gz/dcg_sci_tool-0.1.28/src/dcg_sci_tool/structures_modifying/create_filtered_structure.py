
from typing import List, Set, Tuple, Dict
from ase import Atoms


def create_filtered_structure(data,
                             type_names_order: List[str],
                             keep_indexes_list: List[int],
                             old_indexes :List[int]
                             ) -> Atoms:
    """
    根据保留的原子索引创建新的ASE结构，并找到旧索引对应的新索引
    
    Args:

        data: OVITO数据对象

        type_names_order (list): 原子类型顺序列表

        keep_indexes_list (list): 需要保留的原子索引列表

        old_indexes (list): 要获得新索引的原子在旧索引中的索引列表

    
    Returns:

        new_atoms (ASE Atoms): 新的ASE原子对象

        new_indexes (list): 旧索引old_indexes对应的新的原子索引列表
        
    """
    # 使用OVITO读取文件，确保格式正确
    particles = data.particles

    # 获取原始晶胞参数，第四列是原点坐标，暂时不用
    ori_cell = data.cell.matrix[:, :3]
    
    # 从OVITO获取位置和符号
    positions = particles.positions[...]
    particle_types = particles.particle_types[...]
    
    # 获取保留原子的位置和符号
    keep_positions = []
    keep_symbols = []
    
    for idx in keep_indexes_list:
        keep_positions.append(positions[idx])
        
        # 获取原子类型对应的符号
        type_id = particle_types[idx]
        # 注意：type_id是从1开始的索引
        if 1 <= type_id <= len(type_names_order):
            symbol = type_names_order[type_id - 1]
        else:
            symbol = 'X'  # 未知元素
        keep_symbols.append(symbol)

    # 将保留的原子索引位于old_indexes中的部分从旧索引转换为新索引
    new_indexes = [keep_indexes_list.index(idx) for idx in old_indexes]


    # 创建新的ASE原子对象
    new_atoms = Atoms(symbols=keep_symbols, positions=keep_positions)
    new_atoms.set_cell(ori_cell) # 设定晶胞参数为原晶胞参数
    new_atoms.pbc = [True, True, True]  # 周期性边界条件

    return new_atoms, new_indexes