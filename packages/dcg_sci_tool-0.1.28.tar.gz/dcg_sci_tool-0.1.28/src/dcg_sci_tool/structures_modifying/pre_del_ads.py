
from dcg_sci_tool import *
from ovito.data import *
from ovito.io import import_file
from dcg_sci_tool.reaction.detect_nearby_ads_for_deletion import detect_nearby_ads_for_deletion

def pre_del_ads(input_file: str, c_idx, o_idx, cutoff = 6.0):
    """
    将优化后的反应中心附近有其他吸附物的neb轨迹文件第一帧结构中，距离目标C和O连线中点
    cutoff距离内的其他C和O原子删去，如果某个半径范围内的原子是吸附态气体分子的一部分，
    则整个分子会被删去，输出新的Atoms对象以及目标C和O原子的新的原子索引

    Args:

        input_file (str): 要处理的轨迹文件地址
        c_idx (int): 反应物CO中C原子序号
        o_idx (int): 反应物O原子的序号
        cutoff (float): 半径范围，默认6 Angstrom

    Returns:
        tuple: 处理后的结果

            filtered_atoms (Atoms): 处理后的Atoms对象
        
            tranfered_indexes (list): 转化后的目标C和O原子索引列表[c_idx, o_idx]

    """

    
    pipeline = import_file(input_file)
    type_names_order = extract_atom_types(input_file)
    frame = 0
    data = pipeline.compute(frame)

    # 获取要删除的原子的索引列表
    list_for_deletion = detect_nearby_ads_for_deletion(data, type_names_order,c_idx, o_idx, cutoff)

    # 获取要保留的原子的索引列表
    keep_indexes=[]
    for i in range(data.particles.count):
        if i not in list_for_deletion:
            keep_indexes.append(i)


    # 处理并输出新结构
    old_indexes_to_transfer = [c_idx, o_idx]
    filtered_atoms, tranfered_indexes = create_filtered_structure(data, type_names_order, keep_indexes, old_indexes_to_transfer)

    return filtered_atoms, tranfered_indexes