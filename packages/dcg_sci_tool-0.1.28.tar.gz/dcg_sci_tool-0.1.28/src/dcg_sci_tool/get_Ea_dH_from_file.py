import numpy as np

def get_Ea_dH_from_file(filename = "neb_mep.dat"):
    """
    通过读取neb_mep.dat文件，获取能垒和焓变数值

    Args:
        filename (str): neb_mep.dat文件地址，默认值为"neb_mep.dat"

    Returns:
        tuple: 能垒和焓变元组

            Ea: 能垒数值

            dH: 焓变数值
    """
    
    try:
        data = np.loadtxt(filename)
        if len(data.shape) > 1 and data.shape[1] >= 4:  # 确保有4列
            col4 = data[:, 3]  # 第4列（索引3）
            Ea = np.max(col4)  # 最大值
            dH = col4[-1]      # 最后一个值
            print(f"Ea (最大值): {Ea}")
            print(f"dH (最后值): {dH}")
        else:
            print("错误: 文件列数不足4列")
    except FileNotFoundError:
        print(f"错误: 文件 '{filename}' 不存在")
    except Exception as e:
        print(f"读取错误: {e}")
    return Ea, dH