import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from dcg_sci_tool.plot.mark_special_points import mark_special_points

def plot_scatter_color(input_csv_file: str, 
                       max_threshold=None, 
                       min_threshold=None,
                       special_point_list=None, 
                       x_label: str = 'PCA 1', 
                       y_label: str = 'PCA 2', 
                       colorbar_label: str = 'Energy (eV/atom)'):
    """
    绘制带颜色映射的散点图，可自定义阈值范围，高于或低于阈值的点将使用统一颜色。
    采用viridis（翠绿色）颜色映射方案，适合色盲友好型视觉效果。
    入参文件格式要求：CSV文件，前两列为点的X Y坐标，第三列为用于颜色映射的Z值。
    
    Args:
        input_csv_file: 输入CSV文件路径，文件前两列是点的X Y坐标，第三列是用于颜色映射的Z值
        max_threshold: 最大阈值，可选，默认为Z数据的最大值，如果不设，则没有色阶最大值截断
        min_threshold: 最小阈值，可选，默认为Z数据的最小值，如果不设，则没有色阶最小值截断
        special_point_list: 可选，包含特定点坐标和标签的字典列表，格式为 [{'coords': (x, y), 'label': '点标签'}, ...]
        x_label: X轴标签
        y_label: Y轴标签
        colorbar_label: Colorbar标签

    示例用法：    

    调用函数
    plot_scatter_color(
        input_csv_file='111.csv',
        max_threshold=-2,
        min_threshold=-6,
        x_label='PCA 1',
        y_label='PCA 2',
        colorbar_label='Energy (eV/atom)'
    )
    """
    
    # 读取CSV文件
    df = pd.read_csv(f'{input_csv_file}')
    # 提取数据
    x = df.iloc[:, 0]
    y = df.iloc[:, 1]
    z = df.iloc[:, 2]

    # 数据的最大值和最小值
    data_max = z.max()
    data_min = z.min()

    if max_threshold is None:
        max_threshold = data_max
    if min_threshold is None:
        min_threshold = data_min


    # 创建自定义颜色映射（用于中间渐变区域）
    # viridis（翠绿色）：色盲友好型颜色映射方案
    custom_cmap = plt.cm.viridis 
    # 获取顶部和底部的颜色
    top_color = custom_cmap(1.0)  # 颜色节点的最后一个颜色（浅色）
    bottom_color = custom_cmap(0.0)  # 颜色节点的第一个颜色（深色）


    # 创建图形
    plt.figure(figsize=(12, 8))

    # 绘制底部统一颜色区域（Z < min_threshold）
    mask_z_lt_min_threshold = z < min_threshold
    if mask_z_lt_min_threshold.any():
        plt.scatter(x[mask_z_lt_min_threshold], y[mask_z_lt_min_threshold], 
                   c=bottom_color,  # 使用统一的底部颜色
                   s=30, 
                   edgecolor='k', 
                   linewidth=0.0, 
                   alpha=0.5,
                   label=f'Z < {min_threshold}')

    # 2绘制中间渐变区域（min_threshold ≤ Z ≤ max_threshold）
    mask_in_range = (z >= min_threshold) & (z <= max_threshold)
    if mask_in_range.any():
        # 为中间区域创建独立的归一化对象
        norm_mid = mpl.colors.Normalize(vmin=min_threshold, vmax=max_threshold)
        
        scatter_mid = plt.scatter(x[mask_in_range], y[mask_in_range], 
                                 c=z[mask_in_range], 
                                 cmap=custom_cmap,  # 使用渐变颜色映射
                                 norm=norm_mid,  # 只在阈值范围内归一化
                                 s=30, 
                                 edgecolor='k', 
                                 linewidth=0.0, 
                                 alpha=0.5,
                                 label=f'{min_threshold} ≤ Z ≤ {max_threshold}')

    # 绘制顶部统一颜色区域（Z > max_threshold）
    mask_z_gt_max_threshold = z > max_threshold
    if mask_z_gt_max_threshold.any():
        plt.scatter(x[mask_z_gt_max_threshold], y[mask_z_gt_max_threshold], 
                   c=top_color,  # 使用统一的顶部颜色
                   s=30, 
                   edgecolor='k', 
                   linewidth=0, 
                   alpha=0.5,
                   label=f'Z > {max_threshold}')

    if special_point_list is not None:
        mark_special_points(special_point_list)  # 调用添加特定点的函数

 
    # 添加颜色条（只针对中间渐变区域）
    if mask_in_range.any():

        # 根据数据范围和设定的阈值范围，确定颜色条的extend参数
        extend = 'neither'
        if max_threshold < data_max and min_threshold > data_min:
            extend = 'both'
        if max_threshold < data_max and min_threshold == data_min:
            extend = 'max'
        if max_threshold == data_max and min_threshold > data_min:
            extend = 'min'

            

        cbar = plt.colorbar(scatter_mid,orientation='vertical', 
                       ticks=[min_threshold, max_threshold],
                       extend=f'{extend}')
        cbar.set_label(f'{colorbar_label}', fontsize=15)
        
        
        # 设置颜色条刻度，包括最小值、中间值、最大值
        ticks = [int(min_threshold), int((min_threshold + max_threshold) / 2), int(max_threshold)]
        # 刻度值设置
        cbar.set_ticks(ticks)
        # 刻度标签字体大小设置
        cbar.ax.tick_params(labelsize=12)
   
  

    # 设置坐标轴
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)
    plt.xlabel(f'{x_label}', fontsize=16)
    plt.ylabel(f'{y_label}', fontsize=16)

   
    # # 添加图例
    # plt.legend(fontsize=10, loc='best', framealpha=0.8)
    
    # 添加网格
    # plt.grid(True, alpha=0.2, linestyle='--')

    # 显示统计信息
    print("="*50)
    print("数据统计：")
    print(f"Z实际范围: [{z.min():.3f}, {z.max():.3f}]")
    print(f"设定阈值范围: [{min_threshold:.3f}, {max_threshold:.3f}]")
    print(f"底部区域(Z < {min_threshold})点数: {mask_z_lt_min_threshold.sum()}")
    print(f"中间区域({min_threshold} ≤ Z ≤ {max_threshold})点数: {mask_in_range.sum()}")
    print(f"顶部区域(Z > {max_threshold})点数: {mask_z_gt_max_threshold.sum()}")
    print("="*50)

    plt.tight_layout()
    plt.show()