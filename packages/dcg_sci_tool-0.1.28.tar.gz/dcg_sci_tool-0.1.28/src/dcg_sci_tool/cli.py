import argparse
import sys
from dcg_sci_tool.merge_xyz import merge_xyz
from dcg_sci_tool.applications.manual_name_xyz_png_at_nebdir import manual_name_xyz_png_at_nebdir
import os

# 第一步：为每个子命令定义其对应的处理函数
def merge_xyz_command(args):
    """
    处理 merge_xyz 子命令的实际逻辑。
    """
    print(f"正在处理输入文件列表: {args.input}")
    # 这里调用实际的合并函数
    merge_xyz(args.input)
    return 0

def manual_name_xyz_png_at_nebdir_command(args):
    """
    处理 manual_name_xyz_png_at_nebdir 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    manual_name_xyz_png_at_nebdir()
    return 0

def show_banner():
    """显示banner的函数"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    banner_path = os.path.join(script_dir, 'banner.txt')
    try:
        with open(banner_path, 'r', encoding='utf-8') as f:
            content = f.read()
        print(content)
    except FileNotFoundError:
        print("欢迎使用dcg-sci-tool！这是一个用于科学计算的工具包。")

def main():
    """主 CLI 入口函数"""
    
    # 1. 创建顶层解析器
    parser = argparse.ArgumentParser(
        description="dcg-sci-tool: 一个用于科学计算的工具包。",
        epilog="使用 'dcg-sci-tool <命令> -h' 查看具体命令帮助。",
        add_help=False  # 禁用默认的-h/--help处理
    )
    
    # 添加自定义的-h/--help参数
    parser.add_argument('-h', '--help', action='store_true', help='显示帮助信息')

    # 2. 创建子命令解析器
    subparsers = parser.add_subparsers(
        dest='command',
        title='可用命令',
        help='选择要执行的操作'
    )
    # 注意：这里不设置required=True，因为我们要处理无子命令的情况

    # 3. 定义 'merge_xyz' 子命令
    parser_merge_xyz = subparsers.add_parser(
        'merge_xyz',
        help='合并多个xyz文件'
    )
    
    parser_merge_xyz.add_argument(
        'input',
        nargs='+',
        help='要合并的xyz文件路径'
    )
    
    parser_merge_xyz.add_argument(
        '-o', '--output',
        default='merged.xyz',
        help='输出文件的路径 (默认: merged.xyz)'
    )
    
    # 4. 定义 'manual_name_xyz_png_at_nebdir' 子命令
    parser_manual_name_xyz_png_at_nebdir = subparsers.add_parser(
        'manual_name_xyz_png_at_nebdir',
        help='手动命名xyz文件和png文件'
    )
    
    parser_manual_name_xyz_png_at_nebdir.add_argument(
        '-d', '--directory',
        default='.',
        help='目标目录 (默认: 当前目录)'
    )

    # 5. 将子命令绑定到处理函数
    parser_merge_xyz.set_defaults(func=merge_xyz_command)
    parser_manual_name_xyz_png_at_nebdir.set_defaults(func=manual_name_xyz_png_at_nebdir_command)

    # 6. 解析参数
    try:
        args = parser.parse_args()
    except SystemExit:
        # 当parse_args()遇到错误（如无效参数）时会调用sys.exit()
        # 我们需要在这里捕获并显示帮助信息
        parser.print_help()
        sys.exit(2)
    
    # 7. 根据参数决定是否显示banner
    if not hasattr(args, 'func'):
        # 如果没有子命令，显示banner和帮助
        show_banner()
        print("\n" + "="*50 + "\n")
        parser.print_help()
        return 0
    
    # 8. 有子命令时，不显示banner，直接执行对应函数
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())