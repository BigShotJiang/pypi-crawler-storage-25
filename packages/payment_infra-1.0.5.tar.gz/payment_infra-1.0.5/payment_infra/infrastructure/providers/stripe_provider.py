"""Stripe provider implementation with secure defaults."""

import hashlib
import hmac
import time
from decimal import Decimal
from typing import Dict

import requests
from django.conf import settings

from payment_infra.application.interfaces.providers import (
    AbstractPaymentProvider,
    AbstractWebhookProvider,
)


class StripeProvider(AbstractPaymentProvider, AbstractWebhookProvider):
    def __init__(self):
        self.base_url = getattr(settings, "STRIPE_BASE_URL", "https://api.stripe.com/v1")
        self.secret_key = getattr(settings, "STRIPE_SECRET_KEY", None)
        self.public_key = getattr(settings, "STRIPE_PUBLIC_KEY", None)
        self.webhook_secret = getattr(settings, "STRIPE_WEBHOOK_SECRET", None)
        self.timeout = 20

        self.headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/x-www-form-urlencoded",
        }

    def charge(
        self,
        email: str,
        ref: str,
        amount: Decimal,
        currency: str,
        metadata: Dict,
        callback_url: str,
    ) -> Dict:
        payload = {
            "amount": int(amount * 100),
            "currency": currency.lower(),
            "receipt_email": email,
            "description": f"Payment reference: {ref}",
            "metadata[reference]": ref,
        }

        if callback_url:
            payload["return_url"] = callback_url

        response = requests.post(
            f"{self.base_url}/payment_intents",
            data=payload,
            headers=self.headers,
            timeout=self.timeout,
        )
        response.raise_for_status()

        data = response.json()
        return {
            "status": True,
            "message": "Payment intent created",
            "data": {
                "authorization_url": data.get("next_action", {})
                .get("redirect_to_url", {})
                .get("url"),
                "reference": ref,
                "access_code": data.get("client_secret"),
                "payment_intent": data.get("id"),
            },
        }

    def verify(self, reference: str) -> Dict:
        response = requests.get(
            f"{self.base_url}/payment_intents/{reference}",
            headers={"Authorization": f"Bearer {self.secret_key}"},
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()

        succeeded = data.get("status") == "succeeded"
        return {
            "status": succeeded,
            "message": "Payment verified" if succeeded else "Payment not successful",
            "data": data,
        }

    def verify_signature(self, payload: bytes, signature: str) -> bool:
        if not self.webhook_secret or not signature:
            return False

        elements = [item for item in signature.split(",") if item]
        timestamp_part = next((item for item in elements if item.startswith("t=")), None)
        signed_part = next((item for item in elements if item.startswith("v1=")), None)

        if not timestamp_part or not signed_part:
            return False

        timestamp = timestamp_part.split("=", 1)[1]
        incoming_signature = signed_part.split("=", 1)[1]

        signed_payload = f"{timestamp}.".encode() + payload
        expected = hmac.new(
            self.webhook_secret.encode(),
            signed_payload,
            hashlib.sha256,
        ).hexdigest()

        try:
            event_time = int(timestamp)
        except ValueError:
            return False

        is_recent = abs(time.time() - event_time) <= 300
        return is_recent and hmac.compare_digest(expected, incoming_signature)
