"""Provider registry for payment and webhook integrations."""

from django.conf import settings

from payment_infra.application.services.payment_service import PaymentService
from payment_infra.application.webhooks.event_mapper import PaystackEventMapper
from payment_infra.infrastructure.idempotency.service import IdempotencyService
from payment_infra.infrastructure.providers.monnify_provider import MonnifyProvider
from payment_infra.infrastructure.providers.paystack_provider import PaystackProvider
from payment_infra.infrastructure.providers.stripe_provider import StripeProvider
from payment_infra.infrastructure.repositories.repository import PaymentRepository

DEFAULTS = {
    "PROVIDER": "paystack",
}


def get_setting(name):
    return getattr(settings, f"DJANGO_PAYMENTS_{name}", DEFAULTS.get(name))


def get_provider():
    provider_path = get_setting("PROVIDER").lower()

    if provider_path == "paystack":
        return PaystackProvider()
    if provider_path == "stripe":
        return StripeProvider()
    if provider_path == "monnify":
        return MonnifyProvider()

    raise ValueError("Unsupported payment provider")


def get_mapper():
    provider_path = get_setting("PROVIDER").lower()

    if provider_path == "paystack":
        return PaystackEventMapper()

    return None


def get_payment_service():
    return PaymentService(
        repository=PaymentRepository(),
        provider=get_provider(),
        idempotency_service=IdempotencyService(),
        mapper=get_mapper(),
    )
