"""Monnify payment provider implementation with secure request signing and token handling."""

import base64
import hashlib
import hmac
from decimal import Decimal
from typing import Dict

import requests
from django.conf import settings

from payment_infra.application.interfaces.providers import (
    AbstractPaymentProvider,
    AbstractWebhookProvider,
)


class MonnifyProvider(AbstractPaymentProvider, AbstractWebhookProvider):
    def __init__(self):
        self.base_url = getattr(settings, "MONNIFY_BASE_URL", "https://api.monnify.com")
        self.api_key = getattr(settings, "MONNIFY_API_KEY", None)
        self.secret_key = getattr(settings, "MONNIFY_SECRET_KEY", None)
        self.contract_code = getattr(settings, "MONNIFY_CONTRACT_CODE", None)
        self.public_key = getattr(settings, "MONNIFY_PUBLIC_KEY", None)
        self.timeout = 20

    def _auth_header(self) -> Dict[str, str]:
        credentials = f"{self.api_key}:{self.secret_key}".encode()
        token = base64.b64encode(credentials).decode()

        login_response = requests.post(
            f"{self.base_url}/api/v1/auth/login",
            headers={"Authorization": f"Basic {token}"},
            timeout=self.timeout,
        )
        login_response.raise_for_status()
        auth_data = login_response.json()
        access_token = auth_data.get("responseBody", {}).get("accessToken")

        return {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

    def charge(
        self,
        email: str,
        ref: str,
        amount: Decimal,
        currency: str,
        metadata: Dict,
        callback_url: str,
    ) -> Dict:
        payload = {
            "amount": float(amount),
            "customerName": metadata.get("customer_name", email),
            "customerEmail": email,
            "paymentReference": ref,
            "paymentDescription": metadata.get("description", f"Payment reference: {ref}"),
            "currencyCode": currency,
            "contractCode": self.contract_code,
            "redirectUrl": callback_url,
            "paymentMethods": metadata.get("payment_methods", ["CARD", "ACCOUNT_TRANSFER"]),
        }

        response = requests.post(
            f"{self.base_url}/api/v1/merchant/transactions/init-transaction",
            json=payload,
            headers=self._auth_header(),
            timeout=self.timeout,
        )
        response.raise_for_status()

        data = response.json().get("responseBody", {})
        return {
            "status": True,
            "message": "Transaction initialized",
            "data": {
                "authorization_url": data.get("checkoutUrl"),
                "reference": data.get("paymentReference", ref),
                "access_code": data.get("transactionReference"),
            },
        }

    def verify(self, reference: str) -> Dict:
        response = requests.get(
            f"{self.base_url}/api/v2/transactions/{reference}",
            headers=self._auth_header(),
            timeout=self.timeout,
        )
        response.raise_for_status()

        data = response.json().get("responseBody", {})
        status = data.get("paymentStatus") == "PAID"

        return {
            "status": status,
            "message": "Payment verified" if status else "Payment not successful",
            "data": data,
        }

    def verify_signature(self, payload: bytes, signature: str) -> bool:
        if not self.secret_key or not signature:
            return False

        computed = hmac.new(
            self.secret_key.encode(),
            payload,
            hashlib.sha512,
        ).hexdigest()

        return hmac.compare_digest(computed, signature)
