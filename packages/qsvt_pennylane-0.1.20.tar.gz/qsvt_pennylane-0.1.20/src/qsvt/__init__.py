"""
qsvt
----

Educational PennyLane-based utilities for Quantum Singular Value
Transformation (QSVT) and Quantum Signal Processing (QSP).

This package provides lightweight helpers for:

- Chebyshev and polynomial utilities
- function approximation on bounded intervals
- small Hermitian matrix construction
- spectral matrix-function reference calculations
- explicit QSVT matrix extraction and comparison workflows

The project is designed for small-scale demonstrations, notebooks, and
classical validation of QSVT/QSP ideas.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

from .algorithms import (
    GroundStateFilteringWorkflowResult,
    HamiltonianSimulationWorkflowResult,
    LinearSystemWorkflowResult,
    ResolventWorkflowResult,
    SpectralDensityWorkflowResult,
    ThermalGibbsWorkflowResult,
    ground_state_filtering_workflow,
    hamiltonian_simulation_workflow,
    linear_system_workflow,
    resolvent_workflow,
    spectral_density_workflow,
    thermal_gibbs_workflow,
)
from .approximation import (
    approximation_quality_report,
    chebyshev_approximant,
    chebyshev_eval,
    chebyshev_fit_function,
    fit_and_build_approximant,
    max_error,
    rms_error,
    sample_approximation,
    scale_from_chebyshev_domain,
    scale_to_chebyshev_domain,
)
from .design import (
    design_filter_diagnostics,
    design_filter_polynomial,
    design_interval_projector_diagnostics,
    design_interval_projector_polynomial,
    design_inverse_diagnostics,
    design_inverse_polynomial,
    design_positive_inverse_diagnostics,
    design_positive_inverse_polynomial,
    design_power_diagnostics,
    design_power_polynomial,
    design_projector_diagnostics,
    design_projector_polynomial,
    design_sign_diagnostics,
    design_sign_polynomial,
    design_sqrt_diagnostics,
    design_sqrt_polynomial,
)
from .diagnostics import (
    density_matrix_error,
    expectation_value,
    ground_state_overlap,
    operator_error,
    relative_state_error,
    spectral_weights,
)
from .hamiltonians import (
    heisenberg_chain,
    ising_hamiltonian,
    pauli_string_matrix,
    tight_binding_chain,
)
from .matrices import (
    diagonal_matrix,
    embed_vector,
    hermitian_from_eigendecomposition,
    identity,
    involutory_diagonal,
    normalized_vector,
    pauli_x,
    pauli_z,
    rotated_diagonal,
    rotation,
)
from .matrix_functions import (
    RealTimeEvolutionPolynomials,
    ScaledPolynomial,
    design_gaussian_window_polynomial,
    design_imaginary_time_polynomial,
    design_low_energy_projector_polynomial,
    design_positive_inverse_matrix_polynomial,
    design_real_time_evolution_polynomials,
    design_resolvent_polynomials,
)
from .pde import (
    dirichlet_laplacian_1d,
    dirichlet_laplacian_2d,
    periodic_laplacian_1d,
)
from .polynomials import (
    chebyshev_t,
    chebyshev_t3,
    chebyshev_to_monomial,
    eval_polynomial,
    is_bounded_on_interval,
    monomial_to_chebyshev,
    normalize_coefficients,
    polynomial_degree,
    polynomial_parity,
)
from .qsvt import (
    apply_qsvt_to_embedded_vector,
    classical_diagonal_polynomial_transform,
    compare_qsvt_vs_classical_diagonal,
    compare_qsvt_vs_classical_matrix,
    qsvt_compatibility_report,
    qsvt_diagonal_transform,
    qsvt_matrix_transform,
    qsvt_matrix_transform_report,
    qsvt_operator,
    qsvt_scalar_output,
    qsvt_scalar_scan,
    qsvt_top_left_block,
    qsvt_transform_report,
    qsvt_unitary,
)
from .reports import (
    load_report,
    plot_approximation_report,
    report_to_jsonable,
    save_report,
    save_report_plot,
)
from .rescaling import (
    ScaledOperator,
    rescale_hermitian_about_cutoff,
    rescale_hermitian_to_unit_interval,
    rescale_positive_semidefinite,
    spectral_bounds,
)
from .spectral import (
    apply_function_to_hermitian,
    apply_polynomial_to_hermitian,
    eigh_hermitian,
    matrix_fractional_power,
    matrix_from_eigendecomposition,
    matrix_power_spectral,
    matrix_sign,
    matrix_square_root,
    negative_projector_from_sign,
    positive_projector_from_sign,
    spectral_projector_negative,
    spectral_projector_positive,
    transformed_eigenvalues,
)
from .templates import (
    exponential_approximation_diagnostics,
    exponential_approximation_polynomial,
    inverse_like_diagnostics,
    inverse_like_polynomial,
    sign_approximation_diagnostics,
    sign_approximation_polynomial,
    soft_threshold_filter_diagnostics,
    soft_threshold_filter_polynomial,
    sqrt_approximation_diagnostics,
    sqrt_approximation_polynomial,
)
from .workflow import DesignWorkflowResult, design_workflow

# Version ----------------------------------------------------------------------
try:
    __version__ = _pkg_version("qsvt-pennylane")
except PackageNotFoundError:  # pragma: no cover
    # Allows editable installs / local runs without installed dist metadata.
    __version__ = "0.0.0"

__api_status__ = "alpha"
__public_api_policy__ = (
    "Names exported from qsvt.__all__ are the intended public API. During the "
    "0.x series, incompatible changes should be documented in the changelog and "
    "prefer a deprecation period when practical."
)

__all__ = [
    "__version__",
    "__api_status__",
    "__public_api_policy__",
    "GroundStateFilteringWorkflowResult",
    "HamiltonianSimulationWorkflowResult",
    "LinearSystemWorkflowResult",
    "ResolventWorkflowResult",
    "SpectralDensityWorkflowResult",
    "ThermalGibbsWorkflowResult",
    "approximation_quality_report",
    "chebyshev_approximant",
    "chebyshev_eval",
    "chebyshev_fit_function",
    "fit_and_build_approximant",
    "max_error",
    "rms_error",
    "sample_approximation",
    "scale_from_chebyshev_domain",
    "scale_to_chebyshev_domain",
    "chebyshev_to_monomial",
    "monomial_to_chebyshev",
    "diagonal_matrix",
    "embed_vector",
    "exponential_approximation_polynomial",
    "exponential_approximation_diagnostics",
    "inverse_like_polynomial",
    "inverse_like_diagnostics",
    "sign_approximation_polynomial",
    "sign_approximation_diagnostics",
    "soft_threshold_filter_polynomial",
    "soft_threshold_filter_diagnostics",
    "sqrt_approximation_polynomial",
    "sqrt_approximation_diagnostics",
    "DesignWorkflowResult",
    "design_workflow",
    "ground_state_filtering_workflow",
    "hamiltonian_simulation_workflow",
    "linear_system_workflow",
    "resolvent_workflow",
    "spectral_density_workflow",
    "thermal_gibbs_workflow",
    "hermitian_from_eigendecomposition",
    "identity",
    "involutory_diagonal",
    "normalized_vector",
    "pauli_x",
    "pauli_z",
    "design_filter_polynomial",
    "design_filter_diagnostics",
    "design_interval_projector_polynomial",
    "design_interval_projector_diagnostics",
    "design_inverse_polynomial",
    "design_inverse_diagnostics",
    "design_positive_inverse_polynomial",
    "design_positive_inverse_diagnostics",
    "design_power_polynomial",
    "design_power_diagnostics",
    "design_projector_polynomial",
    "design_projector_diagnostics",
    "design_sign_polynomial",
    "design_sign_diagnostics",
    "design_sqrt_polynomial",
    "design_sqrt_diagnostics",
    "rotated_diagonal",
    "rotation",
    "chebyshev_t",
    "chebyshev_t3",
    "eval_polynomial",
    "is_bounded_on_interval",
    "normalize_coefficients",
    "polynomial_degree",
    "polynomial_parity",
    "ScaledOperator",
    "rescale_hermitian_about_cutoff",
    "rescale_hermitian_to_unit_interval",
    "rescale_positive_semidefinite",
    "spectral_bounds",
    "tight_binding_chain",
    "ising_hamiltonian",
    "heisenberg_chain",
    "pauli_string_matrix",
    "dirichlet_laplacian_1d",
    "dirichlet_laplacian_2d",
    "periodic_laplacian_1d",
    "RealTimeEvolutionPolynomials",
    "ScaledPolynomial",
    "design_gaussian_window_polynomial",
    "design_imaginary_time_polynomial",
    "design_low_energy_projector_polynomial",
    "design_positive_inverse_matrix_polynomial",
    "design_real_time_evolution_polynomials",
    "design_resolvent_polynomials",
    "density_matrix_error",
    "expectation_value",
    "ground_state_overlap",
    "operator_error",
    "relative_state_error",
    "spectral_weights",
    "apply_qsvt_to_embedded_vector",
    "classical_diagonal_polynomial_transform",
    "compare_qsvt_vs_classical_diagonal",
    "compare_qsvt_vs_classical_matrix",
    "qsvt_diagonal_transform",
    "qsvt_matrix_transform",
    "qsvt_matrix_transform_report",
    "qsvt_operator",
    "qsvt_compatibility_report",
    "qsvt_scalar_output",
    "qsvt_scalar_scan",
    "qsvt_top_left_block",
    "qsvt_transform_report",
    "qsvt_unitary",
    "load_report",
    "plot_approximation_report",
    "report_to_jsonable",
    "save_report",
    "save_report_plot",
    "apply_function_to_hermitian",
    "apply_polynomial_to_hermitian",
    "eigh_hermitian",
    "matrix_fractional_power",
    "matrix_from_eigendecomposition",
    "matrix_power_spectral",
    "matrix_sign",
    "matrix_square_root",
    "negative_projector_from_sign",
    "positive_projector_from_sign",
    "spectral_projector_negative",
    "spectral_projector_positive",
    "transformed_eigenvalues",
]
