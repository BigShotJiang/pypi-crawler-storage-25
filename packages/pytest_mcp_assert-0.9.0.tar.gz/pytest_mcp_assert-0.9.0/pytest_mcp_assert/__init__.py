"""pytest plugin for mcp-assert."""

__version__ = "0.9.0"
