# ShapleyCut API

Dedicated service for the ShapleyCut compression engine. This package exposes HTTP endpoints for optimizing memory and running the gateway mode.

## Install

```bash
pip install shapleycut-api
```

## Quickstart

```bash
python -m uvicorn shapleycut_api.main:app --host 0.0.0.0 --port 8000
```

If you are on Python 3.14 and see `httptools` errors, use:

```bash
python -m uvicorn shapleycut_api.main:app --host 0.0.0.0 --port 8000 --http h11
```

## Endpoints

- `GET /health`
- `POST /v1/optimize`
- `POST /v1/chat/completions`
- `POST /v1/responses`
- `GET /v1/metrics`
- `GET /v1/metrics/export`

## Environment

LLM credentials (server side only):

- `GITHUB_TOKEN` or `GH_TOKEN`
- `GITHUB_INFERENCE_BASE_URL` (default: `https://models.github.ai/inference`)
- `OPENAI_API_KEY`
- `OPENAI_BASE_URL` (default: `https://api.openai.com/v1`)

Gateway settings:

- `SHAPLEYCUT_GATEWAY_PROVIDER` (`github_azure`, `openai`, `anthropic`)
- `SHAPLEYCUT_GATEWAY_BASE_URL`
- `SHAPLEYCUT_GATEWAY_API_KEY_ENV`
- `SHAPLEYCUT_GATEWAY_API_KEY`
- `SHAPLEYCUT_GATEWAY_REQUIRE_KEY`
- `SHAPLEYCUT_GATEWAY_ALLOW_OVERRIDE`
- `SHAPLEYCUT_GATEWAY_LOG`
- `SHAPLEYCUT_GATEWAY_DB`
- `SHAPLEYCUT_GATEWAY_METRICS_MAX`
- `SHAPLEYCUT_GATEWAY_CACHE_MAX`
- `SHAPLEYCUT_GATEWAY_CACHE_TTL_S`

## Notes

- `/v1/responses` is not supported when `SHAPLEYCUT_GATEWAY_PROVIDER=github_azure`. Use `/v1/chat/completions` or set the provider to `openai`.
