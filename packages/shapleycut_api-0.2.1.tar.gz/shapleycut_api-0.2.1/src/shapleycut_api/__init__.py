"""ShapleyCut HTTP API."""
