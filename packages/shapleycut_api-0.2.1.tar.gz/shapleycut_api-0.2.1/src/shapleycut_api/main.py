from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).resolve().parent.parent.parent / ".env")

from shapleycut_core import MemoryMessage, OptimizeConfig, OptimizeInput, optimize
from shapleycut_api.gateway import router as gateway_router

app = FastAPI(title="ShapleyCut API", version="0.1.0")
app.include_router(gateway_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


class OptimizeRequestBody(BaseModel):
    memory: str | None = Field(
        default=None,
        description="Raw memory / history to optimize",
    )
    messages: list[MemoryMessage] | None = Field(
        default=None,
        description="Optional structured chat history for role-aware optimization",
    )
    prompt: str | None = None
    max_output_tokens: int | None = Field(
        default=None,
        ge=64,
        description="Approximate token budget for returned memory",
    )
    config: OptimizeConfig | None = Field(
        default=None,
        description="Engine options; use GITHUB_TOKEN (GitHub Models / Azure Inference) or OPENAI_API_KEY on the server",
    )


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/optimize")
def optimize_memory(body: OptimizeRequestBody) -> dict:
    cfg = body.config or OptimizeConfig()
    cfg.inference_provider = "github_azure"
    inp = OptimizeInput(
        memory=body.memory,
        messages=body.messages,
        prompt=body.prompt,
        max_output_tokens=body.max_output_tokens or 4096,
        config=cfg,
    )
    result = optimize(inp)
    return result.model_dump()
