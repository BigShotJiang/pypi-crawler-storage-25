from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any, Literal

import httpx
from fastapi import APIRouter, HTTPException, Query, Request, Response
from pydantic import BaseModel, Field

from shapleycut_core import MemoryMessage, OptimizeConfig, OptimizeInput, optimize
from shapleycut_core.tokens import count_tokens

router = APIRouter()

_METRICS_LOCK = threading.Lock()
_METRICS_MAX = int(os.getenv("SHAPLEYCUT_GATEWAY_METRICS_MAX", "200"))
_METRICS = deque(maxlen=max(_METRICS_MAX, 1))
_DB_INITIALIZED = False

_CACHE_LOCK = threading.Lock()
_CACHE_MAX = int(os.getenv("SHAPLEYCUT_GATEWAY_CACHE_MAX", "0"))
_CACHE_TTL_S = int(os.getenv("SHAPLEYCUT_GATEWAY_CACHE_TTL_S", "300"))
_CACHE: dict[str, tuple[float, Any]] = {}
_CACHE_ORDER: deque[str] = deque()


class PolicyConfig(BaseModel):
    max_output_tokens: int = Field(default=2048, ge=64)
    summarize_omitted: bool = True
    use_llm_final_squeeze: bool = True
    selection_target_ratio: float | None = Field(default=None, ge=0.5, le=0.98)


class ApiKeyConfig(BaseModel):
    key: str
    policy: PolicyConfig | None = None


class UpstreamConfig(BaseModel):
    provider: Literal["openai", "github_azure", "anthropic"] = "github_azure"
    base_url: str
    api_key_env: str


class GatewayConfig(BaseModel):
    api_keys: list[ApiKeyConfig] = Field(default_factory=list)
    default_policy: PolicyConfig = Field(default_factory=PolicyConfig)
    upstream: UpstreamConfig


def _default_upstream(provider: str) -> UpstreamConfig:
    if provider == "openai":
        base = os.getenv("SHAPLEYCUT_GATEWAY_BASE_URL", "https://api.openai.com/v1")
        api_key_env = os.getenv("SHAPLEYCUT_GATEWAY_API_KEY_ENV", "OPENAI_API_KEY")
        return UpstreamConfig(provider="openai", base_url=base, api_key_env=api_key_env)
    if provider == "anthropic":
        base = os.getenv("SHAPLEYCUT_GATEWAY_BASE_URL", "https://api.anthropic.com")
        api_key_env = os.getenv("SHAPLEYCUT_GATEWAY_API_KEY_ENV", "ANTHROPIC_API_KEY")
        return UpstreamConfig(provider="anthropic", base_url=base, api_key_env=api_key_env)
    base = os.getenv("SHAPLEYCUT_GATEWAY_BASE_URL", "https://models.github.ai/inference")
    api_key_env = os.getenv("SHAPLEYCUT_GATEWAY_API_KEY_ENV", "GITHUB_TOKEN")
    return UpstreamConfig(provider="github_azure", base_url=base, api_key_env=api_key_env)


def _config_path() -> Path:
    return Path(os.getenv("SHAPLEYCUT_GATEWAY_CONFIG", Path(__file__).resolve().parent.parent.parent / "gateway-config.json"))


def _load_gateway_config() -> GatewayConfig:
    path = _config_path()
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        return GatewayConfig.model_validate(data)

    provider = os.getenv("SHAPLEYCUT_GATEWAY_PROVIDER", "github_azure")
    api_key = os.getenv("SHAPLEYCUT_GATEWAY_API_KEY", "").strip()
    api_keys = [ApiKeyConfig(key=api_key)] if api_key else []
    return GatewayConfig(api_keys=api_keys, upstream=_default_upstream(provider))


def _policy_for_key(cfg: GatewayConfig, key: str | None) -> PolicyConfig:
    if key:
        for entry in cfg.api_keys:
            if entry.key == key:
                return entry.policy or cfg.default_policy
    return cfg.default_policy


def _allow_policy_override() -> bool:
    return os.getenv("SHAPLEYCUT_GATEWAY_ALLOW_OVERRIDE", "").lower() in {"1", "true", "yes"}


def _apply_policy_override(policy: PolicyConfig, override: str | None) -> PolicyConfig:
    if not override:
        return policy
    mode = override.strip().lower()
    if mode in {"default", "full"}:
        return policy

    updated = policy.model_copy(deep=True)
    if mode == "extractive_only":
        updated.summarize_omitted = False
        updated.use_llm_final_squeeze = False
        return updated
    if mode == "summarize_only":
        updated.summarize_omitted = True
        updated.use_llm_final_squeeze = False
        return updated
    if mode == "squeeze_only":
        updated.summarize_omitted = False
        updated.use_llm_final_squeeze = True
        return updated
    return policy


def _require_api_key(cfg: GatewayConfig) -> bool:
    if os.getenv("SHAPLEYCUT_GATEWAY_REQUIRE_KEY", "").lower() in {"1", "true", "yes"}:
        return True
    return len(cfg.api_keys) > 0


def _cache_enabled() -> bool:
    return _CACHE_MAX > 0 and _CACHE_TTL_S > 0


def _cache_key(parts: list[Any]) -> str:
    blob = json.dumps(parts, ensure_ascii=True, sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _cache_get(key: str) -> Any | None:
    if not _cache_enabled():
        return None
    now = time.time()
    with _CACHE_LOCK:
        entry = _CACHE.get(key)
        if not entry:
            return None
        ts, value = entry
        if now - ts > _CACHE_TTL_S:
            _CACHE.pop(key, None)
            return None
        return value


def _cache_set(key: str, value: Any) -> None:
    if not _cache_enabled():
        return
    with _CACHE_LOCK:
        if key not in _CACHE:
            _CACHE_ORDER.append(key)
        _CACHE[key] = (time.time(), value)
        while len(_CACHE_ORDER) > _CACHE_MAX:
            evict = _CACHE_ORDER.popleft()
            _CACHE.pop(evict, None)


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(parts)
    return ""


def _structured_messages(messages: list[dict[str, Any]]) -> list[MemoryMessage]:
    out: list[MemoryMessage] = []
    for msg in messages:
        role = str(msg.get("role", "user")).strip() or "user"
        if role not in {"system", "user", "assistant", "tool"}:
            role = "user"
        content = _extract_text(msg.get("content"))
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            serialized_calls = json.dumps(tool_calls, ensure_ascii=True)
            content = f"{content}\n\nTool calls: {serialized_calls}" if content else f"Tool calls: {serialized_calls}"
        if not content:
            continue
        out.append(MemoryMessage(role=role, content=content))
    return out


def _compress_messages(messages: list[dict[str, Any]], policy: PolicyConfig) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    cache_key = _cache_key(["chat", messages, policy.model_dump()])
    cached = _cache_get(cache_key)
    if cached:
        new_messages, telemetry = cached
        telemetry = {**telemetry, "cache_hit": True}
        return new_messages, telemetry

    system_msgs = [m for m in messages if m.get("role") == "system"]
    non_system = [m for m in messages if m.get("role") != "system"]

    prompt_msg = next((m for m in reversed(non_system) if m.get("role") == "user"), None)
    history = [m for m in non_system if m is not prompt_msg]

    history_messages = _structured_messages(history)
    prompt = _extract_text(prompt_msg.get("content")) if prompt_msg else None

    cfg = OptimizeConfig(
        summarize_omitted=policy.summarize_omitted,
        use_llm_final_squeeze=policy.use_llm_final_squeeze,
    )
    if policy.selection_target_ratio is not None:
        cfg.selection_target_ratio = policy.selection_target_ratio

    if history_messages:
        out = optimize(
            OptimizeInput(
                messages=history_messages,
                prompt=prompt,
                max_output_tokens=policy.max_output_tokens,
                config=cfg,
            )
        )
        compressed_memory = out.optimized_memory
        telemetry = {
            "segments_in": out.segments_in,
            "segments_kept": out.segments_kept,
            "segments_dropped": out.segments_dropped,
            "stages": out.compression_stages,
            "notes": out.notes,
            "input_tokens": out.estimated_input_tokens,
            "output_tokens": out.estimated_output_tokens,
        }
    else:
        compressed_memory = ""
        telemetry = {
            "segments_in": 0,
            "segments_kept": 0,
            "segments_dropped": 0,
            "stages": [],
            "notes": "no_history",
            "input_tokens": 0,
            "output_tokens": 0,
        }

    new_messages: list[dict[str, Any]] = []
    new_messages.extend(system_msgs)
    if compressed_memory.strip():
        new_messages.append(
            {
                "role": "system",
                "content": "Compressed context:\n" + compressed_memory.strip(),
            }
        )
    if prompt_msg:
        new_messages.append(prompt_msg)
    _cache_set(cache_key, (new_messages, telemetry))
    return new_messages, telemetry


def _log_telemetry(payload: dict[str, Any]) -> None:
    path = os.getenv("SHAPLEYCUT_GATEWAY_LOG", "").strip()
    record = json.dumps(payload, ensure_ascii=True)

    with _METRICS_LOCK:
        _METRICS.append(payload)

    if path:
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(record + "\n")

    db_path = os.getenv("SHAPLEYCUT_GATEWAY_DB", "").strip()
    if db_path:
        _write_telemetry_db(db_path, record)


def _debug_log(message: str) -> None:
    path = os.getenv("SHAPLEYCUT_GATEWAY_DEBUG_LOG", "").strip()
    if not path:
        return
    stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(f"[{stamp}] {message}\n")


def _write_telemetry_db(db_path: str, record: str) -> None:
    global _DB_INITIALIZED
    conn = sqlite3.connect(db_path)
    try:
        if not _DB_INITIALIZED:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS gateway_telemetry ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "ts REAL,"
                "payload TEXT"
                ")"
            )
            _DB_INITIALIZED = True
        try:
            payload = json.loads(record)
            ts = float(payload.get("ts") or time.time())
        except Exception:
            ts = time.time()
        conn.execute(
            "INSERT INTO gateway_telemetry (ts, payload) VALUES (?, ?)",
            (ts, record),
        )
        conn.commit()
    finally:
        conn.close()


def _aggregate_metrics(items: list[dict[str, Any]]) -> dict[str, Any]:
    count = len(items)
    if count == 0:
        return {"count": 0, "avg_latency_ms": None}

    latencies = [item.get("latency_ms") for item in items if isinstance(item.get("latency_ms"), int)]
    avg_latency = int(sum(latencies) / len(latencies)) if latencies else None
    return {"count": count, "avg_latency_ms": avg_latency}


def _extract_compression(item: dict[str, Any]) -> dict[str, Any] | None:
    compression = item.get("compression")
    return compression if isinstance(compression, dict) else None


def _load_db_metrics(db_path: str) -> list[dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    try:
        rows = conn.execute(
            "SELECT payload FROM gateway_telemetry ORDER BY ts DESC LIMIT 1000"
        ).fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()

    items: list[dict[str, Any]] = []
    for (payload,) in rows:
        try:
            parsed = json.loads(payload)
        except Exception:
            continue
        if isinstance(parsed, dict):
            items.append(parsed)
    return items


def _metrics_summary(items: list[dict[str, Any]]) -> dict[str, Any]:
    compression_items = [
        compression
        for item in items
        if (compression := _extract_compression(item)) is not None
    ]
    if not compression_items:
        return {
            "requests": len(items),
            "compressed_requests": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "tokens_saved": 0,
            "avg_compression_ratio": None,
            "avg_latency_ms": _aggregate_metrics(items).get("avg_latency_ms"),
            "estimated_cost_saved_usd": 0.0,
        }

    input_tokens = sum(
        value
        for item in compression_items
        if isinstance((value := item.get("input_tokens")), int)
    )
    output_tokens = sum(
        value
        for item in compression_items
        if isinstance((value := item.get("output_tokens")), int)
    )
    tokens_saved = max(0, input_tokens - output_tokens)
    avg_ratio = round(output_tokens / input_tokens, 4) if input_tokens else None

    # Rough blended estimate for dashboarding; providers vary and this is not billing truth.
    estimated_cost_saved_usd = round(tokens_saved / 1_000_000 * 5.0, 4)

    return {
        "requests": len(items),
        "compressed_requests": len(compression_items),
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "tokens_saved": tokens_saved,
        "avg_compression_ratio": avg_ratio,
        "avg_latency_ms": _aggregate_metrics(items).get("avg_latency_ms"),
        "estimated_cost_saved_usd": estimated_cost_saved_usd,
    }


def _adapt_to_anthropic(body: dict[str, Any]) -> dict[str, Any]:
    messages = body.get("messages")
    if not isinstance(messages, list):
        raise HTTPException(status_code=400, detail="Anthropic adapter requires messages array")

    system_parts: list[str] = []
    out_messages: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role")
        content = _extract_text(msg.get("content"))
        if role == "system":
            if content:
                system_parts.append(content)
            continue
        if content:
            out_messages.append({"role": role, "content": content})

    payload: dict[str, Any] = {
        "model": body.get("model", "claude-3-5-sonnet-20240620"),
        "messages": out_messages,
        "max_tokens": body.get("max_tokens", 1024),
    }
    if system_parts:
        payload["system"] = "\n\n".join(system_parts)
    if "temperature" in body:
        payload["temperature"] = body["temperature"]
    return payload


def _anthropic_to_openai(data: dict[str, Any]) -> dict[str, Any]:
    content_blocks = data.get("content", [])
    text_parts: list[str] = []
    for block in content_blocks:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str):
                text_parts.append(text)

    usage = data.get("usage", {}) if isinstance(data.get("usage"), dict) else {}
    prompt_tokens = usage.get("input_tokens")
    completion_tokens = usage.get("output_tokens")
    total_tokens = None
    if isinstance(prompt_tokens, int) and isinstance(completion_tokens, int):
        total_tokens = prompt_tokens + completion_tokens

    response = {
        "id": f"chatcmpl_{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": data.get("model", "anthropic"),
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": "\n".join(text_parts).strip(),
                },
                "finish_reason": data.get("stop_reason", "stop"),
            }
        ],
    }
    if total_tokens is not None:
        response["usage"] = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": total_tokens,
        }
    return response


def _session_id(header_value: str | None) -> str:
    if header_value and header_value.strip():
        return header_value.strip()
    return str(uuid.uuid4())


def _validate_key(cfg: GatewayConfig, key: str | None) -> None:
    if not _require_api_key(cfg):
        return
    if not key:
        raise HTTPException(status_code=401, detail="Missing x-shapleycut-api-key")
    if not any(entry.key == key for entry in cfg.api_keys):
        raise HTTPException(status_code=403, detail="Invalid x-shapleycut-api-key")


async def _forward_request(endpoint: str, request: Request, body: dict[str, Any]) -> Response:
    cfg = _load_gateway_config()
    api_key = request.headers.get("x-shapleycut-api-key")
    session_id = _session_id(request.headers.get("x-shapleycut-session-id"))
    override = request.headers.get("x-shapleycut-policy")
    _validate_key(cfg, api_key)

    policy = _policy_for_key(cfg, api_key)
    if _allow_policy_override():
        policy = _apply_policy_override(policy, override)

    telemetry: dict[str, Any] = {
        "session_id": session_id,
        "endpoint": endpoint,
        "policy": policy.model_dump(),
        "ts": time.time(),
    }
    if override:
        telemetry["policy_override"] = override
    started = time.perf_counter()

    try:
        if endpoint == "/v1/responses" and cfg.upstream.provider == "github_azure":
            raise HTTPException(
                status_code=400,
                detail="Upstream provider does not support /v1/responses; use /v1/chat/completions or set SHAPLEYCUT_GATEWAY_PROVIDER=openai.",
            )

        if endpoint == "/v1/chat/completions":
            messages = body.get("messages")
            if isinstance(messages, list) and messages:
                new_messages, compression = _compress_messages(messages, policy)
                body = {**body, "messages": new_messages}
                telemetry.update({"compression": compression})
        elif endpoint == "/v1/responses":
            input_data = body.get("input")
            if isinstance(input_data, str) and input_data.strip():
                cfg = OptimizeConfig(
                    summarize_omitted=policy.summarize_omitted,
                    use_llm_final_squeeze=policy.use_llm_final_squeeze,
                )
                if policy.selection_target_ratio is not None:
                    cfg.selection_target_ratio = policy.selection_target_ratio
                out = optimize(
                    OptimizeInput(
                        memory=input_data,
                        max_output_tokens=policy.max_output_tokens,
                        config=cfg,
                    )
                )
                body = {**body, "input": out.optimized_memory}
                telemetry.update(
                    {
                        "compression": {
                            "segments_in": out.segments_in,
                            "segments_kept": out.segments_kept,
                            "segments_dropped": out.segments_dropped,
                            "stages": out.compression_stages,
                            "notes": out.notes,
                            "input_tokens": out.estimated_input_tokens,
                            "output_tokens": out.estimated_output_tokens,
                        }
                    }
                )

    except HTTPException:
        raise
    except Exception as exc:
        _debug_log(f"forward_error endpoint={endpoint} err={exc!s}")
        raise

    upstream_key = os.getenv(cfg.upstream.api_key_env, "").strip()
    if not upstream_key:
        raise HTTPException(status_code=500, detail=f"Missing upstream API key env {cfg.upstream.api_key_env}")

    if cfg.upstream.provider == "anthropic":
        if endpoint != "/v1/chat/completions":
            raise HTTPException(status_code=400, detail="Anthropic upstream supports only /v1/chat/completions")
        url = f"{cfg.upstream.base_url.rstrip('/')}/v1/messages"
        headers = {
            "x-api-key": upstream_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = _adapt_to_anthropic(body)
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code >= 200 and resp.status_code < 300:
            data = _anthropic_to_openai(resp.json())
            content = json.dumps(data, ensure_ascii=True).encode("utf-8")
            resp_content = content
            resp_headers = {"content-type": "application/json"}
        else:
            resp_content = resp.content
            resp_headers = {"content-type": resp.headers.get("content-type", "application/json")}
    else:
        url = f"{cfg.upstream.base_url.rstrip('/')}{endpoint}"
        headers = {
            "Authorization": f"Bearer {upstream_key}",
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=body, headers=headers)
        resp_content = resp.content
        resp_headers = {"content-type": resp.headers.get("content-type", "application/json")}

    telemetry["latency_ms"] = int((time.perf_counter() - started) * 1000)
    telemetry["status"] = resp.status_code
    telemetry["upstream"] = cfg.upstream.provider
    telemetry["request_tokens_estimate"] = count_tokens(json.dumps(body, ensure_ascii=True))
    _log_telemetry(telemetry)

    return Response(
        content=resp_content,
        status_code=resp.status_code,
        media_type=resp_headers.get("content-type", "application/json"),
        headers={"x-shapleycut-session-id": session_id},
    )


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/v1/metrics")
async def metrics() -> dict[str, Any]:
    with _METRICS_LOCK:
        items = list(_METRICS)
    summary = _aggregate_metrics(items)
    return {"summary": summary, "items": items}


@router.get("/v1/metrics/summary")
async def metrics_summary(source: str = Query(default="memory")) -> dict[str, Any]:
    source_key = source.strip().lower()
    if source_key == "db":
        db_path = os.getenv("SHAPLEYCUT_GATEWAY_DB", "").strip()
        if not db_path:
            raise HTTPException(
                status_code=400,
                detail="SHAPLEYCUT_GATEWAY_DB is not configured",
            )
        items = _load_db_metrics(db_path)
    else:
        with _METRICS_LOCK:
            items = list(_METRICS)

    return {
        "source": source_key,
        "summary": _metrics_summary(items),
    }


@router.get("/v1/metrics/export")
async def metrics_export(format: str = Query(default="jsonl")) -> Response:
    with _METRICS_LOCK:
        items = list(_METRICS)

    fmt = format.lower()
    if fmt == "csv":
        lines = ["ts,endpoint,status,latency_ms,upstream,session_id"]
        for item in items:
            line = ",".join(
                [
                    str(item.get("ts", "")),
                    str(item.get("endpoint", "")),
                    str(item.get("status", "")),
                    str(item.get("latency_ms", "")),
                    str(item.get("upstream", "")),
                    str(item.get("session_id", "")),
                ]
            )
            lines.append(line)
        content = "\n".join(lines).encode("utf-8")
        return Response(content=content, media_type="text/csv")

    content = "\n".join(json.dumps(item, ensure_ascii=True) for item in items).encode("utf-8")
    return Response(content=content, media_type="application/x-ndjson")


@router.post("/v1/chat/completions")
async def chat_completions(request: Request) -> Response:
    try:
        body = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON body: {exc!s}")
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Expected JSON object")
    try:
        return await _forward_request("/v1/chat/completions", request, body)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Gateway error: {exc!s}")


@router.post("/v1/responses")
async def responses(request: Request) -> Response:
    try:
        body = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON body: {exc!s}")
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Expected JSON object")
    try:
        return await _forward_request("/v1/responses", request, body)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Gateway error: {exc!s}")
