import os
import sys
scriptDir = os.path.dirname(__file__)+os.sep
rootDir=scriptDir+".."+os.sep
sys.path.append(rootDir)
from src.bscommon import Com
from src.bscommon import Ssh
from src.bscommon import SysTask
sys.path.remove(rootDir)


def RunAction(ssh,config,args):
    print("ssh连接成功")
    print(ssh.getNames("/bs/nginx","lo"))
    print(ssh.getText("/bs/nginx/conf/conf.d/default.conf"))

Ssh.RunAction(RunAction,scriptDir,"host")

