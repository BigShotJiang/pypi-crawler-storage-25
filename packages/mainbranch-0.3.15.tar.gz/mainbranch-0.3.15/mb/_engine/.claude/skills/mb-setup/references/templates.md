# File Templates

Copy and customize these templates when creating reference files.

---

## core/offer.md

```markdown
---
type: context
status: active
---

# The Offer

## What We Sell

[One paragraph: What is this product/service?]

**Core proposition:** "[The main promise in customer language]"

---

## Products/Services

### [Product/Service 1]
- **Price:** $X
- **What's included:** [List]
- **Delivery:** [How they get it]

### [Product/Service 2]
...

---

## The Mechanism

How it works — the unique approach that delivers the transformation:

1. [Step 1]
2. [Step 2]
3. [Step 3]

---

## Transformation

**Before:** [Current state - pains, frustrations]
**After:** [Desired state - outcomes, feelings]

---

## Pricing Philosophy

[Why this price? What does it signal?]

---

## Objections & Responses

| Objection | Response |
|-----------|----------|
| "[Common objection 1]" | [How to address it] |
| "[Common objection 2]" | [How to address it] |
```

---

## core/audience.md

```markdown
---
type: context
status: active
---

# The Audience

## Core Insight

[One sentence: Who are they really?]

---

## Demographics

- **Age:**
- **Gender:**
- **Income:**
- **Location:**
- **Education/Role:**

---

## Psychographics

### Who They Are
- [Characteristic 1]
- [Characteristic 2]
- [Characteristic 3]

### Their Internal State
- [What they're feeling]
- [What they're dealing with]
- [What they're seeking]

### What They Believe
- [Belief 1]
- [Belief 2]
- [Belief 3]

---

## Buying Triggers

### When They Buy
- [Trigger 1]
- [Trigger 2]
- [Trigger 3]

### What Converts Them
- [Conversion factor 1]
- [Conversion factor 2]

---

## Pain Points

| Pain | How We Address It |
|------|-------------------|
| "[Pain 1]" | [Our solution] |
| "[Pain 2]" | [Our solution] |

---

## Their Language

Words and phrases they use to describe their problem:
- "[Phrase 1]"
- "[Phrase 2]"
- "[Phrase 3]"

---

## Where They Hang Out

**Online:** [Platforms, communities, content they consume]
**Offline:** [Places, events, contexts]
```

---

## core/voice.md

```markdown
---
type: context
status: active
---

# Brand Voice

## The Essence

[2-3 sentences describing the voice]

---

## Tone

**Default:** [Primary tone - calm, energetic, professional, casual, etc.]
**Range:** [When it shifts and how]

---

## Cadence

[Short sentences? Long flowing prose? Punchy? Musical?]

---

## Vocabulary

**Use:**
- [Word/phrase to use]
- [Word/phrase to use]

**Avoid:**
- [Word/phrase to avoid]
- [Word/phrase to avoid]

---

## Core Phrases

Signature phrases that define the brand:
- "[Phrase 1]"
- "[Phrase 2]"
- "[Phrase 3]"

---

## Quality Test

Before shipping copy, ask:
1. Can I see it in my head? (Concrete > Abstract)
2. Could someone call BS on it? (Specific > Vague)
3. Could a competitor copy-paste this? (Distinctive > Generic)

---

## Channel Variations

| Channel | Voice Adjustment |
|---------|------------------|
| Email | [How it shifts] |
| Social | [How it shifts] |
| Ads | [How it shifts] |
| Support | [How it shifts] |
```

---

## core/proof/testimonials.md

```markdown
---
type: context
status: active
---

# Testimonials

## Best Quotes

### [Customer Name/Type]
> "[Exact quote - preserve their words]"

**Result:** [Specific outcome if stated]
**Source:** [Where this came from]
**Date:** [When received]

---

### [Customer Name/Type]
> "[Quote]"

**Result:**
**Source:**
**Date:**

---

## Themes

Common words/phrases customers use:
- "[Theme 1]" — appears in X reviews
- "[Theme 2]" — appears in X reviews
- "[Theme 3]" — appears in X reviews
```

---

## core/proof/angles/[angle-name].md

```markdown
---
type: angle
status: active
---

# [Angle Name]

## Hook

[The entry point / attention grabber]

## Core Idea

[What this angle emphasizes — the central insight]

## Proof

[Evidence that validates this angle]
- [Review quote or data point]
- [Review quote or data point]

## Best For

[When to use this angle — audience state, channel, timing]

## Example Copy

[Sample headline or hook using this angle]
```

---

## core/content-strategy.md

```markdown
---
type: reference
status: draft
---

# Content Strategy

## Content Pillars
<!-- 3-5 pillars derived from soul.md + offer.md + audience.md -->
<!-- Each pillar must pass the triple test:
     1. Soul test — Does this connect to why you exist?
     2. Offer test — Does this lead toward your mechanism?
     3. Audience test — Does your audience care about this?
-->

### Pillar 1: [Name]
- **Theme:** [What this pillar covers]
- **Sub-topics:** [Specific angles within this pillar]
- **Connection:** [How it maps to offer/audience/soul]

### Pillar 2: [Name]
- **Theme:**
- **Sub-topics:**
- **Connection:**

### Pillar 3: [Name]
- **Theme:**
- **Sub-topics:**
- **Connection:**

<!-- Add more pillars as needed — 3-5 is the sweet spot -->

---

## Platform Strategy
<!-- Priority-ordered platforms with format, cadence, purpose, funnel role -->
<!-- Start with 1-2 platforms. Add more only after consistency. -->

| Platform | Format | Cadence | Purpose | Funnel Role |
|----------|--------|---------|---------|-------------|
| [e.g., Newsletter] | [Long-form] | [Weekly] | [Keystone content] | [Nurture] |
| [e.g., Instagram] | [Reels, carousels] | [3x/week] | [Discovery] | [Awareness] |
| [e.g., YouTube] | [Short-form] | [2x/week] | [Authority] | [Consideration] |

---

## Content Mix
<!-- Ratios across content types -->
<!-- Starting suggestion: 50 / 25 / 15 / 10 — adjust based on performance -->

| Type | Target % | Description |
|------|----------|-------------|
| Educational | 50% | Teaches concepts, frameworks, how-tos |
| Entertaining | 25% | Stories, personality, relatable moments |
| Community | 15% | Engagement, questions, member spotlights |
| Promotional | 10% | Direct offers, CTAs, launches |

---

## Weekly Cadence
<!-- Day-by-day plan: what content type, which platform -->
<!-- This is a starting template — iterate based on what works -->

| Day | Content Type | Platform | Pillar | Notes |
|-----|-------------|----------|--------|-------|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

---

## Repurposing Flow
<!-- Keystone piece -> derivative flow -->
<!-- The goal: create once, distribute everywhere -->

```
[Keystone piece, e.g., Newsletter]
    |
    ├── [Derivative 1, e.g., 3 social posts]
    ├── [Derivative 2, e.g., 1 short-form video]
    ├── [Derivative 3, e.g., Community discussion thread]
    └── [Derivative 4, e.g., Email teaser]
```

---

## Content Genotype Defaults
<!-- Your preferred content DNA — the defaults AI uses when generating -->
<!-- Variables to test next are tracked here so /mb-think can run experiments -->

| Variable | Current Default | Notes |
|----------|----------------|-------|
| Hook style | [e.g., question, bold claim, story] | |
| Content format | [e.g., talking head, text overlay] | |
| Duration | [e.g., 30-60 sec for reels] | |
| CTA style | [e.g., soft, direct, community-invite] | |
| Tone | [Reference voice.md] | |

**Variables to test next:**
<!-- Track what you want to experiment with -->
- [ ] [e.g., Try controversial hooks vs educational hooks]
- [ ] [e.g., Test 15-sec vs 60-sec format]

---

## Metrics
<!-- PRP (per-piece performance) benchmarks per platform -->
<!-- Updated through /mb-think cycles analyzing performance data -->

### Platform Benchmarks

| Platform | Metric | Current Benchmark | Target | Last Updated |
|----------|--------|-------------------|--------|--------------|
| | Views | | | |
| | Engagement rate | | | |
| | Click-through | | | |

### Review Cadence

- **Weekly:** Check per-piece performance, update hooks library
- **Monthly:** Review pillar performance, adjust content mix
- **Quarterly:** Full strategy review — pillars still relevant? Platforms still right?

---

## Framework Library
<!-- Proven content frameworks extracted via /mb-think mining -->
<!-- Each framework includes structure + when to use + example -->

<!-- Example:
### [Framework Name]
- **Structure:** [Step-by-step pattern]
- **When to use:** [What pillar/content type this fits]
- **Example:** [Brief reference to a piece that used this]
- **Source:** [Mined from competitor X / discovered through testing]
-->

---

## Hooks Library
<!-- Populated over time from what works -->
<!-- Organized by hook type for quick reference during content creation -->

### Question Hooks
<!-- e.g., "What if everything you knew about X was wrong?" -->

### Bold Claim Hooks
<!-- e.g., "Most people fail at X because they skip this one step" -->

### Story Hooks
<!-- e.g., "Last Tuesday a member told me something that changed how I think about X" -->

### Contrarian Hooks
<!-- e.g., "Stop doing X. Here's what to do instead." -->

### Data Hooks
<!-- e.g., "97% of people who try X never see results. Here's why." -->
```

---

## decisions/YYYY-MM-DD-topic.md

```markdown
---
type: decision
date: YYYY-MM-DD
status: proposed
---

# Decision: [Topic]

## Context

[What's happening, what prompted this decision]

## Research Summary

[Summary of research that informed this]
See: `research/YYYY-MM-DD-topic.md`

## Options

### Option A: [Name] (selected)
**Pros:**
**Cons:**

### Option B: [Name] (rejected)
**Pros:**
**Cons:**

## Decision

[The actual choice with rationale]

## Consequences

[What becomes easier, harder, and what you're accepting]

## What Changes

[Which reference files are affected and what the key changes are]
```

---

## research/YYYY-MM-DD-topic-[source].md

```markdown
---
type: research
date: YYYY-MM-DD
source: [gemini | claude-code | web | expert | mining]
topics: [topic1, topic2]
status: complete
---

# [Research Topic]

## Question

[What we were trying to learn]

## Key Findings

1. [Finding 1]
2. [Finding 2]
3. [Finding 3]

## Implications

[What this means for the business]

## Next Steps

- [ ] [Action this research suggests]

---

## Raw Notes

[Detailed findings, quotes, data]
```

---

## README.md

```markdown
# [Business Name]

[One sentence: What this business does]

---

## About

[2-3 sentences about the business]

**URL:** [Website]

---

## This Repo

This is the **data repo** (knowledge base) for [Business Name].

It uses [Main Branch](https://github.com/noontide-co/mainbranch) as the **engine** — skills, lenses, and frameworks that generate content from your data.

### Setup

1. **Clone the engine** (if you haven't):
   ```bash
   git clone https://github.com/noontide-co/mainbranch.git
   ```

2. **Start Claude in this folder** (your business repo) and run `/mb-start`

3. **Main Branch is linked** via `.claude/settings.local.json` (bridge links handle skill discovery fallback)

### How It Works

```
ENGINE (mainbranch)     +     DATA (this repo)     =     OUTPUT
├── Skills                             ├── core/                 ├── Ads
├── Lenses                             ├── research/             ├── Emails
└── Pull updates, don't edit           └── You own this          └── Content
```

Skills from the engine read your `core/`, `research/`, and `decisions/` files
and generate coordinated work under `pushes/`.

---

## Quick Stats

- **[Metric 1]:** [Value]
- **[Metric 2]:** [Value]
- **[Metric 3]:** [Value]
```
