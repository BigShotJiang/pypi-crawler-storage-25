"""CellLocation type for specifying DataFrame locations within worksheets."""

from dataclasses import dataclass
from functools import cached_property

from eftoolkit.gsheets.utils import column_index_to_letter, column_letter_to_index


@dataclass(frozen=True)
class CellLocation:
    """Where a DataFrame should be written within a worksheet.

    The worksheet name comes from the WorksheetDefinition.name property,
    so CellLocation only needs the cell address within that worksheet.
    Computed properties (`row`, `col`, `row_1indexed`, `col_letter`,
    `value`) are offset-aware and documented on their individual
    `@property` methods below.

    Attributes:
        cell: The base cell address (e.g., 'B4', 'A1').
        offset_rows: Number of rows to offset from the base cell. Positive moves down,
            negative moves up. Defaults to 0.
        offset_cols: Number of columns to offset from the base cell. Positive moves right,
            negative moves left. Defaults to 0.

    Example:
        ```python
        location = CellLocation(cell='B4')
        location.cell         # 'B4'
        location.row          # 3
        location.col          # 1
        location.row_1indexed # 4
        location.col_letter   # 'B'

        # With offsets
        CellLocation(cell='I2', offset_cols=1).value   # 'J2'
        CellLocation(cell='I2', offset_cols=-1).value  # 'H2'
        CellLocation(cell='I2', offset_rows=1).value   # 'I3'
        CellLocation(cell='I2', offset_rows=-1).value  # 'I1'
        ```
    """

    cell: str
    offset_rows: int = 0
    offset_cols: int = 0

    @staticmethod
    def _parse_cell(cell: str) -> tuple[str, int]:
        """Parse a cell reference like 'B4' into column ('B') and row (4).

        Args:
            cell: Cell reference string (e.g., 'B4', 'AA10').

        Returns:
            Tuple of (column_letter, row_1indexed).
        """
        col = ''.join(c for c in cell if c.isalpha())
        row = int(''.join(c for c in cell if c.isdigit()))
        return col, row

    @cached_property
    def _parsed(self) -> tuple[str, int]:
        """Cached parsed cell reference (base cell without offsets)."""
        return self._parse_cell(self.cell)

    @cached_property
    def _base_col_index(self) -> int:
        """0-indexed column number of the base cell (without offset)."""
        return column_letter_to_index(self._parsed[0])

    @cached_property
    def _base_row_1indexed(self) -> int:
        """1-indexed row number of the base cell (without offset)."""
        return self._parsed[1]

    @property
    def col_letter(self) -> str:
        """Column letter(s) after applying offset.

        Example: 'B4' → 'B', CellLocation('I2', offset_cols=1) → 'J'.
        """
        return column_index_to_letter(self.col)

    @property
    def row_1indexed(self) -> int:
        """1-indexed row number for Google Sheets API after applying offset.

        Example: 'B4' → 4, CellLocation('I2', offset_rows=1) → 3.
        """
        return self._base_row_1indexed + self.offset_rows

    @property
    def row(self) -> int:
        """0-indexed row number after applying offset.

        Example: 'B4' → 3, CellLocation('I2', offset_rows=1) → 2.
        """
        return self.row_1indexed - 1

    @property
    def col(self) -> int:
        """0-indexed column number after applying offset.

        Example: 'B4' → 1, CellLocation('I2', offset_cols=1) → 9.
        """
        return self._base_col_index + self.offset_cols

    @property
    def value(self) -> str:
        """String representation of the cell after applying offsets.

        Useful for API calls.

        Example: 'B4' → 'B4', CellLocation('I2', offset_cols=1) → 'J2'.
        """
        return f'{self.col_letter}{self.row_1indexed}'

    def __str__(self) -> str:
        """Return string representation of the cell after applying offsets."""
        return self.value
