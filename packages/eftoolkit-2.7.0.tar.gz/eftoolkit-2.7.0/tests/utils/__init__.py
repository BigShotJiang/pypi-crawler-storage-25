"""Tests for eftoolkit.utils."""
