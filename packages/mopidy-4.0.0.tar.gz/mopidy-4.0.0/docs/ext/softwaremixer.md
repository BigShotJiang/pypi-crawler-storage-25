# mopidy-softwaremixer

mopidy-softwaremixer is an extension for controlling audio volume in software
through GStreamer. It is the only mixer bundled with Mopidy and is enabled by
default.

If you use PulseAudio, the software mixer will control the per-application
volume for Mopidy in PulseAudio, and any changes to the per-application volume
done from outside Mopidy will be reflected by the software mixer.

If you don't use PulseAudio, the mixer will adjust the volume internally in
Mopidy's GStreamer pipeline.

## Configuration

Multiple mixers can be installed and enabled at the same time, but only the
mixer pointed to by the [`audio/mixer`](../usage/config.md#audiomixer) config value will actually be used.

See [Configuration](../usage/config.md) for general help on configuring Mopidy.

```ini title="mopidy.conf"
[softwaremixer]
enabled = true
```

### softwaremixer/enabled

If the software mixer should be enabled or not. Usually you don't want to
change this, but instead change the [`audio/mixer`](../usage/config.md#audiomixer) config value to
decide which mixer is actually used.
