import logging
from copy import copy
from datetime import UTC, datetime, timezone
from itertools import chain

from blinker import Signal
from flask import request, url_for
from flask_security import MongoEngineUserDatastore, RoleMixin, UserMixin
from flask_storage.mongo import ImageField
from mongoengine import EmbeddedDocument
from mongoengine.fields import (
    BooleanField,
    DateTimeField,
    GenericEmbeddedDocumentField,
    IntField,
    ListField,
    MapField,
    ReferenceField,
    StringField,
)
from mongoengine.signals import post_save, pre_save
from werkzeug.utils import cached_property

from udata.api_fields import field, generate_fields
from udata.auth.helpers import current_user_is_admin_or_self
from udata.core import storages
from udata.core.discussions.models import Discussion
from udata.core.followers.models import Follow
from udata.core.linkable import Linkable
from udata.core.metrics.models import WithMetrics
from udata.core.spam.models import SpamMixin
from udata.core.storages import avatars, default_image_basename
from udata.frontend.markdown import mdstrip
from udata.i18n import lazy_gettext as _
from udata.mongo import db
from udata.mongo.document import UDataDocument as Document
from udata.mongo.extras_fields import ExtrasField
from udata.mongo.slug_fields import SlugField
from udata.mongo.url_field import URLField
from udata.uris import cdata_url

from . import mails
from .constants import AVATAR_SIZES, BIGGEST_AVATAR_SIZE

__all__ = ("User", "Role", "datastore")

log = logging.getLogger(__name__)


def _is_org_private_context():
    """Check if the current request is an org endpoint where the user has private access."""
    if request.endpoint == "api.request_membership":
        return True
    if request.endpoint != "api.organization":
        return False
    org = request.view_args.get("org")
    return org is not None and org.permissions["private"].can()


def _visible_email(user):
    """Return user email with appropriate visibility level.

    - sysadmin or /me endpoint → full email
    - org member context with private access → partially obfuscated
    - otherwise → domain only
    """
    if current_user_is_admin_or_self():
        return user.email
    if not user.email:
        return None
    name, domain = user.email.split("@")
    if _is_org_private_context():
        name = name[:2] + "*" * (len(name) - 2)
        return f"{name}@{domain}"
    return f"***@{domain}"


def _visible_login_date(user):
    if current_user_is_admin_or_self() or _is_org_private_context():
        return user.current_login_at
    return None


# TODO: use simple text for role
class Role(Document, RoleMixin):
    ADMIN = "admin"
    name = StringField(max_length=80, unique=True)
    description = StringField(max_length=255)
    permissions = ListField()

    def __str__(self):
        return self.name


class UserSettings(EmbeddedDocument):
    prefered_language = StringField()


@generate_fields()
class User(SpamMixin, WithMetrics, UserMixin, Linkable, Document):
    slug = field(
        SlugField(max_length=255, required=True, populate_from="fullname"),
        auditable=False,
        show_as_ref=True,
    )
    email = field(
        StringField(max_length=255, required=True, unique=True),
        show_as_ref=True,
        attribute=_visible_email,
    )
    password = field(StringField())
    active = field(BooleanField())
    fs_uniquifier = field(StringField(max_length=64, unique=True, sparse=True))
    roles = field(ListField(ReferenceField(Role), default=[]))

    first_name = field(StringField(max_length=255, required=True), show_as_ref=True)
    last_name = field(StringField(max_length=255, required=True), show_as_ref=True)

    avatar_url = field(URLField())
    avatar = field(
        ImageField(fs=avatars, basename=default_image_basename, thumbnails=AVATAR_SIZES),
        show_as_ref=True,
        thumbnail_info={
            "size": BIGGEST_AVATAR_SIZE,
        },
    )
    website = field(URLField())
    about = field(
        StringField(),
        markdown=True,
    )

    prefered_language = field(StringField())

    created_at = field(
        DateTimeField(default=lambda: datetime.now(UTC), required=True), auditable=False
    )

    # The field below is required for Flask-security
    # when SECURITY_CONFIRMABLE is True
    confirmed_at = field(DateTimeField(), auditable=False)

    password_rotation_demanded = field(DateTimeField(), auditable=False)
    password_rotation_performed = field(DateTimeField(), auditable=False)

    # The 5 fields below are required for Flask-security when SECURITY_TRACKABLE is True.
    # Flask-Security's naming is counter-intuitive: `current_login_at` is the most recent
    # login and `last_login_at` is the *previous* one. We rename this in the public API:
    # the field exposed as `last_login_at` actually returns the value of `current_login_at`
    # (the most recent login), which is what "last login" naturally means to API consumers.
    last_login_at = field(
        DateTimeField(),
        auditable=False,
        show_as_ref=True,
        attribute=_visible_login_date,
    )
    current_login_at = field(DateTimeField(), auditable=False)
    last_login_ip = field(StringField(), auditable=False)
    current_login_ip = field(StringField(), auditable=False)
    login_count = field(IntField(), auditable=False)

    # Two-Factor authentification fields
    tf_primary_method = field(StringField(), auditable=False)
    tf_totp_secret = field(StringField(), auditable=False)

    deleted = field(DateTimeField())
    ext = field(MapField(GenericEmbeddedDocumentField()))
    extras = field(ExtrasField(), auditable=False)

    # Used to track notification for automatic inactive users deletion
    # when YEARS_OF_INACTIVITY_BEFORE_DELETION is set
    inactive_deletion_notified_at = field(DateTimeField(), auditable=False)

    before_save = Signal()
    after_save = Signal()
    on_create = Signal()
    on_update = Signal()
    before_delete = Signal()
    after_delete = Signal()
    on_delete = Signal()

    meta = {
        "indexes": [
            {
                "fields": ["$last_name", "$first_name", "$email"],
                "default_language": "french",
                "weights": {"last_name": 10, "email": 10, "first_name": 5},
            },
            "-created_at",
            "slug",
        ],
        "ordering": ["-created_at"],
        "auto_create_index_on_save": True,
    }

    verbose_name = _("account")

    def fields_to_check_for_spam(self):
        return {"about": self.about, "website": self.website}

    __metrics_keys__ = [
        "datasets",
        "reuses",
        "dataservices",
        "following",
        "followers",
    ]

    def __str__(self):
        return self.fullname

    @property
    def fullname(self):
        return " ".join((self.first_name or "", self.last_name or "")).strip()

    @cached_property
    def organizations(self):
        from udata.core.organization.models import Organization

        return Organization.objects(members__user=self, deleted__exists=False)

    @property
    def sysadmin(self):
        return self.has_role("admin")

    def self_web_url(self, **kwargs):
        return cdata_url(f"/users/{self._link_id(**kwargs)}", **kwargs)

    def self_api_url(self, **kwargs):
        return url_for(
            "api.user", user=self._link_id(**kwargs), **self._self_api_url_kwargs(**kwargs)
        )

    @property
    def visible(self):
        count = self.metrics.get("datasets", 0) + self.metrics.get("reuses", 0)
        return count > 0 and self.active

    @cached_property
    def resources_availability(self):
        """Return the percentage of availability for resources."""
        # Flatten the list.
        availabilities = list(chain(*[org.check_availability() for org in self.organizations]))
        # Filter out the unknown
        availabilities = [a for a in availabilities if type(a) is bool]
        if availabilities:
            # Trick will work because it's a sum() of booleans.
            return round(100.0 * sum(availabilities) / len(availabilities), 2)
        # if nothing is unavailable, everything is considered OK
        return 100

    @cached_property
    def datasets_org_count(self):
        """Return the number of datasets of user's organizations."""
        from udata.models import Dataset  # Circular imports.

        return sum(
            Dataset.objects(organization=org).visible().count() for org in self.organizations
        )

    @cached_property
    def followers_org_count(self):
        """Return the number of followers of user's organizations."""
        from udata.models import Follow  # Circular imports.

        return sum(Follow.objects(following=org).count() for org in self.organizations)

    @property
    def datasets_count(self):
        """Return the number of datasets of the user."""
        return self.metrics.get("datasets", 0)

    @property
    def followers_count(self):
        """Return the number of followers of the user."""
        return self.metrics.get("followers", 0)

    @field(description="Link to the API endpoint for this user", show_as_ref=True)
    def uri(self, *args, **kwargs):
        return self.self_api_url(*args, **kwargs)

    @field(description="Link to the udata web page for this user", show_as_ref=True)
    def page(self, *args, **kwargs):
        return self.self_web_url(*args, **kwargs)

    @classmethod
    def get(cls, id_or_slug):
        obj = cls.objects(slug=id_or_slug).first()
        return obj or cls.objects.get_or_404(id=id_or_slug)

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        cls.before_save.send(document)

    @classmethod
    def post_save(cls, sender, document, **kwargs):
        if "post_save" in kwargs.get("ignores", []):
            return
        cls.after_save.send(document)
        if kwargs.get("created"):
            cls.on_create.send(document)
        else:
            cls.on_update.send(document)

    @cached_property
    def json_ld(self):
        result = {
            "@type": "Person",
            "@context": "http://schema.org",
            "name": self.fullname,
        }

        if self.about:
            result["description"] = mdstrip(self.about)

        if self.avatar_url:
            result["image"] = self.avatar_url

        if self.website:
            result["url"] = self.website

        return result

    def _delete(self, *args, **kwargs):
        return Document.delete(self, *args, **kwargs)

    def delete(self, *args, **kwargs):
        raise NotImplementedError("""This method should not be using directly.
        Use `mark_as_deleted` (or `_delete` if you know what you're doing)""")

    def mark_as_deleted(self, notify: bool = True, delete_comments: bool = False):
        if self.avatar.filename is not None:
            try:
                storage = storages.avatars
                storage.delete(self.avatar.filename)
                storage.delete(self.avatar.original)
                for key, value in self.avatar.thumbnails.items():
                    storage.delete(value)
            except FileNotFoundError as e:
                log.error(f"File not found while deleting user #{self.id} avatar: {e}")

        copied_user = copy(self)
        self.email = "{}@deleted".format(self.id)
        self.slug = "deleted-{}".format(self.id)
        self.password = None
        self.active = False
        self.first_name = "DELETED"
        self.last_name = "DELETED"
        self.avatar = None
        self.avatar_url = None
        self.website = None
        self.about = None
        self.extras = None
        self.deleted = datetime.now(UTC)
        self.save()
        from udata.core.api_token.models import ApiToken

        ApiToken.objects(user=self, revoked_at=None).update(
            set__revoked_at=datetime.now(timezone.utc)
        )
        for organization in self.organizations:
            organization.members = [
                member for member in organization.members if member.user != self
            ]
            organization.save()
        if delete_comments:
            for discussion in Discussion.objects(discussion__posted_by=self):
                # Remove all discussions with current user as only participant
                if all(message.posted_by == self for message in discussion.discussion):
                    discussion.delete()
                    continue

                for message in discussion.discussion:
                    if message.posted_by == self:
                        message.content = "DELETED"
                discussion.save()
        Follow.objects(follower=self).delete()
        Follow.objects(following=self).delete()
        # Remove related notifications
        from udata.features.notifications.models import Notification

        Notification.objects.with_user_in_details(self).delete()

        from udata.models import ContactPoint

        ContactPoint.objects(owner=self).delete()

        if notify:
            mails.account_deletion().send(copied_user)

    def request_password_rotation(self):
        """Mark the user for password rotation on next login and invalidate
        all ongoing sessions by changing its uniquifier."""
        self.password_rotation_demanded = datetime.now(UTC)
        self.save()
        datastore.set_uniquifier(self)

    def count_datasets(self):
        from udata.models import Dataset

        self.metrics["datasets"] = Dataset.objects(owner=self).visible().count()
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_reuses(self):
        from udata.models import Reuse

        self.metrics["reuses"] = Reuse.objects(owner=self).visible().count()
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_dataservices(self):
        from udata.core.dataservices.models import Dataservice

        self.metrics["dataservices"] = Dataservice.objects(owner=self).visible().count()
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_followers(self):
        from udata.models import Follow

        self.metrics["followers"] = Follow.objects(until=None).followers(self).count()
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_following(self):
        from udata.models import Follow

        self.metrics["following"] = Follow.objects.following(self).count()
        self.save(signal_kwargs={"ignores": ["post_save"]})


datastore = MongoEngineUserDatastore(db, User, Role)

pre_save.connect(User.pre_save, sender=User)
post_save.connect(User.post_save, sender=User)
post_save.connect(SpamMixin.post_save, sender=User)


def match_email_invitations(sender, **kwargs):
    """Match pending email invitations when user registers."""
    from udata.core.organization.models import Organization
    from udata.core.organization.notifications import _create_membership_notification

    user = sender
    for org in Organization.objects(
        requests__kind="invitation", requests__email=user.email.lower(), requests__status="pending"
    ):
        modified = False
        matched_requests = []
        for req in org.requests:
            if (
                req.kind == "invitation"
                and req.email
                and req.email.lower() == user.email.lower()
                and req.status == "pending"
            ):
                req.user = user
                req.email = None
                modified = True
                matched_requests.append(req)
        if modified:
            org.save()
            for req in matched_requests:
                _create_membership_notification(req, org, user)


User.on_create.connect(match_email_invitations)
