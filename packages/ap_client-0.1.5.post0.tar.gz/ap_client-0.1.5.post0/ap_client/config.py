"""Configuration management."""

import os
from dataclasses import dataclass

DEFAULT_BASE_URL = "http://agentplatform.aliyun-inc.com"
CLUSTER_HEADER = "X-Cluster"


class ConfigurationError(Exception):
    """Raised when required client configuration is missing or invalid."""


def _parse_bool(value: str | None) -> bool:
    """Parse a boolean environment variable."""
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_positive_int(value: str | None, default: int) -> int:
    """Parse a positive-integer environment variable."""
    if value is None or not value.strip():
        return default
    parsed = int(value)
    if parsed <= 0:
        raise ValueError("environment variable must be a positive integer")
    return parsed


def has_cluster_header(headers: dict[str, str]) -> bool:
    return any(key.lower() == "x-cluster" and value.strip() for key, value in headers.items())


def _set_cluster_header(headers: dict[str, str], cluster: str) -> None:
    for key in list(headers):
        if key.lower() == "x-cluster":
            del headers[key]
    headers[CLUSTER_HEADER] = cluster


@dataclass
class Config:
    """CLI 配置

    认证: 支持以下两种方式
        - AP_API_KEYS: 与服务端保持一致的环境变量名（推荐）
        - AP_TOKEN_KEY: 向后兼容的旧环境变量名
    """

    base_url: str
    headers: dict
    agenthub_ref: str | None
    verbose: bool = False
    verbose_body_limit: int = 4096
    verbose_full_body: bool = False
    token_key: str | None = None

    @classmethod
    def from_env(cls) -> "Config":
        """从环境变量加载配置"""
        base_url = os.environ.get("AP_BASE_URL") or DEFAULT_BASE_URL

        headers: dict[str, str] = {}
        headers_str = os.environ.get("AP_HEADERS", "")
        if headers_str:
            for h in headers_str.split(","):
                if ":" in h:
                    k, v = h.split(":", 1)
                    headers[k.strip()] = v.strip()

        # 优先使用 AP_API_KEYS（与服务端一致），向后兼容 AP_TOKEN_KEY
        token_key = os.environ.get("AP_API_KEYS") or os.environ.get("AP_TOKEN_KEY")

        cluster = os.environ.get("AP_CLUSTER", "").strip()
        if cluster:
            _set_cluster_header(headers, cluster)

        return cls(
            base_url=base_url.rstrip("/"),
            headers=headers,
            agenthub_ref=os.environ.get("AP_AGENTHUB_REF"),
            verbose=_parse_bool(os.environ.get("AP_VERBOSE")),
            verbose_body_limit=_parse_positive_int(os.environ.get("AP_VERBOSE_BODY_LIMIT"), 4096),
            verbose_full_body=_parse_bool(os.environ.get("AP_VERBOSE_FULL_BODY")),
            token_key=token_key,
        )


def get_config(verbose: bool | None = None) -> Config:
    """Return the current configuration."""
    config = Config.from_env()
    if verbose is not None:
        config.verbose = verbose
    return config
