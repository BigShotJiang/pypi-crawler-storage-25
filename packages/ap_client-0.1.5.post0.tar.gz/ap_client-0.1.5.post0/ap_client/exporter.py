"""Export job/group data from Agent Platform to local directories."""

from __future__ import annotations

import concurrent.futures
import json
import logging
import os
import shutil
import socket
import sys
import tarfile
import threading
from functools import lru_cache
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlparse, urlunparse

import requests

from .api import APIClient, APIError

logger = logging.getLogger(__name__)

DEFAULT_CACHE_DIR = "~/.cache/agentplatform"
_DOWNLOAD_TIMEOUT = (10, 300)
_DOWNLOAD_CHUNK_SIZE = 1024 * 1024 * 4
ProgressCallback = Callable[[int, int, str, str], None]
StageCallback = Callable[[str], None]


def default_cache_dir() -> Path:
    """Return the export cache root."""
    raw = os.environ.get("AP_CACHE_DIR", DEFAULT_CACHE_DIR)
    return Path(raw).expanduser()


def default_job_export_dir(job_id: str) -> Path:
    """Return the default export path for one job."""
    return default_cache_dir() / "jobs" / job_id


def default_group_export_dir(group_id: str) -> Path:
    """Return the default export path for one group."""
    return default_cache_dir() / "groups" / group_id


def export_job(
    client: APIClient,
    job_id: str,
    output_dir: Optional[Path] = None,
) -> Path:
    """Export a single job to disk."""
    dest = Path(output_dir) if output_dir else default_job_export_dir(job_id)
    dest.mkdir(parents=True, exist_ok=True)
    _export_job_into_dir(client, job_id, dest)
    return dest


def export_group(
    client: APIClient,
    group_id: str,
    output_dir: Optional[Path] = None,
    progress_callback: Optional[ProgressCallback] = None,
    workers: int = 4,
) -> Path:
    """Export a group and all of its jobs to disk."""
    dest = Path(output_dir) if output_dir else default_group_export_dir(group_id)
    dest.mkdir(parents=True, exist_ok=True)

    group = client.get_group_stats(group_id)
    _write_json(dest / "group.json", group)
    try:
        group_eval = client.get_group_eval(group_id)
        _write_json(dest / "eval.json", group_eval)
        _write_json(dest / "eval_summary.json", group_eval.get("summary", {}))
        _write_json(dest / "eval_tasks.json", group_eval.get("results", []))
    except Exception:
        # Some groups are non-eval workloads, or older servers may not expose eval endpoints.
        pass

    jobs_dir = dest / "jobs"
    jobs_dir.mkdir(parents=True, exist_ok=True)

    workers = max(1, int(workers))
    jobs = _list_group_jobs(client, group_id)
    total = len(jobs)
    done = 0
    done_lock = threading.Lock()

    if progress_callback is not None:
        progress_callback(done, total, "", "listing jobs")

    def _notify(job_id: str, stage: str) -> None:
        if progress_callback is None:
            return
        with done_lock:
            current_done = done
        progress_callback(current_done, total, job_id, stage)

    def _mark_done(job_id: str) -> None:
        nonlocal done
        with done_lock:
            done += 1
            current_done = done
        if progress_callback is not None:
            progress_callback(current_done, total, job_id, "done")

    if workers == 1 or total <= 1:
        for job in jobs:
            job_id = job["job_id"]
            _notify(job_id, "starting")
            _export_job_into_dir(
                client,
                job_id,
                jobs_dir / job_id,
                job=job,
                stage_callback=lambda stage, current_job_id=job_id: _notify(current_job_id, stage),
            )
            _mark_done(job_id)
        return dest

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {
            executor.submit(
                _export_job_with_fresh_client,
                client.config,
                job,
                jobs_dir / job["job_id"],
                lambda stage, current_job_id=job["job_id"]: _notify(current_job_id, stage),
            ): job["job_id"]
            for job in jobs
        }
        for future in concurrent.futures.as_completed(future_map):
            job_id = future_map[future]
            future.result()
            _mark_done(job_id)

    return dest


def _list_group_jobs(client: APIClient, group_id: str) -> list[dict]:
    """Fetch all jobs in a group with pagination.

    终止条件（满足任一即停止）：
    1. 当前页返回空列表（没有更多数据）
    2. 当前页返回数据量 < limit（最后一页不满，说明已无更多数据）
    3. total 一致性警告：已获取数远超 total 时记录警告，但不终止循环
    """
    skip = 0
    limit = 200
    jobs: list[dict] = []
    total = None

    while True:
        page = client.list_jobs(group_id=group_id, skip=skip, limit=limit)
        page_jobs = page.get("jobs", [])

        # 第一次请求时获取 total
        if total is None:
            total = page.get("total")  # 如果服务端没有返回 total，则为 None

        # 终止条件1: 当前页为空，说明没有更多数据
        if not page_jobs:
            break

        jobs.extend(page_jobs)

        # 终止条件2: 当前页数据量 < limit，说明已到最后一页
        if len(page_jobs) < limit:
            break

        skip += limit

        # total 一致性警告（仅警告，不终止循环）
        if total is not None and total > 0 and len(jobs) > total:
            logger.warning(
                "Fetched %d jobs exceeds server-reported total=%d, continuing pagination",
                len(jobs),
                total,
            )

    return jobs


def _export_job_with_fresh_client(
    config,
    job: dict,
    dest: Path,
    stage_callback: Optional[StageCallback] = None,
) -> None:
    """Export one job with a dedicated client/session for thread safety."""
    worker_client = APIClient(config)
    _export_job_into_dir(worker_client, job["job_id"], dest, job=job, stage_callback=stage_callback)


def _export_job_into_dir(
    client: APIClient,
    job_id: str,
    dest: Path,
    job: Optional[dict] = None,
    stage_callback: Optional[StageCallback] = None,
) -> None:
    """Export one job into an existing directory."""
    dest.mkdir(parents=True, exist_ok=True)
    current_stage = "job metadata"

    def _set_stage(stage: str) -> None:
        nonlocal current_stage
        current_stage = stage
        if stage_callback is not None:
            stage_callback(stage)

    try:
        _set_stage("job metadata")
        job_data = job or client.get_job(job_id)

        _set_stage("metrics")
        metrics = client.get_job_metrics(job_id)

        _set_stage("artifact metadata")
        artifact = _get_job_artifact(client, job_id)

        # _set_stage("logs")
        # logs = client.get_job_logs(job_id)

        _set_stage("events")
        events = client.get_job_events(job_id)

        _write_json(dest / "job.json", job_data)
        _write_json(dest / "metrics.json", metrics)
        _write_json(dest / "artifacts.json", artifact)
        _write_text(dest / "events.txt", _format_events(events))

        # Write logs for all containers
        _set_stage("logs")
        logs_dir = dest / "logs"
        _write_logs(logs_dir, client, job_id, job_data)

        artifact_url = artifact.get("url")
        if artifact_url:
            archive_path = dest / "result.tgz"
            try:
                _set_stage("downloading artifact")
                _download_file(artifact_url, archive_path)
                _set_stage("extracting artifact")
                _extract_tgz(archive_path, dest / "artifacts")
            except Exception as exc:
                archive_path.unlink(missing_ok=True)
                if _is_missing_artifact_error(exc):
                    _warn_missing_artifact(job_id)
                else:
                    raise
    except Exception as exc:
        raise RuntimeError(
            f"Failed to export job {job_id} at stage '{current_stage}': {exc}"
        ) from exc


def _get_job_artifact(client: APIClient, job_id: str) -> dict:
    """Return artifact metadata for one job."""
    items = client.get_job_artifacts([job_id])
    return items[0] if items else {"job_id": job_id, "url": None}


def _write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def _write_logs(logs_dir: Path, client: APIClient, job_id: str, job_data: dict = None) -> None:
    """Write logs for all containers of a job to separate files in the logs directory."""
    logs_dir.mkdir(parents=True, exist_ok=True)

    # 获取所有容器名称
    job_data = job_data or client.get_job(job_id)
    containers_resp = client.get_job_containers(job_id)
    containers = containers_resp.get("containers", ["main"])  # 默认使用 "main" 容器

    # 为每个容器获取日志并保存到独立的文件
    logs_by_container = {}
    for container in containers:
        try:
            container_logs = client.get_job_logs_complete(job_id, container=container)
            logs_by_container[container] = container_logs
        except Exception as e:
            # 如果某个容器没有日志，记录错误并继续
            print(
                f"[ap export] warning: failed to get logs for container '{container}' in job {job_id}: {e}",
                file=sys.stderr,
            )
            logs_by_container[container] = {"logs": [], "container": container, "job_id": job_id}

    # 写入每个容器的日志
    for container, logs_data in logs_by_container.items():
        # 将每个容器的日志写入单独的文件
        container_logs_file = logs_dir / f"{_sanitize_name(container)}.log"

        # 获取日志内容
        content = logs_data.get("logs", "")
        if isinstance(content, list):
            # 如果日志是数组格式，转换为字符串
            log_text = "\n".join(str(line) for line in content) + "\n"
        else:
            log_text = str(content or "")

        _write_text(container_logs_file, log_text)


def _format_events(events: dict) -> str:
    if "containers" in events:
        containers = events.get("containers") or {}
    else:
        container = events.get("container") or "default"
        containers = {container: events.get("events", [])}

    lines = []
    for container in sorted(containers):
        values = containers.get(container) or []
        if lines:
            lines.append("")
        lines.append("[{}]".format(container))
        lines.extend(str(item) for item in values)
    return "\n".join(lines) + ("\n" if lines else "")


def _download_file(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp_path = dest.with_name(dest.name + ".part")
    public_url = url
    download_url = _prefer_internal_oss_url(url)
    response = None
    try:
        try:
            response = requests.get(download_url, timeout=_DOWNLOAD_TIMEOUT, stream=True)
            response.raise_for_status()
        except (requests.ConnectionError, requests.Timeout):
            if response is not None:
                response.close()
            if download_url == public_url:
                raise
            response = requests.get(public_url, timeout=_DOWNLOAD_TIMEOUT, stream=True)
        response.raise_for_status()
        with temp_path.open("wb") as f:
            for chunk in response.iter_content(chunk_size=_DOWNLOAD_CHUNK_SIZE):
                if chunk:
                    f.write(chunk)
        temp_path.replace(dest)
    except Exception:
        if temp_path.exists():
            temp_path.unlink()
        raise
    finally:
        if response is not None:
            response.close()


def _prefer_internal_oss_url(url: str) -> str:
    parsed = urlparse(url)
    hostname = parsed.hostname
    if not hostname:
        return url
    internal_host = _to_internal_oss_host(hostname)
    if internal_host == hostname:
        return url
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    if not can_connect(internal_host, port=port):
        return url
    netloc = internal_host
    if parsed.port is not None:
        netloc = f"{netloc}:{parsed.port}"
    return urlunparse(parsed._replace(netloc=netloc))


def _to_internal_oss_host(hostname: str) -> str:
    if ".oss-" not in hostname or hostname.endswith("-internal.aliyuncs.com"):
        return hostname
    suffix = ".aliyuncs.com"
    if not hostname.endswith(suffix):
        return hostname
    return hostname[: -len(suffix)] + "-internal.aliyuncs.com"


@lru_cache()
def can_connect(endpoint: str, port: int = 80, timeout: int = 1) -> bool:
    """Check whether the host is reachable."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        ip = socket.gethostbyname(endpoint)
        sock.connect((ip, port))
        return True
    except (socket.timeout, socket.gaierror, socket.error):
        return False
    finally:
        sock.close()


def _is_missing_artifact_error(exc: Exception) -> bool:
    if isinstance(exc, APIError):
        if exc.status_code == 404:
            return True
        return "NoSuchKey" in str(exc.detail)
    if isinstance(exc, requests.HTTPError):
        response = exc.response
        if response is not None:
            if response.status_code == 404:
                return True
            try:
                body = response.text or ""
            except Exception:
                body = ""
            if "NoSuchKey" in body:
                return True
    return "NoSuchKey" in str(exc)


def _warn_missing_artifact(job_id: str) -> None:
    print(
        f"[ap export] warning: artifact missing for job {job_id}; skipping result.tgz download",
        file=sys.stderr,
    )


def _extract_tgz(archive_path: Path, dest_dir: Path) -> None:
    # Wipe the destination first so that a previous extraction cannot leave
    # behind a symlink that a re-extraction would follow outside ``dest_dir``.
    if dest_dir.exists():
        shutil.rmtree(dest_dir, ignore_errors=True)
    dest_dir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive_path, "r:gz") as tar:
        _safe_extractall(tar, dest_dir)


def _safe_extractall(tar: tarfile.TarFile, dest_dir: Path) -> None:
    root = dest_dir.resolve()
    for member in tar.getmembers():
        member_path = (root / member.name).resolve()
        if os.path.commonpath([str(root), str(member_path)]) != str(root):
            raise ValueError(f"Unsafe artifact archive path: {member.name} {member_path}")
    tar.extractall(dest_dir)


def _sanitize_name(name: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "-" for ch in name)
