"""
Base evaluation functions for testmcpy.

These evaluators can be used to validate LLM responses and tool calling behavior.
"""

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class EvalResult:
    """Result from an evaluation function."""

    passed: bool
    score: float  # 0.0 to 1.0
    reason: str | None = None
    details: dict[str, Any] | None = None


def _match_tool_name(actual_name: str, expected_name: str) -> bool:
    """
    Match tool names with support for MCP prefixes.

    MCP tools often have prefixed names like 'mcp__testmcpy__health_check'.
    This function matches if:
    - Exact match: 'health_check' == 'health_check'
    - Suffix match: 'mcp__testmcpy__health_check' ends with '__health_check'
    - Contains match: 'mcp__testmcpy__health_check' contains 'health_check'

    Args:
        actual_name: The actual tool name from the LLM response
        expected_name: The expected tool name from the test definition

    Returns:
        True if the names match
    """
    if not actual_name or not expected_name:
        return False

    # Exact match
    if actual_name == expected_name:
        return True

    # Suffix match (handles mcp__namespace__tool_name pattern)
    if actual_name.endswith(f"__{expected_name}"):
        return True

    # Contains match (for partial tool names)
    if expected_name in actual_name:
        return True

    return False


class BaseEvaluator(ABC):
    """Base class for all evaluators."""

    @abstractmethod
    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate based on the provided context.

        Args:
            context: Dictionary containing:
                - prompt: The original prompt
                - response: The LLM response
                - tool_calls: List of tool calls made
                - tool_results: Results from tool executions
                - metadata: Additional metadata
                - mcp_client: Optional MCPClient for deterministic verification

        Returns:
            EvalResult with pass/fail and details
        """
        pass

    async def aevaluate(self, context: dict[str, Any]) -> EvalResult:
        """Async variant — override for evaluators that need MCP/network access.

        Default delegates to sync evaluate(). Evaluators that need async
        operations (e.g., MCP calls) should override this and the test runner
        will use it when running inside an async context.
        """
        return self.evaluate(context)

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the evaluator."""
        pass

    @property
    def description(self) -> str:
        """Description of what this evaluator checks."""
        return ""


class WasMCPToolCalled(BaseEvaluator):
    """Check if an MCP tool was called."""

    def __init__(self, tool_name: str | None = None):
        self.tool_name = tool_name

    @property
    def name(self) -> str:
        if self.tool_name:
            return f"was_tool_called:{self.tool_name}"
        return "was_any_tool_called"

    @property
    def description(self) -> str:
        if self.tool_name:
            return f"Checks if the '{self.tool_name}' tool was called"
        return "Checks if any MCP tool was called"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        if not tool_calls:
            return EvalResult(passed=False, score=0.0, reason="No tool calls found in response")

        if self.tool_name:
            # Check for specific tool (with support for MCP prefixed names)
            for call in tool_calls:
                actual_name = call.get("name", "")
                if _match_tool_name(actual_name, self.tool_name):
                    return EvalResult(
                        passed=True,
                        score=1.0,
                        reason=f"Tool '{self.tool_name}' was called (actual: '{actual_name}')",
                        details={"tool_call": call},
                    )

                # Check if call_tool/search_tools gateway pattern was used
                # e.g., call_tool(name="health_check", arguments={})
                if _match_tool_name(actual_name, "call_tool") or _match_tool_name(
                    actual_name, "search_tools"
                ):
                    args = call.get("arguments", {})
                    # call_tool passes tool name as 'name' or 'tool_name' arg
                    inner_name = args.get("name", args.get("tool_name", ""))
                    if isinstance(inner_name, str) and _match_tool_name(inner_name, self.tool_name):
                        return EvalResult(
                            passed=True,
                            score=1.0,
                            reason=f"Tool '{self.tool_name}' called via gateway '{actual_name}'",
                            details={"tool_call": call, "gateway": actual_name},
                        )
                    # search_tools passes query that may contain tool name
                    query = args.get("query", "")
                    if isinstance(query, str) and self.tool_name in query:
                        return EvalResult(
                            passed=True,
                            score=0.8,
                            reason=f"Tool '{self.tool_name}' searched via '{actual_name}'",
                            details={"tool_call": call, "gateway": actual_name},
                        )

            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Tool '{self.tool_name}' was not called",
                details={"tools_called": [c.get("name") for c in tool_calls]},
            )

        # Any tool call is acceptable
        return EvalResult(
            passed=True,
            score=1.0,
            reason=f"{len(tool_calls)} tool(s) called",
            details={"tool_calls": tool_calls},
        )


class ExecutionSuccessful(BaseEvaluator):
    """Check if tool execution was successful (no errors)."""

    @property
    def name(self) -> str:
        return "execution_successful"

    @property
    def description(self) -> str:
        return "Checks if tool execution completed without errors"

    # Tools blocked by the SDK harness — errors from these are expected and should be ignored
    _BLOCKED_TOOLS = {
        "Read",
        "Bash",
        "Edit",
        "Write",
        "Grep",
        "Glob",
        "ToolSearch",
        "Skill",
        "TodoWrite",
        "Agent",
        "WebFetch",
        "WebSearch",
        "NotebookEdit",
        "EnterWorktree",
        "ExitWorktree",
        # SDK-internal resource tool used when output is saved to a file —
        # the model often hallucinates a non-existent "file-system" / "file" server.
        "ReadMcpResourceTool",
    }

    # Error message substrings that indicate SDK-internal recoveries the model
    # tried (e.g. fetching a saved-to-file tool result via a non-existent
    # MCP server). These should not count as "tool execution errors".
    _SKIP_ERROR_PATTERNS = (
        "No such tool available",
        "not enabled",
        # The SDK saves oversized tool outputs to a file and tells the model
        # to read them via ReadMcpResourceTool, but no file-system MCP server
        # is registered, so the recovery attempt fails.
        'Server "file-system" not found',
        'Server "file" not found',
        "Server not found",
    )

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_results = context.get("tool_results", [])

        if not tool_results:
            return EvalResult(passed=False, score=0.0, reason="No tool execution results found")

        errors = []
        for result in tool_results:
            if result.is_error:
                error_msg = result.error_message or "Unknown error"
                # Skip errors from blocked/disallowed tools (expected failures)
                if any(pattern in error_msg for pattern in self._SKIP_ERROR_PATTERNS):
                    continue
                # Check the tool name against the blocked list
                tool_name = getattr(result, "tool_name", None) or ""
                if tool_name in self._BLOCKED_TOOLS:
                    continue
                # Fallback: check tool_call_id for embedded tool name (legacy path)
                tool_id = result.tool_call_id or ""
                if any(blocked in tool_id for blocked in self._BLOCKED_TOOLS):
                    continue
                errors.append({"tool": tool_name or tool_id, "error": error_msg})

        if errors:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"{len(errors)} tool execution error(s) occurred",
                details={"errors": errors},
            )

        return EvalResult(
            passed=True,
            score=1.0,
            reason="All tool executions completed successfully",
            details={"successful_executions": len(tool_results)},
        )


class FinalAnswerContains(BaseEvaluator):
    """Check if the final answer contains expected content."""

    def __init__(self, expected_content: str | list[str], case_sensitive: bool = False):
        self.expected_content = (
            expected_content if isinstance(expected_content, list) else [expected_content]
        )
        self.case_sensitive = case_sensitive

    @property
    def name(self) -> str:
        return "final_answer_contains"

    @property
    def description(self) -> str:
        return f"Checks if final answer contains: {', '.join(self.expected_content)}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")

        if not self.case_sensitive:
            response = response.lower()

        found = []
        not_found = []

        for content in self.expected_content:
            check_content = content if self.case_sensitive else content.lower()
            if check_content in response:
                found.append(content)
            else:
                not_found.append(content)

        score = len(found) / len(self.expected_content) if self.expected_content else 0.0

        if score == 1.0:
            return EvalResult(
                passed=True,
                score=score,
                reason="All expected content found in response",
                details={"found": found},
            )
        elif score > 0:
            return EvalResult(
                passed=False,
                score=score,
                reason=f"Partial match: {len(found)}/{len(self.expected_content)} items found",
                details={"found": found, "not_found": not_found},
            )
        else:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="No expected content found in response",
                details={"not_found": not_found},
            )


class AnswerContainsLink(BaseEvaluator):
    """Check if the answer contains expected links."""

    def __init__(self, expected_links: list[str] | None = None):
        self.expected_links = expected_links

    @property
    def name(self) -> str:
        return "answer_contains_link"

    @property
    def description(self) -> str:
        return "Checks if answer contains expected links"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")

        # Extract all URLs from response
        url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
        found_links = re.findall(url_pattern, response)

        if not self.expected_links:
            # Just check if any links exist
            if found_links:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Found {len(found_links)} link(s) in response",
                    details={"links": found_links},
                )
            else:
                return EvalResult(passed=False, score=0.0, reason="No links found in response")

        # Check for specific links
        found_expected = []
        missing = []

        for expected_link in self.expected_links:
            if any(expected_link in link for link in found_links):
                found_expected.append(expected_link)
            else:
                missing.append(expected_link)

        score = len(found_expected) / len(self.expected_links) if self.expected_links else 0.0

        if score == 1.0:
            return EvalResult(
                passed=True,
                score=score,
                reason="All expected links found",
                details={"found": found_expected},
            )
        else:
            return EvalResult(
                passed=False,
                score=score,
                reason=f"Missing {len(missing)} expected link(s)",
                details={"found": found_expected, "missing": missing, "all_links": found_links},
            )


class WithinTimeLimit(BaseEvaluator):
    """Check if execution completed within time limit."""

    def __init__(self, max_seconds: float):
        self.max_seconds = max_seconds

    @property
    def name(self) -> str:
        return f"within_time_limit:{self.max_seconds}s"

    @property
    def description(self) -> str:
        return f"Checks if execution completed within {self.max_seconds} seconds"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        duration = context.get("metadata", {}).get("duration_seconds", 0)

        if duration <= 0:
            return EvalResult(passed=False, score=0.0, reason="Duration information not available")

        if duration <= self.max_seconds:
            return EvalResult(
                passed=True,
                score=1.0
                - (duration / self.max_seconds) * 0.5,  # Higher score for faster execution
                reason=f"Completed in {duration:.2f}s (limit: {self.max_seconds}s)",
                details={"duration": duration},
            )
        else:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Exceeded time limit: {duration:.2f}s > {self.max_seconds}s",
                details={"duration": duration, "limit": self.max_seconds},
            )


class TokenUsageReasonable(BaseEvaluator):
    """Check if token usage is reasonable."""

    def __init__(self, max_tokens: int = 2000, max_cost: float = 0.10):
        self.max_tokens = max_tokens
        self.max_cost = max_cost

    @property
    def name(self) -> str:
        return "token_usage_reasonable"

    @property
    def description(self) -> str:
        return (
            f"Checks if token usage is reasonable (max: {self.max_tokens} tokens, ${self.max_cost})"
        )

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        metadata = context.get("metadata", {})
        tokens_used = metadata.get("total_tokens", 0)
        cost = metadata.get("cost", 0.0)

        if tokens_used <= 0:
            return EvalResult(
                passed=False, score=0.0, reason="Token usage information not available"
            )

        issues = []
        if tokens_used > self.max_tokens:
            issues.append(f"Token usage ({tokens_used}) exceeds limit ({self.max_tokens})")

        if cost > self.max_cost:
            issues.append(f"Cost (${cost:.4f}) exceeds limit (${self.max_cost})")

        if issues:
            return EvalResult(
                passed=False,
                score=max(0, 1.0 - (tokens_used / self.max_tokens - 1.0)),
                reason="; ".join(issues),
                details={"tokens_used": tokens_used, "cost": cost},
            )

        return EvalResult(
            passed=True,
            score=1.0 - (tokens_used / self.max_tokens) * 0.5,  # Higher score for fewer tokens
            reason=f"Token usage reasonable: {tokens_used} tokens, ${cost:.4f}",
            details={"tokens_used": tokens_used, "cost": cost},
        )


# Parameter validation evaluators


class ToolCalledWithParameter(BaseEvaluator):
    """Check if a tool was called with a specific parameter."""

    def __init__(self, tool_name: str, parameter_name: str, parameter_value: Any | None = None):
        """
        Check if tool was called with a specific parameter.

        Args:
            tool_name: Name of the tool to check
            parameter_name: Name of the parameter to check for
            parameter_value: Optional - specific value to check for. If None, just checks parameter exists
        """
        self.tool_name = tool_name
        self.parameter_name = parameter_name
        self.parameter_value = parameter_value

    @property
    def name(self) -> str:
        if self.parameter_value is not None:
            return f"tool_called_with_param:{self.tool_name}.{self.parameter_name}={self.parameter_value}"
        return f"tool_called_with_param:{self.tool_name}.{self.parameter_name}"

    @property
    def description(self) -> str:
        if self.parameter_value is not None:
            return f"Checks if '{self.tool_name}' was called with {self.parameter_name}={self.parameter_value}"
        return f"Checks if '{self.tool_name}' was called with parameter '{self.parameter_name}'"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        if not tool_calls:
            return EvalResult(passed=False, score=0.0, reason="No tool calls found in response")

        # Find tool call matching the tool name (with support for MCP prefixed names)
        matching_calls = [
            call for call in tool_calls if _match_tool_name(call.get("name", ""), self.tool_name)
        ]

        if not matching_calls:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Tool '{self.tool_name}' was not called",
                details={"tools_called": [c.get("name") for c in tool_calls]},
            )

        # Check if parameter exists in any matching call
        for call in matching_calls:
            arguments = call.get("arguments", {})

            if self.parameter_name in arguments:
                actual_value = arguments[self.parameter_name]

                # If we're checking for a specific value
                if self.parameter_value is not None:
                    if actual_value == self.parameter_value:
                        return EvalResult(
                            passed=True,
                            score=1.0,
                            reason=f"Tool '{self.tool_name}' called with {self.parameter_name}={actual_value}",
                            details={"tool_call": call, "parameter_value": actual_value},
                        )
                else:
                    # Just checking parameter exists
                    return EvalResult(
                        passed=True,
                        score=1.0,
                        reason=f"Tool '{self.tool_name}' called with parameter '{self.parameter_name}'",
                        details={"tool_call": call, "parameter_value": actual_value},
                    )

        # Parameter not found or value didn't match
        if self.parameter_value is not None:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Tool '{self.tool_name}' was called but parameter '{self.parameter_name}' was not set to '{self.parameter_value}'",
                details={"tool_calls": matching_calls},
            )
        else:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Tool '{self.tool_name}' was called but parameter '{self.parameter_name}' was not provided",
                details={"tool_calls": matching_calls},
            )


class ToolCalledWithParameters(BaseEvaluator):
    """Check if a tool was called with multiple specific parameters."""

    def __init__(self, tool_name: str, parameters: dict[str, Any], partial_match: bool = False):
        """
        Check if tool was called with specific parameters.

        Args:
            tool_name: Name of the tool to check
            parameters: Dictionary of parameter_name -> expected_value
            partial_match: If True, additional parameters are allowed. If False, must match exactly
        """
        self.tool_name = tool_name
        self.parameters = parameters
        self.partial_match = partial_match

    @property
    def name(self) -> str:
        mode = "partial" if self.partial_match else "exact"
        return f"tool_called_with_params:{self.tool_name}:{mode}"

    @property
    def description(self) -> str:
        mode = "at least" if self.partial_match else "exactly"
        params_str = ", ".join(f"{k}={v}" for k, v in self.parameters.items())
        return f"Checks if '{self.tool_name}' was called with {mode} parameters: {params_str}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        if not tool_calls:
            return EvalResult(passed=False, score=0.0, reason="No tool calls found in response")

        # Find tool call matching the tool name (with support for MCP prefixed names)
        matching_calls = [
            call for call in tool_calls if _match_tool_name(call.get("name", ""), self.tool_name)
        ]

        # Also check gateway pattern: call_tool(name="tool_name", arguments={...})
        if not matching_calls:
            for call in tool_calls:
                actual_name = call.get("name", "")
                if _match_tool_name(actual_name, "call_tool"):
                    args = call.get("arguments", {})
                    inner_name = args.get("name", args.get("tool_name", ""))
                    if isinstance(inner_name, str) and _match_tool_name(inner_name, self.tool_name):
                        # Reconstruct as if the inner tool was called directly
                        inner_args = args.get("arguments", {})
                        if isinstance(inner_args, str):
                            import json as _json

                            try:
                                inner_args = _json.loads(inner_args)
                            except (ValueError, TypeError):
                                inner_args = {}
                        matching_calls.append({"name": inner_name, "arguments": inner_args})

        if not matching_calls:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Tool '{self.tool_name}' was not called",
                details={"tools_called": [c.get("name") for c in tool_calls]},
            )

        # Check each matching call for parameter match
        for call in matching_calls:
            arguments = call.get("arguments", {})

            # Unwrap common LLM patterns:
            # 1. {"request": {"param": "value"}} → {"param": "value"}
            if (
                "request" in arguments
                and isinstance(arguments["request"], dict)
                and len(arguments) == 1
            ):
                arguments = arguments["request"]
            # 2. Flatten nested request alongside other params
            elif "request" in arguments and isinstance(arguments["request"], dict):
                flat = dict(arguments)
                flat.update(flat.pop("request"))
                arguments = flat

            # Check if all required parameters match
            matches = []
            mismatches = []

            for param_name, expected_value in self.parameters.items():
                actual_value = arguments.get(param_name)

                if actual_value == expected_value:
                    matches.append(param_name)
                elif self.partial_match:
                    # For partial match: also check if the expected VALUE appears
                    # under a different param name (LLM may use dashboard_id vs identifier)
                    value_found = False
                    for _arg_name, arg_val in arguments.items():
                        if arg_val == expected_value:
                            matches.append(param_name)
                            value_found = True
                            break
                        # Also check string coercion (e.g., 1 vs "1")
                        if str(arg_val) == str(expected_value):
                            matches.append(param_name)
                            value_found = True
                            break
                    if not value_found:
                        mismatches.append(
                            {
                                "parameter": param_name,
                                "expected": expected_value,
                                "actual": actual_value,
                            }
                        )
                else:
                    mismatches.append(
                        {
                            "parameter": param_name,
                            "expected": expected_value,
                            "actual": actual_value,
                        }
                    )

            # If all parameters match
            if len(matches) == len(self.parameters):
                # For exact match, check no extra parameters
                if not self.partial_match:
                    extra_params = set(arguments.keys()) - set(self.parameters.keys())
                    if extra_params:
                        return EvalResult(
                            passed=False,
                            score=0.8,
                            reason=f"Tool called with correct parameters but has extra parameters: {extra_params}",
                            details={"tool_call": call, "extra_parameters": list(extra_params)},
                        )

                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Tool '{self.tool_name}' called with matching parameters",
                    details={"tool_call": call, "matched_parameters": matches},
                )

        # No matching call found
        score = len(matches) / len(self.parameters) if self.parameters else 0.0
        return EvalResult(
            passed=False,
            score=score,
            reason=f"Tool '{self.tool_name}' called but parameters don't match",
            details={"tool_calls": matching_calls, "matched": matches, "mismatched": mismatches},
        )


class ParameterValueInRange(BaseEvaluator):
    """Check if a parameter value is within expected range."""

    def __init__(
        self,
        tool_name: str,
        parameter_name: str,
        min_value: float | None = None,
        max_value: float | None = None,
    ):
        """
        Check if parameter value is in range.

        Args:
            tool_name: Name of the tool
            parameter_name: Name of the parameter
            min_value: Minimum acceptable value (inclusive)
            max_value: Maximum acceptable value (inclusive)
        """
        self.tool_name = tool_name
        self.parameter_name = parameter_name
        self.min_value = min_value
        self.max_value = max_value

    @property
    def name(self) -> str:
        range_str = f"{self.min_value or '-∞'}-{self.max_value or '∞'}"
        return f"param_in_range:{self.tool_name}.{self.parameter_name}:{range_str}"

    @property
    def description(self) -> str:
        range_str = f"[{self.min_value or '-∞'}, {self.max_value or '∞'}]"
        return f"Checks if {self.tool_name}.{self.parameter_name} is in range {range_str}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        matching_calls = [call for call in tool_calls if call.get("name") == self.tool_name]

        if not matching_calls:
            return EvalResult(
                passed=False, score=0.0, reason=f"Tool '{self.tool_name}' was not called"
            )

        for call in matching_calls:
            arguments = call.get("arguments", {})

            if self.parameter_name not in arguments:
                continue

            value = arguments[self.parameter_name]

            try:
                numeric_value = float(value)

                in_range = True
                if self.min_value is not None and numeric_value < self.min_value:
                    in_range = False
                if self.max_value is not None and numeric_value > self.max_value:
                    in_range = False

                if in_range:
                    return EvalResult(
                        passed=True,
                        score=1.0,
                        reason=f"Parameter {self.parameter_name}={numeric_value} is in valid range",
                        details={"value": numeric_value},
                    )
                else:
                    return EvalResult(
                        passed=False,
                        score=0.0,
                        reason=f"Parameter {self.parameter_name}={numeric_value} is out of range",
                        details={
                            "value": numeric_value,
                            "min": self.min_value,
                            "max": self.max_value,
                        },
                    )

            except (ValueError, TypeError):
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"Parameter {self.parameter_name} value '{value}' is not numeric",
                    details={"value": value},
                )

        return EvalResult(
            passed=False,
            score=0.0,
            reason=f"Parameter '{self.parameter_name}' not found in tool calls",
            details={"tool_calls": matching_calls},
        )


class ToolCallCount(BaseEvaluator):
    """Check the number of times a tool was called."""

    def __init__(
        self,
        tool_name: str | None = None,
        expected_count: int | None = None,
        min_count: int | None = None,
        max_count: int | None = None,
    ):
        """
        Check tool call count.

        Args:
            tool_name: Specific tool to count. If None, counts all tools
            expected_count: Exact number of calls expected
            min_count: Minimum number of calls
            max_count: Maximum number of calls
        """
        self.tool_name = tool_name
        self.expected_count = expected_count
        self.min_count = min_count
        self.max_count = max_count

    @property
    def name(self) -> str:
        tool = self.tool_name or "any_tool"
        if self.expected_count is not None:
            return f"tool_call_count:{tool}=={self.expected_count}"
        return f"tool_call_count:{tool}"

    @property
    def description(self) -> str:
        tool = self.tool_name or "any tool"
        if self.expected_count is not None:
            return f"Checks if '{tool}' was called exactly {self.expected_count} time(s)"
        ranges = []
        if self.min_count is not None:
            ranges.append(f"at least {self.min_count}")
        if self.max_count is not None:
            ranges.append(f"at most {self.max_count}")
        range_str = " and ".join(ranges) if ranges else "any number of"
        return f"Checks if '{tool}' was called {range_str} times"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        if self.tool_name:
            count = sum(1 for call in tool_calls if call.get("name") == self.tool_name)
            tool_desc = f"'{self.tool_name}'"
        else:
            count = len(tool_calls)
            tool_desc = "tools"

        # Check expected count
        if self.expected_count is not None:
            if count == self.expected_count:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"{tool_desc} called exactly {count} time(s) as expected",
                    details={"count": count},
                )
            else:
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"{tool_desc} called {count} time(s), expected {self.expected_count}",
                    details={"count": count, "expected": self.expected_count},
                )

        # Check range
        passed = True
        issues = []

        if self.min_count is not None and count < self.min_count:
            passed = False
            issues.append(f"called {count} time(s), minimum {self.min_count}")

        if self.max_count is not None and count > self.max_count:
            passed = False
            issues.append(f"called {count} time(s), maximum {self.max_count}")

        if passed:
            return EvalResult(
                passed=True,
                score=1.0,
                reason=f"{tool_desc} called {count} time(s), within expected range",
                details={"count": count},
            )
        else:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="; ".join(issues),
                details={"count": count, "min": self.min_count, "max": self.max_count},
            )


class ToolCallSequence(BaseEvaluator):
    """Check that tools were called in a specific order."""

    def __init__(
        self,
        sequence: list[str],
        strict: bool = True,
        allow_intermediate: bool = False,
    ):
        """
        Check tool call sequence.

        Args:
            sequence: List of tool names that should be called in order
            strict: If True, sequence must match exactly (no extra tools).
                   If False, only checks that sequence appears in order.
            allow_intermediate: If True, allows other tools between sequence steps.
                              Only applies when strict=False.

        Examples:
            # Strict sequence - must be exactly these tools in this order
            ToolCallSequence(["list_datasets", "generate_chart"], strict=True)

            # Loose sequence - these tools must appear in order, but other tools allowed
            ToolCallSequence(["list_datasets", "generate_chart"], strict=False, allow_intermediate=True)
        """
        self.sequence = sequence
        self.strict = strict
        self.allow_intermediate = allow_intermediate

    @property
    def name(self) -> str:
        return f"tool_call_sequence:{' -> '.join(self.sequence)}"

    @property
    def description(self) -> str:
        if self.strict:
            return f"Checks that tools are called in exact sequence: {' -> '.join(self.sequence)}"
        elif self.allow_intermediate:
            return f"Checks that tools appear in order (other tools allowed): {' -> '.join(self.sequence)}"
        else:
            return f"Checks that only these tools are called in order: {' -> '.join(self.sequence)}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])

        if not tool_calls:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="No tool calls found in response",
            )

        actual_sequence = [call.get("name") for call in tool_calls]

        if self.strict:
            # Exact match required
            if actual_sequence == self.sequence:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Tools called in exact sequence: {' -> '.join(actual_sequence)}",
                    details={
                        "actual_sequence": actual_sequence,
                        "expected_sequence": self.sequence,
                    },
                )
            else:
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"Sequence mismatch. Expected: {' -> '.join(self.sequence)}, Got: {' -> '.join(actual_sequence)}",
                    details={
                        "actual_sequence": actual_sequence,
                        "expected_sequence": self.sequence,
                    },
                )

        # Non-strict mode: check if sequence appears in order
        sequence_idx = 0
        found_positions = []

        for i, tool_name in enumerate(actual_sequence):
            if sequence_idx < len(self.sequence) and tool_name == self.sequence[sequence_idx]:
                found_positions.append(i)
                sequence_idx += 1
            elif not self.allow_intermediate and tool_name not in self.sequence:
                # Found a tool not in our sequence and intermediates not allowed
                return EvalResult(
                    passed=False,
                    score=sequence_idx / len(self.sequence),
                    reason=f"Unexpected tool '{tool_name}' at position {i}. Only {self.sequence} allowed.",
                    details={
                        "actual_sequence": actual_sequence,
                        "expected_sequence": self.sequence,
                        "found_up_to_index": sequence_idx,
                        "unexpected_tool": tool_name,
                    },
                )

        # Check if we found all tools in the sequence
        if sequence_idx == len(self.sequence):
            return EvalResult(
                passed=True,
                score=1.0,
                reason=f"Required tools called in correct order: {' -> '.join([actual_sequence[i] for i in found_positions])}",
                details={
                    "actual_sequence": actual_sequence,
                    "expected_sequence": self.sequence,
                    "found_positions": found_positions,
                },
            )
        else:
            missing_tools = self.sequence[sequence_idx:]
            return EvalResult(
                passed=False,
                score=sequence_idx / len(self.sequence),
                reason=f"Incomplete sequence. Found {sequence_idx}/{len(self.sequence)} tools. Missing: {' -> '.join(missing_tools)}",
                details={
                    "actual_sequence": actual_sequence,
                    "expected_sequence": self.sequence,
                    "found_up_to_index": sequence_idx,
                    "missing_tools": missing_tools,
                },
            )


# Chart creation evaluators


class WasChartCreated(BaseEvaluator):
    """Check if a chart was created."""

    @property
    def name(self) -> str:
        return "was_chart_created"

    @property
    def description(self) -> str:
        return "Checks if a chart was successfully created"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])
        tool_results = context.get("tool_results", [])

        # Look for chart creation tool calls
        chart_tools = ["create_chart", "add_chart", "new_chart"]
        chart_created = False
        chart_id = None

        for i, call in enumerate(tool_calls):
            if any(tool in call.get("name", "") for tool in chart_tools):
                if i < len(tool_results):
                    result = tool_results[i]
                    if not result.is_error:
                        chart_created = True
                        # Try to extract chart ID from result
                        content = result.content or ""
                        if isinstance(content, str):
                            # Look for chart ID pattern
                            import re

                            match = re.search(r"chart[_\s]?id[:\s]+(\d+)", content, re.IGNORECASE)
                            if match:
                                chart_id = match.group(1)

        if chart_created:
            return EvalResult(
                passed=True,
                score=1.0,
                reason="Chart was successfully created",
                details={"chart_id": chart_id} if chart_id else None,
            )
        else:
            return EvalResult(passed=False, score=0.0, reason="No chart creation detected")


class SQLQueryValid(BaseEvaluator):
    """Check if generated SQL query is syntactically valid."""

    @property
    def name(self) -> str:
        return "sql_query_valid"

    @property
    def description(self) -> str:
        return "Checks if generated SQL query is syntactically valid"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")

        # Extract SQL from response (look for code blocks or SQL patterns)
        sql_pattern = r"```sql\n(.*?)\n```|SELECT\s+.*?FROM\s+.*?(?:;|\n|$)"
        sql_matches = re.findall(sql_pattern, response, re.DOTALL | re.IGNORECASE)

        if not sql_matches:
            return EvalResult(passed=False, score=0.0, reason="No SQL query found in response")

        # Basic SQL validation
        sql_query = sql_matches[0] if isinstance(sql_matches[0], str) else sql_matches[0][0]
        sql_query = sql_query.strip()

        # Check for basic SQL structure
        required_keywords = ["SELECT", "FROM"]
        has_required = all(keyword in sql_query.upper() for keyword in required_keywords)

        if has_required:
            return EvalResult(
                passed=True,
                score=1.0,
                reason="SQL query appears syntactically valid",
                details={"query": sql_query[:200]},  # First 200 chars
            )
        else:
            return EvalResult(
                passed=False,
                score=0.5,
                reason="SQL query may have syntax issues",
                details={"query": sql_query[:200]},
            )


# Composite evaluator for running multiple evaluations


class ResponseIncludes(BaseEvaluator):
    """Check if the response includes specific content.

    Searches both the LLM response text AND tool result content,
    since the expected content may appear in tool output rather than
    the LLM's synthesis (especially with agentic SDK providers).
    """

    def __init__(
        self,
        content: str | list[str],
        case_sensitive: bool = False,
        match_all: bool = True,
    ):
        """
        Check if response includes expected content.

        Args:
            content: String or list of strings that should appear in response
            case_sensitive: Whether to match case-sensitively (default: False)
            match_all: If True, all content items must match. If False, any match passes.
        """
        self.expected_content = content if isinstance(content, list) else [content]
        self.case_sensitive = case_sensitive
        self.match_all = match_all

    @property
    def name(self) -> str:
        return "response_includes"

    @property
    def description(self) -> str:
        return f"Checks if response includes: {', '.join(self.expected_content[:3])}{'...' if len(self.expected_content) > 3 else ''}"

    def _build_searchable_text(self, context: dict[str, Any]) -> str:
        """Build searchable text from response + tool results."""
        response = context.get("response", "")
        # Also include tool results content
        for tr in context.get("tool_results", []):
            if isinstance(tr, dict):
                rc = tr.get("content", tr.get("result", ""))
            elif hasattr(tr, "content"):
                rc = tr.content
            else:
                rc = str(tr)
            if rc:
                if isinstance(rc, list):
                    for item in rc:
                        response += " " + (item.text if hasattr(item, "text") else str(item))
                else:
                    response += " " + str(rc)
        return response

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = self._build_searchable_text(context)

        if not self.case_sensitive:
            response = response.lower()

        found = []
        not_found = []

        for content in self.expected_content:
            check_content = content if self.case_sensitive else content.lower()
            if check_content in response:
                found.append(content)
            else:
                not_found.append(content)

        score = len(found) / len(self.expected_content) if self.expected_content else 0.0

        if self.match_all:
            passed = score == 1.0
            if passed:
                return EvalResult(
                    passed=True,
                    score=score,
                    reason="All expected content found in response",
                    details={"found": found},
                )
            else:
                return EvalResult(
                    passed=False,
                    score=score,
                    reason=f"Missing content: {len(not_found)}/{len(self.expected_content)} items",
                    details={"found": found, "not_found": not_found},
                )
        else:
            # Any match passes
            passed = len(found) > 0
            if passed:
                return EvalResult(
                    passed=True,
                    score=score,
                    reason=f"Found {len(found)}/{len(self.expected_content)} expected items",
                    details={"found": found, "not_found": not_found},
                )
            else:
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason="No expected content found in response",
                    details={"not_found": not_found},
                )


class NoHallucination(BaseEvaluator):
    """Check that the response doesn't contain hallucinated data not present in tool results."""

    def __init__(
        self,
        check_numbers: bool = True,
        check_names: bool = True,
        check_dates: bool = True,
        strict: bool = False,
    ):
        """
        Check for hallucinations in response.

        Args:
            check_numbers: Verify numeric values in response appear in tool results
            check_names: Verify names/identifiers in response appear in tool results
            check_dates: Verify dates in response appear in tool results
            strict: If True, any unverified data fails. If False, use heuristics.
        """
        self.check_numbers = check_numbers
        self.check_names = check_names
        self.check_dates = check_dates
        self.strict = strict

    @property
    def name(self) -> str:
        return "no_hallucination"

    @property
    def description(self) -> str:
        return "Checks that response data is grounded in tool results"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")
        tool_results = context.get("tool_results", [])

        if not tool_results:
            # Can't verify without tool results - pass by default
            return EvalResult(
                passed=True,
                score=0.5,
                reason="No tool results to verify against",
                details={"warning": "Unable to verify - no tool data available"},
            )

        # Collect all data from tool results
        tool_data = self._extract_tool_data(tool_results)

        # Extract claims from response
        response_claims = self._extract_claims(response)

        # Verify claims against tool data
        verified = []
        unverified = []
        hallucinated = []

        for claim_type, claim_value in response_claims:
            if self._verify_claim(claim_type, claim_value, tool_data):
                verified.append((claim_type, claim_value))
            else:
                if self.strict:
                    hallucinated.append((claim_type, claim_value))
                else:
                    unverified.append((claim_type, claim_value))

        total_claims = len(verified) + len(unverified) + len(hallucinated)

        if total_claims == 0:
            return EvalResult(
                passed=True,
                score=1.0,
                reason="No verifiable claims found in response",
                details={},
            )

        if hallucinated:
            return EvalResult(
                passed=False,
                score=len(verified) / total_claims,
                reason=f"Found {len(hallucinated)} hallucinated value(s)",
                details={
                    "hallucinated": [f"{t}: {v}" for t, v in hallucinated],
                    "verified": [f"{t}: {v}" for t, v in verified],
                },
            )

        # Score based on verified vs unverified
        if self.strict and unverified:
            score = len(verified) / total_claims
            return EvalResult(
                passed=False,
                score=score,
                reason=f"{len(unverified)} unverified claim(s) in strict mode",
                details={
                    "verified": [f"{t}: {v}" for t, v in verified],
                    "unverified": [f"{t}: {v}" for t, v in unverified],
                },
            )

        return EvalResult(
            passed=True,
            score=1.0 if not unverified else 0.8,
            reason=f"Verified {len(verified)}/{total_claims} claims",
            details={
                "verified": [f"{t}: {v}" for t, v in verified],
                "unverified": [f"{t}: {v}" for t, v in unverified] if unverified else None,
            },
        )

    def _extract_tool_data(self, tool_results: list) -> dict[str, set]:
        """Extract verifiable data from tool results."""
        data = {"numbers": set(), "strings": set(), "dates": set()}

        for result in tool_results:
            content = getattr(result, "content", None) or str(result)
            if isinstance(content, str):
                # Extract numbers
                numbers = re.findall(r"\b\d+(?:\.\d+)?\b", content)
                data["numbers"].update(numbers)

                # Extract potential identifiers/names (capitalized words, quoted strings)
                names = re.findall(r'"([^"]+)"', content)
                names.extend(re.findall(r"'([^']+)'", content))
                data["strings"].update(names)

                # Extract dates (various formats)
                dates = re.findall(r"\d{4}-\d{2}-\d{2}", content)
                dates.extend(re.findall(r"\d{2}/\d{2}/\d{4}", content))
                data["dates"].update(dates)

        return data

    def _extract_claims(self, response: str) -> list[tuple[str, str]]:
        """Extract verifiable claims from response."""
        claims = []

        if self.check_numbers:
            # Extract significant numbers (skip small common numbers like 1, 2, 3)
            numbers = re.findall(r"\b(\d{2,}(?:\.\d+)?)\b", response)
            for num in numbers:
                claims.append(("number", num))

        if self.check_dates:
            dates = re.findall(r"\d{4}-\d{2}-\d{2}", response)
            dates.extend(re.findall(r"\d{2}/\d{2}/\d{4}", response))
            for date in dates:
                claims.append(("date", date))

        return claims

    def _verify_claim(self, claim_type: str, value: str, tool_data: dict[str, set]) -> bool:
        """Check if a claim can be verified against tool data."""
        if claim_type == "number":
            return value in tool_data["numbers"]
        elif claim_type == "date":
            return value in tool_data["dates"]
        elif claim_type == "string":
            return value in tool_data["strings"]
        return False


class LLMJudge(BaseEvaluator):
    """Use an LLM to evaluate the quality of a response."""

    def __init__(
        self,
        criteria: str,
        model: str = "claude-sonnet-4-20250514",
        provider: str = "anthropic",
        pass_threshold: float = 0.7,
        rubric: str | None = None,
    ):
        """
        Use LLM to judge response quality.

        Args:
            criteria: What to evaluate (e.g., "accuracy", "helpfulness", "completeness")
            model: LLM model to use for judging
            provider: LLM provider (anthropic, openai, gemini)
            pass_threshold: Minimum score (0-1) to pass (default: 0.7)
            rubric: Optional detailed rubric for scoring. If not provided, uses criteria.

        Example YAML:
            evaluators:
              - type: llm_judge
                criteria: "Response correctly answers the user's question about chart data"
                pass_threshold: 0.8
                rubric: |
                  Score 1.0: Complete, accurate answer with all requested data
                  Score 0.7: Mostly correct with minor omissions
                  Score 0.4: Partially correct but missing key information
                  Score 0.0: Incorrect or unrelated response
        """
        self.criteria = criteria
        self.model = model
        self.provider = provider
        self.pass_threshold = pass_threshold
        self.rubric = rubric or self._default_rubric()

    def _default_rubric(self) -> str:
        return f"""Evaluate based on: {self.criteria}

Score 1.0: Fully meets the criteria
Score 0.8: Mostly meets criteria with minor issues
Score 0.6: Partially meets criteria
Score 0.4: Significant gaps in meeting criteria
Score 0.2: Barely addresses the criteria
Score 0.0: Does not meet criteria at all"""

    @property
    def name(self) -> str:
        return f"llm_judge:{self.criteria[:30]}..."

    @property
    def description(self) -> str:
        return f"LLM judges response based on: {self.criteria}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """Evaluate using LLM - runs synchronously by creating event loop if needed."""
        import asyncio

        try:
            # Try to get existing event loop
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # We're in an async context, create a new task
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, self._async_evaluate(context))
                    return future.result(timeout=60)
            else:
                return loop.run_until_complete(self._async_evaluate(context))
        except RuntimeError:
            # No event loop, create one
            return asyncio.run(self._async_evaluate(context))

    async def _async_evaluate(self, context: dict[str, Any]) -> EvalResult:
        """Async evaluation using LLM."""
        import json

        prompt = context.get("prompt", "")
        response = context.get("response", "")
        tool_calls = context.get("tool_calls", [])
        tool_results = context.get("tool_results", [])

        # Build context for the judge
        judge_context = f"""## Original User Request
{prompt}

## Assistant Response
{response}

## Tool Calls Made
{json.dumps(tool_calls, indent=2) if tool_calls else "None"}

## Tool Results
{self._format_tool_results(tool_results) if tool_results else "None"}
"""

        judge_prompt = f"""You are an impartial judge evaluating an AI assistant's response.

{judge_context}

## Evaluation Criteria
{self.criteria}

## Scoring Rubric
{self.rubric}

## Instructions
1. Analyze the response against the criteria
2. Consider the tool calls and results in your evaluation
3. Provide a score from 0.0 to 1.0
4. Explain your reasoning

Respond in this exact JSON format:
{{"score": 0.X, "reasoning": "Your explanation here"}}"""

        try:
            result = await self._call_llm(judge_prompt)

            # Parse JSON response
            try:
                # Extract JSON from response (handle markdown code blocks)
                json_str = result
                if "```json" in result:
                    json_str = result.split("```json")[1].split("```")[0]
                elif "```" in result:
                    json_str = result.split("```")[1].split("```")[0]

                parsed = json.loads(json_str.strip())
                score = float(parsed.get("score", 0))
                reasoning = parsed.get("reasoning", "No reasoning provided")

            except (json.JSONDecodeError, ValueError, IndexError):
                # Fallback: try to extract score from text
                score = self._extract_score(result)
                reasoning = result

            passed = score >= self.pass_threshold

            return EvalResult(
                passed=passed,
                score=score,
                reason=f"LLM Judge score: {score:.2f} (threshold: {self.pass_threshold})",
                details={
                    "reasoning": reasoning,
                    "criteria": self.criteria,
                    "model": self.model,
                    "threshold": self.pass_threshold,
                },
            )

        except Exception as e:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"LLM Judge error: {str(e)}",
                details={"error": str(e)},
            )

    def _format_tool_results(self, tool_results: list) -> str:
        """Format tool results for the judge."""
        formatted = []
        for result in tool_results:
            content = getattr(result, "content", str(result))
            if len(str(content)) > 500:
                content = str(content)[:500] + "..."
            formatted.append(f"- {content}")
        return "\n".join(formatted) if formatted else "None"

    def _extract_score(self, text: str) -> float:
        """Try to extract a score from unstructured text."""
        import re

        # Look for patterns like "score: 0.8" or "0.8/1.0" or "8/10"
        patterns = [
            r"score[:\s]+([0-9.]+)",
            r"([0-9.]+)\s*/\s*1\.?0?",
            r"([0-9]+)\s*/\s*10",
            r"rating[:\s]+([0-9.]+)",
        ]

        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                try:
                    score = float(match.group(1))
                    # Normalize to 0-1 range
                    if score > 1:
                        score = score / 10
                    return min(1.0, max(0.0, score))
                except ValueError:
                    continue

        return 0.0

    async def _call_llm(self, prompt: str) -> str:
        """Call LLM API for judging."""
        import httpx

        # Get config
        try:
            from testmcpy.config import get_config

            config = get_config()
        except ImportError:
            config = None

        if self.provider == "anthropic":
            api_key = (config.get("ANTHROPIC_API_KEY") if config else None) or ""
            if not api_key:
                raise ValueError(
                    "ANTHROPIC_API_KEY not set. Configure it in "
                    ".llm_providers.yaml via ${ANTHROPIC_API_KEY} substitution."
                )

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": self.model,
                        "max_tokens": 500,
                        "messages": [{"role": "user", "content": prompt}],
                    },
                )
                response.raise_for_status()
                result = response.json()
                return result["content"][0]["text"]

        elif self.provider == "openai":
            api_key = (config.get("OPENAI_API_KEY") if config else None) or ""
            if not api_key:
                raise ValueError(
                    "OPENAI_API_KEY not set. Configure it in "
                    ".llm_providers.yaml via ${OPENAI_API_KEY} substitution."
                )

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": self.model,
                        "max_tokens": 500,
                        "messages": [{"role": "user", "content": prompt}],
                    },
                )
                response.raise_for_status()
                result = response.json()
                return result["choices"][0]["message"]["content"]

        elif self.provider in ("gemini", "google"):
            api_key = (
                (config.get("GOOGLE_API_KEY") if config else None)
                or (config.get("GEMINI_API_KEY") if config else None)
                or ""
            )
            if not api_key:
                raise ValueError(
                    "GOOGLE_API_KEY / GEMINI_API_KEY not set. Configure it in "
                    ".llm_providers.yaml via ${GOOGLE_API_KEY} substitution."
                )

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={api_key}",
                    json={
                        "contents": [{"parts": [{"text": prompt}]}],
                        "generationConfig": {"maxOutputTokens": 500},
                    },
                )
                response.raise_for_status()
                result = response.json()
                return result["candidates"][0]["content"]["parts"][0]["text"]

        else:
            raise ValueError(f"Unsupported provider for LLM judge: {self.provider}")


class CompositeEvaluator(BaseEvaluator):
    """Run multiple evaluators and combine results."""

    def __init__(self, evaluators: list[BaseEvaluator], require_all: bool = False):
        self.evaluators = evaluators
        self.require_all = require_all

    @property
    def name(self) -> str:
        return "composite_evaluator"

    @property
    def description(self) -> str:
        mode = "all" if self.require_all else "any"
        return f"Composite evaluator requiring {mode} to pass"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        results = []
        total_score = 0.0

        for evaluator in self.evaluators:
            result = evaluator.evaluate(context)
            results.append(
                {
                    "evaluator": evaluator.name,
                    "passed": result.passed,
                    "score": result.score,
                    "reason": result.reason,
                }
            )
            total_score += result.score

        avg_score = total_score / len(self.evaluators) if self.evaluators else 0.0
        passed_count = sum(1 for r in results if r["passed"])

        if self.require_all:
            passed = passed_count == len(self.evaluators)
            reason = (
                "All evaluators passed"
                if passed
                else f"{passed_count}/{len(self.evaluators)} evaluators passed"
            )
        else:
            passed = passed_count > 0
            reason = f"{passed_count}/{len(self.evaluators)} evaluators passed"

        return EvalResult(
            passed=passed, score=avg_score, reason=reason, details={"results": results}
        )


class ResponseNotIncludes(BaseEvaluator):
    """Check that the response does NOT include any of the given strings."""

    def __init__(
        self,
        content: str | list[str],
        case_sensitive: bool = False,
    ):
        """
        Fail if response contains any of the forbidden strings.

        Args:
            content: String or list of strings that must NOT appear in response
            case_sensitive: Whether to match case-sensitively (default: False)
        """
        self.forbidden_content = content if isinstance(content, list) else [content]
        self.case_sensitive = case_sensitive

    @property
    def name(self) -> str:
        return "response_not_includes"

    @property
    def description(self) -> str:
        return f"Checks response does NOT include: {', '.join(self.forbidden_content[:3])}{'...' if len(self.forbidden_content) > 3 else ''}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")
        if not self.case_sensitive:
            response = response.lower()

        found = []
        for content in self.forbidden_content:
            check = content if self.case_sensitive else content.lower()
            if check in response:
                found.append(content)

        if found:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Response contains forbidden content: {found}",
                details={"found_forbidden": found},
            )
        return EvalResult(
            passed=True,
            score=1.0,
            reason="Response does not contain any forbidden content",
            details={"checked": self.forbidden_content},
        )


class ResponseMatchesPattern(BaseEvaluator):
    """Check that the response matches a regex pattern."""

    def __init__(self, pattern: str, should_match: bool = True):
        """
        Regex match on response text.

        Args:
            pattern: Regular expression pattern to search for
            should_match: If True, pattern must be found. If False, pattern must NOT be found.
        """
        self.pattern = pattern
        self.should_match = should_match

    @property
    def name(self) -> str:
        return "response_matches_pattern"

    @property
    def description(self) -> str:
        verb = "matches" if self.should_match else "does not match"
        return f"Checks response {verb} pattern: {self.pattern[:50]}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")
        match = re.search(self.pattern, response)

        if self.should_match:
            if match:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Pattern found: '{match.group()}'",
                    details={"pattern": self.pattern, "match": match.group()},
                )
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Pattern not found in response: {self.pattern}",
                details={"pattern": self.pattern},
            )
        else:
            if match:
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"Forbidden pattern found: '{match.group()}'",
                    details={"pattern": self.pattern, "match": match.group()},
                )
            return EvalResult(
                passed=True,
                score=1.0,
                reason="Forbidden pattern not found in response",
                details={"pattern": self.pattern},
            )


class UrlIsValid(BaseEvaluator):
    """Check that URLs in the response are absolute and well-formed."""

    def __init__(self, require_https: bool = False):
        """
        Validate URLs found in the response.

        Args:
            require_https: If True, all URLs must use https scheme
        """
        self.require_https = require_https

    @property
    def name(self) -> str:
        return "url_is_valid"

    @property
    def description(self) -> str:
        return "Checks that URLs in response are absolute and well-formed"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")
        # Find URLs in response
        url_pattern = r"https?://[^\s<>\"')\]}]+"
        urls = re.findall(url_pattern, response)

        if not urls:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="No URLs found in response",
                details={"urls_found": []},
            )

        invalid = []
        for url in urls:
            # Check for relative URLs (no scheme)
            if not url.startswith(("http://", "https://")):
                invalid.append({"url": url, "issue": "relative URL (no scheme)"})
            elif self.require_https and not url.startswith("https://"):
                invalid.append({"url": url, "issue": "not HTTPS"})
            elif "//" in url.split("://", 1)[-1]:
                invalid.append({"url": url, "issue": "double slash in path"})

        if invalid:
            return EvalResult(
                passed=False,
                score=1.0 - len(invalid) / len(urls),
                reason=f"{len(invalid)}/{len(urls)} URLs are invalid",
                details={"invalid_urls": invalid, "all_urls": urls},
            )
        return EvalResult(
            passed=True,
            score=1.0,
            reason=f"All {len(urls)} URLs are valid and absolute",
            details={"urls": urls},
        )


class NoLeakedData(BaseEvaluator):
    """Check that the response does not contain leaked sensitive data."""

    # Default patterns that indicate data leakage
    DEFAULT_PATTERNS = [
        r"postgresql://[^\s]+",  # Connection strings
        r"mysql://[^\s]+",
        r"mongodb://[^\s]+",
        r"redis://[^\s]+",
        r"sqlite:///[^\s]+",
        r"(?:api[_-]?key|apikey|secret[_-]?key|access[_-]?token)\s*[:=]\s*['\"][^\s'\"]{10,}",
        r"Traceback \(most recent call last\)",  # Python stack traces
        r"File \"[^\"]+\", line \d+",  # Python file references
        r"at\s+[\w.]+\([\w.]+:\d+\)",  # Java/JS stack traces
        r"/(?:home|var|etc|usr)/[\w/]+\.(?:py|js|conf|cfg|ini|yaml|yml)",  # Server file paths
    ]

    def __init__(self, extra_patterns: list[str] | None = None):
        """
        Scan response for leaked sensitive data.

        Args:
            extra_patterns: Additional regex patterns to check (beyond defaults)
        """
        self.patterns = self.DEFAULT_PATTERNS.copy()
        if extra_patterns:
            self.patterns.extend(extra_patterns)

    @property
    def name(self) -> str:
        return "no_leaked_data"

    @property
    def description(self) -> str:
        return "Checks that response does not contain connection strings, API keys, stack traces, or server paths"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        response = context.get("response", "")
        leaks = []

        for pattern in self.patterns:
            matches = re.findall(pattern, response, re.IGNORECASE)
            if matches:
                leaks.append({"pattern": pattern, "matches": matches[:3]})

        if leaks:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Found {len(leaks)} type(s) of leaked data in response",
                details={"leaks": leaks},
            )
        return EvalResult(
            passed=True,
            score=1.0,
            reason="No sensitive data leaked in response",
            details={"patterns_checked": len(self.patterns)},
        )


# Load/burst test aggregate evaluators


class SuccessRateAbove(BaseEvaluator):
    """Check that success rate across multiple runs meets minimum threshold."""

    def __init__(self, min_rate: float = 0.9):
        self.min_rate = min_rate

    @property
    def name(self) -> str:
        return f"success_rate_above:{self.min_rate:.0%}"

    @property
    def description(self) -> str:
        return f"Checks that success rate is at least {self.min_rate:.0%}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        results = context.get("load_test_results", [])
        if not results:
            return EvalResult(passed=False, score=0.0, reason="No load test results")

        successes = sum(1 for r in results if r.get("success", False))
        rate = successes / len(results)
        passed = rate >= self.min_rate
        return EvalResult(
            passed=passed,
            score=rate,
            reason=f"Success rate: {rate:.1%} (minimum: {self.min_rate:.1%})",
            details={"success_rate": rate, "total": len(results), "successes": successes},
        )


class LatencyPercentile(BaseEvaluator):
    """Check that a latency percentile is within bounds."""

    def __init__(self, percentile: float = 95, max_seconds: float = 30.0):
        self.percentile = percentile
        self.max_seconds = max_seconds

    @property
    def name(self) -> str:
        return f"latency_percentile:p{self.percentile}:{self.max_seconds}s"

    @property
    def description(self) -> str:
        return f"Checks that P{self.percentile} latency is under {self.max_seconds}s"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        results = context.get("load_test_results", [])
        if not results:
            return EvalResult(passed=False, score=0.0, reason="No load test results")

        import math

        durations = sorted(r.get("duration", 0) for r in results)
        # Nearest-rank percentile: ceil(N * P / 100) - 1
        idx = int(math.ceil(len(durations) * self.percentile / 100)) - 1
        idx = max(0, min(idx, len(durations) - 1))
        p_value = durations[idx]
        passed = p_value <= self.max_seconds
        return EvalResult(
            passed=passed,
            score=min(1.0, self.max_seconds / p_value) if p_value > 0 else 1.0,
            reason=f"P{self.percentile}: {p_value:.1f}s (max: {self.max_seconds}s)",
            details={"percentile": self.percentile, "value": p_value, "max": self.max_seconds},
        )


# MCP-aware deterministic evaluators


class MCPToolResultMatches(BaseEvaluator):
    """Call MCP tool directly and verify it matches what the LLM received."""

    def __init__(self, tool_name: str, arguments: dict[str, Any] | None = None):
        self.tool_name = tool_name
        self.arguments = arguments or {}

    @property
    def name(self) -> str:
        return f"mcp_tool_result_matches:{self.tool_name}"

    @property
    def description(self) -> str:
        return f"Calls MCP tool '{self.tool_name}' directly and compares result to what the LLM received"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """Sync fallback — returns skip since MCP evaluation requires async."""
        return EvalResult(
            passed=False,
            score=0.0,
            reason="MCP-aware evaluator requires async context (use aevaluate)",
        )

    async def aevaluate(self, context: dict[str, Any]) -> EvalResult:
        mcp_client = context.get("mcp_client")
        if not mcp_client:
            return EvalResult(passed=False, score=0.0, reason="No MCP client in context")
        return await self._async_evaluate(context)

    async def _async_evaluate(self, context: dict[str, Any]) -> EvalResult:
        import json

        from testmcpy.src.mcp_client import MCPToolCall as _MCPToolCall

        mcp_client = context["mcp_client"]

        # Call MCP directly to get ground truth.
        # FastMCP gateway tools often require arguments wrapped in {"request": {...}}
        # Try unwrapped first, then wrapped as fallback on validation error.
        ground_truth = await mcp_client.call_tool(
            _MCPToolCall(name=self.tool_name, arguments=self.arguments)
        )

        # Check for validation errors in content (not is_error) and retry wrapped
        gt_text = self._extract_text(ground_truth.content)
        if ("validation error" in gt_text.lower() or ground_truth.is_error) and (
            "request" not in self.arguments
        ):
            wrapped = {"request": self.arguments} if self.arguments else {"request": {}}
            retry = await mcp_client.call_tool(_MCPToolCall(name=self.tool_name, arguments=wrapped))
            if not retry.is_error:
                gt_text = self._extract_text(retry.content)
                ground_truth = retry

        if ground_truth.is_error:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"MCP ground truth call failed: {ground_truth.error_message}",
                details={"error": ground_truth.error_message},
            )

        # Find what the LLM got for this tool
        llm_result_text = self._find_llm_result(context)

        if not llm_result_text:
            return EvalResult(
                passed=False,
                score=0.5,
                reason=f"LLM called {self.tool_name} but no result found to compare",
                details={"ground_truth": gt_text[:500]},
            )

        # Compare: parse both as JSON and compare key fields
        try:
            gt_data = json.loads(gt_text) if isinstance(gt_text, str) else gt_text
            llm_data = (
                json.loads(llm_result_text) if isinstance(llm_result_text, str) else llm_result_text
            )

            # For dicts, check key overlap
            if isinstance(gt_data, dict) and isinstance(llm_data, dict):
                gt_keys = set(gt_data.keys())
                llm_keys = set(llm_data.keys())
                common = gt_keys & llm_keys
                score = len(common) / len(gt_keys) if gt_keys else 1.0

                mismatches = []
                for key in common:
                    if str(gt_data[key]) != str(llm_data[key]):
                        mismatches.append(key)

                if not mismatches:
                    return EvalResult(
                        passed=True,
                        score=1.0,
                        reason=f"MCP ground truth matches LLM result ({len(common)} fields verified)",
                        details={"verified_fields": list(common)},
                    )
                else:
                    return EvalResult(
                        passed=False,
                        score=score,
                        reason=f"{len(mismatches)} field(s) differ from ground truth",
                        details={
                            "mismatched_fields": mismatches,
                            "ground_truth_sample": {k: gt_data[k] for k in mismatches[:3]},
                        },
                    )
            else:
                # String comparison
                match = gt_text.strip() == llm_result_text.strip()
                return EvalResult(
                    passed=match,
                    score=1.0 if match else 0.5,
                    reason="Ground truth matches" if match else "Results differ",
                    details={
                        "ground_truth_length": len(gt_text),
                        "llm_result_length": len(llm_result_text),
                    },
                )
        except (json.JSONDecodeError, ValueError):
            # Fallback: substring match
            match = gt_text[:200] in llm_result_text or llm_result_text[:200] in gt_text
            return EvalResult(
                passed=match,
                score=0.8 if match else 0.3,
                reason="Content overlap detected"
                if match
                else "Content does not match ground truth",
            )

    def _find_llm_result(self, context: dict[str, Any]) -> str:
        """Find the LLM's result for this tool from context."""
        # Check tool_results
        for tr in context.get("tool_results", []):
            if isinstance(tr, dict):
                tr_content = tr.get("content", tr.get("result", ""))
            elif hasattr(tr, "content"):
                tr_content = tr.content
            else:
                continue

            tr_text = self._extract_text(tr_content)
            if tr_text and self.tool_name in str(context.get("tool_calls", [])):
                return tr_text

        # Try to find in tool_calls results
        for tc in context.get("tool_calls", []):
            tc_name = tc.get("name", "")
            if _match_tool_name(tc_name, self.tool_name) or (
                _match_tool_name(tc_name, "call_tool")
                and tc.get("arguments", {}).get(
                    "name", tc.get("arguments", {}).get("tool_name", "")
                )
                == self.tool_name
            ):
                tc_result = tc.get("result", {})
                if isinstance(tc_result, dict):
                    return self._extract_text(tc_result.get("content", ""))

        return ""

    def _extract_text(self, content: Any) -> str:
        """Extract text from various content types."""
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for item in content:
                if hasattr(item, "text"):
                    parts.append(item.text)
                else:
                    parts.append(str(item))
            return "\n".join(parts)
        if hasattr(content, "text"):
            return content.text
        return str(content)


class MCPVerifyResponseData(BaseEvaluator):
    """Call MCP to get ground truth, verify LLM response contains correct values."""

    def __init__(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        check_fields: list[str] | None = None,
    ):
        self.tool_name = tool_name
        self.arguments = arguments or {}
        self.check_fields = check_fields  # If None, check all top-level fields

    @property
    def name(self) -> str:
        return f"mcp_verify_response_data:{self.tool_name}"

    @property
    def description(self) -> str:
        return f"Calls MCP tool '{self.tool_name}' for ground truth and checks LLM response contains correct values"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """Sync fallback — returns skip since MCP evaluation requires async."""
        return EvalResult(
            passed=False,
            score=0.0,
            reason="MCP-aware evaluator requires async context (use aevaluate)",
        )

    async def aevaluate(self, context: dict[str, Any]) -> EvalResult:
        mcp_client = context.get("mcp_client")
        if not mcp_client:
            return EvalResult(passed=False, score=0.0, reason="No MCP client in context")
        return await self._async_evaluate(context)

    async def _async_evaluate(self, context: dict[str, Any]) -> EvalResult:
        import json

        from testmcpy.src.mcp_client import MCPToolCall as _MCPToolCall

        mcp_client = context["mcp_client"]

        # Call MCP tool to get ground truth.
        # FastMCP gateway tools often require arguments wrapped in {"request": {...}}
        # Try unwrapped first, then wrapped as fallback on validation error.
        ground_truth = await mcp_client.call_tool(
            _MCPToolCall(name=self.tool_name, arguments=self.arguments)
        )
        gt_text = self._extract_text(ground_truth.content)
        if ("validation error" in gt_text.lower() or ground_truth.is_error) and (
            "request" not in self.arguments
        ):
            wrapped = {"request": self.arguments} if self.arguments else {"request": {}}
            retry = await mcp_client.call_tool(_MCPToolCall(name=self.tool_name, arguments=wrapped))
            if not retry.is_error:
                gt_text = self._extract_text(retry.content)
                ground_truth = retry

        if ground_truth.is_error:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"MCP ground truth call failed: {ground_truth.error_message}",
                details={"error": ground_truth.error_message},
            )
        try:
            gt_data = json.loads(gt_text) if isinstance(gt_text, str) else gt_text
        except (json.JSONDecodeError, ValueError):
            gt_data = gt_text

        # Determine which fields to check
        if isinstance(gt_data, dict):
            fields_to_check = self.check_fields or list(gt_data.keys())
        else:
            # Not a dict, check if the whole value appears in response
            response = context.get("response", "")
            gt_str = str(gt_data).strip()
            found = gt_str in response
            return EvalResult(
                passed=found,
                score=1.0 if found else 0.0,
                reason="Ground truth value found in response"
                if found
                else "Ground truth value not found in response",
                details={"ground_truth": gt_str[:500]},
            )

        # For each field value, check if it appears in the LLM response
        response = context.get("response", "")
        found_fields = []
        missing_fields = []

        for field_name in fields_to_check:
            if field_name not in gt_data:
                continue
            value = gt_data[field_name]
            value_str = str(value)

            # Check if this value appears in the response (case-insensitive for strings)
            if isinstance(value, str):
                if value.lower() in response.lower():
                    found_fields.append(field_name)
                else:
                    missing_fields.append(field_name)
            elif isinstance(value, (int, float)):
                if value_str in response:
                    found_fields.append(field_name)
                else:
                    missing_fields.append(field_name)
            elif isinstance(value, bool):
                if value_str.lower() in response.lower():
                    found_fields.append(field_name)
                else:
                    missing_fields.append(field_name)
            else:
                # For complex types, check str representation
                if value_str in response:
                    found_fields.append(field_name)
                else:
                    missing_fields.append(field_name)

        total = len(found_fields) + len(missing_fields)
        score = len(found_fields) / total if total else 1.0
        passed = score >= 0.8  # At least 80% of fields must be present

        if passed:
            return EvalResult(
                passed=True,
                score=score,
                reason=f"LLM response contains {len(found_fields)}/{total} ground truth values",
                details={"found_fields": found_fields, "missing_fields": missing_fields},
            )
        else:
            return EvalResult(
                passed=False,
                score=score,
                reason=f"LLM response missing {len(missing_fields)}/{total} ground truth values",
                details={
                    "found_fields": found_fields,
                    "missing_fields": missing_fields,
                    "missing_values": {
                        f: str(gt_data[f])[:100] for f in missing_fields if f in gt_data
                    },
                },
            )

    def _extract_text(self, content: Any) -> str:
        """Extract text from various content types."""
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for item in content:
                if hasattr(item, "text"):
                    parts.append(item.text)
                else:
                    parts.append(str(item))
            return "\n".join(parts)
        if hasattr(content, "text"):
            return content.text
        return str(content)


class MCPVerifySideEffect(BaseEvaluator):
    """Verify a write operation's side effect by calling MCP to check the resource."""

    def __init__(
        self,
        verify_tool: str,
        arguments: dict[str, Any] | None = None,
        extract_from: str = "tool_result",
        extract_pattern: str | None = None,
        expect_exists: bool = True,
    ):
        self.verify_tool = verify_tool
        self.arguments = arguments or {}
        self.extract_from = extract_from
        self.extract_pattern = extract_pattern
        self.expect_exists = expect_exists

    @property
    def name(self) -> str:
        return f"mcp_verify_side_effect:{self.verify_tool}"

    @property
    def description(self) -> str:
        existence = "exists" if self.expect_exists else "does not exist"
        return f"Calls MCP tool '{self.verify_tool}' to verify resource {existence}"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """Sync fallback — returns skip since MCP evaluation requires async."""
        return EvalResult(
            passed=False,
            score=0.0,
            reason="MCP-aware evaluator requires async context (use aevaluate)",
        )

    async def aevaluate(self, context: dict[str, Any]) -> EvalResult:
        mcp_client = context.get("mcp_client")
        if not mcp_client:
            return EvalResult(passed=False, score=0.0, reason="No MCP client in context")
        return await self._async_evaluate(context)

    async def _async_evaluate(self, context: dict[str, Any]) -> EvalResult:
        from testmcpy.src.mcp_client import MCPToolCall as _MCPToolCall

        mcp_client = context["mcp_client"]

        # Extract resource ID from LLM response/tool_result if needed
        arguments = dict(self.arguments)
        if self.extract_pattern:
            extracted_id = self._extract_id(context)
            if extracted_id:
                # Replace placeholder in arguments
                for key, value in arguments.items():
                    if isinstance(value, str) and "{extracted_id}" in value:
                        arguments[key] = value.replace("{extracted_id}", extracted_id)

        # Call MCP verify tool
        verify_result = await mcp_client.call_tool(
            _MCPToolCall(name=self.verify_tool, arguments=arguments)
        )

        resource_found = not verify_result.is_error
        result_text = self._extract_text(verify_result.content) if resource_found else ""

        if self.expect_exists:
            if resource_found and result_text:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Resource verified via {self.verify_tool}",
                    details={"verify_result": result_text[:500]},
                )
            else:
                error_msg = (
                    verify_result.error_message if verify_result.is_error else "Empty result"
                )
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"Resource not found via {self.verify_tool}: {error_msg}",
                    details={"error": error_msg},
                )
        else:
            # expect_exists=False: resource should NOT be found
            if verify_result.is_error or not result_text:
                return EvalResult(
                    passed=True,
                    score=1.0,
                    reason=f"Resource correctly not found via {self.verify_tool}",
                )
            else:
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason=f"Resource still exists (expected deletion) via {self.verify_tool}",
                    details={"verify_result": result_text[:500]},
                )

    def _extract_id(self, context: dict[str, Any]) -> str | None:
        """Extract resource ID from context using extract_pattern."""
        # Determine source text
        if self.extract_from == "tool_result":
            source_parts = []
            for tr in context.get("tool_results", []):
                if isinstance(tr, dict):
                    source_parts.append(str(tr.get("content", tr.get("result", ""))))
                elif hasattr(tr, "content"):
                    source_parts.append(self._extract_text(tr.content))
            source = "\n".join(source_parts)
        elif self.extract_from == "response":
            source = context.get("response", "")
        else:
            source = context.get("response", "")

        if not source or not self.extract_pattern:
            return None

        match = re.search(self.extract_pattern, source)
        if match:
            # Return first capture group or full match
            return match.group(1) if match.groups() else match.group(0)
        return None

    def _extract_text(self, content: Any) -> str:
        """Extract text from various content types."""
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for item in content:
                if hasattr(item, "text"):
                    parts.append(item.text)
                else:
                    parts.append(str(item))
            return "\n".join(parts)
        if hasattr(content, "text"):
            return content.text
        return str(content)


class UnnecessaryToolCalls(BaseEvaluator):
    """Detect duplicate or unnecessary tool calls that waste tokens/cost.

    Flags when the same tool is called multiple times with identical arguments,
    which indicates the LLM is making redundant API calls. This is a common
    issue that significantly increases costs (e.g., calling get_dashboard_info
    3 times with the same ID).
    """

    def __init__(
        self,
        max_duplicates: int = 1,
        check_args: bool = True,
        ignore_tools: list[str] | None = None,
    ):
        """
        Args:
            max_duplicates: Max times the same call (tool+args) is allowed (default 1)
            check_args: If True, same tool with different args is OK. If False,
                        any repeat of the same tool name counts as duplicate.
            ignore_tools: Tool names to skip when checking for duplicates
                         (e.g., search_tools is often called multiple times legitimately)
        """
        self.max_duplicates = max_duplicates
        self.check_args = check_args
        self.ignore_tools = set(ignore_tools or [])

    @property
    def name(self) -> str:
        return "unnecessary_tool_calls"

    @property
    def description(self) -> str:
        return f"Checks for duplicate tool calls (max {self.max_duplicates} per unique call)"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        tool_calls = context.get("tool_calls", [])
        if not tool_calls:
            return EvalResult(passed=True, score=1.0, reason="No tool calls to check")

        # Group calls by signature
        call_counts: dict[str, int] = {}
        for tc in tool_calls:
            tool_name = tc.get("name", "")
            if tool_name in self.ignore_tools:
                continue

            if self.check_args:
                # Canonical serialization for stable duplicate detection
                args = tc.get("arguments", {})
                try:
                    args_key = json.dumps(args, sort_keys=True, default=str)
                except (TypeError, ValueError):
                    args_key = str(args)
                sig = f"{tool_name}({args_key})"
            else:
                sig = tool_name

            call_counts[sig] = call_counts.get(sig, 0) + 1

        # Find duplicates
        duplicates = {
            sig: count for sig, count in call_counts.items() if count > self.max_duplicates
        }

        if not duplicates:
            return EvalResult(
                passed=True,
                score=1.0,
                reason="No unnecessary duplicate tool calls",
                details={"unique_calls": len(call_counts), "total_calls": len(tool_calls)},
            )

        total_excess = sum(count - self.max_duplicates for count in duplicates.values())
        total_calls = len(tool_calls)
        score = max(0.0, 1.0 - (total_excess / total_calls))

        # Truncate signatures in reason to avoid leaking large args
        short_sigs = []
        for sig, count in duplicates.items():
            if len(sig) > 80:
                sig = sig[:77] + "..."
            short_sigs.append(f"{sig} ({count}x)")

        return EvalResult(
            passed=False,
            score=score,
            reason=f"Found {len(duplicates)} duplicate tool call pattern(s): "
            + ", ".join(short_sigs),
            details={
                "duplicates": duplicates,
                "total_excess_calls": total_excess,
                "total_calls": total_calls,
            },
        )


# Factory function for creating evaluators


def create_evaluator(name: str, **kwargs) -> BaseEvaluator:
    """
    Factory function to create evaluators by name.

    Args:
        name: Name of the evaluator to create
        **kwargs: Arguments to pass to the evaluator constructor

    Returns:
        Instance of the requested evaluator

    Raises:
        ValueError: If evaluator name is unknown
    """
    # Import auth evaluators here to avoid circular imports
    from testmcpy.evals.auth_evaluators import (
        AuthErrorHandlingEvaluator,
        AuthSuccessfulEvaluator,
        JWTClaimsValidEvaluator,
        OAuth2FlowEvaluator,
        OAuthDiscoveryEvaluator,
        TokenValidEvaluator,
    )

    evaluators = {
        # Basic evaluators
        "was_mcp_tool_called": WasMCPToolCalled,
        "execution_successful": ExecutionSuccessful,
        "final_answer_contains": FinalAnswerContains,
        "response_includes": ResponseIncludes,  # More intuitive name
        "no_hallucination": NoHallucination,
        "llm_judge": LLMJudge,  # LLM-as-judge evaluator
        "answer_contains_link": AnswerContainsLink,
        "within_time_limit": WithinTimeLimit,
        "token_usage_reasonable": TokenUsageReasonable,
        # Parameter validation evaluators
        "tool_called_with_parameter": ToolCalledWithParameter,
        "tool_called_with_parameters": ToolCalledWithParameters,
        "parameter_value_in_range": ParameterValueInRange,
        "tool_call_count": ToolCallCount,
        "tool_call_sequence": ToolCallSequence,
        # Chart creation evaluators
        "was_chart_created": WasChartCreated,
        "was_superset_chart_created": WasChartCreated,  # Backward compatibility alias
        "sql_query_valid": SQLQueryValid,
        # Security & validation evaluators
        "response_not_includes": ResponseNotIncludes,
        "response_matches_pattern": ResponseMatchesPattern,
        "url_is_valid": UrlIsValid,
        "no_leaked_data": NoLeakedData,
        # Auth evaluators
        "auth_successful": AuthSuccessfulEvaluator,
        "token_valid": TokenValidEvaluator,
        "oauth2_flow_complete": OAuth2FlowEvaluator,
        "auth_error_handling": AuthErrorHandlingEvaluator,
        "jwt_claims_valid": JWTClaimsValidEvaluator,
        "oauth_discovery_valid": OAuthDiscoveryEvaluator,
        # Load/burst test aggregate evaluators
        "success_rate_above": SuccessRateAbove,
        "latency_percentile": LatencyPercentile,
        # MCP-aware deterministic evaluators
        "mcp_tool_result_matches": MCPToolResultMatches,
        "mcp_verify_response_data": MCPVerifyResponseData,
        "mcp_verify_side_effect": MCPVerifySideEffect,
        # Cost optimization evaluators
        "unnecessary_tool_calls": UnnecessaryToolCalls,
    }

    if name not in evaluators:
        raise ValueError(f"Unknown evaluator: {name}")

    return evaluators[name](**kwargs)
