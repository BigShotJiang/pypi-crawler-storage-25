#  Copyright (c) 2022 - 2025 D-BSSE, ETH Zurich.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from pathlib import Path
from typing import Union

import numpy as np

from pyminflux.processor import MinFluxProcessor


class MinFluxWriter:
    __docs__ = "Writer of (filtered) MINFLUX data to either `.npy` or `.csv` formats."

    @staticmethod
    def write_npy(processor: MinFluxProcessor, file_name: Union[Path, str]) -> bool:
        """Write (filtered) data as a NumPy structured array with the same structure as in the Imspector `.npy` file."""

        # Get the raw data
        filtered_array = processor.filtered_raw_data_array
        if filtered_array is None:
            return False

        # Save the filtered structured NumPy array to disk
        try:
            np.save(str(file_name), filtered_array)
        except Exception as e:
            print(f"Could not save {file_name}: {e}")
            return False

        return True

    @staticmethod
    def write_csv(processor: MinFluxProcessor, file_name: Union[Path, str]) -> bool:
        """Write (filtered) data as a comma-separated-value `.csv` file."""

        # Save the filtered dataframe to disk
        try:
            # Prepare header comment with fluorophore names
            header_lines = []
            fluorophore_names = processor.fluorophore_names
            if fluorophore_names:
                # Only include header comments when names are custom (not default "<id>")
                has_custom_names = any(
                    name != str(fluo_id) for fluo_id, name in fluorophore_names.items()
                )
                if has_custom_names:
                    header_lines.append("# Fluorophore Names:")
                    for fluo_id in sorted(fluorophore_names.keys()):
                        name = fluorophore_names[fluo_id]
                        header_lines.append(f"# fluo_{fluo_id}={name}")

            tid_offsets = getattr(processor.dataset, "tid_offsets", [])
            if tid_offsets:
                header_lines.append("# TID Offsets (first_iid -> tid_offset):")
                for first_iid, tid_offset in sorted(tid_offsets, key=lambda x: x[0]):
                    header_lines.append(f"# iid>={first_iid} : +{tid_offset}")
            
            # Write header and data
            with open(file_name, 'w') as f:
                # Write header comments
                if header_lines:
                    f.write('\n'.join(header_lines) + '\n')
                
                # Write the dataframe
                processor.filtered_dataframe.to_csv(f, index=False)
                
        except Exception as e:
            print(f"Could not save {file_name}: {e}")
            return False

        return True
