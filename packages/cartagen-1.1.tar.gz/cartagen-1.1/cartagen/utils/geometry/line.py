import numpy as np
import shapely
import heapq
import geopandas as gpd
from shapely.ops import split, nearest_points, snap, transform
from shapely.geometry import LineString, Point, Polygon, MultiPoint, MultiLineString, MultiPolygon

from cartagen.utils.geometry.angle import angle_3_pts
from cartagen.utils.partitioning import partition_grid

def get_bend_side(line):
    """
    Return the side of the interior of the bend.

    Parameters
    ----------
    line : LineString
        The line to get the bend side from.

    Returns
    -------
    side : str
        'right' or 'left'

    Examples
    --------
    >>> line = LineString([(0, 0), (1, 1), (2, 0)])
    >>> get_bend_side(line)
    right
    """
    coords = list(line.coords)
    
    if len(coords) < 3:
        return 'left'
    
    first = Point(coords[0])
    angle_sum = 0.0
    
    for i in range(1, len(coords) - 1):
        point1 = Point(coords[i])
        point2 = Point(coords[i + 1])
        
        # Calculate angle using three points
        # Vector from first to point1
        v1 = np.array([point1.x - first.x, point1.y - first.y])
        # Vector from first to point2
        v2 = np.array([point2.x - first.x, point2.y - first.y])
        
        # Calculate angle
        angle_value = np.arctan2(v2[1], v2[0]) - np.arctan2(v1[1], v1[0])
        
        # Normalize to [-pi, pi]
        if angle_value > np.pi:
            angle_value = angle_value - 2 * np.pi
        
        angle_sum += angle_value
    
    return 'right' if angle_sum < 0.0 else 'left'

def get_shortest_edge_length(geom):
    min_length = float('inf')
    segments = get_linestring_segments(geom)
    for segment in segments:
        length = Point(segment[0]).distance(Point(segment[1]))
        if(length < min_length):
            min_length = length

    return min_length

def get_linestring_segments(line):
    segments = []
    prev_coord = line.coords[0]
    for coord in line.coords[1:]:
        segments.append((prev_coord,coord))
        prev_coord = coord

    return segments


# for a 3d sequence of coordinates, returns the 2d sequence. Useful to convert 3d points to 2d points
def to_2d(x, y, z):
    return tuple(filter(None, [x, y]))


# for an array of 3d sequences of coordinates, returns an array containing the 2d sequences. Useful to convert 3d geometries to 2d geometries
def array_to_2d(array):
    array_2d = []
    for tuple in array:
        array_2d.append(to_2d(tuple[0],tuple[1],tuple[2]))
    return array_2d

def polygons_3d_to_2d(polygons):
    polygons_2d = []
    for polygon in polygons:
        # outer ring
        coords_2d = array_to_2d(polygon.exterior.coords)
        # inner rings
        interiors = []
        for interior in polygon.interiors:
            interiors.append(array_to_2d(interior.coords))
        polygons_2d.append(Polygon(coords_2d,interiors))
    return polygons_2d

def resample_line(line, step, keep_vertices=False):
    """
    Densify a line by adding vertices.

    This function densifies a line by adding a vertex every 'step' along the line.
    It preserves the first and last vertex of the line.
    
    Parameters
    ----------
    line : LineString
        The line to densify.
    step : float
        The step (in meters) to resample the geometry.
    keep_vertices : bool, optional
        If set to true, original vertices of the line are kept.
        This is useful to keep the exact same geographical shape.

    Returns
    -------
    LineString

    Examples
    --------
    >>> line = LineString([(1, 1), (5, 1)])
    >>> resample_line(line, 1)
    <LINESTRING (1 1, 2 1, 3 1, 4 1, 5 1)>
    """

    coords = list(line.coords)
    original = []

    if keep_vertices:
        for i in range(1, len(coords) - 1):
            c = coords[i]
            d = shapely.line_locate_point(line, shapely.Point(c))
            original.append((c, d))
    
    # Get the length of the line
    length = line.length 
    
    # Storage for final vertices, starting with the start of the line
    xy = [(line.coords[0])]
    
    for distance in np.arange(step, int(length), step):
        if keep_vertices:
            remove = 0
            for i, o in enumerate(original):
                if o[1] < distance:
                    xy.append(o[0])
                    remove += 1
            for r in range(0, remove):
                original.pop(0)

        # Interpolate a point every step along the old line
        point = line.interpolate(distance)
        # Add the tuple of coordinates
        xy.append((point.x, point.y))
    
    # Add the last point of the line if it doesn't already exist
    if xy[-1] != line.coords[-1]:
        xy.append(line.coords[-1])
        
    # Here, we return a new line with densified points.
    return LineString(xy)

# returns the index of a vertex in a line. Returns -1 if the point given is not a vertex of the line
def get_index_of_vertex(line, vertex, tolerance = 0.01):
    for i in range(0, len(line.coords)):
        point = Point(line.coords[i])
        if point.equals_exact(vertex, tolerance):
            return i
    return -1

# returns the index of the nearest vertex in a line. Returns -1 if the point given is not a vertex of the line
def get_index_of_nearest_vertex(line, vertex):
    mindist = float("inf")
    nearest_index = -1
    for i in range(0, len(line.coords)):
        point = Point(line.coords[i])
        dist = point.distance(vertex)
        if dist < mindist:
            nearest_index = i
            mindist = dist
    return nearest_index

def geometry_flatten(geom):
    if hasattr(geom, 'geoms'):  # Multi<Type> / GeometryCollection
        for g in geom.geoms:
            yield from geometry_flatten(g)
    elif hasattr(geom, 'interiors'):  # Polygon
        yield geom.exterior
        yield from geom.interiors
    else:  # Point / LineString
        yield geom

def geometry_len(geom):
    return sum(len(g.coords) for g in geometry_flatten(geom))

# Gets the nearest point of the geometry to a point. If the point is a vertex, it is not chosen.
def get_nearest_vertex(geometry, point):
    min_dist = float('inf')
    nearest = None

    for vertex in geometry.coords:
        vertex_pt = Point(vertex)
        distance = vertex_pt.distance(point)
        if distance == 0:
            continue
        if distance < min_dist:
            min_dist = distance
            nearest = vertex_pt
    
    return nearest

def extend_line_with_point(line, point, position='start'):
    """
    Extend the line with a given point, depending on the position, adds it at the start or the end
    """
    new_line = []
    p = [point.x, point.y]

    if position == 'start':
        new_line.append(p)

    for n in line.coords:
        new_line.append(n)

    if position == 'end':
        new_line.append(p)

    return LineString(new_line)

def extend_line_by_length(line, length, position='both'):
    """
    Extend the line by a given length.
    This function extend the line by adding a vertice at the start and/or the end of the line and extend it by a given length
    following the direction of the first and/or last segment of the line.
    Position is by default set to 'both' which will add the length to both
    the start and the end of the line. Can be set to 'start' or 'end'.
    """

    def __calculate_coords(a, b, length):
        xa, ya, xb, yb = a[0], a[1], b[0], b[1]
        ab = np.sqrt((yb - ya)**2 + (xb -xa)**2)
        xc = xb - (((xb - xa) / ab) * (ab + length))
        yc = yb - (((yb - ya) / ab) * (ab + length))
        return (xc, yc)

    # Get the list of vertex
    vertex = list(line.coords)

    new_line = []

    if position == 'both' or position == 'start':
        new_line.append(__calculate_coords(vertex[0], vertex[1], length))

    new_line.extend(vertex)

    if position == 'both' or position == 'end':
        new_line.append(__calculate_coords(vertex[-1], vertex[-2], length))

    return LineString(new_line)

def get_line_middle_point(line):
    """
    Return the point located along the line at half its length.
    """
    return line.interpolate(line.length / 2)

def get_segment_center(segment):
    """
    Return the center of the given shapely segment (a linestring with only two vertices) as a shapely Point.
    """
    c = segment.coords

    if len(c) > 2:
        raise Exception("The provided segment has more than two vertices.")

    x1, y1, x2, y2 = c[0][0], c[0][1], c[1][0], c[1][1]
    return shapely.Point([(x1 + x2) / 2, (y1 + y2) / 2])

def merge_linestrings(line1, line2):
    """
    Merge two linestring that are connected by their start or end points.
    Return the new linestring. The first line defines the direction of the merged linestring.
    """
    coords1, coords2 = line1.coords, line2.coords

    start1, end1 = coords1[0], coords1[-1]
    start2, end2 = coords2[0], coords2[-1]
    
    # Lines connected by...
    # ...start and start...
    if start1 == start2:
        # Reverse the second line, and concatenate the first (drop the start)
        return shapely.LineString(list(coords2[::-1]) + list(coords1[1:]))
    # ...start and end...
    elif start1 == end2:
        # Concatenate the second and the first line (drop the start)
        return shapely.LineString(list(coords2) + list(coords1[1:]))
    # ...end and start...
    elif end1 == start2:
        # Concatenate the first and the second line (drop the start)
        return shapely.LineString(list(coords1) + list(coords2[1:]))
    # ...end and end
    elif end1 == end2:
        # Reverse the second line (drop the start) and add it to the first line
        return shapely.LineString(list(coords1) + list(coords2[::-1][1:]))
    # Here, linstrings are not connected
    else:
        raise Exception("Provided LineStrings are not connected by their start or end vertex.")

def inflexion_points(line, min_dir=120.0):
    """
    Detect inflexion points inside a curved line.

    This algorithm extract inflexion points from a line using
    angles calculation. Micro inflexions are removed.

    Parameters
    ----------
    line : LineString
        The line to extract the inflexion points from.
    min_dir : float, optional
        The minimum direction change (in degrees) between two consecutive inflexion points.
        This parameter allows to remove micro inflexions from the results. If set to 0,
        every micro-inflexions will be kept.

    Returns
    -------
    list of int
        A list of index of the line vertices considered to be inflexion points
    
    Examples
    --------
    >>> line = LineString([(0, 0), (1, 1), (2, 0), (5, 3), (8, 5)])
    >>> c4.inflexion_points(line)
    [2, 3]
    """
    coords = np.array(line.coords)
    n = len(coords)

    # Early return for lines too short
    if n < 3:
        return []
    
    # Vectorized computation of all angles
    vectors = np.diff(coords, axis=0)
    angles = np.arctan2(vectors[:, 1], vectors[:, 0])
    directions = np.degrees(angles) % 360
    
    # Calculate turning angles at each interior vertex
    # alpha[i] represents the turn at vertex i+1
    alpha = np.diff(angles)
    
    # Normalize to [-π, π]
    alpha = np.where(alpha > np.pi, alpha - 2 * np.pi, alpha)
    alpha = np.where(alpha < -np.pi, alpha + 2 * np.pi, alpha)
    
    # Determine turn direction at each interior vertex
    turn_signs = np.sign(alpha)  # 1 for left, -1 for right, 0 for straight
    
    # Find where turn direction changes (potential inflexion points)
    sign_changes = np.diff(turn_signs) != 0
    
    # Get indices of potential inflexion points (offset by 1 for interior vertices)
    potential_inflexions = np.where(sign_changes)[0] + 1
    
    if len(potential_inflexions) == 0:
        return []
    
    # Filter out micro-inflexions
    inflexion = []
    part = [potential_inflexions[0]]
    prevdir = directions[potential_inflexions[0] - 1]
    
    for idx in potential_inflexions[1:]:
        direction = directions[idx - 1]
        
        # Calculate direction change with wraparound handling
        dir_change = abs(prevdir - direction)
        if dir_change > 180:
            dir_change = 360 - dir_change
        
        if dir_change > min_dir:
            # Significant inflexion
            if part:
                inflexion.append(part[len(part) // 2])
            part = [idx]
            prevdir = direction
        else:
            # Micro-inflexion
            part.append(idx)
    
    # Add the last part's middle point
    if part:
        inflexion.append(part[len(part) // 2])
    
    return inflexion

def split_line_at_vertex(line, point):
    """
    Divide a line at one of its vertex.

    Parameters
    ----------
    line : LineString
        The line to divide
    point : Point or tuple (x, y)
        A point, it must be one of the line's vertex

    Returns
    -------
    list of LineString
        Liste de 2 segments (ou [line] si le point est aux extrémités)
    """
    # Convertir en tuple si c'est un Point
    if isinstance(point, Point):
        point_coords = point.coords[0]
    else:
        point_coords = point
    
    coords = list(line.coords)

    if point_coords not in coords:
        raise Exception('Provided point is not a vertex of the line.')
    
    # Find the vertex index
    idx = coords.index(point_coords)
    
    # If first or last, return the same line
    if idx == 0 or idx == len(coords) - 1:
        return [line]
    
    # Divide in two parts
    first_part = LineString(coords[:idx+1])
    second_part = LineString(coords[idx:])
    
    return [first_part, second_part]