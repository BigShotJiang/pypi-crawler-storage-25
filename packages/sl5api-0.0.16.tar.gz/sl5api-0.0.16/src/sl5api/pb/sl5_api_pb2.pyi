import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AlarmStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NORMAL: _ClassVar[AlarmStatus]
    LO: _ClassVar[AlarmStatus]
    HI: _ClassVar[AlarmStatus]
    DISCRETE_ON: _ClassVar[AlarmStatus]
    DISCRETE_OFF: _ClassVar[AlarmStatus]
    HI_HI: _ClassVar[AlarmStatus]
    LO_LO: _ClassVar[AlarmStatus]
    BAD_QUALITY: _ClassVar[AlarmStatus]
NORMAL: AlarmStatus
LO: AlarmStatus
HI: AlarmStatus
DISCRETE_ON: AlarmStatus
DISCRETE_OFF: AlarmStatus
HI_HI: AlarmStatus
LO_LO: AlarmStatus
BAD_QUALITY: AlarmStatus

class TagReadManyRequest(_message.Message):
    __slots__ = ("names",)
    NAMES_FIELD_NUMBER: _ClassVar[int]
    names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, names: _Optional[_Iterable[str]] = ...) -> None: ...

class TagReadManyResponse(_message.Message):
    __slots__ = ("tags",)
    TAGS_FIELD_NUMBER: _ClassVar[int]
    tags: _containers.RepeatedCompositeFieldContainer[Tag]
    def __init__(self, tags: _Optional[_Iterable[_Union[Tag, _Mapping]]] = ...) -> None: ...

class Tag(_message.Message):
    __slots__ = ("tag_id", "name", "value", "quality", "high_scale", "low_scale", "lo_lo_alarm", "lo_alarm", "hi_alarm", "hi_hi_alarm", "alarm_status")
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    HIGH_SCALE_FIELD_NUMBER: _ClassVar[int]
    LOW_SCALE_FIELD_NUMBER: _ClassVar[int]
    LO_LO_ALARM_FIELD_NUMBER: _ClassVar[int]
    LO_ALARM_FIELD_NUMBER: _ClassVar[int]
    HI_ALARM_FIELD_NUMBER: _ClassVar[int]
    HI_HI_ALARM_FIELD_NUMBER: _ClassVar[int]
    ALARM_STATUS_FIELD_NUMBER: _ClassVar[int]
    tag_id: int
    name: str
    value: SLValue
    quality: int
    high_scale: float
    low_scale: float
    lo_lo_alarm: float
    lo_alarm: float
    hi_alarm: float
    hi_hi_alarm: float
    alarm_status: AlarmStatus
    def __init__(self, tag_id: _Optional[int] = ..., name: _Optional[str] = ..., value: _Optional[_Union[SLValue, _Mapping]] = ..., quality: _Optional[int] = ..., high_scale: _Optional[float] = ..., low_scale: _Optional[float] = ..., lo_lo_alarm: _Optional[float] = ..., lo_alarm: _Optional[float] = ..., hi_alarm: _Optional[float] = ..., hi_hi_alarm: _Optional[float] = ..., alarm_status: _Optional[_Union[AlarmStatus, str]] = ...) -> None: ...

class TagReadValueRequest(_message.Message):
    __slots__ = ("names",)
    NAMES_FIELD_NUMBER: _ClassVar[int]
    names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, names: _Optional[_Iterable[str]] = ...) -> None: ...

class TagReadValueResponse(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedCompositeFieldContainer[SLValue]
    def __init__(self, values: _Optional[_Iterable[_Union[SLValue, _Mapping]]] = ...) -> None: ...

class SLValue(_message.Message):
    __slots__ = ("double_value", "string_value", "bool_value", "int32_value", "int64_value", "uint32_value", "uint64_value", "time_value")
    DOUBLE_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    BOOL_VALUE_FIELD_NUMBER: _ClassVar[int]
    INT32_VALUE_FIELD_NUMBER: _ClassVar[int]
    INT64_VALUE_FIELD_NUMBER: _ClassVar[int]
    UINT32_VALUE_FIELD_NUMBER: _ClassVar[int]
    UINT64_VALUE_FIELD_NUMBER: _ClassVar[int]
    TIME_VALUE_FIELD_NUMBER: _ClassVar[int]
    double_value: float
    string_value: str
    bool_value: bool
    int32_value: int
    int64_value: int
    uint32_value: int
    uint64_value: int
    time_value: _timestamp_pb2.Timestamp
    def __init__(self, double_value: _Optional[float] = ..., string_value: _Optional[str] = ..., bool_value: bool = ..., int32_value: _Optional[int] = ..., int64_value: _Optional[int] = ..., uint32_value: _Optional[int] = ..., uint64_value: _Optional[int] = ..., time_value: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TagWriteValueRequest(_message.Message):
    __slots__ = ("wvs",)
    WVS_FIELD_NUMBER: _ClassVar[int]
    wvs: _containers.RepeatedCompositeFieldContainer[WriteValue]
    def __init__(self, wvs: _Optional[_Iterable[_Union[WriteValue, _Mapping]]] = ...) -> None: ...

class WriteValue(_message.Message):
    __slots__ = ("tag_name", "value", "quality")
    TAG_NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    tag_name: str
    value: SLValue
    quality: int
    def __init__(self, tag_name: _Optional[str] = ..., value: _Optional[_Union[SLValue, _Mapping]] = ..., quality: _Optional[int] = ...) -> None: ...

class TagWriteValueResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MomentGetOptions(_message.Message):
    __slots__ = ("tag_name", "start", "end")
    TAG_NAME_FIELD_NUMBER: _ClassVar[int]
    START_FIELD_NUMBER: _ClassVar[int]
    END_FIELD_NUMBER: _ClassVar[int]
    tag_name: str
    start: _timestamp_pb2.Timestamp
    end: _timestamp_pb2.Timestamp
    def __init__(self, tag_name: _Optional[str] = ..., start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class MomentGetRangeResponse(_message.Message):
    __slots__ = ("moments",)
    MOMENTS_FIELD_NUMBER: _ClassVar[int]
    moments: _containers.RepeatedCompositeFieldContainer[Moment]
    def __init__(self, moments: _Optional[_Iterable[_Union[Moment, _Mapping]]] = ...) -> None: ...

class Moment(_message.Message):
    __slots__ = ("time", "quality", "value")
    TIME_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    time: _timestamp_pb2.Timestamp
    quality: int
    value: SLValue
    def __init__(self, time: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., quality: _Optional[int] = ..., value: _Optional[_Union[SLValue, _Mapping]] = ...) -> None: ...
