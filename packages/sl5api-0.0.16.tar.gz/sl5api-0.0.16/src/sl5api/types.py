from typing import Any
from dataclasses import dataclass
from datetime import datetime
from .pb import sl5_api_pb2

AlarmStatus = sl5_api_pb2.AlarmStatus

class Tag:
  tag_id: int
  name: str
  value: Any
  quality: int
  high_scale: float
  low_scale: float
  lo_lo_alarm: float
  lo_alarm: float
  hi_alarm: float
  hi_hi_alarm: float
  alarm_status: AlarmStatus

  def __init__(self):
    pass

class Moment:
  time: datetime
  quality: int
  value: Any

  def __init__(self):
    pass

@dataclass
class MomentGetOptions:
  tag_name: str
  start: datetime
  end: datetime