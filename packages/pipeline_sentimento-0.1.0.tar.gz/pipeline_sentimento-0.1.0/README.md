# sentiment-pipeline

Pipeline configurável de análise de sentimentos em Python.

## Instalação

```bash
pip install sentiment-pipeline
```

## Uso rápido

```python
from sentiment_pipeline.pipeline import Pipeline

config_pre = {
    "lowercase": True,
    "remove_urls": True,
    "normalize_emojis": True,
    "handle_negations": False,
    "remove_stopwords": "keep_negations",
    "normalization": "stemming"
}

config_vet = {
    "estrategia": "tfidf",
    "max_features": 10000,
    "ngram_range": (1, 2),
    "sublinear_tf": True,
}

pipeline = Pipeline(config_pre, config_vet)
pipeline.carregar_dados("dataset.csv", "text", "label")
pipeline.treinar()
pipeline.avaliar_validacao()
```

## Interface web

```bash
streamlit run app.py
```