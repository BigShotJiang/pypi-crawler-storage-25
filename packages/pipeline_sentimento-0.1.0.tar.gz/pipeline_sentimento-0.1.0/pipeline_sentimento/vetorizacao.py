# numpy é uma biblioteca de matemática, usamos ela para calcular a média dos vetores no Word2Vec.
import numpy as np

# CountVectorizer implementa o BoW, conta quantas vezes cada palavra aparece.
# TfidfVectorizer implementa o TF-IDF, parecido com BoW mas mais inteligente.
# Ambos já vêm prontos no scikit-learn, não precisamos implementar nada.
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# TruncatedSVD comprime vetores grandes em vetores menores.
# Exemplo: um vetor de 10000 números vira um de 100.
from sklearn.decomposition import TruncatedSVD

# Word2Vec transforma palavras em vetores numéricos que representam significado.
# Palavras parecidas ficam próximas no espaço vetorial.
from gensim.models import Word2Vec


class Vetorizacao:

    # Quando cria um objeto Vetorizacao, esse método roda automaticamente.
    # Ele recebe o dicionário de configuração e reserva espaço para o modelo.
    def __init__(self, config):

        # Guarda o dicionário de configuração para usar nos outros métodos.
        self.config = config

        # Reserva espaço para o vetorizador, começa vazio porque ainda não foi treinado.
        # Vai receber o CountVectorizer, TfidfVectorizer ou Word2Vec dependendo da estratégia.
        self.modelo = None

        # Reserva espaço para o SVD — só é preenchido na estratégia "tfidf_svd".
        self.svd = None

    # "fit" aprende o vocabulário olhando os textos de treino.
    # IMPORTANTE: só deve ser chamado com dados de treino, nunca com teste.
    def fit(self, textos):

        # Lê qual estratégia o usuário escolheu no dicionário.
        estrategia = self.config.get("estrategia")

        # ESTRATÉGIA BOW 
        # Cria uma coluna para cada palavra do vocabulário.
        # Cada texto vira uma linha com a contagem de cada palavra. Exemplo: "não gostei" → [0, 0, 1, 0, 1, ...] (1 nas colunas de "não" e "gostei")
        if estrategia == "bow":
            self.modelo = CountVectorizer(

                # binary=True, marca 1 se a palavra apareceu, 0 se não.
                # binary=False, conta quantas vezes apareceu.
                # Se não definido no config, usa False como padrão.
                binary=self.config.get("binary", False),

                # Limita o vocabulário às N palavras mais frequentes.
                # Sem isso, um corpus grande pode ter 100000 palavras — muito pesado.
                max_features=self.config.get("max_features", 10000)
            )

            # Aprende o vocabulário olhando todos os textos.
            self.modelo.fit(textos)

        # ESTRATÉGIA TF-IDF 
        # Parecido com BoW, mas penaliza palavras que aparecem em muitos textos.
        # Uma palavra que aparece em todo texto não é informativa. Exemplo: "o", "a", "de" aparecem em todo lugar — TF-IDF diminui o peso delas.
        elif estrategia == "tfidf":
            self.modelo = TfidfVectorizer(

                # sublinear_tf=True aplica logaritmo na contagem.
                # Evita que uma palavra que aparece 100x valha 100x mais que uma que aparece 1x.
                sublinear_tf=self.config.get("sublinear_tf", True),

                # ngram_range define se considera palavras sozinhas ou em pares.
                # (1,1) → só palavras sozinhas: "não", "gostei"
                # (1,2) → palavras sozinhas e pares: "não", "gostei", "não gostei"
                # Pares capturam contexto que palavras sozinhas perdem.
                ngram_range=self.config.get("ngram_range", (1, 1)),

                # Limita o vocabulário igual ao BoW.
                max_features=self.config.get("max_features", 10000),

                # norm="l2" normaliza o vetor para que textos longos e curtos
                # tenham o mesmo peso. Sem isso, textos maiores dominam.
                norm=self.config.get("norm", "l2")
            )
            self.modelo.fit(textos)

        # ESTRATÉGIA TF-IDF + SVD 
        # Primeiro aplica TF-IDF normalmente.
        # Depois comprime as dimensões com SVD.
        # Por quê comprimir? Menos dimensões = mais rápido e menos ruído.
        elif estrategia == "tfidf_svd":
            self.modelo = TfidfVectorizer(
                sublinear_tf=self.config.get("sublinear_tf", True),
                max_features=self.config.get("max_features", 10000)
            )
            self.modelo.fit(textos)

            # TruncatedSVD aprende como comprimir os vetores.
            # n_components=100 significa que cada texto vai virar um vetor de 100 números.
            self.svd = TruncatedSVD(n_components=self.config.get("dimensoes_svd", 100))

            # O SVD precisa ver os vetores TF-IDF para aprender a comprimir.
            # Por isso chamamos transform aqui dentro do fit.
            self.svd.fit(self.modelo.transform(textos))

        # ESTRATÉGIA WORD2VEC 
        # Cada palavra vira um vetor de números que representa seu significado.
        # Palavras usadas em contextos parecidos ficam próximas.
        # Exemplo: "ódio" e "raiva" ficam próximas. "ódio" e "feliz" ficam longe.
        elif estrategia == "word2vec":

            # O Word2Vec precisa de listas de palavras, não de strings.
            # texto.split() divide "não gostei" em ["não", "gostei"].
            # Fazemos isso para cada texto do corpus.
            tokens = [texto.split() for texto in textos]

            self.modelo = Word2Vec(
                sentences=tokens,

                # Cada palavra vira um vetor de 100 números.
                vector_size=self.config.get("vector_size", 100),

                # Aprende o significado de uma palavra olhando as 5 palavras ao redor.
                # "não gostei do produto" → para aprender "gostei", olha "não" e "do".
                window=5,

                # Ignora palavras que aparecem menos de N vezes.
                # min_count=1 inclui todas as palavras.
                min_count=1,

                # Usa 4 núcleos do processador para treinar mais rápido.
                workers=4
            )

    # "transformar" converte os textos em vetores numéricos.
    # Usa o que foi aprendido no fit — por isso o fit precisa rodar antes.
    def transformar(self, textos):
        estrategia = self.config.get("estrategia")

        # BoW e TF-IDF usam o mesmo .transform() do scikit-learn.
        # Ele pega cada texto e conta as palavras usando o vocabulário aprendido.
        if estrategia in ("bow", "tfidf"):
            return self.modelo.transform(textos)

        # TF-IDF + SVD: primeiro converte com TF-IDF, depois comprime com SVD.
        elif estrategia == "tfidf_svd":
            matriz = self.modelo.transform(textos)
            return self.svd.transform(matriz)

        # Word2Vec: para cada texto, calcula a média dos vetores das palavras.
        # O resultado é um único vetor que representa o texto inteiro.
        elif estrategia == "word2vec":
            vetores = []

            for texto in textos:
                tokens = texto.split()

                # Filtra palavras que o modelo conhece.
                # Se uma palavra não foi vista no treino, ignora.
                tokens_validos = [t for t in tokens if t in self.modelo.wv]

                if tokens_validos:
                    # Calcula a média dos vetores de todas as palavras do texto.
                    # np.mean com axis=0 faz a média coluna por coluna.
                    vetor = np.mean([self.modelo.wv[t] for t in tokens_validos], axis=0)
                else:
                    # Se nenhuma palavra foi reconhecida, retorna um vetor de zeros.
                    vetor = np.zeros(self.config.get("vector_size", 100))

                vetores.append(vetor)

            # Converte a lista de vetores em uma matriz numpy.
            return np.array(vetores)