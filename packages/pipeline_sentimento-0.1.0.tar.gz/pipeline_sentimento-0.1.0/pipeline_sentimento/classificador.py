# Importa os dois tipos de Naive Bayes que vamos usar.
# Multinomial → funciona com contagens (BoW, TF-IDF).
# Bernoulli → funciona com valores binários (BoW com binary=True).
from sklearn.naive_bayes import MultinomialNB, BernoulliNB

# Regressão Logística — apesar do nome, é um classificador.
# Um dos melhores modelos para texto no geral.
from sklearn.linear_model import LogisticRegression

# LinearSVC — parecido com Regressão Logística mas mais rápido em datasets grandes.
from sklearn.svm import LinearSVC

# Random Forest — cria várias árvores de decisão e combina os resultados.
# Robusto mas mais lento que os anteriores.
from sklearn.ensemble import RandomForestClassifier

# GridSearchCV → testa todas as combinações de hiperparâmetros possíveis.
# RandomizedSearchCV → testa combinações aleatórias — mais rápido para espaços grandes.
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

# f1_score → métrica principal de avaliação do modelo.
# classification_report → relatório completo com precisão, recall e F1 por classe.
from sklearn.metrics import f1_score, classification_report

# LightGBM — algoritmo de gradient boosting muito eficiente.
import lightgbm as lgb


class Classificador:

    # Recebe um dicionário dizendo qual modelo usar e como configurar.
    # Exemplo manual:    {"modelo": "regressao_logistica", "C": 1.0}
    # Exemplo com busca: {"modelo": "regressao_logistica", "busca": "grid", "espaco": {"C": [0.1, 1, 10]}}
    def __init__(self, config):
        self.config = config

        # Reserva espaço para o modelo — preenchido depois do treino.
        self.modelo = None

    # Método interno que cria o objeto do modelo com os hiperparâmetros definidos.
    # O underscore no início indica que é interno — só o treinar usa ele.
    def _criar_modelo(self):
        nome = self.config.get("modelo")

        # Naive Bayes Multinomial.
        # alpha controla a suavização — evita probabilidade zero para palavras não vistas.
        # Se não definido, usa 1.0 como padrão.
        if nome == "naive_bayes_multinomial":
            return MultinomialNB(alpha=self.config.get("alpha", 1.0))

        # Naive Bayes Bernoulli — melhor quando o BoW é binário (0 ou 1).
        elif nome == "naive_bayes_bernoulli":
            return BernoulliNB(alpha=self.config.get("alpha", 1.0))

        # Regressão Logística.
        # C controla a regularização: valores menores = modelo mais simples e conservador.
        # max_iter=1000 garante que o modelo vai convergir em textos maiores.
        elif nome == "regressao_logistica":
            return LogisticRegression(
                C=self.config.get("C", 1.0),
                max_iter=1000
            )

        # LinearSVC — muito parecido com Regressão Logística.
        # Costuma ser mais rápido em datasets grandes.
        elif nome == "linear_svc":
            return LinearSVC(
                C=self.config.get("C", 1.0),
                max_iter=1000
            )

        # Random Forest — cria N árvores de decisão e vota na classe mais comum.
        # n_estimators define quantas árvores criar — mais árvores = mais preciso mas mais lento.
        # random_state=42 garante que o resultado é sempre igual ao rodar de novo.
        elif nome == "random_forest":
            return RandomForestClassifier(
                n_estimators=self.config.get("n_estimators", 100),
                random_state=42
            )

        # LightGBM — gradient boosting eficiente.
        # Constrói árvores em sequência, cada uma corrigindo o erro da anterior.
        elif nome == "lightgbm":
            return lgb.LGBMClassifier(
                n_estimators=self.config.get("n_estimators", 100),
                random_state=42
            )

    # Treina o modelo com os dados de treino.
    # X_treino → os textos vetorizados (números).
    # y_treino → os rótulos corretos (ex: 0 para não ódio, 1 para ódio).
    def treinar(self, X_treino, y_treino):
        modelo_base = self._criar_modelo()
        busca = self.config.get("busca")

        # Modo manual — usa os hiperparâmetros definidos no dicionário e treina direto.
        if not busca:
            self.modelo = modelo_base
            self.modelo.fit(X_treino, y_treino)

        # GridSearchCV — testa todas as combinações do espaço definido.
        # Bom para espaços pequenos onde testar tudo é viável.
        elif busca == "grid":
            grid = GridSearchCV(
                modelo_base,

                # "espaco" é o dicionário com os valores a testar.
                # Exemplo: {"C": [0.1, 1, 10]} testa 3 valores de C.
                param_grid=self.config.get("espaco"),

                # Avalia cada combinação pelo F1-macro.
                scoring="f1_macro",

                # cv=3 divide os dados em 3 partes e testa cada combinação 3 vezes.
                # Isso torna a avaliação mais confiável do que testar só uma vez.
                cv=3
            )
            grid.fit(X_treino, y_treino)

            # Guarda o modelo com os melhores parâmetros encontrados.
            self.modelo = grid.best_estimator_
            print(f"Melhores parâmetros: {grid.best_params_}")

        # RandomizedSearchCV — testa combinações aleatórias do espaço.
        # Bom para espaços grandes onde testar tudo seria muito demorado.
        elif busca == "random":
            rand = RandomizedSearchCV(
                modelo_base,
                param_distributions=self.config.get("espaco"),

                # n_iter define quantas combinações aleatórias testar.
                n_iter=self.config.get("n_iter", 20),
                scoring="f1_macro",
                cv=3,
                random_state=42
            )
            rand.fit(X_treino, y_treino)
            self.modelo = rand.best_estimator_
            print(f"Melhores parâmetros: {rand.best_params_}")

    # Avalia o modelo em qualquer conjunto de dados.
    # X → textos vetorizados. y → rótulos corretos.
    # Retorna o F1-macro e imprime o relatório completo.
    def avaliar(self, X, y):

        # Usa o modelo treinado para classificar os textos.
        predicoes = self.modelo.predict(X)

        # F1-macro trata todas as classes igualmente.
        # Importante para datasets desbalanceados como o HatEval.
        f1 = f1_score(y, predicoes, average="macro")

        # Imprime precisão, recall e F1 para cada classe separadamente.
        print(classification_report(y, predicoes))

        return f1