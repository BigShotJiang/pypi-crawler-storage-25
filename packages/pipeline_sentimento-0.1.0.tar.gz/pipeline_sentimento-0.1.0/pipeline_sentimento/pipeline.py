import pandas as pd
from sklearn.model_selection import train_test_split
from pipeline.pipeline_sentimento.preprocessamento import Preprocessamento
from pipeline.pipeline_sentimento.vetorizacao import Vetorizacao
from pipeline.pipeline_sentimento.classificador import Classificador
from .preprocessamento import Preprocessamento
from .vetorizacao import Vetorizacao
from .classificador import Classificador


# Escolhe automaticamente o melhor modelo baseado na vetorização escolhida.
# Cada vetorizador tem características diferentes que favorecem certos classificadores.
def sugerir_modelo(config_vet):

    estrategia = config_vet.get("estrategia")

    # BoW binário → Naive Bayes Bernoulli.
    # Bernoulli foi feito especificamente para dados binários (0 ou 1).
    if estrategia == "bow" and config_vet.get("binary", False):
        return {"modelo": "naive_bayes_bernoulli"}

    # BoW com contagem ou TF-IDF → Regressão Logística.
    # É o classificador mais robusto e consistente para texto.
    elif estrategia in ("bow", "tfidf"):
        return {"modelo": "regressao_logistica"}

    # TF-IDF + SVD → LinearSVC.
    # Após a redução de dimensões o SVC funciona muito bem.
    elif estrategia == "tfidf_svd":
        return {"modelo": "linear_svc"}

    # Word2Vec → LightGBM.
    # Vetores densos do Word2Vec funcionam melhor com gradient boosting.
    elif estrategia == "word2vec":
        return {"modelo": "lightgbm"}

    # Padrão seguro caso nenhuma opção acima seja encontrada.
    return {"modelo": "regressao_logistica"}


class Pipeline:

    def __init__(self, config_pre, config_vet):

        self.config_vet = config_vet

        # Escolhe o modelo automaticamente baseado na vetorização.
        config_clas = sugerir_modelo(config_vet)
        self.modelo_sugerido = config_clas["modelo"]

        # Cria os três objetos passando cada configuração.
        self.pre = Preprocessamento(config_pre)
        self.vet = Vetorizacao(config_vet)
        self.clas = Classificador(config_clas)

        self.X_treino = self.X_val = self.X_teste = None
        self.y_treino = self.y_val = self.y_teste = None
        self.X_treino_vet = self.X_val_vet = self.X_teste_vet = None

    def carregar_dados(self, caminho, coluna_texto, coluna_label):
        print("Carregando dados...")

        # Tenta ler como CSV — se tiver só uma coluna, tenta como TSV.
        try:
            df = pd.read_csv(caminho)
            if len(df.columns) == 1:
                df = pd.read_csv(caminho, sep='\t')
        except Exception:
            df = pd.read_csv(caminho, sep='\t')

        # Verifica se as colunas existem.
        if coluna_texto not in df.columns:
            raise ValueError(f"Coluna '{coluna_texto}' não encontrada. Disponíveis: {list(df.columns)}")
        if coluna_label not in df.columns:
            raise ValueError(f"Coluna '{coluna_label}' não encontrada. Disponíveis: {list(df.columns)}")

        # Remove linhas vazias.
        df = df[[coluna_texto, coluna_label]].dropna()

        X = df[coluna_texto].astype(str).tolist()
        y = df[coluna_label].tolist()

        print(f"Total de exemplos: {len(X)}")
        print(f"Classes encontradas: {set(y)}")

        # Divide com stratify — se falhar, divide sem.
        try:
            X_temp, self.X_teste, y_temp, self.y_teste = train_test_split(
                X, y, test_size=0.15, stratify=y, random_state=42
            )
            self.X_treino, self.X_val, self.y_treino, self.y_val = train_test_split(
                X_temp, y_temp, test_size=0.176, stratify=y_temp, random_state=42
            )
        except ValueError:
            print("Aviso: stratify desativado por distribuição desigual de classes.")
            X_temp, self.X_teste, y_temp, self.y_teste = train_test_split(
                X, y, test_size=0.15, random_state=42
            )
            self.X_treino, self.X_val, self.y_treino, self.y_val = train_test_split(
                X_temp, y_temp, test_size=0.176, random_state=42
            )

        print(f"Treino: {len(self.X_treino)} | Validação: {len(self.X_val)} | Teste: {len(self.X_teste)}")

    def treinar(self):
        print("\nPré-processando textos...")
        X_treino_pre = [self.pre.transformar(t) for t in self.X_treino]
        X_val_pre    = [self.pre.transformar(t) for t in self.X_val]
        X_teste_pre  = [self.pre.transformar(t) for t in self.X_teste]

        print("\nVetorizando textos...")
        self.vet.fit(X_treino_pre)
        self.X_treino_vet = self.vet.transformar(X_treino_pre)
        self.X_val_vet    = self.vet.transformar(X_val_pre)
        self.X_teste_vet  = self.vet.transformar(X_teste_pre)

        print(f"\nTreinando modelo: {self.modelo_sugerido}...")
        self.clas.treinar(self.X_treino_vet, self.y_treino)

    def avaliar_validacao(self):
        print("\nAvaliação na validação:")
        return self.clas.avaliar(self.X_val_vet, self.y_val)

    def avaliar_teste(self):
        print("\nAvaliação no teste final:")
        return self.clas.avaliar(self.X_teste_vet, self.y_teste)