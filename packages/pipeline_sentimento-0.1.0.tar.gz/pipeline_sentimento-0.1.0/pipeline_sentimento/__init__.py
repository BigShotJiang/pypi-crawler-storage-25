# Esse arquivo torna a pasta um pacote Python.
# Ele expõe as classes principais para quem instalar o pacote.
from .pipeline import Pipeline, sugerir_modelo
from .preprocessamento import Preprocessamento
from .vetorizacao import Vetorizacao
from .classificador import Classificador