import re
import emoji
import spacy
from nltk.corpus import stopwords
from nltk.stem import RSLPStemmer

# Carrega o modelo de português do spaCy uma única vez.
# Se ficasse dentro do método, recarregaria a cada texto — muito lento.
nlp = spacy.load("pt_core_news_sm")


class Preprocessamento:

    # Recebe um dicionário dizendo quais etapas ativar.
    # Exemplo: {"lowercase": True, "remove_urls": False}
    def __init__(self, config):
        self.config = config

    def transformar(self, texto):

        # Converte tudo para minúsculo.
        # "NÃO GOSTEI" → "não gostei"
        if self.config.get("lowercase"):
            texto = texto.lower()

        # Remove links do texto — não carregam sentimento.
        # "acesse http://loja.com" → "acesse"
        if self.config.get("remove_urls"):
            texto = re.sub(r'http\S+', '', texto)
            texto = texto.strip()

        # Converte emojis em texto descritivo.
        # 😡 → ":rosto_furioso:"
        if self.config.get("normalize_emojis"):
            texto = emoji.demojize(texto, language="pt")

        # Remove palavras comuns que não carregam sentimento.
        # "o produto é muito bom" → "produto muito bom"
        # Com "keep_negations", preserva "não", "nunca", "jamais", "nem".
        if self.config.get("remove_stopwords"):
            lista_stopwords = set(stopwords.words("portuguese"))

            if self.config.get("remove_stopwords") == "keep_negations":
                lista_stopwords -= {"não", "nunca", "jamais", "nem"}

            tokens = texto.split()
            tokens = [p for p in tokens if p not in lista_stopwords]
            texto = " ".join(tokens)

        # Marca as próximas 3 palavras após uma negação com _NEG.
        # "não gostei do produto" → "não gostei_NEG do_NEG produto_NEG"
        # Assim o modelo distingue "gostei" de "gostei_NEG".
        if self.config.get("handle_negations"):
            negacoes = {"não", "nunca", "jamais", "nem"}
            tokens = texto.split()
            novos_tokens = []
            contador = 0

            for palavra in tokens:
                if palavra in negacoes:
                    contador = 3
                    novos_tokens.append(palavra)
                elif contador > 0:
                    novos_tokens.append(palavra + "_NEG")
                    contador -= 1
                else:
                    novos_tokens.append(palavra)

            texto = " ".join(novos_tokens)

        # Reduz palavras à sua forma base.
        # Stemming (rápido, bruto): "correndo" → "corr"
        # Lematização (lento, preciso): "correndo" → "correr"
        if self.config.get("normalization") == "stemming":
            stemmer = RSLPStemmer()
            tokens = texto.split()
            texto = " ".join([stemmer.stem(p) for p in tokens])

        elif self.config.get("normalization") == "lemmatization":
            doc = nlp(texto)
            texto = " ".join([token.lemma_ for token in doc])

        return texto