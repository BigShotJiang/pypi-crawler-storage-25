from chalkcompute._image import Image as Image
from chalkcompute._image import LazyLocalFile as LazyLocalFile

def build_image(image: Image) -> str: ...
