---
layout: default
title: Examples
nav_order: 6
---

# Examples

## Basic Queries

### Find a Country

```python
from worldbank.models import Country

# By ISO code
usa = Country.objects.get(iso2_code='US')
japan = Country.objects.get(iso2_code='JP')

# By name
france = Country.objects.get(name__icontains='France')
```

### List Countries by Region

```python
from worldbank.models import Country

# European countries
europe = Country.objects.filter(
    region_name='Europe & Central Asia',
    is_aggregate=False,
)

# High-income countries
rich = Country.objects.filter(
    income_level='HIC',
    is_aggregate=False,
)
```

### Find an Indicator

```python
from worldbank.models import Indicator

# By code
pop = Indicator.objects.get(code='SP.POP.TOTL')

# By category
tourism = Indicator.objects.filter(category='tourism')

# Search by name
gdp_indicators = Indicator.objects.filter(name__icontains='GDP')
```

## Data Queries

### Get Current Value

```python
from worldbank.models import IndicatorValue

# Latest population for USA
pop = IndicatorValue.objects.filter(
    country__iso2_code='US',
    indicator__code='SP.POP.TOTL',
    value__isnull=False,
).order_by('-year').first()

print(f"USA Population ({pop.year}): {pop.value:,.0f}")
```

### Time Series

```python
from worldbank.models import IndicatorValue

# GDP per capita over time
gdp_series = IndicatorValue.objects.filter(
    country__iso2_code='US',
    indicator__code='NY.GDP.PCAP.CD',
    value__isnull=False,
).order_by('year')

for val in gdp_series:
    print(f"{val.year}: ${val.value:,.0f}")
```

### Compare Countries

```python
from worldbank.models import IndicatorValue

# Life expectancy comparison (2022)
comparison = IndicatorValue.objects.filter(
    indicator__code='SP.DYN.LE00.IN',
    year=2022,
    country__is_aggregate=False,
    value__isnull=False,
).select_related('country').order_by('-value')[:10]

print("Top 10 Life Expectancy (2022):")
for val in comparison:
    print(f"  {val.country.name}: {val.value:.1f} years")
```

### Category Summary

```python
from worldbank.models import IndicatorValue

# All tourism indicators for a country
tourism = IndicatorValue.objects.filter(
    country__iso2_code='FR',
    indicator__category='tourism',
    year=2022,
    value__isnull=False,
).select_related('indicator')

for val in tourism:
    print(f"{val.indicator.name}: {val.value:,.0f}")
```

## Aggregations

### Country Profile

```python
from worldbank.models import Country, IndicatorValue

def get_country_profile(iso2_code, year=2022):
    """Get key indicators for a country."""
    country = Country.objects.get(iso2_code=iso2_code)

    indicators = [
        'SP.POP.TOTL',
        'NY.GDP.PCAP.CD',
        'SP.DYN.LE00.IN',
        'IT.NET.USER.ZS',
        'ST.INT.ARVL',
    ]

    values = IndicatorValue.objects.filter(
        country=country,
        indicator__code__in=indicators,
        year=year,
    ).select_related('indicator')

    profile = {
        'country': country.name,
        'year': year,
        'data': {v.indicator.code: v.value for v in values},
    }
    return profile

# Usage
profile = get_country_profile('JP', 2022)
print(profile)
```

### Regional Averages

```python
from django.db.models import Avg
from worldbank.models import IndicatorValue

# Average GDP per capita by region (2022)
regional_gdp = IndicatorValue.objects.filter(
    indicator__code='NY.GDP.PCAP.CD',
    year=2022,
    country__is_aggregate=False,
    value__isnull=False,
).values('country__region_name').annotate(
    avg_gdp=Avg('value')
).order_by('-avg_gdp')

for region in regional_gdp:
    print(f"{region['country__region_name']}: ${region['avg_gdp']:,.0f}")
```

### Income Level Comparison

```python
from django.db.models import Avg
from worldbank.models import IndicatorValue

# Internet usage by income level
internet_by_income = IndicatorValue.objects.filter(
    indicator__code='IT.NET.USER.ZS',
    year=2022,
    country__is_aggregate=False,
    value__isnull=False,
).values('country__income_level_name').annotate(
    avg_internet=Avg('value')
).order_by('-avg_internet')

for level in internet_by_income:
    print(f"{level['country__income_level_name']}: {level['avg_internet']:.1f}%")
```

## API Views

### Django REST Framework

```python
from rest_framework import serializers, viewsets
from worldbank.models import Country, Indicator, IndicatorValue

class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = [
            'iso2_code', 'iso3_code', 'name', 'region_name',
            'income_level_name', 'capital_city', 'latitude', 'longitude',
        ]

class IndicatorValueSerializer(serializers.ModelSerializer):
    country_code = serializers.CharField(source='country.iso2_code')
    indicator_code = serializers.CharField(source='indicator.code')

    class Meta:
        model = IndicatorValue
        fields = ['country_code', 'indicator_code', 'year', 'value']

class CountryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Country.objects.filter(is_aggregate=False)
    serializer_class = CountrySerializer
    filterset_fields = ['income_level', 'region_code']

class IndicatorDataView(viewsets.ReadOnlyModelViewSet):
    serializer_class = IndicatorValueSerializer
    filterset_fields = ['year']

    def get_queryset(self):
        country = self.request.query_params.get('country')
        indicator = self.request.query_params.get('indicator')

        qs = IndicatorValue.objects.select_related('country', 'indicator')

        if country:
            qs = qs.filter(country__iso2_code=country)
        if indicator:
            qs = qs.filter(indicator__code=indicator)

        return qs.order_by('-year')
```

## Data Export

### Export to CSV

```python
import csv
from worldbank.models import IndicatorValue

def export_indicator(indicator_code, filename):
    """Export indicator data to CSV."""
    values = IndicatorValue.objects.filter(
        indicator__code=indicator_code,
        value__isnull=False,
    ).select_related('country').order_by('country__name', 'year')

    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['country', 'iso2', 'year', 'value'])

        for val in values:
            writer.writerow([
                val.country.name,
                val.country.iso2_code,
                val.year,
                val.value,
            ])

# Export population data
export_indicator('SP.POP.TOTL', 'population.csv')
```

### Export to JSON

```python
import json
from worldbank.models import IndicatorValue

def export_country_data(iso2_code, filename):
    """Export all data for a country to JSON."""
    values = IndicatorValue.objects.filter(
        country__iso2_code=iso2_code,
        value__isnull=False,
    ).select_related('indicator').order_by('indicator__code', 'year')

    data = {}
    for val in values:
        if val.indicator.code not in data:
            data[val.indicator.code] = {
                'name': val.indicator.name,
                'values': {},
            }
        data[val.indicator.code]['values'][val.year] = val.value

    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)

# Export Japan data
export_country_data('JP', 'japan_data.json')
```

## Scheduled Updates

### Management Command

```python
# management/commands/update_worldbank.py
from django.core.management.base import BaseCommand
from django.core.management import call_command

class Command(BaseCommand):
    help = 'Weekly World Bank data update'

    def handle(self, *args, **options):
        # Update recent years only
        call_command(
            'worldbank',
            import_type='data',
            start_year=2020,
        )
        self.stdout.write('World Bank data updated')
```

### Crontab

```bash
# Weekly update (Sunday 3 AM)
0 3 * * 0 /path/to/venv/bin/python /path/to/manage.py update_worldbank
```
