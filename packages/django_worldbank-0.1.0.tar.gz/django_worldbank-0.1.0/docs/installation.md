---
layout: default
title: Installation
nav_order: 2
---

# Installation

## Requirements

- Python 3.10 or higher
- Django 4.2 or higher
- requests library

## Install from PyPI

```bash
pip install django-worldbank
```

## Install from Source

```bash
git clone https://github.com/yourusername/django-worldbank.git
cd django-worldbank
pip install -e .
```

## Django Configuration

Add `worldbank` to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'worldbank',
]
```

## Run Migrations

```bash
python manage.py migrate worldbank
```

## Verify Installation

```bash
python manage.py worldbank --help
```

## Initial Data Import

Import countries and indicator metadata first:

```bash
python manage.py worldbank --import=country,indicator
```

Then import data values:

```bash
# Default travel-context indicators
python manage.py worldbank --import=data

# Or specific categories
python manage.py worldbank --import=data --category=tourism,economy
```

## Database Considerations

### PostgreSQL (Recommended)

No special configuration needed. PostgreSQL handles the large number of indicator values efficiently.

### SQLite

Works for development but may be slow with large data imports. Consider limiting year range:

```bash
python manage.py worldbank --import=data --start-year=2015 --end-year=2024
```

## Troubleshooting

### API Rate Limiting

The World Bank API has rate limits. If you encounter errors:

```python
WORLDBANK = {
    'TIMEOUT': 60,  # Increase timeout
    'PER_PAGE': 500,  # Reduce page size
}
```

### Memory Issues

For large imports, reduce batch size:

```python
WORLDBANK = {
    'BATCH_SIZE': 500,
}
```
