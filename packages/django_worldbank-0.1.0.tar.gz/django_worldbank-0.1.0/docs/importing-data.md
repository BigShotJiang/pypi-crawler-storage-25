---
layout: default
title: Importing Data
nav_order: 4
---

# Importing Data

## Management Command

The `worldbank` management command handles all data operations.

```bash
python manage.py worldbank [options]
```

## Import Data

### Import All Data

```bash
python manage.py worldbank --import=all
```

This imports in order:
1. Countries (including regions and aggregates)
2. Indicators (metadata for all 17,000+ indicators)
3. Data values (for default indicators only)

### Import Specific Types

```bash
# Just countries
python manage.py worldbank --import=country

# Just indicator metadata
python manage.py worldbank --import=indicator

# Just data values
python manage.py worldbank --import=data
```

### Import by Category

```bash
# Single category
python manage.py worldbank --import=data --category=tourism

# Multiple categories
python manage.py worldbank --import=data --category=tourism,economy,health

# All categories (comprehensive import)
python manage.py worldbank --import=data --category=all
```

### Import Specific Indicators

```bash
python manage.py worldbank --import=data --indicators=SP.POP.TOTL,NY.GDP.PCAP.CD,ST.INT.ARVL
```

### Specify Year Range

```bash
# Last 10 years
python manage.py worldbank --import=data --start-year=2014 --end-year=2024

# Historical data
python manage.py worldbank --import=data --start-year=1960 --end-year=2000
```

## Flush Data

Delete existing data before importing:

```bash
# Flush everything
python manage.py worldbank --flush=all --import=all

# Flush specific types
python manage.py worldbank --flush=data --import=data
```

## Command Options

| Option | Description |
|--------|-------------|
| `--import` | What to import: country, indicator, data, all |
| `--flush` | Delete existing: country, indicator, data, all |
| `--indicators` | Specific indicator codes (comma-separated) |
| `--category` | Import by category (see Configuration) |
| `--start-year` | Start year for data (default: 2000) |
| `--end-year` | End year for data (default: 2024) |
| `--quiet` | Suppress progress output |
| `--dry-run` | Parse without saving |
| `--list-categories` | Show available categories |
| `--list-indicators` | List indicators in database |

## Import Process

### How It Works

1. **Countries**: Fetched from `/country` endpoint
2. **Indicators**: Fetched from `/indicator` endpoint
3. **Data**: Fetched from `/country/all/indicator/{code}` for each indicator

### Change Detection

- Countries and indicators use `update_or_create`
- Data values use unique constraint on (country, indicator, year)
- Existing values are updated if changed

### Dependencies

1. **Countries** first (no dependencies)
2. **Indicators** (no dependencies, can run in parallel)
3. **Data** (requires countries and indicators)

## Examples

### Initial Setup

```bash
# First time: import everything
python manage.py worldbank --import=all
```

### Daily/Weekly Update

```bash
# Update recent years only
python manage.py worldbank --import=data --start-year=2020
```

### Add New Category

```bash
# Already have tourism, want to add economy
python manage.py worldbank --import=data --category=economy
```

### Development/Testing

```bash
# Quick test with limited data
python manage.py worldbank --import=country,indicator
python manage.py worldbank --import=data --start-year=2020 --indicators=SP.POP.TOTL
```

## Performance Tips

### Large Imports

For importing all categories:

```bash
# Import categories separately for progress visibility
python manage.py worldbank --import=data --category=demographics
python manage.py worldbank --import=data --category=tourism
python manage.py worldbank --import=data --category=economy
# ... etc
```

### Memory Management

Reduce batch size for constrained environments:

```python
WORLDBANK = {
    'BATCH_SIZE': 500,
}
```
