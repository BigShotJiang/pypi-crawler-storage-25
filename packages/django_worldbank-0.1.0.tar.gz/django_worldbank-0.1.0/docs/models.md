---
layout: default
title: Models
nav_order: 5
---

# Models

## Country

World Bank country or aggregate region.

```python
from worldbank.models import Country
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `iso2_code` | CharField(2) | ISO 3166-1 alpha-2 code (unique) |
| `iso3_code` | CharField(3) | ISO 3166-1 alpha-3 code |
| `name` | CharField(200) | Country name |
| `region_code` | CharField(10) | World Bank region code |
| `region_name` | CharField(100) | Region name (e.g., "Europe & Central Asia") |
| `admin_region_code` | CharField(10) | Administrative region code |
| `admin_region_name` | CharField(100) | Administrative region name |
| `income_level` | CharField(3) | Income classification |
| `income_level_name` | CharField(50) | Income level name |
| `lending_type` | CharField(3) | World Bank lending type |
| `lending_type_name` | CharField(50) | Lending type name |
| `capital_city` | CharField(100) | Capital city name |
| `latitude` | FloatField | Capital latitude |
| `longitude` | FloatField | Capital longitude |
| `is_aggregate` | BooleanField | Whether this is an aggregate (not a country) |

### Income Levels

| Code | Description |
|------|-------------|
| `HIC` | High income |
| `UMC` | Upper middle income |
| `LMC` | Lower middle income |
| `LIC` | Low income |
| `INX` | Not classified |

### Relationships

- `indicator_values` - Related IndicatorValue objects

---

## Indicator

World Bank indicator metadata.

```python
from worldbank.models import Indicator
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `code` | CharField(50) | Indicator code (unique), e.g., "SP.POP.TOTL" |
| `name` | CharField(500) | Indicator name |
| `description` | TextField | Full description/source note |
| `source_note` | TextField | Data source note |
| `source_organization` | TextField | Source organization |
| `category` | CharField(20) | Category (see Configuration) |
| `topic_id` | CharField(20) | World Bank topic ID |
| `topic_name` | CharField(200) | Topic name |
| `unit` | CharField(100) | Unit of measurement (if parseable) |

### Categories

| Code | Description |
|------|-------------|
| `demographics` | Demographics |
| `tourism` | Tourism |
| `connectivity` | Connectivity & Infrastructure |
| `economy` | Economy & Cost |
| `health` | Health & Safety |
| `education` | Education & Human Capital |
| `labor` | Labor & Employment |
| `governance` | Governance & Institutions |
| `poverty` | Poverty & Inequality |
| `trade` | Trade, Finance & Aid |
| `environment` | Environment & Energy |
| `agriculture` | Agriculture & Land Use |
| `other` | Other/Uncategorized |

### Relationships

- `values` - Related IndicatorValue objects

---

## IndicatorValue

Individual data point for a country/indicator/year combination.

```python
from worldbank.models import IndicatorValue
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `country` | ForeignKey | Related Country |
| `indicator` | ForeignKey | Related Indicator |
| `year` | PositiveSmallIntegerField | Data year |
| `value` | FloatField | Numeric value (nullable for missing data) |
| `decimal` | PositiveSmallIntegerField | Decimal precision |

### Constraints

- Unique together: (country, indicator, year)

### Indexes

- (indicator, year) - For time series queries
- (country, year) - For country profiles
- (indicator, country, -year) - For latest values

---

## Example Queries

### Get Latest Value

```python
latest = IndicatorValue.objects.filter(
    country__iso2_code='US',
    indicator__code='SP.POP.TOTL',
    value__isnull=False,
).order_by('-year').first()
```

### Time Series

```python
series = IndicatorValue.objects.filter(
    country__iso2_code='US',
    indicator__code='NY.GDP.PCAP.CD',
).order_by('year').values('year', 'value')
```

### Cross-Country Comparison

```python
comparison = IndicatorValue.objects.filter(
    indicator__code='SP.DYN.LE00.IN',
    year=2022,
    country__is_aggregate=False,
    value__isnull=False,
).select_related('country').order_by('-value')
```
