---
layout: default
title: Home
nav_order: 1
---

# django-worldbank

A Django application to download and import data from the [World Bank Open Data](https://data.worldbank.org/) API.

## Features

- **Comprehensive Data**: Import countries, indicators, and time-series values
- **12 Categories**: Demographics, Tourism, Economy, Health, Education, and more
- **Flexible Imports**: Import by category, specific indicators, or all data
- **Travel Context**: Default indicators optimized for travel/destination information
- **Easy Configuration**: Customize default indicators in settings
- **Django Admin**: Built-in admin interface for data exploration

## Quick Start

```bash
pip install django-worldbank
```

```python
INSTALLED_APPS = [
    ...
    'worldbank',
]
```

```bash
python manage.py migrate worldbank
python manage.py worldbank --import=all
```

## Data Coverage

World Bank provides data for:

- **265+** countries and regions
- **17,000+** development indicators
- **60+ years** of historical data
- Annual country-level statistics

## Navigation

- [Installation](installation.md) - Setup and requirements
- [Configuration](configuration.md) - Settings and customization
- [Importing Data](importing-data.md) - Management command usage
- [Models](models.md) - Database models reference
- [Examples](examples.md) - Code examples and recipes

## License

MIT License - Data is CC BY 4.0 (World Bank)
