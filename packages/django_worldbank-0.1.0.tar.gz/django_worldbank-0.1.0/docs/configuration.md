---
layout: default
title: Configuration
nav_order: 3
---

# Configuration

## Settings

Configure django-worldbank in your Django `settings.py`:

```python
WORLDBANK = {
    # Year range for data import
    'START_YEAR': 2000,
    'END_YEAR': 2024,

    # Batch size for bulk operations
    'BATCH_SIZE': 1000,

    # API settings
    'BASE_URL': 'https://api.worldbank.org/v2',
    'TIMEOUT': 30,
    'PER_PAGE': 1000,

    # Default indicators for travel context
    'DEFAULT_INDICATORS': [
        'SP.POP.TOTL',
        'EN.POP.DNST',
        'SP.URB.TOTL.IN.ZS',
        'ST.INT.ARVL',
        'ST.INT.RCPT.CD',
        'IT.NET.USER.ZS',
        'IT.CEL.SETS.P2',
        'EG.ELC.ACCS.ZS',
    ],

    # Plugin modules for import hooks
    'PLUGINS': [],
}
```

## Setting Reference

### START_YEAR / END_YEAR

Year range for data imports.

**Default**: `2000` to `2024`

```python
WORLDBANK = {
    'START_YEAR': 2010,
    'END_YEAR': 2023,
}
```

### BATCH_SIZE

Number of records to process in each batch.

**Default**: `1000`

```python
WORLDBANK = {
    'BATCH_SIZE': 5000,  # Larger batches, more memory
}
```

### DEFAULT_INDICATORS

List of indicator codes to import by default. These are optimized for travel/destination context.

**Default**:
```python
[
    'SP.POP.TOTL',        # Total population
    'EN.POP.DNST',        # Population density
    'SP.URB.TOTL.IN.ZS',  # Urban population %
    'ST.INT.ARVL',        # International tourist arrivals
    'ST.INT.RCPT.CD',     # Tourism receipts (current US$)
    'IT.NET.USER.ZS',     # Internet users (% of population)
    'IT.CEL.SETS.P2',     # Mobile subscriptions (per 100)
    'EG.ELC.ACCS.ZS',     # Access to electricity (%)
]
```

Customize for your needs:

```python
WORLDBANK = {
    'DEFAULT_INDICATORS': [
        # Your custom list
        'NY.GDP.PCAP.CD',     # GDP per capita
        'SP.DYN.LE00.IN',     # Life expectancy
        'SE.ADT.LITR.ZS',     # Literacy rate
    ],
}
```

### TIMEOUT

API request timeout in seconds.

**Default**: `30`

### PER_PAGE

Number of records per API request.

**Default**: `1000`

## Categories

Available categories for import:

| Code | Description |
|------|-------------|
| `demographics` | Population, density, age distribution |
| `tourism` | Tourist arrivals, receipts, departures |
| `connectivity` | Internet, mobile, electricity access |
| `economy` | GDP, GNI, inflation, exchange rates |
| `health` | Life expectancy, healthcare, sanitation |
| `education` | Literacy, enrollment, expenditure |
| `labor` | Employment, unemployment, workforce |
| `governance` | Rule of law, regulatory quality |
| `poverty` | Poverty rates, Gini index |
| `trade` | Imports, exports, FDI, remittances |
| `environment` | CO2 emissions, energy, forests |
| `agriculture` | Land use, crop yields, irrigation |

## Logging

Configure logging for import operations:

```python
LOGGING = {
    'version': 1,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'worldbank': {
            'handlers': ['console'],
            'level': 'INFO',
        },
    },
}
```
