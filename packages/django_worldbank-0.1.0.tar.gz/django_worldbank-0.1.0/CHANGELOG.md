# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2024-01-01

### Added
- Initial release
- Country model with World Bank classification (income level, region, lending type)
- Indicator model with 12 categories
- IndicatorValue model for time-series data
- World Bank API client
- Management command with import/flush operations
- Category-based imports (demographics, tourism, economy, etc.)
- Configurable default indicators for travel context
- Year range filtering for data imports
- Django admin integration
- Plugin system for import customization
- Comprehensive documentation

### Categories
- Demographics (population, density, urbanization)
- Tourism (arrivals, receipts)
- Connectivity (internet, mobile, electricity)
- Economy (GDP, GNI, inflation)
- Health (life expectancy, healthcare)
- Education (literacy, enrollment)
- Labor (employment, unemployment)
- Governance (rule of law, regulatory quality)
- Poverty (poverty rates, inequality)
- Trade (imports, exports, FDI)
- Environment (CO2, energy, forests)
- Agriculture (land use, yields)
