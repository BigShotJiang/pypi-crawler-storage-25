"""Django World Bank - Import and manage World Bank Open Data indicators."""

__version__ = "0.1.0"

default_app_config = "worldbank.apps.WorldBankConfig"
