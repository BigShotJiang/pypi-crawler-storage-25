"""Django admin for World Bank models."""

from django.contrib import admin

from .models import Country, Indicator, IndicatorValue


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("iso2_code", "name", "region_name", "income_level_name", "is_aggregate")
    list_filter = ("income_level", "region_code", "is_aggregate")
    search_fields = ("iso2_code", "iso3_code", "name", "capital_city")
    ordering = ("name",)


@admin.register(Indicator)
class IndicatorAdmin(admin.ModelAdmin):
    list_display = ("code", "name_truncated", "category", "topic_name")
    list_filter = ("category",)
    search_fields = ("code", "name", "description")
    ordering = ("category", "name")

    @admin.display(description="Name")
    def name_truncated(self, obj):
        return obj.name[:60] + "..." if len(obj.name) > 60 else obj.name


@admin.register(IndicatorValue)
class IndicatorValueAdmin(admin.ModelAdmin):
    list_display = ("country", "indicator_code", "year", "value")
    list_filter = ("year", "indicator__category")
    search_fields = ("country__name", "country__iso2_code", "indicator__code")
    raw_id_fields = ("country", "indicator")
    ordering = ("-year", "country", "indicator")

    @admin.display(description="Indicator")
    def indicator_code(self, obj):
        return obj.indicator.code
