"""Indicator importer for World Bank data."""

import logging
from typing import Iterator

from ..conf import LOGGER_NAME, get_category_for_indicator
from ..models import Indicator
from ..util import clean_string, parse_indicator_unit
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class IndicatorImporter(BaseImporter):
    """Import indicators from World Bank API."""

    def __init__(self, command=None, options: dict = None):
        super().__init__(command, options)
        self.indicator_codes = options.get("indicator_codes") if options else None

    def fetch_data(self) -> Iterator[dict]:
        """Fetch indicators from API."""
        if self.indicator_codes:
            # Fetch specific indicators
            for code in self.indicator_codes:
                metadata = self.api.get_indicator_metadata(code)
                if metadata:
                    yield metadata
        else:
            # Fetch all indicators
            yield from self.api.get_indicators()

    def process_record(self, record: dict) -> str:
        """Process a single indicator record."""
        code = clean_string(record.get("id", ""))

        if not code:
            return "skipped"

        name = clean_string(record.get("name", ""))
        source_note = clean_string(record.get("sourceNote", ""))
        source_org = clean_string(record.get("sourceOrganization", ""))

        # Get topic info
        topics = record.get("topics", []) or []
        topic_id = ""
        topic_name = ""
        if topics and isinstance(topics, list) and len(topics) > 0:
            first_topic = topics[0]
            if isinstance(first_topic, dict):
                topic_id = clean_string(first_topic.get("id", ""))
                topic_name = clean_string(first_topic.get("value", ""))

        # Determine category
        category = get_category_for_indicator(code)

        # Try to extract unit from description
        unit = parse_indicator_unit(source_note) or parse_indicator_unit(name)

        defaults = {
            "name": name,
            "description": source_note,
            "source_note": source_note,
            "source_organization": source_org,
            "category": category,
            "topic_id": topic_id,
            "topic_name": topic_name,
            "unit": unit,
        }

        if self.dry_run:
            return "skipped"

        obj, created = Indicator.objects.update_or_create(
            code=code,
            defaults=defaults,
        )

        return "created" if created else "updated"
