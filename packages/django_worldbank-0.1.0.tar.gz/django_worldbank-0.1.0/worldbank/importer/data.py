"""Data importer for World Bank indicator values."""

import logging
from typing import Iterator

from django.db import transaction

from ..conf import (
    CATEGORY_INDICATORS,
    DEFAULT_INDICATORS,
    LOGGER_NAME,
    Category,
    get_worldbank_settings,
)
from ..models import Country, Indicator, IndicatorValue
from ..util import safe_float, safe_int
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class DataImporter(BaseImporter):
    """Import indicator data values from World Bank API."""

    def __init__(self, command=None, options: dict = None):
        super().__init__(command, options)
        self.settings = get_worldbank_settings()

        # Build country lookup
        self._country_cache = {}

        # Determine which indicators to import
        self.indicators = self._get_indicators_to_import(options)

    def _get_indicators_to_import(self, options: dict = None) -> list[str]:
        """Determine which indicators to import based on options."""
        options = options or {}

        # Check for specific indicators
        if options.get("indicator_codes"):
            return options["indicator_codes"]

        # Check for category import
        categories = options.get("categories", [])
        if categories:
            indicators = []
            for cat in categories:
                if cat == "all":
                    # Import all mapped indicators
                    for cat_indicators in CATEGORY_INDICATORS.values():
                        indicators.extend(cat_indicators)
                elif cat in CATEGORY_INDICATORS:
                    indicators.extend(CATEGORY_INDICATORS[cat])
            return list(set(indicators))

        # Default to travel context indicators
        return self.settings.default_indicators.copy()

    def _get_country(self, iso2_code: str) -> Country | None:
        """Get country from cache or database."""
        if iso2_code not in self._country_cache:
            try:
                self._country_cache[iso2_code] = Country.objects.get(iso2_code=iso2_code)
            except Country.DoesNotExist:
                self._country_cache[iso2_code] = None
        return self._country_cache[iso2_code]

    def fetch_data(self) -> Iterator[tuple[str, dict]]:
        """Fetch data for all indicators."""
        start_year = self.options.get("start_year", self.settings.start_year)
        end_year = self.options.get("end_year", self.settings.end_year)

        for indicator_code in self.indicators:
            self.log(f"  Fetching {indicator_code}...")

            for record in self.api.get_indicator_data(
                indicator_code,
                country="all",
                start_year=start_year,
                end_year=end_year,
            ):
                yield indicator_code, record

    def process_record(self, data: tuple[str, dict]) -> str:
        """Process a single data record."""
        indicator_code, record = data

        # Extract country code
        country_info = record.get("country", {}) or {}
        country_code = country_info.get("id", "")

        if not country_code or len(country_code) != 2:
            return "skipped"

        # Get country
        country = self._get_country(country_code)
        if not country:
            return "skipped"

        # Extract year and value
        year = safe_int(record.get("date"))
        if not year:
            return "skipped"

        value = safe_float(record.get("value"))
        # Allow null values - they're valid (no data available)

        decimal = safe_int(record.get("decimal")) or 0

        if self.dry_run:
            return "skipped"

        # Get or create indicator
        try:
            indicator = Indicator.objects.get(code=indicator_code)
        except Indicator.DoesNotExist:
            # Create minimal indicator record
            indicator = Indicator.objects.create(
                code=indicator_code,
                name=record.get("indicator", {}).get("value", indicator_code),
            )

        # Update or create the value
        obj, created = IndicatorValue.objects.update_or_create(
            country=country,
            indicator=indicator,
            year=year,
            defaults={
                "value": value,
                "decimal": decimal,
            },
        )

        return "created" if created else "updated"

    def run(self) -> dict:
        """Run the import with batch processing."""
        self.log(f"  Importing data for {len(self.indicators)} indicators...")

        # Pre-load country cache
        for country in Country.objects.all():
            self._country_cache[country.iso2_code] = country

        return super().run()


class BulkDataImporter(DataImporter):
    """Bulk import indicator data for better performance."""

    def __init__(self, command=None, options: dict = None):
        super().__init__(command, options)
        self._indicator_cache = {}
        self._pending_creates = []
        self._pending_updates = []

    def _get_indicator(self, code: str, name: str = None) -> Indicator:
        """Get indicator from cache or database."""
        if code not in self._indicator_cache:
            indicator, created = Indicator.objects.get_or_create(
                code=code,
                defaults={"name": name or code},
            )
            self._indicator_cache[code] = indicator
        return self._indicator_cache[code]

    def run(self) -> dict:
        """Run bulk import with batching."""
        self.log(f"  Bulk importing data for {len(self.indicators)} indicators...")

        # Pre-load caches
        for country in Country.objects.all():
            self._country_cache[country.iso2_code] = country
        for indicator in Indicator.objects.filter(code__in=self.indicators):
            self._indicator_cache[indicator.code] = indicator

        start_year = self.options.get("start_year", self.settings.start_year)
        end_year = self.options.get("end_year", self.settings.end_year)

        # Load existing values for update detection
        existing_values = set(
            IndicatorValue.objects.filter(
                indicator__code__in=self.indicators,
                year__gte=start_year,
                year__lte=end_year,
            ).values_list("country_id", "indicator_id", "year")
        )

        batch_size = self.settings.batch_size
        creates = []
        updates = []

        for indicator_code in self.indicators:
            self.log(f"  Fetching {indicator_code}...")

            indicator = self._get_indicator(indicator_code)

            for record in self.api.get_indicator_data(
                indicator_code,
                country="all",
                start_year=start_year,
                end_year=end_year,
            ):
                self.stats["processed"] += 1

                # Extract data
                country_info = record.get("country", {}) or {}
                country_code = country_info.get("id", "")
                country = self._country_cache.get(country_code)

                if not country:
                    self.stats["skipped"] += 1
                    continue

                year = safe_int(record.get("date"))
                if not year:
                    self.stats["skipped"] += 1
                    continue

                value = safe_float(record.get("value"))
                decimal = safe_int(record.get("decimal")) or 0

                key = (country.id, indicator.id, year)

                if key in existing_values:
                    # Update existing
                    updates.append(
                        IndicatorValue(
                            country_id=country.id,
                            indicator_id=indicator.id,
                            year=year,
                            value=value,
                            decimal=decimal,
                        )
                    )
                else:
                    # Create new
                    creates.append(
                        IndicatorValue(
                            country=country,
                            indicator=indicator,
                            year=year,
                            value=value,
                            decimal=decimal,
                        )
                    )

                # Batch insert/update
                if len(creates) >= batch_size:
                    if not self.dry_run:
                        with transaction.atomic():
                            IndicatorValue.objects.bulk_create(
                                creates, ignore_conflicts=True
                            )
                    self.stats["created"] += len(creates)
                    creates = []

                if len(updates) >= batch_size:
                    if not self.dry_run:
                        with transaction.atomic():
                            IndicatorValue.objects.bulk_update(
                                updates, ["value", "decimal"]
                            )
                    self.stats["updated"] += len(updates)
                    updates = []

        # Final batch
        if creates and not self.dry_run:
            with transaction.atomic():
                IndicatorValue.objects.bulk_create(creates, ignore_conflicts=True)
            self.stats["created"] += len(creates)

        if updates and not self.dry_run:
            with transaction.atomic():
                IndicatorValue.objects.bulk_update(updates, ["value", "decimal"])
            self.stats["updated"] += len(updates)

        self._log_stats()
        return self.stats
