"""Country importer for World Bank data."""

import logging
from typing import Iterator

from ..conf import LOGGER_NAME
from ..models import Country
from ..util import clean_string, safe_float
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class CountryImporter(BaseImporter):
    """Import countries from World Bank API."""

    # Known aggregate region codes (not actual countries)
    AGGREGATE_CODES = {
        "1A", "1W", "4E", "7E", "8S", "B8", "EU", "F1", "OE", "S1", "S2", "S3", "S4",
        "T2", "T3", "T4", "T5", "T6", "T7", "V1", "V2", "V3", "V4", "XC", "XD", "XE",
        "XF", "XG", "XH", "XI", "XJ", "XK", "XL", "XM", "XN", "XO", "XP", "XQ", "XR",
        "XS", "XT", "XU", "XY", "Z4", "Z7", "ZB", "ZF", "ZG", "ZH", "ZI", "ZJ", "ZQ",
        "ZT", "ZW",
    }

    def fetch_data(self) -> Iterator[dict]:
        """Fetch countries from API."""
        return self.api.get_countries()

    def process_record(self, record: dict) -> str:
        """Process a single country record."""
        iso2_code = clean_string(record.get("iso2Code", ""))

        if not iso2_code or len(iso2_code) != 2:
            return "skipped"

        # Determine if this is an aggregate region
        is_aggregate = (
            iso2_code in self.AGGREGATE_CODES or
            record.get("region", {}).get("id") == "NA"
        )

        # Extract nested values
        region = record.get("region", {}) or {}
        admin_region = record.get("adminregion", {}) or {}
        income_level = record.get("incomeLevel", {}) or {}
        lending_type = record.get("lendingType", {}) or {}

        defaults = {
            "iso3_code": clean_string(record.get("id", "")),
            "name": clean_string(record.get("name", "")),
            "region_code": clean_string(region.get("id", "")),
            "region_name": clean_string(region.get("value", "")),
            "admin_region_code": clean_string(admin_region.get("id", "")),
            "admin_region_name": clean_string(admin_region.get("value", "")),
            "income_level": clean_string(income_level.get("id", "")),
            "income_level_name": clean_string(income_level.get("value", "")),
            "lending_type": clean_string(lending_type.get("id", "")),
            "lending_type_name": clean_string(lending_type.get("value", "")),
            "capital_city": clean_string(record.get("capitalCity", "")),
            "latitude": safe_float(record.get("latitude")),
            "longitude": safe_float(record.get("longitude")),
            "is_aggregate": is_aggregate,
        }

        if self.dry_run:
            return "skipped"

        obj, created = Country.objects.update_or_create(
            iso2_code=iso2_code,
            defaults=defaults,
        )

        return "created" if created else "updated"
