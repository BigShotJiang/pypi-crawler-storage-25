"""Base importer class for World Bank data."""

import logging
from abc import ABC, abstractmethod
from typing import Any

from ..conf import LOGGER_NAME, get_worldbank_settings
from ..services import WorldBankAPI

logger = logging.getLogger(LOGGER_NAME)


class BaseImporter(ABC):
    """Base class for World Bank data importers."""

    def __init__(self, command=None, options: dict = None):
        self.command = command
        self.options = options or {}
        self.settings = get_worldbank_settings()
        self.api = WorldBankAPI()
        self.dry_run = self.options.get("dry_run", False)
        self.quiet = self.options.get("quiet", False)

        self.stats = {
            "processed": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
        }

    def log(self, message: str, style: str = None):
        """Log message to command output."""
        if self.quiet:
            return
        if self.command:
            if style == "success":
                self.command.stdout.write(self.command.style.SUCCESS(message))
            elif style == "error":
                self.command.stdout.write(self.command.style.ERROR(message))
            elif style == "warning":
                self.command.stdout.write(self.command.style.WARNING(message))
            else:
                self.command.stdout.write(message)
        else:
            logger.info(message)

    @abstractmethod
    def fetch_data(self):
        """Fetch data from API. Must be implemented by subclasses."""
        pass

    @abstractmethod
    def process_record(self, record: dict) -> Any:
        """Process a single record. Must be implemented by subclasses."""
        pass

    def run(self) -> dict:
        """Run the import process."""
        for record in self.fetch_data():
            try:
                result = self.process_record(record)
                self.stats["processed"] += 1

                if result == "created":
                    self.stats["created"] += 1
                elif result == "updated":
                    self.stats["updated"] += 1
                elif result == "skipped":
                    self.stats["skipped"] += 1

            except Exception as e:
                self.stats["errors"] += 1
                logger.warning(f"Error processing record: {e}")

        self._log_stats()
        return self.stats

    def _log_stats(self):
        """Log import statistics."""
        self.log(
            f"  Processed: {self.stats['processed']}, "
            f"Created: {self.stats['created']}, "
            f"Updated: {self.stats['updated']}, "
            f"Skipped: {self.stats['skipped']}"
        )
        if self.stats["errors"]:
            self.log(f"  Errors: {self.stats['errors']}", style="warning")
