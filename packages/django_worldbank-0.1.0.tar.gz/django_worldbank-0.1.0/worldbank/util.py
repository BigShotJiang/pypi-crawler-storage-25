"""Utility functions for World Bank data import."""

import logging
from typing import Any

from .conf import LOGGER_NAME

logger = logging.getLogger(LOGGER_NAME)


def safe_float(value: Any) -> float | None:
    """Safely convert value to float."""
    if value is None or value == "" or value == "null":
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def safe_int(value: Any) -> int | None:
    """Safely convert value to int."""
    if value is None or value == "" or value == "null":
        return None
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return None


def clean_string(value: Any) -> str:
    """Clean and return string value."""
    if value is None:
        return ""
    return str(value).strip()


def parse_indicator_unit(description: str) -> str:
    """Try to extract unit from indicator description."""
    if not description:
        return ""

    # Common patterns
    unit_patterns = [
        ("% of GDP", "% of GDP"),
        ("% of population", "% of population"),
        ("% of total", "% of total"),
        ("per 100 people", "per 100 people"),
        ("per 1,000 people", "per 1,000 people"),
        ("per capita", "per capita"),
        ("current US$", "current US$"),
        ("constant US$", "constant US$"),
        ("metric tons", "metric tons"),
        ("kt of CO2 equivalent", "kt CO2 eq"),
        ("kWh per capita", "kWh per capita"),
        ("kg of oil equivalent", "kg oil eq"),
        ("square kilometers", "km²"),
        ("years", "years"),
    ]

    desc_lower = description.lower()
    for pattern, unit in unit_patterns:
        if pattern.lower() in desc_lower:
            return unit

    return ""
