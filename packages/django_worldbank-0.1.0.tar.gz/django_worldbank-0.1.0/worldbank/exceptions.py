"""Exceptions for World Bank data import."""


class WorldBankException(Exception):
    """Base exception for World Bank operations."""

    pass


class APIError(WorldBankException):
    """Error communicating with World Bank API."""

    pass


class ImportError(WorldBankException):
    """Error during data import."""

    pass


class ValidationError(WorldBankException):
    """Data validation error."""

    pass


class HookException(WorldBankException):
    """Exception raised by import hooks to skip a record."""

    pass
