"""Django app configuration for World Bank."""

from django.apps import AppConfig


class WorldBankConfig(AppConfig):
    """World Bank app configuration."""

    name = "worldbank"
    verbose_name = "World Bank Data"
    default_auto_field = "django.db.models.BigAutoField"
