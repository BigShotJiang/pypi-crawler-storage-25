"""Initial migration for World Bank models."""

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True
    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Country",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("iso2_code", models.CharField(db_index=True, help_text="ISO 3166-1 alpha-2 country code", max_length=2, unique=True, verbose_name="ISO2 code")),
                ("iso3_code", models.CharField(blank=True, db_index=True, help_text="ISO 3166-1 alpha-3 country code", max_length=3, verbose_name="ISO3 code")),
                ("name", models.CharField(db_index=True, max_length=200, verbose_name="name")),
                ("region_code", models.CharField(blank=True, db_index=True, max_length=10, verbose_name="region code")),
                ("region_name", models.CharField(blank=True, max_length=100, verbose_name="region name")),
                ("admin_region_code", models.CharField(blank=True, max_length=10, verbose_name="admin region code")),
                ("admin_region_name", models.CharField(blank=True, max_length=100, verbose_name="admin region name")),
                ("income_level", models.CharField(blank=True, choices=[("HIC", "High income"), ("UMC", "Upper middle income"), ("LMC", "Lower middle income"), ("LIC", "Low income"), ("INX", "Not classified")], db_index=True, max_length=3, verbose_name="income level")),
                ("income_level_name", models.CharField(blank=True, max_length=50, verbose_name="income level name")),
                ("lending_type", models.CharField(blank=True, choices=[("IBD", "IBRD"), ("IDB", "IDA & IBRD blend"), ("IDX", "IDA"), ("LNX", "Not classified")], max_length=3, verbose_name="lending type")),
                ("lending_type_name", models.CharField(blank=True, max_length=50, verbose_name="lending type name")),
                ("capital_city", models.CharField(blank=True, max_length=100, verbose_name="capital city")),
                ("latitude", models.FloatField(blank=True, null=True, verbose_name="latitude")),
                ("longitude", models.FloatField(blank=True, null=True, verbose_name="longitude")),
                ("is_aggregate", models.BooleanField(db_index=True, default=False, help_text="Whether this is an aggregate region (not a country)", verbose_name="is aggregate")),
            ],
            options={
                "verbose_name": "country",
                "verbose_name_plural": "countries",
                "ordering": ["name"],
            },
        ),
        migrations.CreateModel(
            name="Indicator",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("code", models.CharField(db_index=True, max_length=50, unique=True, verbose_name="indicator code")),
                ("name", models.CharField(max_length=500, verbose_name="name")),
                ("description", models.TextField(blank=True, verbose_name="description")),
                ("source_note", models.TextField(blank=True, verbose_name="source note")),
                ("source_organization", models.TextField(blank=True, verbose_name="source organization")),
                ("category", models.CharField(choices=[("demographics", "Demographics"), ("tourism", "Tourism"), ("connectivity", "Connectivity & Infrastructure"), ("economy", "Economy & Cost"), ("health", "Health & Safety"), ("education", "Education & Human Capital"), ("labor", "Labor & Employment"), ("governance", "Governance & Institutions"), ("poverty", "Poverty & Inequality"), ("trade", "Trade, Finance & Aid"), ("environment", "Environment & Energy"), ("agriculture", "Agriculture & Land Use"), ("other", "Other")], db_index=True, default="other", max_length=20, verbose_name="category")),
                ("topic_id", models.CharField(blank=True, max_length=20, verbose_name="topic ID")),
                ("topic_name", models.CharField(blank=True, max_length=200, verbose_name="topic name")),
                ("unit", models.CharField(blank=True, max_length=100, verbose_name="unit")),
            ],
            options={
                "verbose_name": "indicator",
                "verbose_name_plural": "indicators",
                "ordering": ["category", "name"],
            },
        ),
        migrations.CreateModel(
            name="IndicatorValue",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("year", models.PositiveSmallIntegerField(db_index=True, verbose_name="year")),
                ("value", models.FloatField(blank=True, null=True, verbose_name="value")),
                ("decimal", models.PositiveSmallIntegerField(default=0, verbose_name="decimal precision")),
                ("country", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="indicator_values", to="worldbank.country", verbose_name="country")),
                ("indicator", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="values", to="worldbank.indicator", verbose_name="indicator")),
            ],
            options={
                "verbose_name": "indicator value",
                "verbose_name_plural": "indicator values",
                "ordering": ["country", "indicator", "-year"],
                "unique_together": {("country", "indicator", "year")},
            },
        ),
        migrations.AddIndex(
            model_name="indicator",
            index=models.Index(fields=["category", "code"], name="worldbank_i_categor_a1b2c3_idx"),
        ),
        migrations.AddIndex(
            model_name="indicatorvalue",
            index=models.Index(fields=["indicator", "year"], name="worldbank_i_indicat_d4e5f6_idx"),
        ),
        migrations.AddIndex(
            model_name="indicatorvalue",
            index=models.Index(fields=["country", "year"], name="worldbank_i_country_g7h8i9_idx"),
        ),
        migrations.AddIndex(
            model_name="indicatorvalue",
            index=models.Index(fields=["indicator", "country", "-year"], name="worldbank_i_indicat_j0k1l2_idx"),
        ),
    ]
