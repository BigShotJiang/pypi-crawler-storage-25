"""World Bank API client."""

import logging
import time
from typing import Any, Iterator

import requests

from ..conf import BASE_API_URL, LOGGER_NAME, get_worldbank_settings
from ..exceptions import APIError

logger = logging.getLogger(LOGGER_NAME)


class WorldBankAPI:
    """Client for World Bank Indicators API."""

    def __init__(
        self,
        base_url: str = None,
        per_page: int = None,
        timeout: int = None,
    ):
        settings = get_worldbank_settings()
        self.base_url = base_url or settings.base_url
        self.per_page = per_page or settings.per_page
        self.timeout = timeout or settings.timeout
        self.session = requests.Session()

    def _request(self, endpoint: str, params: dict = None) -> dict:
        """Make API request and return JSON response."""
        url = f"{self.base_url}{endpoint}"
        params = params or {}
        params.setdefault("format", "json")
        params.setdefault("per_page", self.per_page)

        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            data = response.json()

            # World Bank API returns [metadata, data] for most endpoints
            if isinstance(data, list) and len(data) >= 2:
                return data
            return data

        except requests.exceptions.Timeout as e:
            raise APIError(f"Request timeout: {url}") from e
        except requests.exceptions.RequestException as e:
            raise APIError(f"API request failed: {e}") from e
        except ValueError as e:
            raise APIError(f"Invalid JSON response: {e}") from e

    def _paginate(self, endpoint: str, params: dict = None) -> Iterator[dict]:
        """Paginate through all results."""
        params = params or {}
        params["page"] = 1

        while True:
            result = self._request(endpoint, params)

            if not isinstance(result, list) or len(result) < 2:
                break

            metadata, data = result[0], result[1]

            if data is None:
                break

            yield from data

            # Check pagination
            total_pages = int(metadata.get("pages", 1))
            current_page = int(metadata.get("page", 1))

            if current_page >= total_pages:
                break

            params["page"] = current_page + 1
            time.sleep(0.1)  # Rate limiting

    def get_countries(self) -> Iterator[dict]:
        """Get all countries from World Bank API."""
        logger.info("Fetching countries from World Bank API")
        yield from self._paginate("/country")

    def get_indicators(self) -> Iterator[dict]:
        """Get all indicators from World Bank API."""
        logger.info("Fetching indicators from World Bank API")
        yield from self._paginate("/indicator")

    def get_indicator_data(
        self,
        indicator_code: str,
        country: str = "all",
        start_year: int = None,
        end_year: int = None,
    ) -> Iterator[dict]:
        """
        Get indicator data for countries.

        Args:
            indicator_code: World Bank indicator code (e.g., SP.POP.TOTL)
            country: Country code(s), 'all' for all countries
            start_year: Start year for data range
            end_year: End year for data range
        """
        endpoint = f"/country/{country}/indicator/{indicator_code}"
        params = {}

        if start_year and end_year:
            params["date"] = f"{start_year}:{end_year}"

        logger.debug(f"Fetching data for indicator: {indicator_code}")
        yield from self._paginate(endpoint, params)

    def get_indicator_metadata(self, indicator_code: str) -> dict | None:
        """Get metadata for a specific indicator."""
        try:
            result = self._request(f"/indicator/{indicator_code}")
            if isinstance(result, list) and len(result) >= 2 and result[1]:
                return result[1][0]
            return None
        except APIError:
            return None

    def get_country(self, iso2_code: str) -> dict | None:
        """Get data for a specific country."""
        try:
            result = self._request(f"/country/{iso2_code}")
            if isinstance(result, list) and len(result) >= 2 and result[1]:
                return result[1][0]
            return None
        except APIError:
            return None

    def search_indicators(self, query: str) -> Iterator[dict]:
        """Search indicators by keyword."""
        # World Bank doesn't have a direct search endpoint,
        # but we can filter by topic or source
        yield from self._paginate("/indicator", {"search": query})

    def get_topics(self) -> Iterator[dict]:
        """Get all topics (categories) from World Bank API."""
        logger.info("Fetching topics from World Bank API")
        yield from self._paginate("/topic")

    def get_sources(self) -> Iterator[dict]:
        """Get all data sources from World Bank API."""
        logger.info("Fetching sources from World Bank API")
        yield from self._paginate("/source")
