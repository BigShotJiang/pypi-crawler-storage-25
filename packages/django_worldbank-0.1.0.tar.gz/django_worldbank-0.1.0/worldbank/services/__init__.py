"""Services for World Bank data access."""

from .api import WorldBankAPI

__all__ = ["WorldBankAPI"]
