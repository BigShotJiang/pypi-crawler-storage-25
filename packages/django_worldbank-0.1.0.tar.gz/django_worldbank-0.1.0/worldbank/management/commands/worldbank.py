"""
Management command to download and import World Bank data.

Usage:
    python manage.py worldbank --import=all
    python manage.py worldbank --import=country,indicator
    python manage.py worldbank --import=data --category=tourism,economy
    python manage.py worldbank --import=data --indicators=SP.POP.TOTL,NY.GDP.PCAP.CD
    python manage.py worldbank --flush=all --import=all
"""

import logging

from django.core.management.base import BaseCommand, CommandError

from worldbank.conf import (
    CATEGORY_CHOICES,
    FLUSH_OPTS,
    FLUSH_OPTS_ALL,
    IMPORT_OPTS,
    IMPORT_OPTS_ALL,
    LOGGER_NAME,
    Category,
    get_worldbank_settings,
)
from worldbank.importer import CountryImporter, DataImporter, IndicatorImporter
from worldbank.models import Country, Indicator, IndicatorValue

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Download and import World Bank Open Data"

    IMPORTERS = {
        "country": CountryImporter,
        "indicator": IndicatorImporter,
        "data": DataImporter,
    }

    def add_arguments(self, parser):
        parser.add_argument(
            "--import",
            type=str,
            default="",
            dest="import_type",
            help=f"What to import: {', '.join(IMPORT_OPTS)}",
        )
        parser.add_argument(
            "--flush",
            type=str,
            default="",
            help=f"Delete existing data: {', '.join(FLUSH_OPTS)}",
        )
        parser.add_argument(
            "--indicators",
            type=str,
            default="",
            help="Specific indicator codes (comma-separated)",
        )
        parser.add_argument(
            "--category",
            type=str,
            default="",
            help=f"Import data for category: {', '.join([c[0] for c in CATEGORY_CHOICES])}, all",
        )
        parser.add_argument(
            "--start-year",
            type=int,
            default=None,
            help="Start year for data import (default: 2000)",
        )
        parser.add_argument(
            "--end-year",
            type=int,
            default=None,
            help="End year for data import (default: 2024)",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Parse without saving",
        )
        parser.add_argument(
            "--list-indicators",
            action="store_true",
            help="List available indicators in database",
        )
        parser.add_argument(
            "--list-categories",
            action="store_true",
            help="List available categories",
        )
        parser.add_argument(
            "--default-only",
            action="store_true",
            help="Only import default travel-context indicators",
        )

    def handle(self, *args, **options):
        settings = get_worldbank_settings()

        if options["list_categories"]:
            self._list_categories()
            return

        if options["list_indicators"]:
            self._list_indicators(options.get("category"))
            return

        import_type = options["import_type"]
        flush_type = options["flush"]

        if not import_type and not flush_type:
            self.stdout.write(self.style.WARNING("Use --import=all or --help"))
            return

        if flush_type:
            self._handle_flush(flush_type)

        if import_type:
            self._handle_import(import_type, options)

    def _list_categories(self):
        """List available indicator categories."""
        self.stdout.write("\nAvailable categories:")
        for code, name in CATEGORY_CHOICES:
            count = Indicator.objects.filter(category=code).count()
            self.stdout.write(f"  {code:15} - {name} ({count} indicators)")

        self.stdout.write("\nDefault indicators (travel context):")
        settings = get_worldbank_settings()
        for code in settings.default_indicators:
            try:
                ind = Indicator.objects.get(code=code)
                self.stdout.write(f"  {code:20} - {ind.name[:50]}")
            except Indicator.DoesNotExist:
                self.stdout.write(f"  {code:20} - (not yet imported)")

    def _list_indicators(self, category: str = None):
        """List indicators, optionally filtered by category."""
        qs = Indicator.objects.all()
        if category:
            qs = qs.filter(category=category)

        self.stdout.write(f"\nIndicators ({qs.count()} total):")
        for ind in qs[:100]:  # Limit output
            self.stdout.write(f"  {ind.code:25} [{ind.category:12}] {ind.name[:40]}")

        if qs.count() > 100:
            self.stdout.write(f"  ... and {qs.count() - 100} more")

    def _handle_flush(self, flush_type):
        """Handle flush operations."""
        flush_types = [f.strip() for f in flush_type.split(",")]
        if "all" in flush_types:
            targets = FLUSH_OPTS_ALL
        else:
            targets = flush_types

        for target in targets:
            self._flush(target)

    def _flush(self, target):
        """Flush a specific data type."""
        self.stdout.write(f"Flushing {target}...")
        models = {
            "country": Country,
            "indicator": Indicator,
            "data": IndicatorValue,
        }
        if target in models:
            count = models[target].objects.all().delete()[0]
            self.stdout.write(f"  Deleted {count}")

    def _handle_import(self, import_type, options):
        """Handle import operations."""
        import_types = [t.strip() for t in import_type.split(",")]

        if "all" in import_types:
            targets = IMPORT_OPTS_ALL
        else:
            targets = import_types

        # Parse indicator options
        indicator_codes = None
        if options.get("indicators"):
            indicator_codes = [i.strip() for i in options["indicators"].split(",")]
            options["indicator_codes"] = indicator_codes

        # Parse category options
        if options.get("category"):
            categories = [c.strip() for c in options["category"].split(",")]
            options["categories"] = categories

        # Year range
        settings = get_worldbank_settings()
        if options.get("start_year"):
            options["start_year"] = options["start_year"]
        else:
            options["start_year"] = settings.start_year

        if options.get("end_year"):
            options["end_year"] = options["end_year"]
        else:
            options["end_year"] = settings.end_year

        total_stats = {"processed": 0, "created": 0, "updated": 0, "skipped": 0, "errors": 0}

        # Import in dependency order
        order = ["country", "indicator", "data"]
        for target in order:
            if target in targets:
                self._run_importer(target, options, total_stats)

        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Import complete!"))
        self.stdout.write(f"  Processed: {total_stats['processed']}")
        self.stdout.write(f"  Created:   {total_stats['created']}")
        self.stdout.write(f"  Updated:   {total_stats['updated']}")
        self.stdout.write(f"  Skipped:   {total_stats['skipped']}")

    def _run_importer(self, target, options, total_stats):
        """Run a specific importer."""
        importer_class = self.IMPORTERS.get(target)
        if not importer_class:
            return

        self.stdout.write(f"Importing {target}...")
        try:
            importer = importer_class(self, options)
            stats = importer.run()
            for key in total_stats:
                total_stats[key] += stats.get(key, 0)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Failed: {e}"))
            raise CommandError(str(e)) from e
