"""
Plugin system for World Bank import customization.

Available Hooks:
    country_pre, country_post
    indicator_pre, indicator_post
    data_pre, data_post
"""

from ..exceptions import HookException

__all__ = ["HookException"]
