"""Django models for World Bank data."""

from django.db import models

from .conf import CATEGORY_CHOICES, Category


class Country(models.Model):
    """World Bank country or region."""

    INCOME_LEVEL_CHOICES = [
        ("HIC", "High income"),
        ("UMC", "Upper middle income"),
        ("LMC", "Lower middle income"),
        ("LIC", "Low income"),
        ("INX", "Not classified"),
    ]

    LENDING_TYPE_CHOICES = [
        ("IBD", "IBRD"),
        ("IDB", "IDA & IBRD blend"),
        ("IDX", "IDA"),
        ("LNX", "Not classified"),
    ]

    # Identifiers
    iso2_code = models.CharField(
        max_length=2,
        unique=True,
        db_index=True,
        verbose_name="ISO2 code",
        help_text="ISO 3166-1 alpha-2 country code",
    )
    iso3_code = models.CharField(
        max_length=3,
        db_index=True,
        blank=True,
        verbose_name="ISO3 code",
        help_text="ISO 3166-1 alpha-3 country code",
    )
    name = models.CharField(
        max_length=200,
        db_index=True,
        verbose_name="name",
    )

    # Classification
    region_code = models.CharField(
        max_length=10,
        blank=True,
        db_index=True,
        verbose_name="region code",
    )
    region_name = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="region name",
    )
    admin_region_code = models.CharField(
        max_length=10,
        blank=True,
        verbose_name="admin region code",
    )
    admin_region_name = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="admin region name",
    )
    income_level = models.CharField(
        max_length=3,
        choices=INCOME_LEVEL_CHOICES,
        blank=True,
        db_index=True,
        verbose_name="income level",
    )
    income_level_name = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="income level name",
    )
    lending_type = models.CharField(
        max_length=3,
        choices=LENDING_TYPE_CHOICES,
        blank=True,
        verbose_name="lending type",
    )
    lending_type_name = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="lending type name",
    )

    # Location
    capital_city = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="capital city",
    )
    latitude = models.FloatField(
        null=True,
        blank=True,
        verbose_name="latitude",
    )
    longitude = models.FloatField(
        null=True,
        blank=True,
        verbose_name="longitude",
    )

    # Metadata
    is_aggregate = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name="is aggregate",
        help_text="Whether this is an aggregate region (not a country)",
    )

    class Meta:
        verbose_name = "country"
        verbose_name_plural = "countries"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.iso2_code})"


class Indicator(models.Model):
    """World Bank indicator metadata."""

    code = models.CharField(
        max_length=50,
        unique=True,
        db_index=True,
        verbose_name="indicator code",
    )
    name = models.CharField(
        max_length=500,
        verbose_name="name",
    )
    description = models.TextField(
        blank=True,
        verbose_name="description",
    )
    source_note = models.TextField(
        blank=True,
        verbose_name="source note",
    )
    source_organization = models.TextField(
        blank=True,
        verbose_name="source organization",
    )

    # Classification
    category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        default=Category.OTHER,
        db_index=True,
        verbose_name="category",
    )

    # World Bank topic hierarchy
    topic_id = models.CharField(
        max_length=20,
        blank=True,
        verbose_name="topic ID",
    )
    topic_name = models.CharField(
        max_length=200,
        blank=True,
        verbose_name="topic name",
    )

    # Unit info (if parseable from description)
    unit = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="unit",
    )

    class Meta:
        verbose_name = "indicator"
        verbose_name_plural = "indicators"
        ordering = ["category", "name"]
        indexes = [
            models.Index(fields=["category", "code"]),
        ]

    def __str__(self):
        return f"{self.code}: {self.name[:50]}"


class IndicatorValue(models.Model):
    """World Bank indicator data value."""

    country = models.ForeignKey(
        Country,
        on_delete=models.CASCADE,
        related_name="indicator_values",
        verbose_name="country",
    )
    indicator = models.ForeignKey(
        Indicator,
        on_delete=models.CASCADE,
        related_name="values",
        verbose_name="indicator",
    )
    year = models.PositiveSmallIntegerField(
        db_index=True,
        verbose_name="year",
    )
    value = models.FloatField(
        null=True,
        blank=True,
        verbose_name="value",
    )
    decimal = models.PositiveSmallIntegerField(
        default=0,
        verbose_name="decimal precision",
    )

    class Meta:
        verbose_name = "indicator value"
        verbose_name_plural = "indicator values"
        ordering = ["country", "indicator", "-year"]
        unique_together = [("country", "indicator", "year")]
        indexes = [
            models.Index(fields=["indicator", "year"]),
            models.Index(fields=["country", "year"]),
            models.Index(fields=["indicator", "country", "-year"]),
        ]

    def __str__(self):
        return f"{self.country.iso2_code} - {self.indicator.code} ({self.year}): {self.value}"
