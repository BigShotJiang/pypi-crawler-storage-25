"""Configuration for World Bank data import."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from django.conf import settings

LOGGER_NAME = "worldbank"

# API Configuration
BASE_API_URL = "https://api.worldbank.org/v2"
API_ENDPOINTS = {
    "countries": "/country",
    "indicators": "/indicator",
    "data": "/country/{country}/indicator/{indicator}",
}

# Indicator Categories
class Category:
    """Indicator category constants."""

    DEMOGRAPHICS = "demographics"
    TOURISM = "tourism"
    CONNECTIVITY = "connectivity"
    ECONOMY = "economy"
    HEALTH = "health"
    EDUCATION = "education"
    LABOR = "labor"
    GOVERNANCE = "governance"
    POVERTY = "poverty"
    TRADE = "trade"
    ENVIRONMENT = "environment"
    AGRICULTURE = "agriculture"
    OTHER = "other"


CATEGORY_CHOICES = [
    (Category.DEMOGRAPHICS, "Demographics"),
    (Category.TOURISM, "Tourism"),
    (Category.CONNECTIVITY, "Connectivity & Infrastructure"),
    (Category.ECONOMY, "Economy & Cost"),
    (Category.HEALTH, "Health & Safety"),
    (Category.EDUCATION, "Education & Human Capital"),
    (Category.LABOR, "Labor & Employment"),
    (Category.GOVERNANCE, "Governance & Institutions"),
    (Category.POVERTY, "Poverty & Inequality"),
    (Category.TRADE, "Trade, Finance & Aid"),
    (Category.ENVIRONMENT, "Environment & Energy"),
    (Category.AGRICULTURE, "Agriculture & Land Use"),
    (Category.OTHER, "Other"),
]

# Indicator to category mapping
# This maps known indicator codes to their categories
INDICATOR_CATEGORIES = {
    # Demographics
    "SP.POP.TOTL": Category.DEMOGRAPHICS,
    "SP.POP.GROW": Category.DEMOGRAPHICS,
    "EN.POP.DNST": Category.DEMOGRAPHICS,
    "SP.URB.TOTL.IN.ZS": Category.DEMOGRAPHICS,
    "SP.URB.GROW": Category.DEMOGRAPHICS,
    "SP.RUR.TOTL.ZS": Category.DEMOGRAPHICS,
    "SP.POP.65UP.TO.ZS": Category.DEMOGRAPHICS,
    "SP.POP.0014.TO.ZS": Category.DEMOGRAPHICS,
    "SP.DYN.CBRT.IN": Category.DEMOGRAPHICS,
    "SP.DYN.CDRT.IN": Category.DEMOGRAPHICS,

    # Tourism
    "ST.INT.ARVL": Category.TOURISM,
    "ST.INT.DPRT": Category.TOURISM,
    "ST.INT.RCPT.CD": Category.TOURISM,
    "ST.INT.XPND.CD": Category.TOURISM,
    "ST.INT.RCPT.XP.ZS": Category.TOURISM,
    "ST.INT.TVLR.CD": Category.TOURISM,
    "ST.INT.TRNR.CD": Category.TOURISM,

    # Connectivity & Infrastructure
    "IT.NET.USER.ZS": Category.CONNECTIVITY,
    "IT.CEL.SETS.P2": Category.CONNECTIVITY,
    "IT.NET.BBND.P2": Category.CONNECTIVITY,
    "IT.NET.SECR.P6": Category.CONNECTIVITY,
    "EG.ELC.ACCS.ZS": Category.CONNECTIVITY,
    "EG.ELC.ACCS.RU.ZS": Category.CONNECTIVITY,
    "EG.ELC.ACCS.UR.ZS": Category.CONNECTIVITY,
    "IS.AIR.PSGR": Category.CONNECTIVITY,
    "IS.AIR.GOOD.MT.K1": Category.CONNECTIVITY,
    "IS.RRS.PASG.KM": Category.CONNECTIVITY,
    "IS.RRS.GOOD.MT.K6": Category.CONNECTIVITY,
    "IS.SHP.GOOD.TU": Category.CONNECTIVITY,
    "IS.ROD.TOTL.KM": Category.CONNECTIVITY,
    "IS.ROD.PAVE.ZS": Category.CONNECTIVITY,

    # Economy
    "NY.GDP.MKTP.CD": Category.ECONOMY,
    "NY.GDP.MKTP.KD.ZG": Category.ECONOMY,
    "NY.GDP.PCAP.CD": Category.ECONOMY,
    "NY.GDP.PCAP.KD.ZG": Category.ECONOMY,
    "NY.GDP.PCAP.PP.CD": Category.ECONOMY,
    "NY.GNP.PCAP.CD": Category.ECONOMY,
    "NY.GNP.PCAP.PP.CD": Category.ECONOMY,
    "FP.CPI.TOTL.ZG": Category.ECONOMY,
    "PA.NUS.FCRF": Category.ECONOMY,
    "NE.CON.PRVT.ZS": Category.ECONOMY,
    "NE.CON.GOVT.ZS": Category.ECONOMY,
    "NE.GDI.TOTL.ZS": Category.ECONOMY,
    "FI.RES.TOTL.CD": Category.ECONOMY,

    # Health
    "SP.DYN.LE00.IN": Category.HEALTH,
    "SP.DYN.LE00.MA.IN": Category.HEALTH,
    "SP.DYN.LE00.FE.IN": Category.HEALTH,
    "SH.MED.BEDS.ZS": Category.HEALTH,
    "SH.MED.PHYS.ZS": Category.HEALTH,
    "SH.MED.NUMW.P3": Category.HEALTH,
    "SH.XPD.CHEX.GD.ZS": Category.HEALTH,
    "SH.XPD.CHEX.PC.CD": Category.HEALTH,
    "SH.XPD.OOPC.CH.ZS": Category.HEALTH,
    "SP.DYN.IMRT.IN": Category.HEALTH,
    "SH.STA.MMRT": Category.HEALTH,
    "SH.DYN.MORT": Category.HEALTH,
    "SH.IMM.MEAS": Category.HEALTH,
    "SH.STA.BASS.ZS": Category.HEALTH,
    "SH.H2O.BASW.ZS": Category.HEALTH,
    "SH.STA.SMSS.ZS": Category.HEALTH,

    # Education
    "SE.ADT.LITR.ZS": Category.EDUCATION,
    "SE.ADT.LITR.MA.ZS": Category.EDUCATION,
    "SE.ADT.LITR.FE.ZS": Category.EDUCATION,
    "SE.PRM.ENRR": Category.EDUCATION,
    "SE.SEC.ENRR": Category.EDUCATION,
    "SE.TER.ENRR": Category.EDUCATION,
    "SE.PRM.CMPT.ZS": Category.EDUCATION,
    "SE.SEC.CMPT.LO.ZS": Category.EDUCATION,
    "SE.XPD.TOTL.GD.ZS": Category.EDUCATION,
    "SE.XPD.PRIM.ZS": Category.EDUCATION,
    "SE.XPD.SECO.ZS": Category.EDUCATION,
    "SE.ENR.PRIM.FM.ZS": Category.EDUCATION,

    # Labor & Employment
    "SL.TLF.CACT.ZS": Category.LABOR,
    "SL.TLF.CACT.MA.ZS": Category.LABOR,
    "SL.TLF.CACT.FE.ZS": Category.LABOR,
    "SL.UEM.TOTL.ZS": Category.LABOR,
    "SL.UEM.TOTL.MA.ZS": Category.LABOR,
    "SL.UEM.TOTL.FE.ZS": Category.LABOR,
    "SL.UEM.1524.ZS": Category.LABOR,
    "SL.EMP.TOTL.SP.ZS": Category.LABOR,
    "SL.AGR.EMPL.ZS": Category.LABOR,
    "SL.IND.EMPL.ZS": Category.LABOR,
    "SL.SRV.EMPL.ZS": Category.LABOR,
    "SL.EMP.VULN.ZS": Category.LABOR,
    "SL.TLF.TOTL.IN": Category.LABOR,

    # Governance
    "IQ.REG.QUAL.XQ": Category.GOVERNANCE,
    "IQ.RULE.LAW.XQ": Category.GOVERNANCE,
    "IQ.GOV.EFF.XQ": Category.GOVERNANCE,
    "IQ.CPA.TRAN.XQ": Category.GOVERNANCE,
    "IQ.CPA.PROP.XQ": Category.GOVERNANCE,
    "CC.EST": Category.GOVERNANCE,
    "PV.EST": Category.GOVERNANCE,
    "VA.EST": Category.GOVERNANCE,
    "RL.EST": Category.GOVERNANCE,
    "RQ.EST": Category.GOVERNANCE,
    "GE.EST": Category.GOVERNANCE,
    "IC.BUS.EASE.XQ": Category.GOVERNANCE,
    "IC.REG.DURS": Category.GOVERNANCE,

    # Poverty & Inequality
    "SI.POV.DDAY": Category.POVERTY,
    "SI.POV.LMIC": Category.POVERTY,
    "SI.POV.UMIC": Category.POVERTY,
    "SI.POV.NAHC": Category.POVERTY,
    "SI.POV.GINI": Category.POVERTY,
    "SI.DST.FRST.10": Category.POVERTY,
    "SI.DST.10TH.10": Category.POVERTY,
    "SI.SPR.PCAP.ZG": Category.POVERTY,

    # Trade, Finance & Aid
    "NE.EXP.GNFS.ZS": Category.TRADE,
    "NE.EXP.GNFS.CD": Category.TRADE,
    "NE.IMP.GNFS.ZS": Category.TRADE,
    "NE.IMP.GNFS.CD": Category.TRADE,
    "NE.TRD.GNFS.ZS": Category.TRADE,
    "BX.KLT.DINV.CD.WD": Category.TRADE,
    "BX.KLT.DINV.WD.GD.ZS": Category.TRADE,
    "BX.TRF.PWKR.CD.DT": Category.TRADE,
    "BX.TRF.PWKR.DT.GD.ZS": Category.TRADE,
    "DT.ODA.ODAT.CD": Category.TRADE,
    "DT.ODA.ODAT.GN.ZS": Category.TRADE,
    "GC.DOD.TOTL.GD.ZS": Category.TRADE,
    "GC.REV.XGRT.GD.ZS": Category.TRADE,
    "GC.XPN.TOTL.GD.ZS": Category.TRADE,
    "GC.BAL.CASH.GD.ZS": Category.TRADE,
    "BN.CAB.XOKA.GD.ZS": Category.TRADE,
    "FM.LBL.BMNY.GD.ZS": Category.TRADE,
    "FS.AST.DOMS.GD.ZS": Category.TRADE,

    # Environment & Energy
    "EN.ATM.CO2E.PC": Category.ENVIRONMENT,
    "EN.ATM.CO2E.KT": Category.ENVIRONMENT,
    "EN.ATM.CO2E.GF.ZS": Category.ENVIRONMENT,
    "EN.ATM.METH.KT.CE": Category.ENVIRONMENT,
    "EN.ATM.NOXE.KT.CE": Category.ENVIRONMENT,
    "EN.ATM.PM25.MC.M3": Category.ENVIRONMENT,
    "EG.USE.PCAP.KG.OE": Category.ENVIRONMENT,
    "EG.USE.ELEC.KH.PC": Category.ENVIRONMENT,
    "EG.FEC.RNEW.ZS": Category.ENVIRONMENT,
    "EG.ELC.RNEW.ZS": Category.ENVIRONMENT,
    "EG.ELC.FOSL.ZS": Category.ENVIRONMENT,
    "EG.ELC.NUCL.ZS": Category.ENVIRONMENT,
    "EG.ELC.HYRO.ZS": Category.ENVIRONMENT,
    "AG.LND.FRST.ZS": Category.ENVIRONMENT,
    "AG.LND.FRST.K2": Category.ENVIRONMENT,
    "ER.PTD.TOTL.ZS": Category.ENVIRONMENT,
    "ER.MRN.PTMR.ZS": Category.ENVIRONMENT,
    "EN.FSH.THRD.NO": Category.ENVIRONMENT,

    # Agriculture & Land Use
    "AG.LND.TOTL.K2": Category.AGRICULTURE,
    "AG.LND.AGRI.ZS": Category.AGRICULTURE,
    "AG.LND.AGRI.K2": Category.AGRICULTURE,
    "AG.LND.ARBL.ZS": Category.AGRICULTURE,
    "AG.LND.ARBL.HA.PC": Category.AGRICULTURE,
    "AG.LND.CROP.ZS": Category.AGRICULTURE,
    "AG.LND.IRIG.AG.ZS": Category.AGRICULTURE,
    "AG.YLD.CREL.KG": Category.AGRICULTURE,
    "AG.PRD.FOOD.XD": Category.AGRICULTURE,
    "AG.PRD.CROP.XD": Category.AGRICULTURE,
    "AG.PRD.LVSK.XD": Category.AGRICULTURE,
    "NV.AGR.TOTL.ZS": Category.AGRICULTURE,
    "SL.AGR.EMPL.ZS": Category.AGRICULTURE,
    "AG.CON.FERT.ZS": Category.AGRICULTURE,
}

# Default indicators for core travel context (easily modifiable list)
DEFAULT_INDICATORS = [
    # Demographics
    "SP.POP.TOTL",        # Total population
    "EN.POP.DNST",        # Population density
    "SP.URB.TOTL.IN.ZS",  # Urban population %

    # Tourism
    "ST.INT.ARVL",        # International tourist arrivals
    "ST.INT.RCPT.CD",     # Tourism receipts (current US$)

    # Connectivity & Infrastructure
    "IT.NET.USER.ZS",     # Internet users (% of population)
    "IT.CEL.SETS.P2",     # Mobile cellular subscriptions (per 100 people)
    "EG.ELC.ACCS.ZS",     # Access to electricity (% of population)
]

# Extended indicator sets by category (for optional imports)
CATEGORY_INDICATORS = {
    Category.DEMOGRAPHICS: [
        "SP.POP.TOTL", "SP.POP.GROW", "EN.POP.DNST", "SP.URB.TOTL.IN.ZS",
        "SP.URB.GROW", "SP.RUR.TOTL.ZS", "SP.POP.65UP.TO.ZS", "SP.POP.0014.TO.ZS",
        "SP.DYN.CBRT.IN", "SP.DYN.CDRT.IN",
    ],
    Category.TOURISM: [
        "ST.INT.ARVL", "ST.INT.DPRT", "ST.INT.RCPT.CD", "ST.INT.XPND.CD",
        "ST.INT.RCPT.XP.ZS", "ST.INT.TVLR.CD", "ST.INT.TRNR.CD",
    ],
    Category.CONNECTIVITY: [
        "IT.NET.USER.ZS", "IT.CEL.SETS.P2", "IT.NET.BBND.P2", "EG.ELC.ACCS.ZS",
        "EG.ELC.ACCS.RU.ZS", "EG.ELC.ACCS.UR.ZS", "IS.AIR.PSGR",
        "IS.ROD.TOTL.KM", "IS.ROD.PAVE.ZS",
    ],
    Category.ECONOMY: [
        "NY.GDP.MKTP.CD", "NY.GDP.MKTP.KD.ZG", "NY.GDP.PCAP.CD", "NY.GDP.PCAP.PP.CD",
        "NY.GNP.PCAP.CD", "FP.CPI.TOTL.ZG", "PA.NUS.FCRF", "FI.RES.TOTL.CD",
    ],
    Category.HEALTH: [
        "SP.DYN.LE00.IN", "SH.MED.BEDS.ZS", "SH.MED.PHYS.ZS", "SH.XPD.CHEX.GD.ZS",
        "SH.XPD.CHEX.PC.CD", "SP.DYN.IMRT.IN", "SH.STA.MMRT", "SH.IMM.MEAS",
        "SH.STA.BASS.ZS", "SH.H2O.BASW.ZS",
    ],
    Category.EDUCATION: [
        "SE.ADT.LITR.ZS", "SE.PRM.ENRR", "SE.SEC.ENRR", "SE.TER.ENRR",
        "SE.PRM.CMPT.ZS", "SE.XPD.TOTL.GD.ZS",
    ],
    Category.LABOR: [
        "SL.TLF.CACT.ZS", "SL.UEM.TOTL.ZS", "SL.UEM.1524.ZS", "SL.EMP.TOTL.SP.ZS",
        "SL.AGR.EMPL.ZS", "SL.IND.EMPL.ZS", "SL.SRV.EMPL.ZS",
    ],
    Category.GOVERNANCE: [
        "IQ.REG.QUAL.XQ", "IQ.RULE.LAW.XQ", "IQ.GOV.EFF.XQ", "CC.EST",
        "PV.EST", "VA.EST", "IC.BUS.EASE.XQ",
    ],
    Category.POVERTY: [
        "SI.POV.DDAY", "SI.POV.LMIC", "SI.POV.GINI", "SI.DST.FRST.10", "SI.DST.10TH.10",
    ],
    Category.TRADE: [
        "NE.EXP.GNFS.ZS", "NE.IMP.GNFS.ZS", "NE.TRD.GNFS.ZS", "BX.KLT.DINV.CD.WD",
        "BX.TRF.PWKR.CD.DT", "DT.ODA.ODAT.CD", "GC.DOD.TOTL.GD.ZS",
    ],
    Category.ENVIRONMENT: [
        "EN.ATM.CO2E.PC", "EN.ATM.CO2E.KT", "EG.USE.PCAP.KG.OE", "EG.FEC.RNEW.ZS",
        "AG.LND.FRST.ZS", "ER.PTD.TOTL.ZS", "EN.ATM.PM25.MC.M3",
    ],
    Category.AGRICULTURE: [
        "AG.LND.TOTL.K2", "AG.LND.AGRI.ZS", "AG.LND.ARBL.ZS", "AG.YLD.CREL.KG",
        "AG.PRD.FOOD.XD", "NV.AGR.TOTL.ZS", "AG.CON.FERT.ZS",
    ],
}

# Import options
IMPORT_OPTS = ["country", "indicator", "data", "all"]
IMPORT_OPTS_ALL = ["country", "indicator", "data"]
FLUSH_OPTS = ["country", "indicator", "data", "all"]
FLUSH_OPTS_ALL = ["country", "indicator", "data"]


@dataclass
class WorldBankSettings:
    """World Bank import settings."""

    # API settings
    base_url: str = BASE_API_URL
    per_page: int = 1000
    timeout: int = 30

    # Data settings
    data_dir: Path = field(default_factory=lambda: Path.home() / ".worldbank" / "data")
    cache_duration: int = 86400  # 24 hours

    # Import settings
    batch_size: int = 1000
    default_indicators: list = field(default_factory=lambda: DEFAULT_INDICATORS.copy())

    # Year range for data import
    start_year: int = 2000
    end_year: int = 2024

    # Plugin modules
    plugins: list = field(default_factory=list)


def get_worldbank_settings() -> WorldBankSettings:
    """Get World Bank settings from Django settings."""
    user_settings = getattr(settings, "WORLDBANK", {})

    return WorldBankSettings(
        base_url=user_settings.get("BASE_URL", BASE_API_URL),
        per_page=user_settings.get("PER_PAGE", 1000),
        timeout=user_settings.get("TIMEOUT", 30),
        data_dir=Path(user_settings.get("DATA_DIR", Path.home() / ".worldbank" / "data")),
        cache_duration=user_settings.get("CACHE_DURATION", 86400),
        batch_size=user_settings.get("BATCH_SIZE", 1000),
        default_indicators=user_settings.get("DEFAULT_INDICATORS", DEFAULT_INDICATORS.copy()),
        start_year=user_settings.get("START_YEAR", 2000),
        end_year=user_settings.get("END_YEAR", 2024),
        plugins=user_settings.get("PLUGINS", []),
    )


def get_category_for_indicator(code: str) -> str:
    """Get category for an indicator code."""
    return INDICATOR_CATEGORIES.get(code, Category.OTHER)


def get_indicators_for_category(category: str) -> list:
    """Get indicator codes for a category."""
    return CATEGORY_INDICATORS.get(category, [])
