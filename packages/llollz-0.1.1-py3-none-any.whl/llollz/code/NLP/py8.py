
import nltk
import spacy
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
from nltk.chunk import RegexpParser, tree2conlltags

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('maxent_ne_chunker')
nltk.download('words')

try:
    nlp = spacy.load("en_core_web_sm")
except:
    import os
    os.system("python -m spacy download en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")


def safe_pos_tag(tokens):
    try:
        return pos_tag(tokens)
    except Exception as e:
        print("POS tagging failed:", e)
        return [(word, "NN") for word in tokens]


# 1. NLTK CHUNKING
def nltk_chunking_demo(text):
    print("\n NLTK CHUNKING")

    words = word_tokenize(text)
    tagged = safe_pos_tag(words)

    grammar = r"""
        NP: {<DT>?<JJ>*<NN.*>+}
        VP: {<VB.*>+}
        PP: {<IN>}
    """

    cp = RegexpParser(grammar)
    tree = cp.parse(tagged)

    print("\nChunked Tree:")
    print(tree)

    print("\nIOB Tags:")
    try:
        iob = tree2conlltags(tree)
        for t in iob:
            print(t)
    except Exception as e:
        print("IOB conversion error:", e)


# 2. NLTK NER
def nltk_ner_demo(text):
    print("\n NLTK NER")

    words = word_tokenize(text)
    tagged = safe_pos_tag(words)

    try:
        ne_tree = nltk.ne_chunk(tagged)
        print(ne_tree)
    except Exception as e:
        print("NER failed:", e)


# 3. SPACY ANALYSIS
def spacy_analysis_demo(text):
    print("\n SPACY ANALYSIS")
    doc = nlp(text)
    print("\nEntities:")
    for ent in doc.ents:
        print(f"{ent.text:15} :- {ent.label_}")
    print("\nPOS Tags:")
    for token in doc:
        print(f"{token.text:10} :- {token.pos_}")

if __name__ == "__main__":

    sample_sentence = "European authorities fined Google a record $5.1 billion on Wednesday."
    nltk_chunking_demo(sample_sentence)
    nltk_ner_demo(sample_sentence)
    spacy_analysis_demo(sample_sentence)



