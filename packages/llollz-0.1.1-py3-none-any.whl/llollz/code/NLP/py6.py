
#PRACTICAL-6

import nltk
import spacy
from nltk.tokenize import word_tokenize
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import names
import random

nltk.download('punkt')
nltk.download('names')

# 1: NLTK TOKENIZATION
sentence = "The quick brown fox jumped over the lazy dog."
tokens = word_tokenize(sentence)

print("\n NLTK TOKENIZATION")
print(tokens)


# 2: SPACY POS TAGGING
nlp = spacy.load("en_core_web_sm")

text = "The quick brown fox jumps over the lazy dog."
doc = nlp(text)

print("\n SPACY POS TAGGING")
for token in doc:
    print(f"{token.text}: {token.pos_} ({token.dep_})")


# 3: NAIVE BAYES CLASSIFIER

def gender_features(word):
    return {'last_letter': word[-1]}

labeled_names = (
    [(name, 'male') for name in names.words('male.txt')] +
    [(name, 'female') for name in names.words('female.txt')]
)

random.shuffle(labeled_names)
feature_sets = [(gender_features(n), g) for (n, g) in labeled_names]
train_set = feature_sets[500:]
test_set = feature_sets[:500]
classifier = NaiveBayesClassifier.train(train_set)

print("\n NAIVE BAYES CLASSIFIER")
print("Accuracy:", nltk.classify.accuracy(classifier, test_set))
classifier.show_most_informative_features(5)
print("Prediction for 'John':",
      classifier.classify(gender_features('John')))


