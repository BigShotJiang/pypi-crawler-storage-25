
#PRACTICAL-2

import re

# 1. Detect words (ignore punctuation)
text = "Hello, my name is John Doe! I am learning Python, and it's fun 2 much."
word_pattern = r'\b\w+\b'
words = re.findall(word_pattern, text)
print("1. Words:", words)

# 2. Words starting with 'P'
print("\n 2. Detect Specific Word Patterns (Start With 'P')\n")
pattern_start_with_p = r'\bP\w*\b'
p_words = re.findall(pattern_start_with_p, text)
print("Words starting with 'P':", p_words)

# 3. Tokenizing text (including punctuation)
print("\n 3. Tokenizing Text\n")
tokens = re.split(r'(\W+)', text)
tokens = [t.strip() for t in tokens if t.strip()]
print("Tokens:", tokens)

# 4. Detect numbers
print("\n 4. Detecting Numbers\n")
number_pattern = r'\b\d+\b'
numbers = re.findall(number_pattern, text)
print("Numbers:", numbers)

# 5. Extract course data (single line)
print("\n 5. Course Data (Single Line)\n")
raw_data = "101 COM Computers205 MAT Mathematics189 ENG English"
course_pattern_single = r"(\d+)\s*([A-Z]{3})\s*([A-Za-z]+)"
courses_single = re.findall(course_pattern_single, raw_data)
print("Courses (single line):", courses_single)

# 6. Extract course data (multiline)
print("\n 6. Course Data (Multiline)\n")
text_courses = """101 COM Computers
205 MAT Mathematics
189 ENG English"""
course_pattern = r'(\d+)\s*([A-Z]{3})\s*([A-Za-z]{4,})'
courses = re.findall(course_pattern, text_courses)
print("Course Info:", courses)

# 7. Clean spaces
print("\n 7. Remove Extra Spaces \n")
clean_spaces = re.sub(r" +", " ", text_courses)
clean_spaces = re.sub(r" *\n *", "\n", clean_spaces)
print("Cleaned spaces:\n", clean_spaces)

# 8. Extract emails
print("\n 8. Email Extraction \n")
emails = """zuck26@facebook.com
page33@google.com
jeff42@amazon.com"""
email_pattern = r'(\w+)@([A-Za-z0-9]+)\.([A-Za-z]{2,4})'
email_matches = re.findall(email_pattern, emails)
print("Emails:", email_matches)

# 9. Clean tweet
print("\n 9. Clean Tweet\n")
tweet = '''Good advice! RT @TheNextWeb: What I would do differently if I was 
learning to code today http://t.co/lbwej0pxOd cc: @garybernhardt #rstats'''
def clean_tweet(t):
    t = re.sub(r"http\S+", "", t)        # remove URLs
    t = re.sub(r"#\S+", "", t)           # remove hashtags
    t = re.sub(r"\bRT\b|\bcc\b", "", t)  # remove RT, cc
    t = re.sub(r"@\S+", "", t)           # remove mentions
    t = re.sub(r"[^\w\s]", "", t)        # remove punctuation
    t = re.sub(r"\s+", " ", t).strip()   # remove extra spaces
    return t
print("Cleaned Tweet:", clean_tweet(tweet))

# 10. Colour / Color
print("\n 10. Colour & Color\n")
color_text = "I like Colour but others prefer color or COLOR."
color_matches = re.findall(r'\b[Cc]olou?r\b', color_text)
print("Colour/Color words:", color_matches)

# 11. Words starting with B/b
print("\n 11. Words Starting With B/b\n")
paragraph = "Bob bought a big brown bag before breakfast in Berlin."
b_words = re.findall(r'\b[bB]\w*\b', paragraph)
print("Words starting with B/b:", b_words)

# 12. Substitution examples
print("\n 12. Substitution Examples\n")
sub_text = "Heeellooo wooorld 123!!!"
# A. Remove repeated letters
sub1 = re.sub(r'(.)\1+', r'\1', sub_text)
# B. Replace digits with #
sub2 = re.sub(r'\d', '#', sub_text)
# C. Remove multiple spaces
sub3 = re.sub(r'\s+', ' ', sub_text)
print("Remove repeated characters:", sub1)
print("Replace digits:", sub2)
print("Remove multiple spaces:", sub3)

