
import sys
if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol

import jneqsim.neqsim.process.electricaldesign
import jneqsim.neqsim.process.equipment
import typing



class PumpElectricalDesign(jneqsim.neqsim.process.electricaldesign.ElectricalDesign):
    def __init__(self, processEquipmentInterface: jneqsim.neqsim.process.equipment.ProcessEquipmentInterface): ...
    def readDesignSpecifications(self) -> None: ...


class __module_protocol__(Protocol):
    # A module protocol which reflects the result of ``jp.JPackage("jneqsim.neqsim.process.electricaldesign.pump")``.

    PumpElectricalDesign: typing.Type[PumpElectricalDesign]
