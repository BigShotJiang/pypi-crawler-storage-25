
import sys
if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol

import jneqsim.neqsim.mcp.catalog
import jneqsim.neqsim.mcp.model
import jneqsim.neqsim.mcp.runners
import typing


class __module_protocol__(Protocol):
    # A module protocol which reflects the result of ``jp.JPackage("jneqsim.neqsim.mcp")``.

    catalog: jneqsim.neqsim.mcp.catalog.__module_protocol__
    model: jneqsim.neqsim.mcp.model.__module_protocol__
    runners: jneqsim.neqsim.mcp.runners.__module_protocol__
