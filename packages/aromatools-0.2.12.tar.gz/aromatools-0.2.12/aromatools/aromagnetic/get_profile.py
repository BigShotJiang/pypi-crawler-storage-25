#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import sys
import subprocess
import numpy as np
import networkx as nx
from ase import io
from ase.data import atomic_numbers, covalent_radii

# AromaTools modules
from .tools import orient
from .amg_read_input import read_input
from .amg_write_inputs import make_inputs, flatten_cfg
from . import pseudo_pi

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def _truthy(val):
    return str(val).strip().upper() in ("YES", "Y", "TRUE", "T", "1", "ON")

def _only_ch(ase_atoms):
    syms = [s.upper() for s in ase_atoms.get_chemical_symbols()]
    return all(s in ("C", "H") for s in syms)

def _gen_used(keyword_line: str) -> bool:
    if not keyword_line:
        return False
    return re.search(r"\bgen(ecp)?\b", keyword_line, flags=re.IGNORECASE) is not None

def setup_molGraph(symbols, coords, bond_tol=0.4):
    G = nx.Graph()
    n = len(symbols)
    G.add_nodes_from(range(n))
    Z = [atomic_numbers[s] for s in symbols]
    Rcov = [covalent_radii[z] for z in Z]

    for i in range(n):
        for j in range(i):
            d_act = float(np.linalg.norm(coords[i] - coords[j]))
            d_cov = float(Rcov[i] + Rcov[j])
            if (d_act - d_cov) <= bond_tol:
                G.add_edge(i, j)

    return G

def get_cycles(symbols, coords, bond_tol=0.4):
    G = setup_molGraph(symbols, coords, bond_tol=bond_tol)
    cycles = nx.minimum_cycle_basis(G)
    return cycles

def ring_center(coords, atom_indices):
    ring_coords = coords[np.array(atom_indices, dtype=int)]
    return ring_coords.mean(axis=0)

def ring_normal(atom_coords):
    if len(atom_coords) < 3:
        raise ValueError("At least 3 ring atoms are required to compute a normal vector.")

    v1 = atom_coords[1] - atom_coords[0]
    v2 = atom_coords[2] - atom_coords[0]
    nvec = np.cross(v1, v2)
    norm = float(np.linalg.norm(nvec))
    if norm == 0.0:
        raise ValueError("Normal vector is zero (degenerate ring geometry).")
    return nvec / norm

def build_profile_points(center, normal_vec, profile_block):
    pts = []
    zhat = np.array([0.0, 0.0, 1.0], float)
    if float(np.dot(normal_vec, zhat)) < 0.0:
        normal_vec = -normal_vec
    scale = str(profile_block.get("SCALE", "Linear")).strip().upper()
    if scale == "LINEAR":
        start = float(profile_block.get("START", 0.0))
        dz = float(profile_block.get("DELTA_Z", 0.1))
        npts = int(profile_block.get("NUM_GA", 100))
        if npts < 1:
            raise ValueError("NUM_GA must be >= 1 for Linear scale.")
        for i in range(npts):
            disp = start + i * dz
            pts.append(center + disp * normal_vec)
    elif scale == "LOGARITHMIC":
        start = float(profile_block.get("START", 0.1))
        end = float(profile_block.get("END", 5.0))
        npts = int(profile_block.get("NUM_GA", 100))
        if start <= 0.0 or end <= 0.0:
            raise ValueError("START and END must be > 0 for Logarithmic scale.")
        if end <= start:
            raise ValueError("END must be > START for Logarithmic scale.")
        if npts < 2:
            raise ValueError("NUM_GA must be >= 2 for Logarithmic scale.")
        zpos = np.logspace(np.log10(start), np.log10(end), npts)
        for z in zpos:
            pts.append(center + float(z) * normal_vec)
    else:
        raise ValueError("SCALE must be Linear or Logarithmic (case-insensitive).")
    return [np.array(p, float) for p in pts]

def write_profiles_xyz(path, ase_atoms, all_profile_pts):
    real_syms = ase_atoms.get_chemical_symbols()
    real_xyz = ase_atoms.get_positions()
    n_total = len(real_syms) + len(all_profile_pts)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{n_total}\n")
        f.write("Real atoms + profile points (X)\n")
        for sym, (x, y, z) in zip(real_syms, real_xyz):
            f.write(f"{sym:<2s} {x:14.8f} {y:14.8f} {z:14.8f}\n")
        for (x, y, z) in all_profile_pts:
            f.write(f"X  {x:14.8f} {y:14.8f} {z:14.8f}\n")

def main():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit("ERROR: INPUT.txt not found in current directory")

    general = cfg.get("general", {})
    profile = cfg.get("PROFILE", {})
    name = str(general.get("NAME_MOLECULE", "molecule")).strip()
    xyz_file = general.get("MOLECULAR_COORDINATES", None)
    if not xyz_file:
        raise SystemExit("ERROR: MOLECULAR_COORDINATES must be defined in INPUT.txt")
    if not os.path.isfile(xyz_file):
        raise SystemExit(f"ERROR: XYZ file not found: {xyz_file}")
    kline = str(general.get("KEYWORD_LINE", "")).strip()
    gen_flag = _gen_used(kline)
    if gen_flag and not os.path.isfile("basis.txt"):
        raise SystemExit(
            "\n[ERROR] KEYWORD_LINE contains 'GEN'/'GENECP' but 'basis.txt' was not found.\n"
            "Create 'basis.txt' in the current directory with your generic basis block, then rerun.\n"
        )

    ats, _, _, _, _ = orient(xyz_file, margin=0.0)
    oriented_xyz = f"{name}_oriented.xyz"
    io.write(oriented_xyz, ats, format="xyz")
    symbols = ats.get_chemical_symbols()
    coords = ats.get_positions()
    bond_tol = float(profile.get("BOND_TOL", 0.4))
    cycles = get_cycles(symbols, coords, bond_tol=bond_tol)
    if not cycles:
        raise SystemExit("ERROR: No rings detected. PROFILE module requires at least one ring.")

    print("\n=== GET PROFILE (prepare) ===")
    print(f"Molecule: {name}")
    print(f"XYZ original : {xyz_file}")
    print(f"XYZ oriented: {oriented_xyz}")
    print(f"Rings detected: {len(cycles)}")
    print(f"Bond tol (Å): {bond_tol}")
    print("Profile normal is oriented with fixed reference field (0,0,1).")
    cfg_flat = flatten_cfg(cfg, section="PROFILE")
    all_profile_pts = []
    created_inputs = []
    for rid, atom_indices in enumerate(cycles):
        center = ring_center(coords, atom_indices)
        ring_coords = coords[np.array(atom_indices, dtype=int)]
        nvec = ring_normal(ring_coords)
        pts = build_profile_points(center, nvec, profile)
        all_profile_pts.extend([p.tolist() for p in pts])
        cfg_ring = dict(cfg_flat)
        cfg_ring["da_max"] = max(1, int(len(pts)))
        cfg_ring["name_molecule"] = f"{name}_ring{rid:04d}"
        n_written = make_inputs(cfg_ring["name_molecule"], ats, pts, cfg_ring)
        if n_written > 0:
            created_inputs.append(f"{cfg_ring['name_molecule']}")
        print(f"[ok] ring {rid:04d}: atoms={len(atom_indices)} profile_pts={len(pts)} inputs={n_written}")
    profiles_xyz = f"{name}_profiles.xyz"
    write_profiles_xyz(profiles_xyz, ats, all_profile_pts)
    print(f"[ok] Wrote profiles XYZ: {profiles_xyz}")

    if gen_flag:
        try:
            insert_script = os.path.join(SCRIPT_DIR, "insert_basis.py")
            subprocess.check_call([sys.executable, insert_script])
            print("[ok] basis.txt appended automatically to generated inputs (GEN/GENECP).")
        except Exception as e:
            raise SystemExit(
                f"\n[ERROR] GEN basis insertion failed: {e}\n"
                "You can run it manually: python insert_basis.py\n"
            )
    pseudo_pi_flag = _truthy(general.get("PSEUDO_PI", "NO"))
    if pseudo_pi_flag:
        if _only_ch(ats):
            try:
                pseudo_pi.main()
                print("[ok] pseudo_pi applied to generated inputs (CH-only).")
            except Exception as e:
                raise SystemExit(f"\n[ERROR] pseudo_pi failed: {e}\n")
        else:
            print("[info] PSEUDO_PI=YES but molecule is not CH-only. Skipping pseudo_pi.")

    print("\nDone. Inputs for profiles are ready.")

if __name__ == "__main__":
    main()

