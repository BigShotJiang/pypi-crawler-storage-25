#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import sys
import math
import numpy as np
import matplotlib.pyplot as plt
from ase import io as ase_io

# AromaTools modules
from . import extrac_values
from .amg_read_input import read_input

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

MU_0 = 4.0 * math.pi * 1.0e-7
BOHR_M = 5.29177210903e-11
PROP_1_OVER_MU0 = (1.0 / MU_0) * BOHR_M * 1.0e3

def _truthy(val):
    return str(val).strip().upper() in ("YES", "Y", "TRUE", "T", "1", "ON")


def romberg(f, a, b, tol=1e-6, max_iter=20):
    R = [[0.5 * (b - a) * (f(a) + f(b))]]
    n = 1
    iteration = 0

    while True:
        iteration += 1
        if iteration > max_iter:
            return R[-1][-1], iteration

        h = (b - a) / (2 ** n)
        sum_f = 0.0
        for k in range(1, 2 ** (n - 1) + 1):
            sum_f += f(a + (2 * k - 1) * h)

        R.append([0.5 * R[n - 1][0] + h * sum_f])

        for m in range(1, n + 1):
            R[n].append(R[n][m - 1] + (R[n][m - 1] - R[n - 1][m - 1]) / (4 ** m - 1))

        if abs(R[n][n] - R[n - 1][n - 1]) < tol:
            return R[n][n], iteration

        n += 1

def build_distances(profile_block):
    scale = str(profile_block.get("SCALE", "Linear")).strip().upper()

    if scale == "LINEAR":
        start = float(profile_block.get("START", 0.0))
        dz = float(profile_block.get("DELTA_Z", 0.1))
        npts = int(profile_block.get("NUM_GA", 100))
        return [start + i * dz for i in range(npts)]

    if scale == "LOGARITHMIC":
        start = float(profile_block.get("START", 0.1))
        end = float(profile_block.get("END", 5.0))
        npts = int(profile_block.get("NUM_GA", 100))
        zpos = np.logspace(np.log10(start), np.log10(end), npts)
        return [float(z) for z in zpos]

    raise SystemExit("ERROR: PROFILE:SCALE must be Linear or Logarithmic")

def save_csv(prefix, distances, bindz, nics):
    csv_name = f"{prefix}.csv"
    with open(csv_name, "w", encoding="utf-8") as f:
        f.write("distance_A,Bindz_ppm,NICS_ppm\n")
        for d, b, n in zip(distances, bindz, nics):
            f.write(f"{d:.8f},{b:.8f},{n:.8f}\n")
    return csv_name

def plot_profile(prefix, x, y, ylabel):
    png = f"{prefix}_{ylabel.replace(' ', '_')}.png"
    plt.figure()
    plt.plot(x, y)
    plt.xlabel("Distance (Å)")
    plt.ylabel(ylabel)
    plt.title(f"{prefix}: {ylabel} vs Distance")
    plt.tight_layout()
    plt.savefig(png, dpi=200)
    plt.close()
    return png

def integrate_series(x, y, tol=1e-6):
    x = np.array(x, float)
    y = np.array(y, float)

    def f(t):
        return float(np.interp(t, x, y))

    val, it = romberg(f, float(x.min()), float(x.max()), tol=tol)
    return float(val), int(it)

def ring_current_from_bindz(integral_bindz, symmetry=2.0):
    factor = PROP_1_OVER_MU0 * float(symmetry)
    return float(-factor * integral_bindz)

def find_ring_csvs(name):
    rx = re.compile(rf"^({re.escape(name)}_ring\d{{4}})\.csv$", re.IGNORECASE)
    csvs = []
    for fn in os.listdir(os.getcwd()):
        m = rx.match(fn)
        if m:
            csvs.append(fn)
    csvs.sort()
    return csvs

def read_profile_csv(csv_file):
    dist = []
    bindz = []
    nics = []
    with open(csv_file, "r", encoding="utf-8", errors="ignore") as f:
        header = f.readline()  # distance_A,Bindz_ppm,NICS_ppm
        for line in f:
            if not line.strip():
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 2:
                continue
            dist.append(float(parts[0]))
            bindz.append(float(parts[1]))

            if len(parts) >= 3 and parts[2] != "":
                nics.append(float(parts[2]))
            else:
                nics.append(float("nan"))
    return dist, bindz, nics

def main():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit("ERROR: INPUT.txt not found")
    
    extrac_values.main()
    general = cfg.get("general", {})
    profile = cfg.get("PROFILE", {})
    name = str(general.get("NAME_MOLECULE", "molecule")).strip()
    program = str(general.get("PROGRAM", "orca")).strip().lower()
    xyz_file = general.get("MOLECULAR_COORDINATES", None)

    if not xyz_file or not os.path.isfile(xyz_file):
        raise SystemExit("ERROR: MOLECULAR_COORDINATES must exist for profile analysis.")
    
    csv_files = find_ring_csvs(name)
    if not csv_files:
        raise SystemExit(f"ERROR: No ring CSV files found for {name}. Expected: {name}_ring####.csv")

    block = [
        "==========================================\n",
        "        Integral Analysis Summary         \n",
        "==========================================\n",
        f"Molecule            : {name}\n",
        f"Program             : {program}\n",
        f"XYZ                 : {xyz_file}\n",
        f"CSV files found     : {len(csv_files)}\n",
        "\n"
    ]

    for csv_file in csv_files:

        prefix = os.path.splitext(csv_file)[0]
        print(f"[info] Processing {prefix} from {csv_file}")
        dist, bindz, nics = read_profile_csv(csv_file)
        npts = len(dist)

        if npts < 2:
            print(f"[warn] {prefix}: not enough points for integration. Skipping.")
            block.append(f"{prefix}\n")
            block.append("  Status                 : skipped (not enough points)\n\n")
            continue

        x0 = float(dist[0])
        x1 = float(dist[-1])
        step_A = float(dist[1] - dist[0]) if npts >= 2 else float("nan")

        block.append(f"{prefix}\n")
        block.append("------------------------------------------\n")
        block.append(f"CSV file                : {csv_file}\n")
        block.append(f"Points                  : {npts}\n")
        block.append(f"Distance range [Å]      : {x0:.6f} -> {x1:.6f}\n")
        block.append(f"Step [Å]                : {step_A:.6f}\n")

        png_bindz = plot_profile(prefix, dist, bindz, "Bindz (ppm)")
        print(f"[ok] Plot: {png_bindz}")
        block.append(f"Bindz plot              : {png_bindz}\n")

        if not all(np.isnan(v) for v in nics):
            png_nics = plot_profile(prefix, dist, nics, "NICS (ppm)")
            print(f"[ok] Plot: {png_nics}")
            block.append(f"NICS plot               : {png_nics}\n")
        else:
            print(f"[info] {prefix}: NICS not available (all NaN). Skipping NICS plot.")
            block.append("NICS plot               : not available\n")

        I_bindz, it = integrate_series(dist, bindz, tol=1e-6)
        factor_rc = PROP_1_OVER_MU0 * 2.0
        current = ring_current_from_bindz(I_bindz, symmetry=4.0)
        block.append(f"Integral Bindz [ppm·Å]  : {I_bindz:.10f}\n")
        block.append(f"Romberg iterations      : {it}\n")
        block.append(f"1/mu0 factor            : {PROP_1_OVER_MU0:.10f}\n")
        # block.append(f"Symmetry factor         : 2.0\n")
        block.append(f"Total factor            : {factor_rc:.10f}\n")
        block.append(f"=========== Ring current [nA/T]     : {current:.10f}===========\n")
        nics_valid = [(d, n) for d, n in zip(dist, nics) if not np.isnan(n)]
        
        if len(nics_valid) >= 2:
            d2 = [p[0] for p in nics_valid]
            n2 = [p[1] for p in nics_valid]
            I_nics, itn = integrate_series(d2, n2, tol=1e-6)
            block.append(f"===========Integral NICS [ppm·Å]   : {I_nics:.10f}===========\n")
            block.append(f"NICS Romberg iterations : {itn}\n")
        else:
            block.append("Integral NICS [ppm·Å]   : not available (missing NICS values)\n")

        block.append("\n")

    with open("int_out.txt", "w", encoding="utf-8") as f:
        f.writelines(block)

    print("[done] Wrote int_out.txt")

if __name__ == "__main__":
    main()

