#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import math
import numpy as np
import matplotlib.pyplot as plt
from ase import io as ase_io
from .amg_read_input import read_input

def _truthy(val):
    return str(val).strip().upper() in ("YES", "Y", "TRUE", "T", "1", "ON")

def _parse_heights(height_raw):
    if isinstance(height_raw, (list, tuple)):
        return [float(h) for h in height_raw]
    return [float(height_raw)]

def best_fit_plane_axes(coords):
    center = coords.mean(axis=0)
    X = coords - center
    _, _, vh = np.linalg.svd(X, full_matrices=False)
    zhat = vh[-1, :]
    zhat = zhat / np.linalg.norm(zhat)
    Xproj = X - (X @ zhat)[:, None] * zhat[None, :]
    C = Xproj.T @ Xproj
    evals, evecs = np.linalg.eigh(C)
    idx = np.argsort(evals)[::-1]
    xhat = evecs[:, idx[0]]
    yhat = evecs[:, idx[1]]
    xhat = xhat - np.dot(xhat, zhat) * zhat
    yhat = yhat - np.dot(yhat, zhat) * zhat
    xhat = xhat / np.linalg.norm(xhat)
    yhat = yhat / np.linalg.norm(yhat)

    if np.dot(np.cross(xhat, yhat), zhat) < 0:
        yhat = -yhat

    return center, xhat, yhat, zhat

def compute_half_range(coords, center, axis_hat, margin):
    rel = coords - center
    proj = rel @ axis_hat
    return float(np.max(np.abs(proj)) + float(margin))

def build_scan_positions(coords, center, axis_hat, margin, npts, delta_x_user):
    half_range_geom = compute_half_range(coords, center, axis_hat, margin)
    half_range_from_step = 0.5 * (npts - 1) * float(delta_x_user)
    half_range = max(half_range_geom, half_range_from_step)
    xs = np.linspace(-half_range, half_range, int(npts))
    return xs.tolist(), half_range

def find_outputs_for_prefix(prefix):
    rx = re.compile(rf"^{re.escape(prefix)}(?:_(\d{{4}}))?\.(out|log)$", re.IGNORECASE)
    items = []
    for fn in os.listdir(os.getcwd()):
        m = rx.match(fn)
        if not m:
            continue
        chunk = m.group(1)
        idx = int(chunk) if chunk is not None else -1
        items.append((idx, fn))
    items.sort(key=lambda x: x[0])
    return [fn for _, fn in items]

# ---------------------------
# Gaussian isotropic extraction (Bq only)
# ---------------------------

def gaussian_bq_isotropic(out_files):
    num = r"[-+]?\d+(?:\.\d+)?(?:[EeDd][-+]?\d+)?"
    rx = re.compile(rf"^\s*(?:\d+\s+)?Bq\b.*?Isotropic\s*=\s*({num})", re.IGNORECASE)
    iso = []
    for fn in out_files:
        with open(fn, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                m = rx.search(line)
                if m:
                    val = m.group(1).replace("D", "E").replace("d", "e")
                    iso.append(float(val))
    return iso

# ---------------------------
# ORCA isotropic extraction (dummy atoms)
# ---------------------------

_float_rx = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?")

def orca_dummy_isotropic(out_files, n_real_atoms):
    iso = []
    for fn in out_files:
        diags = []
        with open(fn, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        i = 0
        while i < len(lines):
            if "Total shielding tensor (ppm):" in lines[i]:
                tensor_lines = []
                for j in range(i + 1, i + 4):
                    if j < len(lines):
                        t = lines[j].strip()
                        if t:
                            tensor_lines.append(t)
                if len(tensor_lines) == 3:
                    r1 = _float_rx.findall(tensor_lines[0])
                    r2 = _float_rx.findall(tensor_lines[1])
                    r3 = _float_rx.findall(tensor_lines[2])
                    if len(r1) >= 3 and len(r2) >= 3 and len(r3) >= 3:
                        xx = float(r1[0]); yy = float(r2[1]); zz = float(r3[2])
                        diags.append((xx, yy, zz))
                i += 4
            else:
                i += 1
        diags = diags[n_real_atoms:]
        for (xx, yy, zz) in diags:
            iso.append((xx + yy + zz) / 3.0)
    return iso

def save_csv(prefix, xvals, nics_vals):
    csv_name = f"{prefix}.csv"
    with open(csv_name, "w", encoding="utf-8") as f:
        f.write("x_A,NICS_microT\n")
        for x, n in zip(xvals, nics_vals):
            f.write(f"{x:.8f},{n:.8f}\n")
    return csv_name

def plot_nics(prefix, xvals, nics_vals):
    png = f"{prefix}.png"
    plt.figure()
    plt.plot(xvals, nics_vals)
    plt.xlabel("Scan coordinate (Å)")
    plt.ylabel("NICS (microT)")
    plt.title(prefix)
    plt.tight_layout()
    plt.savefig(png, dpi=200)
    plt.close()
    return png

def main():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit("ERROR: INPUT.txt not found")

    general = cfg.get("general", {})
    scan = cfg.get("NICS_SCAN_XY", {})
    name = str(general.get("NAME_MOLECULE", "molecule")).strip()
    program = str(general.get("PROGRAM", "orca")).strip().lower()
    xyz_file = general.get("MOLECULAR_COORDINATES")

    if not xyz_file or not os.path.isfile(xyz_file):
        raise SystemExit("ERROR: MOLECULAR_COORDINATES must exist")

    npts = int(scan.get("POINTS", 81))
    margin = float(scan.get("MARGIN", 2.0))
    delta_x = float(scan.get("DELTA_X", 0.25))
    make_y = _truthy(scan.get("MAKE_AXIS_Y", "NO"))
    heights = _parse_heights(scan.get("HEIGHT", 1.0))
    ats = ase_io.read(xyz_file, index=0)
    coords = ats.get_positions()
    center, xhat, yhat, zhat = best_fit_plane_axes(coords)
    xs, _ = build_scan_positions(coords, center, xhat, margin, npts, delta_x)
    ys = None
    if make_y:
        ys, _ = build_scan_positions(coords, center, yhat, margin, npts, delta_x)
    n_real = len(ats)

    print("\n=== NICS-SCAN (analyze) ===")
    print(f"Molecule: {name}")
    print(f"PROGRAM : {program}")
    print(f"POINTS  : {npts}")
    print(f"HEIGHTS : {', '.join(str(h) for h in heights)}")
    print(f"MAKE_AXIS_Y: {'YES' if make_y else 'NO'}\n")

    for h in heights:
        tag = f"h{h:.2f}".replace(".", "p")
        prefix_x = f"{name}_nicsX_{tag}"
        out_files_x = find_outputs_for_prefix(prefix_x)
        if not out_files_x:
            print(f"[warn] No outputs found for {prefix_x}.* (skipping)")
        else:
            if "gaussian" in program:
                iso = gaussian_bq_isotropic(out_files_x)
            elif "orca" in program:
                iso = orca_dummy_isotropic(out_files_x, n_real_atoms=n_real)
            else:
                raise SystemExit("ERROR: PROGRAM must be gaussian or orca")
            n_use = min(len(xs), len(iso))
            if len(iso) != len(xs):
                print(f"[warn] {prefix_x}: expected {len(xs)} points, got {len(iso)} isotropic values. Using {n_use}.")
            nics = [-float(v) for v in iso[:n_use]]
            csv_name = save_csv(prefix_x, xs[:n_use], nics)
            png_name = plot_nics(prefix_x, xs[:n_use], nics)
            print(f"[ok] {prefix_x}: {csv_name}, {png_name}")

        if make_y and ys is not None:
            prefix_y = f"{name}_nicsY_{tag}"
            out_files_y = find_outputs_for_prefix(prefix_y)
            if not out_files_y:
                print(f"[warn] No outputs found for {prefix_y}.* (skipping)")
            else:
                if "gaussian" in program:
                    iso = gaussian_bq_isotropic(out_files_y)
                elif "orca" in program:
                    iso = orca_dummy_isotropic(out_files_y, n_real_atoms=n_real)
                else:
                    raise SystemExit("ERROR: PROGRAM must be gaussian or orca")
                n_use = min(len(ys), len(iso))
                if len(iso) != len(ys):
                    print(f"[warn] {prefix_y}: expected {len(ys)} points, got {len(iso)} isotropic values. Using {n_use}.")
                nics = [-float(v) for v in iso[:n_use]]
                csv_name = save_csv(prefix_y, ys[:n_use], nics)
                png_name = plot_nics(prefix_y, ys[:n_use], nics)
                print(f"[ok] {prefix_y}: {csv_name}, {png_name}")

    print("\nDone.")

if __name__ == "__main__":
    main()


