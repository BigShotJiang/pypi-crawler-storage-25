#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import sys
import subprocess
import numpy as np
from ase import io as ase_io

# AromaTools modules
from .tools import orient
from .amg_read_input import read_input
from .amg_write_inputs import make_inputs, flatten_cfg
from . import pseudo_pi

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def _truthy(val):
    return str(val).strip().upper() in ("YES", "Y", "TRUE", "T", "1", "ON")

def _only_ch(ase_atoms):
    syms = [s.upper() for s in ase_atoms.get_chemical_symbols()]
    return all(s in ("C", "H") for s in syms)

def _gen_used(keyword_line: str) -> bool:
    if not keyword_line:
        return False
    return re.search(r"\bgen(ecp)?\b", keyword_line, flags=re.IGNORECASE) is not None

def best_fit_plane_axes(coords):
    center = coords.mean(axis=0)
    X = coords - center

    # SVD: smallest singular vector is plane normal
    _, _, vh = np.linalg.svd(X, full_matrices=False)
    zhat = vh[-1, :]
    zhat = zhat / np.linalg.norm(zhat)

    # Project onto plane
    Xproj = X - (X @ zhat)[:, None] * zhat[None, :]

    # In-plane PCA: take two principal directions in plane
    C = Xproj.T @ Xproj
    evals, evecs = np.linalg.eigh(C)

    # Sort descending
    idx = np.argsort(evals)[::-1]
    xhat = evecs[:, idx[0]]
    yhat = evecs[:, idx[1]]

    # Ensure xhat and yhat are in plane (numerically)
    xhat = xhat - np.dot(xhat, zhat) * zhat
    yhat = yhat - np.dot(yhat, zhat) * zhat
    xhat = xhat / np.linalg.norm(xhat)
    yhat = yhat / np.linalg.norm(yhat)

    # Right-handed consistency (optional but nice)
    if np.dot(np.cross(xhat, yhat), zhat) < 0:
        yhat = -yhat

    return center, xhat, yhat, zhat

def compute_half_range(coords, center, axis_hat, margin):
    rel = coords - center
    proj = rel @ axis_hat
    return float(np.max(np.abs(proj)) + float(margin))

def generate_scan_points(center, xhat, zhat, half_range, npts, height):
    xs = np.linspace(-half_range, half_range, int(npts))
    pts = [center + x * xhat + float(height) * zhat for x in xs]
    return xs.tolist(), [np.array(p, float) for p in pts]

def write_nics_xyz(path, ase_atoms, ptsX, ptsY=None):
    ptsY = ptsY or []
    real_syms = ase_atoms.get_chemical_symbols()
    real_xyz = ase_atoms.get_positions()
    n_total = len(real_syms) + len(ptsX) + len(ptsY)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{n_total}\n")
        f.write("Real atoms + NICS-scan points (X)\n")
        for sym, (x, y, z) in zip(real_syms, real_xyz):
            f.write(f"{sym:<2s} {x:14.8f} {y:14.8f} {z:14.8f}\n")
        for p in ptsX:
            x, y, z = p
            f.write(f"X  {x:14.8f} {y:14.8f} {z:14.8f}\n")
        for p in ptsY:
            x, y, z = p
            f.write(f"X  {x:14.8f} {y:14.8f} {z:14.8f}\n")

def main():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit("ERROR: INPUT.txt not found in current directory")

    general = cfg.get("general", {})
    scan = cfg.get("NICS_SCAN_XY", {})
    name = str(general.get("NAME_MOLECULE", "molecule")).strip()
    xyz_file = general.get("MOLECULAR_COORDINATES", None)
    if not xyz_file:
        raise SystemExit("ERROR: MOLECULAR_COORDINATES must be defined in INPUT.txt")
    if not os.path.isfile(xyz_file):
        raise SystemExit(f"ERROR: XYZ file not found: {xyz_file}")
    npts = int(scan.get("POINTS", 81))
    margin = float(scan.get("MARGIN", 2.0))
    height_raw = scan.get("HEIGHT", 1.0)
    if isinstance(height_raw, (list, tuple)):
        heights = [float(h) for h in height_raw]
    else:
        heights = [float(height_raw)]
    delta_x_user = float(scan.get("DELTA_X", 0.25))
    make_y = _truthy(scan.get("MAKE_AXIS_Y", "NO"))
    if npts < 2:
        raise SystemExit("ERROR: POINTS must be >= 2 for NICS-scan")
    ats, _, _, _, _ = orient(xyz_file, margin=0.0)
    oriented_xyz = f"{name}_oriented.xyz"
    ase_io.write(oriented_xyz, ats, format="xyz")
    coords = ats.get_positions()
    center = coords.mean(axis=0)
    xhat = np.array([1.0, 0.0, 0.0])
    yhat = np.array([0.0, 1.0, 0.0])
    zhat = np.array([0.0, 0.0, 1.0])
    half_range_geom_x = compute_half_range(coords, center, xhat, margin)
    half_range_from_step = 0.5 * (npts - 1) * delta_x_user
    half_range = max(half_range_geom_x, half_range_from_step)
    delta_x_eff = (2.0 * half_range) / (npts - 1)

    print("\n=== NICS-SCAN (prepare) ===")
    print(f"Molecule: {name}")
    print(f"XYZ original : {xyz_file}")
    print(f"XYZ orientado: {oriented_xyz}")
    print("Plane   : inertia-oriented Cartesian XY")
    print(f"HEIGHT  : {height_raw} Å (along +normal)")
    print(f"MARGIN  : {margin} Å")
    print(f"POINTS  : {npts}")
    print(f"DELTA_X (input): {delta_x_user} Å")
    print(f"DELTA_X (used) : {delta_x_eff:.6f} Å")
    if half_range > half_range_from_step + 1e-9:
        print("[warn] POINTS and DELTA_X did not cover the molecule+MARGIN; range was expanded, DELTA_X adjusted.")

    cfg_flat = flatten_cfg(cfg, section="GRID")
    cfg_flat["da_max"] = npts
    all_pts_for_xyz = []  # for visualization xyz (optional)
    half_range_y = None
    if make_y:
        half_range_geom_y = compute_half_range(coords, center, yhat, margin)
        half_range_y = max(half_range_geom_y, half_range_from_step)
    for h in heights:
        xs, ptsX = generate_scan_points(center, xhat, zhat, half_range, npts, h)
        all_pts_for_xyz.extend([p.tolist() for p in ptsX])
        cfg_x = dict(cfg_flat)
        cfg_x["name_molecule"] = f"{name}_nicsX_h{h:.2f}".replace(".", "p")
        cfg_x["da_max"] = npts
        make_inputs(cfg_x["name_molecule"], ats, ptsX, cfg_x)
        print(f"[ok] Inputs for X-scan generated (height={h} Å) prefix: {cfg_x['name_molecule']}")
        if make_y:
            ys, ptsY = generate_scan_points(center, yhat, zhat, half_range_y, npts, h)
            all_pts_for_xyz.extend([p.tolist() for p in ptsY])
            cfg_y = dict(cfg_flat)
            cfg_y["name_molecule"] = f"{name}_nicsY_h{h:.2f}".replace(".", "p")
            cfg_y["da_max"] = npts
            make_inputs(cfg_y["name_molecule"], ats, ptsY, cfg_y)
            print(f"[ok] Inputs for Y-scan generated (height={h} Å) prefix: {cfg_y['name_molecule']}")
    xyz_out = f"{name}_nics_scan.xyz"
    write_nics_xyz(xyz_out, ats, all_pts_for_xyz, None)
    print(f"[ok] Wrote: {xyz_out}")
    print("\nDone. NICS-scan inputs are ready.")

if __name__ == "__main__":
    main()
