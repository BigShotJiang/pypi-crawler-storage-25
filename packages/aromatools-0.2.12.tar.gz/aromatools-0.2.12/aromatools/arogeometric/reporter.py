#!/usr/bin/python3
# -*- coding: utf-8 -*-

import pandas as pd
from aromatools.arogeometric.arogeometric import build_graph, compute_index, get_3Dgraph

class AtomsReporter:
    def __init__(self, mol, index_type: str):
        self.index_type = index_type.upper()
        atoms_list = []
        for atom in mol:
            symbol = atom.symbol.capitalize()
            if symbol == 'H':
                continue
            x, y, z = atom.position
            atoms_list.append((symbol, x, y, z))

        self._graph = build_graph(atoms_list)

        rings, ring_indices_list, df_index, df_bonds = compute_index(
            self._graph,
            atoms_list,
            self.index_type
        )

        if self.index_type == "HOMA":
            cols = [c for c in ["Ring", "HOMA93", "HOMAc", "BLA"] if c in df_index.columns]
            self._df_main = df_index[cols]
        elif self.index_type == "HOMER":
            cols = [c for c in ["Ring", "HOMER", "BLA"] if c in df_index.columns]
            self._df_main = df_index[cols]
        else:
            self._df_main = df_index

        self._df_bonds = df_bonds
        ring_idx_dict = dict(ring_indices_list)

        self._fig = get_3Dgraph(self._graph, atoms_list, rings, ring_idx_dict)

    def df_main(self) -> pd.DataFrame:
        return self._df_main

    def df_bonds(self) -> pd.DataFrame:
        return self._df_bonds

    def fig(self):
        return self._fig
