"""Internal streaming helpers for public SDK event streams."""

from __future__ import annotations

from typing import Any, Dict, Iterator, Optional, Set


_INTERNAL_STREAM_EVENT_TYPES = {
    "client_service_call",
    "client_service_response",
    "model_raw_delta",
}

_SERVICE_PROGRESS_LABELS = {
    "search_web": "Browsing the web",
    "search_news": "Checking the news",
    "search_discussions": "Searching discussions",
    "search_unified": "Searching",
    "search_knowledge": "Searching knowledge",
    "deepsearch": "Researching",
    "read": "Reading page",
    "create_sandbox": "Setting up sandbox",
    "run": "Running code",
    "destroy_sandbox": "Cleaning up sandbox",
    "sandbox": "Working in sandbox",
    "sandbox_status": "Checking sandbox status",
    "volume_write_file": "Writing file",
    "volume_read_file": "Reading file",
    "volume_search_replace": "Editing file",
    "volume_list": "Listing files",
    "get_account_snapshot": "Checking account",
    "get_open_positions": "Checking positions",
    "get_current_price": "Getting price",
    "trade_market_buy": "Placing buy order",
    "trade_market_sell": "Placing sell order",
    "recall_media": "Loading image",
    "media_recall": "Loading image",
    "preview_photo": "Previewing image",
    "media_list": "Listing media",
    "send_message": "Sending message",
    "send_photo": "Sending photo",
    "send_voice": "Sending voice note",
    "edit_message": "Editing message",
    "edit_message_caption": "Editing caption",
    "send_email": "Sending email",
    "send_reply": "Sending reply",
    "set_alarm": "Setting alarm",
    "schedule_at": "Scheduling task",
    "cancel_alarm": "Cancelling alarm",
}


def _service_progress_event(event: Dict[str, Any]) -> Dict[str, Any] | None:
    event_type = event.get("type")
    if event_type not in {"service_call", "client_service_call"}:
        return None

    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    service_name = str(data.get("service_name", "")).strip()
    if not service_name or service_name == "done":
        return None

    label = _SERVICE_PROGRESS_LABELS.get(
        service_name,
        service_name.replace("_", " ").capitalize(),
    )
    return {
        "type": "model_delta",
        "timestamp": event.get("timestamp"),
        "process_id": event.get("process_id"),
        "iteration": event.get("iteration"),
        "data": {
            "text": f"\n> {label}\n",
            "progress": True,
            "synthetic": True,
        },
    }


def _public_service_call_event(event: Dict[str, Any]) -> Dict[str, Any]:
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    service_name = str(data.get("service_name", "")).strip()
    public_data: Dict[str, Any] = {
        "service_name": service_name,
        "client_managed": event.get("type") == "client_service_call",
    }
    call_id = str(data.get("call_id", "")).strip()
    if call_id:
        public_data["call_id"] = call_id

    return {
        "type": "service_call",
        "timestamp": event.get("timestamp"),
        "process_id": event.get("process_id"),
        "iteration": event.get("iteration"),
        "data": public_data,
    }


def _normalize_public_stream_event(
    event: Dict[str, Any],
    *,
    allowed_builtin_services: Optional[Set[str]] = None,
    allow_raw_client_services: bool = False,
) -> Dict[str, Any] | None:
    event_type = event.get("type")
    if event_type == "service_call":
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        service_name = str(data.get("service_name", "")).strip()
        if service_name == "done":
            return None
        if allowed_builtin_services is not None and service_name not in allowed_builtin_services:
            return None
        return _public_service_call_event(event)
    if event_type == "service_response":
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        service_name = str(data.get("service_name", "")).strip()
        if not service_name or service_name == "done":
            return None
        if allowed_builtin_services is not None and service_name not in allowed_builtin_services:
            return None
        return event
    if event_type == "client_service_call":
        if allow_raw_client_services:
            return event
        return None
    if event_type == "model_raw_delta":
        return None
    if event_type in _INTERNAL_STREAM_EVENT_TYPES:
        return None
    return event


def _coalesce_deltas(
    events: Iterator[Dict[str, Any]],
    *,
    allowed_builtin_services: Optional[Set[str]] = None,
    allow_raw_client_services: bool = False,
) -> Iterator[Dict[str, Any]]:
    """Keep visible deltas immediate while normalizing public progress events."""
    for event in events:
        normalized = _normalize_public_stream_event(
            event,
            allowed_builtin_services=allowed_builtin_services,
            allow_raw_client_services=allow_raw_client_services,
        )
        if normalized is None:
            continue
        progress = _service_progress_event(event)
        if progress is not None:
            yield progress
        yield normalized
