import os

import numpy as np
import pytest
import rasterio
from affine import Affine

import raster_tools as rts
from raster_tools._mosaic import mosaic
from raster_tools.batch import _batch_parse_save, _BatchScripParserState
from raster_tools.io import _auto_overview_factors, write_raster
from tests.utils import make_raster


@pytest.fixture
def out_tif(tmp_path):
    return str(tmp_path / "out.tif")


def _open(path):
    return rasterio.open(path)


# --- Round-trip correctness -------------------------------------------------


@pytest.mark.parametrize(
    "dtype", ["float32", "float64", "int16", "uint8", "int32"]
)
def test_save_roundtrip_basic(out_tif, dtype):
    src = make_raster("arange", dtype=dtype, shape=(1, 8, 8))
    src.save(out_tif)
    reloaded = rts.Raster(out_tif)
    assert reloaded.dtype == np.dtype(dtype)
    assert reloaded.crs == src.crs
    assert np.array_equal(reloaded.to_numpy(), src.to_numpy())


def test_save_roundtrip_multiband(out_tif):
    src = make_raster("arange", dtype="float32", shape=(3, 8, 8))
    src.save(out_tif)
    reloaded = rts.Raster(out_tif)
    assert reloaded.nbands == 3
    assert np.array_equal(reloaded.to_numpy(), src.to_numpy())


def test_save_roundtrip_bool(out_tif):
    src = make_raster("ones", dtype="float32", shape=(1, 6, 6)) > 0
    assert src.dtype == np.dtype(bool)
    src.save(out_tif)
    with _open(out_tif) as ds:
        assert ds.dtypes[0] == "uint8"
        # nbits=1 is recorded in the IMAGE_STRUCTURE namespace
        tags = ds.tags(1, ns="IMAGE_STRUCTURE")
        assert tags.get("NBITS") == "1"
    reloaded = rts.Raster(out_tif)
    assert (reloaded.to_numpy() != 0).all()


def test_save_roundtrip_i64(out_tif):
    src = make_raster("arange", dtype="int64", shape=(1, 4, 4))
    src.save(out_tif)
    with _open(out_tif) as ds:
        assert ds.dtypes[0] == "float64"
    reloaded = rts.Raster(out_tif)
    assert np.allclose(reloaded.to_numpy(), src.to_numpy().astype("float64"))


def test_save_roundtrip_with_nulls(out_tif):
    src = make_raster(
        "arange",
        dtype="float32",
        shape=(1, 6, 6),
        null_pattern=np.s_[:, :2, :2],
    )
    src.save(out_tif)
    reloaded = rts.Raster(out_tif)
    assert reloaded.null_value == src.null_value
    assert np.array_equal(reloaded.mask.compute(), src.mask.compute())


# --- Default creation options (TIFF) ----------------------------------------


def test_default_tiled_uncompressed(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 8, 8)).save(out_tif)
    with _open(out_tif) as ds:
        profile = ds.profile
        assert profile["tiled"] is True
        # Default is no compression; GDAL omits the COMPRESS tag.
        assert profile.get("compress") is None
        assert profile.get("blockxsize") is not None
        assert profile.get("blockysize") is not None


def test_compress_lzw_opt_in(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 8, 8)).save(
        out_tif, compress="lzw"
    )
    with _open(out_tif) as ds:
        assert ds.profile["compress"] == "lzw"


def test_compress_deflate_with_level(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 64, 64)).save(
        out_tif, compress="deflate", compress_level=9
    )
    with _open(out_tif) as ds:
        assert ds.profile["compress"] == "deflate"


@pytest.mark.parametrize(
    "blocksize,expected",
    [(128, (128, 128)), ((64, 256), (64, 256))],
)
def test_blocksize_int_and_tuple(out_tif, blocksize, expected):
    make_raster("arange", dtype="float32", shape=(1, 512, 512)).save(
        out_tif, blocksize=blocksize
    )
    with _open(out_tif) as ds:
        assert ds.profile["blockysize"] == expected[0]
        assert ds.profile["blockxsize"] == expected[1]


def test_predictor_horizontal_int(out_tif):
    make_raster("arange", dtype="int16", shape=(1, 64, 64)).save(
        out_tif, compress="deflate", predictor="horizontal"
    )
    with _open(out_tif) as ds:
        # Predictor lives in IMAGE_STRUCTURE tags
        tags = ds.tags(ns="IMAGE_STRUCTURE")
        assert tags.get("PREDICTOR") == "2"


def test_predictor_float(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 64, 64)).save(
        out_tif, compress="deflate", predictor="float"
    )
    with _open(out_tif) as ds:
        tags = ds.tags(ns="IMAGE_STRUCTURE")
        assert tags.get("PREDICTOR") == "3"


def test_predictor_invalid_raises(out_tif):
    with pytest.raises(ValueError, match="predictor"):
        make_raster("arange", dtype="int16", shape=(1, 8, 8)).save(
            out_tif, predictor="bogus"
        )


@pytest.mark.parametrize("predictor", [2, 3])
def test_predictor_int_backward_compat(out_tif, predictor):
    # rasterio-style integer predictor values are accepted unchanged for
    # backward compatibility with workflows that pre-date the logical kwargs.
    dtype = "int16" if predictor == 2 else "float32"
    make_raster("arange", dtype=dtype, shape=(1, 64, 64)).save(
        out_tif, compress="deflate", predictor=predictor
    )
    with _open(out_tif) as ds:
        tags = ds.tags(ns="IMAGE_STRUCTURE")
        assert tags.get("PREDICTOR") == str(predictor)


# --- Null value plumbing ----------------------------------------------------


def test_null_value_kwarg_overrides_raster_null(out_tif):
    src = make_raster("arange", dtype="float32", shape=(1, 6, 6))
    src.save(out_tif, null_value=-9999.0)
    with _open(out_tif) as ds:
        assert ds.nodata == -9999.0
    reloaded = rts.Raster(out_tif)
    assert reloaded.null_value == -9999.0


def test_no_data_value_emits_deprecation_warning_and_works(out_tif):
    src = make_raster("arange", dtype="float32", shape=(1, 6, 6))
    with pytest.warns(DeprecationWarning, match="no_data_value"):
        src.save(out_tif, no_data_value=-1.0)
    with _open(out_tif) as ds:
        assert ds.nodata == -1.0


def test_passing_both_null_and_no_data_raises(out_tif):
    src = make_raster("arange", dtype="float32", shape=(1, 6, 6))
    with (
        pytest.warns(DeprecationWarning),
        pytest.raises(TypeError, match="Cannot specify both"),
    ):
        src.save(out_tif, null_value=-1.0, no_data_value=-2.0)


# --- Overviews --------------------------------------------------------------


def test_overviews_explicit_list(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 256, 256)).save(
        out_tif, overviews=[2, 4]
    )
    with _open(out_tif) as ds:
        assert ds.overviews(1) == [2, 4]


def test_overviews_true_builds_auto_chain(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 1024, 1024)).save(
        out_tif, overviews=True
    )
    expected = _auto_overview_factors(1024, 1024)
    with _open(out_tif) as ds:
        assert ds.overviews(1) == expected


@pytest.mark.parametrize("overviews", [None, False])
def test_overviews_skip(out_tif, overviews):
    make_raster("arange", dtype="float32", shape=(1, 256, 256)).save(
        out_tif, overviews=overviews
    )
    with _open(out_tif) as ds:
        assert ds.overviews(1) == []


def test_overview_resampling_tag(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 512, 512)).save(
        out_tif, overviews=[2], overview_resampling="nearest"
    )
    with _open(out_tif) as ds:
        tags = ds.tags(ns="rio_overview")
        assert tags.get("resampling") == "nearest"


# --- Escape hatch -----------------------------------------------------------


def test_gdal_kwargs_with_unmodelled_option(out_tif):
    # 'sparse_ok' is a GTiff option we don't model; should pass through.
    make_raster("arange", dtype="float32", shape=(1, 64, 64)).save(
        out_tif, sparse_ok=True
    )
    # If the file opens cleanly it accepted the option; nothing more to check.
    with _open(out_tif) as ds:
        assert ds.count == 1


# --- COG driver -------------------------------------------------------------


def test_cog_driver_basic_roundtrip(out_tif):
    src = make_raster("arange", dtype="float32", shape=(1, 256, 256))
    src.save(out_tif, driver="COG")
    with _open(out_tif) as ds:
        assert ds.profile["tiled"] is True
        # Default overviews=None means no overviews are built, even for COG.
        assert ds.overviews(1) == []
    reloaded = rts.Raster(out_tif)
    assert np.array_equal(reloaded.to_numpy(), src.to_numpy())


def test_cog_overviews_true_builds_internal(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 1024, 1024)).save(
        out_tif, driver="COG", overviews=True
    )
    with _open(out_tif) as ds:
        assert ds.overviews(1) != []


def test_cog_blocksize(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 512, 512)).save(
        out_tif, driver="COG", blocksize=256
    )
    with _open(out_tif) as ds:
        assert ds.profile["blockxsize"] == 256
        assert ds.profile["blockysize"] == 256


def test_cog_non_square_blocksize_raises(out_tif):
    with pytest.raises(ValueError, match="square blocksize"):
        make_raster("arange", dtype="float32", shape=(1, 256, 256)).save(
            out_tif, driver="COG", blocksize=(128, 256)
        )


def test_cog_compress_lzw(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 256, 256)).save(
        out_tif, driver="COG", compress="lzw"
    )
    with _open(out_tif) as ds:
        assert ds.profile["compress"] == "lzw"


def test_cog_compress_deflate_with_level(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 256, 256)).save(
        out_tif, driver="COG", compress="deflate", compress_level=9
    )
    with _open(out_tif) as ds:
        assert ds.profile["compress"] == "deflate"


def test_cog_overviews_disabled(out_tif):
    make_raster("arange", dtype="float32", shape=(1, 1024, 1024)).save(
        out_tif, driver="COG", overviews=False
    )
    with _open(out_tif) as ds:
        assert ds.overviews(1) == []


@pytest.mark.parametrize("predictor", [2, 3])
def test_cog_predictor_int_backward_compat(out_tif, predictor):
    dtype = "int16" if predictor == 2 else "float32"
    make_raster("arange", dtype=dtype, shape=(1, 256, 256)).save(
        out_tif,
        driver="COG",
        compress="deflate",
        predictor=predictor,
    )
    with _open(out_tif) as ds:
        tags = ds.tags(ns="IMAGE_STRUCTURE")
        assert tags.get("PREDICTOR") == str(predictor)


def test_cog_explicit_overview_list_warns(out_tif):
    with pytest.warns(UserWarning, match="COG driver builds overviews"):
        make_raster("arange", dtype="float32", shape=(1, 1024, 1024)).save(
            out_tif, driver="COG", overviews=[2, 4]
        )
    with _open(out_tif) as ds:
        # COG picks its own factors; just confirm overviews exist.
        assert ds.overviews(1) != []


# --- Auto chain helper (unit) ----------------------------------------------


@pytest.mark.parametrize(
    "h,w,min_size,expected",
    [
        (1024, 1024, 256, [2, 4]),
        (1000, 1000, 256, [2]),
        (100, 100, 256, []),
        (157000, 90000, 256, [2, 4, 8, 16, 32, 64, 128, 256]),
        (512, 512, 128, [2, 4]),
    ],
)
def test_auto_overview_factors(h, w, min_size, expected):
    assert _auto_overview_factors(h, w, min_size=min_size) == expected


# --- write_raster direct ---------------------------------------------------


def test_write_raster_direct_call(out_tif):
    src = make_raster("arange", dtype="float32", shape=(1, 8, 8))
    write_raster(src.xdata, out_tif)
    reloaded = rts.Raster(out_tif)
    assert np.array_equal(reloaded.to_numpy(), src.to_numpy())


def test_write_raster_unsupported_extension_raises(tmp_path):
    src = make_raster("arange", dtype="float32", shape=(1, 4, 4))
    with pytest.raises(NotImplementedError):
        write_raster(src.xdata, str(tmp_path / "x.nc"))


# --- Batch save (regression for batch.py SAVEFUNCTIONRASTER) ---------------


def test_batch_save_uses_keyword_args(tmp_path):
    src = make_raster("arange", dtype="float32", shape=(1, 32, 32))
    state = _BatchScripParserState.__new__(_BatchScripParserState)
    state.rasters = {"r1": src}
    state.location = str(tmp_path)
    # SAVEFUNCTIONRASTER args: inRaster;outName;outWorkspace;type;nodata;
    #                          blockwidth;blockheight
    args_str = f"r1;out;{tmp_path};TIFF;-1;16;16"
    _batch_parse_save(state, args_str, line_no=1)
    out_path = str(tmp_path / "out.tif")
    with _open(out_path) as ds:
        assert ds.profile["blockxsize"] == 16
        assert ds.profile["blockysize"] == 16
        assert ds.nodata == -1


# --- save_chunks ============================================================


def _multiband_raster():
    return make_raster("arange", dtype="float32", shape=(3, 12, 12)).chunk(
        (1, 4, 4)
    )


def _singleband_raster():
    return make_raster("arange", dtype="float32", shape=(1, 12, 12)).chunk(
        (1, 4, 4)
    )


def test_save_chunks_default_multiband(tmp_path):
    src = _multiband_raster()
    out = src.save_chunks(str(tmp_path / "tile"))

    assert out.shape == (3, 3)
    src_np = src.to_numpy()
    chunk_size = 4
    for r, c in np.ndindex(*out.shape):
        tile = out[r, c]
        assert isinstance(tile, rts.Raster)
        assert tile.nbands == 3
        ys = slice(r * chunk_size, (r + 1) * chunk_size)
        xs = slice(c * chunk_size, (c + 1) * chunk_size)
        assert np.array_equal(tile.to_numpy(), src_np[:, ys, xs])


def test_save_chunks_single_band(tmp_path):
    src = _singleband_raster()
    out = src.save_chunks(str(tmp_path / "tile"))

    assert out.shape == (3, 3)
    for tile in out.ravel():
        assert isinstance(tile, rts.Raster)
        assert tile.nbands == 1


def test_save_chunks_per_band(tmp_path):
    src = _multiband_raster()
    out = src.save_chunks(str(tmp_path / "tile"), per_band=True)

    assert out.shape == (3, 3, 3)
    src_np = src.to_numpy()
    chunk_size = 4
    for b, r, c in np.ndindex(*out.shape):
        tile = out[b, r, c]
        assert isinstance(tile, rts.Raster)
        assert tile.nbands == 1
        ys = slice(r * chunk_size, (r + 1) * chunk_size)
        xs = slice(c * chunk_size, (c + 1) * chunk_size)
        assert np.array_equal(tile.to_numpy()[0], src_np[b, ys, xs])


def test_save_chunks_filenames_zero_padded(tmp_path):
    src = _singleband_raster()
    src.save_chunks(str(tmp_path / "tile"))
    files = sorted(p.name for p in tmp_path.glob("*.tif"))
    # 3 row chunks and 3 col chunks -> single-digit indices, no padding.
    assert files[0] == "tile_0_0.tif"
    assert files[-1] == "tile_2_2.tif"


def test_save_chunks_filenames_padded_for_large_grid(tmp_path):
    # 12 row chunks forces 2-digit zero-padding so files sort correctly.
    src = make_raster("arange", dtype="float32", shape=(1, 144, 12)).chunk(
        (1, 12, 12)
    )
    src.save_chunks(str(tmp_path / "tile"))
    files = sorted(p.name for p in tmp_path.glob("*.tif"))
    assert files[0] == "tile_00_0.tif"
    assert files[-1] == "tile_11_0.tif"


def test_save_chunks_creates_parent_dirs(tmp_path):
    src = _singleband_raster()
    src.save_chunks(str(tmp_path / "nested" / "deep" / "tile"))
    assert (tmp_path / "nested" / "deep").is_dir()
    assert len(list((tmp_path / "nested" / "deep").glob("*.tif"))) == 9


def test_save_chunks_pathlike_prefix_accepted(tmp_path):
    src = _singleband_raster()
    out = src.save_chunks(tmp_path / "tile")
    assert out.shape == (3, 3)
    assert (tmp_path / "tile_0_0.tif").is_file()


@pytest.mark.parametrize("ext", [".tiff", "tiff"])
def test_save_chunks_custom_ext(tmp_path, ext):
    # Verify the leading-dot is optional and the requested extension lands
    # on every file.
    src = _singleband_raster()
    src.save_chunks(str(tmp_path / "tile"), ext=ext)
    files = sorted(p.name for p in tmp_path.iterdir())
    assert all(f.endswith(".tiff") for f in files)


def test_save_chunks_ext_default_picks_tif_without_driver(tmp_path):
    src = _singleband_raster()
    src.save_chunks(str(tmp_path / "tile"))
    files = sorted(p.name for p in tmp_path.iterdir())
    assert all(f.endswith(".tif") for f in files)


@pytest.mark.parametrize(
    "driver,expected_ext",
    [("GTiff", ".tif"), ("COG", ".tif"), ("HFA", ".img")],
)
def test_save_chunks_ext_auto_from_driver(tmp_path, driver, expected_ext):
    src = make_raster("arange", dtype="float32", shape=(1, 256, 256)).chunk(
        (1, 128, 128)
    )
    src.save_chunks(str(tmp_path / "tile"), driver=driver)
    # Some drivers (e.g. HFA) write sidecar files like .aux.xml; only
    # check the primary data files.
    primary = [
        p.name for p in tmp_path.iterdir() if p.name.endswith(expected_ext)
    ]
    assert len(primary) == 4


def test_save_chunks_empty_ext_means_no_extension(tmp_path):
    src = _singleband_raster()
    # ext="" requires an explicit driver since GDAL can't infer from the
    # missing extension.
    src.save_chunks(str(tmp_path / "tile"), ext="", driver="GTiff")
    files = sorted(p.name for p in tmp_path.iterdir())
    # No trailing dot, no extension at all.
    assert files[0] == "tile_0_0"
    assert "." not in files[0]


def test_save_chunks_ext_and_driver_compose(tmp_path):
    # ext controls the filename; driver="COG" controls the writer. Both
    # are orthogonal -- the explicit driver wins regardless of extension
    # (handy because .cog isn't in GDAL's extension table).
    src = make_raster("arange", dtype="float32", shape=(1, 256, 256)).chunk(
        (1, 128, 128)
    )
    src.save_chunks(str(tmp_path / "tile"), ext=".cog", driver="COG")
    files = sorted(p.name for p in tmp_path.iterdir())
    assert all(f.endswith(".cog") for f in files)
    with rasterio.open(tmp_path / files[0]) as ds:
        # COG always writes tiled files.
        assert ds.profile["tiled"] is True


def test_save_chunks_rejects_path_in_save_kwargs(tmp_path):
    src = _singleband_raster()
    with pytest.raises(TypeError, match="do not pass 'path'"):
        src.save_chunks(str(tmp_path / "tile"), path="elsewhere.tif")


def test_save_chunks_no_data_value_warns_once(tmp_path):
    src = _multiband_raster()
    with pytest.warns(DeprecationWarning, match="no_data_value") as record:
        src.save_chunks(str(tmp_path / "tile"), no_data_value=-9999.0)
    # The deprecation should fire once at the top of save_chunks rather than
    # once per tile (9 tiles otherwise).
    assert sum("no_data_value" in str(w.message) for w in record) == 1
    one = next(tmp_path.glob("*.tif"))
    with rasterio.open(one) as ds:
        assert ds.nodata == -9999.0


def test_save_chunks_save_kwargs_forwarded(tmp_path):
    src = make_raster("arange", dtype="float32", shape=(1, 64, 64)).chunk(
        (1, 32, 32)
    )
    src.save_chunks(str(tmp_path / "tile"), compress="lzw", blocksize=16)
    one = next(tmp_path.glob("*.tif"))
    with rasterio.open(one) as ds:
        assert ds.profile["compress"] == "lzw"
        assert ds.profile["blockxsize"] == 16
        assert ds.profile["blockysize"] == 16


def test_save_chunks_affine_per_tile(tmp_path):
    src = _multiband_raster()
    out = src.save_chunks(str(tmp_path / "tile"))

    chunk_size = 4
    for r, c in np.ndindex(*out.shape):
        expected = src.affine * Affine.translation(
            c * chunk_size, r * chunk_size
        )
        assert out[r, c].affine == expected


def test_save_chunks_null_value_preserved(tmp_path):
    src = make_raster(
        "arange",
        dtype="float32",
        shape=(1, 12, 12),
        null_pattern=np.s_[:, :2, :2],
    ).chunk((1, 4, 4))
    out = src.save_chunks(str(tmp_path / "tile"))
    for tile in out.ravel():
        assert tile.null_value == src.null_value


def test_save_chunks_return_shape_and_files_exist(tmp_path):
    src = _multiband_raster()
    out = src.save_chunks(str(tmp_path / "tile"))
    assert isinstance(out, np.ndarray)
    assert out.dtype == object
    assert out.shape == (3, 3)
    files = list(tmp_path.glob("*.tif"))
    assert len(files) == 9
    for f in files:
        assert f.is_file() and os.path.getsize(f) > 0


def test_save_chunks_mosaic_round_trip(tmp_path):
    # End-to-end: split a raster into chunk files, then mosaic them back
    # together and verify pixel-equality with the original.
    src = _multiband_raster()
    tiles = src.save_chunks(str(tmp_path / "tile"))
    rebuilt = mosaic(list(tiles.ravel()), dst_grid=src)
    assert rebuilt.shape == src.shape
    assert rebuilt.crs == src.crs
    assert rebuilt.affine == src.affine
    assert np.array_equal(rebuilt.to_numpy(), src.to_numpy())


def test_save_chunks_mosaic_round_trip_per_band(tmp_path):
    src = _multiband_raster()
    tiles = src.save_chunks(str(tmp_path / "tile"), per_band=True)
    # Mosaic per-band single-band tiles spatially, then stack the per-band
    # results back into a multi-band raster.
    rebuilt_bands = [
        mosaic(list(tiles[b].ravel()), dst_grid=src.get_bands(b + 1))
        for b in range(src.nbands)
    ]
    rebuilt = rts.stack_bands(rebuilt_bands)
    assert rebuilt.shape == src.shape
    assert np.array_equal(rebuilt.to_numpy(), src.to_numpy())
