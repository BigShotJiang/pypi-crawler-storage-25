from django.http import JsonResponse, HttpResponseRedirect


class RenderException(Exception):
    def __init__(self, render, msg=''):
        err = msg
        Exception.__init__(self, err)
        self.render = render
        self.msg = msg

    @staticmethod
    def create_exception(*args, **kwargs):
        code = kwargs.get('code', 500)
        msg = kwargs.get('msg', '')
        if args:
            try:
                msg = msg % args
            except Exception:
                pass
        return RenderException(JsonResponse({'code': code, 'msg': msg}))

    @staticmethod
    def raise_exception(*args, **kwargs):
        raise RenderException.create_exception(*args, **kwargs)


    @staticmethod
    def raise_redirect_exception(url:str):
        raise RenderException(HttpResponseRedirect(url))

class CommonException(Exception):
    def __init__(self, msg):
        err = msg
        Exception.__init__(self, err)
        self.msg = msg
