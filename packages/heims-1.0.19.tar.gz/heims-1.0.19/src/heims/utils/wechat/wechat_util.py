import base64
import json

import requests

from ...common import functions


class WechatUtil(object):
    def __init__(self, app_id, app_secret, token='', *, redis=None):
        self.app_id = app_id
        self.app_secret = app_secret
        self.token = token
        self.redis = redis

    def log_by_code(self, code, client_type='public_account'):
        """

        :param code:
        :param client_type:  public_account/applet
        :return:
        """
        if client_type == 'public_account':
            url = f"https://api.weixin.qq.com/sns/oauth2/access_token?appid={self.app_id}&secret={self.app_secret}&" \
                  f"code={code}&grant_type=authorization_code"
        else:
            url = f'https://api.weixin.qq.com/sns/jscode2session?appid={self.app_id}&secret={self.app_secret}&' \
                  f'js_code={code}&grant_type=authorization_code'

        resp = requests.get(url)
        if resp:
            return resp.json()
        return {}

    def get_token(self):
        if not self.token:
            for i in range(0, 5):
                key = f"token_{self.app_id}"
                self.token = self.redis.get(key, '') if self.redis else None
                if not self.token:
                    url = f"https://token.zhangjianpeng.cn/?app_id={functions.md5(self.app_id)}&" \
                          f"app_secret={functions.md5(self.app_secret)}"
                    resp = requests.post(url, {})
                    if resp:
                        back_data = resp.json()
                        if 'data' in back_data and 'access_token' in back_data['data']:
                            self.token = back_data['data']['access_token']
                            if self.redis:
                                self.redis.set(key, self.token, expire=back_data['data'].get('expires_in', 60))
                if self.token:
                    break

    def get_phone_info(self, code):
        self.get_token()
        if self.token:
            url = f"https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={self.token}"
            resp = requests.post(url, json={"code": code})
            if resp and (resp.status_code == 200):
                back_info = resp.json()
                return back_info
        return None

    def send_text(self, back_data):
        self.get_token()
        if self.token:
            url = f"https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={self.token}"
            requests.post(url, json=back_data)

    def get_mobile_info(self, code):
        self.get_token()
        if self.token:
            url = f"https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={self.token}"
            resp = requests.post(url, data=json.dumps({
                "code": code
            }))
            if resp:
                try:
                    data = json.loads(resp.content.decode('utf-8'))
                    phone = data.get('phone_info', {}).get('purePhoneNumber', '')
                    return phone
                except Exception as e:
                    pass
        return None

    def get_union_id(self, open_id):
        try:
            self.get_token()
            if self.token:
                url = f"https://api.weixin.qq.com/cgi-bin/user/info?access_token={self.token}&openid={open_id}&lang=zh_CN"
                resp = requests.get(url)
                if resp and resp.status_code in (200, '200'):
                    print(resp.content)
        except Exception as e:
            print(e)

    def get_qr_code(self, page, scene, _type='B'):
        try:
            self.get_token()
            if self.token:
                if _type == 'B':
                    url = f"https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token={self.token}"
                    page = page.lstrip("/")
                    post_data = {
                        "page": page,
                        "scene": scene,
                        "check_path": False,
                        "env_version": "release",
                        "is_hyaline": True,
                    }
                elif _type == 'A':
                    url = f"https://api.weixin.qq.com/wxa/getwxacode?access_token={self.token}"
                    page = page.lstrip("/")
                    post_data = {
                        "path": page + "?" + scene,
                        "env_version": "release",
                        "is_hyaline": True,
                    }
                else:
                    return
                resp = requests.post(url, json=post_data)
                if resp and resp.status_code in (200, '200'):
                    if resp.headers.get('Content-Type').lower().startswith('image'):
                        return True, resp.content
                    else:
                        return False, json.loads(resp.content.decode('utf-8'))
        except Exception as e:
            return None, None

if __name__ == '__main__':
    WechatUtil("wx3a77b556d18efaf8", "877028b6d6ea7f446e601e830c0999f1").get_qr_code("packA/pages/study/info/index", "id=28&invite_id=1")
