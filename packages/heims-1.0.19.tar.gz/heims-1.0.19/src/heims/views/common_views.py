import datetime
import json
import traceback
from abc import abstractmethod, ABC

from MySQLdb.converters import NoneType
from django.http import JsonResponse
from django.shortcuts import render
from django.views.generic import View

from ..common.config import BASE_INFO
from ..services.data_service import DataService
from ..utils.db.mysql_util import MySQLUtil
from ..utils.cache.redis_util import RedisUtil
from ..common.log_util import LogUtil
from ..common import functions, config
from ..common.exceptions import RenderException
from ..common.functions import get_data_from_dict, make_id, is_integer, set_default_int, trans_key, Serialize
from ..services.user_service import UserService


class BaseView(View):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # 追踪标记
        self.trace = functions.make_id()

        # 配置项
        self.base_info = config.BASE_INFO
        self.db_config = config.MYSQL_INFO
        self.cache_config = config.REDIS_INFO
        self.app_config = config.WECHAT_INFO

        # 当前用户信息
        self.auth_token = None
        self.new_token = False
        self.user_info = {}
        self.user_id = 0

        # 其他常用变量
        self.now_time = datetime.datetime.now()

        # http相关数据
        self.request = None
        self.post_data = {}
        self.get_data = {}
        self.ip = ""
        self.set_cookie_data = []

        # 工具
        self.logger = None
        self.cache = None
        self.dao = None

        self.page_permission = None
        self.is_ajax = True
        self.template_name = ""
        self.resp_data = {
            "code": 200,
            "msg": "",
            "data": {}
        }

    @abstractmethod
    def set_config(self):
        """
        修改参数设置
        """
        pass

    def initialize(self, request, *args, **kwargs):
        # 钩子，用于覆写__init__中的参数设置
        self.set_config()

        self.init_utils()
        self.get_info_from_request(request)
        self.log_in(request)
        self.save_log()
        if self.base_info.get('check_page_permission', 0):
            flag, url = self.check_permission()
            if not flag:
                self.return_error(code=403, msg="无权访问", raise_error=True, jump_url=url)

    def dispatch(self, request, *args, **kwargs):
        try:
            self.initialize(request, *args, **kwargs)
            resp = super().dispatch(request, *args, **kwargs)
            if self.set_cookie_data:
                for item in self.set_cookie_data:
                    if "key" in item and "value" in item:
                        resp.set_cookie(item["key"], item["value"], **item.get("options", {}))
            return resp
        except RenderException as e:
            return e.render
        except Exception:
            self.logger.error(traceback.format_exc())
            return self.return_error()

    def get(self, request):
        try:
            self.pre_get(request)
            self.do_get(request)
            self.ap_get(request)
            return self.return_success()
        except RenderException as e:
            return e.render
        except Exception:
            self.logger.error(traceback.format_exc())
            return self.return_error()

    def post(self, request):
        try:
            self.pre_post(request)
            self.do_post(request)
            self.ap_post(request)
            return self.return_success()
        except RenderException as e:
            return e.render
        except Exception:
            self.logger.error(traceback.format_exc())
            return self.return_error()

    def set_data(self, _data: dict, refresh=False):
        self.resp_data.update({
            "code": 200,
            "msg": "",
        })
        new_data = trans_key(_data, 'camel' if self.base_info.get('is_camel_case', '') else 'snake')
        if refresh or not self.resp_data.get('data', {}):
            self.resp_data['data'] = {}
        self.resp_data['data'].update(new_data)

    def return_error(self, *, code: int = 500, msg: str = "", raise_error: bool = False, args: list = None,
                     jump_url: str = ""):
        self.resp_data = {
            "code": code,
            "msg": msg,
        }
        if self.is_ajax:
            if raise_error:
                if jump_url:
                    RenderException.raise_redirect_exception(jump_url)
                    return
                if args is None:
                    args = []
                RenderException.raise_exception(*args, **self.resp_data)
                return
            else:
                if self.is_ajax:
                    return JsonResponse(self.resp_data, encoder=Serialize)
        else:
            return render(self.request, self.base_info.get("error_template", "error.html"), self.resp_data)

    def return_success(self, data: dict = None, *, refresh=False):
        if data:
            self.set_data(data, refresh)
        if self.is_ajax:
            return JsonResponse(self.resp_data, encoder=Serialize)
        else:
            return render(self.request, self.template_name, self.resp_data.get('data', {}))

    def pre_get(self, request):
        pass

    def do_get(self, request):
        pass

    def ap_get(self, request):
        pass

    def pre_post(self, request):
        pass

    def do_post(self, request):
        pass

    def ap_post(self, request):
        pass

    def get_info_from_request(self, request):
        self.request = request
        self.get_get_data(request)
        self.get_post_data(request)
        self.get_ip(request)
        if not self.is_ajax:
            self.is_ajax = bool(self.get_data.get('is_ajax', ''))

    def get_get_data(self, request):
        for key, value in dict(request.GET).items():
            if isinstance(value, (list, tuple)):
                if len(value) == 1:
                    self.get_data[key] = request.GET.get(key)
                else:
                    self.get_data[key] = value
            else:
                self.get_data[key] = value

        if self.get_data:
            trans_key(self.get_data, 'snake')

    def get_post_data(self, request):
        data = {}
        # 检查Content-Type
        content_type = request.content_type

        if 'application/json' in content_type:
            # 处理JSON数据
            try:
                data = json.loads(request.body)
            except json.JSONDecodeError:
                self.logger.error(f"bad format: {str(request.body)}")
                self.logger.error(traceback.format_exc())

        elif 'multipart/form-data' in content_type:
            data = {}
            # 处理表单数据（包含文件上传）
            if request.POST:
                data = request.POST.dict()

            # 处理上传的文件
            if request.FILES:
                files = {}
                for name, file in request.FILES.items():
                    files[name] = {
                        'name': file.name,
                        'size': file.size,
                        'content_type': file.content_type
                    }
                data['files'] = files
        elif 'application/x-www-form-urlencoded' in content_type:
            # 处理普通的表单数据
            data = request.POST.dict()

        if data:
            self.post_data.update(data)

        if self.post_data:
            trans_key(self.post_data, 'snake')

    def get_ip(self, request):
        """
        获取用户IP
        """
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            # 包含多个代理 IP 时，第一个是真实客户端 IP
            self.ip = x_forwarded_for.split(',')[0].strip()
        else:
            # 直接获取远程地址
            self.ip = request.META.get('REMOTE_ADDR')

    def init_utils(self):
        """
        初始化日志工具、数据库查询工具、缓存工具
        """
        self.logger = LogUtil(name=self.trace)
        self.cache = RedisUtil.new_redis_client(**self.cache_config)
        if self.cache:
            self.db_config.update({"redis_client": self.cache})
        self.dao = MySQLUtil.new_db(**self.db_config)

    def log_in(self, request):
        self.get_auth_token(request)
        self.login_by_token()
        self.other_login()

    def get_auth_token(self, request):
        """
        获取用户访问token
        """
        token_name = config.BASE_INFO.get("token_name", "")

        self.auth_token = request.META.get(f'HTTP_{token_name.upper()}', '')

        if not self.auth_token:
            self.auth_token = request.session.get(token_name, '')

        if not self.auth_token:
            self.auth_token = self.get_data.get(token_name, '')

        if not self.auth_token:
            self.auth_token = request.COOKIES.get(token_name, '')

        # 如果所有都取不到，那就生成一个
        if not self.auth_token:
            self.auth_token = make_id()
            self.new_token = True

        if self.auth_token:
            request.session[token_name] = self.auth_token
            self.set_cookie_data.append({
                "key": token_name,
                "value": self.auth_token,
                "options": {
                    "max_age": config.BASE_INFO.get("auth_token_expire_time", 3600)
                }
            })

    def login_by_token(self):
        if not self.new_token:
            self.user_id = self.cache.get(f"user_id_{self.auth_token}", '0')
            if is_integer(str(self.user_id)):
                self.user_id = int(self.user_id)

        if self.user_id:
            self.user_info = UserService.get_info_by_id(self.user_id, self.dao, self.cache)

    def other_login(self):
        pass

    def save_log(self):
        """
        保存访问信息
        """
        pass

    def check_permission(self) -> (bool, str):
        """
        检查权限
        """

        if self.page_permission is not None:
            if not self.user_info:
                self.return_error(raise_error=True, **config.ERROR_INFO.get("no_login", {}))
                return False

            if self.page_permission:
                if not isinstance(self.page_permission, dict):
                    if isinstance(self.page_permission, (list, tuple)):
                        self.page_permission = {
                            item: self.base_info.get("permission_error_page", "/404.html")
                            for item in self.page_permission
                        }
                    else:
                        self.page_permission = {
                            str(self.page_permission): self.base_info.get("permission_error_page", "/404.html")
                        }

                if self.page_permission:
                    user_permission = [str(row['permission_id']) for row in self.user_info.get('permission_list', [])]
                    for key, value in self.page_permission:
                        if key not in user_permission:
                            return False, value
        return True, ""


class ModuleView(BaseView, ABC):
    """
    表单模块
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.table = ""
        self.search_field_scheme = {}
        self.search_part = {}
        # 如果本表存在nV1
        self.fk_info = [
            # {
            #     "fk_ids": {"user_id": "id"},  # 关联外键（有可能是组合外键），如本例情况，可以只写一个"user_id"字符串即可
            #     "table": "user",  # 关联表
            #     "show_name": "user",  # 在原纪录中显示的名称
            #     "columns": ["id", "name"],  # 要检索的关联表字段，默认是"id", "name",
            #     "search_part": {}  # 查询条件
            # }
        ]

        # 如果本表存在nvn
        self.m2m_info = [
            # {
            #     "show_name": "user",  # 在原纪录中显示的名称
            #     "search_info": [
            #         # search_info有两个元素，第一个元素是本表关联nvn记录表的设置
            #         {
            #             "fk_ids": {"id": "user_id"},  # 关联外键（有可能是组合外键），如本例情况，可以只写一个"user_id"字符串即可
            #             "table": "user_role",  # 关联表
            #             "columns": ["role_id"],  # 要检索的关联表字段，默认是"id", "name",
            #             "search_part": {}  # 查询条件
            #         },
            #         # 第二个元素是nvn记录表关联另一个主表的设置
            #         {
            #             "fk_ids": {"role_id": "id"},  # 关联外键（有可能是组合外键），如本例情况，可以只写一个"user_id"字符串即可
            #             "table": "role",  # 关联表
            #             "columns": ["id", "name"],  # 要检索的关联表字段，默认是"id", "name",
            #             "search_part": {}  # 查询条件
            #         }
            #     ]
            # }
        ]

        # 如果本表存在1vn
        self.content_info = [
            # {
            #     "table": "roles",
            #     "1v1": False,
            #     "fk_ids": {"id": "user_id"},
            #     "show_name": "roles",
            #     "update_fields": {},
            #     "columns": ["id", "name"],
            #     "search_part": {}
            # }
        ]


class ListView(ModuleView, ABC):
    """
    列表接口
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.column_list = []

    def do_get(self, request):
        search_info = {
            "columns": None,
            "where_condition": "",
            "args": None,
            "search_dict": None,
            "db_name": "",
            "offset": 0,
            "size": 10,
            "group_by": "",
            "having": "",
            "order_by": None,
        }
        search_info.update(self.set_list_params() or {})
        count, results = DataService(self.dao, self.cache, self.table, self.column_list, fk_info=self.fk_info,
                                     m2m_info=self.m2m_info, content_info=self.content_info).get_list(search_info)
        _count = self.edit_result(count, results)
        if _count is not None:
            count = _count
        self.set_data({
            "count": count,
            "list": results
        })

    def set_list_params(self) -> dict:
        """
        用于修改检索列表的查询条件
        """
        list_param = {}
        offset, size = self.get_page()
        list_param.update({
            "offset": offset,
            "size": size
        })
        list_param['order_by'] = self.get_data.get('_sort', '')

        list_param['group_by'] = self.get_data.get('_group', '')

        list_param['having'] = self.get_data.get('_having', '')

        search_dict = {}
        for key, value in self.get_data.items():
            if value:
                if not key.startswith('_'):
                    if key.endswith('[]'):
                        search_dict[key[:-2]] = {"IN": value if isinstance(value, (list, tuple)) else [value]}
                    elif key.endswith('[start]') or key.endswith('[begin]'):
                        search_dict[key[:-7]] = {">=": value}
                    elif key.endswith('[end]'):
                        search_dict[key[:-5]] = {"<=": value}
                    elif key.endswith('_like'):
                        search_dict[key[:-5]] = {"LIKE": value}
                    else:
                        search_dict[key] = value

        if search_dict:
            list_param['search_dict'] = search_dict

        return list_param

    def get_page(self):
        offset = set_default_int(self.get_data.get("_offset", None), -1)
        size = set_default_int(self.get_data.get('_size', None), 10)
        if offset < 0:
            page = set_default_int(self.get_data.get('_page', None), 0)
            offset = page * size
        return offset, size

    @classmethod
    def edit_result(cls, count: int, results: list) -> int:
        """
        列表后处理
        """
        pass


class DetailView(ModuleView, ABC):
    """
    详情接口
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.column_list = []

    def do_get(self, request):
        search_info = {
            "columns": None,
            "where_condition": "",
            "args": None,
            "search_dict": None,
            "db_name": "",
            "order_by": None,
        }
        search_info.update(self.set_info_params() or {})
        info = DataService(self.dao, self.cache, self.table, self.column_list, fk_info=self.fk_info,
                           m2m_info=self.m2m_info, content_info=self.content_info).get_detail(search_info)
        self.edit_info(info)
        self.set_data({
            "info": info,
        })

    def set_info_params(self) -> dict:
        """
        用于修改检索详情接口的查询条件
        """
        params = {}
        if self.get_data.get('id', ''):
            params['_id'] = self.get_data['id']

        return params

    def edit_info(self, info):
        """
        详情后处理
        """
        pass


class EditView(ModuleView, ABC):
    """
    添加/编辑接口
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.column_list = []

    def do_post(self, request):
        upsert_info = {
            "data": None,
            "conflict_columns": None,
            "ignore_duplicate": False,
            "update_columns": None,
            "search_columns": None
        }
        upsert_info.update(self.set_upsert_params() or {})
        data = DataService(self.dao, self.cache, self.table, self.column_list, fk_info=self.fk_info,
                           m2m_info=self.m2m_info, content_info=self.content_info).edit(upsert_info)
        if data:
            self.after_upsert(data)
        self.set_data({
            "info": {
                "id": data.get('id', 0)
            },
        })

    def set_upsert_params(self) -> dict:
        """
        用于编辑接口的预处理
        """
        _data = self.post_data.copy()
        if ":files" in _data:
            del _data[":files"]

        _data.update({
            "update_id": self.user_id,
            "update_time": self.now_time.strftime(BASE_INFO.get('datetime_format', ''))
        })

        if "id" not in _data:
            _data.update({
                "create_id": self.user_id,
                "create_time": self.now_time.strftime(BASE_INFO.get('datetime_format', ''))
            })

        params = {"data": _data}
        return params

    def after_upsert(self, data: dict):
        """
        插入/编辑后处理
        """
        pass


class DeleteView(ModuleView, ABC):
    """
    删除接口
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.column_list = []

    def do_post(self, request):
        delete_info = {
            "data": None,
            "where_condition": "",
            "args": None,
            "search_dict": None,
            "_id": 0
        }
        delete_info.update(self.set_delete_params() or {})
        DataService(self.dao, self.cache, self.table, self.column_list, fk_info=self.fk_info, m2m_info=self.m2m_info,
                    content_info=self.content_info).delete(delete_info)
        self.after_delete()

    def set_delete_params(self) -> dict:
        """
        用于修改删除接口的查询条件
        """
        params = {}
        if self.post_data.get('id', ''):
            params['_id'] = self.post_data['id']
        elif self.post_data.get('ids', []):
            params['_id'] = self.post_data['ids']

        return params

    def after_delete(self):
        """
        删除后处理
        """
        pass
