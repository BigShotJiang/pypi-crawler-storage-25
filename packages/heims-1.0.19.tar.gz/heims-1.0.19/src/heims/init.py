import os
import yaml
from .common.functions import deep_copy_dict

from .common.functions import read_yaml_file

# Ensure pyyaml is installed: pip install pyyaml


def initialize():
    folder = os.getcwd()
    file = os.path.join(folder, "config.yaml")
    if os.path.exists(file):
        from .common import config
        yaml_config = read_yaml_file(file)
        if yaml_config:
            for section, value in yaml_config.items():
                info = f"{section.upper()}_INFO"
                if info in config.__all__:
                    config_info = getattr(config, info)
                    if isinstance(config_info, dict) and isinstance(value, dict):
                        deep_copy_dict(value, config_info)

if __name__ == '__main__':
    initialize()