from typing import Tuple, Union, List, Dict

from ..utils.db.mysql_util import DBClient
from ..utils.cache.cache_util import CacheClient


class DataService:
    def __init__(self, dao: DBClient, cache: CacheClient, table, column_list: List[str] = None, *,
                 fk_info: Union[List[Dict], Tuple[Dict]] = None,
                 m2m_info: Union[List[Dict], Tuple[Dict]] = None,
                 content_info: Union[List[Dict], Tuple[Dict]] = None):
        self.dao = dao
        self.cache = cache
        self.table = table
        if not column_list:
            column_list = list(self.dao.get_table_structure(table).keys())
        self.column_list = column_list
        self.fk_info = fk_info
        self.m2m_info = m2m_info
        self.content_info = content_info

    def get_list(self, search_info: Dict = None, *, table: str = "") -> (int, List[Dict]):
        if not isinstance(search_info, dict):
            search_info = {}
        if not table:
            table = self.table

        count, results = self.dao.get_list(table, ','.join(self.column_list), **search_info)
        if count:
            self.set_fk_list(results)
            self.set_m2m_list(results)
            self.set_content_list(results)
        else:
            results = []

        return count, results

    def get_detail(self, search_info: Dict = None, *, table: str = "") -> Dict:
        if not isinstance(search_info, dict):
            search_info = {}

        if not table:
            table = self.table

        info = self.dao.get_info(table, ','.join(self.column_list), **search_info)
        if info:
            results = [info]
            self.set_fk_list(results)
            self.set_m2m_list(results)
            self.set_content_list(results)
        else:
            info = {}
        return info

    def edit(self, upsert_info: Dict = None, *, table: str = "") -> Dict:
        if not isinstance(upsert_info, dict):
            upsert_info = {}

        if not table:
            table = self.table

        data = upsert_info.get("data", {})
        if data:
            self.upsert_fk_list(data)
            if "data" in upsert_info:
                del upsert_info['data']
            _id = self.dao.upsert(table, data, **upsert_info)
            if "id" not in data:
                action_type = "add"
                data['id'] = _id
            else:
                action_type = "edit"

            self.upsert_m2m_list(data, action_type)
            self.upsert_content_list(data, action_type)

        return data

    def delete(self, delete_info: Dict = None, *, table: str = "") -> int:
        if not isinstance(delete_info, dict):
            delete_info = {}

        if not table:
            table = self.table
        table_structure = self.dao.get_table_structure(table)
        if "is_del" in [key.lower() for key in table_structure.keys()]:
            return self.dao.update(table, set_str="is_del=1", **delete_info)
        else:
            return self.dao.delete(table, **delete_info)

    def upsert_fk_list(self, data):
        """
        处理外键情况，某些情况下外键要同步插入数据并且返回一个id过来
        """
        if self.check_fk_info(self.fk_info):
            for item in self.fk_info:
                if len(item['fk_ids']) == 1:  # 只有单字段对应外键的时候才做处理
                    k, v = next(iter(item['fk_ids'].items()))
                    if not data.get(k, None):  # 只有外键字段没有值而且show_name字段有值的时候才处理
                        _data = data.get(item['show_name'], {})
                        if _data:
                            _id = self.dao.upsert(item['table'], _data)
                            if v == 'id':
                                data[k] = _id
                            else:
                                data[k] = _data.get(v, 0)

    def upsert_m2m_list(self, data, action_type="add"):
        """
        处理多对多，例如下订单时候的商品明细
        """
        if self.check_m2m_info(self.m2m_info):
            for item in self.m2m_info:
                _data = data.get(item['show_name'], [])
                if _data and isinstance(_data, (list, tuple)):

                    if action_type != 'add':
                        new_data = []
                        del_data = []
                        left_data = []
                        for row in _data:
                            if row.get('id', None):
                                if row.get('is_del', 0):
                                    del_data.append(row['id'])
                                else:
                                    self.dao.update(item['search_info'][0]['table'], data=row, _id=row['id'])
                                    left_data.append(row)
                            else:
                                new_data.append(row)
                        if del_data:
                            self.delete({
                                "id": del_data
                            }, table=item['search_info'][0]['table'])
                    else:
                        new_data = _data
                        left_data = []

                    if new_data:
                        for row in new_data:
                            _id = self.dao.upsert(item['search_info'][1]['table'], row)
                            if _id:
                                row['id'] = _id

                    _data = new_data + left_data

                    if _data:
                        m2m_data = []
                        fk_id = {v:k for k, v in item['search_info'][1]['fk_ids'].items()}.get('id', '')
                        if fk_id:
                            for row in _data:
                                _id = row.get('id', 0)
                                if _id:
                                    tmp = {fk_id: _id}
                                    for key, value in item['search_info'][0]['fk_ids'].items():
                                        if key in data:
                                            tmp[value] = data[key]
                                    m2m_data.append(tmp)

                        self.dao.batch_insert(item['search_info'][0]['table'], [], m2m_data)

    def upsert_content_list(self, data, action_type="add"):
        """
        处理子表，例如文章编辑的时候如果有内容表分表，那么就需要插入主表后，再插入内容子表
        """
        if self.check_content_info(self.content_info):
            for item in self.content_info:
                _data = data.get(item['show_name'], [])
                if _data:
                    if not isinstance(_data, (list, tuple)):
                        if isinstance(_data, dict):
                            _data = [_data]
                        else:
                            _data = [{item['show_name']: str(_data)}]

                    # 如果不是添加，那么要考虑已经有的数据，只做编辑不要添加
                    if action_type != 'add':
                        new_data = []
                        del_data = []
                        for row in _data:
                            if row.get('id', None):
                                if row.get('is_del', 0):
                                    del_data.append(row['id'])
                                else:
                                    self.dao.update(item['table'], data=row, _id=row['id'])
                            else:
                                new_data.append(row)
                        _data = new_data
                        self.delete({
                            "id": del_data
                        }, table=item['table'])

                    for key, value in item['fk_ids'].items():
                        if key in data:
                            for row in _data:
                                row[value] = data[key]

                    self.dao.batch_insert(item['table'], [], _data)

    def set_fk_list(self, results):
        """
        获取并转换外键。将形如{"user_id":1}的值，修改为{"user": {"id":1, "name":"张三"}}这样的值
        """
        if self.check_fk_info(self.fk_info):
            for item in self.fk_info:
                search_dict = {}
                for key, value in item["fk_ids"].items():
                    search_dict[value] = {"IN": [row[key] for row in results]}
                c, l = self.dao.get_list(item['table'],
                                         columns=list(set(item['columns']).union(item['fk_ids'].values())),
                                         search_dict=search_dict, size=-1, offset=0, filter_delete=False)
                rlt = {':'.join([str(row[value]) for value in item['fk_ids'].values()]): row for row in l}
                for row in results:
                    row[item['show_name']] = rlt.get(':'.join([str(row[key]) for key in item['fk_ids'].keys()]), {})

    def set_m2m_list(self, results):
        """
        检索并向记录集中处理nvn数据
        """
        if self.check_m2m_info(self.m2m_info):
            for item in self.m2m_info:
                search_dict = {}
                for key, value in item['search_info'][0]["fk_ids"].items():
                    search_dict[value] = {"IN": [row[key] for row in results]}
                c, l = self.dao.get_list(item['search_info'][0]['table'], columns=list(
                    set(item['search_info'][0]['columns']).union(item['search_info'][0]['fk_ids'].values())),
                                         search_dict=search_dict, size=-1, offset=0)
                rlt = {}
                if l:
                    for row in l:
                        key = ':'.join([str(row[value]) for value in item['search_info'][0]['fk_ids'].values()])
                        if key not in rlt:
                            rlt[key] = [row]
                        else:
                            rlt[key].append(row)

                search_dict = {}
                for key, value in item['search_info'][1]["fk_ids"].items():
                    search_dict[value] = {"IN": [row[key] for value in rlt.values() for row in value]}

                c, l = self.dao.get_list(item['search_info'][1]['table'], columns=list(
                    set(item['search_info'][1]['columns']).union(item['search_info'][1]['fk_ids'].values())), size=-1,
                                         offset=0, search_dict=search_dict, filter_delete=False)
                rlt2 = {':'.join([str(row[value]) for value in item['search_info'][1]['fk_ids'].values()]): row for row
                        in l}
                for key, value in rlt.items():
                    new_value = []
                    for row in value:
                        new_value.append(
                            rlt2.get(':'.join([str(row[value]) for value in item['search_info'][1]['fk_ids'].keys()]),
                                     {}))
                    rlt[key] = new_value

                for row in results:
                    row[item['show_name']] = rlt.get(
                        ':'.join([str(row[key]) for key in item['search_info'][0]['fk_ids'].keys()]), [])

    def set_content_list(self, results):
        """
        检索子表，例如活动列表中如果想要获得每个活动的报名列表，就使用这个方法
        """
        if self.check_content_info(self.content_info):
            for item in self.content_info:
                search_dict = {}
                for key, value in item["fk_ids"].items():
                    search_dict[value] = {"IN": [row[key] for row in results]}
                c, l = self.dao.get_list(item['table'],
                                         columns=list(set(item['columns']).union(item['fk_ids'].values())),
                                         search_dict=search_dict, size=-1, offset=0)
                rlt = {}
                if l:
                    for row in l:
                        key = ':'.join([str(row[value]) for value in item['fk_ids'].values()])
                        if key not in rlt:
                            rlt[key] = [row]
                        else:
                            rlt[key].append(row)
                for row in results:
                    if item.get('1v1', None):
                        new_value = rlt.get(':'.join([str(row[key]) for key in item['fk_ids'].keys()]), [])
                        if new_value:
                            new_value = new_value[0]
                            for key, value in item.get('update_fields', {}).items():
                                row[key] = new_value.get(value, None)
                        else:

                            row[item['show_name']] = {}
                    else:
                        row[item['show_name']] = rlt.get(':'.join([str(row[key]) for key in item['fk_ids'].keys()]), [])

    @classmethod
    def check_fk_info(cls, fk_info):
        """
        检查nv1设置情况  nv1指的是本表中某个字段为外键，关联某个其他表，如action_log表，存在user_id字段，对应user表的id字段
        """
        flag = False
        if not fk_info:
            return False
        for item in fk_info:
            if item.get('table', ''):
                cls.check_nv1_item(item)
                if not item.get('show_name', None):
                    item['show_name'] = item.get('table', '')
                flag = True
            else:
                item['show_name'] = ""
        return flag

    @classmethod
    def check_nv1_item(cls, item):
        """
        检查nv1的单条记录设置情况
        """
        if item.get("fk_ids", None):
            if isinstance(item['fk_ids'], str):
                item['fk_ids'] = {item['fk_ids']: "id"}

        if not isinstance(item['fk_ids'], dict):
            item['fk_ids'] = {f"{item.get('table', '')}_id": "id"}

        if not item.get('columns', None):
            item['columns'] = ["id", "name"]

    @classmethod
    def check_m2m_info(cls, m2m_info):
        """
        检查nvn设置情况  nvn指的是本表和其他表存在多对多对应关系，例如本表是student表，还有一个lecture表，另有一个student_lecture表用于保存学生选课记录
        """
        _flag = False
        if not m2m_info:
            return False
        for item in m2m_info:
            if isinstance(item.get('search_info', ''), (tuple, list)) and len(item['search_info']) == 2:
                flag = True
                for index, search_info in enumerate(item['search_info']):
                    if search_info.get('table', ''):
                        if index:
                            cls.check_nv1_item(search_info)
                        else:
                            cls.check_1vn_item(search_info)
                    else:
                        flag = False

                if flag:
                    if not item.get('show_name', None):
                        item['show_name'] = f"{item['search_info'][0].get('table', '')}_list"
                    _flag = True

        return _flag

    @classmethod
    def check_content_info(cls, content_info):
        """
        检查1vn的设置情况  1vn指的是本表为父表（如product_category表，对应product表，表中含有product_category_id字段）
        """
        flag = False
        if not content_info:
            return False
        for item in content_info:
            if item.get('table', ''):
                if not item.get('show_name', None):
                    item['show_name'] = f"{item.get('table', '')}_list"
                cls.check_1vn_item(item)
                flag = True
            else:
                item['show_name'] = ""

        return flag

    @classmethod
    def check_1vn_item(cls, item):
        """
        检查1vn的单条设置情况
        """
        if item.get("fk_ids", None):
            if isinstance(item['fk_ids'], str):
                item['fk_ids'] = {"id": item['fk_ids']}

        if not isinstance(item['fk_ids'], dict):
            item['fk_ids'] = {"id": "id"}

        if not isinstance(item.get('columns', None), (tuple, list)):
            item['columns'] = ["id", "name"]

        if 'show_name' in item and item.get('1v1', None) and not item.get('update_fields', None):
            item['update_fields'] = {item['show_name']: item['show_name']}
