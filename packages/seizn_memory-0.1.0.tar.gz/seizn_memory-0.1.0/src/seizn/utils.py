"""Utility functions for Seizn SDK."""

import os
from typing import Any, Dict, Optional

from .errors import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    SeizinError,
    ServerError,
    ValidationError,
)


def get_api_key_from_env() -> Optional[str]:
    """Get API key from environment variable.

    Returns:
        API key if found, None otherwise
    """
    return os.environ.get("SEIZN_API_KEY")


def get_base_url_from_env() -> str:
    """Get base URL from environment variable.

    Returns:
        Base URL, defaults to production API
    """
    return os.environ.get("SEIZN_API_URL", "https://seizn.com")


def handle_response_error(status_code: int, response_data: Dict[str, Any]) -> None:
    """Handle API error responses.

    Args:
        status_code: HTTP status code
        response_data: Response data from API

    Raises:
        AuthenticationError: For 401 responses
        ValidationError: For 400 responses
        NotFoundError: For 404 responses
        RateLimitError: For 429 responses
        ServerError: For 5xx responses
        SeizinError: For other error responses
    """
    error_message = response_data.get("error", "Unknown error")

    if status_code == 401:
        raise AuthenticationError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 400:
        raise ValidationError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
            errors=response_data.get("errors"),
        )
    elif status_code == 404:
        raise NotFoundError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 429:
        retry_after = response_data.get("retry_after")
        raise RateLimitError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
            retry_after=int(retry_after) if retry_after else None,
        )
    elif 500 <= status_code < 600:
        raise ServerError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
        )
    else:
        raise SeizinError(
            message=error_message,
            status_code=status_code,
            response_data=response_data,
        )


def build_query_params(**kwargs: Any) -> Dict[str, Any]:
    """Build query parameters, filtering out None values.

    Args:
        **kwargs: Key-value pairs for query parameters

    Returns:
        Dict with non-None values
    """
    return {k: v for k, v in kwargs.items() if v is not None}


def sanitize_namespace(namespace: Optional[str]) -> Optional[str]:
    """Sanitize namespace string.

    Args:
        namespace: Raw namespace string

    Returns:
        Sanitized namespace or None
    """
    if namespace is None:
        return None

    # Remove leading/trailing whitespace
    namespace = namespace.strip()

    # Replace spaces with hyphens
    namespace = namespace.replace(" ", "-")

    # Convert to lowercase
    namespace = namespace.lower()

    # Remove invalid characters (keep alphanumeric, hyphens, underscores)
    namespace = "".join(c for c in namespace if c.isalnum() or c in "-_")

    return namespace if namespace else None


def format_tags(tags: Optional[list]) -> Optional[list]:
    """Format tags list.

    Args:
        tags: Raw tags list

    Returns:
        Formatted tags list or None
    """
    if tags is None:
        return None

    # Remove duplicates and empty strings
    formatted = list(set(tag.strip().lower() for tag in tags if tag and tag.strip()))

    return formatted if formatted else None
