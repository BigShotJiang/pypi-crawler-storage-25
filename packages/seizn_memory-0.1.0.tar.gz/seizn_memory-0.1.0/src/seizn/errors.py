"""Exception classes for Seizn SDK."""

from typing import Any, Dict, Optional


class SeizinError(Exception):
    """Base exception for all Seizn SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize SeizinError.

        Args:
            message: Error message
            status_code: HTTP status code if applicable
            response_data: Raw response data from API
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data

    def __str__(self) -> str:
        """Return string representation of error."""
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message

    def __repr__(self) -> str:
        """Return repr of error."""
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(SeizinError):
    """Raised when API key is invalid or missing."""

    def __init__(
        self,
        message: str = "Invalid or missing API key",
        status_code: int = 401,
        response_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize AuthenticationError."""
        super().__init__(message, status_code, response_data)


class RateLimitError(SeizinError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        status_code: int = 429,
        response_data: Optional[Dict[str, Any]] = None,
        retry_after: Optional[int] = None,
    ) -> None:
        """Initialize RateLimitError.

        Args:
            message: Error message
            status_code: HTTP status code
            response_data: Raw response data
            retry_after: Seconds to wait before retrying
        """
        super().__init__(message, status_code, response_data)
        self.retry_after = retry_after


class NotFoundError(SeizinError):
    """Raised when a resource is not found."""

    def __init__(
        self,
        message: str = "Resource not found",
        status_code: int = 404,
        response_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize NotFoundError."""
        super().__init__(message, status_code, response_data)


class ValidationError(SeizinError):
    """Raised when request validation fails."""

    def __init__(
        self,
        message: str = "Validation error",
        status_code: int = 400,
        response_data: Optional[Dict[str, Any]] = None,
        errors: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize ValidationError.

        Args:
            message: Error message
            status_code: HTTP status code
            response_data: Raw response data
            errors: Detailed validation errors
        """
        super().__init__(message, status_code, response_data)
        self.errors = errors


class ServerError(SeizinError):
    """Raised when server returns 5xx error."""

    def __init__(
        self,
        message: str = "Server error",
        status_code: int = 500,
        response_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize ServerError."""
        super().__init__(message, status_code, response_data)


class NetworkError(SeizinError):
    """Raised when network connection fails."""

    def __init__(
        self,
        message: str = "Network connection error",
        original_error: Optional[Exception] = None,
    ) -> None:
        """Initialize NetworkError.

        Args:
            message: Error message
            original_error: The original exception that caused this error
        """
        super().__init__(message)
        self.original_error = original_error


class TimeoutError(SeizinError):
    """Raised when request times out."""

    def __init__(
        self,
        message: str = "Request timed out",
        timeout: Optional[float] = None,
    ) -> None:
        """Initialize TimeoutError.

        Args:
            message: Error message
            timeout: The timeout value that was exceeded
        """
        super().__init__(message)
        self.timeout = timeout
