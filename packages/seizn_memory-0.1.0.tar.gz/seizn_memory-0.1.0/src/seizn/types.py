"""Type definitions for Seizn Memory API."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator


class MemoryType(str, Enum):
    """Memory type categories."""

    FACT = "fact"
    PREFERENCE = "preference"
    EXPERIENCE = "experience"
    RELATIONSHIP = "relationship"
    INSTRUCTION = "instruction"


class Memory(BaseModel):
    """Represents a memory stored in Seizn."""

    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(..., description="Unique identifier for the memory")
    content: str = Field(..., description="The memory content")
    memory_type: Union[MemoryType, str] = Field(
        default=MemoryType.FACT, description="Type of memory"
    )
    importance: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Importance score (0.0-1.0)"
    )
    namespace: Optional[str] = Field(
        default=None, description="Namespace for organizing memories"
    )
    tags: List[str] = Field(default_factory=list, description="Tags for categorization")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")


class MemoryCreate(BaseModel):
    """Input model for creating a memory."""

    model_config = ConfigDict(use_enum_values=True)

    content: str = Field(..., description="The memory content")
    memory_type: Union[MemoryType, str] = Field(
        default=MemoryType.FACT, description="Type of memory"
    )
    importance: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Importance score (0.0-1.0)"
    )
    namespace: Optional[str] = Field(
        default=None, description="Namespace for organizing memories"
    )
    tags: Optional[List[str]] = Field(
        default=None, description="Tags for categorization"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )

    @field_validator("tags", mode="before")
    @classmethod
    def convert_none_tags(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Convert None to empty list for serialization."""
        return v if v else None


class MemoryUpdate(BaseModel):
    """Input model for updating a memory."""

    model_config = ConfigDict(use_enum_values=True)

    content: Optional[str] = Field(default=None, description="The memory content")
    memory_type: Optional[Union[MemoryType, str]] = Field(
        default=None, description="Type of memory"
    )
    importance: Optional[float] = Field(
        default=None, ge=0.0, le=1.0, description="Importance score (0.0-1.0)"
    )
    namespace: Optional[str] = Field(
        default=None, description="Namespace for organizing memories"
    )
    tags: Optional[List[str]] = Field(default=None, description="Tags for categorization")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata"
    )


class SearchResult(BaseModel):
    """Search result with relevance score."""

    memory: Memory = Field(..., description="The matched memory")
    score: float = Field(..., description="Relevance score")


class ListOptions(BaseModel):
    """Options for listing memories."""

    model_config = ConfigDict(use_enum_values=True)

    namespace: Optional[str] = Field(default=None, description="Filter by namespace")
    memory_type: Optional[Union[MemoryType, str]] = Field(
        default=None, description="Filter by memory type"
    )
    tags: Optional[List[str]] = Field(default=None, description="Filter by tags")
    limit: int = Field(default=100, ge=1, le=1000, description="Maximum results")
    offset: int = Field(default=0, ge=0, description="Pagination offset")


class SearchOptions(BaseModel):
    """Options for searching memories."""

    model_config = ConfigDict(use_enum_values=True)

    namespace: Optional[str] = Field(default=None, description="Filter by namespace")
    memory_type: Optional[Union[MemoryType, str]] = Field(
        default=None, description="Filter by memory type"
    )
    tags: Optional[List[str]] = Field(default=None, description="Filter by tags")
    limit: int = Field(default=10, ge=1, le=100, description="Maximum results")
    threshold: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Minimum relevance score"
    )


class APIResponse(BaseModel):
    """Standard API response wrapper."""

    success: bool = Field(..., description="Whether the request was successful")
    data: Optional[Any] = Field(default=None, description="Response data")
    error: Optional[str] = Field(default=None, description="Error message if failed")
