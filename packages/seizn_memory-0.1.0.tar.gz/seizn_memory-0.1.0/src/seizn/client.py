"""Seizn Memory API client implementations."""

from typing import Any, Dict, List, Optional, Union

import httpx

from .errors import AuthenticationError, NetworkError, TimeoutError as SeizinTimeoutError
from .types import (
    ListOptions,
    Memory,
    MemoryCreate,
    MemoryType,
    MemoryUpdate,
    SearchOptions,
    SearchResult,
)
from .utils import (
    build_query_params,
    format_tags,
    get_api_key_from_env,
    get_base_url_from_env,
    handle_response_error,
    sanitize_namespace,
)


class NamespacedClient:
    """A client scoped to a specific namespace."""

    def __init__(self, client: "SeizinClient", namespace: str) -> None:
        """Initialize namespaced client.

        Args:
            client: Parent SeizinClient instance
            namespace: Namespace to scope operations to
        """
        self._client = client
        self._namespace = sanitize_namespace(namespace) or namespace

    def add(
        self,
        content: str,
        memory_type: Union[MemoryType, str] = MemoryType.FACT,
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Add a memory in this namespace."""
        return self._client.add(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=self._namespace,
            tags=tags,
            metadata=metadata,
        )

    def search(
        self,
        query: str,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 10,
        threshold: float = 0.0,
    ) -> List[SearchResult]:
        """Search memories in this namespace."""
        return self._client.search(
            query=query,
            namespace=self._namespace,
            memory_type=memory_type,
            tags=tags,
            limit=limit,
            threshold=threshold,
        )

    def list(
        self,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        """List memories in this namespace."""
        return self._client.list(
            namespace=self._namespace,
            memory_type=memory_type,
            tags=tags,
            limit=limit,
            offset=offset,
        )


class AsyncNamespacedClient:
    """An async client scoped to a specific namespace."""

    def __init__(self, client: "AsyncSeizinClient", namespace: str) -> None:
        """Initialize async namespaced client.

        Args:
            client: Parent AsyncSeizinClient instance
            namespace: Namespace to scope operations to
        """
        self._client = client
        self._namespace = sanitize_namespace(namespace) or namespace

    async def add(
        self,
        content: str,
        memory_type: Union[MemoryType, str] = MemoryType.FACT,
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Add a memory in this namespace."""
        return await self._client.add(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=self._namespace,
            tags=tags,
            metadata=metadata,
        )

    async def search(
        self,
        query: str,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 10,
        threshold: float = 0.0,
    ) -> List[SearchResult]:
        """Search memories in this namespace."""
        return await self._client.search(
            query=query,
            namespace=self._namespace,
            memory_type=memory_type,
            tags=tags,
            limit=limit,
            threshold=threshold,
        )

    async def list(
        self,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        """List memories in this namespace."""
        return await self._client.list(
            namespace=self._namespace,
            memory_type=memory_type,
            tags=tags,
            limit=limit,
            offset=offset,
        )


class SeizinClient:
    """Synchronous client for Seizn Memory API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize SeizinClient.

        Args:
            api_key: API key for authentication. If not provided, reads from
                     SEIZN_API_KEY environment variable.
            base_url: Base URL for API. Defaults to https://seizn.com
            timeout: Request timeout in seconds

        Raises:
            AuthenticationError: If no API key is provided or found
        """
        self._api_key = api_key or get_api_key_from_env()
        if not self._api_key:
            raise AuthenticationError(
                "API key is required. Provide it as argument or set SEIZN_API_KEY environment variable."
            )

        self._base_url = (base_url or get_base_url_from_env()).rstrip("/")
        self._timeout = timeout
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=self._get_headers(),
            timeout=timeout,
        )

    def _get_headers(self) -> Dict[str, str]:
        """Get default headers for requests."""
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "User-Agent": "seizn-python/0.1.0",
        }

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make HTTP request to API.

        Args:
            method: HTTP method
            path: API path
            json: JSON body
            params: Query parameters

        Returns:
            Response data

        Raises:
            NetworkError: On connection errors
            SeizinTimeoutError: On timeout
            Various SeizinError subclasses on API errors
        """
        try:
            response = self._client.request(
                method=method,
                url=path,
                json=json,
                params=params,
            )
        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to {self._base_url}",
                original_error=e,
            )
        except httpx.TimeoutException as e:
            raise SeizinTimeoutError(
                message=f"Request timed out after {self._timeout}s",
                timeout=self._timeout,
            )

        response_data = response.json()

        if not response.is_success:
            handle_response_error(response.status_code, response_data)

        return response_data

    def add(
        self,
        content: str,
        memory_type: Union[MemoryType, str] = MemoryType.FACT,
        importance: float = 0.5,
        namespace: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Add a new memory.

        Args:
            content: The memory content
            memory_type: Type of memory (fact, preference, experience, relationship, instruction)
            importance: Importance score (0.0-1.0)
            namespace: Optional namespace for organizing memories
            tags: Optional list of tags
            metadata: Optional additional metadata

        Returns:
            The created Memory object

        Example:
            >>> client = SeizinClient(api_key="your-api-key")
            >>> memory = client.add(
            ...     content="User prefers dark mode",
            ...     memory_type="preference",
            ...     importance=0.8,
            ...     tags=["ui", "settings"]
            ... )
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        create_data = MemoryCreate(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=sanitize_namespace(namespace),
            tags=format_tags(tags),
            metadata=metadata,
        )

        response = self._request(
            method="POST",
            path="/v1/memories",
            json=create_data.model_dump(exclude_none=True),
        )

        return Memory(**response["data"])

    def search(
        self,
        query: str,
        namespace: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 10,
        threshold: float = 0.0,
    ) -> List[SearchResult]:
        """Search memories by semantic similarity.

        Args:
            query: Search query
            namespace: Filter by namespace
            memory_type: Filter by memory type
            tags: Filter by tags
            limit: Maximum number of results (1-100)
            threshold: Minimum relevance score (0.0-1.0)

        Returns:
            List of SearchResult objects with memories and scores

        Example:
            >>> results = client.search("user preferences for UI")
            >>> for result in results:
            ...     print(f"{result.score:.2f}: {result.memory.content}")
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        options = SearchOptions(
            namespace=sanitize_namespace(namespace),
            memory_type=memory_type,
            tags=format_tags(tags),
            limit=limit,
            threshold=threshold,
        )

        params = build_query_params(
            q=query,
            **options.model_dump(exclude_none=True),
        )

        response = self._request(
            method="GET",
            path="/v1/memories/search",
            params=params,
        )

        return [
            SearchResult(
                memory=Memory(**item["memory"]),
                score=item["score"],
            )
            for item in response["data"]
        ]

    def get(self, memory_id: str) -> Memory:
        """Get a specific memory by ID.

        Args:
            memory_id: The memory ID

        Returns:
            The Memory object

        Raises:
            NotFoundError: If memory not found
        """
        response = self._request(
            method="GET",
            path=f"/v1/memories/{memory_id}",
        )

        return Memory(**response["data"])

    def update(
        self,
        memory_id: str,
        content: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        importance: Optional[float] = None,
        namespace: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Update an existing memory.

        Args:
            memory_id: The memory ID to update
            content: New content (optional)
            memory_type: New memory type (optional)
            importance: New importance score (optional)
            namespace: New namespace (optional)
            tags: New tags (optional)
            metadata: New metadata (optional)

        Returns:
            The updated Memory object
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        update_data = MemoryUpdate(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=sanitize_namespace(namespace) if namespace else None,
            tags=format_tags(tags) if tags else None,
            metadata=metadata,
        )

        response = self._request(
            method="PATCH",
            path=f"/v1/memories/{memory_id}",
            json=update_data.model_dump(exclude_none=True),
        )

        return Memory(**response["data"])

    def delete(self, memory_id: str) -> None:
        """Delete a memory.

        Args:
            memory_id: The memory ID to delete

        Raises:
            NotFoundError: If memory not found
        """
        self._request(
            method="DELETE",
            path=f"/v1/memories/{memory_id}",
        )

    def list(
        self,
        namespace: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        """List memories with optional filters.

        Args:
            namespace: Filter by namespace
            memory_type: Filter by memory type
            tags: Filter by tags
            limit: Maximum number of results (1-1000)
            offset: Pagination offset

        Returns:
            List of Memory objects
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        options = ListOptions(
            namespace=sanitize_namespace(namespace),
            memory_type=memory_type,
            tags=format_tags(tags),
            limit=limit,
            offset=offset,
        )

        response = self._request(
            method="GET",
            path="/v1/memories",
            params=options.model_dump(exclude_none=True),
        )

        return [Memory(**item) for item in response["data"]]

    def namespace(self, name: str) -> NamespacedClient:
        """Get a namespaced client for scoped operations.

        Args:
            name: Namespace name

        Returns:
            NamespacedClient instance

        Example:
            >>> project = client.namespace("my-project")
            >>> project.add("Project-specific memory")
            >>> memories = project.list()
        """
        return NamespacedClient(self, name)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "SeizinClient":
        """Enter context manager."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context manager."""
        self.close()


class AsyncSeizinClient:
    """Asynchronous client for Seizn Memory API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize AsyncSeizinClient.

        Args:
            api_key: API key for authentication. If not provided, reads from
                     SEIZN_API_KEY environment variable.
            base_url: Base URL for API. Defaults to https://seizn.com
            timeout: Request timeout in seconds

        Raises:
            AuthenticationError: If no API key is provided or found
        """
        self._api_key = api_key or get_api_key_from_env()
        if not self._api_key:
            raise AuthenticationError(
                "API key is required. Provide it as argument or set SEIZN_API_KEY environment variable."
            )

        self._base_url = (base_url or get_base_url_from_env()).rstrip("/")
        self._timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=self._get_headers(),
            timeout=timeout,
        )

    def _get_headers(self) -> Dict[str, str]:
        """Get default headers for requests."""
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "User-Agent": "seizn-python/0.1.0",
        }

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make async HTTP request to API."""
        try:
            response = await self._client.request(
                method=method,
                url=path,
                json=json,
                params=params,
            )
        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to {self._base_url}",
                original_error=e,
            )
        except httpx.TimeoutException as e:
            raise SeizinTimeoutError(
                message=f"Request timed out after {self._timeout}s",
                timeout=self._timeout,
            )

        response_data = response.json()

        if not response.is_success:
            handle_response_error(response.status_code, response_data)

        return response_data

    async def add(
        self,
        content: str,
        memory_type: Union[MemoryType, str] = MemoryType.FACT,
        importance: float = 0.5,
        namespace: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Add a new memory (async).

        See SeizinClient.add for full documentation.
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        create_data = MemoryCreate(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=sanitize_namespace(namespace),
            tags=format_tags(tags),
            metadata=metadata,
        )

        response = await self._request(
            method="POST",
            path="/v1/memories",
            json=create_data.model_dump(exclude_none=True),
        )

        return Memory(**response["data"])

    async def search(
        self,
        query: str,
        namespace: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 10,
        threshold: float = 0.0,
    ) -> List[SearchResult]:
        """Search memories by semantic similarity (async).

        See SeizinClient.search for full documentation.
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        options = SearchOptions(
            namespace=sanitize_namespace(namespace),
            memory_type=memory_type,
            tags=format_tags(tags),
            limit=limit,
            threshold=threshold,
        )

        params = build_query_params(
            q=query,
            **options.model_dump(exclude_none=True),
        )

        response = await self._request(
            method="GET",
            path="/v1/memories/search",
            params=params,
        )

        return [
            SearchResult(
                memory=Memory(**item["memory"]),
                score=item["score"],
            )
            for item in response["data"]
        ]

    async def get(self, memory_id: str) -> Memory:
        """Get a specific memory by ID (async).

        See SeizinClient.get for full documentation.
        """
        response = await self._request(
            method="GET",
            path=f"/v1/memories/{memory_id}",
        )

        return Memory(**response["data"])

    async def update(
        self,
        memory_id: str,
        content: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        importance: Optional[float] = None,
        namespace: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Update an existing memory (async).

        See SeizinClient.update for full documentation.
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        update_data = MemoryUpdate(
            content=content,
            memory_type=memory_type,
            importance=importance,
            namespace=sanitize_namespace(namespace) if namespace else None,
            tags=format_tags(tags) if tags else None,
            metadata=metadata,
        )

        response = await self._request(
            method="PATCH",
            path=f"/v1/memories/{memory_id}",
            json=update_data.model_dump(exclude_none=True),
        )

        return Memory(**response["data"])

    async def delete(self, memory_id: str) -> None:
        """Delete a memory (async).

        See SeizinClient.delete for full documentation.
        """
        await self._request(
            method="DELETE",
            path=f"/v1/memories/{memory_id}",
        )

    async def list(
        self,
        namespace: Optional[str] = None,
        memory_type: Optional[Union[MemoryType, str]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        """List memories with optional filters (async).

        See SeizinClient.list for full documentation.
        """
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type)

        options = ListOptions(
            namespace=sanitize_namespace(namespace),
            memory_type=memory_type,
            tags=format_tags(tags),
            limit=limit,
            offset=offset,
        )

        response = await self._request(
            method="GET",
            path="/v1/memories",
            params=options.model_dump(exclude_none=True),
        )

        return [Memory(**item) for item in response["data"]]

    def namespace(self, name: str) -> AsyncNamespacedClient:
        """Get a namespaced client for scoped operations (async).

        See SeizinClient.namespace for full documentation.
        """
        return AsyncNamespacedClient(self, name)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncSeizinClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager."""
        await self.close()
