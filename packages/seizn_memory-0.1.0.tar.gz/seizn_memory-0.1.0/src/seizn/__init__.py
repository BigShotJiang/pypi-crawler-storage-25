"""Seizn Memory API Python SDK.

Official Python SDK for the Seizn Memory API, providing both synchronous
and asynchronous clients for managing AI memories.

Basic Usage:
    >>> from seizn import SeizinClient
    >>> client = SeizinClient(api_key="your-api-key")
    >>> memory = client.add("Important fact to remember")
    >>> results = client.search("find relevant memories")

Async Usage:
    >>> from seizn import AsyncSeizinClient
    >>> async with AsyncSeizinClient(api_key="your-api-key") as client:
    ...     memory = await client.add("Important fact")
    ...     results = await client.search("find memories")

For more information, visit https://docs.seizn.com/sdk/python
"""

from .client import AsyncSeizinClient, SeizinClient
from .errors import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    SeizinError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .types import (
    ListOptions,
    Memory,
    MemoryCreate,
    MemoryType,
    MemoryUpdate,
    SearchOptions,
    SearchResult,
)

__version__ = "0.1.0"
__author__ = "Seizn"
__email__ = "dev@seizn.com"

__all__ = [
    # Clients
    "SeizinClient",
    "AsyncSeizinClient",
    # Types
    "Memory",
    "MemoryCreate",
    "MemoryUpdate",
    "MemoryType",
    "SearchResult",
    "ListOptions",
    "SearchOptions",
    # Errors
    "SeizinError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "NetworkError",
    "TimeoutError",
    # Version
    "__version__",
]
