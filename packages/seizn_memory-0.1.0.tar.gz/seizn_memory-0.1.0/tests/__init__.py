"""Tests for Seizn SDK."""
