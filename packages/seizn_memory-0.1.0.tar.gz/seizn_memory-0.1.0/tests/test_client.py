"""Tests for SeizinClient and AsyncSeizinClient."""

import json
from datetime import datetime
from unittest.mock import MagicMock, patch

import httpx
import pytest

from seizn import (
    AsyncSeizinClient,
    AuthenticationError,
    Memory,
    MemoryType,
    NetworkError,
    NotFoundError,
    RateLimitError,
    SearchResult,
    SeizinClient,
    SeizinError,
    ServerError,
    TimeoutError,
    ValidationError,
)


# Test fixtures
@pytest.fixture
def api_key():
    """Test API key."""
    return "test-api-key-12345"


@pytest.fixture
def base_url():
    """Test base URL."""
    return "https://api.seizn.test"


@pytest.fixture
def sample_memory_data():
    """Sample memory response data."""
    return {
        "id": "mem_123456",
        "content": "Test memory content",
        "memory_type": "fact",
        "importance": 0.8,
        "namespace": "test-namespace",
        "tags": ["test", "sample"],
        "metadata": {"key": "value"},
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }


@pytest.fixture
def sample_search_result(sample_memory_data):
    """Sample search result data."""
    return {
        "memory": sample_memory_data,
        "score": 0.95,
    }


# Client initialization tests
class TestClientInitialization:
    """Tests for client initialization."""

    def test_init_with_api_key(self, api_key, base_url):
        """Test client initialization with API key."""
        client = SeizinClient(api_key=api_key, base_url=base_url)
        assert client._api_key == api_key
        assert client._base_url == base_url
        client.close()

    def test_init_without_api_key_raises_error(self):
        """Test that initialization without API key raises error."""
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(AuthenticationError) as exc_info:
                SeizinClient()
            assert "API key is required" in str(exc_info.value)

    def test_init_from_environment(self, api_key):
        """Test client initialization from environment variable."""
        with patch.dict("os.environ", {"SEIZN_API_KEY": api_key}):
            client = SeizinClient()
            assert client._api_key == api_key
            client.close()

    def test_default_base_url(self, api_key):
        """Test default base URL."""
        client = SeizinClient(api_key=api_key)
        assert client._base_url == "https://seizn.com"
        client.close()

    def test_custom_timeout(self, api_key, base_url):
        """Test custom timeout."""
        client = SeizinClient(api_key=api_key, base_url=base_url, timeout=60.0)
        assert client._timeout == 60.0
        client.close()

    def test_context_manager(self, api_key, base_url):
        """Test client as context manager."""
        with SeizinClient(api_key=api_key, base_url=base_url) as client:
            assert client._api_key == api_key


# Sync client tests
class TestSeizinClient:
    """Tests for synchronous client."""

    @pytest.fixture
    def client(self, api_key, base_url):
        """Create test client."""
        client = SeizinClient(api_key=api_key, base_url=base_url)
        yield client
        client.close()

    def test_add_memory(self, client, sample_memory_data):
        """Test adding a memory."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": sample_memory_data},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            memory = client.add(
                content="Test memory content",
                memory_type="fact",
                importance=0.8,
                namespace="test-namespace",
                tags=["test", "sample"],
                metadata={"key": "value"},
            )

            assert isinstance(memory, Memory)
            assert memory.id == "mem_123456"
            assert memory.content == "Test memory content"
            assert memory.memory_type == MemoryType.FACT
            assert memory.importance == 0.8

    def test_search_memories(self, client, sample_search_result):
        """Test searching memories."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": [sample_search_result]},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            results = client.search(
                query="test query",
                namespace="test-namespace",
                limit=10,
            )

            assert len(results) == 1
            assert isinstance(results[0], SearchResult)
            assert results[0].score == 0.95
            assert results[0].memory.id == "mem_123456"

    def test_get_memory(self, client, sample_memory_data):
        """Test getting a memory by ID."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": sample_memory_data},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            memory = client.get("mem_123456")

            assert isinstance(memory, Memory)
            assert memory.id == "mem_123456"

    def test_update_memory(self, client, sample_memory_data):
        """Test updating a memory."""
        updated_data = {**sample_memory_data, "content": "Updated content"}
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": updated_data},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            memory = client.update(
                memory_id="mem_123456",
                content="Updated content",
            )

            assert memory.content == "Updated content"

    def test_delete_memory(self, client):
        """Test deleting a memory."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": None},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            # Should not raise
            client.delete("mem_123456")

    def test_list_memories(self, client, sample_memory_data):
        """Test listing memories."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": [sample_memory_data]},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            memories = client.list(
                namespace="test-namespace",
                memory_type="fact",
                limit=50,
            )

            assert len(memories) == 1
            assert isinstance(memories[0], Memory)

    def test_namespace_client(self, client, sample_memory_data):
        """Test namespaced client."""
        ns_client = client.namespace("my-project")

        mock_response = httpx.Response(
            200,
            json={"success": True, "data": sample_memory_data},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            memory = ns_client.add("Test content")
            assert isinstance(memory, Memory)


# Error handling tests
class TestErrorHandling:
    """Tests for error handling."""

    @pytest.fixture
    def client(self, api_key, base_url):
        """Create test client."""
        client = SeizinClient(api_key=api_key, base_url=base_url)
        yield client
        client.close()

    def test_authentication_error(self, client):
        """Test 401 error handling."""
        mock_response = httpx.Response(
            401,
            json={"error": "Invalid API key"},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            with pytest.raises(AuthenticationError) as exc_info:
                client.get("mem_123456")
            assert exc_info.value.status_code == 401

    def test_not_found_error(self, client):
        """Test 404 error handling."""
        mock_response = httpx.Response(
            404,
            json={"error": "Memory not found"},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            with pytest.raises(NotFoundError) as exc_info:
                client.get("mem_nonexistent")
            assert exc_info.value.status_code == 404

    def test_validation_error(self, client):
        """Test 400 error handling."""
        mock_response = httpx.Response(
            400,
            json={"error": "Validation failed", "errors": {"content": "required"}},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            with pytest.raises(ValidationError) as exc_info:
                client.add(content="")
            assert exc_info.value.status_code == 400

    def test_rate_limit_error(self, client):
        """Test 429 error handling."""
        mock_response = httpx.Response(
            429,
            json={"error": "Rate limit exceeded", "retry_after": 60},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            with pytest.raises(RateLimitError) as exc_info:
                client.list()
            assert exc_info.value.status_code == 429
            assert exc_info.value.retry_after == 60

    def test_server_error(self, client):
        """Test 500 error handling."""
        mock_response = httpx.Response(
            500,
            json={"error": "Internal server error"},
        )

        with patch.object(client._client, "request", return_value=mock_response):
            with pytest.raises(ServerError) as exc_info:
                client.list()
            assert exc_info.value.status_code == 500

    def test_network_error(self, client):
        """Test network connection error."""
        with patch.object(
            client._client,
            "request",
            side_effect=httpx.ConnectError("Connection refused"),
        ):
            with pytest.raises(NetworkError) as exc_info:
                client.list()
            assert "Failed to connect" in str(exc_info.value)

    def test_timeout_error(self, client):
        """Test timeout error."""
        with patch.object(
            client._client,
            "request",
            side_effect=httpx.TimeoutException("Request timed out"),
        ):
            with pytest.raises(TimeoutError) as exc_info:
                client.list()
            assert "timed out" in str(exc_info.value)


# Async client tests
class TestAsyncSeizinClient:
    """Tests for asynchronous client."""

    @pytest.fixture
    def async_client(self, api_key, base_url):
        """Create async test client."""
        return AsyncSeizinClient(api_key=api_key, base_url=base_url)

    @pytest.mark.asyncio
    async def test_async_add_memory(self, async_client, sample_memory_data):
        """Test async adding a memory."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": sample_memory_data},
        )

        with patch.object(async_client._client, "request", return_value=mock_response):
            memory = await async_client.add(
                content="Test memory content",
                memory_type="fact",
            )

            assert isinstance(memory, Memory)
            assert memory.id == "mem_123456"

        await async_client.close()

    @pytest.mark.asyncio
    async def test_async_search_memories(self, async_client, sample_search_result):
        """Test async searching memories."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": [sample_search_result]},
        )

        with patch.object(async_client._client, "request", return_value=mock_response):
            results = await async_client.search(query="test query")

            assert len(results) == 1
            assert isinstance(results[0], SearchResult)

        await async_client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager(self, api_key, base_url, sample_memory_data):
        """Test async client as context manager."""
        mock_response = httpx.Response(
            200,
            json={"success": True, "data": [sample_memory_data]},
        )

        async with AsyncSeizinClient(api_key=api_key, base_url=base_url) as client:
            with patch.object(client._client, "request", return_value=mock_response):
                memories = await client.list()
                assert len(memories) == 1


# Utility tests
class TestUtilities:
    """Tests for utility functions."""

    def test_sanitize_namespace(self):
        """Test namespace sanitization."""
        from seizn.utils import sanitize_namespace

        assert sanitize_namespace("My Project") == "my-project"
        assert sanitize_namespace("  spaces  ") == "spaces"
        assert sanitize_namespace("special!@#chars") == "specialchars"
        assert sanitize_namespace(None) is None
        assert sanitize_namespace("") is None

    def test_format_tags(self):
        """Test tags formatting."""
        from seizn.utils import format_tags

        result = format_tags(["Tag1", "TAG2", "tag1"])
        assert set(result) == {"tag1", "tag2"}
        assert format_tags(["  spaced  ", ""]) == ["spaced"]
        assert format_tags(None) is None
        assert format_tags([]) is None

    def test_build_query_params(self):
        """Test query params building."""
        from seizn.utils import build_query_params

        result = build_query_params(a=1, b=None, c="test")
        assert result == {"a": 1, "c": "test"}
        assert "b" not in result


# Type tests
class TestTypes:
    """Tests for type definitions."""

    def test_memory_type_enum(self):
        """Test MemoryType enum values."""
        assert MemoryType.FACT.value == "fact"
        assert MemoryType.PREFERENCE.value == "preference"
        assert MemoryType.EXPERIENCE.value == "experience"
        assert MemoryType.RELATIONSHIP.value == "relationship"
        assert MemoryType.INSTRUCTION.value == "instruction"

    def test_memory_model(self, sample_memory_data):
        """Test Memory model."""
        memory = Memory(**sample_memory_data)

        assert memory.id == "mem_123456"
        assert memory.content == "Test memory content"
        assert memory.memory_type == "fact"
        assert memory.importance == 0.8
        assert memory.namespace == "test-namespace"
        assert memory.tags == ["test", "sample"]
        assert memory.metadata == {"key": "value"}

    def test_memory_validation(self):
        """Test Memory validation."""
        with pytest.raises(Exception):  # Pydantic ValidationError
            Memory(
                id="test",
                content="test",
                importance=1.5,  # Invalid: > 1.0
                created_at=datetime.now(),
                updated_at=datetime.now(),
            )
