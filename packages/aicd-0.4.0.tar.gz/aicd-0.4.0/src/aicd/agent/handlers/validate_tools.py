from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicd.kit import script_syntax, validate_viz

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _viz_spec_validate(_router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    op = str(args.get("operation") or "")
    payload = {k: v for k, v in args.items() if k != "operation"}
    return validate_viz.run_operation(op, payload)


def _script_syntax_check(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    kind = str(args.get("kind") or args.get("language") or "").strip()
    if not kind:
        return {"ok": False, "error": "kind (or language) is required, e.g. py|js|bash|ps1|bat"}
    path_str = args.get("path")
    source = args.get("source")
    if path_str is not None and str(path_str).strip():
        p = router._resolve_path(str(path_str))
        return script_syntax.run_check(kind, source=None, file_path=p)
    if source is None:
        return {"ok": False, "error": "provide source (string) or path (under workspace policy)"}
    return script_syntax.run_check(kind, source=str(source), file_path=None)


HANDLERS: dict[str, Any] = {
    "viz_spec_validate": _viz_spec_validate,
    "script_syntax_check": _script_syntax_check,
}
