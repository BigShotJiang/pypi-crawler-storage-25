from __future__ import annotations

from typing import TYPE_CHECKING, Any, Awaitable, Callable

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter

Handler = Callable[["ToolRouter", dict[str, Any]], dict[str, Any] | Awaitable[dict[str, Any]]]


def tool_handlers() -> dict[str, Handler]:
    from aicd.agent.handlers import (
        agent_settings,
        ai_viz,
        chat_history,
        data_kit,
        db_remote,
        desktop_gui,
        doc_project_handlers,
        doc_browser_code,
        drawio_tools,
        fs,
        media_tools,
        net_tools,
        plugin_tools,
        visio_tools,
        runtime_env,
        site_bookmarks_handlers,
        tasks,
        text_process,
        validate_tools,
        vision,
    )

    h: dict[str, Handler] = {}
    for m in (
        fs,
        plugin_tools,
        text_process,
        tasks,
        doc_browser_code,
        doc_project_handlers,
        drawio_tools,
        visio_tools,
        media_tools,
        net_tools,
        data_kit,
        desktop_gui,
        ai_viz,
        db_remote,
        runtime_env,
        site_bookmarks_handlers,
        agent_settings,
        chat_history,
        validate_tools,
        vision,
    ):
        h.update(m.HANDLERS)
    return h
