from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _fs_list_dir(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.list_dir(args["path"])


def _fs_read_file(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.read_file(args["path"])


def _fs_write_file(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.write_file(args["path"], args["content"])


def _fs_delete(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.delete_path(args["path"], dry_run=bool(args.get("dry_run")))


def _fs_mkdir(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.mkdir(args["path"])


def _fs_move(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.move(args["from_path"], args["to_path"])


def _fs_glob(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.glob_names(args["directory"], args["pattern"])


def _fs_search_regex(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return router._fs.search_content_regex(
        args["directory"],
        args["regex"],
        glob_filter=str(args.get("glob_filter", "*")),
    )


HANDLERS: dict[str, Any] = {
    "fs_list_dir": _fs_list_dir,
    "fs_read_file": _fs_read_file,
    "fs_write_file": _fs_write_file,
    "fs_delete": _fs_delete,
    "fs_mkdir": _fs_mkdir,
    "fs_move": _fs_move,
    "fs_glob": _fs_glob,
    "fs_search_regex": _fs_search_regex,
}
