from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="MarkReadBody")


@_attrs_define
class MarkReadBody:
    """
    Attributes:
        up_to_seq (int):
    """

    up_to_seq: int

    def to_dict(self) -> dict[str, Any]:
        up_to_seq = self.up_to_seq

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "up_to_seq": up_to_seq,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        up_to_seq = d.pop("up_to_seq")

        mark_read_body = cls(
            up_to_seq=up_to_seq,
        )

        return mark_read_body
