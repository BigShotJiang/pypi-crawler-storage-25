"""
Template collection utilities for Orbit SSG.

This module scans the application directory to discover templates,
including support for static and dynamic routes.
"""

import os
import importlib.util


def load_data_file(path):
    """
    Dynamically load a Python module from a given file path.

    Args:
        path (str): Path to the Python file.

    Returns:
        module: The loaded Python module.
    """
    spec = importlib.util.spec_from_file_location("data", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def collect_templates(app_dir):
    """
    Collect all templates and generate route definitions.

    This function walks through the app directory, identifies `page.html`
    files, and constructs route mappings. It supports both static routes
    and dynamic routes using bracket notation (e.g., [id]).

    For dynamic routes, it expects a `data.py` file with a
    `get_static_paths()` function to generate route parameters.

    Args:
        app_dir (str): Root directory of the application.

    Returns:
        list: A list of route dictionaries containing path, template, and params.
    """
    routes = []

    for root, _, files in os.walk(app_dir):
        for file in files:
            if file != "page.html":
                continue

            full_path = os.path.join(root, file)
            rel = os.path.relpath(root, app_dir)

            if "[" in rel and "]" in rel:
                """
                Handle dynamic routes.

                Looks for a corresponding data.py file to generate
                static paths for dynamic segments.
                """
                parent_dir = os.path.dirname(root)
                data_path = os.path.join(parent_dir, "data.py")

                if not os.path.exists(data_path):
                    print("❌ No data.py for dynamic route:", root)
                    continue

                data = load_data_file(data_path)

                paths = data.get_static_paths()

                for item in paths:
                    path = rel

                    for key, value in item.items():
                        path = path.replace(f"[{key}]", value)

                    path = "/" if path == "." else f"/{path}"

                    routes.append({
                        "path": path,
                        "template": full_path,
                        "params": item,
                    })

            else:
                """
                Handle static routes.

                Converts directory structure into URL paths.
                """
                path = "/" if rel == "." else f"/{rel}"

                routes.append({
                    "path": path,
                    "template": full_path,
                    "params": {},
                })

    return routes
