from starlette.applications import Starlette
from starlette.responses import HTMLResponse
from starlette.routing import Route

from .renderer import create_env, render_template
from .collector import collect_templates
from .config import SSGConfig
from .data import load_data  


config = SSGConfig()
env = create_env(config.app_dir)


async def handle(request):
    path = request.url.path

    if path.endswith("/") and path != "/":
        path = path[:-1]

    routes = collect_templates(config.app_dir)  

    for r in routes:
        if r["path"] == path:
            params = r.get("params", {})

            data = load_data(r["template"], params)

            html = render_template(
                env,
                r["template"],
                config.app_dir,
                data
            )

            return HTMLResponse(html)

    return HTMLResponse("<h1>404 Not Found</h1>", status_code=404)


app = Starlette(routes=[Route("/{path:path}", handle)])
