"""
SSG request context utilities for Orbit.

This module provides a helper to create a mock RequestContext
for static site generation, simulating an HTTP request.
"""

from orbit_server.context import RequestContext

from starlette.requests import Request


def create_ssg_context(path: str):
    """
    Create a RequestContext for SSG rendering.

    This function simulates a Starlette Request using a minimal ASGI scope,
    allowing templates or handlers to access request-related data during
    static site generation.

    Args:
        path (str): The URL path to simulate.

    Returns:
        RequestContext: A context object wrapping the simulated request.
    """
    scope = {
        "type": "http",
        "method": "GET",
        "path": path,
        "raw_path": path.encode(),
        "headers": [],
        "query_string": b"",
        "client": ("127.0.0.1", 123),
        "server": ("localhost", 8000),
        "scheme": "http",
    }

    request = Request(scope)

    return RequestContext(request)
