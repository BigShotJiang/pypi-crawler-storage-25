"""
Template rendering utilities for Orbit SSG.

This module provides functions to create a Jinja2 environment,
resolve layouts, and render templates with optional layout wrapping.
"""

from jinja2 import Environment, FileSystemLoader, select_autoescape
import os


def create_env(app_dir):
    """
    Create a Jinja2 environment for template rendering.

    Args:
        app_dir (str): The directory containing template files.

    Returns:
        Environment: Configured Jinja2 environment.
    """
    return Environment(
        loader=FileSystemLoader(os.path.abspath(app_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )


def find_layout(template_path, app_dir):
    """
    Find the nearest layout.html file for a given template.

    This function searches upward from the template's directory
    until it finds a layout.html file or reaches the app root.

    Args:
        template_path (str): Path to the template file.
        app_dir (str): Root directory of the app.

    Returns:
        str | None: Relative path to the layout file if found, otherwise None.
    """
    current_dir = os.path.dirname(template_path)
    app_dir = os.path.abspath(app_dir)

    while True:
        layout_path = os.path.join(current_dir, "layout.html")

        if os.path.exists(layout_path):
            return os.path.relpath(layout_path, app_dir)

        if os.path.abspath(current_dir) == app_dir:
            break

        current_dir = os.path.dirname(current_dir)

    root_layout = os.path.join(app_dir, "layout.html")
    if os.path.exists(root_layout):
        return "layout.html"

    return None


def render_template(env, template_path, app_dir, params={}):
    """
    Render a template with optional layout wrapping.

    If a layout is found, the template is wrapped inside the layout
    using Jinja2's template inheritance. Otherwise, the template
    is rendered directly.

    Args:
        env (Environment): Jinja2 environment.
        template_path (str): Path to the template file.
        app_dir (str): Root directory of the app.
        params (dict, optional): Data passed to the template.

    Returns:
        str: Rendered HTML content.
    """
    template_name = os.path.relpath(template_path, app_dir)
    template_name = template_name.replace("\\", "/")

    layout = find_layout(template_path, app_dir)

    if layout:
        layout = layout.replace("\\", "/")

        wrapped = f"""
        {{% extends "{layout}" %}}
        {{% block content %}}
        {{% include "{template_name}" %}}
        {{% endblock %}}
        """

        template = env.from_string(wrapped)
        return template.render(**params) 

    template = env.get_template(template_name)
    return template.render(**params)
