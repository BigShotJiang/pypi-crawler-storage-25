"""
Data loading utilities for Orbit SSG.

This module provides functionality to dynamically load data
from a `data.py` file associated with a template.
"""

import os
import importlib.util


def load_data(template_path, params):
    """
    Load data for a given template.

    This function checks for a `data.py` file in the same directory
    as the template. If found, it imports the module and calls
    `get_data(params)` to retrieve additional data.

    Args:
        template_path (str): Path to the template file.
        params (dict): Parameters passed to the template.

    Returns:
        dict: Combined dictionary of params and loaded data.
    """
    folder = os.path.dirname(template_path)
    data_file = os.path.join(folder, "data.py")

    if not os.path.exists(data_file):
        return params 

    spec = importlib.util.spec_from_file_location("data", data_file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if hasattr(module, "get_data"):
        data = module.get_data(params)

        return {**params, **data}

    return params
