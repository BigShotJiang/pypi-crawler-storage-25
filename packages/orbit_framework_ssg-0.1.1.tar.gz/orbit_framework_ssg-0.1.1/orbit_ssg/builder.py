"""
Static Site Generator (SSG) builder for Orbit.

This module defines the SSGBuilder class responsible for orchestrating
the process of collecting templates, rendering them, and writing output files.
"""

from .collector import collect_templates
from .renderer import create_env, render_template
from .writer import write_output
from .data import load_data


class SSGBuilder:
    """
    Handles the static site generation process.

    This class coordinates template collection, rendering, and output writing
    based on the provided configuration.
    """

    def __init__(self, config):
        """
        Initialize the SSG builder.

        Args:
            config: Configuration object containing build settings.
        """
        self.config = config

    async def build(self):
        """
        Execute the static site build process.

        This method collects templates, renders them with data,
        and writes the generated HTML to the output directory.
        """
        print("🚀 Starting SSG build...")

        routes = collect_templates(self.config.app_dir)
        print(routes)

        env = create_env(self.config.app_dir)

        for route in routes:
            """
            Process and render each route.

            Each route includes a path, template, and optional parameters.
            """
            path = route["path"]

            print(f"⚙️ Rendering {path}")

            params = route.get("params", {})

            data = load_data(route["template"], params)

            html = render_template(
                env,
                route["template"],
                self.config.app_dir,
                data
            )
            write_output(path, html, self.config)

        print("✅ Build complete!")
