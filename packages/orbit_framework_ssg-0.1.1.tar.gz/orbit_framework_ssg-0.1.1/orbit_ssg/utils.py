"""
Output path resolution utilities for Orbit SSG.

This module provides a helper function to determine the correct
file path for generated HTML based on route paths.
"""

def resolve_output_path(path, config):
    """
    Resolve the output file path for a given route.

    This function converts a route path into a corresponding
    file path inside the output directory.

    Args:
        path (str): The route path (e.g., "/", "/about").
        config: Configuration object containing output directory settings.

    Returns:
        str: The resolved file path for the generated HTML.
    """
    if path == "/":
        return f"{config.out_dir}/index.html"

    return f"{config.out_dir}{path}/index.html"
