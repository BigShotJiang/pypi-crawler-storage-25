"""
Configuration module for Orbit SSG.

This module defines the configuration settings used during
the static site generation process.
"""

class SSGConfig:
    """
    Configuration class for the static site generator.

    Attributes:
        app_dir (str): Directory containing source templates.
        out_dir (str): Directory where generated files will be written.
    """

    def __init__(self):
        """
        Initialize default SSG configuration.

        Sets default directories for the application source
        and output build.
        """
        self.app_dir = "app"
        self.out_dir = "dist"
