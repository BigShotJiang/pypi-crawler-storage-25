"""
Output writing utilities for Orbit SSG.

This module provides functionality to write rendered HTML
to the appropriate file structure in the output directory.
"""

import os

def write_output(path, html, config):
    """
    Write rendered HTML content to the output directory.

    This function determines the correct file path based on the route path,
    creates necessary directories, and writes the HTML content to an index.html file.

    Args:
        path (str): The route path (e.g., "/", "/about").
        html (str): The rendered HTML content.
        config: Configuration object containing output directory settings.
    """
    if path == "/":
        file_path = os.path.join(config.out_dir, "index.html")
    else:
        file_path = os.path.join(config.out_dir, path.strip("/"), "index.html")

    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    with open(file_path, "w") as f:
        f.write(html)
