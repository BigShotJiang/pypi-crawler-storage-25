# CLAUDE.md — `pssbl-api`

This file provides all context needed to understand, build, and extend the `pssbl-api` Python package. Read this before writing any code.

---

## Project Overview

`pssbl-api` is a Python API wrapper for the **Puget Sound Senior Baseball League (PSSBL)** website. It targets a single PHP endpoint that communicates directly with a MariaDB backend. The wrapper is primarily for personal use and data analysis, but is intended to be published to **PyPI** for use by other league members and developers.

A primary downstream use case is integration into a **Slack bot** (`bolt-python`), which informed the async-first design.

---

## Package Identity

- **PyPI package name**: `pssbl-api`
- **Build system**: `pyproject.toml` (modern standard — no `setup.py`)

---

## Tech Stack

| Concern | Library | Notes |
|---|---|---|
| HTTP client | `httpx` | Supports both sync and async with a unified interface |
| Data modeling | `pydantic` | All API responses are parsed into Pydantic models |
| Caching | `hishel` or `requests-cache` (httpx-compatible) | 24-hour TTL; cache breaks daily |
| Logging | `logging` (stdlib) | Log exceptions; never raise on API errors |

---

## Base URL

```
https://pssbl.com/PHP/fetchData.php?type={endpoint}
```

All requests are unauthenticated GET requests to this single PHP file. The `type` query parameter selects the endpoint.

---

## Environment Variables

| Variable | Purpose | Default |
|---|---|---|
| `SEASON_YEAR` | Overrides the default season year | Current 4-digit calendar year |
| `DEFAULT_TEAM_ID` | Sets a default team for team-scoped queries | `None` |
| `DEFAULT_DIVISION_NAME` | Sets a default division for division-scoped queries | `None` |

The wrapper should read these at client initialization and allow them to be overridden at the method call level.

---

## Global Modifiers

| Modifier | Description | Default |
|---|---|---|
| `&year=` | Season year | `SEASON_YEAR` env var, else current year |
| `&division=` | Division name (e.g. `Adams`, `Denali`) | `DEFAULT_DIVISION_NAME` |
| `&teamId=` | Numeric team identifier | `DEFAULT_TEAM_ID` |
| `&perPage=` | Page size for paginated endpoints | Use `100000` to retrieve all records at once |

Pagination (`&page=`) is not needed and should not be used.

---

## Endpoints

### `TeamNames`
- **Description**: All teams in the league. Contains `teamId`, `teamName`, `divisionId`, `divisionName`.
- **Modifiers**: `&year=`

### `Years`
- **Description**: All years a division has been active.
- **Modifiers**: `&division=`

### `Divisions`
- **Description**: All divisions in the league. Contains division name, ID, age group, and level.
- **Modifiers**: `&year=`

### `Division`
- **Description**: All teams in a specific division for a given year.
- **Modifiers**: `&year=`, `&division=`

### `RegisteredPlayers`
- **Description**: All players registered for a given year. Contains `playerId`.
- **Modifiers**: `&year=`

### `Roster`
- **Description**: All players on a specific team. Contains `playerId`.
- **Modifiers**: `&year=`, `&teamId=`, `&perPage=`

### `CumulativeBatting`
- **Description**: Multi-mode offensive stats endpoint. Behavior changes based on modifiers:
  - `&teamId={id}&year={year}` → offensive stats for all players on a team
  - `&division={name}&year={year}` → offensive stats for all players in a division
  - `&division={name}&year={year}&group=teams` → combined/average offensive stats per team in a division
- **Modifiers**: `&year=`, `&teamId=`, `&division=`, `&group=`

### `CumulativePitching`
- **Description**: Multi-mode pitching stats endpoint. Behavior mirrors `CumulativeBatting`:
  - `&teamId={id}&year={year}` → pitching stats for all players on a team
  - `&division={name}&year={year}` → pitching stats for all players in a division
  - `&division={name}&year={year}&group=teams` → combined/average pitching stats per team in a division
- **Modifiers**: `&year=`, `&teamId=`, `&division=`, `&group=`

### `Games`
- **Description**: All games for a division and year. Used to derive standings, W/L/T, win percentage, streaks, runs for/against, and run differential.
- **Modifiers**: `&year=`, `&division=`

### `CareerBatting`
- **Description**: Career batting stats for a specific player. Player IDs are sourced from `Roster` or `RegisteredPlayers`.
- **Modifiers**: `&playerId=`

### `CareerPitching`
- **Description**: Career pitching stats for a specific player. Player IDs are sourced from `Roster` or `RegisteredPlayers`.
- **Modifiers**: `&playerId=`

---

## Error Handling

- **Never raise exceptions** to the caller for API or network errors.
- **Log all exceptions** using Python's stdlib `logging` module at the `ERROR` level.
- **Return `None`** gracefully on any failed request or unexpected response.
- Unexpected/malformed responses (e.g. PHP errors, empty arrays) should be caught and logged, not propagated.

---

## Caching

- All GET responses should be cached with a **24-hour TTL**.
- Cache should be transparent to the caller.
- Cache invalidation is time-based only (no manual purge required, but consider exposing a `clear_cache()` utility).

---

## Async-First Design

The client should be **async-first** using `httpx.AsyncClient`, with a sync convenience wrapper available for simple scripts. This is a deliberate decision driven by the Slackbot use case — `bolt-python` is async-native, and blocking HTTP calls would freeze the bot while waiting for API responses. Think of it as building the kitchen for async cooking, with a single-burner sync hotplate available on the side.

---

## Player ID Lookup Chain

`playerId` values are not standalone inputs — they must be sourced from:
1. `Roster` (team-scoped player list)
2. `RegisteredPlayers` (league-wide player list for a given year)

Any helper or convenience method that accepts a player name should resolve to a `playerId` via one of these endpoints before calling `CareerBatting` or `CareerPitching`.

---

## Division Name Values

Division names used in `&division=` come from the `name` key in the `Divisions` endpoint response. Examples: `Adams`, `Denali`. Always treat division names as strings, not IDs.
