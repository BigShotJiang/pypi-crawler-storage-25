# Contributing to pssbl-api

Thank you for your interest in contributing to pssbl-api! This document provides guidelines and instructions for contributing.

## Code of Conduct

Please be respectful and constructive in all interactions. We're all here to build something useful for the PSSBL community.

## Getting Started

### Prerequisites

- Python 3.10 or higher
- Git

### Development Setup

1. Fork the repository on GitHub

2. Clone your fork locally:

   ```bash
   git clone https://github.com/YOUR_USERNAME/pssbl-api.git
   cd pssbl-api
   ```

3. Create a virtual environment:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```

4. Install in development mode with dev dependencies:

   ```bash
   pip install -e ".[dev]"
   ```

5. Verify tests pass:

   ```bash
   pytest
   ```

## Making Changes

### Branching

Create a descriptive branch for your work:

```bash
git checkout -b feature/add-new-endpoint
git checkout -b fix/handle-empty-response
```

### Code Style

- Use [Black](https://black.readthedocs.io/) for code formatting
- Run `black .` before committing
- Follow existing patterns in the codebase

### Testing

- Write tests for new functionality
- Ensure all tests pass before submitting: `pytest`
- Use `respx` for mocking HTTP responses (see existing tests for examples)

### Commit Messages

Write clear, descriptive commit messages:

- Good: `Add get_standings endpoint for division rankings`
- Good: `Fix parsing of null birth dates in roster response`
- Bad: `Update code`
- Bad: `Fix bug`

## Submitting Changes

1. Push your branch to your fork:

   ```bash
   git push origin feature/your-feature
   ```

2. Open a Pull Request against the `main` branch

3. In your PR description:
   - Describe what changes you made and why
   - Reference any related issues
   - Include any testing notes

## Reporting Issues

When reporting bugs, please include:

- Python version (`python --version`)
- Package version (`pip show pssbl-api`)
- Steps to reproduce the issue
- Expected vs actual behavior
- Any error messages or stack traces

## Feature Requests

Feature requests are welcome! Please:

- Check existing issues first to avoid duplicates
- Describe the use case and why it would be valuable
- Be open to discussion about implementation approaches

## Questions?

Feel free to open an issue for questions about the codebase or how to contribute.
