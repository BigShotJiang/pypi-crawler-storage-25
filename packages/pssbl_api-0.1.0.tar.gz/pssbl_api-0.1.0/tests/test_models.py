"""Tests for Pydantic models."""

from datetime import date

import pytest

from pssbl_api.models import (
    CareerBattingStats,
    CumulativeBattingStats,
    CumulativePitchingStats,
    Division,
    Game,
    RegisteredPlayer,
    RosterPlayer,
    Team,
    TeamInDivision,
)


class TestTeam:
    """Tests for Team model."""

    def test_from_api(self) -> None:
        """Parse Team from API response."""
        data = {
            "teamId": "1376",
            "teamName": "Diablos",
            "shortName": "Dia",
            "divisionId": "174",
            "divisionName": "Adams",
        }
        team = Team.from_api(data)
        assert team.team_id == 1376
        assert team.team_name == "Diablos"
        assert team.short_name == "Dia"
        assert team.division_id == 174
        assert team.division_name == "Adams"


class TestDivision:
    """Tests for Division model."""

    def test_from_api(self) -> None:
        """Parse Division from API response."""
        data = {
            "name": "Denali",
            "id": "177",
            "age": "30",
            "roster": "15",
            "level": "Recreational",
            "games": "18",
            "year": "2025",
        }
        division = Division.from_api(data)
        assert division.name == "Denali"
        assert division.id == 177
        assert division.age == 30
        assert division.roster_size == 15
        assert division.level == "Recreational"
        assert division.games == 18
        assert division.year == 2025


class TestTeamInDivision:
    """Tests for TeamInDivision model."""

    def test_from_api(self) -> None:
        """Parse TeamInDivision from API response."""
        data = {
            "division": "Denali",
            "divisionId": "177",
            "teamName": "Expos",
            "teamId": "1404",
            "paid": "18",
            "GM": "Nick Snyder",
            "count": "18",
            "status": "active",
        }
        team = TeamInDivision.from_api(data)
        assert team.division == "Denali"
        assert team.division_id == 177
        assert team.team_name == "Expos"
        assert team.team_id == 1404
        assert team.paid == 18
        assert team.gm == "Nick Snyder"
        assert team.count == 18
        assert team.status == "active"


class TestRosterPlayer:
    """Tests for RosterPlayer model."""

    def test_from_api(self) -> None:
        """Parse RosterPlayer from API response."""
        data = {
            "firstName": "Nick",
            "lastName": "Snyder",
            "birthDate": "1990-05-15",
            "playerId": "5195",
            "registrationId": "23060",
            "rosterId": 25007,
            "GM": "1",
            "number": "42",
            "balance": "0",
            "status": "Active",
            "waiver": "1",
            "registered": "Feb 18 2025, 10:32 PM",
        }
        player = RosterPlayer.from_api(data)
        assert player.first_name == "Nick"
        assert player.last_name == "Snyder"
        assert player.birth_date == date(1990, 5, 15)
        assert player.player_id == 5195
        assert player.is_gm is True
        assert player.number == "42"
        assert player.waiver is True

    def test_from_api_null_birthdate(self) -> None:
        """Handle null birthdate."""
        data = {
            "firstName": "Test",
            "lastName": "Player",
            "birthDate": "",
            "playerId": "123",
            "registrationId": "456",
            "rosterId": 789,
            "GM": "0",
            "number": "",
            "balance": "0",
            "status": "Active",
            "waiver": "0",
            "registered": "Jan 01 2025",
        }
        player = RosterPlayer.from_api(data)
        assert player.birth_date is None
        assert player.is_gm is False
        assert player.number is None
        assert player.waiver is False


class TestRegisteredPlayer:
    """Tests for RegisteredPlayer model."""

    def test_from_api(self) -> None:
        """Parse RegisteredPlayer from API response."""
        data = {
            "firstName": "Nick",
            "lastName": "Snyder",
            "playerName": "Nick Snyder",
            "playerId": "5195",
            "status": "Active",
            "registrationTime": "Feb 15 2025, 9:39 PM",
        }
        player = RegisteredPlayer.from_api(data)
        assert player.first_name == "Nick"
        assert player.last_name == "Snyder"
        assert player.player_name == "Nick Snyder"
        assert player.player_id == 5195
        assert player.status == "Active"


class TestCumulativeBattingStats:
    """Tests for CumulativeBattingStats model."""

    def test_from_api(self) -> None:
        """Parse CumulativeBattingStats from API response."""
        data = {
            "playerId": "5195",
            "firstName": "Nick",
            "lastName": "Snyder",
            "teamId": "1404",
            "teamGames": "18",
            "teamName": "Expos",
            "abrev": "Exp",
            "g": "10",
            "ab": "26",
            "r": "5",
            "h": "9",
            "d": "2",
            "t": "1",
            "hr": "0",
            "rbi": "3",
            "sb": "2",
            "cs": "1",
            "bb": "4",
            "so": "8",
            "gdp": "0",
            "hbp": "1",
            "sh": "0",
            "sf": "1",
            "ibb": "0",
            "ci": "0",
            "rboe": "1",
            "taxi": "0",
        }
        stats = CumulativeBattingStats.from_api(data)
        assert stats.player_id == 5195
        assert stats.team_name == "Expos"
        assert stats.games == 10
        assert stats.at_bats == 26
        assert stats.hits == 9
        assert stats.doubles == 2
        assert stats.triples == 1
        assert stats.stolen_bases == 2


class TestCumulativePitchingStats:
    """Tests for CumulativePitchingStats model."""

    def test_from_api(self) -> None:
        """Parse CumulativePitchingStats from API response."""
        data = {
            "playerId": "5195",
            "firstName": "Nick",
            "lastName": "Snyder",
            "teamId": "1404",
            "teamGames": "18",
            "teamName": "Expos",
            "abrev": "Exp",
            "g": "5",
            "w": "2",
            "l": "1",
            "hld": "0",
            "sv": "1",
            "gs": "3",
            "gf": "2",
            "cg": "0",
            "sho": "0",
            "outs": "45",
            "h": "12",
            "r": "8",
            "er": "6",
            "hr": "1",
            "bb": "5",
            "ibb": "0",
            "so": "20",
            "sol": "5",
            "hbp": "2",
            "bk": "0",
            "wp": "1",
            "bf": "60",
            "pit": "200",
            "str": "120",
            "po": "0",
            "taxi": "0",
        }
        stats = CumulativePitchingStats.from_api(data)
        assert stats.player_id == 5195
        assert stats.games == 5
        assert stats.wins == 2
        assert stats.losses == 1
        assert stats.outs == 45
        assert stats.strikeouts == 20


class TestCareerBattingStats:
    """Tests for CareerBattingStats model."""

    def test_from_api(self) -> None:
        """Parse CareerBattingStats from API response."""
        data = {
            "playerId": "5195",
            "firstName": "Nick",
            "lastName": "Snyder",
            "year": "2021",
            "g": "18",
            "ab": "39",
            "r": "4",
            "h": "2",
            "d": "0",
            "t": "0",
            "hr": "0",
            "rbi": "0",
            "sb": "0",
            "cs": "0",
            "bb": "5",
            "so": "20",
            "gdp": "0",
            "hbp": "3",
            "rboe": "0",
            "sh": "0",
            "sf": "0",
            "ibb": "0",
            "ci": "0",
        }
        stats = CareerBattingStats.from_api(data)
        assert stats.player_id == 5195
        assert stats.year == 2021
        assert stats.games == 18
        assert stats.at_bats == 39
        assert stats.hits == 2


class TestGame:
    """Tests for Game model."""

    def test_from_api(self) -> None:
        """Parse Game from API response."""
        data = {
            "homeId": "1401",
            "awayId": "1403",
            "homeRuns": "15",
            "awayRuns": "6",
            "homeName": "Giants",
            "awayName": "Shuckers",
            "homeDivision": "Denali",
            "awayDivision": "Denali",
            "homeShort": "Gia",
            "awayShort": "Shu",
            "dateTime": "May 14 2025, 7:30 PM",
            "fieldId": "36",
            "fieldName": "Marymoor #2",
            "outcome": "finished",
            "gameId": "21155",
            "playoffRound": "0",
            "result": "home_win",
        }
        game = Game.from_api(data)
        assert game.game_id == 21155
        assert game.home_id == 1401
        assert game.away_id == 1403
        assert game.home_runs == 15
        assert game.away_runs == 6
        assert game.home_name == "Giants"
        assert game.outcome == "finished"
        assert game.result == "home_win"
