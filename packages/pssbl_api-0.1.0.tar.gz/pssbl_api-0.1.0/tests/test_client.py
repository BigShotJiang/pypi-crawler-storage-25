"""Tests for async client."""

import pytest
import respx
from httpx import Response

from pssbl_api import PSSBLClientAsync, Config, StatType


@pytest.fixture
def config() -> Config:
    """Create test config."""
    return Config(season_year=2025, default_team_id=1404, default_division_name="Denali")


class TestPSSBLClientAsync:
    """Tests for PSSBLClientAsync."""

    @respx.mock
    async def test_get_team_names(self, config: Config) -> None:
        """Fetch and parse team names."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "teamId": "1404",
                        "teamName": "Expos",
                        "shortName": "Exp",
                        "divisionId": "177",
                        "divisionName": "Denali",
                    }
                ],
            )
        )

        async with PSSBLClientAsync(config=config) as client:
            teams = await client.get_team_names()

        assert teams is not None
        assert len(teams) == 1
        assert teams[0].team_id == 1404
        assert teams[0].team_name == "Expos"

    @respx.mock
    async def test_get_divisions(self, config: Config) -> None:
        """Fetch and parse divisions."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=Divisions&year=2025"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "name": "Denali",
                        "id": "177",
                        "age": "30",
                        "roster": "15",
                        "level": "Recreational",
                        "games": "18",
                        "year": "2025",
                    }
                ],
            )
        )

        async with PSSBLClientAsync(config=config) as client:
            divisions = await client.get_divisions()

        assert divisions is not None
        assert len(divisions) == 1
        assert divisions[0].name == "Denali"

    @respx.mock
    async def test_get_roster(self, config: Config) -> None:
        """Fetch and parse roster."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=Roster&teamId=1404&year=2025&perPage=100000"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "firstName": "Nick",
                        "lastName": "Snyder",
                        "birthDate": "1990-05-15",
                        "playerId": "5195",
                        "registrationId": "23060",
                        "rosterId": 25007,
                        "GM": "1",
                        "number": "42",
                        "balance": "0",
                        "status": "Active",
                        "waiver": "1",
                        "registered": "Feb 18 2025, 10:32 PM",
                    }
                ],
            )
        )

        async with PSSBLClientAsync(config=config) as client:
            roster = await client.get_roster()

        assert roster is not None
        assert len(roster) == 1
        assert roster[0].player_id == 5195
        assert roster[0].is_gm is True

    @respx.mock
    async def test_get_games(self, config: Config) -> None:
        """Fetch and parse games."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=Games&division=Denali&year=2025"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "homeId": "1401",
                        "awayId": "1403",
                        "homeRuns": "15",
                        "awayRuns": "6",
                        "homeName": "Giants",
                        "awayName": "Shuckers",
                        "homeDivision": "Denali",
                        "awayDivision": "Denali",
                        "homeShort": "Gia",
                        "awayShort": "Shu",
                        "dateTime": "May 14 2025, 7:30 PM",
                        "fieldId": "36",
                        "fieldName": "Marymoor #2",
                        "outcome": "finished",
                        "gameId": "21155",
                        "playoffRound": "0",
                        "result": "home_win",
                    }
                ],
            )
        )

        async with PSSBLClientAsync(config=config) as client:
            games = await client.get_games()

        assert games is not None
        assert len(games) == 1
        assert games[0].game_id == 21155
        assert games[0].home_runs == 15

    @respx.mock
    async def test_get_player_stats_batting(self, config: Config) -> None:
        """Fetch and parse player batting stats."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=CareerBatting&playerId=5195"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "playerId": "5195",
                        "firstName": "Nick",
                        "lastName": "Snyder",
                        "year": "2021",
                        "g": "18",
                        "ab": "39",
                        "r": "4",
                        "h": "2",
                        "d": "0",
                        "t": "0",
                        "hr": "0",
                        "rbi": "0",
                        "sb": "0",
                        "cs": "0",
                        "bb": "5",
                        "so": "20",
                        "gdp": "0",
                        "hbp": "3",
                        "rboe": "0",
                        "sh": "0",
                        "sf": "0",
                        "ibb": "0",
                        "ci": "0",
                    }
                ],
            )
        )

        async with PSSBLClientAsync(config=config) as client:
            result = await client.get_player_stats(
                player_id=5195, stat_type=StatType.BATTING, show_career=True
            )

        assert result is not None
        assert "batting" in result
        assert len(result["batting"]) == 1
        assert result["batting"][0].year == 2021
        assert result["batting"][0].games == 18

    @respx.mock
    async def test_returns_none_on_http_error(self, config: Config) -> None:
        """Return None on HTTP error."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(return_value=Response(500))

        async with PSSBLClientAsync(config=config) as client:
            teams = await client.get_team_names()

        assert teams is None

    @respx.mock
    async def test_returns_none_on_invalid_json(self, config: Config) -> None:
        """Return None on invalid JSON response."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(return_value=Response(200, content=b"not json"))

        async with PSSBLClientAsync(config=config) as client:
            teams = await client.get_team_names()

        assert teams is None

    @respx.mock
    async def test_returns_none_on_non_list_response(self, config: Config) -> None:
        """Return None when response is not a list."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(return_value=Response(200, json={"error": "something"}))

        async with PSSBLClientAsync(config=config) as client:
            teams = await client.get_team_names()

        assert teams is None

    @respx.mock
    async def test_year_override(self, config: Config) -> None:
        """Year parameter overrides config."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2024"
        ).mock(return_value=Response(200, json=[]))

        async with PSSBLClientAsync(config=config) as client:
            teams = await client.get_team_names(year=2024)

        assert teams == []

    @respx.mock
    async def test_get_player_stats_pitching_empty(self, config: Config) -> None:
        """Handle empty player pitching stats response."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=CareerPitching&playerId=5195"
        ).mock(return_value=Response(200, json=[]))

        async with PSSBLClientAsync(config=config) as client:
            result = await client.get_player_stats(
                player_id=5195, stat_type=StatType.PITCHING, show_career=True
            )

        assert result is not None
        assert result["pitching"] == []
