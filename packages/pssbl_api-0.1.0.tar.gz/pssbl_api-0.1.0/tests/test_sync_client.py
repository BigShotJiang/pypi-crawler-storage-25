"""Tests for the sync PSSBL API client."""

import pytest
import respx
from httpx import Response

from pssbl_api import PSSBLClient, StatType
from pssbl_api.config import Config


@pytest.fixture
def config():
    """Create a test config."""
    return Config(
        season_year=2025,
        default_team_id=1404,
        default_division_name="Denali",
    )


@pytest.fixture
def client(config):
    """Create a sync client for testing."""
    return PSSBLClient(config=config, use_cache=False)


class TestSyncClientBasics:
    """Test sync client initialization and basics."""

    def test_init_default_config(self):
        """Test client creates default config if not provided."""
        client = PSSBLClient(use_cache=False)
        assert client.config is not None
        assert isinstance(client.config, Config)

    def test_init_with_config(self, config):
        """Test client uses provided config."""
        client = PSSBLClient(config=config, use_cache=False)
        assert client.config.season_year == 2025
        assert client.config.default_team_id == 1404


class TestSyncClientEndpoints:
    """Test sync client endpoint methods."""

    @respx.mock
    def test_get_team_names(self, client):
        """Test get_team_names returns Team objects."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "teamId": "1404",
                        "teamName": "Expos",
                        "shortName": "Exp",
                        "divisionId": "177",
                        "divisionName": "Denali",
                    }
                ],
            )
        )

        teams = client.get_team_names(year=2025)

        assert teams is not None
        assert len(teams) == 1
        assert teams[0].team_id == 1404
        assert teams[0].team_name == "Expos"

    @respx.mock
    def test_get_divisions(self, client):
        """Test get_divisions returns Division objects."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=Divisions&year=2025"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "name": "Denali",
                        "id": "177",
                        "age": "30",
                        "roster": "15",
                        "level": "Recreational",
                        "games": "18",
                        "year": "2025",
                    }
                ],
            )
        )

        divisions = client.get_divisions(year=2025)

        assert divisions is not None
        assert len(divisions) == 1
        assert divisions[0].name == "Denali"

    @respx.mock
    def test_get_roster(self, client):
        """Test get_roster returns RosterPlayer objects."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=Roster&teamId=1404&year=2025&perPage=100000"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "firstName": "Nick",
                        "lastName": "Snyder",
                        "birthDate": "1990-05-15",
                        "playerId": "5195",
                        "registrationId": "23060",
                        "rosterId": 25007,
                        "GM": "1",
                        "number": "42",
                        "balance": "0",
                        "status": "Active",
                        "waiver": "1",
                        "registered": "Feb 18 2025, 10:32 PM",
                    }
                ],
            )
        )

        roster = client.get_roster(team_id=1404, year=2025)

        assert roster is not None
        assert len(roster) == 1
        assert roster[0].player_id == 5195
        assert roster[0].first_name == "Nick"

    @respx.mock
    def test_get_player_stats_batting(self, client):
        """Test get_player_stats returns batting stats."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=CareerBatting&playerId=5195"
        ).mock(
            return_value=Response(
                200,
                json=[
                    {
                        "playerId": "5195",
                        "firstName": "Nick",
                        "lastName": "Snyder",
                        "year": "2021",
                        "g": "18",
                        "ab": "39",
                        "r": "4",
                        "h": "2",
                        "d": "0",
                        "t": "0",
                        "hr": "0",
                        "rbi": "0",
                        "sb": "0",
                        "cs": "0",
                        "bb": "5",
                        "so": "20",
                        "gdp": "0",
                        "hbp": "3",
                        "rboe": "0",
                        "sh": "0",
                        "sf": "0",
                        "ibb": "0",
                        "ci": "0",
                    }
                ],
            )
        )

        result = client.get_player_stats(
            player_id=5195, stat_type=StatType.BATTING, show_career=True
        )

        assert result is not None
        assert "batting" in result
        assert len(result["batting"]) == 1
        assert result["batting"][0].year == 2021
        assert result["batting"][0].hits == 2

    @respx.mock
    def test_returns_none_on_error(self, client):
        """Test client returns None on HTTP errors."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(return_value=Response(500))

        result = client.get_team_names(year=2025)

        assert result is None

    @respx.mock
    def test_returns_none_on_invalid_json(self, client):
        """Test client returns None on non-list response."""
        respx.get(
            "https://pssbl.com/PHP/fetchData.php?type=TeamNames&year=2025"
        ).mock(return_value=Response(200, json={"error": "not a list"}))

        result = client.get_team_names(year=2025)

        assert result is None
