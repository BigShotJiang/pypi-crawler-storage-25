"""Tests for config module."""

import os
from datetime import datetime
from unittest.mock import patch

import pytest

from pssbl_api.config import Config


class TestConfig:
    """Tests for Config class."""

    def test_default_season_year_is_current_year(self) -> None:
        """Config uses current year when no env var set."""
        with patch.dict(os.environ, {}, clear=True):
            config = Config()
            assert config.season_year == datetime.now().year

    def test_season_year_from_env_var(self) -> None:
        """Config reads SEASON_YEAR from environment."""
        with patch.dict(os.environ, {"SEASON_YEAR": "2023"}):
            config = Config()
            assert config.season_year == 2023

    def test_season_year_override(self) -> None:
        """Constructor arg overrides env var."""
        with patch.dict(os.environ, {"SEASON_YEAR": "2023"}):
            config = Config(season_year=2024)
            assert config.season_year == 2024

    def test_default_team_id_none_when_unset(self) -> None:
        """default_team_id is None when env var not set."""
        with patch.dict(os.environ, {}, clear=True):
            config = Config()
            assert config.default_team_id is None

    def test_default_team_id_from_env_var(self) -> None:
        """Config reads DEFAULT_TEAM_ID from environment."""
        with patch.dict(os.environ, {"DEFAULT_TEAM_ID": "42"}):
            config = Config()
            assert config.default_team_id == 42

    def test_default_team_id_override(self) -> None:
        """Constructor arg overrides env var."""
        with patch.dict(os.environ, {"DEFAULT_TEAM_ID": "42"}):
            config = Config(default_team_id=99)
            assert config.default_team_id == 99

    def test_default_division_name_none_when_unset(self) -> None:
        """default_division_name is None when env var not set."""
        with patch.dict(os.environ, {}, clear=True):
            config = Config()
            assert config.default_division_name is None

    def test_default_division_name_from_env_var(self) -> None:
        """Config reads DEFAULT_DIVISION_NAME from environment."""
        with patch.dict(os.environ, {"DEFAULT_DIVISION_NAME": "Adams"}):
            config = Config()
            assert config.default_division_name == "Adams"

    def test_default_division_name_override(self) -> None:
        """Constructor arg overrides env var."""
        with patch.dict(os.environ, {"DEFAULT_DIVISION_NAME": "Adams"}):
            config = Config(default_division_name="Denali")
            assert config.default_division_name == "Denali"

    def test_base_url_constant(self) -> None:
        """BASE_URL is set correctly."""
        assert Config.BASE_URL == "https://pssbl.com/PHP/fetchData.php"

    def test_default_per_page_constant(self) -> None:
        """DEFAULT_PER_PAGE retrieves all records."""
        assert Config.DEFAULT_PER_PAGE == 100000
