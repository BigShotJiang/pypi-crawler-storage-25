"""Configuration management for PSSBL API client."""

import os
from datetime import datetime
from typing import Optional


class Config:
    """Configuration container for PSSBL API client.

    Reads defaults from environment variables and allows runtime overrides.
    """

    BASE_URL = "https://pssbl.com/PHP/fetchData.php"
    DEFAULT_PER_PAGE = 100000  # Retrieve all records at once

    def __init__(
        self,
        season_year: Optional[int] = None,
        default_team_id: Optional[int] = None,
        default_division_name: Optional[str] = None,
    ) -> None:
        """Initialize configuration.

        Args:
            season_year: Override for season year. Defaults to SEASON_YEAR env var
                or current calendar year.
            default_team_id: Override for default team. Defaults to DEFAULT_TEAM_ID
                env var.
            default_division_name: Override for default division. Defaults to
                DEFAULT_DIVISION_NAME env var.
        """
        self.season_year = season_year or self._get_season_year()
        self.default_team_id = default_team_id or self._get_default_team_id()
        self.default_division_name = (
            default_division_name or self._get_default_division_name()
        )

    @staticmethod
    def _get_season_year() -> int:
        """Get season year from env var or current year."""
        env_year = os.environ.get("SEASON_YEAR")
        if env_year:
            return int(env_year)
        return datetime.now().year

    @staticmethod
    def _get_default_team_id() -> Optional[int]:
        """Get default team ID from env var."""
        env_team = os.environ.get("DEFAULT_TEAM_ID")
        if env_team:
            return int(env_team)
        return None

    @staticmethod
    def _get_default_division_name() -> Optional[str]:
        """Get default division name from env var."""
        return os.environ.get("DEFAULT_DIVISION_NAME")
