"""Team and division models."""

from pydantic import BaseModel


class Team(BaseModel):
    """Team from TeamNames endpoint."""

    team_id: int
    team_name: str
    short_name: str
    division_id: int
    division_name: str

    @classmethod
    def from_api(cls, data: dict) -> "Team":
        """Create Team from API response."""
        return cls(
            team_id=int(data["teamId"]),
            team_name=data["teamName"],
            short_name=data["shortName"],
            division_id=int(data["divisionId"]),
            division_name=data["divisionName"],
        )


class Division(BaseModel):
    """Division from Divisions endpoint."""

    name: str
    id: int
    age: int
    roster_size: int
    level: str
    games: int
    year: int

    @classmethod
    def from_api(cls, data: dict) -> "Division":
        """Create Division from API response."""
        return cls(
            name=data["name"],
            id=int(data["id"]),
            age=int(data["age"]),
            roster_size=int(data["roster"]),
            level=data["level"],
            games=int(data["games"]),
            year=int(data["year"]),
        )


class TeamInDivision(BaseModel):
    """Team info from Division endpoint (teams in a specific division)."""

    division: str
    division_id: int
    team_name: str
    team_id: int
    paid: int
    gm: str
    count: int
    status: str

    @classmethod
    def from_api(cls, data: dict) -> "TeamInDivision":
        """Create TeamInDivision from API response."""
        return cls(
            division=data["division"],
            division_id=int(data["divisionId"]),
            team_name=data["teamName"],
            team_id=int(data["teamId"]),
            paid=int(data["paid"]),
            gm=data["GM"],
            count=int(data["count"]),
            status=data["status"],
        )
