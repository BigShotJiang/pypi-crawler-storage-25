"""Player models."""

from datetime import date
from typing import Optional

from pydantic import BaseModel


class RosterPlayer(BaseModel):
    """Player from Roster endpoint."""

    first_name: str
    last_name: str
    birth_date: Optional[date]
    player_id: int
    registration_id: int
    roster_id: int
    is_gm: bool
    number: Optional[str]
    balance: int
    status: str
    waiver: bool
    registered: str

    @classmethod
    def from_api(cls, data: dict) -> "RosterPlayer":
        """Create RosterPlayer from API response."""
        birth_date = None
        if data.get("birthDate"):
            birth_date = date.fromisoformat(data["birthDate"])

        return cls(
            first_name=data["firstName"],
            last_name=data["lastName"],
            birth_date=birth_date,
            player_id=int(data["playerId"]),
            registration_id=int(data["registrationId"]),
            roster_id=int(data["rosterId"]),
            is_gm=data["GM"] == "1",
            number=data.get("number") or None,
            balance=int(data["balance"]),
            status=data["status"],
            waiver=data["waiver"] == "1",
            registered=data["registered"],
        )


class RegisteredPlayer(BaseModel):
    """Player from RegisteredPlayers endpoint."""

    first_name: str
    last_name: str
    player_name: str
    player_id: int
    status: str
    registration_time: str

    @classmethod
    def from_api(cls, data: dict) -> "RegisteredPlayer":
        """Create RegisteredPlayer from API response."""
        return cls(
            first_name=data["firstName"],
            last_name=data["lastName"],
            player_name=data["playerName"],
            player_id=int(data["playerId"]),
            status=data["status"],
            registration_time=data["registrationTime"],
        )
