"""Game models."""

from enum import Enum

from pydantic import BaseModel


class GameOutcome(str, Enum):
    """Game outcome status."""

    FINISHED = "finished"
    SCHEDULED = "scheduled"
    CANCELLED = "cancelled"
    POSTPONED = "postponed"


class GameResult(str, Enum):
    """Game result."""

    HOME_WIN = "home_win"
    AWAY_WIN = "away_win"
    TIE = "tie"


class Game(BaseModel):
    """Game from Games endpoint."""

    game_id: int
    home_id: int
    away_id: int
    home_runs: int
    away_runs: int
    home_name: str
    away_name: str
    home_division: str
    away_division: str
    home_short: str
    away_short: str
    date_time: str
    field_id: int
    field_name: str
    outcome: str
    playoff_round: int
    result: str

    @classmethod
    def from_api(cls, data: dict) -> "Game":
        """Create Game from API response."""
        return cls(
            game_id=int(data["gameId"]),
            home_id=int(data["homeId"]),
            away_id=int(data["awayId"]),
            home_runs=int(data["homeRuns"]),
            away_runs=int(data["awayRuns"]),
            home_name=data["homeName"],
            away_name=data["awayName"],
            home_division=data["homeDivision"],
            away_division=data["awayDivision"],
            home_short=data["homeShort"],
            away_short=data["awayShort"],
            date_time=data["dateTime"],
            field_id=int(data["fieldId"]),
            field_name=data["fieldName"],
            outcome=data["outcome"],
            playoff_round=int(data["playoffRound"]),
            result=data["result"],
        )
