"""Enums for PSSBL API."""

from enum import Enum


class StatType(str, Enum):
    """Type of statistics to retrieve."""

    BATTING = "batting"
    PITCHING = "pitching"
    BOTH = "both"
