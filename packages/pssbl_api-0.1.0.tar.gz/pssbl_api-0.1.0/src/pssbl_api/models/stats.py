"""Batting and pitching statistics models."""

from pydantic import BaseModel


class CumulativeBattingStats(BaseModel):
    """Batting stats from CumulativeBatting endpoint."""

    player_id: int
    first_name: str
    last_name: str
    team_id: int
    team_games: int
    team_name: str
    team_abbrev: str
    games: int
    at_bats: int
    runs: int
    hits: int
    doubles: int
    triples: int
    home_runs: int
    rbi: int
    stolen_bases: int
    caught_stealing: int
    walks: int
    strikeouts: int
    gdp: int
    hbp: int
    sac_hits: int
    sac_flies: int
    ibb: int
    catcher_interference: int
    rboe: int
    taxi: int

    @classmethod
    def from_api(cls, data: dict) -> "CumulativeBattingStats":
        """Create CumulativeBattingStats from API response."""
        return cls(
            player_id=int(data["playerId"]),
            first_name=data["firstName"],
            last_name=data["lastName"],
            team_id=int(data["teamId"]),
            team_games=int(data["teamGames"]),
            team_name=data["teamName"],
            team_abbrev=data["abrev"],
            games=int(data["g"]),
            at_bats=int(data["ab"]),
            runs=int(data["r"]),
            hits=int(data["h"]),
            doubles=int(data["d"]),
            triples=int(data["t"]),
            home_runs=int(data["hr"]),
            rbi=int(data["rbi"]),
            stolen_bases=int(data["sb"]),
            caught_stealing=int(data["cs"]),
            walks=int(data["bb"]),
            strikeouts=int(data["so"]),
            gdp=int(data["gdp"]),
            hbp=int(data["hbp"]),
            sac_hits=int(data["sh"]),
            sac_flies=int(data["sf"]),
            ibb=int(data["ibb"]),
            catcher_interference=int(data["ci"]),
            rboe=int(data["rboe"]),
            taxi=int(data["taxi"]),
        )


class CumulativePitchingStats(BaseModel):
    """Pitching stats from CumulativePitching endpoint."""

    player_id: int
    first_name: str
    last_name: str
    team_id: int
    team_games: int
    team_name: str
    team_abbrev: str
    games: int
    wins: int
    losses: int
    holds: int
    saves: int
    games_started: int
    games_finished: int
    complete_games: int
    shutouts: int
    outs: int
    hits: int
    runs: int
    earned_runs: int
    home_runs: int
    walks: int
    ibb: int
    strikeouts: int
    strikeouts_looking: int
    hbp: int
    balks: int
    wild_pitches: int
    batters_faced: int
    pitches: int
    strikes: int
    pickoffs: int
    taxi: int

    @classmethod
    def from_api(cls, data: dict) -> "CumulativePitchingStats":
        """Create CumulativePitchingStats from API response."""
        return cls(
            player_id=int(data["playerId"]),
            first_name=data["firstName"],
            last_name=data["lastName"],
            team_id=int(data["teamId"]),
            team_games=int(data["teamGames"]),
            team_name=data["teamName"],
            team_abbrev=data["abrev"],
            games=int(data["g"]),
            wins=int(data["w"]),
            losses=int(data["l"]),
            holds=int(data["hld"]),
            saves=int(data["sv"]),
            games_started=int(data["gs"]),
            games_finished=int(data["gf"]),
            complete_games=int(data["cg"]),
            shutouts=int(data["sho"]),
            outs=int(data["outs"]),
            hits=int(data["h"]),
            runs=int(data["r"]),
            earned_runs=int(data["er"]),
            home_runs=int(data["hr"]),
            walks=int(data["bb"]),
            ibb=int(data["ibb"]),
            strikeouts=int(data["so"]),
            strikeouts_looking=int(data["sol"]),
            hbp=int(data["hbp"]),
            balks=int(data["bk"]),
            wild_pitches=int(data["wp"]),
            batters_faced=int(data["bf"]),
            pitches=int(data["pit"]),
            strikes=int(data["str"]),
            pickoffs=int(data["po"]),
            taxi=int(data["taxi"]),
        )


class CareerBattingStats(BaseModel):
    """Career batting stats from CareerBatting endpoint."""

    player_id: int
    first_name: str
    last_name: str
    year: int
    games: int
    at_bats: int
    runs: int
    hits: int
    doubles: int
    triples: int
    home_runs: int
    rbi: int
    stolen_bases: int
    caught_stealing: int
    walks: int
    strikeouts: int
    gdp: int
    hbp: int
    rboe: int
    sac_hits: int
    sac_flies: int
    ibb: int
    catcher_interference: int

    @classmethod
    def from_api(cls, data: dict) -> "CareerBattingStats":
        """Create CareerBattingStats from API response."""
        return cls(
            player_id=int(data["playerId"]),
            first_name=data["firstName"],
            last_name=data["lastName"],
            year=int(data["year"]),
            games=int(data["g"]),
            at_bats=int(data["ab"]),
            runs=int(data["r"]),
            hits=int(data["h"]),
            doubles=int(data["d"]),
            triples=int(data["t"]),
            home_runs=int(data["hr"]),
            rbi=int(data["rbi"]),
            stolen_bases=int(data["sb"]),
            caught_stealing=int(data["cs"]),
            walks=int(data["bb"]),
            strikeouts=int(data["so"]),
            gdp=int(data["gdp"]),
            hbp=int(data["hbp"]),
            rboe=int(data["rboe"]),
            sac_hits=int(data["sh"]),
            sac_flies=int(data["sf"]),
            ibb=int(data["ibb"]),
            catcher_interference=int(data["ci"]),
        )


class CareerPitchingStats(BaseModel):
    """Career pitching stats from CareerPitching endpoint."""

    player_id: int
    first_name: str
    last_name: str
    year: int
    games: int
    wins: int
    losses: int
    holds: int
    saves: int
    games_started: int
    games_finished: int
    complete_games: int
    shutouts: int
    outs: int
    hits: int
    runs: int
    earned_runs: int
    home_runs: int
    walks: int
    ibb: int
    strikeouts: int
    strikeouts_looking: int
    hbp: int
    balks: int
    wild_pitches: int
    batters_faced: int
    pitches: int
    strikes: int
    pickoffs: int

    @classmethod
    def from_api(cls, data: dict) -> "CareerPitchingStats":
        """Create CareerPitchingStats from API response."""
        return cls(
            player_id=int(data["playerId"]),
            first_name=data["firstName"],
            last_name=data["lastName"],
            year=int(data["year"]),
            games=int(data["g"]),
            wins=int(data["w"]),
            losses=int(data["l"]),
            holds=int(data["hld"]),
            saves=int(data["sv"]),
            games_started=int(data["gs"]),
            games_finished=int(data["gf"]),
            complete_games=int(data["cg"]),
            shutouts=int(data["sho"]),
            outs=int(data["outs"]),
            hits=int(data["h"]),
            runs=int(data["r"]),
            earned_runs=int(data["er"]),
            home_runs=int(data["hr"]),
            walks=int(data["bb"]),
            ibb=int(data["ibb"]),
            strikeouts=int(data["so"]),
            strikeouts_looking=int(data["sol"]),
            hbp=int(data["hbp"]),
            balks=int(data["bk"]),
            wild_pitches=int(data["wp"]),
            batters_faced=int(data["bf"]),
            pitches=int(data["pit"]),
            strikes=int(data["str"]),
            pickoffs=int(data["po"]),
        )
