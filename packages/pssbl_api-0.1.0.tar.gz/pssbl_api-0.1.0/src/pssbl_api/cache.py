"""Caching configuration for PSSBL API client."""

import os
import shutil
from pathlib import Path
from typing import Optional

from hishel import AsyncSqliteStorage
from hishel.httpx import AsyncCacheClient

# Default cache directory
DEFAULT_CACHE_DIR = Path.home() / ".cache" / "pssbl_api"

# 24-hour TTL in seconds
CACHE_TTL_SECONDS = 24 * 60 * 60


def get_cache_db_path(cache_dir: Optional[Path] = None) -> Path:
    """Get the path to the cache database file.

    Args:
        cache_dir: Directory for cache files. Defaults to ~/.cache/pssbl_api.

    Returns:
        Path to the SQLite cache database.
    """
    cache_dir = cache_dir or DEFAULT_CACHE_DIR
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / "cache.db"


def create_cache_storage(
    cache_dir: Optional[Path] = None,
) -> AsyncSqliteStorage:
    """Create cache storage with 24-hour TTL.

    Args:
        cache_dir: Directory for cache files. Defaults to ~/.cache/pssbl_api.

    Returns:
        Configured AsyncSqliteStorage instance.
    """
    db_path = get_cache_db_path(cache_dir)

    return AsyncSqliteStorage(
        database_path=db_path,
        default_ttl=CACHE_TTL_SECONDS,
    )


def create_cache_client(
    cache_dir: Optional[Path] = None,
) -> AsyncCacheClient:
    """Create caching HTTP client.

    Args:
        cache_dir: Directory for cache files. Defaults to ~/.cache/pssbl_api.

    Returns:
        Configured AsyncCacheClient instance.
    """
    storage = create_cache_storage(cache_dir)
    return AsyncCacheClient(storage=storage)


def clear_cache(cache_dir: Optional[Path] = None) -> None:
    """Clear all cached responses.

    Args:
        cache_dir: Directory containing cache files. Defaults to ~/.cache/pssbl_api.
    """
    cache_dir = cache_dir or DEFAULT_CACHE_DIR
    if cache_dir.exists():
        shutil.rmtree(cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
