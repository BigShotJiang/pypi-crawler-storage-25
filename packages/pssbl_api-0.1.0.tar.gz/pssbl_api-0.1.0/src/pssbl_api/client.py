"""Async HTTP client for PSSBL API."""

import asyncio
import logging
from pathlib import Path
from typing import Optional

import httpx

from pssbl_api.cache import create_cache_client
from pssbl_api.config import Config
from pssbl_api.models import (
    CareerBattingStats,
    CareerPitchingStats,
    CumulativeBattingStats,
    CumulativePitchingStats,
    Division,
    Game,
    RegisteredPlayer,
    RosterPlayer,
    StatType,
    Team,
    TeamInDivision,
)

# Type alias for stat results
PlayerStatsResult = dict[
    str, list[CareerBattingStats] | list[CareerPitchingStats] | None
]
TeamStatsResult = dict[
    str, list[CumulativeBattingStats] | list[CumulativePitchingStats] | None
]

logger = logging.getLogger(__name__)


class PSSBLClientAsync:
    """Async client for the PSSBL API.

    All methods return None on error and log exceptions.
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        http_client: Optional[httpx.AsyncClient] = None,
        use_cache: bool = True,
        cache_dir: Optional[Path] = None,
    ) -> None:
        """Initialize the client.

        Args:
            config: Configuration object. Creates default if not provided.
            http_client: Optional httpx.AsyncClient for dependency injection.
            use_cache: Enable response caching with 24h TTL. Default True.
            cache_dir: Directory for cache files. Default ~/.cache/pssbl_api.
        """
        self.config = config or Config()
        self._client = http_client
        self._owns_client = http_client is None
        self._use_cache = use_cache
        self._cache_dir = cache_dir

    async def __aenter__(self) -> "PSSBLClientAsync":
        """Enter async context."""
        if self._client is None:
            if self._use_cache:
                self._client = create_cache_client(self._cache_dir)
            else:
                self._client = httpx.AsyncClient()
        return self

    async def __aexit__(self, *args: object) -> None:
        """Exit async context."""
        if self._owns_client and self._client is not None:
            await self._client.aclose()

    def _build_url(self, endpoint: str, **params: object) -> str:
        """Build URL with query parameters."""
        url = f"{Config.BASE_URL}?type={endpoint}"
        for key, value in params.items():
            if value is not None:
                url += f"&{key}={value}"
        return url

    async def _get(self, endpoint: str, **params: object) -> Optional[list]:
        """Make GET request and return JSON response.

        Returns None on any error.
        """
        if self._client is None:
            logger.error("Client not initialized. Use 'async with' context manager.")
            return None

        url = self._build_url(endpoint, **params)
        try:
            response = await self._client.get(url)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, list):
                logger.error("Unexpected response format: expected list, got %s", type(data))
                return None
            return data
        except httpx.HTTPStatusError as e:
            logger.error("HTTP error %s for %s", e.response.status_code, endpoint)
            return None
        except httpx.RequestError as e:
            logger.error("Request error for %s: %s", endpoint, e)
            return None
        except Exception as e:
            logger.error("Unexpected error for %s: %s", endpoint, e)
            return None

    async def get_team_names(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[Team]]:
        """Get all teams in the league.

        Args:
            year: Season year. Defaults to config.season_year.

        Returns:
            List of Team objects, or None on error.
        """
        year = year or self.config.season_year
        data = await self._get("TeamNames", year=year)
        if data is None:
            return None
        try:
            return [Team.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse TeamNames response: %s", e)
            return None

    async def get_divisions(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[Division]]:
        """Get all divisions in the league.

        Args:
            year: Season year. Defaults to config.season_year.

        Returns:
            List of Division objects, or None on error.
        """
        year = year or self.config.season_year
        data = await self._get("Divisions", year=year)
        if data is None:
            return None
        try:
            return [Division.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse Divisions response: %s", e)
            return None

    async def get_division(
        self,
        division: Optional[str] = None,
        year: Optional[int] = None,
    ) -> Optional[list[TeamInDivision]]:
        """Get all teams in a specific division.

        Args:
            division: Division name. Defaults to config.default_division_name.
            year: Season year. Defaults to config.season_year.

        Returns:
            List of TeamInDivision objects, or None on error.
        """
        division = division or self.config.default_division_name
        year = year or self.config.season_year
        data = await self._get("Division", division=division, year=year)
        if data is None:
            return None
        try:
            return [TeamInDivision.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse Division response: %s", e)
            return None

    async def get_all_players(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[RegisteredPlayer]]:
        """Get all players registered for a given year.

        Args:
            year: Season year. Defaults to config.season_year.

        Returns:
            List of RegisteredPlayer objects, or None on error.
        """
        year = year or self.config.season_year
        data = await self._get(
            "RegisteredPlayers",
            year=year,
            perPage=Config.DEFAULT_PER_PAGE,
        )
        if data is None:
            return None
        try:
            return [RegisteredPlayer.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse RegisteredPlayers response: %s", e)
            return None

    async def get_roster(
        self,
        team_id: Optional[int] = None,
        year: Optional[int] = None,
    ) -> Optional[list[RosterPlayer]]:
        """Get all players on a specific team.

        Args:
            team_id: Team ID. Defaults to config.default_team_id.
            year: Season year. Defaults to config.season_year.

        Returns:
            List of RosterPlayer objects, or None on error.
        """
        team_id = team_id or self.config.default_team_id
        year = year or self.config.season_year
        data = await self._get(
            "Roster",
            teamId=team_id,
            year=year,
            perPage=Config.DEFAULT_PER_PAGE,
        )
        if data is None:
            return None
        try:
            return [RosterPlayer.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse Roster response: %s", e)
            return None

    async def get_games(
        self,
        division: Optional[str] = None,
        year: Optional[int] = None,
    ) -> Optional[list[Game]]:
        """Get all games for a division and year.

        Args:
            division: Division name. Defaults to config.default_division_name.
            year: Season year. Defaults to config.season_year.

        Returns:
            List of Game objects, or None on error.
        """
        division = division or self.config.default_division_name
        year = year or self.config.season_year
        data = await self._get("Games", division=division, year=year)
        if data is None:
            return None
        try:
            return [Game.from_api(item) for item in data]
        except Exception as e:
            logger.error("Failed to parse Games response: %s", e)
            return None

    async def get_player_stats(
        self,
        player_id: int,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
        show_career: bool = False,
    ) -> Optional[PlayerStatsResult]:
        """Get stats for a single player.

        Args:
            player_id: Player ID (from Roster or RegisteredPlayers).
            stat_type: Type of stats to retrieve (batting, pitching, or both).
            year: Season year. Defaults to config.season_year. Ignored if show_career=True.
            show_career: If True, return all career stats. If False, return stats for year.

        Returns:
            Dict with 'batting' and/or 'pitching' keys containing stat lists,
            or None on error.

        Examples:
            get_player_stats(1404, StatType.BATTING, year=2024)
            get_player_stats(1404, StatType.BOTH)
            get_player_stats(1404, StatType.PITCHING, show_career=True)
        """
        year = year or self.config.season_year
        result: PlayerStatsResult = {}

        if stat_type in (StatType.BATTING, StatType.BOTH):
            data = await self._get("CareerBatting", playerId=player_id)
            if data is None:
                result["batting"] = None
            else:
                try:
                    stats = [CareerBattingStats.from_api(item) for item in data]
                    if not show_career:
                        stats = [s for s in stats if s.year == year]
                    result["batting"] = stats
                except Exception as e:
                    logger.error("Failed to parse CareerBatting response: %s", e)
                    result["batting"] = None

        if stat_type in (StatType.PITCHING, StatType.BOTH):
            data = await self._get("CareerPitching", playerId=player_id)
            if data is None:
                result["pitching"] = None
            else:
                try:
                    stats = [CareerPitchingStats.from_api(item) for item in data]
                    if not show_career:
                        stats = [s for s in stats if s.year == year]
                    result["pitching"] = stats
                except Exception as e:
                    logger.error("Failed to parse CareerPitching response: %s", e)
                    result["pitching"] = None

        return result

    async def get_team_stats(
        self,
        team_id: Optional[int] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get stats for all rostered players on a team.

        Args:
            team_id: Team ID. Defaults to config.default_team_id.
            stat_type: Type of stats to retrieve (batting, pitching, or both).
            year: Season year. Defaults to config.season_year.

        Returns:
            Dict with 'batting' and/or 'pitching' keys containing stat lists,
            or None on error.

        Examples:
            get_team_stats(1500, StatType.BATTING, year=2024)
            get_team_stats(1500, StatType.BOTH)
        """
        team_id = team_id or self.config.default_team_id
        year = year or self.config.season_year
        result: TeamStatsResult = {}

        if stat_type in (StatType.BATTING, StatType.BOTH):
            data = await self._get("CumulativeBatting", teamId=team_id, year=year)
            if data is None:
                result["batting"] = None
            else:
                try:
                    result["batting"] = [
                        CumulativeBattingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativeBatting response: %s", e)
                    result["batting"] = None

        if stat_type in (StatType.PITCHING, StatType.BOTH):
            data = await self._get("CumulativePitching", teamId=team_id, year=year)
            if data is None:
                result["pitching"] = None
            else:
                try:
                    result["pitching"] = [
                        CumulativePitchingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativePitching response: %s", e)
                    result["pitching"] = None

        return result

    async def get_division_player_stats(
        self,
        division: Optional[str] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get stats for all rostered players in a division.

        Args:
            division: Division name. Defaults to config.default_division_name.
            stat_type: Type of stats to retrieve (batting, pitching, or both).
            year: Season year. Defaults to config.season_year.

        Returns:
            Dict with 'batting' and/or 'pitching' keys containing stat lists,
            or None on error.

        Examples:
            get_division_player_stats("Denali", StatType.BATTING, year=2025)
            get_division_player_stats("Adams", StatType.PITCHING, year=2023)
            get_division_player_stats("Adams", StatType.BOTH)
        """
        division = division or self.config.default_division_name
        year = year or self.config.season_year
        result: TeamStatsResult = {}

        if stat_type in (StatType.BATTING, StatType.BOTH):
            data = await self._get("CumulativeBatting", division=division, year=year)
            if data is None:
                result["batting"] = None
            else:
                try:
                    result["batting"] = [
                        CumulativeBattingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativeBatting response: %s", e)
                    result["batting"] = None

        if stat_type in (StatType.PITCHING, StatType.BOTH):
            data = await self._get("CumulativePitching", division=division, year=year)
            if data is None:
                result["pitching"] = None
            else:
                try:
                    result["pitching"] = [
                        CumulativePitchingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativePitching response: %s", e)
                    result["pitching"] = None

        return result

    async def get_division_team_stats(
        self,
        division: Optional[str] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get aggregated stats for all teams in a division.

        Returns average and total stats per team (e.g., team batting averages,
        total stolen bases).

        Args:
            division: Division name. Defaults to config.default_division_name.
            stat_type: Type of stats to retrieve (batting, pitching, or both).
            year: Season year. Defaults to config.season_year.

        Returns:
            Dict with 'batting' and/or 'pitching' keys containing stat lists,
            or None on error.

        Examples:
            get_division_team_stats("Denali", StatType.BATTING)
            get_division_team_stats("Denali", StatType.PITCHING, year=2025)
        """
        division = division or self.config.default_division_name
        year = year or self.config.season_year
        result: TeamStatsResult = {}

        if stat_type in (StatType.BATTING, StatType.BOTH):
            data = await self._get(
                "CumulativeBatting", division=division, year=year, group="teams"
            )
            if data is None:
                result["batting"] = None
            else:
                try:
                    result["batting"] = [
                        CumulativeBattingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativeBatting response: %s", e)
                    result["batting"] = None

        if stat_type in (StatType.PITCHING, StatType.BOTH):
            data = await self._get(
                "CumulativePitching", division=division, year=year, group="teams"
            )
            if data is None:
                result["pitching"] = None
            else:
                try:
                    result["pitching"] = [
                        CumulativePitchingStats.from_api(item) for item in data
                    ]
                except Exception as e:
                    logger.error("Failed to parse CumulativePitching response: %s", e)
                    result["pitching"] = None

        return result


class PSSBLClient:
    """Sync wrapper for the PSSBL API client.

    Provides a synchronous interface for simple scripts that don't need async.
    Uses asyncio.run() internally to execute async methods.

    All methods return None on error and log exceptions.
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        use_cache: bool = True,
        cache_dir: Optional[Path] = None,
    ) -> None:
        """Initialize the sync client.

        Args:
            config: Configuration object. Creates default if not provided.
            use_cache: Enable response caching with 24h TTL. Default True.
            cache_dir: Directory for cache files. Default ~/.cache/pssbl_api.
        """
        self.config = config or Config()
        self._use_cache = use_cache
        self._cache_dir = cache_dir

    def _run(self, coro: object) -> object:
        """Run an async coroutine synchronously."""
        return asyncio.run(coro)  # type: ignore[arg-type]

    def get_team_names(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[Team]]:
        """Get all teams in the league."""

        async def _fetch() -> Optional[list[Team]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_team_names(year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_divisions(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[Division]]:
        """Get all divisions in the league."""

        async def _fetch() -> Optional[list[Division]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_divisions(year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_division(
        self,
        division: Optional[str] = None,
        year: Optional[int] = None,
    ) -> Optional[list[TeamInDivision]]:
        """Get all teams in a specific division."""

        async def _fetch() -> Optional[list[TeamInDivision]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_division(division=division, year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_all_players(
        self,
        year: Optional[int] = None,
    ) -> Optional[list[RegisteredPlayer]]:
        """Get all players registered for a given year."""

        async def _fetch() -> Optional[list[RegisteredPlayer]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_all_players(year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_roster(
        self,
        team_id: Optional[int] = None,
        year: Optional[int] = None,
    ) -> Optional[list[RosterPlayer]]:
        """Get all players on a specific team."""

        async def _fetch() -> Optional[list[RosterPlayer]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_roster(team_id=team_id, year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_games(
        self,
        division: Optional[str] = None,
        year: Optional[int] = None,
    ) -> Optional[list[Game]]:
        """Get all games for a division and year."""

        async def _fetch() -> Optional[list[Game]]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_games(division=division, year=year)

        return self._run(_fetch())  # type: ignore[return-value]

    def get_player_stats(
        self,
        player_id: int,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
        show_career: bool = False,
    ) -> Optional[PlayerStatsResult]:
        """Get stats for a single player."""

        async def _fetch() -> Optional[PlayerStatsResult]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_player_stats(
                    player_id=player_id,
                    stat_type=stat_type,
                    year=year,
                    show_career=show_career,
                )

        return self._run(_fetch())  # type: ignore[return-value]

    def get_team_stats(
        self,
        team_id: Optional[int] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get stats for all rostered players on a team."""

        async def _fetch() -> Optional[TeamStatsResult]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_team_stats(
                    team_id=team_id,
                    stat_type=stat_type,
                    year=year,
                )

        return self._run(_fetch())  # type: ignore[return-value]

    def get_division_player_stats(
        self,
        division: Optional[str] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get stats for all rostered players in a division."""

        async def _fetch() -> Optional[TeamStatsResult]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_division_player_stats(
                    division=division,
                    stat_type=stat_type,
                    year=year,
                )

        return self._run(_fetch())  # type: ignore[return-value]

    def get_division_team_stats(
        self,
        division: Optional[str] = None,
        stat_type: StatType = StatType.BOTH,
        year: Optional[int] = None,
    ) -> Optional[TeamStatsResult]:
        """Get aggregated stats for all teams in a division."""

        async def _fetch() -> Optional[TeamStatsResult]:
            async with PSSBLClientAsync(
                config=self.config,
                use_cache=self._use_cache,
                cache_dir=self._cache_dir,
            ) as client:
                return await client.get_division_team_stats(
                    division=division,
                    stat_type=stat_type,
                    year=year,
                )

        return self._run(_fetch())  # type: ignore[return-value]
