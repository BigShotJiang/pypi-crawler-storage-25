"""Minimal csrd.metrics stub package."""

__all__: tuple[str, ...] = ()
