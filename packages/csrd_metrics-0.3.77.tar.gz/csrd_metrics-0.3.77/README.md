# csrd-metrics

Minimal stub package reserved for future metrics support in the `csrd` ecosystem.
