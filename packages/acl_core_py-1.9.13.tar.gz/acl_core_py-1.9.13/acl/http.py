"""
ACL SDK HTTP Layer

This module handles all HTTP communication with the ACL API, including authentication,
error handling, retries, and response parsing.
"""

import json
import time
import uuid
from typing import Dict, Any, Optional, Union
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .exceptions import (
    ACLAuthError,
    ACLPermissionError,
    ACLRateLimitError,
    ACLValidationError,
    ACLServerError,
    ACLBaseError,
    ACLTimeoutError,
    ACLConnectionError,
)
from .config import (
    DEFAULT_TIMEOUT,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY,
    API_KEY_HEADER,
    REQUEST_ID_HEADER,
    USER_AGENT,
)


class HttpClient:
    """Robust HTTP client for communicating with the ACL API."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        """Initialize HTTP client with authentication and configuration."""
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        # Create session with retry strategy
        self.session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=DEFAULT_RETRY_DELAY,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=[
                "HEAD",
                "GET",
                "POST",
                "PUT",
                "DELETE",
                "OPTIONS",
                "TRACE",
            ],
            raise_on_status=False,
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

        # Set default headers
        self.session.headers.update(
            {
                "User-Agent": USER_AGENT,
                "Content-Type": "application/json",
                "Accept": "application/json",
                API_KEY_HEADER: f"Bearer {self.api_key}",
                "X-API-Key": self.api_key,
            }
        )

    def _handle_error_response(self, response: requests.Response) -> None:
        """Handle error responses and raise appropriate exceptions."""
        status_code = response.status_code

        try:
            error_data = response.json()
            message = error_data.get("error", {}).get("message", "Unknown error")
        except (json.JSONDecodeError, KeyError):
            message = f"HTTP {status_code}: {response.text}"

        if status_code == 401:
            raise ACLAuthError(message)
        elif status_code == 403:
            raise ACLPermissionError(message)
        elif status_code == 429:
            raise ACLRateLimitError(message)
        elif 400 <= status_code < 500:
            raise ACLValidationError(message)
        elif 500 <= status_code < 600:
            raise ACLServerError(message)
        else:
            raise ACLBaseError(f"Unexpected HTTP status {status_code}: {message}")

    def request(
        self,
        method: str,
        url_or_endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        request_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Make HTTP request to ACL API."""
        if url_or_endpoint.startswith("http"):
            url = url_or_endpoint
        else:
            url = f"{self.base_url}{url_or_endpoint}"

        headers = kwargs.pop("headers", {})
        if request_id:
            headers[REQUEST_ID_HEADER] = request_id

        timeout = kwargs.pop("timeout", self.timeout)

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                headers=headers,
                timeout=timeout,
                **kwargs,
            )

            if 200 <= response.status_code < 300:
                response_data = response.json()
                if "metadata" not in response_data:
                    response_data["metadata"] = {}
                response_data["metadata"]["request_id"] = response.headers.get(
                    REQUEST_ID_HEADER
                )
                return response_data

            self._handle_error_response(response)

        except requests.exceptions.Timeout as e:
            raise ACLTimeoutError(f"Request timeout: {str(e)}")
        except requests.exceptions.ConnectionError as e:
            raise ACLConnectionError(f"Connection error: {str(e)}")
        except requests.exceptions.RequestException as e:
            raise ACLServerError(f"Request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise ACLValidationError(f"Invalid JSON response: {str(e)}")

    def post(
        self, url: str, json: Optional[Dict[str, Any]] = None, **kwargs: Any
    ) -> Dict[str, Any]:
        """Make POST request."""
        return self.request("POST", url, json_data=json, **kwargs)

    def get(self, url: str, **kwargs: Any) -> Dict[str, Any]:
        """Make GET request."""
        return self.request("GET", url, **kwargs)

    def close(self) -> None:
        """Close the HTTP session."""
        self.session.close()
