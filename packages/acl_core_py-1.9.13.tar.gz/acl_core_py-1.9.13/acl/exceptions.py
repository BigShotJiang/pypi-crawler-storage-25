"""
ACL SDK Exceptions

Custom exceptions for the ACL Python SDK.
"""

from typing import Optional


class ACLBaseError(Exception):
    """Base class for all ACL SDK exceptions."""

    codes = {
        "AUTH_FAILED": "ACL_ERR_AUTH_FAILED",
        "PROVIDER_TIMEOUT": "ACL_ERR_PROVIDER_TIMEOUT",
        "INVALID_KEY": "ACL_ERR_INVALID_KEY",
        "EMPTY_RESPONSE": "ACL_ERR_EMPTY_RESPONSE",
        "RETRY_FAILED": "ACL_ERR_RETRY_FAILED",
        "LOOP_DETECTED": "ACL_ERR_LOOP_DETECTED",
        "INTERNAL": "ACL_ERR_INTERNAL",
    }

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "ACL_ERR_INTERNAL"
        self.request_id = request_id

    def __str__(self) -> str:
        res = f"[{self.error_code}] {self.message}"
        if self.request_id:
            res += f" (Request ID: {self.request_id})"
        return res


class ACLAuthError(ACLBaseError):
    """Raised when authentication fails (401 Unauthorized)."""

    pass


class ACLAuthenticationError(ACLAuthError):
    """Compatibility alias for ACLAuthError."""

    pass


class ACLPermissionError(ACLBaseError):
    """Raised when permission is denied (403 Forbidden)."""

    pass


class ACLRateLimitError(ACLBaseError):
    """Raised when rate limit is exceeded (429 Too Many Requests)."""

    pass


class ACLValidationError(ACLBaseError):
    """Raised when request validation fails (4xx errors)."""

    pass


class ACLServerError(ACLBaseError):
    """Raised when server encounters an error (5xx errors)."""

    pass


class ACLError(ACLBaseError):
    """Alias for ACLBaseError for backward compatibility."""

    pass


class ACLModelError(ACLBaseError):
    """Raised when LLM model errors occur."""

    pass


class ACLTimeoutError(ACLBaseError):
    """Raised when request times out."""

    pass


class ACLConnectionError(ACLBaseError):
    """Raised when connection fails."""

    pass


class ACLSilentFailure(ACLBaseError):
    """Raised when an LLM returns an empty response but no error."""

    def __init__(self, message: str = "LLM returned an empty response", **kwargs):
        super().__init__(message, error_code="ACL_ERR_EMPTY_RESPONSE", **kwargs)


class ACLBudgetError(ACLBaseError):
    """Raised when ACL server returns a zero budget for a non-fast-path request."""

    def __init__(self, message: str = "ACL Core returned zero budget", **kwargs):
        super().__init__(message, error_code="ACL_ERR_BUDGET_EXHAUSTED", **kwargs)
