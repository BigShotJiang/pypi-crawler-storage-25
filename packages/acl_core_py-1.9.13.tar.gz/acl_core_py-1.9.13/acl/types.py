"""
ACL SDK Type Definitions

This module defines the type hints and data structures used throughout the SDK.
"""

from typing import Dict, Any, Optional, List, Union
from typing_extensions import TypedDict


class InputSegment(TypedDict, total=False):
    """Schema describing a single multimodal input segment."""

    id: Optional[str]
    modality: str
    content: Optional[str]
    token_estimate: Optional[int]
    metadata: Dict[str, Any]


class ModelHint(TypedDict, total=False):
    """Optional hint describing expected downstream model usage."""

    name: str
    segment_tokens: Optional[int]


class ActivityInfo(TypedDict):
    """Detected activity information."""

    type: str
    confidence: float
    category: str
    details: Dict[str, Any]


class WindowInfo(TypedDict):
    """Adaptive window recommendations."""

    final_token_budget: int
    max_tokens: int
    confidence: float
    reasoning: str


class ModelAdaptation(TypedDict):
    """Model adaptation results."""

    model_name: str
    optimized_tokens: int
    estimated_savings: float
    adaptations: List[str]


class TokenSavings(TypedDict):
    """Token usage and savings information."""

    original_tokens: int
    optimized_tokens: int
    savings_percentage: float
    savings_count: int


class TelemetryData(TypedDict):
    """Backend telemetry data."""

    execution_profile: str
    cor_percent: float
    processing_time_ms: int
    request_id: str


class AdaptiveResponse(TypedDict):
    """Complete response from adaptive window API."""

    strategy: str
    activity: ActivityInfo
    window: WindowInfo
    model_adaptation: ModelAdaptation
    metadata: Dict[str, Any]
    token_savings: Optional[TokenSavings]


class AnalyzeResponse(TypedDict, total=False):
    """Response from analyze() (/v1/analyze)"""

    execution_profile_id: str
    profile_class: str
    confidence: float
    metadata: Dict[str, Any]
    telemetry_id: str
    adaptive_limit: Optional[int]


class ErrorResponse(TypedDict):
    """Error response structure."""

    error: Dict[str, Any]
