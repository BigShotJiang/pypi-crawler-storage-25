from typing import Any, Dict, Callable, List
import logging
from acl.middlewares.base import ACLMiddleware
from acl.similarity.engine import SimilarityEngine

logger = logging.getLogger(__name__)


class LoopDetectionMiddleware(ACLMiddleware):
    """
    Standardizes loop detection logic with a 3-layer system:
    Layer 1: TF-IDF Cosine Similarity
    Layer 2: Response Fingerprinting
    Layer 3: Entropy Analysis

    Loop Confirmation: 2 out of 3 layers must signal.
    Gradual States:
    - 1 layer signal = warning (log)
    - 2 layers signal = soft loop (prepare recovery)
    - 2 layers + 2 consecutive = confirmed loop (trigger recovery)
    """

    def __init__(self, session_manager: Any):
        self.session_manager = session_manager
        self.similarity_engine = SimilarityEngine()

    def __call__(self, params: Dict[str, Any], next_call: Callable) -> Dict[str, Any]:
        session_id = params.get("session_id", "default")

        # Skip loop detection during recovery mode
        if params.get("_recovery_mode") or params.get("_recovery_attempt"):
            response = next_call(params)
            text = response.get("text", "")
            if text:
                self.session_manager.add_to_history(session_id, text)
            response["loop_detected"] = False
            return response

        # 1. Execute next in chain (Normalization or Provider)
        response = next_call(params)

        # 2. Extract Response Text
        text = response.get("text", "")
        if not text:
            return response

        # 3. Multi-Layer Detection
        signals = 0
        layer_results = {}

        # LAYER 1: TF-IDF Cosine Similarity
        tfidf_history = self.session_manager.get_tfidf_history(session_id)
        if tfidf_history:
            max_sim = self.similarity_engine.calculate_layer1_tfidf(text, tfidf_history)
            layer_results["tfidf_sim"] = max_sim
            if max_sim >= 0.88:
                signals += 1
                logger.warning(f"Loop Layer 1 (TF-IDF) signal: {max_sim:.4f}")

        # LAYER 2: Response Fingerprint
        current_fp = self.similarity_engine.calculate_layer2_fingerprint(text)
        fp_history = self.session_manager.get_fingerprint_history(session_id)
        if fp_history:
            # Compare to last 2 responses
            last_2_fps = fp_history[-2:]
            max_matches = 0
            for prev_fp in last_2_fps:
                matches = self.similarity_engine.compare_fingerprints(
                    current_fp, prev_fp
                )
                max_matches = max(max_matches, matches)

            layer_results["fp_matches"] = max_matches
            if max_matches >= 3:
                signals += 1
                logger.warning(
                    f"Loop Layer 2 (Fingerprint) signal: {max_matches} matches"
                )

        # LAYER 3: Entropy Drop
        current_entropy = self.similarity_engine.calculate_layer3_entropy(text)
        entropy_history = self.session_manager.get_entropy_history(session_id)
        if entropy_history:
            avg_entropy = sum(entropy_history) / len(entropy_history)
            drop = (
                (avg_entropy - current_entropy) / avg_entropy if avg_entropy > 0 else 0
            )
            layer_results["entropy_drop"] = drop
            if drop > 0.35:
                signals += 1
                logger.warning(f"Loop Layer 3 (Entropy) signal: {drop:.2%} drop")

        # 4. State Management
        loop_detected = False
        consecutive_signals = self.session_manager.get_consecutive_signals(session_id)

        if signals >= 1:
            consecutive_signals += 1
            self.session_manager.set_consecutive_signals(
                session_id, consecutive_signals
            )
            logger.info(
                f"Loop signal warning: {signals} layers, consecutive={consecutive_signals} for session {session_id}"
            )

            # New Strategy:
            # (2 layers + 2 signals = sturdy confirm) OR (1 layer + 3 signals = stable confirm)
            if (signals >= 2 and consecutive_signals >= 2) or (
                consecutive_signals >= 3
            ):
                loop_detected = True
                logger.error(
                    f"LOOP CONFIRMED for session {session_id}: signals={signals}, consecutive={consecutive_signals}"
                )

            if signals >= 2:
                response["soft_loop"] = True
        else:
            # Reset counter on no signals
            self.session_manager.set_consecutive_signals(session_id, 0)

        # 5. Update session history
        self.session_manager.add_to_history(session_id, text)
        self.session_manager.add_to_tfidf_history(session_id, text)
        self.session_manager.add_to_fingerprint_history(session_id, current_fp)
        self.session_manager.add_to_entropy_history(session_id, current_entropy)

        # 6. Enrich response
        response["loop_detected"] = loop_detected
        response["loop_signals"] = signals
        response["loop_layer_results"] = layer_results
        return response
