from typing import Any, Dict, Callable
from abc import ABC, abstractmethod


class ACLMiddleware(ABC):
    """
    Phase 3 — Execution Middleware Pipeline.
    Base class for all ACL SDK middlewares.
    """

    @abstractmethod
    def __call__(self, params: Dict[str, Any], next_call: Callable) -> Dict[str, Any]:
        """
        Intersects the request/response flow.
        """
        pass
