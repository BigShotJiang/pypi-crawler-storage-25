import re
import string
import json
import os
import math
from collections import Counter
from typing import Set, Dict, List, Any
import logging

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


class SimilarityEngine:
    """
    Standardized Loop Detection Engine (Phase 2)
    3-Layer Detection: TF-IDF Cosine, Response Fingerprinting, and Entropy Analysis.
    """

    def __init__(self, spec_path: str = None):
        if not spec_path:
            # Robust path detection for production/pip environments
            # Search order:
            # 1. Same directory as this file (engine.py)
            # 2. Package root/shared/
            # 3. Current working directory/shared/

            pkg_dir = os.path.dirname(os.path.abspath(__file__))
            pkg_root = os.path.dirname(os.path.dirname(pkg_dir))  # acl-sdk-p/

            search_paths = [
                os.path.join(pkg_dir, "similarity_spec.json"),
                os.path.join(pkg_root, "shared", "similarity_spec.json"),
                os.path.join(os.getcwd(), "shared", "similarity_spec.json"),
            ]

            for path in search_paths:
                if os.path.exists(path):
                    spec_path = path
                    break

        self.spec = {
            "tfidf_threshold": 0.88,
            "min_tokens": 5,
            "entropy_drop_threshold": 0.35,
            "fingerprint_matches_required": 3,
        }

        if spec_path and os.path.exists(spec_path):
            with open(spec_path, "r") as f:
                self.spec.update(json.load(f))

    def calculate_layer1_tfidf(self, text: str, history: List[str]) -> float:
        """LAYER 1 — TF-IDF Cosine Similarity."""
        if not text or not history:
            return 0.0

        if not SKLEARN_AVAILABLE:
            logging.warning(
                "TF-IDF loop detection unavailable (scikit-learn not found). Using structural fallback."
            )
            return 0.0

        try:
            vectorizer = TfidfVectorizer().fit_transform(history + [text])
            vectors = vectorizer.toarray()
            current_vector = vectors[-1].reshape(1, -1)
            history_vectors = vectors[:-1]

            similarities = cosine_similarity(current_vector, history_vectors)[0]
            return float(max(similarities))
        except Exception as e:
            logging.warning(f"TF-IDF calculation failed: {str(e)}. Using fallback.")
            return 0.0

    def calculate_layer2_fingerprint(self, text: str) -> Dict[str, Any]:
        """LAYER 2 — Response Fingerprint Generation."""
        words = re.findall(r"\w+", text.lower())
        word_count = len(words)

        # Length Bucket
        if word_count < 100:
            length_bucket = "S"
        elif word_count <= 300:
            length_bucket = "M"
        else:
            length_bucket = "L"

        # First/Last 5 words
        first_5 = words[:5]
        last_5 = words[-5:]

        # Unique word ratio
        unique_ratio = len(set(words)) / word_count if word_count > 0 else 0.0

        # Sentence count
        sentences = re.split(r"[.!?]+", text)
        sentence_count = len([s for s in sentences if s.strip()])

        return {
            "length_bucket": length_bucket,
            "first_5_words": first_5,
            "last_5_words": last_5,
            "unique_word_ratio": round(unique_ratio, 4),
            "sentence_count": sentence_count,
        }

    def compare_fingerprints(self, fp1: Dict[str, Any], fp2: Dict[str, Any]) -> int:
        """Compare two fingerprints and return number of matching fields."""
        matches = 0
        if fp1["length_bucket"] == fp2["length_bucket"]:
            matches += 1
        if fp1["first_5_words"] == fp2["first_5_words"]:
            matches += 1
        if fp1["last_5_words"] == fp2["last_5_words"]:
            matches += 1
        if abs(fp1["unique_word_ratio"] - fp2["unique_word_ratio"]) < 0.01:
            matches += 1
        if fp1["sentence_count"] == fp2["sentence_count"]:
            matches += 1
        return matches

    def calculate_layer3_entropy(self, text: str) -> float:
        """LAYER 3 — Shannon Entropy Calculation."""
        if not text:
            return 0.0

        # Optimization: Sample large texts (matching execution_engine.py)
        if len(text) > 25000:
            sample_size = 5000
            mid = len(text) // 2
            text = (
                text[:sample_size] + text[mid : mid + sample_size] + text[-sample_size:]
            )

        counter = Counter(text)
        total_len = len(text)

        entropy = 0.0
        for count in counter.values():
            p = count / total_len
            entropy -= p * math.log2(p)

        return entropy

    def calculate(self, text1: str, text2: str) -> float:
        """Legacy support for Jaccard (if needed), but now defaults to simple word-set similarity."""
        words1 = set(re.findall(r"\w+", text1.lower()))
        words2 = set(re.findall(r"\w+", text2.lower()))
        if not words1 or not words2:
            return 0.0
        return len(words1.intersection(words2)) / len(words1.union(words2))
