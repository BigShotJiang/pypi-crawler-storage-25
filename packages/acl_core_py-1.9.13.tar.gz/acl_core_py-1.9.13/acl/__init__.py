﻿"""
ACL Python SDK

A thin, predictable Python SDK for the Adaptive Context Window API.

The SDK provides enterprise-grade error handling and telemetry while delegating
all intelligence and processing to the ACL backend.
"""

from .client import ACLClient
from .exceptions import (
    ACLBaseError,
    ACLAuthError,
    ACLPermissionError,
    ACLRateLimitError,
    ACLValidationError,
    ACLServerError,
)
from .types import (
    AdaptiveResponse,
    TelemetryData,
    ActivityInfo,
    WindowInfo,
    ModelAdaptation,
    TokenSavings,
)

__version__ = "1.9.9"
__all__ = [
    "ACLClient",
    "ACLBaseError",
    "ACLAuthError",
    "ACLPermissionError",
    "ACLRateLimitError",
    "ACLValidationError",
    "ACLServerError",
    "AdaptiveResponse",
    "TelemetryData",
    "ActivityInfo",
    "WindowInfo",
    "ModelAdaptation",
    "TokenSavings",
]

