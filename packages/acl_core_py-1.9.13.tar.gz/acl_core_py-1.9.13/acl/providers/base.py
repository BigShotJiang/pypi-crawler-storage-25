from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BaseProvider(ABC):
    """
    Abstract base class for all LLM providers.
    """

    @abstractmethod
    def capabilities(self) -> Dict[str, bool]:
        """
        Phase 2 — Provider Capability Abstraction.
        Returns capability flags for the provider.
        """
        pass

    @abstractmethod
    def call(
        self,
        prompt: str,
        model: str,
        api_key: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        stream: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Execute a completion request to the LLM provider.

        Returns a dictionary with standardized keys:
        - text: The generated content
        - finish_reason: string (stop, length, etc.)
        - tokens_input: int
        - tokens_output: int
        - total_tokens: int
        - raw_response: Dict
        """
        pass

    @abstractmethod
    def stream(self, **kwargs: Any):
        """Standard stream placeholder."""
        pass
