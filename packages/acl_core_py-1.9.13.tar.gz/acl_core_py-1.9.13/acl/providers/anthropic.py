import requests
import threading
from typing import Any, Dict, Optional
from requests.adapters import HTTPAdapter
from acl.providers.base import BaseProvider
from acl.exceptions import (
    ACLAuthenticationError,
    ACLRateLimitError,
    ACLModelError,
    ACLTimeoutError,
    ACLConnectionError,
)
from acl.security import redact_secrets


class AnthropicProvider(BaseProvider):
    """
    Anthropic implementation for the ACL SDK.
    Phase 2: Capability-aware.
    Phase 4: Finish reason normalization.
    """

    _session: Optional[requests.Session] = None
    _session_lock = threading.Lock()

    @classmethod
    def _get_session(cls) -> requests.Session:
        if cls._session is None:
            with cls._session_lock:
                if cls._session is None:
                    session = requests.Session()
                    adapter = HTTPAdapter(pool_connections=16, pool_maxsize=32)
                    session.mount("https://", adapter)
                    session.mount("http://", adapter)
                    cls._session = session
        return cls._session

    def capabilities(self) -> Dict[str, bool]:
        return {
            "streaming": True,
            "tools": True,
            "json_mode": False,
            "vision": True,
            "embeddings": False,
            "function_calling": True,
        }

    def call(
        self,
        prompt: str,
        model: str,
        api_key: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        stream: bool = False,
        timeout: int = 30,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        try:
            session = self._get_session()
            response = session.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": max_tokens or 1000,
                    "temperature": temperature,
                    "stream": stream,
                    **kwargs,
                },
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()

            # Standardize response (ACL Universal Schema v1.1)
            usage = data.get("usage", {})
            content = data.get("content", [])

            # Normalize finish_reason (Phase 4)
            stop_reason = data.get("stop_reason", "unknown")
            reason_map = {
                "end_turn": "stop",
                "max_tokens": "length",
                "stop_sequence": "stop",
                "tool_use": "tool_call",
            }

            return {
                "text": content[0].get("text", "") if content else "",
                "finish_reason": reason_map.get(stop_reason, "unknown"),
                "tokens_input": usage.get("input_tokens", 0),
                "tokens_output": usage.get("output_tokens", 0),
                "total_tokens": usage.get("input_tokens", 0)
                + usage.get("output_tokens", 0),
                "raw_response": data,
            }
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code
            safe_error = redact_secrets(str(e))
            if status_code == 401:
                raise ACLAuthenticationError(f"Anthropic Auth failed: {safe_error}")
            elif status_code == 429:
                raise ACLRateLimitError(
                    f"Anthropic Rate limit exceeded: {safe_error}"
                )
            else:
                raise ACLModelError(
                    f"Anthropic Provider error ({status_code}): {safe_error}"
                )
        except requests.exceptions.Timeout:
            raise ACLTimeoutError("Anthropic request timed out")
        except requests.exceptions.ConnectionError:
            raise ACLConnectionError("Anthropic connection failed")
        except Exception as e:
            raise ACLModelError(
                f"Unexpected Anthropic error: {redact_secrets(str(e))}"
            )

    def stream(self, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "Streaming not yet supported. Use complete() for standard requests."
        )
