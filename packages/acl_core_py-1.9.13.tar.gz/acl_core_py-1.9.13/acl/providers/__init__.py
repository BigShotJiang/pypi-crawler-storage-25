from typing import Dict, Type
from .base import BaseProvider
from .openai import OpenAIProvider
from .anthropic import AnthropicProvider
from .google import GoogleProvider


class ProviderRegistry:
    """Universal Registry for LLM Providers."""

    _providers: Dict[str, Type[BaseProvider]] = {
        "openai": OpenAIProvider,
        "anthropic": AnthropicProvider,
        "google": GoogleProvider,
        "universal": OpenAIProvider,  # Use OpenAI standard for custom models
    }

    @classmethod
    def register(cls, name: str, provider_class: Type[BaseProvider]):
        """Dynamically inject a new provider."""
        cls._providers[name.lower()] = provider_class

    @classmethod
    def get(cls, name: str) -> BaseProvider:
        """Instantiate and return a provider."""
        provider_class = cls._providers.get(name.lower())
        if not provider_class:
            raise ValueError(f"Provider '{name}' not found in registry.")
        return provider_class()

    @classmethod
    def list_available(cls):
        return list(cls._providers.keys())
