import collections
import threading
from typing import Any, Dict, List, Optional


class SessionManager:
    """
    Phase 5 — Session Policy Flexibility.
    Abstracts session state management with policy support (FIFO, LRU).
    """

    def __init__(self, policy: str = "FIFO", limit: int = 200):
        self.policy = policy.upper()
        self.limit = limit
        self._lock = threading.RLock()

        if self.policy == "LRU":
            self._sessions = collections.OrderedDict()
        else:  # Default FIFO
            self._sessions = {}
            self._order = []

        self._history = {}  # session_id -> List[str]
        self._tfidf_history = {}  # session_id -> List[str]
        self._fingerprint_history = {}  # session_id -> List[Dict]
        self._entropy_history = {}  # session_id -> List[float]
        self._metrics = {}  # session_id -> Dict
        self._consecutive_matches = {}  # session_id -> int (for loop detection warning)
        self._consecutive_signals = {}  # session_id -> int (for confirmed loop)

    def get_history(self, session_id: str) -> List[str]:
        with self._lock:
            return self._history.get(session_id, [])

    def add_to_history(self, session_id: str, text: str):
        with self._lock:
            if session_id not in self._history:
                self._history[session_id] = []
                self._touch(session_id)

            history = self._history[session_id]
            history.append(text)

            # Keep last 10 for general context
            if len(history) > 10:
                history.pop(0)

    def get_tfidf_history(self, session_id: str) -> List[str]:
        with self._lock:
            return self._tfidf_history.get(session_id, [])

    def add_to_tfidf_history(self, session_id: str, text: str):
        with self._lock:
            if session_id not in self._tfidf_history:
                self._tfidf_history[session_id] = []
            history = self._tfidf_history[session_id]
            history.append(text)
            if len(history) > 5:
                history.pop(0)

    def get_fingerprint_history(self, session_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            return self._fingerprint_history.get(session_id, [])

    def add_to_fingerprint_history(self, session_id: str, fingerprint: Dict[str, Any]):
        with self._lock:
            if session_id not in self._fingerprint_history:
                self._fingerprint_history[session_id] = []
            history = self._fingerprint_history[session_id]
            history.append(fingerprint)
            if len(history) > 5:
                history.pop(0)

    def get_entropy_history(self, session_id: str) -> List[float]:
        with self._lock:
            return self._entropy_history.get(session_id, [])

    def add_to_entropy_history(self, session_id: str, entropy: float):
        with self._lock:
            if session_id not in self._entropy_history:
                self._entropy_history[session_id] = []
            history = self._entropy_history[session_id]
            history.append(entropy)
            if len(history) > 5:
                history.pop(0)

    def get_consecutive_match_count(self, session_id: str) -> int:
        """Get the current consecutive match count (legacy/warning)."""
        with self._lock:
            return self._consecutive_matches.get(session_id, 0)

    def set_consecutive_match_count(self, session_id: str, count: int):
        """Set the consecutive match count (legacy/warning)."""
        with self._lock:
            self._consecutive_matches[session_id] = count

    def get_consecutive_signals(self, session_id: str) -> int:
        """Get consecutive signals for confirmed loop."""
        with self._lock:
            return self._consecutive_signals.get(session_id, 0)

    def set_consecutive_signals(self, session_id: str, count: int):
        """Set consecutive signals for confirmed loop."""
        with self._lock:
            self._consecutive_signals[session_id] = count

    def reset_history(self, session_id: str, summary: str = ""):
        """
        Reset session history to a single summary entry.
        """
        with self._lock:
            self._history[session_id] = [summary] if summary else []
            self._tfidf_history[session_id] = []
            self._fingerprint_history[session_id] = []
            self._entropy_history[session_id] = []
            self._consecutive_matches[session_id] = 0
            self._consecutive_signals[session_id] = 0

    def get_metrics(self, session_id: str) -> Dict[str, Any]:
        with self._lock:
            if session_id not in self._metrics:
                self._metrics[session_id] = {
                    "total_requests": 0,
                    "total_tokens_saved": 0,
                    "api_failures_recovered": 0,
                    "silent_failures_recovered": 0,
                    "loops_detected": 0,
                    "loops_broken": 0,
                    "peak_drift_score": 0.0,
                }
            return self._metrics[session_id]

    def increment_metric(self, session_id: str, metric_name: str, value: int = 1):
        """Increment a specific metric for a session."""
        with self._lock:
            metrics = self.get_metrics(session_id)
            metrics[metric_name] = metrics.get(metric_name, 0) + value

    def _touch(self, session_id: str):
        """Update order based on policy."""
        if self.policy == "LRU":
            if session_id in self._sessions:
                self._sessions.move_to_end(session_id)
            else:
                if len(self._sessions) >= self.limit:
                    self._sessions.popitem(last=False)
                self._sessions[session_id] = True
        else:  # FIFO
            if session_id not in self._order:
                if len(self._order) >= self.limit:
                    oldest = self._order.pop(0)
                    self._history.pop(oldest, None)
                    self._metrics.pop(oldest, None)
                    self._consecutive_matches.pop(oldest, None)
                self._order.append(session_id)

    def pop_session(self, session_id: str) -> Optional[Dict]:
        with self._lock:
            self._history.pop(session_id, None)
            self._consecutive_matches.pop(session_id, None)
            self._consecutive_signals.pop(session_id, None)
            if self.policy == "LRU":
                self._sessions.pop(session_id, None)
            else:
                if session_id in self._order:
                    self._order.remove(session_id)
            return self._metrics.pop(session_id, None)

    def list_sessions(self) -> List[str]:
        with self._lock:
            if self.policy == "LRU":
                return list(self._sessions.keys())
            return list(self._order)
