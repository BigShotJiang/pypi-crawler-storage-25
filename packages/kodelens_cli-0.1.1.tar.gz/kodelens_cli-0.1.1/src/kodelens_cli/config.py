"""
Config resolution — priority:
1. KODELENS_REPO_ID env var
2. Auto-detect from .git/config remote URL → /api/cli/repository/?remote_url=
3. KODELENS_API_KEY env var
4. ~/.config/kodelens/credentials.json (from `kodelens login`)
5. KODELENS_URL env var (default: https://app.kodelens.io)
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

CREDENTIALS_FILE = Path.home() / ".config" / "kodelens" / "credentials.json"
DEFAULT_URL = "https://kodelens.kodestack.io"


def get_url() -> str:
    return os.environ.get("KODELENS_URL", DEFAULT_URL).rstrip("/")


def get_api_key() -> str | None:
    if key := os.environ.get("KODELENS_API_KEY"):
        return key
    if CREDENTIALS_FILE.exists():
        try:
            data = json.loads(CREDENTIALS_FILE.read_text())
            return data.get("api_key")
        except Exception:
            pass
    return None


def save_credentials(api_key: str) -> None:
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps({"api_key": api_key}))


def clear_credentials() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_repo_id_override() -> int | None:
    value = os.environ.get("KODELENS_REPO_ID")
    return int(value) if value else None


def detect_remote_url() -> str | None:
    """Use git to find the origin remote URL of the current repository."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None
