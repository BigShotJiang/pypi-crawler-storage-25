from __future__ import annotations

import httpx

from kodelens_cli.config import get_api_key, get_url


class KodeLensClient:
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self._base_url = (base_url or get_url()).rstrip("/")
        self._api_key = api_key or get_api_key()

    def _headers(self) -> dict:
        headers = {"Accept": "application/json"}
        if self._api_key:
            headers["X-Api-Key"] = self._api_key
        return headers

    def _get(self, path: str, params: dict | None = None) -> dict:
        url = f"{self._base_url}{path}"
        with httpx.Client(timeout=30) as client:
            resp = client.get(url, params=params, headers=self._headers())
        self._raise(resp)
        return resp.json()

    def _post(self, path: str, data: dict) -> dict:
        url = f"{self._base_url}{path}"
        with httpx.Client(timeout=30) as client:
            resp = client.post(url, json=data, headers=self._headers())
        self._raise(resp)
        return resp.json()

    def _patch(self, path: str, data: dict) -> dict:
        url = f"{self._base_url}{path}"
        with httpx.Client(timeout=30) as client:
            resp = client.patch(url, json=data, headers=self._headers())
        self._raise(resp)
        return resp.json()

    def _raise(self, resp: httpx.Response) -> None:
        if resp.status_code == 401:
            raise AuthError(
                "Not authenticated. Run `kodelens login` or set KODELENS_API_KEY."
            )
        if resp.status_code == 404:
            raise NotFoundError("Resource not found.")
        if not resp.is_success:
            try:
                detail = resp.json().get("error") or resp.text
            except Exception:
                detail = resp.text
            raise ApiError(f"API error {resp.status_code}: {detail}")

    def find_repository(
        self, *, remote_url: str | None = None, repo_id: int | None = None
    ) -> dict:
        params = {}
        if repo_id:
            params["repo_id"] = repo_id
        elif remote_url:
            params["remote_url"] = remote_url
        else:
            raise ValueError("Provide remote_url or repo_id.")
        return self._get("/api/cli/repository/", params=params)

    def repository_summary(self, repo_id: int) -> dict:
        return self._get(f"/api/cli/repositories/{repo_id}/summary/")

    def repository_observations(
        self,
        repo_id: int,
        *,
        severity: str | None = None,
        obs_type: str | None = None,
        file_path: str | None = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        params: dict = {"page": page, "per_page": per_page}
        if severity:
            params["severity"] = severity
        if obs_type:
            params["type"] = obs_type
        if file_path:
            params["file_path"] = file_path
        return self._get(
            f"/api/cli/repositories/{repo_id}/observations/", params=params
        )

    def create_branch(self, repo_id: int, branch_name: str, from_branch: str) -> dict:
        return self._post(
            f"/api/cli/repositories/{repo_id}/branches/",
            {"branch_name": branch_name, "from_branch": from_branch},
        )

    def observation_detail(self, observation_id: int) -> dict:
        return self._get(f"/api/cli/observations/{observation_id}/")

    def dismiss_observation(self, observation_id: int, reason: str) -> dict:
        return self._patch(
            f"/api/cli/observations/{observation_id}/",
            {"is_dismissed": True, "dismissal_reason": reason},
        )


class AuthError(Exception):
    pass


class NotFoundError(Exception):
    pass


class ApiError(Exception):
    pass
