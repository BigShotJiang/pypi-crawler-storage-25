"""
Login flow: PKCE browser-based auth.

1. Generate code_verifier + code_challenge
2. Start local HTTP server on ephemeral port
3. Open browser to {KODELENS_URL}/cli/auth?code_challenge=...&redirect_uri=...
4. KodeLens authenticates user, creates ApiKey, redirects to localhost callback
5. Extract token from callback, save to credentials file
"""

from __future__ import annotations

import base64
import hashlib
import http.server
import secrets
import threading
import urllib.parse
import webbrowser
from typing import Optional

from kodelens_cli.config import clear_credentials, get_url, save_credentials

_AUTH_SUCCESS_HTML = b"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KodeLens \xe2\x80\x94 Authenticated</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      height: 100%;
      background-color: #181925;
      color: #ffffff;
      font-family: "Roboto", sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .container {
      text-align: center;
      padding: 2rem;
      max-width: 560px;
    }
    .check {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: rgba(70, 223, 150, 0.12);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 2rem;
    }
    .check svg {
      width: 28px;
      height: 28px;
      stroke: #46df96;
      stroke-width: 2.5;
      fill: none;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    h1 {
      font-family: "Space Grotesk", sans-serif;
      font-size: 2.5rem;
      font-weight: 600;
      color: #46df96;
      letter-spacing: -0.02em;
      margin-bottom: 1rem;
    }
    p {
      font-size: 1.05rem;
      font-weight: 300;
      color: rgba(255, 255, 255, 0.6);
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="check">
      <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
    </div>
    <h1>You&rsquo;re all set.</h1>
    <p>KodeLens CLI is authenticated.<br>You can close this tab and return to the terminal.</p>
  </div>
</body>
</html>"""


def _generate_pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        .rstrip(b"=")
        .decode()
    )
    return verifier, challenge


def login() -> str:
    """Opens browser for KodeLens login, waits for callback, returns API key."""
    _, challenge = _generate_pkce()
    token_holder: dict[str, Optional[str]] = {"token": None}
    done = threading.Event()

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            token_holder["token"] = (params.get("token") or [None])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(_AUTH_SUCCESS_HTML)
            done.set()

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]
    redirect_uri = f"http://127.0.0.1:{port}/callback"

    auth_url = (
        f"{get_url()}/cli/auth/"
        f"?code_challenge={challenge}&redirect_uri={urllib.parse.quote(redirect_uri)}"
    )

    thread = threading.Thread(target=lambda: server.handle_request(), daemon=True)
    thread.start()

    webbrowser.open(auth_url)

    done.wait(timeout=120)
    server.server_close()

    token = token_holder["token"]
    if not token:
        raise TimeoutError("Login timed out. Please try again.")

    save_credentials(token)
    return token


def logout() -> None:
    clear_credentials()
