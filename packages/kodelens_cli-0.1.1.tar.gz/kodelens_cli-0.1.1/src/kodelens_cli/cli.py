from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from kodelens_cli.auth import login, logout
from kodelens_cli.client import ApiError, AuthError, KodeLensClient, NotFoundError
from kodelens_cli.config import detect_remote_url, get_api_key, get_repo_id_override

console = Console()
err_console = Console(stderr=True)

SEVERITY_COLOURS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "blue",
    "info": "dim",
}


def _make_client() -> KodeLensClient:
    if not get_api_key():
        err_console.print(
            "[red]Not authenticated.[/red] Run [bold]kodelens login[/bold] "
            "or set [bold]KODELENS_API_KEY[/bold]."
        )
        sys.exit(1)
    return KodeLensClient()


def _resolve_repo(client: KodeLensClient, debug: bool = False) -> dict:
    repo_id = get_repo_id_override()
    if repo_id:
        if debug:
            err_console.print(f"[dim]Using KODELENS_REPO_ID={repo_id}[/dim]")
        return client.find_repository(repo_id=repo_id)
    remote_url = detect_remote_url()
    if debug:
        err_console.print(f"[dim]Detected remote URL: {remote_url}[/dim]")
    if remote_url:
        return client.find_repository(remote_url=remote_url)
    err_console.print(
        "[red]Could not detect repository.[/red] "
        "Set [bold]KODELENS_REPO_ID[/bold] or run from inside a git repository."
    )
    sys.exit(1)


def _get_current_commit() -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def _warn_if_stale(repo: dict) -> None:
    latest = repo.get("latestCommitSha")
    current = _get_current_commit()
    if not latest or not current:
        return
    if not current.startswith(latest[:12]) and not latest.startswith(current[:12]):
        err_console.print(
            f"[yellow]Note: latest scan was on {latest[:8]}, "
            f"current HEAD is {current[:8]} — results may be outdated.[/yellow]"
        )


def _lang_from_path(file_path: str | None) -> str:
    if not file_path:
        return "text"
    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    return {
        "py": "python",
        "js": "javascript",
        "ts": "typescript",
        "tsx": "tsx",
        "jsx": "jsx",
        "rb": "ruby",
        "go": "go",
        "java": "java",
        "cs": "csharp",
        "rs": "rust",
        "php": "php",
        "kt": "kotlin",
        "swift": "swift",
    }.get(ext, "text")


@click.group()
def cli():
    """KodeLens CLI — surface code health issues in your terminal."""


@cli.command(name="login")
def login_cmd():
    """Authenticate with KodeLens via browser."""
    console.print("Opening browser for authentication...")
    try:
        login()
        console.print("[green]Authenticated successfully.[/green]")
    except TimeoutError as e:
        err_console.print(f"[red]{e}[/red]")
        sys.exit(1)


@cli.command(name="logout")
def logout_cmd():
    """Clear stored credentials."""
    logout()
    console.print("Logged out.")


@cli.group()
def issues():
    """Commands for browsing and inspecting code issues."""


@issues.command(name="list")
@click.option(
    "--file", "file_path", default=None, help="Filter to a specific file path."
)
@click.option(
    "--severity",
    default="high,critical",
    show_default=True,
    help="Comma-separated severities, or 'all'.",
)
@click.option(
    "--type",
    "obs_type",
    default=None,
    help="Filter by type: security, complexity, etc.",
)
@click.option("--limit", default=50, show_default=True)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.option("--debug", is_flag=True, hidden=True)
def issues_list(file_path, severity, obs_type, limit, as_json, debug):
    """List active issues for the current repository."""
    client = _make_client()
    try:
        repo = _resolve_repo(client, debug=debug)
        sev_param = None if severity == "all" else severity
        data = client.repository_observations(
            repo["id"],
            severity=sev_param,
            obs_type=obs_type,
            file_path=file_path,
            per_page=limit,
        )
    except (AuthError, NotFoundError, ApiError) as e:
        err_console.print(f"[red]{e}[/red]")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(data))
        return

    _warn_if_stale(repo)

    results = data.get("results", [])
    _print_table(results, data.get("total", 0))


@issues.command(name="detail")
@click.option("--id", "observation_id", required=True, type=int, help="Issue ID.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def issues_detail(observation_id, as_json):
    """Show full detail for a single issue."""
    client = _make_client()
    try:
        data = client.observation_detail(observation_id)
    except (AuthError, NotFoundError, ApiError) as e:
        err_console.print(f"[red]{e}[/red]")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(data))
        return

    _print_issue_detail(data)


@issues.command(name="dismiss")
@click.option("--id", "observation_id", required=True, type=int, help="Issue ID.")
@click.option("--message", required=True, help="Reason for dismissal.")
def issues_dismiss(observation_id, message):
    """Dismiss an issue with a required reason."""
    console.print(f"Dismissing issue [bold]#{observation_id}[/bold]")
    console.print(f"Reason: [dim]{message}[/dim]")
    if not click.confirm(f"Confirm dismiss issue #{observation_id}?", default=False):
        console.print("[dim]Cancelled.[/dim]")
        return
    client = _make_client()
    try:
        client.dismiss_observation(observation_id, reason=message)
    except (AuthError, NotFoundError, ApiError) as e:
        err_console.print(f"[red]{e}[/red]")
        sys.exit(1)
    console.print(f"[green]Issue #{observation_id} dismissed.[/green]")


def _print_table(results: list, total: int) -> None:
    if not results:
        console.print("[green]No issues found.[/green]")
        return

    table = Table(show_header=True, header_style="bold", show_lines=False)
    table.add_column("ID", justify="right", width=6)
    table.add_column("Severity", width=10)
    table.add_column("Type", width=12)
    table.add_column("File", overflow="fold")
    table.add_column("Line", justify="right", width=6)
    table.add_column("Title")

    for obs in results:
        sev = obs["severity"].lower()
        colour = SEVERITY_COLOURS.get(sev, "")
        sev_str = (
            f"[{colour}]{obs['severity']}[/{colour}]" if colour else obs["severity"]
        )
        file_str = obs.get("filePath") or ""
        sl = obs.get("startLine")
        line_str = str(sl) if sl is not None else ""
        table.add_row(
            str(obs["id"]),
            sev_str,
            obs.get("type", ""),
            file_str,
            line_str,
            obs.get("title", ""),
        )

    console.print(table)
    if total > len(results):
        console.print(
            f"[dim]Showing {len(results)} of {total}. Use --limit to see more.[/dim]"
        )


def _print_issue_detail(data: dict) -> None:
    sev = data.get("severity", "").lower()
    colour = SEVERITY_COLOURS.get(sev, "white")
    obs_type = data.get("type", "")
    issue_id = data.get("id", "")

    header = Text()
    header.append(f"Issue #{issue_id}", style="bold")
    header.append("  ·  ")
    header.append(data.get("severity", ""), style=colour)
    header.append("  ·  ")
    header.append(obs_type)

    repo_name = (data.get("repository") or {}).get("name", "")
    file_path = data.get("filePath") or ""
    start_line = data.get("startLine")
    end_line = data.get("endLine")
    start_col = data.get("startColumn")
    end_col = data.get("endColumn")

    lines_str = (
        f"{start_line}–{end_line}"
        if start_line is not None and end_line is not None
        else (str(start_line) if start_line is not None else "")
    )
    cols_str = (
        f"{start_col}–{end_col}"
        if start_col is not None and end_col is not None and (start_col or end_col)
        else ""
    )

    meta_lines = []
    if repo_name:
        meta_lines.append(f"[dim]Repo   [/dim] {repo_name}")
    if file_path:
        meta_lines.append(f"[dim]File   [/dim] {file_path}")
    if lines_str:
        meta_lines.append(f"[dim]Lines  [/dim] {lines_str}")
    if cols_str:
        meta_lines.append(f"[dim]Cols   [/dim] {cols_str}")

    panel_content = Text.from_markup("\n".join(meta_lines))
    console.print(Panel(panel_content, title=header, title_align="left"))

    title = data.get("title", "")
    description = data.get("description", "")
    if title:
        console.print(f"\n[bold]{title}[/bold]")
    if description and description != title:
        console.print(f"\n{description}")

    code_snippet = data.get("codeSnippet")
    if code_snippet:
        console.print("\n[bold]Code[/bold]")
        lang = _lang_from_path(file_path)
        console.print(Syntax(code_snippet, lang, theme="monokai", line_numbers=False))

    remediation = data.get("remediation", "")
    if remediation:
        console.print("\n[bold]Remediation[/bold]")
        console.print(f"  {remediation}")

    metadata = data.get("metadata")
    if metadata:
        console.print("\n[bold]Metadata[/bold]")
        console.print_json(json.dumps(metadata))


_CLAUDE_SKILL_CONTENT = """\
---
description: Check the repository or a specific file for KodeLens code quality issues
---

Check for active KodeLens code quality issues.

1. Run `kodelens issues list $ARGUMENTS` (pass e.g. `--file src/auth.py` or leave empty for all issues)
2. For any high/critical issues run `kodelens issues detail --id=<id>` to get full context: file path, line range, description, and remediation steps
3. Summarise findings and suggest fixes where appropriate

To dismiss an issue, ask the user for a reason, then run:
`kodelens issues dismiss --id=<id> --message="<reason>"`
Confirm the dismissal when prompted (y/N).
"""

_CLAUDE_MD_SECTION = """\

## Code quality (KodeLens)

Use `kodelens issues list` to check for active security and complexity issues (default: high+critical).
Use `kodelens issues list --file <path>` before modifying a file.
Use `kodelens issues detail --id=<id>` for full context on a specific issue (file, lines, remediation).
Use `kodelens issues dismiss --id=<id> --message="<reason>"` to dismiss a false positive — always ask the user to confirm the reason first.
Use `/kodelens [--file <path>]` as a slash command shortcut.
"""

_COPILOT_SECTION = """\
## Code quality (KodeLens)

This project uses KodeLens for code quality analysis.

- `kodelens issues list` — list active issues (default: high+critical severity)
- `kodelens issues list --file <path>` — check a specific file before editing it
- `kodelens issues detail --id=<id>` — full context: file, line range, and remediation
- `kodelens issues dismiss --id=<id> --message="<reason>"` — dismiss a false positive with a reason

Run `kodelens issues list --file <path>` before modifying any file to check for pre-existing issues.
"""


def _configure_claude_code() -> None:
    commands_dir = Path(".claude") / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)
    skill_file = commands_dir / "kodelens.md"
    if skill_file.exists():
        console.print(f"[dim]Already configured: {skill_file}[/dim]")
    else:
        skill_file.write_text(_CLAUDE_SKILL_CONTENT)
        console.print(f"[green]Created[/green] {skill_file}")

    claude_md = Path("CLAUDE.md")
    existing = claude_md.read_text() if claude_md.exists() else ""
    if "KodeLens" in existing:
        console.print(f"[dim]Already configured: CLAUDE.md[/dim]")
    else:
        with claude_md.open("a") as f:
            f.write(_CLAUDE_MD_SECTION)
        action = "Updated" if existing else "Created"
        console.print(f"[green]{action}[/green] CLAUDE.md")


def _configure_github_copilot() -> None:
    github_dir = Path(".github")
    github_dir.mkdir(parents=True, exist_ok=True)
    instructions_file = github_dir / "copilot-instructions.md"
    existing = instructions_file.read_text() if instructions_file.exists() else ""
    if "KodeLens" in existing:
        console.print(f"[dim]Already configured: {instructions_file}[/dim]")
    else:
        with instructions_file.open("a") as f:
            if existing and not existing.endswith("\n"):
                f.write("\n")
            f.write(_COPILOT_SECTION)
        action = "Updated" if existing else "Created"
        console.print(f"[green]{action}[/green] {instructions_file}")


@cli.command()
@click.option(
    "--claude-code", is_flag=True, help="Set up Claude Code skill and CLAUDE.md."
)
@click.option(
    "--github-copilot", is_flag=True, help="Set up GitHub Copilot instructions."
)
def configure(claude_code, github_copilot):
    """Write AI tool integration files for the current project."""
    if not claude_code and not github_copilot:
        raise click.UsageError(
            "Specify at least one tool: --claude-code or --github-copilot"
        )

    if claude_code:
        _configure_claude_code()

    if github_copilot:
        _configure_github_copilot()
