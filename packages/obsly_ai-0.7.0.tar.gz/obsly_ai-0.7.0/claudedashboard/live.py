#!/usr/bin/env python3
"""
Claude Code Real-Time Token Dashboard
SSE server that streams live updates from ~/.claude/projects/**/*.jsonl

Usage:
    python3 claude_token_live.py          # opens browser on http://localhost:8765
    python3 claude_token_live.py --port 9000 --no-browser
"""

import json
import os
import glob
import sys
import time
import argparse
import threading
import queue
import subprocess
import webbrowser
import sqlite3
from collections import defaultdict, OrderedDict
from datetime import datetime, timezone, timedelta
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse
from urllib.request import urlopen, Request

from claudedashboard import codex_estimate, usage_pusher

# ─── Config ──────────────────────────────────────────────────────────────────

CLAUDE_DIR    = os.path.expanduser("~/.claude/projects")
POLL_INTERVAL = 0.4   # seconds between file-system scans
HISTORY_CALLS = 60    # recent calls to keep in memory
BUCKET_WINDOW = 30    # minutes to keep in the chart window
WEEK_CYCLES   = 9     # cycles to look back for budget reference


_MODEL_PRICE = {
    "claude-opus-4":   {"inp": 15.0,  "ccr": 18.75, "crd": 1.50,  "out": 75.0},
    "claude-sonnet-4": {"inp":  3.0,  "ccr":  3.75, "crd": 0.30,  "out": 15.0},
    "claude-haiku-4":  {"inp":  0.80, "ccr":  1.00, "crd": 0.08,  "out":  4.0},
    "claude-sonnet-3": {"inp":  3.0,  "ccr":  3.75, "crd": 0.30,  "out": 15.0},
    "claude-haiku-3":  {"inp":  0.25, "ccr":  0.30, "crd": 0.03,  "out":  1.25},
}
_DEFAULT_PRICE = {"inp": 3.0, "ccr": 3.75, "crd": 0.30, "out": 15.0}

def _model_price(model):
    for prefix, p in _MODEL_PRICE.items():
        if model.startswith(prefix):
            return p
    return _DEFAULT_PRICE

def _cost(inp, ccr, crd, out, model=""):
    """USD cost based on per-model pricing (prices per million tokens)."""
    p = _model_price(model)
    return (inp * p["inp"] + ccr * p["ccr"] + crd * p["crd"] + out * p["out"]) / 1_000_000


def _local_tz_hours():
    now_local = datetime.now().astimezone()
    offset = now_local.utcoffset() or timedelta(0)
    return int(offset.total_seconds() // 3600)


def _cycle_start_utc():
    """UTC datetime of the most recent Friday 9:00 AM local time (= 7:00 UTC in CEST)."""
    tz_h = _local_tz_hours()
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    days_since_fri = (now_utc.weekday() - 4) % 7
    return (now_utc - timedelta(days=days_since_fri)).replace(
        hour=9 - tz_h, minute=0, second=0, microsecond=0
    )

# ─── Anthropic utilization API ───────────────────────────────────────────────

ANTHROPIC_USAGE_URL  = "https://api.anthropic.com/api/oauth/usage"
ANTHROPIC_BETA_HDR   = "oauth-2025-04-20"
UTILIZATION_INTERVAL = 300  # seconds between API polls (5 min to avoid rate limits)
NOTIFY_WEEKLY_AT     = [75, 90]  # % thresholds for macOS notifications
NOTIFY_5H_AT         = 80        # 5h window threshold (rate limit risk)
_notified            = set()     # tracks which thresholds already fired this cycle

API_CACHE_FILE = os.path.expanduser("~/.claude/.dashboard_api_cache.json")
API_HISTORY_FILE = os.path.expanduser("~/.claude/.dashboard_api_history.jsonl")
CODEX_LOG_DB = os.path.expanduser("~/.codex/logs_1.sqlite")
CODEX_LOG_WAL = CODEX_LOG_DB + "-wal"
CODEX_SESSIONS_DIR = os.path.expanduser("~/.codex/sessions")

def _save_api_cache(snap: dict, path: str = API_CACHE_FILE):
    """Persist the latest Anthropic API response to disk."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(snap, f)
    except Exception:
        pass

def _load_api_cache(path: str = API_CACHE_FILE) -> dict | None:
    """Load the cached Anthropic API response from disk."""
    try:
        with open(path, "r") as f:
            return json.loads(f.read())
    except Exception:
        return None

def _append_api_history(snap: dict, path: str = API_HISTORY_FILE):
    """Append an API reading to the persistent history log (one JSON per line)."""
    try:
        record = {
            "ts": snap.get("fetched_at") or datetime.now(timezone.utc).isoformat(),
            "seven_day_pct": snap.get("seven_day_pct"),
            "sonnet_pct": snap.get("sonnet_pct"),
            "five_hour_pct": snap.get("five_hour_pct"),
            "seven_day_resets": snap.get("seven_day_resets"),
        }
        with open(path, "a") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass

def _load_api_history(path: str = API_HISTORY_FILE) -> list:
    """Load all historical API readings."""
    records = []
    try:
        with open(path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
    except Exception:
        pass
    return records

def _compute_today_used(history, latest_pct, today_9am_utc, cycle_start):
    """% consumed since today's 9am boundary, accounting for weekly resets.

    If a weekly cycle reset happened TODAY after the 9am boundary, readings
    taken before the reset belong to the previous cycle and must be ignored —
    otherwise the delta is huge and negative (bug #14).

    history: list of dicts with 'ts' (ISO) and 'seven_day_pct'.
    latest_pct: current cycle % (most recent reading).
    today_9am_utc: naive UTC datetime for today's 9am-local boundary.
    cycle_start: naive UTC datetime for current weekly cycle start, or None.

    Returns rounded float (>= 0 in normal flow).
    """
    baseline = today_9am_utc
    if cycle_start is not None and cycle_start > baseline:
        baseline = cycle_start

    today_pct = None
    for h in history:
        ts_str = h.get("ts", "")
        p = h.get("seven_day_pct")
        if not ts_str or p is None:
            continue
        try:
            dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).replace(tzinfo=None)
        except Exception:
            continue
        if dt > baseline:
            continue
        # Skip readings that belong to the previous cycle
        if cycle_start is not None and dt < cycle_start:
            continue
        today_pct = p

    if today_pct is None:
        today_pct = 0.0
    return round(latest_pct - today_pct, 1)

def _get_oauth_token() -> str | None:
    """Read the Claude Code OAuth access token from the macOS keychain."""
    try:
        raw = subprocess.check_output(
            ["security", "find-generic-password", "-s", "Claude Code-credentials", "-w"],
            stderr=subprocess.DEVNULL
        ).decode().strip()
        data = json.loads(raw)
        return data.get("claudeAiOauth", {}).get("accessToken")
    except Exception:
        return None

def _macos_notify(title: str, body: str):
    script = f'display notification "{body}" with title "{title}" sound name "Basso"'
    subprocess.run(["osascript", "-e", script], capture_output=True)

def _reset_label(resets_at: str | None) -> str:
    if not resets_at:
        return ""
    try:
        dt = datetime.fromisoformat(resets_at).astimezone()
        return f" Resets {dt.strftime('%a %b %-d at %-I:%M %p')}."
    except Exception:
        return ""

def _check_notifications(seven_pct, five_pct, resets_at, fh_resets_at):
    global _notified
    # New cycle started — reset notification state
    if seven_pct is not None and seven_pct < 40:
        _notified = set()
        return
    # Weekly thresholds
    for threshold in NOTIFY_WEEKLY_AT:
        key = f"7d_{threshold}"
        if seven_pct is not None and seven_pct >= threshold and key not in _notified:
            rl = _reset_label(resets_at)
            if threshold >= 90:
                _macos_notify("🔴 Claude Max — Critical", f"Weekly budget at {seven_pct:.0f}%.{rl} Slow down!")
            else:
                _macos_notify("🟡 Claude Max — Warning", f"Weekly budget at {seven_pct:.0f}%.{rl}")
            _notified.add(key)
    # 5h window (rate limit risk)
    key_fh = "5h_warn"
    if five_pct is not None and five_pct >= NOTIFY_5H_AT and key_fh not in _notified:
        rl = _reset_label(fh_resets_at)
        _macos_notify("⚠️ Claude Max — Rate Limit Risk", f"5h window at {five_pct:.0f}%.{rl} You may get throttled.")
        _notified.add(key_fh)
    elif five_pct is not None and five_pct < 50:
        _notified.discard(key_fh)

_last_api_error = ""  # "no_token", "429", or other error string

def _fetch_anthropic_utilization() -> dict | None:
    """Call /api/oauth/usage and return the parsed JSON, or None on failure."""
    global _last_api_error
    token = _get_oauth_token()
    if not token:
        _last_api_error = "no_token"
        return None
    try:
        req = Request(
            ANTHROPIC_USAGE_URL,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "User-Agent": "claude-code/2.1.87",
                "anthropic-beta": ANTHROPIC_BETA_HDR,
            },
        )
        with urlopen(req, timeout=8) as resp:
            _last_api_error = ""
            return json.loads(resp.read())
    except Exception as e:
        _last_api_error = "429" if "429" in str(e) else str(e)[:80]
        return None

def _utilization_loop():
    """Background thread: poll Anthropic every UTILIZATION_INTERVAL seconds.
    Uses disk cache to avoid hammering the API on restarts."""
    # On startup, always load cache so dashboard has data immediately
    cached = _load_api_cache()
    if cached and cached.get("fetched_at"):
        try:
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(cached["fetched_at"])).total_seconds()
        except Exception:
            age = 9999
        snap = dict(cached)
        snap["from_cache"] = True
        with _lock:
            _state["anthropic"] = snap
        if snap.get("seven_day_pct") is not None:
            _anthropic_readings.append({"t": time.time(), "pct": snap["seven_day_pct"]})
        _broadcast("anthropic", snap)
        # If cache is fresh, wait before first API call
        if age < UTILIZATION_INTERVAL:
            time.sleep(max(0, UTILIZATION_INTERVAL - age))

    consecutive_failures = 0
    MAX_BACKOFF = 600  # 10 minutes cap

    while True:
        data = _fetch_anthropic_utilization()
        if data:
            consecutive_failures = 0
            seven_day = data.get("seven_day") or {}
            sonnet    = data.get("seven_day_sonnet") or {}
            five_hour = data.get("five_hour") or {}
            snap = {
                "seven_day_pct":     seven_day.get("utilization"),
                "seven_day_resets":  seven_day.get("resets_at"),
                "sonnet_pct":        sonnet.get("utilization"),
                "sonnet_resets":     sonnet.get("resets_at"),
                "five_hour_pct":     five_hour.get("utilization"),
                "five_hour_resets":  five_hour.get("resets_at"),
                "fetched_at":        datetime.now(timezone.utc).isoformat(),
            }
            with _lock:
                _state["anthropic"] = snap
            # Save scale factor: ratio between Anthropic's real % and our local USD %
            local_pct = _state["week"].get("pct", 0)
            if local_pct > 0 and snap["seven_day_pct"] is not None and snap["seven_day_pct"] > 0:
                snap["_scale_factor"] = snap["seven_day_pct"] / local_pct
            snap["_raw"] = data
            _save_api_cache(snap)
            _append_api_history(snap)
            # Track readings for burn rate
            if snap["seven_day_pct"] is not None:
                _anthropic_readings.append({
                    "t": time.time(),
                    "pct": snap["seven_day_pct"],
                })
            _check_notifications(
                snap["seven_day_pct"], snap["five_hour_pct"],
                snap["seven_day_resets"], snap["five_hour_resets"],
            )
            _broadcast("anthropic", snap)
            time.sleep(UTILIZATION_INTERVAL)
        else:
            consecutive_failures += 1
            # If we have no real Anthropic data, try local estimation
            with _lock:
                has_real = _state["anthropic"].get("fetched_at") is not None
                if not has_real:
                    local_pct = _state["week"].get("pct", 0)
                    if local_pct > 0:
                        cached = _load_api_cache()
                        scale = (cached or {}).get("_scale_factor", 1.0)
                        estimated_pct = round(local_pct * scale, 1)
                        _state["anthropic"] = {
                            "seven_day_pct": estimated_pct,
                            "seven_day_resets": None,
                            "sonnet_pct": None, "sonnet_resets": None,
                            "five_hour_pct": None, "five_hour_resets": None,
                            "fetched_at": None,
                            "estimated": True,
                        }
                        _broadcast("anthropic", _state["anthropic"])
            wait = min(UTILIZATION_INTERVAL * (2 ** consecutive_failures), MAX_BACKOFF)
            if _last_api_error == "429":
                print(f"Anthropic API rate limited (attempt {consecutive_failures}), "
                      f"backing off {wait}s", file=sys.stderr)
            elif _last_api_error == "no_token":
                print(f"No OAuth token found. Run Claude Code at least once to create it. "
                      f"Retrying in {wait}s", file=sys.stderr)
            else:
                print(f"Anthropic API error: {_last_api_error} (attempt {consecutive_failures}), "
                      f"retrying in {wait}s", file=sys.stderr)
            time.sleep(wait)

# ─── Shared state (protected by lock) ────────────────────────────────────────

_cur_cycle_start    = None   # set during seed; used for projected %
_month_api_cost     = 0.0   # last 4 completed weeks + current week
_subscription_plan  = None  # "5x" or "20x", set via --plan flag
_week_project_effs  = defaultdict(float)  # project -> eff tokens this cycle
_week_hours_cur     = defaultdict(float)  # hour_idx (0-167) -> eff tokens this cycle
_week_hours_prev    = defaultdict(float)  # hour_idx (0-167) -> eff tokens prev cycle

# Per-session cost tracking for the "bank statement"
# key = session_id (filename uuid), value = {cost, project, title, model, calls, first_ts, last_ts}
_week_session_costs = defaultdict(lambda: {
    "cost": 0.0, "project": "", "title": "", "models": defaultdict(float),
    "calls": 0, "first_ts": "", "last_ts": "", "output_tokens": 0,
})

# Burn rate: store Anthropic % readings with timestamps
from collections import deque
_anthropic_readings = deque(maxlen=360)  # up to 6 hours at 1/min
# Seed from persistent history so burn rate works immediately after restart
for _h in _load_api_history()[-360:]:
    if _h.get("seven_day_pct") is not None and _h.get("ts"):
        try:
            _t = datetime.fromisoformat(_h["ts"].replace("Z", "+00:00")).timestamp()
            _anthropic_readings.append({"t": _t, "pct": _h["seven_day_pct"]})
        except Exception:
            pass

_session_titles = {}   # session_id (uuid) → title string
_codex_usage_cache = {
    "stamp": None,
    "data": None,
}

def _clean_first_message(obj):
    """Extract a clean description from a user message object."""
    msg = obj.get("message", {})
    content = msg.get("content", "")
    text = ""
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                text = part["text"]
                break
            elif isinstance(part, str):
                text = part
                break
    if not text:
        return None
    # Skip system/caveat lines
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        if line.startswith("<"):  # skip XML tags like <local-command-caveat>
            continue
        if line.startswith("#"):  # markdown header — use it
            line = line.lstrip("# ").strip()
        # Clean paths
        line = line.replace(os.path.expanduser("~"), "~")
        return line[:80]
    return None

def _extract_session_title(fpath):
    """Read the session title from a JSONL file.
    Priority: custom-title > ai-title > first user message (truncated).
    Scans full file since titles may be anywhere."""
    try:
        custom = None
        ai = None
        first_user_msg = None
        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                t = obj.get("type")
                if t == "custom-title":
                    custom = obj.get("customTitle")
                elif t == "ai-title":
                    ai = obj.get("aiTitle")
                elif t == "user" and first_user_msg is None:
                    first_user_msg = _clean_first_message(obj)
        return custom or ai or first_user_msg
    except Exception:
        return None

_lock       = threading.Lock()
_state      = {
    "today":          {"input": 0, "cache_cr": 0, "cache_cr_5m": 0, "cache_cr_1h": 0,
                       "cache_rd": 0, "output": 0, "total": 0, "calls": 0},
    "session":        {"input": 0, "cache_cr": 0, "cache_cr_5m": 0, "cache_cr_1h": 0,
                       "cache_rd": 0, "output": 0, "total": 0, "calls": 0,
                       "project": "", "session_id": "", "last_ts": ""},
    "week":           {"eff": 0.0, "budget": 1.0, "pct": 0.0, "days_elapsed": 0,
                       "seconds_elapsed": 0, "top_projects": []},
    "anthropic":      {"seven_day_pct": None, "seven_day_resets": None,
                       "sonnet_pct": None, "sonnet_resets": None,
                       "five_hour_pct": None, "five_hour_resets": None,
                       "fetched_at": None},
    "recent_calls":   [],
    "minute_buckets": OrderedDict(),  # "HH:MM" → {total, cache_rd, input, output, calls}
    "started_at":     datetime.now(timezone.utc).isoformat(),
}
_subscribers = []
_file_state  = {}
_seen_usage_keys = set()

# ─── Helpers ─────────────────────────────────────────────────────────────────

def _now_day():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def _project_name(project_raw):
    name = project_raw
    for prefix in [f"-Users-{os.getenv('USER', 'user')}-", "-Users-xavi-1-"]:
        name = name.replace(prefix, "")
    if name == project_raw:
        name = project_raw.lstrip("-").replace("-Users-", "")
    return name or project_raw

def _broadcast(event_name: str, data: dict):
    msg = f"event: {event_name}\ndata: {json.dumps(data)}\n\n"
    dead = []
    for q in _subscribers:
        try:
            q.put_nowait(msg)
        except queue.Full:
            dead.append(q)
    for q in dead:
        try:
            _subscribers.remove(q)
        except ValueError:
            pass

def _add_to_minute_bucket(rec, buckets):
    """Add a record to the rolling minute-bucket chart data."""
    ts = rec.get("timestamp", "")
    if not ts:
        return
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        key = dt.strftime("%H:%M")
    except Exception:
        return
    if key not in buckets:
        buckets[key] = {"total": 0, "cache_rd": 0, "input": 0, "output": 0, "cache_cr": 0, "calls": 0}
    b = buckets[key]
    b["total"]    += rec["total"]
    b["cache_rd"] += rec["cache_rd"]
    b["input"]    += rec["input"]
    b["output"]   += rec["output"]
    b["cache_cr"] += rec["cache_cr"]
    b["calls"]    += 1
    # Trim to BUCKET_WINDOW most-recent keys
    while len(buckets) > BUCKET_WINDOW:
        buckets.popitem(last=False)

# ─── File watcher ─────────────────────────────────────────────────────────────

def _parse_record(obj, project, session_id):
    msg   = obj.get("message", {})
    usage = msg.get("usage", {})
    if not usage:
        return None
    inp  = usage.get("input_tokens", 0) or 0
    ccr  = usage.get("cache_creation_input_tokens", 0) or 0
    crd  = usage.get("cache_read_input_tokens", 0) or 0
    out  = usage.get("output_tokens", 0) or 0
    tot  = inp + ccr + crd + out
    if tot == 0:
        return None
    cache_creation = usage.get("cache_creation", {}) or {}
    ccr_5m = cache_creation.get("ephemeral_5m_input_tokens", 0) or 0
    ccr_1h = cache_creation.get("ephemeral_1h_input_tokens", 0) or 0
    dedup_id = obj.get("requestId") or msg.get("id") or obj.get("uuid")
    return {
        "dedup_id":    dedup_id,
        "input":      inp,
        "cache_cr":   ccr,
        "cache_cr_5m": ccr_5m,
        "cache_cr_1h": ccr_1h,
        "cache_rd":   crd,
        "output":     out,
        "total":      tot,
        "timestamp":  obj.get("timestamp", ""),
        "model":      msg.get("model", "?"),
        "service_tier": usage.get("service_tier"),
        "project":    project,
        "session_id": session_id,
    }

def _ingest_new_bytes(fpath, project, session_id):
    st = _file_state.get(fpath)
    try:
        file_size = os.path.getsize(fpath)
    except OSError:
        return []

    start_pos = st["size"] if st else 0
    if file_size <= start_pos:
        _file_state[fpath] = {"size": file_size, "project": project, "session_id": session_id}
        return []

    records = []
    try:
        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
            f.seek(start_pos)
            for raw in f:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                rec = _parse_record(obj, project, session_id)
                if rec:
                    records.append(rec)
    except OSError:
        pass

    _file_state[fpath] = {"size": file_size, "project": project, "session_id": session_id}
    return records

def _record_key(fpath, rec):
    ident = rec.get("dedup_id") or f"{rec.get('timestamp', '')}:{rec.get('total', 0)}"
    return f"{fpath}::{ident}"

def _watcher_loop():
    today = _now_day()

    # ── Seed: load ALL existing records ──────────────────────────────────────
    print("Seeding today's totals from existing logs…", file=sys.stderr)

    # Pre-compute cycle boundaries for weekly budget
    now_utc      = datetime.now(timezone.utc).replace(tzinfo=None)
    cur_cycle    = _cycle_start_utc()
    cycle_starts = [cur_cycle - timedelta(weeks=i) for i in range(WEEK_CYCLES)]
    week_effs    = defaultdict(float)  # cycle_index -> effective tokens

    files = glob.glob(os.path.join(CLAUDE_DIR, "**/*.jsonl"), recursive=True)
    for fpath in files:
        rel   = os.path.relpath(fpath, CLAUDE_DIR)
        parts = rel.split(os.sep)
        proj_raw   = parts[0] if parts else "unknown"
        session_id = parts[1] if len(parts) > 1 else "unknown"
        session_id_clean = session_id.replace(".jsonl", "")
        project    = _project_name(proj_raw)

        try:
            with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                for raw in f:
                    raw = raw.strip()
                    if not raw:
                        continue
                    try:
                        obj = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    # Extract titles by checking parsed type (not string matching)
                    obj_type = obj.get("type")
                    if obj_type == "custom-title":
                        _session_titles[session_id_clean] = obj.get("customTitle") or _session_titles.get(session_id_clean, "")
                        continue
                    if obj_type == "ai-title":
                        if session_id_clean not in _session_titles or not _session_titles[session_id_clean]:
                            _session_titles[session_id_clean] = obj.get("aiTitle", "")
                        continue
                    # Fallback: first user message as description
                    if obj_type == "user" and session_id_clean not in _session_titles:
                        desc = _clean_first_message(obj)
                        if desc:
                            _session_titles[session_id_clean] = desc
                    rec = _parse_record(obj, project, session_id)
                    if not rec:
                        continue
                    key = _record_key(fpath, rec)
                    if key in _seen_usage_keys:
                        continue
                    _seen_usage_keys.add(key)
                    ts_day = rec["timestamp"][:10] if rec["timestamp"] else ""
                    with _lock:
                        if ts_day == today:
                            for k in ("input", "cache_cr", "cache_cr_5m", "cache_cr_1h", "cache_rd", "output", "total"):
                                _state["today"][k] += rec[k]
                            _state["today"]["calls"] += 1
                            _add_to_minute_bucket(rec, _state["minute_buckets"])

                    # Weekly budget tracking
                    if rec["timestamp"]:
                        try:
                            rec_dt = datetime.fromisoformat(
                                rec["timestamp"].replace("Z", "+00:00")
                            ).replace(tzinfo=None)
                            for i, cs in enumerate(cycle_starts):
                                if cs <= rec_dt < cs + timedelta(weeks=1):
                                    e = _cost(rec["input"], rec["cache_cr"],
                                              rec["cache_rd"], rec["output"], rec["model"])
                                    week_effs[i] += e
                                    h_idx = int((rec_dt - cs).total_seconds() // 3600)
                                    h_idx = min(max(h_idx, 0), 167)
                                    if i == 0:
                                        _week_project_effs[rec["project"]] += e
                                        _week_hours_cur[h_idx] += e
                                        # Per-session cost tracking
                                        sc = _week_session_costs[session_id_clean]
                                        sc["cost"] += e
                                        sc["project"] = rec["project"]
                                        sc["models"][rec["model"]] += e
                                        sc["calls"] += 1
                                        sc["output_tokens"] += rec["output"]
                                        ts = rec["timestamp"]
                                        if not sc["first_ts"] or ts < sc["first_ts"]:
                                            sc["first_ts"] = ts
                                        if ts > sc["last_ts"]:
                                            sc["last_ts"] = ts
                                    elif i == 1:
                                        _week_hours_prev[h_idx] += e
                                    break
                        except Exception:
                            pass

            _file_state[fpath] = {
                "size":       os.path.getsize(fpath),
                "project":    project,
                "session_id": session_id,
            }
        except OSError:
            pass

    # Budget = most recent completed cycle (reflects current Claude Max limits)
    past_effs    = [week_effs[i] for i in range(1, WEEK_CYCLES) if week_effs[i] > 0]
    budget       = past_effs[0] if past_effs else 1.0
    current_eff  = week_effs[0]
    secs_elapsed = int((now_utc - cur_cycle).total_seconds())
    days_elapsed = secs_elapsed // 86400
    top_proj     = sorted(_week_project_effs.items(), key=lambda x: -x[1])[:5]
    global _cur_cycle_start, _month_api_cost
    _cur_cycle_start = cur_cycle
    _month_api_cost = current_eff + sum(past_effs[:4])
    with _lock:
        _state["week"] = {
            "eff":             current_eff,
            "budget":          budget,
            "pct":             round(current_eff / budget * 100, 1),
            "days_elapsed":    min(days_elapsed, 6),
            "seconds_elapsed": secs_elapsed,
            "top_projects":    [[p, round(e)] for p, e in top_proj],
        }

    # If Anthropic API hasn't responded yet, push local estimation
    with _lock:
        has_real = _state["anthropic"].get("fetched_at") is not None
        local_pct = _state["week"].get("pct", 0)
        if not has_real and local_pct > 0:
            # Use cached scale factor if available to improve accuracy
            cached = _load_api_cache()
            scale = (cached or {}).get("_scale_factor", 1.0)
            estimated_pct = round(local_pct * scale, 1)
            _state["anthropic"] = {
                "seven_day_pct": estimated_pct,
                "seven_day_resets": None,
                "sonnet_pct": None, "sonnet_resets": None,
                "five_hour_pct": None, "five_hour_resets": None,
                "fetched_at": None,
                "estimated": True,
            }
            _broadcast("anthropic", _state["anthropic"])

    print("Seed complete. Watching for new activity…", file=sys.stderr)

    # ── Main watch loop ───────────────────────────────────────────────────────
    while True:
        time.sleep(POLL_INTERVAL)
        current_today = _now_day()
        # Refresh cycle start in case day rolled over into a new week
        cur_cycle = _cycle_start_utc()

        if current_today != today:
            today = current_today
            with _lock:
                _state["today"] = {"input": 0, "cache_cr": 0, "cache_rd": 0,
                                    "cache_cr_5m": 0, "cache_cr_1h": 0,
                                    "output": 0, "total": 0, "calls": 0}
                _state["minute_buckets"] = OrderedDict()

        files = glob.glob(os.path.join(CLAUDE_DIR, "**/*.jsonl"), recursive=True)

        latest_mtime = 0
        latest_fpath = None
        for fpath in files:
            try:
                mt = os.path.getmtime(fpath)
                if mt > latest_mtime:
                    latest_mtime = mt
                    latest_fpath = fpath
            except OSError:
                pass

        new_records = []
        for fpath in files:
            rel   = os.path.relpath(fpath, CLAUDE_DIR)
            parts = rel.split(os.sep)
            proj_raw   = parts[0] if parts else "unknown"
            session_id = parts[1] if len(parts) > 1 else "unknown"
            project    = _project_name(proj_raw)
            recs = _ingest_new_bytes(fpath, project, session_id)
            if recs:
                new_records.extend((r, fpath) for r in recs)

        if not new_records:
            continue

        active_sessions   = set(fpath for _, fpath in new_records)
        active_session_id = ""
        active_project    = ""
        if latest_fpath and latest_fpath in active_sessions:
            st = _file_state.get(latest_fpath, {})
            active_session_id = st.get("session_id", "")
            active_project    = st.get("project", "")

        with _lock:
            cur_sess_id = _state["session"]["session_id"]
            if active_session_id and active_session_id != cur_sess_id:
                _state["session"] = {
                    "input": 0, "cache_cr": 0, "cache_cr_5m": 0, "cache_cr_1h": 0, "cache_rd": 0,
                    "output": 0, "total": 0, "calls": 0,
                    "project": active_project,
                    "session_id": active_session_id,
                    "last_ts": "",
                }

            for rec, fpath in new_records:
                key = _record_key(fpath, rec)
                if key in _seen_usage_keys:
                    continue
                _seen_usage_keys.add(key)
                ts_day = rec["timestamp"][:10] if rec["timestamp"] else ""

                if ts_day == current_today:
                    for k in ("input", "cache_cr", "cache_cr_5m", "cache_cr_1h", "cache_rd", "output", "total"):
                        _state["today"][k] += rec[k]
                    _state["today"]["calls"] += 1
                    _add_to_minute_bucket(rec, _state["minute_buckets"])

                if rec["session_id"] == (_state["session"]["session_id"] or rec["session_id"]):
                    for k in ("input", "cache_cr", "cache_cr_5m", "cache_cr_1h", "cache_rd", "output", "total"):
                        _state["session"][k] += rec[k]
                    _state["session"]["calls"] += 1
                    _state["session"]["last_ts"] = rec["timestamp"]
                    if not _state["session"]["project"]:
                        _state["session"]["project"] = rec["project"]

                # Weekly budget: accumulate effective tokens in current cycle
                if rec["timestamp"]:
                    try:
                        rec_dt = datetime.fromisoformat(
                            rec["timestamp"].replace("Z", "+00:00")
                        ).replace(tzinfo=None)
                        if cur_cycle <= rec_dt < cur_cycle + timedelta(weeks=1):
                            e = _cost(rec["input"], rec["cache_cr"],
                                      rec["cache_rd"], rec["output"], rec["model"])
                            _state["week"]["eff"] += e
                            _week_project_effs[rec["project"]] += e
                            h_idx = min(int((rec_dt - cur_cycle).total_seconds() // 3600), 167)
                            _week_hours_cur[h_idx] += e
                            # Per-session cost tracking
                            sid = rec["session_id"].replace(".jsonl", "")
                            sc = _week_session_costs[sid]
                            sc["cost"] += e
                            sc["project"] = rec["project"]
                            sc["models"][rec["model"]] += e
                            sc["calls"] += 1
                            sc["output_tokens"] += rec["output"]
                            ts = rec["timestamp"]
                            if not sc["first_ts"] or ts < sc["first_ts"]:
                                sc["first_ts"] = ts
                            if ts > sc["last_ts"]:
                                sc["last_ts"] = ts
                            # Also extract title if we haven't yet
                            if sid not in _session_titles:
                                t = _extract_session_title(fpath)
                                if t:
                                    _session_titles[sid] = t
                            now_s = int((datetime.now(timezone.utc).replace(tzinfo=None) - cur_cycle).total_seconds())
                            top_proj = sorted(_week_project_effs.items(), key=lambda x: -x[1])[:5]
                            _state["week"]["pct"] = round(
                                _state["week"]["eff"] / _state["week"]["budget"] * 100, 1
                            )
                            _state["week"]["days_elapsed"] = min(
                                int((rec_dt - cur_cycle).total_seconds() // 86400), 6
                            )
                            _state["week"]["seconds_elapsed"] = now_s
                            _state["week"]["top_projects"] = [[p, round(ef, 4)] for p, ef in top_proj]
                    except Exception:
                        pass

                _state["recent_calls"].insert(0, {
                    "ts":       rec["timestamp"][:19].replace("T", " "),
                    "project":  rec["project"][:35],
                    "session":  rec["session_id"][:8],
                    "total":    rec["total"],
                    "input":    rec["input"],
                    "cache_cr": rec["cache_cr"],
                    "cache_cr_5m": rec["cache_cr_5m"],
                    "cache_cr_1h": rec["cache_cr_1h"],
                    "cache_rd": rec["cache_rd"],
                    "output":   rec["output"],
                    "model":    rec["model"],
                    "service_tier": rec["service_tier"],
                })
                if len(_state["recent_calls"]) > HISTORY_CALLS:
                    _state["recent_calls"] = _state["recent_calls"][:HISTORY_CALLS]

            snapshot = _build_snapshot()

        _broadcast("update", snapshot)


def _compute_daily_pct():
    """Compute per-day % usage from API history, using 9AM-to-9AM boundaries.
    Returns list of {day: 'YYYY-MM-DD', pct: float} for each day in current cycle."""
    history = _load_api_history()
    if not history:
        return []

    tz_off = _local_tz_hours()

    # Find readings with timestamps, sorted
    readings = []
    for r in history:
        ts = r.get("ts")
        pct = r.get("seven_day_pct")
        if ts and pct is not None:
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00")).replace(tzinfo=None)
                readings.append((dt, pct))
            except Exception:
                continue
    if not readings:
        return []
    readings.sort(key=lambda x: x[0])

    # Build 9AM boundaries (in UTC)
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    # Current day's 9AM local in UTC
    today_9am_utc = now_utc.replace(hour=max(0, 9 - tz_off), minute=0, second=0, microsecond=0)
    if today_9am_utc > now_utc:
        today_9am_utc -= timedelta(days=1)

    days = []
    # Go back up to 7 days
    for i in range(7, -1, -1):
        boundary = today_9am_utc - timedelta(days=i)
        days.append(boundary)

    # For each pair of boundaries, find the closest reading BEFORE each boundary
    def closest_before(target):
        best = None
        for dt, pct in readings:
            if dt <= target:
                best = pct
            else:
                break
        return best

    result = []
    for i in range(len(days) - 1):
        start_boundary = days[i]
        end_boundary = days[i + 1]
        pct_start = closest_before(start_boundary)
        pct_end = closest_before(end_boundary)
        if pct_start is not None and pct_end is not None:
            delta = pct_end - pct_start
            # If delta is negative, a new cycle started — skip
            if delta >= 0:
                local_day = (end_boundary + timedelta(hours=tz_off)).strftime("%Y-%m-%d")
                day_name = (end_boundary + timedelta(hours=tz_off)).strftime("%a")
                result.append({"day": local_day, "name": day_name, "pct": round(delta, 1)})

    # Add current partial day
    pct_at_today_9am = closest_before(today_9am_utc)
    pct_now = readings[-1][1] if readings else None
    if pct_at_today_9am is not None and pct_now is not None:
        delta = pct_now - pct_at_today_9am
        if delta >= 0:
            local_day = (now_utc + timedelta(hours=tz_off)).strftime("%Y-%m-%d")
            day_name = (now_utc + timedelta(hours=tz_off)).strftime("%a")
            result.append({"day": local_day, "name": day_name, "pct": round(delta, 1), "partial": True})

    return result


def _codex_sessions_stamp():
    try:
        latest_mtime = 0
        count = 0
        for root, _, files in os.walk(CODEX_SESSIONS_DIR):
            for name in files:
                if not name.endswith(".jsonl"):
                    continue
                count += 1
                path = os.path.join(root, name)
                try:
                    latest_mtime = max(latest_mtime, os.stat(path).st_mtime_ns)
                except OSError:
                    pass
        return (count, latest_mtime)
    except OSError:
        return (0, 0)


def _extract_codex_token_count(obj: dict, session_id: str) -> dict | None:
    if obj.get("type") != "event_msg":
        return None
    payload = obj.get("payload") or {}
    if payload.get("type") != "token_count":
        return None
    info = payload.get("info") or {}
    total_usage = info.get("total_token_usage") or {}
    rate_limits = payload.get("rate_limits") or {}
    primary = rate_limits.get("primary") or {}
    secondary = rate_limits.get("secondary") or {}
    timestamp = obj.get("timestamp")
    if not timestamp:
        return None
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None
    return {
        "session_id": session_id,
        "timestamp": timestamp,
        "dt": dt,
        "total_tokens": int(total_usage.get("total_tokens") or 0),
        "primary_pct": primary.get("used_percent"),
        "primary_resets_at": primary.get("resets_at"),
        "secondary_pct": secondary.get("used_percent"),
        "secondary_resets_at": secondary.get("resets_at"),
        "plan_type": rate_limits.get("plan_type"),
    }


def _build_codex_weekly_usage(records: list[dict], now_utc: datetime | None = None) -> dict:
    now_utc = (now_utc or datetime.now(timezone.utc)).replace(tzinfo=None)
    start_utc = now_utc - timedelta(hours=167)
    hourly = {}
    latest = None
    latest_session_totals = {}

    for rec in records:
        dt = rec["dt"]
        sid = rec["session_id"]
        if latest is None or dt > latest["dt"]:
            latest = rec
        prev = latest_session_totals.get(sid)
        if prev is None or dt > prev["dt"]:
            latest_session_totals[sid] = rec
        if dt < start_utc:
            continue
        hour_idx = int((dt - start_utc).total_seconds() // 3600)
        if 0 <= hour_idx < 168:
            cur = hourly.get(hour_idx)
            if cur is None or dt > cur["dt"]:
                hourly[hour_idx] = rec

    history_pts = [None] * 168
    for hour_idx, rec in hourly.items():
        history_pts[hour_idx] = rec["secondary_pct"]

    all_time_total = sum(max(0, rec.get("total_tokens") or 0) for rec in latest_session_totals.values())
    day_labels = []
    for hour in range(168):
        if hour % 24 == 0:
            label_dt = start_utc + timedelta(hours=hour)
            day_labels.append((label_dt + timedelta(hours=_local_tz_hours())).strftime("%a"))

    return {
        "total_tokens": all_time_total,
        "session_count": len(latest_session_totals),
        "plan_type": latest.get("plan_type") if latest else None,
        "seven_day_pct": latest.get("secondary_pct") if latest else None,
        "seven_day_remaining": (100 - latest["secondary_pct"]) if latest and latest.get("secondary_pct") is not None else None,
        "seven_day_resets_at": latest.get("secondary_resets_at") if latest else None,
        "five_hour_pct": latest.get("primary_pct") if latest else None,
        "five_hour_remaining": (100 - latest["primary_pct"]) if latest and latest.get("primary_pct") is not None else None,
        "five_hour_resets_at": latest.get("primary_resets_at") if latest else None,
        "day_labels": day_labels,
        "history_pts": history_pts,
        "last_event_at": latest["timestamp"] if latest else None,
    }


def _load_codex_weekly_usage() -> dict:
    return codex_estimate.load_codex_weekly_usage()


def _usage_push_loop():
    if not usage_pusher.has_device_token():
        return
    while True:
        try:
            usage_pusher.push_usage_snapshot(_build_snapshot())
        except Exception:
            pass
        time.sleep(UTILIZATION_INTERVAL)


def _build_snapshot():
    s    = _state
    week = dict(s["week"])
    if _cur_cycle_start:
        secs = int((datetime.now(timezone.utc).replace(tzinfo=None) - _cur_cycle_start).total_seconds())
        week["seconds_elapsed"] = secs
        cur_hour = min(secs // 3600, 167)
        budget   = week.get("budget", 1) or 1

        # Cumulative % curves (168 hourly points each)
        running = 0.0
        cur_pts = []
        for h in range(168):
            running += _week_hours_cur.get(h, 0)
            cur_pts.append(round(running / budget * 100, 2) if h <= cur_hour else None)

        running = 0.0
        prev_pts = []
        for h in range(168):
            running += _week_hours_prev.get(h, 0)
            prev_pts.append(round(running / budget * 100, 2))

        week["cur_pts"]  = cur_pts
        week["prev_pts"] = prev_pts

    # Build session cost breakdown (top 15, sorted by cost desc)
    # Express each session as % of Anthropic's real weekly budget.
    # We know: total_local_cost maps to anthropic_pct% of the budget.
    # So each session's share = (session_cost / total_local_cost) * anthropic_pct
    total_local_cost = sum(sc["cost"] for sc in _week_session_costs.values()) or 1
    anthropic_pct = (s["anthropic"].get("seven_day_pct") or 0) if s["anthropic"] else 0
    session_costs = []
    for sid, sc in sorted(_week_session_costs.items(), key=lambda x: -x[1]["cost"])[:15]:
        top_model = max(sc["models"], key=sc["models"].get) if sc["models"] else "?"
        share = sc["cost"] / total_local_cost
        # Clean model name: "claude-opus-4-5-20251101" → "opus"
        model_short = top_model
        for prefix in ("claude-opus", "claude-sonnet", "claude-haiku"):
            if top_model.startswith(prefix):
                model_short = prefix.replace("claude-", "").capitalize()
                break
        # Compute duration
        dur_str = ""
        if sc["first_ts"] and sc["last_ts"]:
            try:
                t0 = datetime.fromisoformat(sc["first_ts"].replace("Z", "+00:00"))
                t1 = datetime.fromisoformat(sc["last_ts"].replace("Z", "+00:00"))
                mins = (t1 - t0).total_seconds() / 60
                if mins < 1:
                    dur_str = "<1m"
                elif mins < 60:
                    dur_str = f"{int(mins)}m"
                else:
                    h, m = int(mins // 60), int(mins % 60)
                    dur_str = f"{h}h {m}m" if m else f"{h}h"
            except Exception:
                pass

        session_costs.append({
            "id":       sid[:8],
            "title":    _session_titles.get(sid, ""),
            "project":  sc["project"],
            "cost":     round(sc["cost"], 4),
            "pct":      round(share * anthropic_pct, 1) if anthropic_pct else round(share * 100, 1),
            "model":    model_short,
            "calls":    sc["calls"],
            "duration": dur_str,
            "output_tokens": sc["output_tokens"],
            "first_ts": sc["first_ts"][:16].replace("T", " ") if sc["first_ts"] else "",
            "last_ts":  sc["last_ts"][:16].replace("T", " ") if sc["last_ts"] else "",
        })

    # Burn rate — based on actual cycle average, not instant speed
    burn_rate = None
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    if _anthropic_readings and len(_anthropic_readings) >= 2:
        latest_pct = _anthropic_readings[-1]["pct"]
        # Average pace = total % used / days elapsed in cycle
        if _cur_cycle_start:
            cycle_days = max((now_utc - _cur_cycle_start).total_seconds() / 86400, 0.1)
            avg_pace = latest_pct / cycle_days
            # Sustainable = remaining % / remaining days
            cycle_end = _cur_cycle_start + timedelta(weeks=1)
            remaining_days = max((cycle_end - now_utc).total_seconds() / 86400, 0.1)
            remaining_pct = 100.0 - latest_pct
            sustainable = remaining_pct / remaining_days
            # Today's usage from API history, accounting for weekly resets
            history = _load_api_history()
            tz_off = _local_tz_hours()
            today_9am_utc = now_utc.replace(hour=max(0, 9 - tz_off), minute=0, second=0, microsecond=0)
            if today_9am_utc > now_utc:
                today_9am_utc -= timedelta(days=1)
            today_used = _compute_today_used(history, latest_pct, today_9am_utc, _cur_cycle_start)

            burn_rate = {
                "avg_pace":    round(avg_pace, 1),
                "sustainable": round(sustainable, 1),
                "today_used":  today_used,
                "total_pct":   latest_pct,
            }

    # API cost equivalent
    week_api_cost = sum(sc["cost"] for sc in _week_session_costs.values())
    month_api_cost = _month_api_cost

    # Daily usage from API history (% consumed each day, 9AM-to-9AM boundaries)
    daily_pct = _compute_daily_pct()
    codex_week = _load_codex_weekly_usage()

    return {
        "today":          dict(s["today"]),
        "session":        dict(s["session"]),
        "week":           week,
        "codex_week":     codex_week,
        "anthropic":      dict(s["anthropic"]),
        "session_costs":  session_costs,
        "burn_rate":      burn_rate,
        "week_api_cost":  round(week_api_cost, 2),
        "month_api_cost": round(month_api_cost, 2),
        "plan":           _subscription_plan,
        "daily_pct":      daily_pct,
        "recent_calls":   list(s["recent_calls"]),
        "minute_buckets": dict(s["minute_buckets"]),
        "ts":             datetime.now(timezone.utc).isoformat(),
    }

# ─── HTML ─────────────────────────────────────────────────────────────────────

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Claude Code · Live Token Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  :root {
    --bg:#0d1117; --surface:#161b22; --border:#30363d;
    --text:#e6edf3; --muted:#8b949e;
    --accent:#58a6ff; --green:#3fb950; --yellow:#d29922;
    --orange:#f0883e; --red:#f85149; --cache:#1f6feb;
  }
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;
       font-size:14px;padding:20px}
  h1{font-size:1.15rem;font-weight:600;color:var(--accent);
     display:flex;align-items:center;gap:10px;margin-bottom:14px}
  .live-dot{width:9px;height:9px;border-radius:50%;background:var(--green);
            box-shadow:0 0 6px var(--green);animation:pulse 1.5s infinite;flex-shrink:0}
  .live-dot.stale{background:var(--yellow);box-shadow:0 0 6px var(--yellow);animation:none}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
  .ts-ago{font-size:11px;color:var(--muted)}

  /* Alert */
  .alert{display:none;padding:10px 16px;border-radius:8px;margin-bottom:14px;
         border-left:4px solid;font-size:13px;line-height:1.6}
  .alert-danger {background:#2d1111;border-color:var(--red);   color:#ffa0a0}
  .alert-warning{background:#2d2208;border-color:var(--yellow);color:#ffd080}
  .alert strong{display:block;font-size:14px;margin-bottom:2px}

  /* Weekly chart — hero section */
  .week-hero{background:var(--surface);border:1px solid var(--border);border-radius:12px;
             padding:18px 20px;margin-bottom:16px}
  .week-hero-hdr{display:flex;justify-content:space-between;align-items:flex-start;
                 flex-wrap:wrap;gap:12px;margin-bottom:14px}
  .week-title{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .week-nums{display:flex;gap:24px;align-items:baseline;flex-wrap:wrap}
  .wn-block{text-align:center}
  .wn-label{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
  .wn-val{font-size:2rem;font-weight:800;letter-spacing:-1.5px;line-height:1.1}
  .wn-val span{font-size:1rem;font-weight:400;color:var(--muted)}
  .week-meta{font-size:11px;color:var(--muted);margin-top:10px;display:flex;gap:16px;flex-wrap:wrap}
  .week-meta strong{color:var(--text)}
  .week-chart-wrap{position:relative;height:200px}

  /* Small cards grid */
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));
        gap:12px;margin-bottom:14px}
  .card{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:14px}
  .card-title{font-size:10px;text-transform:uppercase;letter-spacing:.08em;
              color:var(--muted);margin-bottom:8px}
  .big-num{font-size:1.7rem;font-weight:700;letter-spacing:-1px}
  .big-num span{font-size:.9rem;color:var(--muted);margin-left:3px}
  .sub{color:var(--muted);font-size:11px;margin-top:3px}

  /* Stacked bar */
  .stacked{display:flex;height:8px;border-radius:4px;overflow:hidden;margin-top:8px}
  .stacked div{transition:flex .4s ease;min-width:0}
  .s-input{background:var(--accent)}.s-cache-cr{background:var(--yellow)}
  .s-cache-rd{background:var(--cache)}.s-output{background:var(--green)}

  /* Session bars */
  .bar-wrap{margin-top:8px}
  .bar-label{display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-bottom:2px}
  .bar-track{background:#21262d;border-radius:3px;height:6px;overflow:hidden}
  .bar-fill{height:100%;border-radius:3px;transition:width .4s ease}
  .bar-input{background:var(--accent)}.bar-crd{background:var(--cache)}.bar-out{background:var(--green)}

  /* Cache pill */
  .pill{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:600;margin-top:6px}
  .pill-red{background:#3d1a1a;color:var(--red)}
  .pill-green{background:#1a3d1a;color:var(--green)}
  .pill-yellow{background:#3d3010;color:var(--yellow)}

  /* Live 30-min chart */
  .chart-wrap{background:var(--surface);border:1px solid var(--border);border-radius:10px;
              padding:12px 14px;margin-bottom:14px}
  .chart-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
  .chart-hdr-title{font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .legend{display:flex;gap:10px;flex-wrap:wrap}
  .legend-item{display:flex;align-items:center;gap:4px;font-size:10px;color:var(--muted)}
  .dot-sm{width:7px;height:7px;border-radius:2px;flex-shrink:0}
  canvas{display:block;width:100%}

  /* Feed */
  .feed-wrap{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden}
  .feed-hdr{padding:8px 14px;border-bottom:1px solid var(--border);
            font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .feed{max-height:320px;overflow-y:auto}
  .feed-hdr-row,.feed-row{display:grid;gap:6px;padding:6px 14px;
    grid-template-columns:105px 1fr 55px 70px 60px 60px 60px 50px;font-size:11px}
  .feed-hdr-row{font-size:10px;color:var(--muted);border-bottom:1px solid var(--border)}
  .feed-row{border-bottom:1px solid #1a1f27;align-items:center;transition:background .15s}
  .feed-row:hover{background:#1c2128}
  .feed-row.new-row{animation:flash .7s}
  @keyframes flash{0%{background:#1f3044}100%{background:transparent}}
  .mono{font-family:'SF Mono','Fira Code',monospace}
  .num{text-align:right}
  .miss-cell{text-align:right;font-weight:700}
  .miss-cell.hi{color:var(--red)}.miss-cell.lo{color:var(--green)}

  /* Burn rate gauge */
  .burn-rate{display:flex;gap:20px;align-items:center;padding:10px 16px;
             background:var(--surface);border:1px solid var(--border);border-radius:10px;
             margin-bottom:14px;font-size:13px}
  .burn-rate .br-label{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
  .burn-rate .br-val{font-size:1.3rem;font-weight:700;letter-spacing:-0.5px}
  .burn-rate .br-vs{color:var(--muted);font-size:12px}
  .burn-rate .br-msg{flex:1;font-size:12px;color:var(--muted);text-align:right}

  /* Session costs table */
  .sessions-wrap{background:var(--surface);border:1px solid var(--border);border-radius:10px;
                  overflow:hidden;margin-bottom:14px}
  .sessions-hdr{padding:8px 14px;border-bottom:1px solid var(--border);
                font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .sessions{max-height:400px;overflow-y:auto}
  .sess-hdr-row,.sess-row{display:grid;gap:6px;padding:7px 14px;
    grid-template-columns:1fr 65px 60px 70px 55px 50px;font-size:12px;align-items:center}
  .sess-hdr-row{font-size:10px;color:var(--muted);border-bottom:1px solid var(--border)}
  .sess-row{border-bottom:1px solid #1a1f27;transition:background .15s}
  .sess-row:hover{background:#1c2128}
  .sess-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .sess-title .st-name{color:var(--text);font-weight:500}
  .sess-title .st-proj{color:var(--muted);font-size:10px}
  .sess-pct-bar{height:6px;border-radius:3px;background:#21262d;overflow:hidden}
  .sess-pct-fill{height:100%;border-radius:3px}

  #status{font-size:10px;color:var(--muted);margin-top:10px}
</style>
</head>
<body>

<h1>
  <span class="live-dot" id="live-dot"></span>
  Claude Code · Live Tokens
  <span class="ts-ago" id="last-update"></span>
</h1>

<!-- ALERT BANNER -->
<div class="alert" id="alert-banner"></div>

<!-- ═══ PACE ═══════════════════════════════════════════════════════════ -->
<div class="burn-rate" id="burn-rate" style="display:none">
  <div>
    <div class="br-label">Today (since 9AM)</div>
    <div class="br-val" id="br-today">—<span style="font-size:.8rem;color:var(--muted)">%</span></div>
  </div>
  <div class="br-vs">·</div>
  <div>
    <div class="br-label">Avg pace</div>
    <div class="br-val" id="br-current">—<span style="font-size:.8rem;color:var(--muted)">%/day</span></div>
  </div>
  <div class="br-vs">vs</div>
  <div>
    <div class="br-label">Sustainable</div>
    <div class="br-val" id="br-sustainable" style="color:var(--muted)">—<span style="font-size:.8rem;color:var(--muted)">%/day</span></div>
  </div>
  <div class="br-msg" id="br-msg"></div>
</div>

<!-- ═══ WEEKLY BURNDOWN — HERO ═══════════════════════════════════════════ -->
<div class="week-hero">
  <div class="week-hero-hdr">
    <div>
      <div class="week-title" id="week-source">Weekly budget (all models) · loading...</div>
      <div class="week-nums" style="margin-top:8px">
        <div class="wn-block">
          <div class="wn-label">All models</div>
          <div class="wn-val" id="week-pct" style="color:var(--orange)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">Sonnet only</div>
          <div class="wn-val" id="week-sonnet-pct" style="color:var(--muted)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">5h window</div>
          <div class="wn-val" id="week-5h-pct" style="color:var(--muted)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">Day</div>
          <div class="wn-val" id="week-day" style="color:var(--text)">—<span>/7</span></div>
        </div>
      </div>
    </div>
    <div class="week-meta" id="week-meta">
      <span>Resets <strong id="week-resets-val">—</strong></span>
      <span id="week-fetched" style="color:var(--muted)"></span>
    </div>
  </div>
  <div class="week-chart-wrap">
    <canvas id="week-chart"></canvas>
  </div>
  <div id="api-cost-bar" style="margin-top:14px;padding:12px 18px;background:#0d1117;border-radius:8px;border-left:3px solid #3fb950;font-size:13px;color:var(--muted);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
    <div>
      <span style="color:var(--text)">API cost this week:</span>
      <strong id="api-cost-val" style="color:#f0883e;font-size:1.1em;margin-left:6px">$—</strong>
      <span style="margin-left:8px;font-size:11px;color:var(--muted)">Last 30 days savings vs pay-as-you-go API:</span>
    </div>
    <div id="api-cost-savings" style="font-size:12px">
      <span id="savings-5x" style="margin-right:14px"></span>
      <span id="savings-20x"></span>
    </div>
</div>
</div>

<!-- ═══ CODEX WEEKLY TOKENS ═══════════════════════════════════════════════ -->
<div class="week-hero">
  <div class="week-hero-hdr">
    <div>
      <div class="week-title">Codex limits · from ~/.codex/sessions token_count</div>
      <div class="week-nums" style="margin-top:8px">
        <div class="wn-block">
          <div class="wn-label">7d used</div>
          <div class="wn-val" id="codex-total" style="color:var(--accent)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">7d left</div>
          <div class="wn-val" id="codex-left" style="color:var(--green)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">5h used</div>
          <div class="wn-val" id="codex-5h" style="color:var(--muted)">—<span>%</span></div>
        </div>
        <div style="font-size:1.6rem;color:var(--border);align-self:center">·</div>
        <div class="wn-block">
          <div class="wn-label">Sessions</div>
          <div class="wn-val" id="codex-sessions" style="color:var(--text)">—<span>seen</span></div>
        </div>
      </div>
    </div>
    <div class="week-meta">
      <span>7d resets <strong id="codex-week-total">—</strong></span>
      <span>5h resets <strong id="codex-prev-total">—</strong></span>
      <span>Plan <strong id="codex-remaining">—</strong></span>
      <span id="codex-last-event" style="color:var(--muted)"></span>
    </div>
  </div>
  <div class="week-chart-wrap">
    <canvas id="codex-chart"></canvas>
  </div>
</div>

<!-- ═══ SECONDARY CARDS ══════════════════════════════════════════════════ -->
<div class="grid">

  <!-- TODAY -->
  <div class="card">
    <div class="card-title">Today</div>
    <div class="big-num" id="today-total">—<span>tokens</span></div>
    <div class="sub" id="today-calls">—</div>
    <div class="stacked" style="margin-top:10px">
      <div class="s-input"    id="st-input"    style="flex:0"></div>
      <div class="s-cache-cr" id="st-cache-cr" style="flex:0"></div>
      <div class="s-cache-rd" id="st-cache-rd" style="flex:0"></div>
      <div class="s-output"   id="st-output"   style="flex:0"></div>
    </div>
    <div class="sub" style="margin-top:6px" id="today-cache-detail">cache —</div>
    <div style="margin-top:6px">
      <span style="font-size:10px;color:var(--muted)">Cache hit </span>
      <span id="hit-pct" style="font-size:12px;font-weight:700;color:var(--green)">—%</span>
      <span style="font-size:10px;color:var(--muted)"> miss </span>
      <span id="miss-pct" style="font-size:12px;font-weight:700;color:var(--red)">—%</span>
      <span id="miss-rating" style="margin-left:6px"></span>
    </div>
  </div>

  <!-- SESSION -->
  <div class="card">
    <div class="card-title">Current session</div>
    <div class="big-num" id="sess-total">—<span>tokens</span></div>
    <div class="sub" id="sess-calls">—</div>
    <div class="sub mono" id="sess-project" style="margin-top:3px;font-size:10px"></div>
    <div class="sub mono" id="sess-id" style="font-size:9px;color:var(--muted)"></div>
    <div class="sub" id="sess-cache-detail" style="margin-top:3px">cache —</div>
    <div class="bar-wrap">
      <div class="bar-label"><span>input</span><span id="b-input-v">—</span></div>
      <div class="bar-track"><div class="bar-fill bar-input" id="b-input" style="width:0%"></div></div>
    </div>
    <div class="bar-wrap">
      <div class="bar-label"><span>cache read</span><span id="b-crd-v">—</span></div>
      <div class="bar-track"><div class="bar-fill bar-crd" id="b-crd" style="width:0%"></div></div>
    </div>
    <div class="bar-wrap">
      <div class="bar-label"><span>output</span><span id="b-out-v">—</span></div>
      <div class="bar-track"><div class="bar-fill bar-out" id="b-out" style="width:0%"></div></div>
    </div>
  </div>

</div>

<!-- ═══ SESSION COSTS — BANK STATEMENT ══════════════════════════════════ -->
<div class="sessions-wrap">
  <div class="sessions-hdr">This week — where your budget went</div>
  <div class="sess-hdr-row">
    <span>Session</span><span class="num">Budget</span>
    <span>Duration</span><span class="num">Output</span>
    <span class="num">Calls</span><span class="num">Model</span>
  </div>
  <div class="sessions" id="session-costs"></div>
</div>

<!-- LIVE CHART: last 30 min -->
<div class="chart-wrap">
  <div class="chart-hdr">
    <span class="chart-hdr-title">Tokens/min — last 30 min</span>
    <div class="legend">
      <span class="legend-item"><span class="dot-sm" style="background:var(--accent)"></span>input</span>
      <span class="legend-item"><span class="dot-sm" style="background:var(--cache)"></span>cache read</span>
      <span class="legend-item"><span class="dot-sm" style="background:var(--green)"></span>output</span>
    </div>
  </div>
  <canvas id="chart" height="120"></canvas>
</div>

<!-- FEED -->
<div class="feed-wrap">
  <div class="feed-hdr">Live API calls</div>
  <div class="feed-hdr-row">
    <span>Time</span><span>Project</span><span class="num">Session</span>
    <span class="num">Total</span><span class="num">Input</span>
    <span class="num">Cache↓</span><span class="num">Output</span>
    <span class="num">Miss%</span>
  </div>
  <div class="feed" id="feed"></div>
</div>

<div id="status">Connecting…</div>

<script>
const fmt = n => n >= 1e6 ? (n/1e6).toFixed(2)+'M'
               : n >= 1e3 ? (n/1e3).toFixed(1)+'K'
               : String(n);
const fmtFull = n => n.toLocaleString();
const setBar  = (id, val, max) =>
  document.getElementById(id).style.width = (max>0 ? Math.min(100,val/max*100) : 0)+'%';

// ── Weekly burndown chart (Chart.js) ────────────────────────────────────────

Chart.defaults.color       = '#8b949e';
Chart.defaults.borderColor = '#21262d';
Chart.defaults.font.size   = 11;

const DAY_LABELS = ['Fri','Sat','Sun','Mon','Tue','Wed','Thu'];
// 168 hourly points; label every 24h
const xLabels = Array.from({length:168}, (_,i) => i%24===0 ? DAY_LABELS[i/24] : '');

const weekCtx = document.getElementById('week-chart').getContext('2d');
const weekChart = new Chart(weekCtx, {
  type: 'line',
  data: {
    labels: xLabels,
    datasets: [
      {
        label: 'Last week',
        data: new Array(168).fill(null),
        borderColor: 'rgba(88,166,255,0.45)',
        backgroundColor: 'rgba(88,166,255,0.04)',
        borderWidth: 1.5,
        pointRadius: 0,
        fill: false,
        tension: 0.3,
        spanGaps: true,
      },
      {
        label: 'This week ★',
        data: new Array(168).fill(null),
        borderColor: '#f0883e',
        backgroundColor: 'rgba(240,136,62,0.08)',
        borderWidth: 2.5,
        pointRadius: 0,
        pointHoverRadius: 4,
        fill: true,
        tension: 0.3,
        spanGaps: false,
      },
      {
        label: '100%',
        data: new Array(168).fill(100),
        borderColor: 'rgba(248,81,73,0.35)',
        borderWidth: 1,
        borderDash: [5,4],
        pointRadius: 0,
        fill: false,
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 300 },
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'top', labels: { boxWidth: 10, padding: 12 } },
      tooltip: {
        callbacks: {
          label: ctx => {
            if (ctx.parsed.y == null) return '';
            return `${ctx.dataset.label}: ${ctx.parsed.y.toFixed(1)}%`;
          },
          title: ctxArr => {
            const i = ctxArr[0]?.dataIndex ?? 0;
            const day = Math.floor(i/24);
            const hr  = i % 24;
            return `${DAY_LABELS[day]} +${hr}h`;
          }
        }
      }
    },
    scales: {
      x: {
        grid: { color: '#21262d' },
        ticks: {
          maxRotation: 0,
          callback: (_, i) => xLabels[i] || null,
          autoSkip: false,
        }
      },
      y: {
        min: 0,
        suggestedMax: 110,
        grid: { color: '#21262d' },
        ticks: { callback: v => v + '%', stepSize: 20 }
      }
    }
  }
});

const codexCtx = document.getElementById('codex-chart').getContext('2d');
const codexChart = new Chart(codexCtx, {
  type: 'line',
  data: {
    labels: xLabels,
    datasets: [
      {
        label: 'Codex 7d',
        data: new Array(168).fill(null),
        borderColor: '#58a6ff',
        backgroundColor: 'rgba(88,166,255,0.08)',
        borderWidth: 2.5,
        pointRadius: 0,
        pointHoverRadius: 4,
        fill: true,
        tension: 0.25,
        spanGaps: true,
      },
      {
        label: '100%',
        data: new Array(168).fill(100),
        borderColor: 'rgba(248,81,73,0.35)',
        borderWidth: 1,
        borderDash: [5,4],
        pointRadius: 0,
        fill: false,
      },
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 300 },
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'top', labels: { boxWidth: 10, padding: 12 } },
      tooltip: {
        callbacks: {
          label: ctx => {
            if (ctx.parsed.y == null) return '';
            return `${ctx.dataset.label}: ${ctx.parsed.y.toFixed(1)}%`;
          },
          title: ctxArr => {
            const i = ctxArr[0]?.dataIndex ?? 0;
            const day = Math.floor(i/24);
            const hr  = i % 24;
            return `${DAY_LABELS[day]} +${hr}h`;
          }
        }
      }
    },
    scales: {
      x: {
        grid: { color: '#21262d' },
        ticks: {
          maxRotation: 0,
          callback: (_, i) => xLabels[i] || null,
          autoSkip: false,
        }
      },
      y: {
        min: 0,
        suggestedMax: 110,
        grid: { color: '#21262d' },
        ticks: { callback: v => v + '%', stepSize: 20 }
      }
    }
  }
});

let _lastAnthropicPct = null;
let _lastWeekData     = null;

function updateWeekChart(w) {
  if (!w) return;
  _lastWeekData = w;
  const prev = w.prev_pts || [];
  let cur    = w.cur_pts  || [];

  // Scale cur_pts so the current endpoint matches Anthropic's real utilization
  if (_lastAnthropicPct != null && cur.length) {
    const lastVal = [...cur].reverse().find(v => v != null);
    if (lastVal && lastVal > 0) {
      const scale = _lastAnthropicPct / lastVal;
      cur = cur.map(v => v != null ? Math.round(v * scale * 100) / 100 : null);
    }
  }

  weekChart.data.datasets[0].data = prev.length ? prev : new Array(168).fill(null);
  weekChart.data.datasets[1].data = cur.length  ? cur  : new Array(168).fill(null);
  weekChart.update('none');
}

function updateCodexChart(cw) {
  if (!cw) return;
  codexChart.data.datasets[0].data = cw.history_pts || new Array(168).fill(null);
  codexChart.update('none');

  const weekPct = cw.seven_day_pct;
  const leftPct = cw.seven_day_remaining;
  const fivePct = cw.five_hour_pct;
  const sessions = cw.session_count || 0;

  document.getElementById('codex-total').innerHTML = weekPct != null ? weekPct.toFixed(1) + '<span>%</span>' : '—<span>%</span>';
  document.getElementById('codex-left').innerHTML = leftPct != null ? leftPct.toFixed(1) + '<span>%</span>' : '—<span>%</span>';
  document.getElementById('codex-5h').innerHTML = fivePct != null ? fivePct.toFixed(1) + '<span>%</span>' : '—<span>%</span>';
  document.getElementById('codex-sessions').innerHTML = fmtFull(sessions) + '<span>seen</span>';

  const weekResetEl = document.getElementById('codex-week-total');
  const fhResetEl = document.getElementById('codex-prev-total');
  const planEl = document.getElementById('codex-remaining');
  if (cw.seven_day_resets_at) {
    weekResetEl.textContent = new Date(cw.seven_day_resets_at * 1000).toLocaleString();
  } else {
    weekResetEl.textContent = '—';
  }
  if (cw.five_hour_resets_at) {
    fhResetEl.textContent = new Date(cw.five_hour_resets_at * 1000).toLocaleString();
  } else {
    fhResetEl.textContent = '—';
  }
  planEl.textContent = cw.plan_type || '—';

  const lastEl = document.getElementById('codex-last-event');
  if (cw.last_event_at) {
    const d = new Date(cw.last_event_at);
    lastEl.textContent = 'Last event ' + d.toLocaleString();
  } else {
    lastEl.textContent = 'No Codex usage found yet';
  }
}

// ── Live 30-min canvas chart ─────────────────────────────────────────────────

const canvas = document.getElementById('chart');
const ctx2   = canvas.getContext('2d');
let lastBuckets = {};

function resizeCanvas() {
  canvas.width  = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;
}
window.addEventListener('resize', () => { resizeCanvas(); drawLiveChart(lastBuckets); });
resizeCanvas();

function drawLiveChart(buckets) {
  lastBuckets = buckets;
  const W = canvas.width, H = canvas.height;
  ctx2.clearRect(0, 0, W, H);
  const keys = Object.keys(buckets);
  if (!keys.length) {
    ctx2.fillStyle='#8b949e'; ctx2.font='12px system-ui'; ctx2.textAlign='center';
    ctx2.fillText('Waiting for data…', W/2, H/2); return;
  }
  const last = keys[keys.length-1];
  const [lh,lm] = last.split(':').map(Number);
  const allKeys = [];
  for (let i=29;i>=0;i--) {
    let m=lm-i, h=lh;
    while(m<0){m+=60;h--;}
    if(h<0)h+=24;
    allKeys.push(`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`);
  }
  const maxVal=Math.max(...allKeys.map(k=>buckets[k]?.total||0),1);
  const pad={l:42,r:10,t:8,b:22};
  const cW=W-pad.l-pad.r, cH=H-pad.t-pad.b;
  const barW=Math.max(1,cW/allKeys.length-1.5), gap=cW/allKeys.length;
  ctx2.strokeStyle='#21262d'; ctx2.lineWidth=1;
  for(let i=0;i<=4;i++){
    const y=pad.t+cH*(1-i/4);
    ctx2.beginPath();ctx2.moveTo(pad.l,y);ctx2.lineTo(W-pad.r,y);ctx2.stroke();
    ctx2.fillStyle='#8b949e';ctx2.font='9px monospace';ctx2.textAlign='right';
    ctx2.fillText(fmt(maxVal*i/4),pad.l-3,y+3);
  }
  allKeys.forEach((k,i)=>{
    const b=buckets[k]||{input:0,cache_rd:0,output:0};
    const x=pad.l+i*gap+gap/2-barW/2;
    const layers=[{val:b.input,color:'#58a6ff'},{val:b.cache_rd,color:'#1f6feb'},{val:b.output,color:'#3fb950'}];
    let yBase=pad.t+cH;
    for(const l of layers){
      const bh=l.val/maxVal*cH; if(bh<0.5)continue;
      ctx2.fillStyle=l.color; ctx2.fillRect(x,yBase-bh,barW,bh); yBase-=bh;
    }
    if(i%5===0){ctx2.fillStyle='#8b949e';ctx2.font='9px monospace';ctx2.textAlign='center';
      ctx2.fillText(k,pad.l+i*gap+gap/2,H-5);}
  });
  const now=new Date();
  const curK=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  const ci=allKeys.indexOf(curK);
  if(ci>=0){ctx2.strokeStyle='#f0883e33';ctx2.lineWidth=gap;
    ctx2.beginPath();ctx2.moveTo(pad.l+ci*gap+gap/2,pad.t);ctx2.lineTo(pad.l+ci*gap+gap/2,pad.t+cH);ctx2.stroke();ctx2.lineWidth=1;}
}

// ── API cost equivalent ─────────────────────────────────────────────────────
function updateApiCost(weekCost, monthCost, plan) {
  if (weekCost == null) return;
  document.getElementById('api-cost-val').textContent = '$' + weekCost.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2});
  const s5x = document.getElementById('savings-5x');
  const s20x = document.getElementById('savings-20x');
  if (monthCost <= 0) return;
  const show5x = !plan || plan === '5x';
  const show20x = !plan || plan === '20x';
  const subCost = plan === '5x' ? 100 : plan === '20x' ? 200 : null;
  if (show5x && monthCost > 100) {
    s5x.innerHTML = 'vs Max 5x ($100/mo): <strong style="color:#3fb950">saving $' + (monthCost-100).toLocaleString(undefined,{maximumFractionDigits:0}) + '</strong>';
  } else if (show5x) {
    s5x.innerHTML = 'vs Max 5x ($100/mo): <span style="color:var(--muted)">API cheaper</span>';
  } else { s5x.innerHTML = ''; }
  if (show20x && monthCost > 200) {
    s20x.innerHTML = 'vs Max 20x ($200/mo): <strong style="color:#3fb950">saving $' + (monthCost-200).toLocaleString(undefined,{maximumFractionDigits:0}) + '</strong>';
  } else if (show20x) {
    s20x.innerHTML = 'vs Max 20x ($200/mo): <span style="color:var(--muted)">API cheaper</span>';
  } else { s20x.innerHTML = ''; }
}

// ── Session costs ("bank statement") ────────────────────────────────────────

function updateSessionCosts(sessions) {
  const wrap = document.getElementById('session-costs');
  if (!sessions || !sessions.length) return;
  wrap.innerHTML = '';
  for (const s of sessions) {
    const title = s.title || s.id;
    const col = s.pct > 15 ? 'var(--red)' : s.pct > 8 ? 'var(--orange)' : 'var(--accent)';
    const row = document.createElement('div');
    row.className = 'sess-row';
    const outFmt = s.output_tokens >= 1e6 ? (s.output_tokens/1e6).toFixed(1)+'M'
                 : s.output_tokens >= 1e3 ? (s.output_tokens/1e3).toFixed(1)+'K'
                 : String(s.output_tokens);
    row.innerHTML = `
      <div class="sess-title">
        <div class="st-name" title="${title}">${title}</div>
        <div class="st-proj">${s.project}</div>
      </div>
      <span class="num" style="font-weight:700;color:${col}">${s.pct.toFixed(1)}%</span>
      <span style="font-size:10px;color:var(--muted)">${s.duration || '—'}</span>
      <span class="num" style="color:var(--green)">${outFmt}</span>
      <span class="num">${s.calls}</span>
      <span class="num" style="font-size:10px;color:var(--muted)">${s.model}</span>`;
    wrap.appendChild(row);
  }
}

// ── Burn rate gauge ─────────────────────────────────────────────────────────

function updateBurnRate(br) {
  const el = document.getElementById('burn-rate');
  if (!br || br.avg_pace == null) { el.style.display = 'none'; return; }
  el.style.display = 'flex';
  const pace = br.avg_pace;
  const sus = br.sustainable;
  const danger = sus != null && pace > sus;
  const ok     = sus != null && pace <= sus;
  const col = danger ? 'var(--red)' : pace > sus * 0.8 ? 'var(--orange)' : 'var(--green)';
  // Today
  const todayEl = document.getElementById('br-today');
  if (br.today_used != null) {
    todayEl.innerHTML = `<span style="color:var(--orange)">${br.today_used}</span><span style="font-size:.8rem;color:var(--muted)">%</span>`;
  } else {
    todayEl.innerHTML = '—<span style="font-size:.8rem;color:var(--muted)">%</span>';
  }
  // Avg pace
  document.getElementById('br-current').innerHTML =
    `<span style="color:${col}">${pace.toFixed(1)}</span><span style="font-size:.8rem;color:var(--muted)">%/day</span>`;
  // Sustainable
  document.getElementById('br-sustainable').innerHTML = sus != null
    ? `${sus.toFixed(1)}<span style="font-size:.8rem;color:var(--muted)">%/day</span>` : '—';
  const msg = document.getElementById('br-msg');
  if (danger) {
    msg.innerHTML = `<span style="color:var(--red)">Over budget pace</span>`;
  } else if (ok) {
    msg.innerHTML = `<span style="color:var(--green)">On track</span>`;
  } else {
    msg.textContent = '';
  }
}

// ── Main update ──────────────────────────────────────────────────────────────

function updateAnthropic(a) {
  if (!a) return;
  const sevenPct  = a.seven_day_pct;
  const sonnetPct = a.sonnet_pct;
  const fivePct   = a.five_hour_pct;
  if (sevenPct != null) {
    _lastAnthropicPct = sevenPct;
    if (_lastWeekData) updateWeekChart(_lastWeekData);
  }
  if (sevenPct != null) {
    document.getElementById('week-pct').innerHTML = sevenPct.toFixed(1)+'<span>%</span>';
    const col = sevenPct > 80 ? 'var(--red)' : sevenPct > 50 ? 'var(--yellow)' : 'var(--orange)';
    document.getElementById('week-pct').style.color = col;
  }
  if (sonnetPct != null) {
    document.getElementById('week-sonnet-pct').innerHTML = sonnetPct.toFixed(1)+'<span>%</span>';
    const col = sonnetPct > 80 ? 'var(--red)' : sonnetPct > 50 ? 'var(--yellow)' : 'var(--muted)';
    document.getElementById('week-sonnet-pct').style.color = col;
  }
  if (fivePct != null) {
    document.getElementById('week-5h-pct').innerHTML = fivePct.toFixed(1)+'<span>%</span>';
    const col = fivePct > 80 ? 'var(--red)' : fivePct > 50 ? 'var(--yellow)' : 'var(--muted)';
    document.getElementById('week-5h-pct').style.color = col;
  }
  if (a.seven_day_resets) {
    const d = new Date(a.seven_day_resets);
    document.getElementById('week-resets-val').textContent =
      d.toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'}) +
      ' ' + d.toLocaleTimeString('en-US', {hour:'2-digit', minute:'2-digit'});
  }
  const srcEl = document.getElementById('week-source');
  const fetchedEl = document.getElementById('week-fetched');
  if (a.fetched_at) {
    const ago = Math.round((Date.now() - new Date(a.fetched_at)) / 1000);
    let label = ago < 60 ? ago+'s' : Math.round(ago/60)+'m';
    if (a.from_cache) label += ' (cached)';
    srcEl.textContent = 'Weekly budget (all models) · source: Anthropic API';
    fetchedEl.textContent = `· updated ${label} ago`;
  } else if (a.estimated) {
    srcEl.textContent = 'Weekly budget (all models) · estimated from local data';
    fetchedEl.textContent = '· API temporarily unavailable, retrying...';
  } else {
    srcEl.textContent = 'Weekly budget (all models) · loading...';
    fetchedEl.textContent = '';
  }
}

function update(data) {
  const t = data.today, s = data.session, w = data.week || {};

  // ── Weekly hero: local data for chart + day counter ──────────────────────
  const wSecs = w.seconds_elapsed || 0;
  const wDays = w.days_elapsed || 0;
  document.getElementById('week-day').innerHTML = (wDays+1)+'<span>/7</span>';

  // Anthropic real utilization (overrides local estimate)
  if (data.anthropic) updateAnthropic(data.anthropic);

  updateWeekChart(w);
  updateCodexChart(data.codex_week);
  updateSessionCosts(data.session_costs);
  updateBurnRate(data.burn_rate);
  updateApiCost(data.week_api_cost, data.month_api_cost, data.plan);

  // ── Alert banner ─────────────────────────────────────────────────────────
  const banner = document.getElementById('alert-banner');
  const recentSlice = (data.recent_calls||[]).slice(0,15);
  const projTotals  = {};
  for (const c of recentSlice)
    projTotals[c.project] = (projTotals[c.project]||0) + c.input + (c.cache_cr||0) + c.cache_rd + c.output;
  const projEntries  = Object.entries(projTotals).sort((a,b)=>b[1]-a[1]);
  const topProj0     = projEntries[0];
  const totalRecent  = recentSlice.reduce((s,c)=>s+c.total,0);
  const hotShare     = topProj0 && totalRecent>0 ? topProj0[1]/totalRecent : 0;
  const hotAlert     = hotShare > 0.7 && recentSlice.length >= 5;
  const hotStr       = hotAlert ? `<br>Hot project: <strong>${topProj0[0]}</strong> (${(hotShare*100).toFixed(0)}% of recent calls)` : '';

  const realPct   = (data.anthropic && data.anthropic.seven_day_pct != null)
    ? data.anthropic.seven_day_pct : null;
  const weekSecs  = 7 * 24 * 3600;
  // Only project if we have at least 1 hour of elapsed data
  const projected = (realPct != null && wSecs > 3600)
    ? Math.round(realPct / wSecs * weekSecs) : null;

  const br = data.burn_rate;
  const remainDays = Math.max(0.1, (weekSecs - wSecs) / 86400).toFixed(1);
  const remainPct  = realPct != null ? (100 - realPct).toFixed(0) : null;

  if (realPct != null && realPct > 85) {
    banner.className='alert alert-danger'; banner.style.display='block';
    banner.innerHTML=`<strong>Almost out of budget</strong>${remainPct}% left for ${remainDays} days. Switch to Sonnet or reduce context.`;
  } else if (br && br.avg_pace != null && br.sustainable != null && br.avg_pace > br.sustainable * 1.5 && wSecs > 7200) {
    banner.className='alert alert-danger'; banner.style.display='block';
    banner.innerHTML=`<strong>Over budget pace</strong>Averaging ${br.avg_pace.toFixed(1)}%/day, sustainable is ${br.sustainable.toFixed(1)}%/day. ${remainPct}% left for ${remainDays} days.`;
  } else if (br && br.avg_pace != null && br.sustainable != null && br.avg_pace > br.sustainable && wSecs > 7200) {
    banner.className='alert alert-warning'; banner.style.display='block';
    banner.innerHTML=`<strong>Slightly over pace</strong>${br.avg_pace.toFixed(1)}%/day vs ${br.sustainable.toFixed(1)}%/day sustainable. ${remainPct}% left for ${remainDays} days.`;
  } else if (projected != null && projected > 100) {
    banner.className='alert alert-warning'; banner.style.display='block';
    banner.innerHTML=`<strong>On pace to exceed budget</strong>${remainPct}% left for ${remainDays} days.`;
  } else {
    banner.style.display='none';
  }

  // ── Today card ───────────────────────────────────────────────────────────
  document.getElementById('today-total').innerHTML = fmt(t.total)+'<span>tokens</span>';
  document.getElementById('today-calls').textContent = fmtFull(t.calls)+' API calls today';
  document.getElementById('st-input').style.flex    = t.input;
  document.getElementById('st-cache-cr').style.flex = t.cache_cr;
  document.getElementById('st-cache-rd').style.flex = t.cache_rd;
  document.getElementById('st-output').style.flex   = t.output;
  document.getElementById('today-cache-detail').textContent =
    `cache write 5m: ${fmt(t.cache_cr_5m||0)} · 1h: ${fmt(t.cache_cr_1h||0)}`;
  const denom   = t.input + t.cache_cr + t.cache_rd;
  const hitRate = denom > 0 ? t.cache_rd/denom*100 : 0;
  document.getElementById('hit-pct').textContent  = hitRate.toFixed(1)+'%';
  document.getElementById('miss-pct').textContent = (100-hitRate).toFixed(1)+'%';
  const rating = hitRate>=60?['Excellent','pill-green']:hitRate>=30?['Moderate','pill-yellow']:['Low','pill-red'];
  document.getElementById('miss-rating').innerHTML = `<span class="pill ${rating[1]}">${rating[0]}</span>`;

  // ── Session card ─────────────────────────────────────────────────────────
  document.getElementById('sess-total').innerHTML = fmt(s.total)+'<span>tokens</span>';
  document.getElementById('sess-calls').textContent = fmtFull(s.calls)+' calls';
  document.getElementById('sess-project').textContent = s.project||'—';
  document.getElementById('sess-id').textContent = s.session_id ? s.session_id.slice(0,20)+'…' : '';
  document.getElementById('sess-cache-detail').textContent =
    `cache write 5m: ${fmt(s.cache_cr_5m||0)} · 1h: ${fmt(s.cache_cr_1h||0)}`;
  const sm = s.total||1;
  document.getElementById('b-input-v').textContent = fmt(s.input);
  document.getElementById('b-crd-v').textContent   = fmt(s.cache_rd);
  document.getElementById('b-out-v').textContent   = fmt(s.output);
  setBar('b-input',s.input,sm); setBar('b-crd',s.cache_rd,sm); setBar('b-out',s.output,sm);

  // ── Live chart ───────────────────────────────────────────────────────────
  drawLiveChart(data.minute_buckets||{});

  // ── Feed ─────────────────────────────────────────────────────────────────
  const feed = document.getElementById('feed');
  const existing = new Set(Array.from(feed.querySelectorAll('.feed-row')).map(r=>r.dataset.key));
  for (const c of data.recent_calls) {
    const key = c.ts+c.session+c.total;
    if (existing.has(key)) continue;
    const callDenom = c.input+(c.cache_cr||0)+c.cache_rd;
    const callHit   = callDenom>0 ? c.cache_rd/callDenom*100 : 0;
    const row = document.createElement('div');
    row.className='feed-row new-row'; row.dataset.key=key;
    row.innerHTML=`
      <span class="mono" style="font-size:10px">${c.ts.slice(11)}</span>
      <span title="${c.project}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.project}</span>
      <span class="mono num" style="font-size:10px">${c.session}</span>
      <span class="num" style="font-weight:600">${fmt(c.total)}</span>
      <span class="num">${fmt(c.input)}</span>
      <span class="num" style="color:var(--cache)">${fmt(c.cache_rd)}</span>
      <span class="num" style="color:var(--green)">${fmt(c.output)}</span>
      <span class="${(100-callHit)>70?'miss-cell hi':'miss-cell lo'}">${(100-callHit).toFixed(0)}%</span>`;
    feed.insertBefore(row, feed.firstChild);
  }
  while(feed.children.length>60) feed.removeChild(feed.lastChild);

  // ── Header ───────────────────────────────────────────────────────────────
  document.getElementById('live-dot').className='live-dot';
  document.getElementById('last-update').textContent='· '+new Date().toLocaleTimeString();
  document.getElementById('status').textContent=`Connected · ${data.recent_calls.length} calls in feed`;
}

// ── SSE ──────────────────────────────────────────────────────────────────────

function connect() {
  const es = new EventSource('/stream');
  es.addEventListener('snapshot',  e => update(JSON.parse(e.data)));
  es.addEventListener('update',    e => update(JSON.parse(e.data)));
  es.addEventListener('anthropic', e => updateAnthropic(JSON.parse(e.data)));
  es.onopen  = () => {
    document.getElementById('live-dot').className='live-dot';
    document.getElementById('status').textContent='Connected';
  };
  es.onerror = () => {
    document.getElementById('live-dot').className='live-dot stale';
    document.getElementById('status').textContent='Reconnecting…';
    es.close(); setTimeout(connect, 2000);
  };
}
connect();
</script>
</body>
</html>
"""

# ─── HTTP Server ──────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/":
            body = HTML.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        elif path == "/api":
            with _lock:
                snap = _build_snapshot()
            # Strip heavy arrays for the lightweight API endpoint
            snap["week"] = {k: v for k, v in snap["week"].items()
                            if k not in ("cur_pts", "prev_pts")}
            snap["codex_week"] = {k: v for k, v in snap["codex_week"].items()
                                  if k not in ("history_pts",)}
            body = json.dumps(snap).encode()
            self.send_response(200)
            self.send_header("Content-Type",  "application/json")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        elif path == "/stream":
            self.send_response(200)
            self.send_header("Content-Type",  "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Accel-Buffering", "no")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            q = queue.Queue(maxsize=50)
            with _lock:
                snapshot = _build_snapshot()
            init = f"event: snapshot\ndata: {json.dumps(snapshot)}\n\n"
            try:
                self.wfile.write(init.encode())
                self.wfile.flush()
            except OSError:
                return

            _subscribers.append(q)
            try:
                while True:
                    try:
                        msg = q.get(timeout=15)
                    except queue.Empty:
                        msg = ": heartbeat\n\n"
                    self.wfile.write(msg.encode())
                    self.wfile.flush()
            except OSError:
                pass
            finally:
                try:
                    _subscribers.remove(q)
                except ValueError:
                    pass
        else:
            self.send_response(404)
            self.end_headers()


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Claude Code Live Token Dashboard")
    parser.add_argument("--port",       type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--plan",       choices=["5x", "20x"], default=None,
                        help="Max subscription tier (5x=$100/mo, 20x=$200/mo). Shows both if omitted.")
    args = parser.parse_args()
    global _subscription_plan
    _subscription_plan = args.plan

    t = threading.Thread(target=_watcher_loop, daemon=True)
    t.start()

    tu = threading.Thread(target=_utilization_loop, daemon=True)
    tu.start()

    if usage_pusher.has_device_token():
        tp = threading.Thread(target=_usage_push_loop, daemon=True)
        tp.start()

    class _Server(ThreadingMixIn, HTTPServer):
        daemon_threads = True
    server = _Server(("127.0.0.1", args.port), Handler)
    url = f"http://localhost:{args.port}"
    print(f"Dashboard: {url}", file=sys.stderr)

    if not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.", file=sys.stderr)


if __name__ == "__main__":
    main()
