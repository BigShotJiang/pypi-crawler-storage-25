"""Best-effort push loop for team-usage snapshots.

The pusher is stdlib-only, reads the device token from local config or the
OBSLY_DEVICE_TOKEN environment variable, and never raises to the caller.
"""

import json
import os
import urllib.error
import urllib.request

from claudedashboard import __version__
from claudedashboard.codex_estimate import estimate_codex_usage
from claudedashboard.gitai.obsly_config import DEFAULT_SERVER_URL, load_config

DEFAULT_USAGE_PATH = "/api/usage-snapshot"
DEFAULT_USAGE_SERVER_URL = "https://ai.obsly.io"


def _normalize_server_url(server_url):
    server = (server_url or DEFAULT_SERVER_URL or "").strip()
    return server.rstrip("/")


def _resolve_device_token(cfg=None):
    cfg = cfg or load_config()
    token = os.environ.get("OBSLY_DEVICE_TOKEN") or cfg.get("device_token") or ""
    token = token.strip()
    return token or ""


def _resolve_server_url(cfg=None):
    cfg = cfg or load_config()
    override = os.environ.get("OBSLY_USAGE_SERVER_URL") or cfg.get("usage_server_url")
    if override:
        return _normalize_server_url(override)

    server = _normalize_server_url(cfg.get("server_url"))
    if not server or server == _normalize_server_url(DEFAULT_SERVER_URL):
        return DEFAULT_USAGE_SERVER_URL
    return server


def _build_payload(snapshot=None, home_dir=None):
    snapshot = snapshot or {}
    anthropic = snapshot.get("anthropic") or {}
    codex_week = snapshot.get("codex_week") or snapshot.get("codex") or {}

    claude = {
        "weekly_pct": anthropic.get("seven_day_pct"),
        "five_hour_pct": anthropic.get("five_hour_pct"),
        "sonnet_pct": anthropic.get("sonnet_pct"),
    }
    claude_plan = anthropic.get("plan")
    if claude_plan:
        claude["plan"] = claude_plan

    codex_plan = codex_week.get("plan") or codex_week.get("plan_type")
    codex_weekly_pct = codex_week.get("weekly_pct")
    if codex_weekly_pct is None:
        codex_weekly_pct = codex_week.get("seven_day_pct")
    if codex_weekly_pct is None:
        codex_week = estimate_codex_usage(home_dir=home_dir, plan=codex_plan)
        codex_plan = codex_week.get("plan")
        codex_weekly_pct = codex_week.get("weekly_pct")

    payload = {
        "claude": claude,
        "codex": {
            "plan": codex_plan or codex_week.get("plan"),
            "weekly_pct": codex_weekly_pct,
            "estimated": True,
        },
        "equivalent_value_7d_usd": snapshot.get("week_api_cost"),
        "client_version": __version__,
    }
    return payload


def push_usage_snapshot(snapshot=None, *, home_dir=None, cfg=None, timeout=10, opener=None):
    """Best-effort POST to the team usage endpoint.

    Returns True on a successful 2xx response, False otherwise.
    """
    try:
        cfg = cfg or load_config()
        device_token = _resolve_device_token(cfg)
        if not device_token:
            return False

        server_url = _resolve_server_url(cfg)
        if not server_url:
            return False

        payload = _build_payload(snapshot=snapshot, home_dir=home_dir)
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{server_url}{DEFAULT_USAGE_PATH}",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {device_token}",
            },
            method="POST",
        )

        open_fn = opener or urllib.request.urlopen
        with open_fn(req, timeout=timeout) as resp:
            return 200 <= getattr(resp, "status", 0) < 300
    except (urllib.error.URLError, OSError, TimeoutError, ValueError, TypeError, Exception):
        return False


def has_device_token(cfg=None):
    return bool(_resolve_device_token(cfg))
