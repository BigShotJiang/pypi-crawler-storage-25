"""Read/write Git Notes under refs/notes/ai."""

import subprocess


def _git(args, cwd, input_data=None, check=True):
    """Run a git command and return stdout."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd, capture_output=True, text=True, timeout=5,
            input=input_data,
        )
        if check and result.returncode != 0:
            return None
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None


def notes_add(repo_path, commit_sha, content):
    """Write a note to refs/notes/ai for a commit."""
    subprocess.run(
        ["git", "notes", "--ref=ai", "add", "-f", "-F", "-", commit_sha],
        input=content, cwd=repo_path, check=True, capture_output=True, text=True, timeout=5,
    )


def notes_read(repo_path, commit_sha):
    """Read the note from refs/notes/ai. Returns None if no note."""
    return _git(["notes", "--ref=ai", "show", commit_sha], repo_path)


def notes_remove(repo_path, commit_sha):
    """Remove note from refs/notes/ai. Returns True if removed."""
    result = _git(["notes", "--ref=ai", "remove", commit_sha], repo_path)
    return result is not None


def notes_list(repo_path):
    """List all (note_blob_sha, commit_sha) pairs under refs/notes/ai."""
    output = _git(["notes", "--ref=ai", "list"], repo_path)
    if not output:
        return []
    pairs = []
    for line in output.split("\n"):
        parts = line.strip().split()
        if len(parts) == 2:
            pairs.append((parts[0], parts[1]))
    return pairs


def has_note(repo_path, commit_sha):
    """Quick check if a commit has an AI note."""
    return notes_read(repo_path, commit_sha) is not None


def notes_copy(repo_path, from_sha, to_sha):
    """Copy note from one commit to another."""
    content = notes_read(repo_path, from_sha)
    if content is None:
        return False
    notes_add(repo_path, to_sha, content)
    return True


def get_repo_root(cwd):
    """Find git repo root from cwd. Returns None if not in a git repo."""
    return _git(["rev-parse", "--show-toplevel"], cwd)


def get_head_sha(repo_path):
    """git rev-parse HEAD."""
    return _git(["rev-parse", "HEAD"], repo_path)


def get_git_user(repo_path):
    """git config user.email. Returns 'unknown' if not set."""
    result = _git(["config", "user.email"], repo_path)
    return result or "unknown"


def get_staged_files(repo_path):
    """git diff --cached --name-only."""
    output = _git(["diff", "--cached", "--name-only"], repo_path)
    if not output:
        return []
    return [f for f in output.split("\n") if f.strip()]


def get_file_at_commit(repo_path, commit_sha, file_path):
    """Read file content at a specific commit. Returns None if not found."""
    return _git(["show", f"{commit_sha}:{file_path}"], repo_path)


def blame_origin(repo_path, commit_sha, file_path):
    """Run git blame -p; return list of (commit_sha, orig_line) per current line."""
    out = _git(["blame", "-p", commit_sha, "--", file_path], repo_path)
    if not out:
        return []
    result = []
    for line in out.split("\n"):
        # Header lines look like: "<sha> <orig_line> <final_line> [count]"
        if line and line[0] != "\t" and " " in line:
            parts = line.split(" ")
            sha, orig = parts[0], parts[1]
            if len(sha) == 40 and orig.isdigit():
                result.append((sha, int(orig)))
    return result
