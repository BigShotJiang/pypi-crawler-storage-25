"""Checkpoint engine — pre/post snapshot and commit-time note writing."""

import os, sys
from pathlib import Path
from claudedashboard.gitai.models import (
    Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, NormalizedHookInput, HookEvent,
)
from claudedashboard.gitai.attribution import (
    compute_attributions, initial_attributions, attributions_for_new_file, INITIAL_AUTHOR,
)
from claudedashboard.gitai.working_log import WorkingLog
from claudedashboard.gitai.authorship_log import from_checkpoints, serialize
from claudedashboard.gitai.git_notes import notes_add, get_head_sha, get_git_user
from claudedashboard.gitai.session import generate_session_hash, compute_file_hash
from claudedashboard.gitai.ignore import should_ignore, is_binary_file


class CheckpointEngine:
    """Processes hook events and manages the checkpoint lifecycle."""

    def __init__(self, repo_root):
        self.repo_root = Path(repo_root)
        self.working_log = WorkingLog(repo_root)

    def handle_pre_tool_use(self, hook):
        """Save pre-edit file state as a snapshot."""
        files = self._extract_files(hook)
        if not files:
            return
        snapshot = {}
        for rel_path in files:
            if should_ignore(rel_path):
                continue
            content = self._read_file(rel_path)
            if content is not None:
                snapshot[rel_path] = content
            else:
                # File doesn't exist yet (Write tool) — record as empty
                snapshot[rel_path] = ""
        if snapshot:
            self.working_log.save_snapshot(hook.tool_use_id, snapshot)

    def handle_post_tool_use(self, hook):
        """Compute attribution for changes and create checkpoint."""
        snapshot = self.working_log.load_snapshot(hook.tool_use_id)
        if snapshot is None:
            return

        files = self._extract_files(hook)
        if not files:
            self.working_log.delete_snapshot(hook.tool_use_id)
            return

        base_commit = get_head_sha(str(self.repo_root))
        if not base_commit:
            self.working_log.delete_snapshot(hook.tool_use_id)
            return

        session_hash = generate_session_hash(hook.agent, hook.session_id)
        entries = []

        for rel_path in files:
            if should_ignore(rel_path):
                continue

            old_content = snapshot.get(rel_path, "")
            new_content = self._read_file(rel_path)
            if new_content is None:
                continue

            # Skip binary
            if is_binary_file(new_content.encode("utf-8", errors="replace")):
                continue

            # Skip if unchanged
            if old_content == new_content:
                continue

            # Compute attributions
            if old_content == "":
                # New file
                attrs = attributions_for_new_file(new_content, session_hash)
            else:
                prev_attrs = self._get_previous_attributions(base_commit, rel_path)
                attrs = compute_attributions(old_content, new_content, session_hash, prev_attrs)

            blob_sha = compute_file_hash(new_content.encode("utf-8"))
            entries.append(WorkingLogEntry(rel_path, blob_sha, attrs))

        self.working_log.delete_snapshot(hook.tool_use_id)

        if not entries:
            return

        agent_id = AgentId(hook.agent, hook.session_id, hook.model or "unknown")
        cp = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author=get_git_user(str(self.repo_root)),
            entries=entries,
            agent_id=agent_id,
            tool_use_id=hook.tool_use_id,
        )
        self.working_log.append_checkpoint(base_commit, cp)

    def handle_post_commit(self):
        """Convert working log to AuthorshipLog and write git note."""
        head = get_head_sha(str(self.repo_root))
        if not head:
            return

        # Find parent commit (the base of our working log)
        parent = self._get_parent_sha(head)
        if not parent:
            # First commit or error — check if working log exists for HEAD
            parent = head

        # Try parent first, then HEAD
        checkpoints = self.working_log.read_checkpoints(parent)
        if not checkpoints:
            checkpoints = self.working_log.read_checkpoints(head)
        if not checkpoints:
            return

        # Check if any AI checkpoints
        ai_cps = [cp for cp in checkpoints if cp.kind == CheckpointKind.AI_AGENT]
        if not ai_cps:
            self.working_log.delete_log(parent)
            return

        git_user = get_git_user(str(self.repo_root))
        total_added = self._total_lines_added(head, parent if parent != head else None)
        log = from_checkpoints(checkpoints, head, git_user, total_lines_added=total_added)

        if log.attestations:
            note_content = serialize(log)
            notes_add(str(self.repo_root), head, note_content)
            self._push_notes_ref()
            self._sync_note_to_server(head, note_content)

        self._maybe_emit_cost_alert(head, log)

        self.working_log.delete_log(parent)

    def _maybe_emit_cost_alert(self, commit_sha, log):
        """Best-effort: check the just-built AuthorshipLog for a cost spike and
        emit an alert. Never raises — failure to alert must not break the hook."""
        try:
            from claudedashboard.gitai import cost_alerts
            prompts = list(log.prompts.values()) if log.prompts else []
            if not prompts:
                return
            cost_alerts.check_and_alert(commit_sha, str(self.repo_root), prompts)
        except Exception as e:
            print(f"cost alert check failed: {e}", file=sys.stderr)

    def _push_notes_ref(self):
        """Push refs/notes/ai to origin so the server-side webhook flow can
        fetch them. Silent on failure (no remote, network down, etc.)."""
        try:
            import subprocess
            subprocess.run(
                ["git", "push", "origin", "refs/notes/ai:refs/notes/ai"],
                cwd=str(self.repo_root),
                capture_output=True, timeout=10,
            )
        except Exception:
            pass

    def _sync_note_to_server(self, sha, note_content):
        """POST the note to the configured obsly-ai server. Silent on failure."""
        try:
            from claudedashboard.gitai.ingest_sync import send_note
            from claudedashboard.gitai.git_notes import _git
            repo = str(self.repo_root)
            remote = _git(["remote", "get-url", "origin"], repo) or ""
            meta = _git(["log", "-1", "--format=%H|%ae|%an|%s|%aI", sha], repo) or ""
            parts = meta.split("|", 4)
            if len(parts) == 5:
                _, email, name, msg, committed_at = parts
            else:
                email = name = msg = committed_at = ""
            send_note(
                repo_url=remote, sha=sha, note_content=note_content,
                author_email=email, author_name=name,
                message=msg, committed_at=committed_at,
            )
        except Exception:
            pass

    # ── Internal ─────────────────────────────────────────────────────

    def _total_lines_added(self, head_sha, parent_sha):
        """Sum of `+` lines in the commit's diff against its parent.

        Returns None on any error so the caller falls back to the v3.0.0
        behaviour (no total). Uses `git show --numstat` which works for the
        initial commit too. Skips binary files (numstat reports them as `-`).
        """
        try:
            import subprocess
            if parent_sha:
                args = ["git", "diff", "--numstat", parent_sha, head_sha]
            else:
                args = ["git", "show", "--numstat", "--format=", head_sha]
            out = subprocess.run(
                args, cwd=str(self.repo_root),
                capture_output=True, text=True, timeout=5,
            )
            if out.returncode != 0:
                return None
            total = 0
            for line in out.stdout.splitlines():
                if not line.strip():
                    continue
                parts = line.split("\t", 2)
                if len(parts) < 2:
                    continue
                added = parts[0]
                if added == "-":  # binary
                    continue
                try:
                    total += int(added)
                except ValueError:
                    continue
            return total
        except Exception:
            return None

    def _extract_files(self, hook):
        """Get relative file paths from hook input."""
        tool = hook.tool_name
        ti = hook.tool_input

        if tool in ("Write", "Edit", "write", "edit"):
            path = ti.get("file_path", "")
            if path:
                return [self._abs_to_rel(path)]
        return []

    def _abs_to_rel(self, abs_path):
        """Convert absolute path to repo-relative path."""
        try:
            return str(Path(abs_path).relative_to(self.repo_root))
        except ValueError:
            return abs_path

    def _read_file(self, rel_path):
        """Read file content. Returns None if not readable."""
        path = self.repo_root / rel_path
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return None

    def _get_previous_attributions(self, base_commit, rel_path):
        """Get attributions from latest checkpoint or compute initial."""
        checkpoints = self.working_log.read_checkpoints(base_commit)
        # Walk backwards to find latest entry for this file
        for cp in reversed(checkpoints):
            for entry in cp.entries:
                if entry.file == rel_path and entry.line_attributions:
                    return entry.line_attributions

        # No prior checkpoint — get initial from HEAD content
        from claudedashboard.gitai.git_notes import get_file_at_commit
        content = get_file_at_commit(str(self.repo_root), base_commit, rel_path)
        if content:
            return initial_attributions(content)
        return []

    def _get_parent_sha(self, commit_sha):
        """Get parent commit SHA."""
        import subprocess
        try:
            result = subprocess.run(
                ["git", "rev-parse", f"{commit_sha}~1"],
                cwd=str(self.repo_root), capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None
