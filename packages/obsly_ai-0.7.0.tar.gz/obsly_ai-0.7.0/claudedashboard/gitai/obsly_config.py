"""Read/write the obsly-ai client config."""

import json
import os
from pathlib import Path

DEFAULT_SERVER_URL = "http://localhost:8002"


def config_path():
    override = os.environ.get("OBSLY_CONFIG_DIR")
    if override:
        d = Path(override)
    else:
        d = Path(os.path.expanduser("~")) / ".obsly-ai"
    return d / "config.json"


def load_config():
    p = config_path()
    cfg = {"server_url": DEFAULT_SERVER_URL, "token": "", "device_token": ""}
    if p.exists():
        try:
            data = json.loads(p.read_text())
            if isinstance(data, dict):
                cfg.update(data)
        except (OSError, ValueError):
            pass
    return cfg


def save_config(cfg):
    p = config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2))


def set_value(key, value):
    """Set a config value. Accepts 'server'/'server_url', 'token', 'device_token'."""
    cfg = load_config()
    if key in ("server", "server_url"):
        cfg["server_url"] = value
    elif key == "token":
        cfg["token"] = value
    elif key == "device_token":
        cfg["device_token"] = value
    else:
        cfg[key] = value
    save_config(cfg)


def show():
    cfg = load_config()
    print(f"server_url: {cfg['server_url']}")
    token = cfg.get("token", "")
    print(f"token:      {'<set>' if token else '<not set>'}")
    device_token = cfg.get("device_token", "")
    print(f"device_token: {'<set>' if device_token else '<not set>'}")
    print(f"path:       {config_path()}")
