"""Rewrite git notes on rebase, amend, cherry-pick."""

import difflib
from claudedashboard.gitai.models import LineRange
from claudedashboard.gitai.authorship_log import serialize, deserialize
from claudedashboard.gitai.git_notes import notes_read, notes_add


def handle_post_rewrite_amend(repo_root, old_sha, new_sha):
    """Copy note from old to new SHA, update base_commit_sha."""
    note = notes_read(repo_root, old_sha)
    if not note:
        return False
    log = deserialize(note)
    log.base_commit_sha = new_sha
    notes_add(repo_root, new_sha, serialize(log))
    return True


def handle_post_rewrite_rebase(repo_root, mappings):
    """Rewrite notes for rebased commits. Returns count rewritten."""
    count = 0
    for old_sha, new_sha in mappings:
        note = notes_read(repo_root, old_sha)
        if not note:
            continue
        log = deserialize(note)
        log.base_commit_sha = new_sha
        notes_add(repo_root, new_sha, serialize(log))
        count += 1
    return count


def handle_cherry_pick(repo_root, original_sha, new_sha):
    """Copy note from original commit to cherry-picked commit."""
    note = notes_read(repo_root, original_sha)
    if not note:
        return False
    log = deserialize(note)
    log.base_commit_sha = new_sha
    notes_add(repo_root, new_sha, serialize(log))
    return True


def adjust_line_ranges(ranges, old_content, new_content):
    """Adjust line ranges when content changes (e.g., during rebase conflict resolution)."""
    old_lines = old_content.splitlines(True)
    new_lines = new_content.splitlines(True)

    # Build a mapping: old_line_num -> new_line_num
    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)
    old_to_new = {}
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                old_to_new[i1 + offset + 1] = j1 + offset + 1  # 1-indexed

    # Adjust ranges
    result = []
    for lr in ranges:
        new_start = None
        new_end = None
        for line_num in range(lr.start, lr.end + 1):
            mapped = old_to_new.get(line_num)
            if mapped is not None:
                if new_start is None:
                    new_start = mapped
                new_end = mapped
        if new_start is not None:
            result.append(LineRange(new_start, new_end))
    return result
