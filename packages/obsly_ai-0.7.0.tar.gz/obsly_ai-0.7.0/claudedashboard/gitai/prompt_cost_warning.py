"""Real-time prompt cost warning (0.7.0 #1, issue #45).

Reads a Claude Code session JSONL transcript, computes accumulated cost
+ context size + cache pressure, and decides whether to warn the user
to consider ``/clear`` before sending the next prompt.

Pure logic, stdlib only — runs inside the agent process via the
UserPromptSubmit hook. Must never raise; the caller (CLI) is
responsible for routing errors to ``None`` so the agent never blocks.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from claudedashboard.gitai.pricing import calc_cost


# --- thresholds ------------------------------------------------------------


@dataclass
class Thresholds:
    """When any of these is crossed, the user gets a warning.

    Defaults are conservative — chosen so a normal short conversation
    never triggers, but a long Opus 1M session that has been hoarding
    context for an hour does."""
    context_tokens: int = 200_000      # > 200k context = warn
    accumulated_cost_usd: float = 20.0  # > $20 spent on this session
    cache_ratio: float = 100.0          # last_msg cache_read / input_tokens > 100x
    session_age_seconds: int = 90 * 60  # > 90 minutes since first message

    @classmethod
    def from_config_file(cls, path: Optional[Path] = None) -> "Thresholds":
        """Load thresholds from ``~/.obsly-ai/config.json`` if present.

        Missing file or missing keys → defaults. Malformed file → defaults
        (we never crash the user's agent over a bad config)."""
        path = path or Path.home() / ".obsly-ai" / "config.json"
        try:
            data = json.loads(path.read_text())
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            return cls()
        section = data.get("prompt_cost_warning") or {}
        defaults = cls()
        return cls(
            context_tokens=int(section.get("context_tokens", defaults.context_tokens)),
            accumulated_cost_usd=float(section.get("accumulated_cost_usd", defaults.accumulated_cost_usd)),
            cache_ratio=float(section.get("cache_ratio", defaults.cache_ratio)),
            session_age_seconds=int(section.get("session_age_seconds", defaults.session_age_seconds)),
        )


# --- session metrics -------------------------------------------------------


@dataclass
class SessionMetrics:
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_read: int = 0
    total_cache_creation: int = 0
    total_cost_usd: float = 0.0
    context_tokens: int = 0
    session_age_seconds: int = 0
    message_count: int = 0
    last_message_input_tokens: int = 0
    last_message_output_tokens: int = 0
    last_message_cache_read: int = 0
    last_message_cache_creation: int = 0
    last_message_cost_usd: float = 0.0
    last_message_model: str = ""


def _parse_ts(ts: str) -> Optional[datetime]:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def compute_session_metrics(
    transcript_path,
    *,
    now_ts: Optional[str] = None,
) -> Optional[SessionMetrics]:
    """Parse a Claude Code session JSONL and aggregate token + cost stats.

    Returns ``None`` when the file does not exist or cannot be opened.
    Skips malformed lines and non-usage messages silently — the file
    contains user/assistant text rows that have no ``message.usage``."""
    path = Path(transcript_path)
    if not path.exists():
        return None

    metrics = SessionMetrics()
    first_ts = None
    last_ts = None

    try:
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except (json.JSONDecodeError, TypeError):
                    continue

                msg = obj.get("message") or {}
                usage = msg.get("usage") or {}
                if not usage:
                    continue

                input_tokens = usage.get("input_tokens", 0) or 0
                cache_creation = usage.get("cache_creation_input_tokens", 0) or 0
                cache_read = usage.get("cache_read_input_tokens", 0) or 0
                output_tokens = usage.get("output_tokens", 0) or 0
                model = msg.get("model", "") or ""

                if input_tokens + cache_creation + cache_read + output_tokens == 0:
                    continue

                metrics.total_input_tokens += input_tokens
                metrics.total_output_tokens += output_tokens
                metrics.total_cache_read += cache_read
                metrics.total_cache_creation += cache_creation
                metrics.message_count += 1
                metrics.total_cost_usd += calc_cost(
                    model, input_tokens, output_tokens, cache_read, cache_creation,
                )

                metrics.last_message_input_tokens = input_tokens
                metrics.last_message_output_tokens = output_tokens
                metrics.last_message_cache_read = cache_read
                metrics.last_message_cache_creation = cache_creation
                metrics.last_message_cost_usd = calc_cost(
                    model, input_tokens, output_tokens, cache_read, cache_creation,
                )
                metrics.last_message_model = model
                metrics.context_tokens = cache_read + cache_creation + input_tokens

                ts = _parse_ts(obj.get("timestamp", ""))
                if ts is not None:
                    if first_ts is None:
                        first_ts = ts
                    last_ts = ts
    except OSError:
        return None

    if first_ts is not None:
        end = _parse_ts(now_ts) if now_ts else last_ts
        if end is not None:
            metrics.session_age_seconds = max(0, int((end - first_ts).total_seconds()))

    return metrics


# --- warning logic ---------------------------------------------------------


@dataclass
class Warning:
    """A decision to warn the user, plus the math behind it."""
    current_cost_usd: float
    post_clear_cost_usd: float
    savings_usd: float
    savings_pct: float
    reasons: list = field(default_factory=list)


def _post_clear_cost(metrics: SessionMetrics) -> float:
    """Estimate what the same exchange would cost if the user had done
    ``/clear`` first.

    The output tokens are paid regardless (the model still generates
    the same response), so include them. ``cache_read`` drops to 0
    (the whole point of /clear) and ``cache_creation`` also drops
    because there's nothing to cache on a fresh session.

    ``savings = current_cost - post_clear_cost`` = the cache_* portion
    of the bill, exactly the part that ``/clear`` would have erased.
    """
    return calc_cost(
        metrics.last_message_model,
        metrics.last_message_input_tokens,
        metrics.last_message_output_tokens,
        cache_read=0,
        cache_create=0,
    )


def should_warn(metrics: SessionMetrics, thresholds: Thresholds) -> Optional[Warning]:
    """Return a ``Warning`` if any threshold is crossed, else ``None``."""
    if metrics is None:
        return None

    reasons = []
    if metrics.context_tokens > thresholds.context_tokens:
        reasons.append("context_tokens")
    if metrics.total_cost_usd > thresholds.accumulated_cost_usd:
        reasons.append("accumulated_cost")
    if metrics.session_age_seconds > thresholds.session_age_seconds:
        reasons.append("session_age")
    if metrics.last_message_input_tokens > 0:
        ratio = metrics.last_message_cache_read / metrics.last_message_input_tokens
        if ratio > thresholds.cache_ratio:
            reasons.append("cache_ratio")

    if not reasons:
        return None

    current = metrics.last_message_cost_usd
    post_clear = _post_clear_cost(metrics)
    savings = max(0.0, current - post_clear)
    savings_pct = (savings / current * 100) if current > 0 else 0.0

    return Warning(
        current_cost_usd=round(current, 4),
        post_clear_cost_usd=round(post_clear, 4),
        savings_usd=round(savings, 4),
        savings_pct=round(savings_pct, 1),
        reasons=reasons,
    )


# --- formatting ------------------------------------------------------------


def _fmt_minutes(seconds: int) -> str:
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    rem = minutes % 60
    return f"{hours}h{rem:02d}m"


def _fmt_tokens(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}k"
    return str(n)


_REASON_LABELS = {
    "context_tokens": "context size",
    "accumulated_cost": "accumulated cost",
    "cache_ratio": "cache_read pressure",
    "session_age": "session age",
}


def format_warning(warning: Warning, metrics: SessionMetrics) -> str:
    """Render the warning text. Goes to stderr in the CLI."""
    reasons_text = ", ".join(_REASON_LABELS.get(r, r) for r in warning.reasons)
    lines = [
        "obsly-ai: prompt cost warning",
        f"  This conversation has been running {_fmt_minutes(metrics.session_age_seconds)},"
        f" carrying {_fmt_tokens(metrics.context_tokens)} context tokens,"
        f" ${metrics.total_cost_usd:.2f} accumulated.",
        f"  Last message cost: ${warning.current_cost_usd:.2f}"
        f" (cache_read: {_fmt_tokens(metrics.last_message_cache_read)} tokens).",
        f"  Estimated cost of the same prompt after /clear: ${warning.post_clear_cost_usd:.2f}",
        f"  -> Potential saving: ${warning.savings_usd:.2f} ({warning.savings_pct:.0f}%)",
        f"  Tripped: {reasons_text}",
        "",
        "  If your next prompt changes topic or doesn't need the previous",
        "  context, run /clear (or /compact) before sending it.",
    ]
    return "\n".join(lines)
