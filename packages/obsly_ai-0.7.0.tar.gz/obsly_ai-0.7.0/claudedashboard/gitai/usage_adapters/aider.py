"""Aider usage adapter - parses .aider.chat.history.md token footers."""

import re
from datetime import datetime, timezone
from pathlib import Path

from claudedashboard.gitai.usage_adapters.base import UsageAdapter, UsageRecord


# Modern Aider footer:
# > Tokens: 1.2k sent, 345 received. Cost: $0.0234 message, $0.0567 session.
# Older variants drop the leading `>` and use `request` instead of `message`.
_FOOTER_RE = re.compile(
    r"^\s*>?\s*Tokens:\s*([\d.]+)([kK]?)\s*sent,\s*([\d.]+)([kK]?)\s*received\.\s*"
    r"Cost:\s*\$([\d.]+)\s*(?:message|request)",
    re.MULTILINE,
)


def _parse_token_count(value, suffix):
    """Convert '1.2', 'k' -> 1200; '345', '' -> 345."""
    n = float(value)
    if suffix.lower() == "k":
        n *= 1000
    return int(round(n))


def parse_footers(text):
    """Return list of dicts {tokens_in, tokens_out, cost_usd} for each footer match in text."""
    out = []
    for m in _FOOTER_RE.finditer(text):
        tin = _parse_token_count(m.group(1), m.group(2))
        tout = _parse_token_count(m.group(3), m.group(4))
        cost = float(m.group(5))
        out.append({"tokens_in": tin, "tokens_out": tout, "cost_usd": cost})
    return out


def session_id_for_repo(repo_path):
    """Synthesize a stable session id for a given Aider history file's repo."""
    p = Path(repo_path)
    name = p.name
    if not name:
        # Handle trailing slash / root paths: fall back to parent name.
        name = p.parent.name or "unknown"
    return f"aider:{name}"


class AiderAdapter(UsageAdapter):
    agent = "aider"

    def __init__(self, search_paths=None):
        """search_paths: iterable of directories to look for .aider.chat.history.md.
        If None, uses [Path.cwd()] only."""
        if search_paths is None:
            self.search_paths = [Path.cwd()]
        else:
            self.search_paths = [Path(p) for p in search_paths]

    def records_for_session(self, session_id):
        """Return list[UsageRecord] for the given session id."""
        if not session_id:
            return []

        records = []
        for root in self.search_paths:
            history_file = root / ".aider.chat.history.md"
            if not history_file.exists():
                continue
            if session_id_for_repo(root) != session_id:
                continue
            try:
                text = history_file.read_text(encoding="utf-8", errors="replace")
                mtime = history_file.stat().st_mtime
            except OSError:
                continue
            footers = parse_footers(text)
            timestamp = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()
            for f in footers:
                records.append(UsageRecord(
                    session_id=session_id,
                    timestamp=timestamp,
                    agent=self.agent,
                    model="",
                    tokens_in=f["tokens_in"],
                    tokens_out=f["tokens_out"],
                    cache_read=0,
                    cache_create=0,
                    equivalent_api_cost_usd=f["cost_usd"],
                    billed_usd=None,
                    plan=None,
                ))
        return records
