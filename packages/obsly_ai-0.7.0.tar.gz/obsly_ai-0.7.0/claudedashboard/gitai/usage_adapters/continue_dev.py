"""Continue.dev usage adapter — reads ~/.continue/sessions/*.json prompt logs."""

import json
import os
from pathlib import Path
from claudedashboard.gitai.usage_adapters.base import UsageAdapter, UsageRecord


class ContinueAdapter(UsageAdapter):
    agent = "continue"

    def __init__(self, sessions_root=None):
        if sessions_root:
            self.sessions_root = Path(sessions_root)
        else:
            self.sessions_root = Path(os.path.expanduser("~")) / ".continue" / "sessions"

    def records_for_session(self, session_id):
        if not session_id or not self.sessions_root.exists():
            return []
        records = []
        for json_file in self.sessions_root.rglob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8", errors="replace"))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict):
                continue
            file_session_id = data.get("sessionId") or json_file.stem
            if file_session_id != session_id:
                continue
            records.extend(self._extract_records(data, session_id))
        return records

    def _extract_records(self, data, session_id):
        out = []
        history = data.get("history") or []
        if not isinstance(history, list):
            return out
        for turn in history:
            if not isinstance(turn, dict):
                continue
            prompt_logs = turn.get("promptLogs") or []
            if not isinstance(prompt_logs, list):
                continue
            for log in prompt_logs:
                rec = self._log_to_record(log, session_id)
                if rec:
                    out.append(rec)
        return out

    def _log_to_record(self, log, session_id):
        if not isinstance(log, dict):
            return None
        stats = log.get("stats") or {}
        if not isinstance(stats, dict):
            stats = {}
        completion = log.get("completionOptions") or {}
        if not isinstance(completion, dict):
            completion = {}
        model = completion.get("model") or log.get("modelTitle") or ""
        return UsageRecord(
            session_id=session_id,
            timestamp=log.get("timestamp") or "",
            agent=self.agent,
            model=model,
            tokens_in=int(stats.get("promptTokens") or 0),
            tokens_out=int(stats.get("completionTokens") or 0),
            cache_read=int(stats.get("cacheReadTokens") or 0),
            cache_create=int(stats.get("cacheWriteTokens") or 0),
            equivalent_api_cost_usd=float(stats.get("cost") or 0.0),
            billed_usd=None,
            plan=None,
        )
