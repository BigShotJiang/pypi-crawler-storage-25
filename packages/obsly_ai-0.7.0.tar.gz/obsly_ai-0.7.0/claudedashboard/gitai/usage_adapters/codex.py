"""Codex usage adapter — reads ~/.codex/sessions/**/*.jsonl.

Codex stores its session log as a stream of `{type, timestamp, payload}` rows:
- session_meta:   payload.id is the session id, payload.timestamp the start
- turn_context:   payload.model is the model used for that turn
- event_msg(token_count): payload.info.total_token_usage has cumulative
  input/output/cached/reasoning tokens for the session so far
"""

import json
import os
from pathlib import Path
from claudedashboard.gitai.usage_adapters.base import UsageAdapter, UsageRecord
from claudedashboard.gitai.pricing import calc_cost, match_model


class CodexAdapter(UsageAdapter):
    agent = "codex"

    def __init__(self, home_dir=None):
        self.home_dir = Path(home_dir) if home_dir else Path(os.path.expanduser("~"))
        self.sessions_root = self.home_dir / ".codex" / "sessions"

    def records_for_session(self, session_id):
        if not session_id or not self.sessions_root.exists():
            return []

        for jsonl in self.sessions_root.rglob("*.jsonl"):
            try:
                file_session_id = None
                model = None
                last_total = None
                last_ts = ""
                with jsonl.open("r", encoding="utf-8", errors="replace") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except (ValueError, json.JSONDecodeError):
                            continue
                        t = entry.get("type")
                        p = entry.get("payload") or {}
                        if not isinstance(p, dict):
                            continue
                        if t == "session_meta":
                            file_session_id = p.get("id")
                            if file_session_id != session_id:
                                break  # wrong file
                        elif t == "turn_context":
                            if p.get("model"):
                                model = p.get("model")
                        elif t == "event_msg" and p.get("type") == "token_count":
                            info = p.get("info") or {}
                            total = info.get("total_token_usage") or {}
                            if total:
                                last_total = total
                                last_ts = entry.get("timestamp", last_ts)
                if file_session_id != session_id or not last_total:
                    continue

                tokens_in = last_total.get("input_tokens", 0) or 0
                tokens_out = (last_total.get("output_tokens", 0) or 0) \
                    + (last_total.get("reasoning_output_tokens", 0) or 0)
                cache_read = last_total.get("cached_input_tokens", 0) or 0
                cost = calc_cost(model or "", tokens_in, tokens_out, cache_read, 0)
                return [UsageRecord(
                    session_id=session_id,
                    timestamp=last_ts,
                    agent=self.agent,
                    model=match_model(model) or (model or ""),
                    tokens_in=tokens_in,
                    tokens_out=tokens_out,
                    cache_read=cache_read,
                    cache_create=0,
                    equivalent_api_cost_usd=cost,
                    billed_usd=None,
                    plan=None,
                )]
            except OSError:
                continue
        return []
