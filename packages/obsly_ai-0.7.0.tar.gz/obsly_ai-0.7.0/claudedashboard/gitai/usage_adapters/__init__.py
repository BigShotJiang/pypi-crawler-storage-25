"""Usage adapters: read token usage + compute equivalent cost from each
agent's local logs. Each adapter is independent and stdlib-only."""

from claudedashboard.gitai.usage_adapters.base import UsageRecord, UsageAdapter
from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
from claudedashboard.gitai.usage_adapters.codex import CodexAdapter
from claudedashboard.gitai.usage_adapters.cursor import CursorAdapter
from claudedashboard.gitai.usage_adapters.windsurf import WindsurfAdapter
from claudedashboard.gitai.usage_adapters.aider import AiderAdapter
from claudedashboard.gitai.usage_adapters.continue_dev import ContinueAdapter


def all_adapters():
    """Return the default registered adapters in priority order."""
    return [ClaudeCodeAdapter(), CodexAdapter(), CursorAdapter(), WindsurfAdapter(), AiderAdapter(), ContinueAdapter()]


def cost_for_session(session_id, agent_hint=None):
    """Sum equivalent_api_cost_usd across adapters for a given session.
    Returns 0.0 if no adapter has data for the session."""
    total = 0.0
    for adapter in all_adapters():
        if agent_hint and adapter.agent != agent_hint:
            continue
        for r in adapter.records_for_session(session_id):
            total += r.equivalent_api_cost_usd
    return round(total, 6)
