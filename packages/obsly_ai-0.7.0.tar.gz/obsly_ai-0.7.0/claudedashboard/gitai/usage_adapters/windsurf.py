"""Windsurf usage adapter — reads proxy_events.jsonl filtered by Windsurf process."""

import json
import os
from pathlib import Path
from claudedashboard.gitai.usage_adapters.base import UsageAdapter, UsageRecord


WINDSURF_PROCESS_NAMES = (
    "Windsurf",
    "Windsurf Helper",
    "Windsurf Helper (Renderer)",
    "Windsurf Helper (Plugin)",
    "Windsurf Helper (GPU)",
    "windsurf",
    "windsurf-helper",
    "Codeium",
    "codeium",
)


def _is_windsurf_process(tool):
    """Return True if `tool` looks like a Windsurf process name."""
    if not tool:
        return False
    if tool in WINDSURF_PROCESS_NAMES:
        return True
    lowered = tool.lower()
    return "windsurf" in lowered or "codeium" in lowered


class WindsurfAdapter(UsageAdapter):
    agent = "windsurf"

    def __init__(self, events_path=None):
        if events_path:
            self.events_path = Path(events_path)
        else:
            self.events_path = Path(os.path.expanduser("~")) / ".claude" / "proxy_events.jsonl"

    def records_for_session(self, session_id):
        """Return list[UsageRecord] for the given session id from Windsurf events."""
        if not session_id or not self.events_path.exists():
            return []

        records = []
        try:
            with self.events_path.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except (ValueError, json.JSONDecodeError):
                        continue
                    if not isinstance(event, dict):
                        continue
                    if event.get("session_id") != session_id:
                        continue
                    if not _is_windsurf_process(event.get("tool")):
                        continue
                    records.append(self._event_to_record(event, session_id))
        except OSError:
            return []
        return records

    def _event_to_record(self, event, session_id):
        ts_raw = event.get("timestamp")
        if isinstance(ts_raw, (int, float)):
            timestamp = self._iso_from_unix(float(ts_raw))
        elif isinstance(ts_raw, str):
            timestamp = ts_raw
        else:
            timestamp = ""
        return UsageRecord(
            session_id=session_id,
            timestamp=timestamp,
            agent=self.agent,
            model=event.get("model") or "",
            tokens_in=int(event.get("tokens_in") or 0),
            tokens_out=int(event.get("tokens_out") or 0),
            cache_read=int(event.get("cache_read") or 0),
            cache_create=int(event.get("cache_create") or 0),
            equivalent_api_cost_usd=float(event.get("cost_usd") or 0.0),
            billed_usd=None,
            plan=None,
        )

    def _iso_from_unix(self, ts):
        from datetime import datetime, timezone
        return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
