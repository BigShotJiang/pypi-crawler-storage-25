"""AI stats — per-commit and per-repo analytics."""

import json, subprocess
from collections import defaultdict
from claudedashboard.gitai.models import CommitStats, RepoStats
from claudedashboard.gitai.authorship_log import deserialize
from claudedashboard.gitai.git_notes import notes_read, has_note, get_head_sha


def stats_for_commit(repo_root, commit_sha="HEAD"):
    """Compute AI stats for one commit. Returns None if no note."""
    if commit_sha == "HEAD":
        commit_sha = get_head_sha(repo_root)
    if not commit_sha:
        return None

    note = notes_read(repo_root, commit_sha)
    if not note:
        return None

    log = deserialize(note)

    # Count AI lines from attestations
    ai_lines = 0
    by_agent = defaultdict(int)
    by_model = defaultdict(int)
    total_cost = 0.0

    for fa in log.attestations:
        for entry in fa.entries:
            prompt = log.prompts.get(entry.session_hash)
            line_count = sum(lr.end - lr.start + 1 for lr in entry.line_ranges)
            ai_lines += line_count
            if prompt:
                by_agent[prompt.agent_id.tool] += line_count
                by_model[prompt.agent_id.model] += line_count

    # Cost from custom_attributes
    for prompt in log.prompts.values():
        if prompt.custom_attributes and "cost_usd" in prompt.custom_attributes:
            try:
                total_cost += float(prompt.custom_attributes["cost_usd"])
            except ValueError:
                pass

    # Get commit info
    info = _get_commit_info(repo_root, commit_sha)
    total_added = ai_lines  # Use AI lines as total for note-only analysis

    pct = 100.0 if total_added > 0 else 0.0

    return CommitStats(
        commit_sha=commit_sha,
        message=info.get("message", ""),
        author=info.get("author", ""),
        date=info.get("date", ""),
        total_lines_added=total_added,
        ai_lines=ai_lines,
        human_lines=max(0, total_added - ai_lines),
        ai_percentage=pct,
        by_agent=dict(by_agent),
        by_model=dict(by_model),
        estimated_cost_usd=round(total_cost, 4) if total_cost else None,
    )


def stats_for_repo(repo_root, limit=100, since=None):
    """Walk recent commits, aggregate stats."""
    cmd = ["git", "log", f"--max-count={limit}", "--format=%H"]
    if since:
        cmd.append(f"--since={since}")

    try:
        result = subprocess.run(cmd, cwd=repo_root, capture_output=True, text=True, timeout=10)
        shas = [s.strip() for s in result.stdout.strip().split("\n") if s.strip()]
    except Exception:
        shas = []

    total_ai = 0
    total_added = 0
    by_agent = defaultdict(int)
    by_model = defaultdict(int)
    total_cost = 0.0
    commits = []
    with_ai = 0

    for sha in shas:
        cs = stats_for_commit(repo_root, sha)
        if cs:
            with_ai += 1
            total_ai += cs.ai_lines
            total_added += cs.total_lines_added
            for a, c in cs.by_agent.items():
                by_agent[a] += c
            for m, c in cs.by_model.items():
                by_model[m] += c
            if cs.estimated_cost_usd:
                total_cost += cs.estimated_cost_usd
            commits.append(cs)

    pct = (total_ai / total_added * 100) if total_added > 0 else 0.0

    return RepoStats(
        repo_path=repo_root,
        total_commits_scanned=len(shas),
        commits_with_ai=with_ai,
        total_lines_added=total_added,
        ai_lines=total_ai,
        ai_percentage=round(pct, 1),
        by_agent=dict(by_agent),
        by_model=dict(by_model),
        estimated_total_cost_usd=round(total_cost, 4) if total_cost else None,
        commits=commits,
    )


def _get_commit_info(repo_root, sha):
    """Get message, author, date for a commit."""
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%s%n%ae%n%aI", sha],
            cwd=repo_root, capture_output=True, text=True, timeout=5,
        )
        lines = result.stdout.strip().split("\n")
        return {
            "message": lines[0] if len(lines) > 0 else "",
            "author": lines[1] if len(lines) > 1 else "",
            "date": lines[2] if len(lines) > 2 else "",
        }
    except Exception:
        return {}


# ── Formatters ───────────────────────────────────────────────────────

def format_commit_terminal(stats):
    """Terminal output for a single commit."""
    lines = [
        f"Commit {stats.commit_sha[:7]}: \"{stats.message}\"",
        f"Author: {stats.author} | Date: {stats.date[:10] if stats.date else 'unknown'}",
        "",
        f"  AI authored:     {stats.ai_lines} lines ({stats.ai_percentage:.1f}%)",
        f"  Human authored:  {stats.human_lines} lines ({100 - stats.ai_percentage:.1f}%)",
    ]
    if stats.by_agent:
        lines.append("")
        lines.append("  By agent:")
        for agent, count in sorted(stats.by_agent.items(), key=lambda x: -x[1]):
            lines.append(f"    {agent:<15} {count} lines")
    if stats.estimated_cost_usd:
        lines.append(f"\n  Estimated cost: ${stats.estimated_cost_usd:.2f}")
    return "\n".join(lines)


def format_stats_json(stats):
    """JSON output for CommitStats or RepoStats."""
    if isinstance(stats, CommitStats):
        return json.dumps({
            "commit_sha": stats.commit_sha,
            "message": stats.message,
            "ai_lines": stats.ai_lines,
            "human_lines": stats.human_lines,
            "ai_percentage": stats.ai_percentage,
            "by_agent": stats.by_agent,
            "by_model": stats.by_model,
            "estimated_cost_usd": stats.estimated_cost_usd,
        }, indent=2)
    else:
        return json.dumps({
            "total_commits_scanned": stats.total_commits_scanned,
            "commits_with_ai": stats.commits_with_ai,
            "ai_lines": stats.ai_lines,
            "ai_percentage": stats.ai_percentage,
            "by_agent": stats.by_agent,
            "by_model": stats.by_model,
            "estimated_total_cost_usd": stats.estimated_total_cost_usd,
        }, indent=2)


def format_oneliner(stats):
    """One-liner for embedding."""
    if isinstance(stats, RepoStats):
        cost = f" ~${stats.estimated_total_cost_usd:.2f}" if stats.estimated_total_cost_usd else ""
        return f"{stats.ai_percentage:.0f}% AI | {stats.ai_lines} lines{cost}"
    else:
        return f"{stats.ai_percentage:.0f}% AI | {stats.ai_lines} lines"
