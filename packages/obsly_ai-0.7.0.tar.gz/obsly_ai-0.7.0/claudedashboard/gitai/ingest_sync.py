"""POST git notes to the obsly-ai server. Stdlib only, silent on failure."""

import json
import urllib.request
import urllib.error

from claudedashboard.gitai.obsly_config import load_config


def send_note(repo_url, sha, note_content, author_email, author_name,
              message, committed_at, timeout=5):
    """POST a single note to {server}/api/ingest-note. Returns True/False."""
    cfg = load_config()
    server = cfg.get("server_url", "").rstrip("/")
    if not server:
        return False

    payload = {
        "repo_url": repo_url,
        "sha": sha,
        "note_content": note_content,
        "author_email": author_email,
        "author_name": author_name,
        "message": message,
        "committed_at": committed_at,
    }

    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    token = cfg.get("token", "")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = urllib.request.Request(
        f"{server}/api/ingest-note",
        data=body, headers=headers, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, TimeoutError, Exception):
        return False
