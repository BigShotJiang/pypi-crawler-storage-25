"""File ignore patterns for attribution tracking."""

import fnmatch
from pathlib import Path

DEFAULT_IGNORE_PATTERNS = [
    "*.lock", "*.min.js", "*.min.css", "*.map",
    "*.woff", "*.woff2", "*.ttf", "*.eot",
    "*.png", "*.jpg", "*.jpeg", "*.gif", "*.ico", "*.svg",
    "*.pdf", "*.zip", "*.tar.gz", "*.whl",
    "*.pyc", "*.pyo", "__pycache__/*",
    "*.so", "*.dylib", "*.dll", "*.exe",
    "node_modules/*", ".git/*", ".venv/*", "vendor/*",
    "dist/*", "build/*", "*.egg-info/*",
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "Cargo.lock", "poetry.lock", "Gemfile.lock",
]


def should_ignore(filepath, extra_patterns=None):
    """Check if file should be excluded from attribution tracking."""
    patterns = DEFAULT_IGNORE_PATTERNS + (extra_patterns or [])
    name = Path(filepath).name
    for pattern in patterns:
        if fnmatch.fnmatch(filepath, pattern) or fnmatch.fnmatch(name, pattern):
            return True
    return False


def is_binary_file(content, sample_size=8192):
    """Detect binary by checking for null bytes in first sample_size bytes."""
    if not content:
        return False
    return b"\x00" in content[:sample_size]


def load_gitaiignore(repo_root):
    """Load patterns from .gitaiignore if it exists."""
    path = Path(repo_root) / ".gitaiignore"
    if not path.exists():
        return []
    patterns = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns
