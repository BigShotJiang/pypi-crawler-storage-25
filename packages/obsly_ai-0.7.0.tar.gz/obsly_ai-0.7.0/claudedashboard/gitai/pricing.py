"""LLM pricing table + equivalent-cost calculator. Stdlib only.

Used by usage_adapters/* to compute the equivalent API dollar cost from
local agent token logs, even when the user is on a flat-fee plan."""

# Pricing per million tokens. Mirrors proxy/capture.py PRICING but lives in
# gitai/ so the zero-dep core can compute equivalent API cost without
# importing the optional proxy package.
PRICING = {
    # Anthropic
    "claude-opus-4-6":   {"input": 15.0, "output": 75.0, "cache_read": 1.50, "cache_create": 18.75},
    "claude-opus-4-5":   {"input": 15.0, "output": 75.0, "cache_read": 1.50, "cache_create": 18.75},
    "claude-sonnet-4-6": {"input": 3.0,  "output": 15.0, "cache_read": 0.30, "cache_create": 3.75},
    "claude-sonnet-4-5": {"input": 3.0,  "output": 15.0, "cache_read": 0.30, "cache_create": 3.75},
    "claude-haiku-4-5":  {"input": 0.80, "output": 4.0,  "cache_read": 0.08, "cache_create": 1.00},
    # OpenAI
    "gpt-5":             {"input": 5.00, "output": 20.0},
    "gpt-4o":            {"input": 2.50, "output": 10.0},
    "gpt-4o-mini":       {"input": 0.15, "output": 0.60},
    "o3":                {"input": 2.00, "output": 8.00},
    # DeepSeek
    "deepseek-chat":     {"input": 0.14, "output": 0.28},
    "deepseek-reasoner": {"input": 0.55, "output": 2.19},
}

DEFAULT_PRICING = {"input": 3.0, "output": 15.0, "cache_read": 0.30, "cache_create": 3.75}


def match_model(model_str):
    """Resolve a full model id (e.g. 'claude-sonnet-4-6-20250514') to a
    PRICING key. Returns None if no prefix matches."""
    if not model_str:
        return None
    # Longest-prefix match so 'claude-opus-4-6' wins over 'claude-opus-4-5'
    matches = [k for k in PRICING if model_str.startswith(k)]
    if not matches:
        return None
    return max(matches, key=len)


def calc_cost(model, tokens_in, tokens_out, cache_read=0, cache_create=0):
    """Compute USD cost for a single API call. Falls back to DEFAULT_PRICING
    if the model is unknown."""
    key = match_model(model) or model
    p = PRICING.get(key, DEFAULT_PRICING)
    cost = (
        (tokens_in or 0) * p["input"] / 1_000_000
        + (tokens_out or 0) * p["output"] / 1_000_000
        + (cache_read or 0) * p.get("cache_read", 0) / 1_000_000
        + (cache_create or 0) * p.get("cache_create", 0) / 1_000_000
    )
    return round(cost, 6)
