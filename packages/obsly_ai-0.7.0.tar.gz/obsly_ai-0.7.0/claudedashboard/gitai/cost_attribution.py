"""Map proxy cost data to git note attribution lines."""

import json
from collections import defaultdict
from pathlib import Path
from claudedashboard.gitai.models import AuthorshipLog, PromptRecord


AGENT_TOOL_MAP = {
    "claude-code": "claude",
    "codex": "codex",
    "cursor": "cursor",
    "windsurf": "windsurf",
    "copilot": "copilot",
}


def load_proxy_events(path=None, since=None, repo_filter=None):
    """Load proxy events from JSONL file."""
    if path is None:
        path = Path.home() / ".claude" / "proxy_events.jsonl"
    path = Path(path)
    if not path.exists():
        return []
    events = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
            if since and ev.get("timestamp", 0) < since:
                continue
            if repo_filter and repo_filter not in ev.get("repo", ""):
                continue
            events.append(ev)
        except json.JSONDecodeError:
            continue
    return events


def match_events_to_prompts(proxy_events, log, commit_timestamp=0, time_window=600):
    """Match proxy events to prompt records by agent tool and timestamp."""
    result = defaultdict(list)

    for session_hash, prompt in log.prompts.items():
        agent_tool = AGENT_TOOL_MAP.get(prompt.agent_id.tool, prompt.agent_id.tool)
        for ev in proxy_events:
            ev_tool = ev.get("tool", "")
            ev_ts = ev.get("timestamp", 0)
            if agent_tool in ev_tool or ev_tool in agent_tool:
                if abs(ev_ts - commit_timestamp) <= time_window:
                    result[session_hash].append(ev)

    return dict(result)


def enrich_authorship_log(log, proxy_events, commit_timestamp=0, time_window=600):
    """Add cost/token data to AuthorshipLog prompt records."""
    if not proxy_events:
        return log

    matches = match_events_to_prompts(proxy_events, log, commit_timestamp, time_window)

    for session_hash, events in matches.items():
        if session_hash not in log.prompts:
            continue
        prompt = log.prompts[session_hash]
        total_cost = sum(ev.get("cost", 0) for ev in events)
        total_in = sum(ev.get("tokens_in", 0) for ev in events)
        total_out = sum(ev.get("tokens_out", 0) for ev in events)
        if total_cost > 0:
            if prompt.custom_attributes is None:
                prompt.custom_attributes = {}
            prompt.custom_attributes["cost_usd"] = str(round(total_cost, 6))
            prompt.custom_attributes["tokens_in"] = str(total_in)
            prompt.custom_attributes["tokens_out"] = str(total_out)
            prompt.custom_attributes["request_count"] = str(len(events))

    return log


def estimate_cost_per_line(prompt):
    """Simple cost-per-line estimation."""
    if not prompt or not prompt.custom_attributes:
        return None
    cost_str = prompt.custom_attributes.get("cost_usd")
    if not cost_str:
        return None
    try:
        total_cost = float(cost_str)
        total_lines = prompt.total_additions or 1
        return round(total_cost / total_lines, 4)
    except (ValueError, ZeroDivisionError):
        return None


def cost_summary(events, group_by="tool"):
    """Group proxy events and sum costs."""
    result = defaultdict(float)
    for ev in events:
        key = ev.get(group_by, "unknown")
        result[key] += ev.get("cost", 0)
    return dict(result)
