"""Hook entrypoint — reads stdin JSON, dispatches to checkpoint engine."""

import json, sys
from claudedashboard.gitai.models import NormalizedHookInput, HookEvent
from claudedashboard.gitai.checkpoint import CheckpointEngine
from claudedashboard.gitai.git_notes import get_repo_root

EVENT_MAP = {
    "PreToolUse": HookEvent.PRE_TOOL_USE,
    "PostToolUse": HookEvent.POST_TOOL_USE,
    "Stop": HookEvent.STOP,
    # Cursor camelCase
    "preToolUse": HookEvent.PRE_TOOL_USE,
    "postToolUse": HookEvent.POST_TOOL_USE,
}


def main(agent, hook_source="stdin"):
    """CLI entrypoint: claude-dashboard ai-checkpoint <agent> --hook-input stdin"""
    try:
        if hook_source == "stdin":
            raw = sys.stdin.read()
        else:
            raw = hook_source

        hook = parse_hook_input(agent, raw)
        if hook is None:
            return

        repo_root = get_repo_root(hook.cwd)
        if repo_root is None:
            return

        engine = CheckpointEngine(repo_root)

        if hook.event == HookEvent.PRE_TOOL_USE:
            engine.handle_pre_tool_use(hook)
        elif hook.event == HookEvent.POST_TOOL_USE:
            engine.handle_post_tool_use(hook)
        elif hook.event == HookEvent.STOP:
            pass  # Optional: finalize session

    except Exception as e:
        print(f"claude-dashboard ai-checkpoint error: {e}", file=sys.stderr)


def parse_hook_input(agent, raw_json):
    """Parse agent-specific JSON into NormalizedHookInput."""
    try:
        data = json.loads(raw_json)
    except (json.JSONDecodeError, TypeError):
        return None

    event_name = data.get("hook_event_name", "")
    event = EVENT_MAP.get(event_name)
    if event is None:
        return None

    if agent == "claude-code":
        return _parse_claude(data, event)
    elif agent == "codex":
        return _parse_codex(data, event)
    elif agent == "cursor":
        return _parse_cursor(data, event)
    elif agent == "windsurf":
        return _parse_windsurf(data, event)
    else:
        return _parse_generic(data, event, agent)


def _parse_claude(data, event):
    return NormalizedHookInput(
        event=event, agent="claude-code",
        session_id=data.get("session_id", ""),
        tool_name=data.get("tool_name", ""),
        tool_input=data.get("tool_input", {}),
        tool_use_id=data.get("tool_use_id", ""),
        cwd=data.get("cwd", ""),
        transcript_path=data.get("transcript_path"),
        model=data.get("model"),
    )


def _parse_codex(data, event):
    return NormalizedHookInput(
        event=event, agent="codex",
        session_id=data.get("session_id", ""),
        tool_name=data.get("tool_name", ""),
        tool_input=data.get("tool_input", {}),
        tool_use_id=data.get("tool_use_id", ""),
        cwd=data.get("cwd", ""),
        model=data.get("model"),
    )


def _parse_cursor(data, event):
    cwd = ""
    roots = data.get("workspace_roots", [])
    if roots:
        cwd = roots[0]
    return NormalizedHookInput(
        event=event, agent="cursor",
        session_id=data.get("conversation_id", ""),
        tool_name=data.get("tool_name", ""),
        tool_input=data.get("tool_input", {}),
        tool_use_id=data.get("tool_use_id", ""),
        cwd=cwd,
        model=data.get("model"),
    )


def _parse_windsurf(data, event):
    cwd = ""
    roots = data.get("workspace_roots", [])
    if roots:
        cwd = roots[0]
    return NormalizedHookInput(
        event=event, agent="windsurf",
        session_id=data.get("conversation_id", data.get("session_id", "")),
        tool_name=data.get("tool_name", ""),
        tool_input=data.get("tool_input", {}),
        tool_use_id=data.get("tool_use_id", ""),
        cwd=cwd,
        model=data.get("model"),
    )


def _parse_generic(data, event, agent):
    return NormalizedHookInput(
        event=event, agent=agent,
        session_id=data.get("session_id", data.get("conversation_id", "")),
        tool_name=data.get("tool_name", ""),
        tool_input=data.get("tool_input", {}),
        tool_use_id=data.get("tool_use_id", ""),
        cwd=data.get("cwd", ""),
        model=data.get("model"),
    )


def handle_git_hook(hook_type):
    """Handle git hooks (pre-commit, post-commit, post-rewrite)."""
    try:
        repo_root = get_repo_root(os.getcwd()) if 'os' in dir() else None
        import os
        repo_root = get_repo_root(os.getcwd())
        if not repo_root:
            return

        engine = CheckpointEngine(repo_root)

        if hook_type == "pre-commit":
            pass  # Optional: create human checkpoint
        elif hook_type == "post-commit":
            engine.handle_post_commit()
        elif hook_type == "post-rewrite":
            pass  # Task 15
    except Exception as e:
        print(f"claude-dashboard git hook error: {e}", file=sys.stderr)
