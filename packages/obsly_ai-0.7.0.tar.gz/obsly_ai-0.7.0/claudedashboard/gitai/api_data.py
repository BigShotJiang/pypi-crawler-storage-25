"""Data provider for dashboard APIs, SSE events, and menubar."""

from claudedashboard.gitai.stats import stats_for_commit, stats_for_repo
from claudedashboard.gitai.working_log import WorkingLog
from claudedashboard.gitai.git_notes import notes_read, get_head_sha
from claudedashboard.gitai.authorship_log import deserialize


def get_ai_summary(repo_root, limit=100):
    """API data for /api/ai/summary."""
    stats = stats_for_repo(repo_root, limit=limit)
    return {
        "total_commits_scanned": stats.total_commits_scanned,
        "commits_with_ai": stats.commits_with_ai,
        "overall_ai_percentage": stats.ai_percentage,
        "ai_lines": stats.ai_lines,
        "total_lines": stats.total_lines_added,
        "by_agent": stats.by_agent,
        "by_model": stats.by_model,
        "estimated_cost_usd": stats.estimated_total_cost_usd,
    }


def get_ai_commits(repo_root, limit=20):
    """API data for /api/ai/commits."""
    stats = stats_for_repo(repo_root, limit=limit)
    commits = []
    for cs in stats.commits:
        commits.append({
            "sha": cs.commit_sha[:7],
            "message": cs.message,
            "author": cs.author,
            "date": cs.date,
            "ai_lines": cs.ai_lines,
            "ai_percentage": cs.ai_percentage,
            "agents": list(cs.by_agent.keys()),
            "estimated_cost_usd": cs.estimated_cost_usd,
        })
    return {"commits": commits, "total": len(commits)}


def build_activity_event(repo_root):
    """Build SSE ai_activity event from working log (uncommitted data)."""
    wl = WorkingLog(repo_root)
    head = get_head_sha(repo_root)
    if not head:
        return None

    # Check all base commits
    base_commits = wl.list_base_commits()
    if not base_commits:
        return None

    total_ai_lines = 0
    files = []

    for base in base_commits:
        stats = wl.uncommitted_stats(base)
        if stats["ai_checkpoints"] == 0:
            continue
        total_ai_lines += stats["total_ai_lines"]
        for f in stats["files_touched"]:
            files.append({"path": f, "ai_lines": stats["total_ai_lines"]})

    if total_ai_lines == 0:
        return None

    return {
        "type": "ai_activity",
        "data": {
            "active": True,
            "total_ai_lines_uncommitted": total_ai_lines,
            "files": files,
        },
    }


def build_commit_event(repo_root, commit_sha):
    """Build SSE ai_commit event from a committed git note."""
    cs = stats_for_commit(repo_root, commit_sha)
    if cs is None:
        return None
    return {
        "type": "ai_commit",
        "data": {
            "sha": cs.commit_sha[:7],
            "message": cs.message,
            "ai_lines": cs.ai_lines,
            "ai_percentage": cs.ai_percentage,
            "agents": list(cs.by_agent.keys()),
            "estimated_cost_usd": cs.estimated_cost_usd,
        },
    }


def get_menubar_stats(repo_root):
    """Get stats for menubar display."""
    head = get_head_sha(repo_root)
    if not head:
        return None

    cs = stats_for_commit(repo_root, head)
    if cs is None:
        return None

    return {
        "last_commit_ai_pct": cs.ai_percentage,
        "last_commit_ai_lines": cs.ai_lines,
        "last_commit_agents": list(cs.by_agent.keys()),
        "estimated_cost_usd": cs.estimated_cost_usd,
    }
