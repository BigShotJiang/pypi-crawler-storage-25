"""Diff-based line attribution engine."""

import difflib
from claudedashboard.gitai.models import LineAttribution

INITIAL_AUTHOR = "__initial__"


def compute_attributions(old_content, new_content, author_id, previous_attributions):
    """Compute new line attributions after a file edit using difflib."""
    if old_content == new_content:
        return list(previous_attributions)

    old_lines = old_content.splitlines(True)
    new_lines = new_content.splitlines(True)

    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)
    result = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            # Copy previous attributions for these lines
            for old_idx in range(i1, i2):
                new_line = j1 + (old_idx - i1) + 1  # 1-indexed
                owner = _lookup_owner(old_idx + 1, previous_attributions)
                result.append(LineAttribution(new_line, new_line, owner or INITIAL_AUTHOR, None))

        elif tag == "insert":
            # New lines attributed to the AI agent
            for new_idx in range(j1, j2):
                result.append(LineAttribution(new_idx + 1, new_idx + 1, author_id, None))

        elif tag == "replace":
            # Old lines replaced — attribute to AI, record who was overridden
            prev_owner = _lookup_owner(i1 + 1, previous_attributions)
            for new_idx in range(j1, j2):
                result.append(LineAttribution(new_idx + 1, new_idx + 1, author_id, prev_owner))

        elif tag == "delete":
            # Lines removed — nothing to add to new file
            pass

    return merge_adjacent(result)


def initial_attributions(content):
    """All lines attributed to INITIAL_AUTHOR (human baseline)."""
    if not content:
        return []
    num_lines = len(content.splitlines())
    if num_lines == 0:
        return []
    return [LineAttribution(1, num_lines, INITIAL_AUTHOR, None)]


def attributions_for_new_file(content, author_id):
    """All lines of a brand-new file attributed to author_id."""
    if not content:
        return []
    num_lines = len(content.splitlines())
    if num_lines == 0:
        return []
    return [LineAttribution(1, num_lines, author_id, None)]


def merge_adjacent(attrs):
    """Merge consecutive LineAttributions with same author_id and overrode."""
    if not attrs:
        return []
    result = [attrs[0]]
    for la in attrs[1:]:
        prev = result[-1]
        if (la.author_id == prev.author_id
                and la.overrode == prev.overrode
                and la.start_line == prev.end_line + 1):
            result[-1] = LineAttribution(prev.start_line, la.end_line, prev.author_id, prev.overrode)
        else:
            result.append(la)
    return result


def _lookup_owner(line_num, previous_attributions):
    """Find who owned a specific line in the previous version."""
    for la in previous_attributions:
        if la.start_line <= line_num <= la.end_line:
            return la.author_id
    return None


def count_ai_lines(attrs):
    """Count total lines attributed to any non-INITIAL author."""
    return sum(la.line_count() for la in attrs if la.author_id != INITIAL_AUTHOR)


def count_human_lines(attrs):
    """Count total lines attributed to INITIAL_AUTHOR."""
    return sum(la.line_count() for la in attrs if la.author_id == INITIAL_AUTHOR)
