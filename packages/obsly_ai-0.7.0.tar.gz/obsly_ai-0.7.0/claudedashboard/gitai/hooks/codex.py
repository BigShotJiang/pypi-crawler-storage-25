"""Codex hook installer — writes to ~/.codex/hooks.json."""

import json
from pathlib import Path
from claudedashboard.gitai.hooks.base import HookInstaller

MARKER = "ai-checkpoint codex"
EVENTS = ["PreToolUse", "PostToolUse", "Stop"]


class CodexInstaller(HookInstaller):

    def __init__(self, config_dir=None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".codex"
        self.hooks_path = self.config_dir / "hooks.json"

    def name(self):
        return "Codex"

    def agent_id(self):
        return "codex"

    def check(self):
        detected = self.config_dir.exists()
        if not detected:
            return (False, False, False)
        if not self.hooks_path.exists():
            return (True, False, False)
        data = json.loads(self.hooks_path.read_text())
        installed = any(
            any(MARKER in h.get("command", "") for h in data.get("hooks", {}).get(ev, []))
            for ev in EVENTS
        )
        return (True, installed, installed)

    def install(self, binary_path, dry_run=False):
        self.config_dir.mkdir(parents=True, exist_ok=True)
        if self.hooks_path.exists():
            data = json.loads(self.hooks_path.read_text())
        else:
            data = {}

        cmd = f"{binary_path} ai-checkpoint codex --hook-input stdin"
        hooks = data.get("hooks", {})
        changed = False

        for event in EVENTS:
            entries = hooks.get(event, [])
            if not any(MARKER in h.get("command", "") for h in entries):
                entries.append({"command": cmd})
                changed = True
            hooks[event] = entries

        if not changed:
            return None

        data["hooks"] = hooks
        if not dry_run:
            self.hooks_path.write_text(json.dumps(data, indent=2))
        return "installed"

    def uninstall(self, dry_run=False):
        if not self.hooks_path.exists():
            return None
        data = json.loads(self.hooks_path.read_text())
        changed = False
        for event in EVENTS:
            entries = data.get("hooks", {}).get(event, [])
            filtered = [h for h in entries if MARKER not in h.get("command", "")]
            if len(filtered) != len(entries):
                changed = True
            data["hooks"][event] = filtered
        if not changed:
            return None
        if not dry_run:
            self.hooks_path.write_text(json.dumps(data, indent=2))
        return "uninstalled"
