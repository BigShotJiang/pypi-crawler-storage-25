"""Claude Code hook installer — writes to ~/.claude/settings.json."""

import json
from pathlib import Path
from claudedashboard.gitai.hooks.base import HookInstaller

MARKER = "ai-checkpoint claude-code"
PROMPT_COST_MARKER = "prompt-cost-warning"


class ClaudeCodeInstaller(HookInstaller):

    def __init__(self, config_dir=None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".claude"
        self.settings_path = self.config_dir / "settings.json"

    def name(self):
        return "Claude Code"

    def agent_id(self):
        return "claude-code"

    def check(self):
        detected = self.config_dir.exists()
        if not detected:
            return (False, False, False)
        if not self.settings_path.exists():
            return (True, False, False)
        data = json.loads(self.settings_path.read_text())
        installed = self._has_our_hooks(data) and self._has_prompt_cost_hook(data)
        return (True, installed, installed)

    def install(self, binary_path, dry_run=False):
        self.config_dir.mkdir(parents=True, exist_ok=True)
        if self.settings_path.exists():
            data = json.loads(self.settings_path.read_text())
        else:
            data = {}

        if self._has_our_hooks(data) and self._has_prompt_cost_hook(data):
            return None  # Already fully installed

        if "hooks" not in data:
            data["hooks"] = {}

        cmd = f"{binary_path} ai-checkpoint claude-code --hook-input stdin"

        for event in ("PreToolUse", "PostToolUse"):
            blocks = data["hooks"].get(event, [])

            # Find or create catch-all block
            catch_all = None
            for block in blocks:
                if block.get("matcher") == "*":
                    catch_all = block
                    break

            if catch_all is None:
                catch_all = {"matcher": "*", "hooks": []}
                blocks.append(catch_all)

            # Add our hook if not present
            if not any(MARKER in h.get("command", "") for h in catch_all.get("hooks", [])):
                catch_all.setdefault("hooks", []).append({"type": "command", "command": cmd})

            data["hooks"][event] = blocks

        # 0.7.0 #1 (issue #45) — UserPromptSubmit hook for the real-time
        # prompt cost warning. Different command than the checkpoint hook
        # so it can be uninstalled / iterated independently.
        prompt_cmd = f"{binary_path} prompt-cost-warning"
        prompt_blocks = data["hooks"].get("UserPromptSubmit", [])
        if not any(
            PROMPT_COST_MARKER in h.get("command", "")
            for block in prompt_blocks
            for h in block.get("hooks", [])
        ):
            prompt_blocks.append({"hooks": [{"type": "command", "command": prompt_cmd}]})
            data["hooks"]["UserPromptSubmit"] = prompt_blocks

        if not dry_run:
            self.settings_path.write_text(json.dumps(data, indent=2))
        return "installed"

    def uninstall(self, dry_run=False):
        if not self.settings_path.exists():
            return None
        data = json.loads(self.settings_path.read_text())
        if not self._has_our_hooks(data) and not self._has_prompt_cost_hook(data):
            return None

        for event in ("PreToolUse", "PostToolUse"):
            blocks = data.get("hooks", {}).get(event, [])
            for block in blocks:
                hooks = block.get("hooks", [])
                block["hooks"] = [h for h in hooks if MARKER not in h.get("command", "")]
            # Remove empty catch-all blocks we created
            data["hooks"][event] = [b for b in blocks if b.get("hooks") or b.get("matcher") != "*"]

        # Strip the UserPromptSubmit hook we added (issue #45).
        prompt_blocks = data.get("hooks", {}).get("UserPromptSubmit", [])
        cleaned = []
        for block in prompt_blocks:
            hooks = block.get("hooks", [])
            kept = [h for h in hooks if PROMPT_COST_MARKER not in h.get("command", "")]
            if kept:
                block["hooks"] = kept
                cleaned.append(block)
            elif "matcher" in block and block.get("matcher") != "*":
                # Preserve matcher blocks the user added themselves.
                cleaned.append(block)
        if cleaned:
            data["hooks"]["UserPromptSubmit"] = cleaned
        else:
            data.get("hooks", {}).pop("UserPromptSubmit", None)

        if not dry_run:
            self.settings_path.write_text(json.dumps(data, indent=2))
        return "uninstalled"

    def _has_our_hooks(self, data):
        for event in ("PreToolUse", "PostToolUse"):
            for block in data.get("hooks", {}).get(event, []):
                for h in block.get("hooks", []):
                    if MARKER in h.get("command", ""):
                        return True
        return False

    def _has_prompt_cost_hook(self, data):
        for block in data.get("hooks", {}).get("UserPromptSubmit", []):
            for h in block.get("hooks", []):
                if PROMPT_COST_MARKER in h.get("command", ""):
                    return True
        return False
