"""Hook installers for AI coding agents."""
