"""Base class for hook installers."""

from abc import ABC, abstractmethod


class HookInstaller(ABC):

    @abstractmethod
    def name(self):
        """Human-readable name."""

    @abstractmethod
    def agent_id(self):
        """CLI identifier."""

    @abstractmethod
    def check(self):
        """Returns (tool_detected, hooks_installed, hooks_up_to_date)."""

    @abstractmethod
    def install(self, binary_path, dry_run=False):
        """Install hooks. Returns diff string or None if already installed."""

    @abstractmethod
    def uninstall(self, dry_run=False):
        """Uninstall hooks. Returns diff string or None."""
