"""Git hooks installer — pre-commit, post-commit, post-rewrite."""

import os, stat
from pathlib import Path

START_MARKER = "# --- claude-dashboard ai-attribution ---"
END_MARKER = "# --- end claude-dashboard ---"

HOOK_CONFIGS = {
    "pre-commit": "ai-checkpoint --pre-commit",
    "post-commit": "ai-checkpoint --post-commit",
    "post-rewrite": "ai-checkpoint --post-rewrite",
}


class GitHooksInstaller:

    def install(self, repo_root, binary_path, dry_run=False):
        """Install git hooks. Preserves existing hook content."""
        hooks_dir = Path(repo_root) / ".git" / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        results = {}

        for hook_name, cmd_suffix in HOOK_CONFIGS.items():
            path = hooks_dir / hook_name
            our_block = _make_block(binary_path, cmd_suffix)

            if path.exists():
                content = path.read_text()
                if START_MARKER in content:
                    results[hook_name] = "already installed"
                    continue
                # Append to existing
                content = content.rstrip("\n") + "\n\n" + our_block + "\n"
            else:
                content = "#!/bin/sh\n" + our_block + "\n"

            if not dry_run:
                path.write_text(content)
                path.chmod(path.stat().st_mode | stat.S_IEXEC)
            results[hook_name] = "installed"

        return results

    def uninstall(self, repo_root, dry_run=False):
        """Remove our blocks from git hooks."""
        hooks_dir = Path(repo_root) / ".git" / "hooks"
        results = {}

        for hook_name in HOOK_CONFIGS:
            path = hooks_dir / hook_name
            if not path.exists():
                results[hook_name] = "not found"
                continue

            content = path.read_text()
            if START_MARKER not in content:
                results[hook_name] = "not installed"
                continue

            # Remove our block
            lines = content.split("\n")
            new_lines = []
            skip = False
            for line in lines:
                if line.strip() == START_MARKER:
                    skip = True
                    continue
                if line.strip() == END_MARKER:
                    skip = False
                    continue
                if not skip:
                    new_lines.append(line)

            new_content = "\n".join(new_lines).strip()
            if not dry_run:
                if new_content and new_content != "#!/bin/sh":
                    path.write_text(new_content + "\n")
                else:
                    path.unlink()
            results[hook_name] = "uninstalled"

        return results

    def check(self, repo_root):
        """Check which hooks are installed."""
        hooks_dir = Path(repo_root) / ".git" / "hooks"
        results = {}
        for hook_name in HOOK_CONFIGS:
            path = hooks_dir / hook_name
            if path.exists() and START_MARKER in path.read_text():
                results[hook_name] = True
            else:
                results[hook_name] = False
        return results


def _make_block(binary_path, cmd_suffix):
    return f"""{START_MARKER}
{binary_path} {cmd_suffix} 2>/dev/null || true
{END_MARKER}"""
