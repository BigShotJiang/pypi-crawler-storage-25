"""GitHub Copilot CLI hook installer — writes to ~/.copilot/hooks.json."""

import json
from pathlib import Path
from claudedashboard.gitai.hooks.base import HookInstaller

MARKER = "ai-checkpoint copilot-cli"
EVENTS = ["preToolUse", "postToolUse", "sessionEnd"]


class CopilotCliInstaller(HookInstaller):

    def __init__(self, config_dir=None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".copilot"
        self.hooks_path = self.config_dir / "hooks.json"

    def name(self):
        return "Copilot CLI"

    def agent_id(self):
        return "copilot-cli"

    def check(self):
        detected = self.config_dir.exists()
        if not detected:
            return (False, False, False)
        if not self.hooks_path.exists():
            return (True, False, False)
        try:
            data = json.loads(self.hooks_path.read_text())
        except (json.JSONDecodeError, OSError):
            return (True, False, False)
        installed = any(
            any(MARKER in h.get("bash", "") for h in data.get("hooks", {}).get(ev, []))
            for ev in EVENTS
        )
        return (True, installed, installed)

    def install(self, binary_path, dry_run=False):
        if self.hooks_path.exists():
            try:
                data = json.loads(self.hooks_path.read_text())
            except (json.JSONDecodeError, OSError):
                data = {}
        else:
            data = {}

        data.setdefault("version", 1)
        hooks = data.get("hooks", {})

        cmd = f"{binary_path} ai-checkpoint copilot-cli --hook-input stdin"
        changed = False

        for event in EVENTS:
            entries = hooks.get(event, [])
            if not any(MARKER in h.get("bash", "") for h in entries):
                entries.append({
                    "type": "command",
                    "bash": cmd,
                    "timeoutSec": 30,
                })
                changed = True
            hooks[event] = entries

        if not changed:
            return None

        data["hooks"] = hooks
        if not dry_run:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self.hooks_path.write_text(json.dumps(data, indent=2))
        return "installed"

    def uninstall(self, dry_run=False):
        if not self.hooks_path.exists():
            return None
        try:
            data = json.loads(self.hooks_path.read_text())
        except (json.JSONDecodeError, OSError):
            return None
        hooks = data.get("hooks", {})
        changed = False
        for event in EVENTS:
            entries = hooks.get(event, [])
            filtered = [h for h in entries if MARKER not in h.get("bash", "")]
            if len(filtered) != len(entries):
                changed = True
            hooks[event] = filtered
        if not changed:
            return None
        data["hooks"] = hooks
        if not dry_run:
            self.hooks_path.write_text(json.dumps(data, indent=2))
        return "uninstalled"
