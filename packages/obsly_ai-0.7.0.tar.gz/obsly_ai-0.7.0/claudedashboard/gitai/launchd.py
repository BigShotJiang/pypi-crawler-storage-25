"""Shared launchd LaunchAgent installer for managed background services."""

import os, plistlib, re, subprocess, tempfile
from pathlib import Path


_NAME_RE = re.compile(r"^[a-zA-Z0-9._-]+$")


def _label(name):
    """Return 'io.obsly.<name>' after validating name."""
    if not name or not _NAME_RE.match(name):
        raise ValueError(f"invalid launchd name: {name!r}")
    return f"io.obsly.{name}"


def _uid():
    """Return current user UID as int."""
    return os.getuid()


def _launch_agents_dir():
    return Path.home() / "Library" / "LaunchAgents"


def plist_path(name):
    """Return the absolute Path to ~/Library/LaunchAgents/io.obsly.<name>.plist."""
    label = _label(name)
    return _launch_agents_dir() / f"{label}.plist"


def write_plist(name, program_args, *, keep_alive=True, run_at_load=True,
                stderr_path=None, stdout_path=None, working_dir=None, env=None):
    """Write the plist for the agent. Creates parent dir if needed. Idempotent."""
    label = _label(name)
    data = {
        "Label": label,
        "ProgramArguments": list(program_args),
        "KeepAlive": bool(keep_alive),
        "RunAtLoad": bool(run_at_load),
    }
    if stderr_path is not None:
        data["StandardErrorPath"] = stderr_path
    if stdout_path is not None:
        data["StandardOutPath"] = stdout_path
    if working_dir is not None:
        data["WorkingDirectory"] = working_dir
    if env is not None:
        data["EnvironmentVariables"] = dict(env)

    payload = plistlib.dumps(data, fmt=plistlib.FMT_XML)
    target = plist_path(name)
    target.parent.mkdir(parents=True, exist_ok=True)

    if target.exists() and target.read_bytes() == payload:
        return target

    fd, tmp = tempfile.mkstemp(prefix=f".{label}.", suffix=".plist", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return target


def bootstrap(name):
    """launchctl bootstrap the agent. Returns (ok, stderr_text)."""
    target = plist_path(name)
    try:
        result = subprocess.run(
            ["launchctl", "bootstrap", f"gui/{_uid()}", str(target)],
            capture_output=True, text=True, timeout=10,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
        return (False, str(e))
    if result.returncode == 0:
        return (True, result.stderr or "")
    stderr = result.stderr or ""
    if "already bootstrapped" in stderr or "already loaded" in stderr:
        return (True, stderr)
    return (False, stderr)


def bootout(name):
    """launchctl bootout the agent. Returns (ok, stderr_text)."""
    label = _label(name)
    try:
        result = subprocess.run(
            ["launchctl", "bootout", f"gui/{_uid()}/{label}"],
            capture_output=True, text=True, timeout=10,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
        return (False, str(e))
    if result.returncode == 0:
        return (True, result.stderr or "")
    stderr = result.stderr or ""
    if "Could not find specified service" in stderr or "not loaded" in stderr:
        return (True, stderr)
    return (False, stderr)


def status(name):
    """Return 'running', 'stopped', or 'not_installed'."""
    target = plist_path(name)
    if not target.exists():
        return "not_installed"
    label = _label(name)
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{_uid()}/{label}"],
            capture_output=True, text=True, timeout=10,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return "stopped"
    if result.returncode != 0:
        return "stopped"
    if "state = running" in (result.stdout or ""):
        return "running"
    return "stopped"


def uninstall(name):
    """Bootout (best-effort) and delete the plist file."""
    target = plist_path(name)
    existed = target.exists()
    bootout(name)
    if existed:
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        return True
    return False
