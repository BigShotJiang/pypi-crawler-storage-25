"""AI code durability — track survival of AI-generated lines over time."""

import subprocess
from collections import defaultdict
from claudedashboard.gitai.models import DurabilityRecord
from claudedashboard.gitai.authorship_log import deserialize
from claudedashboard.gitai.git_notes import notes_read, get_head_sha, get_file_at_commit


def analyze_durability(repo_root, limit=50):
    """Trace AI-authored lines forward to HEAD and measure survival."""
    head = get_head_sha(repo_root)
    if not head:
        return []

    # Get recent commits
    try:
        result = subprocess.run(
            ["git", "log", f"--max-count={limit}", "--format=%H"],
            cwd=repo_root, capture_output=True, text=True, timeout=10,
        )
        shas = [s.strip() for s in result.stdout.strip().split("\n") if s.strip()]
    except Exception:
        return []

    # Collect AI attributions from all commits with notes
    session_data = {}  # session_hash -> {agent, model, files: {file: set(lines)}}

    for sha in shas:
        note = notes_read(repo_root, sha)
        if not note:
            continue
        log = deserialize(note)
        for fa in log.attestations:
            for entry in fa.entries:
                prompt = log.prompts.get(entry.session_hash)
                if not prompt:
                    continue
                if entry.session_hash not in session_data:
                    session_data[entry.session_hash] = {
                        "agent": prompt.agent_id.tool,
                        "model": prompt.agent_id.model,
                        "files": defaultdict(set),
                        "commit": sha,
                    }
                for lr in entry.line_ranges:
                    for line_num in range(lr.start, lr.end + 1):
                        session_data[entry.session_hash]["files"][fa.file_path].add(line_num)

    # For each session, check how many lines survive at HEAD
    records = []
    for session_hash, data in session_data.items():
        total_authored = sum(len(lines) for lines in data["files"].values())
        surviving = 0
        modified = 0
        deleted = 0

        for file_path, original_lines in data["files"].items():
            # Get file content at original commit and HEAD
            old_content = get_file_at_commit(repo_root, data["commit"], file_path)
            new_content = get_file_at_commit(repo_root, head, file_path)

            if old_content is None or new_content is None:
                # File was deleted
                deleted += len(original_lines)
                continue

            old_lines = old_content.splitlines()
            new_lines = new_content.splitlines()

            for line_num in original_lines:
                if line_num <= len(old_lines):
                    original_text = old_lines[line_num - 1]
                    if original_text in new_lines:
                        surviving += 1
                    else:
                        # Line changed or removed
                        modified += 1
                else:
                    deleted += 1

        # Anything not surviving or modified is deleted
        accounted = surviving + modified
        deleted = max(0, total_authored - accounted)

        rate = surviving / total_authored if total_authored > 0 else 0.0
        commits_since = shas.index(data["commit"]) if data["commit"] in shas else 0

        records.append(DurabilityRecord(
            session_hash=session_hash,
            agent=data["agent"],
            model=data["model"],
            lines_authored=total_authored,
            lines_surviving=surviving,
            lines_modified=modified,
            lines_deleted=deleted,
            survival_rate=round(rate, 3),
            commits_since=commits_since,
        ))

    return records


def durability_by_agent(records):
    """Aggregate durability by agent."""
    agents = defaultdict(lambda: {"total_authored": 0, "surviving": 0, "modified": 0, "deleted": 0})
    for r in records:
        a = agents[r.agent]
        a["total_authored"] += r.lines_authored
        a["surviving"] += r.lines_surviving
        a["modified"] += r.lines_modified
        a["deleted"] += r.lines_deleted

    result = {}
    for agent, data in agents.items():
        total = data["total_authored"]
        data["survival_rate"] = round(data["surviving"] / total, 3) if total > 0 else 0.0
        result[agent] = data
    return result


def format_durability_terminal(by_agent):
    """Terminal output for durability stats."""
    lines = ["AI Code Durability", ""]
    for agent, data in sorted(by_agent.items()):
        rate = data.get("survival_rate", 0)
        total = data.get("total_authored", 0)
        pct = int(rate * 100)
        bar_filled = int(rate * 20)
        bar = "█" * bar_filled + "░" * (20 - bar_filled)
        lines.append(f"  {agent:<15} {pct}% survival  {bar}  {total} lines")
    return "\n".join(lines)
