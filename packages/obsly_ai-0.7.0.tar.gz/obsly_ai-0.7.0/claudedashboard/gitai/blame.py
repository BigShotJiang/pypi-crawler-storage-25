"""AI blame — per-line attribution with cost estimates."""

import json
from claudedashboard.gitai.models import BlameLine
from claudedashboard.gitai.authorship_log import deserialize
from claudedashboard.gitai.git_notes import notes_read, get_head_sha, get_file_at_commit, blame_origin

AGENT_COLORS = {
    "claude-code": "\033[35m",
    "codex": "\033[32m",
    "cursor": "\033[34m",
    "copilot": "\033[36m",
    "windsurf": "\033[33m",
    "human": "\033[37m",
}
RESET = "\033[0m"


def blame(repo_root, file_path, commit="HEAD", start_line=None, end_line=None):
    """Core blame: read git note, map lines to agents."""
    # Resolve commit
    if commit == "HEAD":
        sha = get_head_sha(repo_root)
    else:
        sha = commit
    if not sha:
        return []

    # Read file content
    content = get_file_at_commit(repo_root, sha, file_path)
    if content is None:
        return []

    file_lines = content.splitlines()
    if not file_lines:
        return []

    # Resolve each current line to its origin (commit, orig_line) via git blame,
    # then look up the AI note for that origin commit. This way AI attributions
    # from past commits survive subsequent human-only commits.
    origins = blame_origin(repo_root, sha, file_path)
    note_cache = {}  # origin_sha -> (origin_line -> (agent, model, session_hash, prompt))

    def _line_map_for(origin_sha):
        if origin_sha in note_cache:
            return note_cache[origin_sha]
        lm = {}
        note = notes_read(repo_root, origin_sha)
        if note:
            log = deserialize(note)
            for fa in log.attestations:
                if fa.file_path != file_path:
                    continue
                for entry in fa.entries:
                    prompt = log.prompts.get(entry.session_hash)
                    for lr in entry.line_ranges:
                        for line_num in range(lr.start, lr.end + 1):
                            agent = prompt.agent_id.tool if prompt else "unknown"
                            model = prompt.agent_id.model if prompt else ""
                            lm[line_num] = (agent, model, entry.session_hash, prompt)
        note_cache[origin_sha] = lm
        return lm

    line_map = {}  # current line_number -> (agent, model, session_hash, prompt)
    for i, (origin_sha, origin_line) in enumerate(origins):
        lm = _line_map_for(origin_sha)
        if origin_line in lm:
            line_map[i + 1] = lm[origin_line]

    # Build result
    result = []
    for i, line_content in enumerate(file_lines):
        line_num = i + 1
        if line_num in line_map:
            agent, model, session_hash, prompt = line_map[line_num]
            cost = _estimate_line_cost(prompt) if prompt else None
            result.append(BlameLine(line_num, line_content, agent, model, session_hash, cost))
        else:
            result.append(BlameLine(line_num, line_content, "human", "", "", None))

    # Apply range filter
    if start_line is not None or end_line is not None:
        s = (start_line or 1) - 1
        e = end_line or len(result)
        result = result[s:e]

    return result


def _estimate_line_cost(prompt):
    """Estimate cost per line from prompt's custom_attributes."""
    if not prompt or not prompt.custom_attributes:
        return None
    cost_str = prompt.custom_attributes.get("cost_usd")
    if not cost_str:
        return None
    try:
        total_cost = float(cost_str)
        total_lines = prompt.total_additions or 1
        return round(total_cost / total_lines, 4)
    except (ValueError, ZeroDivisionError):
        return None


def format_terminal(lines, file_path, commit, show_cost=False, no_color=False):
    """Terminal output with ANSI colors."""
    out = [f"{file_path} ({commit[:7] if len(commit) > 7 else commit})"]
    max_agent_len = max((len(l.agent) for l in lines), default=5)

    for l in lines:
        color = "" if no_color else AGENT_COLORS.get(l.agent, AGENT_COLORS["human"])
        reset = "" if no_color else RESET
        cost_str = f"  ${l.cost_usd:.3f}" if show_cost and l.cost_usd else ""
        out.append(f"  {l.line_number:>4} {color}{l.agent:<{max_agent_len}}{reset} {l.content}{cost_str}")

    # Summary
    total = len(lines)
    ai = sum(1 for l in lines if l.agent != "human")
    pct = (ai / total * 100) if total else 0
    agents = {}
    for l in lines:
        if l.agent != "human":
            agents[l.agent] = agents.get(l.agent, 0) + 1
    agent_str = " | ".join(f"{a}: {c}" for a, c in sorted(agents.items()))
    out.append(f"\n  {ai}/{total} lines AI ({pct:.1f}%) | {agent_str}")

    return "\n".join(out)


def format_json(lines, file_path, commit):
    """JSON output."""
    total = len(lines)
    ai = sum(1 for l in lines if l.agent != "human")
    pct = (ai / total * 100) if total else 0
    agents = {}
    for l in lines:
        if l.agent != "human":
            agents[l.agent] = agents.get(l.agent, 0) + 1
    total_cost = sum(l.cost_usd for l in lines if l.cost_usd)

    data = {
        "file": file_path,
        "commit": commit,
        "lines": [
            {
                "line": l.line_number, "content": l.content,
                "agent": l.agent, "model": l.model,
                "session_hash": l.session_hash, "cost_usd": l.cost_usd,
            }
            for l in lines
        ],
        "summary": {
            "total_lines": total,
            "ai_lines": ai,
            "ai_percentage": round(pct, 1),
            "by_agent": agents,
            "estimated_cost_usd": round(total_cost, 4) if total_cost else None,
        },
    }
    return json.dumps(data, indent=2)


def format_compact(lines):
    """One-liner summary."""
    total = len(lines)
    ai = sum(1 for l in lines if l.agent != "human")
    pct = (ai / total * 100) if total else 0
    agents = {}
    for l in lines:
        if l.agent != "human":
            agents[l.agent] = agents.get(l.agent, 0) + 1
    agent_str = ", ".join(f"{a}: {c}" for a, c in sorted(agents.items()))
    return f"{pct:.0f}% AI ({ai}/{total} lines) [{agent_str}]"
