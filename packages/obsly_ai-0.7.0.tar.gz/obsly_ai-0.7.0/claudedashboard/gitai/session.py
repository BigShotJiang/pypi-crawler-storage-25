"""Session hash generation and file hashing."""

import hashlib


def generate_session_hash(tool, conversation_id):
    """SHA-256 of '{tool}:{conversation_id}', first 16 hex chars."""
    combined = f"{tool}:{conversation_id}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:16]


def compute_file_hash(content):
    """SHA-256 hex digest of file content bytes."""
    return hashlib.sha256(content).hexdigest()
