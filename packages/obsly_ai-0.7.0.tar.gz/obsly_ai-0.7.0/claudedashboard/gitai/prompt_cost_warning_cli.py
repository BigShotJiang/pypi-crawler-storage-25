"""CLI entry for the real-time prompt cost warning hook (issue #45).

Wired into Claude Code via a ``UserPromptSubmit`` hook in
``~/.claude/settings.json``. Reads the hook input JSON on stdin,
extracts the ``transcript_path``, computes session metrics, and
prints a warning to stderr if any threshold is crossed.

ALWAYS exits 0. The agent must never be blocked by this hook —
errors are swallowed silently and produce no output.
"""

import json
import sys

from claudedashboard.gitai.prompt_cost_warning import (
    Thresholds,
    compute_session_metrics,
    format_warning,
    should_warn,
)


def main(argv=None, stdin=None, stderr=None):
    """Run the warning hook. Returns the exit code (always 0)."""
    stdin = stdin if stdin is not None else sys.stdin
    stderr = stderr if stderr is not None else sys.stderr

    try:
        raw = stdin.read()
    except Exception:
        return 0

    if not raw:
        return 0

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return 0

    if not isinstance(data, dict):
        return 0

    transcript_path = data.get("transcript_path")
    if not transcript_path:
        return 0

    try:
        metrics = compute_session_metrics(transcript_path)
    except Exception:
        return 0

    if metrics is None:
        return 0

    try:
        thresholds = Thresholds.from_config_file()
    except Exception:
        thresholds = Thresholds()

    warning = should_warn(metrics, thresholds)
    if warning is None:
        return 0

    try:
        text = format_warning(warning, metrics)
        print(text, file=stderr)
    except Exception:
        pass

    return 0


if __name__ == "__main__":
    sys.exit(main())
