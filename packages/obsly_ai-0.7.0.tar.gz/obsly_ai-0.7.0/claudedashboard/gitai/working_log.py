"""Manages .git/ai/ storage for checkpoints and snapshots."""

import fcntl, json, os, time
from pathlib import Path
from claudedashboard.gitai.models import Checkpoint, CheckpointKind


class WorkingLog:
    """Manages .git/ai/ directory inside a git repository."""

    def __init__(self, repo_root):
        self.repo_root = Path(repo_root)
        self.ai_dir = self._find_git_dir() / "ai"
        self.logs_dir = self.ai_dir / "working_logs"
        self.snapshots_dir = self.ai_dir / "snapshots"

    def _find_git_dir(self):
        """Find .git directory. Handles worktrees where .git is a file."""
        git_path = self.repo_root / ".git"
        if git_path.is_file():
            # Worktree: .git is a file containing "gitdir: /path/to/real/.git/worktrees/name"
            text = git_path.read_text().strip()
            if text.startswith("gitdir: "):
                return Path(text[8:])
        return git_path

    def ensure_dirs(self):
        """Create .git/ai/ subdirectories if they don't exist."""
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)

    # ── Checkpoint CRUD ──────────────────────────────────────────────

    def append_checkpoint(self, base_commit, checkpoint):
        """Append checkpoint as one JSON line to working_logs/{base_commit}.jsonl."""
        self.ensure_dirs()
        path = self.logs_dir / f"{base_commit}.jsonl"
        data = json.dumps(checkpoint.to_dict())
        self._append_with_lock(path, data)

    def read_checkpoints(self, base_commit):
        """Read all checkpoints for a base commit."""
        path = self.logs_dir / f"{base_commit}.jsonl"
        if not path.exists():
            return []
        result = []
        for line in path.read_text().splitlines():
            line = line.strip()
            if line:
                result.append(Checkpoint.from_dict(json.loads(line)))
        return result

    def delete_log(self, base_commit):
        """Remove working log file for a base commit."""
        path = self.logs_dir / f"{base_commit}.jsonl"
        if path.exists():
            path.unlink()

    def list_base_commits(self):
        """List all base commits that have working logs."""
        if not self.logs_dir.exists():
            return []
        return [p.stem for p in self.logs_dir.glob("*.jsonl")]

    # ── Snapshot CRUD ────────────────────────────────────────────────

    def save_snapshot(self, tool_use_id, files):
        """Save pre-edit file contents as JSON."""
        self.ensure_dirs()
        path = self.snapshots_dir / f"{tool_use_id}.json"
        data = {"tool_use_id": tool_use_id, "timestamp_ms": int(time.time() * 1000), "files": files}
        path.write_text(json.dumps(data))

    def load_snapshot(self, tool_use_id):
        """Load pre-edit snapshot. Returns file dict or None."""
        path = self.snapshots_dir / f"{tool_use_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return data.get("files")

    def delete_snapshot(self, tool_use_id):
        """Remove snapshot file."""
        path = self.snapshots_dir / f"{tool_use_id}.json"
        if path.exists():
            path.unlink()

    # ── Cleanup ──────────────────────────────────────────────────────

    def cleanup_stale_snapshots(self, max_age_seconds=3600):
        """Remove snapshot files older than max_age_seconds. Returns count."""
        if not self.snapshots_dir.exists():
            return 0
        now = time.time()
        removed = 0
        for path in self.snapshots_dir.glob("*.json"):
            if now - path.stat().st_mtime > max_age_seconds:
                path.unlink()
                removed += 1
        return removed

    def cleanup_orphaned_logs(self, valid_commits):
        """Remove working logs whose base_commit is not in valid_commits."""
        if not self.logs_dir.exists():
            return 0
        valid = set(valid_commits)
        removed = 0
        for path in self.logs_dir.glob("*.jsonl"):
            if path.stem not in valid:
                path.unlink()
                removed += 1
        return removed

    # ── Stats ────────────────────────────────────────────────────────

    def uncommitted_stats(self, base_commit):
        """Quick stats from the working log before commit."""
        checkpoints = self.read_checkpoints(base_commit)
        files = set()
        ai_lines = 0
        ai_count = 0
        for cp in checkpoints:
            if cp.kind == CheckpointKind.AI_AGENT:
                ai_count += 1
            for entry in cp.entries:
                files.add(entry.file)
                for la in entry.line_attributions:
                    ai_lines += la.line_count()
        return {
            "checkpoint_count": len(checkpoints),
            "ai_checkpoints": ai_count,
            "files_touched": sorted(files),
            "total_ai_lines": ai_lines,
        }

    # ── Internal ─────────────────────────────────────────────────────

    def _append_with_lock(self, path, data):
        """Append to file with exclusive lock."""
        with open(path, "a") as f:
            deadline = time.monotonic() + 1.0
            while True:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError("Could not acquire lock on working log")
                    time.sleep(0.005)
            try:
                f.write(data + "\n")
                f.flush()
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
