"""Detect cost spikes per commit and write alerts.jsonl for the menubar."""

import json, os, subprocess, sys, tempfile, time
from dataclasses import dataclass, asdict, field
from pathlib import Path

from claudedashboard.gitai.obsly_config import load_config

DEFAULT_THRESHOLD_USD = 25.0


@dataclass
class Alert:
    timestamp: float
    cost_usd: float
    threshold_usd: float
    commit_sha: str
    repo_path: str
    session_count: int
    read: bool = False


def alerts_path():
    """Return Path to ~/.obsly-ai/alerts.jsonl. Honors OBSLY_CONFIG_DIR."""
    override = os.environ.get("OBSLY_CONFIG_DIR")
    if override:
        d = Path(override)
    else:
        d = Path(os.path.expanduser("~")) / ".obsly-ai"
    return d / "alerts.jsonl"


def get_threshold():
    """Return the configured cost_alert_threshold or the default."""
    try:
        cfg = load_config()
        val = cfg.get("cost_alert_threshold")
        if val is None:
            return DEFAULT_THRESHOLD_USD
        return float(val)
    except Exception as e:
        print(f"cost_alerts: get_threshold error: {e}", file=sys.stderr)
        return DEFAULT_THRESHOLD_USD


def check_and_alert(commit_sha, repo_path, prompt_records, *, threshold=None,
                    notifier=None, now=None):
    """Sum costs across prompt_records and append an Alert if threshold crossed."""
    try:
        records = list(prompt_records)
        total = _sum_cost(records)
        if threshold is None:
            threshold = get_threshold()
        if total < threshold:
            return None
        ts = (now or time.time)()
        alert = Alert(
            timestamp=float(ts),
            cost_usd=float(total),
            threshold_usd=float(threshold),
            commit_sha=str(commit_sha),
            repo_path=str(repo_path),
            session_count=len(records),
            read=False,
        )
        _append_alert(alert)
        fn = notifier if notifier is not None else _osascript_notify
        try:
            fn(alert)
        except Exception as e:
            print(f"cost_alerts: notifier error: {e}", file=sys.stderr)
        return alert
    except Exception as e:
        print(f"cost_alerts: check_and_alert error: {e}", file=sys.stderr)
        return None


def load_alerts(*, unread_only=False, limit=None):
    """Read alerts.jsonl and return Alert objects newest first."""
    try:
        path = alerts_path()
        if not path.exists():
            return []
        alerts = []
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                alerts.append(Alert(
                    timestamp=float(data.get("timestamp", 0.0)),
                    cost_usd=float(data.get("cost_usd", 0.0)),
                    threshold_usd=float(data.get("threshold_usd", 0.0)),
                    commit_sha=str(data.get("commit_sha", "")),
                    repo_path=str(data.get("repo_path", "")),
                    session_count=int(data.get("session_count", 0)),
                    read=bool(data.get("read", False)),
                ))
            except Exception as e:
                print(f"cost_alerts: corrupted alert line: {e}", file=sys.stderr)
                continue
        alerts.sort(key=lambda a: a.timestamp, reverse=True)
        if unread_only:
            alerts = [a for a in alerts if not a.read]
        if limit is not None:
            alerts = alerts[:limit]
        return alerts
    except Exception as e:
        print(f"cost_alerts: load_alerts error: {e}", file=sys.stderr)
        return []


def mark_alert_read(timestamp):
    """Set read=True on the alert with this timestamp. Atomic rewrite."""
    try:
        path = alerts_path()
        if not path.exists():
            return False
        lines = path.read_text().splitlines()
        found = False
        new_lines = []
        for line in lines:
            s = line.strip()
            if not s:
                continue
            try:
                data = json.loads(s)
            except Exception:
                new_lines.append(s)
                continue
            if not found and float(data.get("timestamp", 0.0)) == float(timestamp):
                data["read"] = True
                found = True
            new_lines.append(json.dumps(data))
        if not found:
            return False
        tmp_fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=".alerts.", suffix=".tmp")
        try:
            with os.fdopen(tmp_fd, "w") as f:
                for nl in new_lines:
                    f.write(nl + "\n")
            os.replace(tmp_name, path)
        except Exception:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
            raise
        return True
    except Exception as e:
        print(f"cost_alerts: mark_alert_read error: {e}", file=sys.stderr)
        return False


def _osascript_notify(alert):
    try:
        msg = f"{alert.repo_path}: ${alert.cost_usd:.2f} over ${alert.threshold_usd:.2f} threshold"
        msg = msg.replace('"', '\\"')
        script = f'display notification "{msg}" with title "Obsly AI cost spike"'
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=3,
        )
    except Exception as e:
        print(f"cost_alerts: osascript error: {e}", file=sys.stderr)


def _sum_cost(prompt_records):
    total = 0.0
    for rec in prompt_records:
        try:
            attrs = getattr(rec, "custom_attributes", None) or {}
            raw = attrs.get("cost_usd")
            if raw is None:
                continue
            try:
                total += float(raw)
            except (ValueError, TypeError):
                continue
        except Exception:
            continue
    return total


def _append_alert(alert):
    path = alerts_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(asdict(alert))
    with open(path, "a") as f:
        f.write(line + "\n")
