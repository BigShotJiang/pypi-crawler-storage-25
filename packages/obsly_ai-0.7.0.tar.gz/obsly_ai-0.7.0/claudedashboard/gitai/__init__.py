"""AI Code Attribution System — compatible with git-ai v3.0.0 standard."""

__version__ = "0.1.0"
