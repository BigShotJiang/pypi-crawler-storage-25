#!/usr/bin/env python3
"""
Claude Code — Burndown de presupuesto semanal
Muestra cuánto % del presupuesto llevas gastado cada día del ciclo.

Ciclo por defecto: viernes 9:00h local → jueves 8:59h local

Usage:
    python3 claude_burndown.py
    python3 claude_burndown.py --tz 2       # UTC offset (default 1 = España invierno)
    python3 claude_burndown.py --cycles 10
    python3 claude_burndown.py --no-browser
"""

import json
import os
import glob
import webbrowser
import tempfile
import sys
import argparse
from datetime import datetime, timezone, timedelta
from collections import defaultdict

CLAUDE_DIR = os.path.expanduser("~/.claude/projects")


def default_tz_offset_hours():
    now_local = datetime.now().astimezone()
    offset = now_local.utcoffset() or timedelta(0)
    return int(offset.total_seconds() // 3600)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--tz",        type=int, default=default_tz_offset_hours(), help="UTC offset horas (default: zona horaria local actual)")
    p.add_argument("--cycles",    type=int, default=9, help="Ciclos a mostrar (default 9)")
    p.add_argument("--no-browser", action="store_true")
    return p.parse_args()


def parse_ts(ts):
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None


_MODEL_PRICE = {
    "claude-opus-4":   {"inp": 15.0,  "ccr": 18.75, "crd": 1.50,  "out": 75.0},
    "claude-sonnet-4": {"inp":  3.0,  "ccr":  3.75, "crd": 0.30,  "out": 15.0},
    "claude-haiku-4":  {"inp":  0.80, "ccr":  1.00, "crd": 0.08,  "out":  4.0},
    "claude-sonnet-3": {"inp":  3.0,  "ccr":  3.75, "crd": 0.30,  "out": 15.0},
    "claude-haiku-3":  {"inp":  0.25, "ccr":  0.30, "crd": 0.03,  "out":  1.25},
}
_DEFAULT_PRICE = {"inp": 3.0, "ccr": 3.75, "crd": 0.30, "out": 15.0}

def _model_price(model):
    for prefix, p in _MODEL_PRICE.items():
        if model.startswith(prefix):
            return p
    return _DEFAULT_PRICE

def cost(inp, ccr, crd, out, model=""):
    """USD cost based on per-model pricing (prices per million tokens)."""
    p = _model_price(model)
    return (inp * p["inp"] + ccr * p["ccr"] + crd * p["crd"] + out * p["out"]) / 1_000_000

def dedup_key(obj, msg):
    return obj.get("requestId") or msg.get("id") or obj.get("uuid")


def main():
    args   = parse_args()
    tz_off = timedelta(hours=args.tz)

    now_utc       = datetime.now(timezone.utc).replace(tzinfo=None)
    # Viernes más reciente a las (9-tz):00 UTC = 9am Madrid (CEST)
    days_since_fri = (now_utc.weekday() - 4) % 7
    last_fri = (now_utc - timedelta(days=days_since_fri)).replace(
        hour=9 - args.tz, minute=0, second=0, microsecond=0
    )

    # Construir ciclos (más reciente primero)
    cycles = []
    for i in range(args.cycles):
        start = last_fri - timedelta(weeks=i)
        end   = start + timedelta(weeks=1)
        local = (start + tz_off).strftime("%-d %b")
        cycles.append({
            "start":      start,
            "end":        min(end, now_utc),   # ciclo actual no va más allá de ahora
            "full_end":   end,
            "label":      local,
            "is_current": i == 0,
            "by_day":     defaultdict(float),
        })

    # Leer JSONL
    files = glob.glob(os.path.join(CLAUDE_DIR, "**/*.jsonl"), recursive=True)
    print(f"Leyendo {len(files)} archivos…", file=sys.stderr)
    seen = set()

    for fpath in files:
        try:
            with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    msg   = obj.get("message", {})
                    usage = msg.get("usage", {})
                    if not usage:
                        continue
                    inp = usage.get("input_tokens", 0) or 0
                    ccr = usage.get("cache_creation_input_tokens", 0) or 0
                    crd = usage.get("cache_read_input_tokens", 0) or 0
                    out = usage.get("output_tokens", 0) or 0
                    model = msg.get("model", "")
                    e   = cost(inp, ccr, crd, out, model)
                    if e == 0:
                        continue
                    key = (fpath, dedup_key(obj, msg))
                    if key in seen:
                        continue
                    seen.add(key)
                    dt = parse_ts(obj.get("timestamp", ""))
                    if not dt:
                        continue
                    for c in cycles:
                        if c["start"] <= dt < c["full_end"]:
                            day = int((dt - c["start"]).total_seconds() // 86400)
                            c["by_day"][min(day, 6)] += e
                            break
        except Exception:
            pass

    # Presupuesto de referencia = ciclo completo MÁS RECIENTE
    # (los límites de Claude Max cambian con el tiempo; la semana pasada refleja los límites actuales)
    completed = [
        sum(c["by_day"].values())
        for c in cycles
        if not c["is_current"] and sum(c["by_day"].values()) > 0
    ]
    budget = completed[0] if completed else 1.0

    # Calcular series cronológicas (oldest → newest)
    # Cada punto = acumulado al FINAL de ese día expresado como % del budget
    # El punto 0 (antes del primer día) siempre vale 0
    days_elapsed = int((now_utc - cycles[0]["start"]).total_seconds() // 86400)

    series = []
    for c in reversed(cycles):
        total = sum(c["by_day"].values())
        if total == 0:
            continue
        pts   = [0.0]          # punto inicial = 0%
        running = 0.0
        for d in range(7):
            running += c["by_day"].get(d, 0)
            if c["is_current"] and d > days_elapsed:
                pts.append(None)   # días futuros = sin dato
            else:
                pts.append(round(running / budget * 100, 1))
        series.append({
            "label":      c["label"],
            "is_current": c["is_current"],
            "data":       pts,
            "total_cost":  round(total, 2),
        })

    # ── Info del ciclo actual para la nota ───────────────────────────────────
    cur       = next((s for s in series if s["is_current"]), None)
    known     = [v for v in (cur["data"] if cur else []) if v is not None]
    pct_now   = known[-1] if known else 0
    days_done = len(known) - 1   # excluye el punto 0
    expected  = round(days_done / 7 * 100)
    diff      = round(pct_now - expected, 1)

    # ── Colores ───────────────────────────────────────────────────────────────
    colors = []
    n = len(series)
    for i, s in enumerate(series):
        if s["is_current"]:
            colors.append({"line": "#f0883e", "w": 3, "r": 5})
        else:
            alpha = max(0.12, 0.55 - (n - 1 - i) * 0.08)
            colors.append({"line": f"rgba(88,166,255,{alpha:.2f})", "w": 1.5, "r": 2})

    x_labels = ["Vie 9h", "Vie noche", "Sáb", "Dom", "Lun", "Mar", "Mié", "Jue"]

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Claude Code · Weekly Budget Burndown</title>
<style>
  :root{{--bg:#0d1117;--surface:#161b22;--border:#30363d;
        --text:#e6edf3;--muted:#8b949e;--orange:#f0883e}}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{background:var(--bg);color:var(--text);
        font-family:'Segoe UI',system-ui,sans-serif;padding:28px;font-size:13px}}
  h1{{font-size:1.2rem;font-weight:700;color:var(--orange);margin-bottom:4px}}
  .sub{{color:var(--muted);font-size:12px;margin-bottom:20px}}
  .card{{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px}}
  .note{{margin-top:14px;padding:11px 15px;background:#0d1117;border-radius:8px;
         border-left:3px solid var(--orange);font-size:12px;color:var(--muted);line-height:1.8}}
  .note strong{{color:var(--text)}}
</style>
</head>
<body>
<h1>Weekly Budget Burndown — Claude Max</h1>
<p class="sub">
  Each line = one billing cycle (Fri 9:00 AM → next Fri 9:00 AM) · starts at 0% · 100% = last completed week<br>
  Orange line ★ = current cycle
</p>
<div class="card">
  <canvas id="chart"></canvas>
  <div class="note">
    <strong>Current cycle (★):</strong>
    at <strong style="color:var(--orange)">{pct_now}%</strong>
    after {days_done} day{"s" if days_done != 1 else ""} of 7 —
    linear pace would expect ~{expected}%
    (<strong style="color:{'#f85149' if diff > 0 else '#3fb950'}">{diff:+.1f}%</strong> vs normal pace).<br>
    <strong>100% reference</strong> = ${budget:.2f} (last completed cycle).
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const series  = {json.dumps(series)};
const colors  = {json.dumps(colors)};
const xlabels = {json.dumps(x_labels)};

Chart.defaults.color       = '#8b949e';
Chart.defaults.borderColor = '#21262d';
Chart.defaults.font.size   = 12;

const datasets = series.map((s, i) => ({{
  label:               s.label + (s.is_current ? ' ★' : ''),
  data:                s.data,
  borderColor:         colors[i].line,
  backgroundColor:     colors[i].line.replace('rgb','rgba').replace(')',',0.05)'),
  borderWidth:         colors[i].w,
  pointRadius:         colors[i].r,
  pointBackgroundColor:colors[i].line,
  fill:                false,
  tension:             0.35,
  spanGaps:            false,
}}));

// Línea 100%
datasets.push({{
  label:'budget 100%',
  data: [null,100,100,100,100,100,100,100],
  borderColor:'#f8514966', borderWidth:1.5,
  borderDash:[6,4], pointRadius:0, fill:false,
}});

new Chart(document.getElementById('chart'), {{
  type: 'line',
  data: {{ labels: xlabels, datasets }},
  options: {{
    responsive: true,
    aspectRatio: 3.5,
    interaction: {{ mode:'index', intersect:false }},
    plugins: {{
      legend: {{ position:'top', labels:{{ boxWidth:12, padding:12 }} }},
      tooltip: {{
        callbacks: {{
          label: ctx => {{
            if (ctx.parsed.y == null) return '';
            const s = series[ctx.datasetIndex];
            if (!s) return ctx.dataset.label + ': ' + ctx.parsed.y + '%';
            return `${{s.label}}: ${{ctx.parsed.y}}%`;
          }}
        }}
      }}
    }},
    scales: {{
      x: {{ grid:{{ color:'#21262d' }} }},
      y: {{
        min: 0,
        max: 110,
        ticks: {{ callback: v => v + '%', stepSize: 10 }},
        grid:  {{ color:'#21262d' }}
      }}
    }}
  }}
}});
</script>
</body>
</html>"""

    with tempfile.NamedTemporaryFile(
        suffix=".html", delete=False, mode="w", encoding="utf-8"
    ) as f:
        f.write(html)
        path = f.name

    print(f"Dashboard: file://{path}", file=sys.stderr)
    if not args.no_browser:
        webbrowser.open(f"file://{path}")


if __name__ == "__main__":
    main()
