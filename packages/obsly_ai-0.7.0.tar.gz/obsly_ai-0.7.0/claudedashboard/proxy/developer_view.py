"""Developer view — summary for menubar and individual dashboard."""

import json
from collections import defaultdict
from pathlib import Path


def _load_events(events_path, email=None):
    events = []
    try:
        with open(events_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                e = json.loads(line)
                if email is None or e.get("git_user") == email:
                    events.append(e)
    except FileNotFoundError:
        pass
    return events


def developer_summary(events_path, email=None):
    """Build a summary for a single developer (or all if email is None)."""
    events = _load_events(events_path, email)
    if not events:
        return {
            "total_cost": 0, "total_events": 0, "branches": {},
            "models": {}, "active_session": None, "cache_hit_ratio": 0,
        }

    total_cost = sum(e.get("cost", 0) for e in events)

    # By branch (with repo short name)
    branch_costs = defaultdict(lambda: {"cost": 0.0, "events": 0, "repo": None})
    for e in events:
        b = e.get("branch")
        if b:
            branch_costs[b]["cost"] += e.get("cost", 0)
            branch_costs[b]["events"] += 1
            branch_costs[b]["repo"] = e.get("repo")

    branches = {}
    for b, data in sorted(branch_costs.items(), key=lambda x: -x[1]["cost"]):
        repo_short = data["repo"].split("/")[-1].replace(".git", "") if data["repo"] else "?"
        branches[b] = {
            "cost": round(data["cost"], 6),
            "pct": round(data["cost"] / total_cost * 100, 1) if total_cost > 0 else 0,
            "events": data["events"],
            "repo_short": repo_short,
        }

    # By model
    model_data = defaultdict(lambda: {"cost": 0.0, "count": 0})
    for e in events:
        m = e.get("model", "unknown")
        model_data[m]["cost"] += e.get("cost", 0)
        model_data[m]["count"] += 1
    models = {m: {"cost": round(d["cost"], 6), "count": d["count"]}
              for m, d in sorted(model_data.items(), key=lambda x: -x[1]["cost"])}

    # Active session (most recent)
    sorted_events = sorted(events, key=lambda e: e.get("timestamp", 0), reverse=True)
    latest = sorted_events[0]
    session_id = latest.get("session_id")
    session_events = [e for e in events if e.get("session_id") == session_id] if session_id else [latest]
    active_session = {
        "session_id": session_id,
        "cost": round(sum(e.get("cost", 0) for e in session_events), 6),
        "events": len(session_events),
        "model": latest.get("model"),
        "transcript": latest.get("transcript"),
        "repo": latest.get("repo"),
        "branch": latest.get("branch"),
    }

    # Cache efficiency
    total_cache_read = sum(e.get("cache_read", 0) for e in events)
    total_input = sum(e.get("tokens_in", 0) for e in events)
    cache_hit_ratio = round(total_cache_read / (total_cache_read + total_input) * 100, 1) if (total_cache_read + total_input) > 0 else 0

    return {
        "total_cost": round(total_cost, 6),
        "total_events": len(events),
        "branches": branches,
        "models": models,
        "active_session": active_session,
        "cache_hit_ratio": cache_hit_ratio,
    }


def menubar_line(events_path, email=None):
    """One-liner for the menubar: 'app/JIRA-1: 86% | backend/BUG-99: 5%'"""
    s = developer_summary(events_path, email)
    if not s["branches"]:
        return "No activity"

    parts = []
    for branch, data in list(s["branches"].items())[:3]:  # top 3
        repo = data["repo_short"]
        short_branch = branch.split("/")[-1] if "/" in branch else branch
        parts.append(f"{repo}/{short_branch}: {data['pct']:.0f}%")

    line = " | ".join(parts)

    # Add session cost
    if s["active_session"]:
        line += f"  [${s['active_session']['cost']:.2f}]"

    return line
