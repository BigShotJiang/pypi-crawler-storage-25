"""Team dashboard — Flask app showing aggregated proxy data."""

import json
from collections import defaultdict

from flask import Flask, jsonify, request


def create_app(events_path=None):
    app = Flask(__name__)
    app.config["EVENTS_PATH"] = events_path

    def _load_events():
        path = app.config["EVENTS_PATH"]
        if not path:
            return []
        events = []
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        events.append(json.loads(line))
        except FileNotFoundError:
            pass
        return events

    def _group_by(events, key):
        result = defaultdict(lambda: {"cost": 0.0, "events": 0, "tokens_in": 0, "tokens_out": 0})
        for e in events:
            k = e.get(key, "unknown")
            result[k]["cost"] += e.get("cost", 0)
            result[k]["events"] += 1
            result[k]["tokens_in"] += e.get("tokens_in", 0)
            result[k]["tokens_out"] += e.get("tokens_out", 0)
        return {k: {kk: round(vv, 6) if isinstance(vv, float) else vv for kk, vv in v.items()} for k, v in result.items()}

    def _group_by_model(events):
        result = defaultdict(lambda: {"cost": 0.0, "count": 0, "tokens_in": 0, "tokens_out": 0})
        for e in events:
            m = e.get("model", "unknown")
            result[m]["cost"] += e.get("cost", 0)
            result[m]["count"] += 1
            result[m]["tokens_in"] += e.get("tokens_in", 0)
            result[m]["tokens_out"] += e.get("tokens_out", 0)
        return {k: {kk: round(vv, 6) if isinstance(vv, float) else vv for kk, vv in v.items()} for k, v in result.items()}

    @app.route("/")
    def index():
        events = _load_events()
        return _render_html(events)

    @app.route("/api/health")
    def health():
        return jsonify({"status": "ok"})

    @app.route("/api/summary")
    def summary():
        events = _load_events()
        providers = defaultdict(int)
        total_cost = 0.0
        for e in events:
            providers[e.get("provider", "unknown")] += 1
            total_cost += e.get("cost", 0)
        return jsonify({
            "total_events": len(events),
            "total_cost": round(total_cost, 6),
            "providers": dict(providers),
        })

    @app.route("/api/repos")
    def repos():
        return jsonify(_group_by(_load_events(), "repo"))

    @app.route("/api/developers")
    def developers():
        return jsonify(_group_by(_load_events(), "git_user"))

    @app.route("/api/branches")
    def branches():
        return jsonify(_group_by(_load_events(), "branch"))

    @app.route("/api/models")
    def models():
        return jsonify(_group_by_model(_load_events()))

    @app.route("/api/tools")
    def tools():
        return jsonify(_group_by(_load_events(), "tool"))

    @app.route("/api/developer")
    def developer():
        from .developer_view import developer_summary
        email = request.args.get("email")
        return jsonify(developer_summary(app.config["EVENTS_PATH"], email))

    @app.route("/api/events")
    def events_feed():
        events = _load_events()
        limit = request.args.get("limit", len(events), type=int)
        sorted_events = sorted(events, key=lambda e: e.get("timestamp", 0), reverse=True)
        return jsonify(sorted_events[:limit])

    return app


def _render_html(events):
    from collections import defaultdict

    # Aggregate
    by_repo = defaultdict(float)
    by_dev = defaultdict(float)
    by_model = defaultdict(lambda: {"cost": 0.0, "count": 0})
    by_tool = defaultdict(float)
    total_cost = 0.0

    for e in events:
        total_cost += e.get("cost", 0)
        by_repo[e.get("repo", "unknown")] += e.get("cost", 0)
        by_dev[e.get("git_user", "unknown")] += e.get("cost", 0)
        by_model[e.get("model", "unknown")]["cost"] += e.get("cost", 0)
        by_model[e.get("model", "unknown")]["count"] += 1
        by_tool[e.get("tool", "unknown")] += e.get("cost", 0)

    def pct(v):
        return f"{v / total_cost * 100:.1f}%" if total_cost > 0 else "0%"

    def bar(v):
        w = v / total_cost * 100 if total_cost > 0 else 0
        return f'<div style="background:#58a6ff;height:8px;border-radius:4px;width:{w:.1f}%"></div>'

    def row(label, cost):
        return f"<tr><td>{label}</td><td>${cost:.4f}</td><td>{pct(cost)}</td><td>{bar(cost)}</td></tr>"

    def table(title, data):
        rows = "".join(row(k, v) for k, v in sorted(data.items(), key=lambda x: -x[1]))
        return f"""
        <div class="card">
            <h2>{title}</h2>
            <table><thead><tr><th>Name</th><th>Cost</th><th>%</th><th></th></tr></thead>
            <tbody>{rows}</tbody></table>
        </div>"""

    model_rows = "".join(
        f"<tr><td>{m}</td><td>{d['count']}</td><td>${d['cost']:.4f}</td><td>{pct(d['cost'])}</td></tr>"
        for m, d in sorted(by_model.items(), key=lambda x: -x[1]["cost"])
    )

    recent = sorted(events, key=lambda e: e.get("timestamp", 0), reverse=True)[:20]
    recent_rows = "".join(
        f"<tr><td>{e.get('tool','')}</td><td>{e.get('model','')}</td>"
        f"<td>{e.get('repo','').split('/')[-1] if e.get('repo') else ''}</td>"
        f"<td>{e.get('branch','')}</td><td>{e.get('git_user','').split('@')[0] if e.get('git_user') else ''}</td>"
        f"<td>${e.get('cost',0):.4f}</td></tr>"
        for e in recent
    )

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Team Dashboard</title>
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family:-apple-system,system-ui,sans-serif; background:#0d1117; color:#e6edf3; padding:24px; }}
  h1 {{ font-size:24px; margin-bottom:8px; }}
  .subtitle {{ color:#8b949e; margin-bottom:24px; }}
  .hero {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:24px; }}
  .hero-card {{ background:#161b22; border:1px solid #30363d; border-radius:8px; padding:16px; text-align:center; }}
  .hero-card .value {{ font-size:28px; font-weight:700; color:#58a6ff; }}
  .hero-card .label {{ color:#8b949e; font-size:13px; margin-top:4px; }}
  .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(400px,1fr)); gap:16px; margin-bottom:24px; }}
  .card {{ background:#161b22; border:1px solid #30363d; border-radius:8px; padding:16px; }}
  .card h2 {{ font-size:16px; margin-bottom:12px; color:#e6edf3; }}
  table {{ width:100%; border-collapse:collapse; font-size:13px; }}
  th {{ text-align:left; color:#8b949e; border-bottom:1px solid #30363d; padding:6px 8px; }}
  td {{ padding:6px 8px; border-bottom:1px solid #21262d; }}
  tr:hover {{ background:#1c2128; }}
</style></head>
<body>
<h1>Team Dashboard</h1>
<p class="subtitle">{len(events)} events captured &middot; ${total_cost:.2f} total cost</p>

<div class="hero">
  <div class="hero-card"><div class="value">{len(events)}</div><div class="label">Total Requests</div></div>
  <div class="hero-card"><div class="value">${total_cost:.2f}</div><div class="label">Total Cost</div></div>
  <div class="hero-card"><div class="value">{len(by_dev)}</div><div class="label">Developers</div></div>
  <div class="hero-card"><div class="value">{len(by_repo)}</div><div class="label">Repositories</div></div>
  <div class="hero-card"><div class="value">{len(by_model)}</div><div class="label">Models</div></div>
</div>

<div class="grid">
  {table("By Repository", dict(by_repo))}
  {table("By Developer", dict(by_dev))}
  {table("By Tool", dict(by_tool))}
  <div class="card">
    <h2>By Model</h2>
    <table><thead><tr><th>Model</th><th>Calls</th><th>Cost</th><th>%</th></tr></thead>
    <tbody>{model_rows}</tbody></table>
  </div>
</div>

<div class="card">
  <h2>Recent Activity</h2>
  <table><thead><tr><th>Tool</th><th>Model</th><th>Repo</th><th>Branch</th><th>Dev</th><th>Cost</th></tr></thead>
  <tbody>{recent_rows}</tbody></table>
</div>

<script>setTimeout(()=>location.reload(), 30000);</script>
</body></html>"""
