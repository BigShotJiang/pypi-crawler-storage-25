"""mitmproxy addon — intercepts LLM API traffic, attributes, and stores."""

import json
import os
import subprocess
import sys
import time

# Support both relative imports (tests) and standalone loading (mitmdump -s)
try:
    from .capture import extract_usage, PROVIDER_MAP
    from .attribute import get_git_info
    from .store import EventStore
    from .session import extract_transcript, get_session_id
except ImportError:
    _pkg_dir = os.path.dirname(os.path.abspath(__file__))
    if _pkg_dir not in sys.path:
        sys.path.insert(0, _pkg_dir)
    from capture import extract_usage, PROVIDER_MAP
    from attribute import get_git_info
    from store import EventStore
    from session import extract_transcript, get_session_id


def get_pid_cwd(flow):
    """Get the working directory of the process that made the request.

    Platform-specific: uses lsof on macOS/Linux.
    Returns cwd string or None.
    """
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "p"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = line[1:]
                cwd = subprocess.check_output(
                    ["lsof", "-p", pid, "-d", "cwd", "-F", "n"],
                    text=True, timeout=2, stderr=subprocess.DEVNULL,
                )
                for cwd_line in cwd.strip().split("\n"):
                    if cwd_line.startswith("n") and cwd_line != "ncwd":
                        return cwd_line[1:]
    except Exception:
        pass
    return None


def get_process_name(flow):
    """Get the name of the process that made the request."""
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "c"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        for line in out.strip().split("\n"):
            if line.startswith("c"):
                return line[1:]
    except Exception:
        pass
    return "unknown"


def get_pid_from_flow(flow):
    """Get (pid, ppid) of the process that made the request."""
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "pR"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        pid = None
        ppid = None
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = int(line[1:])
            elif line.startswith("R"):
                ppid = int(line[1:])
        return (pid, ppid)
    except Exception:
        return (None, None)


def _resolve_process_info(flow):
    """Resolve PID, cwd, process name, ppid from flow's client connection.

    Must be called while the client connection is still alive (in request hook).
    """
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "pcRn"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        pid = None
        ppid = None
        pname = "unknown"
        cwd = None
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = int(line[1:])
            elif line.startswith("c"):
                pname = line[1:]
            elif line.startswith("R"):
                ppid = int(line[1:])
        if pid:
            cwd_out = subprocess.check_output(
                ["lsof", "-p", str(pid), "-d", "cwd", "-F", "n"],
                text=True, timeout=2, stderr=subprocess.DEVNULL,
            )
            for cwd_line in cwd_out.strip().split("\n"):
                if cwd_line.startswith("n") and cwd_line != "ncwd":
                    cwd = cwd_line[1:]
        return {"pid": pid, "ppid": ppid, "pname": pname, "cwd": cwd}
    except Exception:
        return {"pid": None, "ppid": None, "pname": "unknown", "cwd": None}


class LLMTrackerAddon:
    """mitmproxy addon that captures LLM usage and stores attributed events."""

    def __init__(self, store_path=None):
        from pathlib import Path

        if store_path is None:
            store_path = str(Path.home() / ".claude" / "proxy_events.jsonl")
        self._store = EventStore(store_path)
        self._flow_info = {}  # flow.id -> process info

    def _parse_sse_usage(self, host, content):
        """Extract usage from a streaming SSE response.

        Anthropic streams end with a message_delta event containing usage.
        OpenAI streams end with a [DONE] chunk, usage is in the last data chunk.
        """
        model = None
        usage = {}
        for line in content.decode("utf-8", errors="replace").split("\n"):
            if not line.startswith("data: "):
                continue
            data_str = line[6:].strip()
            if data_str == "[DONE]":
                continue
            try:
                data = json.loads(data_str)
            except (json.JSONDecodeError, ValueError):
                continue
            # Anthropic: message_start has the model
            if data.get("type") == "message_start" and "message" in data:
                model = data["message"].get("model")
            # Anthropic: message_delta has usage
            if data.get("type") == "message_delta" and "usage" in data:
                usage = data["usage"]
            # OpenAI: each chunk may have usage in the last one
            if data.get("model"):
                model = data["model"]
            if data.get("usage"):
                usage = data["usage"]
        if usage and model:
            return extract_usage(host, {"model": model, "usage": usage})
        return None

    def request(self, flow):
        """Capture process info while client connection is alive."""
        if flow.request.host in PROVIDER_MAP:
            self._flow_info[id(flow)] = _resolve_process_info(flow)

    def response(self, flow):
        if flow.request.host not in PROVIDER_MAP:
            return

        content_type = flow.response.headers.get("content-type", "")
        is_sse = "text/event-stream" in content_type

        if is_sse:
            usage_event = self._parse_sse_usage(flow.request.host, flow.response.content)
        else:
            try:
                body = json.loads(flow.response.content)
            except (json.JSONDecodeError, UnicodeDecodeError):
                return
            if not isinstance(body, dict):
                return
            usage_event = extract_usage(flow.request.host, body)

        if usage_event is None:
            self._flow_info.pop(id(flow), None)
            return

        # Use process info captured during request (connection was alive)
        pinfo = self._flow_info.pop(id(flow), None) or _resolve_process_info(flow)
        cwd = pinfo["cwd"]
        git_info = get_git_info(cwd) if cwd else {"repo": None, "branch": None, "git_user": None}

        # Transcript from request body
        transcript = None
        try:
            req_body = json.loads(flow.request.content)
            transcript = extract_transcript(req_body)
        except Exception:
            pass

        event = {
            **usage_event,
            "tool": pinfo["pname"],
            "repo": git_info["repo"],
            "branch": git_info["branch"],
            "git_user": git_info["git_user"],
            "session_id": get_session_id(pid=pinfo["pid"], ppid=pinfo["ppid"]),
            "transcript": transcript,
            "timestamp": getattr(flow, "timestamp_end", None) or flow.timestamp_created,
        }

        self._store.append(event)

    def websocket_message(self, flow):
        """Handle WebSocket messages (Codex uses WebSocket via ab.chatgpt.com)."""
        if flow.request.host not in PROVIDER_MAP:
            return

        # Only look at server->client messages
        msg = flow.websocket.messages[-1]
        if msg.from_client:
            return

        try:
            data = json.loads(msg.content)
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
            return

        if not isinstance(data, dict):
            return

        # OpenAI realtime/WebSocket format: look for usage in response
        usage = data.get("usage")
        model = data.get("model")

        # Codex may nest differently — also check response.usage
        if not usage and "response" in data:
            resp = data["response"]
            usage = resp.get("usage") if isinstance(resp, dict) else None
            model = model or (resp.get("model") if isinstance(resp, dict) else None)

        if not usage or not model:
            return

        usage_event = extract_usage(flow.request.host, {"model": model, "usage": usage})
        if usage_event is None:
            return

        # Attribution — use flow info if captured, or resolve now
        pinfo = self._flow_info.get(id(flow)) or _resolve_process_info(flow)
        cwd = pinfo["cwd"]
        git_info = get_git_info(cwd) if cwd else {"repo": None, "branch": None, "git_user": None}

        event = {
            **usage_event,
            "tool": pinfo["pname"],
            "repo": git_info["repo"],
            "branch": git_info["branch"],
            "git_user": git_info["git_user"],
            "session_id": get_session_id(pid=pinfo["pid"], ppid=pinfo["ppid"]),
            "transcript": None,  # WebSocket doesn't have easy request body
            "timestamp": time.time(),
        }

        self._store.append(event)


# mitmproxy script entry point
addons = [LLMTrackerAddon(store_path=os.environ.get("LLM_PROXY_STORE_PATH"))]
