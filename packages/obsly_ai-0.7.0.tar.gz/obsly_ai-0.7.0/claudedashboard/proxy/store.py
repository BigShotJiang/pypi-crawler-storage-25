"""Persist captured LLM events to JSONL."""

import json
from pathlib import Path


class EventStore:
    def __init__(self, path):
        self._path = Path(path)

    def append(self, event):
        with open(self._path, "a") as f:
            f.write(json.dumps(event) + "\n")

    def read_all(self):
        if not self._path.exists():
            return []
        events = []
        with open(self._path) as f:
            for line in f:
                line = line.strip()
                if line:
                    events.append(json.loads(line))
        return events
