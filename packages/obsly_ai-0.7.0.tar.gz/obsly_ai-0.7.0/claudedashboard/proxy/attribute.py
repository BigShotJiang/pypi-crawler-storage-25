"""Attribute LLM usage to repo, branch, and developer via git."""

import subprocess


def _git(cmd, cwd):
    try:
        return subprocess.check_output(
            ["git"] + cmd.split(),
            cwd=cwd,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=2,
        ).strip() or None
    except Exception:
        return None


def _repo_remote(cwd):
    remote = _git("remote get-url origin", cwd)
    if remote:
        return remote
    remotes = _git("remote", cwd)
    if not remotes:
        return None
    for name in remotes.splitlines():
        name = name.strip()
        if not name:
            continue
        remote = _git(f"remote get-url {name}", cwd)
        if remote:
            return remote
    return None


def _git_user(cwd):
    return (
        _git("config user.email", cwd)
        or _git("config --global user.email", cwd)
        or _git("log -1 --format=%ae", cwd)
    )


def get_git_info(cwd):
    """Get repo, branch, and git user from a working directory.

    Returns dict with repo, branch, git_user — any can be None.
    """
    return {
        "repo": _repo_remote(cwd),
        "branch": _git("branch --show-current", cwd),
        "git_user": _git_user(cwd),
    }
