"""Aggregate captured events into useful views."""

from collections import defaultdict


def cost_by_repo(events):
    totals = defaultdict(float)
    for e in events:
        totals[e["repo"]] += e["cost"]
    return dict(totals)


def cost_by_branch(events):
    totals = defaultdict(float)
    for e in events:
        totals[e["branch"]] += e["cost"]
    return dict(totals)


def cost_by_developer(events):
    totals = defaultdict(float)
    for e in events:
        totals[e["git_user"]] += e["cost"]
    return dict(totals)


def model_distribution(events):
    result = defaultdict(lambda: {"cost": 0.0, "count": 0})
    for e in events:
        result[e["model"]]["cost"] += e["cost"]
        result[e["model"]]["count"] += 1
    return dict(result)


def pct_by_repo_branch(events):
    """Return cost as % of total, keyed by (repo, branch)."""
    totals = defaultdict(float)
    grand = 0.0
    for e in events:
        key = (e["repo"], e["branch"])
        totals[key] += e["cost"]
        grand += e["cost"]
    if grand == 0:
        return {}
    return {k: round(v / grand * 100, 1) for k, v in totals.items()}
