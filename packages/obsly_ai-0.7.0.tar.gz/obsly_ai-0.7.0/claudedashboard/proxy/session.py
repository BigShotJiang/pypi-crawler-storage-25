"""Session tracking and transcript extraction for proxy events."""


def extract_transcript(body, max_len=200):
    """Extract the last user messages as a short transcript.

    Returns up to 2-3 user messages joined, truncated to max_len.
    """
    messages = body.get("messages")
    if not messages:
        return None

    user_msgs = []
    for m in messages:
        if m.get("role") != "user":
            continue
        content = m.get("content", "")
        if isinstance(content, list):
            # Anthropic content blocks: [{"type": "text", "text": "..."}]
            parts = [b.get("text", "") for b in content if b.get("type") == "text"]
            content = " ".join(parts)
        if content:
            user_msgs.append(content)

    # Filter out system reminders and tool noise
    user_msgs = [m for m in user_msgs if not m.startswith("<system-reminder>") and not m.startswith("<") and len(m.strip()) > 0]

    if not user_msgs:
        return None

    # Keep last 3 user messages
    recent = user_msgs[-3:]
    transcript = " → ".join(recent)

    if len(transcript) > max_len:
        return transcript[:max_len] + "..."
    return transcript


def get_session_id(pid=None, ppid=None):
    """Generate a session ID from process info.

    If ppid is available, use it (groups child processes of same terminal).
    Otherwise use pid directly.
    """
    if pid is None and ppid is None:
        return "unknown"

    # If we have parent PID, use it as session key (same terminal = same session)
    key = ppid if ppid is not None else pid
    return f"session-{key}"
