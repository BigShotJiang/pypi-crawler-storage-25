"""Doctor — integration health checks for the proxy setup."""

import os
import shutil
import subprocess
import tempfile
from pathlib import Path


def check_mitmproxy_installed():
    path = shutil.which("mitmdump")
    if path:
        try:
            version = subprocess.check_output(
                [path, "--version"], text=True, timeout=5, stderr=subprocess.DEVNULL
            ).strip()
            return ("ok", f"mitmdump found: {version}")
        except Exception:
            return ("ok", f"mitmdump found at {path}")
    return ("fail", "mitmdump not found. Install: pip install mitmproxy")


def check_cert_exists():
    cert_path = Path.home() / ".mitmproxy" / "mitmproxy-ca-cert.pem"
    if cert_path.exists():
        return ("ok", f"Certificate exists: {cert_path}")
    return ("fail", f"Certificate not found at {cert_path}. Run: mitmdump --quit")


def check_cert_trusted():
    cert_path = Path.home() / ".mitmproxy" / "mitmproxy-ca-cert.pem"
    if not cert_path.exists():
        return ("fail", "Certificate not generated yet")

    import platform
    system = platform.system()

    if system == "Darwin":
        try:
            result = subprocess.run(
                ["security", "verify-cert", "-c", str(cert_path)],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return ("ok", "Certificate trusted in macOS Keychain")
            return ("fail", f"Certificate NOT trusted. Run: sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain {cert_path}")
        except Exception as e:
            return ("fail", f"Could not verify cert: {e}")
    elif system == "Linux":
        # Check common locations
        for ca_dir in ["/usr/local/share/ca-certificates", "/etc/pki/ca-trust/source/anchors"]:
            if os.path.isdir(ca_dir):
                expected = Path(ca_dir) / "mitmproxy-ca-cert.crt"
                if expected.exists():
                    return ("ok", f"Certificate installed at {expected}")
        return ("fail", "Certificate not installed. Copy to /usr/local/share/ca-certificates/ and run update-ca-certificates")
    else:
        return ("warn", f"Cannot verify cert trust on {system} — check manually")


def check_proxy_starts():
    mitmdump = shutil.which("mitmdump")
    if not mitmdump:
        return ("fail", "mitmdump not installed")
    try:
        proc = subprocess.Popen(
            [mitmdump, "--listen-port", "0", "-q"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        import time
        time.sleep(1)
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=3)
            return ("ok", "Proxy starts successfully")
        else:
            stderr = proc.stderr.read().decode()
            return ("fail", f"Proxy exited immediately: {stderr[:200]}")
    except Exception as e:
        return ("fail", f"Could not start proxy: {e}")


def check_git_attribution():
    from .attribute import get_git_info
    # Test with the project's own directory
    project_dir = Path(__file__).resolve().parent.parent.parent
    info = get_git_info(str(project_dir))
    parts = []
    if info["repo"]:
        parts.append(f"repo={info['repo'].split('/')[-1]}")
    if info["branch"]:
        parts.append(f"branch={info['branch']}")
    if info["git_user"]:
        parts.append(f"user={info['git_user']}")
    if parts:
        return ("ok", f"Git attribution: {', '.join(parts)}")
    return ("fail", "Could not read git info from project directory")


def check_store_writable(path=None):
    if path is None:
        path = str(Path.home() / ".claude" / "proxy_events.jsonl")
    try:
        parent = Path(path).parent
        if not parent.exists():
            return ("fail", f"Directory does not exist: {parent}")
        # Try writing
        test_path = Path(path)
        test_path.touch()
        if test_path.stat().st_size == 0:
            test_path.unlink()
        return ("ok", f"Store writable: {path}")
    except Exception as e:
        return ("fail", f"Cannot write to {path}: {e}")


def run_all(store_path=None):
    checks = [
        ("mitmproxy installed", check_mitmproxy_installed),
        ("certificate exists", check_cert_exists),
        ("certificate trusted", check_cert_trusted),
        ("proxy starts", check_proxy_starts),
        ("git attribution", check_git_attribution),
        ("store writable", lambda: check_store_writable(store_path)),
    ]
    results = []
    for name, fn in checks:
        try:
            status, msg = fn()
        except Exception as e:
            status, msg = "fail", str(e)
        results.append((name, status, msg))
    return results
