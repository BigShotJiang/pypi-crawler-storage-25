"""Orchestration layer for the macOS menubar launchd background agent."""

import sys
from pathlib import Path

from claudedashboard.gitai import launchd


_NAME = "menubar"


def _logs_dir():
    """Return Path to ~/.obsly-ai/logs/. Creates it if absent."""
    d = Path.home() / ".obsly-ai" / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _program_args():
    return [sys.executable, "-m", "claudedashboard.cli", "menubar", "run"]


def install(*, dry_run=False):
    """Install the menubar as a launchd background agent."""
    target = launchd.plist_path(_NAME)
    stderr_path = str(Path.home() / ".obsly-ai" / "logs" / "menubar.err")
    stdout_path = str(Path.home() / ".obsly-ai" / "logs" / "menubar.out")
    args = _program_args()

    if dry_run:
        print(f"(dry-run) would write plist: {target}")
        print(f"(dry-run) program: {' '.join(args)}")
        print(f"(dry-run) stderr: {stderr_path}")
        print(f"(dry-run) stdout: {stdout_path}")
        return {
            "plist": str(target),
            "bootstrap_ok": False,
            "bootstrap_msg": "dry-run",
        }

    _logs_dir()

    written = launchd.write_plist(
        _NAME,
        args,
        keep_alive=True,
        run_at_load=True,
        stderr_path=stderr_path,
        stdout_path=stdout_path,
    )

    try:
        ok, msg = launchd.bootstrap(_NAME)
    except Exception as e:  # pragma: no cover - defensive
        ok, msg = False, str(e)

    return {
        "plist": str(written) if written else str(target),
        "bootstrap_ok": bool(ok),
        "bootstrap_msg": msg or "",
    }


def uninstall(*, dry_run=False):
    """Uninstall the menubar background agent."""
    target = launchd.plist_path(_NAME)
    if dry_run:
        return {"removed": False, "plist": str(target)}
    try:
        removed = launchd.uninstall(_NAME)
    except Exception:
        removed = False
    return {"removed": bool(removed), "plist": str(target)}


def status():
    """Return 'running', 'stopped', or 'not_installed'."""
    return launchd.status(_NAME)
