"""Run a command with HTTPS_PROXY pointing at the local Obsly LLM proxy."""

import os
import sys

PROXY_URL = "http://localhost:8080"


def build_env(base_env=None, proxy_url=PROXY_URL):
    """Return a copy of base_env with HTTPS_PROXY/HTTP_PROXY set to proxy_url."""
    if base_env is None:
        base_env = os.environ
    env = dict(base_env)
    env["HTTPS_PROXY"] = proxy_url
    env["HTTP_PROXY"] = proxy_url
    return env


def check_proxy_running(status_func=None):
    """Return (running, status_string). Tests inject status_func."""
    if status_func is None:
        from claudedashboard import proxy_service
        status_func = proxy_service.status
    s = status_func()
    return (s == "running", s)


def run(argv, *, status_func=None, exec_func=None, env=None):
    """Run the command in argv with proxy env injected.

    Returns an exit code. In real usage exec replaces the process so the
    return is unreachable; tests inject exec_func to capture the call.
    """
    if not argv:
        print(
            "usage: obsly-ai run-with-proxy <command> [args...]",
            file=sys.stderr,
        )
        return 2

    running, state = check_proxy_running(status_func)
    if not running:
        print(
            f"obsly-ai proxy is not running (status: {state}).\n"
            f"Start it with: obsly-ai proxy install",
            file=sys.stderr,
        )
        return 3

    if exec_func is None:
        exec_func = os.execvpe

    full_env = build_env(env)
    try:
        exec_func(argv[0], argv, full_env)
    except FileNotFoundError as e:
        print(f"command not found: {argv[0]}: {e}", file=sys.stderr)
        return 127
    except OSError as e:
        print(f"failed to exec {argv[0]}: {e}", file=sys.stderr)
        return 127
    return 0
