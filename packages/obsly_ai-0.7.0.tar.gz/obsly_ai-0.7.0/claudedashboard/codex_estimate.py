"""Codex local log parsing and usage estimation.

Stdlib-only helpers shared by the live dashboard, tray icon and the team
usage pusher.
"""

import glob
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

DEFAULT_PLAN = "pro"
PLAN_WEEKLY_TOKEN_BUDGETS = {
    "plus": 250_000,
    "pro": 1_000_000,
    "team": 5_000_000,
    "enterprise": 10_000_000,
}


def _home_dir_path(home_dir=None):
    if home_dir is None:
        return Path(os.path.expanduser("~"))
    return Path(home_dir)


def _sessions_root(home_dir=None):
    return _home_dir_path(home_dir) / ".codex" / "sessions"


def _parse_timestamp(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None


def _extract_codex_token_count(obj: dict, session_id: str) -> dict | None:
    if obj.get("type") != "event_msg":
        return None
    payload = obj.get("payload") or {}
    if payload.get("type") != "token_count":
        return None
    info = payload.get("info") or {}
    total_usage = info.get("total_token_usage") or {}
    rate_limits = payload.get("rate_limits") or {}
    primary = rate_limits.get("primary") or {}
    secondary = rate_limits.get("secondary") or {}
    timestamp = obj.get("timestamp")
    dt = _parse_timestamp(timestamp)
    if not dt:
        return None
    return {
        "session_id": session_id,
        "timestamp": timestamp,
        "dt": dt,
        "total_tokens": int(total_usage.get("total_tokens") or 0),
        "primary_pct": primary.get("used_percent"),
        "primary_resets_at": primary.get("resets_at"),
        "secondary_pct": secondary.get("used_percent"),
        "secondary_resets_at": secondary.get("resets_at"),
        "plan_type": rate_limits.get("plan_type"),
    }


def _build_codex_weekly_usage(records: list[dict], now_utc: datetime | None = None) -> dict:
    now_utc = (now_utc or datetime.now(timezone.utc)).replace(tzinfo=None)
    start_utc = now_utc - timedelta(hours=167)
    hourly = {}
    latest = None
    latest_session_totals = {}

    for rec in records:
        dt = rec["dt"]
        sid = rec["session_id"]
        if latest is None or dt > latest["dt"]:
            latest = rec
        prev = latest_session_totals.get(sid)
        if prev is None or dt > prev["dt"]:
            latest_session_totals[sid] = rec
        if dt < start_utc:
            continue
        hour_idx = int((dt - start_utc).total_seconds() // 3600)
        if 0 <= hour_idx < 168:
            cur = hourly.get(hour_idx)
            if cur is None or dt > cur["dt"]:
                hourly[hour_idx] = rec

    history_pts = [None] * 168
    for hour_idx, rec in hourly.items():
        history_pts[hour_idx] = rec["secondary_pct"]

    all_time_total = sum(max(0, rec.get("total_tokens") or 0) for rec in latest_session_totals.values())
    day_labels = []
    for hour in range(168):
        if hour % 24 == 0:
            label_dt = start_utc + timedelta(hours=hour)
            day_labels.append((label_dt + timedelta(hours=_local_tz_hours())).strftime("%a"))

    return {
        "total_tokens": all_time_total,
        "session_count": len(latest_session_totals),
        "plan_type": latest.get("plan_type") if latest else None,
        "seven_day_pct": latest.get("secondary_pct") if latest else None,
        "seven_day_remaining": (100 - latest["secondary_pct"]) if latest and latest.get("secondary_pct") is not None else None,
        "seven_day_resets_at": latest.get("secondary_resets_at") if latest else None,
        "five_hour_pct": latest.get("primary_pct") if latest else None,
        "five_hour_remaining": (100 - latest["primary_pct"]) if latest and latest.get("primary_pct") is not None else None,
        "five_hour_resets_at": latest.get("primary_resets_at") if latest else None,
        "day_labels": day_labels,
        "history_pts": history_pts,
        "last_event_at": latest["timestamp"] if latest else None,
    }


def _local_tz_hours():
    now_local = datetime.now().astimezone()
    offset = now_local.utcoffset() or timedelta(0)
    return int(offset.total_seconds() // 3600)


def load_codex_weekly_usage(home_dir=None, now_utc: datetime | None = None) -> dict:
    sessions_root = _sessions_root(home_dir)
    records = []
    if not sessions_root.exists():
        return _build_codex_weekly_usage(records, now_utc=now_utc)

    for path in glob.glob(os.path.join(str(sessions_root), "**/*.jsonl"), recursive=True):
        session_id = os.path.splitext(os.path.basename(path))[0].split("-")[-1]
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    if '"token_count"' not in line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    rec = _extract_codex_token_count(obj, session_id)
                    if rec:
                        records.append(rec)
        except OSError:
            continue

    return _build_codex_weekly_usage(records, now_utc=now_utc)


def estimate_codex_usage(home_dir=None, plan=None, now_utc: datetime | None = None) -> dict:
    """Return a best-effort local Codex usage estimate.

    Prefer the percent already exposed by Codex logs; fall back to a token
    budget approximation when the percent is missing.
    """
    usage = load_codex_weekly_usage(home_dir=home_dir, now_utc=now_utc)
    plan_name = _normalize_plan(plan or usage.get("plan_type") or DEFAULT_PLAN)
    weekly_pct = usage.get("seven_day_pct")
    if weekly_pct is None and usage.get("total_tokens") is not None:
        budget = PLAN_WEEKLY_TOKEN_BUDGETS.get(plan_name, PLAN_WEEKLY_TOKEN_BUDGETS[DEFAULT_PLAN])
        if budget:
            weekly_pct = round(min(100.0, (usage["total_tokens"] / budget) * 100.0), 1)

    return {
        "plan": plan_name,
        "weekly_pct": weekly_pct,
        "estimated": True,
    }


def _normalize_plan(plan):
    if not plan:
        return DEFAULT_PLAN
    if not isinstance(plan, str):
        return DEFAULT_PLAN
    normalized = plan.strip().lower()
    return normalized or DEFAULT_PLAN
