#!/usr/bin/env python3
# <xbar.title>Claude Budget</xbar.title>
# <xbar.version>v3.0</xbar.version>
# <xbar.author>xaviguardia</xbar.author>
# <xbar.desc>Claude Max weekly budget — real data from Anthropic API</xbar.desc>
# <xbar.refreshOnOpen>true</xbar.refreshOnOpen>
# <xbar.dependencies>python3,matplotlib</xbar.dependencies>

"""
Shows Claude Max weekly budget in the macOS menu bar.
Reads your OAuth token from the macOS Keychain (same token Claude Code uses).
Sends native macOS notifications when approaching the limit.

No configuration needed — just drop in your xbar plugins folder.
Requires: matplotlib  (pip3 install matplotlib)
"""

import json, subprocess, urllib.request, base64, io, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

ANTHROPIC_URL  = "https://api.anthropic.com/api/oauth/usage"
ANTHROPIC_BETA = "oauth-2025-04-20"
NOTIFY_AT      = [80, 90]          # thresholds for macOS notifications
STATE_FILE     = os.path.expanduser("~/.claude/.budget_notified")


# ── Keychain ──────────────────────────────────────────────────────────────────

def get_access_token():
    try:
        raw = subprocess.check_output(
            ["security", "find-generic-password", "-s", "Claude Code-credentials", "-w"],
            stderr=subprocess.DEVNULL
        ).decode().strip()
        return json.loads(raw).get("claudeAiOauth", {}).get("accessToken")
    except Exception:
        return None


# ── Anthropic API ─────────────────────────────────────────────────────────────

def fetch_utilization():
    token = get_access_token()
    if not token:
        return None
    req = urllib.request.Request(
        ANTHROPIC_URL,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "claude-code/2.1.87",
            "anthropic-beta": ANTHROPIC_BETA,
        },
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        return json.loads(r.read())


# ── Notifications ─────────────────────────────────────────────────────────────

def load_notified():
    try:
        return set(json.loads(open(STATE_FILE).read()))
    except Exception:
        return set()

def save_notified(notified):
    with open(STATE_FILE, "w") as f:
        f.write(json.dumps(list(notified)))

def notify(title, message):
    script = f'display notification "{message}" with title "{title}" sound name "Basso"'
    subprocess.run(["osascript", "-e", script], capture_output=True)

def check_notifications(seven_day_pct, resets_at):
    notified = load_notified()
    # Reset state if we're in a new cycle (pct went back to low)
    if seven_day_pct < 50 and notified:
        notified = set()
        save_notified(notified)
        return

    reset_str = ""
    if resets_at:
        from datetime import datetime, timezone
        try:
            dt = datetime.fromisoformat(resets_at)
            reset_str = f" Resets {dt.strftime('%a %b %-d at %-I:%M %p')}."
        except Exception:
            pass

    for threshold in NOTIFY_AT:
        key = str(threshold)
        if seven_day_pct >= threshold and key not in notified:
            if threshold >= 90:
                notify(
                    "🔴 Claude Max — Critical",
                    f"Weekly budget at {seven_day_pct:.0f}%.{reset_str} Slow down!"
                )
            else:
                notify(
                    "🟡 Claude Max — Warning",
                    f"Weekly budget at {seven_day_pct:.0f}%.{reset_str}"
                )
            notified.add(key)
            save_notified(notified)


# ── Ring image ────────────────────────────────────────────────────────────────

def make_ring(pct, color, size=22):
    fig, ax = plt.subplots(figsize=(size/72, size/72), dpi=72)
    fig.patch.set_facecolor("none")
    ax.set_aspect("equal")
    ax.axis("off")
    p = min(pct / 100, 1.0)
    theta = np.linspace(0, 2 * np.pi, 300)
    ax.plot(np.cos(theta), np.sin(theta), color="#30363d", linewidth=3.5, solid_capstyle="round")
    if p > 0:
        t = np.linspace(np.pi/2, np.pi/2 - 2*np.pi*p, max(int(300*p), 2))
        ax.plot(np.cos(t), np.sin(t), color=color, linewidth=3.5, solid_capstyle="round")
    ax.set_xlim(-1.4, 1.4); ax.set_ylim(-1.4, 1.4)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", transparent=True, pad_inches=0)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    try:
        data       = fetch_utilization()
        seven      = data.get("seven_day") or {}
        sonnet     = data.get("seven_day_sonnet") or {}
        five_hour  = data.get("five_hour") or {}

        pct        = seven.get("utilization") or 0
        resets_at  = seven.get("resets_at")
        sonnet_pct = sonnet.get("utilization") or 0
        fh_pct     = five_hour.get("utilization") or 0

    except Exception as e:
        img = make_ring(0, "#8b949e")
        print(f"— | image={img}")
        print("---")
        print(f"Claude API unavailable | color=#8b949e size=12")
        print(f"{e} | color=#8b949e size=10")
        return

    # Notification check
    check_notifications(pct, resets_at)

    # Color based on severity
    if pct >= 90:
        color = "#f85149"   # red
    elif pct >= 80:
        color = "#d29922"   # yellow
    elif pct >= 60:
        color = "#f0883e"   # orange
    else:
        color = "#3fb950"   # green

    img = make_ring(pct, color)

    # ── Menu bar line ──────────────────────────────────────────────────────
    print(f"{pct:.0f}% | image={img} color={color} font=Menlo size=11")
    print("---")

    # Reset time
    reset_label = ""
    if resets_at:
        from datetime import datetime, timezone
        try:
            dt = datetime.fromisoformat(resets_at).astimezone()
            reset_label = f"  ·  resets {dt.strftime('%a %-d %b %-I:%M %p')}"
        except Exception:
            pass

    print(f"Weekly (all models): {pct:.0f}%{reset_label} | size=13 color=#e6edf3")
    print(f"Sonnet only: {sonnet_pct:.0f}%  ·  5h window: {fh_pct:.0f}% | size=11 color=#8b949e")
    print("---")
    print("Open dashboard | href=http://localhost:8765 color=#58a6ff size=12")
    print("Refresh | refresh=true color=#8b949e size=11")


if __name__ == "__main__":
    main()
