"""PyPI update check for obsly-ai. Stdlib only — must not break Tier 1 zero-deps."""

import json
import os
import time
from pathlib import Path
from urllib.request import urlopen

PYPI_URL = "https://pypi.org/pypi/obsly-ai/json"
CACHE_TTL_OK = 24 * 3600       # 24h on success
CACHE_TTL_FAIL = 60 * 60       # 1h on failure (don't hammer)
HTTP_TIMEOUT = 2.0             # never block the CLI more than ~2s
_DEFAULT_CACHE = Path.home() / ".claude" / ".obsly_version_check"


def _parse_version(v):
    """Best-effort tuple of ints from a SemVer-ish string. '0.4.0' -> (0,4,0)."""
    out = []
    for part in str(v).split("."):
        num = ""
        for ch in part:
            if ch.isdigit():
                num += ch
            else:
                break
        out.append(int(num) if num else 0)
    return tuple(out)


def _is_newer(latest, current):
    try:
        return _parse_version(latest) > _parse_version(current)
    except Exception:
        return False


def _read_cache(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return None


def _write_cache(path, data):
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def check_for_update(current_version, cache_path=None):
    """Return the latest PyPI version if newer than `current_version`, else None.

    - Respects $OBSLY_NO_UPDATE_CHECK=1 (returns None without doing anything).
    - Caches the result for 24h on success, 1h on failure.
    - Never raises. Network/parse errors are silent.
    """
    if os.environ.get("OBSLY_NO_UPDATE_CHECK"):
        return None

    cache_path = cache_path or str(_DEFAULT_CACHE)
    now = time.time()

    cache = _read_cache(cache_path)
    if cache:
        last = cache.get("last_check", 0)
        last_attempt = cache.get("last_attempt", 0)
        latest = cache.get("latest")
        if latest and (now - last) < CACHE_TTL_OK:
            return latest if _is_newer(latest, current_version) else None
        if (now - last_attempt) < CACHE_TTL_FAIL and not latest:
            return None

    latest = None
    try:
        with urlopen(PYPI_URL, timeout=HTTP_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
            latest = payload.get("info", {}).get("version")
    except Exception:
        _write_cache(cache_path, {
            "last_check": cache.get("last_check", 0) if cache else 0,
            "last_attempt": now,
            "latest": cache.get("latest") if cache else None,
        })
        return None

    _write_cache(cache_path, {
        "last_check": now,
        "last_attempt": now,
        "latest": latest,
    })
    return latest if _is_newer(latest, current_version) else None


def format_update_message(current_version, latest_version):
    """Build the user-facing stderr line. Returns None if no update."""
    if not latest_version:
        return None
    return (f"obsly-ai {latest_version} available "
            f"(you have {current_version}) — pipx upgrade obsly-ai")
