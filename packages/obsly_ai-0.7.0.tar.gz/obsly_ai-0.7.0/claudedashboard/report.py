#!/usr/bin/env python3
"""
Claude Code Token Usage Dashboard
Generates an interactive HTML dashboard and opens it in the browser.
Usage: python3 claude_token_dashboard.py

Reads Claude Code session logs from ~/.claude/projects/**/*.jsonl
No dependencies required beyond Python 3.6+.
"""

import json
import os
import glob
import webbrowser
import tempfile
import sys
from collections import defaultdict
from datetime import datetime

CLAUDE_DIR = os.path.expanduser("~/.claude/projects")

# ─── Data loading ────────────────────────────────────────────────────────────

def parse_date(ts):
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None

def load_records():
    records = []
    files = glob.glob(os.path.join(CLAUDE_DIR, "**/*.jsonl"), recursive=True)
    print(f"Reading {len(files)} JSONL files...", file=sys.stderr)
    for fpath in files:
        rel = os.path.relpath(fpath, CLAUDE_DIR)
        parts = rel.split(os.sep)
        project_raw = parts[0] if parts else "unknown"
        # Strip common home dir prefix for readability
        project = project_raw
        for prefix in [f"-Users-{os.getenv('USER', 'user')}-", "-Users-xavi-1-"]:
            project = project.replace(prefix, "")
        if project == project_raw:
            project = project_raw.lstrip("-").replace("-Users-", "")
        session_id = parts[1] if len(parts) > 1 else "unknown"
        is_subagent = "subagents" in rel

        try:
            with open(fpath, "r", encoding="utf-8") as f:
                file_version = "unknown"
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    # Grab Claude Code version from any record that has it
                    if file_version == "unknown" and obj.get("version"):
                        file_version = obj["version"]

                    msg = obj.get("message", {})
                    usage = msg.get("usage", {})
                    if not usage:
                        continue

                    input_t   = usage.get("input_tokens", 0) or 0
                    cache_cr  = usage.get("cache_creation_input_tokens", 0) or 0
                    cache_rd  = usage.get("cache_read_input_tokens", 0) or 0
                    output_t  = usage.get("output_tokens", 0) or 0
                    total = input_t + cache_cr + cache_rd + output_t
                    if total == 0:
                        continue

                    ts = obj.get("timestamp", "")
                    dt = parse_date(ts)

                    records.append({
                        "project":    project,
                        "session_id": session_id,
                        "is_subagent": is_subagent,
                        "timestamp":  ts,
                        "dt":         dt,
                        "day":        dt.strftime("%Y-%m-%d") if dt else "unknown",
                        "hour":       dt.hour if dt else 0,
                        "input":      input_t,
                        "cache_cr":   cache_cr,
                        "cache_rd":   cache_rd,
                        "output":     output_t,
                        "total":      total,
                        "model":      msg.get("model", "unknown"),
                        "cc_version": file_version,
                    })
        except Exception:
            pass
    print(f"  → {len(records):,} records with token usage", file=sys.stderr)
    return records

# ─── Aggregation ─────────────────────────────────────────────────────────────

def aggregate(records):
    by_day     = defaultdict(lambda: {"input": 0, "cache_cr": 0, "cache_rd": 0, "output": 0, "total": 0, "calls": 0})
    by_project = defaultdict(lambda: {"input": 0, "cache_cr": 0, "cache_rd": 0, "output": 0, "total": 0, "calls": 0})
    by_session = defaultdict(lambda: {"total": 0, "calls": 0, "project": ""})
    by_hour        = defaultdict(lambda: {"total": 0, "calls": 0})
    by_hour_ts     = defaultdict(lambda: {"input": 0, "cache_cr": 0, "cache_rd": 0, "output": 0, "total": 0, "calls": 0})
    by_model            = defaultdict(int)
    by_cc_version       = defaultdict(int)   # Claude Code version → total tokens
    calls_by_cc_version = defaultdict(int)   # Claude Code version → call count

    for r in records:
        d = r["day"]
        for k in ("input", "cache_cr", "cache_rd", "output", "total"):
            by_day[d][k] += r[k]
        by_day[d]["calls"] += 1

        p = r["project"]
        for k in ("input", "cache_cr", "cache_rd", "output", "total"):
            by_project[p][k] += r[k]
        by_project[p]["calls"] += 1

        key = (r["project"], r["session_id"][:8])
        by_session[key]["total"] += r["total"]
        by_session[key]["calls"] += 1
        by_session[key]["project"] = r["project"]

        by_hour[r["hour"]]["total"] += r["total"]
        by_hour[r["hour"]]["calls"] += 1

        # Hourly timeline key: "YYYY-MM-DD HH" for zoom chart
        if r["dt"]:
            hkey = r["dt"].strftime("%Y-%m-%d %H:00")
            for k in ("input", "cache_cr", "cache_rd", "output", "total"):
                by_hour_ts[hkey][k] += r[k]
            by_hour_ts[hkey]["calls"] += 1

        by_model[r["model"]] += r["total"]
        by_cc_version[r["cc_version"]] += r["total"]
        calls_by_cc_version[r["cc_version"]] += 1

    # Statistical anomalies: individual calls > mean + 3σ
    totals   = [r["total"] for r in records]
    mean     = sum(totals) / len(totals) if totals else 0
    variance = sum((x - mean) ** 2 for x in totals) / len(totals) if totals else 0
    std      = variance ** 0.5
    threshold = mean + 3 * std
    anomalies_all = sorted([r for r in records if r["total"] > threshold], key=lambda x: -x["total"])

    # Anomalies grouped by session
    anom_by_session = defaultdict(lambda: {"calls": 0, "total_tokens": 0, "max_tokens": 0, "project": "", "timestamps": []})
    for r in anomalies_all:
        key = (r["project"], r["session_id"])
        anom_by_session[key]["calls"] += 1
        anom_by_session[key]["total_tokens"] += r["total"]
        anom_by_session[key]["max_tokens"] = max(anom_by_session[key]["max_tokens"], r["total"])
        anom_by_session[key]["project"] = r["project"]
        if len(anom_by_session[key]["timestamps"]) < 2:
            anom_by_session[key]["timestamps"].append(r["timestamp"][:10])

    # Anomalous calls per day (for chart)
    anom_by_day = defaultdict(int)
    for r in anomalies_all:
        anom_by_day[r["day"]] += 1

    return {
        "by_day":          dict(sorted(by_day.items())),
        "by_project":      dict(sorted(by_project.items(), key=lambda x: -x[1]["total"])),
        "by_session":      dict(sorted(by_session.items(), key=lambda x: -x[1]["total"])[:20]),
        "by_hour":         dict(sorted(by_hour.items())),
        "by_hour_ts":      dict(sorted(by_hour_ts.items())),
        "by_model":        by_model,
        "by_cc_version":       dict(sorted(by_cc_version.items())),
        "calls_by_cc_version": dict(calls_by_cc_version),
        "anomalies_all":   anomalies_all,
        "anom_by_session": dict(sorted(anom_by_session.items(), key=lambda x: -x[1]["calls"])),
        "anom_by_day":     dict(sorted(anom_by_day.items())),
        "threshold":       threshold,
        "mean":            mean,
        "std":             std,
        "total_records": len(records),
        "grand_total":   sum(r["total"]    for r in records),
        "grand_input":   sum(r["input"]    for r in records),
        "grand_cache_cr":sum(r["cache_cr"] for r in records),
        "grand_cache_rd":sum(r["cache_rd"] for r in records),
        "grand_output":  sum(r["output"]   for r in records),
    }

# ─── HTML generation ─────────────────────────────────────────────────────────

def build_html(agg):
    days        = list(agg["by_day"].keys())
    days_totals = [agg["by_day"][d]["total"] // 1_000_000 for d in days]
    days_calls  = [agg["by_day"][d]["calls"] for d in days]

    avg_daily   = sum(days_totals) / len(days_totals) if days_totals else 0
    avg_line    = [round(avg_daily * 2)] * len(days)

    # Daily cache hit ratio (%) — key metric for detecting the cache overcounting bug
    def day_cache_hit(d):
        v = agg["by_day"][d]
        denom = v["input"] + v["cache_cr"] + v["cache_rd"]
        return round(v["cache_rd"] / denom * 100, 1) if denom > 0 else 0

    days_cache_hit = [day_cache_hit(d) for d in days]

    # Daily cache_read in millions (for the stacked breakdown chart)
    days_input_m    = [agg["by_day"][d]["input"]    // 1_000_000 for d in days]
    days_cache_cr_m = [agg["by_day"][d]["cache_cr"] // 1_000_000 for d in days]
    days_cache_rd_m = [agg["by_day"][d]["cache_rd"] // 1_000_000 for d in days]
    days_output_m   = [agg["by_day"][d]["output"]   // 1_000_000 for d in days]

    # Hourly timeline data (zoomable)
    hr_labels    = list(agg["by_hour_ts"].keys())
    hr_total_m   = [agg["by_hour_ts"][h]["total"]    // 1_000_000 for h in hr_labels]
    hr_cache_rd_m= [agg["by_hour_ts"][h]["cache_rd"] // 1_000_000 for h in hr_labels]
    hr_input_m   = [agg["by_hour_ts"][h]["input"]    // 1_000_000 for h in hr_labels]
    hr_output_m  = [agg["by_hour_ts"][h]["output"]   // 1_000_000 for h in hr_labels]
    hr_calls     = [agg["by_hour_ts"][h]["calls"]                  for h in hr_labels]
    def hr_cache_hit_fn(h):
        v = agg["by_hour_ts"][h]
        denom = v["input"] + v["cache_cr"] + v["cache_rd"]
        return round(v["cache_rd"] / denom * 100, 1) if denom > 0 else 0
    hr_cache_hit = [hr_cache_hit_fn(h) for h in hr_labels]

    top_projects  = list(agg["by_project"].items())[:15]
    proj_names    = [p[:30] for p, _ in top_projects]
    proj_totals   = [v["total"] // 1_000_000 for _, v in top_projects]

    hours       = list(range(24))
    hour_totals = [agg["by_hour"].get(h, {}).get("total", 0) // 1_000_000 for h in hours]

    model_labels = list(agg["by_model"].keys())
    model_vals   = [agg["by_model"][m] // 1_000_000 for m in model_labels]

    # Claude Code versions
    ccv_labels = list(agg["by_cc_version"].keys())
    ccv_vals   = [agg["by_cc_version"][v] // 1_000_000 for v in ccv_labels]

    # Sessions table
    sessions_rows = ""
    max_sess_total = max((v["total"] for v in agg["by_session"].values()), default=1)
    for (proj, sess), v in agg["by_session"].items():
        pct = min(100, v["total"] / max_sess_total * 100)
        sessions_rows += f"""
        <tr>
          <td title="{proj}">{proj[:38]}</td>
          <td class="mono">{sess}</td>
          <td class="num">{v['calls']:,}</td>
          <td class="num">{v['total'] // 1_000_000:,}M</td>
          <td><div class="bar-inline" style="width:{pct:.0f}%"></div></td>
        </tr>"""

    # Anomalies — by session summary
    anom_sess_rows = ""
    for (proj, sess), v in agg["anom_by_session"].items():
        anom_sess_rows += f"""
        <tr>
          <td title="{proj}">{proj[:42]}</td>
          <td class="mono">{sess}</td>
          <td class="num">{v['calls']:,}</td>
          <td class="num">{v['max_tokens']:,}</td>
          <td class="num">{v['total_tokens'] // 1_000_000:,}M</td>
          <td class="mono">{v['timestamps'][0] if v['timestamps'] else ''}</td>
        </tr>"""

    # Anomalies — all individual calls (for JS, capped at 5000 for page weight)
    anom_all_js = json.dumps([
        {"ts": r["timestamp"][:19].replace("T"," "), "proj": r["project"][:40],
         "sess": r["session_id"], "total": r["total"],
         "input": r["input"], "cache_rd": r["cache_rd"], "output": r["output"],
         "ver": r.get("cc_version", "?")}
        for r in agg["anomalies_all"][:5000]
    ])

    # Version → anomaly correlation
    anom_by_ver = defaultdict(int)
    for r in agg["anomalies_all"]:
        anom_by_ver[r.get("cc_version", "?")] += 1
    all_by_ver = agg["calls_by_cc_version"]
    ver_corr_labels = sorted(set(list(anom_by_ver.keys()) + list(all_by_ver.keys())))
    ver_corr_anom   = [anom_by_ver.get(v, 0) for v in ver_corr_labels]
    ver_corr_total  = [all_by_ver.get(v, 0)  for v in ver_corr_labels]
    ver_corr_pct    = [round(anom_by_ver.get(v,0) / all_by_ver.get(v,1) * 100, 1) for v in ver_corr_labels]

    # Anomalous calls per day chart data
    anom_days       = list(agg["anom_by_day"].keys())
    anom_day_counts = [agg["anom_by_day"][d] for d in anom_days]
    total_anom      = len(agg["anomalies_all"])

    # Projects table
    proj_table_rows = ""
    for proj, v in agg["by_project"].items():
        cache_pct = (v["cache_rd"] / v["total"] * 100) if v["total"] > 0 else 0
        proj_table_rows += f"""
        <tr>
          <td title="{proj}">{proj[:45]}</td>
          <td class="num">{v['calls']:,}</td>
          <td class="num">{v['total'] // 1_000_000:,}M</td>
          <td class="num">{v['input'] // 1_000:,}K</td>
          <td class="num">{v['cache_cr'] // 1_000:,}K</td>
          <td class="num">{v['cache_rd'] // 1_000_000:,}M</td>
          <td class="num">{v['output'] // 1_000:,}K</td>
          <td class="num">{cache_pct:.0f}%</td>
        </tr>"""

    grand      = agg["grand_total"]
    denom      = agg["grand_cache_rd"] + agg["grand_input"] + agg["grand_cache_cr"]
    cache_hit  = (agg["grand_cache_rd"] / denom * 100) if denom > 0 else 0
    alert_days = sum(1 for t in days_totals if t > avg_daily * 2)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Claude Code Token Usage Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    :root {{
      --bg: #0f1117; --card: #1a1d2e; --card2: #232640; --border: #2e3158;
      --accent: #6c63ff; --accent2: #ff6584; --accent3: #43e97b; --accent4: #f7971e;
      --text: #e0e0f0; --muted: #8888aa; --red: #ff4757; --yellow: #ffa502; --green: #2ed573;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ background: var(--bg); color: var(--text); font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; font-size: 14px; }}
    h1 {{ font-size: 22px; font-weight: 700; }}
    h2 {{ font-size: 13px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 14px; }}
    header {{ background: var(--card); border-bottom: 1px solid var(--border); padding: 18px 28px; display: flex; align-items: center; gap: 16px; }}
    header .dot {{ width: 10px; height: 10px; border-radius: 50%; background: var(--accent); box-shadow: 0 0 10px var(--accent); }}
    .subtitle {{ font-size: 12px; color: var(--muted); margin-top: 4px; }}
    .container {{ max-width: 1400px; margin: 0 auto; padding: 24px; }}
    .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 14px; margin-bottom: 24px; }}
    .kpi {{ background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; }}
    .kpi .label {{ font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 8px; }}
    .kpi .value {{ font-size: 28px; font-weight: 700; }}
    .kpi .value.red {{ color: var(--red); }}
    .kpi .value.yellow {{ color: var(--yellow); }}
    .kpi .value.green {{ color: var(--green); }}
    .kpi .value.purple {{ color: var(--accent); }}
    .kpi .sub {{ font-size: 11px; color: var(--muted); margin-top: 5px; }}
    .grid-2 {{ display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-bottom: 18px; }}
    .grid-3 {{ display: grid; grid-template-columns: 2fr 1fr; gap: 18px; margin-bottom: 18px; }}
    .card {{ background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; }}
    .chart-wrap {{ position: relative; }}
    .section {{ margin-bottom: 24px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
    th {{ text-align: left; color: var(--muted); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.6px; padding: 8px 10px; border-bottom: 1px solid var(--border); }}
    td {{ padding: 8px 10px; border-bottom: 1px solid #1e2035; vertical-align: middle; }}
    tr:hover td {{ background: var(--card2); }}
    .num {{ text-align: right; font-variant-numeric: tabular-nums; font-family: 'SF Mono', 'Menlo', monospace; }}
    .mono {{ font-family: 'SF Mono', 'Menlo', monospace; font-size: 12px; color: var(--muted); }}
    .anom-row td {{ color: var(--red); }}
    .bar-inline {{ height: 6px; background: var(--accent); border-radius: 3px; min-width: 2px; }}
    .badge {{ display: inline-block; padding: 2px 9px; border-radius: 4px; font-size: 11px; font-weight: 600; }}
    .badge.red {{ background: #ff475722; color: var(--red); border: 1px solid #ff475744; }}
    .note {{ font-size: 12px; color: var(--muted); margin-bottom: 14px; line-height: 1.6; padding: 10px 14px; background: #ffffff08; border-left: 3px solid var(--accent); border-radius: 0 6px 6px 0; }}
    @media (max-width: 900px) {{ .grid-2, .grid-3 {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
<header>
  <div class="dot"></div>
  <div>
    <h1>Claude Code &mdash; Token Usage Dashboard</h1>
    <div class="subtitle">
      Local analysis of <strong style="color:var(--text)">{agg["total_records"]:,}</strong> API calls &nbsp;·&nbsp;
      Source: <code style="font-size:11px">~/.claude/projects/**/*.jsonl</code> &nbsp;·&nbsp;
      Generated {datetime.now().strftime("%Y-%m-%d %H:%M")}
    </div>
  </div>
</header>

<div class="container">

  <div class="note" style="margin-bottom:20px">
    <strong>About this tool:</strong> Reads Claude Code local session logs and visualises token consumption over time.
    Useful for investigating anomalous usage spikes (e.g. <a href="https://github.com/anthropics/claude-code/issues/40535" style="color:var(--accent)">issue #40535</a>).
    No data leaves your machine.
  </div>

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi">
      <div class="label">Total tokens</div>
      <div class="value purple">{grand / 1_000_000_000:.1f}B</div>
      <div class="sub">{grand:,}</div>
    </div>
    <div class="kpi">
      <div class="label">Cache read</div>
      <div class="value green">{agg["grand_cache_rd"] / 1_000_000_000:.1f}B</div>
      <div class="sub">Cache hit ratio: {cache_hit:.1f}%</div>
    </div>
    <div class="kpi">
      <div class="label">Input tokens</div>
      <div class="value">{agg["grand_input"] / 1_000_000:.1f}M</div>
      <div class="sub">Billed at full rate</div>
    </div>
    <div class="kpi">
      <div class="label">Cache creation</div>
      <div class="value yellow">{agg["grand_cache_cr"] / 1_000_000:.1f}M</div>
      <div class="sub">~1.25× input cost</div>
    </div>
    <div class="kpi">
      <div class="label">Output tokens</div>
      <div class="value">{agg["grand_output"] / 1_000_000:.1f}M</div>
      <div class="sub">Most expensive per token</div>
    </div>
    <div class="kpi">
      <div class="label">Alert days</div>
      <div class="value red">{alert_days}</div>
      <div class="sub">out of {len(days)} days (&gt;2× avg)</div>
    </div>
    <div class="kpi">
      <div class="label">Projects</div>
      <div class="value">{len(agg["by_project"])}</div>
      <div class="sub">{len(agg["by_session"])} top sessions</div>
    </div>
    <div class="kpi">
      <div class="label">API calls</div>
      <div class="value">{agg["total_records"] / 1000:.0f}K</div>
      <div class="sub">recorded locally</div>
    </div>
  </div>

  <!-- Daily consumption -->
  <div class="section card">
    <h2>Daily token consumption (millions)</h2>
    <div class="chart-wrap" style="height:280px">
      <canvas id="chartDaily"></canvas>
    </div>
  </div>

  <!-- Cache hit ratio over time — KEY CHART for bug investigation -->
  <div class="section card">
    <h2>Daily cache hit ratio (%) &amp; token breakdown</h2>
    <p class="note" style="margin-bottom:14px">
      <strong>Cache hit ratio</strong> = cache_read / (input + cache_write + cache_read).
      A sudden <em>drop</em> means more tokens billed at full price.
      A sustained ratio near 100% with huge <em>total</em> spikes suggests the context window
      is ballooning — each call re-reads the same enormous cache.
      This is the key signal for <a href="https://github.com/anthropics/claude-code/issues/40535" style="color:var(--accent)">issue #40535</a>.
    </p>
    <div class="chart-wrap" style="height:260px">
      <canvas id="chartCacheRatio"></canvas>
    </div>
  </div>

  <!-- Stacked token breakdown per day -->
  <div class="section card">
    <h2>Daily token breakdown — stacked (millions)</h2>
    <div class="chart-wrap" style="height:260px">
      <canvas id="chartStacked"></canvas>
    </div>
  </div>

  <!-- Hourly timeline — zoomable -->
  <div class="section card">
    <h2>Hourly timeline — cache hit ratio &amp; consumption &nbsp;<span class="badge" style="background:#6c63ff22;color:#6c63ff;border:1px solid #6c63ff44">scroll to zoom · drag to pan</span></h2>
    <p class="note" style="margin-bottom:14px">
      Granularity: 1 hour. Shows every hour with recorded API calls. Hover for details.
    </p>
    <div class="chart-wrap" style="height:300px">
      <canvas id="chartHourlyTimeline"></canvas>
    </div>
    <div style="margin-top:18px">
      <div class="chart-wrap" style="height:160px">
        <canvas id="chartHourlyStacked"></canvas>
      </div>
    </div>
  </div>

  <!-- Calls per day + Hourly heatmap -->
  <div class="grid-2 section">
    <div class="card">
      <h2>API calls per day</h2>
      <div class="chart-wrap" style="height:220px">
        <canvas id="chartCalls"></canvas>
      </div>
    </div>
    <div class="card">
      <h2>Usage by hour of day (UTC)</h2>
      <div class="chart-wrap" style="height:220px">
        <canvas id="chartHour"></canvas>
      </div>
    </div>
  </div>

  <!-- Projects -->
  <div class="grid-3 section">
    <div class="card">
      <h2>Top 15 projects by token usage (M)</h2>
      <div class="chart-wrap" style="height:340px">
        <canvas id="chartProjects"></canvas>
      </div>
    </div>
    <div class="card">
      <h2>Token composition</h2>
      <div class="chart-wrap" style="height:180px">
        <canvas id="chartCompo"></canvas>
      </div>
      <div style="margin-top:16px">
        <h2>Claude model</h2>
        <div class="chart-wrap" style="height:110px">
          <canvas id="chartModels"></canvas>
        </div>
      </div>
      <div style="margin-top:16px">
        <h2>Claude Code version</h2>
        <div class="chart-wrap" style="height:110px">
          <canvas id="chartCCVersion"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- Projects table -->
  <div class="section card">
    <h2>Breakdown by project</h2>
    <div style="overflow-x:auto">
      <table>
        <thead>
          <tr>
            <th>Project</th><th>Calls</th><th>Total</th><th>Input</th>
            <th>Cache write</th><th>Cache read</th><th>Output</th><th>Cache%</th>
          </tr>
        </thead>
        <tbody>{proj_table_rows}</tbody>
      </table>
    </div>
  </div>

  <!-- Top sessions -->
  <div class="section card">
    <h2>Top 20 most expensive sessions</h2>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Project</th><th>Session ID</th><th>Calls</th><th>Total</th><th>Volume</th></tr></thead>
        <tbody>{sessions_rows}</tbody>
      </table>
    </div>
  </div>

  <!-- Anomalies -->
  <div class="section card">
    <h2>
      Anomalous calls — overview &nbsp;
      <span class="badge red">threshold: {agg["threshold"]:,.0f} tokens &nbsp;(mean {agg["mean"]:,.0f} + 3σ {agg["std"]:,.0f})</span>
    </h2>
    <p class="note" style="margin-bottom:16px">
      <strong>{total_anom:,} calls</strong> exceed the threshold across
      <strong>{len(agg["anom_by_session"])}</strong> sessions and
      <strong>{len(set(k[0] for k in agg["anom_by_session"]))}</strong> projects.
      A high <em>cache_read</em> with near-zero <em>input</em>/<em>output</em> means the context window
      is enormous and being re-read on every call — key evidence for
      <a href="https://github.com/anthropics/claude-code/issues/40535" style="color:var(--accent)">issue #40535</a>.
    </p>

    <!-- Anomalous calls per day chart -->
    <div class="chart-wrap" style="height:180px; margin-bottom:20px">
      <canvas id="chartAnomDay"></canvas>
    </div>

    <!-- By session -->
    <h2 style="margin-top:4px">Affected sessions</h2>
    <div style="overflow-x:auto; margin-bottom:20px">
      <table>
        <thead><tr><th>Project</th><th>Session</th><th>Anom. calls</th><th>Max tokens</th><th>Total anom.</th><th>First seen</th></tr></thead>
        <tbody>{anom_sess_rows}</tbody>
      </table>
    </div>

    <!-- Version vs anomalies correlation -->
    <h2 style="margin-top:4px">Claude Code version correlation</h2>
    <p class="note" style="margin-bottom:12px">
      <strong>% anomalous calls</strong> = anomalous calls / total calls per version.
      A spike in a specific version points to a regression introduced in that release.
    </p>
    <div class="chart-wrap" style="height:200px; margin-bottom:20px">
      <canvas id="chartVerCorr"></canvas>
    </div>

    <!-- All individual calls — filterable -->
    <h2>All anomalous calls <span style="color:var(--muted);font-size:11px;text-transform:none;letter-spacing:0">(showing up to 5,000)</span></h2>
    <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
      <input id="anomSearch" type="text" placeholder="Filter by project, session or version..."
        style="background:#0f1117;border:1px solid var(--border);color:var(--text);padding:7px 12px;border-radius:6px;font-size:13px;width:280px"
        oninput="filterAnom()">
      <select id="anomSort" onchange="filterAnom()"
        style="background:#0f1117;border:1px solid var(--border);color:var(--text);padding:7px 12px;border-radius:6px;font-size:13px">
        <option value="total">Sort: Total tokens ↓</option>
        <option value="cache_rd">Sort: Cache read ↓</option>
        <option value="ts">Sort: Time ↑</option>
      </select>
      <span id="anomCount" style="line-height:34px;font-size:12px;color:var(--muted)"></span>
    </div>
    <div style="overflow-x:auto;max-height:520px;overflow-y:auto">
      <table id="anomTable">
        <thead style="position:sticky;top:0;background:var(--card);z-index:1">
          <tr><th>Timestamp (UTC)</th><th>Project</th><th>Session</th><th>CC Version</th><th>Total tokens</th><th>Input</th><th>Cache read</th><th>Output</th></tr>
        </thead>
        <tbody id="anomTbody"></tbody>
      </table>
    </div>
  </div>

</div>

<script>
const C = id => document.getElementById(id).getContext('2d');
const DAYS         = {json.dumps(days)};
const DAYS_TOTAL   = {json.dumps(days_totals)};
const AVG_LINE     = {json.dumps(avg_line)};
const DAYS_CALLS   = {json.dumps(days_calls)};
const PROJ         = {json.dumps(proj_names)};
const PROJ_TOTAL   = {json.dumps(proj_totals)};
const HOURS        = {json.dumps(list(range(24)))};
const HOUR_TOTAL   = {json.dumps(hour_totals)};
const MODEL_LABELS = {json.dumps(model_labels)};
const MODEL_VALS   = {json.dumps(model_vals)};
const CCV_LABELS   = {json.dumps(ccv_labels)};
const CCV_VALS     = {json.dumps(ccv_vals)};
const VER_CORR_LABELS = {json.dumps(ver_corr_labels)};
const VER_CORR_ANOM   = {json.dumps(ver_corr_anom)};
const VER_CORR_TOTAL  = {json.dumps(ver_corr_total)};
const VER_CORR_PCT    = {json.dumps(ver_corr_pct)};

const DAYS_CACHE_HIT  = {json.dumps(days_cache_hit)};
const DAYS_INPUT_M    = {json.dumps(days_input_m)};
const DAYS_CACHE_CR_M = {json.dumps(days_cache_cr_m)};
const DAYS_CACHE_RD_M = {json.dumps(days_cache_rd_m)};
const DAYS_OUTPUT_M   = {json.dumps(days_output_m)};
const HR_LABELS       = {json.dumps(hr_labels)};
const HR_TOTAL_M      = {json.dumps(hr_total_m)};
const HR_CACHE_HIT    = {json.dumps(hr_cache_hit)};
const HR_CACHE_RD_M   = {json.dumps(hr_cache_rd_m)};
const HR_INPUT_M      = {json.dumps(hr_input_m)};
const HR_OUTPUT_M     = {json.dumps(hr_output_m)};
const HR_CALLS        = {json.dumps(hr_calls)};
const ANOM_DAYS       = {json.dumps(anom_days)};
const ANOM_DAY_COUNTS = {json.dumps(anom_day_counts)};
const ANOM_ALL        = {anom_all_js};

const PALETTE = ['#6c63ff','#ff6584','#43e97b','#f7971e','#38f9d7','#fa709a','#fee140','#4facfe','#a8edea','#fed6e3','#96fbc4','#f5e6ff','#fccb90','#d57eeb','#89f7fe'];
const gridColor = '#2e315844';
const tickColor = '#8888aa';
const baseOpts = {{
  responsive: true, maintainAspectRatio: false,
  plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 12 }} }} }} }},
}};

// Hourly timeline — cache hit ratio (dual axis)
new Chart(C('chartHourlyTimeline'), {{
  type: 'bar',
  data: {{
    labels: HR_LABELS,
    datasets: [
      {{ label: 'Cache hit ratio (%)', data: HR_CACHE_HIT, type: 'line', borderColor: '#43e97b', backgroundColor: '#43e97b11', borderWidth: 2, pointRadius: 1, yAxisID: 'yPct', fill: true, order: 1 }},
      {{ label: 'Total (M tokens)',    data: HR_TOTAL_M,   backgroundColor: '#6c63ff44', borderColor: '#6c63ff', borderWidth: 0.5, yAxisID: 'yTokens', order: 2 }},
    ]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    interaction: {{ mode: 'index', intersect: false }},
    plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 12 }} }} }} }},
    scales: {{
      x: {{ ticks: {{ color: tickColor, maxRotation: 60, font: {{ size: 9 }}, maxTicksLimit: 30 }}, grid: {{ color: '#2e315822' }} }},
      yPct:    {{ position: 'left',  min: 0, max: 100, ticks: {{ color: '#43e97b', callback: v => v + '%' }}, grid: {{ color: gridColor }}, title: {{ display: true, text: 'Cache hit %', color: '#43e97b', font: {{ size: 11 }} }} }},
      yTokens: {{ position: 'right', ticks: {{ color: '#6c63ff' }}, grid: {{ display: false }}, title: {{ display: true, text: 'M tokens', color: '#6c63ff', font: {{ size: 11 }} }} }}
    }}
  }}
}});

new Chart(C('chartHourlyStacked'), {{
  type: 'bar',
  data: {{
    labels: HR_LABELS,
    datasets: [
      {{ label: 'Cache read', data: HR_CACHE_RD_M, backgroundColor: '#43e97b88', borderWidth: 0, stack: 's' }},
      {{ label: 'Input',      data: HR_INPUT_M,    backgroundColor: '#6c63ff88', borderWidth: 0, stack: 's' }},
      {{ label: 'Output',     data: HR_OUTPUT_M,   backgroundColor: '#ff658488', borderWidth: 0, stack: 's' }},
    ]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    interaction: {{ mode: 'index', intersect: false }},
    plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 11 }} }} }} }},
    scales: {{
      x: {{ stacked: true, ticks: {{ color: tickColor, maxRotation: 60, font: {{ size: 9 }}, maxTicksLimit: 30 }}, grid: {{ color: '#2e315822' }} }},
      y: {{ stacked: true, ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
    }}
  }}
}});

// Cache hit ratio + total (dual axis)
new Chart(C('chartCacheRatio'), {{
  type: 'bar',
  data: {{
    labels: DAYS,
    datasets: [
      {{ label: 'Cache hit ratio (%)', data: DAYS_CACHE_HIT, type: 'line', borderColor: '#43e97b', backgroundColor: '#43e97b22', borderWidth: 2, pointRadius: 2, yAxisID: 'yPct', fill: true, order: 1 }},
      {{ label: 'Total (M tokens)', data: DAYS_TOTAL, backgroundColor: '#6c63ff33', borderColor: '#6c63ff', borderWidth: 1, yAxisID: 'yTokens', order: 2 }},
    ]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 12 }} }} }} }},
    scales: {{
      x: {{ ticks: {{ color: tickColor, maxRotation: 45, font: {{ size: 10 }} }}, grid: {{ color: '#2e315822' }} }},
      yPct: {{ position: 'left', min: 0, max: 100, ticks: {{ color: '#43e97b', callback: v => v + '%' }}, grid: {{ color: gridColor }}, title: {{ display: true, text: 'Cache hit %', color: '#43e97b', font: {{ size: 11 }} }} }},
      yTokens: {{ position: 'right', ticks: {{ color: '#6c63ff' }}, grid: {{ display: false }}, title: {{ display: true, text: 'M tokens', color: '#6c63ff', font: {{ size: 11 }} }} }}
    }}
  }}
}});

// Stacked daily breakdown
new Chart(C('chartStacked'), {{
  type: 'bar',
  data: {{
    labels: DAYS,
    datasets: [
      {{ label: 'Cache read', data: DAYS_CACHE_RD_M, backgroundColor: '#43e97b88', borderWidth: 0, stack: 's' }},
      {{ label: 'Input',      data: DAYS_INPUT_M,    backgroundColor: '#6c63ff88', borderWidth: 0, stack: 's' }},
      {{ label: 'Cache write',data: DAYS_CACHE_CR_M, backgroundColor: '#f7971e88', borderWidth: 0, stack: 's' }},
      {{ label: 'Output',     data: DAYS_OUTPUT_M,   backgroundColor: '#ff658488', borderWidth: 0, stack: 's' }},
    ]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 12 }} }} }} }},
    scales: {{
      x: {{ stacked: true, ticks: {{ color: tickColor, maxRotation: 45, font: {{ size: 10 }} }}, grid: {{ color: '#2e315822' }} }},
      y: {{ stacked: true, ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
    }}
  }}
}});

// Daily consumption
new Chart(C('chartDaily'), {{
  type: 'bar',
  data: {{
    labels: DAYS,
    datasets: [
      {{ label: 'Total (M tokens)', data: DAYS_TOTAL, backgroundColor: '#6c63ff44', borderColor: '#6c63ff', borderWidth: 1.5, order: 2 }},
      {{ label: '2× daily average (alert threshold)', data: AVG_LINE, type: 'line', borderColor: '#ff475799', borderWidth: 1.5, borderDash: [6,3], pointRadius: 0, fill: false, order: 1 }},
    ]
  }},
  options: {{ ...baseOpts, scales: {{
    x: {{ ticks: {{ color: tickColor, maxRotation: 45, font: {{ size: 10 }} }}, grid: {{ color: '#2e315822' }} }},
    y: {{ ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
  }} }}
}});

// Calls per day
new Chart(C('chartCalls'), {{
  type: 'bar',
  data: {{ labels: DAYS, datasets: [{{ label: 'API calls/day', data: DAYS_CALLS, backgroundColor: '#43e97b44', borderColor: '#43e97b', borderWidth: 1 }}] }},
  options: {{ ...baseOpts, plugins: {{ legend: {{ display: false }} }}, scales: {{
    x: {{ ticks: {{ color: tickColor, maxRotation: 45, font: {{ size: 9 }} }}, grid: {{ color: '#2e315822' }} }},
    y: {{ ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
  }} }}
}});

// Hourly
new Chart(C('chartHour'), {{
  type: 'bar',
  data: {{ labels: HOURS.map(h => h + ':00'), datasets: [{{ label: 'M tokens', data: HOUR_TOTAL, backgroundColor: '#f7971e44', borderColor: '#f7971e', borderWidth: 1 }}] }},
  options: {{ ...baseOpts, plugins: {{ legend: {{ display: false }} }}, scales: {{
    x: {{ ticks: {{ color: tickColor, font: {{ size: 10 }} }}, grid: {{ display: false }} }},
    y: {{ ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
  }} }}
}});

// Projects
new Chart(C('chartProjects'), {{
  type: 'bar',
  data: {{ labels: PROJ, datasets: [{{ label: 'M tokens', data: PROJ_TOTAL, backgroundColor: PALETTE.map(c => c + '77'), borderColor: PALETTE, borderWidth: 1 }}] }},
  options: {{ ...baseOpts, indexAxis: 'y', plugins: {{ legend: {{ display: false }} }}, scales: {{
    x: {{ ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }},
    y: {{ ticks: {{ color: '#ccc', font: {{ size: 11 }} }}, grid: {{ display: false }} }}
  }} }}
}});

// Composition donut
new Chart(C('chartCompo'), {{
  type: 'doughnut',
  data: {{
    labels: ['Cache read', 'Input', 'Cache write', 'Output'],
    datasets: [{{
      data: [{agg["grand_cache_rd"]}, {agg["grand_input"]}, {agg["grand_cache_cr"]}, {agg["grand_output"]}],
      backgroundColor: ['#43e97b88','#6c63ff88','#f7971e88','#ff658488'],
      borderColor:     ['#43e97b',  '#6c63ff',  '#f7971e',  '#ff6584'],
      borderWidth: 1.5
    }}]
  }},
  options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ legend: {{ position: 'bottom', labels: {{ color: tickColor, font: {{ size: 11 }}, boxWidth: 12 }} }} }} }}
}});

// Models donut
new Chart(C('chartModels'), {{
  type: 'doughnut',
  data: {{ labels: MODEL_LABELS, datasets: [{{ data: MODEL_VALS, backgroundColor: PALETTE.map(c => c + '99'), borderColor: PALETTE, borderWidth: 1 }}] }},
  options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ legend: {{ position: 'bottom', labels: {{ color: tickColor, font: {{ size: 10 }}, boxWidth: 10 }} }} }} }}
}});

// Claude Code version donut
new Chart(C('chartCCVersion'), {{
  type: 'doughnut',
  data: {{ labels: CCV_LABELS, datasets: [{{ data: CCV_VALS, backgroundColor: PALETTE.slice(3).map(c => c + '99'), borderColor: PALETTE.slice(3), borderWidth: 1 }}] }},
  options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ legend: {{ position: 'bottom', labels: {{ color: tickColor, font: {{ size: 10 }}, boxWidth: 10 }} }} }} }}
}});

// Version correlation chart (dual axis: counts + %)
new Chart(C('chartVerCorr'), {{
  type: 'bar',
  data: {{
    labels: VER_CORR_LABELS,
    datasets: [
      {{ label: 'Anomalous calls', data: VER_CORR_ANOM,  backgroundColor: '#ff475766', borderColor: '#ff4757', borderWidth: 1, order: 2, yAxisID: 'yCalls' }},
      {{ label: 'Total calls',     data: VER_CORR_TOTAL, backgroundColor: '#6c63ff33', borderColor: '#6c63ff', borderWidth: 1, order: 3, yAxisID: 'yCalls' }},
      {{ label: '% anomalous',     data: VER_CORR_PCT,   type: 'line', borderColor: '#ffa502', borderWidth: 2.5, pointRadius: 4, pointBackgroundColor: '#ffa502', yAxisID: 'yPct', order: 1 }},
    ]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    interaction: {{ mode: 'index', intersect: false }},
    plugins: {{ legend: {{ labels: {{ color: tickColor, font: {{ size: 12 }} }} }} }},
    scales: {{
      x: {{ ticks: {{ color: tickColor }}, grid: {{ color: '#2e315822' }} }},
      yCalls: {{ position: 'left',  ticks: {{ color: tickColor }}, grid: {{ color: gridColor }}, title: {{ display: true, text: 'Calls', color: tickColor, font: {{ size: 11 }} }} }},
      yPct:   {{ position: 'right', min: 0, max: 100, ticks: {{ color: '#ffa502', callback: v => v + '%' }}, grid: {{ display: false }}, title: {{ display: true, text: '% anomalous', color: '#ffa502', font: {{ size: 11 }} }} }},
    }}
  }}
}});

// Anomalous calls per day chart
new Chart(C('chartAnomDay'), {{
  type: 'bar',
  data: {{
    labels: ANOM_DAYS,
    datasets: [{{ label: 'Anomalous calls/day', data: ANOM_DAY_COUNTS, backgroundColor: '#ff475766', borderColor: '#ff4757', borderWidth: 1 }}]
  }},
  options: {{
    responsive: true, maintainAspectRatio: false,
    plugins: {{ legend: {{ display: false }} }},
    scales: {{
      x: {{ ticks: {{ color: tickColor, maxRotation: 45, font: {{ size: 10 }} }}, grid: {{ color: '#2e315822' }} }},
      y: {{ ticks: {{ color: tickColor }}, grid: {{ color: gridColor }} }}
    }}
  }}
}});

// Anomalous calls — filterable table
let anomFiltered = [...ANOM_ALL];
function renderAnom() {{
  const tb = document.getElementById('anomTbody');
  const frag = document.createDocumentFragment();
  anomFiltered.forEach(r => {{
    const tr = document.createElement('tr');
    tr.className = 'anom-row';
    tr.innerHTML = `
      <td class="mono">${{r.ts}}</td>
      <td title="${{r.proj}}">${{r.proj}}</td>
      <td class="mono">${{r.sess}}</td>
      <td class="mono" style="color:var(--yellow)">${{r.ver}}</td>
      <td class="num">${{r.total.toLocaleString()}}</td>
      <td class="num">${{r.input.toLocaleString()}}</td>
      <td class="num">${{r.cache_rd.toLocaleString()}}</td>
      <td class="num">${{r.output.toLocaleString()}}</td>`;
    frag.appendChild(tr);
  }});
  tb.innerHTML = '';
  tb.appendChild(frag);
  document.getElementById('anomCount').textContent = anomFiltered.length.toLocaleString() + ' calls';
}}
function filterAnom() {{
  const q   = document.getElementById('anomSearch').value.toLowerCase();
  const srt = document.getElementById('anomSort').value;
  anomFiltered = ANOM_ALL.filter(r => !q || r.proj.toLowerCase().includes(q) || r.sess.toLowerCase().includes(q) || r.ver.toLowerCase().includes(q));
  if (srt === 'total')    anomFiltered.sort((a,b) => b.total    - a.total);
  else if (srt === 'cache_rd') anomFiltered.sort((a,b) => b.cache_rd - a.cache_rd);
  else                    anomFiltered.sort((a,b) => a.ts.localeCompare(b.ts));
  renderAnom();
}}
filterAnom();
</script>
</body>
</html>"""
    return html

# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    records = load_records()
    if not records:
        print("No token usage records found.", file=sys.stderr)
        sys.exit(1)

    print("Aggregating data...", file=sys.stderr)
    agg = aggregate(records)

    print("Building HTML dashboard...", file=sys.stderr)
    html = build_html(agg)

    out_path = os.path.join(tempfile.gettempdir(), "claude_token_dashboard.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Dashboard saved to: {out_path}", file=sys.stderr)
    print("Opening in browser...", file=sys.stderr)
    webbrowser.open(f"file://{out_path}")
    print("Done!", file=sys.stderr)


if __name__ == "__main__":
    main()
