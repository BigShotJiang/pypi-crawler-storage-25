#!/usr/bin/env python3
"""Análisis de consumo de tokens de Claude Code"""

import json
import os
import glob
from collections import defaultdict
from datetime import datetime, date
import sys

CLAUDE_DIR = os.path.expanduser("~/.claude/projects")

def parse_date(ts):
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None

def load_all_jsonl():
    """Carga todos los .jsonl y extrae registros de uso de tokens."""
    records = []
    files = glob.glob(os.path.join(CLAUDE_DIR, "**/*.jsonl"), recursive=True)

    for fpath in files:
        # Extraer proyecto del path
        rel = os.path.relpath(fpath, CLAUDE_DIR)
        parts = rel.split(os.sep)
        project = parts[0] if parts else "unknown"
        session_id = parts[1] if len(parts) > 1 else "unknown"
        is_subagent = "subagents" in rel

        try:
            with open(fpath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    msg = obj.get("message", {})
                    usage = msg.get("usage", {})
                    if not usage:
                        continue

                    input_tokens = usage.get("input_tokens", 0) or 0
                    cache_creation = usage.get("cache_creation_input_tokens", 0) or 0
                    cache_read = usage.get("cache_read_input_tokens", 0) or 0
                    output_tokens = usage.get("output_tokens", 0) or 0

                    total = input_tokens + cache_creation + cache_read + output_tokens
                    if total == 0:
                        continue

                    ts = obj.get("timestamp", "")
                    dt = parse_date(ts)

                    records.append({
                        "project": project,
                        "session_id": session_id,
                        "is_subagent": is_subagent,
                        "file": fpath,
                        "timestamp": ts,
                        "dt": dt,
                        "input_tokens": input_tokens,
                        "cache_creation": cache_creation,
                        "cache_read": cache_read,
                        "output_tokens": output_tokens,
                        "total": total,
                        "model": msg.get("model", "unknown"),
                    })
        except Exception as e:
            print(f"Error leyendo {fpath}: {e}", file=sys.stderr)

    return records

def fmt_num(n):
    return f"{n:>12,}"

def analyze(records):
    if not records:
        print("No se encontraron registros de uso de tokens.")
        return

    # --- Totales globales ---
    total_input = sum(r["input_tokens"] for r in records)
    total_cache_create = sum(r["cache_creation"] for r in records)
    total_cache_read = sum(r["cache_read"] for r in records)
    total_output = sum(r["output_tokens"] for r in records)
    grand_total = total_input + total_cache_create + total_cache_read + total_output

    print("=" * 70)
    print("ANÁLISIS DE CONSUMO DE TOKENS - CLAUDE CODE")
    print("=" * 70)
    print(f"\nTotal de registros analizados: {len(records):,}")
    print(f"\n{'TOTALES GLOBALES':}")
    print(f"  input_tokens:          {fmt_num(total_input)}")
    print(f"  cache_creation_tokens: {fmt_num(total_cache_create)}")
    print(f"  cache_read_tokens:     {fmt_num(total_cache_read)}")
    print(f"  output_tokens:         {fmt_num(total_output)}")
    print(f"  TOTAL:                 {fmt_num(grand_total)}")

    # --- Por proyecto ---
    by_project = defaultdict(lambda: defaultdict(int))
    for r in records:
        p = r["project"]
        by_project[p]["input"] += r["input_tokens"]
        by_project[p]["cache_create"] += r["cache_creation"]
        by_project[p]["cache_read"] += r["cache_read"]
        by_project[p]["output"] += r["output_tokens"]
        by_project[p]["total"] += r["total"]
        by_project[p]["calls"] += 1

    print(f"\n{'CONSUMO POR PROYECTO (ordenado por total desc)':}")
    print(f"{'Proyecto':<50} {'Llamadas':>8} {'Total tokens':>14}")
    print("-" * 75)
    for proj, d in sorted(by_project.items(), key=lambda x: -x[1]["total"]):
        name = proj[:50]
        print(f"{name:<50} {d['calls']:>8,} {d['total']:>14,}")

    # --- Por día ---
    by_day = defaultdict(lambda: defaultdict(int))
    for r in records:
        if r["dt"]:
            day = r["dt"].strftime("%Y-%m-%d")
        else:
            day = "unknown"
        by_day[day]["total"] += r["total"]
        by_day[day]["input"] += r["input_tokens"]
        by_day[day]["output"] += r["output_tokens"]
        by_day[day]["calls"] += 1

    sorted_days = sorted(by_day.items())
    if sorted_days:
        daily_totals = [d["total"] for _, d in sorted_days if _ != "unknown"]
        if daily_totals:
            avg_daily = sum(daily_totals) / len(daily_totals)
            max_daily = max(daily_totals)
            print(f"\n{'CONSUMO POR DÍA':}")
            print(f"  Promedio diario: {avg_daily:,.0f} tokens")
            print(f"  Máximo diario:   {max_daily:,.0f} tokens")
            print(f"\n{'Día':<12} {'Llamadas':>8} {'Total tokens':>14} {'Alerta':>8}")
            print("-" * 48)
            for day, d in sorted_days:
                alert = " *** ALTO ***" if d["total"] > avg_daily * 2 else ""
                print(f"{day:<12} {d['calls']:>8,} {d['total']:>14,}{alert}")

    # --- Sesiones más costosas ---
    by_session = defaultdict(lambda: defaultdict(int))
    for r in records:
        key = (r["project"][:40], r["session_id"][:8])
        by_session[key]["total"] += r["total"]
        by_session[key]["calls"] += 1
        by_session[key]["input"] += r["input_tokens"]
        by_session[key]["output"] += r["output_tokens"]

    top_sessions = sorted(by_session.items(), key=lambda x: -x[1]["total"])[:15]
    print(f"\n{'TOP 15 SESIONES MÁS COSTOSAS':}")
    print(f"{'Proyecto':<42} {'Sesión':>10} {'Llamadas':>8} {'Total tokens':>14}")
    print("-" * 78)
    for (proj, sess), d in top_sessions:
        print(f"{proj:<42} {sess:>10} {d['calls']:>8,} {d['total']:>14,}")

    # --- Llamadas individuales más grandes ---
    top_calls = sorted(records, key=lambda x: -x["total"])[:10]
    print(f"\n{'TOP 10 LLAMADAS INDIVIDUALES MÁS GRANDES':}")
    print(f"{'Timestamp':<26} {'Proyecto':<35} {'Total':>10} {'input':>8} {'output':>8}")
    print("-" * 95)
    for r in top_calls:
        proj = r["project"][:35]
        print(f"{r['timestamp'][:25]:<26} {proj:<35} {r['total']:>10,} {r['input_tokens']:>8,} {r['output_tokens']:>8,}")

    # --- Ratio cache vs input ---
    total_billable_input = total_input + total_cache_create
    if total_billable_input > 0:
        cache_hit_ratio = total_cache_read / (total_billable_input + total_cache_read) * 100
        print(f"\n{'EFICIENCIA DE CACHÉ':}")
        print(f"  Cache hit ratio: {cache_hit_ratio:.1f}%")
        print(f"  (mayor ratio = menos tokens facturados en input)")

    # --- Anomalías por llamada ---
    all_totals = [r["total"] for r in records]
    if len(all_totals) > 10:
        mean = sum(all_totals) / len(all_totals)
        variance = sum((x - mean) ** 2 for x in all_totals) / len(all_totals)
        std = variance ** 0.5
        threshold = mean + 3 * std
        anomalies = [r for r in records if r["total"] > threshold]
        print(f"\n{'ANOMALÍAS (> media + 3σ = {:.0f} tokens)'.format(threshold):}")
        if anomalies:
            for r in sorted(anomalies, key=lambda x: -x["total"])[:20]:
                proj = r["project"][:35]
                print(f"  {r['timestamp'][:25]} | {proj:<35} | {r['total']:>10,} tokens")
        else:
            print("  No se detectaron anomalías estadísticas.")

    print("\n" + "=" * 70)

def main():
    print("Cargando registros...", file=sys.stderr)
    records = load_all_jsonl()
    print(f"Registros encontrados: {len(records)}", file=sys.stderr)
    analyze(records)


if __name__ == "__main__":
    main()
