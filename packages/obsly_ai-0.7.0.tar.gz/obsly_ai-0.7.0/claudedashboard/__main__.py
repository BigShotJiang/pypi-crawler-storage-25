"""Allow running as `python -m claudedashboard`."""

from claudedashboard.cli import main

main()
