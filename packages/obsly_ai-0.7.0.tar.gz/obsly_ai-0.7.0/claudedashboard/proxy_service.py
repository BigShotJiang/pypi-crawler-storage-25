"""Orchestration layer for the LLM proxy launchd background agent."""

import os
import shutil
from pathlib import Path

from claudedashboard.gitai import launchd


_NAME = "proxy"
_PORT = "8080"
_OK_HTTPS_PROXIES = (
    "http://localhost:8080",
    "http://localhost:8080/",
    "http://127.0.0.1:8080",
    "http://127.0.0.1:8080/",
)


def _logs_dir():
    """Return Path to ~/.obsly-ai/logs/. Creates it if absent."""
    d = Path.home() / ".obsly-ai" / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _addon_path():
    """Return absolute path (as str) to claudedashboard/proxy/addon.py."""
    return str(Path(__file__).resolve().parent / "proxy" / "addon.py")


def _resolve_mitmdump():
    """Return absolute path to mitmdump on PATH, or None if not found."""
    return shutil.which("mitmdump")


def _events_path():
    """Return the configured events_path from proxy/commands._load_config().

    Falls back to ~/.claude/proxy_events.jsonl on any failure.
    """
    try:
        from claudedashboard.proxy import commands as pcmd
        cfg = pcmd._load_config()
        p = cfg.get("events_path")
        if p:
            return str(p)
    except Exception:
        pass
    return str(Path.home() / ".claude" / "proxy_events.jsonl")


def _detect_https_proxy_conflict():
    """Return None if no conflict, else a string describing the conflict.

    A conflict exists when HTTPS_PROXY is set to a value that is not
    localhost:8080 or 127.0.0.1:8080 (our proxy).
    """
    val = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    if not val:
        return None
    normalized = val.strip().rstrip("/")
    ok = tuple(v.rstrip("/") for v in _OK_HTTPS_PROXIES)
    if normalized in ok:
        return None
    return (
        f"HTTPS_PROXY is set to {val!r}; refusing to install over a "
        f"conflicting proxy. Unset HTTPS_PROXY and retry."
    )


def _program_args(mitmdump_path):
    return [mitmdump_path, "--listen-port", _PORT, "-s", _addon_path()]


def install(*, dry_run=False):
    """Install the LLM proxy as a launchd background agent. Never raises."""
    target = launchd.plist_path(_NAME)
    stderr_path = str(Path.home() / ".obsly-ai" / "logs" / "proxy.err")
    stdout_path = str(Path.home() / ".obsly-ai" / "logs" / "proxy.out")

    # Pre-flight: mitmdump must be available
    mitmdump = _resolve_mitmdump()
    if not mitmdump:
        return {
            "plist": str(target),
            "bootstrap_ok": False,
            "bootstrap_msg": "",
            "refused": True,
            "reason": (
                "mitmdump not found on PATH. Install it with "
                "`pipx install mitmproxy` or `pip install mitmproxy`."
            ),
        }

    # Pre-flight: no conflicting HTTPS_PROXY
    conflict = _detect_https_proxy_conflict()
    if conflict:
        return {
            "plist": str(target),
            "bootstrap_ok": False,
            "bootstrap_msg": "",
            "refused": True,
            "reason": conflict,
        }

    args = _program_args(mitmdump)
    env = {"LLM_PROXY_STORE_PATH": _events_path()}

    if dry_run:
        print(f"(dry-run) would write plist: {target}")
        print(f"(dry-run) program: {' '.join(args)}")
        print(f"(dry-run) stderr: {stderr_path}")
        print(f"(dry-run) stdout: {stdout_path}")
        return {
            "plist": str(target),
            "bootstrap_ok": False,
            "bootstrap_msg": "dry-run",
            "refused": False,
            "reason": None,
        }

    _logs_dir()

    written = launchd.write_plist(
        _NAME,
        args,
        keep_alive=True,
        run_at_load=True,
        stderr_path=stderr_path,
        stdout_path=stdout_path,
        env=env,
    )

    try:
        ok, msg = launchd.bootstrap(_NAME)
    except Exception as e:  # pragma: no cover - defensive
        ok, msg = False, str(e)

    return {
        "plist": str(written) if written else str(target),
        "bootstrap_ok": bool(ok),
        "bootstrap_msg": msg or "",
        "refused": False,
        "reason": None,
    }


def uninstall(*, dry_run=False):
    """Uninstall the proxy background agent. Never raises."""
    target = launchd.plist_path(_NAME)
    if dry_run:
        return {"removed": False, "plist": str(target)}
    try:
        removed = launchd.uninstall(_NAME)
    except Exception:
        removed = False
    return {"removed": bool(removed), "plist": str(target)}


def status():
    """Return 'running', 'stopped', or 'not_installed'."""
    return launchd.status(_NAME)
