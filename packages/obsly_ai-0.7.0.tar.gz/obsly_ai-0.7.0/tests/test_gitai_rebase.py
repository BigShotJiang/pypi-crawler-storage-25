"""TDD for rebase/amend note survival — red to green."""
import subprocess
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "foo.py").write_text("line1\nline2\nline3\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _add_note(repo, sha=None):
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add
    if sha is None:
        sha = _head(repo)
    log = AuthorshipLog(
        attestations=[FileAttestation("foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(2, 3)]),
        ])],
        base_commit_sha=sha,
        prompts={"aaa1234567890123": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "sonnet"), total_additions=2,
        )},
    )
    notes_add(str(repo), sha, serialize(log))
    return sha


class TestAmend:

    def test_amend_preserves_note(self, git_repo):
        from claudedashboard.gitai.rebase import handle_post_rewrite_amend
        from claudedashboard.gitai.git_notes import notes_read
        from claudedashboard.gitai.authorship_log import deserialize

        old_sha = _add_note(git_repo)
        subprocess.run(["git", "-C", str(git_repo), "commit", "--amend", "-m", "amended"],
                       check=True, capture_output=True)
        new_sha = _head(git_repo)
        assert new_sha != old_sha

        handle_post_rewrite_amend(str(git_repo), old_sha, new_sha)

        note = notes_read(str(git_repo), new_sha)
        assert note is not None
        log = deserialize(note)
        assert log.base_commit_sha == new_sha
        assert len(log.attestations) > 0


class TestRebase:

    def test_simple_rewrite(self, git_repo):
        from claudedashboard.gitai.rebase import handle_post_rewrite_rebase
        from claudedashboard.gitai.git_notes import notes_read

        old_sha = _add_note(git_repo)
        # Simulate rebase by amending (creates new SHA)
        subprocess.run(["git", "-C", str(git_repo), "commit", "--amend", "-m", "rebased"],
                       check=True, capture_output=True)
        new_sha = _head(git_repo)

        count = handle_post_rewrite_rebase(str(git_repo), [(old_sha, new_sha)])
        assert count == 1
        assert notes_read(str(git_repo), new_sha) is not None


class TestCherryPick:

    def test_copy_note(self, git_repo):
        from claudedashboard.gitai.rebase import handle_cherry_pick
        from claudedashboard.gitai.git_notes import notes_read

        # Commit 2 with note
        (git_repo / "foo.py").write_text("line1\nai_line2\nai_line3\n")
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI edit"],
                       check=True, capture_output=True)
        original = _head(git_repo)
        _add_note(git_repo, original)

        # Branch, cherry-pick
        subprocess.run(["git", "-C", str(git_repo), "checkout", "-b", "other", "HEAD~1"],
                       check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "cherry-pick", original],
                       check=True, capture_output=True)
        new_sha = _head(git_repo)

        handle_cherry_pick(str(git_repo), original, new_sha)
        note = notes_read(str(git_repo), new_sha)
        assert note is not None


class TestLineAdjust:

    def test_shift_down(self):
        from claudedashboard.gitai.rebase import adjust_line_ranges
        from claudedashboard.gitai.models import LineRange
        # Original lines 5-10, insertion at line 3 shifts them to 6-11
        ranges = [LineRange(5, 10)]
        old = "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\n"
        new = "a\nb\nINSERTED\nc\nd\ne\nf\ng\nh\ni\nj\n"
        adjusted = adjust_line_ranges(ranges, old, new)
        assert adjusted[0].start == 6
        assert adjusted[0].end == 11
