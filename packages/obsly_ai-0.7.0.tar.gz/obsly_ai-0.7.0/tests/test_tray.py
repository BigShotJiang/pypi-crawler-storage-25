"""Tests for claudedashboard.tray — cross-platform system tray dispatcher."""

import sys
import pytest

from claudedashboard import tray


# ── choose_backend ────────────────────────────────────────────────────────

def test_choose_backend_darwin_returns_rumps():
    assert tray.choose_backend("darwin") == "rumps"


def test_choose_backend_win32_returns_pystray():
    assert tray.choose_backend("win32") == "pystray"


def test_choose_backend_linux_returns_pystray():
    assert tray.choose_backend("linux") == "pystray"


def test_choose_backend_unknown_returns_pystray():
    # Default to pystray for anything unrecognised (freebsd, cygwin, ...)
    assert tray.choose_backend("freebsd8") == "pystray"


def test_choose_backend_default_uses_sys_platform(monkeypatch):
    monkeypatch.setattr(sys, "platform", "win32")
    assert tray.choose_backend() == "pystray"


# ── format_title ──────────────────────────────────────────────────────────

def test_format_title_with_both_claude_and_codex():
    snap = {
        "anthropic": {"seven_day_pct": 42.3},
        "codex_week": {"seven_day_pct": 15.1},
    }
    assert tray.format_title(snap) == "Claude: 42% | Codex: 15%"


def test_format_title_handles_missing_values():
    snap = {"anthropic": {}, "codex_week": {}}
    assert tray.format_title(snap) == "Claude: - | Codex: -"


def test_format_title_handles_empty_snapshot():
    assert tray.format_title({}) == "Claude: - | Codex: -"


def test_format_title_handles_none_values():
    snap = {"anthropic": {"seven_day_pct": None}, "codex_week": {"seven_day_pct": 90}}
    assert tray.format_title(snap) == "Claude: - | Codex: 90%"


# ── format_menu_items ─────────────────────────────────────────────────────

def test_format_menu_items_returns_list_of_strings():
    snap = {
        "anthropic": {
            "seven_day_pct": 42,
            "sonnet_pct": 30,
            "five_hour_pct": 60,
        },
        "codex_week": {"seven_day_pct": 20, "five_hour_pct": 10},
    }
    items = tray.format_menu_items(snap)
    assert isinstance(items, list)
    assert all(isinstance(x, str) for x in items)
    # Expect weekly/sonnet/5h lines
    joined = "\n".join(items)
    assert "Weekly" in joined
    assert "Sonnet" in joined
    assert "5h" in joined
    assert "Codex" in joined


def test_format_menu_items_handles_empty():
    items = tray.format_menu_items({})
    assert isinstance(items, list)
    assert len(items) > 0  # placeholder lines


# ── run_tray dispatcher ───────────────────────────────────────────────────

def test_run_tray_dispatches_to_rumps_on_darwin(monkeypatch):
    called = {}

    def fake_rumps():
        called["rumps"] = True

    def fake_pystray():
        called["pystray"] = True

    monkeypatch.setattr(tray, "_run_rumps_backend", fake_rumps)
    monkeypatch.setattr(tray, "_run_pystray_backend", fake_pystray)
    monkeypatch.setattr(sys, "platform", "darwin")

    tray.run_tray()
    assert called == {"rumps": True}


def test_run_tray_dispatches_to_pystray_on_win32(monkeypatch):
    called = {}
    monkeypatch.setattr(tray, "_run_rumps_backend", lambda: called.setdefault("rumps", True))
    monkeypatch.setattr(tray, "_run_pystray_backend", lambda: called.setdefault("pystray", True))
    monkeypatch.setattr(sys, "platform", "win32")

    tray.run_tray()
    assert called == {"pystray": True}


def test_run_tray_dispatches_to_pystray_on_linux(monkeypatch):
    called = {}
    monkeypatch.setattr(tray, "_run_rumps_backend", lambda: called.setdefault("rumps", True))
    monkeypatch.setattr(tray, "_run_pystray_backend", lambda: called.setdefault("pystray", True))
    monkeypatch.setattr(sys, "platform", "linux")

    tray.run_tray()
    assert called == {"pystray": True}


def test_run_tray_missing_dep_exits_nonzero(monkeypatch, capsys):
    def boom():
        raise ImportError("no module named pystray")

    monkeypatch.setattr(tray, "_run_rumps_backend", boom)
    monkeypatch.setattr(tray, "_run_pystray_backend", boom)

    with pytest.raises(SystemExit) as exc:
        tray.run_tray()
    assert exc.value.code != 0
    err = capsys.readouterr().err
    assert "tray" in err.lower() or "install" in err.lower()


# ── CLI smoke tests ───────────────────────────────────────────────────────

def test_cli_tray_help_does_not_crash(monkeypatch, capsys):
    from claudedashboard import cli
    monkeypatch.setattr(sys, "argv", ["obsly-ai", "tray", "--help"])
    with pytest.raises(SystemExit) as exc:
        cli.main()
    assert exc.value.code == 0
    out = capsys.readouterr().out
    assert "tray" in out.lower() or "usage" in out.lower()


def test_cli_menubar_alias_still_works(monkeypatch):
    """Legacy `obsly-ai menubar` should dispatch to the tray entrypoint."""
    from claudedashboard import cli

    called = {}

    def fake_run_tray():
        called["ran"] = True

    monkeypatch.setattr("claudedashboard.tray.run_tray", fake_run_tray)
    monkeypatch.setattr(sys, "argv", ["obsly-ai", "menubar"])
    # Suppress update check network I/O
    monkeypatch.setattr(cli, "_maybe_notify_update", lambda _c: None)
    cli.main()
    assert called.get("ran") is True


def test_cli_tray_dispatches_to_run_tray(monkeypatch):
    from claudedashboard import cli

    called = {}
    monkeypatch.setattr("claudedashboard.tray.run_tray", lambda: called.setdefault("ran", True))
    monkeypatch.setattr(sys, "argv", ["obsly-ai", "tray"])
    monkeypatch.setattr(cli, "_maybe_notify_update", lambda _c: None)
    cli.main()
    assert called.get("ran") is True
