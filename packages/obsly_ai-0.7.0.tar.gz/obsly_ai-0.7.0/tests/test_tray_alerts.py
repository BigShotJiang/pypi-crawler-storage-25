"""Tests for alert formatters and helpers in claudedashboard.tray."""

import json
import os
from pathlib import Path

import pytest

from claudedashboard import tray
from claudedashboard.tray import (
    count_unread_alerts,
    format_alert_items,
    format_title,
    format_title_with_alerts,
    load_recent_alerts,
)


class _Alert:
    def __init__(self, timestamp, cost_usd, threshold_usd, commit_sha, repo_path,
                 session_count, read=False):
        self.timestamp = timestamp
        self.cost_usd = cost_usd
        self.threshold_usd = threshold_usd
        self.commit_sha = commit_sha
        self.repo_path = repo_path
        self.session_count = session_count
        self.read = read


@pytest.fixture
def alerts_dir(tmp_path, monkeypatch):
    d = tmp_path / ".obsly-ai"
    d.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(d))
    return d


def _write_alert_line(alerts_dir, **kwargs):
    data = {
        "timestamp": kwargs.get("timestamp", 1700000000.0),
        "cost_usd": kwargs.get("cost_usd", 30.0),
        "threshold_usd": kwargs.get("threshold_usd", 25.0),
        "commit_sha": kwargs.get("commit_sha", "abc123"),
        "repo_path": kwargs.get("repo_path", "/tmp/repo"),
        "session_count": kwargs.get("session_count", 2),
        "read": kwargs.get("read", False),
    }
    path = alerts_dir / "alerts.jsonl"
    with open(path, "a") as f:
        f.write(json.dumps(data) + "\n")


# ── format_alert_items ───────────────────────────────────────────────

def test_format_alert_items_empty_returns_empty_list():
    assert format_alert_items([]) == []


def test_format_alert_items_single_alert():
    a = _Alert(
        timestamp=1700000000,
        cost_usd=42.50,
        threshold_usd=25.0,
        commit_sha="deadbeef",
        repo_path="/Users/foo/myrepo",
        session_count=3,
    )
    out = format_alert_items([a])
    assert len(out) == 1
    line = out[0]
    assert "$42.50" in line
    assert "myrepo" in line


def test_format_alert_items_preserves_order():
    alerts = [
        _Alert(1700000300, 99.00, 25.0, "c", "/r/a", 1),
        _Alert(1700000200, 50.00, 25.0, "b", "/r/b", 1),
        _Alert(1700000100, 30.00, 25.0, "a", "/r/c", 1),
    ]
    out = format_alert_items(alerts)
    assert len(out) == 3
    assert "$99.00" in out[0]
    assert "$50.00" in out[1]
    assert "$30.00" in out[2]


def test_format_alert_items_handles_repo_path_with_trailing_slash():
    a = _Alert(1700000000, 30.0, 25.0, "sha", "/Users/foo/myrepo/", 1)
    out = format_alert_items([a])
    assert "myrepo" in out[0]
    # not an empty basename rendered
    assert "  " in out[0]


# ── format_title_with_alerts ─────────────────────────────────────────

def test_format_title_with_alerts_no_unread_returns_format_title():
    snap = {"anthropic": {"seven_day_pct": 50}, "codex_week": {}}
    assert format_title_with_alerts(snap, 0) == format_title(snap)


def test_format_title_with_alerts_one_unread_prepends_indicator():
    snap = {"anthropic": {"seven_day_pct": 50}, "codex_week": {}}
    out = format_title_with_alerts(snap, 1)
    assert out.startswith("(!1) ")
    assert format_title(snap) in out


def test_format_title_with_alerts_many_unread():
    snap = {"anthropic": {"seven_day_pct": 50}, "codex_week": {}}
    out = format_title_with_alerts(snap, 7)
    assert out.startswith("(!7) ")


# ── load_recent_alerts ───────────────────────────────────────────────

def test_load_recent_alerts_returns_empty_when_no_file(alerts_dir):
    assert load_recent_alerts() == []


def test_load_recent_alerts_returns_alerts_via_cost_alerts(alerts_dir):
    _write_alert_line(alerts_dir, timestamp=1700000100.0, cost_usd=30.0)
    _write_alert_line(alerts_dir, timestamp=1700000200.0, cost_usd=40.0)
    out = load_recent_alerts(limit=10)
    assert len(out) == 2


def test_load_recent_alerts_swallows_exceptions(alerts_dir, monkeypatch):
    from claudedashboard.gitai import cost_alerts

    def _boom(*args, **kwargs):
        raise RuntimeError("kaboom")

    monkeypatch.setattr(cost_alerts, "load_alerts", _boom)
    assert load_recent_alerts() == []


# ── count_unread_alerts ──────────────────────────────────────────────

def test_count_unread_alerts_returns_zero_when_none(alerts_dir):
    assert count_unread_alerts() == 0


def test_count_unread_alerts_counts_only_unread(alerts_dir):
    _write_alert_line(alerts_dir, timestamp=1700000100.0, read=False)
    _write_alert_line(alerts_dir, timestamp=1700000200.0, read=False)
    _write_alert_line(alerts_dir, timestamp=1700000300.0, read=True)
    assert count_unread_alerts() == 2


def test_count_unread_alerts_swallows_exceptions(alerts_dir, monkeypatch):
    from claudedashboard.gitai import cost_alerts

    def _boom(*args, **kwargs):
        raise RuntimeError("kaboom")

    monkeypatch.setattr(cost_alerts, "load_alerts", _boom)
    assert count_unread_alerts() == 0
