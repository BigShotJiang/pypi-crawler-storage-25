"""TDD for gitai data models — red to green."""
import hashlib
import pytest


# ── AgentId ──────────────────────────────────────────────────────────

class TestAgentId:

    def test_roundtrip(self):
        from claudedashboard.gitai.models import AgentId
        a = AgentId(tool="claude-code", id="sess-123", model="claude-sonnet-4-6")
        assert AgentId.from_dict(a.to_dict()) == a

    def test_fields(self):
        from claudedashboard.gitai.models import AgentId
        a = AgentId(tool="cursor", id="conv-1", model="gpt-4o")
        d = a.to_dict()
        assert d["tool"] == "cursor"
        assert d["id"] == "conv-1"
        assert d["model"] == "gpt-4o"


# ── LineAttribution ──────────────────────────────────────────────────

class TestLineAttribution:

    def test_line_count(self):
        from claudedashboard.gitai.models import LineAttribution
        la = LineAttribution(start_line=5, end_line=10, author_id="abc123", overrode=None)
        assert la.line_count() == 6

    def test_single_line(self):
        from claudedashboard.gitai.models import LineAttribution
        la = LineAttribution(start_line=1, end_line=1, author_id="x", overrode=None)
        assert la.line_count() == 1

    def test_with_overrode_roundtrip(self):
        from claudedashboard.gitai.models import LineAttribution
        la = LineAttribution(start_line=1, end_line=5, author_id="new", overrode="old")
        d = la.to_dict()
        assert d["overrode"] == "old"
        assert LineAttribution.from_dict(d) == la

    def test_without_overrode_roundtrip(self):
        from claudedashboard.gitai.models import LineAttribution
        la = LineAttribution(start_line=1, end_line=3, author_id="a", overrode=None)
        restored = LineAttribution.from_dict(la.to_dict())
        assert restored.overrode is None


# ── LineRange ────────────────────────────────────────────────────────

class TestLineRange:

    def test_compress_consecutive(self):
        from claudedashboard.gitai.models import LineRange
        assert LineRange.compress([1, 2, 3, 5, 6, 10]) == [
            LineRange(1, 3), LineRange(5, 6), LineRange(10, 10)
        ]

    def test_compress_single(self):
        from claudedashboard.gitai.models import LineRange
        assert LineRange.compress([42]) == [LineRange(42, 42)]

    def test_compress_empty(self):
        from claudedashboard.gitai.models import LineRange
        assert LineRange.compress([]) == []

    def test_compress_non_consecutive(self):
        from claudedashboard.gitai.models import LineRange
        assert LineRange.compress([1, 3, 5]) == [
            LineRange(1, 1), LineRange(3, 3), LineRange(5, 5)
        ]

    def test_format_ranges(self):
        from claudedashboard.gitai.models import LineRange
        ranges = [LineRange(1, 3), LineRange(5, 6), LineRange(10, 10)]
        assert LineRange.format(ranges) == "1-3,5-6,10"

    def test_format_single(self):
        from claudedashboard.gitai.models import LineRange
        assert LineRange.format([LineRange(42, 42)]) == "42"

    def test_parse_ranges(self):
        from claudedashboard.gitai.models import LineRange
        parsed = LineRange.parse("1-3,5-6,10")
        assert parsed == [LineRange(1, 3), LineRange(5, 6), LineRange(10, 10)]

    def test_parse_format_roundtrip(self):
        from claudedashboard.gitai.models import LineRange
        original = "1-3,5-6,10,20-25"
        assert LineRange.format(LineRange.parse(original)) == original

    def test_str_single(self):
        from claudedashboard.gitai.models import LineRange
        assert str(LineRange(42, 42)) == "42"

    def test_str_range(self):
        from claudedashboard.gitai.models import LineRange
        assert str(LineRange(1, 10)) == "1-10"


# ── WorkingLogEntry ──────────────────────────────────────────────────

class TestWorkingLogEntry:

    def test_roundtrip(self):
        from claudedashboard.gitai.models import WorkingLogEntry, LineAttribution
        entry = WorkingLogEntry(
            file="src/foo.py", blob_sha="abc123",
            line_attributions=[LineAttribution(1, 10, "hash1234567890ab", None)]
        )
        restored = WorkingLogEntry.from_dict(entry.to_dict())
        assert restored.file == "src/foo.py"
        assert restored.blob_sha == "abc123"
        assert len(restored.line_attributions) == 1
        assert restored.line_attributions[0].author_id == "hash1234567890ab"


# ── Checkpoint ───────────────────────────────────────────────────────

class TestCheckpoint:

    def test_roundtrip(self):
        from claudedashboard.gitai.models import (
            Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, LineAttribution,
        )
        cp = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author="dev@example.com",
            entries=[WorkingLogEntry(
                file="src/foo.py", blob_sha="abc",
                line_attributions=[LineAttribution(1, 10, "hash1234567890ab", None)]
            )],
            agent_id=AgentId("claude-code", "sess-1", "claude-sonnet-4-6"),
            tool_use_id="toolu_01",
        )
        restored = Checkpoint.from_dict(cp.to_dict())
        assert restored.kind == CheckpointKind.AI_AGENT
        assert restored.author == "dev@example.com"
        assert restored.entries[0].file == "src/foo.py"
        assert restored.entries[0].line_attributions[0].author_id == "hash1234567890ab"
        assert restored.agent_id.tool == "claude-code"
        assert restored.tool_use_id == "toolu_01"

    def test_human_checkpoint(self):
        from claudedashboard.gitai.models import Checkpoint, CheckpointKind
        cp = Checkpoint(kind=CheckpointKind.HUMAN, author="dev@test.com", entries=[])
        d = cp.to_dict()
        assert d["kind"] == "human"
        assert Checkpoint.from_dict(d).kind == CheckpointKind.HUMAN

    def test_timestamp_auto(self):
        from claudedashboard.gitai.models import Checkpoint, CheckpointKind
        cp = Checkpoint(kind=CheckpointKind.HUMAN, author="x", entries=[])
        assert cp.timestamp_ms > 0


# ── PromptRecord ─────────────────────────────────────────────────────

class TestPromptRecord:

    def test_with_custom_attributes(self):
        from claudedashboard.gitai.models import PromptRecord, AgentId
        pr = PromptRecord(
            agent_id=AgentId("claude-code", "s1", "opus"),
            total_additions=50,
            custom_attributes={"cost_usd": "1.23", "tokens_in": "5000", "tokens_out": "2000"}
        )
        d = pr.to_dict()
        assert d["custom_attributes"]["cost_usd"] == "1.23"
        restored = PromptRecord.from_dict(d)
        assert restored.custom_attributes["tokens_in"] == "5000"

    def test_without_custom_attributes(self):
        from claudedashboard.gitai.models import PromptRecord, AgentId
        pr = PromptRecord(agent_id=AgentId("cursor", "c1", "gpt-4o"), total_additions=10)
        d = pr.to_dict()
        assert d["custom_attributes"] is None
        restored = PromptRecord.from_dict(d)
        assert restored.custom_attributes is None


# ── Session Hash ─────────────────────────────────────────────────────

class TestSessionHash:

    def test_deterministic(self):
        from claudedashboard.gitai.session import generate_session_hash
        h1 = generate_session_hash("claude-code", "abc123")
        h2 = generate_session_hash("claude-code", "abc123")
        assert h1 == h2
        assert len(h1) == 16
        assert all(c in "0123456789abcdef" for c in h1)

    def test_different_inputs(self):
        from claudedashboard.gitai.session import generate_session_hash
        h1 = generate_session_hash("claude-code", "abc")
        h2 = generate_session_hash("cursor", "abc")
        assert h1 != h2

    def test_known_value(self):
        from claudedashboard.gitai.session import generate_session_hash
        expected = hashlib.sha256(b"claude-code:test-session").hexdigest()[:16]
        assert generate_session_hash("claude-code", "test-session") == expected

    def test_compute_file_hash(self):
        from claudedashboard.gitai.session import compute_file_hash
        h = compute_file_hash(b"hello world")
        assert h == hashlib.sha256(b"hello world").hexdigest()


# ── Ignore ───────────────────────────────────────────────────────────

class TestIgnore:

    def test_ignore_lockfile(self):
        from claudedashboard.gitai.ignore import should_ignore
        assert should_ignore("package-lock.json") is True

    def test_ignore_node_modules(self):
        from claudedashboard.gitai.ignore import should_ignore
        assert should_ignore("node_modules/foo/bar.js") is True

    def test_no_ignore_python(self):
        from claudedashboard.gitai.ignore import should_ignore
        assert should_ignore("src/main.py") is False

    def test_no_ignore_typescript(self):
        from claudedashboard.gitai.ignore import should_ignore
        assert should_ignore("src/app.ts") is False

    def test_ignore_min_js(self):
        from claudedashboard.gitai.ignore import should_ignore
        assert should_ignore("dist/bundle.min.js") is True

    def test_binary_detection_text(self):
        from claudedashboard.gitai.ignore import is_binary_file
        assert is_binary_file(b"normal text content\nwith newlines\n") is False

    def test_binary_detection_binary(self):
        from claudedashboard.gitai.ignore import is_binary_file
        assert is_binary_file(b"binary\x00content\x00here") is True

    def test_binary_detection_empty(self):
        from claudedashboard.gitai.ignore import is_binary_file
        assert is_binary_file(b"") is False
