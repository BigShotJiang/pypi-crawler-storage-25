import json
import pytest
from claudedashboard.gitai.usage_adapters.continue_dev import ContinueAdapter


@pytest.fixture
def sessions_root(tmp_path):
    d = tmp_path / "sessions"
    d.mkdir()
    return d


def _write_session(root, session_id, data):
    (root / f"{session_id}.json").write_text(json.dumps(data))


def test_records_empty_when_root_missing(tmp_path):
    a = ContinueAdapter(sessions_root=tmp_path / "missing")
    assert a.records_for_session("any") == []


def test_records_empty_when_session_id_empty(sessions_root):
    _write_session(sessions_root, "s1", {"sessionId": "s1", "history": []})
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("") == []


def test_records_single_prompt_log(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [
            {
                "promptLogs": [
                    {
                        "modelTitle": "claude-sonnet",
                        "completionOptions": {"model": "claude-sonnet-4-5"},
                        "stats": {
                            "promptTokens": 1234,
                            "completionTokens": 567,
                            "cacheReadTokens": 12000,
                            "cacheWriteTokens": 0,
                            "cost": 0.045,
                        },
                        "timestamp": "2026-04-11T10:00:00Z",
                    }
                ]
            }
        ],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    records = a.records_for_session("s1")
    assert len(records) == 1
    r = records[0]
    assert r.agent == "continue"
    assert r.session_id == "s1"
    assert r.model == "claude-sonnet-4-5"
    assert r.tokens_in == 1234
    assert r.tokens_out == 567
    assert r.cache_read == 12000
    assert r.equivalent_api_cost_usd == 0.045
    assert r.timestamp == "2026-04-11T10:00:00Z"


def test_records_multiple_turns_multiple_logs(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [
            {"promptLogs": [
                {"stats": {"promptTokens": 100, "completionTokens": 50, "cost": 0.01}},
                {"stats": {"promptTokens": 200, "completionTokens": 100, "cost": 0.02}},
            ]},
            {"promptLogs": [
                {"stats": {"promptTokens": 300, "completionTokens": 150, "cost": 0.03}},
            ]},
        ],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    records = a.records_for_session("s1")
    assert len(records) == 3
    costs = sorted(r.equivalent_api_cost_usd for r in records)
    assert costs == [0.01, 0.02, 0.03]


def test_records_filters_by_session_id(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [{"promptLogs": [{"stats": {"cost": 0.01}}]}],
    })
    _write_session(sessions_root, "s2", {
        "sessionId": "s2",
        "history": [{"promptLogs": [{"stats": {"cost": 0.02}}]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    s1 = a.records_for_session("s1")
    s2 = a.records_for_session("s2")
    assert len(s1) == 1
    assert len(s2) == 1
    assert s1[0].equivalent_api_cost_usd == 0.01
    assert s2[0].equivalent_api_cost_usd == 0.02


def test_records_falls_back_to_filename_when_no_sessionId(sessions_root):
    _write_session(sessions_root, "filename-id", {
        "history": [{"promptLogs": [{"stats": {"cost": 0.05}}]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    records = a.records_for_session("filename-id")
    assert len(records) == 1


def test_records_handles_corrupted_json(sessions_root):
    (sessions_root / "broken.json").write_text("not valid json")
    _write_session(sessions_root, "good", {
        "sessionId": "good",
        "history": [{"promptLogs": [{"stats": {"cost": 0.05}}]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("good")[0].equivalent_api_cost_usd == 0.05


def test_records_handles_missing_history_key(sessions_root):
    _write_session(sessions_root, "s1", {"sessionId": "s1"})
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("s1") == []


def test_records_handles_history_not_a_list(sessions_root):
    _write_session(sessions_root, "s1", {"sessionId": "s1", "history": "garbage"})
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("s1") == []


def test_records_handles_promptLogs_missing_or_garbage(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [
            {"message": {"role": "user"}},
            {"promptLogs": "not a list"},
            {"promptLogs": []},
            {"promptLogs": [None, "not a dict"]},
        ],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("s1") == []


def test_records_handles_missing_stats(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [{"promptLogs": [{"modelTitle": "claude"}]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    records = a.records_for_session("s1")
    assert len(records) == 1
    assert records[0].tokens_in == 0
    assert records[0].equivalent_api_cost_usd == 0.0
    assert records[0].model == "claude"


def test_records_uses_modelTitle_when_no_completionOptions(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [{"promptLogs": [
            {"modelTitle": "GPT-4", "stats": {"promptTokens": 50, "completionTokens": 25}}
        ]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    records = a.records_for_session("s1")
    assert records[0].model == "GPT-4"


def test_records_for_unknown_session_returns_empty(sessions_root):
    _write_session(sessions_root, "known", {
        "sessionId": "known",
        "history": [{"promptLogs": [{"stats": {"cost": 0.05}}]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.records_for_session("unknown") == []


def test_default_sessions_root_under_dot_continue(monkeypatch, tmp_path):
    monkeypatch.setattr("os.path.expanduser", lambda p: str(tmp_path) if p == "~" else p)
    a = ContinueAdapter()
    assert ".continue" in str(a.sessions_root)
    assert "sessions" in str(a.sessions_root)


def test_cost_for_session_sums_records(sessions_root):
    _write_session(sessions_root, "s1", {
        "sessionId": "s1",
        "history": [{"promptLogs": [
            {"stats": {"cost": 0.10}},
            {"stats": {"cost": 0.20}},
        ]}],
    })
    a = ContinueAdapter(sessions_root=sessions_root)
    assert a.cost_for_session("s1") == 0.3


def test_adapter_is_registered_in_all_adapters():
    from claudedashboard.gitai.usage_adapters import all_adapters
    adapters = all_adapters()
    assert any(a.agent == "continue" for a in adapters)
