"""TDD for session tracking and transcript extraction."""
import json
import pytest
from unittest.mock import MagicMock, patch


class TestTranscript:
    """Extract a short transcript from the request body."""

    def test_extract_anthropic_user_message(self):
        from claudedashboard.proxy.session import extract_transcript

        body = {
            "messages": [
                {"role": "user", "content": "Fix the login bug in auth.py"}
            ]
        }
        assert extract_transcript(body) == "Fix the login bug in auth.py"

    def test_extract_last_user_messages(self):
        from claudedashboard.proxy.session import extract_transcript

        body = {
            "messages": [
                {"role": "user", "content": "Help me with auth"},
                {"role": "assistant", "content": "Sure, what do you need?"},
                {"role": "user", "content": "Fix the login bug"},
            ]
        }
        result = extract_transcript(body)
        assert "Help me with auth" in result
        assert "Fix the login bug" in result

    def test_truncate_long_message(self):
        from claudedashboard.proxy.session import extract_transcript

        body = {
            "messages": [{"role": "user", "content": "x" * 500}]
        }
        result = extract_transcript(body, max_len=100)
        assert len(result) <= 103  # 100 + "..."
        assert result.endswith("...")

    def test_empty_messages(self):
        from claudedashboard.proxy.session import extract_transcript

        assert extract_transcript({}) is None
        assert extract_transcript({"messages": []}) is None

    def test_content_is_list(self):
        """Anthropic allows content as list of blocks."""
        from claudedashboard.proxy.session import extract_transcript

        body = {
            "messages": [
                {"role": "user", "content": [
                    {"type": "text", "text": "Refactor the database layer"}
                ]}
            ]
        }
        assert extract_transcript(body) == "Refactor the database layer"


class TestSessionId:
    """Group requests by session (same parent process = same window)."""

    def test_session_from_pid(self):
        from claudedashboard.proxy.session import get_session_id

        # Same PID should give same session
        s1 = get_session_id(pid=1234)
        s2 = get_session_id(pid=1234)
        assert s1 == s2

    def test_different_pid_different_session(self):
        from claudedashboard.proxy.session import get_session_id

        s1 = get_session_id(pid=1234)
        s2 = get_session_id(pid=5678)
        assert s1 != s2

    def test_session_includes_parent_pid(self):
        """If we can get ppid, use it to group child processes."""
        from claudedashboard.proxy.session import get_session_id

        # Two children of the same parent = same session
        s1 = get_session_id(pid=100, ppid=50)
        s2 = get_session_id(pid=101, ppid=50)
        assert s1 == s2

    def test_none_pid(self):
        from claudedashboard.proxy.session import get_session_id

        s = get_session_id(pid=None)
        assert s == "unknown"


class TestAddonWithSession:
    """The addon should include session_id and transcript in events."""

    def test_event_has_session_and_transcript(self, tmp_path):
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        flow = MagicMock(spec=["request", "response", "client_conn", "timestamp_created"])
        flow.request = MagicMock()
        flow.response = MagicMock()
        flow.client_conn = MagicMock()
        flow.request.host = "api.anthropic.com"
        flow.request.content = json.dumps({
            "messages": [{"role": "user", "content": "Fix the bug"}]
        }).encode()
        flow.response.content = json.dumps({
            "model": "claude-sonnet-4-6",
            "usage": {"input_tokens": 100, "output_tokens": 50},
        }).encode()
        headers_mock = MagicMock()
        headers_mock.get = lambda key, default="": "application/json" if key == "content-type" else default
        flow.response.headers = headers_mock
        flow.timestamp_created = 1712345678.0
        flow.client_conn.peername = ("127.0.0.1", 54321)

        mock_pinfo = {"pid": 1234, "ppid": 500, "pname": "cursor", "cwd": "/tmp"}
        with patch("claudedashboard.proxy.addon._resolve_process_info", return_value=mock_pinfo):
            addon.request(flow)
            addon.response(flow)

        events = []
        with open(store_path) as f:
            for line in f:
                events.append(json.loads(line))

        assert len(events) == 1
        assert events[0]["transcript"] == "Fix the bug"
        assert events[0]["session_id"] is not None
        assert events[0]["session_id"] != "unknown"
