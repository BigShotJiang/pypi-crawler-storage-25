"""TDD for working log storage — red to green."""
import json, os, time, threading, subprocess
import pytest
from claudedashboard.gitai.models import (
    Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, LineAttribution,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "README.md").write_text("# Test\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _make_cp(kind=CheckpointKind.AI_AGENT, tool_use_id=None):
    return Checkpoint(
        kind=kind, author="test@test.com", entries=[],
        agent_id=AgentId("claude-code", "s1", "sonnet") if kind == CheckpointKind.AI_AGENT else None,
        tool_use_id=tool_use_id,
    )


# ── Directory setup ──────────────────────────────────────────────────

class TestSetup:

    def test_ensure_dirs(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        wl.ensure_dirs()
        assert (git_repo / ".git" / "ai" / "working_logs").is_dir()
        assert (git_repo / ".git" / "ai" / "snapshots").is_dir()


# ── Checkpoint CRUD ──────────────────────────────────────────────────

class TestCheckpointCrud:

    def test_append_and_read(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        cp = _make_cp()
        wl.append_checkpoint("abc123", cp)
        result = wl.read_checkpoints("abc123")
        assert len(result) == 1
        assert result[0].kind == CheckpointKind.AI_AGENT
        assert result[0].agent_id.tool == "claude-code"

    def test_append_multiple(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        for i in range(5):
            wl.append_checkpoint("abc123", _make_cp(tool_use_id=f"t{i}"))
        assert len(wl.read_checkpoints("abc123")) == 5

    def test_read_nonexistent(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        assert wl.read_checkpoints("nonexistent") == []

    def test_delete_log(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        wl.append_checkpoint("abc123", _make_cp())
        wl.delete_log("abc123")
        assert wl.read_checkpoints("abc123") == []

    def test_list_base_commits(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        wl.append_checkpoint("aaa", _make_cp())
        wl.append_checkpoint("bbb", _make_cp())
        assert set(wl.list_base_commits()) == {"aaa", "bbb"}


# ── Snapshot CRUD ────────────────────────────────────────────────────

class TestSnapshotCrud:

    def test_save_and_load(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        files = {"src/foo.py": "content here", "src/bar.py": "other"}
        wl.save_snapshot("toolu_01", files)
        assert wl.load_snapshot("toolu_01") == files

    def test_load_missing(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        assert wl.load_snapshot("nonexistent") is None

    def test_delete_snapshot(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        wl.save_snapshot("toolu_01", {"f": "c"})
        wl.delete_snapshot("toolu_01")
        assert wl.load_snapshot("toolu_01") is None


# ── Cleanup ──────────────────────────────────────────────────────────

class TestCleanup:

    def test_cleanup_stale_snapshots(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        wl.save_snapshot("old_one", {"f": "c"})
        snap_path = wl.snapshots_dir / "old_one.json"
        old_time = time.time() - 7200
        os.utime(snap_path, (old_time, old_time))
        removed = wl.cleanup_stale_snapshots(max_age_seconds=3600)
        assert removed == 1
        assert wl.load_snapshot("old_one") is None


# ── Stats ────────────────────────────────────────────────────────────

class TestStats:

    def test_uncommitted_stats(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        cp = Checkpoint(
            kind=CheckpointKind.AI_AGENT, author="test@test.com",
            entries=[WorkingLogEntry(
                file="src/foo.py", blob_sha="x",
                line_attributions=[LineAttribution(1, 10, "hash", None)]
            )],
        )
        wl.append_checkpoint("abc123", cp)
        stats = wl.uncommitted_stats("abc123")
        assert stats["checkpoint_count"] == 1
        assert stats["ai_checkpoints"] == 1
        assert "src/foo.py" in stats["files_touched"]
        assert stats["total_ai_lines"] == 10


# ── Concurrent access ───────────────────────────────────────────────

class TestConcurrency:

    def test_concurrent_appends(self, git_repo):
        from claudedashboard.gitai.working_log import WorkingLog
        wl = WorkingLog(str(git_repo))
        errors = []

        def append_n(n, name):
            try:
                for i in range(20):
                    wl.append_checkpoint("concurrent",
                        _make_cp(tool_use_id=f"{name}_{i}"))
            except Exception as e:
                errors.append(e)

        t1 = threading.Thread(target=append_n, args=(20, "t1"))
        t2 = threading.Thread(target=append_n, args=(20, "t2"))
        t1.start(); t2.start()
        t1.join(); t2.join()
        assert errors == []
        result = wl.read_checkpoints("concurrent")
        assert len(result) == 40
