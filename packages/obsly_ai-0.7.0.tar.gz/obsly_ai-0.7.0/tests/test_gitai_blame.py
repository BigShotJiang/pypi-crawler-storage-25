"""TDD for ai-blame command — red to green."""
import json, subprocess
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\nline4\nline5\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _add_note(repo, log):
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add
    sha = _get_head(repo)
    notes_add(str(repo), sha, serialize(log))


@pytest.fixture
def repo_with_note(git_repo):
    """Repo with a git note: lines 3-4 are claude-code, rest is human."""
    log = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("c9883b05a2487d6d", [LineRange(3, 4)]),
        ])],
        base_commit_sha=_get_head(git_repo),
        prompts={"c9883b05a2487d6d": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "claude-sonnet-4-6"),
            human_author="test@test.com", total_additions=2,
        )},
    )
    _add_note(git_repo, log)
    return git_repo


@pytest.fixture
def repo_with_cost_note(git_repo):
    """Repo with a git note that includes cost data."""
    log = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("c9883b05a2487d6d", [LineRange(3, 4)]),
        ])],
        base_commit_sha=_get_head(git_repo),
        prompts={"c9883b05a2487d6d": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "claude-sonnet-4-6"),
            total_additions=2,
            custom_attributes={"cost_usd": "0.50"},
        )},
    )
    _add_note(git_repo, log)
    return git_repo


# ── Core blame ───────────────────────────────────────────────────────

class TestBlame:

    def test_mixed_attribution(self, repo_with_note):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(repo_with_note), "src/foo.py")
        assert len(lines) == 5
        assert lines[0].agent == "human"  # line 1
        assert lines[1].agent == "human"  # line 2
        assert lines[2].agent == "claude-code"  # line 3
        assert lines[3].agent == "claude-code"  # line 4
        assert lines[4].agent == "human"  # line 5

    def test_all_human_no_note(self, git_repo):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(git_repo), "src/foo.py")
        assert all(l.agent == "human" for l in lines)
        assert len(lines) == 5

    def test_nonexistent_file(self, git_repo):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(git_repo), "nonexistent.py")
        assert lines == []

    def test_line_range_filter(self, repo_with_note):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(repo_with_note), "src/foo.py", start_line=2, end_line=4)
        assert len(lines) == 3
        assert lines[0].line_number == 2
        assert lines[2].line_number == 4

    def test_with_cost(self, repo_with_cost_note):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(repo_with_cost_note), "src/foo.py")
        ai_lines = [l for l in lines if l.cost_usd is not None]
        assert len(ai_lines) == 2
        assert ai_lines[0].cost_usd > 0

    def test_model_in_output(self, repo_with_note):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(repo_with_note), "src/foo.py")
        ai_lines = [l for l in lines if l.agent != "human"]
        assert ai_lines[0].model == "claude-sonnet-4-6"

    def test_session_hash_in_output(self, repo_with_note):
        from claudedashboard.gitai.blame import blame
        lines = blame(str(repo_with_note), "src/foo.py")
        ai_lines = [l for l in lines if l.agent != "human"]
        assert ai_lines[0].session_hash == "c9883b05a2487d6d"

    def test_ai_attribution_survives_later_human_commit(self, repo_with_note):
        """AI lines from a past commit must remain attributed even after a
        later human commit (only changing other lines) becomes HEAD."""
        from claudedashboard.gitai.blame import blame
        repo = str(repo_with_note)
        # Append a human-only line in a new commit. Lines 3-4 (AI) are unchanged.
        (repo_with_note / "src" / "foo.py").write_text(
            "line1\nline2\nline3\nline4\nline5\nline6_human\n"
        )
        subprocess.run(["git", "-C", repo, "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", repo, "commit", "-m", "human change"],
                       check=True, capture_output=True)

        lines = blame(repo, "src/foo.py")
        assert len(lines) == 6
        assert lines[2].agent == "claude-code"  # line 3 still AI
        assert lines[3].agent == "claude-code"  # line 4 still AI
        assert lines[5].agent == "human"        # new line 6


# ── Output formatters ───────────────────────────────────────────────

class TestFormatters:

    def test_terminal_output(self, repo_with_note):
        from claudedashboard.gitai.blame import blame, format_terminal
        lines = blame(str(repo_with_note), "src/foo.py")
        output = format_terminal(lines, "src/foo.py", "abc1234")
        assert "src/foo.py" in output
        assert "human" in output
        assert "claude-code" in output

    def test_json_output(self, repo_with_note):
        from claudedashboard.gitai.blame import blame, format_json
        lines = blame(str(repo_with_note), "src/foo.py")
        output = format_json(lines, "src/foo.py", "abc1234")
        data = json.loads(output)
        assert "lines" in data
        assert "summary" in data
        assert data["summary"]["total_lines"] == 5
        assert data["summary"]["ai_lines"] == 2
        assert data["summary"]["ai_percentage"] == pytest.approx(40.0)

    def test_compact_output(self, repo_with_note):
        from claudedashboard.gitai.blame import blame, format_compact
        lines = blame(str(repo_with_note), "src/foo.py")
        output = format_compact(lines)
        assert "40" in output  # 40%
