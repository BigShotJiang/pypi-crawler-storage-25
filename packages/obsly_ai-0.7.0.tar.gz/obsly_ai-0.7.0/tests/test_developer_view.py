"""TDD for developer view — what the menubar shows when proxy is active."""
import json
import pytest


@pytest.fixture
def events_path(tmp_path):
    events = [
        {"provider": "anthropic", "model": "claude-sonnet-4-6", "tokens_in": 1500, "tokens_out": 800,
         "cache_read": 200, "cache_create": 0, "cost": 0.057,
         "tool": "cursor", "repo": "github.com/co/app", "branch": "feature/JIRA-1",
         "git_user": "xavi@co.com", "session_id": "session-100", "transcript": "Fix the login bug",
         "timestamp": 1712345600.0},
        {"provider": "anthropic", "model": "claude-opus-4-6", "tokens_in": 500, "tokens_out": 200,
         "cache_read": 0, "cache_create": 100, "cost": 0.222,
         "tool": "claude", "repo": "github.com/co/app", "branch": "feature/JIRA-1",
         "git_user": "xavi@co.com", "session_id": "session-100", "transcript": "Refactor auth module",
         "timestamp": 1712345700.0},
        {"provider": "openai", "model": "gpt-4o", "tokens_in": 2000, "tokens_out": 1000,
         "cache_read": 0, "cache_create": 0, "cost": 0.015,
         "tool": "aider", "repo": "github.com/co/backend", "branch": "fix/BUG-99",
         "git_user": "xavi@co.com", "session_id": "session-200", "transcript": "Add error handling",
         "timestamp": 1712345800.0},
        {"provider": "anthropic", "model": "claude-sonnet-4-6", "tokens_in": 3000, "tokens_out": 1500,
         "cache_read": 500, "cache_create": 0, "cost": 0.031,
         "tool": "cursor", "repo": "github.com/co/app", "branch": "feature/JIRA-2",
         "git_user": "xavi@co.com", "session_id": "session-300", "transcript": "Write unit tests",
         "timestamp": 1712345900.0},
    ]
    path = tmp_path / "events.jsonl"
    with open(path, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")
    return str(path)


class TestDeveloperSummary:
    """Summary for a single developer — what the menubar shows."""

    def test_cost_by_branch(self, events_path):
        from claudedashboard.proxy.developer_view import developer_summary

        s = developer_summary(events_path, "xavi@co.com")
        branches = s["branches"]
        assert "feature/JIRA-1" in branches
        assert branches["feature/JIRA-1"]["cost"] == pytest.approx(0.279)
        assert branches["feature/JIRA-1"]["pct"] == pytest.approx(85.8, abs=0.5)

    def test_total_cost(self, events_path):
        from claudedashboard.proxy.developer_view import developer_summary

        s = developer_summary(events_path, "xavi@co.com")
        assert s["total_cost"] == pytest.approx(0.325)

    def test_active_session(self, events_path):
        from claudedashboard.proxy.developer_view import developer_summary

        s = developer_summary(events_path, "xavi@co.com")
        # Most recent session
        assert s["active_session"]["session_id"] == "session-300"
        assert s["active_session"]["cost"] > 0
        assert s["active_session"]["transcript"] == "Write unit tests"

    def test_model_breakdown(self, events_path):
        from claudedashboard.proxy.developer_view import developer_summary

        s = developer_summary(events_path, "xavi@co.com")
        models = s["models"]
        assert "claude-opus-4-6" in models
        assert models["claude-opus-4-6"]["cost"] > models["claude-sonnet-4-6"]["cost"]

    def test_cache_efficiency(self, events_path):
        from claudedashboard.proxy.developer_view import developer_summary

        s = developer_summary(events_path, "xavi@co.com")
        assert s["cache_hit_ratio"] > 0  # we have cache_read events

    def test_menubar_line(self, events_path):
        """The one-liner for the menubar title."""
        from claudedashboard.proxy.developer_view import menubar_line

        line = menubar_line(events_path, "xavi@co.com")
        # Should contain branch costs like "app/JIRA-1: 86%"
        assert "JIRA-1" in line
        assert "%" in line


class TestDeveloperAPI:
    """API endpoint for the developer view."""

    def test_api_endpoint(self, events_path):
        pytest.importorskip("flask")
        from claudedashboard.proxy.team_dashboard import create_app

        app = create_app(events_path=events_path)
        app.config["TESTING"] = True
        with app.test_client() as c:
            r = c.get("/api/developer?email=xavi@co.com")
            data = r.get_json()
            assert data["total_cost"] > 0
            assert "branches" in data
            assert "active_session" in data

    def test_api_without_email_returns_all(self, events_path):
        pytest.importorskip("flask")
        from claudedashboard.proxy.team_dashboard import create_app

        app = create_app(events_path=events_path)
        app.config["TESTING"] = True
        with app.test_client() as c:
            r = c.get("/api/developer")
            data = r.get_json()
            assert data["total_cost"] > 0
