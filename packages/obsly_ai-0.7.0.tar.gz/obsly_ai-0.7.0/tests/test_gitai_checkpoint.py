"""TDD for checkpoint engine + hook handler — red to green."""
import json, subprocess, time, os
import pytest
from claudedashboard.gitai.models import (
    NormalizedHookInput, HookEvent, CheckpointKind,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _make_hook(repo, event, tool_use_id, tool_name, file_rel, session="s1"):
    return NormalizedHookInput(
        event=event, agent="claude-code", session_id=session,
        tool_name=tool_name,
        tool_input={"file_path": str(repo / file_rel)},
        tool_use_id=tool_use_id, cwd=str(repo), model="claude-sonnet-4-6",
    )


# ── Pre/Post Tool Use ───────────────────────────────────────────────

class TestPrePost:

    def test_pre_creates_snapshot(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        hook = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook)
        snapshot = engine.working_log.load_snapshot("t1")
        assert snapshot is not None
        assert "src/foo.py" in snapshot
        assert snapshot["src/foo.py"] == "line1\nline2\nline3\n"

    def test_post_creates_checkpoint(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("line1\nnew_line2\nline3\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        base = _get_head(git_repo)
        cps = engine.working_log.read_checkpoints(base)
        assert len(cps) == 1
        assert cps[0].kind == CheckpointKind.AI_AGENT
        assert cps[0].entries[0].file == "src/foo.py"
        # Line 2 was changed
        ai_lines = [la for la in cps[0].entries[0].line_attributions
                     if la.author_id != "__initial__"]
        assert len(ai_lines) > 0

    def test_post_no_change_no_checkpoint(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        # Don't change the file
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        base = _get_head(git_repo)
        assert engine.working_log.read_checkpoints(base) == []

    def test_write_new_file(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        new_path = "src/new.py"
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Write", new_path)
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / new_path).write_text("a\nb\nc\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Write", new_path)
        engine.handle_post_tool_use(hook_post)
        base = _get_head(git_repo)
        cps = engine.working_log.read_checkpoints(base)
        assert len(cps) == 1
        assert cps[0].entries[0].line_attributions[0].end_line == 3

    def test_binary_file_skipped(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "image.png").write_bytes(b"\x89PNG\r\n\x1a\n\x00binary")
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Write", "image.png")
        engine.handle_pre_tool_use(hook_pre)
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Write", "image.png")
        engine.handle_post_tool_use(hook_post)
        base = _get_head(git_repo)
        assert engine.working_log.read_checkpoints(base) == []

    def test_ignored_file_skipped(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "package-lock.json").write_text('{"x": 1}')
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Write", "package-lock.json")
        engine.handle_pre_tool_use(hook_pre)
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Write", "package-lock.json")
        engine.handle_post_tool_use(hook_post)
        base = _get_head(git_repo)
        assert engine.working_log.read_checkpoints(base) == []

    def test_snapshot_cleaned_after_post(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("changed\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        assert engine.working_log.load_snapshot("t1") is None


# ── Post-commit ──────────────────────────────────────────────────────

class TestPostCommit:

    def test_writes_git_note(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai.git_notes import notes_read
        from claudedashboard.gitai.authorship_log import deserialize
        engine = CheckpointEngine(str(git_repo))
        # AI edit
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("line1\nnew_line2\nline3\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        # Commit
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI edit"],
                       check=True, capture_output=True)
        engine.handle_post_commit()
        # Verify
        sha = _get_head(git_repo)
        note = notes_read(str(git_repo), sha)
        assert note is not None
        log = deserialize(note)
        # Schema bumps to 3.1.0 once we know total_lines_added (#11 fix)
        assert log.schema_version in ("authorship/3.0.0", "authorship/3.1.0")
        assert len(log.attestations) > 0

    def test_post_commit_records_total_lines_added(self, git_repo):
        """The note must carry total_lines_added so the server can compute ai%."""
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai.git_notes import notes_read
        from claudedashboard.gitai.authorship_log import deserialize
        engine = CheckpointEngine(str(git_repo))
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        # Add 2 new lines (total file has 5 lines now: line1, AI_a, AI_b, line2, line3)
        (git_repo / "src" / "foo.py").write_text("line1\nAI_a\nAI_b\nline2\nline3\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI"],
                       check=True, capture_output=True)
        engine.handle_post_commit()
        sha = _get_head(git_repo)
        log = deserialize(notes_read(str(git_repo), sha))
        assert log.total_lines_added is not None
        assert log.total_lines_added >= 2  # at least the 2 new lines we added

    def test_no_ai_no_note(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai.git_notes import notes_read
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "src" / "foo.py").write_text("human edit\n")
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "human"],
                       check=True, capture_output=True)
        engine.handle_post_commit()
        sha = _get_head(git_repo)
        assert notes_read(str(git_repo), sha) is None

    def test_cleans_working_log(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        parent = _get_head(git_repo)
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("changed\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "edit"],
                       check=True, capture_output=True)
        engine.handle_post_commit()
        assert engine.working_log.read_checkpoints(parent) == []


# ── Hook handler parsing ────────────────────────────────────────────

class TestHookHandler:

    def test_parse_claude(self):
        from claudedashboard.gitai.hook_handler import parse_hook_input
        raw = json.dumps({
            "session_id": "s1", "cwd": "/repo", "hook_event_name": "PostToolUse",
            "tool_name": "Edit", "tool_input": {"file_path": "/repo/foo.py"},
            "tool_use_id": "t1", "transcript_path": "/path/transcript.jsonl",
        })
        hook = parse_hook_input("claude-code", raw)
        assert hook.event == HookEvent.POST_TOOL_USE
        assert hook.tool_name == "Edit"
        assert hook.agent == "claude-code"
        assert hook.session_id == "s1"

    def test_parse_cursor_camelcase(self):
        from claudedashboard.gitai.hook_handler import parse_hook_input
        raw = json.dumps({
            "hook_event_name": "postToolUse", "conversation_id": "c1",
            "workspace_roots": ["/repo"], "tool_name": "edit",
            "tool_input": {"file_path": "/repo/foo.py"}, "tool_use_id": "t1",
        })
        hook = parse_hook_input("cursor", raw)
        assert hook.event == HookEvent.POST_TOOL_USE

    def test_parse_codex(self):
        from claudedashboard.gitai.hook_handler import parse_hook_input
        raw = json.dumps({
            "hook_event_name": "PreToolUse", "tool_name": "write",
            "tool_input": {"file_path": "/repo/foo.py"}, "tool_use_id": "t1",
            "cwd": "/repo", "session_id": "codex-s1",
        })
        hook = parse_hook_input("codex", raw)
        assert hook.event == HookEvent.PRE_TOOL_USE
        assert hook.agent == "codex"


# ── Performance ──────────────────────────────────────────────────────

class TestPerformance:

    def test_hook_latency(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        start = time.monotonic()
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "perf", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("perf test\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "perf", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        elapsed = (time.monotonic() - start) * 1000
        assert elapsed < 200, f"Hook cycle took {elapsed:.0f}ms"
