"""TDD for mitmproxy addon — the glue that connects capture + attribute + store."""
import json
import pytest
from unittest.mock import MagicMock, patch


MOCK_PINFO_CURSOR = {"pid": 1234, "ppid": 500, "pname": "cursor", "cwd": "/Users/xavi/projects/app"}
MOCK_PINFO_AIDER = {"pid": 5678, "ppid": 600, "pname": "aider", "cwd": "/Users/xavi_1/Repositories/claudedashboard"}
MOCK_PINFO_PYTHON = {"pid": 9999, "ppid": 700, "pname": "python", "cwd": "/tmp"}


class TestAddon:
    """The mitmproxy addon intercepts LLM responses and stores attributed events."""

    def test_addon_processes_anthropic_response(self, tmp_path):
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        flow = _make_flow(
            host="api.anthropic.com",
            response_body={
                "model": "claude-sonnet-4-6-20250514",
                "usage": {"input_tokens": 100, "output_tokens": 50},
            },
        )

        with patch("claudedashboard.proxy.addon._resolve_process_info", return_value=MOCK_PINFO_CURSOR):
            addon.request(flow)
            addon.response(flow)

        events = _read_jsonl(store_path)
        assert len(events) == 1
        assert events[0]["provider"] == "anthropic"
        assert events[0]["tokens_in"] == 100
        assert events[0]["tool"] == "cursor"

    def test_addon_ignores_non_llm_traffic(self, tmp_path):
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        flow = _make_flow(host="api.github.com", response_body={"data": "stuff"})
        addon.request(flow)
        addon.response(flow)

        assert not store_path.exists()

    def test_addon_handles_malformed_response(self, tmp_path):
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        flow = _make_flow(host="api.anthropic.com", response_body="not json at all")
        addon.request(flow)
        addon.response(flow)  # should not crash

        assert not store_path.exists()

    def test_addon_includes_git_attribution(self, tmp_path):
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        flow = _make_flow(
            host="api.openai.com",
            response_body={
                "model": "gpt-4o",
                "usage": {"prompt_tokens": 200, "completion_tokens": 100},
            },
        )

        with patch("claudedashboard.proxy.addon._resolve_process_info", return_value=MOCK_PINFO_AIDER):
            addon.request(flow)
            addon.response(flow)

        events = _read_jsonl(store_path)
        assert events[0]["repo"] is not None
        assert any(name in events[0]["repo"] for name in ("claudedashboard", "obsly-ai"))
        assert events[0]["tool"] == "aider"

    def test_addon_works_with_streaming_final_chunk(self, tmp_path):
        """Streaming responses: only the final message has usage."""
        from claudedashboard.proxy.addon import LLMTrackerAddon

        store_path = tmp_path / "events.jsonl"
        addon = LLMTrackerAddon(store_path=str(store_path))

        # Chunk without usage — should be ignored
        flow1 = _make_flow(
            host="api.anthropic.com",
            response_body={"type": "content_block_delta", "delta": {"text": "hello"}},
        )
        addon.request(flow1)
        addon.response(flow1)
        assert not store_path.exists()

        # Final message with usage
        flow2 = _make_flow(
            host="api.anthropic.com",
            response_body={
                "model": "claude-sonnet-4-6",
                "type": "message",
                "usage": {"input_tokens": 500, "output_tokens": 200},
            },
        )
        with patch("claudedashboard.proxy.addon._resolve_process_info", return_value=MOCK_PINFO_PYTHON):
            addon.request(flow2)
            addon.response(flow2)

        events = _read_jsonl(store_path)
        assert len(events) == 1


# ── Helpers ──────────────────────────────────────────────────────────

def _make_flow(host, response_body, request_body=None):
    flow = MagicMock(spec=["request", "response", "client_conn", "timestamp_created"])
    flow.request = MagicMock()
    flow.response = MagicMock()
    flow.client_conn = MagicMock()
    flow.request.host = host
    flow.request.url = f"https://{host}/v1/messages"
    if request_body:
        flow.request.content = json.dumps(request_body).encode()
    else:
        flow.request.content = b"{}"
    if isinstance(response_body, str):
        flow.response.content = response_body.encode()
    else:
        flow.response.content = json.dumps(response_body).encode()
    flow.response.headers = MagicMock()
    flow.response.headers.get = lambda key, default="": "application/json"
    flow.timestamp_created = 1712345678.0
    flow.client_conn.peername = ("127.0.0.1", 54321)
    return flow


def _read_jsonl(path):
    if not path.exists():
        return []
    events = []
    with open(path) as f:
        for line in f:
            if line.strip():
                events.append(json.loads(line))
    return events
