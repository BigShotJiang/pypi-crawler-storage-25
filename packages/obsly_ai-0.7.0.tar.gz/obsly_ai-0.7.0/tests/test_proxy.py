"""TDD for LLM proxy plugin — red to green."""
import json
import pytest


# ── Test 1: CAPTURE — extract usage from LLM responses ──────────────

class TestCapture:
    """Can we extract tokens, model, cost from each provider's response?"""

    def test_extract_anthropic_response(self):
        from claudedashboard.proxy.capture import extract_usage

        body = {
            "model": "claude-sonnet-4-6-20250514",
            "usage": {
                "input_tokens": 1500,
                "output_tokens": 800,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 200,
            },
        }
        event = extract_usage("api.anthropic.com", body)
        assert event["provider"] == "anthropic"
        assert event["model"] == "claude-sonnet-4-6-20250514"
        assert event["tokens_in"] == 1500
        assert event["tokens_out"] == 800
        assert event["cache_read"] == 200
        assert event["cost"] > 0

    def test_extract_openai_response(self):
        from claudedashboard.proxy.capture import extract_usage

        body = {
            "model": "gpt-4o",
            "usage": {
                "prompt_tokens": 1000,
                "completion_tokens": 500,
            },
        }
        event = extract_usage("api.openai.com", body)
        assert event["provider"] == "openai"
        assert event["model"] == "gpt-4o"
        assert event["tokens_in"] == 1000
        assert event["tokens_out"] == 500
        assert event["cost"] > 0

    def test_extract_deepseek_response(self):
        from claudedashboard.proxy.capture import extract_usage

        body = {
            "model": "deepseek-chat",
            "usage": {
                "prompt_tokens": 2000,
                "completion_tokens": 1000,
            },
        }
        event = extract_usage("api.deepseek.com", body)
        assert event["provider"] == "deepseek"
        assert event["tokens_in"] == 2000
        assert event["tokens_out"] == 1000

    def test_ignore_non_llm_domain(self):
        from claudedashboard.proxy.capture import extract_usage

        result = extract_usage("api.github.com", {"whatever": True})
        assert result is None

    def test_missing_usage_field(self):
        from claudedashboard.proxy.capture import extract_usage

        result = extract_usage("api.anthropic.com", {"model": "claude", "no_usage": True})
        assert result is None


# ── Test 2: ATTRIBUTE — git info from a directory ────────────────────

class TestAttribute:
    """Can we get repo, branch, git user from a working directory?"""

    def test_get_git_info_from_cwd(self, tmp_path):
        """Use the actual repo we're in as test fixture."""
        from claudedashboard.proxy.attribute import get_git_info

        info = get_git_info("/Users/xavi_1/Repositories/claudedashboard")
        assert info["repo"] is not None
        assert any(name in info["repo"] for name in ("claudedashboard", "obsly-ai"))
        assert info["branch"] is not None
        assert info["git_user"] is not None

    def test_get_git_info_non_repo(self, tmp_path):
        from claudedashboard.proxy.attribute import get_git_info

        info = get_git_info(str(tmp_path))
        assert info["repo"] is None
        assert info["branch"] is None

    def test_get_git_info_nonexistent_path(self):
        from claudedashboard.proxy.attribute import get_git_info

        info = get_git_info("/nonexistent/path")
        assert info["repo"] is None


# ── Test 3: STORE — persist events to JSONL ──────────────────────────

class TestStore:
    """Can we store and retrieve captured events?"""

    def test_store_and_read_event(self, tmp_path):
        from claudedashboard.proxy.store import EventStore

        store = EventStore(tmp_path / "events.jsonl")
        event = {
            "provider": "anthropic",
            "model": "claude-sonnet-4-6",
            "tokens_in": 1500,
            "tokens_out": 800,
            "cost": 0.057,
            "tool": "cursor",
            "repo": "github.com/empresa/backend",
            "branch": "feature/JIRA-123",
            "git_user": "xavi@empresa.com",
            "timestamp": 1712345678.0,
        }
        store.append(event)
        events = store.read_all()
        assert len(events) == 1
        assert events[0]["repo"] == "github.com/empresa/backend"

    def test_store_multiple_events(self, tmp_path):
        from claudedashboard.proxy.store import EventStore

        store = EventStore(tmp_path / "events.jsonl")
        for i in range(5):
            store.append({"tokens_in": i, "timestamp": float(i)})
        assert len(store.read_all()) == 5


# ── Test 4: AGGREGATE — behavior and conclusions ─────────────────────

class TestAggregate:
    """Can we show behavior and draw conclusions?"""

    def test_cost_by_repo(self):
        from claudedashboard.proxy.aggregate import cost_by_repo

        events = [
            {"repo": "app", "cost": 0.10, "timestamp": 1.0},
            {"repo": "app", "cost": 0.20, "timestamp": 2.0},
            {"repo": "backend", "cost": 0.05, "timestamp": 3.0},
        ]
        result = cost_by_repo(events)
        assert result["app"] == pytest.approx(0.30)
        assert result["backend"] == pytest.approx(0.05)

    def test_cost_by_branch(self):
        from claudedashboard.proxy.aggregate import cost_by_branch

        events = [
            {"branch": "feature/JIRA-1", "cost": 0.10, "timestamp": 1.0},
            {"branch": "feature/JIRA-1", "cost": 0.20, "timestamp": 2.0},
            {"branch": "fix/BUG-99", "cost": 0.05, "timestamp": 3.0},
        ]
        result = cost_by_branch(events)
        assert result["feature/JIRA-1"] == pytest.approx(0.30)

    def test_cost_by_developer(self):
        from claudedashboard.proxy.aggregate import cost_by_developer

        events = [
            {"git_user": "xavi@co.com", "cost": 0.50, "timestamp": 1.0},
            {"git_user": "ana@co.com", "cost": 0.30, "timestamp": 2.0},
        ]
        result = cost_by_developer(events)
        assert result["xavi@co.com"] == pytest.approx(0.50)

    def test_model_usage_distribution(self):
        from claudedashboard.proxy.aggregate import model_distribution

        events = [
            {"model": "claude-sonnet-4-6", "cost": 0.10, "timestamp": 1.0},
            {"model": "claude-sonnet-4-6", "cost": 0.10, "timestamp": 2.0},
            {"model": "claude-opus-4-6", "cost": 0.50, "timestamp": 3.0},
        ]
        result = model_distribution(events)
        assert result["claude-opus-4-6"]["cost"] == pytest.approx(0.50)
        assert result["claude-opus-4-6"]["count"] == 1
        assert result["claude-sonnet-4-6"]["count"] == 2

    def test_pct_by_repo_branch(self):
        """Developer sees: 'mi-app/feature-123: 28%' in menubar."""
        from claudedashboard.proxy.aggregate import pct_by_repo_branch

        events = [
            {"repo": "app", "branch": "feat-1", "cost": 0.28, "timestamp": 1.0},
            {"repo": "app", "branch": "feat-2", "cost": 0.12, "timestamp": 2.0},
            {"repo": "api", "branch": "fix-9", "cost": 0.60, "timestamp": 3.0},
        ]
        result = pct_by_repo_branch(events)
        assert result[("app", "feat-1")] == pytest.approx(28.0)
        assert result[("api", "fix-9")] == pytest.approx(60.0)
