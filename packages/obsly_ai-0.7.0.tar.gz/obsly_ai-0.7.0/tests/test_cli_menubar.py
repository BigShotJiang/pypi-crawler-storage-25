"""Tests for the menubar CLI subcommand parsing."""

import pytest

from claudedashboard.cli import _build_parser


def test_cli_menubar_default_action_is_run():
    parser = _build_parser()
    args = parser.parse_args(["menubar"])
    assert args.command == "menubar"
    assert args.action == "run"


def test_cli_menubar_install_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["menubar", "install"])
    assert args.command == "menubar"
    assert args.action == "install"


def test_cli_menubar_install_dry_run_flag():
    parser = _build_parser()
    args = parser.parse_args(["menubar", "install", "--dry-run"])
    assert args.action == "install"
    assert args.dry_run is True


def test_cli_menubar_status_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["menubar", "status"])
    assert args.action == "status"


def test_cli_menubar_uninstall_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["menubar", "uninstall"])
    assert args.action == "uninstall"


def test_cli_menubar_invalid_action_rejected():
    parser = _build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(["menubar", "badaction"])


def test_cli_tray_still_works():
    parser = _build_parser()
    args = parser.parse_args(["tray"])
    assert args.command == "tray"
