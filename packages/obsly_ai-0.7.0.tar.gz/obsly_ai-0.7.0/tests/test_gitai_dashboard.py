"""TDD for dashboard integration — API endpoints + SSE events."""
import json, subprocess, os
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _add_note(repo):
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add
    sha = _get_head(repo)
    log = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(2, 3)]),
        ])],
        base_commit_sha=sha,
        prompts={"aaa1234567890123": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "sonnet"),
            total_additions=2, custom_attributes={"cost_usd": "0.25"},
        )},
    )
    notes_add(str(repo), sha, serialize(log))


# ── API data provider ────────────────────────────────────────────────

class TestApiData:

    def test_summary(self, git_repo):
        _add_note(git_repo)
        from claudedashboard.gitai.api_data import get_ai_summary
        data = get_ai_summary(str(git_repo))
        assert data["total_commits_scanned"] >= 1
        assert data["commits_with_ai"] == 1
        assert data["ai_lines"] == 2
        assert data["overall_ai_percentage"] > 0

    def test_commits_list(self, git_repo):
        _add_note(git_repo)
        from claudedashboard.gitai.api_data import get_ai_commits
        data = get_ai_commits(str(git_repo), limit=10)
        assert len(data["commits"]) == 1
        assert data["commits"][0]["ai_lines"] == 2
        assert "claude-code" in data["commits"][0]["agents"]

    def test_empty_repo(self, git_repo):
        from claudedashboard.gitai.api_data import get_ai_summary
        data = get_ai_summary(str(git_repo))
        assert data["commits_with_ai"] == 0
        assert data["ai_lines"] == 0


# ── SSE event builder ───────────────────────────────────────────────

class TestSseEvents:

    def test_activity_event(self, git_repo):
        from claudedashboard.gitai.api_data import build_activity_event
        from claudedashboard.gitai.working_log import WorkingLog
        from claudedashboard.gitai.models import Checkpoint, CheckpointKind, WorkingLogEntry, LineAttribution
        wl = WorkingLog(str(git_repo))
        cp = Checkpoint(kind=CheckpointKind.AI_AGENT, author="test@test.com",
                        entries=[WorkingLogEntry("src/foo.py", "sha", [LineAttribution(1, 5, "h", None)])])
        base = _get_head(git_repo)
        wl.append_checkpoint(base, cp)
        event = build_activity_event(str(git_repo))
        assert event is not None
        assert event["type"] == "ai_activity"
        assert event["data"]["total_ai_lines_uncommitted"] == 5

    def test_activity_event_empty(self, git_repo):
        from claudedashboard.gitai.api_data import build_activity_event
        event = build_activity_event(str(git_repo))
        assert event is None  # no working log, no event

    def test_commit_event(self, git_repo):
        _add_note(git_repo)
        from claudedashboard.gitai.api_data import build_commit_event
        sha = _get_head(git_repo)
        event = build_commit_event(str(git_repo), sha)
        assert event is not None
        assert event["type"] == "ai_commit"
        assert event["data"]["ai_lines"] == 2


# ── Menubar data ─────────────────────────────────────────────────────

class TestMenubarData:

    def test_fetch_stats(self, git_repo):
        _add_note(git_repo)
        from claudedashboard.gitai.api_data import get_menubar_stats
        stats = get_menubar_stats(str(git_repo))
        assert stats is not None
        assert "last_commit_ai_pct" in stats
        assert stats["last_commit_ai_pct"] > 0

    def test_fetch_stats_no_data(self, git_repo):
        from claudedashboard.gitai.api_data import get_menubar_stats
        stats = get_menubar_stats(str(git_repo))
        assert stats is None or stats.get("last_commit_ai_pct", 0) == 0
