"""TDD for obsly-ai config command + ingest sync helper."""

import json
import os
import pytest
from unittest.mock import patch


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(tmp_path / ".obsly-ai"))
    return tmp_path


def test_default_config_uses_localhost(fake_home):
    from claudedashboard.gitai.obsly_config import load_config
    cfg = load_config()
    assert cfg["server_url"] == "http://localhost:8002"
    assert cfg.get("token", "") == ""
    assert cfg.get("device_token", "") == ""


def test_set_and_load_config(fake_home):
    from claudedashboard.gitai.obsly_config import set_value, load_config
    set_value("server", "https://ai.obsly.io")
    set_value("token", "abc123")
    set_value("device_token", "dev-123")
    cfg = load_config()
    assert cfg["server_url"] == "https://ai.obsly.io"
    assert cfg["token"] == "abc123"
    assert cfg["device_token"] == "dev-123"


def test_config_file_location(fake_home):
    from claudedashboard.gitai.obsly_config import set_value, config_path
    set_value("server", "http://x")
    p = config_path()
    assert p.exists()
    data = json.loads(p.read_text())
    assert data["server_url"] == "http://x"


def test_show_includes_device_token_state(fake_home, capsys):
    from claudedashboard.gitai.obsly_config import set_value, show
    set_value("device_token", "dev-123")
    show()
    out = capsys.readouterr().out
    assert "device_token:" in out
    assert "<set>" in out


# ── ingest_sync.send_note ───────────────────────────────────────────

class _FakeResp:
    def __init__(self, status=200, body=b'{"status":"ok","commit_id":1}'):
        self.status = status
        self._body = body
    def read(self):
        return self._body
    def __enter__(self):
        return self
    def __exit__(self, *a):
        return False


def test_send_note_posts_to_configured_server(fake_home, monkeypatch):
    from claudedashboard.gitai import ingest_sync
    from claudedashboard.gitai.obsly_config import set_value
    set_value("server", "http://test-server:9999")

    captured = {}
    def fake_urlopen(req, timeout=None):
        captured["url"] = req.full_url
        captured["body"] = json.loads(req.data.decode())
        captured["headers"] = dict(req.headers)
        return _FakeResp()

    monkeypatch.setattr(ingest_sync.urllib.request, "urlopen", fake_urlopen)

    ok = ingest_sync.send_note(
        repo_url="git@github.com:alice/repo.git",
        sha="a"*40,
        note_content="some note",
        author_email="alice@example.com",
        author_name="Alice",
        message="msg",
        committed_at="2026-04-10T12:00:00Z",
    )
    assert ok is True
    assert captured["url"] == "http://test-server:9999/api/ingest-note"
    assert captured["body"]["sha"] == "a" * 40
    assert captured["body"]["repo_url"] == "git@github.com:alice/repo.git"


def test_send_note_silent_on_error(fake_home, monkeypatch):
    from claudedashboard.gitai import ingest_sync

    def fake_urlopen(req, timeout=None):
        raise OSError("connection refused")

    monkeypatch.setattr(ingest_sync.urllib.request, "urlopen", fake_urlopen)

    # Must not raise
    ok = ingest_sync.send_note(
        repo_url="git@github.com:a/b.git", sha="x"*40,
        note_content="", author_email="", author_name="",
        message="", committed_at=None,
    )
    assert ok is False


def test_send_note_uses_token_header(fake_home, monkeypatch):
    from claudedashboard.gitai import ingest_sync
    from claudedashboard.gitai.obsly_config import set_value
    set_value("token", "secret-token")

    captured = {}
    def fake_urlopen(req, timeout=None):
        captured["headers"] = dict(req.headers)
        return _FakeResp()

    monkeypatch.setattr(ingest_sync.urllib.request, "urlopen", fake_urlopen)

    ingest_sync.send_note(
        repo_url="git@x:y/z.git", sha="a"*40,
        note_content="", author_email="", author_name="",
        message="", committed_at=None,
    )
    # urllib normalizes header names with .title()
    auth = captured["headers"].get("Authorization") or captured["headers"].get("authorization")
    assert auth == "Bearer secret-token"
