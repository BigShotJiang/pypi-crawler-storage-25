"""Tests for claudedashboard.version_check (PyPI update check, stdlib only)."""

import io
import json
import os
import time
from unittest.mock import patch

import pytest

from claudedashboard import version_check


def _fake_urlopen(payload, raise_exc=None, delay=0.0):
    class _Resp:
        def __init__(self, data):
            self._data = data
        def read(self):
            return self._data
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False

    def _opener(url, timeout=None):
        if delay:
            time.sleep(delay)
        if raise_exc is not None:
            raise raise_exc
        return _Resp(json.dumps(payload).encode("utf-8"))
    return _opener


@pytest.fixture
def cache_file(tmp_path):
    return tmp_path / "version_cache.json"


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    monkeypatch.delenv("OBSLY_NO_UPDATE_CHECK", raising=False)
    yield


def test_check_returns_latest_when_outdated(cache_file):
    fake = _fake_urlopen({"info": {"version": "0.4.0"}})
    with patch.object(version_check, "urlopen", fake):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest == "0.4.0"


def test_check_returns_none_when_up_to_date(cache_file):
    fake = _fake_urlopen({"info": {"version": "0.3.1"}})
    with patch.object(version_check, "urlopen", fake):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest is None


def test_check_returns_none_when_local_is_newer(cache_file):
    """Local dev version > pypi must NOT report an update."""
    fake = _fake_urlopen({"info": {"version": "0.3.1"}})
    with patch.object(version_check, "urlopen", fake):
        latest = version_check.check_for_update("0.4.0", cache_path=str(cache_file))
    assert latest is None


def test_check_uses_cache_within_24h(cache_file):
    cache_file.write_text(json.dumps({
        "last_check": time.time() - 3600,  # 1h ago
        "latest": "0.5.0",
    }))
    called = {"n": 0}
    def _opener(url, timeout=None):
        called["n"] += 1
        raise AssertionError("urlopen should not be called when cache is fresh")
    with patch.object(version_check, "urlopen", _opener):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest == "0.5.0"
    assert called["n"] == 0


def test_check_refreshes_cache_after_24h(cache_file):
    cache_file.write_text(json.dumps({
        "last_check": time.time() - (25 * 3600),  # 25h ago — stale
        "latest": "0.3.1",
    }))
    fake = _fake_urlopen({"info": {"version": "0.6.0"}})
    with patch.object(version_check, "urlopen", fake):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest == "0.6.0"


def test_check_silent_on_network_error(cache_file):
    fake = _fake_urlopen(None, raise_exc=OSError("network down"))
    with patch.object(version_check, "urlopen", fake):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest is None


def test_check_skipped_when_env_var_set(cache_file, monkeypatch):
    monkeypatch.setenv("OBSLY_NO_UPDATE_CHECK", "1")
    def _opener(url, timeout=None):
        raise AssertionError("urlopen should not be called when disabled")
    with patch.object(version_check, "urlopen", _opener):
        latest = version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert latest is None


def test_check_completes_under_2s(cache_file):
    """Even if everything goes wrong, the call must not block more than ~2s."""
    fake = _fake_urlopen(None, raise_exc=OSError("timeout"))
    start = time.monotonic()
    with patch.object(version_check, "urlopen", fake):
        version_check.check_for_update("0.3.1", cache_path=str(cache_file))
    assert time.monotonic() - start < 2.0


def test_format_message_outdated():
    msg = version_check.format_update_message("0.3.1", "0.4.0")
    assert "0.4.0" in msg
    assert "0.3.1" in msg
    assert "pipx" in msg or "pip" in msg


def test_format_message_none_when_no_update():
    assert version_check.format_update_message("0.3.1", None) is None
