import os
import claudedashboard.run_with_proxy as rwp


def test_build_env_sets_https_proxy():
    env = rwp.build_env({"PATH": "/usr/bin", "FOO": "bar"})
    assert env["HTTPS_PROXY"] == "http://localhost:8080"
    assert env["HTTP_PROXY"] == "http://localhost:8080"
    assert env["PATH"] == "/usr/bin"
    assert env["FOO"] == "bar"


def test_build_env_uses_os_environ_by_default(monkeypatch):
    monkeypatch.setenv("FAKE_VAR", "value")
    env = rwp.build_env()
    assert env["FAKE_VAR"] == "value"
    assert env["HTTPS_PROXY"] == "http://localhost:8080"


def test_build_env_overrides_existing_https_proxy():
    env = rwp.build_env({"HTTPS_PROXY": "http://corporate:3128"})
    assert env["HTTPS_PROXY"] == "http://localhost:8080"


def test_build_env_does_not_mutate_input():
    base = {"FOO": "bar"}
    rwp.build_env(base)
    assert "HTTPS_PROXY" not in base


def test_build_env_custom_proxy_url():
    env = rwp.build_env({}, proxy_url="http://localhost:9999")
    assert env["HTTPS_PROXY"] == "http://localhost:9999"
    assert env["HTTP_PROXY"] == "http://localhost:9999"


def test_check_proxy_running_when_running():
    assert rwp.check_proxy_running(lambda: "running") == (True, "running")


def test_check_proxy_running_when_stopped():
    assert rwp.check_proxy_running(lambda: "stopped") == (False, "stopped")


def test_check_proxy_running_when_not_installed():
    assert rwp.check_proxy_running(lambda: "not_installed") == (False, "not_installed")


def test_check_proxy_running_default_uses_proxy_service(monkeypatch):
    import claudedashboard.proxy_service as ps
    monkeypatch.setattr(ps, "status", lambda: "running")
    assert rwp.check_proxy_running() == (True, "running")


def test_run_returns_2_for_empty_argv(capsys):
    code = rwp.run([], status_func=lambda: "running")
    assert code == 2
    err = capsys.readouterr().err
    assert "usage" in err.lower() or "command" in err.lower()


def test_run_returns_3_when_proxy_not_running(capsys):
    code = rwp.run(["claude"], status_func=lambda: "stopped")
    assert code == 3
    err = capsys.readouterr().err
    assert "proxy" in err.lower()
    assert "obsly-ai proxy install" in err or "obsly-ai proxy" in err


def test_run_returns_3_when_proxy_not_installed(capsys):
    code = rwp.run(["claude"], status_func=lambda: "not_installed")
    assert code == 3


def test_run_calls_exec_with_command_when_proxy_running():
    captured = {}
    def fake_exec(file, args, env):
        captured["file"] = file
        captured["args"] = list(args)
        captured["env"] = dict(env)
    rwp.run(["claude", "--foo"], status_func=lambda: "running", exec_func=fake_exec)
    assert captured["file"] == "claude"
    assert captured["args"] == ["claude", "--foo"]
    assert captured["env"]["HTTPS_PROXY"] == "http://localhost:8080"


def test_run_passes_through_existing_env(monkeypatch):
    monkeypatch.setenv("PATH", "/usr/local/bin")
    captured = {}
    def fake_exec(file, args, env):
        captured["env"] = dict(env)
    rwp.run(["claude"], status_func=lambda: "running", exec_func=fake_exec)
    assert captured["env"]["PATH"] == "/usr/local/bin"


def test_run_returns_127_on_filenotfound(capsys):
    def fake_exec(file, args, env):
        raise FileNotFoundError(f"no such command: {file}")
    code = rwp.run(["nonexistent"], status_func=lambda: "running", exec_func=fake_exec)
    assert code == 127
    err = capsys.readouterr().err
    assert "nonexistent" in err


def test_run_returns_127_on_oserror():
    def fake_exec(file, args, env):
        raise OSError("permission denied")
    code = rwp.run(["claude"], status_func=lambda: "running", exec_func=fake_exec)
    assert code == 127


def test_run_uses_injected_env_argument():
    captured = {}
    def fake_exec(file, args, env):
        captured["env"] = dict(env)
    rwp.run(["claude"], status_func=lambda: "running", exec_func=fake_exec,
            env={"CUSTOM": "value"})
    assert captured["env"]["CUSTOM"] == "value"
    assert captured["env"]["HTTPS_PROXY"] == "http://localhost:8080"
