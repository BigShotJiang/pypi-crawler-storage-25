"""TDD for new CLI subcommands: proxy, server, doctor, config."""
import pytest
from unittest.mock import patch


class TestCLIProxy:
    def test_proxy_command_exists(self):
        from claudedashboard.proxy.commands import cmd_proxy
        assert callable(cmd_proxy)

    def test_proxy_default_port(self):
        from claudedashboard.proxy.commands import cmd_proxy
        import inspect
        sig = inspect.signature(cmd_proxy)
        assert "port" in sig.parameters


class TestCLIServer:
    def test_server_command_exists(self):
        from claudedashboard.proxy.commands import cmd_server
        assert callable(cmd_server)

    def test_server_default_port(self):
        from claudedashboard.proxy.commands import cmd_server
        import inspect
        sig = inspect.signature(cmd_server)
        assert "port" in sig.parameters


class TestCLIDoctor:
    def test_doctor_command_exists(self):
        from claudedashboard.proxy.commands import cmd_doctor
        assert callable(cmd_doctor)

    def test_doctor_prints_results(self, capsys):
        from claudedashboard.proxy.commands import cmd_doctor
        cmd_doctor()
        captured = capsys.readouterr()
        assert "mitmproxy" in captured.out.lower()


class TestCLIConfig:
    def test_config_command_exists(self):
        from claudedashboard.proxy.commands import cmd_config
        assert callable(cmd_config)

    def test_config_show_defaults(self, capsys):
        from claudedashboard.proxy.commands import cmd_config
        cmd_config(action="show")
        captured = capsys.readouterr()
        assert "proxy_port" in captured.out or "events_path" in captured.out
