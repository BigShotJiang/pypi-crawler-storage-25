"""TDD for ai-stats command — red to green."""
import json, subprocess
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\nline4\nline5\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _add_note(repo, log):
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add
    sha = _get_head(repo)
    notes_add(str(repo), sha, serialize(log))


@pytest.fixture
def repo_with_note(git_repo):
    log = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(1, 3)]),
            AttestationEntry("bbb1234567890123", [LineRange(4, 5)]),
        ])],
        base_commit_sha=_get_head(git_repo),
        prompts={
            "aaa1234567890123": PromptRecord(
                agent_id=AgentId("claude-code", "s1", "claude-sonnet-4-6"),
                total_additions=3, custom_attributes={"cost_usd": "0.30"},
            ),
            "bbb1234567890123": PromptRecord(
                agent_id=AgentId("cursor", "s2", "gpt-4o"),
                total_additions=2, custom_attributes={"cost_usd": "0.20"},
            ),
        },
    )
    _add_note(git_repo, log)
    return git_repo


@pytest.fixture
def repo_with_multiple_notes(git_repo):
    """Two commits, each with a note."""
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add

    # First commit already exists (init). Add note to it.
    sha1 = _get_head(git_repo)
    log1 = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(1, 3)]),
        ])],
        base_commit_sha=sha1,
        prompts={"aaa1234567890123": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "sonnet"), total_additions=3,
        )},
    )
    notes_add(str(git_repo), sha1, serialize(log1))

    # Second commit
    (git_repo / "src" / "bar.py").write_text("a\nb\nc\n")
    subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "add bar"],
                   check=True, capture_output=True)
    sha2 = _get_head(git_repo)
    log2 = AuthorshipLog(
        attestations=[FileAttestation("src/bar.py", [
            AttestationEntry("bbb1234567890123", [LineRange(1, 2)]),
        ])],
        base_commit_sha=sha2,
        prompts={"bbb1234567890123": PromptRecord(
            agent_id=AgentId("cursor", "s2", "gpt-4o"), total_additions=2,
        )},
    )
    notes_add(str(git_repo), sha2, serialize(log2))
    return git_repo


# ── Stats for commit ─────────────────────────────────────────────────

class TestCommitStats:

    def test_basic(self, repo_with_note):
        from claudedashboard.gitai.stats import stats_for_commit
        stats = stats_for_commit(str(repo_with_note))
        assert stats is not None
        assert stats.ai_lines == 5
        assert stats.ai_percentage == pytest.approx(100.0)
        assert "claude-code" in stats.by_agent
        assert "cursor" in stats.by_agent
        assert stats.by_agent["claude-code"] == 3
        assert stats.by_agent["cursor"] == 2

    def test_no_note(self, git_repo):
        from claudedashboard.gitai.stats import stats_for_commit
        assert stats_for_commit(str(git_repo)) is None

    def test_by_model(self, repo_with_note):
        from claudedashboard.gitai.stats import stats_for_commit
        stats = stats_for_commit(str(repo_with_note))
        assert "claude-sonnet-4-6" in stats.by_model
        assert "gpt-4o" in stats.by_model

    def test_with_cost(self, repo_with_note):
        from claudedashboard.gitai.stats import stats_for_commit
        stats = stats_for_commit(str(repo_with_note))
        assert stats.estimated_cost_usd == pytest.approx(0.50)


# ── Stats for repo ───────────────────────────────────────────────────

class TestRepoStats:

    def test_basic(self, repo_with_multiple_notes):
        from claudedashboard.gitai.stats import stats_for_repo
        stats = stats_for_repo(str(repo_with_multiple_notes), limit=10)
        assert stats.total_commits_scanned >= 2
        assert stats.commits_with_ai == 2
        assert stats.ai_lines == 5  # 3 + 2
        assert stats.ai_percentage > 0

    def test_empty_repo(self, git_repo):
        from claudedashboard.gitai.stats import stats_for_repo
        stats = stats_for_repo(str(git_repo), limit=10)
        assert stats.commits_with_ai == 0
        assert stats.ai_percentage == 0


# ── Output formatters ───────────────────────────────────────────────

class TestFormatters:

    def test_json_output(self, repo_with_note):
        from claudedashboard.gitai.stats import stats_for_commit, format_stats_json
        stats = stats_for_commit(str(repo_with_note))
        output = format_stats_json(stats)
        data = json.loads(output)
        assert "ai_percentage" in data
        assert "by_agent" in data

    def test_terminal_output(self, repo_with_note):
        from claudedashboard.gitai.stats import stats_for_commit, format_commit_terminal
        stats = stats_for_commit(str(repo_with_note))
        output = format_commit_terminal(stats)
        assert "%" in output
        assert "claude-code" in output

    def test_oneliner(self, repo_with_multiple_notes):
        from claudedashboard.gitai.stats import stats_for_repo, format_oneliner
        stats = stats_for_repo(str(repo_with_multiple_notes))
        line = format_oneliner(stats)
        assert "%" in line
        assert "AI" in line
