"""TDD for usage_adapters: claude_code + codex readers."""

import json
from pathlib import Path
import pytest


# ── Claude Code adapter ──────────────────────────────────────────

@pytest.fixture
def claude_logs(tmp_path):
    """Synthetic ~/.claude/projects/... structure with one assistant message."""
    proj = tmp_path / ".claude" / "projects" / "-Users-test-myproject"
    sess = "abc123-session"
    proj.mkdir(parents=True)
    log = proj / f"{sess}.jsonl"
    lines = [
        {
            "sessionId": sess, "type": "user",
            "timestamp": "2026-04-10T12:00:00.000Z",
            "message": {"role": "user", "content": "hi"},
        },
        {
            "sessionId": sess, "type": "assistant",
            "timestamp": "2026-04-10T12:00:05.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 200,
                    "cache_read_input_tokens": 1000,
                    "cache_creation_input_tokens": 500,
                },
            },
        },
        {
            "sessionId": sess, "type": "assistant",
            "timestamp": "2026-04-10T12:01:00.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "usage": {
                    "input_tokens": 50,
                    "output_tokens": 50,
                    "cache_read_input_tokens": 0,
                    "cache_creation_input_tokens": 0,
                },
            },
        },
    ]
    log.write_text("\n".join(json.dumps(l) for l in lines) + "\n")
    return tmp_path, sess


def test_claude_adapter_finds_session_records(claude_logs):
    home, sess = claude_logs
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    adapter = ClaudeCodeAdapter(home_dir=home)
    records = adapter.records_for_session(sess)
    assert len(records) == 2  # only assistant messages
    r = records[0]
    assert r.session_id == sess
    assert r.agent == "claude-code"
    assert r.model.startswith("claude-sonnet-4-6")
    assert r.tokens_in == 100
    assert r.tokens_out == 200
    assert r.cache_read == 1000
    assert r.cache_create == 500


def test_claude_adapter_equivalent_cost(claude_logs):
    home, sess = claude_logs
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    adapter = ClaudeCodeAdapter(home_dir=home)
    records = adapter.records_for_session(sess)
    total = sum(r.equivalent_api_cost_usd for r in records)
    # 150 in + 250 out + 1000 cache_read + 500 cache_create at sonnet rates
    # = 150*3/1M + 250*15/1M + 1000*0.30/1M + 500*3.75/1M
    expected = 0.000450 + 0.003750 + 0.000300 + 0.001875
    assert abs(total - expected) < 1e-6


def test_claude_adapter_unknown_session_returns_empty(claude_logs):
    home, _ = claude_logs
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    adapter = ClaudeCodeAdapter(home_dir=home)
    assert adapter.records_for_session("nonexistent") == []


def test_claude_adapter_billed_is_zero_for_max_plan(claude_logs):
    """Claude Max users see equivalent cost; billed is 0 (subsumed by plan)."""
    home, sess = claude_logs
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    adapter = ClaudeCodeAdapter(home_dir=home)
    records = adapter.records_for_session(sess)
    for r in records:
        assert r.billed_usd is None  # unknown without proxy / billing source


def test_cost_for_session_helper(claude_logs):
    home, sess = claude_logs
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    adapter = ClaudeCodeAdapter(home_dir=home)
    cost = adapter.cost_for_session(sess)
    assert cost > 0


def test_from_checkpoints_injects_cost(claude_logs, monkeypatch):
    """from_checkpoints should annotate prompts with cost_usd from adapters."""
    home, sess = claude_logs
    monkeypatch.setenv("HOME", str(home))

    # Force ClaudeCodeAdapter to read from our tmp home
    import claudedashboard.gitai.usage_adapters as ua
    from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
    from claudedashboard.gitai.usage_adapters.codex import CodexAdapter
    monkeypatch.setattr(ua, "all_adapters",
                        lambda: [ClaudeCodeAdapter(home_dir=home), CodexAdapter(home_dir=home)])

    from claudedashboard.gitai.models import (
        Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, LineAttribution,
    )
    from claudedashboard.gitai.session import generate_session_hash
    from claudedashboard.gitai.authorship_log import from_checkpoints

    sh = generate_session_hash("claude-code", sess)
    cp = Checkpoint(
        kind=CheckpointKind.AI_AGENT,
        author="test@test",
        agent_id=AgentId(tool="claude-code", id=sess, model="claude-sonnet-4-6"),
        entries=[WorkingLogEntry(
            file="src/foo.py",
            blob_sha="x"*40,
            line_attributions=[LineAttribution(1, 5, sh)],
        )],
        timestamp_ms=0,
    )

    log = from_checkpoints([cp], "abc123", "test@test")
    assert sh in log.prompts
    pr = log.prompts[sh]
    assert pr.custom_attributes is not None
    assert "cost_usd" in pr.custom_attributes
    assert float(pr.custom_attributes["cost_usd"]) > 0
