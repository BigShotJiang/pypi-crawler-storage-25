"""TDD for team dashboard — web UI showing aggregated proxy data."""
import json
import pytest


@pytest.fixture
def sample_events(tmp_path):
    """Write sample events to a JSONL file."""
    events = [
        {"provider": "anthropic", "model": "claude-sonnet-4-6", "tokens_in": 1500, "tokens_out": 800,
         "cache_read": 0, "cache_create": 0, "cost": 0.057,
         "tool": "cursor", "repo": "github.com/co/app", "branch": "feature/JIRA-1",
         "git_user": "xavi@co.com", "timestamp": 1712345600.0},
        {"provider": "anthropic", "model": "claude-opus-4-6", "tokens_in": 500, "tokens_out": 200,
         "cache_read": 0, "cache_create": 0, "cost": 0.022,
         "tool": "claude", "repo": "github.com/co/app", "branch": "feature/JIRA-1",
         "git_user": "xavi@co.com", "timestamp": 1712345700.0},
        {"provider": "openai", "model": "gpt-4o", "tokens_in": 2000, "tokens_out": 1000,
         "cache_read": 0, "cache_create": 0, "cost": 0.015,
         "tool": "aider", "repo": "github.com/co/backend", "branch": "fix/BUG-99",
         "git_user": "ana@co.com", "timestamp": 1712345800.0},
        {"provider": "anthropic", "model": "claude-sonnet-4-6", "tokens_in": 3000, "tokens_out": 1500,
         "cache_read": 100, "cache_create": 0, "cost": 0.031,
         "tool": "cursor", "repo": "github.com/co/app", "branch": "feature/JIRA-2",
         "git_user": "ana@co.com", "timestamp": 1712345900.0},
    ]
    path = tmp_path / "events.jsonl"
    with open(path, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")
    return str(path)


@pytest.fixture
def client(sample_events):
    pytest.importorskip("flask")
    from claudedashboard.proxy.team_dashboard import create_app

    app = create_app(events_path=sample_events)
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


class TestTeamDashboardAPI:

    def test_health(self, client):
        r = client.get("/api/health")
        assert r.status_code == 200

    def test_summary(self, client):
        r = client.get("/api/summary")
        data = r.get_json()
        assert data["total_events"] == 4
        assert data["total_cost"] > 0
        assert len(data["providers"]) >= 2

    def test_by_repo(self, client):
        r = client.get("/api/repos")
        data = r.get_json()
        assert "github.com/co/app" in data
        assert data["github.com/co/app"]["cost"] > 0
        assert data["github.com/co/app"]["events"] == 3

    def test_by_developer(self, client):
        r = client.get("/api/developers")
        data = r.get_json()
        assert "xavi@co.com" in data
        assert "ana@co.com" in data

    def test_by_branch(self, client):
        r = client.get("/api/branches")
        data = r.get_json()
        assert "feature/JIRA-1" in data

    def test_by_model(self, client):
        r = client.get("/api/models")
        data = r.get_json()
        assert "claude-sonnet-4-6" in data
        assert data["claude-sonnet-4-6"]["count"] == 2

    def test_by_tool(self, client):
        r = client.get("/api/tools")
        data = r.get_json()
        assert "cursor" in data
        assert "aider" in data

    def test_html_dashboard_loads(self, client):
        r = client.get("/")
        assert r.status_code == 200
        assert b"Team Dashboard" in r.data

    def test_events_feed(self, client):
        r = client.get("/api/events?limit=2")
        data = r.get_json()
        assert len(data) == 2
