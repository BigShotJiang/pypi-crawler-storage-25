"""TDD for cost spike alert emission from handle_post_commit."""
import json, subprocess
import pytest

from claudedashboard.gitai.models import NormalizedHookInput, HookEvent


# ── Fixtures / helpers ───────────────────────────────────────────────

@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _make_hook(repo, event, tool_use_id, tool_name, file_rel, session="s1"):
    return NormalizedHookInput(
        event=event, agent="claude-code", session_id=session,
        tool_name=tool_name,
        tool_input={"file_path": str(repo / file_rel)},
        tool_use_id=tool_use_id, cwd=str(repo), model="claude-sonnet-4-6",
    )


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


class _FakePrompt:
    def __init__(self, cost_usd):
        self.custom_attributes = {"cost_usd": f"{cost_usd:.6f}"}


class _FakeLog:
    def __init__(self, prompts):
        self.prompts = prompts


class _Recorder:
    def __init__(self, raise_exc=None):
        self.calls = []
        self.raise_exc = raise_exc

    def __call__(self, commit_sha, repo_path, prompt_records, **kwargs):
        self.calls.append({
            "commit_sha": commit_sha,
            "repo_path": repo_path,
            "prompts": list(prompt_records),
            "kwargs": kwargs,
        })
        if self.raise_exc is not None:
            raise self.raise_exc


# ── Direct _maybe_emit_cost_alert unit tests ────────────────────────

class TestMaybeEmitCostAlert:

    def test_maybe_emit_cost_alert_with_no_prompts_does_nothing(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        rec = _Recorder()
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        log = _FakeLog(prompts={})
        engine._maybe_emit_cost_alert("abc", log)
        assert rec.calls == []

    def test_maybe_emit_cost_alert_calls_check_and_alert_with_prompts(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        rec = _Recorder()
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        log = _FakeLog(prompts={
            "sha1": _FakePrompt(10.0),
            "sha2": _FakePrompt(20.0),
        })
        engine._maybe_emit_cost_alert("abc", log)
        assert len(rec.calls) == 1
        call = rec.calls[0]
        assert call["commit_sha"] == "abc"
        assert call["repo_path"] == str(engine.repo_root)
        assert len(call["prompts"]) == 2

    def test_maybe_emit_cost_alert_swallows_check_and_alert_exception(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        rec = _Recorder(raise_exc=ValueError("boom"))
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        log = _FakeLog(prompts={"sha1": _FakePrompt(99.0)})
        # Must not raise
        engine._maybe_emit_cost_alert("abc", log)
        assert len(rec.calls) == 1

    def test_maybe_emit_cost_alert_handles_log_with_none_prompts(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        rec = _Recorder()
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        log = _FakeLog(prompts=None)
        engine._maybe_emit_cost_alert("abc", log)
        assert rec.calls == []


# ── Integration via handle_post_commit ─────────────────────────────

class TestHandlePostCommitCostAlert:

    def test_handle_post_commit_invokes_cost_alert_when_attestations_exist(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        # AI edit
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("line1\nnew_line2\nline3\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI edit"],
                       check=True, capture_output=True)
        rec = _Recorder()
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        engine.handle_post_commit()
        assert len(rec.calls) == 1
        assert rec.calls[0]["commit_sha"] == _get_head(git_repo)

    def test_handle_post_commit_does_not_invoke_cost_alert_when_no_ai_checkpoints(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "src" / "foo.py").write_text("human edit\n")
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "human"],
                       check=True, capture_output=True)
        rec = _Recorder()
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        engine.handle_post_commit()
        assert rec.calls == []

    def test_handle_post_commit_still_writes_note_when_cost_alert_fails(self, git_repo, monkeypatch):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        from claudedashboard.gitai import cost_alerts
        from claudedashboard.gitai.git_notes import notes_read
        engine = CheckpointEngine(str(git_repo))
        hook_pre = _make_hook(git_repo, HookEvent.PRE_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_pre_tool_use(hook_pre)
        (git_repo / "src" / "foo.py").write_text("line1\nnew_line2\nline3\n")
        hook_post = _make_hook(git_repo, HookEvent.POST_TOOL_USE, "t1", "Edit", "src/foo.py")
        engine.handle_post_tool_use(hook_post)
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI edit"],
                       check=True, capture_output=True)
        rec = _Recorder(raise_exc=RuntimeError("notifier down"))
        monkeypatch.setattr(cost_alerts, "check_and_alert", rec)
        # Must not raise and must still write the note
        engine.handle_post_commit()
        sha = _get_head(git_repo)
        assert notes_read(str(git_repo), sha) is not None
