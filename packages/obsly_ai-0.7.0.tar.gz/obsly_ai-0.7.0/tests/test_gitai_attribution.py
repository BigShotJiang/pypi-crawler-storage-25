"""TDD for attribution engine — red to green."""
import time
import pytest

INITIAL_AUTHOR = "__initial__"


# ── Basic operations ─────────────────────────────────────────────────

class TestInsert:

    def test_insert_at_end(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        old = "line1\nline2\n"
        new = "line1\nline2\nline3\nline4\n"
        prev = [LineAttribution(1, 2, INITIAL_AUTHOR, None)]
        result = compute_attributions(old, new, "ai_hash_1234abcd", prev)
        assert result[0] == LineAttribution(1, 2, INITIAL_AUTHOR, None)
        assert result[1] == LineAttribution(3, 4, "ai_hash_1234abcd", None)

    def test_insert_in_middle(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        old = "line1\nline3\n"
        new = "line1\nline2\nline3\n"
        prev = [LineAttribution(1, 2, INITIAL_AUTHOR, None)]
        result = compute_attributions(old, new, "ai_hash_1234abcd", prev)
        assert result[0] == LineAttribution(1, 1, INITIAL_AUTHOR, None)
        assert result[1] == LineAttribution(2, 2, "ai_hash_1234abcd", None)
        assert result[2] == LineAttribution(3, 3, INITIAL_AUTHOR, None)


class TestReplace:

    def test_replace_lines(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        old = "old_line1\nold_line2\n"
        new = "new_line1\nnew_line2\nnew_line3\n"
        prev = [LineAttribution(1, 2, INITIAL_AUTHOR, None)]
        result = compute_attributions(old, new, "ai_hash_1234abcd", prev)
        assert len(result) == 1
        assert result[0].author_id == "ai_hash_1234abcd"
        assert result[0].overrode == INITIAL_AUTHOR
        assert result[0].start_line == 1
        assert result[0].end_line == 3


class TestDelete:

    def test_delete_lines(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        old = "line1\nline2\nline3\n"
        new = "line1\nline3\n"
        prev = [LineAttribution(1, 3, INITIAL_AUTHOR, None)]
        result = compute_attributions(old, new, "ai_hash_1234abcd", prev)
        # Both remaining lines are same author + consecutive → merged
        assert result == [LineAttribution(1, 2, INITIAL_AUTHOR, None)]


class TestNoChange:

    def test_no_changes(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        content = "line1\nline2\n"
        prev = [LineAttribution(1, 2, INITIAL_AUTHOR, None)]
        result = compute_attributions(content, content, "ai_hash_1234abcd", prev)
        assert result == prev


# ── New file / empty file ────────────────────────────────────────────

class TestNewFile:

    def test_new_file_all_ai(self):
        from claudedashboard.gitai.attribution import attributions_for_new_file
        from claudedashboard.gitai.models import LineAttribution
        result = attributions_for_new_file("line1\nline2\nline3\n", "ai_hash_1234abcd")
        assert result == [LineAttribution(1, 3, "ai_hash_1234abcd", None)]

    def test_empty_file(self):
        from claudedashboard.gitai.attribution import attributions_for_new_file, initial_attributions
        assert attributions_for_new_file("", "ai") == []
        assert initial_attributions("") == []

    def test_initial_attributions(self):
        from claudedashboard.gitai.attribution import initial_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        result = initial_attributions("line1\nline2\nline3\n")
        assert result == [LineAttribution(1, 3, INITIAL_AUTHOR, None)]


# ── Multiple agents ──────────────────────────────────────────────────

class TestMultiAgent:

    def test_sequential_edits_two_agents(self):
        from claudedashboard.gitai.attribution import compute_attributions, initial_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        original = "line1\nline2\nline3\n"
        prev = initial_attributions(original)

        # Agent A inserts after line1
        after_a = "line1\nagent_a_line\nline2\nline3\n"
        attrs_a = compute_attributions(original, after_a, "agent_a_hash1234", prev)

        # Agent B replaces line3 (now line4)
        after_b = "line1\nagent_a_line\nline2\nnew_line3\n"
        attrs_b = compute_attributions(after_a, after_b, "agent_b_hash5678", attrs_a)

        authors = [a.author_id for a in attrs_b]
        assert INITIAL_AUTHOR in authors
        assert "agent_a_hash1234" in authors
        assert "agent_b_hash5678" in authors


# ── Merge adjacent ───────────────────────────────────────────────────

class TestMergeAdjacent:

    def test_merge_same_author(self):
        from claudedashboard.gitai.attribution import merge_adjacent
        from claudedashboard.gitai.models import LineAttribution
        attrs = [
            LineAttribution(1, 3, "a", None),
            LineAttribution(4, 6, "a", None),
        ]
        assert merge_adjacent(attrs) == [LineAttribution(1, 6, "a", None)]

    def test_no_merge_different_authors(self):
        from claudedashboard.gitai.attribution import merge_adjacent
        from claudedashboard.gitai.models import LineAttribution
        attrs = [
            LineAttribution(1, 3, "a", None),
            LineAttribution(4, 6, "b", None),
        ]
        assert merge_adjacent(attrs) == attrs

    def test_no_merge_different_overrode(self):
        from claudedashboard.gitai.attribution import merge_adjacent
        from claudedashboard.gitai.models import LineAttribution
        attrs = [
            LineAttribution(1, 3, "a", "old1"),
            LineAttribution(4, 6, "a", "old2"),
        ]
        assert merge_adjacent(attrs) == attrs


# ── Counting ─────────────────────────────────────────────────────────

class TestCounting:

    def test_count_ai_and_human(self):
        from claudedashboard.gitai.attribution import count_ai_lines, count_human_lines, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        attrs = [
            LineAttribution(1, 5, INITIAL_AUTHOR, None),
            LineAttribution(6, 10, "ai_hash", None),
            LineAttribution(11, 15, "ai_hash2", None),
        ]
        assert count_ai_lines(attrs) == 10
        assert count_human_lines(attrs) == 5


# ── Edge cases ───────────────────────────────────────────────────────

class TestEdgeCases:

    def test_single_line_file(self):
        from claudedashboard.gitai.attribution import compute_attributions, INITIAL_AUTHOR
        from claudedashboard.gitai.models import LineAttribution
        old = "x\n"
        new = "y\n"
        prev = [LineAttribution(1, 1, INITIAL_AUTHOR, None)]
        result = compute_attributions(old, new, "ai", prev)
        assert result == [LineAttribution(1, 1, "ai", INITIAL_AUTHOR)]

    def test_file_no_trailing_newline(self):
        from claudedashboard.gitai.attribution import compute_attributions, initial_attributions
        old = "line1\nline2"
        new = "line1\nline2\nline3"
        prev = initial_attributions(old)
        result = compute_attributions(old, new, "ai", prev)
        assert result[-1].author_id == "ai"

    def test_large_file_performance(self):
        from claudedashboard.gitai.attribution import compute_attributions, initial_attributions
        old = "\n".join(f"line{i}" for i in range(1000)) + "\n"
        new_lines = [f"line{i}" for i in range(500)]
        new_lines += [f"new{i}" for i in range(100)]
        new_lines += [f"line{i}" for i in range(500, 1000)]
        new = "\n".join(new_lines) + "\n"
        prev = initial_attributions(old)
        start = time.monotonic()
        result = compute_attributions(old, new, "ai", prev)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert elapsed_ms < 200, f"Took {elapsed_ms:.1f}ms"
        from claudedashboard.gitai.attribution import count_ai_lines
        assert count_ai_lines(result) == 100
