"""End-to-end integration tests — full pipeline validation."""
import json, subprocess
import pytest
from claudedashboard.gitai.models import NormalizedHookInput, HookEvent
from claudedashboard.gitai.checkpoint import CheckpointEngine
from claudedashboard.gitai.git_notes import notes_read, get_head_sha
from claudedashboard.gitai.authorship_log import deserialize
from claudedashboard.gitai.blame import blame
from claudedashboard.gitai.stats import stats_for_commit


@pytest.fixture
def full_repo(tmp_path):
    repo = tmp_path / "project"
    repo.mkdir()
    subprocess.run(["git", "init", str(repo)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "config", "user.email", "dev@company.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "config", "user.name", "Dev"],
                   check=True, capture_output=True)
    (repo / "src").mkdir()
    (repo / "src" / "main.py").write_text("import os\nimport sys\n\ndef main():\n    print('hello')\n")
    (repo / "src" / "utils.py").write_text("def add(a, b):\n    return a + b\n\ndef multiply(a, b):\n    return a * b\n")
    subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "commit", "-m", "initial"],
                   check=True, capture_output=True)
    return repo


def _head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _hook(repo, event, agent, session, tool_name, file_rel, tool_use_id, model="sonnet"):
    return NormalizedHookInput(
        event=event, agent=agent, session_id=session, tool_name=tool_name,
        tool_input={"file_path": str(repo / file_rel)},
        tool_use_id=tool_use_id, cwd=str(repo), model=model,
    )


def _simulate_edit(engine, repo, agent, session, model, file_rel, tid, new_content):
    pre = _hook(repo, HookEvent.PRE_TOOL_USE, agent, session, "Edit", file_rel, tid, model)
    engine.handle_pre_tool_use(pre)
    (repo / file_rel).write_text(new_content)
    post = _hook(repo, HookEvent.POST_TOOL_USE, agent, session, "Edit", file_rel, tid, model)
    engine.handle_post_tool_use(post)


def _commit(repo, msg):
    subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "commit", "-m", msg], check=True, capture_output=True)


# ── Test 1: Single agent full flow ──────────────────────────────────

def test_e2e_claude_single_edit(full_repo):
    engine = CheckpointEngine(str(full_repo))
    _simulate_edit(engine, full_repo, "claude-code", "s1", "claude-sonnet-4-6",
                   "src/utils.py", "t1",
                   "def add(a, b):\n    return a + b\n\ndef subtract(a, b):\n    return a - b\n\ndef multiply(a, b):\n    return a * b\n")
    _commit(full_repo, "Add subtract")
    engine.handle_post_commit()

    sha = _head(full_repo)
    note = notes_read(str(full_repo), sha)
    assert note is not None

    log = deserialize(note)
    # Schema bumps to 3.1.0 once total_lines_added is recorded (#11)
    assert log.schema_version in ("authorship/3.0.0", "authorship/3.1.0")
    assert len(log.attestations) > 0
    assert len(log.prompts) > 0
    prompt = list(log.prompts.values())[0]
    assert prompt.agent_id.tool == "claude-code"

    blame_lines = blame(str(full_repo), "src/utils.py")
    ai_lines = [l for l in blame_lines if l.agent != "human"]
    assert len(ai_lines) >= 2

    stats = stats_for_commit(str(full_repo))
    assert stats is not None
    assert stats.ai_lines >= 2
    assert "claude-code" in stats.by_agent


# ── Test 2: Multi-agent ─────────────────────────────────────────────

def test_e2e_multi_agent(full_repo):
    engine = CheckpointEngine(str(full_repo))
    _simulate_edit(engine, full_repo, "claude-code", "s1", "sonnet",
                   "src/utils.py", "t1",
                   "def add(a, b):\n    return a + b\n\ndef new_func():\n    pass\n\ndef multiply(a, b):\n    return a * b\n")
    _simulate_edit(engine, full_repo, "cursor", "s2", "gpt-4o",
                   "src/main.py", "t2",
                   "import os\nimport sys\nimport json\n\ndef main():\n    print('hello')\n")
    _commit(full_repo, "multi-agent")
    engine.handle_post_commit()

    log = deserialize(notes_read(str(full_repo), _head(full_repo)))
    files = {a.file_path for a in log.attestations}
    assert "src/utils.py" in files
    assert "src/main.py" in files
    agents = {p.agent_id.tool for p in log.prompts.values()}
    assert "claude-code" in agents
    assert "cursor" in agents


# ── Test 3: New file (all AI) ───────────────────────────────────────

def test_e2e_write_new_file(full_repo):
    engine = CheckpointEngine(str(full_repo))
    pre = _hook(full_repo, HookEvent.PRE_TOOL_USE, "claude-code", "s1", "Write", "src/new.py", "t1")
    engine.handle_pre_tool_use(pre)
    (full_repo / "src" / "new.py").write_text("class New:\n    pass\n")
    post = _hook(full_repo, HookEvent.POST_TOOL_USE, "claude-code", "s1", "Write", "src/new.py", "t1")
    engine.handle_post_tool_use(post)
    _commit(full_repo, "new file")
    engine.handle_post_commit()

    lines = blame(str(full_repo), "src/new.py")
    assert all(l.agent == "claude-code" for l in lines)


# ── Test 4: Human only → no note ────────────────────────────────────

def test_e2e_human_only(full_repo):
    engine = CheckpointEngine(str(full_repo))
    (full_repo / "src" / "main.py").write_text("# human edit\n")
    _commit(full_repo, "human edit")
    engine.handle_post_commit()
    assert notes_read(str(full_repo), _head(full_repo)) is None


# ── Test 5: v3.0.0 format compliance ────────────────────────────────

def test_e2e_format_compliance(full_repo):
    engine = CheckpointEngine(str(full_repo))
    _simulate_edit(engine, full_repo, "claude-code", "s1", "sonnet",
                   "src/utils.py", "t1",
                   "def add(a, b):\n    return a + b\n\ndef ai_func():\n    pass\n\ndef multiply(a, b):\n    return a * b\n")
    _commit(full_repo, "AI edit")
    engine.handle_post_commit()

    note = notes_read(str(full_repo), _head(full_repo))
    parts = note.split("\n---\n")
    assert len(parts) == 2

    # Attestation format
    attest = parts[0]
    for line in attest.split("\n"):
        if line.startswith("  "):
            h, ranges = line.strip().split(" ", 1)
            assert len(h) == 16
            assert all(c in "0123456789abcdef" for c in h)

    # JSON metadata — schema may be 3.0.0 or 3.1.0 (#11 added total_lines_added)
    meta = json.loads(parts[1])
    assert meta["schema_version"] in ("authorship/3.0.0", "authorship/3.1.0")
    for h, p in meta["prompts"].items():
        assert len(h) == 16
        assert "agent_id" in p
        assert "tool" in p["agent_id"]
