"""TDD for durability analysis — red to green."""
import subprocess
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId, DurabilityRecord,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\nline4\nline5\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _add_note(repo, log):
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add
    sha = _get_head(repo)
    notes_add(str(repo), sha, serialize(log))


@pytest.fixture
def repo_with_history(git_repo):
    """Repo with:
    - Commit 1 (init): lines 1-5 human
    - Commit 2: AI adds lines 3-4, note attached
    - Commit 3: human modifies line 3, no note
    """
    from claudedashboard.gitai.authorship_log import serialize
    from claudedashboard.gitai.git_notes import notes_add

    # Commit 2: AI writes lines 3-4
    (git_repo / "src" / "foo.py").write_text("line1\nline2\nai_line3\nai_line4\nline5\n")
    subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "AI edit"],
                   check=True, capture_output=True)
    sha2 = _get_head(git_repo)
    log = AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(3, 4)]),
        ])],
        base_commit_sha=sha2,
        prompts={"aaa1234567890123": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "sonnet"), total_additions=2,
        )},
    )
    notes_add(str(git_repo), sha2, serialize(log))

    # Commit 3: human modifies line 3
    (git_repo / "src" / "foo.py").write_text("line1\nline2\nhuman_modified_3\nai_line4\nline5\n")
    subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "human edit"],
                   check=True, capture_output=True)
    return git_repo


class TestDurability:

    def test_surviving_lines(self, repo_with_history):
        from claudedashboard.gitai.durability import analyze_durability
        records = analyze_durability(str(repo_with_history))
        assert len(records) > 0
        r = records[0]
        assert r.agent == "claude-code"
        assert r.lines_authored == 2
        # line 4 survives unchanged, line 3 was modified
        assert r.lines_surviving >= 1
        assert r.lines_modified >= 0

    def test_survival_rate(self, repo_with_history):
        from claudedashboard.gitai.durability import analyze_durability
        records = analyze_durability(str(repo_with_history))
        for r in records:
            assert 0 <= r.survival_rate <= 1.0

    def test_by_agent(self, repo_with_history):
        from claudedashboard.gitai.durability import analyze_durability, durability_by_agent
        records = analyze_durability(str(repo_with_history))
        by_agent = durability_by_agent(records)
        assert "claude-code" in by_agent
        assert "total_authored" in by_agent["claude-code"]
        assert by_agent["claude-code"]["total_authored"] == 2

    def test_empty_repo(self, git_repo):
        from claudedashboard.gitai.durability import analyze_durability
        records = analyze_durability(str(git_repo))
        assert records == []

    def test_format_terminal(self):
        from claudedashboard.gitai.durability import format_durability_terminal
        by_agent = {"claude-code": {"survival_rate": 0.89, "total_authored": 100, "surviving": 89, "modified": 7, "deleted": 4}}
        output = format_durability_terminal(by_agent)
        assert "89%" in output
        assert "claude-code" in output
