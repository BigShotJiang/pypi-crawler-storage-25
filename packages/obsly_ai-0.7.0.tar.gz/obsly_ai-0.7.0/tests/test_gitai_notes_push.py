"""Tests for the post-commit hook also pushing refs/notes/ai to origin."""

import subprocess
import pytest
from claudedashboard.gitai.models import (
    NormalizedHookInput, HookEvent, AgentId,
)
from claudedashboard.gitai.checkpoint import CheckpointEngine


def _git(args, cwd, **kw):
    return subprocess.run(["git", "-C", str(cwd)] + args,
                          capture_output=True, text=True, check=True, **kw)


@pytest.fixture
def repo_with_origin(tmp_path):
    """A working repo with a bare 'origin' remote so we can verify push."""
    bare = tmp_path / "origin.git"
    subprocess.run(["git", "init", "--bare", str(bare)], check=True, capture_output=True)

    work = tmp_path / "work"
    work.mkdir()
    subprocess.run(["git", "init", str(work)], check=True, capture_output=True)
    _git(["config", "user.email", "dev@example.com"], work)
    _git(["config", "user.name", "Dev"], work)
    _git(["remote", "add", "origin", str(bare)], work)

    (work / "foo.py").write_text("print('hi')\n")
    _git(["add", "."], work)
    _git(["commit", "-m", "init"], work)
    _git(["push", "-u", "origin", "HEAD"], work)
    return work, bare


def _make_ai_commit(repo, file_path, new_content):
    """Simulate an AI agent edit + commit so the working_log has data."""
    engine = CheckpointEngine(str(repo))
    abs_path = str(repo / file_path)
    pre = NormalizedHookInput(
        event=HookEvent.PRE_TOOL_USE, agent="claude-code",
        session_id="s1", tool_name="Edit",
        tool_input={"file_path": abs_path}, tool_use_id="tool-1",
        cwd=str(repo), model="claude-sonnet-4-6",
    )
    engine.handle_pre_tool_use(pre)

    (repo / file_path).write_text(new_content)

    post = NormalizedHookInput(
        event=HookEvent.POST_TOOL_USE, agent="claude-code",
        session_id="s1", tool_name="Edit",
        tool_input={"file_path": abs_path}, tool_use_id="tool-1",
        cwd=str(repo), model="claude-sonnet-4-6",
    )
    engine.handle_post_tool_use(post)

    _git(["add", "."], repo)
    _git(["commit", "-m", "ai change"], repo)
    engine.handle_post_commit()


def test_post_commit_pushes_notes_ref_to_origin(repo_with_origin, monkeypatch):
    work, bare = repo_with_origin
    # Stop the http POST from doing anything (no server)
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(work / "no-config"))

    _make_ai_commit(work, "foo.py", "print('AI wrote this')\nprint('and this')\n")

    # Note exists locally
    local_note = subprocess.run(
        ["git", "-C", str(work), "notes", "--ref=ai", "list"],
        capture_output=True, text=True,
    )
    assert local_note.stdout.strip(), "expected a local note"

    # Note also exists on the bare origin (was pushed)
    remote_note = subprocess.run(
        ["git", "-C", str(bare), "for-each-ref", "refs/notes/ai"],
        capture_output=True, text=True,
    )
    assert remote_note.stdout.strip(), \
        f"expected refs/notes/ai on origin, got: {remote_note.stdout!r}"


def test_post_commit_push_failure_does_not_raise(repo_with_origin, monkeypatch):
    work, bare = repo_with_origin
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(work / "no-config"))
    # Break the remote so push fails
    subprocess.run(["git", "-C", str(work), "remote", "set-url", "origin",
                    "/tmp/does-not-exist.git"], check=True, capture_output=True)

    # Should not raise
    _make_ai_commit(work, "foo.py", "print('still works')\n")
