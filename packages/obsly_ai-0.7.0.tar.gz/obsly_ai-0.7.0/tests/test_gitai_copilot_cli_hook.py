"""TDD for the Copilot CLI hook installer."""
import json
import pytest


BINARY = "/usr/local/bin/obsly-ai"


@pytest.fixture
def installer(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    return CopilotCliInstaller(config_dir=tmp_path / ".copilot")


# ── Metadata ─────────────────────────────────────────────────────────

def test_agent_id_is_copilot_cli(installer):
    assert installer.agent_id() == "copilot-cli"


def test_name_is_human_readable(installer):
    name = installer.name()
    assert isinstance(name, str)
    assert "Copilot" in name


# ── check() ──────────────────────────────────────────────────────────

def test_check_when_not_detected(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    inst = CopilotCliInstaller(config_dir=tmp_path / "absent")
    assert inst.check() == (False, False, False)


def test_check_when_detected_not_installed(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    config_dir = tmp_path / ".copilot"
    config_dir.mkdir()
    inst = CopilotCliInstaller(config_dir=config_dir)
    assert inst.check() == (True, False, False)


def test_check_when_installed(installer, tmp_path):
    installer.install(BINARY)
    detected, installed, up_to_date = installer.check()
    assert detected is True
    assert installed is True
    assert up_to_date is True


# ── install() ────────────────────────────────────────────────────────

def test_install_creates_hooks_file(installer, tmp_path):
    diff = installer.install(BINARY)
    assert diff is not None
    hooks_path = tmp_path / ".copilot" / "hooks.json"
    assert hooks_path.exists()
    data = json.loads(hooks_path.read_text())
    assert data.get("version") == 1
    assert "preToolUse" in data["hooks"]
    assert "postToolUse" in data["hooks"]
    assert "sessionEnd" in data["hooks"]
    for event in ("preToolUse", "postToolUse", "sessionEnd"):
        entries = data["hooks"][event]
        assert any("ai-checkpoint copilot-cli" in e.get("bash", "") for e in entries)
        assert all(e.get("type") == "command" for e in entries)


def test_install_is_idempotent(installer):
    installer.install(BINARY)
    diff = installer.install(BINARY)
    assert diff is None


def test_install_preserves_existing_config(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    config_dir = tmp_path / ".copilot"
    config_dir.mkdir()
    hooks_path = config_dir / "hooks.json"
    hooks_path.write_text(json.dumps({
        "version": 1,
        "hooks": {
            "preToolUse": [
                {"type": "command", "bash": "my-linter", "timeoutSec": 10}
            ],
            "sessionStart": [
                {"type": "command", "bash": "echo hi"}
            ],
        },
    }))
    inst = CopilotCliInstaller(config_dir=config_dir)
    inst.install(BINARY)
    data = json.loads(hooks_path.read_text())
    # Original entries preserved
    pre = data["hooks"]["preToolUse"]
    assert any(e.get("bash") == "my-linter" for e in pre)
    assert any("ai-checkpoint copilot-cli" in e.get("bash", "") for e in pre)
    assert data["hooks"]["sessionStart"][0]["bash"] == "echo hi"


def test_install_dry_run_does_not_write(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    config_dir = tmp_path / ".copilot"
    config_dir.mkdir()
    inst = CopilotCliInstaller(config_dir=config_dir)
    diff = inst.install(BINARY, dry_run=True)
    assert diff is not None
    assert not (config_dir / "hooks.json").exists()


# ── uninstall() ──────────────────────────────────────────────────────

def test_uninstall_removes_only_our_entries(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    config_dir = tmp_path / ".copilot"
    config_dir.mkdir()
    hooks_path = config_dir / "hooks.json"
    hooks_path.write_text(json.dumps({
        "version": 1,
        "hooks": {
            "preToolUse": [
                {"type": "command", "bash": "my-linter"}
            ]
        },
    }))
    inst = CopilotCliInstaller(config_dir=config_dir)
    inst.install(BINARY)
    inst.uninstall()
    data = json.loads(hooks_path.read_text())
    pre = data["hooks"].get("preToolUse", [])
    assert any(e.get("bash") == "my-linter" for e in pre)
    assert not any("ai-checkpoint copilot-cli" in e.get("bash", "") for e in pre)
    # other files in the dir untouched
    (config_dir / "unrelated.txt").write_text("keep me")
    assert (config_dir / "unrelated.txt").exists()


def test_uninstall_is_idempotent(installer):
    installer.install(BINARY)
    installer.uninstall()
    # second call must not raise and must be a no-op
    assert installer.uninstall() is None


def test_uninstall_when_not_installed_returns_none(tmp_path):
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    inst = CopilotCliInstaller(config_dir=tmp_path / ".copilot")
    assert inst.uninstall() is None


# ── CLI integration ──────────────────────────────────────────────────

def test_cli_install_accepts_copilot_cli_agent():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["install", "--agent", "copilot-cli"])
    assert args.agent == "copilot-cli"


def test_cli_uninstall_accepts_copilot_cli_agent():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["uninstall", "--agent", "copilot-cli"])
    assert args.agent == "copilot-cli"


def test_installer_registered_in_cli_install_dispatch(monkeypatch, tmp_path, capsys):
    """The CLI _ai_install path must know about copilot-cli."""
    from claudedashboard import cli
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller
    # Redirect HOME so real installers don't mutate user state
    monkeypatch.setenv("HOME", str(tmp_path))
    (tmp_path / ".copilot").mkdir()

    class Args:
        agent = "copilot-cli"
        dry_run = True
    cli._ai_install(Args())
    out = capsys.readouterr().out
    assert "Copilot" in out
    # Sanity: class is importable and has expected shape
    assert CopilotCliInstaller().agent_id() == "copilot-cli"
