def test_cli_run_with_proxy_captures_command():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["run-with-proxy", "claude"])
    assert args.command == "run-with-proxy"
    assert args.cmd == ["claude"]


def test_cli_run_with_proxy_captures_command_with_args():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["run-with-proxy", "claude", "--foo", "bar"])
    assert args.cmd == ["claude", "--foo", "bar"]


def test_cli_run_with_proxy_with_double_dash_separator():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["run-with-proxy", "--", "cursor", "--new-window"])
    assert args.cmd == ["--", "cursor", "--new-window"]


def test_cli_run_with_proxy_empty_command():
    from claudedashboard.cli import _build_parser
    parser = _build_parser()
    args = parser.parse_args(["run-with-proxy"])
    assert args.cmd == []
