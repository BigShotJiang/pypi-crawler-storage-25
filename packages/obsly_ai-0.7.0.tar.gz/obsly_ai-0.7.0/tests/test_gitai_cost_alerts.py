"""Tests for claudedashboard.gitai.cost_alerts."""

import json
import os
from pathlib import Path

import pytest

from claudedashboard.gitai import cost_alerts
from claudedashboard.gitai.cost_alerts import (
    Alert,
    DEFAULT_THRESHOLD_USD,
    alerts_path,
    check_and_alert,
    get_threshold,
    load_alerts,
    mark_alert_read,
    _osascript_notify,
)


class _FakeRecord:
    def __init__(self, cost_usd):
        if cost_usd is None:
            self.custom_attributes = {}
        elif isinstance(cost_usd, str):
            self.custom_attributes = {"cost_usd": cost_usd}
        else:
            self.custom_attributes = {"cost_usd": f"{cost_usd:.6f}"}


@pytest.fixture
def alerts_dir(tmp_path, monkeypatch):
    d = tmp_path / ".obsly-ai"
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(d))
    return d


def _write_config(alerts_dir, cfg):
    alerts_dir.mkdir(parents=True, exist_ok=True)
    (alerts_dir / "config.json").write_text(json.dumps(cfg))


# ── alerts_path ──────────────────────────────────────────────────────

def test_alerts_path_honors_obsly_config_dir(alerts_dir):
    p = alerts_path()
    assert p == alerts_dir / "alerts.jsonl"


def test_alerts_path_default_under_home(monkeypatch):
    monkeypatch.delenv("OBSLY_CONFIG_DIR", raising=False)
    p = alerts_path()
    assert p == Path(os.path.expanduser("~")) / ".obsly-ai" / "alerts.jsonl"


# ── get_threshold ────────────────────────────────────────────────────

def test_get_threshold_returns_default_when_no_config(alerts_dir):
    assert get_threshold() == DEFAULT_THRESHOLD_USD
    assert get_threshold() == 25.0


def test_get_threshold_reads_from_config(alerts_dir):
    _write_config(alerts_dir, {"cost_alert_threshold": 10.0})
    assert get_threshold() == 10.0


def test_get_threshold_handles_corrupted_config(alerts_dir):
    alerts_dir.mkdir(parents=True, exist_ok=True)
    (alerts_dir / "config.json").write_text("not-json{{{")
    assert get_threshold() == DEFAULT_THRESHOLD_USD


# ── check_and_alert ──────────────────────────────────────────────────

def test_check_and_alert_no_spike_returns_none(alerts_dir):
    records = [_FakeRecord(2.0), _FakeRecord(2.0), _FakeRecord(1.0)]
    result = check_and_alert("abc123", "/tmp/repo", records)
    assert result is None
    assert not (alerts_dir / "alerts.jsonl").exists()


def test_check_and_alert_spike_writes_alert(alerts_dir):
    records = [_FakeRecord(10.0), _FakeRecord(10.0), _FakeRecord(10.0)]
    result = check_and_alert("abc123", "/tmp/repo", records, notifier=lambda a: None)
    assert result is not None
    assert isinstance(result, Alert)
    path = alerts_dir / "alerts.jsonl"
    assert path.exists()
    lines = [l for l in path.read_text().splitlines() if l.strip()]
    assert len(lines) == 1
    data = json.loads(lines[0])
    assert data["cost_usd"] == 30.0


def test_check_and_alert_records_commit_and_repo(alerts_dir):
    records = [_FakeRecord(30.0)]
    alert = check_and_alert("deadbeef", "/abs/repo", records, notifier=lambda a: None)
    assert alert.commit_sha == "deadbeef"
    assert alert.repo_path == "/abs/repo"


def test_check_and_alert_records_session_count(alerts_dir):
    records = [_FakeRecord(10.0), _FakeRecord(10.0), _FakeRecord(10.0), _FakeRecord(10.0)]
    alert = check_and_alert("sha", "/r", records, notifier=lambda a: None)
    assert alert.session_count == 4


def test_check_and_alert_uses_injected_threshold_override(alerts_dir):
    records = [_FakeRecord(10.0), _FakeRecord(10.0)]
    # default threshold 25 → no spike
    assert check_and_alert("sha", "/r", records) is None
    # override 10 → spike
    alert = check_and_alert("sha", "/r", records, threshold=10.0, notifier=lambda a: None)
    assert alert is not None


def test_check_and_alert_calls_notifier_with_alert(alerts_dir):
    captured = []
    records = [_FakeRecord(30.0)]
    alert = check_and_alert("sha", "/r", records, notifier=lambda a: captured.append(a))
    assert len(captured) == 1
    assert captured[0] is alert


def test_check_and_alert_does_not_call_notifier_when_no_spike(alerts_dir):
    captured = []
    records = [_FakeRecord(1.0)]
    check_and_alert("sha", "/r", records, notifier=lambda a: captured.append(a))
    assert captured == []


def test_check_and_alert_uses_injected_now(alerts_dir):
    records = [_FakeRecord(30.0)]
    alert = check_and_alert("sha", "/r", records, notifier=lambda a: None, now=lambda: 1234567890.0)
    assert alert.timestamp == 1234567890.0


def test_check_and_alert_swallows_exceptions(alerts_dir):
    def bad_notifier(a):
        raise RuntimeError("boom")
    records = [_FakeRecord(30.0)]
    # Must not raise
    check_and_alert("sha", "/r", records, notifier=bad_notifier)
    # Alert was still written before notifier call
    path = alerts_dir / "alerts.jsonl"
    assert path.exists()
    assert len([l for l in path.read_text().splitlines() if l.strip()]) == 1


def test_check_and_alert_handles_records_without_cost_attr(alerts_dir):
    records = [_FakeRecord(None), _FakeRecord(None)]
    result = check_and_alert("sha", "/r", records, threshold=1.0, notifier=lambda a: None)
    # sum is 0, no spike
    assert result is None


def test_check_and_alert_handles_records_with_garbage_cost(alerts_dir):
    records = [_FakeRecord("not-a-number"), _FakeRecord(30.0)]
    alert = check_and_alert("sha", "/r", records, notifier=lambda a: None)
    assert alert is not None
    assert alert.cost_usd == 30.0


# ── load_alerts ──────────────────────────────────────────────────────

def test_load_alerts_returns_empty_list_when_no_file(alerts_dir):
    assert load_alerts() == []


def test_load_alerts_returns_alerts_newest_first(alerts_dir):
    for ts in (100.0, 200.0, 150.0):
        check_and_alert("sha", "/r", [_FakeRecord(30.0)],
                        notifier=lambda a: None, now=lambda ts=ts: ts)
    result = load_alerts()
    assert [a.timestamp for a in result] == [200.0, 150.0, 100.0]


def test_load_alerts_unread_only_filter(alerts_dir):
    check_and_alert("sha1", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 100.0)
    check_and_alert("sha2", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 200.0)
    mark_alert_read(100.0)
    result = load_alerts(unread_only=True)
    assert len(result) == 1
    assert result[0].timestamp == 200.0


def test_load_alerts_limit(alerts_dir):
    for ts in (100.0, 200.0, 300.0, 400.0, 500.0):
        check_and_alert("sha", "/r", [_FakeRecord(30.0)],
                        notifier=lambda a: None, now=lambda ts=ts: ts)
    result = load_alerts(limit=2)
    assert len(result) == 2
    assert [a.timestamp for a in result] == [500.0, 400.0]


def test_load_alerts_skips_corrupted_lines(alerts_dir):
    check_and_alert("sha", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 100.0)
    # Append garbage
    path = alerts_dir / "alerts.jsonl"
    with open(path, "a") as f:
        f.write("not-json-line\n")
    check_and_alert("sha", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 200.0)
    result = load_alerts()
    assert len(result) == 2


# ── mark_alert_read ──────────────────────────────────────────────────

def test_mark_alert_read_updates_file(alerts_dir):
    check_and_alert("sha1", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 100.0)
    check_and_alert("sha2", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 200.0)
    assert mark_alert_read(100.0) is True
    result = load_alerts()
    by_ts = {a.timestamp: a for a in result}
    assert by_ts[100.0].read is True
    assert by_ts[200.0].read is False


def test_mark_alert_read_returns_false_when_not_found(alerts_dir):
    check_and_alert("sha", "/r", [_FakeRecord(30.0)],
                    notifier=lambda a: None, now=lambda: 100.0)
    original = (alerts_dir / "alerts.jsonl").read_text()
    assert mark_alert_read(999.0) is False
    assert (alerts_dir / "alerts.jsonl").read_text() == original


# ── _osascript_notify ────────────────────────────────────────────────

def test_osascript_notify_builds_correct_command(alerts_dir, monkeypatch):
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["kwargs"] = kwargs
        class R:
            returncode = 0
        return R()

    monkeypatch.setattr(cost_alerts.subprocess, "run", fake_run)
    alert = Alert(
        timestamp=1.0,
        cost_usd=42.50,
        threshold_usd=25.0,
        commit_sha="abc",
        repo_path="/some/repo",
        session_count=2,
    )
    _osascript_notify(alert)
    cmd = captured["cmd"]
    assert cmd[0] == "osascript"
    assert cmd[1] == "-e"
    script = cmd[2]
    assert "display notification" in script
    assert "Obsly AI cost spike" in script
    assert "42.50" in script
    assert "25.00" in script


def test_osascript_notify_swallows_subprocess_errors(monkeypatch):
    def fake_run(cmd, **kwargs):
        raise FileNotFoundError("osascript not found")
    monkeypatch.setattr(cost_alerts.subprocess, "run", fake_run)
    alert = Alert(
        timestamp=1.0,
        cost_usd=30.0,
        threshold_usd=25.0,
        commit_sha="abc",
        repo_path="/r",
        session_count=1,
    )
    # Must not raise
    _osascript_notify(alert)
