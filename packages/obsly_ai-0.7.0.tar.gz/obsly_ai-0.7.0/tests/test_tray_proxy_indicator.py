import json
import pytest
import claudedashboard.tray as tray


def test_proxy_status_label_running():
    assert "[Running]" in tray.proxy_status_label("running")
    assert "stop" in tray.proxy_status_label("running").lower()


def test_proxy_status_label_stopped():
    assert "[Stopped]" in tray.proxy_status_label("stopped")
    assert "start" in tray.proxy_status_label("stopped").lower()


def test_proxy_status_label_not_installed():
    assert "[Not installed]" in tray.proxy_status_label("not_installed")
    assert "install" in tray.proxy_status_label("not_installed").lower()


def test_proxy_status_label_unknown():
    assert "[Unknown]" in tray.proxy_status_label("garbage")
    assert "[Unknown]" in tray.proxy_status_label("")
    assert "[Unknown]" in tray.proxy_status_label(None)


def _write_events(path, events):
    with open(path, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")


def test_compute_last_hour_proxy_stats_no_file(tmp_path):
    result = tray.compute_last_hour_proxy_stats(str(tmp_path / "missing.jsonl"))
    assert result == {"count": 0, "cost_usd": 0.0}


def test_compute_last_hour_proxy_stats_counts_recent(tmp_path):
    events_file = tmp_path / "events.jsonl"
    _write_events(events_file, [
        {"timestamp": 500.0, "cost_usd": 0.10},   # outside last hour from now=5000
        {"timestamp": 1000.0, "cost_usd": 0.20},  # outside last hour from now=5000
        {"timestamp": 4000.0, "cost_usd": 0.30},  # inside last hour from now=5000
    ])
    result = tray.compute_last_hour_proxy_stats(str(events_file), now=5000.0)
    # last hour = (1400, 5000]
    assert result["count"] == 1
    assert abs(result["cost_usd"] - 0.30) < 1e-6


def test_compute_last_hour_proxy_stats_accepts_ts_key(tmp_path):
    events_file = tmp_path / "events.jsonl"
    _write_events(events_file, [
        {"ts": 4500.0, "cost_usd": 0.50},
        {"ts": 4900.0, "cost": 0.25},  # also accept 'cost' key
    ])
    result = tray.compute_last_hour_proxy_stats(str(events_file), now=5000.0)
    assert result["count"] == 2
    assert abs(result["cost_usd"] - 0.75) < 1e-6


def test_compute_last_hour_proxy_stats_skips_garbage_lines(tmp_path):
    events_file = tmp_path / "events.jsonl"
    events_file.write_text(
        '{"timestamp": 4900.0, "cost_usd": 0.10}\n'
        'this is not json\n'
        '{"timestamp": "not-a-number", "cost_usd": 0.20}\n'
        '{"no_timestamp": true, "cost_usd": 0.30}\n'
        '{"timestamp": 4950.0, "cost_usd": 0.20}\n'
    )
    result = tray.compute_last_hour_proxy_stats(str(events_file), now=5000.0)
    assert result["count"] == 2
    assert abs(result["cost_usd"] - 0.30) < 1e-6


def test_compute_last_hour_proxy_stats_handles_missing_cost(tmp_path):
    events_file = tmp_path / "events.jsonl"
    _write_events(events_file, [
        {"timestamp": 4900.0},  # no cost field
    ])
    result = tray.compute_last_hour_proxy_stats(str(events_file), now=5000.0)
    assert result["count"] == 1
    assert result["cost_usd"] == 0.0


def test_format_proxy_stats_line_with_traffic():
    line = tray.format_proxy_stats_line({"count": 12, "cost_usd": 0.34})
    assert "12 events" in line
    assert "$0.34" in line


def test_format_proxy_stats_line_no_traffic():
    assert tray.format_proxy_stats_line({"count": 0, "cost_usd": 0.0}) == "Last 1h: no traffic"


def test_format_proxy_stats_line_zero_cost_with_events():
    line = tray.format_proxy_stats_line({"count": 5, "cost_usd": 0.0})
    assert "5 events" in line


def test_get_proxy_status_safe_returns_status(monkeypatch):
    assert tray.get_proxy_status_safe(lambda: "running") == "running"
    assert tray.get_proxy_status_safe(lambda: "stopped") == "stopped"


def test_get_proxy_status_safe_returns_unknown_on_exception():
    def boom():
        raise RuntimeError("nope")
    assert tray.get_proxy_status_safe(boom) == "unknown"


def test_get_proxy_status_safe_default_uses_proxy_service(monkeypatch):
    import claudedashboard.proxy_service as ps
    monkeypatch.setattr(ps, "status", lambda: "running")
    assert tray.get_proxy_status_safe() == "running"


def test_toggle_proxy_when_running_calls_uninstall():
    captured = {}
    def fake_uninstall():
        captured["uninstall_called"] = True
        return {"removed": True}
    result = tray.toggle_proxy(
        status_func=lambda: "running",
        install_func=lambda: {"plist": "/x", "bootstrap_ok": True, "bootstrap_msg": ""},
        uninstall_func=fake_uninstall,
    )
    assert captured.get("uninstall_called") is True
    assert result["action"] == "uninstall"
    assert result["ok"] is True


def test_toggle_proxy_when_stopped_calls_install():
    captured = {}
    def fake_install():
        captured["install_called"] = True
        return {"plist": "/x", "bootstrap_ok": True, "bootstrap_msg": "", "refused": False}
    result = tray.toggle_proxy(
        status_func=lambda: "stopped",
        install_func=fake_install,
        uninstall_func=lambda: {"removed": False},
    )
    assert captured.get("install_called") is True
    assert result["action"] == "install"
    assert result["ok"] is True


def test_toggle_proxy_when_not_installed_calls_install():
    captured = {}
    def fake_install():
        captured["install_called"] = True
        return {"plist": "/x", "bootstrap_ok": True, "bootstrap_msg": "", "refused": False}
    tray.toggle_proxy(
        status_func=lambda: "not_installed",
        install_func=fake_install,
        uninstall_func=lambda: {"removed": False},
    )
    assert captured.get("install_called") is True


def test_toggle_proxy_install_refused_returns_not_ok():
    def fake_install():
        return {"plist": "/x", "bootstrap_ok": False, "bootstrap_msg": "",
                "refused": True, "reason": "mitmdump not on PATH"}
    result = tray.toggle_proxy(
        status_func=lambda: "stopped",
        install_func=fake_install,
        uninstall_func=lambda: {"removed": False},
    )
    assert result["action"] == "install"
    assert result["ok"] is False
    assert "mitmdump" in (result.get("message") or "")


def test_toggle_proxy_swallows_install_exception():
    def fake_install():
        raise RuntimeError("kaboom")
    result = tray.toggle_proxy(
        status_func=lambda: "stopped",
        install_func=fake_install,
        uninstall_func=lambda: {"removed": False},
    )
    assert result["ok"] is False
    assert result["action"] == "install"


def test_toggle_proxy_swallows_status_exception():
    def boom():
        raise RuntimeError("status broke")
    result = tray.toggle_proxy(
        status_func=boom,
        install_func=lambda: {"plist": "/x", "bootstrap_ok": True, "refused": False},
        uninstall_func=lambda: {"removed": True},
    )
    assert result["ok"] is False
