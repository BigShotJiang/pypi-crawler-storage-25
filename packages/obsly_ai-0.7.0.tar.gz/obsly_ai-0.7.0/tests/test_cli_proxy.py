"""Tests for the proxy CLI subcommand parsing."""

import pytest

from claudedashboard.cli import _build_parser


def test_cli_proxy_default_action_is_run():
    parser = _build_parser()
    args = parser.parse_args(["proxy"])
    assert args.command == "proxy"
    assert args.action == "run"


def test_cli_proxy_install_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["proxy", "install"])
    assert args.command == "proxy"
    assert args.action == "install"


def test_cli_proxy_install_dry_run_flag():
    parser = _build_parser()
    args = parser.parse_args(["proxy", "install", "--dry-run"])
    assert args.action == "install"
    assert args.dry_run is True


def test_cli_proxy_status_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["proxy", "status"])
    assert args.action == "status"


def test_cli_proxy_uninstall_action_parses():
    parser = _build_parser()
    args = parser.parse_args(["proxy", "uninstall"])
    assert args.action == "uninstall"


def test_cli_proxy_invalid_action_rejected():
    parser = _build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(["proxy", "badaction"])


def test_cli_proxy_run_keeps_port_flag():
    parser = _build_parser()
    args = parser.parse_args(["proxy", "run", "--port", "9090"])
    assert args.action == "run"
    assert args.port == 9090
