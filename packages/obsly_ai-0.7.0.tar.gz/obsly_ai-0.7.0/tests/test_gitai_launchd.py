"""Tests for the shared launchd installer."""

import os
import plistlib
import subprocess
from pathlib import Path

import pytest

from claudedashboard.gitai import launchd


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    return tmp_path


def _make_run(recorded, returncode=0, stdout="", stderr=""):
    def fake_run(cmd, *args, **kwargs):
        recorded.append(cmd)
        return subprocess.CompletedProcess(cmd, returncode, stdout, stderr)
    return fake_run


# ── plist_path ────────────────────────────────────────────────────────

def test_plist_path_uses_io_obsly_prefix(fake_home):
    p = launchd.plist_path("menubar")
    assert str(p).endswith("Library/LaunchAgents/io.obsly.menubar.plist")
    assert str(p).startswith(str(fake_home))


def test_plist_path_rejects_unsafe_name(fake_home):
    for bad in ["foo bar", "foo/bar", "foo;rm", "", "foo$"]:
        with pytest.raises(ValueError):
            launchd.plist_path(bad)


# ── write_plist ───────────────────────────────────────────────────────

def test_write_plist_creates_parent_dir(fake_home):
    la = fake_home / "Library" / "LaunchAgents"
    assert not la.exists()
    launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "foo"])
    assert la.exists()


def test_write_plist_writes_valid_xml(fake_home):
    path = launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "foo"])
    with open(path, "rb") as f:
        data = plistlib.load(f)
    assert data["Label"] == "io.obsly.menubar"
    assert data["ProgramArguments"] == ["/usr/bin/python3", "-m", "foo"]
    assert data["KeepAlive"] is True
    assert data["RunAtLoad"] is True


def test_write_plist_optional_fields_omitted_when_none(fake_home):
    path = launchd.write_plist("menubar", ["/usr/bin/python3"])
    with open(path, "rb") as f:
        data = plistlib.load(f)
    assert "StandardErrorPath" not in data
    assert "StandardOutPath" not in data
    assert "WorkingDirectory" not in data
    assert "EnvironmentVariables" not in data


def test_write_plist_optional_fields_present_when_set(fake_home):
    path = launchd.write_plist(
        "menubar",
        ["/usr/bin/python3"],
        keep_alive=False,
        run_at_load=False,
        stderr_path="/tmp/err.log",
        stdout_path="/tmp/out.log",
        working_dir="/tmp",
        env={"FOO": "bar"},
    )
    with open(path, "rb") as f:
        data = plistlib.load(f)
    assert data["KeepAlive"] is False
    assert data["RunAtLoad"] is False
    assert data["StandardErrorPath"] == "/tmp/err.log"
    assert data["StandardOutPath"] == "/tmp/out.log"
    assert data["WorkingDirectory"] == "/tmp"
    assert data["EnvironmentVariables"] == {"FOO": "bar"}


def test_write_plist_is_idempotent(fake_home):
    p1 = launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "foo"])
    content1 = p1.read_bytes()
    p2 = launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "foo"])
    content2 = p2.read_bytes()
    assert content1 == content2


def test_write_plist_atomic_replace(fake_home):
    launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "first"])
    path = launchd.write_plist("menubar", ["/usr/bin/python3", "-m", "second"])
    with open(path, "rb") as f:
        data = plistlib.load(f)
    assert data["ProgramArguments"] == ["/usr/bin/python3", "-m", "second"]


# ── bootstrap ─────────────────────────────────────────────────────────

def test_bootstrap_calls_launchctl_with_gui_uid(fake_home, monkeypatch):
    recorded = []
    monkeypatch.setattr(subprocess, "run", _make_run(recorded))
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    launchd.bootstrap("menubar")
    assert recorded, "subprocess.run was not called"
    cmd = recorded[0]
    assert cmd[0] == "launchctl"
    assert cmd[1] == "bootstrap"
    assert cmd[2] == f"gui/{os.getuid()}"
    assert cmd[3].endswith("io.obsly.menubar.plist")


def test_bootstrap_returns_ok_on_zero_exit(fake_home, monkeypatch):
    monkeypatch.setattr(subprocess, "run", _make_run([], returncode=0, stderr=""))
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    ok, err = launchd.bootstrap("menubar")
    assert ok is True


def test_bootstrap_returns_ok_when_already_loaded(fake_home, monkeypatch):
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=37, stderr="Bootstrap failed: 37: service already bootstrapped"),
    )
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    ok, err = launchd.bootstrap("menubar")
    assert ok is True


def test_bootstrap_returns_false_on_other_error(fake_home, monkeypatch):
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=1, stderr="Some other failure"),
    )
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    ok, err = launchd.bootstrap("menubar")
    assert ok is False
    assert "Some other failure" in err


def test_bootstrap_handles_called_process_error(fake_home, monkeypatch):
    def raise_it(*a, **kw):
        raise subprocess.CalledProcessError(1, a[0] if a else "launchctl")
    monkeypatch.setattr(subprocess, "run", raise_it)
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    ok, err = launchd.bootstrap("menubar")
    assert ok is False


# ── bootout ───────────────────────────────────────────────────────────

def test_bootout_calls_launchctl_bootout(fake_home, monkeypatch):
    recorded = []
    monkeypatch.setattr(subprocess, "run", _make_run(recorded))
    launchd.bootout("menubar")
    assert recorded[0] == [
        "launchctl", "bootout", f"gui/{os.getuid()}/io.obsly.menubar",
    ]


def test_bootout_returns_ok_when_not_loaded(fake_home, monkeypatch):
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=3, stderr="Boot-out failed: Could not find specified service"),
    )
    ok, err = launchd.bootout("menubar")
    assert ok is True


# ── status ────────────────────────────────────────────────────────────

def test_status_returns_not_installed_when_plist_missing(fake_home):
    assert launchd.status("menubar") == "not_installed"


def test_status_returns_running_when_launchctl_print_says_running(fake_home, monkeypatch):
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=0, stdout="\tstate = running\n"),
    )
    assert launchd.status("menubar") == "running"


def test_status_returns_stopped_when_launchctl_print_fails(fake_home, monkeypatch):
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=1, stdout="", stderr="not found"),
    )
    assert launchd.status("menubar") == "stopped"


def test_status_returns_stopped_when_state_not_running(fake_home, monkeypatch):
    launchd.write_plist("menubar", ["/usr/bin/python3"])
    monkeypatch.setattr(
        subprocess, "run",
        _make_run([], returncode=0, stdout="\tstate = waiting\n"),
    )
    assert launchd.status("menubar") == "stopped"


# ── uninstall ─────────────────────────────────────────────────────────

def test_uninstall_removes_plist_and_returns_true_when_existed(fake_home, monkeypatch):
    monkeypatch.setattr(subprocess, "run", _make_run([], returncode=0))
    path = launchd.write_plist("menubar", ["/usr/bin/python3"])
    assert path.exists()
    result = launchd.uninstall("menubar")
    assert result is True
    assert not path.exists()


def test_uninstall_returns_false_when_no_plist(fake_home, monkeypatch):
    monkeypatch.setattr(subprocess, "run", _make_run([], returncode=0))
    assert launchd.uninstall("menubar") is False


def test_uninstall_calls_bootout_before_delete(fake_home, monkeypatch):
    recorded = []
    monkeypatch.setattr(subprocess, "run", _make_run(recorded, returncode=0))
    path = launchd.write_plist("menubar", ["/usr/bin/python3"])
    launchd.uninstall("menubar")
    assert any(cmd[:2] == ["launchctl", "bootout"] for cmd in recorded)
    assert not path.exists()
