"""Tests for live.py burn rate computation, especially weekly-reset edge cases."""

from datetime import datetime, timedelta

from claudedashboard.live import _compute_today_used


def _hist(*pairs):
    """Build a fake history list from (datetime, pct) pairs."""
    return [
        {"ts": dt.isoformat() + "Z", "seven_day_pct": pct}
        for dt, pct in pairs
    ]


def test_today_used_normal_within_cycle():
    """Inside a normal cycle, today_used = latest - last reading before today_9am."""
    today_9am = datetime(2026, 4, 8, 8, 0, 0)  # Wednesday 9am Madrid
    cycle_start = today_9am - timedelta(days=2)  # cycle started 2 days ago
    history = _hist(
        (today_9am - timedelta(hours=1), 30.0),
        (today_9am + timedelta(hours=3), 35.0),
    )
    used = _compute_today_used(history, latest_pct=35.0,
                               today_9am_utc=today_9am, cycle_start=cycle_start)
    assert used == 5.0


def test_today_used_is_not_negative_after_weekly_reset():
    """After a weekly reset that happened TODAY at 9am, today_used must reflect
    the new cycle (small positive), not (latest - end_of_previous_cycle)."""
    today_9am = datetime(2026, 4, 10, 8, 0, 0)  # Friday 9am Madrid (reset day)
    cycle_start = today_9am  # cycle resets exactly at the 9am boundary
    history = _hist(
        (today_9am - timedelta(hours=1), 92.0),  # end of previous cycle
        (today_9am + timedelta(hours=6), 7.0),   # current reading in new cycle
    )
    used = _compute_today_used(history, latest_pct=7.0,
                               today_9am_utc=today_9am, cycle_start=cycle_start)
    assert used == 7.0
    assert used >= 0


def test_today_used_reset_happened_after_9am():
    """If the cycle reset happened later than today's 9am boundary, the baseline
    is the cycle_start, not today_9am — readings before cycle_start are stale."""
    today_9am = datetime(2026, 4, 10, 8, 0, 0)
    cycle_start = today_9am + timedelta(hours=1)  # reset 1h after the 9am boundary
    history = _hist(
        (today_9am + timedelta(minutes=30), 88.0),  # before reset, stale
        (today_9am + timedelta(hours=2), 5.0),      # after reset
    )
    used = _compute_today_used(history, latest_pct=5.0,
                               today_9am_utc=today_9am, cycle_start=cycle_start)
    assert used == 5.0


def test_today_used_no_history_returns_latest():
    """No usable history → assume start-of-period baseline of 0."""
    today_9am = datetime(2026, 4, 8, 8, 0, 0)
    cycle_start = today_9am - timedelta(days=2)
    used = _compute_today_used([], latest_pct=12.5,
                               today_9am_utc=today_9am, cycle_start=cycle_start)
    assert used == 12.5


def test_today_used_handles_missing_cycle_start():
    """If cycle_start is unknown, fall back to plain latest - last_pre_9am behavior."""
    today_9am = datetime(2026, 4, 8, 8, 0, 0)
    history = _hist(
        (today_9am - timedelta(hours=1), 30.0),
        (today_9am + timedelta(hours=1), 33.0),
    )
    used = _compute_today_used(history, latest_pct=33.0,
                               today_9am_utc=today_9am, cycle_start=None)
    assert used == 3.0


def test_today_used_skips_malformed_entries():
    """Malformed history rows must not crash and must not be picked as baseline."""
    today_9am = datetime(2026, 4, 8, 8, 0, 0)
    cycle_start = today_9am - timedelta(days=1)
    history = [
        {"ts": "", "seven_day_pct": 50.0},
        {"ts": (today_9am - timedelta(hours=1)).isoformat() + "Z", "seven_day_pct": None},
        {"ts": "garbage", "seven_day_pct": 10.0},
        {"ts": (today_9am - timedelta(minutes=30)).isoformat() + "Z", "seven_day_pct": 20.0},
    ]
    used = _compute_today_used(history, latest_pct=22.0,
                               today_9am_utc=today_9am, cycle_start=cycle_start)
    assert used == 2.0
