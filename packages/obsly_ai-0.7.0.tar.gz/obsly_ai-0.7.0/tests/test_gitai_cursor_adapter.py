import json
import pytest
from claudedashboard.gitai.usage_adapters.cursor import CursorAdapter, _is_cursor_process


def _write_events(path, events):
    with open(path, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")


@pytest.fixture
def events_file(tmp_path):
    return tmp_path / "proxy_events.jsonl"


def test_is_cursor_process_matches_known_names():
    assert _is_cursor_process("Cursor") is True
    assert _is_cursor_process("Cursor Helper") is True
    assert _is_cursor_process("Cursor Helper (Renderer)") is True
    assert _is_cursor_process("cursor") is True
    assert _is_cursor_process("cursor-helper") is True


def test_is_cursor_process_partial_match():
    assert _is_cursor_process("Cursor.app") is True
    assert _is_cursor_process("MY-cursor-thing") is True


def test_is_cursor_process_rejects_other():
    assert _is_cursor_process("claude") is False
    assert _is_cursor_process("Claude Code") is False
    assert _is_cursor_process("python") is False
    assert _is_cursor_process(None) is False
    assert _is_cursor_process("") is False


def test_records_empty_when_file_missing(tmp_path):
    a = CursorAdapter(events_path=tmp_path / "nope.jsonl")
    assert a.records_for_session("any") == []


def test_records_empty_when_session_id_empty(events_file):
    _write_events(events_file, [{"session_id": "x", "tool": "Cursor", "model": "m", "cost_usd": 1.0}])
    a = CursorAdapter(events_path=events_file)
    assert a.records_for_session("") == []
    assert a.records_for_session(None) == []


def test_records_for_session_returns_matching_cursor_events(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor Helper (Renderer)", "model": "claude-sonnet-4-5",
         "tokens_in": 100, "tokens_out": 50, "cache_read": 1000, "cache_create": 0,
         "cost_usd": 0.05, "timestamp": 1700000000.0},
        {"session_id": "s1", "tool": "Cursor", "model": "claude-sonnet-4-5",
         "tokens_in": 200, "tokens_out": 75, "cost_usd": 0.10, "timestamp": 1700000100.0},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert len(records) == 2
    assert records[0].agent == "cursor"
    assert records[0].tokens_in == 100
    assert records[0].equivalent_api_cost_usd == 0.05
    assert records[1].tokens_in == 200


def test_records_for_session_filters_by_session_id(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor", "cost_usd": 0.10},
        {"session_id": "s2", "tool": "Cursor", "cost_usd": 0.20},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert len(records) == 1
    assert records[0].equivalent_api_cost_usd == 0.10


def test_records_for_session_filters_by_tool_name(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor", "cost_usd": 0.10},
        {"session_id": "s1", "tool": "claude", "cost_usd": 0.20},
        {"session_id": "s1", "tool": "python", "cost_usd": 0.30},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert len(records) == 1
    assert records[0].equivalent_api_cost_usd == 0.10


def test_records_for_session_skips_garbage_lines(events_file):
    events_file.write_text(
        '{"session_id": "s1", "tool": "Cursor", "cost_usd": 0.10}\n'
        'this is not json\n'
        '{"session_id": "s1", "tool": "Cursor", "cost_usd": 0.20}\n'
    )
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert len(records) == 2


def test_records_for_session_handles_missing_fields(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor"},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert len(records) == 1
    assert records[0].tokens_in == 0
    assert records[0].tokens_out == 0
    assert records[0].cache_read == 0
    assert records[0].equivalent_api_cost_usd == 0.0
    assert records[0].model == ""


def test_records_for_session_converts_unix_timestamp_to_iso(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor", "timestamp": 1700000000.0},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert "T" in records[0].timestamp


def test_records_for_session_passes_iso_timestamp_through(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor", "timestamp": "2026-04-11T10:00:00Z"},
    ])
    a = CursorAdapter(events_path=events_file)
    records = a.records_for_session("s1")
    assert records[0].timestamp == "2026-04-11T10:00:00Z"


def test_default_events_path_is_under_dot_claude(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr("os.path.expanduser", lambda p: str(tmp_path) if p == "~" else p)
    a = CursorAdapter()
    assert ".claude" in str(a.events_path)
    assert "proxy_events.jsonl" in str(a.events_path)


def test_cost_for_session_sums_records(events_file):
    _write_events(events_file, [
        {"session_id": "s1", "tool": "Cursor", "cost_usd": 0.10},
        {"session_id": "s1", "tool": "Cursor", "cost_usd": 0.20},
    ])
    a = CursorAdapter(events_path=events_file)
    assert a.cost_for_session("s1") == 0.3


def test_records_returns_empty_for_unknown_session(events_file):
    _write_events(events_file, [
        {"session_id": "known", "tool": "Cursor", "cost_usd": 0.10},
    ])
    a = CursorAdapter(events_path=events_file)
    assert a.records_for_session("unknown") == []


def test_adapter_is_registered_in_all_adapters():
    from claudedashboard.gitai.usage_adapters import all_adapters
    adapters = all_adapters()
    assert any(a.agent == "cursor" for a in adapters)
