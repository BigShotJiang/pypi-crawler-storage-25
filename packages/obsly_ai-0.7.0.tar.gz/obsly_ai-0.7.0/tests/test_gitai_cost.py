"""TDD for cost attribution engine — red to green."""
import json
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId,
)


def _make_log():
    return AuthorshipLog(
        attestations=[FileAttestation("src/foo.py", [
            AttestationEntry("aaa1234567890123", [LineRange(1, 10)]),
        ])],
        base_commit_sha="abc",
        prompts={"aaa1234567890123": PromptRecord(
            agent_id=AgentId("claude-code", "s1", "claude-sonnet-4-6"),
            total_additions=10,
        )},
    )


class TestMatchEvents:

    def test_match_by_agent_and_time(self):
        from claudedashboard.gitai.cost_attribution import match_events_to_prompts
        events = [
            {"tool": "claude", "timestamp": 1000, "cost": 0.50, "repo": "myrepo"},
            {"tool": "cursor", "timestamp": 1001, "cost": 0.30, "repo": "myrepo"},
            {"tool": "claude", "timestamp": 9999, "cost": 0.10, "repo": "myrepo"},
        ]
        log = _make_log()
        matches = match_events_to_prompts(events, log, commit_timestamp=1000, time_window=600)
        total = sum(len(v) for v in matches.values())
        assert total >= 1  # at least the claude event at t=1000

    def test_no_match_too_far(self):
        from claudedashboard.gitai.cost_attribution import match_events_to_prompts
        events = [
            {"tool": "claude", "timestamp": 99999, "cost": 0.50, "repo": "myrepo"},
        ]
        log = _make_log()
        matches = match_events_to_prompts(events, log, commit_timestamp=1000, time_window=600)
        total = sum(len(v) for v in matches.values())
        assert total == 0


class TestEnrich:

    def test_adds_cost(self):
        from claudedashboard.gitai.cost_attribution import enrich_authorship_log
        log = _make_log()
        events = [{"tool": "claude", "timestamp": 1000, "cost": 1.50,
                    "tokens_in": 5000, "tokens_out": 2000, "repo": "myrepo"}]
        enriched = enrich_authorship_log(log, events, commit_timestamp=1000)
        prompt = enriched.prompts["aaa1234567890123"]
        assert prompt.custom_attributes is not None
        assert float(prompt.custom_attributes["cost_usd"]) == pytest.approx(1.50)

    def test_no_events_no_change(self):
        from claudedashboard.gitai.cost_attribution import enrich_authorship_log
        log = _make_log()
        enriched = enrich_authorship_log(log, [], commit_timestamp=1000)
        assert enriched.prompts["aaa1234567890123"].custom_attributes is None


class TestEstimate:

    def test_cost_per_line(self):
        from claudedashboard.gitai.cost_attribution import estimate_cost_per_line
        prompt = PromptRecord(
            agent_id=AgentId("claude-code", "s1", "sonnet"),
            total_additions=50,
            custom_attributes={"cost_usd": "2.50"},
        )
        assert estimate_cost_per_line(prompt) == pytest.approx(0.05)

    def test_no_data(self):
        from claudedashboard.gitai.cost_attribution import estimate_cost_per_line
        prompt = PromptRecord(agent_id=AgentId("claude-code", "s1", "sonnet"), total_additions=50)
        assert estimate_cost_per_line(prompt) is None


class TestCostSummary:

    def test_by_agent(self):
        from claudedashboard.gitai.cost_attribution import cost_summary
        events = [
            {"tool": "claude", "cost": 1.0},
            {"tool": "claude", "cost": 0.5},
            {"tool": "cursor", "cost": 0.3},
        ]
        summary = cost_summary(events, group_by="tool")
        assert summary["claude"] == pytest.approx(1.5)
        assert summary["cursor"] == pytest.approx(0.3)
