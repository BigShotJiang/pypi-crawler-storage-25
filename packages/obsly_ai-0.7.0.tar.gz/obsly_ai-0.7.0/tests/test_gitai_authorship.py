"""TDD for authorship log serialization + git notes — red to green."""
import json, subprocess
import pytest
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, AgentId, Checkpoint, CheckpointKind,
    WorkingLogEntry, LineAttribution,
)


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "README.md").write_text("# Test\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _get_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                          capture_output=True, text=True).stdout.strip()


def _make_sample_log():
    return AuthorshipLog(
        attestations=[
            FileAttestation("src/main.py", [
                AttestationEntry("c9883b05a2487d6d", [LineRange(1, 10), LineRange(15, 15), LineRange(20, 25)]),
                AttestationEntry("abc1234567890123", [LineRange(30, 40)]),
            ]),
            FileAttestation("src/utils.py", [
                AttestationEntry("c9883b05a2487d6d", [LineRange(1, 5)]),
            ]),
        ],
        base_commit_sha="deadbeef12345678",
        prompts={
            "c9883b05a2487d6d": PromptRecord(
                agent_id=AgentId("claude-code", "sess-xyz", "claude-sonnet-4-6"),
                human_author="dev@example.com",
                total_additions=21,
            ),
            "abc1234567890123": PromptRecord(
                agent_id=AgentId("cursor", "conv-456", "gpt-4o"),
                total_additions=11,
            ),
        },
    )


# ── Serialization ────────────────────────────────────────────────────

class TestSerialize:

    def test_basic_format(self):
        from claudedashboard.gitai.authorship_log import serialize
        log = _make_sample_log()
        text = serialize(log)
        assert text.startswith("src/main.py\n")
        assert "\n---\n" in text
        assert '"schema_version"' in text

    def test_attestation_indentation(self):
        from claudedashboard.gitai.authorship_log import serialize
        log = _make_sample_log()
        text = serialize(log)
        attest_part = text.split("\n---\n")[0]
        for line in attest_part.split("\n"):
            if not line:
                continue
            if line.startswith("  "):
                # Attestation entry: 2 spaces + 16-char hash + space + ranges
                stripped = line.strip()
                parts = stripped.split(" ", 1)
                assert len(parts[0]) == 16
                assert all(c in "0123456789abcdef" for c in parts[0])
            elif not line.startswith('"'):
                # File path at column 0
                assert not line.startswith(" ")

    def test_json_metadata(self):
        from claudedashboard.gitai.authorship_log import serialize
        log = _make_sample_log()
        text = serialize(log)
        json_part = text.split("\n---\n")[1]
        metadata = json.loads(json_part)
        assert metadata["schema_version"] == "authorship/3.0.0"
        assert metadata["base_commit_sha"] == "deadbeef12345678"
        assert "c9883b05a2487d6d" in metadata["prompts"]
        assert metadata["prompts"]["c9883b05a2487d6d"]["agent_id"]["tool"] == "claude-code"


class TestDeserialize:

    def test_basic(self):
        from claudedashboard.gitai.authorship_log import deserialize
        text = 'src/main.py\n  c9883b05a2487d6d 1-10,15\n---\n{"schema_version":"authorship/3.0.0","base_commit_sha":"abc","prompts":{"c9883b05a2487d6d":{"agent_id":{"tool":"claude-code","id":"s1","model":"sonnet"},"human_author":null,"messages":[],"total_additions":11,"total_deletions":0,"accepted_lines":0,"overridden_lines":0,"messages_url":null,"custom_attributes":null}}}'
        log = deserialize(text)
        assert len(log.attestations) == 1
        assert log.attestations[0].file_path == "src/main.py"
        assert log.attestations[0].entries[0].session_hash == "c9883b05a2487d6d"
        assert log.prompts["c9883b05a2487d6d"].agent_id.tool == "claude-code"

    def test_roundtrip(self):
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = _make_sample_log()
        restored = deserialize(serialize(log))
        assert len(restored.attestations) == len(log.attestations)
        assert restored.base_commit_sha == log.base_commit_sha
        assert set(restored.prompts.keys()) == set(log.prompts.keys())
        for key in log.prompts:
            assert restored.prompts[key].agent_id.tool == log.prompts[key].agent_id.tool

    def test_file_with_spaces(self):
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = AuthorshipLog(
            attestations=[FileAttestation("src/my file.py", [
                AttestationEntry("abcd1234abcd1234", [LineRange(1, 5)])
            ])],
            prompts={"abcd1234abcd1234": PromptRecord(
                agent_id=AgentId("claude-code", "s1", "sonnet"),
                total_additions=5,
            )},
        )
        text = serialize(log)
        assert '"src/my file.py"' in text
        restored = deserialize(text)
        assert restored.attestations[0].file_path == "src/my file.py"

    def test_empty_attestations(self):
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = AuthorshipLog(attestations=[], prompts={})
        text = serialize(log)
        assert "---\n" in text
        restored = deserialize(text)
        assert restored.attestations == []

    def test_custom_attributes_preserved(self):
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = AuthorshipLog(
            attestations=[FileAttestation("f.py", [
                AttestationEntry("hash123456789012", [LineRange(1, 1)])
            ])],
            prompts={"hash123456789012": PromptRecord(
                agent_id=AgentId("claude-code", "s1", "sonnet"),
                total_additions=1,
                custom_attributes={"cost_usd": "1.23", "tokens_in": "5000"},
            )},
        )
        restored = deserialize(serialize(log))
        assert restored.prompts["hash123456789012"].custom_attributes["cost_usd"] == "1.23"


# ── from_checkpoints ────────────────────────────────────────────────

class TestFromCheckpoints:

    def test_single_ai_checkpoint(self):
        from claudedashboard.gitai.authorship_log import from_checkpoints
        from claudedashboard.gitai.session import generate_session_hash
        cp = Checkpoint(
            kind=CheckpointKind.AI_AGENT, author="dev@test.com",
            entries=[WorkingLogEntry("src/foo.py", "sha1", [
                LineAttribution(1, 10, generate_session_hash("claude-code", "s1"), None)
            ])],
            agent_id=AgentId("claude-code", "s1", "claude-sonnet-4-6"),
        )
        log = from_checkpoints([cp], "commit123", "dev@test.com")
        assert len(log.attestations) == 1
        assert log.attestations[0].file_path == "src/foo.py"
        assert log.base_commit_sha == "commit123"
        assert len(log.prompts) == 1

    def test_human_only_empty(self):
        from claudedashboard.gitai.authorship_log import from_checkpoints
        cp = Checkpoint(kind=CheckpointKind.HUMAN, author="dev@test.com", entries=[])
        log = from_checkpoints([cp], "commit123", "dev@test.com")
        assert log.attestations == []
        assert log.prompts == {}

    def test_multiple_agents(self):
        from claudedashboard.gitai.authorship_log import from_checkpoints
        from claudedashboard.gitai.session import generate_session_hash
        hash1 = generate_session_hash("claude-code", "s1")
        hash2 = generate_session_hash("cursor", "s2")
        cp1 = Checkpoint(
            kind=CheckpointKind.AI_AGENT, author="dev@test.com",
            entries=[WorkingLogEntry("src/foo.py", "sha1", [
                LineAttribution(1, 10, hash1, None)
            ])],
            agent_id=AgentId("claude-code", "s1", "sonnet"),
        )
        cp2 = Checkpoint(
            kind=CheckpointKind.AI_AGENT, author="dev@test.com",
            entries=[WorkingLogEntry("src/foo.py", "sha2", [
                LineAttribution(15, 20, hash2, None)
            ])],
            agent_id=AgentId("cursor", "s2", "gpt-4o"),
        )
        log = from_checkpoints([cp1, cp2], "commit123", "dev@test.com")
        assert len(log.prompts) == 2

    def test_total_lines_added_passed_through(self):
        """from_checkpoints should accept total_lines_added and store it on the log."""
        from claudedashboard.gitai.authorship_log import from_checkpoints
        from claudedashboard.gitai.session import generate_session_hash
        cp = Checkpoint(
            kind=CheckpointKind.AI_AGENT, author="dev@test.com",
            entries=[WorkingLogEntry("src/foo.py", "sha1", [
                LineAttribution(1, 10, generate_session_hash("claude-code", "s1"), None)
            ])],
            agent_id=AgentId("claude-code", "s1", "sonnet"),
        )
        log = from_checkpoints([cp], "commit123", "dev@test.com", total_lines_added=42)
        assert log.total_lines_added == 42

    def test_total_lines_added_default_none(self):
        """When not given, total_lines_added is None (back-compat)."""
        from claudedashboard.gitai.authorship_log import from_checkpoints
        log = from_checkpoints([], "commit123", "dev@test.com")
        assert log.total_lines_added is None


class TestSerializeTotalLines:

    def test_serialize_includes_total_lines_added_when_set(self):
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = AuthorshipLog(
            attestations=[FileAttestation("a.py", [
                AttestationEntry("hash123456789012", [LineRange(1, 5)])
            ])],
            prompts={"hash123456789012": PromptRecord(
                agent_id=AgentId("claude-code", "s1", "sonnet"),
                total_additions=5,
            )},
            total_lines_added=20,
        )
        text = serialize(log)
        assert "total_lines_added" in text
        assert "authorship/3.1.0" in text  # bumped schema
        restored = deserialize(text)
        assert restored.total_lines_added == 20
        assert restored.schema_version == "authorship/3.1.0"

    def test_deserialize_v300_note_has_no_total_lines(self):
        """Old v3.0.0 notes (no total_lines_added) round-trip without raising."""
        from claudedashboard.gitai.authorship_log import deserialize
        text = ('src/main.py\n  hash123456789012 1-10\n---\n'
                '{"schema_version":"authorship/3.0.0","base_commit_sha":"abc",'
                '"prompts":{"hash123456789012":{"agent_id":{"tool":"claude-code","id":"s1","model":"sonnet"},'
                '"human_author":null,"messages":[],"total_additions":10,"total_deletions":0,'
                '"accepted_lines":0,"overridden_lines":0,"messages_url":null,"custom_attributes":null}}}')
        log = deserialize(text)
        assert log.total_lines_added is None
        assert log.schema_version == "authorship/3.0.0"

    def test_serialize_without_total_lines_omits_field_or_uses_null(self):
        """Serializing a log with total_lines_added=None should not include a misleading 0."""
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = AuthorshipLog(
            attestations=[FileAttestation("a.py", [
                AttestationEntry("hash123456789012", [LineRange(1, 3)])
            ])],
            prompts={"hash123456789012": PromptRecord(
                agent_id=AgentId("claude-code", "s1", "sonnet"),
                total_additions=3,
            )},
            total_lines_added=None,
        )
        restored = deserialize(serialize(log))
        assert restored.total_lines_added is None


# ── Git Notes ────────────────────────────────────────────────────────

class TestGitNotes:

    def test_write_read(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add, notes_read
        sha = _get_head(git_repo)
        notes_add(str(git_repo), sha, "test note content")
        result = notes_read(str(git_repo), sha)
        assert result.strip() == "test note content"

    def test_read_nonexistent(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_read
        assert notes_read(str(git_repo), "0" * 40) is None

    def test_overwrite(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add, notes_read
        sha = _get_head(git_repo)
        notes_add(str(git_repo), sha, "first")
        notes_add(str(git_repo), sha, "second")
        assert notes_read(str(git_repo), sha).strip() == "second"

    def test_has_note(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add, has_note
        sha = _get_head(git_repo)
        assert has_note(str(git_repo), sha) is False
        notes_add(str(git_repo), sha, "x")
        assert has_note(str(git_repo), sha) is True

    def test_notes_list(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add, notes_list
        sha = _get_head(git_repo)
        notes_add(str(git_repo), sha, "content")
        pairs = notes_list(str(git_repo))
        assert any(commit == sha for _, commit in pairs)

    def test_visible_in_git_log(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add
        sha = _get_head(git_repo)
        notes_add(str(git_repo), sha, "ai attribution data")
        result = subprocess.run(
            ["git", "-C", str(git_repo), "log", "--notes=ai", "-1", "--format=%N"],
            capture_output=True, text=True,
        )
        assert "ai attribution data" in result.stdout

    def test_full_authorship_log_roundtrip(self, git_repo):
        from claudedashboard.gitai.git_notes import notes_add, notes_read
        from claudedashboard.gitai.authorship_log import serialize, deserialize
        log = _make_sample_log()
        sha = _get_head(git_repo)
        notes_add(str(git_repo), sha, serialize(log))
        raw = notes_read(str(git_repo), sha)
        restored = deserialize(raw)
        assert len(restored.attestations) == len(log.attestations)
        assert restored.schema_version == "authorship/3.0.0"

    def test_get_repo_root(self, git_repo):
        from claudedashboard.gitai.git_notes import get_repo_root
        assert get_repo_root(str(git_repo)) == str(git_repo)

    def test_get_repo_root_not_git(self, tmp_path):
        from claudedashboard.gitai.git_notes import get_repo_root
        assert get_repo_root(str(tmp_path)) is None

    def test_get_head_sha(self, git_repo):
        from claudedashboard.gitai.git_notes import get_head_sha
        sha = get_head_sha(str(git_repo))
        assert len(sha) == 40
        assert all(c in "0123456789abcdef" for c in sha)

    def test_get_git_user(self, git_repo):
        from claudedashboard.gitai.git_notes import get_git_user
        assert get_git_user(str(git_repo)) == "test@test.com"
