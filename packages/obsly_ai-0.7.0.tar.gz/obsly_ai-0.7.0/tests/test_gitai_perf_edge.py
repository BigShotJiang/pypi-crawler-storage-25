"""TDD for performance benchmarks + edge cases — red to green."""
import json, os, subprocess, time
import pytest
from claudedashboard.gitai.models import NormalizedHookInput, HookEvent


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("line1\nline2\nline3\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


def _hook(repo, event, tid, tool, file_rel):
    return NormalizedHookInput(
        event=event, agent="claude-code", session_id="s1", tool_name=tool,
        tool_input={"file_path": str(repo / file_rel)},
        tool_use_id=tid, cwd=str(repo), model="sonnet",
    )


# ── Performance ──────────────────────────────────────────────────────

class TestPerformance:

    def test_edit_hook_latency(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        start = time.monotonic()
        engine.handle_pre_tool_use(_hook(git_repo, HookEvent.PRE_TOOL_USE, "p1", "Edit", "src/foo.py"))
        (git_repo / "src" / "foo.py").write_text("changed\n")
        engine.handle_post_tool_use(_hook(git_repo, HookEvent.POST_TOOL_USE, "p1", "Edit", "src/foo.py"))
        ms = (time.monotonic() - start) * 1000
        assert ms < 200, f"Edit hook took {ms:.0f}ms"

    def test_large_file_hook(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        big = "\n".join(f"line_{i}" for i in range(500)) + "\n"
        (git_repo / "src" / "big.py").write_text(big)
        subprocess.run(["git", "-C", str(git_repo), "add", "."], check=True, capture_output=True)
        subprocess.run(["git", "-C", str(git_repo), "commit", "-m", "big"],
                       check=True, capture_output=True)
        engine = CheckpointEngine(str(git_repo))
        start = time.monotonic()
        engine.handle_pre_tool_use(_hook(git_repo, HookEvent.PRE_TOOL_USE, "p2", "Edit", "src/big.py"))
        # Insert 50 lines in middle
        lines = big.splitlines()
        lines[250:250] = [f"new_{i}" for i in range(50)]
        (git_repo / "src" / "big.py").write_text("\n".join(lines) + "\n")
        engine.handle_post_tool_use(_hook(git_repo, HookEvent.POST_TOOL_USE, "p2", "Edit", "src/big.py"))
        ms = (time.monotonic() - start) * 1000
        assert ms < 300, f"Large file hook took {ms:.0f}ms"


# ── Edge cases ───────────────────────────────────────────────────────

class TestEdgeCases:

    def test_not_a_git_repo(self, tmp_path):
        """Non-git directory → no crash."""
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(tmp_path))
        hook = NormalizedHookInput(
            event=HookEvent.PRE_TOOL_USE, agent="claude-code", session_id="s1",
            tool_name="Write", tool_input={"file_path": str(tmp_path / "foo.py")},
            tool_use_id="t1", cwd=str(tmp_path),
        )
        engine.handle_pre_tool_use(hook)  # should not raise

    def test_binary_file(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "img.png").write_bytes(b"\x89PNG\x00\x00binary")
        engine.handle_pre_tool_use(_hook(git_repo, HookEvent.PRE_TOOL_USE, "b1", "Write", "img.png"))
        engine.handle_post_tool_use(_hook(git_repo, HookEvent.POST_TOOL_USE, "b1", "Write", "img.png"))
        from claudedashboard.gitai.git_notes import get_head_sha
        base = get_head_sha(str(git_repo))
        assert engine.working_log.read_checkpoints(base) == []

    def test_empty_file(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "empty.py").write_text("")
        engine.handle_pre_tool_use(_hook(git_repo, HookEvent.PRE_TOOL_USE, "e1", "Write", "empty.py"))
        engine.handle_post_tool_use(_hook(git_repo, HookEvent.POST_TOOL_USE, "e1", "Write", "empty.py"))
        # Should not crash

    def test_unicode_filename(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        (git_repo / "café.py").write_text("print('hola')\n")
        engine.handle_pre_tool_use(_hook(git_repo, HookEvent.PRE_TOOL_USE, "u1", "Write", "café.py"))
        engine.handle_post_tool_use(_hook(git_repo, HookEvent.POST_TOOL_USE, "u1", "Write", "café.py"))

    def test_malformed_hook_json(self):
        from claudedashboard.gitai.hook_handler import parse_hook_input
        assert parse_hook_input("claude-code", "NOT JSON") is None
        assert parse_hook_input("claude-code", "{}") is None
        assert parse_hook_input("claude-code", '{"hook_event_name": "Unknown"}') is None

    def test_read_only_tools_skipped(self, git_repo):
        from claudedashboard.gitai.checkpoint import CheckpointEngine
        engine = CheckpointEngine(str(git_repo))
        hook = NormalizedHookInput(
            event=HookEvent.PRE_TOOL_USE, agent="claude-code", session_id="s1",
            tool_name="Read", tool_input={"file_path": str(git_repo / "src/foo.py")},
            tool_use_id="r1", cwd=str(git_repo),
        )
        engine.handle_pre_tool_use(hook)
        assert engine.working_log.load_snapshot("r1") is None

    def test_blame_nonexistent(self, git_repo):
        from claudedashboard.gitai.blame import blame
        assert blame(str(git_repo), "nonexistent.py") == []

    def test_stats_no_notes(self, git_repo):
        from claudedashboard.gitai.stats import stats_for_repo
        stats = stats_for_repo(str(git_repo), limit=10)
        assert stats.commits_with_ai == 0
        assert stats.ai_percentage == 0


# ── CLI wiring ───────────────────────────────────────────────────────

class TestCli:

    def test_ai_status_import(self):
        """Verify CLI modules are importable."""
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        from claudedashboard.gitai.hooks.codex import CodexInstaller
        from claudedashboard.gitai.hooks.cursor import CursorInstaller
        from claudedashboard.gitai.hooks.windsurf import WindsurfInstaller
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        from claudedashboard.gitai.hook_handler import main
        from claudedashboard.gitai.blame import blame
        from claudedashboard.gitai.stats import stats_for_commit, stats_for_repo
        from claudedashboard.gitai.durability import analyze_durability
        from claudedashboard.gitai.cost_attribution import estimate_cost_per_line
        from claudedashboard.gitai.api_data import get_ai_summary
        # All imported without error

    def test_all_gitai_modules_zero_deps(self):
        """Verify no external imports in gitai package."""
        import importlib, pkgutil
        import claudedashboard.gitai as gitai_pkg
        for importer, modname, ispkg in pkgutil.walk_packages(
            gitai_pkg.__path__, prefix="claudedashboard.gitai."
        ):
            mod = importlib.import_module(modname)
            # Check that no non-stdlib modules are imported
            for attr_name in dir(mod):
                obj = getattr(mod, attr_name)
                if hasattr(obj, "__module__") and obj.__module__:
                    # Skip builtins and our own modules
                    m = obj.__module__
                    assert not m.startswith("flask"), f"{modname} imports flask"
                    assert not m.startswith("mitmproxy"), f"{modname} imports mitmproxy"
                    assert not m.startswith("rumps"), f"{modname} imports rumps"
