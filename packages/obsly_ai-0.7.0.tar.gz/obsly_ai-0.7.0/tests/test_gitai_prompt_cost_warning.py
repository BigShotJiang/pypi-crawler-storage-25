"""Tests for the real-time prompt cost warning (0.7.0 #1, issue #45).

The feature: a `UserPromptSubmit` hook that runs before Claude Code
processes the next user message. It reads the current session JSONL,
computes accumulated cost + context size + cache_read pressure, and
prints a warning to stderr if any threshold is crossed, suggesting
`/clear` with the estimated savings.

The lessons:

- Tests are stdlib-only (zero deps in `gitai/`).
- We synthesize Claude Code session JSONL files in tmp_path so the
  tests are hermetic.
- The hook MUST never block the agent — every error path returns
  None (no warning) and the CLI always exits 0.
- The warning text MUST be a true assertion of math, not a string
  match against a label that could vanish.
"""

import io
import json
import os
import sys
import time
from pathlib import Path

import pytest

from claudedashboard.gitai import prompt_cost_warning as pcw


# --- helpers ---------------------------------------------------------------


def _mk_message(
    *,
    input_tokens=0,
    cache_creation=0,
    cache_read=0,
    output_tokens=0,
    model="claude-opus-4-6-20251101",
    timestamp=None,
):
    """Build one Claude Code JSONL message line."""
    return {
        "timestamp": timestamp or "2026-04-11T20:00:00Z",
        "message": {
            "model": model,
            "usage": {
                "input_tokens": input_tokens,
                "cache_creation_input_tokens": cache_creation,
                "cache_read_input_tokens": cache_read,
                "output_tokens": output_tokens,
            },
        },
    }


def _write_jsonl(path: Path, messages: list[dict]) -> Path:
    path.write_text("\n".join(json.dumps(m) for m in messages) + "\n")
    return path


# --- compute_session_metrics -----------------------------------------------


def test_compute_session_metrics_aggregates_tokens(tmp_path):
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=200, cache_read=1000),
        _mk_message(input_tokens=50, output_tokens=80, cache_read=2000),
    ])
    m = pcw.compute_session_metrics(f)
    assert m.total_input_tokens == 150
    assert m.total_output_tokens == 280
    assert m.total_cache_read == 3000
    assert m.message_count == 2


def test_compute_session_metrics_computes_cost_with_pricing(tmp_path):
    """Use known pricing for claude-opus-4-6: input $15/M, output $75/M, cache_read $1.50/M."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=1_000_000, output_tokens=0, cache_read=0),
    ])
    m = pcw.compute_session_metrics(f)
    # 1M input * $15/M = $15
    assert m.total_cost_usd == pytest.approx(15.0, abs=0.01)


def test_compute_session_metrics_includes_cache_read_cost(tmp_path):
    """The whole point of the feature: cache_read dominates cost in long
    sessions. The real-world example from issue #45:
    - 2612 input + 90191 output + 30524591 cache_read + 422494 cache_create
    - On opus-4-6: input $15/M, output $75/M, cache_read $1.50/M, cache_create $18.75/M
    - = $0.039 + $6.764 + $45.787 + $7.922 = $60.512"""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(
            input_tokens=2612, output_tokens=90191,
            cache_read=30_524_591, cache_creation=422_494,
        ),
    ])
    m = pcw.compute_session_metrics(f)
    assert m.total_cost_usd == pytest.approx(60.51, abs=0.5)


def test_compute_session_metrics_handles_empty_file(tmp_path):
    f = tmp_path / "empty.jsonl"
    f.write_text("")
    m = pcw.compute_session_metrics(f)
    assert m.message_count == 0
    assert m.total_cost_usd == 0
    assert m.total_input_tokens == 0


def test_compute_session_metrics_skips_lines_without_usage(tmp_path):
    """User text messages have no `usage` field — they must be skipped
    silently, not crash the parser."""
    lines = [
        json.dumps({"timestamp": "2026-04-11T20:00:00Z", "type": "user", "content": "hello"}),
        json.dumps(_mk_message(input_tokens=100)),
        json.dumps({"timestamp": "2026-04-11T20:00:01Z", "message": {"role": "user"}}),
    ]
    f = tmp_path / "s.jsonl"
    f.write_text("\n".join(lines) + "\n")
    m = pcw.compute_session_metrics(f)
    assert m.message_count == 1
    assert m.total_input_tokens == 100


def test_compute_session_metrics_skips_malformed_lines(tmp_path):
    """A corrupt or partial line must not crash the metrics."""
    f = tmp_path / "s.jsonl"
    f.write_text(
        "not json\n"
        + json.dumps(_mk_message(input_tokens=42)) + "\n"
        + "{partial\n"
    )
    m = pcw.compute_session_metrics(f)
    assert m.total_input_tokens == 42


def test_compute_session_metrics_returns_none_for_missing_file(tmp_path):
    m = pcw.compute_session_metrics(tmp_path / "does-not-exist.jsonl")
    assert m is None


def test_compute_session_metrics_tracks_session_age_seconds(tmp_path):
    """Session age = (now - first_message_timestamp) so we know how long
    it has been running."""
    old_ts = "2026-04-11T19:00:00Z"  # 1 hour before "now" in test
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, timestamp=old_ts),
        _mk_message(input_tokens=50, timestamp="2026-04-11T20:00:00Z"),
    ])
    m = pcw.compute_session_metrics(
        f, now_ts="2026-04-11T20:00:00Z",
    )
    assert m.session_age_seconds == 3600


def test_compute_session_metrics_computes_context_tokens_from_last_message(tmp_path):
    """Context size = the cache_read of the latest message (because that
    is exactly the size of context Claude is carrying into the next call).
    Plus cache_creation, plus input_tokens of the latest exchange."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=10, cache_read=1000),
        _mk_message(input_tokens=20, cache_read=180_000, cache_creation=5000),
    ])
    m = pcw.compute_session_metrics(f)
    # last message context = 180000 cache_read + 5000 cache_creation + 20 input
    assert m.context_tokens == 180_000 + 5000 + 20


# --- thresholds + should_warn ---------------------------------------------


def test_should_warn_returns_none_when_nothing_tripped():
    metrics = pcw.SessionMetrics(
        total_input_tokens=100,
        total_output_tokens=100,
        total_cache_read=100,
        total_cache_creation=0,
        total_cost_usd=0.5,
        context_tokens=10_000,
        session_age_seconds=60,
        message_count=2,
        last_message_cost_usd=0.1,
    )
    thresholds = pcw.Thresholds()  # defaults
    assert pcw.should_warn(metrics, thresholds) is None


def test_should_warn_fires_when_context_threshold_crossed():
    metrics = pcw.SessionMetrics(
        total_input_tokens=100, total_output_tokens=100,
        total_cache_read=300_000, total_cache_creation=0,
        total_cost_usd=2.0,
        context_tokens=300_000,  # > default 200k
        session_age_seconds=300, message_count=10,
        last_message_cost_usd=1.0,
    )
    warning = pcw.should_warn(metrics, pcw.Thresholds())
    assert warning is not None
    assert "context_tokens" in warning.reasons


def test_should_warn_fires_when_accumulated_cost_threshold_crossed():
    metrics = pcw.SessionMetrics(
        total_input_tokens=100, total_output_tokens=100,
        total_cache_read=100, total_cache_creation=0,
        total_cost_usd=25.0,  # > default $20
        context_tokens=10_000, session_age_seconds=60, message_count=10,
        last_message_cost_usd=1.0,
    )
    warning = pcw.should_warn(metrics, pcw.Thresholds())
    assert warning is not None
    assert "accumulated_cost" in warning.reasons


def test_should_warn_fires_when_session_age_threshold_crossed():
    metrics = pcw.SessionMetrics(
        total_input_tokens=100, total_output_tokens=100,
        total_cache_read=100, total_cache_creation=0,
        total_cost_usd=1.0, context_tokens=10_000,
        session_age_seconds=120 * 60,  # 120 min > default 90 min
        message_count=10,
        last_message_cost_usd=0.05,
    )
    warning = pcw.should_warn(metrics, pcw.Thresholds())
    assert warning is not None
    assert "session_age" in warning.reasons


def test_should_warn_fires_when_cache_ratio_huge():
    """When cache_read of the last message is more than 100x the
    input_tokens of the same message, the new prompt is paying for
    contextual deadweight."""
    metrics = pcw.SessionMetrics(
        total_input_tokens=200, total_output_tokens=100,
        total_cache_read=200_000, total_cache_creation=0,
        total_cost_usd=5.0, context_tokens=200_000,
        session_age_seconds=60, message_count=2,
        last_message_input_tokens=100,
        last_message_cache_read=200_000,
        last_message_cost_usd=1.0,
    )
    # ratio = 200000/100 = 2000x, way over default 100x
    warning = pcw.should_warn(metrics, pcw.Thresholds())
    assert warning is not None
    assert "cache_ratio" in warning.reasons


def test_should_warn_concatenates_multiple_reasons():
    metrics = pcw.SessionMetrics(
        total_input_tokens=100, total_output_tokens=100,
        total_cache_read=300_000, total_cache_creation=0,
        total_cost_usd=25.0,  # cost tripped
        context_tokens=300_000,  # context tripped
        session_age_seconds=60, message_count=10,
        last_message_cost_usd=1.0,
    )
    warning = pcw.should_warn(metrics, pcw.Thresholds())
    assert warning is not None
    assert set(warning.reasons) >= {"context_tokens", "accumulated_cost"}


# --- savings math ----------------------------------------------------------


def test_warning_savings_uses_cache_read_cost(tmp_path):
    """The savings = cost of last message minus cost of the same prompt
    AS IF cache_read were 0 (i.e. fresh /clear). On opus, 200k cache_read
    saves 200k * $1.50/M = $0.30 vs reusing it."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=500, cache_read=200_000),
    ])
    m = pcw.compute_session_metrics(f)
    warning = pcw.should_warn(m, pcw.Thresholds(cache_ratio=10))
    assert warning is not None
    # current_cost includes cache_read; post_clear excludes it.
    # cache_read 200_000 * $1.50/M = $0.30
    assert warning.savings_usd == pytest.approx(0.30, abs=0.01)
    assert warning.savings_pct > 0


def test_warning_savings_zero_when_no_cache(tmp_path):
    """A fresh session with no cache_read has nothing to save."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=500, cache_read=0),
    ])
    m = pcw.compute_session_metrics(f)
    # Force a warning by lowering thresholds
    warning = pcw.should_warn(
        m, pcw.Thresholds(context_tokens=1, accumulated_cost_usd=0.001),
    )
    assert warning is not None
    assert warning.savings_usd == pytest.approx(0.0, abs=0.001)


# --- format_warning --------------------------------------------------------


def test_format_warning_includes_actual_savings_dollar_amount(tmp_path):
    """Assert the EXACT dollar figure, not just `'$' in text` (which would
    pass even with a broken savings calculation — the same lesson PR #43
    learned with the bare `'60'` false positive)."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=500, cache_read=30_000_000),
    ])
    m = pcw.compute_session_metrics(f)
    warning = pcw.should_warn(m, pcw.Thresholds())
    text = pcw.format_warning(warning, m)
    # Build the expected dollar string from the warning math itself, then
    # assert it appears literally in the text. If format_warning changes
    # the layout, this fails loudly.
    expected_savings = f"${warning.savings_usd:.2f}"
    assert expected_savings in text, (
        f"format_warning did not render the savings dollar amount {expected_savings!r}"
    )
    expected_pct = f"{warning.savings_pct:.0f}%"
    assert expected_pct in text
    assert "/clear" in text


def test_format_warning_renders_each_tripped_reason_label(tmp_path):
    """Assert that EVERY label of EVERY tripped reason appears in the
    text. Previous version used a loose `any(... in ('cost', 'cache'))`
    match that would pass on the static header `'obsly-ai: prompt cost
    warning'` regardless of which reasons fired."""
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=500, cache_read=30_000_000),
    ])
    m = pcw.compute_session_metrics(f)
    warning = pcw.should_warn(m, pcw.Thresholds())
    assert warning is not None
    assert len(warning.reasons) >= 1
    text = pcw.format_warning(warning, m)
    for reason in warning.reasons:
        label = pcw._REASON_LABELS.get(reason, reason)
        assert label in text, (
            f"format_warning did not mention the tripped reason {reason!r} "
            f"(expected label {label!r})"
        )


# --- Thresholds.from_config_file -------------------------------------------


def test_thresholds_from_config_file_uses_defaults_when_missing(tmp_path):
    t = pcw.Thresholds.from_config_file(tmp_path / "missing.json")
    defaults = pcw.Thresholds()
    assert t.context_tokens == defaults.context_tokens
    assert t.accumulated_cost_usd == defaults.accumulated_cost_usd


def test_thresholds_from_config_file_overrides_keys(tmp_path):
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({
        "prompt_cost_warning": {
            "context_tokens": 50_000,
            "accumulated_cost_usd": 5.0,
            "cache_ratio": 50,
            "session_age_seconds": 1800,
        }
    }))
    t = pcw.Thresholds.from_config_file(cfg)
    assert t.context_tokens == 50_000
    assert t.accumulated_cost_usd == 5.0
    assert t.cache_ratio == 50
    assert t.session_age_seconds == 1800


def test_thresholds_from_config_file_partial_keeps_defaults(tmp_path):
    """Only override what is in the config; the rest stays at defaults."""
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({
        "prompt_cost_warning": {"context_tokens": 50_000}
    }))
    t = pcw.Thresholds.from_config_file(cfg)
    defaults = pcw.Thresholds()
    assert t.context_tokens == 50_000
    assert t.accumulated_cost_usd == defaults.accumulated_cost_usd


def test_thresholds_from_config_file_malformed_json_uses_defaults(tmp_path):
    cfg = tmp_path / "config.json"
    cfg.write_text("not json {{{")
    t = pcw.Thresholds.from_config_file(cfg)
    defaults = pcw.Thresholds()
    assert t.context_tokens == defaults.context_tokens


# --- CLI -------------------------------------------------------------------


def _run_cli(stdin_text: str):
    """Helper: run the CLI with a fake stdin and capture stderr."""
    from claudedashboard.gitai import prompt_cost_warning_cli as cli
    stdin = io.StringIO(stdin_text)
    stderr = io.StringIO()
    code = cli.main(stdin=stdin, stderr=stderr)
    return code, stderr.getvalue()


def test_cli_emits_warning_when_threshold_crossed(tmp_path):
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=100, output_tokens=500, cache_read=30_000_000),
    ])
    code, err = _run_cli(json.dumps({
        "hook_event_name": "UserPromptSubmit",
        "transcript_path": str(f),
    }))
    assert code == 0
    assert "obsly-ai" in err
    assert "/clear" in err


def test_cli_silent_when_below_thresholds(tmp_path):
    f = _write_jsonl(tmp_path / "s.jsonl", [
        _mk_message(input_tokens=10, output_tokens=10, cache_read=100),
    ])
    code, err = _run_cli(json.dumps({
        "hook_event_name": "UserPromptSubmit",
        "transcript_path": str(f),
    }))
    assert code == 0
    assert err == ""


def test_cli_silent_when_transcript_missing():
    code, err = _run_cli(json.dumps({
        "hook_event_name": "UserPromptSubmit",
        "transcript_path": "/does/not/exist.jsonl",
    }))
    assert code == 0
    assert err == ""


def test_cli_silent_when_no_transcript_path():
    code, err = _run_cli(json.dumps({"hook_event_name": "UserPromptSubmit"}))
    assert code == 0
    assert err == ""


def test_cli_silent_on_malformed_json():
    code, err = _run_cli("not json {{{")
    assert code == 0
    assert err == ""


def test_cli_silent_on_empty_stdin():
    code, err = _run_cli("")
    assert code == 0
    assert err == ""


def test_cli_silent_on_non_dict_payload():
    code, err = _run_cli(json.dumps([1, 2, 3]))
    assert code == 0
    assert err == ""


def test_cli_never_raises_even_on_unparseable_payload():
    """The CLI is a hook — it MUST exit 0 silently. Verify with several
    pathological inputs."""
    for bad in (
        "\x00\x01\x02",
        '{"transcript_path": null}',
        '{"transcript_path": 12345}',
        json.dumps({"transcript_path": "/dev/null"}),
    ):
        code, _ = _run_cli(bad)
        assert code == 0
