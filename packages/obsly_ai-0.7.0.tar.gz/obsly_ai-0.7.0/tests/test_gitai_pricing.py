"""Pricing dict + cost calculator (stdlib only, no proxy dep)."""


def test_calc_cost_sonnet():
    from claudedashboard.gitai.pricing import calc_cost
    # 1M input + 1M output of sonnet → $3 + $15
    assert calc_cost("claude-sonnet-4-6", 1_000_000, 1_000_000, 0, 0) == 18.0


def test_calc_cost_with_cache():
    from claudedashboard.gitai.pricing import calc_cost
    c = calc_cost("claude-sonnet-4-6", 0, 0, cache_read=1_000_000, cache_create=0)
    assert c == 0.30


def test_calc_cost_unknown_model_uses_default():
    from claudedashboard.gitai.pricing import calc_cost
    c = calc_cost("totally-made-up-model", 1_000_000, 0, 0, 0)
    assert c > 0  # falls back to DEFAULT_PRICING


def test_match_model_strips_date_suffix():
    from claudedashboard.gitai.pricing import match_model
    assert match_model("claude-sonnet-4-6-20250514") == "claude-sonnet-4-6"
    assert match_model("claude-opus-4-6") == "claude-opus-4-6"
    assert match_model(None) is None
    assert match_model("") is None
