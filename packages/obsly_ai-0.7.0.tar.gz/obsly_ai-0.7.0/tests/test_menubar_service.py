"""Tests for the menubar_service orchestration module."""

import sys
from pathlib import Path

import pytest

from claudedashboard import menubar_service as svc
from claudedashboard.gitai import launchd


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    return tmp_path


class _PlistRecorder:
    def __init__(self, target):
        self.calls = []
        self.target = target

    def __call__(self, name, program_args, **kwargs):
        self.calls.append({"name": name, "program_args": list(program_args), **kwargs})
        self.target.parent.mkdir(parents=True, exist_ok=True)
        self.target.write_bytes(b"<plist/>")
        return self.target


@pytest.fixture
def recorder(fake_home, monkeypatch):
    target = launchd.plist_path("menubar")
    rec = _PlistRecorder(target)
    monkeypatch.setattr(launchd, "write_plist", rec)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (True, ""))
    return rec


# ── _logs_dir ─────────────────────────────────────────────────────────

def test_logs_dir_created_under_obsly_ai(fake_home):
    d = svc._logs_dir()
    assert d == fake_home / ".obsly-ai" / "logs"
    assert d.exists()
    assert d.is_dir()


# ── install ───────────────────────────────────────────────────────────

def test_install_writes_plist_via_launchd_module(fake_home, recorder):
    svc.install()
    assert len(recorder.calls) == 1
    call = recorder.calls[0]
    assert call["name"] == "menubar"
    assert call["keep_alive"] is True
    assert call["run_at_load"] is True
    assert call["program_args"][-2:] == ["menubar", "run"]


def test_install_passes_log_paths_to_plist(fake_home, recorder):
    svc.install()
    call = recorder.calls[0]
    assert call["stderr_path"].endswith(".obsly-ai/logs/menubar.err")
    assert call["stdout_path"].endswith(".obsly-ai/logs/menubar.out")


def test_install_creates_logs_dir(fake_home, recorder):
    logs = fake_home / ".obsly-ai" / "logs"
    assert not logs.exists()
    svc.install()
    assert logs.exists()


def test_install_calls_bootstrap_after_writing_plist(fake_home, monkeypatch):
    order = []
    target = launchd.plist_path("menubar")

    def fake_write(name, program_args, **kwargs):
        order.append(("write_plist", name))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"x")
        return target

    def fake_bootstrap(name):
        order.append(("bootstrap", name))
        return (True, "")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", fake_bootstrap)

    svc.install()
    assert order == [("write_plist", "menubar"), ("bootstrap", "menubar")]


def test_install_returns_dict_with_plist_and_bootstrap_status(fake_home, recorder):
    result = svc.install()
    assert "plist" in result
    assert "bootstrap_ok" in result
    assert "bootstrap_msg" in result
    assert result["bootstrap_ok"] is True


def test_install_returns_failure_when_bootstrap_fails(fake_home, monkeypatch):
    target = launchd.plist_path("menubar")

    def fake_write(name, program_args, **kwargs):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"x")
        return target

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (False, "some error"))

    result = svc.install()
    assert result["bootstrap_ok"] is False
    assert result["bootstrap_msg"] == "some error"
    assert target.exists()


def test_install_dry_run_does_not_write_plist_or_bootstrap(fake_home, monkeypatch):
    calls = {"write": 0, "boot": 0}

    def fake_write(*a, **kw):
        calls["write"] += 1
        return launchd.plist_path("menubar")

    def fake_boot(name):
        calls["boot"] += 1
        return (True, "")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", fake_boot)

    result = svc.install(dry_run=True)
    assert calls["write"] == 0
    assert calls["boot"] == 0
    assert not launchd.plist_path("menubar").exists()
    assert "plist" in result
    assert "bootstrap_ok" in result
    assert "bootstrap_msg" in result


def test_install_program_args_invokes_python_module_cli(fake_home, recorder):
    svc.install()
    args = recorder.calls[0]["program_args"]
    assert args[0] == sys.executable
    assert args[1:] == ["-m", "claudedashboard.cli", "menubar", "run"]


# ── uninstall ─────────────────────────────────────────────────────────

def test_uninstall_calls_launchd_uninstall(fake_home, monkeypatch):
    recorded = []

    def fake_uninstall(name):
        recorded.append(name)
        return True

    monkeypatch.setattr(launchd, "uninstall", fake_uninstall)
    result = svc.uninstall()
    assert recorded == ["menubar"]
    assert result["removed"] is True
    assert "plist" in result


def test_uninstall_returns_false_when_not_installed(fake_home, monkeypatch):
    monkeypatch.setattr(launchd, "uninstall", lambda name: False)
    result = svc.uninstall()
    assert result["removed"] is False


def test_uninstall_dry_run_does_not_call_launchd(fake_home, monkeypatch):
    calls = []
    monkeypatch.setattr(launchd, "uninstall", lambda name: calls.append(name) or True)
    result = svc.uninstall(dry_run=True)
    assert calls == []
    assert result["removed"] is False
    assert "plist" in result


# ── status ────────────────────────────────────────────────────────────

def test_status_passes_through_to_launchd(fake_home, monkeypatch):
    for state in ("running", "stopped", "not_installed"):
        monkeypatch.setattr(launchd, "status", lambda name, s=state: s)
        assert svc.status() == state
