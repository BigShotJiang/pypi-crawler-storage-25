"""TDD for CLI ai-* subcommand wiring — red to green."""
import subprocess, sys
import pytest


def _run(cmd):
    return subprocess.run(
        [sys.executable, "-m", "claudedashboard"] + cmd,
        capture_output=True, text=True, timeout=10,
    )


class TestCliWiring:

    def test_version_still_works(self):
        r = _run(["version"])
        assert r.returncode == 0
        assert "claude-dashboard" in r.stdout

    def test_ai_status_runs(self):
        r = _run(["ai-status"])
        assert r.returncode == 0

    def test_ai_blame_missing_file_errors(self):
        r = _run(["ai-blame"])
        assert r.returncode != 0  # missing required arg

    def test_ai_stats_runs(self):
        r = _run(["ai-stats"])
        # May show "no notes" but should not crash
        assert r.returncode == 0

    def test_ai_install_dry_run(self):
        r = _run(["ai-install", "--dry-run"])
        assert r.returncode == 0
        assert "dry-run" in r.stdout.lower() or "install" in r.stdout.lower() or r.stdout == ""

    def test_ai_cleanup_runs(self):
        r = _run(["ai-cleanup"])
        assert r.returncode == 0

    # ── Rename: `install` is the new canonical name (#29) ────────────
    def test_install_dry_run_works(self):
        r = _run(["install", "--dry-run"])
        assert r.returncode == 0

    def test_uninstall_dry_run_works(self):
        r = _run(["uninstall", "--dry-run"])
        assert r.returncode == 0

    def test_status_runs(self):
        r = _run(["status"])
        assert r.returncode == 0

    def test_ai_install_alias_prints_deprecation(self):
        r = _run(["ai-install", "--dry-run"])
        assert r.returncode == 0
        assert "deprecated" in r.stderr.lower()
        assert "install" in r.stderr.lower()

    def test_ai_uninstall_alias_prints_deprecation(self):
        r = _run(["ai-uninstall", "--dry-run"])
        assert r.returncode == 0
        assert "deprecated" in r.stderr.lower()

    def test_ai_status_alias_prints_deprecation(self):
        r = _run(["ai-status"])
        assert r.returncode == 0
        assert "deprecated" in r.stderr.lower()

    def test_ai_help(self):
        r = _run(["ai-install", "--help"])
        assert r.returncode == 0
        assert "agent" in r.stdout.lower() or "install" in r.stdout.lower()
