"""Tests for the proxy_service launchd orchestration module."""

from pathlib import Path

import pytest

from claudedashboard import proxy_service as svc
from claudedashboard.gitai import launchd


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    # Default: no HTTPS_PROXY set
    monkeypatch.delenv("HTTPS_PROXY", raising=False)
    monkeypatch.delenv("https_proxy", raising=False)
    return tmp_path


class _PlistRecorder:
    def __init__(self, target):
        self.calls = []
        self.target = target

    def __call__(self, name, program_args, **kwargs):
        self.calls.append({"name": name, "program_args": list(program_args), **kwargs})
        self.target.parent.mkdir(parents=True, exist_ok=True)
        self.target.write_bytes(b"<plist/>")
        return self.target


@pytest.fixture
def recorder(fake_home, monkeypatch):
    target = launchd.plist_path("proxy")
    rec = _PlistRecorder(target)
    monkeypatch.setattr(launchd, "write_plist", rec)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (True, ""))
    # Pretend mitmdump is installed
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which",
        lambda binary: "/usr/local/bin/mitmdump" if binary == "mitmdump" else None,
    )
    return rec


# ── _logs_dir ─────────────────────────────────────────────────────────

def test_logs_dir_created_under_obsly_ai(fake_home):
    d = svc._logs_dir()
    assert d == fake_home / ".obsly-ai" / "logs"
    assert d.exists()
    assert d.is_dir()


# ── install ───────────────────────────────────────────────────────────

def test_install_writes_plist_via_launchd_module(fake_home, recorder):
    svc.install()
    assert len(recorder.calls) == 1
    call = recorder.calls[0]
    assert call["name"] == "proxy"
    assert call["keep_alive"] is True
    assert call["run_at_load"] is True
    args = call["program_args"]
    assert args[0] == "/usr/local/bin/mitmdump"
    assert "--listen-port" in args
    idx = args.index("--listen-port")
    assert args[idx + 1] == "8080"
    assert "-s" in args
    sidx = args.index("-s")
    assert args[sidx + 1].endswith("claudedashboard/proxy/addon.py")


def test_install_passes_log_paths(fake_home, recorder):
    svc.install()
    call = recorder.calls[0]
    assert call["stderr_path"].endswith(".obsly-ai/logs/proxy.err")
    assert call["stdout_path"].endswith(".obsly-ai/logs/proxy.out")


def test_install_passes_events_path_env(fake_home, recorder):
    svc.install()
    call = recorder.calls[0]
    env = call.get("env")
    assert env is not None
    assert "LLM_PROXY_STORE_PATH" in env
    assert env["LLM_PROXY_STORE_PATH"]  # non-empty


def test_install_creates_logs_dir(fake_home, recorder):
    logs = fake_home / ".obsly-ai" / "logs"
    assert not logs.exists()
    svc.install()
    assert logs.exists()


def test_install_calls_bootstrap_after_writing_plist(fake_home, monkeypatch):
    order = []
    target = launchd.plist_path("proxy")

    def fake_write(name, program_args, **kwargs):
        order.append(("write_plist", name))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"x")
        return target

    def fake_bootstrap(name):
        order.append(("bootstrap", name))
        return (True, "")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", fake_bootstrap)
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which",
        lambda binary: "/usr/local/bin/mitmdump",
    )

    svc.install()
    assert order == [("write_plist", "proxy"), ("bootstrap", "proxy")]


def test_install_returns_dict_with_expected_keys(fake_home, recorder):
    result = svc.install()
    for key in ("plist", "bootstrap_ok", "bootstrap_msg", "refused", "reason"):
        assert key in result
    assert result["refused"] is False
    assert result["bootstrap_ok"] is True


def test_install_returns_failure_when_bootstrap_fails(fake_home, monkeypatch):
    target = launchd.plist_path("proxy")

    def fake_write(name, program_args, **kwargs):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"x")
        return target

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (False, "some error"))
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which",
        lambda binary: "/usr/local/bin/mitmdump",
    )

    result = svc.install()
    assert result["bootstrap_ok"] is False
    assert result["bootstrap_msg"] == "some error"
    assert target.exists()


def test_install_dry_run_does_not_write_or_bootstrap(fake_home, monkeypatch):
    calls = {"write": 0, "boot": 0}

    def fake_write(*a, **kw):
        calls["write"] += 1
        return launchd.plist_path("proxy")

    def fake_boot(name):
        calls["boot"] += 1
        return (True, "")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", fake_boot)
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which",
        lambda binary: "/usr/local/bin/mitmdump",
    )

    result = svc.install(dry_run=True)
    assert calls["write"] == 0
    assert calls["boot"] == 0
    assert not launchd.plist_path("proxy").exists()
    for key in ("plist", "bootstrap_ok", "bootstrap_msg", "refused", "reason"):
        assert key in result


def test_install_refuses_when_mitmdump_not_found(fake_home, monkeypatch):
    calls = {"write": 0}

    def fake_write(*a, **kw):
        calls["write"] += 1
        return launchd.plist_path("proxy")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (True, ""))
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which", lambda binary: None
    )

    result = svc.install()
    assert result["refused"] is True
    assert "mitmdump" in (result["reason"] or "")
    assert calls["write"] == 0


def test_install_refuses_when_https_proxy_conflicts(fake_home, monkeypatch):
    calls = {"write": 0}

    def fake_write(*a, **kw):
        calls["write"] += 1
        return launchd.plist_path("proxy")

    monkeypatch.setattr(launchd, "write_plist", fake_write)
    monkeypatch.setattr(launchd, "bootstrap", lambda name: (True, ""))
    monkeypatch.setattr(
        "claudedashboard.proxy_service.shutil.which",
        lambda binary: "/usr/local/bin/mitmdump",
    )
    monkeypatch.setenv("HTTPS_PROXY", "http://corporate.example:3128")

    result = svc.install()
    assert result["refused"] is True
    assert "HTTPS_PROXY" in (result["reason"] or "")
    assert calls["write"] == 0


def test_install_proceeds_when_https_proxy_is_localhost_8080(fake_home, recorder, monkeypatch):
    monkeypatch.setenv("HTTPS_PROXY", "http://localhost:8080")
    result = svc.install()
    assert result["refused"] is False
    assert len(recorder.calls) == 1


def test_install_proceeds_when_https_proxy_is_127_0_0_1_8080(fake_home, recorder, monkeypatch):
    monkeypatch.setenv("HTTPS_PROXY", "http://127.0.0.1:8080")
    result = svc.install()
    assert result["refused"] is False
    assert len(recorder.calls) == 1


def test_install_proceeds_when_https_proxy_unset(fake_home, recorder):
    result = svc.install()
    assert result["refused"] is False
    assert len(recorder.calls) == 1


# ── uninstall ─────────────────────────────────────────────────────────

def test_uninstall_calls_launchd_uninstall(fake_home, monkeypatch):
    recorded = []

    def fake_uninstall(name):
        recorded.append(name)
        return True

    monkeypatch.setattr(launchd, "uninstall", fake_uninstall)
    result = svc.uninstall()
    assert recorded == ["proxy"]
    assert result["removed"] is True
    assert "plist" in result


def test_uninstall_returns_false_when_not_installed(fake_home, monkeypatch):
    monkeypatch.setattr(launchd, "uninstall", lambda name: False)
    result = svc.uninstall()
    assert result["removed"] is False


def test_uninstall_dry_run_does_not_call_launchd(fake_home, monkeypatch):
    calls = []
    monkeypatch.setattr(launchd, "uninstall", lambda name: calls.append(name) or True)
    result = svc.uninstall(dry_run=True)
    assert calls == []
    assert result["removed"] is False
    assert "plist" in result


# ── status ────────────────────────────────────────────────────────────

def test_status_passes_through_to_launchd(fake_home, monkeypatch):
    for state in ("running", "stopped", "not_installed"):
        monkeypatch.setattr(launchd, "status", lambda name, s=state: s)
        assert svc.status() == state


# ── helpers ───────────────────────────────────────────────────────────

def test_addon_path_points_to_proxy_addon_py():
    p = svc._addon_path()
    assert p.endswith("claudedashboard/proxy/addon.py")
    assert Path(p).exists()


def test_events_path_falls_back_when_load_config_fails(fake_home, monkeypatch):
    def boom():
        raise RuntimeError("nope")

    import claudedashboard.proxy.commands as pcmd
    monkeypatch.setattr(pcmd, "_load_config", boom)
    result = svc._events_path()
    assert result.endswith(".claude/proxy_events.jsonl")
