import pytest
from claudedashboard.gitai.usage_adapters.aider import (
    AiderAdapter, parse_footers, session_id_for_repo, _parse_token_count,
)


def test_parse_token_count_no_suffix():
    assert _parse_token_count("345", "") == 345


def test_parse_token_count_k_lowercase():
    assert _parse_token_count("1.2", "k") == 1200


def test_parse_token_count_k_uppercase():
    assert _parse_token_count("2.5", "K") == 2500


def test_parse_token_count_integer_with_k():
    assert _parse_token_count("3", "k") == 3000


def test_parse_footers_modern_format():
    text = "> Tokens: 1.2k sent, 345 received. Cost: $0.0234 message, $0.0567 session."
    footers = parse_footers(text)
    assert len(footers) == 1
    assert footers[0]["tokens_in"] == 1200
    assert footers[0]["tokens_out"] == 345
    assert footers[0]["cost_usd"] == 0.0234


def test_parse_footers_older_format_request():
    text = "> Tokens: 567 sent, 89 received. Cost: $0.01 request, $0.10 session."
    footers = parse_footers(text)
    assert len(footers) == 1
    assert footers[0]["tokens_in"] == 567
    assert footers[0]["tokens_out"] == 89
    assert footers[0]["cost_usd"] == 0.01


def test_parse_footers_without_leading_quote():
    text = "Tokens: 100 sent, 50 received. Cost: $0.001 message, $0.002 session."
    footers = parse_footers(text)
    assert len(footers) == 1
    assert footers[0]["tokens_in"] == 100


def test_parse_footers_multiple_in_text():
    text = (
        "Some markdown here.\n"
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
        "Some other content.\n"
        "> Tokens: 2k sent, 400 received. Cost: $0.10 message, $0.15 session.\n"
    )
    footers = parse_footers(text)
    assert len(footers) == 2
    assert footers[0]["tokens_in"] == 1000
    assert footers[1]["tokens_in"] == 2000
    assert footers[1]["cost_usd"] == 0.10


def test_parse_footers_empty_string():
    assert parse_footers("") == []


def test_parse_footers_no_match():
    assert parse_footers("Just some markdown without any token footer.") == []


def test_session_id_for_repo_uses_basename():
    assert session_id_for_repo("/Users/foo/myrepo") == "aider:myrepo"
    assert session_id_for_repo("/tmp/another") == "aider:another"


def test_session_id_for_repo_handles_trailing_slash():
    assert session_id_for_repo("/Users/foo/myrepo/") == "aider:myrepo"


def test_records_empty_when_no_history_file(tmp_path):
    a = AiderAdapter(search_paths=[tmp_path])
    assert a.records_for_session("aider:" + tmp_path.name) == []


def test_records_empty_when_session_id_mismatch(tmp_path):
    (tmp_path / ".aider.chat.history.md").write_text(
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
    )
    a = AiderAdapter(search_paths=[tmp_path])
    assert a.records_for_session("aider:other-repo") == []


def test_records_empty_when_session_id_empty(tmp_path):
    (tmp_path / ".aider.chat.history.md").write_text(
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
    )
    a = AiderAdapter(search_paths=[tmp_path])
    assert a.records_for_session("") == []


def test_records_for_session_returns_all_footers(tmp_path):
    (tmp_path / ".aider.chat.history.md").write_text(
        "Markdown content.\n"
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
        "More content.\n"
        "> Tokens: 2k sent, 400 received. Cost: $0.10 message, $0.15 session.\n"
    )
    a = AiderAdapter(search_paths=[tmp_path])
    records = a.records_for_session("aider:" + tmp_path.name)
    assert len(records) == 2
    assert records[0].agent == "aider"
    assert records[0].tokens_in == 1000
    assert records[0].equivalent_api_cost_usd == 0.05
    assert records[1].tokens_in == 2000


def test_records_includes_timestamp_from_mtime(tmp_path):
    (tmp_path / ".aider.chat.history.md").write_text(
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
    )
    a = AiderAdapter(search_paths=[tmp_path])
    records = a.records_for_session("aider:" + tmp_path.name)
    assert len(records) == 1
    assert "T" in records[0].timestamp  # ISO format includes 'T'


def test_records_handles_corrupted_file_gracefully(tmp_path):
    f = tmp_path / ".aider.chat.history.md"
    f.write_bytes(b"\x00\x01\x02 garbage \xff bytes")
    a = AiderAdapter(search_paths=[tmp_path])
    records = a.records_for_session("aider:" + tmp_path.name)
    # No footers parsed -> empty list, no exception
    assert records == []


def test_default_search_paths_uses_cwd(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".aider.chat.history.md").write_text(
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
    )
    a = AiderAdapter()  # no search_paths
    records = a.records_for_session("aider:" + tmp_path.name)
    assert len(records) == 1


def test_cost_for_session_sums_all_footers(tmp_path):
    (tmp_path / ".aider.chat.history.md").write_text(
        "> Tokens: 1k sent, 200 received. Cost: $0.05 message, $0.05 session.\n"
        "> Tokens: 2k sent, 400 received. Cost: $0.10 message, $0.15 session.\n"
    )
    a = AiderAdapter(search_paths=[tmp_path])
    assert a.cost_for_session("aider:" + tmp_path.name) == 0.15


def test_adapter_is_registered_in_all_adapters():
    from claudedashboard.gitai.usage_adapters import all_adapters
    adapters = all_adapters()
    assert any(a.agent == "aider" for a in adapters)
