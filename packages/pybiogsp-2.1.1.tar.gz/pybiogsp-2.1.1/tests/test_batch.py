"""
Tests for batch SGWT and SGCC pair operations.
"""
import numpy as np
import pandas as pd
import pytest
from pybiogsp import SGWT


def _make_sg(n_signals=10, n_nodes=200, seed=42):
    """Helper: build a test SGWT object with random signals."""
    np.random.seed(seed)
    coords = np.random.rand(n_nodes, 2) * 100
    signals = {f"sig_{i}": np.random.randn(n_nodes) for i in range(n_signals)}
    df = pd.DataFrame({"X": coords[:, 0], "Y": coords[:, 1], **signals})
    sg = SGWT(df, x_col="X", y_col="Y", signals=list(signals.keys()), J=3)
    sg.build_graph(k=10, laplacian_type="normalized", verbose=False)
    return sg


# ======================================================================
# Phase 1: batch cheby / jackson vs individual
# ======================================================================


class TestBatchSGWT:

    def test_cheby_batch_vs_individual(self):
        sg_batch = _make_sg(n_signals=5)
        sg_batch.run_sgwt(method="cheby", verbose=False)

        for name in sg_batch.Data.signals:
            sg_ind = _make_sg(n_signals=5)
            # Override to single signal
            sg_ind.Data.signals = [name]
            sg_ind.run_sgwt(method="cheby", verbose=False)

            for key in sg_ind.Forward[name]["vertex_coefficients"]:
                np.testing.assert_allclose(
                    sg_batch.Forward[name]["vertex_coefficients"][key],
                    sg_ind.Forward[name]["vertex_coefficients"][key],
                    atol=1e-10,
                    err_msg=f"cheby mismatch: {name}/{key}",
                )

    def test_jackson_batch_vs_individual(self):
        sg_batch = _make_sg(n_signals=5)
        sg_batch.run_sgwt(method="jackson", verbose=False)

        for name in sg_batch.Data.signals:
            sg_ind = _make_sg(n_signals=5)
            sg_ind.Data.signals = [name]
            sg_ind.run_sgwt(method="jackson", verbose=False)

            for key in sg_ind.Forward[name]["vertex_coefficients"]:
                np.testing.assert_allclose(
                    sg_batch.Forward[name]["vertex_coefficients"][key],
                    sg_ind.Forward[name]["vertex_coefficients"][key],
                    atol=1e-10,
                    err_msg=f"jackson mismatch: {name}/{key}",
                )

    def test_single_signal_cheby(self):
        sg = _make_sg(n_signals=1)
        sg.run_sgwt(method="cheby", verbose=False)
        assert "sig_0" in sg.Forward

    def test_reconstruction_error_matches(self):
        sg_batch = _make_sg(n_signals=5)
        sg_batch.run_sgwt(method="cheby", verbose=False)

        for name in sg_batch.Data.signals:
            sg_ind = _make_sg(n_signals=5)
            sg_ind.Data.signals = [name]
            sg_ind.run_sgwt(method="cheby", verbose=False)

            np.testing.assert_allclose(
                sg_batch.Inverse[name]["reconstruction_error"],
                sg_ind.Inverse[name]["reconstruction_error"],
                atol=1e-10,
                err_msg=f"recon error mismatch: {name}",
            )

    def test_lanczos_still_works(self):
        sg = _make_sg(n_signals=3)
        sg.run_sgwt(method="lanczos", verbose=False)
        assert len(sg.Forward) == 3

    def test_arma_still_works(self):
        sg = _make_sg(n_signals=3)
        sg.run_sgwt(method="arma", verbose=False)
        assert len(sg.Forward) == 3


# ======================================================================
# Phase 2: run_sgcc_pairs vs individual run_sgcc
# ======================================================================


class TestSGCCPairs:

    @pytest.fixture
    def sg_cheby(self):
        sg = _make_sg(n_signals=10)
        sg.run_sgwt(method="cheby", verbose=False)
        return sg

    @pytest.fixture
    def sg_jackson(self):
        sg = _make_sg(n_signals=10)
        sg.run_sgwt(method="jackson", verbose=False)
        return sg

    def test_pairs_vs_individual(self, sg_cheby):
        pairs = [("sig_0", "sig_1"), ("sig_2", "sig_3"), ("sig_0", "sig_9")]
        df_pairs = sg_cheby.run_sgcc_pairs(pairs)

        for _, row in df_pairs.iterrows():
            individual = sg_cheby.run_sgcc(
                row["signal1"], row["signal2"], return_parts=True,
            )
            np.testing.assert_allclose(
                row["c_low"], individual["c_low"], atol=1e-10,
            )
            np.testing.assert_allclose(
                row["c_nonlow"], individual["c_nonlow"], atol=1e-10,
            )
            np.testing.assert_allclose(
                row["S"], individual["S"], atol=1e-10,
            )
            np.testing.assert_allclose(
                row["w_low"], individual["w_low"], atol=1e-10,
            )

    def test_pairs_returns_dataframe(self, sg_cheby):
        pairs = [("sig_0", "sig_1"), ("sig_2", "sig_3")]
        result = sg_cheby.run_sgcc_pairs(pairs)
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert set(result.columns) == {
            "signal1", "signal2", "c_low", "c_nonlow",
            "w_low", "w_NL", "S",
        }

    def test_pairs_empty_list(self, sg_cheby):
        result = sg_cheby.run_sgcc_pairs([])
        assert len(result) == 0

    def test_pairs_with_jackson(self, sg_jackson):
        pairs = [("sig_0", "sig_5")]
        df_pairs = sg_jackson.run_sgcc_pairs(pairs)
        individual = sg_jackson.run_sgcc("sig_0", "sig_5", return_parts=True)
        np.testing.assert_allclose(
            df_pairs.iloc[0]["S"], individual["S"], atol=1e-10,
        )

    def test_pairs_no_forward_raises(self):
        df = pd.DataFrame({"X": [0, 1], "Y": [0, 1], "s0": [1, 2], "s1": [3, 4]})
        sg = SGWT(df, x_col="X", y_col="Y", signals=["s0", "s1"])
        with pytest.raises(ValueError, match="run_sgwt"):
            sg.run_sgcc_pairs([("s0", "s1")])

    def test_pairs_matches_matrix_diagonal(self, sg_cheby):
        """Spot-check: pairs result matches run_sgcc_matrix values."""
        pairs = [("sig_0", "sig_1"), ("sig_3", "sig_7")]
        df_pairs = sg_cheby.run_sgcc_pairs(pairs)
        S_mat = sg_cheby.run_sgcc_matrix()

        for _, row in df_pairs.iterrows():
            np.testing.assert_allclose(
                row["S"],
                S_mat.loc[row["signal1"], row["signal2"]],
                atol=1e-10,
            )
