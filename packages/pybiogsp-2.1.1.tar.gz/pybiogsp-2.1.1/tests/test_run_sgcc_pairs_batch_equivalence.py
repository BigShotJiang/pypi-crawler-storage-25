"""
Equivalence test for the batch-fast-path optimization in
``SGWT.run_sgcc_pairs``.

The patched version caches the dense (n_nodes, n_signals) matrices that
``_run_sgwt_approx`` already produces for cheby / jackson, and reuses
them in ``run_sgcc_pairs`` instead of rebuilding via per-signal Python
loop + ``np.column_stack``.

This test:
  1. Builds a small SGWT, runs cheby in batch mode → fast path is used.
  2. Records the resulting SGCC DataFrame.
  3. Clears ``_batch_vc`` and calls ``run_sgcc_pairs`` again → forces the
     legacy per-signal path.
  4. Asserts the two DataFrames are numerically equal.

Runs in <2 s.
"""
import numpy as np
import pandas as pd
import pytest

from pybiogsp import SGWT


def _make_sgwt(n_nodes=400, n_signals=120, J=3, seed=0):
    """Small synthetic SGWT object with batched cheby ready to consume."""
    rng = np.random.default_rng(seed)
    coords = rng.uniform(0, 1, size=(n_nodes, 2))
    sig_names = [f"sig_{i}" for i in range(n_signals)]
    sig_data = {s: rng.standard_normal(n_nodes) for s in sig_names}
    df = pd.concat(
        [pd.DataFrame(coords, columns=["X", "Y"]),
         pd.DataFrame(sig_data)],
        axis=1,
    )
    sg = SGWT(df, x_col="X", y_col="Y", signals=sig_names,
              J=J, scaling_factor=2.0, kernel_type="heat")
    sg.build_graph(k=8, laplacian_type="normalized", verbose=False)
    sg.run_sgwt(method="cheby", verbose=False)
    return sg, sig_names


def test_batch_fast_path_matches_legacy():
    sg, names = _make_sgwt()
    pairs = [(names[i], names[(i + 7) % len(names)]) for i in range(50)]

    # Fast path (uses cached _batch_vc set by _run_sgwt_approx)
    assert hasattr(sg, "_batch_vc") and sg._batch_vc is not None, (
        "Patched _run_sgwt_approx should populate self._batch_vc"
    )
    df_fast = sg.run_sgcc_pairs(pairs)

    # Legacy path: clear cache, force original per-signal code
    sg._batch_vc = None
    df_legacy = sg.run_sgcc_pairs(pairs)

    # Same row order
    assert list(df_fast["signal1"]) == list(df_legacy["signal1"])
    assert list(df_fast["signal2"]) == list(df_legacy["signal2"])

    # Numerical equivalence on every score column
    for col in ("c_low", "c_nonlow", "w_low", "w_NL", "S"):
        np.testing.assert_allclose(
            df_fast[col].values,
            df_legacy[col].values,
            rtol=1e-10, atol=1e-12,
            err_msg=f"column {col!r} diverged between fast and legacy paths",
        )


def test_non_batched_method_falls_back():
    """lanczos / arma / single-signal don't set _batch_vc; legacy path runs."""
    rng = np.random.default_rng(1)
    n_nodes = 200
    df = pd.DataFrame(rng.uniform(0, 1, size=(n_nodes, 2)), columns=["X", "Y"])
    df["sig_a"] = rng.standard_normal(n_nodes)
    df["sig_b"] = rng.standard_normal(n_nodes)

    sg = SGWT(df, signals=["sig_a", "sig_b"], J=2, kernel_type="heat")
    sg.build_graph(k=6, verbose=False)
    sg.run_sgwt(method="lanczos", verbose=False)

    assert getattr(sg, "_batch_vc", None) is None, (
        "Non-batched methods must not set _batch_vc"
    )
    df_out = sg.run_sgcc_pairs([("sig_a", "sig_b")])
    assert len(df_out) == 1
    assert {"c_low", "c_nonlow", "S"}.issubset(df_out.columns)


if __name__ == "__main__":
    test_batch_fast_path_matches_legacy()
    test_non_batched_method_falls_back()
    print("OK — batch-fast-path equivalence verified")
