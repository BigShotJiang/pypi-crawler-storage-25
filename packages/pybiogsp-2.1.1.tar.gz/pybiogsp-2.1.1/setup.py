"""
Setup script for PyBioGSP package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""

setup(
    name="pybiogsp",
    version="2.1.1",
    author="Yuzhou Chang",
    author_email="yuzhou.chang@osumc.edu",
    description="Biological Graph Signal Processing for Spatial Data Analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/BMEngineeR/PyBioGSP",
    project_urls={
        "Bug Reports": "https://github.com/BMEngineeR/PyBioGSP/issues",
        "Source": "https://github.com/BMEngineeR/PyBioGSP",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "Topic :: Scientific/Engineering :: Mathematics",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.20.0",
        "scipy>=1.7.0",
        "pandas>=1.3.0",
        "torch>=1.9.0",
        "scikit-learn>=0.24.0",
        "tqdm>=4.60.0",
    ],
    extras_require={
        "viz": [
            "matplotlib>=3.4.0",
            "seaborn>=0.11.0",
        ],
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.0.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
            "mypy>=0.900",
        ],
        "docs": [
            "sphinx>=7.0.0",
            "furo>=2024.1.29",
            "myst-parser>=2.0.0",
            "sphinx-autodoc-typehints>=2.0.0",
        ],
        "all": [
            "matplotlib>=3.4.0",
            "seaborn>=0.11.0",
            "pytest>=6.0.0",
            "pytest-cov>=2.0.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
            "mypy>=0.900",
        ],
    },
    keywords=[
        "graph signal processing",
        "spectral graph wavelet transform",
        "spatial transcriptomics",
        "single-cell analysis",
        "bioinformatics",
        "spatial biology",
    ],
    include_package_data=True,
    zip_safe=False,
)
