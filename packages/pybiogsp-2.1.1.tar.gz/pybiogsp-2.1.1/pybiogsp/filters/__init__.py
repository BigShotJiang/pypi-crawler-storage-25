"""
Filter approximation methods for eigendecomposition-free SGWT.

Submodules
----------
cheby    – Chebyshev polynomial approximation
jackson  – Jackson-damped Chebyshev (Gibbs suppression)
lanczos  – Lanczos (Krylov subspace) approximation
arma     – ARMA rational approximation
"""

from .cheby import (
    cheby_coefficients,
    cheby_op,
    sgwt_forward_cheby,
    sgwt_inverse_cheby,
)
from .jackson import (
    jackson_damping_coeffs,
    sgwt_forward_jackson,
    sgwt_inverse_jackson,
)
from .lanczos import (
    lanczos_basis,
    lanczos_filter_op,
    sgwt_forward_lanczos,
    sgwt_inverse_lanczos,
)
from .arma import (
    arma_rational_approx,
    arma_filter_op,
    sgwt_forward_arma,
    sgwt_inverse_arma,
)

__all__ = [
    # Chebyshev
    "cheby_coefficients",
    "cheby_op",
    "sgwt_forward_cheby",
    "sgwt_inverse_cheby",
    # Jackson
    "jackson_damping_coeffs",
    "sgwt_forward_jackson",
    "sgwt_inverse_jackson",
    # Lanczos
    "lanczos_basis",
    "lanczos_filter_op",
    "sgwt_forward_lanczos",
    "sgwt_inverse_lanczos",
    # ARMA
    "arma_rational_approx",
    "arma_filter_op",
    "sgwt_forward_arma",
    "sgwt_inverse_arma",
]
