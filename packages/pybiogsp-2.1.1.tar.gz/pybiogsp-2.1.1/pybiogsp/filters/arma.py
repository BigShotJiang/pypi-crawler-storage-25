"""
ARMA (Auto-Regressive Moving Average) rational approximation for SGWT filters.

Approximates each filter g(λ) by a partial-fraction rational function

    g(λ) ≈ Σ_{p=1}^{P}  b_p / (λ - a_p)

then evaluates  g(L)f  =  Σ  b_p · (L - a_p I)^{-1} f   via sparse linear
solves (one per pole).

Reference: Loukas et al. (2015) "Stationary signal processing on graphs";
ARMA filters on graphs (Isufi et al., 2017).
"""

import numpy as np
from scipy.sparse import eye as sparse_eye
from scipy.sparse.linalg import spsolve
from typing import Dict, Optional, Tuple

from ..core import sgwt_get_kernels
from .cheby import sgwt_inverse_cheby


def arma_rational_approx(
    g,
    P: int,
    arange: Tuple[float, float] = (0.0, 2.0),
    n_sample: int = 200,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Fit a partial-fraction rational approximation to a filter function.

    Samples g on [a, b], places P poles uniformly outside the interval
    (shifted left by a small margin), and solves a least-squares problem
    for the residues.

    Parameters
    ----------
    g : callable
        Filter function g(λ).
    P : int
        Number of poles (order of the rational approximation).
    arange : tuple of float
        Spectral interval [a, b].
    n_sample : int
        Number of sample points for the least-squares fit.

    Returns
    -------
    poles : np.ndarray
        Pole locations, shape (P,).  All strictly negative (outside [0, b]).
    residues : np.ndarray
        Residue coefficients b_p, shape (P,).
    """
    a, b = arange
    margin = 0.05 * (b - a + 1e-8)

    # Place poles uniformly in the negative half-line
    poles = -margin - np.linspace(margin, b + margin, P)

    # Sample filter on the interval
    lam = np.linspace(a + 1e-10, b, n_sample)
    g_vals = np.asarray(g(lam), dtype=np.float64)

    # Build Vandermonde-like matrix: A_{ij} = 1 / (λ_i - a_j)
    # lam (n_sample,)  poles (P,)
    A_mat = 1.0 / (lam[:, np.newaxis] - poles[np.newaxis, :])

    # Least-squares solve for residues
    residues, _, _, _ = np.linalg.lstsq(A_mat, g_vals, rcond=None)

    return poles, residues


def arma_filter_op(
    L,
    f: np.ndarray,
    poles: np.ndarray,
    residues: np.ndarray,
) -> np.ndarray:
    """
    Apply a rational filter to a graph signal via sparse linear solves.

    Computes  g(L)f ≈ Σ  b_p · (L - a_p I)^{-1} f.

    Parameters
    ----------
    L : scipy.sparse matrix
        Graph Laplacian (n × n, sparse, CSC or CSR).
    f : np.ndarray
        Signal vector (n,).
    poles : np.ndarray
        Pole locations (P,).
    residues : np.ndarray
        Residue coefficients (P,).

    Returns
    -------
    np.ndarray
        Filtered signal (n,).
    """
    f = np.asarray(f, dtype=np.float64).ravel()
    n = L.shape[0]
    result = np.zeros(n, dtype=np.float64)

    I = sparse_eye(n, format="csc")
    L_csc = L.tocsc()

    for a_p, b_p in zip(poles, residues):
        # (L - a_p I) x = f  →  x = (L - a_p I)^{-1} f
        A = L_csc - a_p * I
        x = spsolve(A, f)
        result += b_p * x

    return result


def sgwt_forward_arma(
    signal: np.ndarray,
    L,
    lmax: float,
    scales: np.ndarray,
    kernel_type: str = "heat",
    P: int = 8,
) -> Dict:
    """
    SGWT forward transform via ARMA rational approximation.

    Each filter g_j is approximated by a P-pole partial-fraction expansion,
    then applied through P sparse linear solves.

    Parameters
    ----------
    signal : np.ndarray
        Input signal (n,).
    L : scipy.sparse matrix
        Graph Laplacian.
    lmax : float
        Maximum eigenvalue estimate.
    scales : np.ndarray
        Wavelet scales.
    kernel_type : str
        Kernel family.
    P : int
        Number of poles in the rational approximation.

    Returns
    -------
    dict
        ``{"vertex_coefficients": {…}, "method": "arma"}``
    """
    signal = np.asarray(signal, dtype=np.float64).ravel()
    scales = np.asarray(scales, dtype=np.float64)
    arange = (0.0, lmax)

    kernels = sgwt_get_kernels(kernel_type)
    vertex_coeffs: Dict[str, np.ndarray] = {}

    # Scaling filter
    g_scaling = lambda x, _s=scales[0]: kernels["scaling"](x, _s)
    poles_s, res_s = arma_rational_approx(g_scaling, P, arange)
    vertex_coeffs["scaling"] = arma_filter_op(L, signal, poles_s, res_s)

    # Wavelet filters
    for j, s in enumerate(scales):
        g_wavelet = lambda x, _s=s: kernels["wavelet"](x, _s)
        poles_w, res_w = arma_rational_approx(g_wavelet, P, arange)
        vertex_coeffs[f"wavelet_scale_{j + 1}"] = arma_filter_op(L, signal, poles_w, res_w)

    return {"vertex_coefficients": vertex_coeffs, "method": "arma"}


# Inverse is the same component-sum as Chebyshev.
sgwt_inverse_arma = sgwt_inverse_cheby
