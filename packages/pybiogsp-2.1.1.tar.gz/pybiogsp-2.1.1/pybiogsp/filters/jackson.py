"""
Jackson-damped Chebyshev approximation for SGWT filters.

Applies Jackson damping factors to the Chebyshev expansion to suppress
Gibbs-like oscillations near spectral discontinuities, yielding smoother
and more accurate filter approximations for the same polynomial order.

Reference: Jackson (1912), "On approximation by trigonometric sums and
polynomials"; see also Di Napoli et al. (2016).
"""

import numpy as np
from typing import Dict, Optional

from ..core import sgwt_get_kernels
from .cheby import cheby_coefficients, cheby_op, sgwt_inverse_cheby


def jackson_damping_coeffs(M: int) -> np.ndarray:
    """
    Compute Jackson damping factors for a Chebyshev expansion of order M.

    The Jackson kernel damps the k-th Chebyshev coefficient by

        j_k = ((M - k + 1) cos(πk/(M+1)) + sin(πk/(M+1)) cot(π/(M+1)))
              / (M + 1)

    Parameters
    ----------
    M : int
        Chebyshev approximation order (number of coefficients = M+1).

    Returns
    -------
    np.ndarray
        Damping factors j_0 … j_M, shape (M+1,).
    """
    k = np.arange(M + 1, dtype=np.float64)
    alpha = np.pi * k / (M + 1)
    cot_val = np.cos(np.pi / (M + 1)) / np.sin(np.pi / (M + 1))
    j = ((M - k + 1) * np.cos(alpha) + np.sin(alpha) * cot_val) / (M + 1)
    return j


def sgwt_forward_jackson(
    signal: np.ndarray,
    L,
    lmax: float,
    scales: np.ndarray,
    kernel_type: str = "heat",
    M: int = 30,
) -> Dict:
    """
    SGWT forward transform with Jackson-damped Chebyshev approximation.

    Identical to the standard Chebyshev path but multiplies each set of
    Chebyshev coefficients element-wise by the Jackson damping factors.
    This suppresses ringing artifacts (Gibbs phenomenon).

    Parameters
    ----------
    signal : np.ndarray
        Input signal (n,) or matrix (n, p).
    L : scipy.sparse matrix
        Graph Laplacian.
    lmax : float
        Maximum eigenvalue estimate.
    scales : np.ndarray
        Wavelet scales.
    kernel_type : str
        Kernel family.
    M : int
        Chebyshev polynomial order.

    Returns
    -------
    dict
        ``{"vertex_coefficients": {…}, "method": "jackson"}``
    """
    signal = np.asarray(signal, dtype=np.float64)
    scales = np.asarray(scales, dtype=np.float64)
    arange = (0.0, lmax)

    kernels = sgwt_get_kernels(kernel_type)
    jk = jackson_damping_coeffs(M)

    vertex_coeffs: Dict[str, np.ndarray] = {}

    # Scaling filter
    g_scaling = lambda x, _s=scales[0]: kernels["scaling"](x, _s)
    c_scaling = cheby_coefficients(g_scaling, M, arange) * jk
    vertex_coeffs["scaling"] = cheby_op(L, signal, c_scaling, lmax)

    # Wavelet filters
    for j, s in enumerate(scales):
        g_wavelet = lambda x, _s=s: kernels["wavelet"](x, _s)
        c_wavelet = cheby_coefficients(g_wavelet, M, arange) * jk
        vertex_coeffs[f"wavelet_scale_{j + 1}"] = cheby_op(L, signal, c_wavelet, lmax)

    return {"vertex_coefficients": vertex_coeffs, "method": "jackson"}


# Inverse is identical to the generic Chebyshev inverse (sum of components).
sgwt_inverse_jackson = sgwt_inverse_cheby
