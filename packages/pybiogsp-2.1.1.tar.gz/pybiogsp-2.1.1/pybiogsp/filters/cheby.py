"""
Chebyshev polynomial approximation for SGWT filters.

Approximates g(L)f via truncated Chebyshev expansion without
eigendecomposition.  Complexity is O(M · nnz(L)) per filter per signal.
"""

import numpy as np
from scipy.sparse import eye as sparse_eye
from typing import Callable, Dict, Optional, Tuple

from ..core import sgwt_get_kernels


def cheby_coefficients(
    g: Callable,
    M: int,
    arange: Tuple[float, float] = (0.0, 2.0),
) -> np.ndarray:
    """
    Compute Chebyshev expansion coefficients for a filter function.

    Approximates g(x) on [a, b] as  g(x) ≈ Σ_{k=0}^{M} c_k T_k(x̃)
    where x̃ = (2x - a - b) / (b - a) maps [a,b] → [-1,1].

    Parameters
    ----------
    g : callable
        Filter function g(x) to approximate.
    M : int
        Chebyshev approximation order.
    arange : tuple of float
        (a, b) interval on which to approximate g.

    Returns
    -------
    np.ndarray
        Chebyshev coefficients c_0 … c_M, shape (M+1,).
    """
    a, b = arange
    N = M + 1
    nodes = np.cos(np.pi * (np.arange(N) + 0.5) / N)
    x = 0.5 * (a + b) + 0.5 * (b - a) * nodes
    gx = np.asarray(g(x), dtype=np.float64)

    c = np.zeros(N, dtype=np.float64)
    for k in range(N):
        c[k] = (2.0 / N) * np.sum(
            gx * np.cos(np.pi * k * (np.arange(N) + 0.5) / N)
        )
    c[0] /= 2.0
    return c


def cheby_op(
    L,
    f: np.ndarray,
    coeffs: np.ndarray,
    lmax: float,
) -> np.ndarray:
    """
    Apply a Chebyshev polynomial filter to a graph signal.

    Computes  g(L)f ≈ Σ c_k T_k(L̃)f   where L̃ = 2L/lmax − I.

    Parameters
    ----------
    L : scipy.sparse matrix
        Graph Laplacian (n × n, sparse).
    f : np.ndarray
        Signal vector (n,) or matrix (n, p).
    coeffs : np.ndarray
        Chebyshev coefficients [c_0, …, c_M].
    lmax : float
        Estimated maximum eigenvalue of L.

    Returns
    -------
    np.ndarray
        Filtered signal, same shape as f.
    """
    M = len(coeffs) - 1
    n = L.shape[0]
    L_tilde = (2.0 / lmax) * L - sparse_eye(n, format=L.format)

    f = np.asarray(f, dtype=np.float64)

    f_prev = f.copy()
    result = coeffs[0] * f_prev

    if M >= 1:
        f_curr = L_tilde @ f
        result = result + coeffs[1] * f_curr

        for k in range(2, M + 1):
            f_next = 2.0 * (L_tilde @ f_curr) - f_prev
            result = result + coeffs[k] * f_next
            f_prev = f_curr
            f_curr = f_next

    return result


def sgwt_forward_cheby(
    signal: np.ndarray,
    L,
    lmax: float,
    scales: np.ndarray,
    kernel_type: str = "heat",
    M: int = 30,
) -> Dict:
    """
    Fast SGWT forward transform via Chebyshev approximation.

    Parameters
    ----------
    signal : np.ndarray
        Input signal (n,) or matrix (n, p).
    L : scipy.sparse matrix
        Graph Laplacian.
    lmax : float
        Maximum eigenvalue estimate.
    scales : np.ndarray
        Wavelet scales.
    kernel_type : str
        Kernel family: "mexican_hat", "meyer", or "heat".
    M : int
        Chebyshev polynomial order.

    Returns
    -------
    dict
        ``{"vertex_coefficients": {"scaling": …, "wavelet_scale_1": …, …},
        "method": "cheby"}``
    """
    signal = np.asarray(signal, dtype=np.float64)
    scales = np.asarray(scales, dtype=np.float64)
    arange = (0.0, lmax)

    kernels = sgwt_get_kernels(kernel_type)
    vertex_coeffs: Dict[str, np.ndarray] = {}

    g_scaling = lambda x, _s=scales[0]: kernels["scaling"](x, _s)
    c_scaling = cheby_coefficients(g_scaling, M, arange)
    vertex_coeffs["scaling"] = cheby_op(L, signal, c_scaling, lmax)

    for j, s in enumerate(scales):
        g_wavelet = lambda x, _s=s: kernels["wavelet"](x, _s)
        c_wavelet = cheby_coefficients(g_wavelet, M, arange)
        vertex_coeffs[f"wavelet_scale_{j + 1}"] = cheby_op(L, signal, c_wavelet, lmax)

    return {"vertex_coefficients": vertex_coeffs, "method": "cheby"}


def sgwt_inverse_cheby(
    forward_cheby: Dict,
    original_signal: Optional[np.ndarray] = None,
) -> Dict:
    """
    Inverse SGWT from Chebyshev forward result (sum of components).

    Parameters
    ----------
    forward_cheby : dict
        Output of :func:`sgwt_forward_cheby`.
    original_signal : np.ndarray, optional
        Original signal for RMSE calculation.

    Returns
    -------
    dict
        ``{"vertex_approximations": …, "reconstructed_signal": …,
        "reconstruction_error": …}``
    """
    vertex_coeffs = forward_cheby["vertex_coefficients"]

    vertex_approximations: Dict[str, np.ndarray] = {}
    for name, arr in vertex_coeffs.items():
        if name == "scaling":
            vertex_approximations["low_pass"] = arr
        elif name.startswith("wavelet_scale_"):
            idx = name.replace("wavelet_scale_", "")
            vertex_approximations[f"wavelet_{idx}"] = arr
        else:
            vertex_approximations[name] = arr

    reconstructed = None
    for approx in vertex_approximations.values():
        if reconstructed is None:
            reconstructed = approx.copy()
        else:
            reconstructed = reconstructed + approx

    reconstruction_error = None
    if original_signal is not None:
        original_signal = np.asarray(original_signal, dtype=np.float64)
        if original_signal.ndim != reconstructed.ndim:
            if reconstructed.ndim == 1:
                original_signal = original_signal.flatten()
            else:
                original_signal = original_signal.reshape(reconstructed.shape)
        if original_signal.ndim == 1:
            reconstruction_error = np.sqrt(np.mean((original_signal - reconstructed) ** 2))
        else:
            reconstruction_error = np.sqrt(np.mean((original_signal - reconstructed) ** 2, axis=0))

    return {
        "vertex_approximations": vertex_approximations,
        "reconstructed_signal": reconstructed,
        "reconstruction_error": reconstruction_error,
    }
