"""
Lanczos (Krylov subspace) approximation for SGWT filters.

Builds an m-dimensional Krylov subspace V_m and tridiagonal projection T_m
via the Lanczos iteration with full reorthogonalization, then evaluates
g(L)f ≈ ||f|| V_m g(T_m) e_1.

The Lanczos basis is computed once per signal and reused across all J+1
filters, making the method efficient for multi-scale SGWT.

Reference: Susnjara et al. (2015) "Accelerated filtering on graphs using
Lanczos method".
"""

import numpy as np
from scipy.linalg import eigh as dense_eigh
from typing import Dict, Optional, Tuple

from ..core import sgwt_get_kernels
from .cheby import sgwt_inverse_cheby


def lanczos_basis(
    L,
    f: np.ndarray,
    m: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute the Lanczos basis and tridiagonal matrix for L starting from f.

    Uses full reorthogonalization to maintain numerical stability.

    Parameters
    ----------
    L : scipy.sparse matrix
        Graph Laplacian (n × n).
    f : np.ndarray
        Starting vector (n,).
    m : int
        Number of Lanczos iterations (subspace dimension).

    Returns
    -------
    V : np.ndarray
        Orthonormal basis of the Krylov subspace, shape (n, m).
    T : np.ndarray
        Symmetric tridiagonal matrix, shape (m, m).
    """
    f = np.asarray(f, dtype=np.float64).ravel()
    n = len(f)
    m = min(m, n)

    V = np.zeros((n, m), dtype=np.float64)
    alpha = np.zeros(m, dtype=np.float64)
    beta = np.zeros(m, dtype=np.float64)

    norm_f = np.linalg.norm(f)
    if norm_f < 1e-15:
        # Zero signal → trivial basis
        return V, np.zeros((m, m), dtype=np.float64)

    V[:, 0] = f / norm_f

    w = L @ V[:, 0]
    alpha[0] = np.dot(w, V[:, 0])
    w = w - alpha[0] * V[:, 0]

    for j in range(1, m):
        # Full reorthogonalization
        w -= V[:, :j] @ (V[:, :j].T @ w)
        beta[j] = np.linalg.norm(w)

        if beta[j] < 1e-14:
            # Invariant subspace reached — truncate
            V = V[:, :j]
            alpha = alpha[:j]
            beta = beta[:j]
            break

        V[:, j] = w / beta[j]
        w = L @ V[:, j]
        alpha[j] = np.dot(w, V[:, j])
        w = w - alpha[j] * V[:, j] - beta[j] * V[:, j - 1]

    # Assemble tridiagonal matrix
    m_actual = len(alpha)
    T = np.diag(alpha)
    if m_actual > 1:
        T += np.diag(beta[1:m_actual], 1) + np.diag(beta[1:m_actual], -1)

    return V[:, :m_actual], T


def lanczos_filter_op(
    V: np.ndarray,
    T: np.ndarray,
    norm_f: float,
    g_func,
) -> np.ndarray:
    """
    Evaluate g(L)f from a precomputed Lanczos basis.

    g(L)f ≈ ||f|| · V_m · g(T_m) · e_1

    Parameters
    ----------
    V : np.ndarray
        Lanczos basis (n, m).
    T : np.ndarray
        Tridiagonal matrix (m, m).
    norm_f : float
        Norm of the original signal vector.
    g_func : callable
        Filter function g(λ).

    Returns
    -------
    np.ndarray
        Filtered signal (n,).
    """
    m = T.shape[0]
    if m == 0:
        return np.zeros(V.shape[0], dtype=np.float64)

    # Diagonalize the small tridiagonal matrix
    eigvals, eigvecs = dense_eigh(T)

    # g(T_m) e_1  =  Q diag(g(λ)) Q^T e_1
    e1 = np.zeros(m, dtype=np.float64)
    e1[0] = 1.0
    g_diag = np.asarray(g_func(eigvals), dtype=np.float64)
    coeffs = eigvecs @ (g_diag * (eigvecs.T @ e1))

    return norm_f * (V @ coeffs)


def sgwt_forward_lanczos(
    signal: np.ndarray,
    L,
    lmax: float,
    scales: np.ndarray,
    kernel_type: str = "heat",
    m: int = 30,
) -> Dict:
    """
    SGWT forward transform via Lanczos approximation.

    The Lanczos basis is built once per signal and shared across all
    scaling + wavelet filters.

    Parameters
    ----------
    signal : np.ndarray
        Input signal (n,).
    L : scipy.sparse matrix
        Graph Laplacian.
    lmax : float
        Maximum eigenvalue estimate (unused directly but kept for API
        consistency; Lanczos auto-captures the spectral range).
    scales : np.ndarray
        Wavelet scales.
    kernel_type : str
        Kernel family.
    m : int
        Lanczos iteration count (subspace dimension).

    Returns
    -------
    dict
        ``{"vertex_coefficients": {…}, "method": "lanczos"}``
    """
    signal = np.asarray(signal, dtype=np.float64).ravel()
    scales = np.asarray(scales, dtype=np.float64)
    norm_f = np.linalg.norm(signal)

    kernels = sgwt_get_kernels(kernel_type)

    # Build Lanczos basis once
    V, T = lanczos_basis(L, signal, m)

    vertex_coeffs: Dict[str, np.ndarray] = {}

    # Scaling filter
    g_scaling = lambda lam, _s=scales[0]: kernels["scaling"](lam, _s)
    vertex_coeffs["scaling"] = lanczos_filter_op(V, T, norm_f, g_scaling)

    # Wavelet filters
    for j, s in enumerate(scales):
        g_wavelet = lambda lam, _s=s: kernels["wavelet"](lam, _s)
        vertex_coeffs[f"wavelet_scale_{j + 1}"] = lanczos_filter_op(V, T, norm_f, g_wavelet)

    return {"vertex_coefficients": vertex_coeffs, "method": "lanczos"}


# Inverse is the same component-sum as Chebyshev.
sgwt_inverse_lanczos = sgwt_inverse_cheby
