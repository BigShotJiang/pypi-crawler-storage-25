"""
Main SGWT class and workflow functions for BioGSP package.

Provides the SGWT class that encapsulates the complete workflow:
SGWT() -> build_graph() -> run_sgwt(method=...) -> run_sgcc()

Legacy workflow (deprecated):
SGWT() -> run_spec_graph(method=...) -> run_sgwt() -> run_sgcc()
"""

import warnings
import numpy as np
import pandas as pd
import torch
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass, field

from .utils import (
    cal_laplacian,
    fast_decomposition_lap,
    build_knn_graph,
    cosine_similarity,
    cosine_similarity_matrix,
    cosine_similarity_pairs,
    get_device,
    estimate_lmax,
)
from .core import (
    sgwt_auto_scales,
    sgwt_forward,
    sgwt_inverse,
    compute_sgwt_filters,
)
from .filters.cheby import sgwt_forward_cheby, sgwt_inverse_cheby
from .filters.jackson import sgwt_forward_jackson, sgwt_inverse_jackson
from .filters.lanczos import sgwt_forward_lanczos, sgwt_inverse_lanczos
from .filters.arma import sgwt_forward_arma, sgwt_inverse_arma

VALID_METHODS = ("eigen", "cheby", "jackson", "lanczos", "arma")


@dataclass
class SGWTData:
    """Container for SGWT data."""
    data: pd.DataFrame
    x_col: str
    y_col: str
    signals: List[str]


@dataclass
class SGWTGraph:
    """Container for SGWT graph data."""
    adjacency_matrix: Any
    laplacian_matrix: Any
    eigenvalues: Optional[np.ndarray] = None
    eigenvectors: Optional[np.ndarray] = None
    lmax: Optional[float] = None


@dataclass
class SGWTParameters:
    """Container for SGWT parameters."""
    scales: Optional[np.ndarray] = None
    J: int = 5
    scaling_factor: float = 2.0
    kernel_type: str = "heat"
    k: Optional[int] = None
    laplacian_type: Optional[str] = None
    cheby_order: int = 30
    lanczos_order: int = 30
    arma_order: int = 8


class SGWT:
    """
    Spectral Graph Wavelet Transform (SGWT) object.

    Main class for performing SGWT analysis on spatial data.

    **Recommended workflow**::

        sg = SGWT(data, signals=[...], J=3, kernel_type="heat")
        sg.build_graph(k=12, laplacian_type="normalized")
        sg.run_sgwt(method="cheby")
        sim = sg.run_sgcc("signal_1", "signal_2")

    The same graph can be reused with different methods::

        sg.run_sgwt(method="eigen")    # switch to eigen
        sg.run_sgwt(method="jackson")  # switch to jackson

    Parameters
    ----------
    data : pd.DataFrame
        Data frame containing spatial coordinates and signal data.
    x_col : str
        Column name for X coordinates.
    y_col : str
        Column name for Y coordinates.
    signals : list of str, optional
        Signal column names to analyze. If None, all non-coordinate columns
        are used.
    scales : np.ndarray, optional
        Vector of scales for wavelets. If None, auto-generated.
    J : int
        Number of scales to generate if scales is None.
    scaling_factor : float
        Scaling factor between consecutive scales.
    kernel_type : str
        Kernel family: ``"mexican_hat"``, ``"meyer"``, or ``"heat"``.
    cheby_order : int
        Polynomial order for Chebyshev and Jackson methods.
    lanczos_order : int
        Krylov subspace dimension for Lanczos method.
    arma_order : int
        Rational filter order for ARMA method.

    Attributes
    ----------
    Data : SGWTData
        Container for input data.
    Graph : SGWTGraph or None
        Container for graph data (after ``build_graph``).
    Forward : dict or None
        Forward transform results (after ``run_sgwt``).
    Inverse : dict or None
        Inverse transform results (after ``run_sgwt``).
    Parameters : SGWTParameters
        Container for parameters.
    """

    def __init__(
        self,
        data: pd.DataFrame,
        x_col: str = "X",
        y_col: str = "Y",
        signals: Optional[List[str]] = None,
        scales: Optional[np.ndarray] = None,
        J: int = 5,
        scaling_factor: float = 2.0,
        kernel_type: str = "heat",
        cheby_order: int = 30,
        lanczos_order: int = 30,
        arma_order: int = 8,
    ):
        """Initialize SGWT object."""
        if data is None:
            raise ValueError("data must be provided")

        if not isinstance(data, pd.DataFrame):
            data = pd.DataFrame(data)

        if x_col not in data.columns or y_col not in data.columns:
            raise ValueError(f"Data must contain columns: {x_col} and {y_col}")

        # Auto-detect signals if not provided
        if signals is None:
            signals = [col for col in data.columns if col not in [x_col, y_col]]
            if len(signals) == 0:
                raise ValueError("No signal columns found in data")

        # Validate signal columns exist
        missing_signals = [s for s in signals if s not in data.columns]
        if missing_signals:
            raise ValueError(
                f"Signal columns not found in data: {', '.join(missing_signals)}"
            )

        self.Data = SGWTData(
            data=data.copy(), x_col=x_col, y_col=y_col, signals=signals,
        )

        self.Graph: Optional[SGWTGraph] = None
        self.Forward: Optional[Dict] = None
        self.Inverse: Optional[Dict] = None
        # Track which method produced the current Forward/Inverse
        self._last_method: Optional[str] = None
        # For backward-compat: stores method from deprecated run_spec_graph()
        self._pending_method: Optional[str] = None

        self.Parameters = SGWTParameters(
            scales=scales,
            J=J,
            scaling_factor=scaling_factor,
            kernel_type=kernel_type,
            cheby_order=cheby_order,
            lanczos_order=lanczos_order,
            arma_order=arma_order,
        )

    # ==================================================================
    # Graph construction (method-agnostic)
    # ==================================================================

    def build_graph(
        self,
        k: int = 25,
        laplacian_type: str = "normalized",
        verbose: bool = True,
    ) -> "SGWT":
        """
        Build graph from spatial coordinates.

        Constructs a k-nearest-neighbour graph and computes the Laplacian.
        This step is independent of the SGWT approximation method.

        Parameters
        ----------
        k : int
            Number of nearest neighbours.
        laplacian_type : str
            ``"unnormalized"``, ``"normalized"``, or ``"randomwalk"``.
        verbose : bool
            Whether to print progress messages.

        Returns
        -------
        SGWT
            Self, with ``Graph`` slot populated.
        """
        data = self.Data.data
        coords = data[[self.Data.x_col, self.Data.y_col]].values

        if verbose:
            print("Building graph from spatial coordinates...")

        A = build_knn_graph(coords, k)
        L = cal_laplacian(A, laplacian_type)

        self.Graph = SGWTGraph(adjacency_matrix=A, laplacian_matrix=L)

        self.Parameters.k = k
        self.Parameters.laplacian_type = laplacian_type

        # Clear stale results from a previous method
        self.Forward = None
        self.Inverse = None
        self._last_method = None

        if verbose:
            print("Graph construction completed.")

        return self

    # ==================================================================
    # Forward + Inverse transform
    # ==================================================================

    def run_sgwt(
        self,
        method: Optional[str] = None,
        use_batch: bool = True,
        verbose: bool = True,
        use_torch: bool = True,
        length_eigenvalue: Optional[int] = None,
    ) -> "SGWT":
        """
        Run SGWT forward and inverse transforms for all signals.

        Performs spectral preparation (eigendecomposition or lmax estimation)
        as needed, then computes the forward and inverse transforms.

        Parameters
        ----------
        method : str, optional
            One of ``"eigen"``, ``"cheby"``, ``"jackson"``, ``"lanczos"``,
            ``"arma"``.  Defaults to ``"eigen"`` (or the method specified via
            the deprecated ``run_spec_graph``).
        use_batch : bool
            Whether to use batch processing for multiple signals (eigen only).
        verbose : bool
            Whether to print progress messages.
        use_torch : bool
            Whether to use PyTorch for eigen computation.
        length_eigenvalue : int, optional
            Number of eigenvalues to compute (eigen only).  Defaults to N.

        Returns
        -------
        SGWT
            Self, with ``Forward`` and ``Inverse`` slots populated.
        """
        if self.Graph is None:
            raise ValueError(
                "Graph slot is empty. Call build_graph() first."
            )

        # Resolve method
        if method is None:
            method = self._pending_method or "eigen"
        if method not in VALID_METHODS:
            raise ValueError(f"method must be one of {VALID_METHODS}")

        # --- Spectral preparation ---
        L = self.Graph.laplacian_matrix

        if method == "eigen":
            # Compute eigendecomposition if not yet cached (or was stale)
            if self.Graph.eigenvalues is None or self.Graph.eigenvectors is None:
                if length_eigenvalue is None:
                    length_eigenvalue = len(self.Data.data)
                if verbose:
                    print("Computing eigendecomposition...")
                decomp = fast_decomposition_lap(
                    L, k_eigen=length_eigenvalue, which="SM",
                    use_torch=use_torch,
                )
                self.Graph.eigenvalues = decomp["evalues"]
                self.Graph.eigenvectors = decomp["evectors"]
                self.Graph.lmax = float(np.max(decomp["evalues"]))
        else:
            # All approximation methods only need lmax
            if self.Graph.lmax is None:
                if self.Graph.eigenvalues is not None:
                    self.Graph.lmax = float(np.max(self.Graph.eigenvalues))
                else:
                    if verbose:
                        print(f"Estimating lmax ({method} mode)...")
                    self.Graph.lmax = estimate_lmax(L)

        # --- Auto-generate scales if needed ---
        if self.Parameters.scales is None:
            lmax = self.Graph.lmax
            self.Parameters.scales = sgwt_auto_scales(
                lmax * 0.95,
                self.Parameters.J,
                self.Parameters.scaling_factor,
            )
            if verbose:
                scales_str = ", ".join(
                    [f"{s:.4f}" for s in self.Parameters.scales]
                )
                print(f"Auto-generated scales: {scales_str}")

        # --- Dispatch ---
        if method == "eigen":
            self._run_sgwt_eigen(
                use_batch=use_batch, verbose=verbose,
                use_torch=use_torch,
            )
        else:
            self._run_sgwt_approx(method, verbose=verbose)

        self._last_method = method
        if verbose:
            print(f"SGWT analysis completed ({method}).")

        return self

    # ------------------------------------------------------------------
    # Eigen path
    # ------------------------------------------------------------------

    def _run_sgwt_eigen(
        self,
        use_batch: bool = True,
        verbose: bool = True,
        use_torch: bool = True,
    ) -> None:
        """Internal: eigen-path forward + inverse."""
        eigenvalues = self.Graph.eigenvalues
        eigenvectors = self.Graph.eigenvectors
        params = self.Parameters
        signals = self.Data.signals
        data = self.Data.data
        n_signals = len(signals)

        if verbose:
            print(f"Performing SGWT analysis (eigen) for {n_signals} signals...")

        device = get_device() if use_torch else None

        if use_batch and n_signals > 1:
            if verbose:
                print("Using batch processing for efficiency...")

            signals_matrix = data[signals].values

            batch_forward = sgwt_forward(
                signals_matrix, eigenvectors, eigenvalues,
                params.scales, kernel_type=params.kernel_type,
                use_torch=use_torch, device=device,
            )
            batch_inverse = sgwt_inverse(
                batch_forward, eigenvectors, signals_matrix,
                use_torch=use_torch, device=device,
            )

            forward_list = {}
            inverse_list = {}

            for i, sig in enumerate(signals):
                # --- Forward: Fourier coefficients ---
                filtered = {}
                for key, val in batch_forward["fourier_coefficients"]["filtered"].items():
                    filtered[key] = val[:, i] if val.ndim > 1 else val

                original = batch_forward["fourier_coefficients"]["original"]
                if original.ndim > 1:
                    original = original[:, i]

                # --- Forward: vertex coefficients ---
                vc = {}
                for key, val in batch_forward["vertex_coefficients"].items():
                    vc[key] = val[:, i] if val.ndim > 1 else val

                forward_list[sig] = {
                    "fourier_coefficients": {
                        "original": original,
                        "filtered": filtered,
                    },
                    "vertex_coefficients": vc,
                    "filters": batch_forward["filters"],
                }

                # --- Inverse ---
                coefficients_individual = {}
                for comp_name, comp_val in batch_inverse["vertex_approximations"].items():
                    coefficients_individual[comp_name] = (
                        comp_val[:, i] if comp_val.ndim > 1 else comp_val
                    )

                reconstructed = batch_inverse["reconstructed_signal"]
                if reconstructed.ndim > 1:
                    reconstructed = reconstructed[:, i]

                error = batch_inverse["reconstruction_error"]
                if error is not None and hasattr(error, "__len__") and len(error) > 1:
                    error = error[i]

                inverse_list[sig] = {
                    "vertex_approximations": coefficients_individual,
                    "reconstructed_signal": reconstructed,
                    "reconstruction_error": error,
                }
        else:
            if verbose and n_signals > 1:
                print("Using individual processing...")

            forward_list = {}
            inverse_list = {}

            for sig in signals:
                if verbose:
                    print(f"Processing signal: {sig}")
                sig_vec = data[sig].values

                fwd = sgwt_forward(
                    sig_vec, eigenvectors, eigenvalues,
                    params.scales, kernel_type=params.kernel_type,
                    use_torch=use_torch, device=device,
                )
                forward_list[sig] = fwd

                inv = sgwt_inverse(
                    fwd, eigenvectors, sig_vec,
                    use_torch=use_torch, device=device,
                )
                inverse_list[sig] = inv

        self.Forward = forward_list
        self.Inverse = inverse_list

    # ------------------------------------------------------------------
    # Approximation path (cheby / jackson / lanczos / arma)
    # ------------------------------------------------------------------

    def _run_sgwt_approx(self, method: str, verbose: bool = True) -> None:
        """Internal: run SGWT via an eigendecomposition-free method."""
        L = self.Graph.laplacian_matrix
        lmax = self.Graph.lmax
        params = self.Parameters
        signals = self.Data.signals
        data = self.Data.data

        _dispatch = {
            "cheby":   (sgwt_forward_cheby,   sgwt_inverse_cheby,   {"M": params.cheby_order}),
            "jackson": (sgwt_forward_jackson,  sgwt_inverse_jackson, {"M": params.cheby_order}),
            "lanczos": (sgwt_forward_lanczos,  sgwt_inverse_lanczos, {"m": params.lanczos_order}),
            "arma":    (sgwt_forward_arma,     sgwt_inverse_arma,    {"P": params.arma_order}),
        }
        fwd_fn, inv_fn, extra_kw = _dispatch[method]
        n_signals = len(signals)

        forward_list = {}
        inverse_list = {}

        # cheby / jackson support (n, p) matrix input natively via
        # cheby_op's sparse matrix multiply.  Batch all signals at once.
        if method in ("cheby", "jackson") and n_signals > 1:
            if verbose:
                print(
                    f"Performing SGWT ({method}, {extra_kw}, batch) "
                    f"for {n_signals} signals..."
                )

            signals_matrix = data[signals].values  # (n, p)

            batch_fwd = fwd_fn(
                signals_matrix, L, lmax, params.scales,
                kernel_type=params.kernel_type, **extra_kw,
            )
            batch_inv = inv_fn(batch_fwd, signals_matrix)

            # === Cache batch matrices for vectorized SGCC (PR #1 patch) ===
            self._batch_vc = batch_fwd["vertex_coefficients"]

            # Unpack 2-D arrays into per-signal dicts
            for i, sig in enumerate(signals):
                vc = {}
                for key, val in batch_fwd["vertex_coefficients"].items():
                    vc[key] = val[:, i] if val.ndim > 1 else val
                forward_list[sig] = {
                    "vertex_coefficients": vc,
                    "method": method,
                }

                va = {}
                for key, val in batch_inv["vertex_approximations"].items():
                    va[key] = val[:, i] if val.ndim > 1 else val
                recon = batch_inv["reconstructed_signal"]
                recon_i = recon[:, i] if recon.ndim > 1 else recon
                err = batch_inv["reconstruction_error"]
                err_i = (
                    err[i]
                    if err is not None
                    and hasattr(err, "__len__")
                    and len(err) > 1
                    else err
                )
                inverse_list[sig] = {
                    "vertex_approximations": va,
                    "reconstructed_signal": recon_i,
                    "reconstruction_error": err_i,
                }
        else:
            # lanczos / arma / single signal — per-signal loop
            if verbose:
                print(
                    f"Performing SGWT ({method}, {extra_kw}) "
                    f"for {n_signals} signals..."
                )

            for sig in signals:
                if verbose:
                    print(f"Processing signal: {sig}")
                sig_vec = data[sig].values

                fwd = fwd_fn(
                    sig_vec, L, lmax, params.scales,
                    kernel_type=params.kernel_type, **extra_kw,
                )
                forward_list[sig] = fwd

                inv = inv_fn(fwd, sig_vec)
                inverse_list[sig] = inv

        self.Forward = forward_list
        self.Inverse = inverse_list

    # ==================================================================
    # Unified coefficient accessor (removes all method-based branching)
    # ==================================================================

    def _get_coefficients(
        self,
        x: Union[str, "SGWT", Dict],
    ) -> Dict[str, np.ndarray]:
        """
        Return ``{"scaling": ..., "wavelet_scale_*": ...}`` from Forward
        regardless of whether the run used eigen or an approximation method.

        Parameters
        ----------
        x : str, SGWT, or dict
            Signal name, another SGWT object, or a raw Forward dict.

        Returns
        -------
        dict
            Coefficient dict with keys ``"scaling"``, ``"wavelet_scale_1"``,
            etc.
        """
        if isinstance(x, str):
            if self.Forward is None or x not in self.Forward:
                raise ValueError(f"Signal '{x}' not found in Forward results")
            fwd = self.Forward[x]
        elif isinstance(x, SGWT):
            if x.Forward is None or len(x.Forward) == 0:
                raise ValueError("SGWT object must have Forward results")
            fwd = list(x.Forward.values())[0]
        elif isinstance(x, dict):
            fwd = x
        else:
            raise ValueError("Invalid input type for signal")

        # All methods now have "vertex_coefficients"
        if "vertex_coefficients" in fwd:
            return fwd["vertex_coefficients"]
        # Fallback for old-format eigen dicts (fourier only, pre-refactor)
        if "fourier_coefficients" in fwd:
            return fwd["fourier_coefficients"]["filtered"]
        raise ValueError(
            "Forward dict has neither 'vertex_coefficients' nor "
            "'fourier_coefficients'"
        )

    @staticmethod
    def _remove_dc(v: np.ndarray) -> np.ndarray:
        """Remove DC component from a scaling coefficient vector."""
        v = np.asarray(v, dtype=np.float64)
        v = np.nan_to_num(v, nan=0.0, posinf=0.0, neginf=0.0)
        return v - np.mean(v)

    @staticmethod
    def _extract_wavelet_names(coeffs: dict) -> List[str]:
        """Return sorted wavelet key names from a coefficient dict."""
        return sorted(
            [k for k in coeffs if k.startswith("wavelet_scale_")],
            key=lambda x: int(x.replace("wavelet_scale_", "")),
        )

    # ==================================================================
    # SGCC (unified — single code path for all methods)
    # ==================================================================

    def run_sgcc(
        self,
        signal1: Union[str, "SGWT"],
        signal2: Optional[Union[str, "SGWT"]] = None,
        eps: float = 1e-12,
        validate: bool = True,
        return_parts: bool = True,
        low_only: bool = False,
    ) -> Dict:
        """
        Run SGCC weighted similarity analysis.

        Uses vertex-domain coefficients for all methods (Parseval's theorem
        guarantees equivalence with the Fourier-domain computation for the
        eigen path).

        Parameters
        ----------
        signal1 : str or SGWT
            Signal name or SGWT object.
        signal2 : str or SGWT, optional
            Signal name or SGWT object.
        eps : float
            Small value for numerical stability.
        validate : bool
            Whether to check consistency.
        return_parts : bool
            Whether to return detailed components.
        low_only : bool
            Whether to compute only low-frequency similarity.

        Returns
        -------
        dict or float
            Similarity analysis results or just the similarity value.

        Examples
        --------
        >>> similarity = sg.run_sgcc("signal1", "signal2")
        """
        ca = self._get_coefficients(signal1)
        cb = (
            self._get_coefficients(signal2)
            if signal2 is not None
            else self._get_coefficients(signal1)
        )

        # Low-frequency (scaling) — DC removed
        v_low_a = self._remove_dc(ca["scaling"])
        v_low_b = self._remove_dc(cb["scaling"])

        # Ensure same length
        min_len = min(len(v_low_a), len(v_low_b))
        if len(v_low_a) != len(v_low_b) and validate:
            print(
                f"Warning: Scaling coefficients have different lengths: "
                f"{len(v_low_a)} vs {len(v_low_b)}. "
                f"Truncating to minimum length: {min_len}"
            )
        v_low_a = v_low_a[:min_len]
        v_low_b = v_low_b[:min_len]

        E_low_a = float(np.sum(v_low_a ** 2))
        E_low_b = float(np.sum(v_low_b ** 2))
        c_low = cosine_similarity(v_low_a, v_low_b, eps)

        if low_only:
            if return_parts:
                return {
                    "c_low": c_low, "c_nonlow": np.nan,
                    "w_low": 1.0, "w_NL": 0.0, "S": c_low,
                    "E_low_a": E_low_a, "E_NL_a": np.nan,
                    "E_low_b": E_low_b, "E_NL_b": np.nan,
                    "n": len(v_low_a), "J": np.nan,
                }
            return c_low

        # Wavelet (non-low) — concatenated
        wnames_a = self._extract_wavelet_names(ca)
        wnames_b = self._extract_wavelet_names(cb)
        min_scales = min(len(wnames_a), len(wnames_b))
        if len(wnames_a) != len(wnames_b) and validate:
            print(
                f"Warning: Different numbers of wavelet scales: "
                f"{len(wnames_a)} vs {len(wnames_b)}. "
                f"Using first {min_scales} scales."
            )
        wnames_a = wnames_a[:min_scales]
        wnames_b = wnames_b[:min_scales]

        v_wave_a = np.concatenate(
            [np.asarray(ca[n], dtype=np.float64).flatten() for n in wnames_a]
        )
        v_wave_b = np.concatenate(
            [np.asarray(cb[n], dtype=np.float64).flatten() for n in wnames_b]
        )
        v_wave_a = np.nan_to_num(v_wave_a, nan=0.0, posinf=0.0, neginf=0.0)
        v_wave_b = np.nan_to_num(v_wave_b, nan=0.0, posinf=0.0, neginf=0.0)

        min_wave_len = min(len(v_wave_a), len(v_wave_b))
        if len(v_wave_a) != len(v_wave_b) and validate:
            print(
                f"Warning: Wavelet coefficients have different lengths: "
                f"{len(v_wave_a)} vs {len(v_wave_b)}. "
                f"Truncating to minimum length: {min_wave_len}"
            )
        v_wave_a = v_wave_a[:min_wave_len]
        v_wave_b = v_wave_b[:min_wave_len]

        E_NL_a = float(np.sum(v_wave_a ** 2))
        E_NL_b = float(np.sum(v_wave_b ** 2))
        c_nonlow = cosine_similarity(v_wave_a, v_wave_b, eps)

        J = len(wnames_a)
        n = len(v_low_a)

        w_low_a = E_low_a / (E_low_a + E_NL_a + eps)
        w_low_b = E_low_b / (E_low_b + E_NL_b + eps)
        w_low = np.clip(0.5 * (w_low_a + w_low_b), 0, 1)
        w_NL = 1 - w_low
        S = w_low * c_low + w_NL * c_nonlow

        if return_parts:
            return {
                "c_low": c_low,
                "c_nonlow": c_nonlow,
                "w_low": w_low,
                "w_NL": w_NL,
                "S": S,
                "E_low_a": E_low_a,
                "E_NL_a": E_NL_a,
                "E_low_b": E_low_b,
                "E_NL_b": E_NL_b,
                "n": n,
                "J": J,
            }
        return S

    # ==================================================================
    # SGCC matrix (unified — single code path)
    # ==================================================================

    def run_sgcc_matrix(
        self,
        eps: float = 1e-12,
        return_parts: bool = False,
    ) -> Union[pd.DataFrame, Dict]:
        """
        Compute SGCC similarity matrix for all signal pairs via matrix
        operations.

        Parameters
        ----------
        eps : float
            Small value for numerical stability.
        return_parts : bool
            If True, return dict with C_low, C_nonlow, W_low matrices and
            individual energy vectors in addition to the S matrix.

        Returns
        -------
        pd.DataFrame or dict
            If *return_parts* is False, returns SGCC similarity DataFrame
            (p x p).  If True, returns dict with keys ``'S'``, ``'C_low'``,
            ``'C_nonlow'``, ``'W_low'``, ``'E_low'``, ``'E_NL'``,
            ``'signal_names'``.
        """
        if self.Forward is None or len(self.Forward) < 2:
            raise ValueError(
                "Need at least 2 signals with Forward results. "
                "Run run_sgwt() first."
            )

        signal_names = list(self.Forward.keys())
        p = len(signal_names)

        low_cols = []
        wave_cols = []

        for sig in signal_names:
            coeffs = self._get_coefficients(sig)

            v_low = self._remove_dc(coeffs["scaling"])
            low_cols.append(v_low)

            wnames = self._extract_wavelet_names(coeffs)
            v_wave = np.concatenate(
                [np.asarray(coeffs[n], dtype=np.float64).flatten()
                 for n in wnames]
            )
            v_wave = np.nan_to_num(v_wave, nan=0.0, posinf=0.0, neginf=0.0)
            wave_cols.append(v_wave)

        F_low = np.column_stack(low_cols)
        F_wave = np.column_stack(wave_cols)

        C_low = cosine_similarity_matrix(F_low, eps)
        C_nonlow = cosine_similarity_matrix(F_wave, eps)

        E_low = np.sum(F_low ** 2, axis=0)
        E_NL = np.sum(F_wave ** 2, axis=0)
        w_low_vec = E_low / (E_low + E_NL + eps)

        W_low = 0.5 * (w_low_vec[:, np.newaxis] + w_low_vec[np.newaxis, :])
        W_low = np.clip(W_low, 0.0, 1.0)
        W_NL = 1.0 - W_low

        S = W_low * C_low + W_NL * C_nonlow

        S_df = pd.DataFrame(S, index=signal_names, columns=signal_names)

        if return_parts:
            return {
                "S": S_df,
                "C_low": pd.DataFrame(
                    C_low, index=signal_names, columns=signal_names,
                ),
                "C_nonlow": pd.DataFrame(
                    C_nonlow, index=signal_names, columns=signal_names,
                ),
                "W_low": pd.DataFrame(
                    W_low, index=signal_names, columns=signal_names,
                ),
                "E_low": dict(zip(signal_names, E_low)),
                "E_NL": dict(zip(signal_names, E_NL)),
                "signal_names": signal_names,
            }
        return S_df

    # ==================================================================
    # SGCC for specified pairs (vectorized)
    # ==================================================================

    def run_sgcc_pairs(
        self,
        pairs: List[Tuple[str, str]],
        eps: float = 1e-12,
    ) -> pd.DataFrame:
        """
        Compute SGCC for specific signal pairs via vectorized operations.

        More efficient than calling ``run_sgcc()`` in a loop (avoids
        repeated dict lookups and Python overhead) and much cheaper than
        ``run_sgcc_matrix()`` when only a subset of pairs is needed.

        Parameters
        ----------
        pairs : list of (str, str)
            Signal name pairs to compare.
        eps : float
            Small value for numerical stability.

        Returns
        -------
        pd.DataFrame
            One row per pair with columns ``signal1``, ``signal2``,
            ``c_low``, ``c_nonlow``, ``w_low``, ``w_NL``, ``S``.

        Examples
        --------
        >>> pairs = [("gene_A", "gene_B"), ("gene_C", "gene_D")]
        >>> df = sg.run_sgcc_pairs(pairs)
        """
        if self.Forward is None:
            raise ValueError(
                "Forward results not found. Run run_sgwt() first."
            )

        if len(pairs) == 0:
            return pd.DataFrame(
                columns=["signal1", "signal2", "c_low", "c_nonlow",
                         "w_low", "w_NL", "S"],
            )

        # === Fast batch path (PR #1 patch) ===
        bvc = getattr(self, "_batch_vc", None)
        if bvc is not None:
            return self._run_sgcc_pairs_from_batch(pairs, bvc, eps)

        # Collect unique signal names (order-preserving)
        all_names = list(dict.fromkeys(
            s for pair in pairs for s in pair
        ))
        name_to_idx = {n: i for i, n in enumerate(all_names)}

        # Build coefficient matrices once
        low_cols = []
        wave_cols = []
        for sig in all_names:
            coeffs = self._get_coefficients(sig)
            low_cols.append(self._remove_dc(coeffs["scaling"]))
            wnames = self._extract_wavelet_names(coeffs)
            v_wave = np.concatenate(
                [np.asarray(coeffs[n], dtype=np.float64).flatten()
                 for n in wnames]
            )
            wave_cols.append(
                np.nan_to_num(v_wave, nan=0.0, posinf=0.0, neginf=0.0)
            )

        F_low = np.column_stack(low_cols)    # (n, p_unique)
        F_wave = np.column_stack(wave_cols)  # (n*J, p_unique)

        # Pair index arrays
        idx_a = np.array([name_to_idx[p[0]] for p in pairs])
        idx_b = np.array([name_to_idx[p[1]] for p in pairs])

        # Vectorized cosine similarity for specified pairs
        c_low = cosine_similarity_pairs(F_low, idx_a, idx_b, eps)
        c_nonlow = cosine_similarity_pairs(F_wave, idx_a, idx_b, eps)

        # Vectorized energy weights
        E_low = np.sum(F_low ** 2, axis=0)    # (p_unique,)
        E_NL = np.sum(F_wave ** 2, axis=0)    # (p_unique,)
        w_low_vec = E_low / (E_low + E_NL + eps)

        w_low = np.clip(
            0.5 * (w_low_vec[idx_a] + w_low_vec[idx_b]), 0.0, 1.0,
        )
        w_NL = 1.0 - w_low
        S = w_low * c_low + w_NL * c_nonlow

        return pd.DataFrame({
            "signal1": [p[0] for p in pairs],
            "signal2": [p[1] for p in pairs],
            "c_low": c_low,
            "c_nonlow": c_nonlow,
            "w_low": w_low,
            "w_NL": w_NL,
            "S": S,
        })

    def _run_sgcc_pairs_from_batch(self, pairs, vc, eps):
        """Vectorized SGCC over pre-computed batch matrices (PR #1 patch).

        Skips the per-signal Python loop + 460k-vector column_stack of
        the original ``run_sgcc_pairs``.  Same numerical result.
        """
        signals = self.Data.signals
        name_to_idx = {n: i for i, n in enumerate(signals)}
        idx_a = np.fromiter((name_to_idx[p[0]] for p in pairs), dtype=np.int64)
        idx_b = np.fromiter((name_to_idx[p[1]] for p in pairs), dtype=np.int64)

        # F_low: scaling matrix, demean per column (matches _remove_dc per-signal)
        F_low = np.nan_to_num(
            np.asarray(vc["scaling"], dtype=np.float64),
            nan=0.0, posinf=0.0, neginf=0.0,
        )
        F_low = F_low - F_low.mean(axis=0, keepdims=True)

        # F_wave: vstack J wavelet-scale matrices in one shot (J ~ 3, NOT n_signals)
        wnames = self._extract_wavelet_names(vc)
        F_wave = np.nan_to_num(
            np.concatenate(
                [np.asarray(vc[n], dtype=np.float64) for n in wnames], axis=0,
            ),
            nan=0.0, posinf=0.0, neginf=0.0,
        )

        c_low = cosine_similarity_pairs(F_low, idx_a, idx_b, eps)
        c_nonlow = cosine_similarity_pairs(F_wave, idx_a, idx_b, eps)

        E_low = (F_low ** 2).sum(axis=0)
        E_NL = (F_wave ** 2).sum(axis=0)
        w_low_vec = E_low / (E_low + E_NL + eps)
        w_low = np.clip(0.5 * (w_low_vec[idx_a] + w_low_vec[idx_b]), 0.0, 1.0)
        w_NL = 1.0 - w_low
        S = w_low * c_low + w_NL * c_nonlow

        return pd.DataFrame({
            "signal1": [p[0] for p in pairs],
            "signal2": [p[1] for p in pairs],
            "c_low": c_low,
            "c_nonlow": c_nonlow,
            "w_low": w_low,
            "w_NL": w_NL,
            "S": S,
        })

    # ==================================================================
    # Energy analysis (unified — single code path)
    # ==================================================================

    def energy_analysis(
        self, signal_name: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Analyze SGWT energy distribution across scales.

        Parameters
        ----------
        signal_name : str, optional
            Name of signal to analyze. If None, uses first signal.

        Returns
        -------
        pd.DataFrame
            Energy analysis results.
        """
        if self.Forward is None:
            raise ValueError("Forward results not found. Run run_sgwt() first.")

        if signal_name is None:
            signal_name = list(self.Forward.keys())[0]
        if signal_name not in self.Forward:
            raise ValueError(
                f"Signal '{signal_name}' not found in Forward results"
            )

        coeffs = self._get_coefficients(signal_name)
        scales = self.Parameters.scales

        energies = []
        scale_names = []
        scale_values = []

        # Scaling energy (DC removed)
        if "scaling" in coeffs:
            v_low = self._remove_dc(coeffs["scaling"])
            energies.append(float(np.sum(v_low ** 2)))
            scale_names.append("low_pass")
            scale_values.append(scales[0])

        # Wavelet energies
        wavelet_names = self._extract_wavelet_names(coeffs)
        for name in wavelet_names:
            v_w = np.asarray(coeffs[name], dtype=np.float64)
            scale_idx = int(name.replace("wavelet_scale_", "")) - 1
            energies.append(float(np.sum(v_w ** 2)))
            scale_names.append(f"wavelet_{scale_idx + 1}")
            scale_values.append(
                scales[scale_idx] if scale_idx < len(scales) else np.nan
            )

        total_energy = sum(energies)
        energy_ratios = [
            e / total_energy if total_energy > 0 else 0 for e in energies
        ]

        return pd.DataFrame({
            "scale": scale_names,
            "energy": energies,
            "energy_ratio": energy_ratios,
            "scale_value": scale_values,
            "signal": signal_name,
        })

    # ==================================================================
    # Deprecated backward-compat wrapper
    # ==================================================================

    def run_spec_graph(
        self,
        k: int = 25,
        laplacian_type: str = "normalized",
        length_eigenvalue: Optional[int] = None,
        verbose: bool = True,
        use_torch: bool = True,
        method: str = "eigen",
    ) -> "SGWT":
        """
        .. deprecated:: 2.0
            Use :meth:`build_graph` followed by :meth:`run_sgwt` instead.

        Build spectral graph for SGWT object (legacy API).
        Internally calls :meth:`build_graph` and stores *method* for
        the subsequent :meth:`run_sgwt` call.
        """
        warnings.warn(
            "run_spec_graph() is deprecated. "
            "Use build_graph() + run_sgwt(method=...) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if method not in VALID_METHODS:
            raise ValueError(f"method must be one of {VALID_METHODS}")

        self.build_graph(k=k, laplacian_type=laplacian_type, verbose=verbose)

        # Eager spectral prep to match old behaviour
        if method == "eigen":
            if length_eigenvalue is None:
                length_eigenvalue = len(self.Data.data)
            if verbose:
                print("Computing eigendecomposition...")
            decomp = fast_decomposition_lap(
                self.Graph.laplacian_matrix,
                k_eigen=length_eigenvalue,
                which="SM",
                use_torch=use_torch,
            )
            self.Graph.eigenvalues = decomp["evalues"]
            self.Graph.eigenvectors = decomp["evectors"]
            self.Graph.lmax = float(np.max(decomp["evalues"]))
        else:
            if verbose:
                print(f"Estimating lmax ({method} mode)...")
            self.Graph.lmax = estimate_lmax(self.Graph.laplacian_matrix)

        # Auto-generate scales like old code
        if self.Parameters.scales is None:
            lmax = self.Graph.lmax * 0.95
            self.Parameters.scales = sgwt_auto_scales(
                lmax, self.Parameters.J, self.Parameters.scaling_factor,
            )
            if verbose:
                scales_str = ", ".join(
                    [f"{s:.4f}" for s in self.Parameters.scales]
                )
                print(f"Auto-generated scales: {scales_str}")

        self._pending_method = method

        if verbose:
            print(f"Graph construction completed ({method}).")

        return self

    # ==================================================================
    # Repr
    # ==================================================================

    def __repr__(self) -> str:
        """String representation of SGWT object."""
        lines = ["SGWT Object", "==========="]

        if self.Data is not None:
            lines.append("Data:")
            lines.append(
                f"  Dimensions: {len(self.Data.data)} x "
                f"{len(self.Data.data.columns)}"
            )
            lines.append(
                f"  Coordinates: {self.Data.x_col}, {self.Data.y_col}"
            )
            lines.append(f"  Signals: {', '.join(self.Data.signals)}")

        if self.Parameters is not None:
            lines.append("\nParameters:")
            lines.append(f"  k (neighbors): {self.Parameters.k}")
            lines.append(f"  J (scales): {self.Parameters.J}")
            lines.append(f"  Kernel type: {self.Parameters.kernel_type}")
            lines.append(f"  Laplacian type: {self.Parameters.laplacian_type}")
            if self.Parameters.scales is not None:
                scales_str = ", ".join(
                    [f"{s:.4f}" for s in self.Parameters.scales]
                )
                lines.append(f"  Scales: {scales_str}")

        lines.append("\nStatus:")
        lines.append(f"  Graph computed: {self.Graph is not None}")
        if self._last_method is not None:
            lines.append(f"  Method: {self._last_method}")
        lines.append(f"  Forward computed: {self.Forward is not None}")
        lines.append(f"  Inverse computed: {self.Inverse is not None}")

        if self.Inverse is not None:
            lines.append("\nReconstruction Errors:")
            for sig, inv in self.Inverse.items():
                err = inv.get("reconstruction_error")
                if err is not None:
                    if hasattr(err, "__len__"):
                        err = float(np.mean(err))
                    lines.append(f"  {sig}: {err:.6f}")

        return "\n".join(lines)

    def _repr_html_(self) -> str:
        """HTML representation for Jupyter notebooks."""
        return f"<pre>{self.__repr__()}</pre>"


# ==================================================================
# Convenience function to match R API
# ==================================================================

def init_sgwt(
    data: Union[pd.DataFrame, np.ndarray, Dict],
    x_col: str = "X",
    y_col: str = "Y",
    signals: Optional[List[str]] = None,
    scales: Optional[np.ndarray] = None,
    J: int = 5,
    scaling_factor: float = 2.0,
    kernel_type: str = "heat",
    cheby_order: int = 30,
    lanczos_order: int = 30,
    arma_order: int = 8,
) -> SGWT:
    """
    Initialize SGWT object (convenience function matching R API).

    Parameters
    ----------
    data : pd.DataFrame, np.ndarray, or dict
        Data containing spatial coordinates and signals.
    x_col : str
        Column name for X coordinates.
    y_col : str
        Column name for Y coordinates.
    signals : list of str, optional
        Signal column names.
    scales : np.ndarray, optional
        Wavelet scales.
    J : int
        Number of scales.
    scaling_factor : float
        Scaling factor between scales.
    kernel_type : str
        Kernel family.
    cheby_order : int
        Polynomial order for Chebyshev and Jackson methods.
    lanczos_order : int
        Krylov subspace dimension for Lanczos method.
    arma_order : int
        Rational filter order for ARMA method.

    Returns
    -------
    SGWT
        Initialized SGWT object.
    """
    if isinstance(data, np.ndarray):
        data = pd.DataFrame(data)
    elif isinstance(data, dict):
        data = pd.DataFrame(data)

    return SGWT(
        data=data, x_col=x_col, y_col=y_col, signals=signals,
        scales=scales, J=J, scaling_factor=scaling_factor,
        kernel_type=kernel_type,
        cheby_order=cheby_order, lanczos_order=lanczos_order,
        arma_order=arma_order,
    )
