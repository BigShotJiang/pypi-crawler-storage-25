"""
PyBioGSP: Biological Graph Signal Processing for Spatial Data Analysis

A Python implementation of Graph Signal Processing (GSP) methods including 
Spectral Graph Wavelet Transform (SGWT) for analyzing spatial patterns in 
biological data. Uses PyTorch for accelerated matrix decomposition.

Based on Hammond, Vandergheynst, and Gribonval (2011) 
"Wavelets on Graphs via Spectral Graph Theory"
"""

from .sgwt import SGWT, init_sgwt, VALID_METHODS
from .core import (
    sgwt_get_kernels,
    compute_sgwt_filters,
    sgwt_forward,
    sgwt_inverse,
    sgwt_auto_scales,
    compare_kernel_families,
)
from .filters import (
    cheby_coefficients,
    cheby_op,
    sgwt_forward_cheby,
    sgwt_inverse_cheby,
    jackson_damping_coeffs,
    sgwt_forward_jackson,
    sgwt_inverse_jackson,
    lanczos_basis,
    lanczos_filter_op,
    sgwt_forward_lanczos,
    sgwt_inverse_lanczos,
    arma_rational_approx,
    arma_filter_op,
    sgwt_forward_arma,
    sgwt_inverse_arma,
)
from .utils import (
    cal_laplacian,
    fast_decomposition_lap,
    gft,
    igft,
    cosine_similarity,
    cosine_similarity_matrix,
    cosine_similarity_pairs,
    find_knee_point,
    check_kband,
    estimate_lmax,
)
from .simulation import (
    simulate_multiscale,
    simulate_stripe_patterns,
    simulate_multiscale_overlap,
    simulate_moving_circles,
    simulate_checkerboard,
)
from .visualization import (
    plot_sgwt_decomposition,
    plot_fourier_modes,
    visualize_sgwt_kernels,
    visualize_similarity_xy,
    visualize_multiscale,
    visualize_stripe_patterns,
    visualize_moving_circles,
    visualize_checkerboard,
)

__version__ = "2.1.1"
__author__ = "Yuzhou Chang"
__email__ = "yuzhou.chang@osumc.edu"

__all__ = [
    # Main class
    "SGWT",
    "init_sgwt",
    "VALID_METHODS",
    # Core functions
    "sgwt_get_kernels",
    "compute_sgwt_filters",
    "sgwt_forward",
    "sgwt_inverse",
    "sgwt_auto_scales",
    "compare_kernel_families",
    # Chebyshev
    "cheby_coefficients",
    "cheby_op",
    "sgwt_forward_cheby",
    "sgwt_inverse_cheby",
    # Jackson
    "jackson_damping_coeffs",
    "sgwt_forward_jackson",
    "sgwt_inverse_jackson",
    # Lanczos
    "lanczos_basis",
    "lanczos_filter_op",
    "sgwt_forward_lanczos",
    "sgwt_inverse_lanczos",
    # ARMA
    "arma_rational_approx",
    "arma_filter_op",
    "sgwt_forward_arma",
    "sgwt_inverse_arma",
    # Utility functions
    "cal_laplacian",
    "fast_decomposition_lap",
    "gft",
    "igft",
    "cosine_similarity",
    "cosine_similarity_matrix",
    "cosine_similarity_pairs",
    "find_knee_point",
    "check_kband",
    "estimate_lmax",
    # Simulation functions
    "simulate_multiscale",
    "simulate_stripe_patterns",
    "simulate_multiscale_overlap",
    "simulate_moving_circles",
    "simulate_checkerboard",
    # Visualization functions
    "plot_sgwt_decomposition",
    "plot_fourier_modes",
    "visualize_sgwt_kernels",
    "visualize_similarity_xy",
    "visualize_multiscale",
    "visualize_stripe_patterns",
    "visualize_moving_circles",
    "visualize_checkerboard",
]
