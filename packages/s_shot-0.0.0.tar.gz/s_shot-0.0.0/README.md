# s-shot

Reserved package name for the official S-SHOT Python SDK.

The production SDK is being implemented and will be published as a later semver release.
