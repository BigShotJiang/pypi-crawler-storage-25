"""Reserved package namespace for the official S-SHOT Python SDK."""

__version__ = "0.0.0"
