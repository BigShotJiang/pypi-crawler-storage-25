import re


# =========================
# 🔧 BASIC FIXERS
# =========================

def fix_code_inside_strings(code):
    pattern = r'("""|\'\'\')(.*?)(\1)'

    def fix_match(match):
        quote, inner, _ = match.groups()

        inner = re.sub(
            r'def (\w+)\(\)(?!:)',
            r'def \1():',
            inner
        )

        return quote + inner + quote

    return re.sub(pattern, fix_match, code, flags=re.DOTALL)


def fix_indentation(code):
    lines = code.split("\n")
    fixed = []

    for i, line in enumerate(lines):
        fixed.append(line)

        stripped = line.strip()

        if stripped.startswith("def ") and stripped.endswith(":"):
            if i + 1 >= len(lines) or not lines[i + 1].startswith((" ", "\t")):
                fixed.append("    pass")

    return "\n".join(fixed)


def fix_async(code):
    code = re.sub(r'\b(await\s+)+', 'await ', code)
    code = re.sub(r'async\s+def\s+await\s+', 'async def ', code)
    return code


def safe_replace(code, old, new):
    if old in code:
        return code.replace(old, new)
    return code


# =========================
# 🧠 SMART ERROR FIXES
# =========================

def fix_missing_async_func(code, error):
    if "NameError" in error and "async_func" in error:
        if "def async_func" not in code:
            return (
                "import asyncio\n\n"
                "async def async_func():\n"
                "    return 'Hello from async'\n\n"
            ) + code
    return code


def fix_missing_person(code, error):
    if "NameError" in error and "Person" in error:
        if "class Person" not in code:
            return (
                "class Person:\n"
                "    def __init__(self, name):\n"
                "        self.name = name\n\n"
            ) + code
    return code


def fix_unbound_local(code, error):
    if "UnboundLocalError" in error:
        code = re.sub(
            r'print\((\w+)\)\n\s*(\1\s*=)',
            r'\2\n    print(\1)',
            code
        )
    return code


# =========================
# 🛡️ SELF-HEALING FIXES
# =========================

def fix_broken_append(code):
    if "# removed append" in code:
        code = code.replace(
            "x# removed append(5)",
            "x.append(5)"
        )
    return code

def fix_syntax_errors(code, error):
    # Fix unclosed quotes
    if "unterminated string literal" in error or "was never closed" in error:
        lines = code.split("\n")
        fixed_lines = []

        for line in lines:
            if line.count('"') % 2 != 0:
                line += '"'
            if line.count("'") % 2 != 0:
                line += "'"
            fixed_lines.append(line)

        code = "\n".join(fixed_lines)

    # Fix missing closing parentheses
    if "was never closed" in error:
        if code.count("(") > code.count(")"):
            code += ")"

    return code


def fix_missing_return(code):
    if "def unbound_local" in code and "return x" not in code:
        code = code.replace(
            "print(x)",
            "print(x)\n    return x"
        )
    return code


# =========================
# 🎯 MAIN FIX ENGINE
# =========================

def get_fix(code, error, previous_output=None):
    original_code = code

    # Step 1: basic cleanup
    code = fix_code_inside_strings(code)
    code = fix_indentation(code)
    code = fix_async(code)

    # Step 2: smart fixes
    code = fix_missing_async_func(code, error)
    code = fix_missing_person(code, error)
    code = fix_unbound_local(code, error)

    # Step 3: self-healing
    code = fix_broken_append(code)
    code = fix_missing_return(code)

    # Step 1.5: syntax fixes
    code = fix_syntax_errors(code, error)

    # Step 4: safe replacements
    fixes = [
        ("import non_existing_module", "# removed bad import"),
        ('"10" + 5', '"10" + str(5)'),
        ("return unknown_variable", "unknown_variable = 0\n    return unknown_variable"),
        ("arr[10]", "arr[0]"),
        ('["age"]', '.get("age", 0)'),
        ('int("abc")', '0'),
        ("/ 0", "/ 1"),
        ('"no_file.txt"', '"test.txt"'),
        ("Person()", 'Person("User")'),
        ("return recursion_error()", "return 0"),
        ("assert False", "assert True"),
    ]

    for old, new in fixes:
        code = safe_replace(code, old, new)

    # 🚨 Stop infinite loop
    if code.strip() == original_code.strip():
        return None

    return code