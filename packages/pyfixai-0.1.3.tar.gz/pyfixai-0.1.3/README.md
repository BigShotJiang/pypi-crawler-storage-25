![Python](https://img.shields.io/badge/Python-3.8+-blue)
![Status](https://img.shields.io/badge/Status-Active-success)
![License](https://img.shields.io/badge/License-MIT-green)
# PyFixAI 🚀

**PyFixAI** is an intelligent Python auto-debugger that automatically detects, analyzes, and fixes errors in your code using an iterative execution engine.

 Most of the People USe to ask Chatgpt or any ai tool to fix the code and again Paste it and run it This will be a Big process to run a project file 
 So, we Found this library "Pyfixai" to debug fix reset and run your python code until it runs sucessfully!!..

---

## ✨ Features

* 🔁 Automatic debugging loop
* 🧠 Detects multiple Python errors
* ⚡ Fixes code without manual intervention
* 🛡️ Safe and controlled patching
* 💻 Easy CLI usage

---

## ⚙️ How It Works

PyFixAI follows a smart cycle:

```
Run → Detect → Fix → Repeat
```

1. Executes your Python script
2. Captures errors and tracebacks
3. Applies intelligent fixes
4. Re-runs until successful

---

## 📦 Installation

```bash
pip install pyfixai
```

---

## 🚀 Usage

```bash
autofix run your_script.py
```

---

## 🧪 Example

### ❌ Before

```python
def test():
    return "10" + 5
```

### ▶ Run

```bash
autofix run test.py
```

### ✅ After

```python
def test():
    return "10" + str(5)
```

---

## 📁 Project Structure

```
pyfixai/
│
├── core.py
├── fixer.py
├── cli.py
└── utils.py
```

---

## 💡 Use Cases

* Debugging student code
* Fixing runtime errors quickly
* Automating repetitive debugging tasks

---


## 🔮 Future Plans

* AST-based fixing
* AI-powered debugging
* IDE integrations

---

## 👨‍💻 Team

* Akhila Bodduri
* ANIMIREDDY YASWANTH


---

## 📜 License

MIT License
