"""Desk Awake - Cross-platform idle activity simulator with web control."""

__version__ = "1.5.0"
