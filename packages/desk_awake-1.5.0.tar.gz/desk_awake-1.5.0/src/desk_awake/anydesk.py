"""AnyDesk connection monitoring and management."""

import subprocess
import time
import platform
import os

CURRENT_OS = platform.system().lower()


def is_anydesk_running():
    """Check if AnyDesk process is running."""
    try:
        if CURRENT_OS == "darwin":
            result = subprocess.run(['pgrep', '-f', 'AnyDesk'], capture_output=True, text=True)
        elif CURRENT_OS == "linux":
            result = subprocess.run(['pgrep', '-f', 'anydesk'], capture_output=True, text=True)
        elif CURRENT_OS == "windows":
            result = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq AnyDesk.exe'],
                                    capture_output=True, text=True)
            return 'AnyDesk.exe' in result.stdout
        else:
            return False
        return result.returncode == 0
    except Exception:
        return False


def is_anydesk_connected():
    """
    Check if AnyDesk has an active remote session (someone is connected TO this machine
    or this machine is connected to a remote).
    
    Detection methods by OS:
    - Linux: Check for active session via network connections on AnyDesk port,
             or session-specific processes.
    - macOS: Check for AnyDesk windows with active session titles.
    - Windows: Check for session processes.
    """
    try:
        if CURRENT_OS == "linux":
            return _check_linux_connection()
        elif CURRENT_OS == "darwin":
            return _check_macos_connection()
        elif CURRENT_OS == "windows":
            return _check_windows_connection()
    except Exception:
        pass

    return False


def _check_linux_connection():
    """
    Check for active AnyDesk session on Linux.
    
    Methods (in order of reliability):
    1. Check AnyDesk trace log for session state
    2. Check for established TCP connections on AnyDesk ports
    3. Check for session-specific child processes
    """
    # Method 1: Check AnyDesk trace/log for active session
    # AnyDesk logs session events to its trace file
    trace_paths = [
        os.path.expanduser('~/.anydesk/connection_trace.txt'),
        '/var/log/anydesk/connection_trace.txt',
        os.path.expanduser('~/.anydesk-ad/connection_trace.txt'),
    ]
    
    for trace_path in trace_paths:
        if os.path.exists(trace_path):
            try:
                result = subprocess.run(
                    ['tail', '-5', trace_path],
                    capture_output=True, text=True, timeout=3
                )
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    # Look at recent entries — connected sessions show "CONNECTED" 
                    # and disconnections show "DISCONNECTED"
                    for line in reversed(lines):
                        line_lower = line.lower()
                        if 'disconnected' in line_lower or 'closed' in line_lower:
                            return False
                        if 'connected' in line_lower:
                            return True
            except (subprocess.TimeoutExpired, Exception):
                pass

    # Method 2: Check for established TCP connections on AnyDesk ports (7070, 6568)
    # An active session will have ESTABLISHED connections
    try:
        result = subprocess.run(
            ['ss', '-tnp'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            lines = result.stdout.lower()
            # Look for established connections from anydesk process
            for line in lines.split('\n'):
                if 'anydesk' in line and 'estab' in line:
                    # Filter out just the relay/discovery connections
                    # Active sessions typically use port 7070 or dynamic ports
                    if ':7070' in line or 'anydesk' in line:
                        return True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        # ss not available, try netstat
        try:
            result = subprocess.run(
                ['netstat', '-tnp'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'anydesk' in line.lower() and 'ESTABLISHED' in line:
                        return True
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass

    # Method 3: Check if anydesk has session-specific child processes
    # When connected, anydesk spawns additional processes for the session
    try:
        # Get the main anydesk PID
        result = subprocess.run(['pgrep', '-x', 'anydesk'], capture_output=True, text=True)
        if result.returncode == 0:
            pids = result.stdout.strip().split('\n')
            # If there are multiple anydesk processes, likely a session is active
            # Main daemon is 1 process, a session adds more
            if len(pids) > 1:
                return True
            
            # Check /proc for the process's file descriptors (open sockets indicate session)
            for pid in pids:
                fd_path = f'/proc/{pid.strip()}/fd'
                if os.path.exists(fd_path):
                    try:
                        fd_count = len(os.listdir(fd_path))
                        # Active session typically has many more FDs than idle
                        # Idle anydesk: ~20-30 FDs, Active session: 50+
                        if fd_count > 45:
                            return True
                    except PermissionError:
                        pass
    except Exception:
        pass

    return False


def _check_macos_connection():
    """Check for active AnyDesk session on macOS."""
    # Check window titles — active sessions show the remote machine name
    try:
        result = subprocess.run(
            ['osascript', '-e',
             'tell application "System Events" to get name of every window of process "AnyDesk"'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            windows = result.stdout.strip()
            # Active session windows contain the remote address/name
            # The main AnyDesk window is just "AnyDesk" 
            # Session windows have titles like "123456789 - AnyDesk" or the remote machine name
            if windows and windows != 'AnyDesk':
                # Check if there's more than just the main window
                window_list = [w.strip() for w in windows.split(',')]
                for w in window_list:
                    if w and w != 'AnyDesk' and w != '':
                        return True
    except (subprocess.TimeoutExpired, Exception):
        pass

    # Fallback: check network connections
    try:
        result = subprocess.run(
            ['lsof', '-i', '-n', '-P'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if 'AnyDesk' in line and 'ESTABLISHED' in line:
                    return True
    except (subprocess.TimeoutExpired, Exception):
        pass

    return False


def _check_windows_connection():
    """Check for active AnyDesk session on Windows."""
    try:
        result = subprocess.run(
            ['netstat', '-ano'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            # Get AnyDesk PIDs
            pid_result = subprocess.run(
                ['tasklist', '/FI', 'IMAGENAME eq AnyDesk.exe', '/FO', 'CSV'],
                capture_output=True, text=True
            )
            if pid_result.returncode == 0:
                # Extract PIDs and check for ESTABLISHED connections
                for line in result.stdout.split('\n'):
                    if 'ESTABLISHED' in line:
                        # Check if this connection belongs to AnyDesk
                        for pid_line in pid_result.stdout.split('\n'):
                            if 'AnyDesk' in pid_line:
                                parts = pid_line.split(',')
                                if len(parts) > 1:
                                    pid = parts[1].strip('"')
                                    if pid in line:
                                        return True
    except (subprocess.TimeoutExpired, Exception):
        pass

    return False


def start_anydesk():
    """Start AnyDesk application."""
    try:
        if CURRENT_OS == "darwin":
            subprocess.Popen(['open', '-a', 'AnyDesk'])
        elif CURRENT_OS == "linux":
            subprocess.Popen(['anydesk'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif CURRENT_OS == "windows":
            subprocess.Popen(['AnyDesk.exe'])
        time.sleep(2)
        return True
    except Exception as e:
        print(f"Error starting AnyDesk: {e}")
        return False


def connect_to_address(address, password=None):
    """
    Connect AnyDesk to a remote address.
    
    Args:
        address: The AnyDesk ID or alias to connect to.
        password: Optional password for unattended access.
    
    Returns:
        True if connection command was sent, False on error.
    """
    try:
        if not is_anydesk_running():
            start_anydesk()
            time.sleep(3)

        if CURRENT_OS == "linux":
            cmd = ['anydesk', address]
            if password:
                cmd.extend(['--with-password'])
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                proc.stdin.write(f"{password}\n".encode())
                proc.stdin.close()
            else:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        elif CURRENT_OS == "darwin":
            # macOS: open anydesk URI scheme
            subprocess.Popen(['open', f'anydesk:{address}'])

        elif CURRENT_OS == "windows":
            cmd = ['AnyDesk.exe', address]
            if password:
                cmd.extend(['--with-password'])
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                proc.stdin.write(f"{password}\n".encode())
                proc.stdin.close()
            else:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        time.sleep(3)
        return True

    except Exception as e:
        print(f"Error connecting to {address}: {e}")
        return False


def close_anydesk():
    """Close AnyDesk based on the current OS."""
    try:
        if CURRENT_OS == "darwin":
            subprocess.run(['osascript', '-e', 'tell application "AnyDesk" to quit'], check=False)
            subprocess.run(['pkill', '-f', 'AnyDesk'], check=False)
        elif CURRENT_OS == "linux":
            subprocess.run(['pkill', '-f', 'anydesk'], check=False)
        elif CURRENT_OS == "windows":
            subprocess.run(['taskkill', '/F', '/IM', 'AnyDesk.exe'], check=False)
        return True
    except Exception as e:
        print(f"Error closing AnyDesk: {e}")
        return False
