"""Shared state management for desk-awake."""

import threading
from datetime import datetime
from enum import Enum


class Status(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    RECONNECTING = "reconnecting"


class AppState:
    """Thread-safe application state shared between the web server and the automator."""

    def __init__(self):
        self._lock = threading.Lock()
        self._status = Status.IDLE
        self._stop_time = None
        self._end_date = None
        self._start_time_str = None
        self._anydesk_address = None
        self._anydesk_password = None
        self._webhook_url = None
        self._close_anydesk_on_exit = True
        self._sleep_on_exit = False
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 5
        self._last_activity = None
        self._connection_healthy = False
        self._logs = []
        self._max_logs = 200

    @property
    def status(self):
        with self._lock:
            return self._status

    @status.setter
    def status(self, value):
        with self._lock:
            self._status = value
            self._log(f"Status changed to: {value}")

    @property
    def stop_time(self):
        with self._lock:
            return self._stop_time

    @stop_time.setter
    def stop_time(self, value):
        with self._lock:
            self._stop_time = value

    @property
    def end_date(self):
        with self._lock:
            return self._end_date

    @end_date.setter
    def end_date(self, value):
        with self._lock:
            self._end_date = value

    @property
    def start_time_str(self):
        with self._lock:
            return self._start_time_str

    @start_time_str.setter
    def start_time_str(self, value):
        with self._lock:
            self._start_time_str = value

    @property
    def anydesk_address(self):
        with self._lock:
            return self._anydesk_address

    @anydesk_address.setter
    def anydesk_address(self, value):
        with self._lock:
            self._anydesk_address = value

    @property
    def anydesk_password(self):
        with self._lock:
            return self._anydesk_password

    @anydesk_password.setter
    def anydesk_password(self, value):
        with self._lock:
            self._anydesk_password = value

    @property
    def webhook_url(self):
        with self._lock:
            return self._webhook_url

    @webhook_url.setter
    def webhook_url(self, value):
        with self._lock:
            self._webhook_url = value

    @property
    def close_anydesk_on_exit(self):
        with self._lock:
            return self._close_anydesk_on_exit

    @close_anydesk_on_exit.setter
    def close_anydesk_on_exit(self, value):
        with self._lock:
            self._close_anydesk_on_exit = value

    @property
    def sleep_on_exit(self):
        with self._lock:
            return self._sleep_on_exit

    @sleep_on_exit.setter
    def sleep_on_exit(self, value):
        with self._lock:
            self._sleep_on_exit = value

    @property
    def reconnect_attempts(self):
        with self._lock:
            return self._reconnect_attempts

    @reconnect_attempts.setter
    def reconnect_attempts(self, value):
        with self._lock:
            self._reconnect_attempts = value

    @property
    def max_reconnect_attempts(self):
        with self._lock:
            return self._max_reconnect_attempts

    @property
    def connection_healthy(self):
        with self._lock:
            return self._connection_healthy

    @connection_healthy.setter
    def connection_healthy(self, value):
        with self._lock:
            self._connection_healthy = value

    @property
    def last_activity(self):
        with self._lock:
            return self._last_activity

    @last_activity.setter
    def last_activity(self, value):
        with self._lock:
            self._last_activity = value

    @property
    def logs(self):
        with self._lock:
            return list(self._logs)

    def _log(self, message):
        """Internal log (must be called with lock held or from property setter)."""
        entry = f"[{datetime.now().strftime('%H:%M:%S')}] {message}"
        self._logs.append(entry)
        if len(self._logs) > self._max_logs:
            self._logs = self._logs[-self._max_logs:]

    def log(self, message):
        """Add a log entry."""
        with self._lock:
            self._log(message)

    def get_info(self):
        """Get current state as a dict (for API responses)."""
        with self._lock:
            return {
                "status": self._status.value,
                "stop_time": self._stop_time.strftime('%Y-%m-%d %H:%M') if self._stop_time else None,
                "end_date": str(self._end_date) if self._end_date else None,
                "start_time": self._start_time_str,
                "anydesk_address": self._anydesk_address,
                "connection_healthy": self._connection_healthy,
                "reconnect_attempts": self._reconnect_attempts,
                "last_activity": self._last_activity.strftime('%H:%M:%S') if self._last_activity else None,
                "close_anydesk_on_exit": self._close_anydesk_on_exit,
                "sleep_on_exit": self._sleep_on_exit,
            }
