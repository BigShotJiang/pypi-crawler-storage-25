"""`mecon exp` — experiment lifecycle management."""

from __future__ import annotations

import json
import os
import sys
import time
import webbrowser
from typing import Any

import click
import httpx

CONFIG_FILE = os.path.expanduser("~/.mecon/config.toml")
DEFAULT_API_BASE = "https://ra.maestro.onl"
DEFAULT_PROFILE = "default"
EXP_API_PREFIX = "/api/experiment/admin"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_profiles() -> dict[str, dict[str, str]]:
    import tomllib

    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "rb") as fh:
        return tomllib.load(fh)


def _get_config() -> dict[str, str]:
    profiles = _read_profiles()
    active = os.environ.get("MECON_PROFILE", DEFAULT_PROFILE)
    cfg = profiles.get(active, profiles.get(DEFAULT_PROFILE, {}))
    return {
        "api_key": os.environ.get("MECON_API_KEY") or cfg.get("api_key", ""),
        "api_base": os.environ.get("MECON_API_BASE") or cfg.get("api_base", DEFAULT_API_BASE),
    }


def _exp_api(
    method: str,
    path: str,
    json_data: dict[str, Any] | None = None,
    timeout: float = 30,
    raw: bool = False,
) -> Any:
    """HTTP client for the experiment admin API with retry."""
    cfg = _get_config()
    if not cfg["api_key"]:
        click.echo("Error: No API key. Run 'mecon setup' first.", err=True)
        sys.exit(1)

    url = f"{cfg['api_base'].rstrip('/')}{EXP_API_PREFIX}{path}"
    headers = {"Authorization": f"Bearer {cfg['api_key']}"}

    MAX_ATTEMPTS = 3
    last_err: Exception | None = None
    response: httpx.Response | None = None

    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = httpx.request(
                method, url, json=json_data, headers=headers, timeout=timeout
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError) as exc:
            last_err = exc
            if attempt < MAX_ATTEMPTS:
                click.echo(
                    f"Warning: request failed ({exc.__class__.__name__}); "
                    f"retrying {attempt}/{MAX_ATTEMPTS}...",
                    err=True,
                )
                time.sleep(2 ** (attempt - 1))
                continue
            kind = (
                "cannot connect"
                if isinstance(exc, httpx.ConnectError)
                else "timed out"
                if isinstance(exc, httpx.TimeoutException)
                else "network request failed"
            )
            click.echo(f"Error: {kind} after {MAX_ATTEMPTS} attempts: {exc}", err=True)
            sys.exit(1)

        if response.status_code >= 500 and attempt < MAX_ATTEMPTS:
            click.echo(
                f"Warning: server returned {response.status_code} "
                f"({response.text[:200] or '<empty body>'}); "
                f"retrying {attempt}/{MAX_ATTEMPTS}...",
                err=True,
            )
            time.sleep(2 ** (attempt - 1))
            continue

        if response.status_code >= 400:
            click.echo(
                f"Error {response.status_code}: {response.text or '<empty body>'}",
                err=True,
            )
            sys.exit(1)

        break

    if response is None:
        click.echo(
            f"Error: exhausted retries without a response. Last error: {last_err}",
            err=True,
        )
        sys.exit(1)

    if raw:
        return response

    body = response.json()
    if isinstance(body, dict) and "success" in body:
        if body.get("success") is False:
            err = body.get("error") or body.get("message") or "request failed"
            click.echo(f"Error: {err}", err=True)
            sys.exit(1)
        return body.get("data", body)
    return body


def _base_url() -> str:
    return _get_config()["api_base"].rstrip("/")


# ---------------------------------------------------------------------------
# Group
# ---------------------------------------------------------------------------


@click.group("exp")
def exp_group() -> None:
    """Manage experiments: create, preview, publish, export."""


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@exp_group.command("init")
@click.argument("slug")
@click.option("--dir", "-d", "directory", default=None, help="Output directory (default: experiments/<slug>)")
def init(slug: str, directory: str | None) -> None:
    """Scaffold a local experiment source project template."""
    target = directory or os.path.join("experiments", slug)
    if os.path.exists(target):
        click.echo(f"Directory {target} already exists.", err=True)
        sys.exit(1)

    os.makedirs(os.path.join(target, "apps", "main", "pages"), exist_ok=True)

    experiment: dict[str, Any] = {
        "schema": "experiment-project/1",
        "slug": slug,
        "title": slug.replace("-", " ").title(),
        "locale": "en",
        "session": {
            "app_sequence": ["main"],
        },
    }
    with open(os.path.join(target, "experiment.json"), "w") as fh:
        json.dump(experiment, fh, indent=2)

    app: dict[str, Any] = {
        "schema": "experiment-app/1",
        "id": "main",
        "player": {},
        "pages": [
            {
                "id": "welcome",
                "type": "display",
                "title": "Welcome",
                "content": "Welcome to the experiment.",
            }
        ],
    }
    with open(os.path.join(target, "apps", "main", "app.json"), "w") as fh:
        json.dump(app, fh, indent=2)

    click.echo(f"Created experiment template at {target}/")
    click.echo("  experiment.json")
    click.echo("  apps/main/app.json")
    click.echo(f"\nNext: edit the files, then run: mecon exp push {target}")


# ---------------------------------------------------------------------------
# push  (placeholder — requires server-side source compilation endpoint)
# ---------------------------------------------------------------------------


@exp_group.command("push")
@click.argument("directory")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
@click.option("--publish", is_flag=True, help="Also promote preview to live after push")
def push(directory: str, as_json: bool, publish: bool) -> None:
    """Upload experiment source files → remote compile → create preview."""
    if not os.path.isdir(directory):
        click.echo(f"Directory not found: {directory}", err=True)
        sys.exit(1)

    exp_path = os.path.join(directory, "experiment.json")
    if not os.path.exists(exp_path):
        click.echo(f"No experiment.json found in {directory}", err=True)
        sys.exit(1)

    with open(exp_path) as fh:
        experiment = json.load(fh)
    slug = experiment.get("slug")
    if not slug:
        click.echo("experiment.json must have a 'slug' field", err=True)
        sys.exit(1)

    file_list: list[dict[str, str]] = []
    for root, _, filenames in os.walk(directory):
        for fname in sorted(filenames):
            if not fname.endswith((".json", ".js")):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, directory)
            with open(full) as fh:
                file_list.append({"path": rel, "content": fh.read()})

    if not file_list:
        click.echo("No JSON files found in directory", err=True)
        sys.exit(1)

    if not as_json:
        click.echo(f"Pushing {len(file_list)} file(s) for '{slug}'...")

    data = _exp_api("POST", "/push", json_data={"files": file_list})

    if as_json:
        click.echo(json.dumps(data, indent=2, default=str))
    else:
        click.echo(f"  Version:  {data.get('version', '?')}")
        click.echo(f"  Preview:  {data.get('previewUrl', '?')}")
        if data.get("pageCount"):
            click.echo(f"  Status:   {data['pageCount']}")

    if publish:
        if not as_json:
            click.echo(f"Publishing '{slug}' to live...")
        _set_status(slug, "live")
        if not as_json:
            click.echo(f"  Live:     https://{slug}.exp.maestro.onl/")


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------


@exp_group.command("pull")
@click.argument("slug")
@click.option("--dir", "-d", "-o", "directory", default=None, help="Output directory (default: experiments/<slug>)")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def pull(slug: str, directory: str | None, as_json: bool) -> None:
    """Download experiment source files to a local directory."""
    data = _exp_api("GET", f"/{slug}/source")

    files: list[dict[str, str]] = data.get("files", [])
    if not files:
        click.echo("No source files available for this experiment.", err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(data, indent=2, default=str))
        return

    target = directory or os.path.join("experiments", slug)
    os.makedirs(target, exist_ok=True)

    for f in files:
        path = os.path.join(target, f["path"])
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as fh:
            fh.write(f["content"])

    click.echo(f"Pulled {len(files)} file(s) to {target}/")
    for f in files:
        click.echo(f"  {f['path']}")
    click.echo(f"\nEdit locally, then: mecon exp push {target}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@exp_group.command("list")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def list_experiments(as_json: bool) -> None:
    """List your experiments."""
    data = _exp_api("GET", "/list")
    experiments: list[dict[str, Any]] = data if isinstance(data, list) else data.get("experiments", [])

    if as_json:
        click.echo(json.dumps(experiments, indent=2, default=str))
        return

    if not experiments:
        click.echo("No experiments found.")
        return

    click.echo(f"{'Slug':<36} {'Status':<10} {'Sessions':>8}  Title")
    click.echo("─" * 80)
    for exp in experiments:
        slug = str(exp.get("slug", ""))[:36]
        status = str(exp.get("status", ""))[:10]
        sessions = exp.get("session_count", exp.get("sessions", "?"))
        title = exp.get("title", "")
        click.echo(f"{slug:<36} {status:<10} {str(sessions):>8}  {title}")


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@exp_group.command("status")
@click.argument("slug")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def status(slug: str, as_json: bool) -> None:
    """Show experiment status and participation stats."""
    # Fetch metadata from list + stats for session counts
    all_experiments = _exp_api("GET", "/list")
    experiments = all_experiments if isinstance(all_experiments, list) else all_experiments.get("experiments", [])
    meta = next((e for e in experiments if e.get("slug") == slug), {})
    stats = _exp_api("GET", f"/{slug}/stats")

    combined = {**meta, **stats, "slug": slug}
    if as_json:
        click.echo(json.dumps(combined, indent=2, default=str))
        return

    base = _base_url()
    preview_token = meta.get("preview_token", "")
    click.echo(f"Slug:       {slug}")
    click.echo(f"Status:     {meta.get('status', '?')}")
    click.echo(f"Sessions:   {stats.get('total', meta.get('session_count', '?'))}")
    click.echo(f"Completed:  {stats.get('completed', 0)}")
    click.echo(f"Active:     {stats.get('active', 0)}")
    if stats.get("completion_rate") is not None:
        click.echo(f"Rate:       {stats['completion_rate']}%")
    if meta.get("created_at"):
        click.echo(f"Created:    {meta['created_at']}")
    if meta.get("updated_at"):
        click.echo(f"Updated:    {meta['updated_at']}")
    click.echo(f"Live URL:   https://{slug}.exp.maestro.onl/")
    if preview_token:
        click.echo(f"Preview:    https://{slug}.exp.maestro.onl/?pt={preview_token}")
    click.echo(f"Dashboard:  {base}/dashboard/experiments/{slug}")


# ---------------------------------------------------------------------------
# publish / pause / close  — status transitions
# ---------------------------------------------------------------------------


def _set_status(slug: str, new_status: str) -> None:
    _exp_api("PATCH", f"/{slug}/status", json_data={"status": new_status})


@exp_group.command("publish")
@click.argument("slug")
def publish(slug: str) -> None:
    """Set experiment status to live."""
    _set_status(slug, "live")
    click.echo(f"Experiment '{slug}' is now live.")


@exp_group.command("pause")
@click.argument("slug")
def pause(slug: str) -> None:
    """Pause a live experiment (stop accepting new sessions)."""
    _set_status(slug, "paused")
    click.echo(f"Experiment '{slug}' paused.")


@exp_group.command("close")
@click.argument("slug")
def close(slug: str) -> None:
    """Close an experiment (no further participation)."""
    _set_status(slug, "closed")
    click.echo(f"Experiment '{slug}' closed.")


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------


@exp_group.command("export")
@click.argument("slug")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["wide", "long"]),
    default="wide",
    show_default=True,
    help="Export format.",
)
@click.option(
    "--scope",
    type=click.Choice(["all", "completed"]),
    default="all",
    show_default=True,
    help="Which sessions to include.",
)
@click.option("--output", "-o", default=None, help="Write CSV to file (default: stdout)")
def export(slug: str, fmt: str, scope: str, output: str | None) -> None:
    """Export experiment response data as CSV."""
    cfg = _get_config()
    url = (
        f"{cfg['api_base'].rstrip('/')}{EXP_API_PREFIX}/{slug}/export"
        f"?format={fmt}&scope={scope}"
    )
    headers = {"Authorization": f"Bearer {cfg['api_key']}"}

    try:
        response = httpx.get(url, headers=headers, timeout=60, follow_redirects=True)
    except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError) as exc:
        click.echo(f"Error: request failed: {exc}", err=True)
        sys.exit(1)

    if response.status_code >= 400:
        click.echo(
            f"Error {response.status_code}: {response.text or '<empty body>'}",
            err=True,
        )
        sys.exit(1)

    content = response.text
    if output:
        with open(output, "w", encoding="utf-8") as fh:
            fh.write(content)
        click.echo(f"Exported {slug} ({fmt}/{scope}) to {output}")
    else:
        click.echo(content)


# ---------------------------------------------------------------------------
# sessions
# ---------------------------------------------------------------------------


@exp_group.command("sessions")
@click.argument("slug")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def sessions(slug: str, as_json: bool) -> None:
    """List participant sessions for an experiment."""
    data = _exp_api("GET", f"/{slug}/sessions")
    rows: list[dict[str, Any]] = data if isinstance(data, list) else data.get("sessions", [])

    if as_json:
        click.echo(json.dumps(rows, indent=2, default=str))
        return

    if not rows:
        click.echo("No sessions found.")
        return

    click.echo(f"{'Participant':<28} {'Status':<12} {'Started':<22} {'Completed'}")
    click.echo("─" * 90)
    for row in rows:
        pid = str(row.get("participant_id", row.get("id", "")))[:28]
        st = str(row.get("status", ""))[:12]
        started = str(row.get("started_at", row.get("created_at", "")))[:22]
        completed = str(row.get("completed_at", ""))
        click.echo(f"{pid:<28} {st:<12} {started:<22} {completed}")


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@exp_group.command("delete")
@click.argument("slug")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def delete(slug: str, yes: bool) -> None:
    """Delete an experiment and all its data."""
    if not yes:
        click.confirm(
            f"Delete experiment '{slug}' and all session data? This cannot be undone.",
            abort=True,
        )
    _exp_api("DELETE", f"/{slug}/delete")
    click.echo(f"Experiment '{slug}' deleted.")


# ---------------------------------------------------------------------------
# open
# ---------------------------------------------------------------------------


@exp_group.command("open")
@click.argument("slug")
def open_experiment(slug: str) -> None:
    """Open the experiment dashboard in a browser."""
    url = f"{_base_url()}/dashboard/experiments/{slug}"
    click.echo(f"Opening {url}")
    webbrowser.open(url)
