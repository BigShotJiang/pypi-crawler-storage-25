"""`mecon data` command group."""

from __future__ import annotations

import json
from pathlib import Path

import click

from maestro_economics import data as data_api


@click.group("data")
def data_group() -> None:
    """Browse, sample, download, and query RA Data datasets."""


@data_group.command("list")
@click.option("--family", default=None)
@click.option("--search", default=None)
@click.option("--tier", default=None)
@click.option("--json", "json_output", is_flag=True)
def list_datasets(family: str | None, search: str | None, tier: str | None, json_output: bool) -> None:
    """List available datasets."""
    try:
        rows = data_api.list(family=family, search=search, tier=tier)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(json.dumps(rows, indent=2))
        return
    for row in rows:
        status = row.get("catalog_visibility", "published")
        click.echo(f"{row['slug']:<42} {status:<12} {row['name']}")


@data_group.command("info")
@click.argument("slug")
@click.option("--json", "json_output", is_flag=True)
def info(slug: str, json_output: bool) -> None:
    """Show dataset metadata."""
    try:
        row = data_api.info(slug)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(json.dumps(row, indent=2))
        return
    click.echo(row["name"])
    click.echo(f"Slug:       {row['slug']}")
    click.echo(f"Coverage:   {row.get('geo_scope')} · {row.get('time_range')}")
    click.echo(f"Visibility: {row.get('catalog_visibility')}")
    click.echo(f"Version:    {row.get('version')}")
    if row.get("citation"):
        click.echo(f"Citation:   {row['citation']}")


@data_group.command("cite")
@click.argument("slug")
def cite(slug: str) -> None:
    """Print dataset citation."""
    try:
        click.echo(data_api.cite(slug))
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc


@data_group.command("query-url")
@click.argument("slug")
@click.option("--resolution", default=None)
@click.option("--json", "json_output", is_flag=True)
def query_url(slug: str, resolution: str | None, json_output: bool) -> None:
    """Return a signed Parquet URL for DuckDB/httpfs."""
    try:
        signed = data_api.signed_url(slug, endpoint="query-url", resolution=resolution)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(json.dumps(signed, indent=2))
    else:
        click.echo(signed["url"])


@data_group.command("sample")
@click.argument("slug")
@click.option("--output", "-o", default=None)
def sample(slug: str, output: str | None) -> None:
    """Download the sample Parquet or print a small preview."""
    try:
        result = data_api.sample(slug, output=output)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if output:
        click.echo(f"Saved {Path(output).expanduser()}")
    else:
        click.echo(result.head(20).to_string(index=False))


@data_group.command("download")
@click.argument("slug")
@click.option("--resolution", default=None)
@click.option("--format", "file_format", type=click.Choice(["parquet", "csv"]), default="parquet")
@click.option("--output", "-o", default=None)
def download(slug: str, resolution: str | None, file_format: str, output: str | None) -> None:
    """Download a dataset file."""
    try:
        path = data_api.download(slug, output=output, resolution=resolution, format=file_format)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Saved {path}")


@data_group.command("query")
@click.argument("slug")
@click.argument("sql")
@click.option("--resolution", default=None)
@click.option("--json", "json_output", is_flag=True)
def query(slug: str, sql: str, resolution: str | None, json_output: bool) -> None:
    """Run a local DuckDB query against a signed remote Parquet URL."""
    try:
        df = data_api.query(slug, sql, resolution=resolution)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(df.to_json(orient="records", indent=2))
    else:
        click.echo(df.to_string(index=False))


@data_group.command("head")
@click.argument("slug")
@click.option("--rows", default=10, type=int, help="Number of rows (max 1000)")
@click.option("--json", "json_output", is_flag=True)
def head(slug: str, rows: int, json_output: bool) -> None:
    """Show the first N rows of a dataset."""
    try:
        df = data_api.head(slug, rows=rows)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(df.to_json(orient="records", indent=2))
        return
    click.echo(df.to_string(index=False))
    try:
        meta = data_api.info(slug)
        total = meta.get("row_count", "?")
        click.echo(f"\n({rows} of {total} rows)")
    except Exception:
        click.echo(f"\n({rows} rows shown)")


@data_group.command("describe")
@click.argument("slug")
@click.option("--json", "json_output", is_flag=True)
def describe(slug: str, json_output: bool) -> None:
    """Show dataset profile with column statistics."""
    try:
        meta = data_api.describe(slug)
    except data_api.DataApiError as exc:
        raise click.ClickException(str(exc)) from exc
    if json_output:
        click.echo(json.dumps(meta, indent=2, default=str))
        return

    name = meta.get("name", slug)
    row_count = meta.get("row_count", "?")
    col_count = meta.get("column_count", "?")
    time_range = meta.get("time_range", "?")
    geo = meta.get("geo_scope", "?")

    click.echo(f"\n{name}")
    if isinstance(row_count, int):
        click.echo(f"{row_count:,} rows × {col_count} columns | {time_range} | {geo}\n")
    else:
        click.echo(f"{row_count} rows × {col_count} columns | {time_range} | {geo}\n")

    stats = meta.get("stats", {})
    columns = stats.get("columns", []) if isinstance(stats, dict) else []
    if columns:
        click.echo(f"{'Column':<20} {'Type':<8} {'Pop%':>6} {'Unique':>8} {'Min':>12} {'Max':>12}")
        click.echo("─" * 70)
        for col in columns:
            col_name = str(col.get("name", "?"))[:20]
            dtype = str(col.get("type", "?"))[:8]
            pct = col.get("pct_populated")
            pct_str = f"{pct:.0f}%" if isinstance(pct, (int, float)) else "?"
            unique = col.get("unique_count", "?")
            mn = str(col.get("min_value", ""))[:12]
            mx = str(col.get("max_value", ""))[:12]
            click.echo(f"{col_name:<20} {dtype:<8} {pct_str:>6} {unique:>8} {mn:>12} {mx:>12}")

    sources = meta.get("sources", [])
    if sources:
        click.echo(f"\nSources: {', '.join(str(s) for s in sources)}")

    cite = meta.get("citation_text")
    if cite:
        click.echo(f"Citation: {cite}")
