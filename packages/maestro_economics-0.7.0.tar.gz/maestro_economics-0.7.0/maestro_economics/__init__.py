"""Maestro Economics — CLI and SDK for RA Data platform."""
__version__ = "0.7.0"
