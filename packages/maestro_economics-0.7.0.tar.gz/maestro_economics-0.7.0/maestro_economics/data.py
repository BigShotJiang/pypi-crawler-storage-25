"""RA Data API client for dataset catalog, signed downloads, and DuckDB queries."""

from __future__ import annotations

import os
import tempfile
import time
import tomllib
import urllib.parse
import uuid
from pathlib import Path
from typing import Any

import httpx

CONFIG_FILE = os.path.expanduser("~/.mecon/config.toml")
DEFAULT_API_BASE = "https://ra.maestro.onl"
DEFAULT_PROFILE = "default"
DATA_API_PREFIX = "/api/ra/data/v1"


class DataApiError(RuntimeError):
    """Raised when the RA Data API returns an error."""


def _read_profiles() -> dict[str, dict[str, str]]:
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "rb") as file:
        return tomllib.load(file)


def get_config(profile: str | None = None) -> dict[str, str]:
    profiles = _read_profiles()
    active = profile or os.environ.get("MECON_PROFILE", DEFAULT_PROFILE)
    cfg = profiles.get(active, profiles.get(DEFAULT_PROFILE, {}))
    return {
        "api_key": os.environ.get("MECON_API_KEY") or cfg.get("api_key", ""),
        "api_base": os.environ.get("MECON_API_BASE") or cfg.get("api_base", DEFAULT_API_BASE),
    }


def _request(
    method: str,
    path: str,
    json_data: dict[str, Any] | None = None,
    timeout: float = 30,
) -> dict[str, Any]:
    cfg = get_config()
    if not cfg["api_key"]:
        raise DataApiError("No API key. Run 'mecon login' or 'mecon setup' first.")

    url = f"{cfg['api_base'].rstrip('/')}{DATA_API_PREFIX}{path}"
    headers = {"Authorization": f"Bearer {cfg['api_key']}"}

    last_error: Exception | None = None
    for attempt in range(1, 4):
        try:
            response = httpx.request(method, url, json=json_data, headers=headers, timeout=timeout)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError) as exc:
            last_error = exc
            if attempt < 3:
                time.sleep(2 ** (attempt - 1))
                continue
            raise DataApiError(f"Request failed after 3 attempts: {exc}") from exc

        if response.status_code >= 500 and attempt < 3:
            time.sleep(2 ** (attempt - 1))
            continue
        if response.status_code >= 400:
            raise DataApiError(f"HTTP {response.status_code}: {response.text or '<empty body>'}")
        payload = response.json()
        if not payload.get("success"):
            raise DataApiError(str(payload.get("error") or payload))
        return payload["data"]

    raise DataApiError(f"Request failed: {last_error}")


def list(family: str | None = None, search: str | None = None, tier: str | None = None) -> list[dict[str, Any]]:  # noqa: A001
    params: dict[str, str] = {}
    if family:
        params["family"] = family
    if search:
        params["search"] = search
    if tier:
        params["tier"] = tier
    suffix = "?" + urllib.parse.urlencode(params) if params else ""
    return _request("GET", f"/datasets{suffix}")  # type: ignore[return-value]


def info(slug: str) -> dict[str, Any]:
    return _request("GET", f"/datasets/{slug}")


def cite(slug: str) -> str:
    data = _request("GET", f"/datasets/{slug}/cite")
    return str(data["citation"])


def signed_url(
    slug: str,
    *,
    endpoint: str = "download",
    resolution: str | None = None,
    idempotency_key: str | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"idempotency_key": idempotency_key or str(uuid.uuid4())}
    if resolution and resolution != "primary":
        body["resolution"] = resolution
    return _request("POST", f"/datasets/{slug}/{endpoint}", body, timeout=45)


def _download_url(url: str, output: str | Path) -> Path:
    path = Path(output).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with httpx.stream("GET", url, follow_redirects=True, timeout=None) as response:
        response.raise_for_status()
        with path.open("wb") as file:
            for chunk in response.iter_bytes():
                if chunk:
                    file.write(chunk)
    return path


def download(
    slug: str,
    *,
    output: str | Path | None = None,
    resolution: str | None = None,
    format: str = "parquet",
) -> Path:
    signed = signed_url(slug, endpoint="download", resolution=resolution)
    suffix = "csv" if format == "csv" else "parquet"
    target = Path(output or f"{slug}.{suffix}")
    parquet_path = target if suffix == "parquet" else target.with_suffix(".parquet")
    _download_url(signed["url"], parquet_path)
    if format == "csv":
        import pandas as pd

        df = pd.read_parquet(parquet_path)
        df.to_csv(target, index=False)
        if parquet_path != target:
            parquet_path.unlink(missing_ok=True)
    return target


def sample(slug: str, *, output: str | Path | None = None):
    signed = signed_url(slug, endpoint="sample")
    if output:
        return _download_url(signed["url"], output)
    import pandas as pd

    with tempfile.NamedTemporaryFile(suffix=".parquet") as tmp:
        _download_url(signed["url"], tmp.name)
        return pd.read_parquet(tmp.name)


def load(slug: str, *, resolution: str | None = None):
    import pandas as pd

    signed = signed_url(slug, endpoint="download", resolution=resolution)
    with tempfile.NamedTemporaryFile(suffix=".parquet") as tmp:
        _download_url(signed["url"], tmp.name)
        return pd.read_parquet(tmp.name)


def query(slug: str, sql: str, *, resolution: str | None = None):
    import duckdb

    signed = signed_url(slug, endpoint="query-url", resolution=resolution)
    url = signed["url"].replace("'", "''")
    con = duckdb.connect()
    try:
        con.execute("INSTALL httpfs")
    except Exception:
        pass
    con.execute("LOAD httpfs")
    con.execute(f"CREATE OR REPLACE VIEW data AS SELECT * FROM read_parquet('{url}')")
    return con.execute(sql).fetchdf()


def head(slug: str, *, rows: int = 10) -> "pd.DataFrame":
    """Return the first N rows of a dataset via the query API."""
    return query(slug, f"SELECT * FROM data LIMIT {min(rows, 1000)}")


def describe(slug: str) -> dict[str, Any]:
    """Return dataset metadata including column stats from the API (pre-computed, no DuckDB)."""
    return info(slug)


__all__ = [
    "DataApiError",
    "cite",
    "describe",
    "download",
    "head",
    "info",
    "list",
    "load",
    "query",
    "sample",
    "signed_url",
]
