# maestro-economics

CLI and SDK for the RA Data platform — datasets, compute, and experiments.

```bash
pip install maestro-economics
mecon --help
```
