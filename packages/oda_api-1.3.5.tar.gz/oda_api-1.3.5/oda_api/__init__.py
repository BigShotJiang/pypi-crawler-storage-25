import pkgutil
import os
from importlib.metadata import version as pkg_ver


__author__ = "Andrea Tramacere"
__version__ = pkg_ver("oda-api")

pkg_dir = os.path.abspath(os.path.dirname(__file__))
pkg_name = os.path.basename(pkg_dir)


__all__=[]
for importer, modname, ispkg in pkgutil.walk_packages(path=[pkg_dir],
                                                      prefix=pkg_name+'.',
                                                      onerror=lambda x: None):

    if ispkg == True:
        __all__.append(modname)
    else:
        pass



conf_dir=os.path.dirname(__file__)+'/config_dir'

env_phat=os.environ.get('CDCI_API_PLUGIN_CONF_FILE')

if env_phat is not None:
    conf_dir=env_phat

conf_file=os.path.join(conf_dir,'data_server_conf.yml')

context_file = ".oda_api_context"

