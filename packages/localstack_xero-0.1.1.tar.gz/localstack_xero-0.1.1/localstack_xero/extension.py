"""LocalStack extension that starts the Xero API emulator alongside LocalStack."""
import logging
import os

from localstack.extensions.api import Extension

LOG = logging.getLogger(__name__)

# Environment variable overrides
ENV_XERO_PORT = "XERO_PORT"
ENV_XERO_HOST = "XERO_HOST"


class XeroExtension(Extension):
    """
    LocalStack extension that runs the Xero API emulator as an embedded HTTP
    server.  Once started, the emulator is reachable at:

        http://xero.localhost.localstack.cloud:<edge-port>

    or directly on the configured XERO_PORT (default 5001).

    Configure the xero-python SDK (or any Xero client) by pointing it at this
    URL instead of https://api.xero.com.
    """

    name = "xero"

    def on_platform_start(self) -> None:
        """Called when LocalStack starts – launch the emulator thread."""
        from xero_local import server as xero_server

        host = os.environ.get(ENV_XERO_HOST, "0.0.0.0")
        port = int(os.environ.get(ENV_XERO_PORT, str(xero_server.DEFAULT_PORT)))
        LOG.info("Starting Xero emulator on %s:%d", host, port)
        xero_server.start(host=host, port=port)

    def on_platform_ready(self) -> None:
        """Called when LocalStack is fully initialised."""
        try:
            from localstack import config, constants
            edge_port = config.get_edge_port_http()
            url = f"http://xero.{constants.LOCALHOST_HOSTNAME}:{edge_port}"
        except Exception:
            port = int(os.environ.get(ENV_XERO_PORT, "5001"))
            url = f"http://localhost:{port}"

        LOG.info("Xero emulator ready: %s", url)
        LOG.info(
            "Point your Xero client at this URL. "
            "Set XERO_BASE_URL=%s in your application.",
            url,
        )

    def update_gateway_routes(self, router) -> None:
        """
        Register a catch-all route under /xero/ in LocalStack's gateway so
        that requests to http://<localstack>/xero/... are forwarded to the
        emulator.
        """
        try:
            import requests as _requests

            from xero_local import server as xero_server

            port = int(os.environ.get(ENV_XERO_PORT, str(xero_server.DEFAULT_PORT)))
            base = f"http://127.0.0.1:{port}"

            def _proxy(request, **kwargs):
                # Strip the /xero prefix and forward the rest
                path = request.path
                if path.startswith("/xero"):
                    path = path[len("/xero"):]
                target = f"{base}{path}"
                resp = _requests.request(
                    method=request.method,
                    url=target,
                    headers={k: v for k, v in request.headers if k.lower() != "host"},
                    data=request.get_data(),
                    params=request.args,
                    allow_redirects=False,
                    timeout=10,
                )
                from rolo import Response
                return Response(
                    response=resp.content,
                    status=resp.status_code,
                    headers=dict(resp.headers),
                )

            router.add("/xero", _proxy)
            router.add("/xero/<path:path>", _proxy)
        except Exception as exc:
            LOG.warning("Could not register gateway routes: %s", exc)
