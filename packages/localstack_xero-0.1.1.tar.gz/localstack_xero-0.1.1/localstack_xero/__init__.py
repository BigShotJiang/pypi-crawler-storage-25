"""LocalStack extension wrapping the Xero emulator."""
