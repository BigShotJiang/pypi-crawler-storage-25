"""
Snapshot tests for the OAuth2 / Identity API.

Record against real Xero API:
    pytest tests/test_auth_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_auth_snapshot.py
"""
import pytest

try:
    from localstack_snapshot.snapshots.transformer import KeyValueBasedTransformer, RegexTransformer
except ImportError:
    pytest.skip("localstack-snapshot not installed (requires Python >=3.10)", allow_module_level=True)  # noqa: E501

_UUID_RE = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
_XERO_DATE_RE = r"/Date\(\d+\+?\d*\)/"


@pytest.mark.snapshot
def test_connections_list(xero_http, snapshot):
    """GET /connections returns a list with at least one organisation tenant."""
    snapshot.add_transformer(RegexTransformer(_UUID_RE, "<uuid>"))
    snapshot.add_transformer(RegexTransformer(_XERO_DATE_RE, "<xero-date>"))
    snapshot.add_transformer(
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("createdDateUtc", "updatedDateUtc", "DateTimeUTC") else None,
            "<datetime>",
        )
    )
    snapshot.add_transformer(
        KeyValueBasedTransformer(lambda k, v: v if k == "ProviderName" else None, "<provider>")
    )
    # tenantName is org-specific — mask so emulator and real API can both match.
    snapshot.add_transformer(
        KeyValueBasedTransformer(lambda k, v: v if k == "tenantName" else None, "<tenant-name>")
    )

    resp = xero_http.get("/connections")
    assert resp.status_code == 200

    data = resp.json()
    assert isinstance(data, list)
    assert len(data) >= 1
    assert data[0]["tenantType"] == "ORGANISATION"

    snapshot.match("connections", data)


@pytest.mark.snapshot
def test_token_endpoint(xero_http, snapshot):
    """
    POST /connect/token with client-credentials grant returns a valid token payload.

    Note: the real Xero API requires a valid client_id/secret for this endpoint.
    When running against the emulator the grant is accepted without validation.
    When running against the real API we skip this test because the authorization
    code grant (not client_credentials) is the correct flow – the token we already
    hold was obtained via the browser flow.
    """
    if xero_http.real_api:
        pytest.skip("Token endpoint tested via browser flow; snapshot not applicable for real API")

    snapshot.add_transformer(
        KeyValueBasedTransformer(
            lambda k, v: v if k == "access_token" else None,
            "<access_token>",
        )
    )
    snapshot.add_transformer(
        KeyValueBasedTransformer(
            lambda k, v: v if k == "refresh_token" else None,
            "<refresh_token>",
        )
    )
    snapshot.add_transformer(
        KeyValueBasedTransformer(
            lambda k, v: v if k == "authentication_event_id" else None,
            "<uuid>",
        )
    )

    resp = xero_http.post(
        "/connect/token",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={
            "grant_type": "client_credentials",
            "client_id": "test-client",
            "client_secret": "test-secret",
        },
    )
    assert resp.status_code == 200

    data = resp.json()
    assert data["token_type"] == "Bearer"
    assert data["expires_in"] == 1800
    assert "access_token" in data
    assert "refresh_token" in data

    snapshot.match("token_response", data)
