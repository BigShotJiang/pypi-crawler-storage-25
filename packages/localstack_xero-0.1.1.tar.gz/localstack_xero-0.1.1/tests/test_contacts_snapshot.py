"""
Snapshot tests for the Contacts API.

Record against real Xero API:
    pytest tests/test_contacts_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_contacts_snapshot.py
"""
import uuid

import pytest

try:
    from localstack_snapshot.snapshots.transformer import (
        KeyValueBasedTransformer,
        RegexTransformer,
        SortingTransformer,
    )
except ImportError:
    pytest.skip("localstack-snapshot not installed (requires Python >=3.10)", allow_module_level=True)  # noqa: E501

_UUID_RE = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
# Xero /Date(epoch)/ timestamp format
_XERO_DATE_RE = r"/Date\(\d+\+?\d*\)/"


def _contact_payload(account_number: str) -> dict:
    return {
        "Contacts": [
            {
                "Name": "Snapshot Corp",
                "FirstName": "Alice",
                "LastName": "Smith",
                "AccountNumber": account_number,
                "ContactStatus": "ACTIVE",
                "Addresses": [
                    {
                        "AddressType": "STREET",
                        "AddressLine1": "1 Test Lane",
                        "City": "Auckland",
                        "PostalCode": "1010",
                        "Country": "NZ",
                    }
                ],
                "Phones": [
                    {
                        "PhoneType": "DEFAULT",
                        "PhoneNumber": "+64-9-000-0001",
                    }
                ],
            }
        ]
    }


def _standard_transformers():
    return [
        RegexTransformer(_UUID_RE, "<uuid>"),
        RegexTransformer(_XERO_DATE_RE, "<xero-date>"),
        # Random per-run account numbers (SNAP-XXXXXXXX[-SUFFIX])
        RegexTransformer(r"SNAP-[0-9A-F]{8}(?:-\w+)?", "<account_number>"),
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("UpdatedDateUTC", "CreatedDateUTC", "DateTimeUTC") else None,
            "<datetime>",
        ),
        # Envelope fields that vary per request/app
        KeyValueBasedTransformer(
            lambda k, v: v if k == "ProviderName" else None,
            "<provider>",
        ),
        # Sort phones by PhoneType so ordering differences between real API and
        # emulator don't cause false failures.
        SortingTransformer("Phones", lambda p: p.get("PhoneType", "")),
    ]


@pytest.fixture
def account_number():
    """Unique per-run account number so re-runs don't collide on real API."""
    return f"SNAP-{uuid.uuid4().hex[:8].upper()}"


@pytest.fixture
def created_contact(xero_http, account_number):
    """Create a contact and yield its dict; archive on teardown (real API only)."""
    resp = xero_http.post("/api.xro/2.0/Contacts", json=_contact_payload(account_number))
    assert resp.status_code == 200, resp.text
    contact = resp.json()["Contacts"][0]
    yield contact
    if xero_http.real_api:
        cid = contact["ContactID"]
        xero_http.post(
            f"/api.xro/2.0/Contacts/{cid}",
            json={"Contacts": [{"ContactStatus": "ARCHIVED"}]},
        )


@pytest.mark.snapshot
def test_list_contacts_empty(xero_http, snapshot):
    """GET /Contacts on a fresh tenant returns an empty list."""
    if xero_http.real_api:
        pytest.skip("Real API has pre-existing contacts; empty-list snapshot not applicable")

    snapshot.add_transformers_list(_standard_transformers())

    resp = xero_http.get("/api.xro/2.0/Contacts")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Status"] == "OK"
    assert data["Contacts"] == []

    snapshot.match("list_empty", data)


@pytest.mark.snapshot
def test_create_contact(xero_http, snapshot, account_number):
    """POST /Contacts creates a contact and returns it with a ContactID."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = xero_http.post("/api.xro/2.0/Contacts", json=_contact_payload(account_number))
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Status"] == "OK"
    contact = data["Contacts"][0]
    assert contact["HasValidationErrors"] is False
    assert contact["Name"] == "Snapshot Corp"
    assert "ContactID" in contact

    snapshot.match("create_contact", data)

    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Contacts/{contact['ContactID']}",
            json={"Contacts": [{"ContactStatus": "ARCHIVED"}]},
        )


@pytest.mark.snapshot
def test_get_contact_by_id(xero_http, snapshot, created_contact):
    """GET /Contacts/{id} returns the full contact record."""
    snapshot.add_transformers_list(_standard_transformers())

    cid = created_contact["ContactID"]
    resp = xero_http.get(f"/api.xro/2.0/Contacts/{cid}")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Status"] == "OK"
    assert data["Contacts"][0]["ContactID"] == cid

    snapshot.match("get_by_id", data)


@pytest.mark.snapshot
def test_get_contact_not_found(xero_http, snapshot):
    """GET /Contacts/{unknown-id} returns 404."""
    resp = xero_http.get("/api.xro/2.0/Contacts/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404

    # Real Xero API returns plain text on 404; emulator returns JSON.
    try:
        body = resp.json()
    except Exception:
        body = {"error": resp.text.strip()}

    snapshot.match("get_not_found", body)


@pytest.mark.snapshot
def test_update_contact(xero_http, snapshot, created_contact, account_number):
    """POST /Contacts/{id} updates fields and returns the updated record."""
    snapshot.add_transformers_list(_standard_transformers())

    cid = created_contact["ContactID"]
    resp = xero_http.post(
        f"/api.xro/2.0/Contacts/{cid}",
        json={"Contacts": [{"Name": "Snapshot Corp (Updated)", "AccountNumber": f"{account_number}-UPD"}]},  # noqa: E501
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Contacts"][0]["Name"] == "Snapshot Corp (Updated)"

    snapshot.match("update_contact", data)


@pytest.mark.snapshot
def test_create_contact_duplicate_name(xero_http, snapshot, created_contact, account_number):
    """Second POST with the same Name succeeds — Xero allows duplicate contact names."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = xero_http.post("/api.xro/2.0/Contacts", json=_contact_payload(f"{account_number}-DUP"))
    assert resp.status_code == 200
    data = resp.json()

    snapshot.match("duplicate_name_response", data)

    if xero_http.real_api:
        cid = data["Contacts"][0]["ContactID"]
        xero_http.post(
            f"/api.xro/2.0/Contacts/{cid}",
            json={"Contacts": [{"ContactStatus": "ARCHIVED"}]},
        )


@pytest.mark.snapshot
def test_list_contacts_filter_by_ids(xero_http, snapshot, created_contact):
    """GET /Contacts?IDs={id} returns only that contact."""
    snapshot.add_transformers_list(_standard_transformers())

    cid = created_contact["ContactID"]
    resp = xero_http.get(f"/api.xro/2.0/Contacts?IDs={cid}")
    assert resp.status_code == 200

    data = resp.json()
    contacts = data["Contacts"]
    assert len(contacts) >= 1
    assert any(c["ContactID"] == cid for c in contacts)

    snapshot.match("filter_by_ids", data)


@pytest.mark.snapshot
def test_list_contacts_filter_by_name(xero_http, snapshot, created_contact):
    """GET /Contacts?Name={name} returns only contacts with that exact name.

    NOTE: The real Xero API uses ?where= clauses for filtering and ignores the
    ?Name= shorthand (returns all contacts). This is an emulator-only shortcut.
    """
    if xero_http.real_api:
        pytest.skip("Real Xero API does not support ?Name= shorthand filter")

    snapshot.add_transformers_list(_standard_transformers())

    name = created_contact["Name"]
    resp = xero_http.get("/api.xro/2.0/Contacts", params={"Name": name})
    assert resp.status_code == 200

    data = resp.json()
    contacts = data["Contacts"]
    assert len(contacts) >= 1
    assert any(c["Name"] == name for c in contacts)

    snapshot.match("filter_by_name", data)


@pytest.mark.snapshot
def test_create_contact_missing_name(xero_http, snapshot):
    """POST /Contacts without a Name returns 400."""
    snapshot.add_transformers_list(_standard_transformers())

    resp = xero_http.post(
        "/api.xro/2.0/Contacts",
        json={"Contacts": [{"FirstName": "No", "LastName": "Name"}]},
    )
    assert resp.status_code == 400

    snapshot.match("missing_name_response", resp.json())
