"""Tests for the /api.xro/2.0/Invoices endpoint."""
import json


def _make_contact(client, headers, name="Test Customer"):
    resp = client.post(
        "/api.xro/2.0/Contacts",
        headers=headers,
        data=json.dumps({"Contacts": [{"Name": name, "IsCustomer": True}]}),
    )
    return resp.get_json()["Contacts"][0]


def _invoice_payload(contact_id, invoice_number="INV-001", inv_type="ACCREC"):
    return {
        "Invoices": [
            {
                "Type": inv_type,
                "InvoiceNumber": invoice_number,
                "Reference": "Stripe invoice inv_123",
                "Contact": {"ContactID": contact_id},
                "Date": "2024-01-15",
                "DueDate": "2024-02-15",
                "Status": "AUTHORISED",
                "CurrencyCode": "USD",
                "Total": 100.00,
                "AmountPaid": 0.00,
                "LineItems": [
                    {
                        "Description": "Monthly subscription",
                        "Quantity": 1,
                        "UnitAmount": 100.00,
                        "LineAmount": 100.00,
                        "AccountCode": "200",
                        "TaxType": "TAX010",
                    }
                ],
            }
        ]
    }


def test_list_invoices_empty(client, auth_headers):
    resp = client.get("/api.xro/2.0/Invoices", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Invoices"] == []
    assert data["pagination"]["itemCount"] == 0


def test_create_invoice(client, auth_headers):
    contact = _make_contact(client, auth_headers)
    resp = client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"])),
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Status"] == "OK"
    inv = data["Invoices"][0]
    assert inv["Type"] == "ACCREC"
    assert inv["InvoiceNumber"] == "INV-001"
    assert "InvoiceID" in inv


def test_create_invoice_duplicate_number(client, auth_headers):
    # Real Xero API allows duplicate invoice numbers; emulator matches that behaviour.
    contact = _make_contact(client, auth_headers)
    client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"])),
    )
    resp = client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"])),
    )
    assert resp.status_code == 200
    assert resp.get_json()["Status"] == "OK"


def test_get_invoice_by_id(client, auth_headers):
    contact = _make_contact(client, auth_headers)
    create_resp = client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"])),
    )
    invoice_id = create_resp.get_json()["Invoices"][0]["InvoiceID"]

    resp = client.get(f"/api.xro/2.0/Invoices/{invoice_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["Invoices"][0]["InvoiceID"] == invoice_id


def test_get_invoice_not_found(client, auth_headers):
    resp = client.get("/api.xro/2.0/Invoices/nonexistent", headers=auth_headers)
    assert resp.status_code == 404


def test_filter_invoices_by_contact(client, auth_headers):
    c1 = _make_contact(client, auth_headers, "Customer A")
    c2 = _make_contact(client, auth_headers, "Customer B")
    client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(c1["ContactID"], "INV-A1")),
    )
    client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(c2["ContactID"], "INV-B1")),
    )

    resp = client.get(f"/api.xro/2.0/Invoices?ContactIDs={c1['ContactID']}", headers=auth_headers)
    invoices = resp.get_json()["Invoices"]
    assert len(invoices) == 1
    assert invoices[0]["InvoiceNumber"] == "INV-A1"


def test_filter_invoices_by_number(client, auth_headers):
    contact = _make_contact(client, auth_headers)
    client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"], "INV-X1")),
    )
    client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"], "INV-X2")),
    )

    resp = client.get("/api.xro/2.0/Invoices?InvoiceNumbers=INV-X2", headers=auth_headers)
    invoices = resp.get_json()["Invoices"]
    assert len(invoices) == 1
    assert invoices[0]["InvoiceNumber"] == "INV-X2"


def test_update_invoice_status(client, auth_headers):
    contact = _make_contact(client, auth_headers)
    create_resp = client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"])),
    )
    invoice_id = create_resp.get_json()["Invoices"][0]["InvoiceID"]

    resp = client.post(
        f"/api.xro/2.0/Invoices/{invoice_id}",
        headers=auth_headers,
        data=json.dumps({"Invoices": [{"Status": "VOIDED"}]}),
    )
    assert resp.status_code == 200
    assert resp.get_json()["Invoices"][0]["Status"] == "VOIDED"


def test_create_accpay_invoice(client, auth_headers):
    contact = _make_contact(client, auth_headers)
    resp = client.post(
        "/api.xro/2.0/Invoices",
        headers=auth_headers,
        data=json.dumps(_invoice_payload(contact["ContactID"], "FEE-001", "ACCPAY")),
    )
    assert resp.status_code == 200
    assert resp.get_json()["Invoices"][0]["Type"] == "ACCPAY"


def test_create_invoice_discount_invalid(client, auth_headers):
    """DiscountRate with pre-discounted UnitAmount produces Xero validation error.

    Xero requires UnitAmount to be the ORIGINAL (pre-discount) price when
    DiscountRate is set. LineAmount must equal UnitAmount * Qty * (1 - Rate/100).

    This mirrors the real-API error:
      "The UnitAmount should be used when specifying a discount for a line item."
    """
    contact = _make_contact(client, auth_headers)
    payload = {
        "Invoices": [
            {
                "Type": "ACCREC",
                "Status": "AUTHORISED",
                "Contact": {"ContactID": contact["ContactID"]},
                "Date": "2026-05-01",
                "DueDate": "2026-05-01",
                "LineItems": [
                    {
                        "Description": "1 × Base Seat (at $45.00 / month)",
                        # UnitAmount is already post-discount (should be 45.00)
                        "UnitAmount": 27.00,
                        "DiscountRate": 40.00,
                        "DiscountEnteredAsPercent": True,
                        # Xero expects 27.00 * (1 - 0.40) = 16.20, not 27.00
                        "LineAmount": 27.00,
                        "Quantity": 1.0,
                        "AccountCode": "200",
                        "TaxType": "NONE",
                    }
                ],
            }
        ]
    }
    resp = client.post("/api.xro/2.0/Invoices", headers=auth_headers, json=payload)
    assert resp.status_code == 400
    data = resp.get_json()
    assert data["Type"] == "ValidationException"
    msgs = [e["Message"] for e in data["Elements"][0]["ValidationErrors"]]
    assert any("UnitAmount" in m for m in msgs)
    assert any("16.20" in m for m in msgs)


def test_create_invoice_discount_valid(client, auth_headers):
    """DiscountRate with ORIGINAL UnitAmount (pre-discount) creates successfully."""
    contact = _make_contact(client, auth_headers)
    payload = {
        "Invoices": [
            {
                "Type": "ACCREC",
                "Status": "AUTHORISED",
                "Contact": {"ContactID": contact["ContactID"]},
                "Date": "2026-05-01",
                "DueDate": "2026-05-01",
                "LineItems": [
                    {
                        "Description": "1 × Base Seat (at $45.00 / month)",
                        "UnitAmount": 45.00,   # original price
                        "DiscountRate": 40.00,
                        "DiscountEnteredAsPercent": True,
                        "LineAmount": 27.00,   # 45.00 * 1.0 * 0.60 = 27.00
                        "Quantity": 1.0,
                        "AccountCode": "200",
                        "TaxType": "NONE",
                    }
                ],
            }
        ]
    }
    resp = client.post("/api.xro/2.0/Invoices", headers=auth_headers, json=payload)
    assert resp.status_code == 200
    inv = resp.get_json()["Invoices"][0]
    li = inv["LineItems"][0]
    assert li["DiscountRate"] == 40.0
    assert li["DiscountEnteredAsPercent"] is True
    assert li["UnitAmount"] == 45.0


def test_invoices_require_auth(client):
    resp = client.get("/api.xro/2.0/Invoices")
    assert resp.status_code == 401
