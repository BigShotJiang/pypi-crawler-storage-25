"""Tests for the /api.xro/2.0/Payments endpoint."""
import json


def _create_contact(client, headers, name="Payer"):
    resp = client.post(
        "/api.xro/2.0/Contacts",
        headers=headers,
        data=json.dumps({"Contacts": [{"Name": name, "IsCustomer": True}]}),
    )
    return resp.get_json()["Contacts"][0]


def _create_invoice(client, headers, contact_id, number="INV-P1", total=200.0):
    payload = {
        "Invoices": [
            {
                "Type": "ACCREC",
                "InvoiceNumber": number,
                "Contact": {"ContactID": contact_id},
                "Date": "2024-03-01",
                "DueDate": "2024-04-01",
                "Status": "AUTHORISED",
                "CurrencyCode": "USD",
                "Total": total,
                "LineItems": [
                    {
                        "Description": "Service",
                        "UnitAmount": total,
                        "LineAmount": total,
                        "AccountCode": "200",
                    }
                ],
            }
        ]
    }
    resp = client.post("/api.xro/2.0/Invoices", headers=headers, data=json.dumps(payload))
    return resp.get_json()["Invoices"][0]


def _payment_payload(invoice_id, amount=200.0):
    return {
        "Payments": [
            {
                "Amount": amount,
                "Date": "2024-03-15",
                "Account": {"Code": "090"},
                "PaymentType": "ACCRECPAYMENT",
                "Invoice": {"InvoiceID": invoice_id},
            }
        ]
    }


def test_list_payments_empty(client, auth_headers):
    resp = client.get("/api.xro/2.0/Payments", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["Payments"] == []


def test_create_payment(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])

    resp = client.post(
        "/api.xro/2.0/Payments",
        headers=auth_headers,
        data=json.dumps(_payment_payload(invoice["InvoiceID"])),
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Status"] == "OK"
    payment = data["Payments"][0]
    assert "PaymentID" in payment
    assert payment["Amount"] == 200.0
    assert payment["Status"] == "AUTHORISED"


def test_payment_updates_invoice_amount_paid(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"], total=500.0)

    client.post(
        "/api.xro/2.0/Payments",
        headers=auth_headers,
        data=json.dumps(_payment_payload(invoice["InvoiceID"], amount=300.0)),
    )

    resp = client.get(f"/api.xro/2.0/Invoices/{invoice['InvoiceID']}", headers=auth_headers)
    updated = resp.get_json()["Invoices"][0]
    assert updated["AmountPaid"] == 300.0
    assert updated["AmountDue"] == 200.0


def test_get_payment_by_id(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    create_resp = client.post(
        "/api.xro/2.0/Payments",
        headers=auth_headers,
        data=json.dumps(_payment_payload(invoice["InvoiceID"])),
    )
    payment_id = create_resp.get_json()["Payments"][0]["PaymentID"]

    resp = client.get(f"/api.xro/2.0/Payments/{payment_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["Payments"][0]["PaymentID"] == payment_id


def test_delete_payment(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    create_resp = client.post(
        "/api.xro/2.0/Payments",
        headers=auth_headers,
        data=json.dumps(_payment_payload(invoice["InvoiceID"])),
    )
    payment_id = create_resp.get_json()["Payments"][0]["PaymentID"]

    resp = client.post(
        f"/api.xro/2.0/Payments/{payment_id}",
        headers=auth_headers,
        data=json.dumps({"Payments": [{"Status": "DELETED"}]}),
    )
    assert resp.status_code == 200
    assert resp.get_json()["Payments"][0]["Status"] == "DELETED"


def test_get_payment_not_found(client, auth_headers):
    resp = client.get("/api.xro/2.0/Payments/nonexistent", headers=auth_headers)
    assert resp.status_code == 404


def test_payment_currency_rate(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    payload = {
        "Payments": [
            {
                "Amount": 90.0,
                "Date": "2024-03-15",
                "Account": {"Code": "090"},
                "CurrencyRate": 0.9,
                "Invoice": {"InvoiceID": invoice["InvoiceID"]},
            }
        ]
    }
    resp = client.post("/api.xro/2.0/Payments", headers=auth_headers, data=json.dumps(payload))
    assert resp.status_code == 200
    assert resp.get_json()["Payments"][0]["CurrencyRate"] == 0.9


def test_payments_require_auth(client):
    resp = client.get("/api.xro/2.0/Payments")
    assert resp.status_code == 401
