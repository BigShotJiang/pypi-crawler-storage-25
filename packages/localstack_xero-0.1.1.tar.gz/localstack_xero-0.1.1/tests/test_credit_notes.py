"""Tests for the /api.xro/2.0/CreditNotes endpoint."""
import json


def _create_contact(client, headers, name="Refund Customer"):
    resp = client.post(
        "/api.xro/2.0/Contacts",
        headers=headers,
        data=json.dumps({"Contacts": [{"Name": name, "IsCustomer": True}]}),
    )
    return resp.get_json()["Contacts"][0]


def _create_invoice(client, headers, contact_id, number="INV-CN1", total=150.0):
    payload = {
        "Invoices": [
            {
                "Type": "ACCREC",
                "InvoiceNumber": number,
                "Contact": {"ContactID": contact_id},
                "Date": "2024-02-01",
                "DueDate": "2024-03-01",
                "Status": "AUTHORISED",
                "CurrencyCode": "EUR",
                "Total": total,
                "LineItems": [
                    {
                        "Description": "Service",
                        "UnitAmount": total,
                        "LineAmount": total,
                        "AccountCode": "200",
                    }
                ],
            }
        ]
    }
    resp = client.post("/api.xro/2.0/Invoices", headers=headers, data=json.dumps(payload))
    return resp.get_json()["Invoices"][0]


def _credit_note_payload(contact_id, invoice_id, amount=50.0):
    return {
        "CreditNotes": [
            {
                "Type": "ACCRECCREDIT",
                "CreditNoteNumber": "CN-stripe-refund-re_test",
                "Reference": invoice_id,
                "Contact": {"ContactID": contact_id},
                "Date": "2024-02-20",
                "Status": "AUTHORISED",
                "CurrencyCode": "EUR",
                "Total": amount,
                "SubTotal": amount,
                "LineItems": [
                    {
                        "Description": "Refund for order",
                        "Quantity": 1,
                        "UnitAmount": amount,
                        "LineAmount": amount,
                        "AccountCode": "200",
                        "TaxType": "TAX010",
                    }
                ],
                "Allocations": [
                    {
                        "Amount": amount,
                        "Invoice": {"InvoiceID": invoice_id},
                        "Date": "2024-02-20",
                    }
                ],
            }
        ]
    }


def test_list_credit_notes_empty(client, auth_headers):
    resp = client.get("/api.xro/2.0/CreditNotes", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["CreditNotes"] == []


def test_create_credit_note(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])

    resp = client.post(
        "/api.xro/2.0/CreditNotes",
        headers=auth_headers,
        data=json.dumps(_credit_note_payload(contact["ContactID"], invoice["InvoiceID"])),
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Status"] == "OK"
    cn = data["CreditNotes"][0]
    assert cn["Type"] == "ACCRECCREDIT"
    assert "CreditNoteID" in cn
    assert cn["Status"] == "AUTHORISED"
    assert cn["HasValidationErrors"] is False


def test_get_credit_note_by_id(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    create_resp = client.post(
        "/api.xro/2.0/CreditNotes",
        headers=auth_headers,
        data=json.dumps(_credit_note_payload(contact["ContactID"], invoice["InvoiceID"])),
    )
    cn_id = create_resp.get_json()["CreditNotes"][0]["CreditNoteID"]

    resp = client.get(f"/api.xro/2.0/CreditNotes/{cn_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["CreditNotes"][0]["CreditNoteID"] == cn_id


def test_get_credit_note_not_found(client, auth_headers):
    resp = client.get("/api.xro/2.0/CreditNotes/nonexistent", headers=auth_headers)
    assert resp.status_code == 404


def test_list_credit_notes_after_create(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    client.post(
        "/api.xro/2.0/CreditNotes",
        headers=auth_headers,
        data=json.dumps(_credit_note_payload(contact["ContactID"], invoice["InvoiceID"])),
    )
    resp = client.get("/api.xro/2.0/CreditNotes", headers=auth_headers)
    assert len(resp.get_json()["CreditNotes"]) == 1


def test_credit_note_allocations_stored(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    create_resp = client.post(
        "/api.xro/2.0/CreditNotes",
        headers=auth_headers,
        data=json.dumps(
            _credit_note_payload(contact["ContactID"], invoice["InvoiceID"], amount=75.0)
        ),
    )
    cn = create_resp.get_json()["CreditNotes"][0]
    assert len(cn["Allocations"]) == 1
    assert cn["Allocations"][0]["Amount"] == 75.0


def test_credit_note_reference_contains_invoice_id(client, auth_headers):
    contact = _create_contact(client, auth_headers)
    invoice = _create_invoice(client, auth_headers, contact["ContactID"])
    create_resp = client.post(
        "/api.xro/2.0/CreditNotes",
        headers=auth_headers,
        data=json.dumps(_credit_note_payload(contact["ContactID"], invoice["InvoiceID"])),
    )
    cn = create_resp.get_json()["CreditNotes"][0]
    assert cn["Reference"] == invoice["InvoiceID"]


def test_credit_notes_require_auth(client):
    resp = client.get("/api.xro/2.0/CreditNotes")
    assert resp.status_code == 401
