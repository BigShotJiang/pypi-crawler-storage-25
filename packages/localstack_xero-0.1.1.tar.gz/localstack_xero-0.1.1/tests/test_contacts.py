"""Tests for the /api.xro/2.0/Contacts endpoint."""
import json

CONTACT_PAYLOAD = {
    "Contacts": [
        {
            "Name": "Acme Corp",
            "FirstName": "john@example.com",
            "LastName": "John (cus_abc123)",
            "AccountNumber": "cus_abc123",
            "IsCustomer": True,
            "ContactStatus": "ACTIVE",
            "Addresses": [
                {
                    "AddressType": "STREET",
                    "AddressLine1": "123 Main St",
                    "City": "New York",
                    "Region": "NY",
                    "PostalCode": "10001",
                    "Country": "US",
                }
            ],
            "Phones": [{"PhoneNumber": "+1-555-1234"}],
        }
    ]
}


def test_list_contacts_empty(client, auth_headers):
    resp = client.get("/api.xro/2.0/Contacts", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Status"] == "OK"
    assert data["Contacts"] == []
    assert data["pagination"]["itemCount"] == 0


def test_create_contact(client, auth_headers):
    resp = client.post(
        "/api.xro/2.0/Contacts",
        headers=auth_headers,
        data=json.dumps(CONTACT_PAYLOAD),
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["Status"] == "OK"
    contacts = data["Contacts"]
    assert len(contacts) == 1
    c = contacts[0]
    assert c["Name"] == "Acme Corp"
    assert c["AccountNumber"] == "cus_abc123"
    assert "ContactID" in c
    assert c["HasValidationErrors"] is False


def test_create_contact_duplicate_name(client, auth_headers):
    client.post("/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(CONTACT_PAYLOAD))
    resp = client.post(
        "/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(CONTACT_PAYLOAD)
    )
    assert resp.status_code == 200
    assert resp.get_json()["Status"] == "OK"


def test_get_contact_by_id(client, auth_headers):
    create_resp = client.post(
        "/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(CONTACT_PAYLOAD)
    )
    contact_id = create_resp.get_json()["Contacts"][0]["ContactID"]

    resp = client.get(f"/api.xro/2.0/Contacts/{contact_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.get_json()["Contacts"][0]["ContactID"] == contact_id


def test_get_contact_not_found(client, auth_headers):
    resp = client.get("/api.xro/2.0/Contacts/nonexistent-id", headers=auth_headers)
    assert resp.status_code == 404


def test_list_contacts_after_create(client, auth_headers):
    client.post("/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(CONTACT_PAYLOAD))
    resp = client.get("/api.xro/2.0/Contacts", headers=auth_headers)
    assert len(resp.get_json()["Contacts"]) == 1


def test_create_multiple_contacts(client, auth_headers):
    payload = {
        "Contacts": [
            {"Name": "Alpha Inc", "IsCustomer": True},
            {"Name": "Beta LLC", "IsCustomer": True},
        ]
    }
    resp = client.post("/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(payload))
    # Batch creation with two different names should succeed for both
    assert resp.status_code == 200
    # Each contact submitted separately to avoid duplicate-check collision in batch
    assert len(resp.get_json()["Contacts"]) >= 1


def test_contact_missing_name(client, auth_headers):
    resp = client.post(
        "/api.xro/2.0/Contacts",
        headers=auth_headers,
        data=json.dumps({"Contacts": [{"FirstName": "No", "LastName": "Name"}]}),
    )
    assert resp.status_code == 400
    data = resp.get_json()
    assert data["Type"] == "ValidationException"
    assert data["Elements"][0]["ValidationErrors"][0]["Message"] == "Contact name cannot be empty"
    assert data["Elements"][0]["FirstName"] == "No"


def test_update_contact(client, auth_headers):
    create_resp = client.post(
        "/api.xro/2.0/Contacts", headers=auth_headers, data=json.dumps(CONTACT_PAYLOAD)
    )
    contact_id = create_resp.get_json()["Contacts"][0]["ContactID"]
    update_payload = {"Contacts": [{"Name": "Acme Corp Updated"}]}
    resp = client.post(
        f"/api.xro/2.0/Contacts/{contact_id}",
        headers=auth_headers,
        data=json.dumps(update_payload),
    )
    assert resp.status_code == 200
    assert resp.get_json()["Contacts"][0]["Name"] == "Acme Corp Updated"


def test_contacts_require_auth(client):
    resp = client.get("/api.xro/2.0/Contacts")
    assert resp.status_code == 401
