"""
Snapshot tests for the Payments API.

Record against real Xero API:
    pytest tests/test_payments_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_payments_snapshot.py
"""
import uuid

import pytest

try:
    from localstack_snapshot.snapshots.transformer import KeyValueBasedTransformer, RegexTransformer
except ImportError:
    pytest.skip("localstack-snapshot not installed (requires Python >=3.10)", allow_module_level=True)  # noqa: E501

_UUID_RE = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
_XERO_DATE_RE = r"/Date\(\d+\+?\d*\)/"


# AccountID is removed from snapshots (chart-of-accounts resolution unavailable in emulator).
_COA_SKIP_PATHS = []


def _standard_transformers():
    return [
        RegexTransformer(_UUID_RE, "<uuid>"),
        RegexTransformer(_XERO_DATE_RE, "<xero-date>"),
        # Random per-run account numbers used in contact/invoice fixtures
        RegexTransformer(r"PAY-SNAP-[0-9A-F]{8}", "<pay-snap-acct>"),
        RegexTransformer(r"Payment Snapshot Customer <pay-snap-acct>", "<pay-customer-name>"),
        RegexTransformer(r"SNAP-PAY-[0-9A-F]{6}", "<pay-snap-invnum>"),
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("UpdatedDateUTC", "DateTimeUTC") else None,
            "<datetime>",
        ),
        KeyValueBasedTransformer(
            lambda k, v: v if k == "ProviderName" else None,
            "<provider>",
        ),
        # Tax-affected amounts and COA-derived strings masked — emulator cannot replicate
        # Xero's account-code tax rates. replace_reference=False for float values.
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("Total", "TotalTax", "SubTotal", "AmountDue",
                                    "TaxAmount", "LineAmount") and isinstance(v, (int, float))
            else None,
            "<amount>",
            replace_reference=False,
        ),
        # replace_reference=False: avoid global empty-string replacement corrupting JSON.
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("TaxType", "InvoiceNumber") and isinstance(v, str) else None,
            "<derived>",
            replace_reference=False,
        ),
    ]


@pytest.fixture
def contact_and_invoice(xero_http):
    """Create a contact + AUTHORISED invoice; clean up on teardown."""
    acct = f"PAY-SNAP-{uuid.uuid4().hex[:8].upper()}"
    c_resp = xero_http.post(
        "/api.xro/2.0/Contacts",
        json={"Contacts": [{"Name": f"Payment Snapshot Customer {acct}", "AccountNumber": acct}]},
    )
    assert c_resp.status_code == 200, c_resp.text
    contact = c_resp.json()["Contacts"][0]

    inv_number = f"SNAP-PAY-{uuid.uuid4().hex[:6].upper()}"
    i_resp = xero_http.post(
        "/api.xro/2.0/Invoices",
        json={
            "Invoices": [
                {
                    "Type": "ACCREC",
                    "InvoiceNumber": inv_number,
                    "Status": "AUTHORISED",
                    "Contact": {"ContactID": contact["ContactID"]},
                    "Date": "2024-06-01",
                    "DueDate": "2024-07-01",
                    "CurrencyCode": "USD",
                    "LineItems": [
                        {
                            "Description": "Snapshot payment test",
                            "Quantity": 1,
                            "UnitAmount": 500.00,
                            "LineAmount": 500.00,
                            "AccountCode": "200",
                        }
                    ],
                }
            ]
        },
    )
    assert i_resp.status_code == 200, i_resp.text
    invoice = i_resp.json()["Invoices"][0]

    yield contact, invoice

    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Invoices/{invoice['InvoiceID']}",
            json={"Invoices": [{"Status": "VOIDED"}]},
        )
        xero_http.post(
            f"/api.xro/2.0/Contacts/{contact['ContactID']}",
            json={"Contacts": [{"ContactStatus": "ARCHIVED"}]},
        )


@pytest.fixture
def created_payment(xero_http, contact_and_invoice):
    """Create a payment against the invoice."""
    _, invoice = contact_and_invoice
    resp = xero_http.post(
        "/api.xro/2.0/Payments",
        json={
            "Payments": [
                {
                    "Invoice": {"InvoiceID": invoice["InvoiceID"]},
                    "Account": {"Code": "090"},
                    "Amount": 250.00,
                    "Date": "2024-06-15",
                }
            ]
        },
    )
    assert resp.status_code == 200, resp.text
    payment = resp.json()["Payments"][0]
    yield payment
    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Payments/{payment['PaymentID']}",
            json={"Payments": [{"Status": "DELETED"}]},
        )


@pytest.mark.snapshot
def test_list_payments_empty(xero_http, snapshot):
    """GET /Payments on a fresh tenant returns an empty list."""
    if xero_http.real_api:
        pytest.skip("Real API has pre-existing payments")

    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    resp = xero_http.get("/api.xro/2.0/Payments")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Payments"] == []
    snapshot.match("list_empty", data)


@pytest.mark.snapshot
def test_create_payment(xero_http, snapshot, contact_and_invoice):
    """POST /Payments links a payment to an invoice."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    _, invoice = contact_and_invoice

    resp = xero_http.post(
        "/api.xro/2.0/Payments",
        json={
            "Payments": [
                {
                    "Invoice": {"InvoiceID": invoice["InvoiceID"]},
                    "Account": {"Code": "090"},
                    "Amount": 250.00,
                    "Date": "2024-06-15",
                }
            ]
        },
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Status"] == "OK"
    pmt = data["Payments"][0]
    assert pmt["HasValidationErrors"] is False
    assert float(pmt["Amount"]) == 250.0

    snapshot.match("create_payment", data)

    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Payments/{pmt['PaymentID']}",
            json={"Payments": [{"Status": "DELETED"}]},
        )


@pytest.mark.snapshot
def test_invoice_updated_after_payment(xero_http, snapshot, created_payment, contact_and_invoice):
    """Invoice.AmountPaid and AmountDue update after a payment is applied."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    _, invoice = contact_and_invoice

    resp = xero_http.get(f"/api.xro/2.0/Invoices/{invoice['InvoiceID']}")
    assert resp.status_code == 200

    data = resp.json()
    inv = data["Invoices"][0]
    assert float(inv["AmountPaid"]) == 250.0
    # AmountDue = Total(+tax) - AmountPaid; masked in snapshot since tax varies
    assert float(inv["AmountDue"]) >= 0.0

    snapshot.match("invoice_after_payment", data)


@pytest.mark.snapshot
def test_get_payment_by_id(xero_http, snapshot, created_payment):
    """GET /Payments/{id} returns the full payment record."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    pid = created_payment["PaymentID"]

    resp = xero_http.get(f"/api.xro/2.0/Payments/{pid}")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Payments"][0]["PaymentID"] == pid
    snapshot.match("get_by_id", data)


@pytest.mark.snapshot
def test_get_payment_not_found(xero_http, snapshot):
    """GET /Payments/{unknown} returns 404."""
    resp = xero_http.get("/api.xro/2.0/Payments/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404

    try:
        body = resp.json()
    except Exception:
        body = {"error": resp.text.strip()}
    snapshot.match("get_not_found", body)


@pytest.mark.snapshot
def test_delete_payment(xero_http, snapshot, created_payment):
    """POST /Payments/{id} with Status=DELETED marks the payment deleted."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    pid = created_payment["PaymentID"]

    resp = xero_http.post(
        f"/api.xro/2.0/Payments/{pid}",
        json={"Payments": [{"Status": "DELETED"}]},
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Payments"][0]["Status"] == "DELETED"
    snapshot.match("delete_payment", data)
