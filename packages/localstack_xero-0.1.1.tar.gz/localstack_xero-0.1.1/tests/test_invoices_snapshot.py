"""
Snapshot tests for the Invoices API.

Record against real Xero API:
    pytest tests/test_invoices_snapshot.py --snapshot-update

Verify against emulator:
    pytest tests/test_invoices_snapshot.py
"""
import uuid

import pytest

try:
    from localstack_snapshot.snapshots.transformer import KeyValueBasedTransformer, RegexTransformer
except ImportError:
    pytest.skip("localstack-snapshot not installed (requires Python >=3.10)", allow_module_level=True)  # noqa: E501

_UUID_RE = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
_XERO_DATE_RE = r"/Date\(\d+\+?\d*\)/"


# AccountID is removed from snapshots (chart-of-accounts resolution unavailable in emulator).
_COA_SKIP_PATHS = []


def _standard_transformers():
    return [
        RegexTransformer(_UUID_RE, "<uuid>"),
        RegexTransformer(_XERO_DATE_RE, "<xero-date>"),
        # Random per-run account numbers used in contact/invoice fixtures
        RegexTransformer(r"INV-SNAP-[0-9A-F]{8}", "<inv-snap-acct>"),
        RegexTransformer(r"Invoice Snapshot Customer <inv-snap-acct>", "<inv-customer-name>"),
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("UpdatedDateUTC", "DateTimeUTC", "FullyPaidOnDate") else None,
            "<datetime>",
        ),
        KeyValueBasedTransformer(
            lambda k, v: v if k == "ProviderName" else None,
            "<provider>",
        ),
        # Tax-affected amounts differ — emulator cannot replicate Xero's account-code
        # tax rates. replace_reference=False required because values are floats.
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("Total", "TotalTax", "SubTotal", "AmountDue",
                                    "TaxAmount", "LineAmount") and isinstance(v, (int, float))
            else None,
            "<amount>",
            replace_reference=False,
        ),
        # replace_reference=False: avoid global empty-string replacement corrupting JSON.
        KeyValueBasedTransformer(
            lambda k, v: v if k in ("TaxType", "InvoiceNumber") and isinstance(v, str) else None,
            "<derived>",
            replace_reference=False,
        ),
    ]


def _inv_number() -> str:
    return f"SNAP-INV-{uuid.uuid4().hex[:6].upper()}"


@pytest.fixture
def contact_id(xero_http):
    """Create a throw-away contact; archive it on teardown."""
    acct = f"INV-SNAP-{uuid.uuid4().hex[:8].upper()}"
    resp = xero_http.post(
        "/api.xro/2.0/Contacts",
        json={"Contacts": [{"Name": f"Invoice Snapshot Customer {acct}", "AccountNumber": acct}]},
    )
    assert resp.status_code == 200, resp.text
    cid = resp.json()["Contacts"][0]["ContactID"]
    yield cid
    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Contacts/{cid}",
            json={"Contacts": [{"ContactStatus": "ARCHIVED"}]},
        )


def _invoice_payload(contact_id: str, inv_number: str, inv_type: str = "ACCREC") -> dict:
    return {
        "Invoices": [
            {
                "Type": inv_type,
                "InvoiceNumber": inv_number,
                "Reference": "Snapshot ref",
                "Status": "AUTHORISED",
                "Contact": {"ContactID": contact_id},
                "Date": "2024-06-01",
                "DueDate": "2024-07-01",
                "CurrencyCode": "USD",
                "LineItems": [
                    {
                        "Description": "Snapshot line item",
                        "Quantity": 1,
                        "UnitAmount": 100.00,
                        "LineAmount": 100.00,
                        "AccountCode": "200",
                    }
                ],
            }
        ]
    }


@pytest.fixture
def created_invoice(xero_http, contact_id):
    """Create an ACCREC invoice; void it on teardown."""
    inv_number = _inv_number()
    resp = xero_http.post(
        "/api.xro/2.0/Invoices",
        json=_invoice_payload(contact_id, inv_number),
    )
    assert resp.status_code == 200, resp.text
    invoice = resp.json()["Invoices"][0]
    yield invoice
    if xero_http.real_api:
        iid = invoice["InvoiceID"]
        xero_http.post(
            f"/api.xro/2.0/Invoices/{iid}",
            json={"Invoices": [{"Status": "VOIDED"}]},
        )


@pytest.mark.snapshot
def test_list_invoices_empty(xero_http, snapshot):
    """GET /Invoices on a fresh tenant returns an empty list."""
    if xero_http.real_api:
        pytest.skip("Real API has pre-existing invoices")

    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    resp = xero_http.get("/api.xro/2.0/Invoices")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Invoices"] == []
    snapshot.match("list_empty", data)


@pytest.mark.snapshot
def test_create_accrec_invoice(xero_http, snapshot, contact_id):
    """POST /Invoices creates an accounts-receivable invoice."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    inv_number = _inv_number()

    resp = xero_http.post(
        "/api.xro/2.0/Invoices",
        json=_invoice_payload(contact_id, inv_number),
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Status"] == "OK"
    inv = data["Invoices"][0]
    assert inv["Type"] == "ACCREC"

    snapshot.match("create_accrec", data)

    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Invoices/{inv['InvoiceID']}",
            json={"Invoices": [{"Status": "VOIDED"}]},
        )


@pytest.mark.snapshot
def test_create_accpay_invoice(xero_http, snapshot, contact_id):
    """POST /Invoices creates an accounts-payable invoice (bill)."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    inv_number = _inv_number()

    resp = xero_http.post(
        "/api.xro/2.0/Invoices",
        json=_invoice_payload(contact_id, inv_number, inv_type="ACCPAY"),
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    inv = data["Invoices"][0]
    assert inv["Type"] == "ACCPAY"

    snapshot.match("create_accpay", data)

    if xero_http.real_api:
        xero_http.post(
            f"/api.xro/2.0/Invoices/{inv['InvoiceID']}",
            json={"Invoices": [{"Status": "VOIDED"}]},
        )


@pytest.mark.snapshot
def test_get_invoice_by_id(xero_http, snapshot, created_invoice):
    """GET /Invoices/{id} returns the full invoice record."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS

    iid = created_invoice["InvoiceID"]
    resp = xero_http.get(f"/api.xro/2.0/Invoices/{iid}")
    assert resp.status_code == 200

    data = resp.json()
    assert data["Invoices"][0]["InvoiceID"] == iid
    snapshot.match("get_by_id", data)


@pytest.mark.snapshot
def test_get_invoice_not_found(xero_http, snapshot):
    """GET /Invoices/{unknown} returns 404."""
    resp = xero_http.get("/api.xro/2.0/Invoices/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404

    try:
        body = resp.json()
    except Exception:
        body = {"error": resp.text.strip()}
    snapshot.match("get_not_found", body)


@pytest.mark.snapshot
def test_filter_by_contact(xero_http, snapshot, created_invoice, contact_id):
    """GET /Invoices?ContactIDs=... returns only that contact's invoices."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS

    resp = xero_http.get(f"/api.xro/2.0/Invoices?ContactIDs={contact_id}")
    assert resp.status_code == 200

    data = resp.json()
    assert len(data["Invoices"]) >= 1
    snapshot.match("filter_by_contact", data)


@pytest.mark.snapshot
def test_filter_by_invoice_number(xero_http, snapshot, created_invoice):
    """GET /Invoices?InvoiceNumbers=... returns the matching invoice."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    number = created_invoice["InvoiceNumber"]

    resp = xero_http.get(f"/api.xro/2.0/Invoices?InvoiceNumbers={number}")
    assert resp.status_code == 200

    data = resp.json()
    assert len(data["Invoices"]) >= 1
    snapshot.match("filter_by_number", data)


@pytest.mark.snapshot
def test_filter_by_status(xero_http, snapshot, created_invoice, contact_id):
    """GET /Invoices?Statuses=AUTHORISED&ContactIDs=... filters correctly."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS

    # Narrow by ContactIDs so we only see our own test invoice, not pre-existing ones.
    resp = xero_http.get(f"/api.xro/2.0/Invoices?Statuses=AUTHORISED&ContactIDs={contact_id}")
    assert resp.status_code == 200

    data = resp.json()
    assert all(i["Status"] == "AUTHORISED" for i in data["Invoices"])
    assert len(data["Invoices"]) >= 1
    snapshot.match("filter_by_status", data)


@pytest.mark.snapshot
def test_update_invoice_to_voided(xero_http, snapshot, created_invoice):
    """POST /Invoices/{id} with Status=VOIDED voids the invoice."""
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS

    iid = created_invoice["InvoiceID"]
    resp = xero_http.post(
        f"/api.xro/2.0/Invoices/{iid}",
        json={"Invoices": [{"Status": "VOIDED"}]},
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    assert data["Invoices"][0]["Status"] == "VOIDED"
    snapshot.match("update_voided", data)


@pytest.mark.snapshot
def test_duplicate_invoice_number(xero_http, snapshot, contact_id, created_invoice):
    """POST /Invoices with a duplicate InvoiceNumber.

    NOTE: The real Xero API allows duplicate invoice numbers (returns 200).
    The emulator rejects them with 400 — a known parity gap. This snapshot
    records real API behaviour.
    """
    snapshot.add_transformers_list(_standard_transformers())
    snapshot.skip_paths = _COA_SKIP_PATHS
    number = created_invoice["InvoiceNumber"]
    resp = xero_http.post(
        "/api.xro/2.0/Invoices",
        json=_invoice_payload(contact_id, number),
    )
    data = resp.json()
    snapshot.match("duplicate_number_response", data)

    # Clean up the second invoice on real API
    if xero_http.real_api and resp.status_code == 200:
        for inv in data.get("Invoices", []):
            if inv.get("InvoiceID") != created_invoice["InvoiceID"]:
                xero_http.post(
                    f"/api.xro/2.0/Invoices/{inv['InvoiceID']}",
                    json={"Invoices": [{"Status": "VOIDED"}]},
                )
