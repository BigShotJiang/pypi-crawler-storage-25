"""Tests for OAuth2 and Identity endpoints."""


def test_token_endpoint(client):
    resp = client.post(
        "/connect/token",
        data={
            "grant_type": "authorization_code",
            "client_id": "test-client",
            "client_secret": "test-secret",
            "code": "test-code",
            "redirect_uri": "http://localhost/callback",
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert "access_token" in data
    assert data["token_type"] == "Bearer"
    assert data["expires_in"] == 1800
    assert "refresh_token" in data


def test_token_client_credentials(client):
    resp = client.post(
        "/connect/token",
        data={
            "grant_type": "client_credentials",
            "client_id": "test-client",
            "client_secret": "test-secret",
        },
    )
    assert resp.status_code == 200
    assert "access_token" in resp.get_json()


def test_connections_requires_auth(client):
    resp = client.get("/connections")
    assert resp.status_code == 401


def test_connections(client, auth_headers):
    resp = client.get("/connections", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.get_json()
    assert isinstance(data, list)
    assert len(data) == 1
    conn = data[0]
    assert "tenantId" in conn
    assert conn["tenantType"] == "ORGANISATION"


def test_health(client):
    resp = client.get("/_xero/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"


def test_reset(client):
    resp = client.post("/_xero/reset")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"
