"""Start/stop the Xero emulator HTTP server."""
import logging
import os
import threading
from typing import Optional

from werkzeug.serving import make_server

LOG = logging.getLogger(__name__)

DEFAULT_PORT = int(os.environ.get("XERO_PORT", "5001"))
DEFAULT_HOST = os.environ.get("XERO_HOST", "0.0.0.0")

_server: Optional[object] = None
_thread: Optional[threading.Thread] = None


def get_port() -> int:
    return DEFAULT_PORT


def start(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> None:
    """Start the emulator in a background daemon thread."""
    global _server, _thread

    from xero_local.app import app

    _server = make_server(host, port, app)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True, name="xero-local")
    _thread.start()
    LOG.info("Xero emulator listening on http://%s:%d", host, port)


def stop() -> None:
    """Gracefully stop the emulator."""
    global _server, _thread
    if _server:
        _server.shutdown()
        _server = None
    if _thread:
        _thread.join(timeout=5)
        _thread = None


def main() -> None:
    """CLI entry point: run the emulator in the foreground."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )
    host = DEFAULT_HOST
    port = DEFAULT_PORT
    LOG.info("Starting Xero emulator on http://%s:%d", host, port)
    from xero_local.app import app
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    main()
