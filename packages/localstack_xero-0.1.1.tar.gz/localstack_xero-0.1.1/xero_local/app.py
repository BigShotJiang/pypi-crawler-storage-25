"""Flask application implementing the Xero Accounting and Identity APIs."""
import datetime as dt
import logging
import math
import uuid
from functools import wraps

from flask import Flask, jsonify, make_response, request

from xero_local.store import store

LOG = logging.getLogger(__name__)

app = Flask(__name__)

_PROVIDER_NAME = "xero-local"
_PAGE_SIZE = 100


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tenant_id() -> str:
    return request.headers.get("Xero-Tenant-Id") or request.headers.get("X-Xero-TenantId") or None


def _xero_datetime_now() -> str:
    ms = int(dt.datetime.now(dt.timezone.utc).timestamp() * 1000)
    return f"/Date({ms})/"


def _envelope(resource_key: str, items: list, **extra) -> dict:
    """Build the standard Xero response envelope."""
    body = {
        "Id": str(uuid.uuid4()),
        "Status": "OK",
        "ProviderName": _PROVIDER_NAME,
        "DateTimeUTC": _xero_datetime_now(),
        resource_key: items,
    }
    body.update(extra)
    return body


def _paginate(items: list, page: int) -> tuple[list, dict]:
    """Return the requested page of items and a pagination object."""
    total = len(items)
    page_count = max(1, math.ceil(total / _PAGE_SIZE))
    start = (page - 1) * _PAGE_SIZE
    end = start + _PAGE_SIZE
    return items[start:end], {
        "page": page,
        "pageSize": _PAGE_SIZE,
        "pageCount": page_count,
        "itemCount": total,
    }


def _validation_error(message: str) -> tuple:
    body = {
        "ErrorNumber": 10,
        "Type": "ValidationException",
        "Message": "A validation exception occurred",
        "Elements": [
            {
                "ValidationErrors": [{"Message": message}],
                "HasValidationErrors": True,
            }
        ],
    }
    return jsonify(body), 400


def _discount_validation_errors(line_items: list) -> list[str]:
    """Return validation error messages for any line items with inconsistent discounts.

    Xero requires that when DiscountRate is set, UnitAmount is the pre-discount
    price and LineAmount == UnitAmount * Quantity * (1 - DiscountRate / 100).
    """
    errors = []
    for li in line_items:
        if "DiscountRate" not in li:
            continue
        unit = float(li.get("UnitAmount", 0))
        qty = float(li.get("Quantity", 1))
        line = float(li.get("LineAmount", 0))
        rate = float(li["DiscountRate"])
        expected = round(unit * qty * (1 - rate / 100), 2)
        if abs(expected - line) > 0.005:
            errors.append(
                "The UnitAmount should be used when specifying a discount for a line item."
            )
            errors.append(
                f"The line total {line:.2f} does not match the expected line total {expected:.2f}"
            )
    return errors


def _not_found() -> tuple:
    """Xero returns plain text for 404s."""
    return make_response("The resource you're looking for cannot be found", 404)


def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated


def _with_attachments_flag(contacts: list, include_array: bool = False) -> list:
    """Add HasAttachments (and optionally Attachments) to each contact dict."""
    result = []
    for c in contacts:
        c = dict(c)
        c["HasAttachments"] = False
        if include_array:
            c["Attachments"] = []
        # Remove write-only tracking fields from read responses
        c.pop("SalesTrackingCategories", None)
        c.pop("PurchasesTrackingCategories", None)
        result.append(c)
    return result


# ---------------------------------------------------------------------------
# OAuth / Identity endpoints
# ---------------------------------------------------------------------------

@app.route("/connect/token", methods=["POST"])
def token():
    return jsonify({
        "access_token": f"xero-local-token-{uuid.uuid4()}",
        "expires_in": 1800,
        "token_type": "Bearer",
        "refresh_token": f"xero-local-refresh-{uuid.uuid4()}",
        "scope": (
            "openid profile email accounting.invoices"
            " accounting.settings accounting.contacts accounting.payments"
        ),
        "authentication_event_id": str(uuid.uuid4()),
        "id_token": "dummy-id-token",
    })


@app.route("/identity/connect/authorize", methods=["GET"])
def authorize():
    redirect_uri = request.args.get("redirect_uri", "")
    state = request.args.get("state", "")
    code = f"xero-auth-code-{uuid.uuid4()}"
    sep = "&" if "?" in redirect_uri else "?"
    location = f"{redirect_uri}{sep}code={code}&state={state}"
    from flask import redirect as flask_redirect
    return flask_redirect(location, code=302)


# ---------------------------------------------------------------------------
# Identity API
# ---------------------------------------------------------------------------

@app.route("/connections", methods=["GET"])
@require_auth
def get_connections():
    return jsonify(store.get_connections())


# ---------------------------------------------------------------------------
# Contacts
# ---------------------------------------------------------------------------

@app.route("/api.xro/2.0/Contacts", methods=["GET"])
@require_auth
def list_contacts():
    tid = _tenant_id()
    contacts = store.list_contacts(tid)

    ids_param = request.args.get("IDs") or request.args.get("ContactIDs")
    if ids_param:
        ids = {i.strip() for i in ids_param.split(",")}
        contacts = [c for c in contacts if c["ContactID"] in ids]

    name_param = request.args.get("Name")
    if name_param:
        contacts = [c for c in contacts if c.get("Name", "").lower() == name_param.lower()]

    page = int(request.args.get("page", 1))
    paged, pagination = _paginate(contacts, page)
    contacts_out = _with_attachments_flag(paged)
    return jsonify(_envelope("Contacts", contacts_out, pagination=pagination))


@app.route("/api.xro/2.0/Contacts/<contact_id>", methods=["GET"])
@require_auth
def get_contact(contact_id: str):
    tid = _tenant_id()
    contact = store.get_contact(contact_id, tid)
    if not contact:
        return _not_found()
    contacts_out = _with_attachments_flag([contact], include_array=True)
    return jsonify(_envelope("Contacts", contacts_out))


@app.route("/api.xro/2.0/Contacts", methods=["POST"])
@require_auth
def create_contacts():
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    contacts_data = body.get("Contacts", [body])
    created = []
    for c in contacts_data:
        if not c.get("Name", ""):
            element = {
                "ContactID": str(uuid.uuid4()),
                "FirstName": c.get("FirstName", ""),
                "LastName": c.get("LastName", ""),
                "Addresses": [],
                "Phones": [],
                "ContactGroups": [],
                "ContactPersons": [],
                "HasValidationErrors": True,
                "ValidationErrors": [{"Message": "Contact name cannot be empty"}],
            }
            return jsonify({
                "ErrorNumber": 10,
                "Type": "ValidationException",
                "Message": "A validation exception occurred",
                "Elements": [element],
            }), 400
        created.append(store.create_contact(c, tid))
    return jsonify(_envelope("Contacts", created))


@app.route("/api.xro/2.0/Contacts/<contact_id>", methods=["POST", "PUT"])
@require_auth
def update_contact(contact_id: str):
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    data = body.get("Contacts", [body])[0]
    updated = store.update_contact(contact_id, data, tid)
    if not updated:
        return _not_found()
    return jsonify(_envelope("Contacts", [updated]))


# ---------------------------------------------------------------------------
# Invoices
# ---------------------------------------------------------------------------

@app.route("/api.xro/2.0/Invoices", methods=["GET"])
@require_auth
def list_invoices():
    tid = _tenant_id()
    contact_ids = None
    invoice_numbers = None
    statuses = None

    if v := request.args.get("ContactIDs"):
        contact_ids = [x.strip() for x in v.split(",")]
    if v := request.args.get("InvoiceNumbers"):
        invoice_numbers = [x.strip() for x in v.split(",")]
    if v := request.args.get("Statuses"):
        statuses = [x.strip() for x in v.split(",")]

    invoices = store.list_invoices(
        tid, contact_ids=contact_ids, invoice_numbers=invoice_numbers, statuses=statuses
    )
    page = int(request.args.get("page", 1))
    paged, pagination = _paginate(invoices, page)
    return jsonify(_envelope("Invoices", paged, pagination=pagination))


@app.route("/api.xro/2.0/Invoices/<invoice_id>", methods=["GET"])
@require_auth
def get_invoice(invoice_id: str):
    tid = _tenant_id()
    invoice = store.get_invoice(invoice_id, tid)
    if not invoice:
        return _not_found()
    return jsonify(_envelope("Invoices", [invoice]))


@app.route("/api.xro/2.0/Invoices", methods=["POST", "PUT"])
@require_auth
def create_invoices():
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    invoices_data = body.get("Invoices", [body])
    created = []
    for inv in invoices_data:
        errs = _discount_validation_errors(inv.get("LineItems", []))
        if errs:
            element = {
                "Type": inv.get("Type", "ACCREC"),
                "InvoiceNumber": inv.get("InvoiceNumber", ""),
                "Status": inv.get("Status", "DRAFT"),
                "HasErrors": True,
                "HasValidationErrors": True,
                "ValidationErrors": [{"Message": m} for m in errs],
                "LineItems": inv.get("LineItems", []),
            }
            return jsonify({
                "ErrorNumber": 10,
                "Type": "ValidationException",
                "Message": "A validation exception occurred",
                "Elements": [element],
            }), 400
        created.append(store.create_invoice(inv, tid))
    return jsonify(_envelope("Invoices", created))


@app.route("/api.xro/2.0/Invoices/<invoice_id>", methods=["POST", "PUT"])
@require_auth
def update_invoice(invoice_id: str):
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    data = body.get("Invoices", [body])[0]
    updated = store.update_invoice(invoice_id, data, tid)
    if not updated:
        return _not_found()
    return jsonify(_envelope("Invoices", [updated]))


# ---------------------------------------------------------------------------
# Payments
# ---------------------------------------------------------------------------

@app.route("/api.xro/2.0/Payments", methods=["GET"])
@require_auth
def list_payments():
    tid = _tenant_id()
    payments = store.list_payments(tid)
    page = int(request.args.get("page", 1))
    paged, pagination = _paginate(payments, page)
    return jsonify(_envelope("Payments", paged, pagination=pagination))


@app.route("/api.xro/2.0/Payments/<payment_id>", methods=["GET"])
@require_auth
def get_payment(payment_id: str):
    tid = _tenant_id()
    payment = store.get_payment(payment_id, tid)
    if not payment:
        return _not_found()
    return jsonify(_envelope("Payments", [payment]))


@app.route("/api.xro/2.0/Payments", methods=["POST"])
@require_auth
def create_payment():
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    payments_data = body.get("Payments", [body])
    created = [store.create_payment(p, tid) for p in payments_data]
    return jsonify(_envelope("Payments", created))


@app.route("/api.xro/2.0/Payments/<payment_id>", methods=["POST", "PUT", "DELETE"])
@require_auth
def delete_payment(payment_id: str):
    tid = _tenant_id()
    result = store.delete_payment(payment_id, tid)
    if not result:
        return _not_found()
    return jsonify(_envelope("Payments", [result]))


# ---------------------------------------------------------------------------
# Credit Notes
# ---------------------------------------------------------------------------

@app.route("/api.xro/2.0/CreditNotes", methods=["GET"])
@require_auth
def list_credit_notes():
    tid = _tenant_id()
    cns = store.list_credit_notes(tid)
    page = int(request.args.get("page", 1))
    paged, pagination = _paginate(cns, page)
    return jsonify(_envelope("CreditNotes", paged, pagination=pagination))


@app.route("/api.xro/2.0/CreditNotes/<credit_note_id>", methods=["GET"])
@require_auth
def get_credit_note(credit_note_id: str):
    tid = _tenant_id()
    cn = store.get_credit_note(credit_note_id, tid)
    if not cn:
        return _not_found()
    return jsonify(_envelope("CreditNotes", [cn]))


@app.route("/api.xro/2.0/CreditNotes", methods=["POST", "PUT"])
@require_auth
def create_credit_notes():
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    cns_data = body.get("CreditNotes", [body])
    created = [store.create_credit_note(cn, tid) for cn in cns_data]
    return jsonify(_envelope("CreditNotes", created))


@app.route("/api.xro/2.0/CreditNotes/<credit_note_id>", methods=["POST", "PUT"])
@require_auth
def update_credit_note(credit_note_id: str):
    tid = _tenant_id()
    body = request.get_json(force=True) or {}
    data = body.get("CreditNotes", [body])[0]
    with store._lock:
        resources = store._resources(tid, "credit_notes")
        if credit_note_id not in resources:
            return _not_found()
        resources[credit_note_id].update({k: v for k, v in data.items() if k != "CreditNoteID"})
        result = resources[credit_note_id].copy()
    return jsonify(_envelope("CreditNotes", [result]))


# ---------------------------------------------------------------------------
# Health / Reset / State
# ---------------------------------------------------------------------------

@app.route("/_xero/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "xero-local"})


@app.route("/_xero/reset", methods=["POST"])
def reset():
    store.reset()
    return jsonify({"status": "ok", "message": "store reset"})


@app.route("/_xero/state", methods=["GET"])
def state():
    with store._lock:
        tid = store._default_tenant["tenantId"]
        return jsonify({
            "tenant": store._default_tenant,
            "contacts": list(store._tenants.get(tid, {}).get("contacts", {}).values()),
            "invoices": list(store._tenants.get(tid, {}).get("invoices", {}).values()),
            "payments": list(store._tenants.get(tid, {}).get("payments", {}).values()),
            "credit_notes": list(store._tenants.get(tid, {}).get("credit_notes", {}).values()),
        })
