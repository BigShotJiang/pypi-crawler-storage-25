"""Xero API emulator - in-process HTTP server."""
