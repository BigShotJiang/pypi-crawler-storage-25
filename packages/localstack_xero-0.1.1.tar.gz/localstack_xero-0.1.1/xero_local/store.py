"""In-memory data store for the Xero emulator."""
import datetime as dt
import threading
import uuid
from copy import deepcopy
from typing import Any, Optional

_ALL_PHONE_TYPES = ["DEFAULT", "DDI", "FAX", "MOBILE"]


def new_id() -> str:
    return str(uuid.uuid4())


def _xero_date() -> str:
    """Current UTC time in Xero's /Date(ms+0000)/ format used on resource fields."""
    ms = int(dt.datetime.now(dt.timezone.utc).timestamp() * 1000)
    return f"/Date({ms}+0000)/"


def _normalize_phones(phones_input: list) -> list:
    """Merge provided phones into the canonical 4-entry list Xero always returns."""
    by_type = {p.get("PhoneType", "DEFAULT"): p for p in (phones_input or [])}
    return [
        {
            "PhoneType": t,
            "PhoneNumber": by_type.get(t, {}).get("PhoneNumber", ""),
            "PhoneAreaCode": by_type.get(t, {}).get("PhoneAreaCode", ""),
            "PhoneCountryCode": by_type.get(t, {}).get("PhoneCountryCode", ""),
        }
        for t in _ALL_PHONE_TYPES
    ]


def _date_to_xero(date_str: str) -> str:
    """Convert ISO date string '2024-06-01' to Xero /Date(epoch_ms)/ format."""
    if not date_str:
        return ""
    try:
        d = dt.datetime.strptime(date_str[:10], "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
        ms = int(d.timestamp() * 1000)
        return f"/Date({ms}+0000)/"
    except ValueError:
        return date_str


def _normalize_line_item(li: dict) -> dict:
    """Normalise a submitted line item to match the real API response shape."""
    item: dict = {
        "LineItemID": li.get("LineItemID") or new_id(),
        "Description": li.get("Description", ""),
        "UnitAmount": float(li.get("UnitAmount", 0.0)),
        "LineAmount": float(li.get("LineAmount", 0.0)),
        "TaxAmount": float(li.get("TaxAmount", 0.0)),
        "TaxType": li.get("TaxType", ""),
        "AccountCode": li.get("AccountCode", ""),
        "Quantity": float(li.get("Quantity", 1.0)),
        "Tracking": li.get("Tracking", []),
        "ValidationErrors": [],
    }
    if "DiscountRate" in li:
        item["DiscountRate"] = float(li["DiscountRate"])
    if "DiscountAmount" in li:
        item["DiscountAmount"] = float(li["DiscountAmount"])
    if "DiscountEnteredAsPercent" in li:
        item["DiscountEnteredAsPercent"] = bool(li["DiscountEnteredAsPercent"])
    return item


def _normalize_addresses(addresses_input: list) -> list:
    """Ensure STREET + POBOX entries are always present with Region normalised."""
    by_type = {a.get("AddressType", "STREET"): a for a in (addresses_input or [])}
    result = []
    for addr_type in ("STREET", "POBOX"):
        src = by_type.get(addr_type, {})
        entry: dict = {"AddressType": addr_type}
        # Only include AddressLine1 when non-empty (matches Xero behaviour)
        line1 = src.get("AddressLine1", "")
        if line1:
            entry["AddressLine1"] = line1
        entry["City"] = src.get("City", "")
        entry["Region"] = src.get("Region", "")
        entry["PostalCode"] = src.get("PostalCode", "")
        entry["Country"] = src.get("Country", "")
        result.append(entry)
    return result


class XeroStore:
    """Thread-safe in-memory store for all Xero resources."""

    def __init__(self):
        self._lock = threading.Lock()
        self.reset()

    def reset(self):
        with self._lock:
            self._tenants: dict[str, dict[str, dict[str, Any]]] = {}
            self._default_tenant = {
                "id": new_id(),
                "authEventId": new_id(),
                "tenantId": new_id(),
                "tenantType": "ORGANISATION",
                "tenantName": "Test Organisation",
                "createdDateUtc": "2024-01-01T00:00:00",
                "updatedDateUtc": "2024-06-01T00:00:00",
            }
            self._tenants[self._default_tenant["tenantId"]] = {
                "contacts": {},
                "invoices": {},
                "payments": {},
                "credit_notes": {},
            }

    def get_tenant(self, tenant_id: Optional[str] = None) -> Optional[dict]:
        if tenant_id is None:
            return self._default_tenant
        if tenant_id == self._default_tenant["tenantId"]:
            return self._default_tenant
        return None

    def get_connections(self) -> list[dict]:
        return [deepcopy(self._default_tenant)]

    def _resources(self, tenant_id: Optional[str], resource_type: str) -> dict:
        tid = tenant_id or self._default_tenant["tenantId"]
        if tid not in self._tenants:
            self._tenants[tid] = {
                "contacts": {},
                "invoices": {},
                "payments": {},
                "credit_notes": {},
            }
        return self._tenants[tid][resource_type]

    # --- Contacts ---

    def list_contacts(self, tenant_id: Optional[str] = None) -> list[dict]:
        with self._lock:
            return list(deepcopy(self._resources(tenant_id, "contacts")).values())

    def get_contact(self, contact_id: str, tenant_id: Optional[str] = None) -> Optional[dict]:
        with self._lock:
            return deepcopy(self._resources(tenant_id, "contacts").get(contact_id))

    def create_contact(self, data: dict, tenant_id: Optional[str] = None) -> dict:
        with self._lock:
            resources = self._resources(tenant_id, "contacts")
            contact_id = new_id()
            contact = {
                "ContactID": contact_id,
                "AccountNumber": data.get("AccountNumber", ""),
                "ContactStatus": data.get("ContactStatus", "ACTIVE"),
                "Name": data.get("Name", ""),
                "FirstName": data.get("FirstName", ""),
                "LastName": data.get("LastName", ""),
                "EmailAddress": data.get("EmailAddress", ""),
                "BankAccountDetails": data.get("BankAccountDetails", ""),
                # IsCustomer/IsSupplier are derived from invoice history in Xero;
                # always false on creation regardless of what the client sends.
                "IsCustomer": False,
                "IsSupplier": False,
                "Addresses": _normalize_addresses(data.get("Addresses", [])),
                "Phones": _normalize_phones(data.get("Phones", [])),
                "ContactGroups": data.get("ContactGroups", []),
                "ContactPersons": data.get("ContactPersons", []),
                "SalesTrackingCategories": data.get("SalesTrackingCategories", []),
                "PurchasesTrackingCategories": data.get("PurchasesTrackingCategories", []),
                "UpdatedDateUTC": _xero_date(),
                "HasValidationErrors": False,
            }
            resources[contact_id] = contact
            return deepcopy(contact)

    def update_contact(
        self, contact_id: str, data: dict, tenant_id: Optional[str] = None
    ) -> Optional[dict]:
        with self._lock:
            resources = self._resources(tenant_id, "contacts")
            if contact_id not in resources:
                return None
            resources[contact_id].update({k: v for k, v in data.items() if k != "ContactID"})
            resources[contact_id]["UpdatedDateUTC"] = _xero_date()
            return deepcopy(resources[contact_id])

    def find_contacts_by_name(self, name: str, tenant_id: Optional[str] = None) -> list[dict]:
        with self._lock:
            return [
                deepcopy(c)
                for c in self._resources(tenant_id, "contacts").values()
                if c.get("Name", "").lower() == name.lower()
            ]

    # --- Invoices ---

    def _embed_contact(self, invoice: dict, contacts: dict) -> dict:
        """Replace Contact stub {ContactID: ...} with full contact data if available."""
        cid = invoice.get("Contact", {}).get("ContactID")
        if cid and cid in contacts:
            invoice["Contact"] = deepcopy(contacts[cid])
        return invoice

    def list_invoices(
        self,
        tenant_id: Optional[str] = None,
        contact_ids: Optional[list[str]] = None,
        invoice_numbers: Optional[list[str]] = None,
        statuses: Optional[list[str]] = None,
    ) -> list[dict]:
        with self._lock:
            contacts = self._resources(tenant_id, "contacts")
            invoices = list(self._resources(tenant_id, "invoices").values())
            if contact_ids:
                invoices = [
                    i for i in invoices
                    if i.get("Contact", {}).get("ContactID") in contact_ids
                ]
            if invoice_numbers:
                invoices = [
                    i for i in invoices
                    if i.get("InvoiceNumber") in invoice_numbers
                ]
            if statuses:
                invoices = [i for i in invoices if i.get("Status") in statuses]
            return [self._embed_contact(deepcopy(i), contacts) for i in invoices]

    def get_invoice(self, invoice_id: str, tenant_id: Optional[str] = None) -> Optional[dict]:
        with self._lock:
            contacts = self._resources(tenant_id, "contacts")
            inv = self._resources(tenant_id, "invoices").get(invoice_id)
            if inv is None:
                return None
            return self._embed_contact(deepcopy(inv), contacts)

    def create_invoice(self, data: dict, tenant_id: Optional[str] = None) -> dict:
        with self._lock:
            resources = self._resources(tenant_id, "invoices")
            invoice_id = new_id()
            raw_date = data.get("Date", "")
            raw_due = data.get("DueDate", "")
            line_items = [_normalize_line_item(li) for li in data.get("LineItems", [])]
            sub_total = data.get("SubTotal") or sum(
                float(li.get("LineAmount", 0)) for li in line_items
            )
            invoice = {
                "InvoiceID": invoice_id,
                "Type": data.get("Type", "ACCREC"),
                "InvoiceNumber": data.get("InvoiceNumber", f"INV-{invoice_id[:8].upper()}"),
                "Reference": data.get("Reference", ""),
                "Status": data.get("Status", "DRAFT"),
                "Contact": data.get("Contact", {}),
                "DateString": f"{raw_date}T00:00:00" if raw_date else "",
                "Date": _date_to_xero(raw_date),
                "DueDateString": f"{raw_due}T00:00:00" if raw_due else "",
                "DueDate": _date_to_xero(raw_due),
                "LineAmountTypes": data.get("LineAmountTypes", "Exclusive"),
                "LineItems": line_items,
                "SubTotal": sub_total,
                "TotalTax": data.get("TotalTax", 0.0),
                "Total": data.get("Total", sub_total),
                "AmountDue": data.get("AmountDue", data.get("Total", sub_total)),
                "AmountPaid": data.get("AmountPaid", 0.0),
                "AmountCredited": 0.0,
                "CurrencyCode": data.get("CurrencyCode", "USD"),
                "CurrencyRate": data.get("CurrencyRate", 1.0),
                "BrandingThemeID": new_id(),
                "IsDiscounted": False,
                "HasErrors": False,
                "HasAttachments": False,
                "SentToContact": False,
                "Overpayments": [],
                "Prepayments": [],
                "Payments": [],
                "CreditNotes": [],
                "InvoicePaymentServices": [],
                "UpdatedDateUTC": _xero_date(),
            }
            # Only include FullyPaidOnDate when it has a value
            if fpd := data.get("FullyPaidOnDate"):
                invoice["FullyPaidOnDate"] = fpd
            resources[invoice_id] = invoice
            contacts = self._resources(tenant_id, "contacts")
            return self._embed_contact(deepcopy(invoice), contacts)

    def update_invoice(
        self, invoice_id: str, data: dict, tenant_id: Optional[str] = None
    ) -> Optional[dict]:
        with self._lock:
            resources = self._resources(tenant_id, "invoices")
            contacts = self._resources(tenant_id, "contacts")
            if invoice_id not in resources:
                return None
            resources[invoice_id].update({k: v for k, v in data.items() if k != "InvoiceID"})
            resources[invoice_id]["UpdatedDateUTC"] = _xero_date()
            return self._embed_contact(deepcopy(resources[invoice_id]), contacts)

    def invoice_number_exists(self, number: str, tenant_id: Optional[str] = None) -> bool:
        with self._lock:
            return any(
                i.get("InvoiceNumber") == number
                for i in self._resources(tenant_id, "invoices").values()
            )

    # --- Payments ---

    def list_payments(self, tenant_id: Optional[str] = None) -> list[dict]:
        with self._lock:
            return list(deepcopy(self._resources(tenant_id, "payments")).values())

    def get_payment(self, payment_id: str, tenant_id: Optional[str] = None) -> Optional[dict]:
        with self._lock:
            return deepcopy(self._resources(tenant_id, "payments").get(payment_id))

    def create_payment(self, data: dict, tenant_id: Optional[str] = None) -> dict:
        with self._lock:
            resources = self._resources(tenant_id, "payments")
            invoices = self._resources(tenant_id, "invoices")
            contacts = self._resources(tenant_id, "contacts")
            payment_id = new_id()
            raw_date = data.get("Date", "")
            amount = float(data.get("Amount", 0.0))
            # Expand Account with stub AccountID/Name so structural shape matches real API.
            account = dict(data.get("Account", {}))
            account.setdefault("AccountID", new_id())
            account.setdefault("Name", "Bank Account")
            payment = {
                "PaymentID": payment_id,
                "Status": "AUTHORISED",
                "Amount": amount,
                "BankAmount": amount,
                "Date": _date_to_xero(raw_date),
                "CurrencyRate": data.get("CurrencyRate", 1.0),
                "PaymentType": data.get("PaymentType", "ACCRECPAYMENT"),
                "HasAccount": bool(data.get("Account")),
                "IsReconciled": False,
                "Account": account,
                "UpdatedDateUTC": _xero_date(),
                "HasValidationErrors": False,
            }
            # Embed linked invoice/credit note as full objects (matches real API).
            # The embedded invoice omits array/attachment fields not present in real API embeds.
            _inv_embed_exclude = {"Payments", "CreditNotes", "HasAttachments", "AmountCredited"}
            if inv_ref := data.get("Invoice"):
                inv_id = inv_ref.get("InvoiceID")
                if inv_id and inv_id in invoices:
                    paid = float(invoices[inv_id].get("AmountPaid", 0)) + amount
                    total = float(invoices[inv_id].get("Total", 0))
                    invoices[inv_id]["AmountPaid"] = paid
                    invoices[inv_id]["AmountDue"] = max(0.0, total - paid)
                    invoices[inv_id]["Payments"].append({"PaymentID": payment_id})
                    inv_embed = {
                        k: v for k, v in deepcopy(invoices[inv_id]).items()
                        if k not in _inv_embed_exclude
                    }
                    # Embed full Contact in the invoice (same as real API behaviour)
                    payment["Invoice"] = self._embed_contact(inv_embed, contacts)
                else:
                    payment["Invoice"] = inv_ref
            if cn_ref := data.get("CreditNote"):
                payment["CreditNote"] = cn_ref
            resources[payment_id] = payment
            return deepcopy(payment)

    def delete_payment(self, payment_id: str, tenant_id: Optional[str] = None) -> Optional[dict]:
        with self._lock:
            resources = self._resources(tenant_id, "payments")
            payment = resources.get(payment_id)
            if not payment:
                return None
            payment["Status"] = "DELETED"
            resources[payment_id] = payment
            return deepcopy(payment)

    # --- Credit Notes ---

    def list_credit_notes(self, tenant_id: Optional[str] = None) -> list[dict]:
        with self._lock:
            return list(deepcopy(self._resources(tenant_id, "credit_notes")).values())

    def get_credit_note(
        self, credit_note_id: str, tenant_id: Optional[str] = None
    ) -> Optional[dict]:
        with self._lock:
            return deepcopy(self._resources(tenant_id, "credit_notes").get(credit_note_id))

    def create_credit_note(self, data: dict, tenant_id: Optional[str] = None) -> dict:
        with self._lock:
            resources = self._resources(tenant_id, "credit_notes")
            cn_id = new_id()
            credit_note = {
                "CreditNoteID": cn_id,
                "Type": data.get("Type", "ACCRECCREDIT"),
                "CreditNoteNumber": data.get("CreditNoteNumber", f"CN-{cn_id[:8].upper()}"),
                "Reference": data.get("Reference", ""),
                "Status": data.get("Status", "DRAFT"),
                "Contact": data.get("Contact", {}),
                "Date": data.get("Date", ""),
                "LineItems": data.get("LineItems", []),
                "SubTotal": data.get("SubTotal", 0.0),
                "TotalTax": data.get("TotalTax", 0.0),
                "Total": data.get("Total", 0.0),
                "CurrencyCode": data.get("CurrencyCode", "USD"),
                "CurrencyRate": data.get("CurrencyRate", 1.0),
                "RemainingCredit": data.get("Total", 0.0),
                "Allocations": data.get("Allocations", []),
                "UpdatedDateUTC": _xero_date(),
                "HasValidationErrors": False,
            }
            resources[cn_id] = credit_note
            return deepcopy(credit_note)


# Global store instance
store = XeroStore()
