# xero-local

A lightweight local emulator for the [Xero Accounting API](https://developer.xero.com/documentation/api/accounting/overview), designed for development and testing without hitting the real Xero service.

Can be used standalone (Python or Docker) or as a [LocalStack](https://localstack.cloud) extension that starts automatically alongside LocalStack.

## Supported endpoints

| Resource | Operations |
|---|---|
| `Contacts` | list, get, create, update |
| `Invoices` | list, get, create, update |
| `Payments` | list, get, create, delete |
| `CreditNotes` | list, get, create, update |
| `Connections` | list (Identity API) |
| OAuth2 token | issue (any credentials accepted) |

All data is stored in memory and reset on restart. A `POST /_xero/reset` endpoint is available to clear state between tests.

## Quickstart

### Python

```bash
pip install localstack-xero
xero-local          # starts on http://localhost:5001
```

### Docker

```bash
docker run --rm -p 5001:5001 localstack/xero-local
```

Point your Xero client at `http://localhost:5001` instead of `https://api.xero.com`.

### LocalStack extension

```bash
localstack extensions install xero
localstack start
```

The emulator starts automatically with LocalStack and is reachable at `http://xero.localhost.localstack.cloud:4566`.

Set `XERO_PORT` (default `5001`) or `XERO_HOST` to change the bind address.

## Development

```bash
make install-dev   # install with test/lint deps
make test          # run the test suite (42 tests)
make run           # start the emulator locally
make lint          # ruff check
make format        # ruff format + autofix
```

### Docker

```bash
make docker-build  # build image for host platform
make docker-run    # run on port 5001
make docker-buildx # build and push multi-arch (amd64 + arm64)
```

## Configuration

| Variable | Default | Description |
|---|---|---|
| `XERO_PORT` | `5001` | Port the emulator listens on |
| `XERO_HOST` | `0.0.0.0` | Bind address |

## CI

Pushes to `main` and semver tags (`v*.*.*`) trigger a GitHub Actions workflow that runs the test suite (Python 3.9 and 3.11) and builds and pushes a multi-arch image (`linux/amd64`, `linux/arm64`) to Docker Hub. Required secrets: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`.
