"""History state behavior with shallow and deep history.

Tests exercise shallow history (remembers last direct child), deep history
(remembers exact leaf in nested compounds), default transitions on first visit,
multiple exit/reentry cycles, and the history_values dict.

Theme: Gollum's dual personality — remembers which was active.
"""

import pytest

from tests.machines.history.deep_memory_of_moria import DeepMemoryOfMoria
from tests.machines.history.gollum_personality import GollumPersonality
from tests.machines.history.gollum_personality_default_gollum import GollumPersonalityDefaultGollum
from tests.machines.history.gollum_personality_with_default import GollumPersonalityWithDefault
from tests.machines.history.shallow_moria import ShallowMoria


@pytest.mark.timeout(5)
class TestHistoryStates:
    async def test_shallow_history_remembers_last_child(self, sm_runner):
        """Exit compound, re-enter via history -> restores last active child."""
        sm = await sm_runner.start(GollumPersonality)
        await sm_runner.send(sm, "dark_side")
        assert "gollum" in sm.configuration_values

        await sm_runner.send(sm, "leave")
        assert {"outside"} == set(sm.configuration_values)

        await sm_runner.send(sm, "return_via_history")
        assert "gollum" in sm.configuration_values
        assert "personality" in sm.configuration_values

    async def test_shallow_history_default_on_first_visit(self, sm_runner):
        """No prior visit -> history uses default transition target."""
        sm = await sm_runner.start(GollumPersonalityWithDefault)
        assert {"outside"} == set(sm.configuration_values)

        await sm_runner.send(sm, "enter_via_history")
        assert "smeagol" in sm.configuration_values

    async def test_deep_history_remembers_full_descendant(self, sm_runner):
        """Deep history restores the exact leaf in a nested compound."""
        sm = await sm_runner.start(DeepMemoryOfMoria)
        await sm_runner.send(sm, "explore")
        assert "chamber" in sm.configuration_values

        await sm_runner.send(sm, "escape")
        assert {"outside"} == set(sm.configuration_values)

        await sm_runner.send(sm, "return_deep")
        assert "chamber" in sm.configuration_values
        assert "halls" in sm.configuration_values
        assert "moria" in sm.configuration_values

    async def test_multiple_exits_and_reentries(self, sm_runner):
        """History updates each time we exit the compound."""
        sm = await sm_runner.start(GollumPersonality)
        await sm_runner.send(sm, "leave")
        await sm_runner.send(sm, "return_via_history")
        assert "smeagol" in sm.configuration_values

        await sm_runner.send(sm, "dark_side")
        await sm_runner.send(sm, "leave")
        await sm_runner.send(sm, "return_via_history")
        assert "gollum" in sm.configuration_values

        await sm_runner.send(sm, "light_side")
        await sm_runner.send(sm, "leave")
        await sm_runner.send(sm, "return_via_history")
        assert "smeagol" in sm.configuration_values

    async def test_history_after_state_change(self, sm_runner):
        """Change state within compound, exit, re-enter -> new state restored."""
        sm = await sm_runner.start(GollumPersonality)
        await sm_runner.send(sm, "dark_side")
        await sm_runner.send(sm, "leave")
        await sm_runner.send(sm, "return_via_history")
        assert "gollum" in sm.configuration_values

    async def test_shallow_only_remembers_immediate_child(self, sm_runner):
        """Shallow history in nested compound restores direct child, not grandchild."""
        sm = await sm_runner.start(ShallowMoria)
        await sm_runner.send(sm, "explore")
        assert "chamber" in sm.configuration_values

        await sm_runner.send(sm, "escape")
        await sm_runner.send(sm, "return_shallow")
        # Shallow history restores 'halls' as the direct child,
        # but re-enters halls at its initial state (entrance), not chamber
        assert "halls" in sm.configuration_values
        assert "entrance" in sm.configuration_values

    async def test_history_values_dict_populated(self, sm_runner):
        """sm.history_values[history_id] has saved states after exit."""
        sm = await sm_runner.start(GollumPersonality)
        await sm_runner.send(sm, "dark_side")
        await sm_runner.send(sm, "leave")
        assert "h" in sm.history_values
        saved = sm.history_values["h"]
        assert len(saved) == 1
        assert saved[0].id == "gollum"

    async def test_history_with_default_transition(self, sm_runner):
        """HistoryState with explicit default .to() transition."""
        sm = await sm_runner.start(GollumPersonalityDefaultGollum)
        await sm_runner.send(sm, "enter_via_history")
        assert "gollum" in sm.configuration_values
