from __future__ import annotations

import base64
import json
import re
from html import unescape
from typing import Any
from urllib.parse import unquote

import click
from click.core import ParameterSource

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import NETWORK_ERROR_CODE, WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload

ARTICLE_SEARCH_PATH = "/v1/Finder/WebSearch"
ARTICLE_BUSINESS_TYPE = 2
ARTICLE_SCENE = 101
CURSOR_VERSION = 1
DEFAULT_SORT = "default"
NEWEST_SORT = "newest"
HOT_SORT = "hot"
SORT_CHOICES = (DEFAULT_SORT, NEWEST_SORT, HOT_SORT)

HIGHLIGHT_TAG_RE = re.compile(r"</?em\b[^>]*>")
READ_COUNT_RE = re.compile(r"(?:^|&)show_tag=R_2_1_(\d+)(?:&|$)")


@click.group()
def search() -> None:
    """WeChat Search (微信搜一搜) — the in-app WeChat search engine that indexes official account articles, videos, mini-programs and more. These commands cover two different search intents: search-suggestion related keywords (`search related`) and normalized official-account article result lists (`search article`)."""


@search.command()
@click.option("--seed", required=True, help="Seed keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, seed: str) -> JsonObject:
    """Get long-tail user-query related keywords for a seed term from WeChat Search (e.g. seed='咖啡' → ['附近咖啡店', '星巴克咖啡', '中国咖啡十大品牌']). These are phrase-level actual user queries from WeChat Search's suggestion aggregator, NOT short word associations — for short word-level terms use 'wxflywheel wxindex related' instead. Requires the WeChat account (identified by --key) to be online. Returns {seed, related[]}."""
    client = require_client(runtime)
    payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": seed})
    words = payload["data"]["words"]
    return success_payload({"seed": seed, "related": words}, payload["message"])


@search.command()
@click.option(
    "--keyword",
    default=None,
    help="Keyword for a new article-list search.",
)
@click.option(
    "--cursor",
    default=None,
    help="Opaque next-page cursor returned by a previous 'wxflywheel search article' response.",
)
@click.option(
    "--sort",
    "sort_name",
    type=click.Choice(SORT_CHOICES, case_sensitive=False),
    default=DEFAULT_SORT,
    show_default=True,
    help="Article list order. Use only with --keyword.",
)
@click.pass_obj
@json_command
def article(
    runtime: RuntimeContext,
    keyword: str | None,
    cursor: str | None,
    sort_name: str,
) -> JsonObject:
    """Search WeChat Search official-account article results and return a normalized article list, NOT article bodies, comments or engagement-detail pages. Use --keyword to start a new search and choose one of the three live-verified list orders (`default`, `newest`, `hot`); use --cursor to fetch the next page of a previous result set without manually handling offset, search_id or cookies. Returns {keyword, sort, has_more, next_cursor?, items[]} where each item keeps only article_id/title/summary/source_name/published_at_ts/url/cover_url plus read_count/read_count_text when the live response actually includes reading-hotness metadata."""
    ctx = click.get_current_context()
    sort_source = ctx.get_parameter_source("sort_name")
    if (keyword is None) == (cursor is None):
        raise click.UsageError(
            "Provide exactly one of --keyword or --cursor. Use --keyword to start a new article search and --cursor to fetch the next page of a previous article result set."
        )
    if cursor is not None and sort_source != ParameterSource.DEFAULT:
        raise click.UsageError(
            "Do not pass --sort together with --cursor. The cursor already contains the original article-search order."
        )

    if cursor is not None:
        cursor_payload = _decode_cursor(cursor)
        request_keyword = cursor_payload["keyword"]
        request_sort = cursor_payload["sort"]
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=cursor_payload["offset"],
            search_id=cursor_payload["search_id"],
            cookies=cursor_payload.get("cookies"),
        )
    else:
        request_keyword = keyword if keyword is not None else ""
        request_sort = sort_name
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=0,
            search_id="",
            cookies=None,
        )

    client = require_client(runtime)
    payload = client.post(ARTICLE_SEARCH_PATH, body=body)
    article_data = _build_article_output(payload["data"], keyword=request_keyword, sort_name=request_sort)
    return success_payload(article_data, payload["message"])


def _build_article_search_body(
    *, keyword: str, sort_name: str, offset: int, search_id: str, cookies: str | None
) -> JsonObject:
    body: JsonObject = {
        "KeyWord": keyword,
        "Offset": offset,
        "BusinessType": ARTICLE_BUSINESS_TYPE,
        "Scene": ARTICLE_SCENE,
        "SearchId": search_id,
    }
    ext_req_params = _build_article_ext_req_params(sort_name=sort_name, cookies=cookies)
    if ext_req_params:
        body["ExtReqParams"] = ext_req_params
    return body


def _build_article_ext_req_params(*, sort_name: str, cookies: str | None) -> list[JsonObject]:
    params: list[JsonObject] = []
    if sort_name == NEWEST_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"2\"]"})
    elif sort_name == HOT_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"4\"]"})

    if isinstance(cookies, str) and cookies:
        params.append({"Key": "cookies", "TextValue": cookies})
    return params


def _build_article_output(payload_data: Any, *, keyword: str, sort_name: str) -> JsonObject:
    outer_data = _require_dict(payload_data, field_name="WebSearch outer data")
    raw_inner_json = outer_data.get("json")
    if not isinstance(raw_inner_json, str) or not raw_inner_json.strip():
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is missing or empty, so the article result list cannot be parsed.",
        )

    try:
        inner_payload = json.loads(raw_inner_json)
    except ValueError as exc:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is not valid JSON, so the article result list cannot be parsed.",
        ) from exc

    inner_data = _require_dict(inner_payload, field_name="WebSearch inner data.json")
    raw_groups = inner_data.get("data")
    if not isinstance(raw_groups, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article search payload is missing the inner data[] groups, so the article result list cannot be parsed.",
        )

    article_group = _find_article_group(raw_groups)
    if article_group is None:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    items = _normalize_article_items(article_group.get("items"))
    if not items:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    has_more = _coerce_intlike(inner_data.get("continueFlag"), field_name="continueFlag") == 1

    result: JsonObject = {
        "keyword": keyword,
        "sort": sort_name,
        "has_more": has_more,
        "items": items,
    }
    if has_more:
        result["next_cursor"] = _encode_cursor(
            {
                "v": CURSOR_VERSION,
                "keyword": keyword,
                "sort": sort_name,
                "offset": _coerce_intlike(inner_data.get("offset"), field_name="offset"),
                "search_id": _require_string(inner_data.get("searchID"), field_name="searchID"),
                "cookies": _require_string(inner_data.get("cookies"), field_name="cookies"),
            }
        )
    return result


def _find_article_group(raw_groups: list[object]) -> dict[str, Any] | None:
    for group in raw_groups:
        if not isinstance(group, dict):
            continue
        raw_type = group.get("type")
        if _try_coerce_intlike(raw_type) == ARTICLE_BUSINESS_TYPE:
            return group
    return None


def _normalize_article_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article group exists but its items field is not a list, so the article result list cannot be normalized.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"article item #{index}")
        source = _require_dict(item.get("source"), field_name=f"article item #{index}.source")
        article: JsonObject = {
            "article_id": _require_string(item.get("docID"), field_name=f"article item #{index}.docID"),
            "title": _clean_highlight_text(
                _require_string(item.get("title"), field_name=f"article item #{index}.title")
            ),
            "summary": _clean_highlight_text(
                _require_string(
                    item.get("desc"),
                    field_name=f"article item #{index}.desc",
                    allow_empty=True,
                )
            ),
            "source_name": _require_string(
                source.get("title"), field_name=f"article item #{index}.source.title"
            ),
            "published_at_ts": _coerce_intlike(
                item.get("timestamp"), field_name=f"article item #{index}.timestamp"
            ),
            "url": _require_string(item.get("doc_url"), field_name=f"article item #{index}.doc_url"),
            "cover_url": _require_string(
                item.get("thumbUrl"), field_name=f"article item #{index}.thumbUrl"
            ),
        }

        read_count_text = _extract_read_count_text(source.get("tag"))
        if read_count_text is not None:
            article["read_count_text"] = read_count_text

        read_count = _extract_read_count(item.get("report_extinfo_str"))
        if read_count is not None:
            article["read_count"] = read_count

        normalized.append(article)
    return normalized


def _clean_highlight_text(text: str) -> str:
    return unescape(HIGHLIGHT_TAG_RE.sub("", text))


def _extract_read_count_text(raw_tags: Any) -> str | None:
    if not isinstance(raw_tags, list):
        return None
    for raw_tag in raw_tags:
        if not isinstance(raw_tag, dict):
            continue
        title = raw_tag.get("title")
        if isinstance(title, str) and title.startswith("阅读"):
            return title
    return None


def _extract_read_count(raw_report_extinfo: Any) -> int | None:
    if not isinstance(raw_report_extinfo, str) or not raw_report_extinfo:
        return None
    decoded = unquote(raw_report_extinfo)
    match = READ_COUNT_RE.search(decoded)
    if match is None:
        return None
    return int(match.group(1))


def _encode_cursor(cursor_payload: JsonObject) -> str:
    raw = json.dumps(cursor_payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_cursor(raw_cursor: str) -> dict[str, Any]:
    cursor_value = raw_cursor.strip()
    if not cursor_value:
        raise click.BadParameter(
            "Cursor is empty. Pass the exact next_cursor string returned by a previous 'wxflywheel search article' response.",
            param_hint="--cursor",
        )

    padding = "=" * (-len(cursor_value) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(f"{cursor_value}{padding}")
        payload = json.loads(decoded_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise click.BadParameter(
            "Cursor is not a valid article-search cursor. It may have been truncated, copied incorrectly, or generated by a different command/version.",
            param_hint="--cursor",
        ) from exc

    if not isinstance(payload, dict):
        raise click.BadParameter(
            "Cursor is not a JSON object. Pass the exact next_cursor string returned by 'wxflywheel search article'.",
            param_hint="--cursor",
        )

    version = payload.get("v")
    if version != CURSOR_VERSION:
        raise click.BadParameter(
            f"Cursor version is unsupported (expected v={CURSOR_VERSION}). Generate a fresh cursor with the current 'wxflywheel search article' command.",
            param_hint="--cursor",
        )

    keyword = payload.get("keyword")
    sort_name = payload.get("sort")
    search_id = payload.get("search_id")
    cookies = payload.get("cookies")

    if not isinstance(keyword, str) or not keyword:
        raise click.BadParameter(
            "Cursor is missing a valid keyword field.", param_hint="--cursor"
        )
    if sort_name not in SORT_CHOICES:
        raise click.BadParameter(
            "Cursor is missing a valid sort field.", param_hint="--cursor"
        )
    if not isinstance(search_id, str) or not search_id:
        raise click.BadParameter(
            "Cursor is missing a valid search_id field.", param_hint="--cursor"
        )
    if cookies is not None and not isinstance(cookies, str):
        raise click.BadParameter(
            "Cursor cookies field must be a string when present.", param_hint="--cursor"
        )

    try:
        offset = _coerce_intlike(payload.get("offset"), field_name="cursor.offset")
    except WxflywheelError as exc:
        raise click.BadParameter(exc.message, param_hint="--cursor") from exc

    return {
        "keyword": keyword,
        "sort": sort_name,
        "offset": offset,
        "search_id": search_id,
        "cookies": cookies,
    }


def _require_dict(value: Any, *, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is not a JSON object, so the article result list cannot be normalized safely.",
        )
    return value


def _require_string(value: Any, *, field_name: str, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        requirement = "string" if allow_empty else "non-empty string"
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not a {requirement}, so the article result list cannot be normalized safely.",
        )
    return value


def _coerce_intlike(value: Any, *, field_name: str) -> int:
    coerced = _try_coerce_intlike(value)
    if coerced is None:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not numeric, so the article result list cannot be normalized safely.",
        )
    return coerced


def _try_coerce_intlike(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError:
            return None
    return None
