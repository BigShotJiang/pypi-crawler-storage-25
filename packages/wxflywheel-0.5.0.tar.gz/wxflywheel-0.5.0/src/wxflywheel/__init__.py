"""wxflywheel CLI package."""

__version__ = "0.5.0"
