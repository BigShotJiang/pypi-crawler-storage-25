<img src="imgs/SeisCat_logo.svg" width="400">

# SeisCat

Keep a local seismic catalog.

[![changelog-badge]][changelog-link]
[![PyPI-badge]][PyPI-link]
[![license-badge]][license-link]
[![docs-badge]][docs-link]
[![DeepWiki-badge]][DeepWiki-link]
[![codecov-badge]][codecov-link]
[![DOI-badge]][DOI-link]

Copyright (c) 2022-2026 Claudio Satriano <satriano@ipgp.fr>

## Overview

SeisCat is a command-line tool to build, maintain, and query a local seismic
catalog.

It builds and updates the catalog from FDSNWS event web services or local
event files. Input formats include CSV and any format handled by ObsPy
(QuakeML, SC3ML, NLLOC, etc.). The catalog is stored in a SQLite
single-file database and can be used as a basis for further analysis.

SeisCat also provides tools to plot and export the catalog, fetch waveforms
and station metadata for catalog events, and run user-defined scripts on those
events.

👇  See below on how to [install](#installation) and
[get started](#getting-started).

📖 Check out the official documentation [here](https://seiscat.rtfd.io).

## Getting Started

To get help:

    seiscat -h

First thing to do is to generate a sample configuration file:

    seiscat sampleconfig

Then, edit the configuration file and init the database:

    seiscat initdb

Alternatively, you can init the database from an event file (CSV, QuakeML,
SC3ML, NLLOC, etc.):

    seiscat initdb -f /path/to/your/catalog.csv
    seiscat initdb -f /path/to/your/events.xml

To update an existing database from an FDSN webservice, run:

    seiscat updatedb

(This will use the configuration parameter `recheck_period` to recheck the
last *n* days or hours).

Alternatively, you can update the database from an event file:

    seiscat updatedb -f /path/to/your/catalog.csv
    seiscat updatedb -f /path/to/your/events.xml

You can edit the attributes of specific events in the database using:

    seiscat editdb

You can print the catalog to screen:

    seiscat print

Or plot it:

    seiscat plot

Each of the above commands can have its own options.
As an example, to discover the options for the `plot` command, try:

    seiscat plot -h

SeisCat supports command line tab completion for arguments, thanks to
[argcomplete](https://kislyuk.github.io/argcomplete/).
To enable command line tab completion run:

    activate-global-python-argcomplete

(This is a one-time command that needs to be run only once).

Or, alternatively, add the following line to your `.bashrc` or `.zshrc`:

    eval "$(register-python-argcomplete seiscat)"

## Installation

### Installing the latest release

#### Using pip and PyPI (preferred method)

The latest release of SeisCat is available on the
[Python Package Index](https://pypi.org/project/seiscat/).

You can install it easily through `pip`:

    pip install seiscat

Optional plotting backends can be installed with extras:

    pip install seiscat[cartopy]
    pip install seiscat[plotly]
    pip install seiscat[cartopy,plotly]

To upgrade from a previously installed version:

    pip install --upgrade seiscat

#### From SeisCat GitHub releases

Download the latest release from the
[releases page](https://github.com/SeismicSource/seiscat/releases),
in `zip` or `tar.gz` format, then:

    pip install seiscat-X.Y.zip

or

    pip install seiscat-X.Y.tar.gz

Where, `X.Y` is the version number (e.g., `0.1`).
You don't need to uncompress the release files yourself.

### Installing a developer snapshot

If you need a recent feature that is not in the latest release (see the
`unreleased` section in [CHANGELOG][changelog-link]), you want to use the more
recent development snapshot from the
[SeisCat GitHub repository](https://github.com/SeismicSource/seiscat).

#### Using pip (preferred method)

The easiest way to install the most recent development snapshot is to download
and install it through `pip`, using its builtin `git` client:

    pip install git+https://github.com/SeismicSource/seiscat.git

Run this command again, from times to times, to keep SeisCat updated with
the development version.

### Cloning the SeisCat GitHub repository

If you want to take a look at the source code (and possibly modify it 😉),
clone the project using `git`:

    git clone https://github.com/SeismicSource/seiscat.git

or, using SSH:

    git clone git@github.com:SeismicSource/seiscat.git

(avoid using the "Download ZIP" option from the green "Code" button, since
version number is lost).

Then, go into the `seiscat` main directory and install the code in "editable
mode" by running:

    pip install -e .

To install optional plotting backends in editable mode:

    pip install -e .[cartopy]
    pip install -e .[plotly]
    pip install -e .[cartopy,plotly]

You can keep your local SeisCat repository updated by running `git pull`
from times to times. Thanks to `pip`'s "editable mode", you don't need to
reinstall SeisCat after each update.

## Getting Help / Reporting Bugs

### 🙏 I need help

Please open an [Issue][Issues].

### 🐞 I found a bug

Please open an [Issue][Issues].

## Contributing

I'm very open to contributions: if you have new ideas, please open an
[Issue][Issues].
Don't hesitate sending me pull requests with new features and/or bugfixes!

<!-- Badges and project links -->
[changelog-badge]: https://img.shields.io/badge/Changelog-136CB6.svg
[changelog-link]: CHANGELOG.md
[PyPI-badge]: http://img.shields.io/pypi/v/seiscat.svg
[PyPI-link]: https://pypi.python.org/pypi/seiscat
[license-badge]: https://img.shields.io/badge/license-GPLv3-green
[license-link]: https://www.gnu.org/licenses/gpl-3.0.html
[docs-badge]: https://readthedocs.org/projects/seiscat/badge/?version=latest
[docs-link]: https://seiscat.readthedocs.io/en/latest/?badge=latest
[DOI-badge]: https://zenodo.org/badge/DOI/10.5281/zenodo.19596891.svg
[DOI-link]: https://doi.org/10.5281/zenodo.19596891
[Issues]: https://github.com/SeismicSource/seiscat/issues
[codecov-badge]: https://codecov.io/github/SeismicSource/seiscat/graph/badge.svg?token=X0Z60185PC
[codecov-link]: https://codecov.io/github/SeismicSource/seiscat
[DeepWiki-badge]: https://deepwiki.com/badge.svg
[DeepWiki-link]: https://deepwiki.com/SeismicSource/seiscat
