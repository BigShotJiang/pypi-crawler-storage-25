## Module: `{{ path }}`

**Lines:** {{ lines }}

### Module Contents
{{ module_contents }}

{% if previous_commit %}
### Changes Since Last Review

**Previous review:** {{ previous_commit }} ({{ previous_date }})
**Current HEAD:** {{ current_commit }}

[View diff]({{ diff_url }})

**Previous reviewers:** {{ previous_reviewers }}
{% else %}
### First Review

This module has not been formally reviewed before.

**Current HEAD:** {{ current_commit }}
{% endif %}

---

## Pre-Review Checklist

Before reviewing the code, verify these items:

- [ ] **AI Review** — Read the Claude review comment (if present). Confirm findings are addressed or note disagreements below.
- [ ] **AI Fix MR** — Check if an automated fix MR exists. Review, merge, or note why it was skipped.
- [ ] **Linting & Formatting** — Confirm the module passes project linters and formatters.
- [ ] **Type Checking** — Confirm no type errors are introduced in this module.
- [ ] **Test Coverage** — Confirm tests exist and pass for this module.

---

## Review Checklist

Rate each criterion: **OK** | **SUGGESTED** | **REQUIRED**
- **OK** - No issues found
- **SUGGESTED** - Improvement worth considering; author's discretion
- **REQUIRED** - Must fix before sign-off

| # | Criterion | Rating | Notes |
|---|-----------|--------|-------|
| 1 | **Correctness** - Logic errors? Wrong results? Unhandled edge cases? | | |
| 2 | **Error Handling** - Validates inputs? Handles failures? No resource leaks? | | |
| 3 | **Code Quality** - DRY? Well organized? Clear naming? Appropriate abstractions? | | |
| 4 | **Testing** - Critical paths covered? Meaningful assertions? Edge cases? | | |
| 5 | **Documentation** - Non-obvious decisions explained? Public API documented? | | |
| 6 | **Risk** - Security, performance, or data integrity concerns? (N/A if none) | | |

---

## Findings

_Add detailed findings below. Use `glreview claude-review {{ path }}` for AI-assisted review._

---

When complete (no REQUIRED items remaining), close this issue and run:
```
glreview signoff {{ path }}
```
