import pytest
from btr.client import BarterClient

class TestBarterClient:
    def test_init_default(self):
        client = BarterClient()
        assert client.network == "sepolia"
        assert client.trust is not None
        assert client.trade is not None
        assert client.credit is not None
        assert client.compliance is not None

    def test_subclients_accessible(self):
        client = BarterClient()
        assert hasattr(client, "trust")
        assert hasattr(client, "trade")
        assert hasattr(client, "credit")
        assert hasattr(client, "compliance")

    def test_version(self):
        import btr
        assert btr.__version__ == "1.0.0"

    def test_imports(self):
        from btr import BarterClient, TrustProfile, Trade, TradeStatus
        from btr import BarterError, InvalidAddressError
        assert BarterClient is not None
        assert TrustProfile is not None
