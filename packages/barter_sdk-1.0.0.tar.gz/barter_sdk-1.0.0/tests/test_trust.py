import pytest
from btr.trust import TrustClient
from btr.types import TrustProfile
from btr.exceptions import InvalidAddressError
from unittest.mock import MagicMock

VALID_ADDR = "0x742d35Cc6634C0532925a3b844Bc9e7595f3F9a0"
ZERO_ADDR = "0x0000000000000000000000000000000000000000"

@pytest.fixture
def trust_client():
    w3 = MagicMock()
    w3.to_checksum_address = lambda x: x
    contracts = {"BTRTrust": None, "BarterCore": None}
    return TrustClient(w3, contracts)

class TestGetScore:
    def test_valid_address_returns_int(self, trust_client):
        score = trust_client.get_score(VALID_ADDR)
        assert isinstance(score, int)
        assert score == 0

    def test_invalid_address_raises(self, trust_client):
        with pytest.raises(InvalidAddressError):
            trust_client.get_score("invalid")

    def test_empty_address_raises(self, trust_client):
        with pytest.raises(InvalidAddressError):
            trust_client.get_score("")

    def test_short_address_raises(self, trust_client):
        with pytest.raises(InvalidAddressError):
            trust_client.get_score("0x123")

class TestGetProfile:
    def test_returns_trust_profile(self, trust_client):
        profile = trust_client.get_profile(VALID_ADDR)
        assert isinstance(profile, TrustProfile)

    def test_all_required_fields(self, trust_client):
        profile = trust_client.get_profile(VALID_ADDR)
        assert hasattr(profile, "address")
        assert hasattr(profile, "score")
        assert hasattr(profile, "unique_counterparties")
        assert hasattr(profile, "trade_count")
        assert hasattr(profile, "completion_rate")

    def test_invalid_address_raises(self, trust_client):
        with pytest.raises(InvalidAddressError):
            trust_client.get_profile("bad")

class TestGetHistory:
    def test_returns_list(self, trust_client):
        result = trust_client.get_history(VALID_ADDR)
        assert isinstance(result, list)

    def test_with_date_filters(self, trust_client):
        from datetime import datetime
        result = trust_client.get_history(
            VALID_ADDR,
            from_date=datetime(2024, 1, 1),
            to_date=datetime(2024, 12, 31)
        )
        assert isinstance(result, list)
