import pytest
from btr.trade import TradeClient
from btr.types import Trade
from btr.exceptions import SelfTradeError, InsufficientAmountError, InvalidAddressError
from unittest.mock import MagicMock

ALICE = "0x742d35Cc6634C0532925a3b844Bc9e7595f3F9a0"
BOB = "0x8ba1f109551bD432803012645Ac136ddd64DBA72"

@pytest.fixture
def trade_client():
    w3 = MagicMock()
    w3.to_checksum_address = lambda x: x
    w3.eth.accounts = [ALICE]
    contracts = {"BarterCore": None}
    return TradeClient(w3, contracts)

class TestPropose:
    def test_self_trade_raises(self, trade_client):
        with pytest.raises(SelfTradeError):
            trade_client.propose(ALICE, "0x" + "ab" * 32, 5000)

    def test_below_min_raises(self, trade_client):
        with pytest.raises(InsufficientAmountError):
            trade_client.propose(BOB, "0x" + "ab" * 32, 999)

    def test_invalid_address_raises(self, trade_client):
        with pytest.raises(InvalidAddressError):
            trade_client.propose("bad", "0x" + "ab" * 32, 5000)

    def test_long_description_raises(self, trade_client):
        with pytest.raises(ValueError):
            trade_client.propose(BOB, "0x" + "ab" * 32, 5000, description="x" * 201)

class TestGet:
    def test_not_found_raises(self, trade_client):
        from btr.exceptions import TradeNotFoundError
        with pytest.raises(TradeNotFoundError):
            trade_client.get("0x" + "00" * 32)

class TestListByAddress:
    def test_returns_list(self, trade_client):
        result = trade_client.list_by_address(BOB)
        assert isinstance(result, list)
