import pytest
from btr.compliance import ComplianceClient
from btr.types import ComplianceReport, VelocityReport, ClusterReport
from btr.exceptions import InvalidAddressError
from unittest.mock import MagicMock

VALID_ADDR = "0x742d35Cc6634C0532925a3b844Bc9e7595f3F9a0"

@pytest.fixture
def compliance_client():
    w3 = MagicMock()
    w3.to_checksum_address = lambda x: x
    contracts = {"BarterCore": None, "BTRTrust": None}
    return ComplianceClient(w3, contracts)

class TestGetFlags:
    def test_returns_list(self, compliance_client):
        flags = compliance_client.get_flags(VALID_ADDR)
        assert isinstance(flags, list)

    def test_invalid_address_raises(self, compliance_client):
        with pytest.raises(InvalidAddressError):
            compliance_client.get_flags("bad")

class TestFullReport:
    def test_returns_compliance_report(self, compliance_client):
        report = compliance_client.full_report(VALID_ADDR)
        assert isinstance(report, ComplianceReport)

    def test_has_all_fields(self, compliance_client):
        report = compliance_client.full_report(VALID_ADDR)
        assert hasattr(report, "flags")
        assert hasattr(report, "velocity")
        assert hasattr(report, "cluster")
        assert hasattr(report, "risk_level")
        assert hasattr(report, "generated_at")

    def test_velocity_report(self, compliance_client):
        velocity = compliance_client.get_velocity(VALID_ADDR)
        assert isinstance(velocity, VelocityReport)

    def test_cluster_report(self, compliance_client):
        cluster = compliance_client.detect_isolation(VALID_ADDR)
        assert isinstance(cluster, ClusterReport)
