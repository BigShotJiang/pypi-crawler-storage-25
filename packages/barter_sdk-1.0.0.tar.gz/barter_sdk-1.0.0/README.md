# barter-sdk

Python SDK for the BTR Proof of Trade Protocol.

## Install

```bash
pip install barter-sdk
```

## Usage

```python
import btr

client = btr.BarterClient(network="sepolia")

# Get trust score
score = client.trust.get_score("0x742d...3F9a")

# Get full profile
profile = client.trust.get_profile("0x742d...3F9a")
print(f"Score: {profile.score}")
print(f"Trades: {profile.trade_count}")

# Compliance check
report = client.compliance.full_report("0x742d...3F9a")
print(f"Risk: {report.risk_level}")
```

## License

MIT
