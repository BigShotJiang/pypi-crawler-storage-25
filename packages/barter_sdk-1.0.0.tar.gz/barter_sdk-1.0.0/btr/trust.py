from datetime import datetime
from typing import List, Optional
from btr.types import TrustProfile, ScoreEvent
from btr.exceptions import InvalidAddressError

class TrustClient:
    def __init__(self, w3, contracts):
        self._w3 = w3
        self._trust = contracts.get("BTRTrust")
        self._core = contracts.get("BarterCore")

    def _validate_address(self, address: str) -> str:
        if not address or not isinstance(address, str):
            raise InvalidAddressError(f"Invalid address: {address}")
        if not address.startswith("0x") or len(address) != 42:
            raise InvalidAddressError(f"Invalid address format: {address}")
        try:
            return self._w3.to_checksum_address(address)
        except Exception:
            raise InvalidAddressError(f"Invalid address: {address}")

    def get_score(self, address: str) -> int:
        """Get the BTR-Trust score for a wallet address."""
        addr = self._validate_address(address)
        if self._trust is None:
            return 0
        return self._trust.functions.getScore(addr).call()

    def get_profile(self, address: str) -> TrustProfile:
        """Get the full trust profile for a wallet address."""
        addr = self._validate_address(address)
        if self._trust is None:
            return TrustProfile(
                address=addr, score=0, unique_counterparties=0,
                trade_count=0, completion_rate=0.0
            )
        result = self._trust.functions.getTrustProfile(addr).call()
        score, unique, member_since_ts, trade_count, last_trade_ts = result

        # Calculate completion rate from trade data
        settled = 0
        total = 0
        if self._core:
            trade_ids = self._core.functions.getTradesByAddress(addr).call()
            total = len(trade_ids)
            for tid in trade_ids:
                trade = self._core.functions.trades(tid).call()
                if trade[5] == 2:  # Settled status
                    settled += 1

        completion_rate = (settled / total * 100) if total > 0 else 0.0

        return TrustProfile(
            address=addr,
            score=score,
            unique_counterparties=unique,
            member_since=datetime.fromtimestamp(member_since_ts) if member_since_ts > 0 else None,
            trade_count=trade_count,
            completion_rate=round(completion_rate, 1),
            last_trade_at=datetime.fromtimestamp(last_trade_ts) if last_trade_ts > 0 else None,
        )

    def get_history(self, address: str, from_date: Optional[datetime] = None, to_date: Optional[datetime] = None) -> List[ScoreEvent]:
        """Get score change history for an address."""
        addr = self._validate_address(address)
        # Would query ScoreUpdated events from the contract
        return []

    def get_pair_count(self, addr_a: str, addr_b: str) -> int:
        """Get the number of trust-counted trades between two addresses."""
        a = self._validate_address(addr_a)
        b = self._validate_address(addr_b)
        if self._trust is None:
            return 0
        return self._trust.functions.pairCount(a, b).call()
