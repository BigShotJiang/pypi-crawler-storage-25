import json
import os

SEPOLIA_CHAIN_ID = 11155111
DEFAULT_RPC = "https://eth-sepolia.g.alchemy.com/v2/demo"
MIN_TRADE_SATS = 1000
MAX_PAIR_TRUST = 5
TRADE_EXPIRY_SECONDS = 7 * 24 * 3600

# Contract addresses (Sepolia deployment)
CONTRACTS = {
    "sepolia": {
        "BarterCore": "0x0000000000000000000000000000000000000001",
        "BTRTrust": "0x0000000000000000000000000000000000000002",
        "BTRCredit": "0x0000000000000000000000000000000000000003",
    }
}

def _load_abi(name: str) -> list:
    abi_dir = os.path.join(os.path.dirname(__file__), "abis")
    path = os.path.join(abi_dir, f"{name}.json")
    if os.path.exists(path):
        with open(path) as f:
            data = json.load(f)
            return data if isinstance(data, list) else data.get("abi", [])
    return []

ABIS = {
    "BarterCore": _load_abi("BarterCore"),
    "BTRTrust": _load_abi("BTRTrust"),
    "BTRCredit": _load_abi("BTRCredit"),
}
