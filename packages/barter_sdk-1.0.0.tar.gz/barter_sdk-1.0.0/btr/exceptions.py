class BarterError(Exception):
    """Base exception for all BTR SDK errors."""
    pass

class InvalidAddressError(BarterError):
    """Raised when an Ethereum address is invalid."""
    pass

class TradeNotFoundError(BarterError):
    """Raised when a trade ID does not exist on-chain."""
    pass

class PreimageMismatchError(BarterError):
    """Raised when SHA256(preimage) != payment_hash."""
    pass

class InsufficientAmountError(BarterError):
    """Raised when trade amount is below minimum (1000 sats)."""
    pass

class SelfTradeError(BarterError):
    """Raised when attempting to trade with yourself."""
    pass

class NetworkError(BarterError):
    """Raised on RPC/network connectivity issues."""
    pass
