from datetime import datetime
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field

class TradeStatus(str, Enum):
    PROPOSED = "proposed"
    ACCEPTED = "accepted"
    SETTLED = "settled"
    DISPUTED = "disputed"
    EXPIRED = "expired"

class TrustProfile(BaseModel):
    address: str
    score: int
    unique_counterparties: int
    member_since: Optional[datetime] = None
    trade_count: int = 0
    completion_rate: float = 0.0
    last_trade_at: Optional[datetime] = None

class Trade(BaseModel):
    trade_id: str
    party_a: str
    party_b: str
    payment_hash: str
    amount_sats: int
    status: TradeStatus
    created_at: datetime
    accepted_at: Optional[datetime] = None
    settled_at: Optional[datetime] = None
    category: str = ""
    description: str = ""

class ScoreEvent(BaseModel):
    block_number: int
    timestamp: datetime
    delta: int
    new_score: int
    counterparty: str
    amount_sats: int

class AnomalyFlag(BaseModel):
    flag_type: str
    severity: str  # "low", "medium", "high"
    description: str
    detected_at: datetime
    details: dict = Field(default_factory=dict)

class VelocityReport(BaseModel):
    address: str
    trades_24h: int
    trades_7d: int
    trades_30d: int
    avg_amount_sats: int
    is_elevated: bool

class ClusterReport(BaseModel):
    address: str
    cluster_size: int
    isolation_score: float
    connected_addresses: List[str]
    depth_analyzed: int

class ComplianceReport(BaseModel):
    address: str
    flags: List[AnomalyFlag]
    velocity: VelocityReport
    cluster: ClusterReport
    risk_level: str  # "low", "medium", "high"
    generated_at: datetime
