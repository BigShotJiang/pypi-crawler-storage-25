import hashlib
from datetime import datetime
from typing import List
from btr.types import Trade, TradeStatus
from btr.exceptions import (
    InvalidAddressError, TradeNotFoundError,
    PreimageMismatchError, InsufficientAmountError, SelfTradeError
)

class TradeClient:
    MIN_TRADE_SATS = 1000

    def __init__(self, w3, contracts, private_key=None):
        self._w3 = w3
        self._core = contracts.get("BarterCore")
        self._pk = private_key
        self._account = None
        if private_key and w3:
            self._account = w3.eth.account.from_key(private_key)

    def _validate_address(self, address: str) -> str:
        if not address or not isinstance(address, str):
            raise InvalidAddressError(f"Invalid address: {address}")
        if not address.startswith("0x") or len(address) != 42:
            raise InvalidAddressError(f"Invalid address format: {address}")
        try:
            return self._w3.to_checksum_address(address)
        except Exception:
            raise InvalidAddressError(f"Invalid address: {address}")

    def _get_sender(self) -> str:
        if self._account:
            return self._account.address
        accounts = self._w3.eth.accounts
        if accounts:
            return accounts[0]
        raise Exception("No account available. Provide a private_key.")

    def propose(self, counterparty: str, payment_hash: str,
                amount_sats: int, category: str = "", description: str = "") -> str:
        """Propose a new trade. Returns trade ID."""
        sender = self._get_sender()
        cp = self._validate_address(counterparty)

        if cp.lower() == sender.lower():
            raise SelfTradeError("Cannot trade with yourself")
        if amount_sats < self.MIN_TRADE_SATS:
            raise InsufficientAmountError(f"Amount {amount_sats} below minimum {self.MIN_TRADE_SATS} sats")
        if len(description) > 200:
            raise ValueError("Description too long (max 200 chars)")

        if self._core is None:
            raise Exception("Contract not connected")

        tx = self._core.functions.proposeTrade(
            cp, bytes.fromhex(payment_hash[2:]) if payment_hash.startswith("0x") else bytes.fromhex(payment_hash),
            amount_sats, category, description
        )

        if self._pk:
            built = tx.build_transaction({
                "from": sender,
                "nonce": self._w3.eth.get_transaction_count(sender),
                "gas": 300000,
            })
            signed = self._w3.eth.account.sign_transaction(built, self._pk)
            tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            receipt = self._w3.eth.wait_for_transaction_receipt(tx_hash)
        else:
            receipt = tx.transact({"from": sender})
            receipt = self._w3.eth.wait_for_transaction_receipt(receipt)

        # Extract tradeId from event logs
        logs = self._core.events.TradeProposed().process_receipt(receipt)
        if logs:
            return "0x" + logs[0]["args"]["tradeId"].hex()
        return receipt["transactionHash"].hex()

    def accept(self, trade_id: str) -> dict:
        """Accept a proposed trade."""
        tid = bytes.fromhex(trade_id[2:]) if trade_id.startswith("0x") else bytes.fromhex(trade_id)
        sender = self._get_sender()
        tx = self._core.functions.acceptTrade(tid)

        if self._pk:
            built = tx.build_transaction({
                "from": sender,
                "nonce": self._w3.eth.get_transaction_count(sender),
                "gas": 200000,
            })
            signed = self._w3.eth.account.sign_transaction(built, self._pk)
            tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))
        else:
            tx_hash = tx.transact({"from": sender})
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))

    def settle(self, trade_id: str, preimage: str) -> dict:
        """Settle a trade with Lightning preimage. Verifies SHA256."""
        tid = bytes.fromhex(trade_id[2:]) if trade_id.startswith("0x") else bytes.fromhex(trade_id)
        pre = bytes.fromhex(preimage[2:]) if preimage.startswith("0x") else bytes.fromhex(preimage)

        # Local verification before submitting
        trade = self.get(trade_id)
        expected_hash = trade.payment_hash
        # The contract uses sha256(abi.encode(preimage))
        # abi.encode for bytes32 is just the 32 bytes padded
        computed = hashlib.sha256(pre.rjust(32, b'\x00')).hexdigest()
        if not expected_hash.lower().endswith(computed.lower()):
            raise PreimageMismatchError("SHA256(preimage) does not match payment_hash")

        sender = self._get_sender()
        tx = self._core.functions.settleTrade(tid, pre)

        if self._pk:
            built = tx.build_transaction({
                "from": sender,
                "nonce": self._w3.eth.get_transaction_count(sender),
                "gas": 400000,
            })
            signed = self._w3.eth.account.sign_transaction(built, self._pk)
            tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))
        else:
            tx_hash = tx.transact({"from": sender})
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))

    def dispute(self, trade_id: str) -> dict:
        """Dispute a trade."""
        tid = bytes.fromhex(trade_id[2:]) if trade_id.startswith("0x") else bytes.fromhex(trade_id)
        sender = self._get_sender()
        tx = self._core.functions.disputeTrade(tid)

        if self._pk:
            built = tx.build_transaction({
                "from": sender,
                "nonce": self._w3.eth.get_transaction_count(sender),
                "gas": 200000,
            })
            signed = self._w3.eth.account.sign_transaction(built, self._pk)
            tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))
        else:
            tx_hash = tx.transact({"from": sender})
            return dict(self._w3.eth.wait_for_transaction_receipt(tx_hash))

    def get(self, trade_id: str) -> Trade:
        """Get trade details by ID."""
        tid = bytes.fromhex(trade_id[2:]) if trade_id.startswith("0x") else bytes.fromhex(trade_id)
        if self._core is None:
            raise TradeNotFoundError(f"Trade {trade_id} not found")
        result = self._core.functions.trades(tid).call()
        if result[6] == 0:  # createdAt == 0
            raise TradeNotFoundError(f"Trade {trade_id} not found")

        status_map = {0: TradeStatus.PROPOSED, 1: TradeStatus.ACCEPTED,
                      2: TradeStatus.SETTLED, 3: TradeStatus.DISPUTED, 4: TradeStatus.EXPIRED}

        return Trade(
            trade_id="0x" + result[0].hex(),
            party_a=result[1],
            party_b=result[2],
            payment_hash="0x" + result[3].hex(),
            amount_sats=result[4],
            status=status_map.get(result[5], TradeStatus.PROPOSED),
            created_at=datetime.fromtimestamp(result[6]),
            accepted_at=datetime.fromtimestamp(result[7]) if result[7] > 0 else None,
            settled_at=datetime.fromtimestamp(result[8]) if result[8] > 0 else None,
            category=result[9],
            description=result[10],
        )

    def list_by_address(self, address: str) -> List[Trade]:
        """Get all trades for an address."""
        addr = self._validate_address(address)
        if self._core is None:
            return []
        trade_ids = self._core.functions.getTradesByAddress(addr).call()
        trades = []
        for tid in trade_ids:
            try:
                trades.append(self.get("0x" + tid.hex()))
            except TradeNotFoundError:
                continue
        return trades
