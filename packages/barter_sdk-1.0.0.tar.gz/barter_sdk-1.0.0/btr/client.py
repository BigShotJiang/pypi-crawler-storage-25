import os
from typing import Optional
from web3 import Web3
from btr.trust import TrustClient
from btr.trade import TradeClient
from btr.credit import CreditClient
from btr.compliance import ComplianceClient
from btr.constants import CONTRACTS, ABIS, DEFAULT_RPC

class BarterClient:
    """Main client for the BTR Proof of Trade Protocol.

    Usage:
        import btr
        client = btr.BarterClient(network="sepolia")
        score = client.trust.get_score("0x...")
        profile = client.trust.get_profile("0x...")
    """

    def __init__(self,
                 rpc_url: Optional[str] = None,
                 network: str = "sepolia",
                 private_key: Optional[str] = None):
        self.network = network

        # Resolve RPC URL
        url = rpc_url or os.environ.get("ALCHEMY_RPC_URL") or DEFAULT_RPC
        self._w3 = Web3(Web3.HTTPProvider(url))

        # Resolve private key
        pk = private_key or os.environ.get("DEPLOYER_PRIVATE_KEY")

        # Load contracts
        addresses = CONTRACTS.get(network, {})
        contracts = {}

        for name in ["BarterCore", "BTRTrust", "BTRCredit"]:
            addr = addresses.get(name)
            abi = ABIS.get(name, [])
            if addr and abi and self._w3.is_connected():
                try:
                    contracts[name] = self._w3.eth.contract(
                        address=self._w3.to_checksum_address(addr),
                        abi=abi
                    )
                except Exception:
                    contracts[name] = None
            else:
                contracts[name] = None

        # Initialize sub-clients
        self.trust = TrustClient(self._w3, contracts)
        self.trade = TradeClient(self._w3, contracts, pk)
        self.credit = CreditClient(self._w3, contracts)
        self.compliance = ComplianceClient(self._w3, contracts)

    @property
    def w3(self) -> Web3:
        """Access the underlying Web3 instance."""
        return self._w3

    @property
    def is_connected(self) -> bool:
        """Check if connected to the network."""
        try:
            return self._w3.is_connected()
        except Exception:
            return False
