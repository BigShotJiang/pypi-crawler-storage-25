from btr.exceptions import InvalidAddressError

class CreditClient:
    def __init__(self, w3, contracts):
        self._w3 = w3
        self._credit = contracts.get("BTRCredit")

    def _validate_address(self, address: str) -> str:
        if not address or not address.startswith("0x") or len(address) != 42:
            raise InvalidAddressError(f"Invalid address: {address}")
        return self._w3.to_checksum_address(address)

    def balance_of(self, address: str) -> int:
        """Get BTR-C balance in wei."""
        addr = self._validate_address(address)
        if self._credit is None:
            return 0
        return self._credit.functions.balanceOf(addr).call()

    def balance_formatted(self, address: str) -> float:
        """Get BTR-C balance in human-readable format."""
        raw = self.balance_of(address)
        return raw / 1e18

    def total_supply(self) -> int:
        """Get total BTR-C supply."""
        if self._credit is None:
            return 0
        return self._credit.functions.totalSupply().call()
