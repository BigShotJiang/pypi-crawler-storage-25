"""
animekai-dl-tmux — AnimeKAI CLI downloader for Termux
"""

import argparse
import sys

from loguru import logger

from .utils import config as cfg


def _setup_logger(verbose: bool):
    logger.remove()
    level = "DEBUG" if verbose else "INFO"
    logger.add(
        sys.stderr,
        level=level,
        format="<level>{level: <8}</level> | {message}",
        colorize=True,
    )


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="animekai",
        description="AnimeKAI downloader for Termux — search, browse, and download anime",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  animekai "one piece"                       # search and download interactively
  animekai --browse                          # browse ALL anime with local search
  animekai --browse --refresh                # force-refresh the anime list cache
  animekai "naruto" --type sub --quality 1080p
  animekai "naruto" --episodes 1-10 --type dub --no-interactive
  animekai "aot" --play                      # stream in mpv instead of downloading
  animekai --config show                     # print current config
  animekai --config edit                     # open config in $EDITOR
  animekai --test-domains                    # check which domains work on your network
        """,
    )

    p.add_argument(
        "query", nargs="?", default="",
        help="Anime title to search (omit to use --browse)",
    )

    # --- Mode flags ---
    p.add_argument(
        "--browse", "-b",
        action="store_true", default=False,
        help="Browse full anime list (loads ~13 000 titles, cached locally for 24 h)",
    )
    p.add_argument(
        "--refresh",
        action="store_true", default=False,
        help="Force-refresh the browse cache (use with --browse)",
    )
    p.add_argument(
        "--config",
        choices=["show", "edit"],
        metavar="{show,edit}",
        default=None,
        help="Config management: 'show' prints the config, 'edit' opens it in $EDITOR",
    )
    p.add_argument(
        "--test-domains",
        dest="test_domains",
        action="store_true", default=False,
        help="Check which AnimeKAI domains are reachable from your network",
    )

    # --- Stream options ---
    p.add_argument(
        "--type", "-t",
        dest="stream_type",
        choices=["sub", "dub", "softsub"],
        default=None,
        help="Stream type: sub, dub, softsub (default: ask / config default)",
    )
    p.add_argument(
        "--quality", "-q",
        default=None,
        help="Quality preference: best, 1080p, 720p, 480p (default: best)",
    )
    p.add_argument(
        "--episodes", "-e",
        dest="episode_range",
        default=None,
        help="Episode range: '1', '1-5', '1,3,5' (default: interactive selection)",
    )
    p.add_argument(
        "--server", "-s",
        dest="preferred_server",
        default=None,
        help="Preferred server name, e.g. 'Server 1' (default: interactive pick)",
    )
    p.add_argument(
        "--auto-server",
        dest="auto_server",
        type=int,
        default=None,
        help="Auto-select server by index in --no-interactive mode (1-based, default: 1)",
    )
    p.add_argument(
        "--server-retries",
        dest="server_retries",
        type=int,
        default=None,
        help="Max servers to try before giving up on an episode (default: from config, 3)",
    )

    # --- Output ---
    p.add_argument(
        "--output", "-o",
        dest="download_dir",
        default=None,
        help="Download directory (default: from config or ~/Downloads/Anime)",
    )
    p.add_argument(
        "--play",
        action="store_true", default=False,
        help="Stream in mpv instead of downloading",
    )
    p.add_argument(
        "--player",
        default=None,
        help="Media player for --play mode (default: from config, mpv)",
    )

    # --- Network ---
    p.add_argument(
        "--url",
        dest="base_url",
        default=None,
        help="Override AnimeKAI base URL (default: auto-detect working domain)",
    )
    p.add_argument(
        "--threads",
        type=int,
        default=None,
        help="Parallel threads for --browse (default: from config, 4)",
    )

    # --- Behaviour ---
    p.add_argument(
        "--no-interactive",
        dest="non_interactive",
        action="store_true", default=False,
        help="Skip all prompts — auto-select first/best option everywhere",
    )
    p.add_argument(
        "--verbose", "-v",
        action="store_true", default=False,
        help="Enable debug logging",
    )

    return p


def _resolve_base_url(explicit_url):
    """
    Return a working AnimeKAI base URL.
    Priority: --url flag > auto-detect (probes config URL first, then alternates).
    Auto-detection saves the working domain to config for instant startup next time.
    """
    if explicit_url:
        return explicit_url.rstrip("/")
    from .utils.network import get_working_domain
    return get_working_domain()


def _resolve_opts(args):
    """Merge CLI flags with config defaults."""
    return dict(
        download_dir=args.download_dir or cfg.get_download_dir(),
        stream_type=args.stream_type or cfg.get_stream_type(),
        quality=None if (args.quality or "best").lower() == "best" else args.quality,
        player=args.player or cfg.get_player(),
        auto_server=args.auto_server if args.auto_server is not None else cfg.get_auto_server(),
        server_retries=args.server_retries if args.server_retries is not None else cfg.get_server_retries(),
        threads=args.threads if args.threads is not None else cfg.get_threads(),
    )


def _run(args, default_browse: bool = False):
    verbose = args.verbose or cfg.get("behavior", "verbose", fallback="false").lower() == "true"
    _setup_logger(verbose)

    # --- Config subcommands (no network needed) ---
    if args.config == "show":
        cfg.cmd_show_config()
        return
    if args.config == "edit":
        cfg.cmd_edit_config()
        return

    # --- Domain test (no download) ---
    if args.test_domains:
        from .utils.network import cmd_test_domains
        cmd_test_domains()
        return

    # --- Resolve working domain ---
    try:
        base_url = _resolve_base_url(args.base_url)
    except RuntimeError as e:
        logger.error(str(e))
        sys.exit(1)

    opts = _resolve_opts(args)
    use_browse = args.browse or (default_browse and not args.query)

    from .cli.commands import cmd_search, cmd_browse

    try:
        if use_browse:
            cmd_browse(
                base_url=base_url,
                download_dir=opts["download_dir"],
                stream_type=opts["stream_type"],
                preferred_server=args.preferred_server,
                quality=opts["quality"],
                play=args.play,
                player=opts["player"],
                auto_server=opts["auto_server"],
                server_retries=opts["server_retries"],
                episode_range=args.episode_range,
                non_interactive=args.non_interactive,
                threads=opts["threads"],
                force_refresh=args.refresh,
            )
        elif args.query:
            cmd_search(
                query=args.query,
                base_url=base_url,
                download_dir=opts["download_dir"],
                stream_type=opts["stream_type"],
                preferred_server=args.preferred_server,
                quality=opts["quality"],
                play=args.play,
                player=opts["player"],
                auto_server=opts["auto_server"],
                server_retries=opts["server_retries"],
                episode_range=args.episode_range,
                non_interactive=args.non_interactive,
            )
        else:
            build_parser().print_help()
            sys.exit(0)

    except KeyboardInterrupt:
        logger.info("Interrupted.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        if verbose:
            raise
        sys.exit(1)


def main():
    """Entry point for `animekai` and `animekai-dl` commands."""
    parser = build_parser()
    args = parser.parse_args()
    _run(args, default_browse=False)


def kai_main():
    """
    Entry point for the `kai` command.
    Identical to `animekai` but defaults to browse mode when called with no
    query — so just typing `kai` launches the full anime list browser,
    the same way `dl` worked for animepahe-dl-tmux.
    """
    parser = build_parser()
    args = parser.parse_args()
    _run(args, default_browse=True)


if __name__ == "__main__":
    main()
