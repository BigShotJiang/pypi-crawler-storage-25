"""
Domain auto-detection for AnimeKAI.

The site runs on multiple domains. ISPs sometimes block specific TLDs.
This module tries all known domains concurrently and returns the first
one that responds, then saves it to config so the next run is instant.
"""

import concurrent.futures
import configparser
from loguru import logger

from .constants import BASE_URL, ALT_URLS

# All known domains in priority order
ALL_DOMAINS = [BASE_URL] + ALT_URLS


def _probe(url: str, timeout: int = 6):
    """Return url if it responds with HTTP 200, else None."""
    try:
        import requests
        r = requests.get(
            f"{url}/",
            timeout=timeout,
            allow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0"},
        )
        if r.status_code == 200:
            return url
    except Exception:
        pass
    return None


def find_working_domain(save_to_config: bool = True, timeout: int = 6) -> str:
    """
    Try all known AnimeKAI domains concurrently.
    Returns the first one that responds.
    Saves the winner to config so next run skips this check.
    """
    logger.info("Checking which AnimeKAI domain is reachable...")

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ALL_DOMAINS)) as ex:
        futures = {ex.submit(_probe, url, timeout): url for url in ALL_DOMAINS}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                # Cancel the rest
                for f in futures:
                    f.cancel()
                logger.info(f"Using domain: {result}")
                if save_to_config:
                    _save_domain(result)
                return result

    raise RuntimeError(
        "No AnimeKAI domain is reachable from your network.\n"
        "Check your internet connection or try a VPN.\n"
        f"Domains tried: {', '.join(ALL_DOMAINS)}"
    )


def get_working_domain() -> str:
    """
    Return a working domain. Priority:
      1. Config file value (if it still responds)
      2. Auto-detect from all known domains
    """
    from .config import get_base_url
    configured = get_base_url()

    # Quick probe of the configured URL first (low timeout to stay fast)
    result = _probe(configured, timeout=5)
    if result:
        return configured

    # Configured domain is down — auto-detect
    logger.warning(f"Configured domain '{configured}' is unreachable. Trying alternatives...")
    return find_working_domain(save_to_config=True)


def _save_domain(url: str):
    """Persist the working domain to config.ini."""
    from .config import CONFIG_FILE, CONFIG_DIR, _ensure_config
    try:
        cfg = _ensure_config()
        cfg.set("site", "base_url", url)
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            cfg.write(f)
        logger.debug(f"Saved working domain to config: {url}")
    except Exception as e:
        logger.debug(f"Could not save domain to config: {e}")


def cmd_test_domains():
    """Print connectivity status for all known domains."""
    from rich.console import Console
    from rich.table import Table
    import requests

    console = Console()
    table = Table(title="AnimeKAI Domain Status", show_header=True, header_style="bold cyan")
    table.add_column("Domain", style="bold")
    table.add_column("Status")
    table.add_column("Final URL")

    def check(url):
        try:
            r = requests.get(f"{url}/", timeout=8, allow_redirects=True,
                             headers={"User-Agent": "Mozilla/5.0"})
            return url, "✓ reachable", r.url
        except Exception as e:
            return url, f"✗ {str(e)[:50]}", ""

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ALL_DOMAINS)) as ex:
        results = list(ex.map(check, ALL_DOMAINS))

    for url, status, final in results:
        color = "green" if "✓" in status else "red"
        table.add_row(url, f"[{color}]{status}[/{color}]", final)

    console.print(table)
    console.print("\n[dim]Set the working domain in your config:[/dim]  animekai --config edit")
