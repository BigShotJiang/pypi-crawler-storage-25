"""
Browse all anime on AnimeKAI site.
Fetches all az-list pages with threading and caches results locally.

Card structure on az-list:
  div.aitem-wrapper > div.aitem > div.inner
    > a.poster[href="/watch/..."]   ← path is here
    > a.title[title="..."]          ← anime title is here (sibling, NOT inside poster)
"""

import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Dict, Optional

import requests
from bs4 import BeautifulSoup
from loguru import logger
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from ..utils.constants import BASE_URL, DEFAULT_USER_AGENT
from ..utils.config import CACHE_DIR

CACHE_FILE = CACHE_DIR / "anime-list.json"
CACHE_TTL_HOURS = 24

console = Console()


def _cache_is_fresh() -> bool:
    if not CACHE_FILE.exists():
        return False
    age_hours = (time.time() - CACHE_FILE.stat().st_mtime) / 3600
    return age_hours < CACHE_TTL_HOURS


def _load_cache() -> Optional[List[Dict]]:
    try:
        data = json.loads(CACHE_FILE.read_text())
        if isinstance(data, list) and data:
            return data
    except Exception:
        pass
    return None


def _save_cache(anime_list: List[Dict]):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(anime_list, ensure_ascii=False))


def _get_last_page(session: requests.Session, base_url: str = BASE_URL) -> int:
    """
    Find the total number of az-list pages.
    Uses raw regex on the HTML so it catches all page= occurrences reliably,
    including next/last buttons that may not have standard <a> tags.
    """
    try:
        r = session.get(f"{base_url}/az-list", timeout=20)
        # Regex on raw HTML — more reliable than CSS selectors for pagination
        pages = [int(m) for m in re.findall(r"az-list\?page=(\d+)", r.text)]
        return max(pages) if pages else 1
    except Exception as e:
        logger.debug(f"Could not determine last page: {e}")
        return 1


def _fetch_page(session: requests.Session, page: int, base_url: str) -> List[Dict]:
    """
    Fetch a single az-list page and extract anime titles + paths.

    The title is in <a class="title"> which is a SIBLING of <a class="poster">,
    both inside div.aitem. We must select the card container (div.aitem) and
    pull both elements from it — NOT try to get text from the poster link.
    """
    url = f"{base_url}/az-list?page={page}"
    try:
        r = session.get(url, timeout=20)
        soup = BeautifulSoup(r.text, "html.parser")
        results = []

        for card in soup.select("div.aitem"):
            poster = card.select_one("a.poster[href*='/watch/']")
            title_tag = card.select_one("a.title")

            if not poster or not title_tag:
                continue

            href = poster.get("href", "").strip()
            # Title: try text first, then title attribute, then data-jp
            title = (
                title_tag.get_text(strip=True)
                or title_tag.get("title", "").strip()
                or title_tag.get("data-jp", "").strip()
            )

            if href and title:
                # Normalise path to always start with /watch/
                if not href.startswith("/"):
                    href = "/" + href
                results.append({"title": title, "path": href})

        return results
    except Exception as e:
        logger.debug(f"Page {page} failed: {e}")
        return []


def fetch_all_anime(
    base_url: str = BASE_URL,
    threads: int = 4,
    force_refresh: bool = False,
) -> List[Dict]:
    """
    Fetch the complete anime list from AnimeKAI (~13 500 titles).
    Uses a local cache with a 24 h TTL — first run takes ~30 s with threading,
    subsequent runs are instant.
    """
    if not force_refresh and _cache_is_fresh():
        cached = _load_cache()
        if cached:
            logger.debug(f"Using cached list ({len(cached)} titles)")
            return cached

    session = requests.Session()
    session.headers.update({
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": base_url,
    })

    console.print("[dim]Fetching anime list from AnimeKAI...[/dim]")
    last_page = _get_last_page(session, base_url)
    console.print(
        f"[dim]Found {last_page} pages (~{last_page * 30} titles). "
        f"Fetching with {threads} threads...[/dim]"
    )

    all_anime: List[Dict] = []
    seen: set = set()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("({task.completed}/{task.total})"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Loading anime list", total=last_page)

        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = {
                executor.submit(_fetch_page, session, page, base_url): page
                for page in range(1, last_page + 1)
            }
            for future in as_completed(futures):
                for entry in future.result():
                    if entry["path"] not in seen:
                        seen.add(entry["path"])
                        all_anime.append(entry)
                progress.advance(task)

    all_anime.sort(key=lambda x: x["title"].lower())
    _save_cache(all_anime)
    console.print(
        f"[bold green]Loaded {len(all_anime)} titles[/bold green] — "
        f"cached to [dim]{CACHE_FILE}[/dim]"
    )
    return all_anime


def get_cache_info() -> dict:
    if not CACHE_FILE.exists():
        return {"exists": False}
    age_hours = (time.time() - CACHE_FILE.stat().st_mtime) / 3600
    data = _load_cache()
    return {
        "exists": True,
        "path": str(CACHE_FILE),
        "titles": len(data) if data else 0,
        "age_hours": round(age_hours, 1),
        "fresh": age_hours < CACHE_TTL_HOURS,
    }
