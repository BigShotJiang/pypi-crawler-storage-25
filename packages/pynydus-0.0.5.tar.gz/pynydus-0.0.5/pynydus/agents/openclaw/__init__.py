"""OpenClaw agent connector."""
