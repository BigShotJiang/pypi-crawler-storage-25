"""Proxmox cluster endpoints and cluster response schemas."""

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel

from proxbox_api.enum.proxmox import *
from proxbox_api.schemas.proxmox import *
from proxbox_api.services.proxmox_helpers import (
    get_cluster_resources as get_typed_cluster_resources,
)
from proxbox_api.services.proxmox_helpers import (
    get_cluster_status as get_typed_cluster_status,
)
from proxbox_api.session.proxmox import ProxmoxSession, ProxmoxSessionsDep

router = APIRouter()


class BaseClusterStatusSchema(BaseModel):
    id: str
    name: str
    type: str


class ClusterNodeStatusSchema(BaseClusterStatusSchema):
    ip: str
    level: str | None = None
    local: int
    nodeid: int
    online: int


class ClusterStatusSchema(BaseClusterStatusSchema):
    nodes: int
    quorate: int
    version: int
    mode: str
    node_list: list[ClusterNodeStatusSchema] | None = None


ClusterStatusSchemaList = list[ClusterStatusSchema]


# /proxmox/cluster/ API Endpoints
@router.get("/status", response_model=ClusterStatusSchemaList)
async def cluster_status(pxs: ProxmoxSessionsDep) -> ClusterStatusSchemaList:
    """
    ### Retrieve the status of clusters from multiple Proxmox sessions.

    **Args:**
    - **pxs (`ProxmoxSessionsDep`):** A list of Proxmox session dependencies.

    **Returns:**
    - **list (`ClusterStatusSchemaList`):** A list of dictionaries containing the status of each cluster.

    ### Example Response:
    ```json
    [
        'id': 'cluster',
        'name': 'Cluster-Name',
        'type': 'cluster',
        'mode': 'standalone',
        'nodes:' 2,
        'quorate': 1,
        'version': 1,
        'node_list': [
            {
                'id': 'node/node-name',
                'name': 'node-name',
                'type': 'node',
                'ip': '10.0.0.1',
                'level: '',
                'local': 1,
                'nodeid': 1,
                'online': 1
            },
            {
                'id': 'node/node-name2',
                'name': 'node-name2',
                'type': 'node',
                'ip': '10.0.0.2',
                'level: '',
                'local': 1,
                'nodeid': 1,
                'online': 1
            }
        ]
    ]
    ```
    """

    async def parse_cluster_status(
        proxmox_object: ProxmoxSession, data: list
    ) -> ClusterStatusSchema:
        node_list = []
        cluster: ClusterStatusSchema = None

        for item in data:
            item_data = item.model_dump(mode="python", by_alias=True, exclude_none=True)
            item_data["mode"] = proxmox_object.mode
            if item_data.get("type") == "cluster":
                cluster = ClusterStatusSchema(**item_data)

            if item_data.get("type") == "node":
                node_list.append(ClusterNodeStatusSchema(**item_data))

        if cluster:
            cluster.node_list = node_list
            return cluster

    return ClusterStatusSchemaList(
        [
            await parse_cluster_status(proxmox_object=px, data=get_typed_cluster_status(px))
            for px in pxs
        ]
    )


ClusterStatusDep = Annotated[ClusterStatusSchemaList, Depends(cluster_status)]

# /proxmox/cluster/ API Endpoints


@router.get("/resources", response_model=ClusterResourcesList)
async def cluster_resources(
    pxs: ProxmoxSessionsDep,
    type: Annotated[
        ClusterResourcesType,
        Query(
            title="Proxmox Resource Type",
            description="Type of Proxmox resource to return (ex. 'vm' return QEMU Virtual Machines).",
        ),
    ] = None,
):
    """
    ### Fetches Proxmox cluster resources.

    This asynchronous function retrieves resources from a Proxmox cluster. It supports filtering by resource type.

    **Args:**
    - **pxs (`ProxmoxSessionsDep`):** Dependency injection for Proxmox sessions.
    - **type (`Annotated[ClusterResourcesType, Query]`):** Optional. The type of Proxmox resource to return. If not provided, all resources are returned.

    **Returns:**
    - **list:** A list of dictionaries containing the Proxmox cluster resources.
    """

    resource_type = type if isinstance(type, str) else None
    json_response = []

    for px in pxs:
        json_response.append(
            {
                px.name: [
                    resource.model_dump(mode="python", by_alias=True, exclude_none=True)
                    for resource in get_typed_cluster_resources(px, resource_type=resource_type)
                ]
            }
        )

    return json_response


ClusterResourcesDep = Annotated[ClusterResourcesList, Depends(cluster_resources)]


# Backup routines endpoint
@router.get("/backup", response_model=list)
async def cluster_backup(pxs: ProxmoxSessionsDep):
    """
    ### Retrieve backup job configurations from multiple Proxmox sessions.

    **Args:**
    - **pxs (`ProxmoxSessionsDep`):** A list of Proxmox session dependencies.

    **Returns:**
    - **list:** A list of backup job configurations from each cluster.
    """
    results = []

    for px in pxs:
        try:
            backup_jobs = px.session.cluster.backup.get()
            for job in backup_jobs:
                job["cluster_name"] = px.name
                results.append(job)
        except Exception as error:
            logger.exception("Error fetching backup jobs for Proxmox cluster %s", px.name)
            results.append({"cluster_name": px.name, "error": str(error)})

    return results
