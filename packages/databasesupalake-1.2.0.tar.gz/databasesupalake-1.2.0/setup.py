"""
setup.py for dbhandler — Python database handling package.
"""

from setuptools import setup, find_packages
import os

# Read the long description from README.md (if present)
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, "README.md"), encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = (
        "dbhandler — A lightweight Python package for managing SQLite, "
        "PostgreSQL, and MySQL databases."
    )

setup(
    # -----------------------------------------------------------------------
    # Package metadata
    # -----------------------------------------------------------------------
    name="databasesupalake",
    version="1.2.0",
    author="dbhandler contributors",
    author_email="you@example.com",
    description="A lightweight Python package for managing SQLite, PostgreSQL, and MySQL databases.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/dbhandler",
    license="MIT",

    # -----------------------------------------------------------------------
    # Package discovery
    # -----------------------------------------------------------------------
    packages=find_packages(exclude=["tests", "tests.*"]),

    # -----------------------------------------------------------------------
    # Python version requirement
    # -----------------------------------------------------------------------
    python_requires=">=3.8",

    # -----------------------------------------------------------------------
    # Core dependencies
    # SQLite support is built into Python's standard library — no extra dep.
    # PostgreSQL and MySQL drivers are listed as optional extras.
    # -----------------------------------------------------------------------
    install_requires=[
        "api-analysis",
    ],

    extras_require={
        # Install with: pip install dbhandler[postgresql]
        "postgresql": ["psycopg2-binary>=2.9"],

        # Install with: pip install dbhandler[mysql]
        "mysql": ["mysql-connector-python>=8.0"],

        # Install with: pip install dbhandler[all]
        "all": [
            "psycopg2-binary>=2.9",
            "mysql-connector-python>=8.0",
        ],

        # Development / testing extras
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black",
            "isort",
            "mypy",
        ],
    },

    # -----------------------------------------------------------------------
    # Entry points (optional CLI)
    # -----------------------------------------------------------------------
    entry_points={
        "console_scripts": [
            # Uncomment when a CLI module is added:
            # "dbhandler=dbhandler.cli:main",
        ],
    },

    # -----------------------------------------------------------------------
    # Package classifiers (used by PyPI)
    # -----------------------------------------------------------------------
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Database",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],

    # -----------------------------------------------------------------------
    # Additional files to include in the source distribution
    # -----------------------------------------------------------------------
    include_package_data=True,
    zip_safe=False,
)
