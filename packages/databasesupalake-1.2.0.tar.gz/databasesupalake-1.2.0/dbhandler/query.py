"""
dbhandler.query - Fluent QueryBuilder for constructing SQL statements.
"""

from typing import Any, Dict, List, Optional, Tuple, Union


class QueryBuilder:
    """
    Fluent SQL query builder.

    Example:
        qb = QueryBuilder("users")
        sql, params = (
            qb.select("id", "name", "email")
              .where("age > ?", 18)
              .where("active = ?", 1)
              .order_by("name ASC")
              .limit(10)
              .offset(0)
              .build()
        )
        rows = db.fetchall(sql, params)

    INSERT example:
        sql, params = QueryBuilder("users").insert(name="Alice", age=30).build()
        db.execute(sql, params)

    UPDATE example:
        sql, params = (
            QueryBuilder("users")
            .update(name="Alice Smith")
            .where("id = ?", 1)
            .build()
        )
        db.execute(sql, params)

    DELETE example:
        sql, params = QueryBuilder("users").delete().where("id = ?", 5).build()
        db.execute(sql, params)
    """

    def __init__(self, table: str):
        self._table = table
        self._operation: Optional[str] = None  # SELECT | INSERT | UPDATE | DELETE
        self._columns: List[str] = []
        self._where_clauses: List[str] = []
        self._where_params: List[Any] = []
        self._order: Optional[str] = None
        self._limit_val: Optional[int] = None
        self._offset_val: Optional[int] = None
        self._data: Dict[str, Any] = {}
        self._join_clauses: List[str] = []

    # ------------------------------------------------------------------
    # Operation starters
    # ------------------------------------------------------------------

    def select(self, *columns: str) -> "QueryBuilder":
        """Set to SELECT mode. Pass column names or use default '*'."""
        self._operation = "SELECT"
        self._columns = list(columns) if columns else ["*"]
        return self

    def insert(self, **data: Any) -> "QueryBuilder":
        """Set to INSERT mode with the given column=value pairs."""
        self._operation = "INSERT"
        self._data = data
        return self

    def update(self, **data: Any) -> "QueryBuilder":
        """Set to UPDATE mode with the given column=value pairs."""
        self._operation = "UPDATE"
        self._data = data
        return self

    def delete(self) -> "QueryBuilder":
        """Set to DELETE mode."""
        self._operation = "DELETE"
        return self

    # ------------------------------------------------------------------
    # Clauses
    # ------------------------------------------------------------------

    def where(self, clause: str, *params: Any) -> "QueryBuilder":
        """
        Add a WHERE condition (ANDed with previous conditions).

        Example:
            .where("age > ?", 18)
            .where("name = ?", "Alice")
        """
        self._where_clauses.append(clause)
        self._where_params.extend(params)
        return self

    def join(self, join_clause: str) -> "QueryBuilder":
        """
        Add a raw JOIN clause.

        Example:
            .join("INNER JOIN orders ON orders.user_id = users.id")
        """
        self._join_clauses.append(join_clause)
        return self

    def order_by(self, clause: str) -> "QueryBuilder":
        """
        Set the ORDER BY clause.

        Example:
            .order_by("created_at DESC")
        """
        self._order = clause
        return self

    def limit(self, n: int) -> "QueryBuilder":
        """Set the LIMIT clause."""
        self._limit_val = int(n)
        return self

    def offset(self, n: int) -> "QueryBuilder":
        """Set the OFFSET clause."""
        self._offset_val = int(n)
        return self

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self, placeholder: str = "?") -> Tuple[str, tuple]:
        """
        Compile the query into a (sql, params) tuple.

        Args:
            placeholder: The parameter placeholder style ('?' for SQLite,
                         '%s' for PostgreSQL/MySQL).

        Returns:
            A (sql_string, params_tuple) pair ready for cursor.execute().
        """
        if self._operation is None:
            raise ValueError(
                "No operation set. Call .select(), .insert(), .update(), or .delete() first."
            )

        if self._operation == "SELECT":
            return self._build_select(placeholder)
        if self._operation == "INSERT":
            return self._build_insert(placeholder)
        if self._operation == "UPDATE":
            return self._build_update(placeholder)
        if self._operation == "DELETE":
            return self._build_delete(placeholder)

        raise ValueError(f"Unknown operation: {self._operation}")

    # ------------------------------------------------------------------
    # Internal builders
    # ------------------------------------------------------------------

    def _ph(self, placeholder: str, n: int = 1) -> List[str]:
        return [placeholder] * n

    def _where_sql(self, placeholder: str) -> Tuple[str, list]:
        if not self._where_clauses:
            return "", []
        # Replace '?' with the target placeholder
        clauses = [c.replace("?", placeholder) for c in self._where_clauses]
        return " WHERE " + " AND ".join(clauses), list(self._where_params)

    def _build_select(self, ph: str) -> Tuple[str, tuple]:
        cols = ", ".join(self._columns)
        sql = f"SELECT {cols} FROM {self._table}"
        for j in self._join_clauses:
            sql += f" {j}"
        where_sql, where_params = self._where_sql(ph)
        sql += where_sql
        if self._order:
            sql += f" ORDER BY {self._order}"
        if self._limit_val is not None:
            sql += f" LIMIT {self._limit_val}"
        if self._offset_val is not None:
            sql += f" OFFSET {self._offset_val}"
        return sql, tuple(where_params)

    def _build_insert(self, ph: str) -> Tuple[str, tuple]:
        if not self._data:
            raise ValueError("No data provided for INSERT.")
        cols = ", ".join(self._data.keys())
        placeholders = ", ".join([ph] * len(self._data))
        sql = f"INSERT INTO {self._table} ({cols}) VALUES ({placeholders})"
        return sql, tuple(self._data.values())

    def _build_update(self, ph: str) -> Tuple[str, tuple]:
        if not self._data:
            raise ValueError("No data provided for UPDATE.")
        set_clause = ", ".join(f"{col} = {ph}" for col in self._data.keys())
        sql = f"UPDATE {self._table} SET {set_clause}"
        where_sql, where_params = self._where_sql(ph)
        sql += where_sql
        return sql, tuple(self._data.values()) + tuple(where_params)

    def _build_delete(self, ph: str) -> Tuple[str, tuple]:
        sql = f"DELETE FROM {self._table}"
        where_sql, where_params = self._where_sql(ph)
        sql += where_sql
        return sql, tuple(where_params)

    def __repr__(self) -> str:
        try:
            sql, params = self.build()
            return f"<QueryBuilder sql={sql!r} params={params!r}>"
        except ValueError:
            return f"<QueryBuilder table={self._table!r} op={self._operation!r}>"
