"""
dbhandler.core - Core DBHandler class for managing database connections.
Supports SQLite, PostgreSQL (via psycopg2), and MySQL (via mysql-connector-python).
"""

import sqlite3
import logging
from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Tuple, Union

from .exceptions import ConnectionError, QueryError

logger = logging.getLogger(__name__)


class DBHandler:
    """
    A unified interface for interacting with SQLite, PostgreSQL, and MySQL databases.

    Usage (SQLite):
        db = DBHandler("sqlite", database="mydb.sqlite3")
        db.connect()
        db.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)")
        db.disconnect()

    Usage (PostgreSQL):
        db = DBHandler("postgresql", host="localhost", port=5432,
                       database="mydb", user="admin", password="secret")
        db.connect()

    Usage (MySQL):
        db = DBHandler("mysql", host="localhost", port=3306,
                       database="mydb", user="admin", password="secret")
        db.connect()

    Context manager support:
        with DBHandler("sqlite", database=":memory:") as db:
            db.execute("SELECT 1")
    """

    SUPPORTED_BACKENDS = ("sqlite", "postgresql", "mysql")

    def __init__(
        self,
        backend: str,
        *,
        database: str = ":memory:",
        host: str = "localhost",
        port: Optional[int] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        **kwargs: Any,
    ):
        """
        Initialize the DBHandler.

        Args:
            backend:    One of 'sqlite', 'postgresql', or 'mysql'.
            database:   Database name / file path.
            host:       Hostname (PostgreSQL / MySQL only).
            port:       Port number (defaults: PostgreSQL=5432, MySQL=3306).
            user:       Username (PostgreSQL / MySQL only).
            password:   Password (PostgreSQL / MySQL only).
            **kwargs:   Additional driver-specific keyword arguments.
        """
        backend = backend.lower()
        if backend not in self.SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unsupported backend '{backend}'. "
                f"Choose from: {', '.join(self.SUPPORTED_BACKENDS)}"
            )

        self.backend = backend
        self.database = database
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.extra = kwargs

        self._conn = None
        self._cursor = None

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Open the database connection."""
        try:
            if self.backend == "sqlite":
                self._conn = sqlite3.connect(self.database)
                self._conn.row_factory = sqlite3.Row

            elif self.backend == "postgresql":
                try:
                    import psycopg2
                    import psycopg2.extras
                except ImportError:
                    raise ConnectionError(
                        "psycopg2 is required for PostgreSQL support. "
                        "Install it with: pip install psycopg2-binary"
                    )
                self._conn = psycopg2.connect(
                    host=self.host,
                    port=self.port or 5432,
                    dbname=self.database,
                    user=self.user,
                    password=self.password,
                    **self.extra,
                )
                self._conn.autocommit = False

            elif self.backend == "mysql":
                try:
                    import mysql.connector
                except ImportError:
                    raise ConnectionError(
                        "mysql-connector-python is required for MySQL support. "
                        "Install it with: pip install mysql-connector-python"
                    )
                self._conn = mysql.connector.connect(
                    host=self.host,
                    port=self.port or 3306,
                    database=self.database,
                    user=self.user,
                    password=self.password,
                    **self.extra,
                )

            self._cursor = self._conn.cursor()
            logger.info("Connected to %s database '%s'.", self.backend, self.database)

        except Exception as exc:
            raise ConnectionError(f"Failed to connect: {exc}") from exc

    def disconnect(self) -> None:
        """Close the database connection."""
        if self._cursor:
            self._cursor.close()
            self._cursor = None
        if self._conn:
            self._conn.close()
            self._conn = None
            logger.info("Disconnected from %s database '%s'.", self.backend, self.database)

    def is_connected(self) -> bool:
        """Return True if the connection is active."""
        return self._conn is not None

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "DBHandler":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.commit()
        else:
            self.rollback()
        self.disconnect()

    # ------------------------------------------------------------------
    # Transaction helpers
    # ------------------------------------------------------------------

    def commit(self) -> None:
        """Commit the current transaction."""
        self._require_connection()
        self._conn.commit()

    def rollback(self) -> None:
        """Roll back the current transaction."""
        self._require_connection()
        self._conn.rollback()

    @contextmanager
    def transaction(self):
        """
        Context manager for explicit transactions.

        Example:
            with db.transaction():
                db.execute("INSERT INTO users (name) VALUES (?)", ("Alice",))
                db.execute("INSERT INTO users (name) VALUES (?)", ("Bob",))
        """
        self._require_connection()
        try:
            yield self
            self.commit()
        except Exception:
            self.rollback()
            raise

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    def execute(
        self,
        sql: str,
        params: Optional[Union[Tuple, Dict]] = None,
    ) -> Any:
        """
        Execute a single SQL statement.

        Args:
            sql:    The SQL statement to run.
            params: Optional bind parameters (tuple or dict).

        Returns:
            The cursor object after execution.
        """
        self._require_connection()
        try:
            if params:
                self._cursor.execute(sql, params)
            else:
                self._cursor.execute(sql)
            logger.debug("Executed: %s | params=%s", sql.strip(), params)
            return self._cursor
        except Exception as exc:
            raise QueryError(f"Query failed: {exc}\nSQL: {sql}") from exc

    def executemany(
        self,
        sql: str,
        params_seq: List[Union[Tuple, Dict]],
    ) -> Any:
        """
        Execute a statement against a sequence of parameter sets.

        Args:
            sql:        The SQL statement template.
            params_seq: A list of tuples or dicts to bind.
        """
        self._require_connection()
        try:
            self._cursor.executemany(sql, params_seq)
            logger.debug("Executemany: %s | %d rows", sql.strip(), len(params_seq))
            return self._cursor
        except Exception as exc:
            raise QueryError(f"Executemany failed: {exc}\nSQL: {sql}") from exc

    # ------------------------------------------------------------------
    # Fetch helpers
    # ------------------------------------------------------------------

    def fetchone(
        self,
        sql: str,
        params: Optional[Union[Tuple, Dict]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Execute *sql* and return the first row as a dict, or None."""
        cursor = self.execute(sql, params)
        row = cursor.fetchone()
        return self._row_to_dict(row) if row else None

    def fetchall(
        self,
        sql: str,
        params: Optional[Union[Tuple, Dict]] = None,
    ) -> List[Dict[str, Any]]:
        """Execute *sql* and return all rows as a list of dicts."""
        cursor = self.execute(sql, params)
        rows = cursor.fetchall()
        return [self._row_to_dict(r) for r in rows]

    def fetchmany(
        self,
        sql: str,
        size: int = 100,
        params: Optional[Union[Tuple, Dict]] = None,
    ) -> List[Dict[str, Any]]:
        """Execute *sql* and return up to *size* rows as a list of dicts."""
        cursor = self.execute(sql, params)
        rows = cursor.fetchmany(size)
        return [self._row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # CRUD shortcuts
    # ------------------------------------------------------------------

    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """
        Insert a single row and return the last inserted row id.

        Args:
            table: Target table name.
            data:  Column → value mapping.

        Returns:
            The last inserted row ID.
        """
        cols = ", ".join(data.keys())
        placeholders = self._placeholders(len(data))
        sql = f"INSERT INTO {table} ({cols}) VALUES ({placeholders})"
        self.execute(sql, tuple(data.values()))
        return self._cursor.lastrowid

    def insert_many(self, table: str, rows: List[Dict[str, Any]]) -> None:
        """Insert multiple rows efficiently using executemany."""
        if not rows:
            return
        cols = ", ".join(rows[0].keys())
        placeholders = self._placeholders(len(rows[0]))
        sql = f"INSERT INTO {table} ({cols}) VALUES ({placeholders})"
        self.executemany(sql, [tuple(r.values()) for r in rows])

    def select(
        self,
        table: str,
        *,
        columns: Union[str, List[str]] = "*",
        where: Optional[str] = None,
        params: Optional[Union[Tuple, Dict]] = None,
        order_by: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Build and execute a SELECT statement.

        Args:
            table:    Source table name.
            columns:  Column(s) to select (default '*').
            where:    Optional WHERE clause (e.g. "age > ?").
            params:   Bind parameters for the WHERE clause.
            order_by: Optional ORDER BY clause.
            limit:    Row limit.
            offset:   Row offset.

        Returns:
            A list of row dicts.
        """
        if isinstance(columns, list):
            columns = ", ".join(columns)

        sql = f"SELECT {columns} FROM {table}"
        if where:
            sql += f" WHERE {where}"
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        if offset is not None:
            sql += f" OFFSET {int(offset)}"

        return self.fetchall(sql, params)

    def update(
        self,
        table: str,
        data: Dict[str, Any],
        where: str,
        where_params: Optional[Union[Tuple, Dict]] = None,
    ) -> int:
        """
        Update rows in *table* and return the number of affected rows.

        Args:
            table:        Target table name.
            data:         Column → new-value mapping.
            where:        WHERE clause (required to prevent accidental mass updates).
            where_params: Bind parameters for the WHERE clause.
        """
        set_clause = ", ".join(
            f"{col} = {self._single_placeholder()}" for col in data.keys()
        )
        sql = f"UPDATE {table} SET {set_clause} WHERE {where}"
        params: tuple = tuple(data.values())
        if where_params:
            params += tuple(where_params) if not isinstance(where_params, dict) else ()
        self.execute(sql, params)
        return self._cursor.rowcount

    def delete(
        self,
        table: str,
        where: str,
        params: Optional[Union[Tuple, Dict]] = None,
    ) -> int:
        """
        Delete rows from *table* and return the number of affected rows.

        Args:
            table:  Target table name.
            where:  WHERE clause (required).
            params: Bind parameters.
        """
        sql = f"DELETE FROM {table} WHERE {where}"
        self.execute(sql, params)
        return self._cursor.rowcount

    # ------------------------------------------------------------------
    # Schema helpers
    # ------------------------------------------------------------------

    def table_exists(self, table: str) -> bool:
        """Return True if *table* exists in the database."""
        if self.backend == "sqlite":
            row = self.fetchone(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                (table,),
            )
        elif self.backend == "postgresql":
            row = self.fetchone(
                "SELECT 1 FROM information_schema.tables WHERE table_name=%s",
                (table,),
            )
        else:  # mysql
            row = self.fetchone(
                "SELECT 1 FROM information_schema.tables WHERE table_name=%s AND table_schema=DATABASE()",
                (table,),
            )
        return row is not None

    def get_tables(self) -> List[str]:
        """Return a list of all table names in the database."""
        if self.backend == "sqlite":
            rows = self.fetchall(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            return [r["name"] for r in rows]
        elif self.backend == "postgresql":
            rows = self.fetchall(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema='public' ORDER BY table_name"
            )
            return [r["table_name"] for r in rows]
        else:  # mysql
            rows = self.fetchall("SHOW TABLES")
            return [list(r.values())[0] for r in rows]

    def get_columns(self, table: str) -> List[Dict[str, Any]]:
        """Return column info for the given table."""
        if self.backend == "sqlite":
            return self.fetchall(f"PRAGMA table_info({table})")
        elif self.backend == "postgresql":
            return self.fetchall(
                "SELECT column_name, data_type, is_nullable "
                "FROM information_schema.columns WHERE table_name=%s",
                (table,),
            )
        else:  # mysql
            return self.fetchall(
                "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE "
                "FROM information_schema.columns WHERE table_name=%s AND table_schema=DATABASE()",
                (table,),
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _require_connection(self) -> None:
        if self._conn is None:
            raise ConnectionError("Not connected. Call connect() first.")

    def _placeholders(self, n: int) -> str:
        """Return comma-separated placeholders for n values."""
        ph = self._single_placeholder()
        return ", ".join([ph] * n)

    def _single_placeholder(self) -> str:
        return "?" if self.backend == "sqlite" else "%s"

    def _row_to_dict(self, row: Any) -> Dict[str, Any]:
        """Convert a database row to a plain dict."""
        if row is None:
            return {}
        if isinstance(row, sqlite3.Row):
            return dict(row)
        if hasattr(row, "_asdict"):  # psycopg2 RealDictRow / namedtuple
            return dict(row._asdict())
        if hasattr(self._cursor, "description") and self._cursor.description:
            keys = [d[0] for d in self._cursor.description]
            return dict(zip(keys, row))
        return dict(row)

    def __repr__(self) -> str:
        status = "connected" if self.is_connected() else "disconnected"
        return f"<DBHandler backend={self.backend!r} database={self.database!r} [{status}]>"
