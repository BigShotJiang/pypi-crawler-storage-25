"""
tests/test_dbhandler.py — Tests for dbhandler using an in-memory SQLite database.
"""

import pytest
from dbhandler import DBHandler, QueryBuilder, BaseModel
from dbhandler.models import Field
from dbhandler.exceptions import ConnectionError, QueryError, ModelError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db():
    """Provide a connected in-memory SQLite DBHandler."""
    handler = DBHandler("sqlite", database=":memory:")
    handler.connect()
    handler.execute(
        """
        CREATE TABLE users (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            name  TEXT    NOT NULL,
            email TEXT    NOT NULL UNIQUE,
            age   INTEGER DEFAULT 0
        )
        """
    )
    handler.commit()
    yield handler
    handler.disconnect()


@pytest.fixture
def seeded_db(db):
    """DBHandler with sample rows inserted."""
    db.insert_many(
        "users",
        [
            {"name": "Alice", "email": "alice@example.com", "age": 30},
            {"name": "Bob",   "email": "bob@example.com",   "age": 25},
            {"name": "Carol", "email": "carol@example.com", "age": 35},
        ],
    )
    db.commit()
    return db


# ---------------------------------------------------------------------------
# DBHandler — connection
# ---------------------------------------------------------------------------

class TestConnection:
    def test_connect_sqlite(self):
        db = DBHandler("sqlite", database=":memory:")
        db.connect()
        assert db.is_connected()
        db.disconnect()
        assert not db.is_connected()

    def test_context_manager(self):
        with DBHandler("sqlite", database=":memory:") as db:
            assert db.is_connected()
        assert not db.is_connected()

    def test_unsupported_backend(self):
        with pytest.raises(ValueError, match="Unsupported backend"):
            DBHandler("oracle")

    def test_query_without_connect_raises(self):
        db = DBHandler("sqlite", database=":memory:")
        with pytest.raises(ConnectionError):
            db.execute("SELECT 1")


# ---------------------------------------------------------------------------
# DBHandler — CRUD
# ---------------------------------------------------------------------------

class TestCRUD:
    def test_insert_and_fetchall(self, db):
        db.insert("users", {"name": "Dave", "email": "dave@example.com", "age": 22})
        db.commit()
        rows = db.fetchall("SELECT * FROM users")
        assert len(rows) == 1
        assert rows[0]["name"] == "Dave"

    def test_insert_many(self, seeded_db):
        rows = seeded_db.fetchall("SELECT * FROM users ORDER BY name")
        assert len(rows) == 3
        assert rows[0]["name"] == "Alice"

    def test_fetchone(self, seeded_db):
        row = seeded_db.fetchone("SELECT * FROM users WHERE name = ?", ("Alice",))
        assert row is not None
        assert row["email"] == "alice@example.com"

    def test_fetchmany(self, seeded_db):
        rows = seeded_db.fetchmany("SELECT * FROM users ORDER BY id", size=2)
        assert len(rows) == 2

    def test_select_helper(self, seeded_db):
        rows = seeded_db.select(
            "users",
            columns=["name", "age"],
            where="age > ?",
            params=(25,),
            order_by="age ASC",
        )
        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"

    def test_update(self, seeded_db):
        affected = seeded_db.update(
            "users", {"age": 31}, where="name = ?", where_params=("Alice",)
        )
        seeded_db.commit()
        assert affected == 1
        row = seeded_db.fetchone("SELECT age FROM users WHERE name = ?", ("Alice",))
        assert row["age"] == 31

    def test_delete(self, seeded_db):
        affected = seeded_db.delete("users", where="name = ?", params=("Bob",))
        seeded_db.commit()
        assert affected == 1
        remaining = seeded_db.fetchall("SELECT * FROM users")
        assert len(remaining) == 2

    def test_transaction_rollback(self, db):
        try:
            with db.transaction():
                db.insert("users", {"name": "X", "email": "x@x.com", "age": 1})
                raise RuntimeError("intentional error")
        except RuntimeError:
            pass
        rows = db.fetchall("SELECT * FROM users")
        assert len(rows) == 0  # rolled back


# ---------------------------------------------------------------------------
# DBHandler — Schema helpers
# ---------------------------------------------------------------------------

class TestSchema:
    def test_table_exists(self, db):
        assert db.table_exists("users")
        assert not db.table_exists("nonexistent")

    def test_get_tables(self, db):
        tables = db.get_tables()
        assert "users" in tables

    def test_get_columns(self, db):
        cols = db.get_columns("users")
        col_names = [c["name"] for c in cols]
        assert "name" in col_names
        assert "email" in col_names


# ---------------------------------------------------------------------------
# QueryBuilder
# ---------------------------------------------------------------------------

class TestQueryBuilder:
    def test_select_all(self):
        sql, params = QueryBuilder("users").select().build()
        assert "SELECT *" in sql
        assert "FROM users" in sql
        assert params == ()

    def test_select_with_where(self):
        sql, params = (
            QueryBuilder("users")
            .select("id", "name")
            .where("age > ?", 18)
            .order_by("name ASC")
            .limit(5)
            .offset(0)
            .build()
        )
        assert "WHERE" in sql
        assert params == (18,)
        assert "LIMIT 5" in sql

    def test_insert_build(self):
        sql, params = QueryBuilder("users").insert(name="Alice", age=30).build()
        assert "INSERT INTO users" in sql
        assert params == ("Alice", 30)

    def test_update_build(self):
        sql, params = (
            QueryBuilder("users")
            .update(name="Bob")
            .where("id = ?", 1)
            .build()
        )
        assert "UPDATE users SET" in sql
        assert params == ("Bob", 1)

    def test_delete_build(self):
        sql, params = QueryBuilder("users").delete().where("id = ?", 99).build()
        assert "DELETE FROM users WHERE" in sql
        assert params == (99,)

    def test_no_operation_raises(self):
        with pytest.raises(ValueError, match="No operation set"):
            QueryBuilder("users").build()

    def test_integration_with_db(self, seeded_db):
        sql, params = (
            QueryBuilder("users")
            .select("name")
            .where("age > ?", 28)
            .order_by("name ASC")
            .build()
        )
        rows = seeded_db.fetchall(sql, params)
        names = [r["name"] for r in rows]
        assert "Alice" in names
        assert "Carol" in names
        assert "Bob" not in names


# ---------------------------------------------------------------------------
# BaseModel
# ---------------------------------------------------------------------------

class TestBaseModel:

    @pytest.fixture(autouse=True)
    def setup_model(self, db):
        class User(BaseModel):
            __table__ = "people"
            id    = Field(int, primary_key=True)
            name  = Field(str, nullable=False)
            email = Field(str, nullable=False, unique=True)
            age   = Field(int, default=0)

        User.__db__ = db
        User.create_table()
        self.User = User
        yield
        User.drop_table()

    def test_save_insert(self):
        u = self.User(name="Alice", email="a@a.com", age=30)
        u.save()
        assert u.id is not None

    def test_all(self):
        self.User(name="Alice", email="a@a.com", age=30).save()
        self.User(name="Bob", email="b@b.com", age=25).save()
        users = self.User.all()
        assert len(users) == 2

    def test_get(self):
        self.User(name="Carol", email="c@c.com", age=35).save()
        u = self.User.get(name="Carol")
        assert u is not None
        assert u.email == "c@c.com"

    def test_filter(self):
        self.User(name="Dave", email="d@d.com", age=20).save()
        self.User(name="Eve",  email="e@e.com", age=40).save()
        adults = self.User.filter("age >= ?", (30,))
        assert len(adults) == 1
        assert adults[0].name == "Eve"

    def test_count(self):
        self.User(name="Frank", email="f@f.com", age=50).save()
        assert self.User.count() == 1

    def test_save_update(self):
        u = self.User(name="Grace", email="g@g.com", age=22)
        u.save()
        pk = u.id
        u.age = 23
        u.save()
        fetched = self.User.get(id=pk)
        assert fetched.age == 23

    def test_delete_instance(self):
        u = self.User(name="Hank", email="h@h.com", age=45)
        u.save()
        u.delete()
        assert self.User.count() == 0

    def test_to_dict(self):
        u = self.User(name="Ivy", email="i@i.com", age=28)
        d = u.to_dict()
        assert d["name"] == "Ivy"
        assert "email" in d

    def test_no_db_raises(self):
        class Orphan(BaseModel):
            __table__ = "orphans"

        with pytest.raises(ModelError, match="No database bound"):
            Orphan.create_table()
