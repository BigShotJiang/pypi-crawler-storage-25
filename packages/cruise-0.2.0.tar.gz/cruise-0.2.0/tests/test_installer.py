"""Tests for the service installer."""

import platform
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from cruise.installer import (
    _LABEL,
    _PLIST_PATH,
    _SYSTEMD_PATH,
    _LOG_DIR,
    _find_cruise_bin,
)


class TestFindCruiseBin:
    def test_finds_cruise_on_path(self):
        with patch("shutil.which", return_value="/usr/local/bin/cruise"):
            assert _find_cruise_bin() == "/usr/local/bin/cruise"

    def test_fallback_to_python_module(self):
        import sys
        with patch("shutil.which", return_value=None):
            result = _find_cruise_bin()
            assert sys.executable in result
            assert "cruise.cli" in result


class TestInstallLaunchd:
    @pytest.mark.skipif(platform.system() != "Darwin", reason="macOS only")
    def test_generates_valid_plist(self, tmp_path):
        """install writes a valid plist file."""
        from cruise.installer import _install_launchd

        plist_path = tmp_path / "test.plist"
        with patch("cruise.installer._PLIST_DIR", tmp_path), \
             patch("cruise.installer._PLIST_PATH", plist_path), \
             patch("cruise.installer._LOG_DIR", tmp_path / "logs"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            _install_launchd("/usr/local/bin/cruise")

            content = plist_path.read_text()
            assert _LABEL in content
            assert "/usr/local/bin/cruise" in content
            assert "daemon" in content
            mock_run.assert_called_once()


class TestInstallSystemd:
    @pytest.mark.skipif(platform.system() != "Linux", reason="Linux only")
    def test_generates_valid_unit(self, tmp_path):
        """install writes a valid systemd unit file."""
        from cruise.installer import _install_systemd

        unit_path = tmp_path / "cruise-daemon.service"
        with patch("cruise.installer._SYSTEMD_DIR", tmp_path), \
             patch("cruise.installer._SYSTEMD_PATH", unit_path), \
             patch("cruise.installer._LOG_DIR", tmp_path / "logs"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            _install_systemd("/usr/local/bin/cruise")

            content = unit_path.read_text()
            assert "/usr/local/bin/cruise" in content
            assert "daemon" in content


class TestStatus:
    def test_returns_dict_with_running_key(self):
        from cruise.installer import status
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=1, stdout="")
            result = status()
            assert "running" in result
            assert "platform" in result
