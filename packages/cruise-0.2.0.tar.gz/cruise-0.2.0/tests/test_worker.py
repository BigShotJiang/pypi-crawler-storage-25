"""Tests for the agent worker."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path

import pytest

from cruise.worker import Worker, _RunningSession
from cruise.protocol import (
    CancelMessage,
    CommentPayload,
    DispatchMessage,
    InjectCommentMessage,
    IssuePayload,
    QuestionReplyMessage,
)


def _make_issue(**overrides):
    defaults = dict(
        id="uuid-1", identifier="SUP-42", title="Fix bug", state="Todo",
        description="Something broken", url="https://linear.app/SUP-42",
        labels=["agent"], branch_name="aryan/sup-42",
    )
    defaults.update(overrides)
    return IssuePayload(**defaults)


def _make_dispatch(issue=None, **overrides):
    defaults = dict(
        issue=issue or _make_issue(),
        comments=[], images=[], resume_session_id=None,
    )
    defaults.update(overrides)
    return DispatchMessage(**defaults)


@pytest.fixture
def mock_client():
    client = AsyncMock()
    client.send_agent_started = AsyncMock()
    client.send_agent_completed = AsyncMock()
    client.send_agent_failed = AsyncMock()
    client.send_progress = AsyncMock()
    return client


@pytest.fixture
def worker(mock_client, tmp_path):
    return Worker(
        client=mock_client,
        repo_path=str(tmp_path / "repo"),
        workspace_root=str(tmp_path / "workspaces"),
        branch_prefix="aryan",
        max_turns=20,
    )


class TestHandleDispatch:
    @pytest.mark.asyncio
    async def test_dispatches_agent_session(self, worker, mock_client, tmp_path):
        """Dispatch creates a worktree and runs an agent."""
        issue = _make_issue()
        msg = _make_dispatch(issue=issue)

        with patch("cruise.worker.create_worktree", new_callable=AsyncMock) as mock_wt, \
             patch("cruise.worker.run_agent", new_callable=AsyncMock) as mock_run:
            mock_wt.return_value = tmp_path / "workspaces" / "SUP-42"
            mock_run.return_value = MagicMock(
                session_id="ses_abc", success=True, cost_usd=0.42,
                num_turns=15, duration_ms=180000, error=None,
            )

            await worker.handle_message(msg)
            # Wait for the background task to complete
            await asyncio.sleep(0.1)
            for session in list(worker._sessions.values()):
                await session.task

            mock_wt.assert_called_once()
            mock_run.assert_called_once()
            mock_client.send_agent_completed.assert_called_once()
            call_args = mock_client.send_agent_completed.call_args
            # Check kwargs or positional args
            if call_args.kwargs:
                assert call_args.kwargs["success"] is True
                assert call_args.kwargs["cost_usd"] == 0.42
            else:
                # Positional: issue_id, session_id, success, cost_usd, ...
                assert call_args.args[2] is True

    @pytest.mark.asyncio
    async def test_ignores_duplicate_dispatch(self, worker, mock_client, tmp_path):
        """Second dispatch for same issue is ignored."""
        issue = _make_issue()

        # Manually insert a running session
        worker._sessions[issue.id] = _RunningSession(
            issue_id=issue.id, identifier=issue.identifier,
            task=asyncio.create_task(asyncio.sleep(100)),
            comment_queue=asyncio.Queue(),
        )

        msg = _make_dispatch(issue=issue)
        with patch("cruise.worker.create_worktree", new_callable=AsyncMock) as mock_wt:
            await worker.handle_message(msg)
            mock_wt.assert_not_called()

        # Cleanup
        worker._sessions[issue.id].task.cancel()

    @pytest.mark.asyncio
    async def test_reports_failure_on_error(self, worker, mock_client, tmp_path):
        """Agent errors are reported back to the cloud."""
        issue = _make_issue()
        msg = _make_dispatch(issue=issue)

        with patch("cruise.worker.create_worktree", new_callable=AsyncMock) as mock_wt, \
             patch("cruise.worker.run_agent", new_callable=AsyncMock) as mock_run:
            mock_wt.return_value = tmp_path / "workspaces" / "SUP-42"
            mock_run.return_value = MagicMock(
                session_id="ses_abc", success=False, cost_usd=0.0,
                num_turns=3, duration_ms=5000, error="Something went wrong",
            )

            await worker.handle_message(msg)
            await asyncio.sleep(0.1)
            for session in list(worker._sessions.values()):
                await session.task

            mock_client.send_agent_failed.assert_called_once()
            call_args = mock_client.send_agent_failed.call_args
            error_str = call_args.kwargs.get("error") or call_args.args[1]
            assert "Something went wrong" in error_str


class TestHandleCancel:
    @pytest.mark.asyncio
    async def test_cancels_running_session(self, worker):
        """Cancel message cancels the running task."""
        task = asyncio.create_task(asyncio.sleep(100))
        worker._sessions["uuid-1"] = _RunningSession(
            issue_id="uuid-1", identifier="SUP-42",
            task=task, comment_queue=asyncio.Queue(),
        )

        msg = CancelMessage(issue_id="uuid-1", reason="Issue moved to Done")
        await worker.handle_message(msg)

        assert "uuid-1" not in worker._sessions
        # Task is cancelling; let the event loop process the cancellation
        await asyncio.sleep(0)
        assert task.cancelled() or task.done()

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_is_noop(self, worker):
        """Cancelling a non-existent session does nothing."""
        msg = CancelMessage(issue_id="uuid-999", reason="Gone")
        await worker.handle_message(msg)  # Should not raise


class TestHandleComment:
    @pytest.mark.asyncio
    async def test_injects_comment_into_queue(self, worker):
        """Comment message is placed into the session's comment queue."""
        queue = asyncio.Queue()
        worker._sessions["uuid-1"] = _RunningSession(
            issue_id="uuid-1", identifier="SUP-42",
            task=asyncio.create_task(asyncio.sleep(100)),
            comment_queue=queue,
        )

        msg = InjectCommentMessage(issue_id="uuid-1", body="Skip the sidebar")
        await worker.handle_message(msg)

        assert not queue.empty()
        assert queue.get_nowait() == "Skip the sidebar"

        worker._sessions["uuid-1"].task.cancel()


class TestHandleQuestionReply:
    @pytest.mark.asyncio
    async def test_resolves_pending_question(self, worker):
        """Question reply resolves the pending future."""
        future = asyncio.get_event_loop().create_future()
        worker._sessions["uuid-1"] = _RunningSession(
            issue_id="uuid-1", identifier="SUP-42",
            task=asyncio.create_task(asyncio.sleep(100)),
            comment_queue=asyncio.Queue(),
            question_future=future,
        )

        msg = QuestionReplyMessage(issue_id="uuid-1", reply="Use existing auth")
        await worker.handle_message(msg)

        assert future.done()
        assert future.result() == "Use existing auth"

        worker._sessions["uuid-1"].task.cancel()


class TestCancelAll:
    @pytest.mark.asyncio
    async def test_cancels_all_sessions(self, worker):
        """cancel_all cancels every running session."""
        tasks = []
        for i in range(3):
            task = asyncio.create_task(asyncio.sleep(100))
            tasks.append(task)
            worker._sessions[f"uuid-{i}"] = _RunningSession(
                issue_id=f"uuid-{i}", identifier=f"SUP-{i}",
                task=task, comment_queue=asyncio.Queue(),
            )

        await worker.cancel_all()
        await asyncio.sleep(0)

        assert len(worker._sessions) == 0
        for task in tasks:
            assert task.cancelled() or task.done()
