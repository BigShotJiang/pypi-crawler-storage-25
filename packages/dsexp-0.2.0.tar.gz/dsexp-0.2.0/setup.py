from setuptools import setup, find_packages

setup(
    name="dsexp",
    version="0.2.0",
    author="Shlok Jha",
    author_email="your_email@example.com",
    description="Data Science Experiments Library with Theory and Code",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    keywords=[
        "python",
        "data science",
        "machine learning",
        "ai",
        "ann",
        "experiments"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)