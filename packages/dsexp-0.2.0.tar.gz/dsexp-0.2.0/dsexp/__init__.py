from .theory import theories
from .codes import codes

def print_theory(num):

    if num in theories:
        print(theories[num])

    else:
        print("Theory not found")


def print_code(num):

    if num in codes:
        print(codes[num])

    else:
        print("Code not found")