theories = {

    1:"""
    DATA WRANGLING I: Data Preprocessing
    ------------------------------------
    Data Wrangling is the process of cleaning, structuring, and enriching raw data into a desired format for better decision-making in less time.

    Key Concepts:
    1. Data Loading: Importing datasets from CSV, Excel, or SQL databases into DataFrames.
    2. Missing Values: Identified using .isnull() or .isna(). Handled via dropping or imputation.
    3. Data Normalization: Scaling features to a common range (e.g., 0 to 1) to prevent bias in models.
    4. Data Formatting: Ensuring consistent data types (e.g., converting 'Age' to int).
    5. Label Encoding: Converting categorical text data into numerical values so machines can understand them.
    """ ,
    2:"""
    DATA WRANGLING II: Cleaning & Transformation
    --------------------------------------------
    Focuses on advanced cleaning techniques like handling outliers and data normalization.
 
    Key Concepts:
    1. Missing Values: Imputation techniques include filling with mean, median, or mode.
    2. Inconsistencies: Removing logical errors (e.g., negative scores or ages).
    3. Outliers: Data points that differ significantly from other observations.
       - Detected using: Boxplots, Scatter plots, or Z-scores.
       - Handled using: IQR (Interquartile Range) method to clip or remove them.
    4. Data Transformation: 
       - Log Transformation: Used to reduce skewness and make the distribution more 'normal'.
       - Scaling: Adjusting values for better model performance.
    """ ,
    3:"""
    DESCRIPTIVE STATISTICS: Measures of Central Tendency
    ----------------------------------------------------
    Summarizes or describes the characteristics of a dataset.

    Key Concepts:
    1. Central Tendency:
      - Mean: Average value.
     - Median: Middle value when data is sorted.
     - Mode: Most frequent value.
    2. Measures of Variability:
       - Standard Deviation: Measures the spread of data from the mean.
       - Variance: The square of the standard deviation.
    3. Grouping: Analyzing quantitative variables (like Income) based on qualitative variables (like Age Group).
    4. Binning: Converting continuous variables into categorical 'bins'.
    """ ,
    4:"""
    DATA ANALYTICS I: Linear Regression
    -----------------------------------
    A statistical method used for predictive analysis by modeling the relationship between a dependent (target) variable and one or more independent (predictor) variables.

    Key Concepts:
    1. Model: Y = mX + c (Simple Linear Regression).
    2. Train-Test Split: Dividing data into training set (to learn patterns) and testing set (to evaluate).
    3. MSE (Mean Squared Error): Measures the average of the squares of errors—the difference between actual and predicted values.
    4. R2 Score (Coefficient of Determination): Indicates how well the model predicts the outcomes (0 to 1).
    """ ,
    5:"""
    DATA ANALYTICS II: Logistic Regression
    --------------------------------------
    Used for classification problems where the output is a categorical value (e.g., Yes/No, 0/1).

    Key Concepts:
    1. Logistic Function: Uses the Sigmoid function to map predictions to probabilities between 0 and 1.
    2. Classification: Assigning data points to discrete categories.
    3. Confusion Matrix: A table used to describe the performance of a classification model.
       - TP: True Positive (Correctly predicted positive)
       - TN: True Negative (Correctly predicted negative)
       - FP: False Positive (Incorrectly predicted positive - Type I Error)
       - FN: False Negative (Incorrectly predicted negative - Type II Error)
    4. Metrics: Accuracy, Precision, Recall, and Error Rate.
     """ ,
    6:"""
    DATA ANALYTICS III: Naive Bayes Classification
    ----------------------------------------------
    A probabilistic classifier based on Bayes' Theorem with an assumption of independence among predictors.

    Key Concepts:
    1. Bayes' Theorem: P(A|B) = [P(B|A) * P(A)] / P(B).
    2. 'Naive' Assumption: Assumes that the presence of a particular feature in a class is unrelated to any other feature.
    3. Performance Metrics:
       - Accuracy: Overall correctness.
       - Precision: Correctness of positive predictions.
       - Recall: Ability to find all positive instances.
    4. Macro-averaging: Calculating metrics for each class and then taking the average.
    """ ,
    7:"""
    TEXT ANALYTICS: Natural Language Processing (NLP)
    -------------------------------------------------
     Analyzing and extracting information from textual data.

    Key Concepts:
    1. Tokenization: Breaking text into smaller units (sentences or words).
    2. POS Tagging: Identifying parts of speech (Nouns, Verbs, etc.).
    3. Stop Words Removal: Removing common words (is, the, at) that carry little meaning.
    4. Stemming: Reducing words to their root form (e.g., 'running' to 'run').
    5. Lemmatization: Reducing words to their dictionary base form using vocabulary and morphological analysis.
    6. TF-IDF: 
       - Term Frequency (TF): Frequency of a word in a document.
       - Inverse Document Frequency (IDF): Importance of a word based on its rarity across documents.
       """ ,
    8:"""
    DATA VISUALIZATION I: Univariate Analysis
    -----------------------------------------
    Visual representation of data to find patterns and trends using tools like Seaborn and Matplotlib.

    Key Concepts:
    1. Histograms: Used to visualize the distribution of a single numerical variable.
    2. Countplots: Used to show the counts of observations in each categorical bin.
    3. Distribution Analysis: Checking for skewness, peaks, and spread.
    4. Feature Engineering: Using visualization to decide which features impact the target (e.g., survival in Titanic).
    """ ,
    9:"""
    DATA VISUALIZATION II: Bivariate Analysis
    ------------------------------------------
    Analyzing the relationship between two variables.

    Key Concepts:
    1. Boxplots: Displaying the distribution of data based on a five-number summary (Min, Q1, Median, Q3, Max).
    2. Categorical vs. Numerical: Comparing distributions across categories (e.g., Age distribution by Gender).
    3. Hue parameter: Adding a third dimension to a plot (e.g., Survival status) using color coding.
    4. Observation: Drawing inferences about which groups performed better or had different characteristics.
    """ ,
    10:"""
    DATA VISUALIZATION III: Multivariate Analysis
    ---------------------------------------------
    Visualizing three or more variables simultaneously to understand complex relationships.

    Key Concepts:
    1. Histograms for all features: Understanding the spread and range of numerical features (e.g., Iris sepal/petal lengths).
    2. Outlier Detection: Using boxplots across multiple features to identify anomalous data points.
    3. Correlation: How features move in relation to each other.
    4. Standard Deviation/Median: Comparing the central tendency and spread across different species or groups.
    """ 

}