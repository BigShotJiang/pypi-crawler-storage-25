codes = {

    1:"""
    # ============================================
# IRIS DATASET PREPROCESSING
# ============================================

# 1. Import Libraries
import pandas as pd
import seaborn as sns
from sklearn.preprocessing import LabelEncoder

# 2. Load Inbuilt Dataset from Seaborn
df = sns.load_dataset('iris')

# 3. Display Dataset
print("First 5 Rows:")
print(df.head())

# ============================================
# 4. Data Preprocessing
# ============================================

# Check Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Statistical Information
print("\nStatistics:")
print(df.describe())

# Shape of Dataset
print("\nShape:")
print(df.shape)

# Data Types
print("\nData Types:")
print(df.dtypes)

# ============================================
# 5. Convert Categorical Column into Category Type
# ============================================

df['species'] = df['species'].astype('category')

print("\nAfter Type Conversion:")
print(df.dtypes)

# ============================================
# 6. Convert Categorical Variable to Numerical
# ============================================

le = LabelEncoder()

df['species'] = le.fit_transform(df['species'])

print("\nAfter Encoding:")
print(df.head())

# ============================================
# 7. Final Dataset Information
# ============================================

print("\nDataset Info:")
df.info()
""" ,
2:"""
# ============================================
# STUDENT DATA PREPROCESSING
# ============================================

# 1. Import Libraries
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# ============================================
# 2. Load Dataset
# ============================================

df = pd.read_csv("student_data.csv")

print("First 5 Rows:")
print(df.head())

# ============================================
# 3. Check Missing Values
# ============================================

print("\nMissing Values:")
print(df.isnull().sum())

# Fill Missing Values with Mean
df.fillna(df.mean(numeric_only=True), inplace=True)

# ============================================
# 4. Remove Outliers using IQR Method
# ============================================

# Select Numerical Columns
num_cols = df.select_dtypes(include='number')

# Remove Outliers
for col in num_cols:

    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)

    IQR = Q3 - Q1

    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    df = df[(df[col] >= lower) & (df[col] <= upper)]

print("\nOutliers Removed")

# ============================================
# 5. Data Transformation (Normalization)
# ============================================

scaler = MinMaxScaler()

df[num_cols.columns] = scaler.fit_transform(df[num_cols.columns])

# ============================================
# 6. Display Final Dataset
# ============================================

print("\nNormalized Dataset:")
print(df.head())
""" ,
3: """
# ============================================
# IRIS DATASET STATISTICAL ANALYSIS
# ============================================

# 1. Import Libraries
import pandas as pd

# ============================================
# 2. Load Dataset
# ============================================

df = pd.read_csv("Iris.csv")

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# ============================================
# 3. Summary Statistics Grouped by Species
# ============================================

print("\nSummary Statistics Grouped by Species:")

summary = df.groupby('Species')['SepalLengthCm'].agg(
    ['mean', 'median', 'min', 'max', 'std']
)

print(summary)

# ============================================
# 4. List of Sepal Length Values by Species
# ============================================

species_list = df.groupby('Species')['SepalLengthCm'].apply(list)

print("\nList of Sepal Length Values by Species:")
print(species_list)

# ============================================
# 5. Statistical Details of Each Species
# ============================================

print("\nIris-setosa:")
print(df[df['Species'] == 'Iris-setosa'].describe())

print("\nIris-versicolor:")
print(df[df['Species'] == 'Iris-versicolor'].describe())

print("\nIris-virginica:")
print(df[df['Species'] == 'Iris-virginica'].describe())
""" ,
4:"""
# ============================================
# LINEAR REGRESSION ON HOUSING DATASET
# ============================================

# 1. Import Libraries
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# ============================================
# 2. Load Dataset
# ============================================

df = pd.read_csv("housing.csv", sep='\\s+', header=None)

print("First 5 Rows:")
print(df.head())

# ============================================
# 3. Input and Output Separation
# ============================================

# Features
X = df.iloc[:, :-1]

# Target (House Price)
y = df.iloc[:, -1]

# ============================================
# 4. Split Dataset into Training and Testing
# ============================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ============================================
# 5. Create Linear Regression Model
# ============================================

model = LinearRegression()

# ============================================
# 6. Train the Model
# ============================================

model.fit(X_train, y_train)

# ============================================
# 7. Make Predictions
# ============================================

y_pred = model.predict(X_test)

# ============================================
# 8. Evaluate the Model
# ============================================

print("\nModel Performance:")

print("R2 Score:", r2_score(y_test, y_pred))

print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
""" ,
5:  """
# ============================================
# LOGISTIC REGRESSION ON SOCIAL NETWORK ADS
# ============================================

# 1. Import Libraries
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score

# ============================================
# 2. Load Dataset
# ============================================

df = pd.read_csv("Social_Network_Ads.csv")

print("First 5 Rows:")
print(df.head())

print("\nComplete Dataset:")
print(df)

# ============================================
# 3. Define Features (X) and Target (y)
# ============================================

# Features
X = df[['Age', 'EstimatedSalary']]

# Target
y = df['Purchased']

# ============================================
# 4. Split Dataset into Training and Testing
# ============================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ============================================
# 5. Apply Logistic Regression
# ============================================

model = LogisticRegression()

# Train Model
model.fit(X_train, y_train)

# Make Predictions
y_pred = model.predict(X_test)

# ============================================
# 6. Generate Confusion Matrix
# ============================================

cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:\n")
print(cm)

# ============================================
# 7. Extract TP, TN, FP, FN
# ============================================

TN = cm[0][0]
FP = cm[0][1]
FN = cm[1][0]
TP = cm[1][1]

print("\nTP =", TP)
print("TN =", TN)
print("FP =", FP)
print("FN =", FN)

# ============================================
# 8. Calculate Performance Metrics
# ============================================

accuracy = accuracy_score(y_test, y_pred)

error_rate = 1 - accuracy

precision = TP / (TP + FP)

recall = TP / (TP + FN)

# ============================================
# 9. Display Results
# ============================================

print("\nAccuracy =", accuracy * 100)

print("Error Rate =", error_rate * 100)

print("Precision =", precision)

print("Recall =", recall)
""" ,
6: """
# =====================================================
# DATA ANALYTICS III
# Naive Bayes on iris.csv Dataset
# =====================================================

# 1. Import Libraries
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix, accuracy_score

# =====================================================
# 2. Load Dataset
# =====================================================

df = pd.read_csv("iris.csv")

print("First 5 Rows:\n")

print(df.head())

# =====================================================
# 3. Display Column Names
# =====================================================

print("\nColumns:\n")

print(df.columns)

# =====================================================
# 4. Convert Categorical Data into Numerical
# =====================================================

le = LabelEncoder()

df['Species'] = le.fit_transform(df['Species'])

# =====================================================
# 5. Define Features (X) and Target (y)
# =====================================================

# Features
X = df.drop('Species', axis=1)

# Target
y = df['Species']

# =====================================================
# 6. Split Dataset into Training and Testing
# =====================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =====================================================
# 7. Apply Naive Bayes
# =====================================================

model = GaussianNB()

# Train Model
model.fit(X_train, y_train)

# =====================================================
# 8. Make Predictions
# =====================================================

y_pred = model.predict(X_test)

# =====================================================
# 9. Generate Confusion Matrix
# =====================================================

cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:\n")

print(cm)

# =====================================================
# 10. Calculate Accuracy
# =====================================================

accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy =", accuracy * 100)

# =====================================================
# 11. Extract TP, TN, FP, FN
# =====================================================

# For First Class

TP = cm[0][0]

FP = cm[1][0]

FN = cm[0][1]

TN = cm[1][1]

print("\nTP =", TP)

print("TN =", TN)

print("FP =", FP)

print("FN =", FN)

# =====================================================
# 12. Calculate Precision, Recall, Error Rate
# =====================================================

precision = TP / (TP + FP)

recall = TP / (TP + FN)

error_rate = 1 - accuracy

# =====================================================
# 13. Display Results
# =====================================================

print("\nPrecision =", precision)

print("Recall =", recall)

print("Error Rate =", error_rate * 100)
""" ,
7: """
# =====================================================
# NATURAL LANGUAGE PROCESSING (NLP)
# Text Processing using NLTK and TF-IDF
# =====================================================

# 1. Import NLTK
import nltk

# =====================================================
# 2. Download Required NLTK Resources
# =====================================================

nltk.download('punkt')

nltk.download('punkt_tab')

nltk.download('stopwords')

nltk.download('averaged_perceptron_tagger')

nltk.download('averaged_perceptron_tagger_eng')

nltk.download('wordnet')

# =====================================================
# 3. Import Required Libraries
# =====================================================

from nltk.tokenize import word_tokenize

from nltk.corpus import stopwords

from nltk.stem import PorterStemmer, WordNetLemmatizer

from nltk import pos_tag

from sklearn.feature_extraction.text import TfidfVectorizer

# =====================================================
# 4. Sample Document
# =====================================================

text = "Natural Language Processing is used in text analytics"

print("Original Text:\n")

print(text)

# =====================================================
# 5. Tokenization
# =====================================================

tokens = word_tokenize(text)

print("\nTokens:")

print(tokens)

# =====================================================
# 6. POS Tagging
# =====================================================

print("\nPOS Tags:")

print(pos_tag(tokens))

# =====================================================
# 7. Stop Words Removal
# =====================================================

stop_words = set(stopwords.words('english'))

filtered = [
    word for word in tokens
    if word.lower() not in stop_words
]

print("\nStopwords Removed:")

print(filtered)

# =====================================================
# 8. Stemming
# =====================================================

stemmer = PorterStemmer()

stemmed_words = [stemmer.stem(word) for word in filtered]

print("\nStemming:")

print(stemmed_words)

# =====================================================
# 9. Lemmatization
# =====================================================

lemmatizer = WordNetLemmatizer()

lemmatized_words = [
    lemmatizer.lemmatize(word)
    for word in filtered
]

print("\nLemmatization:")

print(lemmatized_words)

# =====================================================
# 10. TF-IDF Vectorization
# =====================================================

tfidf = TfidfVectorizer()

result = tfidf.fit_transform([text])

print("\nTF-IDF Matrix:")

print(result.toarray())
""" ,
8:"""
# =====================================================
# TITANIC DATA VISUALIZATION
# Using Seaborn and Matplotlib
# =====================================================

# 1. Import Libraries
import seaborn as sns
import matplotlib.pyplot as plt

# =====================================================
# 2. Load Titanic Dataset
# =====================================================

df = sns.load_dataset("titanic")

# Display First 5 Rows
print("First 5 Rows:\n")

print(df.head())

# =====================================================
# 3. Pattern 1: Survival Count
# =====================================================

sns.countplot(x='survived', data=df)

plt.title("Survival Count")

plt.show()

# =====================================================
# 4. Pattern 2: Gender vs Survival
# =====================================================

sns.countplot(x='sex', hue='survived', data=df)

plt.title("Gender vs Survival")

plt.show()

# =====================================================
# 5. Histogram of Fare Distribution
# =====================================================

plt.hist(df['fare'])

plt.xlabel("Fare")

plt.ylabel("Passenger Count")

plt.title("Fare Distribution")

plt.show()
""" ,
9: """ 
# =====================================================
# TITANIC DATA VISUALIZATION
# Box Plot using Seaborn and Matplotlib
# =====================================================

# 1. Import Libraries
import seaborn as sns
import matplotlib.pyplot as plt

# =====================================================
# 2. Load Titanic Dataset
# =====================================================

df = sns.load_dataset("titanic")

# Display First 5 Rows
print("First 5 Rows:\n")

print(df.head())

# =====================================================
# 3. Create Box Plot
# =====================================================

sns.boxplot(
    x='sex',
    y='age',
    hue='survived',
    data=df
)

# =====================================================
# 4. Add Labels and Title
# =====================================================

plt.title("Age Distribution by Gender and Survival")

plt.xlabel("Gender")

plt.ylabel("Age")

# =====================================================
# 5. Add Legend
# =====================================================

plt.legend(labels=['Not Survived', 'Survived'])

# =====================================================
# 6. Display Plot
# =====================================================

plt.show()
""" ,
10: """
# =====================================================
# IRIS DATASET VISUALIZATION
# Histograms and Boxplots
# =====================================================

# 1. Import Libraries
import pandas as pd
import matplotlib.pyplot as plt

# =====================================================
# 2. Load Dataset
# =====================================================

df = pd.read_csv("Iris.csv")

# Display First 5 Rows
print("First 5 Rows:\n")

print(df.head())

# =====================================================
# 3. Remove Id Column
# =====================================================

df = df.drop("Id", axis=1)

# =====================================================
# 4. Display Features and Datatypes
# =====================================================

print("\nFeatures and Datatypes:\n")

print(df.dtypes)

# =====================================================
# 5. Histogram for Each Feature
# =====================================================

df.hist(figsize=(8, 8))

plt.suptitle("Histograms of Iris Features")

plt.show()

# =====================================================
# 6. Boxplot for Each Feature
# =====================================================

df.plot(
    kind='box',
    subplots=True,
    layout=(2, 2),
    figsize=(8, 8)
)

plt.suptitle("Boxplots of Iris Features")

plt.show()
""" ,
}