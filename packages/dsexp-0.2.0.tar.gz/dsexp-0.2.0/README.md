# dsexperiments

A Python library containing Data Science and Artificial Intelligence experiments with:

- Theory
- Python Code
- Practical Implementations

## Installation

```bash
pip install dsexp