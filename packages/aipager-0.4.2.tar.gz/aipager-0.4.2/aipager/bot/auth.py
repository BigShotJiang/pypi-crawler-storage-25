"""Telegram bot — python-telegram-bot v22 async Application.

Single owner of all Telegram communication. Handles:
- CallbackQuery (button taps) → dtach_inject.send_keys()
- Message replies → dtach_inject.send_text_and_enter()
- /status command → show all sessions
- /<label> <prompt> → direct send to session
"""

from __future__ import annotations

import asyncio
import html as html_mod
import logging
from typing import TYPE_CHECKING

from telegram import (
    Update,
)

from aipager.dtach import inject

from aipager.config import (
    CHAT_ID,
)
from aipager.state import Status, TrackedSession
from aipager.team import (
    Role,
    User as TeamUser,
    attribution_label,
    record_pending_user,
    remember_unauthorized,
)

# Pure-function helpers and constants live in aipager.bot.transport
# now. Re-export the names this module uses internally so the
# TelegramBot class body below (and any external consumers like the
# tests) keeps working without changes.
from aipager.bot.transport import (  # noqa: F401
    ACTION_VERBS,
    TELEGRAM_BOT_DOWNLOAD_LIMIT_BYTES,
    TELEGRAM_MAX_DOC_BYTES,
    TELEGRAM_MAX_TEXT_LEN,
    TruncationFailed,
    _build_diff_block,
    _detect_api_error,
    _DIFF_MAX_CHARS,
    _DIFF_MAX_LINES,
    _diff_view_enabled,
    _ERROR_PATTERNS,
    _extract_retry_after,
    _is_bot_blocked,
    _log_blocked_once,
    _MAX_TRUNCATIONS,
    _md_safe_boundaries,
    _PERSONAL_MODE_SENTINEL,
    _RETRY_AFTER_RE,
    _safe_truncate,
    _send_with_retry,
    _TRUNC_SUFFIX,
    _truncate_diff,
)

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)





class AuthMixin:
    """Mixin for TelegramBot — see :mod:`aipager.bot` overview."""

    # ------------------------------------------------------------------
    # Authorization helpers (team mode)
    #
    # In personal mode (``self.team is None``) every chat-id-passing
    # message is implicitly authorized. In team mode we re-check the
    # sender's user_id against ``self.team`` allow-list at the top of
    # every handler — never trust the chat-level filter alone for
    # actions that mutate state.
    # ------------------------------------------------------------------

    # ---- scope helpers (Phase C — used when self.scopes is not None) ----

    def _scope_for(self, chat_id):
        """Return the Scope whose chat_id matches, or None."""
        if not self.scopes or chat_id is None:
            return None
        for s in self.scopes:
            if s.chat_id == chat_id:
                return s
        return None

    def _member_in_scope(self, scope, user_id):
        if scope is None:
            return None
        for m in scope.members:
            if m.id == user_id:
                return m
        return None

    def _member_anywhere(self, user_id):
        """Find a member by id across all scopes (for driver attribution)."""
        for s in (self.scopes or []):
            for m in s.members:
                if m.id == user_id:
                    return m
        return None

    def _role_can_prompt(self, member) -> bool:
        if member is None:
            return False
        role = self.policy.get_role(member.role)
        return bool(role and role.can_prompt)

    # ---- observability (Phase H) ----------------------------------------

    def _scope_label(self, chat_id) -> str:
        """Human label for a chat, for audit + scope-prefixed logs."""
        if self.scopes is None:
            return "legacy"
        scope = self._scope_for(chat_id)
        if scope is not None:
            return scope.label
        if chat_id is None:
            return "unknown"
        return f"{'group' if chat_id < 0 else 'dm'}:{chat_id}"

    @staticmethod
    def _inbound_action(update) -> str:
        """Derive a short 'what' from an inbound message: the leading
        ``/command`` (stripped of any ``@botname``) or ``"prompt"``."""
        msg = getattr(update, "message", None)
        text = (getattr(msg, "text", None) or "").strip()
        if text.startswith("/"):
            return text.split()[0].split("@")[0]
        return "prompt" if text else "action"

    def _audit_event(self, update, action: str | None = None,
                     *, denied: bool = False, reason: str = "") -> None:
        """Audit one inbound message with scope attribution + emit a
        scope-labeled INFO log. **Multi-scope only** — a no-op when
        ``self.scopes is None`` (single-user installs don't need a
        per-message trail; legacy tests stay side-effect free)."""
        if self.scopes is None:
            return
        member = self._team_user(update)
        chat = getattr(update, "effective_chat", None)
        chat_id = getattr(chat, "id", None)
        scope_label = self._scope_label(chat_id)
        if action is None:
            action = self._inbound_action(update)
        bypass = False
        if member is not None:
            role = self.policy.get_role(member.role)
            bypass = bool(role and role.bypass_safety)
        log.info("[scope:%s] %s by %s%s", scope_label, action,
                 attribution_label(member),
                 f" DENIED: {reason}" if denied else "")
        try:
            from aipager import audit as audit_mod
            audit_mod.append(
                session="-", label="-", action=action,
                user_id=getattr(member, "id", None),
                username=getattr(member, "label", ""),
                scope_label=scope_label, scope_chat_id=chat_id,
                denied=denied, reason=reason, bypass_safety=bypass,
            )
        except Exception:
            log.debug("audit_event append failed", exc_info=True)

    def _tool_auto_denied(self, sess: TrackedSession, tool_name: str) -> bool:
        """Scope/policy version of the team-mode ``deny_tools`` auto-deny.

        True iff the session's last driver's effective deny set
        (scope-level ∪ role ∪ per-user) blocks ``tool_name``. Owner/
        admin roles (``bypass_role_denies``) are exempt. This is only
        the tool-name auto-deny that team mode already had — the full
        path/bash/origin safety enforcement is Phase E.
        """
        if self.scopes is None or not tool_name:
            return False
        scope = self._scope_for(sess.scope_chat_id)
        member = self._driver_user(sess)
        if member is None:
            # Unknown driver → apply only the scope-wide deny list.
            return bool(scope and tool_name in scope.deny_tools)
        role = self.policy.get_role(member.role)
        if role and role.bypass_role_denies:
            return False
        denies: set[str] = set()
        if scope:
            denies |= set(scope.deny_tools)
        if role:
            denies |= set(role.deny_tools)
        denies |= set(getattr(member, "deny_tools", ()))
        return tool_name in denies

    def _team_user(self, update: Update):
        """Resolve the Telegram sender to a member/user, or None.

        Scope mode (``self.scopes`` set): the ``scope.Member`` for the
        sender within the message's scope. Legacy mode: the
        ``team.User`` from the allow-list (None in personal mode).
        """
        if self.scopes is not None:
            tg_user = update.effective_user
            if tg_user is None:
                return None
            chat = update.effective_chat
            return self._member_in_scope(
                self._scope_for(chat.id if chat else None), tg_user.id)
        if self.team is None:
            return None
        tg_user = update.effective_user
        if tg_user is None:
            return None
        return self.team.get(tg_user.id)

    async def _authorize(
        self, update: Update, *, allow_read_only: bool = False,
    ) -> bool:
        """Return True iff the message's sender is allowed to act.

        Personal mode: always True (chat filter already gated it).
        Team mode: True iff the sender is on the allow-list AND
        either ``allow_read_only`` or their role is not READ_ONLY.

        On rejection, sends a one-shot polite reply explaining why,
        then silently ignores subsequent messages from that user
        until daemon restart.
        """
        if self.scopes is not None:
            return await self._authorize_scoped(
                update, allow_read_only=allow_read_only)

        if self.team is None:
            return True

        tg_user = update.effective_user
        if tg_user is None:
            return False  # malformed update, ignore

        member = self.team.get(tg_user.id)
        if member is None:
            # Not on the allow-list. Two things happen:
            #   1. Persist the identity to ~/.claude/aipager-pending-users.json
            #      so the admin can review + approve later via the wizard
            #      (no scrolling chat / grep'ing logs).
            #   2. Log at INFO level + send one-shot in-chat reply.
            handle = tg_user.username or ""
            display = (tg_user.first_name or "") + (
                f" {tg_user.last_name}" if tg_user.last_name else ""
            )
            chat = update.effective_chat
            chat_id = chat.id if chat is not None else None
            try:
                record_pending_user(
                    tg_user.id,
                    username=handle,
                    display_name=display.strip(),
                    chat_id=chat_id,
                )
            except Exception:
                log.debug("record_pending_user failed", exc_info=True)

            already_seen = remember_unauthorized(tg_user.id)
            log.info(
                "unauthorized user %s mentioned the bot (id=%d, name=%r) "
                "— %s",
                f"@{handle}" if handle else "(no handle)",
                tg_user.id,
                display.strip(),
                "already replied earlier" if already_seen
                else "sending one-shot reply",
            )
            if not already_seen:
                msg = update.effective_message
                if msg is not None:
                    try:
                        await msg.reply_text(
                            "🚫 You're not on this bot's allow-list. "
                            "Ask an admin to add your Telegram user ID "
                            f"({tg_user.id}) to ~/.config/aipager/team.yaml — "
                            "or `aipager config` → Review pending users.",
                        )
                    except Exception:
                        log.debug("reply to unauthorized user failed", exc_info=True)
            return False

        if member.role == Role.READ_ONLY and not allow_read_only:
            msg = update.effective_message
            if msg is not None:
                try:
                    await msg.reply_text(
                        f"👀 {attribution_label(member)} — your role is "
                        "<i>read_only</i>; you can use <code>/status</code> "
                        "but can't drive sessions.",
                        parse_mode="HTML",
                    )
                except Exception:
                    log.debug("reply to read-only user failed", exc_info=True)
            return False

        return True

    async def _authorize_scoped(
        self, update: Update, *, allow_read_only: bool = False,
    ) -> bool:
        """Scope-aware authorization (Phase C). True iff the sender is a
        member of the scope this message belongs to and may act."""
        tg_user = update.effective_user
        chat = update.effective_chat
        if tg_user is None or chat is None:
            return False

        scope = self._scope_for(chat.id)
        if scope is None:
            # Unknown chat. Groups: silent (someone added the bot to a
            # group we don't serve). DMs (positive chat_id): one polite
            # reply so the person knows to ask the operator.
            if chat.id > 0 and not remember_unauthorized(tg_user.id):
                msg = update.effective_message
                if msg is not None:
                    try:
                        await msg.reply_text(
                            "🚫 This bot isn't configured to talk to you. "
                            f"Ask the operator to add your Telegram user ID "
                            f"({tg_user.id}) via `aipager config`.",
                        )
                    except Exception:
                        log.debug("reply to unknown-DM user failed", exc_info=True)
            self._audit_event(update, denied=True, reason="unknown-chat")
            return False

        member = self._member_in_scope(scope, tg_user.id)
        if member is None:
            handle = tg_user.username or ""
            display = (tg_user.first_name or "") + (
                f" {tg_user.last_name}" if tg_user.last_name else ""
            )
            try:
                record_pending_user(
                    tg_user.id, username=handle,
                    display_name=display.strip(), chat_id=chat.id,
                )
            except Exception:
                log.debug("record_pending_user failed", exc_info=True)
            if not remember_unauthorized(tg_user.id):
                msg = update.effective_message
                if msg is not None:
                    try:
                        await msg.reply_text(
                            "🚫 You're not on this scope's allow-list. "
                            f"Ask the operator to add your Telegram user ID "
                            f"({tg_user.id}) via `aipager config`.",
                        )
                    except Exception:
                        log.debug("reply to non-member failed", exc_info=True)
            self._audit_event(update, denied=True, reason="not-a-member")
            return False

        if not self._role_can_prompt(member) and not allow_read_only:
            msg = update.effective_message
            if msg is not None:
                try:
                    await msg.reply_text(
                        f"👀 {attribution_label(member)} — your role is "
                        f"<i>{html_mod.escape(member.role)}</i>; you can use "
                        "<code>/status</code> but can't drive sessions.",
                        parse_mode="HTML",
                    )
                except Exception:
                    log.debug("reply to read-only member failed", exc_info=True)
            self._audit_event(update, denied=True, reason="read-only")
            return False

        self._audit_event(update, denied=False)
        return True

    async def _auto_deny(
        self,
        sess: TrackedSession,
        tool_info: dict,
        triggerer: TeamUser | None,
    ) -> None:
        """Auto-deny a tool prompt via the same key-injection path the
        ``[❌ Deny]`` button uses. Called when a team rule matches.

        Posts a one-line notice in the chat naming the rule and the
        triggering user. Writes a structured audit record. Returns the
        session to BUSY so the next claude tick proceeds normally.
        """
        tool_name = tool_info.get("name", "?")
        summary = tool_info.get("summary", "")[:120]

        # Inject Down + Enter — same sequence the Deny button uses to
        # walk claude's "Allow / Deny" picker.
        ok = await inject.send_keys(sess.name, "Down")
        if ok:
            await asyncio.sleep(0.1)
            ok = await inject.send_keys(sess.name, "Enter")
        if not ok:
            log.warning(
                "[%s] auto-deny key injection failed for %s",
                sess.label, tool_name,
            )

        # Restore BUSY (claude is proceeding past the denied prompt).
        self.registry.transition(sess.name, Status.BUSY)
        sess.pending_permission = None

        by_attr = (
            f" (triggered by {attribution_label(triggerer)})"
            if triggerer is not None
            else ""
        )
        try:
            await self._app.bot.send_message(
                CHAT_ID,
                f"⛔ <b>{html_mod.escape(sess.label)}</b> · "
                f"Auto-denied · {html_mod.escape(tool_name)} · "
                f"per rules.deny_tools{html_mod.escape(by_attr)}\n"
                f"<i>{html_mod.escape(summary)}</i>",
                parse_mode="HTML",
                reply_to_message_id=(sess.busy_msg_id
                                     if sess.busy_msg_id and sess.busy_msg_id > 0
                                     else None),
            )
        except Exception:
            log.debug(
                "[%s] auto-deny chat message failed", sess.label,
                exc_info=True,
            )

        try:
            from aipager import audit as audit_mod
            audit_mod.append(
                session=sess.name, label=sess.label,
                action="Auto-denied",
                tool=tool_name,
                summary=summary,
                user_id=triggerer.id if triggerer else None,
                username=triggerer.label if triggerer else "",
                scope_label=self._scope_label(sess.scope_chat_id),
                scope_chat_id=sess.scope_chat_id or None,
                denied=True, reason="deny_tools",
            )
        except Exception:
            log.debug("[%s] auto-deny audit failed", sess.label, exc_info=True)

        log.info(
            "[%s] auto-denied %s per rules.deny_tools (triggerer=%s)",
            sess.label, tool_name,
            triggerer.label if triggerer else "unknown",
        )

    def _mark_driver(
        self, sess: TrackedSession, update: Update,
    ) -> TeamUser | None:
        """Record the message sender as the session's last driver.

        Personal-mode no-op (returns ``None``). In team mode, sets
        ``sess.last_driver_user_id`` and (if first-touch) also
        ``sess.created_by_user_id``. The returned :class:`team.User`
        is used by callers to attribute prompts and audit records.
        """
        if self.scopes is not None:
            tg_user = update.effective_user
            if tg_user is None:
                return None
            member = self._member_anywhere(tg_user.id)
            if member is None:
                return None
            sess.last_driver_user_id = member.id
            if sess.created_by_user_id is None:
                sess.created_by_user_id = member.id
            return member
        if self.team is None:
            return None
        tg_user = update.effective_user
        if tg_user is None:
            return None
        member = self.team.get(tg_user.id)
        if member is None:
            return None
        sess.last_driver_user_id = member.id
        if sess.created_by_user_id is None:
            sess.created_by_user_id = member.id
        return member

    def _driver_user(self, sess: TrackedSession) -> TeamUser | None:
        """Resolve a session's ``last_driver_user_id`` to a ``TeamUser``.

        Returns ``None`` if no driver is recorded, the team isn't
        loaded, or the driver was removed from the allow-list since
        their last interaction.
        """
        if self.scopes is not None:
            if sess.last_driver_user_id is None:
                return None
            return self._member_anywhere(sess.last_driver_user_id)
        if self.team is None or sess.last_driver_user_id is None:
            return None
        return self.team.get(sess.last_driver_user_id)

    async def _authorize_callback(self, query) -> TeamUser | None:
        """Allow-list check for inline-keyboard taps.

        Returns the matching ``team.User`` on success, or ``None`` on
        rejection (in which case a Telegram toast is shown to the
        user via ``answer``). Personal mode returns a synthetic
        sentinel — never ``None`` — so callers can keep their
        existing flow.
        """
        if self.scopes is not None:
            tg_user = query.from_user
            if tg_user is None:
                return None
            chat = getattr(query, "message", None)
            chat_id = getattr(getattr(chat, "chat", None), "id", None)
            member = self._member_in_scope(self._scope_for(chat_id), tg_user.id)
            if member is None:
                try:
                    await query.answer("Not on the allow-list", show_alert=True)
                except Exception:
                    log.debug("toast to unauthorized callback failed", exc_info=True)
                return None
            return member

        if self.team is None:
            return _PERSONAL_MODE_SENTINEL

        tg_user = query.from_user
        if tg_user is None:
            return None

        member = self.team.get(tg_user.id)
        if member is None:
            try:
                await query.answer(
                    "Not on the allow-list", show_alert=True,
                )
            except Exception:
                log.debug("toast to unauthorized callback failed", exc_info=True)
            return None
        return member
