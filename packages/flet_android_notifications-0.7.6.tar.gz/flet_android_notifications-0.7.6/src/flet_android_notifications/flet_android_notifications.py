from datetime import datetime
import json
import flet as ft
from typing import Optional, Union


class NotificationError(Exception):
    """Raised when a notification operation fails on the native side."""

    pass


class BigTextStyle:
    """Expandable big text notification style.

    When the notification is expanded, shows the full big_text content
    instead of the truncated body.
    """

    def __init__(
        self,
        big_text: str,
        *,
        content_title: Optional[str] = None,
        summary_text: Optional[str] = None,
    ):
        self.big_text = big_text
        self.content_title = content_title
        self.summary_text = summary_text

    def to_dict(self) -> dict:
        return {
            "type": "big_text",
            "big_text": self.big_text,
            "content_title": self.content_title,
            "summary_text": self.summary_text,
        }


class BigPictureStyle:
    """Notification style that shows a large image when expanded.

    Provide exactly one of file_path or drawable_resource for the main image.
    Optionally provide a large icon via large_icon_file_path or large_icon_drawable_resource.
    """

    def __init__(
        self,
        *,
        file_path: Optional[str] = None,
        drawable_resource: Optional[str] = None,
        content_title: Optional[str] = None,
        summary_text: Optional[str] = None,
        large_icon_file_path: Optional[str] = None,
        large_icon_drawable_resource: Optional[str] = None,
        hide_expanded_large_icon: bool = False,
    ):
        if file_path and drawable_resource:
            raise ValueError("provide exactly one of file_path or drawable_resource, not both")
        if not file_path and not drawable_resource:
            raise ValueError("provide exactly one of file_path or drawable_resource")
        self.file_path = file_path
        self.drawable_resource = drawable_resource
        self.content_title = content_title
        self.summary_text = summary_text
        self.large_icon_file_path = large_icon_file_path
        self.large_icon_drawable_resource = large_icon_drawable_resource
        self.hide_expanded_large_icon = hide_expanded_large_icon

    def to_dict(self) -> dict:
        bitmap_type = "file_path" if self.file_path else "drawable_resource"
        bitmap_value = self.file_path or self.drawable_resource
        d = {
            "type": "big_picture",
            "bitmap_type": bitmap_type,
            "bitmap_value": bitmap_value,
            "content_title": self.content_title,
            "summary_text": self.summary_text,
            "hide_expanded_large_icon": self.hide_expanded_large_icon,
        }
        if self.large_icon_file_path:
            d["large_icon_type"] = "file_path"
            d["large_icon_value"] = self.large_icon_file_path
        elif self.large_icon_drawable_resource:
            d["large_icon_type"] = "drawable_resource"
            d["large_icon_value"] = self.large_icon_drawable_resource
        return d


class InboxStyle:
    """Notification style that shows a list of text lines when expanded."""

    def __init__(
        self,
        lines: list[str],
        *,
        content_title: Optional[str] = None,
        summary_text: Optional[str] = None,
    ):
        self.lines = lines
        self.content_title = content_title
        self.summary_text = summary_text

    def to_dict(self) -> dict:
        return {
            "type": "inbox",
            "lines": self.lines,
            "content_title": self.content_title,
            "summary_text": self.summary_text,
        }


NotificationStyle = Union[BigTextStyle, BigPictureStyle, InboxStyle]


_VALID_VISIBILITIES = {"public", "private", "secret"}

_VALID_IMPORTANCES = {"none", "min", "low", "default", "high", "max"}

_VALID_GROUP_ALERT_BEHAVIORS = {"all", "summary", "children"}

_VALID_SCHEDULE_MODES = {
    "alarm_clock", "exact", "exact_allow_while_idle", "inexact", "inexact_allow_while_idle",
}

_VALID_REPEAT_INTERVALS = {"every_minute", "hourly", "daily", "weekly"}

_VALID_MATCH_COMPONENTS = {"time", "day_of_week_and_time", "day_of_month_and_time", "date_and_time"}

_VALID_LARGE_ICON_TYPES = {"drawable_resource", "file_path"}

_VALID_START_TYPES = {
    "start_sticky", "start_not_sticky", "start_sticky_compatibility", "start_redeliver_intent",
}

_VALID_CATEGORIES = {
    "alarm", "call", "email", "error", "event", "message", "navigation",
    "progress", "promo", "recommendation", "reminder", "service", "social",
    "status", "stopwatch", "transport", "workout",
}

_VALID_FOREGROUND_SERVICE_TYPES = {
    "data_sync", "media_playback", "phone_call", "location", "connected_device",
    "media_projection", "camera", "microphone", "health", "remote_messaging",
    "system_exempted", "short_service", "special_use",
}


def _validate_enum(value: str, valid: set, name: str) -> None:
    if value not in valid:
        raise ValueError(f"{name} must be one of {sorted(valid)}, got: {value!r}")


def _validate_visibility(visibility: str) -> None:
    """Validate visibility is one of public, private, secret."""
    _validate_enum(visibility, _VALID_VISIBILITIES, "visibility")


def _validate_color_hex(color: str) -> None:
    """Validate a hex color string like '#FF5722' or '#80FF5722'."""
    if not color.startswith("#"):
        raise ValueError(f"color must start with '#', got: {color!r}")
    hex_part = color[1:]
    if len(hex_part) not in (6, 8):
        raise ValueError(f"color must be 6 or 8 hex digits after '#', got: {color!r}")
    try:
        int(hex_part, 16)
    except ValueError:
        raise ValueError(f"color contains invalid hex characters: {color!r}")


@ft.control("flet_android_notifications")
class FletAndroidNotifications(ft.Service):
    on_notification_tap: Optional[ft.ControlEventHandler["FletAndroidNotifications"]] = None

    def _check_error(self, result):
        """Check if Dart returned an error and raise if so."""
        if isinstance(result, str) and result.startswith("error:"):
            raise NotificationError(result[6:])
        return result

    async def show_notification(
        self,
        notification_id: int,
        title: str,
        body: str,
        *,
        payload: str = "",
        actions: Optional[list[dict]] = None,
        channel_id: str = "flet_notifications",
        channel_name: str = "Flet Notifications",
        channel_description: str = "Notifications from Flet app",
        importance: str = "high",
        play_sound: bool = True,
        enable_vibration: bool = True,
        style: Optional[NotificationStyle] = None,
        show_progress: bool = False,
        max_progress: int = 0,
        progress: int = 0,
        indeterminate: bool = False,
        group_key: Optional[str] = None,
        set_as_group_summary: bool = False,
        group_alert_behavior: str = "all",
        icon: Optional[str] = None,
        large_icon: Optional[str] = None,
        large_icon_type: str = "drawable_resource",
        color: Optional[str] = None,
        colorized: bool = False,
        sound: Optional[str] = None,
        ongoing: bool = False,
        auto_cancel: bool = True,
        silent: bool = False,
        only_alert_once: bool = False,
        visibility: Optional[str] = None,
        sub_text: Optional[str] = None,
        channel_bypass_dnd: bool = False,
        vibration_pattern: Optional[list[int]] = None,
        timeout_after: Optional[int] = None,
        category: Optional[str] = None,
    ):
        """Show an Android notification.

        Args:
            notification_id: Unique integer ID for this notification.
            title: Notification title.
            body: Notification body text.
            payload: Arbitrary string returned in on_notification_tap event.
            actions: List of action buttons shown on the notification. Each is
                a dict with "id" and "title" keys, plus optional
                "cancel_notification" (bool, default True) and
                "shows_user_interface" (bool, default True). Example:
                [{"id": "approve", "title": "Approve"},
                 {"id": "snooze", "title": "Snooze", "cancel_notification": False}].
                The tapped action's id is returned as "action_id" in the
                on_notification_tap event data (JSON string).
            channel_id: Android notification channel ID.
            channel_name: Human-readable channel name (shown in system settings).
            channel_description: Channel description (shown in system settings).
            importance: One of "none", "min", "low", "default", "high", "max".
            play_sound: Whether to play the default notification sound.
            enable_vibration: Whether to vibrate on notification.
            style: Notification style (BigTextStyle, BigPictureStyle, or InboxStyle).
            show_progress: Whether to show a progress bar.
            max_progress: Maximum progress value (0 = indeterminate when show_progress is True).
            progress: Current progress value.
            indeterminate: Whether the progress bar is indeterminate.
            group_key: Group key for bundling notifications together.
            set_as_group_summary: If True, this notification is the group
                summary. You must manage summary lifecycle yourself.
            group_alert_behavior: "all", "summary", or "children".
            icon: Drawable resource name for the small status bar icon
                (e.g. "ic_notification"). None = app launcher icon. Must
                be a compiled Android drawable, not a file path. Android
                renders small icons as single-color silhouettes.
            large_icon: Large icon shown on the notification's right side.
                Interpreted according to large_icon_type.
            large_icon_type: "drawable_resource" (default) or "file_path".
            color: Hex color string (e.g. "#FF5722" or "#80FF5722"). Sets
                the accent color, which also tints the small icon.
            colorized: When True, applies color as background. Only works
                on foreground service / media-style notifications.
            sound: Raw resource name (e.g. "alert_tone" for
                res/raw/alert_tone.mp3). Omit file extension. The sound
                is permanently bound to the channel at creation — changing
                it later requires a different channel_id.
            ongoing: Persistent notification that can't be swiped away.
            auto_cancel: Dismiss notification when tapped. Default True.
            silent: Suppress sound and vibration.
            only_alert_once: Only alert (sound/vibration) on the first
                show; updates are silent.
            visibility: Lock screen visibility. One of "public" (show
                full content), "private" (hide sensitive content), or
                "secret" (don't show on lock screen at all).
            sub_text: Small text shown below the notification content.
            channel_bypass_dnd: Allow the notification channel to bypass
                do-not-disturb mode. Only takes effect when the channel
                is first created.
            vibration_pattern: Custom vibration pattern as a list of
                millisecond durations, e.g. [0, 500, 200, 500].
            timeout_after: Auto-dismiss the notification after this many
                milliseconds. None means no timeout.

        Raises:
            NotificationError: If the native side reports an error.
        """
        _validate_enum(importance, _VALID_IMPORTANCES, "importance")
        _validate_enum(group_alert_behavior, _VALID_GROUP_ALERT_BEHAVIORS, "group_alert_behavior")
        if large_icon is not None:
            _validate_enum(large_icon_type, _VALID_LARGE_ICON_TYPES, "large_icon_type")
        if color is not None:
            _validate_color_hex(color)
        if visibility is not None:
            _validate_visibility(visibility)
        if category is not None:
            _validate_enum(category, _VALID_CATEGORIES, "category")
        result = await self._invoke_method(
            method_name="show_notification",
            arguments={
                "id": notification_id,
                "title": title,
                "body": body,
                "payload": payload,
                "actions": actions or [],
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_description": channel_description,
                "importance": importance,
                "play_sound": play_sound,
                "enable_vibration": enable_vibration,
                "style": style.to_dict() if style else None,
                "show_progress": show_progress,
                "max_progress": max_progress,
                "progress": progress,
                "indeterminate": indeterminate,
                "group_key": group_key,
                "set_as_group_summary": set_as_group_summary,
                "group_alert_behavior": group_alert_behavior,
                "icon": icon,
                "large_icon": large_icon,
                "large_icon_type": large_icon_type,
                "color": color,
                "colorized": colorized,
                "sound": sound,
                "ongoing": ongoing,
                "auto_cancel": auto_cancel,
                "silent": silent,
                "only_alert_once": only_alert_once,
                "visibility": visibility,
                "sub_text": sub_text,
                "channel_bypass_dnd": channel_bypass_dnd,
                "vibration_pattern": vibration_pattern,
                "timeout_after": timeout_after,
                "category": category,
            },
        )
        return self._check_error(result)

    async def schedule_notification(
        self,
        notification_id: int,
        title: str,
        body: str,
        scheduled_time: datetime,
        *,
        payload: str = "",
        actions: Optional[list[dict]] = None,
        channel_id: str = "flet_notifications",
        channel_name: str = "Flet Notifications",
        channel_description: str = "Notifications from Flet app",
        importance: str = "high",
        play_sound: bool = True,
        enable_vibration: bool = True,
        schedule_mode: str = "inexact_allow_while_idle",
        match_date_time_components: Optional[str] = None,
        style: Optional[NotificationStyle] = None,
        show_progress: bool = False,
        max_progress: int = 0,
        progress: int = 0,
        indeterminate: bool = False,
        group_key: Optional[str] = None,
        set_as_group_summary: bool = False,
        group_alert_behavior: str = "all",
        icon: Optional[str] = None,
        large_icon: Optional[str] = None,
        large_icon_type: str = "drawable_resource",
        color: Optional[str] = None,
        colorized: bool = False,
        sound: Optional[str] = None,
        ongoing: bool = False,
        auto_cancel: bool = True,
        silent: bool = False,
        only_alert_once: bool = False,
        visibility: Optional[str] = None,
        sub_text: Optional[str] = None,
        channel_bypass_dnd: bool = False,
        vibration_pattern: Optional[list[int]] = None,
        timeout_after: Optional[int] = None,
        category: Optional[str] = None,
    ):
        """Schedule an Android notification for a future time.

        Uses Android's AlarmManager via zonedSchedule(). The notification
        fires even if the app is killed or the device restarts (if the
        required BroadcastReceivers are registered in AndroidManifest.xml).

        Args:
            notification_id: Unique integer ID for this notification.
            title: Notification title.
            body: Notification body text.
            scheduled_time: When to fire. If naive (no tzinfo), treated as
                local time. If timezone-aware, converted to UTC internally.
            payload: Arbitrary string returned in on_notification_tap event.
            actions: List of action buttons, each {"id": "...", "title": "..."}.
                Optional keys: "cancel_notification" (bool, default True),
                "shows_user_interface" (bool, default True).
            channel_id: Android notification channel ID.
            channel_name: Human-readable channel name.
            channel_description: Channel description.
            importance: One of "none", "min", "low", "default", "high", "max".
            play_sound: Whether to play the default notification sound.
            enable_vibration: Whether to vibrate on notification.
            schedule_mode: One of "alarm_clock", "exact",
                "exact_allow_while_idle", "inexact",
                "inexact_allow_while_idle" (default). Exact modes require
                SCHEDULE_EXACT_ALARM permission.
            match_date_time_components: For recurring notifications. One of
                "time" (daily), "day_of_week_and_time" (weekly),
                "day_of_month_and_time" (monthly), "date_and_time" (yearly),
                or None (one-shot, default).
            style: Notification style (BigTextStyle, BigPictureStyle, or InboxStyle).
            show_progress: Whether to show a progress bar.
            max_progress: Maximum progress value (0 = indeterminate when show_progress is True).
            progress: Current progress value.
            indeterminate: Whether the progress bar is indeterminate.
            group_key: Group key for bundling notifications together.
            set_as_group_summary: If True, this notification is the group
                summary. You must manage summary lifecycle yourself.
            group_alert_behavior: "all", "summary", or "children".
            icon: Drawable resource name for the small status bar icon
                (e.g. "ic_notification"). None = app launcher icon. Must
                be a compiled Android drawable, not a file path. Android
                renders small icons as single-color silhouettes.
            large_icon: Large icon shown on the notification's right side.
                Interpreted according to large_icon_type.
            large_icon_type: "drawable_resource" (default) or "file_path".
            color: Hex color string (e.g. "#FF5722" or "#80FF5722"). Sets
                the accent color, which also tints the small icon.
            colorized: When True, applies color as background. Only works
                on foreground service / media-style notifications.
            sound: Raw resource name (e.g. "alert_tone" for
                res/raw/alert_tone.mp3). Omit file extension. The sound
                is permanently bound to the channel at creation — changing
                it later requires a different channel_id.
            ongoing: Persistent notification that can't be swiped away.
            auto_cancel: Dismiss notification when tapped. Default True.
            silent: Suppress sound and vibration.
            only_alert_once: Only alert (sound/vibration) on the first
                show; updates are silent.
            visibility: Lock screen visibility. One of "public" (show
                full content), "private" (hide sensitive content), or
                "secret" (don't show on lock screen at all).
            sub_text: Small text shown below the notification content.
            channel_bypass_dnd: Allow the notification channel to bypass
                do-not-disturb mode. Only takes effect when the channel
                is first created.
            vibration_pattern: Custom vibration pattern as a list of
                millisecond durations, e.g. [0, 500, 200, 500].
            timeout_after: Auto-dismiss the notification after this many
                milliseconds. None means no timeout.

        Raises:
            NotificationError: If the native side reports an error.
        """
        _validate_enum(importance, _VALID_IMPORTANCES, "importance")
        _validate_enum(group_alert_behavior, _VALID_GROUP_ALERT_BEHAVIORS, "group_alert_behavior")
        _validate_enum(schedule_mode, _VALID_SCHEDULE_MODES, "schedule_mode")
        if match_date_time_components is not None:
            _validate_enum(match_date_time_components, _VALID_MATCH_COMPONENTS, "match_date_time_components")
        if large_icon is not None:
            _validate_enum(large_icon_type, _VALID_LARGE_ICON_TYPES, "large_icon_type")
        if color is not None:
            _validate_color_hex(color)
        if visibility is not None:
            _validate_visibility(visibility)
        if category is not None:
            _validate_enum(category, _VALID_CATEGORIES, "category")
        epoch_ms = int(scheduled_time.timestamp() * 1000)
        result = await self._invoke_method(
            method_name="schedule_notification",
            arguments={
                "id": notification_id,
                "title": title,
                "body": body,
                "scheduled_epoch_ms": epoch_ms,
                "payload": payload,
                "actions": actions or [],
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_description": channel_description,
                "importance": importance,
                "play_sound": play_sound,
                "enable_vibration": enable_vibration,
                "schedule_mode": schedule_mode,
                "match_date_time_components": match_date_time_components,
                "style": style.to_dict() if style else None,
                "show_progress": show_progress,
                "max_progress": max_progress,
                "progress": progress,
                "indeterminate": indeterminate,
                "group_key": group_key,
                "set_as_group_summary": set_as_group_summary,
                "group_alert_behavior": group_alert_behavior,
                "icon": icon,
                "large_icon": large_icon,
                "large_icon_type": large_icon_type,
                "color": color,
                "colorized": colorized,
                "sound": sound,
                "ongoing": ongoing,
                "auto_cancel": auto_cancel,
                "silent": silent,
                "only_alert_once": only_alert_once,
                "visibility": visibility,
                "sub_text": sub_text,
                "channel_bypass_dnd": channel_bypass_dnd,
                "vibration_pattern": vibration_pattern,
                "timeout_after": timeout_after,
                "category": category,
            },
        )
        return self._check_error(result)

    async def periodically_show(
        self,
        notification_id: int,
        title: str,
        body: str,
        repeat_interval: str,
        *,
        payload: str = "",
        actions: Optional[list[dict]] = None,
        channel_id: str = "flet_notifications",
        channel_name: str = "Flet Notifications",
        channel_description: str = "Notifications from Flet app",
        importance: str = "high",
        play_sound: bool = True,
        enable_vibration: bool = True,
        style: Optional[NotificationStyle] = None,
        show_progress: bool = False,
        max_progress: int = 0,
        progress: int = 0,
        indeterminate: bool = False,
        group_key: Optional[str] = None,
        set_as_group_summary: bool = False,
        group_alert_behavior: str = "all",
        icon: Optional[str] = None,
        large_icon: Optional[str] = None,
        large_icon_type: str = "drawable_resource",
        color: Optional[str] = None,
        colorized: bool = False,
        sound: Optional[str] = None,
        ongoing: bool = False,
        auto_cancel: bool = True,
        silent: bool = False,
        only_alert_once: bool = False,
        visibility: Optional[str] = None,
        sub_text: Optional[str] = None,
        channel_bypass_dnd: bool = False,
        vibration_pattern: Optional[list[int]] = None,
        timeout_after: Optional[int] = None,
        category: Optional[str] = None,
    ):
        """Show a notification that repeats at a fixed interval.

        Args:
            notification_id: Unique integer ID for this notification.
            title: Notification title.
            body: Notification body text.
            repeat_interval: One of "every_minute", "hourly", "daily", "weekly".
            payload: Arbitrary string returned in on_notification_tap event.
            timeout_after: Auto-dismiss after this many milliseconds.
            (All other params are the same as show_notification.)

        Raises:
            NotificationError: If the native side reports an error.
        """
        _validate_enum(importance, _VALID_IMPORTANCES, "importance")
        _validate_enum(group_alert_behavior, _VALID_GROUP_ALERT_BEHAVIORS, "group_alert_behavior")
        _validate_enum(repeat_interval, _VALID_REPEAT_INTERVALS, "repeat_interval")
        if large_icon is not None:
            _validate_enum(large_icon_type, _VALID_LARGE_ICON_TYPES, "large_icon_type")
        if color is not None:
            _validate_color_hex(color)
        if visibility is not None:
            _validate_visibility(visibility)
        if category is not None:
            _validate_enum(category, _VALID_CATEGORIES, "category")
        result = await self._invoke_method(
            method_name="periodically_show",
            arguments={
                "id": notification_id,
                "title": title,
                "body": body,
                "repeat_interval": repeat_interval,
                "payload": payload,
                "actions": actions or [],
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_description": channel_description,
                "importance": importance,
                "play_sound": play_sound,
                "enable_vibration": enable_vibration,
                "style": style.to_dict() if style else None,
                "show_progress": show_progress,
                "max_progress": max_progress,
                "progress": progress,
                "indeterminate": indeterminate,
                "group_key": group_key,
                "set_as_group_summary": set_as_group_summary,
                "group_alert_behavior": group_alert_behavior,
                "icon": icon,
                "large_icon": large_icon,
                "large_icon_type": large_icon_type,
                "color": color,
                "colorized": colorized,
                "sound": sound,
                "ongoing": ongoing,
                "auto_cancel": auto_cancel,
                "silent": silent,
                "only_alert_once": only_alert_once,
                "visibility": visibility,
                "sub_text": sub_text,
                "channel_bypass_dnd": channel_bypass_dnd,
                "vibration_pattern": vibration_pattern,
                "timeout_after": timeout_after,
                "category": category,
            },
        )
        return self._check_error(result)

    async def periodically_show_with_duration(
        self,
        notification_id: int,
        title: str,
        body: str,
        duration_seconds: Union[int, float],
        *,
        payload: str = "",
        actions: Optional[list[dict]] = None,
        channel_id: str = "flet_notifications",
        channel_name: str = "Flet Notifications",
        channel_description: str = "Notifications from Flet app",
        importance: str = "high",
        play_sound: bool = True,
        enable_vibration: bool = True,
        style: Optional[NotificationStyle] = None,
        show_progress: bool = False,
        max_progress: int = 0,
        progress: int = 0,
        indeterminate: bool = False,
        group_key: Optional[str] = None,
        set_as_group_summary: bool = False,
        group_alert_behavior: str = "all",
        icon: Optional[str] = None,
        large_icon: Optional[str] = None,
        large_icon_type: str = "drawable_resource",
        color: Optional[str] = None,
        colorized: bool = False,
        sound: Optional[str] = None,
        ongoing: bool = False,
        auto_cancel: bool = True,
        silent: bool = False,
        only_alert_once: bool = False,
        visibility: Optional[str] = None,
        sub_text: Optional[str] = None,
        channel_bypass_dnd: bool = False,
        vibration_pattern: Optional[list[int]] = None,
        timeout_after: Optional[int] = None,
        category: Optional[str] = None,
    ):
        """Show a notification that repeats at a custom duration.

        Args:
            notification_id: Unique integer ID for this notification.
            title: Notification title.
            body: Notification body text.
            duration_seconds: Repeat interval in seconds.
            payload: Arbitrary string returned in on_notification_tap event.
            timeout_after: Auto-dismiss after this many milliseconds.
            (All other params are the same as show_notification.)

        Raises:
            NotificationError: If the native side reports an error.
        """
        _validate_enum(importance, _VALID_IMPORTANCES, "importance")
        _validate_enum(group_alert_behavior, _VALID_GROUP_ALERT_BEHAVIORS, "group_alert_behavior")
        if large_icon is not None:
            _validate_enum(large_icon_type, _VALID_LARGE_ICON_TYPES, "large_icon_type")
        if color is not None:
            _validate_color_hex(color)
        if visibility is not None:
            _validate_visibility(visibility)
        if category is not None:
            _validate_enum(category, _VALID_CATEGORIES, "category")
        result = await self._invoke_method(
            method_name="periodically_show_with_duration",
            arguments={
                "id": notification_id,
                "title": title,
                "body": body,
                "duration_ms": int(duration_seconds * 1000),
                "payload": payload,
                "actions": actions or [],
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_description": channel_description,
                "importance": importance,
                "play_sound": play_sound,
                "enable_vibration": enable_vibration,
                "style": style.to_dict() if style else None,
                "show_progress": show_progress,
                "max_progress": max_progress,
                "progress": progress,
                "indeterminate": indeterminate,
                "group_key": group_key,
                "set_as_group_summary": set_as_group_summary,
                "group_alert_behavior": group_alert_behavior,
                "icon": icon,
                "large_icon": large_icon,
                "large_icon_type": large_icon_type,
                "color": color,
                "colorized": colorized,
                "sound": sound,
                "ongoing": ongoing,
                "auto_cancel": auto_cancel,
                "silent": silent,
                "only_alert_once": only_alert_once,
                "visibility": visibility,
                "sub_text": sub_text,
                "channel_bypass_dnd": channel_bypass_dnd,
                "vibration_pattern": vibration_pattern,
                "timeout_after": timeout_after,
                "category": category,
            },
        )
        return self._check_error(result)

    async def start_foreground_service(
        self,
        notification_id: int,
        title: str,
        body: str,
        *,
        payload: str = "",
        start_type: str = "start_sticky",
        foreground_service_types: Optional[list[str]] = None,
        actions: Optional[list[dict]] = None,
        channel_id: str = "flet_notifications",
        channel_name: str = "Flet Notifications",
        channel_description: str = "Notifications from Flet app",
        importance: str = "high",
        play_sound: bool = True,
        enable_vibration: bool = True,
        style: Optional[NotificationStyle] = None,
        show_progress: bool = False,
        max_progress: int = 0,
        progress: int = 0,
        indeterminate: bool = False,
        group_key: Optional[str] = None,
        set_as_group_summary: bool = False,
        group_alert_behavior: str = "all",
        icon: Optional[str] = None,
        large_icon: Optional[str] = None,
        large_icon_type: str = "drawable_resource",
        color: Optional[str] = None,
        colorized: bool = False,
        sound: Optional[str] = None,
        ongoing: bool = False,
        auto_cancel: bool = True,
        silent: bool = False,
        only_alert_once: bool = False,
        visibility: Optional[str] = None,
        sub_text: Optional[str] = None,
        channel_bypass_dnd: bool = False,
        vibration_pattern: Optional[list[int]] = None,
        timeout_after: Optional[int] = None,
        category: Optional[str] = None,
    ):
        """Start an Android foreground service with a persistent notification.

        Foreground services keep the app alive for long-running tasks (music,
        GPS, uploads). The notification cannot be swiped away and is not
        removed by cancel() — use stop_foreground_service() instead.

        Args:
            notification_id: Unique integer ID. Must not be 0 (Android constraint).
            title: Notification title.
            body: Notification body text.
            payload: Arbitrary string returned in on_notification_tap event.
            start_type: Service start type. One of "start_sticky" (default),
                "start_not_sticky", "start_sticky_compatibility",
                "start_redeliver_intent".
            foreground_service_types: List of foreground service types, e.g.
                ["special_use"]. Values: data_sync, media_playback, phone_call,
                location, connected_device, media_projection, camera, microphone,
                health, remote_messaging, system_exempted, short_service,
                special_use.
            (All other params are the same as show_notification.)

        Raises:
            ValueError: If notification_id is 0, or start_type/foreground_service_types invalid.
            NotificationError: If the native side reports an error.
        """
        if notification_id == 0:
            raise ValueError("notification_id must not be 0 for foreground services (Android constraint)")
        _validate_enum(importance, _VALID_IMPORTANCES, "importance")
        _validate_enum(group_alert_behavior, _VALID_GROUP_ALERT_BEHAVIORS, "group_alert_behavior")
        _validate_enum(start_type, _VALID_START_TYPES, "start_type")
        if foreground_service_types is not None:
            for fst in foreground_service_types:
                _validate_enum(fst, _VALID_FOREGROUND_SERVICE_TYPES, "foreground_service_type")
        if large_icon is not None:
            _validate_enum(large_icon_type, _VALID_LARGE_ICON_TYPES, "large_icon_type")
        if color is not None:
            _validate_color_hex(color)
        if visibility is not None:
            _validate_visibility(visibility)
        if category is not None:
            _validate_enum(category, _VALID_CATEGORIES, "category")
        result = await self._invoke_method(
            method_name="start_foreground_service",
            arguments={
                "id": notification_id,
                "title": title,
                "body": body,
                "payload": payload,
                "start_type": start_type,
                "foreground_service_types": foreground_service_types,
                "actions": actions or [],
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_description": channel_description,
                "importance": importance,
                "play_sound": play_sound,
                "enable_vibration": enable_vibration,
                "style": style.to_dict() if style else None,
                "show_progress": show_progress,
                "max_progress": max_progress,
                "progress": progress,
                "indeterminate": indeterminate,
                "group_key": group_key,
                "set_as_group_summary": set_as_group_summary,
                "group_alert_behavior": group_alert_behavior,
                "icon": icon,
                "large_icon": large_icon,
                "large_icon_type": large_icon_type,
                "color": color,
                "colorized": colorized,
                "sound": sound,
                "ongoing": ongoing,
                "auto_cancel": auto_cancel,
                "silent": silent,
                "only_alert_once": only_alert_once,
                "visibility": visibility,
                "sub_text": sub_text,
                "channel_bypass_dnd": channel_bypass_dnd,
                "vibration_pattern": vibration_pattern,
                "timeout_after": timeout_after,
                "category": category,
            },
        )
        return self._check_error(result)

    async def stop_foreground_service(self):
        """Stop the Android foreground service and remove its notification.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="stop_foreground_service",
        )
        return self._check_error(result)

    async def get_active_notifications(self) -> list[dict]:
        """Get all currently active (shown) notifications.

        Returns:
            List of dicts with keys: id, title, body, channel_id, payload.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="get_active_notifications",
        )
        self._check_error(result)
        try:
            return json.loads(result)
        except (json.JSONDecodeError, TypeError) as e:
            raise NotificationError(f"failed to parse response: {e}")

    async def get_pending_notifications(self) -> list[dict]:
        """Get all pending (scheduled) notification requests.

        Returns:
            List of dicts with keys: id, title, body, payload.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="get_pending_notifications",
        )
        self._check_error(result)
        try:
            return json.loads(result)
        except (json.JSONDecodeError, TypeError) as e:
            raise NotificationError(f"failed to parse response: {e}")

    async def cancel(self, notification_id: int):
        """Cancel a specific notification by ID.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="cancel",
            arguments={"id": notification_id},
        )
        return self._check_error(result)

    async def cancel_all(self):
        """Cancel all active notifications.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="cancel_all",
        )
        return self._check_error(result)

    async def request_permissions(self):
        """Request notification permissions (required on Android 13+).

        Returns:
            bool: True if granted, False if denied.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="request_permissions",
        )
        return self._check_error(result) == "true"

    async def request_exact_alarm_permission(self):
        """Request the SCHEDULE_EXACT_ALARM permission (Android 14+).

        Required before using exact schedule modes ("alarm_clock", "exact",
        "exact_allow_while_idle"). Inexact modes do not need this permission.

        Returns:
            bool: True if granted, False if denied.

        Raises:
            NotificationError: If the native side reports an error.
        """
        result = await self._invoke_method(
            method_name="request_exact_alarm_permission",
        )
        return self._check_error(result) == "true"
