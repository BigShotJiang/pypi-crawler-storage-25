import json
import tomllib
import unittest
from pathlib import Path
from click.testing import CliRunner
from unittest.mock import patch
from docs_kit.cli.__main__ import cli

DEFAULT_URL = "http://localhost:45139/sse"


class FakeDocsKitConfig:
    def __init__(self, data=None):
        self._data = data or {
            "embedding": {"provider": "fastembed", "model": "BAAI/bge-small-en-v1.5"},
            "vector_store": {
                "provider": "qdrant",
                "url": "",
                "collection_name": "knowledge_base",
                "local_path": ".docs-kit/qdrant",
            },
            "ingestion": {"chunk_size": 800, "chunk_overlap": 120, "bm25_model": "Qdrant/bm25"},
            "mcp": {"transport": "sse", "host": "localhost", "port": 45139},
        }
        vector_store = type("VectorStore", (), {})()
        vector_store.local_path = self._data["vector_store"]["local_path"]
        self.vector_store = vector_store

        mcp_data = self._data.get("mcp", {})
        mcp = type("Mcp", (), {})()
        mcp.host = mcp_data.get("host", "localhost")
        mcp.port = mcp_data.get("port", 45139)
        self.mcp = mcp

    def model_dump(self):
        self._data["vector_store"]["local_path"] = self.vector_store.local_path
        return self._data

    @classmethod
    def from_yaml(cls, path):
        import yaml

        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return cls(data)


class TestInstallCmd(unittest.TestCase):

    def test_install_claude_code_creates_settings(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertIn("Installed docs-kit", result.output)

    def test_install_writes_url_config(self):
        """install writes a url-based MCP entry instead of command/args."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                self.assertTrue(settings_file.exists())
                with open(settings_file) as f:
                    data = json.load(f)
                self.assertIn("mcpServers", data)
                self.assertIn("docs-kit", data["mcpServers"])
                entry = data["mcpServers"]["docs-kit"]
                self.assertEqual(entry["url"], DEFAULT_URL)
                self.assertNotIn("command", entry)
                self.assertNotIn("args", entry)

    def test_install_output_shows_url_and_serve_reminder(self):
        """install output tells the user the URL and how to start the server."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertIn(DEFAULT_URL, result.output)
                self.assertIn("docs-kit serve", result.output)

    def test_install_auto_discovers_config_yaml(self):
        """docs-kit.yaml in CWD is auto-discovered."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            config_file = Path(tmp_dir) / "docs-kit.yaml"
            config_file.write_text("vector_store:\n  local_path: .docs-kit/qdrant\n")
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"], catch_exceptions=False)
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                with open(settings_file) as f:
                    data = json.load(f)
                entry = data["mcpServers"]["docs-kit"]
                self.assertIn("url", entry)
                self.assertNotIn("command", entry)

    def test_install_warns_when_no_config_on_global_install(self):
        """Global install bootstraps a user config when no config is present."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertNotIn("Warning", result.output)
                self.assertIn("Created user config", result.output)
                user_config = fake_home / ".docs-kit" / "docs-kit.yaml"
                self.assertTrue(user_config.exists())
                settings_file = fake_home / ".claude" / "settings.json"
                with open(settings_file) as f:
                    data = json.load(f)
                entry = data["mcpServers"]["docs-kit"]
                self.assertEqual(entry["url"], DEFAULT_URL)

    def test_install_no_warning_on_project_install_without_config(self):
        """--project install does not warn about missing config (project-local is expected)."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            with patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertNotIn("Warning", result.output)

    def test_install_merges_with_existing_settings(self):
        """Existing mcpServers entries are preserved."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            settings_dir = fake_home / ".claude"
            settings_dir.mkdir(parents=True)
            settings_file = settings_dir / "settings.json"
            settings_file.write_text(json.dumps({
                "mcpServers": {"other-tool": {"command": "other", "args": []}}
            }))
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                with open(settings_file) as f:
                    data = json.load(f)
                self.assertIn("other-tool", data["mcpServers"])
                self.assertIn("docs-kit", data["mcpServers"])

    def test_install_project_flag_uses_local_path(self):
        """--project flag writes to .claude/settings.json in current dir."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            with patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = Path(tmp_dir) / ".claude" / "settings.json"
                self.assertTrue(settings_file.exists())

    def test_install_invalid_agent_rejected(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["install", "vscode"])
        self.assertNotEqual(result.exit_code, 0)

    def test_install_codex_writes_toml_url(self):
        """Codex install writes a URL entry in TOML config."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "codex"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".codex" / "config.toml"
                self.assertTrue(settings_file.exists())
                with open(settings_file, "rb") as f:
                    data = tomllib.load(f)
                self.assertIn("mcp_servers", data)
                self.assertIn("docs-kit", data["mcp_servers"])
                entry = data["mcp_servers"]["docs-kit"]
                self.assertEqual(entry["url"], DEFAULT_URL)
                self.assertNotIn("command", entry)

    def test_install_codex_aliases_use_same_config(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "codex-desktop"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertIn(".codex/config.toml", result.output)

    def test_install_project_does_not_bootstrap_user_config(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertFalse((fake_home / ".docs-kit" / "docs-kit.yaml").exists())

    def test_install_chatgpt_shows_remote_mcp_guidance(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["install", "chatgpt"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("does not use a local MCP config file", result.output)
        self.assertIn("Settings > Apps/Connectors", result.output)
