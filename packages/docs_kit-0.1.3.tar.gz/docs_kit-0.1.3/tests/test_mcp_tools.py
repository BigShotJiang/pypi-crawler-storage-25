"""
Tests for MCP server tool logic in docs_kit.mcp.server.

Strategy: create the FastMCP server with a mock DocsKitAgent, then call
`call_tool` directly (which FastMCP exposes) to exercise the registered tools
without spinning up a network transport.
"""
from __future__ import annotations

import json
import unittest
from unittest.mock import MagicMock

from docs_kit.core.models import RetrievedChunk
from docs_kit.mcp.server import _create_server


def _make_agent() -> MagicMock:
    agent = MagicMock()
    agent.query.return_value = [
        RetrievedChunk(source="docs/intro.md", chunk_index=0, text="Hello world", score=0.9)
    ]
    agent.list_sources.return_value = ["docs/intro.md", "docs/guide.md"]
    agent.get_collection_info.return_value = {"collection_exists": True, "points_count": 42}
    agent.get_document.return_value = "Original full document text"
    return agent


class TestMcpServerCreation(unittest.TestCase):
    def test_server_creates_without_error(self):
        agent = _make_agent()
        server = _create_server(agent)
        self.assertIsNotNone(server)

    def test_server_has_expected_tools(self):
        agent = _make_agent()
        server = _create_server(agent)
        tool_names = {t.name for t in server._tool_manager.list_tools()}
        self.assertIn("search_docs", tool_names)
        self.assertIn("list_sources", tool_names)
        self.assertIn("get_collection_info", tool_names)
        self.assertIn("get_full_document", tool_names)


class TestMcpToolLogic(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.agent = _make_agent()
        self.server = _create_server(self.agent)

    async def _call(self, name: str, **kwargs):
        """Helper: invoke a tool by name and return its text result."""
        result = await self.server.call_tool(name, kwargs)
        # FastMCP 1.x returns a tuple (content_list, structured_output_dict).
        # Unpack accordingly.
        content_list = result[0] if isinstance(result, tuple) else result
        return content_list[0].text if content_list else ""

    async def test_search_docs_returns_json_array(self):
        raw = await self._call("search_docs", query="hello", limit=3)
        data = json.loads(raw)
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["source"], "docs/intro.md")
        self.assertEqual(data[0]["chunk_index"], 0)
        self.assertAlmostEqual(data[0]["score"], 0.9)
        self.assertEqual(data[0]["text"], "Hello world")
        self.agent.query.assert_called_once_with("hello", limit=3)

    async def test_search_docs_default_limit(self):
        await self._call("search_docs", query="test")
        self.agent.query.assert_called_once_with("test", limit=5)

    async def test_list_sources_returns_json_array(self):
        raw = await self._call("list_sources")
        data = json.loads(raw)
        self.assertIsInstance(data, list)
        self.assertIn("docs/intro.md", data)
        self.assertIn("docs/guide.md", data)

    async def test_get_collection_info_returns_json_object(self):
        raw = await self._call("get_collection_info")
        data = json.loads(raw)
        self.assertIsInstance(data, dict)
        self.assertTrue(data["collection_exists"])
        self.assertEqual(data["points_count"], 42)

    async def test_get_full_document_returns_exact_text(self):
        raw = await self._call("get_full_document", source="docs/intro.md")
        self.assertEqual(raw, "Original full document text")
        self.agent.get_document.assert_called_once_with("docs/intro.md")

    async def test_get_full_document_missing_source(self):
        self.agent.get_document.return_value = None
        raw = await self._call("get_full_document", source="docs/missing.md")
        self.assertIn("No document found", raw)
        self.assertIn("docs/missing.md", raw)
