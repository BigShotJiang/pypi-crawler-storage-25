# docs-kit

[![PyPI version](https://img.shields.io/pypi/v/docs-kit)](https://pypi.org/project/docs-kit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python](https://img.shields.io/pypi/pyversions/docs-kit)](https://pypi.org/project/docs-kit/)
[![CI](https://github.com/docs-kit/docs-kit/actions/workflows/ci.yml/badge.svg)](https://github.com/docs-kit/docs-kit/actions/workflows/ci.yml)

Fetch docs from GitBook, Mintlify, or local files, embed them locally, and expose retrieval to AI tools over MCP.

No API keys are required for the default local embedding path.

## What it does

- Fetches public docs from GitBook and Mintlify sites via `llms-full.txt` / `llms.txt` (with sitemap.xml fallback for Mintlify)
- Ingests local `.md` and `.txt` files
- Stores vectors in local Qdrant by default
- Runs a **persistent background MCP server** on `http://localhost:45139/sse`
- All agents (Claude Code, Codex, Cursor) connect to the same server — no Qdrant lock conflicts
- Exposes MCP tools to ingest, remove, and list sources at runtime

## Install

The recommended install method is **`pipx`** — it puts `docs-kit` on your global PATH without touching your system Python or any project venv:

```bash
pipx install docs-kit
```

Install `pipx` first if you don't have it:

```bash
brew install pipx
pipx ensurepath   # adds ~/.local/bin to PATH
```

Or with plain `pip` (works, but binary won't be on global PATH unless you're in the right venv):

```bash
pip install docs-kit
```

## Quickstart

```bash
# 1. Install (once)
pipx install docs-kit

# 2. Ingest some docs
docs-kit ingest https://docs.elevenlabs.io

# 3. Start the shared MCP server (runs as a background daemon)
docs-kit serve

# 4. Install into your agents (they connect to the running server)
docs-kit install claude-code
docs-kit install codex

# 5. Use your agent — it can now search and ingest docs via MCP
```

To stop the server: `docs-kit stop`

## Shared Server Model

docs-kit runs as a **single persistent background daemon** that all your AI agents connect to over SSE:

```
docs-kit serve          ← one process, owns the Qdrant lock
      │
      ├── Claude Code   (http://localhost:45139/sse)
      ├── Codex CLI     (http://localhost:45139/sse)
      └── Cursor        (http://localhost:45139/sse)
```

This avoids Qdrant database lock conflicts that occur when each agent tries to spawn its own subprocess pointing at the same local database. Start it once, leave it running.

## Commands

### `docs-kit serve`

Start the MCP server as a background daemon on `http://localhost:45139/sse`.

```bash
docs-kit serve
docs-kit serve --port 45139
docs-kit serve --config ./docs-kit.yaml
```

The server daemonizes automatically — your shell prompt returns immediately. PID is written to `~/.docs-kit/docs-kit.pid` and logs go to `~/.docs-kit/serve.log`.

If the server is already running, `docs-kit serve` prints the PID and exits cleanly.

### `docs-kit stop`

Stop the running MCP server daemon.

```bash
docs-kit stop
```

### `docs-kit install <agent>`

Install docs-kit into a supported client's MCP config. The agent will connect to `http://localhost:45139/sse`.

```bash
docs-kit install claude-code
docs-kit install codex
docs-kit install claude-code --project
docs-kit install cursor --config ./docs-kit.yaml
```

Run `docs-kit serve` before using the agent.

If you run `docs-kit install <agent>` outside a project and omit `--config`, docs-kit creates `~/.docs-kit/docs-kit.yaml` automatically.

### `docs-kit init`

Create a project-local `docs-kit.yaml`.

```bash
docs-kit init
docs-kit init --dir ./sandbox
```

### `docs-kit ingest <path-or-url>`

Ingest a local file, directory, or documentation URL into the vector store. Supports GitBook and Mintlify sites out of the box — auto-detected by default.

```bash
docs-kit ingest ./docs
docs-kit ingest https://docs.example.com
docs-kit ingest https://docs.mintlify-site.com --provider mintlify
docs-kit ingest https://docs.gitbook-site.com --provider gitbook
docs-kit ingest ./docs --recreate
```

`--provider` accepts `auto` (default), `gitbook`, or `mintlify`. In `auto` mode, the fetcher tries `/llms-full.txt` → `/llms.txt` → `/sitemap.xml` in order.

### `docs-kit fetch <url>`

Download GitBook docs as Markdown without ingesting them.

```bash
docs-kit fetch https://docs.example.com
docs-kit fetch https://docs.example.com --output ./downloaded-docs
```

### `docs-kit query <text>`

Run retrieval directly from the CLI.

```bash
docs-kit query "How do I authenticate?"
docs-kit query "getting started" --limit 3
```

### `docs-kit inspect`

Show collection and embedding configuration details.

```bash
docs-kit inspect
docs-kit inspect --config ./docs-kit.yaml
```

### `docs-kit doctor`

Check environment variables, config presence, Qdrant connectivity, and whether the MCP server is running.

```bash
docs-kit doctor
docs-kit doctor --config ./docs-kit.yaml
```

### `docs-kit list`

List ingested sources with their ingestion timestamps.

```bash
docs-kit list
docs-kit list --config ./docs-kit.yaml
```

### `docs-kit remove <source>`

Remove an ingested source by URL or file path.

```bash
docs-kit remove https://docs.example.com/page
docs-kit remove ./docs/getting-started.md
```

## MCP Tools

When connected to an MCP client, docs-kit exposes:

| Tool | Description |
|------|-------------|
| `search_docs(query, limit=5)` | Hybrid dense + BM25 retrieval |
| `list_sources()` | List all ingested source URLs/paths |
| `list_ingested_sources()` | List sources with ingestion timestamps |
| `get_collection_info()` | Collection stats (exists, point count) |
| `get_full_document(source)` | Retrieve full stored document by source |
| `ingest_urls(urls, provider="auto")` | Ingest comma-separated URLs at runtime |
| `remove_source(source)` | Remove a source and all its chunks |

## Install Targets

URL-based SSE install is supported for:

- `claude-code`
- `claude-desktop`
- `cursor`
- `codex` / `codex-app`

ChatGPT aliases are accepted for guidance only:

- `chatgpt`
- `chatgpt-desktop`

`chatgpt` and `chatgpt-desktop` do not currently use a local config written by this command. The installer prints guidance for exposing the SSE server remotely via ChatGPT Settings > Apps/Connectors.

## Configuration

Project-local `docs-kit.yaml` created by `docs-kit init`:

```yaml
embedding:
  provider: fastembed
  model: BAAI/bge-small-en-v1.5

vector_store:
  provider: qdrant
  local_path: .docs-kit/qdrant
  collection_name: knowledge_base

ingestion:
  chunk_size: 800
  chunk_overlap: 120
  bm25_model: Qdrant/bm25

mcp:
  transport: sse
  host: localhost
  port: 45139
```

Global installs can also use a user config at `~/.docs-kit/docs-kit.yaml`, with data stored under `~/.docs-kit/qdrant`.

## Supported Sources

| Source | Strategy |
|--------|----------|
| GitBook sites | `/llms-full.txt` → `/llms.txt` |
| Mintlify sites | `/llms-full.txt` → `/llms.txt` → `/sitemap.xml` |
| Local `.md` files | Direct file read |
| Local `.txt` files | Direct file read |

Both GitBook and Mintlify support the [`llms.txt` standard](https://llmstxt.org), so in most cases the same auto strategy works for both. The Mintlify fetcher adds a `/sitemap.xml` fallback for sites where `llms.txt` is disabled.

## Requirements

- Python 3.11–3.13 (3.14+ not yet supported — `onnxruntime` wheels are unavailable for 3.14)
- Disk space for the local embedding model download
- Local Qdrant storage under `.docs-kit/` by default

If your system Python is 3.14, pass an explicit version to pipx:

```bash
pipx install docs-kit --python python3.13
```
