# docs-kit — Project Memory

## Project Overview

**docs-kit** is a distributable toolkit (PyPI **`docs-kit`**, optional **npm/npx** wrapper) that:

1. **Pulls** documentation from public **GitBook** sites via AI-oriented endpoints (`/llms-full.txt` or `/llms.txt` and linked pages).
2. **Stores** content locally — either as downloaded `.md` files (`docs-kit fetch`) or in a **local Qdrant** vector store after embedding (`docs-kit ingest`).
3. **Ingests** with **local embeddings** (FastEmbed by default; no API keys required for embeddings).
4. **Serves** an **MCP (Model Context Protocol) server** so **Claude Code**, **Claude Desktop**, **Cursor**, and other MCP-capable agents can query the knowledge base (`search_docs`, `list_sources`, `get_collection_info`, `get_full_document`).
5. **Installs** MCP wiring via `docs-kit install claude-code | claude-desktop | cursor`.

**Pitch:** Point at any public GitBook docs, embed locally, expose them to your coding agents through MCP.

**Target:** Developers who want product/docs RAG in the agent loop without shipping docs to a remote embedding API.

---

## Distribution

| Channel | What it is |
|---------|------------|
| **PyPI** | Canonical install: `pip install docs-kit`. CLI entry: `docs-kit`. |
| **npm/npx** | `npx-wrapper/` — thin Node shim that ensures Python 3.11+ and `pip install docs-kit`, then runs `python -m docs_kit …`. |

---

## Repo Structure

| Path | Purpose |
|------|---------|
| `docs_kit/` | Python package: `DocsKitAgent`, GitBook fetcher, parsers, FastEmbed, Qdrant store, MCP server, Click CLI |
| `docs_kit/cli/` | CLI (`docs-kit init`, `fetch`, `ingest`, `serve`, `install`, `query`, `inspect`, `doctor`) |
| `docs_kit/mcp/` | FastMCP server (`stdio` default; `sse` with optional deps) |
| `docs_kit/connectors/fetchers/gitbook.py` | GitBook `llms-full.txt` / `llms.txt` fetch |
| `npx-wrapper/` | npm package wrapping the Python CLI |
| `tests/` | pytest suite |
| `data/sample_docs/` | Sample markdown for local ingest tests |

---

## Tech Stack

- **Python** ≥ 3.11, **Click**, **Pydantic** / **pydantic-settings**, **httpx**, **PyYAML**
- **Embeddings:** FastEmbed (local)
- **Vector store:** Qdrant (local path, e.g. `.docs-kit/qdrant` in config)
- **MCP:** `mcp` + FastMCP; optional **uvicorn** / **starlette** for SSE (`docs-kit[sse]`)

---

## Security & Privacy

- **NEVER** touch `.env`, `.env.local`, `.env.*`, or other secret/credentials files. Treat them as if they do not exist.
- **NEVER** read, access, reference, or recommend reading environment or secret files.
- **ALWAYS** work on `.env.example` when documenting or adding environment variables — use placeholder values only.
- If config is needed, ask the user for non-sensitive details.

---

## Build & Verification

From the project root (where `pyproject.toml` lives):

```bash
pytest tests/ -v
```

After substantive changes, run the full test suite before claiming completion.

---

## Git Commits

- **MUST** write descriptive commit messages using [Conventional Commits](https://www.conventionalcommits.org/): `feat`, `fix`, `chore`, `docs`, `style`, `refactor`, `test`, `perf`.
- **SHOULD** keep subject line under 50 characters, imperative mood; use bullet points in body for context.

---

## Key Paths & Commands

- **Config:** `docs-kit.yaml` (from `docs-kit init`) — embedding model, Qdrant `local_path`, MCP transport/port.
- **Fetch only:** `docs-kit fetch <gitbook-url> --output docs-kit-docs`
- **Ingest URL or path:** `docs-kit ingest https://example.gitbook.io/docs` or `docs-kit ingest ./path/to/markdown`
- **MCP:** `docs-kit serve` (stdio); SSE requires `docs-kit[sse]` and config/flags for `sse`.
- **Agent setup:** `docs-kit install claude-code` (optional `--project` for project-level Claude Code).
