from __future__ import annotations

import json

from docs_kit.core.config import DocsKitConfig
from docs_kit.agent import DocsKitAgent


def _create_server(agent: DocsKitAgent, host: str = "127.0.0.1", port: int = 3001):
    """Create a FastMCP server wired to the given agent."""
    from mcp.server.fastmcp import FastMCP

    mcp_server = FastMCP("docs-kit", host=host, port=port)

    @mcp_server.tool()
    def search_docs(query: str, limit: int = 5) -> str:
        """Search the knowledge base using hybrid retrieval. Returns relevant document chunks with source attribution."""
        chunks = agent.query(query, limit=limit)
        results = [
            {
                "source": c.source,
                "chunk_index": c.chunk_index,
                "score": round(c.score, 4),
                "text": c.text,
            }
            for c in chunks
        ]
        return json.dumps(results, indent=2)

    @mcp_server.tool()
    def list_sources() -> str:
        """List all ingested document sources in the knowledge base."""
        sources = agent.list_sources()
        return json.dumps(sources, indent=2)

    @mcp_server.tool()
    def get_collection_info() -> str:
        """Get statistics about the vector store collection."""
        info = agent.get_collection_info()
        return json.dumps(info, indent=2)

    @mcp_server.tool()
    def get_full_document(source: str) -> str:
        """Retrieve the full text of a specific document by its source URL or path."""
        document = agent.get_document(source)
        if not document:
            return f"No document found with source: {source}"
        return document

    @mcp_server.tool()
    def ingest_urls(urls: str, provider: str = "auto") -> str:
        """Ingest one or more URLs (comma-separated) into the knowledge base.

        Args:
            urls: Comma-separated list of documentation site URLs.
            provider: Documentation platform — "auto" (default), "gitbook", or "mintlify".
                      "auto" tries llms-full.txt → llms.txt → sitemap.xml automatically.
        """
        url_list = [u.strip() for u in urls.split(",") if u.strip()]
        if not url_list:
            return json.dumps({"error": "No URLs provided"})
        resolved_provider = provider if provider != "auto" else None
        results = []
        for url in url_list:
            try:
                count = agent.ingest_url(url, provider=resolved_provider)
                results.append({"url": url, "status": "ok", "chunks_ingested": count})
            except Exception as exc:
                results.append({"url": url, "status": "error", "error": str(exc)})
        return json.dumps(results, indent=2)

    @mcp_server.tool()
    def remove_source(source: str) -> str:
        """Remove a previously ingested source (URL or file path) and all its chunks from the knowledge base."""
        deleted = agent.remove_source(source)
        if deleted:
            return json.dumps({"status": "ok", "message": f"Removed source: {source}"})
        return json.dumps({"status": "not_found", "message": f"No data found for source: {source}"})

    @mcp_server.tool()
    def list_ingested_sources() -> str:
        """List all ingested document sources with their ingestion dates."""
        entries = agent.list_sources_with_dates()
        return json.dumps(entries, indent=2)

    return mcp_server


def run_stdio(config: DocsKitConfig) -> None:
    """Start the MCP server using stdio transport."""
    agent = DocsKitAgent(config=config)
    server = _create_server(agent, host=config.mcp.host, port=config.mcp.port)
    server.run(transport="stdio")


def run_sse(config: DocsKitConfig) -> None:
    """Start the MCP server using SSE transport (HTTP)."""
    agent = DocsKitAgent(config=config)
    server = _create_server(agent, host=config.mcp.host, port=config.mcp.port)
    server.run(transport="sse")
