from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

import click
import tomli_w

from docs_kit.cli.help import DocsKitCommand, HELP_CONTEXT_SETTINGS, format_examples

INSTALL_TARGETS = [
    "claude-code",
    "claude-desktop",
    "cursor",
    "codex",
    "codex-desktop",
    "codex-app",
    "chatgpt",
    "chatgpt-desktop",
]


def _get_agent_class():
    from docs_kit.agent import DocsKitAgent

    return DocsKitAgent


def _get_config_class():
    from docs_kit.core.config import DocsKitConfig

    return DocsKitConfig


def _get_mcp_config_class():
    from docs_kit.core.config import McpConfig

    return McpConfig


def _get_server_runners():
    from docs_kit.mcp.server import run_stdio, run_sse

    return run_stdio, run_sse


def _get_qdrant_client_class():
    from qdrant_client import QdrantClient

    return QdrantClient


def _get_user_config_dir() -> Path:
    return Path.home() / ".docs-kit"


def _get_user_config_path() -> Path:
    return _get_user_config_dir() / "docs-kit.yaml"


def _get_pid_file() -> Path:
    return _get_user_config_dir() / "docs-kit.pid"


def _get_log_file() -> Path:
    return _get_user_config_dir() / "serve.log"


def _get_running_pid() -> int | None:
    pid_file = _get_pid_file()
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)
        return pid
    except (ValueError, ProcessLookupError, PermissionError, OSError):
        pid_file.unlink(missing_ok=True)
        return None


def _build_serve_foreground_cmd(config_path: str, port: int) -> list[str]:
    resolved = shutil.which("docs-kit")
    if resolved:
        cmd = [str(Path(resolved).resolve()), "serve", "--foreground", "--port", str(port), "--config", config_path]
    else:
        cmd = [sys.executable, "-m", "docs_kit", "serve", "--foreground", "--port", str(port), "--config", config_path]
    return cmd


def _build_user_bootstrap_config():
    DocsKitConfig = _get_config_class()
    config = DocsKitConfig()
    config.vector_store.local_path = str((_get_user_config_dir() / "qdrant").resolve())
    return config


def _ensure_user_config() -> Path:
    import yaml as _yaml

    config_path = _get_user_config_path()
    if config_path.exists():
        return config_path

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config = _build_user_bootstrap_config()
    with open(config_path, "w") as f:
        _yaml.dump(config.model_dump(), f, default_flow_style=False, sort_keys=False)
    return config_path


def _load_config(config_path: str | None):
    DocsKitConfig = _get_config_class()
    if config_path:
        return DocsKitConfig.from_yaml(config_path)
    default_yaml = Path("docs-kit.yaml")
    if default_yaml.exists():
        return DocsKitConfig.from_yaml(default_yaml)
    return DocsKitConfig.from_yaml(_ensure_user_config())


def _describe_vector_store(config) -> str:
    if config.vector_store.url:
        return f"remote Qdrant at {config.vector_store.url}"
    return f"local embedded Qdrant at {config.vector_store.local_path}"


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Create a docs-kit config file.",
    epilog=format_examples(
        "docs-kit init",
        "docs-kit init --dir ./sandbox",
    ),
)
@click.option("--dir", "directory", default=".", help="Target directory for the config file.")
def init_cmd(directory: str):
    """Initialize a docs-kit project with a config file."""
    import yaml as _yaml

    dir_path = Path(directory)
    dir_path.mkdir(parents=True, exist_ok=True)
    config_path = dir_path / "docs-kit.yaml"
    if config_path.exists():
        click.echo(f"Config already exists at {config_path}")
        return
    DocsKitConfig = _get_config_class()
    config = DocsKitConfig()
    data = config.model_dump()
    with open(config_path, "w") as f:
        _yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    click.echo(f"Created config at {config_path}")
    click.echo("No API keys required — embeddings run fully locally.")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Ingest docs from a path or URL.",
    epilog=format_examples(
        "docs-kit ingest ./docs",
        "docs-kit ingest https://docs.example.com",
        "docs-kit ingest ./docs --recreate",
    ),
)
@click.argument("path")
@click.option("--recreate", is_flag=True, help="Recreate the collection first.")
@click.option("--provider", default="auto", show_default=True,
              type=click.Choice(["auto", "gitbook", "mintlify"], case_sensitive=False),
              help="Docs platform. auto tries llms.txt then sitemap.xml.")
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def ingest_cmd(path: str, recreate: bool, provider: str, config_path: str | None):
    """Ingest documents from a file, directory, or URL."""
    import logging
    logging.basicConfig(level=logging.INFO, format="%(message)s", force=True)

    config = _load_config(config_path)
    agent = _get_agent_class()(config=config)

    try:
        if path.startswith("http://") or path.startswith("https://"):
            click.echo(f"Fetching docs from {path}...")
            total = agent.ingest_url(path, recreate=recreate, provider=provider if provider != "auto" else None)
        else:
            total = agent.ingest(path, recreate=recreate)
        click.echo(f"Total: {total} chunks ingested")
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Download GitBook docs to Markdown files.",
    epilog=format_examples(
        "docs-kit fetch https://docs.example.com",
        "docs-kit fetch https://docs.example.com --output ./downloaded-docs",
    ),
)
@click.argument("url")
@click.option(
    "--output",
    "output_dir",
    default="docs-kit-docs",
    show_default=True,
    help="Output directory for downloaded .md files.",
)
def fetch_cmd(url: str, output_dir: str):
    """Download docs from a GitBook URL to local .md files."""
    from urllib.parse import urlparse
    from docs_kit.connectors.fetchers.gitbook import GitBookFetcher

    fetcher = GitBookFetcher()
    click.echo(f"Fetching docs from {url}...")
    try:
        documents = fetcher.fetch(url)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    for doc in documents:
        # Derive a filename from the source URL
        parsed = urlparse(doc.source)
        slug = parsed.path.strip("/").replace("/", "_") or "index"
        filename = f"{slug}.md"
        file_path = out_path / filename
        file_path.write_text(doc.content, encoding="utf-8")
        click.echo(f"  Saved {file_path}")

    click.echo(f"Downloaded {len(documents)} document(s) to {output_dir}/")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Start the MCP server daemon.",
    epilog=format_examples(
        "docs-kit serve",
        "docs-kit serve --port 45139",
        "docs-kit serve --config ./docs-kit.yaml",
    ),
)
@click.option("--port", default=None, type=int, help="Port to listen on (default: 45139).")
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
@click.option("--foreground", is_flag=True, hidden=True, help="Run in foreground (internal use by daemon).")
def serve_cmd(port: int | None, config_path: str | None, foreground: bool):
    """Start the MCP server as a background daemon on http://localhost:45139/sse.

    All MCP clients (Claude Code, Codex, Cursor) share this single server,
    avoiding Qdrant lock conflicts when multiple agents run simultaneously.

    Use 'docs-kit stop' to stop the server.
    """
    config = _load_config(config_path)
    effective_port = port or config.mcp.port
    effective_host = config.mcp.host

    if foreground:
        # Internal: run the SSE server blocking in foreground (called by daemon subprocess).
        _, run_sse = _get_server_runners()
        McpConfig = _get_mcp_config_class()
        mcp_cfg = McpConfig(transport="sse", host=effective_host, port=effective_port)
        run_sse(config.model_copy(update={"mcp": mcp_cfg}))
        return

    running_pid = _get_running_pid()
    if running_pid:
        click.echo(f"docs-kit server already running (PID {running_pid})")
        click.echo(f"  http://{effective_host}:{effective_port}/sse")
        return

    # Determine absolute config path for the daemon subprocess.
    if config_path:
        abs_config = str(Path(config_path).resolve())
    else:
        default_yaml = Path("docs-kit.yaml")
        if default_yaml.exists():
            abs_config = str(default_yaml.resolve())
        else:
            abs_config = str(_get_user_config_path())

    log_file = _get_log_file()
    log_file.parent.mkdir(parents=True, exist_ok=True)

    cmd = _build_serve_foreground_cmd(abs_config, effective_port)
    with open(log_file, "a") as log:
        proc = subprocess.Popen(
            cmd,
            stdout=log,
            stderr=log,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

    _get_pid_file().write_text(str(proc.pid))

    click.echo(f"docs-kit MCP server started (PID {proc.pid})")
    click.echo(f"  http://{effective_host}:{effective_port}/sse")
    click.echo(f"  Logs: {log_file}")
    click.echo(f"  Stop: docs-kit stop")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Stop the MCP server daemon.",
)
def stop_cmd():
    """Stop the running docs-kit MCP server daemon."""
    import signal

    pid = _get_running_pid()
    if not pid:
        click.echo("docs-kit server is not running.")
        return
    try:
        os.kill(pid, signal.SIGTERM)
        _get_pid_file().unlink(missing_ok=True)
        click.echo(f"Stopped docs-kit server (PID {pid})")
    except ProcessLookupError:
        _get_pid_file().unlink(missing_ok=True)
        click.echo("docs-kit server was not running (removed stale PID).")
    except PermissionError:
        click.echo(f"Permission denied stopping PID {pid}.", err=True)
        sys.exit(1)


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Show collection stats.",
    epilog=format_examples(
        "docs-kit inspect",
        "docs-kit inspect --config ./docs-kit.yaml",
    ),
)
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def inspect_cmd(config_path: str | None):
    """Show collection stats and configuration."""
    config = _load_config(config_path)
    agent = _get_agent_class()(config=config)

    stats = agent.collection_stats()
    click.echo(f"Collection: {config.vector_store.collection_name}")
    click.echo(f"Exists: {stats.get('collection_exists', False)}")
    click.echo(f"Points: {stats.get('points_count', 0)}")
    click.echo(f"Embeddings: {config.embedding.provider} ({config.embedding.model})")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Check config and connectivity.",
    epilog=format_examples(
        "docs-kit doctor",
        "docs-kit doctor --config ./docs-kit.yaml",
    ),
)
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def doctor_cmd(config_path: str | None):
    """Check environment, connectivity, and MCP server status."""
    import socket

    config = _load_config(config_path)
    checks = {
        "EMBEDDING_MODEL": os.environ.get("EMBEDDING_MODEL"),
        "VECTOR_STORE_URL": os.environ.get("VECTOR_STORE_URL"),
    }

    for key, value in checks.items():
        if value:
            click.echo(f"  [OK] {key} is set")
        else:
            click.echo(f"  [--] {key} not set")

    click.echo(f"  [OK] Vector store mode: {_describe_vector_store(config)}")

    if config.vector_store.url:
        try:
            QdrantClient = _get_qdrant_client_class()
            client = QdrantClient(url=config.vector_store.url, timeout=3)
            client.get_collections()
            click.echo(f"  [OK] Qdrant reachable at {config.vector_store.url}")
        except Exception:
            click.echo(f"  [--] Qdrant not reachable at {config.vector_store.url}")

    resolved_config_path = Path(config_path) if config_path else Path("docs-kit.yaml")
    if resolved_config_path.exists():
        click.echo(f"  [OK] Config file found: {resolved_config_path}")
    else:
        expected = "docs-kit.yaml" if config_path is None else config_path
        click.echo(f"  [--] No config file found at {expected} (run: docs-kit init)")

    # Check if the MCP server is running.
    pid = _get_running_pid()
    if pid:
        click.echo(f"  [OK] MCP server running (PID {pid}) at http://{config.mcp.host}:{config.mcp.port}/sse")
    else:
        try:
            with socket.create_connection((config.mcp.host, config.mcp.port), timeout=2):
                click.echo(f"  [OK] MCP server reachable at http://{config.mcp.host}:{config.mcp.port}/sse")
        except OSError:
            click.echo(f"  [--] MCP server not running (start with: docs-kit serve)")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Search ingested docs.",
    epilog=format_examples(
        'docs-kit query "How do I authenticate?"',
        'docs-kit query "getting started" --limit 3',
    ),
)
@click.argument("text")
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
@click.option("--limit", default=None, type=int, help="Maximum chunks to return.")
def query_cmd(text: str, config_path: str | None, limit: int | None):
    """Run a retrieval query against the vector store (no server required)."""
    config = _load_config(config_path)
    agent = _get_agent_class()(config=config)
    chunks = agent.query(text, limit=limit)

    if not chunks:
        click.echo("No results found.")
        sys.exit(1)

    for i, chunk in enumerate(chunks, start=1):
        preview = chunk.text[:300] + "..." if len(chunk.text) > 300 else chunk.text
        click.echo(f"[{i}] score={chunk.score:.2f}  source={chunk.source}")
        click.echo(preview)
        click.echo("---")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Remove an ingested source.",
    epilog=format_examples(
        "docs-kit remove https://docs.example.com/page",
        "docs-kit remove ./docs/getting-started.md",
    ),
)
@click.argument("source")
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def remove_cmd(source: str, config_path: str | None):
    """Remove an ingested source (URL or file path) from the knowledge base."""
    config = _load_config(config_path)
    agent = _get_agent_class()(config=config)
    deleted = agent.remove_source(source)
    if deleted:
        click.echo(f"Removed source: {source}")
    else:
        click.echo(f"No data found for source: {source}", err=True)
        sys.exit(1)


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="List ingested sources.",
    epilog=format_examples(
        "docs-kit list",
        "docs-kit list --config ./docs-kit.yaml",
    ),
)
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def list_cmd(config_path: str | None):
    """List all ingested sources with their ingestion dates."""
    config = _load_config(config_path)
    agent = _get_agent_class()(config=config)
    entries = agent.list_sources_with_dates()
    if not entries:
        click.echo("No sources ingested yet.")
        return
    for entry in entries:
        click.echo(f"{entry['ingested_at']}  {entry['source']}")


def _resolve_agent_settings_path(agent: str, project: bool = False) -> Path | None:
    import platform
    home = Path.home()
    system = platform.system()

    if agent == "claude-code":
        if project:
            return Path(".claude") / "settings.json"
        return home / ".claude" / "settings.json"

    elif agent == "claude-desktop":
        if system == "Darwin":
            return home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
        elif system == "Windows":
            appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
        else:  # Linux
            return home / ".config" / "Claude" / "claude_desktop_config.json"

    elif agent == "cursor":
        if system == "Darwin":
            return home / ".cursor" / "mcp.json"
        elif system == "Windows":
            appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
            return Path(appdata) / "Cursor" / "mcp.json"
        else:  # Linux
            return home / ".config" / "Cursor" / "mcp.json"

    elif agent in {"codex", "codex-desktop", "codex-app"}:
        return home / ".codex" / "config.toml"

    return None


def _install_json_mcp_url(settings_path: Path, server_name: str, url: str) -> None:
    import json
    import tempfile

    if settings_path.exists():
        with open(settings_path) as f:
            try:
                settings = json.load(f)
            except json.JSONDecodeError:
                click.echo(f"Warning: {settings_path} contains invalid JSON. Creating backup and overwriting.", err=True)
                backup = settings_path.with_suffix(".json.bak")
                settings_path.rename(backup)
                settings = {}
    else:
        settings = {}
        settings_path.parent.mkdir(parents=True, exist_ok=True)

    settings.setdefault("mcpServers", {})
    settings["mcpServers"][server_name] = {"url": url}

    tmp_fd, tmp_path = tempfile.mkstemp(dir=settings_path.parent, suffix=".tmp")
    try:
        with os.fdopen(tmp_fd, "w") as f:
            json.dump(settings, f, indent=2)
            f.write("\n")
        Path(tmp_path).rename(settings_path)
    except Exception:
        os.unlink(tmp_path)
        raise


def _install_codex_mcp_url(settings_path: Path, server_name: str, url: str) -> None:
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    if settings_path.exists():
        with open(settings_path, "rb") as f:
            settings = tomllib.load(f)
    else:
        settings = {}

    settings.setdefault("mcp_servers", {})
    settings["mcp_servers"][server_name] = {"url": url}

    settings_path.write_text(tomli_w.dumps(settings), encoding="utf-8")


def _print_chatgpt_remote_mcp_instructions() -> None:
    click.echo(
        "ChatGPT does not use a local MCP config file here. "
        "OpenAI's current docs route ChatGPT through remote MCP apps/connectors in Settings."
    )
    click.echo("To use docs-kit with ChatGPT, start the server and expose it remotely:")
    click.echo("  docs-kit serve")
    click.echo("Then expose http://localhost:45139/sse remotely and connect it from ChatGPT Settings > Apps/Connectors.")
    sys.exit(1)


def _print_restart_instructions(agent: str) -> None:
    if agent == "claude-code":
        click.echo("  Restart Claude Code or run /mcp in the Claude Code prompt.")
    elif agent == "claude-desktop":
        click.echo("  Restart Claude Desktop for changes to take effect.")
    elif agent == "cursor":
        click.echo("  Restart Cursor for changes to take effect.")


@click.command(
    cls=DocsKitCommand,
    context_settings=HELP_CONTEXT_SETTINGS,
    short_help="Install the MCP server into an agent config.",
    epilog=format_examples(
        "docs-kit install claude-code",
        "docs-kit install codex",
        "docs-kit install claude-code --project",
        "docs-kit install cursor --config ./docs-kit.yaml",
        "docs-kit install chatgpt",
    ),
)
@click.argument("agent", type=click.Choice(INSTALL_TARGETS, case_sensitive=False))
@click.option("--project", is_flag=True, default=False,
              help="Install in project-level settings (claude-code only).")
@click.option("--config", "config_path", default=None, help="Path to docs-kit.yaml.")
def install_cmd(agent: str, project: bool, config_path: str | None):
    """Install docs-kit into an AI agent's MCP settings.

    Configures the agent to connect to the shared docs-kit server at
    http://localhost:45139/sse. All agents share one server — no Qdrant
    lock conflicts when multiple clients run simultaneously.

    Start the server with: docs-kit serve

    AGENT must be one of: claude-code, claude-desktop, cursor, codex,
    codex-desktop, codex-app, chatgpt, chatgpt-desktop
    """
    normalized_agent = agent.lower()

    if normalized_agent in {"chatgpt", "chatgpt-desktop"}:
        _print_chatgpt_remote_mcp_instructions()

    settings_path = _resolve_agent_settings_path(normalized_agent, project=project)
    if settings_path is None:
        click.echo(f"Error: Could not determine settings path for {normalized_agent!r} on this platform.", err=True)
        sys.exit(1)

    created_user_config = False
    DocsKitConfig = _get_config_class()

    if config_path:
        config_path = str(Path(config_path).resolve())
    else:
        default_yaml = Path("docs-kit.yaml")
        if default_yaml.exists():
            config_path = str(default_yaml.resolve())
        elif not project:
            user_config_already_exists = _get_user_config_path().exists()
            user_config_path = _ensure_user_config()
            config_path = str(user_config_path.resolve())
            created_user_config = not user_config_already_exists

    if config_path is not None:
        config = DocsKitConfig.from_yaml(config_path)
    elif project:
        config = DocsKitConfig()
    else:
        config = _load_config(None)
    url = f"http://{config.mcp.host}:{config.mcp.port}/sse"

    if normalized_agent in {"codex", "codex-desktop", "codex-app"}:
        _install_codex_mcp_url(settings_path, "docs-kit", url)
        click.echo(f"✓ Installed docs-kit into {settings_path}")
        click.echo(f"  Connects to: {url}")
        if created_user_config:
            click.echo(f"  Created user config at {config_path}")
            click.echo(f"  Local data will be stored under {_get_user_config_dir() / 'qdrant'}")
        click.echo("  Start the server: docs-kit serve")
        click.echo("  Codex CLI and the Codex IDE extension share this config.")
        return

    _install_json_mcp_url(settings_path, "docs-kit", url)
    click.echo(f"✓ Installed docs-kit into {settings_path}")
    click.echo(f"  Connects to: {url}")
    if created_user_config:
        click.echo(f"  Created user config at {config_path}")
        click.echo(f"  Local data will be stored under {_get_user_config_dir() / 'qdrant'}")
    click.echo("  Start the server: docs-kit serve")
    _print_restart_instructions(normalized_agent)
