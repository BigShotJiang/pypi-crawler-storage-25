# docs-kit — Agent Instructions

## Scope

This document applies to AI agents working on the **docs-kit** codebase: a **PyPI** package (and optional **npx** wrapper) that **fetches GitBook documentation**, **stores and embeds it locally** (markdown on disk + Qdrant), and **exposes retrieval via an MCP server** for **Claude Code**, **Claude Desktop**, **Cursor**, and other MCP-aware tools.

---

## What the product does

1. **Fetch** — `GitBookFetcher` uses `/llms-full.txt` or `/llms.txt` on a public GitBook base URL.
2. **Local storage** — `docs-kit fetch` writes `.md` files; `docs-kit ingest` chunks, embeds with FastEmbed, and upserts into local Qdrant.
3. **MCP** — `docs-kit serve` runs tools: `search_docs`, `list_sources`, `get_collection_info`, `get_full_document`.
4. **Install** — `docs-kit install` merges an `mcpServers.docs-kit` entry into agent settings for `claude-code`, `claude-desktop`, or `cursor`.

The **npx** package under `npx-wrapper/` only ensures Python 3.11+ and installs/runs the **`docs-kit`** Python module; behavior lives in Python.

---

## Security (Non-Negotiable)

- **MUST NOT** read, access, or reference `.env`, `.env.local`, `.env.*`, or any secret/credentials files.
- **MUST NOT** recommend reading environment files. If config is needed, ask the user for non-sensitive details.
- **MUST** treat `.env` files as if they do not exist.

---

## Verification After Changes

From the repository root:

```bash
pytest tests/ -v
```

- **MUST NOT** claim work is complete without a successful test run when behavior or dependencies changed.

---

## Git Commit Workflow

When the user asks to commit, stage, or write a commit message:

1. **MUST** analyze staged/unstaged changes via `git status` and `git diff` in the relevant git root.
2. **MUST** write a commit message following Conventional Commits:
   - `feat:` — new feature
   - `fix:` — bug fix
   - `chore:` — maintenance, deps, config
   - `docs:` — documentation only
   - `style:` — formatting, no logic change
   - `refactor:` — code restructure
   - `test:` — tests only
   - `perf:` — performance
3. **SHOULD** keep subject line under 50 chars, imperative mood; use bullet points in body.
4. **SHOULD** suggest splitting into atomic commits if changes span unrelated concerns.

---

## Project Context (Brief)

- **Package name:** `docs-kit` (import `docs_kit`, CLI `docs-kit`).
- **Main types:** `DocsKitConfig`, `DocsKitAgent` (`docs_kit/agent.py`); MCP in `docs_kit/mcp/server.py`.
- **CLI:** `docs_kit/cli/commands.py` — `init`, `fetch`, `ingest`, `serve`, `install`, `query`, `inspect`, `doctor`.
- **Docs:** [README.md](README.md) for user-facing quickstart and command table.
