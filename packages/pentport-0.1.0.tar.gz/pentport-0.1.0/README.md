﻿# PentPort Python SDK

Python SDK for the PentPort API.

## Install

```bash
pip install pentport
```

## Authentication

Set your API key in PowerShell:

```powershell
$env:PENTPORT_API_KEY = "pp_live_REPLACE_ME"
```

Or pass it directly in Python:

```python
from pentport import PentPort

pp = PentPort(api_key="pp_live_REPLACE_ME")
```

## Quickstart

```python
from pentport import PentPort

pp = PentPort()

account = pp.choose_account("stocks")
account_hash = account["account_hash"]

print(pp.account_balance(account_hash=account_hash))
print(pp.quotes(["AAPL", "TSLA"], account_hash=account_hash))

order = pp.buy("AAPL", 1, account_hash=account_hash)
print(order)
```

## Important

Do not expose your API key in public frontend JavaScript. Use this SDK from a backend, script, notebook, or private automation environment.
