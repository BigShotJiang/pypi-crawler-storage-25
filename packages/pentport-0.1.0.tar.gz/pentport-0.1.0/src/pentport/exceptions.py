﻿from __future__ import annotations


class PentPortError(Exception):
    """Base class for PentPort SDK errors."""


class PentPortAPIError(PentPortError):
    """Raised when PentPort returns a non-2xx response or ok=false payload."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error: str | None = None,
        data: dict | None = None,
        headers: dict | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.error = error
        self.data = data or {}
        self.headers = headers or {}


class PentPortRateLimitError(PentPortAPIError):
    """Raised when the API returns HTTP 429."""

    @property
    def retry_after_seconds(self) -> int | None:
        value = self.headers.get("Retry-After")
        try:
            return int(value) if value is not None else None
        except ValueError:
            return None
