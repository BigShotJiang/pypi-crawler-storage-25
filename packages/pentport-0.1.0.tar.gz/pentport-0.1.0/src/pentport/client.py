﻿from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Iterable

import requests

from .exceptions import PentPortAPIError, PentPortRateLimitError


DEFAULT_BASE_URL = "https://pentport.com"


class PentPort:
    """
    Python client for PentPort API v1.

    Example:
        from pentport import PentPort

        pp = PentPort()
        account = pp.choose_account("stocks")
        quotes = pp.quotes(["AAPL", "TSLA"], account_hash=account["account_hash"])
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 20.0,
        session: requests.Session | None = None,
    ):
        self.api_key = api_key or os.getenv("PENTPORT_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Missing API key. Pass api_key='...' or set PENTPORT_API_KEY."
            )

        self.base_url = (base_url or os.getenv("PENTPORT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

        self.session = session or requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "pentport-python/0.1.0",
            }
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """
        Low-level request method.

        Use this for any v1 endpoint that does not yet have a convenience method:

            pp.request("GET", "/predictions/browse", params={...})
        """
        if not path.startswith("/"):
            path = "/" + path

        if path.startswith("/api/v1/"):
            url = f"{self.base_url}{path}"
        else:
            url = f"{self.base_url}/api/v1{path}"

        response = self.session.request(
            method.upper(),
            url,
            params=_clean(params),
            json=_clean(json),
            timeout=self.timeout if timeout is None else timeout,
        )

        try:
            parsed = response.json()
            data = parsed if isinstance(parsed, dict) else {"data": parsed}
        except ValueError:
            data = {"raw": response.text}

        if response.status_code == 429:
            raise PentPortRateLimitError(
                data.get("message") or data.get("error") or "PentPort rate limit exceeded.",
                status_code=response.status_code,
                error=data.get("error"),
                data=data,
                headers=dict(response.headers),
            )

        if response.status_code >= 400 or data.get("ok") is False:
            raise PentPortAPIError(
                data.get("message") or data.get("error") or f"PentPort API error: HTTP {response.status_code}",
                status_code=response.status_code,
                error=data.get("error"),
                data=data,
                headers=dict(response.headers),
            )

        return data

    def get(self, path: str, **params: Any) -> dict[str, Any]:
        return self.request("GET", path, params=params)

    def post(self, path: str, **payload: Any) -> dict[str, Any]:
        return self.request("POST", path, json=payload)

    @staticmethod
    def _scope(
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        scope: dict[str, Any] = {}
        if account_hash:
            scope["account_hash"] = account_hash
        if competition_id is not None:
            scope["competition_id"] = competition_id
        return scope

    # -------------------------
    # Accounts / usage
    # -------------------------

    def accounts(self) -> list[dict[str, Any]]:
        """List accounts and competitions available to this API key."""
        return self.get("/accounts")["accounts"]

    def usage(self) -> dict[str, Any]:
        """Return API usage and tier details."""
        return self.get("/usage")

    def account_balance(
        self,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/account/balance",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def positions(
        self,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/positions",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def orders(
        self,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/orders",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    # -------------------------
    # Stocks / options
    # -------------------------

    def quotes(
        self,
        symbols: str | Iterable[str],
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        if isinstance(symbols, str):
            symbols_value = symbols
        else:
            symbols_value = ",".join(str(symbol).strip().upper() for symbol in symbols)

        return self.get(
            "/quotes",
            symbols=symbols_value,
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def options_chain(
        self,
        symbol: str,
        *,
        expiry: str | None = None,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/options/chain",
            symbol=symbol.upper(),
            expiry=expiry,
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def trade_stock(
        self,
        *,
        symbol: str,
        quantity: int | float,
        action: str,
        order_type: str = "MARKET",
        asset_type: str = "EQUITY",
        price: float | None = None,
        stop_price: float | None = None,
        duration: str = "DAY",
        session_type: str = "NORMAL",
        account_hash: str | None = None,
        competition_id: int | None = None,
        strat_code: str | None = None,
        strat_seq: int | None = None,
    ) -> dict[str, Any]:
        return self.post(
            "/trades/stocks",
            symbol=symbol.upper(),
            quantity=quantity,
            action=action.upper(),
            orderType=order_type.upper(),
            assetType=asset_type,
            price=price,
            stop_price=stop_price,
            duration=duration,
            session=session_type,
            stratCode=strat_code,
            stratSeq=strat_seq,
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def buy(
        self,
        symbol: str,
        quantity: int | float,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
        order_type: str = "MARKET",
        price: float | None = None,
    ) -> dict[str, Any]:
        return self.trade_stock(
            symbol=symbol,
            quantity=quantity,
            action="BUY",
            order_type=order_type,
            price=price,
            account_hash=account_hash,
            competition_id=competition_id,
        )

    def sell(
        self,
        symbol: str,
        quantity: int | float,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
        order_type: str = "MARKET",
        price: float | None = None,
    ) -> dict[str, Any]:
        return self.trade_stock(
            symbol=symbol,
            quantity=quantity,
            action="SELL",
            order_type=order_type,
            price=price,
            account_hash=account_hash,
            competition_id=competition_id,
        )

    def trade_options(
        self,
        *,
        legs: list[dict[str, Any]],
        order_type: str = "MARKET",
        price: float | None = None,
        session_type: str = "NORMAL",
        duration: str = "DAY",
        complex_order_strategy_type: str = "NONE",
        order_strategy_type: str = "SINGLE",
        account_hash: str | None = None,
        competition_id: int | None = None,
        strat_code: str | None = None,
        strat_seq: int | None = None,
    ) -> dict[str, Any]:
        return self.post(
            "/trades/options",
            legs=legs,
            orderType=order_type,
            price=price,
            session=session_type,
            duration=duration,
            complexOrderStrategyType=complex_order_strategy_type,
            orderStrategyType=order_strategy_type,
            stratCode=strat_code,
            stratSeq=strat_seq,
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    # -------------------------
    # Prediction markets
    # -------------------------

    def predictions_featured(
        self,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/predictions/featured",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def predictions_market(self, **params: Any) -> dict[str, Any]:
        return self.get("/predictions/market", **params)

    def predictions_search(self, **params: Any) -> dict[str, Any]:
        return self.get("/predictions/search", **params)

    def prediction_order(self, **payload: Any) -> dict[str, Any]:
        return self.post("/predictions/order", **payload)

    # -------------------------
    # Sports
    # -------------------------

    def sports(
        self,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            "/sports",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def sports_odds(
        self,
        sport: str,
        *,
        account_hash: str | None = None,
        competition_id: int | None = None,
    ) -> dict[str, Any]:
        return self.get(
            f"/sports/odds/{sport}",
            **self._scope(account_hash=account_hash, competition_id=competition_id),
        )

    def sports_bet(self, **payload: Any) -> dict[str, Any]:
        return self.post("/sports/bet", **payload)

    # -------------------------
    # Convenience helpers
    # -------------------------

    def choose_account(self, product: str = "stocks") -> dict[str, Any]:
        """
        Pick the first active account supporting the requested product.

        Product examples:
            stocks
            options
            predictions
            sports
        """
        now = datetime.now(timezone.utc)

        for account in self.accounts():
            products = account.get("products") or {}
            if not products.get(product):
                continue

            starts_at = _parse_datetime(account.get("starts_at"))
            ends_at = _parse_datetime(account.get("ends_at"))

            active = (starts_at is None or starts_at <= now) and (ends_at is None or ends_at > now)
            if active:
                return account

        raise PentPortAPIError(f"No active {product}-enabled account found.")


def _parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _clean(data: dict[str, Any] | None) -> dict[str, Any] | None:
    if data is None:
        return None
    return {key: value for key, value in data.items() if value is not None}
