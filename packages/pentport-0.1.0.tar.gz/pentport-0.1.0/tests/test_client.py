﻿import pytest
import responses

from pentport import PentPort
from pentport.exceptions import PentPortRateLimitError


@responses.activate
def test_accounts():
    responses.add(
        responses.GET,
        "https://pentport.com/api/v1/accounts",
        json={
            "ok": True,
            "accounts": [
                {
                    "account_hash": "abc123",
                    "competition_id": 1,
                    "products": {"stocks": True},
                    "starts_at": None,
                    "ends_at": None,
                }
            ],
        },
        status=200,
    )

    pp = PentPort(api_key="pp_live_test")
    accounts = pp.accounts()

    assert accounts[0]["account_hash"] == "abc123"


@responses.activate
def test_rate_limit_error():
    responses.add(
        responses.GET,
        "https://pentport.com/api/v1/accounts",
        json={"ok": False, "error": "rate_limit_exceeded"},
        headers={"Retry-After": "12"},
        status=429,
    )

    pp = PentPort(api_key="pp_live_test")

    with pytest.raises(PentPortRateLimitError) as exc:
        pp.accounts()

    assert exc.value.retry_after_seconds == 12
