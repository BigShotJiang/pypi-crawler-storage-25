from __future__ import annotations

import json
import sys
from os import PathLike
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Tuple, Union

from loguru import logger
from requests import Response


SUPPORTED_EXT: set[str]


def _resolve(filepath: Union[str, PathLike], mode: str) -> Path: ...


def _parse_mode(mode: str) -> Tuple[str, bool]: ...


_src_cache: dict


def _get_src(fn: Callable[..., Any]) -> str: ...


def _check_conditions(resp: Response, conditions: Iterable[Callable[[Response], bool]]) -> None: ...


def _is_valid_cache(path: Path) -> bool: ...


def _write(path: Path, resp: Response, is_binary: bool) -> None: ...


def _build_cached_response(url: str, path: Path, is_binary: bool) -> Response: ...


def handle_request(orig: Callable[..., Response], debug: bool, method: str, url: str, kwargs: Dict[str, Any]) -> Response: ...
