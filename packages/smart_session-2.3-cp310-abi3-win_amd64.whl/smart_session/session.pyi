# pyright: reportIncompatibleMethodOverride=false
from __future__ import annotations

from os import PathLike
from typing import Any, Callable, Generic, Iterable, Literal, TypeVar

from cloudscraper import CloudScraper
from curl_cffi.requests import Response as CurlCffiResponse
from curl_cffi.requests import Session as CurlCffiSession
from httpx import Client as HttpxClient
from httpx import Response as HttpxResponse
from requests import Response as RequestsResponse
from requests import Session as RequestsSession
from tls_client import Session as TlsClientSession
from tls_client.response import Response as TlsClientResponse

T = TypeVar("T")

CacheMode = Literal["r", "w", "rr", "rb", "wb", "rrb"]
Pathish = str | PathLike[str]


class SmartSession(Generic[T]):
    _session: T

    def __init__(
        self,
        base: type[T] | T,
        *args: Any,
        debug_mode: bool = ...,
        **kwargs: Any,
    ) -> None: ...
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def __getattr__(self, name: str) -> Any: ...
    def __enter__(self) -> SmartSession[T]: ...
    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool: ...
    def __repr__(self) -> str: ...


class RequestsWrappedSession(RequestsSession):
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def request(
        self,
        method: str | bytes,
        url: str | bytes,
        params: Any = ...,
        data: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: bool = ...,
        proxies: Any = ...,
        hooks: Any = ...,
        stream: Any = ...,
        verify: Any = ...,
        cert: Any = ...,
        json: Any = ...,
        *,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
    ) -> RequestsResponse: ...
    def get(
        self,
        url: str | bytes,
        *,
        params: Any = ...,
        data: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: bool = ...,
        proxies: Any = ...,
        hooks: Any = ...,
        stream: Any = ...,
        verify: Any = ...,
        cert: Any = ...,
        json: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> RequestsResponse: ...
    def post(
        self,
        url: str | bytes,
        data: Any = ...,
        json: Any = ...,
        *,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: bool = ...,
        proxies: Any = ...,
        hooks: Any = ...,
        stream: Any = ...,
        verify: Any = ...,
        cert: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> RequestsResponse: ...
    def put(self, url: str | bytes, data: Any = ..., **kwargs: Any) -> RequestsResponse: ...
    def patch(self, url: str | bytes, data: Any = ..., **kwargs: Any) -> RequestsResponse: ...
    def delete(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...
    def head(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...
    def options(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...


class CloudScraperWrappedSession(CloudScraper):
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def request(
        self,
        method: Any,
        url: Any,
        *args: Any,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> RequestsResponse: ...
    def get(
        self,
        url: str | bytes,
        *,
        params: Any = ...,
        data: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: bool = ...,
        proxies: Any = ...,
        hooks: Any = ...,
        stream: Any = ...,
        verify: Any = ...,
        cert: Any = ...,
        json: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> RequestsResponse: ...
    def post(
        self,
        url: str | bytes,
        data: Any = ...,
        json: Any = ...,
        *,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: bool = ...,
        proxies: Any = ...,
        hooks: Any = ...,
        stream: Any = ...,
        verify: Any = ...,
        cert: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[RequestsResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> RequestsResponse: ...
    def put(self, url: str | bytes, data: Any = ..., **kwargs: Any) -> RequestsResponse: ...
    def patch(self, url: str | bytes, data: Any = ..., **kwargs: Any) -> RequestsResponse: ...
    def delete(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...
    def head(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...
    def options(self, url: str | bytes, **kwargs: Any) -> RequestsResponse: ...


class CurlCffiWrappedSession(CurlCffiSession):
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def request(
        self,
        method: str,
        url: str,
        params: Any = ...,
        data: Any = ...,
        json: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: Any = ...,
        max_redirects: Any = ...,
        proxies: Any = ...,
        proxy: Any = ...,
        proxy_auth: Any = ...,
        verify: Any = ...,
        referer: Any = ...,
        accept_encoding: Any = ...,
        content_callback: Any = ...,
        impersonate: Any = ...,
        ja3: Any = ...,
        akamai: Any = ...,
        extra_fp: Any = ...,
        default_headers: Any = ...,
        default_encoding: Any = ...,
        quote: Any = ...,
        http_version: Any = ...,
        interface: Any = ...,
        cert: Any = ...,
        stream: Any = ...,
        max_recv_speed: int = ...,
        multipart: Any = ...,
        discard_cookies: bool = ...,
        *,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[CurlCffiResponse], bool]] | None = ...,
    ) -> CurlCffiResponse: ...
    def get(
        self,
        url: str,
        *,
        params: Any = ...,
        data: Any = ...,
        json: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: Any = ...,
        max_redirects: Any = ...,
        proxies: Any = ...,
        proxy: Any = ...,
        proxy_auth: Any = ...,
        verify: Any = ...,
        referer: Any = ...,
        accept_encoding: Any = ...,
        content_callback: Any = ...,
        impersonate: Any = ...,
        ja3: Any = ...,
        akamai: Any = ...,
        extra_fp: Any = ...,
        default_headers: Any = ...,
        default_encoding: Any = ...,
        quote: Any = ...,
        http_version: Any = ...,
        interface: Any = ...,
        cert: Any = ...,
        stream: Any = ...,
        max_recv_speed: int = ...,
        multipart: Any = ...,
        discard_cookies: bool = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[CurlCffiResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> CurlCffiResponse: ...
    def post(
        self,
        url: str,
        *,
        params: Any = ...,
        data: Any = ...,
        json: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        files: Any = ...,
        auth: Any = ...,
        timeout: Any = ...,
        allow_redirects: Any = ...,
        max_redirects: Any = ...,
        proxies: Any = ...,
        proxy: Any = ...,
        proxy_auth: Any = ...,
        verify: Any = ...,
        referer: Any = ...,
        accept_encoding: Any = ...,
        content_callback: Any = ...,
        impersonate: Any = ...,
        ja3: Any = ...,
        akamai: Any = ...,
        extra_fp: Any = ...,
        default_headers: Any = ...,
        default_encoding: Any = ...,
        quote: Any = ...,
        http_version: Any = ...,
        interface: Any = ...,
        cert: Any = ...,
        stream: Any = ...,
        max_recv_speed: int = ...,
        multipart: Any = ...,
        discard_cookies: bool = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[CurlCffiResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> CurlCffiResponse: ...
    def put(self, url: str, **kwargs: Any) -> CurlCffiResponse: ...
    def patch(self, url: str, **kwargs: Any) -> CurlCffiResponse: ...
    def delete(self, url: str, **kwargs: Any) -> CurlCffiResponse: ...
    def head(self, url: str, **kwargs: Any) -> CurlCffiResponse: ...
    def options(self, url: str, **kwargs: Any) -> CurlCffiResponse: ...


class HttpxWrappedClient(HttpxClient):
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def request(
        self,
        method: str,
        url: Any,
        *,
        content: Any = ...,
        data: Any = ...,
        files: Any = ...,
        json: Any = ...,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        auth: Any = ...,
        follow_redirects: Any = ...,
        timeout: Any = ...,
        extensions: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[HttpxResponse], bool]] | None = ...,
    ) -> HttpxResponse: ...
    def get(
        self,
        url: Any,
        *,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        auth: Any = ...,
        follow_redirects: Any = ...,
        timeout: Any = ...,
        extensions: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[HttpxResponse], bool]] | None = ...,
    ) -> HttpxResponse: ...
    def post(
        self,
        url: Any,
        *,
        content: Any = ...,
        data: Any = ...,
        files: Any = ...,
        json: Any = ...,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        auth: Any = ...,
        follow_redirects: Any = ...,
        timeout: Any = ...,
        extensions: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[HttpxResponse], bool]] | None = ...,
    ) -> HttpxResponse: ...
    def put(self, url: Any, **kwargs: Any) -> HttpxResponse: ...
    def patch(self, url: Any, **kwargs: Any) -> HttpxResponse: ...
    def delete(self, url: Any, **kwargs: Any) -> HttpxResponse: ...
    def head(self, url: Any, **kwargs: Any) -> HttpxResponse: ...
    def options(self, url: Any, **kwargs: Any) -> HttpxResponse: ...


class TlsClientWrappedSession(TlsClientSession):
    @property
    def docs(self) -> None: ...
    @property
    def supported(self) -> None: ...
    def execute_request(
        self,
        method: str,
        url: str,
        params: Any = ...,
        data: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        json: Any = ...,
        allow_redirects: bool | None = ...,
        insecure_skip_verify: bool | None = ...,
        timeout_seconds: int | None = ...,
        proxy: Any = ...,
        *,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[TlsClientResponse], bool]] | None = ...,
    ) -> TlsClientResponse: ...
    def request(
        self,
        method: str,
        url: str,
        params: Any = ...,
        data: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        json: Any = ...,
        allow_redirects: bool | None = ...,
        insecure_skip_verify: bool | None = ...,
        timeout_seconds: int | None = ...,
        proxy: Any = ...,
        *,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[TlsClientResponse], bool]] | None = ...,
    ) -> TlsClientResponse: ...
    def get(
        self,
        url: str,
        *,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        allow_redirects: bool | None = ...,
        insecure_skip_verify: bool | None = ...,
        timeout_seconds: int | None = ...,
        proxy: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[TlsClientResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> TlsClientResponse: ...
    def post(
        self,
        url: str,
        data: Any = ...,
        json: Any = ...,
        *,
        params: Any = ...,
        headers: Any = ...,
        cookies: Any = ...,
        allow_redirects: bool | None = ...,
        insecure_skip_verify: bool | None = ...,
        timeout_seconds: int | None = ...,
        proxy: Any = ...,
        mode: CacheMode | None = ...,
        filepath: Pathish | None = ...,
        conditions: Iterable[Callable[[TlsClientResponse], bool]] | None = ...,
        **kwargs: Any,
    ) -> TlsClientResponse: ...
    def put(self, url: str, data: Any = ..., json: Any = ..., **kwargs: Any) -> TlsClientResponse: ...
    def patch(self, url: str, data: Any = ..., json: Any = ..., **kwargs: Any) -> TlsClientResponse: ...
    def delete(self, url: str, **kwargs: Any) -> TlsClientResponse: ...
    def head(self, url: str, **kwargs: Any) -> TlsClientResponse: ...
    def options(self, url: str, **kwargs: Any) -> TlsClientResponse: ...
