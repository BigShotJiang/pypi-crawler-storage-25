"""Documentation renderer for the smart_session package."""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .session import SmartSession

_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_MAGENTA = "\033[95m"
_WHITE = "\033[97m"

_BOX_WIDTH = 94

_MODES = [
    ("r", "rb", "Cache-first", "Use disk if present, otherwise fetch and save"),
    ("w", "wb", "Always live", "Always fetch live data and overwrite the cache"),
    ("rr", "rrb", "Read-only", "Replay from disk only and fail if the file is missing"),
]

_EXTENSIONS = [
    ".html",
    ".json",
    ".txt",
    ".xml",
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".csv",
    ".bin",
]


def _colour_supported() -> bool:
    if os.environ.get("NO_COLOR") or os.environ.get("SMART_SESSION_NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _c(text: str, *codes: str) -> str:
    if not _colour_supported():
        return text
    return "".join(codes) + text + _RESET


def _strip_ansi(text: str) -> str:
    import re

    return re.sub(r"\033\[[0-9;]*m", "", text)


def _hline(char: str = "-") -> str:
    return char * _BOX_WIDTH


def _box_top() -> str:
    return _c("+" + _hline() + "+", _CYAN)


def _box_bottom() -> str:
    return _c("+" + _hline() + "+", _CYAN)


def _box_sep() -> str:
    return _c("+" + _hline() + "+", _CYAN)


def _box_row(text: str = "", pad: int = 1) -> str:
    inner = " " * pad + text
    visible = _strip_ansi(inner)
    spaces = max(0, _BOX_WIDTH - len(visible))
    return _c("|", _CYAN) + inner + " " * spaces + _c("|", _CYAN)


def _blank() -> str:
    return _box_row("")


def _section(title: str) -> str:
    return _box_row(_c(f"  {title.upper()}", _BOLD, _CYAN))


def _row(label: str, value: str) -> str:
    label_text = _c(f"{label:<15}", _BOLD, _YELLOW)
    return _box_row(f"{label_text} {value}")


def _print(*lines: str) -> None:
    print("\n".join(lines))


def module_info() -> None:
    """Print a formatted overview of the smart_session package."""
    from . import __author__, __description__, __version__

    _print(
        "",
        _box_top(),
        _box_row(_c(f"  smart_session v{__version__}", _BOLD, _WHITE)),
        _box_row(_c(f"  {__description__}", _DIM)),
        _box_sep(),
        _section("What it does"),
        _blank(),
        _box_row(
            "  Wrap sync HTTP sessions with disk-backed cache modes, response validation,"
        ),
        _box_row(
            "  runtime introspection, and bundled Mongo/network helper utilities."
        ),
        _blank(),
        _box_sep(),
        _section("Quick start"),
        _blank(),
        _box_row(_c("  from curl_cffi import Session", _GREEN)),
        _box_row(_c("  from smart_session import session_wrapper", _GREEN)),
        _blank(),
        _box_row(
            _c("  sess = session_wrapper(Session, impersonate='chrome124')", _GREEN)
        ),
        _box_row(_c("  resp = sess.get(", _GREEN)),
        _box_row(_c("      url,", _GREEN)),
        _box_row(_c("      mode='r',", _GREEN)),
        _box_row(_c("      filepath='cache/page.html',", _GREEN)),
        _box_row(_c("      conditions=[lambda r: r.status_code == 200],", _GREEN)),
        _box_row(_c("  )", _GREEN)),
        _blank(),
        _box_row("  You can also wrap an already-created sync session object."),
        _box_sep(),
        _section("Session wrapper highlights"),
        _blank(),
        _box_row("  Supports clients with .request() or .execute_request()."),
        _box_row("  No mode means plain pass-through to the wrapped session."),
        _box_row("  filepath without mode implies mode='w'."),
        _box_row("  sess.docs prints detailed help for the current wrapped session."),
        _box_row("  sess.supported prints detected verbs, methods, and attributes."),
        _box_row("  debug_mode=True enables cache decision logging through loguru."),
        _box_row("  Async sessions are not supported."),
        _blank(),
        _box_sep(),
        _section("Modes"),
        _blank(),
        _box_row(
            _c("  Mode ", _BOLD, _YELLOW)
            + _c("  Bin  ", _BOLD, _YELLOW)
            + _c("  Behavior", _BOLD, _YELLOW)
        ),
        _box_row(_c("  " + "-" * 76, _DIM)),
    )

    for mode, bmode, label, desc in _MODES:
        _print(
            _box_row(
                _c(f"  {mode:<4}", _BOLD, _GREEN)
                + _c(f"  {bmode:<5}", _BOLD, _MAGENTA)
                + f"  {_c(label, _BOLD)} - {desc}"
            )
        )

    _print(
        _blank(),
        _box_row("  Modes are case-insensitive."),
        _box_row("  Supported cache extensions: " + ", ".join(_EXTENSIONS)),
        _blank(),
        _box_sep(),
        _section("Cached response notes"),
        _blank(),
        _box_row("  Live requests return the wrapped client's native response object."),
        _box_row("  Cache hits and rr replays return a synthesized requests.Response."),
        _box_row("  Replayed responses are rebuilt from disk content with status_code=200."),
        _box_row("  JSON text cache hits also expose resp.json()."),
        _blank(),
        _box_sep(),
        _section("Bundled helper utilities"),
        _blank(),
        _box_row(
            _c(
                "  from smart_session import insert_to_db, get_local_ip, mount_path",
                _GREEN,
            )
        ),
        _blank(),
        _box_row("  insert_to_db() cleans records, adds deterministic ids, timestamps,"),
        _box_row("  source IP metadata, and recursively inserts nested dict/list payloads."),
        _box_row("  get_local_ip() returns a cached private LAN IP or 127.0.0.1."),
        _box_row("  mount_path() mounts a UNC share root with Windows net use."),
        _blank(),
        _box_row("  Import requirement: the helper module is exported at package root,"),
        _box_row("  so current imports also expect pymongo, python-dotenv, and a"),
        _box_row("  config.py file with FEED, MONGO_URI, and MONGO_DB."),
        _blank(),
        _box_sep(),
        _section("More help"),
        _blank(),
        _box_row(_c("  info()         ", _GREEN) + _c("# package overview", _DIM)),
        _box_row(_c("  sess.docs      ", _GREEN) + _c("# wrapper usage for this instance", _DIM)),
        _box_row(_c("  sess.supported ", _GREEN) + _c("# detected wrapped-session surface", _DIM)),
        _blank(),
        _box_row(_c(f"  Maintainer: {__author__}", _DIM)),
        _box_bottom(),
        "",
    )


def session_docs(instance: "SmartSession") -> None:
    """Print full documentation scoped to this SmartSession instance."""

    session = object.__getattribute__(instance, "_session")
    req_attr = object.__getattribute__(instance, "_req_attr")
    debug = object.__getattribute__(instance, "_debug")

    session_type = type(session).__name__
    session_mod = type(session).__module__ or "unknown"

    _print(
        "",
        _box_top(),
        _box_row(_c("  SmartSession instance documentation", _BOLD, _WHITE)),
        _box_sep(),
        _section("Wrapped session"),
        _blank(),
        _row("Type", f"{session_type} ({session_mod})"),
        _row("Dispatch", f".{req_attr}()"),
        _row("Debug mode", str(debug)),
        _blank(),
        _box_sep(),
        _section("Request flow"),
        _blank(),
        _box_row("  1. Call any detected HTTP verb or session.request()."),
        _box_row("  2. If mode is omitted, the wrapped session handles the call directly."),
        _box_row("  3. If filepath is supplied without mode, mode defaults to 'w'."),
        _box_row("  4. If conditions are supplied, they run only on live responses."),
        _box_row("  5. Cache hits and rr replays are served from disk."),
        _blank(),
        _box_sep(),
        _section("Mode reference"),
        _blank(),
    )

    for mode, bmode, label, desc in _MODES:
        _print(
            _box_row(
                _c(f"  {mode:<4}", _BOLD, _GREEN)
                + _c(f"  {bmode:<5}", _BOLD, _MAGENTA)
                + f"  {_c(label, _BOLD)} - {desc}"
            )
        )

    _print(
        _blank(),
        _box_row("  Modes are case-insensitive."),
        _box_row("  Use rb/wb/rrb for binary cache files such as PDFs and images."),
        _blank(),
        _box_sep(),
        _section("filepath rules"),
        _blank(),
        _box_row("  filepath is required whenever mode is set explicitly."),
        _box_row("  It must point to a file, not a directory."),
        _box_row("  It must include one of the supported extensions."),
        _box_row("  Parent directories are created automatically."),
        _box_row("  Tilde expansion is supported."),
        _box_row("  Supported extensions: " + ", ".join(_EXTENSIONS)),
        _blank(),
        _box_sep(),
        _section("conditions"),
        _blank(),
        _box_row("  conditions must be a list of callables that accept the live response."),
        _box_row("  Every callable must return a truthy value."),
        _box_row("  On failure, ValueError is raised and nothing is written to disk."),
        _box_row("  Error messages include the callable source when it can be inspected."),
        _blank(),
        _box_row(_c("  Example:", _BOLD)),
        _box_row(_c("    conditions=[", _GREEN)),
        _box_row(_c("        lambda r: r.status_code == 200,", _GREEN)),
        _box_row(_c("        lambda r: 'captcha' not in r.text.lower(),", _GREEN)),
        _box_row(_c("        lambda r: len(r.content) > 512,", _GREEN)),
        _box_row(_c("    ]", _GREEN)),
        _blank(),
        _box_sep(),
        _section("Response notes"),
        _blank(),
        _box_row("  Live responses keep the wrapped client's original response type."),
        _box_row("  Cached responses are rebuilt as requests.Response objects."),
        _box_row("  Rebuilt text responses use UTF-8 and status_code=200."),
        _box_row("  JSON text caches also support resp.json()."),
        _blank(),
        _box_sep(),
        _section("Examples"),
        _blank(),
        _box_row(_c("  resp = sess.get(", _GREEN)),
        _box_row(_c("      'https://county.gov/property/12345',", _GREEN)),
        _box_row(_c("      mode='r',", _GREEN)),
        _box_row(_c("      filepath='cache/property_12345.html',", _GREEN)),
        _box_row(_c("      conditions=[lambda r: r.status_code == 200],", _GREEN)),
        _box_row(_c("  )", _GREEN)),
        _blank(),
        _box_row(_c("  resp = sess.get(", _GREEN)),
        _box_row(_c("      'https://example.com/report.pdf',", _GREEN)),
        _box_row(_c("      mode='rb',", _GREEN)),
        _box_row(_c("      filepath='cache/report.pdf',", _GREEN)),
        _box_row(_c("  )", _GREEN)),
        _blank(),
        _box_bottom(),
        "",
    )
