# pyright: reportOverlappingOverload=false
from __future__ import annotations

from typing import Any, TypeVar, overload

from cloudscraper import CloudScraper
from curl_cffi.requests import Session as CurlCffiSession
from httpx import Client as HttpxClient
from requests import Session as RequestsSession
from tls_client import Session as TlsClientSession

from ._dbcore import (
    get_local_ip as get_local_ip,
    insert_to_db as insert_to_db,
    mount_path as mount_path,
)
from ._docs import module_info as info
from .session import (
    CloudScraperWrappedSession,
    CurlCffiWrappedSession,
    HttpxWrappedClient,
    RequestsWrappedSession,
    TlsClientWrappedSession,
)

T = TypeVar("T")

@overload
def session_wrapper(
    base: type[CloudScraper],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> CloudScraperWrappedSession: ...
@overload
def session_wrapper(
    base: CloudScraper,
    *,
    debug_mode: bool = ...,
) -> CloudScraperWrappedSession: ...
@overload
def session_wrapper(
    base: type[CurlCffiSession],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> CurlCffiWrappedSession: ...
@overload
def session_wrapper(
    base: CurlCffiSession,
    *,
    debug_mode: bool = ...,
) -> CurlCffiWrappedSession: ...
@overload
def session_wrapper(
    base: type[HttpxClient],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> HttpxWrappedClient: ...
@overload
def session_wrapper(
    base: HttpxClient,
    *,
    debug_mode: bool = ...,
) -> HttpxWrappedClient: ...
@overload
def session_wrapper(
    base: type[TlsClientSession],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> TlsClientWrappedSession: ...
@overload
def session_wrapper(
    base: TlsClientSession,
    *,
    debug_mode: bool = ...,
) -> TlsClientWrappedSession: ...
@overload
def session_wrapper(
    base: type[RequestsSession],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> RequestsWrappedSession: ...
@overload
def session_wrapper(
    base: RequestsSession,
    *,
    debug_mode: bool = ...,
) -> RequestsWrappedSession: ...
@overload
def session_wrapper(
    base: type[T],
    *args: Any,
    debug_mode: bool = ...,
    **kwargs: Any,
) -> T: ...
@overload
def session_wrapper(
    base: T,
    *,
    debug_mode: bool = ...,
) -> T: ...

__version__: str
__description__: str
__author__: str
__author_email__: str
__maintainer__: str
__maintainer_email__: str

__all__: list[str]
