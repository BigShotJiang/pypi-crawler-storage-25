# __init__.py
from pathlib import Path
from .session import SmartSession as session_wrapper
# After
from ._dbcore import (
    insert_to_db as insert_to_db,        # re-export trick — tells pylance
    get_local_ip as get_local_ip,        # these are intentional public exports
    mount_path as mount_path,
)

from ._docs import module_info as info




def _read_version():
    try:
        return (
            (Path(__file__).parent.parent / "version.txt")
            .read_text(encoding="utf-8")
            .strip()
        )
    except Exception:
        return "0.0.0"


__version__ = _read_version()
__description__ = (
    "Sync HTTP session wrapper with cache modes, response validation, "
    "introspection, and bundled Mongo/network helpers"
)
__author__ = "dharmik.vadher@xbyte.io"
__author_email__ = "dharmik.vadher@xbyte.io"
__maintainer__ = "dharmik.vadher@xbyte.io"
__maintainer_email__ = "dharmik.vadher@xbyte.io"

__doc__ = f"""
smart_session v{__version__}
{__description__}

Wrap sync HTTP sessions with transparent disk caching, response validation,
per-request cache modes, and helper utilities for Mongo/network workflows.

Quick start:
    from smart_session import session_wrapper
    sess = session_wrapper(Session, impersonate="chrome124")
    resp = sess.get(
        url,
        mode="r",
        filepath="cache/page.html",
        conditions=[lambda r: r.status_code == 200],
    )

Session helper highlights:
    - wrap a class or an existing sync session object
    - supports .request() and .execute_request() dispatch methods
    - filepath without mode defaults to mode="w"
    - cache hits replay as requests.Response objects
    - sess.docs and sess.supported expose runtime help

Full documentation:
    import smart_session
    smart_session.info()     # module overview
    sess.docs                # instance documentation
    sess.supported           # detected wrapped-session surface

Bundled utilities:
    from smart_session import insert_to_db, get_local_ip, mount_path
"""

__all__ = ["session_wrapper", "info","insert_to_db" , "get_local_ip" , "mount_path"]
