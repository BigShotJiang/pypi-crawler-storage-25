from __future__ import annotations

from typing import Any, Dict, List, TypedDict, Union
from pymongo.collection import Collection


class InsertMetadata(TypedDict, total=False):
    source: str
    source_url: str
    spider: str
    spider_name: str
    job_id: str
    run_id: str
    batch_id: str
    state: str
    county: str
    city: str
    country: str
    region: str
    dataset: str
    category: str


def insert_to_db(
    data: Union[Dict[str, Any], List[Dict[str, Any]]],
    output_col: Union[Collection, str],
    input_field: str,
    page_save: str,
    feed: str | None = ...,
    *,
    source: str | None = ...,
    source_url: str | None = ...,
    spider: str | None = ...,
    spider_name: str | None = ...,
    job_id: str | None = ...,
    run_id: str | None = ...,
    batch_id: str | None = ...,
    state: str | None = ...,
    county: str | None = ...,
    city: str | None = ...,
    country: str | None = ...,
    region: str | None = ...,
    dataset: str | None = ...,
    category: str | None = ...,
    **kwargs: Any,
) -> bool: ...


def get_local_ip() -> str: ...


def mount_path(path: str, user: str = ..., pwd: str = ...) -> None: ...
