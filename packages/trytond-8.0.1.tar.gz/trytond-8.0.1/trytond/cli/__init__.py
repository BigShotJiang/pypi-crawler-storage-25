# PYTHON_ARGCOMPLETE_OK
# This file is part of Tryton.  The COPYRIGHT file at the top level of
# this repository contains the full copyright notices and license terms.

import glob
import logging
import os
import threading

import trytond.commandline as commandline
import trytond.config as config


def main():

    parser = commandline.get_parser_daemon()
    commandline.set_autocomplete(parser)
    options = parser.parse_args()
    commandline.config_log(options)
    extra_files = config.update_etc(options.configfile)

    if options.coroutine:
        # Monkey patching must be done before importing
        from gevent import monkey
        monkey.patch_all()

    from trytond.modules import get_module_info, get_modules
    from trytond.pool import Pool
    # Import trytond things after it is configured
    from trytond.wsgi import app

    with commandline.pidfile(options):
        Pool.start()
        threads = []
        for name in options.database_names:
            thread = threading.Thread(target=lambda: Pool(name).init())
            thread.start()
            threads.append(thread)
        for thread in threads:
            thread.join()
        hostname, port = config.split_netloc(config.get('web', 'listen'))
        certificate = config.get('ssl', 'certificate')
        try:
            if config.getboolean('ssl', 'certificate'):
                certificate = None
        except ValueError:
            pass
        privatekey = config.get('ssl', 'privatekey')
        try:
            if config.getboolean('ssl', 'privatekey'):
                privatekey = None
        except ValueError:
            pass
        if certificate or privatekey:
            from werkzeug.serving import load_ssl_context
            ssl_args = dict(
                ssl_context=load_ssl_context(certificate, privatekey))
        else:
            ssl_args = {}
        if options.dev and not options.coroutine:
            for module in get_modules():
                info = get_module_info(module)
                for ext in [
                        'cfg', 'xml',
                        'fodt', 'odt',
                        'fodp', 'odp',
                        'fods', 'ods',
                        'fodg', 'odg',
                        'txt', 'html', 'xhtml']:
                    path = os.path.join(info['directory'], '**', '*.' + ext)
                    extra_files.extend(glob.glob(path, recursive=True))
        app.dev = options.dev

        if options.coroutine:
            from gevent.pywsgi import WSGIServer
            logger = logging.getLogger('gevent')
            WSGIServer((hostname, port), app,
                log=logger,
                error_log=logger,
                **ssl_args).serve_forever()
        else:
            from werkzeug.serving import run_simple
            run_simple(hostname, port, app,
                threaded=True,
                extra_files=extra_files,
                use_reloader=options.dev,
                **ssl_args)


if __name__ == '__main__':
    main()
