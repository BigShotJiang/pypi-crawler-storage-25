from __future__ import annotations

import asyncio
import os
import re
import sys
import time
import warnings
from typing import Any, Callable, Literal, Mapping, cast

from langchain.agents import create_agent
from langchain.agents.middleware import (
    ModelCallLimitMiddleware,
    ModelRetryMiddleware,
    ToolCallLimitMiddleware,
    ToolRetryMiddleware,
)
from langchain_core.documents import Document
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from tenacity import retry, stop_after_attempt, wait_exponential

from . import prompts
from ._internal import llm_cache as _cache
from ._internal.boost import BoostSignals
from ._internal.context import RAGContext
from .helpers.disk_cache import (
    field_rank_cache_load,
    filters_cache_load,
    filters_cache_save,
)
from .helpers.render import _doc_to_grader_text, _render_value
from .embed.embedder import Embedder, coerce_embedder
from .helpers.schema_introspect import _align_embedder_with_backend
from .retrieval.intent_match import (
    _content_contains_exclusion,
    _doc_matches_intent,
)
from .retrieval.result import RetrievalResult
from .mixins.filter_detection import FilterDetectionMixin
from .mixins.memory import MemoryMixin
from ._internal.memory import LangGraphStoreMemory, Mem0Memory, Memory
from .backend import (
    _ACTIVE_COLLECTIONS,
    SearchBackend,
    SearchRequest,
)
from .config import RAGConfig
from .models import (
    AnswerGrade,
    CloseMatchKeep,
    ConversationTurn,
    FilterIntent,
    MultiQuery,
    NoResultSuggestion,
    ProductCodeQuery,
    RAGState,
    RelevanceCheck,
    Reranker,
    SearchQuery,
    StandaloneQuery,
    SynonymResult,
)
from .rerankers import CohereReranker, LLMReranker
from .tools import RAGToolset
from .utils import (
    _SKIP_FIELDS,
    _dbsf_fuse,
    _doc_id,
    _mmr_diverse,
    _rrf_fuse,
    _run_sync,
    _strip_stop_words,
)

warnings.filterwarnings(
    "ignore",
    message="Pydantic serializer warnings",
    category=UserWarning,
    module="pydantic",
)
warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
    module="langchain_core",
)

_llm_retry = retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    reraise=True,
)


_BRAND_FIELDS = frozenset({"supplier_name", "brand", "manufacturer_name", "vendor"})


def _is_brand_intent(intent: FilterIntent) -> bool:
    return intent.field in _BRAND_FIELDS and intent.operator in (
        "=",
        "==",
        "CONTAINS",
    )


_FILTER_INTENT_WORDS_BY_LANG: dict[str, frozenset[str]] = {
    "de": frozenset(
        {
            "von",
            "vom",
            "aus",
            "ohne",
            "nicht",
            "kein",
            "keine",
            "für",
            "fur",
            "bei",
            "mit",
        }
    ),
    "fr": frozenset({"de", "du", "des", "sans", "pour", "par", "pas", "avec", "chez"}),
    "it": frozenset({"di", "da", "del", "della", "senza", "non", "per", "con"}),
    "en": frozenset({"from", "without", "not", "no", "for", "by", "of", "with"}),
}

# Generic identifier heuristic — single-token alphanumeric value that
# contains at least one digit, optionally with `-`, `_`, `.`, or `/` as
# separators. Catches SKUs (BOSCH-12345), part numbers (M8x40), thread
# sizes (G1/2"), article IDs (9148594), short codes (ABC-123). Excludes
# plain dictionary words. Length bounded so we don't fast-track free
# text that happens to contain a digit.
_ID_LIKE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-./]{2,39}$")


def _looks_like_id(token: str) -> bool:
    """Single-token identifier heuristic — must contain a digit AND
    match the alphanumeric+separator shape. Single source of truth so
    the fast-accept gate and retrieve_single agree."""
    if not token or " " in token or "\t" in token:
        return False
    if not _ID_LIKE_RE.fullmatch(token):
        return False
    return any(c.isdigit() for c in token)

_UNKNOWN_FIELD_RANK = 10


def _filter_bohrer_variants(
    question: str, corrected_query: str, variants: list[str]
) -> list[str]:
    orig = (question + " " + corrected_query).lower()
    if "bohrer" in orig or "bohrschrauber" in orig:
        return variants
    return [
        v
        for v in variants
        if "bohrer" not in v.lower() and "bohrschrauber" not in v.lower()
    ]


class AgenticRAG(FilterDetectionMixin, MemoryMixin):
    @staticmethod
    def _llm_seed() -> int:
        return int(os.getenv("RAG_LLM_SEED", "42"))

    @staticmethod
    def _default_llm(
        *,
        timeout: int = 30,
    ) -> BaseChatModel:
        if os.getenv("AZURE_OPENAI_ENDPOINT"):
            from langchain_openai import AzureChatOpenAI

            deploy = os.getenv("AZURE_OPENAI_FAST_DEPLOYMENT") or os.getenv(
                "AZURE_OPENAI_DEPLOYMENT"
            )
            return AzureChatOpenAI(  # type: ignore[call-arg]
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                azure_deployment=deploy,  # ty: ignore[unknown-argument]
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),  # ty: ignore[unknown-argument]
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),  # ty: ignore[unknown-argument]
                seed=AgenticRAG._llm_seed(),
                request_timeout=timeout,  # type: ignore[call-arg]
            )

        from langchain_openai import ChatOpenAI

        return ChatOpenAI(  # type: ignore[call-arg]
            model=os.getenv("OPENAI_MODEL", "gpt-5.4"),  # ty: ignore[unknown-argument]
            api_key=os.getenv("OPENAI_API_KEY"),  # ty: ignore[unknown-argument]
            seed=AgenticRAG._llm_seed(),
            request_timeout=timeout,  # type: ignore[call-arg]
        )

    @staticmethod
    def _default_gen_llm() -> BaseChatModel:
        if os.getenv("AZURE_OPENAI_ENDPOINT"):
            from langchain_openai import AzureChatOpenAI

            deploy = os.getenv("AZURE_OPENAI_GENERATION_DEPLOYMENT") or os.getenv(
                "AZURE_OPENAI_DEPLOYMENT"
            )
            return AzureChatOpenAI(  # type: ignore[call-arg]
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                azure_deployment=deploy,  # ty: ignore[unknown-argument]
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),  # ty: ignore[unknown-argument]
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),  # ty: ignore[unknown-argument]
                seed=AgenticRAG._llm_seed(),
                request_timeout=60,  # type: ignore[call-arg]
            )

        from langchain_openai import ChatOpenAI

        return ChatOpenAI(  # type: ignore[call-arg]
            model=os.getenv("OPENAI_MODEL", "gpt-5.4"),  # ty: ignore[unknown-argument]
            api_key=os.getenv("OPENAI_API_KEY"),  # ty: ignore[unknown-argument]
            seed=AgenticRAG._llm_seed(),
            request_timeout=60,  # type: ignore[call-arg]
        )

    @staticmethod
    def _resolve_llm(spec: str, timeout: int = 30) -> BaseChatModel:
        from langchain.chat_models import init_chat_model

        if spec.startswith("azure:"):
            spec = "azure_openai:" + spec.split(":", 1)[1]

        kwargs: dict[str, Any] = {"temperature": 0, "seed": AgenticRAG._llm_seed()}
        if spec.startswith("azure_openai:"):
            kwargs.update(
                azure_deployment=spec.split(":", 1)[1],
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                request_timeout=timeout,
            )
        return init_chat_model(spec, **kwargs)  # type: ignore[return-value]

    @staticmethod
    def _chain_llm(llm: BaseChatModel, name: str) -> BaseChatModel:
        try:
            from langchain_openai import AzureChatOpenAI

            if isinstance(llm, AzureChatOpenAI):
                return llm
        except ImportError:
            pass
        try:
            from langchain_openai import ChatOpenAI

            if isinstance(llm, ChatOpenAI):
                return cast(
                    BaseChatModel,
                    llm.bind(
                        model_kwargs={"prompt_cache_key": f"retrievalagent-{name}-v1"}
                    ),
                )
        except ImportError:
            pass
        return llm

    @staticmethod
    def _default_reranker() -> CohereReranker | LLMReranker:
        try:
            return CohereReranker()
        except Exception as e:
            import warnings

            warnings.warn(
                f"CohereReranker unavailable ({type(e).__name__}: {e}). "
                "Falling back to LLMReranker with no LLM — reranker will return "
                "positional fallback scores (1/i), effectively a no-op. "
                "Install cohere (`uv pip install cohere`) or configure a reranker explicitly.",
                stacklevel=2,
            )
            return LLMReranker()

    @classmethod
    def from_model(
        cls,
        model: str,
        index: str,
        *,
        gen_model: str | None = None,
        configurable_fields: str | list[str] | None = None,
        **kwargs: Any,
    ) -> "AgenticRAG":
        from langchain.chat_models import (
            init_chat_model,  # type: ignore[import-untyped]
        )

        init_kwargs: dict[str, Any] = {"temperature": 0}
        if configurable_fields is not None:
            init_kwargs["configurable_fields"] = configurable_fields

        llm = init_chat_model(model, **init_kwargs)
        gen_llm = init_chat_model(gen_model, **init_kwargs) if gen_model else llm
        return cls(index=index, llm=llm, gen_llm=gen_llm, **kwargs)

    def __init__(
        self,
        index: str,
        *,
        backend: SearchBackend | None = None,
        collections: Mapping[str, SearchBackend] | None = None,
        collection_descriptions: Mapping[str, str] | None = None,
        llm: BaseChatModel | None = None,
        gen_llm: BaseChatModel | None = None,
        reranker: Reranker | CohereReranker | LLMReranker | None = None,
        top_k: int | None = None,
        rerank_top_n: int | None = None,
        retrieval_factor: int | None = None,
        max_iter: int | None = None,
        instructions: str = "",
        n_swarm_queries: int | None = None,
        embed_fn: Embedder | Callable[[str], list[float]] | None = None,
        embedder_name: str | None = None,
        semantic_ratio: float | None = None,
        boost_fn: Callable[[dict], float] | None = None,
        sort_fields: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        base_filter: str | None = None,
        rerank_chars: int | None = None,
        hyde_min_words: int | None = None,
        auto_strategy: bool = True,
        group_field: str = "",
        name_field: str = "",
        category_fields: list[str] | None = None,
        fusion: Literal["rrf", "dbsf"] | None = None,
        expert_reranker: Reranker | CohereReranker | LLMReranker | None = None,
        expert_top_n: int | None = None,
        expert_threshold: float | None = None,
        verbose: bool | None = None,
        checkpointer: Any = None,
        memory_store: Any = None,
        mem0_memory: Any = None,
        config: "RAGConfig | None" = None,
        trace_callback: Callable[[dict[str, Any]], None] | None = None,
    ):
        self.index = index
        if base_filter is not None:
            warnings.warn(
                "`base_filter` is deprecated, use `filter` instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if filter is None:
                filter = base_filter

        ctx = RAGContext.build(
            backend=backend,
            collections=collections,
            collection_descriptions=collection_descriptions,
            llm=llm,
            gen_llm=gen_llm,
            reranker=reranker,
            expert_reranker=expert_reranker,
            top_k=top_k,
            rerank_top_n=rerank_top_n,
            retrieval_factor=retrieval_factor,
            max_iter=max_iter,
            instructions=instructions,
            n_swarm_queries=n_swarm_queries,
            embed_fn=embed_fn,
            embedder_name=embedder_name,
            semantic_ratio=semantic_ratio,
            boost_fn=boost_fn,
            sort_fields=sort_fields,
            filter=filter,
            rerank_chars=rerank_chars,
            hyde_min_words=hyde_min_words,
            group_field=group_field,
            name_field=name_field,
            category_fields=category_fields,
            fusion=fusion,
            expert_top_n=expert_top_n,
            expert_threshold=expert_threshold,
            verbose=verbose,
            checkpointer=checkpointer,
            memory_store=memory_store,
            mem0_memory=mem0_memory,
            config=config,
            trace_callback=trace_callback,
            resolve_llm=self._resolve_llm,
            default_llm=self._default_llm,
            default_gen_llm=self._default_gen_llm,
            default_reranker=self._default_reranker,
            chain_llm=self._chain_llm,
        )

        # backend / collections
        self.backend = ctx.backend
        self.collections: dict[str, SearchBackend] | None = ctx.collections
        self.collection_descriptions: dict[str, str] = ctx.collection_descriptions

        # numeric knobs
        self.top_k = ctx.top_k
        self.rerank_top_n = ctx.rerank_top_n
        self.retrieval_factor = ctx.retrieval_factor
        self.min_rerank_pool = ctx.min_rerank_pool
        self.memory_relevance_threshold = ctx.memory_relevance_threshold
        self.memory_storage_threshold = ctx.memory_storage_threshold
        self.max_iter = ctx.max_iter
        self.n_swarm_queries = ctx.n_swarm_queries
        self.rerank_chars = ctx.rerank_chars
        self.hyde_min_words = ctx.hyde_min_words
        self.expert_top_n = ctx.expert_top_n
        self.expert_threshold = ctx.expert_threshold
        self.semantic_ratio = ctx.semantic_ratio
        self._rerank_cap_multiplier = ctx.rerank_cap_multiplier
        self._short_query_threshold = ctx.short_query_threshold
        self._short_query_sort_tokens = ctx.short_query_sort_tokens
        self._bm25_fallback_threshold = ctx.bm25_fallback_threshold
        self._bm25_fallback_semantic_ratio = ctx.bm25_fallback_semantic_ratio
        self._fast_accept_score: float | None = ctx.fast_accept_score
        self._fast_accept_confidence: float | None = ctx.fast_accept_confidence
        self._rerank_min_score: float | None = ctx.rerank_min_score
        self._name_field_boost_max: float = ctx.name_field_boost_max
        self._preview_chars: int = ctx.preview_chars
        self._final_grade_threshold = ctx.final_grade_threshold
        self._reranker_trust_top_score = ctx.reranker_trust_top_score
        self._reranker_trust_score_gap = ctx.reranker_trust_score_gap
        self._n_synonym_variants = ctx.n_synonym_variants
        self._close_match_min_top_rerank: float | None = ctx.close_match_min_top_rerank
        self._rerank_timeout_s = ctx.rerank_timeout_s
        self._llm_timeout_s = ctx.llm_timeout_s

        # flags / strings
        self.verbose = ctx.verbose
        self.fusion: Literal["rrf", "dbsf"] = ctx.fusion
        self.instructions = ctx.instructions
        self.filter = ctx.filter
        self.group_field = ctx.group_field
        self.name_field = ctx.name_field
        self._enable_hyde = ctx.enable_hyde
        self._enable_filter_intent = ctx.enable_filter_intent
        self._enable_preprocess_llm = ctx.enable_preprocess_llm
        self._enable_final_grade = ctx.enable_final_grade
        self._enable_swarm_grade = ctx.enable_swarm_grade
        self._enable_reranker = ctx.enable_reranker
        self._enable_close_match_grader = ctx.enable_close_match_grader
        self._close_match_strictness: str = ctx.close_match_strictness
        self._custom_instructions: str = ctx.custom_instructions
        self.embedder_name = ctx.embedder_name

        # callables / structured data
        # Normalize embed_fn → Embedder (#7): callable lifts via
        # CallableEmbedder, dim-aligned to backend. embed_fn stays as a
        # back-compat alias since Embedder is callable via __call__.
        self.embedder: Embedder | None = _align_embedder_with_backend(
            coerce_embedder(ctx.embed_fn), ctx.backend
        )
        self.embed_fn: Callable[[str], list[float]] | None = (
            self.embedder if self.embedder is not None else None
        )
        self.boost_fn = ctx.boost_fn
        self.sort_fields = ctx.sort_fields
        self.num_fields = ctx.num_fields
        self.category_fields = ctx.category_fields
        self._primary_preference_field = ctx.primary_preference_field
        self._has_own_brand_field = ctx.has_own_brand_field
        self._filter_intent_words: frozenset[str] = ctx.filter_intent_words
        self.trace_callback: Callable[[dict[str, Any]], None] | None = (
            ctx.trace_callback
        )

        # llms
        self._llm = ctx.llm
        self._gen_llm = ctx.gen_llm
        self._thinking_llm: BaseChatModel = ctx.thinking_llm
        self._grader_llm: BaseChatModel = ctx.grader_llm
        self._reranker = ctx.reranker
        self._expert_reranker = ctx.expert_reranker

        # mutable scratch + background task set
        self._field_values_cache: dict = ctx.field_values_cache
        self._filter_values: dict[str, list[str]] = ctx.filter_values
        self._background_tasks: set[asyncio.Task[Any]] = set()

        # mixin-state init runs against the freshly populated agent
        if auto_strategy:
            self._auto_init_filters()

        # backend index config + structured chains
        self._index_config = ctx.index_config
        self._search_query_chain = ctx.search_query_chain
        self._quality_chain = ctx.quality_chain
        self._multi_query_chain = ctx.multi_query_chain
        self._synonym_chain = ctx.synonym_chain
        self._suggestion_chain = ctx.suggestion_chain
        self._standalone_chain = ctx.standalone_chain
        self._filter_intent_chain = ctx.filter_intent_chain
        self._select_collection_chain = ctx.select_collection_chain
        self._field_priority_chain = ctx.field_priority_chain
        self._relevance_chain = ctx.relevance_chain
        self._grade_chain = ctx.grade_chain
        self._product_code_chain = ctx.product_code_chain
        self._close_match_chain = ctx.close_match_chain
        # Strong grader — used as escalation when the cheap grader's
        # output looks sparse / low-confidence. Only fires on hard
        # queries; for clear winners the cheap grader returns and the
        # strong chain is never invoked.
        self._close_match_chain_strong = ctx.close_match_chain_strong

        self._toolset = RAGToolset(self)
        self._tools = self._toolset.as_tools()
        self._checkpointer = ctx.checkpointer
        self._memory_store = ctx.memory_store
        self._mem0_memory = ctx.mem0_memory
        memories: list[Memory] = []
        if ctx.memory_store is not None:
            memories.append(LangGraphStoreMemory(ctx.memory_store))
        if ctx.mem0_memory is not None:
            memories.append(
                Mem0Memory(
                    ctx.mem0_memory,
                    relevance_threshold=self.memory_relevance_threshold,
                )
            )
        self._memories: list[Memory] = memories
        self._graph = self._build_graph()
        self._agent = self._build_agent()

    @property
    def base_filter(self) -> str | None:
        warnings.warn(
            "`base_filter` attribute is deprecated, use `filter` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.filter

    @base_filter.setter
    def base_filter(self, value: str | None) -> None:
        warnings.warn(
            "`base_filter` attribute is deprecated, use `filter` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.filter = value

    def _auto_init_filters(self) -> None:
        """Deterministic init: schema inference + filter-value discovery.

        Samples documents once, widens rerank_chars if docs are long, infers
        name/group fields, then discovers filterable attributes and a small
        set of distinct values per field so the filter-intent agent knows
        what filters are available.
        """
        try:
            sample = self.backend.sample_documents(
                limit=15,
                filter_expr=self.filter,
            )
            if not sample:
                return
            max_doc_chars = 0
            for h in sample[:5]:
                items = [
                    (k, str(v))
                    for k, v in h.items()
                    if k not in _SKIP_FIELDS and v and isinstance(v, (str, int, float))
                ]
                max_doc_chars = max(max_doc_chars, sum(len(v) for _, v in items))

            # 16384 chars ≈ 4096 Cohere v3.5 tokens — gives the reranker
            # the full doc on rerank-v3.5 and rerank-multilingual-v3.5.
            # If the user is on the older v2 (512-token cap), they should
            # set rerank_chars=2000 explicitly — the cap below v2's
            # actual ceiling (~2400 chars).
            if max_doc_chars > self.rerank_chars:
                self.rerank_chars = min(16384, int(max_doc_chars * 1.2))

            self._infer_name_and_group_fields(sample)

            schema_sig = self._schema_signature(sample)
            cached = filters_cache_load(schema_sig)
            if cached is not None:
                self._filter_values = {k: list(v) for k, v in cached.items()}
                return

            try:
                filterable = self.backend.get_index_config().filterable_attributes
            except Exception:
                filterable = []

            if not filterable:
                self._filter_values = {}
                filters_cache_save(schema_sig, {})
                return

            # One extra broader sample to improve coverage of distinct values.
            try:
                extra = self.backend.sample_documents(
                    limit=200, filter_expr=self.filter
                )
            except Exception:
                extra = []
            combined = list(sample) + list(extra)

            discovered: dict[str, list[str]] = {}
            for attr in filterable:
                seen: set[str] = set()
                values: list[str] = []
                for h in combined:
                    v = h.get(attr)
                    if v is None or v == "":
                        continue
                    for item in v if isinstance(v, list) else [v]:
                        s = str(item)
                        if s and s not in seen:
                            seen.add(s)
                            values.append(s)
                            if len(values) >= 20:
                                break
                    if len(values) >= 20:
                        break
                if values:
                    discovered[attr] = sorted(values)[:20]

            self._filter_values = discovered
            filters_cache_save(schema_sig, discovered)
        except Exception as e:
            self._filter_values = {}
            print(
                f"  [{self.index}] filter-value discovery failed ({e}), using empty dict"
            )

    def _infer_name_and_group_fields(self, sample: list[dict]) -> None:
        if self.name_field and self.group_field:
            return
        try:
            raw = self.backend.get_index_config().searchable_attributes
        except Exception:
            raw = []
        attrs = [a.split(":", 1)[0] for a in raw if a and not a.startswith("*")]
        first_doc = sample[0] if sample else {}

        def _looks_like_id(field: str) -> bool:
            return field.lower() in {
                "id",
                "_id",
                "uid",
                "uuid",
            } or field.lower().endswith("_id")

        def _is_string_field(field: str) -> bool:
            v = first_doc.get(field)
            return isinstance(v, str) and len(v.strip()) > 0

        if not self.name_field:
            candidates = [
                a for a in attrs if a.lower().endswith("_name") and _is_string_field(a)
            ]
            if not candidates:
                candidates = [
                    a for a in attrs if not _looks_like_id(a) and _is_string_field(a)
                ]
            if candidates:
                self.name_field = candidates[0]

        if not self.group_field:
            candidates = [
                a
                for a in attrs
                if any(
                    tok in a.lower() for tok in ("group", "category", "class", "type")
                )
                and not _looks_like_id(a)
                and _is_string_field(a)
            ]
            if candidates:
                self.group_field = candidates[0]

        known_fields = sorted({k for d in sample[:5] for k in d.keys()})
        offset = len(attrs)
        self._field_priority: dict[str, int] = {
            field.split(":", 1)[0]: i for i, field in enumerate(attrs)
        }
        gap_fields = [
            field.split(":", 1)[0]
            for field in known_fields
            if field.split(":", 1)[0] not in self._field_priority
        ]
        schema_sig = self._schema_signature(sample)
        cached_ranks = field_rank_cache_load(schema_sig)
        # Each gap field gets a UNIQUE rank so render order is stable.
        # With LLM-cached ranks: use those (semantic priority). Without:
        # fall back to alphabetical position so every doc renders fields
        # in the same order — important for grader/reranker consistency
        # across docs in the same query.
        for i, base in enumerate(gap_fields):
            if cached_ranks and base in cached_ranks:
                self._field_priority[base] = offset + cached_ranks[base]
            else:
                self._field_priority[base] = offset + _UNKNOWN_FIELD_RANK + i
        self._field_priority_sample: list[dict] = list(sample[:5])
        self._field_priority_unranked: list[str] = [] if cached_ranks else gap_fields

    def _schema_signature(self, sample: list[dict]) -> str:
        import hashlib

        doc_keys = sorted({k for d in sample[:5] for k in d.keys()})
        try:
            filterable = sorted(self.backend.get_index_config().filterable_attributes)
        except Exception:
            filterable = []

        if self.collections:
            index_sig = ",".join(sorted(self.collections.keys()))
        else:
            index_sig = self.index
        raw = f"{index_sig}|{','.join(doc_keys)}|{','.join(filterable)}"
        return hashlib.sha1(raw.encode()).hexdigest()[:12]

    def _sys(self, prompt: str) -> SystemMessage:
        if self.instructions:
            return SystemMessage(f"{self.instructions}\n\n{prompt}")
        return SystemMessage(prompt)

    def _hit_to_text(self, h: dict) -> str:
        content = h.get("content")
        fp: dict[str, int] = getattr(self, "_field_priority", {})

        items: list[tuple[int, str]] = []
        for k, v in h.items():
            if k in _SKIP_FIELDS or k == "content" or v is None or v == "":
                continue
            rendered = _render_value(v, indent=0)
            if not rendered:
                continue
            rank = fp.get(k)
            if rank is None:
                if isinstance(v, str) and content and rendered in content:
                    continue
                rank = 1000 + _UNKNOWN_FIELD_RANK
            line = (
                f"**{k}**:\n{rendered}"
                if "\n" in rendered and not isinstance(v, str)
                else f"**{k}**: {rendered}"
            )
            items.append((rank, line))

        sorted_lines = [line for _, line in sorted(items)]
        parts = sorted_lines + ([str(content)] if content else [])
        return "\n".join(parts) if parts else ""

    def _make_search_request(
        self,
        query: str,
        limit: int,
        *,
        vector: list[float] | None = None,
        semantic_ratio: float | None = None,
        filter_expr: str | None = None,
        sort_fields: list[str] | None = None,
        show_ranking_score: bool = False,
    ) -> SearchRequest:
        filters = [f for f in [self.filter, filter_expr] if f]
        return SearchRequest(
            query=query,
            limit=limit,
            vector=vector,
            semantic_ratio=semantic_ratio
            if semantic_ratio is not None
            else self.semantic_ratio,
            filter_expr=" AND ".join(filters) if filters else None,
            sort_fields=sort_fields,
            show_ranking_score=show_ranking_score,
            embedder_name=self.embedder_name,
            index_uid=self.index,
        )

    @_llm_retry
    async def _ahypothetical_doc(self, query: str) -> str:
        cached = await _cache.aload("hyde-v2", "", query)
        if cached:
            return str(cached)
        result = await self._llm.ainvoke(
            [
                self._sys(prompts.hyde_system()),
                HumanMessage(query),
            ]
        )
        text = str(result.content).strip() or query
        await _cache.asave("hyde-v2", "", query, value=text)
        return text

    def _cached_batch_search(self, requests: "list[Any]") -> "list[list[dict]]":
        key = tuple(
            (
                r.query,
                r.limit,
                r.semantic_ratio,
                r.filter_expr or "",
                tuple(r.sort_fields) if r.sort_fields else (),
                r.show_ranking_score,
                r.matching_strategy,
                r.embedder_name,
                r.index_uid or "",
            )
            for r in requests
        )
        cached = _cache.load("batch-search-v1", self.index, key)
        if cached is not None:
            return cached
        results = self.backend.batch_search(requests)
        _cache.save("batch-search-v1", self.index, key, value=results)
        return results

    def _multi_search(
        self,
        queries: list[str],
        lang: str | None = None,
        vectors: list[list[float] | None] | None = None,
        filter_expr: str | None = None,
    ) -> list[Document]:
        limit = self._rerank_pool_size(self.top_k)
        vecs: list[list[float] | None] = vectors if vectors else [None] * len(queries)

        parts = [p for p in [f"language = {lang}" if lang else None, filter_expr] if p]
        combined_filter = " AND ".join(f"({p})" for p in parts) if parts else None

        requests = [
            self._make_search_request(q, limit, vector=v, filter_expr=combined_filter)
            for q, v in zip(queries, vecs)
        ]
        results = self._cached_batch_search(requests)
        fused = _rrf_fuse(results)
        return [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in fused[:limit]
        ]

    async def _apreprocess(self, state: RAGState) -> RAGState:
        t0 = time.perf_counter()

        if not self._enable_preprocess_llm:
            raw = _strip_stop_words(state.question) or state.question
            new = state.model_copy(
                update={
                    "query": raw,
                    "query_variants": [],
                    "adaptive_semantic_ratio": None,
                    "adaptive_fusion": None,
                }
            )
            self._trace(new, "preprocess", t0, path="disabled", query=raw)
            return new

        # The 3-tier swarm ladder (ID fast-track, cached-keyword
        # multisearch, synonym swarm) covers query expansion natively,
        # so the preprocess LLM call is redundant — skip unless we
        # detect a marker the swarm can't handle (alternative_to
        # phrasing).
        ql = state.question.lower()
        if "alternativ" not in ql:
            new = state.model_copy(
                update={
                    "query": state.question,
                    "query_variants": [],
                    "adaptive_semantic_ratio": None,
                    "adaptive_fusion": None,
                }
            )
            self._trace(new, "preprocess", t0, path="swarm_skip")
            return new

        # ID-like queries (SKUs, EANs, article IDs) don't benefit from
        # preprocessing — they're literal lookups. Skip the LLM and let
        # the Tier-0 fast-track handle it.
        if _looks_like_id(state.question.strip()):
            new = state.model_copy(
                update={
                    "query": state.question,
                    "query_variants": [],
                    "adaptive_semantic_ratio": None,
                    "adaptive_fusion": None,
                }
            )
            self._trace(new, "preprocess", t0, path="id_skip", query=state.question)
            return new

        cached = await _cache.aload("preprocess-v8", "", state.question)
        if cached:
            try:
                result = SearchQuery.model_validate(cached)
                raw = _strip_stop_words(state.question)
                variants = _filter_bohrer_variants(
                    state.question, result.query, result.variants[:3]
                )
                if raw and raw.lower() != result.query.lower():
                    variants = [raw] + variants
                updates: dict = {
                    "query": result.query,
                    "query_variants": variants[:4],
                    "adaptive_semantic_ratio": result.semantic_ratio,
                    "adaptive_fusion": result.fusion,
                }
                if result.alternative_to:
                    updates["alternative_to"] = result.alternative_to
                new = state.model_copy(update=updates)
                self._trace(new, "preprocess", t0, cached=True)
                return new
            except Exception:
                pass
        try:
            result = cast(
                SearchQuery,
                await self._search_query_chain.ainvoke(
                    [
                        self._sys(prompts.preprocess_system()),
                        HumanMessage(state.question),
                    ]
                ),
            )
            await _cache.asave(
                "preprocess-v8",
                "",
                state.question,
                value=result.model_dump(),
            )
            raw = _strip_stop_words(state.question)
            variants = _filter_bohrer_variants(
                state.question, result.query, result.variants[:3]
            )
            if raw and raw.lower() != result.query.lower():
                variants = [raw] + variants
            updates: dict = {
                "query": result.query,
                "query_variants": variants[:4],
                "adaptive_semantic_ratio": result.semantic_ratio,
                "adaptive_fusion": result.fusion,
            }
            if result.alternative_to:
                updates["alternative_to"] = result.alternative_to
            new = state.model_copy(update=updates)
            self._trace(
                new,
                "preprocess",
                t0,
                query=result.query,
                semantic_ratio=result.semantic_ratio,
                fusion=result.fusion,
                variants=len(variants[:4]),
                alternative_to=result.alternative_to,
            )
            return new
        except Exception as e:
            new = state.model_copy(update={"query": state.question})
            self._trace(new, "preprocess", t0, error=type(e).__name__)
            return new

    async def _asearch(
        self,
        query: str,
        question: str | None = None,
        lang: str | None = None,
        extra_bm25: list[str] | None = None,
        factor: int | None = None,
        adaptive_semantic_ratio: float | None = None,
        adaptive_fusion: str | None = None,
        hyde_text: str | None = None,
    ) -> tuple[list[Document], bool]:
        limit = max(
            int(self.top_k * (factor or self.retrieval_factor)), self.min_rerank_pool
        )
        hyde_source = question or query

        if hyde_text is None:
            n_words = len(hyde_source.split())
            short_thr = self._short_query_threshold
            if (
                self.embedder
                and n_words >= 1
                and (n_words <= short_thr or n_words >= self.hyde_min_words)
            ):
                try:
                    hyde_text = await self._ahypothetical_doc(hyde_source)
                except Exception:
                    hyde_text = hyde_source
            else:
                hyde_text = hyde_source
        loop = asyncio.get_running_loop()
        vector: list[float] | None = None
        if self.embedder:
            try:
                vector = await self.embedder.aembed(hyde_text)
            except Exception:
                vector = None

        lang_filter = f"language = {lang}" if lang else None
        hyde_bm25 = hyde_text if hyde_text != hyde_source else query
        raw_ratio = (
            adaptive_semantic_ratio
            if adaptive_semantic_ratio is not None
            else self.semantic_ratio
        )
        # Clamp to mixed band — always some keyword, always some semantic.
        # Pure semantic hallucinates on typos; pure BM25 misses paraphrases.
        hybrid_ratio = min(0.8, max(0.2, raw_ratio))

        def _req(q: str, **extra: Any) -> SearchRequest:
            return self._make_search_request(
                q,
                limit,
                sort_fields=self.sort_fields,
                show_ranking_score=True,
                filter_expr=lang_filter,
                **extra,
            )

        requests = [_req(query)]

        if hyde_bm25 != query:
            requests.append(_req(hyde_bm25))
        requests.append(_req(query, vector=vector, semantic_ratio=hybrid_ratio))
        seen = {query, hyde_bm25}
        for v in extra_bm25 or []:
            if v and v not in seen:
                requests.append(_req(v))
                seen.add(v)

        results = await loop.run_in_executor(None, self._cached_batch_search, requests)
        bm25_arms = [r for req, r in zip(requests, results) if not req.vector]
        bm25_empty = bool(bm25_arms) and all(len(r) == 0 for r in bm25_arms)
        fuse_method = adaptive_fusion or self.fusion
        if results:
            if fuse_method == "dbsf":
                fused = _dbsf_fuse(results)
            else:
                fused = _rrf_fuse(results, ranking_score_weight=1.0)
        else:
            fused = await loop.run_in_executor(
                None,
                self.backend.search,
                self._make_search_request(query, limit, filter_expr=lang_filter),
            )

        docs = [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in fused[:limit]
        ]
        return docs, bm25_empty

    async def _aroute_collections(self, state: RAGState) -> RAGState:
        if self.collections and not state.selected_collections:
            selected = await self._aselect_collections(state.question)
            _ACTIVE_COLLECTIONS.set(selected)
            return state.model_copy(update={"selected_collections": selected})
        if state.selected_collections:
            _ACTIVE_COLLECTIONS.set(state.selected_collections)
        return state

    def _spawn_background(self, coro: Any) -> "asyncio.Task[Any]":
        """Fire-and-forget a coroutine on the running event loop and
        keep a strong reference so it isn't GC'd before completion.
        Used for non-critical work like long-term memory writes that
        must not block the user-facing response."""
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        return task

    async def adrain_background(self) -> None:
        """Await any in-flight background tasks (memory writes etc.).
        Call before shutdown when you want their side effects to land
        before the process exits."""
        if self._background_tasks:
            await asyncio.gather(*self._background_tasks, return_exceptions=True)

    def _rerank_pool_size(self, k: int) -> int:
        """Number of candidates to fetch before reranking. Floors at
        ``min_rerank_pool`` so that small ``top_k`` (e.g. user asks for
        3) still gives the reranker a meaningful pool to choose from.
        """
        return max(int(k * self.retrieval_factor), self.min_rerank_pool)

    def _trace(self, state: RAGState, node: str, t0: float, **info: Any) -> None:
        dur = round(time.perf_counter() - t0, 4)
        event = {"node": node, "dur_s": dur, **info}
        state.trace.append(event)
        if self.verbose:
            extras = " ".join(f"{k}={v}" for k, v in info.items())
            msg = f"[rag {node}] {dur:.3f}s {extras}".rstrip()
            print(msg, file=sys.stderr, flush=True)
        if self.trace_callback is not None:
            try:
                self.trace_callback(event)
            except Exception:
                pass

    async def _acontextualize(self, state: RAGState) -> RAGState:
        if not state.history:
            return state
        last = state.history[-1]
        try:
            result = cast(
                StandaloneQuery,
                await self._standalone_chain.ainvoke(
                    [
                        self._sys(prompts.CONTEXTUALIZE),
                        HumanMessage(
                            f"Previous question: {last.question}\n"
                            f"Previous answer (first 300 chars): {last.answer[:300]}\n"
                            f"New message: {state.question}"
                        ),
                    ]
                ),
            )
        except Exception:
            return state

        updates: dict[str, Any] = {"is_followup": result.is_followup}
        if result.query and result.query != state.question and len(result.query) < 500:
            updates["question"] = result.query

        if result.is_followup and last.documents:
            updates["documents"] = last.documents

        return state.model_copy(update=updates)


    async def _aswarm_retrieve(self, state: RAGState) -> RAGState:
        t0 = time.perf_counter()
        state = await self._aroute_collections(state)

        async def _gen_variants() -> list[str]:
            if state.query_variants:
                base = state.query_variants[: self.n_swarm_queries]

                rewritten = state.query
                if rewritten and rewritten != state.question and rewritten not in base:
                    base = [rewritten] + base[: self.n_swarm_queries - 1]
                return base or [state.query]
            cached = await _cache.aload(
                "multi-query-v1", self.n_swarm_queries, state.question
            )
            if cached and isinstance(cached, list):
                return cached[: self.n_swarm_queries] or [state.query]
            try:
                result = cast(
                    MultiQuery,
                    await self._multi_query_chain.ainvoke(
                        [
                            self._sys(prompts.multi_query_swarm(self.n_swarm_queries)),
                            HumanMessage(state.question),
                        ]
                    ),
                )
                queries = result.queries[: self.n_swarm_queries] or [state.query]
                if result.queries:
                    await _cache.asave(
                        "multi-query-v1",
                        self.n_swarm_queries,
                        state.question,
                        value=result.queries,
                    )
                return queries
            except Exception:
                return [state.query]

        queries, filter_intent = await asyncio.gather(
            _gen_variants(),
            self._adetect_filter_intent(state.question),
        )

        vectors: list[list[float] | None] | None = None
        if self.embedder:
            try:
                vectors = cast(
                    list[list[float] | None],
                    await self.embedder.aembed_batch(queries),
                )
            except Exception:
                vectors = None

        loop = asyncio.get_running_loop()

        def _search(filter_expr: str | None = None) -> list[Document]:
            return self._multi_search(queries, vectors=vectors, filter_expr=filter_expr)

        has_filter = filter_intent.is_confident
        if has_filter:
            f_expr = self._build_filter_expr(filter_intent)
            broad_docs, filtered_docs = await asyncio.gather(
                loop.run_in_executor(None, _search),
                loop.run_in_executor(None, _search, f_expr),
            )
            docs = (
                self._merge_doc_lists(filtered_docs, broad_docs)
                if filtered_docs
                else broad_docs
            )
        else:
            docs = await loop.run_in_executor(None, _search)

        new = state.model_copy(
            update={"documents": docs, "iterations": state.iterations + 1}
        )
        self._trace(
            new,
            "swarm_retrieve",
            t0,
            variants=len(queries),
            docs=len(docs),
            has_filter=bool(has_filter),
        )
        return new


    async def _afilter_search_with_intent(
        self,
        question: str,
        query: str,
        precomputed: FilterIntent | None = None,
        variants: list[str] | None = None,
    ) -> tuple[FilterIntent | None, list[Document]]:

        intent = precomputed or await self._adetect_filter_intent(question)
        if not intent.is_confident:
            # No usable DB-level filter, but the intent may still carry
            # content-level negations (field=None NOT_CONTAINS, or
            # NOT_CONTAINS entries inside and_filters). Keep the intent
            # so _arerank's post-filter can drop matching docs from the
            # broad search; just skip the DB filter call.
            has_content_negation = (
                (intent.operator in ("NOT_CONTAINS", "!=") and intent.value)
                or any(
                    af.operator in ("NOT_CONTAINS", "!=") and af.value
                    for af in intent.and_filters
                )
            )
            return (intent if has_content_negation else None), []
        docs = await self._afilter_search_from_intent(query, intent, variants)
        return intent, docs

    def _build_filter_expr(self, intent: FilterIntent) -> str:
        return self.backend.build_filter_expr(intent)

    async def _afilter_search_from_intent(
        self,
        query: str,
        intent: FilterIntent,
        variants: list[str] | None = None,
    ) -> list[Document]:
        filter_expr = self._build_filter_expr(intent)
        limit = self._rerank_pool_size(self.top_k)
        loop = asyncio.get_running_loop()
        vector: list[float] | None = None
        if self.embedder:
            try:
                vector = await self.embedder.aembed(query)
            except Exception:
                pass

        filter_token = intent.value.lower().strip() if intent.value else ""

        def _strip_filter_token(q: str) -> str:
            if not filter_token:
                return q
            parts = [t for t in q.split() if t.lower().strip("?,!.") != filter_token]
            return " ".join(parts) if parts else q

        async def _search(expr: str) -> list[dict]:

            all_queries = [query] + [v for v in (variants or []) if v and v != query]
            stripped = [_strip_filter_token(q) for q in all_queries]
            seen: set[str] = set()
            unique: list[str] = []
            for q in stripped:
                if q and q not in seen:
                    seen.add(q)
                    unique.append(q)

            if len(unique) > 3:
                unique = unique[:1] + sorted(unique[1:], key=lambda s: -len(s))[:2]
            vecs: list[list[float] | None] = [vector] + [None] * (len(unique) - 1)
            requests = [
                self._make_search_request(q, limit, vector=v, filter_expr=expr)
                for q, v in zip(unique, vecs)
            ]
            try:
                if len(requests) == 1:
                    return await loop.run_in_executor(
                        None, self.backend.search, requests[0]
                    )
                results = await loop.run_in_executor(
                    None, self._cached_batch_search, requests
                )
                return _rrf_fuse(results)
            except Exception:
                return []

        hits = await _search(filter_expr)
        if not hits and intent.and_filters:
            primary_only = intent.model_copy(update={"and_filters": []})
            hits = await _search(self._build_filter_expr(primary_only))
        pref_field = self._primary_preference_field
        if pref_field and (
            _is_brand_intent(intent) or len(hits) < self.top_k * 2
        ):
            # Own-brand supplemental fetch: empty query + filter so preferred
            # items that don't share keywords with the user query still enter
            # the candidate pool and get a fair shot at the reranker.
            own_brand_req = self._make_search_request(
                "", limit, vector=vector, filter_expr=f"{pref_field} = true"
            )
            try:
                own_brand_hits = await loop.run_in_executor(
                    None, self.backend.search, own_brand_req
                )
            except Exception:
                own_brand_hits = []
            seen: set[str] = {
                str(h.get("id") or h.get("article_id") or id(h)) for h in hits
            }
            for h in own_brand_hits:
                doc_id = str(h.get("id") or h.get("article_id") or id(h))
                if doc_id not in seen:
                    seen.add(doc_id)
                    hits.append(h)
        return [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in hits[:limit]
        ]

    def _make_rerank_docs(self, docs: list[Document]) -> list[str]:
        # Pass the full markdown-rendered doc to the reranker.
        # Cohere v3.5 accepts up to 4096 tokens per doc and truncates
        # server-side beyond that — no need to cap client-side. Older
        # rerankers (v2) still respect `rerank_chars` because they error
        # over 512 tokens; for those, set rerank_chars=2000 explicitly.
        if self.rerank_chars and self.rerank_chars < 4096:
            return [_doc_to_grader_text(d)[: self.rerank_chars] for d in docs]
        return [_doc_to_grader_text(d) for d in docs]

    def _truncate_low_score(self, docs: list[Document], k: int) -> list[Document]:
        """Cap at k, then drop docs whose rerank score is below threshold.

        Returns empty list if no doc passes — honest "no results" beats
        returning an irrelevant top-1 as a confident answer.
        Docs without _rerank_score are treated as passing (not reranked yet).
        """
        head = docs[:k]
        th = self._rerank_min_score
        if th is None or not head:
            return head
        return [
            d
            for d in head
            if d.metadata.get("_rerank_score") is None
            or float(d.metadata["_rerank_score"]) >= th
        ]

    def _priority_boost(self, doc: Document, query_tokens: set[str]) -> float:
        """Schema-aware multiplier: boost docs whose high-priority
        fields (per `_field_priority`) contain query tokens. Generic
        — no hardcoded field names, no per-collection config. The
        agent already discovers which fields are most discriminating;
        this turns that knowledge into a ranking signal.

        Returns 1.0 baseline. Max boost capped at
        `_name_field_boost_max` (default 0.1 = +10%) so it tie-breaks
        rather than overrules the Cohere / LLM-grader decisions.
        """
        priority = getattr(self, "_field_priority", None)
        if not query_tokens or not priority:
            return 1.0
        bump = 0.0
        for field, rank in priority.items():
            val = doc.metadata.get(field)
            if not val:
                continue
            text = str(val).lower()
            hits = sum(1 for t in query_tokens if t in text)
            if hits == 0:
                continue
            # rank 0 → weight 1.0, rank 9 → weight 0.1
            weight = (10 - min(int(rank), 9)) / 10.0
            bump += weight * (hits / len(query_tokens))
        return 1.0 + min(bump, 1.0) * self._name_field_boost_max

    def _apply_priority_boost(
        self, docs: list[Document], query: str
    ) -> list[Document]:
        """Re-order docs by two boost signals, both gentle:

          1. **Priority boost** (schema-aware): query tokens hitting
             high-priority fields (per `_field_priority`) get a small
             rank bump. Generic, no per-collection config — uses the
             field-importance ranking the agent already inferred. Stays
             client-side because it is query-conditional and content-
             driven (no backend index can see "did the query token
             match this field text?").

          2. **Popularity boost** (`self.boost_fn`): when sortable
             bool/numeric fields exist (in-stock, own-brand,
             sales_l12m), `_detect_index_signals` builds a multiplier
             from them. Delegated to ``backend.boost_for_query`` so
             backends with native ranking (Meili sort, Qdrant decay)
             can apply it server-side; the default backend impl runs
             ``boost_fn`` per hit, matching the historical behaviour.

        Boosts are capped (~+10-15%) so they shift close calls without
        overriding the Cohere / LLM grader decisions.
        """
        if not docs:
            return docs
        tokens = (
            {t for t in query.lower().split() if len(t) > 3}
            if query
            else set()
        )
        boost_fn = getattr(self, "boost_fn", None)
        if not tokens and not boost_fn:
            return docs

        # Popularity-only fast path: no query tokens means the priority
        # arm is a no-op, so the backend can take the whole ordering.
        # Backends with native ranking (Meili sort, Qdrant decay) get a
        # chance to push the math server-side; the default impl matches
        # the historical client-side behaviour bit-for-bit.
        if boost_fn is not None and not tokens:
            signals = BoostSignals(
                sort_fields=list(self.sort_fields or []),
                boost_fn=boost_fn,
                num_fields=list(self.num_fields),
                primary_bool=self._primary_preference_field,
            )
            doc_by_id = {id(d.metadata): d for d in docs}
            ranked_meta = self.backend.boost_for_query(
                query, [d.metadata for d in docs], signals
            )
            return [doc_by_id[id(m)] for m in ranked_meta]

        # Combined path: priority and popularity multiply against the
        # same base score, so they must compose in a single sort to
        # preserve the original ranking semantics. Math channel for
        # the cross-encoder: when a Cohere rerank already wrote
        # `_rerank_score`, use that as the base — boost multiplies the
        # actual confidence, not just the rank slot. Otherwise fall
        # back to linear position decay.
        n = max(len(docs), 1)
        decay = 1.0 / max(n - 1, 1)

        def score(idx: int, d: Document) -> float:
            rerank = d.metadata.get("_rerank_score")
            base = (
                float(rerank)
                if isinstance(rerank, (int, float))
                else 1.0 - idx * decay
            )
            pri = self._priority_boost(d, tokens) if tokens else 1.0
            pop = boost_fn(d.metadata) if boost_fn else 1.0
            return base * pri * pop

        scored = [(d, score(i, d)) for i, d in enumerate(docs)]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [d for d, _ in scored]

    async def _aexpert_rerank(
        self,
        query: str,
        documents: list[Document],
        indexed: list[tuple[int, float]],
    ) -> list[tuple[int, float]]:
        if not self._expert_reranker:
            return indexed
        head = indexed[: self.expert_top_n]
        tail = indexed[self.expert_top_n :]
        docs = [documents[i].page_content[: self.rerank_chars] for i, _ in head]
        idx_map = [i for i, _ in head]
        arerank_fn = getattr(self._expert_reranker, "arerank", None)
        try:
            if arerank_fn is not None:
                results = await asyncio.wait_for(
                    arerank_fn(query, docs, len(docs)), timeout=60.0
                )
            else:
                loop = asyncio.get_running_loop()
                results = await asyncio.wait_for(
                    loop.run_in_executor(
                        None,
                        self._expert_reranker.rerank,
                        query,
                        docs,
                        len(docs),
                    ),
                    timeout=60.0,
                )
        except Exception:
            return indexed
        rescored = [(idx_map[r.index], r.relevance_score) for r in results]
        return rescored + tail

    async def _arerank(
        self, state: RAGState, *, _accumulate_pool: bool = True
    ) -> RAGState:
        t0 = time.perf_counter()
        if not state.documents:
            return state
        # Cross-encoder reranker is now opt-in. Skip when disabled —
        # the LLM close_match grader handles relevance judgment instead.
        if not getattr(self, "_enable_reranker", False):
            intent = state.filter_intent
            if intent:
                filtered = intent.apply(list(state.documents))
                if len(filtered) != len(state.documents):
                    state = state.model_copy(update={"documents": filtered})
            self._trace(state, "rerank", t0, skipped="reranker_disabled")
            return state

        rerank_cap = max(
            int(self.top_k * self._rerank_cap_multiplier), self.rerank_top_n * 2
        )
        capped_docs = state.documents[:rerank_cap]
        rerank_docs = self._make_rerank_docs(capped_docs)
        effective_top_n = len(rerank_docs)
        rerank_query = state.question or state.query
        if state.grader_feedback:
            rerank_query = f"{state.grader_feedback}. {rerank_query}"

        try:
            _rerank_cached = await _cache.aload(
                "rerank-v1", rerank_query, tuple(rerank_docs)
            )
            expert_fired = False
            if _rerank_cached is not None:
                indexed = [tuple(r) for r in _rerank_cached]
            else:
                arerank_fn = getattr(self._reranker, "arerank", None)
                if arerank_fn is not None:
                    coro = arerank_fn(rerank_query, rerank_docs, effective_top_n)
                else:
                    coro = asyncio.get_running_loop().run_in_executor(
                        None,
                        self._reranker.rerank,
                        rerank_query,
                        rerank_docs,
                        effective_top_n,
                    )
                results = await asyncio.wait_for(coro, timeout=self._rerank_timeout_s)
                indexed = [(r.index, r.relevance_score) for r in results]
                await _cache.asave(
                    "rerank-v1", rerank_query, tuple(rerank_docs), value=indexed
                )
            if self._expert_reranker and len(indexed) >= 2:
                scores = sorted((s for _, s in indexed), reverse=True)
                top1 = scores[0]
                ref = scores[min(len(scores) - 1, 4)]
                gap = top1 - ref
                if self.expert_threshold is not None and gap < self.expert_threshold:
                    indexed = await self._aexpert_rerank(
                        rerank_query, state.documents, indexed
                    )
                    expert_fired = True
            score_by_idx = {i: s for i, s in indexed}
            for i, d in enumerate(state.documents):
                if i in score_by_idx:
                    d.metadata["_rerank_score"] = float(score_by_idx[i])
            ranked = sorted(
                state.documents,
                key=lambda d: -float(d.metadata.get("_rerank_score", 0.0)),
            )
            ranked = self._apply_priority_boost(ranked, state.query)
            intent = state.filter_intent
            if intent:
                ranked = intent.apply(ranked)
            if intent and intent.field and ranked:
                is_negation = intent.operator in ("NOT_CONTAINS", "!=")
                if is_negation:
                    exclude_vals = [str(intent.value)] + list(intent.extra_excludes)
                    ranked = [
                        d
                        for d in ranked
                        if _doc_matches_intent(d, intent)
                        and not any(
                            _content_contains_exclusion(d.page_content, v)
                            for v in exclude_vals
                        )
                    ]
                else:
                    top_n = self.rerank_top_n
                    top_match_count = sum(
                        1 for d in ranked[:top_n] if _doc_matches_intent(d, intent)
                    )
                    if top_match_count >= 1:
                        matching_all = [
                            state.documents[i]
                            for i, _ in indexed
                            if _doc_matches_intent(state.documents[i], intent)
                        ]
                        seen_ids = {_doc_id(d.metadata) for d in matching_all}
                        rest = [
                            d for d in ranked if _doc_id(d.metadata) not in seen_ids
                        ]
                        ranked = matching_all + rest
            new = state.model_copy(
                update={"documents": ranked, "expert_fired": expert_fired}
            )
            if _accumulate_pool:
                new = self._merge_into_pool(new, ranked)
            self._trace(new, "rerank", t0, docs=len(ranked), expert_fired=expert_fired)
            return new
        except Exception as e:
            self._trace(state, "rerank", t0, error=type(e).__name__)
            return state

    @staticmethod
    def _merge_into_pool(state: "RAGState", docs: "list[Document]") -> "RAGState":
        pool = state.candidate_pool
        seen = {_doc_id(d.metadata) for d in pool}
        new_pool = pool + [d for d in docs if _doc_id(d.metadata) not in seen]
        return state.model_copy(update={"candidate_pool": new_pool})

    async def _agenerate(self, state: RAGState) -> RAGState:
        t0 = time.perf_counter()
        # Cap each doc body to `_preview_chars`. page_content is sorted
        # most-important fields first, so a fixed cap reliably keeps
        # citation-worthy info in view while cutting bulky spec sheets
        # that don't help the answer. Saves ~40% input tokens per
        # generate call vs. the prior unbounded markdown.
        preview = max(int(self._preview_chars), 400)
        numbered = "\n\n---\n\n".join(
            f"[{i + 1}] {d.page_content[:preview]}"
            for i, d in enumerate(state.documents[: self.top_k])
        )
        sys_content = prompts.ANSWER_SYSTEM
        if state.memory_context:
            sys_content += (
                "\n\nKnown search hints for this corpus (synonyms / "
                "aliases learned from past exchanges; use only if "
                "directly relevant to disambiguate the query):\n"
                f"{state.memory_context}"
            )
        if state.grader_feedback:
            sys_content += (
                f"\n\nSearch guidance for this attempt: {state.grader_feedback}"
            )
        # Derive "filter attempted but empty" from existing data instead
        # of carrying a redundant flag: a confident filter intent that
        # produced zero strict-filter hits.
        fi = state.filter_intent
        filter_empty = (
            fi is not None and fi.is_confident and state.filter_arm_hits == 0
        )
        if filter_empty and fi is not None:
            sys_content += (
                f"\n\nIMPORTANT — strict filter result: the user named "
                f'`{fi.field}={fi.value}` (operator {fi.operator}), but '
                f"zero documents in the corpus match that filter exactly. "
                f"The context below is fuzzy/related results only. State "
                f"clearly that `{fi.value}` is not in the corpus, then "
                f"optionally point to nearest related items as alternatives."
            )
        messages: list = [self._sys(sys_content)]
        for turn in state.history:
            messages.append(HumanMessage(turn.question))
            messages.append(AIMessage(turn.answer))
        messages.append(
            HumanMessage(f"Context:\n{numbered}\n\nQuestion: {state.question}")
        )
        # Stream chunks instead of single ainvoke — langgraph "messages"
        # stream_mode captures them and forwards to the UI as token events.
        chunks: list[str] = []
        try:
            async for chunk in self._gen_llm.astream(messages):
                content = getattr(chunk, "content", None)
                if content:
                    chunks.append(str(content))
        except Exception:
            # Fallback to ainvoke if the model doesn't support streaming
            # (some local providers or stub LLMs in tests).
            response = await self._gen_llm.ainvoke(messages)
            chunks = [str(response.content)]
        answer = "".join(chunks)
        update: dict[str, Any] = {"answer": answer}

        if self._checkpointer is not None:
            update["documents"] = []
        new = state.model_copy(update=update)
        self._trace(
            new,
            "generate",
            t0,
            docs=len(state.documents[: self.top_k]),
            answer_chars=len(answer),
        )
        return new

    async def _arewrite(self, state: RAGState) -> RAGState:
        """Rewrite the search query when the quality gate or final grade
        is unhappy. If we've already tried and got nothing back, fall
        through to a swarm retrieve as a last-ditch broadening.
        """
        t0 = time.perf_counter()
        if not state.documents and not self._enable_swarm_grade:
            if state.adaptive_semantic_ratio is None:
                pre = await self._apreprocess(state)
                state = state.model_copy(
                    update={
                        "query": pre.query or state.query,
                        "query_variants": pre.query_variants,
                        "adaptive_semantic_ratio": pre.adaptive_semantic_ratio,
                        "adaptive_fusion": pre.adaptive_fusion,
                    }
                )
            new = await self._aswarm_retrieve(state)
            self._trace(new, "rewrite", t0, path="swarm", docs=len(new.documents))
            return new

        # Pinpoint: grader identified an exact code.
        # If the code is already in the result set, the reranker just needs
        # the right focus — no new retrieval needed.
        # Only do a full retrieval bypass when the code is absent from docs.
        if state.retry_strategy == "pinpoint" and state.pinpoint_code:
            code = state.pinpoint_code
            in_results = any(
                code.lower() in (d.page_content + " ".join(
                    str(v) for v in d.metadata.values() if isinstance(v, str)
                )).lower()
                for d in state.documents
            )
            if in_results:
                # Already retrieved — let the reranker sort it out
                new = state.model_copy(update={
                    "grader_rerank_focus": code,
                    "retry_strategy": None,
                    "pinpoint_code": "",
                })
                self._trace(new, "rewrite", t0, path="pinpoint-rerank", rerank_focus=code)
                return new
            # Not found — bypass LLM rewrite, search by exact code
            new = state.model_copy(update={
                "query": code,
                "retry_strategy": None,
                "pinpoint_code": "",
            })
            self._trace(new, "rewrite", t0, path="pinpoint", new_query=code)
            return new

        feedback: str | None = None
        doc_snippets: list[str] | None = None
        if state.grader_feedback and state.documents:
            feedback = state.grader_feedback
        elif state.documents:
            doc_snippets = [
                d.page_content[: self._preview_chars]
                for d in state.documents[:3]
            ]
        prompt = prompts.rewrite_query(
            previous_query=state.query,
            feedback=feedback,
            doc_snippets=doc_snippets,
            retry_strategy=state.retry_strategy,
        )

        try:
            rewrite_coro = self._search_query_chain.ainvoke(
                [self._sys(prompt), HumanMessage(state.question)]
            )
            if state.adaptive_semantic_ratio is None:
                pre, result = await asyncio.gather(
                    self._apreprocess(state), rewrite_coro
                )
                state = state.model_copy(
                    update={
                        "query_variants": pre.query_variants,
                        "adaptive_semantic_ratio": pre.adaptive_semantic_ratio,
                        "adaptive_fusion": pre.adaptive_fusion,
                    }
                )
            else:
                result = await rewrite_coro
            result = cast(SearchQuery, result)
            new = state.model_copy(update={
                "query": result.query,
                "retry_strategy": None,
                "pinpoint_code": "",
            })
            self._trace(new, "rewrite", t0, path=state.retry_strategy or "llm", new_query=result.query)
            return new
        except Exception as e:
            self._trace(state, "rewrite", t0, path="llm", error=type(e).__name__)
            return state

    async def _agive_up(self, state: RAGState) -> RAGState:
        try:
            prompt = prompts.no_result_suggestions(
                question=state.question,
                query=state.query,
                iterations=state.iterations,
            )
            result = cast(
                NoResultSuggestion,
                await self._suggestion_chain.ainvoke([self._sys(prompt)]),
            )
            parts = [result.message]
            if result.suggestions:
                parts.append(" ".join(f"• {s}" for s in result.suggestions))
            answer = "\n".join(parts)
        except Exception:
            answer = f"No relevant documents found after {state.iterations} attempts."
        return state.model_copy(update={"answer": answer})

    async def _allm_filter_relevance(
        self,
        query: str,
        docs: list[Document],
        *,
        strictness: str | None = None,
        strong: bool = False,
    ) -> list[str]:
        """LLM relevance filter AND ranker — returns doc IDs in the
        LLM's chosen order from most to least relevant.

        Replaces the cross-encoder reranker: the LLM both filters
        off-topic docs and decides the final order. The grader sees the
        original user query verbatim (typos, slang, colloquial form
        included) and ranks against THAT, so 'bieröffner' →
        'Flaschenöffner' is judged by concept, not lexical overlap.

        `strong=True` uses the thinking model (slower but better at
        nuance) — call sites use this for escalation on hard queries.

        Returns empty list if all docs are off-topic (caller decides
        what to do).
        """
        from langchain_core.messages import HumanMessage

        from . import prompts

        if not docs:
            return []
        # Prose channel for the boost: tag the schema designer's
        # primary preference (first sortable bool — typically
        # is_own_brand or is_featured) with ★. No magic-number
        # threshold; the tag means a specific semantic flag fired,
        # not a score-cap heuristic. Other signals (sales, in-stock)
        # still influence ranking via the math channel.
        primary_bool = getattr(self, "_primary_preference_field", None)
        any_starred = False

        def tag(d: Document) -> str:
            nonlocal any_starred
            if not primary_bool or not d.metadata.get(primary_bool):
                return ""
            any_starred = True
            return "★ "

        snippets = "\n\n".join(
            f"[{i + 1}] {tag(d)}{_doc_to_grader_text(d)}"
            for i, d in enumerate(docs)
        )
        chain = (
            self._close_match_chain_strong if strong else self._close_match_chain
        )
        try:
            verdict = cast(
                CloseMatchKeep,
                await chain.ainvoke(
                    [
                        self._sys(
                            prompts.close_match(
                                self._custom_instructions,
                                strictness or self._close_match_strictness,
                            )
                        ),
                        HumanMessage(
                            f"Original user query (verbatim): {query}\n\n"
                            f"Retrieved documents:\n{snippets}"
                        ),
                    ]
                ),
            )
        except Exception:
            # Fail-open: keep everything if the LLM errored.
            return [_doc_id(d.metadata) for d in docs]
        # Preserve LLM-chosen order — the keep list IS the ranking.
        # Validate indices, dedupe stray duplicates. Some LLMs emit
        # article_id values instead of positional indices; for those,
        # fall back to looking up by article_id / doc_id substring
        # match on the metadata.
        ordered_ids: list[str] = []
        seen: set[str] = set()
        article_id_to_doc: dict[str, Document] = {}
        for d in docs:
            for key in ("article_id", "id"):
                v = d.metadata.get(key)
                if v is not None:
                    article_id_to_doc[str(v)] = d
        for raw_idx in verdict.keep:
            doc: Document | None = None
            try:
                idx = int(raw_idx)
            except (TypeError, ValueError):
                idx = -1
            if 1 <= idx <= len(docs):
                doc = docs[idx - 1]
            else:
                # Treat huge "indices" as article_ids the LLM hallucinated.
                key = str(raw_idx)
                doc = article_id_to_doc.get(key)
                if doc is None:
                    # Suffix tolerance — Meilisearch sometimes appends
                    # internal counters (e.g. 7794905000001 vs 7794905).
                    for aid, d in article_id_to_doc.items():
                        if key.startswith(aid) or aid.startswith(key):
                            doc = d
                            break
            if doc is None:
                continue
            doc_key = _doc_id(doc.metadata)
            if doc_key in seen:
                continue
            seen.add(doc_key)
            ordered_ids.append(doc_key)
        return ordered_ids

    async def _aclose_match_grade(self, state: RAGState) -> RAGState:
        t0 = time.perf_counter()
        if not self._enable_close_match_grader or not state.documents:
            self._trace(state, "close_match", t0, path="skip")
            return state
        top_n = min(self.rerank_top_n, len(state.documents))
        if top_n <= 1:
            self._trace(state, "close_match", t0, path="skip_too_few")
            return state
        snippets = "\n\n".join(
            f"[{i + 1}] {_doc_to_grader_text(d)}"
            for i, d in enumerate(state.documents[:top_n])
        )
        # Use the verbatim user question (state.question) so the grader
        # judges the original phrasing — not a preprocessed/rewritten
        # form that has lost the colloquial signal.
        original_query = state.question or state.query
        try:
            verdict = cast(
                CloseMatchKeep,
                await self._close_match_chain.ainvoke(
                    [
                        self._sys(
                            prompts.close_match(
                                self._custom_instructions, self._close_match_strictness
                            )
                        ),
                        HumanMessage(
                            f"Original user query (verbatim): {original_query}\n\n"
                            f"Retrieved documents:\n{snippets}"
                        ),
                    ]
                ),
            )
        except Exception as e:
            self._trace(state, "close_match", t0, path="error", error=type(e).__name__)
            return state
        if not verdict.keep:
            # Grader succeeded and said keep none → honest "no relevant docs".
            # Better than showing brand-only matches. Only LLM errors fail-open
            # (handled by the except-branch above which returns state unchanged).
            new = state.model_copy(update={"documents": []})
            self._trace(new, "close_match", t0, path="dropped_all", dropped=top_n)
            return new
        # Preserve LLM order — keep IS the ranking. The graded head
        # gets reordered; the un-graded tail beyond top_n stays as-is.
        head = state.documents[:top_n]
        tail = state.documents[top_n:]
        seen: set[int] = set()
        kept: list[Document] = []
        for raw_idx in verdict.keep:
            try:
                idx = int(raw_idx)
            except (TypeError, ValueError):
                continue
            if idx < 1 or idx > len(head) or idx in seen:
                continue
            seen.add(idx)
            kept.append(head[idx - 1])
        kept = kept + tail
        new = state.model_copy(update={"documents": kept})
        self._trace(
            new,
            "close_match",
            t0,
            path="fired",
            kept=len(kept),
            dropped=top_n - len(kept),
        )
        return new

    async def _afinal_grade(self, state: RAGState) -> RAGState:
        """LLM-driven post-generation check: did the answer actually use
        the evidence well? Drives the retry-rewrite loop on weak answers
        and gates whether a memory write is worth doing.
        """
        t0 = time.perf_counter()
        if not self._enable_final_grade:
            self._trace(state, "final_grade", t0, path="disabled")
            return state
        if not state.answer or state.iterations >= self.max_iter:
            self._trace(state, "final_grade", t0, path="skip")
            return state

        snippets = "\n\n".join(
            f"[{i + 1}] {_doc_to_grader_text(d)}"
            for i, d in enumerate(state.documents[:5])
        )
        grade: AnswerGrade | None = None
        err = None
        try:
            grade = cast(
                AnswerGrade,
                await self._grade_chain.ainvoke(
                    [
                        self._sys(prompts.FINAL_GRADE),
                        HumanMessage(
                            f"Question: {state.question}\n\n"
                            f"Retrieved snippets:\n{snippets}\n\n"
                            f"Generated answer:\n{state.answer}"
                        ),
                    ]
                ),
            )
        except Exception as e:
            err = type(e).__name__

        if grade is None:
            self._trace(state, "final_grade", t0, path="error", error=err)
            return state

        should_retry = not grade.sufficient and (
            grade.confidence >= self._final_grade_threshold
            or grade.confidence <= 1.0 - self._final_grade_threshold
        )
        memory_enabled = bool(self._memories)
        store_memory = bool(
            memory_enabled
            and grade.sufficient
            and grade.memory_worth_storing
            and grade.memory_fact
            and grade.memory_confidence >= self.memory_storage_threshold
        )
        update: dict[str, Any] = {
            "grader_confidence": grade.confidence,
            "grader_feedback": grade.suggestion if should_retry else None,
            "grader_rerank_focus": grade.rerank_focus if should_retry else "",
            "retry_strategy": grade.retry_strategy if should_retry else None,
            "pinpoint_code": grade.pinpoint_code if should_retry else "",
            "memory_should_store": store_memory,
            "memory_fact": grade.memory_fact if store_memory else "",
        }
        new = state.model_copy(update=update)
        self._trace(
            new,
            "final_grade",
            t0,
            sufficient=grade.sufficient,
            confidence=grade.confidence,
            memory_should_store=store_memory,
            memory_confidence=grade.memory_confidence,
            error=err,
        )
        return new

    async def _agrade_docs(
        self, question: str, docs: list[Document]
    ) -> "AnswerGrade | None":
        snippets = "\n\n".join(
            f"[{i + 1}] {_doc_to_grader_text(d)}"
            for i, d in enumerate(docs[:5])
        )
        try:
            return cast(
                AnswerGrade,
                await self._grade_chain.ainvoke(
                    [
                        self._sys(prompts.GRADE_DOCS),
                        HumanMessage(
                            f"Question: {question}\n\nRetrieved document snippets:\n{snippets}"
                        ),
                    ]
                ),
            )
        except Exception:
            return None

    async def _aswarm_preprocess(self, state: RAGState) -> RAGState:
        if not state.history and state.filter_intent is None:
            intent_task: asyncio.Task[FilterIntent] | None = asyncio.create_task(
                self._adetect_filter_intent(state.question)
            )
        else:
            intent_task = None
        state = await self._acontextualize(state)
        state = await self._aroute_collections(state)
        state = await self._apreprocess(state)
        if intent_task is not None:
            try:
                intent = await intent_task
            except Exception:
                intent = FilterIntent(field=None, value="", operator="")
            state = state.model_copy(update={"filter_intent": intent})
        return state

    async def _agen_swarm_variants(
        self, state: RAGState
    ) -> tuple[list[str], list[list[float] | None], str | None]:
        seed = state.query or state.question

        async def _variants() -> list[str]:
            cached = await _cache.aload("multi-query-v1", self.n_swarm_queries, seed)
            if cached and isinstance(cached, list):
                return cached[: self.n_swarm_queries] or [seed]
            try:
                result = cast(
                    MultiQuery,
                    await self._multi_query_chain.ainvoke(
                        [
                            self._sys(prompts.multi_query_swarm(self.n_swarm_queries)),
                            HumanMessage(seed),
                        ]
                    ),
                )
                queries = result.queries[: self.n_swarm_queries] or [seed]
                if result.queries:
                    await _cache.asave(
                        "multi-query-v1",
                        self.n_swarm_queries,
                        seed,
                        value=result.queries,
                    )
                return queries
            except Exception:
                return [seed]

        filter_intent = state.filter_intent
        if filter_intent is None:
            queries, filter_intent = await asyncio.gather(
                _variants(), self._adetect_filter_intent(state.question)
            )
        else:
            queries = await _variants()

        vectors: list[list[float] | None] = [None] * len(queries)
        if self.embedder:
            try:
                vectors = cast(
                    list[list[float] | None],
                    await self.embedder.aembed_batch(queries),
                )
            except Exception:
                pass

        has_filter = filter_intent.is_confident
        f_expr = self._build_filter_expr(filter_intent) if has_filter else None

        return queries, vectors, f_expr

    async def _aarm_retrieve(
        self,
        question: str,
        query: str,
        vec: list[float] | None,
        f_expr: str | None,
    ) -> tuple[list[Document], str]:
        loop = asyncio.get_running_loop()
        docs = await loop.run_in_executor(
            None,
            lambda: self._multi_search([query], vectors=[vec], filter_expr=f_expr),
        )
        if not docs and f_expr:
            docs = await loop.run_in_executor(
                None,
                lambda: self._multi_search([query], vectors=[vec], filter_expr=None),
            )
        if not docs:
            return [], query
        arm_state = RAGState(question=question, query=query, documents=docs)
        reranked = await self._arerank(arm_state)
        return reranked.documents[: self.rerank_top_n], query

    async def _aswarm_race(
        self,
        state: RAGState,
        queries: list[str],
        vectors: list[list[float] | None],
        f_expr: str | None,
        t0: float,
    ) -> RAGState:
        tasks = [
            asyncio.create_task(
                self._aarm_retrieve(state.question, queries[i], vectors[i], f_expr)
            )
            for i in range(len(queries))
        ]
        pending: set[asyncio.Task[tuple[list[Document], str]]] = set(tasks)
        all_arm_docs: list[list[Document]] = []
        best_suggestion: str | None = state.grader_feedback
        best_confidence: float = 0.0

        while pending:
            done, pending = await asyncio.wait(
                pending, return_when=asyncio.FIRST_COMPLETED
            )
            for task in done:
                try:
                    arm_docs, arm_query = task.result()
                except Exception:
                    continue
                if not arm_docs:
                    continue

                grade = await self._agrade_docs(state.question, arm_docs)
                if (
                    grade is not None
                    and grade.sufficient
                    and grade.confidence >= self._final_grade_threshold
                ):
                    for t in pending:
                        t.cancel()
                    await asyncio.gather(*pending, return_exceptions=True)
                    new = state.model_copy(
                        update={
                            "documents": arm_docs,
                            "query": arm_query,
                            "iterations": state.iterations + 1,
                            "grader_confidence": grade.confidence,
                            "grader_feedback": None,
                        }
                    )
                    self._trace(
                        new,
                        "swarm_grade",
                        t0,
                        path="hit",
                        conf=grade.confidence,
                        docs=len(arm_docs),
                        arm=arm_query,
                    )
                    return new

                all_arm_docs.append(arm_docs)
                if grade is not None and grade.confidence > best_confidence:
                    best_confidence = grade.confidence
                    if grade.suggestion:
                        best_suggestion = grade.suggestion

        merged = self._merge_doc_lists(*all_arm_docs) if all_arm_docs else []
        new = state.model_copy(
            update={
                "documents": merged,
                "iterations": state.iterations + 1,
                "grader_feedback": best_suggestion,
                "grader_confidence": best_confidence,
            }
        )
        self._trace(
            new, "swarm_grade", t0, path="miss", conf=best_confidence, docs=len(merged)
        )
        return new

    async def _aswarm_grade_node(self, state: RAGState) -> RAGState:
        t0 = time.perf_counter()

        async def _arm_with_ratio(ratio: float) -> list[Document]:
            arm_state = state.model_copy(
                update={"adaptive_semantic_ratio": ratio, "adaptive_fusion": "rrf"}
            )
            result = await self._aswarm_retrieve(arm_state)
            return result.documents

        bm25_docs, semantic_docs = await asyncio.gather(
            _arm_with_ratio(0.05),
            _arm_with_ratio(0.95),
        )
        merged = (
            self._merge_doc_lists(bm25_docs, semantic_docs)
            if (bm25_docs or semantic_docs)
            else state.documents
        )
        new = state.model_copy(
            update={"documents": merged, "iterations": state.iterations + 1}
        )
        self._trace(new, "swarm_grade", t0, path="bm25+sem", docs=len(merged))
        return new

    def _grade_route(self, state: RAGState) -> Literal["end", "rewrite"]:
        # Fast-path retrievals (tier 0/1) skip final_grade entirely via
        # the conditional edge after `generate`, so by the time we get
        # here state.tier is always 2 — no need to re-check.
        if state.grader_feedback is None:
            return "end"
        if state.iterations >= self.max_iter:
            return "end"
        return "rewrite"

    def _route(self, state: RAGState) -> Literal["generate", "rewrite", "give_up"]:
        if not state.documents:
            return "give_up" if state.iterations >= self.max_iter else "rewrite"
        return "generate"

    def _build_graph(self) -> Any:
        from .graph import build_graph

        return build_graph(self)

    def _build_agent(self) -> Any:
        system_prompt = (
            "You are a retrieval agent with intelligent filtering. For each user question:\n"
            "\n"
            "1. Call get_index_settings to discover filterable, sortable, and boost fields.\n"
            "   Use ONLY the field names returned — never invent field names.\n"
            "\n"
            "2. DECIDE whether to apply a filter (fast precision boost):\n"
            "   - If the user names a specific entity that maps to a filterable field,\n"
            "     call get_filter_values(field) to see real stored values.\n"
            "     Then build a filter expression using the closest matching value.\n"
            "   - Use CONTAINS for partial name matches.\n"
            "   - Use exact = for booleans, IDs, and known precise values.\n"
            "   - Combine with AND/OR when multiple constraints apply.\n"
            "   - SKIP the filter step for broad or ambiguous queries where no entity is named.\n"
            "\n"
            "3. Call search_hybrid with the query and any filter_expr you decided to apply.\n"
            + (
                f"   ALWAYS pass sort_fields={self.sort_fields!r} to every search call "
                "to boost own-brand / high-sales results.\n"
                if self.sort_fields
                else
                "   If the question implies popularity/preference, pass sort_fields"
                " (e.g. sort_fields=['field_name:desc']).\n"
            )
            + "\n"
            "4. If results are poor (< 3 hits), call search_bm25 as fallback (drop the filter\n"
            "   if the previous filtered search was empty).\n"
            "\n"
            "5. Call rerank_results to get the top semantically-ranked hits.\n"
            "\n"
            "6. Summarise results. When boost/filter fields influenced ranking, explain why.\n"
            f"{self.instructions}"
        )

        agent = create_agent(
            self._llm,
            self._tools,
            system_prompt=system_prompt,
            store=self._memory_store,
            middleware=[  # ty: ignore[invalid-argument-type]
                ToolCallLimitMiddleware(run_limit=10, exit_behavior="end"),  # type: ignore[arg-type]
                ModelCallLimitMiddleware(  # type: ignore[arg-type]
                    run_limit=int(os.getenv("RAG_AGENT_MODEL_CALL_LIMIT", "12")),
                    exit_behavior="end",
                ),
                ToolRetryMiddleware(
                    max_retries=5,
                    tools=["search_hybrid", "rerank_results", "get_filter_values"],
                    retry_on=(Exception,),
                    backoff_factor=2.0,
                    initial_delay=1.0,
                    max_delay=30.0,
                    jitter=True,
                    on_failure="continue",
                ),
                ModelRetryMiddleware(
                    max_retries=5,
                    backoff_factor=2.0,
                    initial_delay=1.0,
                    max_delay=30.0,
                    on_failure="continue",
                ),
            ],
        )
        agent.step_timeout = 30.0
        return agent

    async def _adetect_product_code(self, query: str) -> str | None:
        """Return the extracted product code if the query is a code/ID/EAN lookup, else None."""
        cached = _cache.load("product-code-v1", query)
        if cached is not None:
            return cached.get("code")
        try:
            result = cast(
                ProductCodeQuery,
                await self._product_code_chain.ainvoke(
                    [
                        self._sys(prompts.PRODUCT_CODE),
                        HumanMessage(query),
                    ]
                ),
            )
        except Exception:
            return None
        code = result.code if result.is_product_code and result.code else None
        _cache.save("product-code-v1", query, value={"code": code})
        return code

    def _pin_filter_top(
        self,
        ranked: list[Document],
        filter_docs: list[Document],
        pin_to: int = 5,
    ) -> list[Document]:
        if not ranked or not filter_docs:
            return ranked
        ranked_ids = [_doc_id(d.metadata) for d in ranked]
        want_ids = [_doc_id(d.metadata) for d in filter_docs[:pin_to]]
        need = [wid for wid in want_ids if wid not in set(ranked_ids[:pin_to])]
        if not need:
            return ranked

        id_to_doc: dict[str, Document] = {_doc_id(d.metadata): d for d in filter_docs}
        for d in ranked:
            id_to_doc.setdefault(_doc_id(d.metadata), d)
        promoted_ids = [*need, *(rid for rid in ranked_ids if rid not in set(need))]
        return [id_to_doc[i] for i in promoted_ids]

    def _merge_doc_lists(self, *doc_lists: list[Document]) -> list[Document]:
        raw = [[d.metadata for d in dl] for dl in doc_lists]
        fused_meta = _rrf_fuse(raw)
        id_to_doc: dict[str, Document] = {}
        for dl in doc_lists:
            for d in dl:
                id_to_doc.setdefault(_doc_id(d.metadata), d)
        result = []
        for meta in fused_meta:
            key = _doc_id(meta)
            result.append(
                id_to_doc.get(key)
                or Document(page_content=self._hit_to_text(meta), metadata=meta)
            )
        return result

    async def _acompute_hyde(self, question: str) -> str:
        if not self._enable_hyde or not self.embedder:
            return ""
        n_words = len(question.split())
        if n_words >= 1 and (
            n_words <= self._short_query_threshold or n_words >= self.hyde_min_words
        ):
            try:
                return await self._ahypothetical_doc(question)
            except Exception:
                return question
        return question

    async def _arelevance_check(
        self, query: str, docs: list[Document]
    ) -> RelevanceCheck:
        top_ids = tuple(
            d.metadata.get("id") or d.metadata.get("_id") or d.page_content[:40]
            for d in docs[:3]
        )
        cached = _cache.load("relevance-v2", query, top_ids)
        if cached:
            try:
                return RelevanceCheck.model_validate(cached)
            except Exception:
                pass
        snippets = "\n---\n".join(
            _doc_to_grader_text(d) for d in docs[:3]
        )
        try:
            result = cast(
                RelevanceCheck,
                await self._relevance_chain.ainvoke(
                    [
                        self._sys(prompts.RELEVANCE_CHECK),
                        HumanMessage(f"Question: {query}\n\nSnippets:\n{snippets}"),
                    ]
                ),
            )
            _cache.save("relevance-v2", query, top_ids, value=result.model_dump())
            return result
        except Exception:
            return RelevanceCheck(makes_sense=False, confidence=0.0)

    async def _afast_keyword_retrieve(self, query: str, limit: int) -> list[Document]:
        loop = asyncio.get_running_loop()
        req = self._make_search_request(
            query,
            limit,
            semantic_ratio=0.0,
            sort_fields=self.sort_fields,
            show_ranking_score=True,
        )
        results = await loop.run_in_executor(None, self._cached_batch_search, [req])
        hits = results[0] if results else []
        return [Document(page_content=self._hit_to_text(h), metadata=h) for h in hits]

    async def _aalternative_retrieve(
        self, query: str, alternative_to: str, top_k: int
    ) -> tuple[str, list[Document]]:
        limit = self._rerank_pool_size(top_k)
        ref_docs = await self._afast_keyword_retrieve(alternative_to, 3)
        if not ref_docs:
            ref_docs = await self._afast_keyword_retrieve(query, limit)
            return query, ref_docs[:top_k]

        ref = ref_docs[0]
        ref_text = ref.page_content
        ref_id = _doc_id(ref.metadata)

        ref_category = ""
        for f in self.category_fields:
            v = ref.metadata.get(f)
            if v:
                ref_category = str(v)
                break
        rerank_signal = (
            f"{ref_category}: {ref.metadata.get(self.name_field) or ''}".strip(": ")
            if ref_category
            else ref_text
        )

        broad_docs, _ = await self._asearch(
            query,
            question=ref_text,
            factor=self.retrieval_factor,
            adaptive_semantic_ratio=0.7,
            adaptive_fusion="dbsf",
        )
        filtered = [
            d
            for d in broad_docs
            if _doc_id(d.metadata) != ref_id
            and not _content_contains_exclusion(d.page_content, alternative_to)
        ]
        state = RAGState(
            question=rerank_signal,
            query=query,
            documents=filtered,
            iterations=1,
        )
        state = await self._arerank(state)
        return state.query, state.documents[:top_k]

    async def _aretrieve_documents(
        self,
        query: str,
        top_k: int | None = None,
        *,
        memory_context: str = "",
        rerank_focus: str = "",
    ) -> RetrievalResult:
        """The 3-tier retrieval ladder.

        Tier 0 (ID fast-track) and Tier 1 (cached-synonym multisearch)
        return immediately on a confident hit, no LLM, no swarm.
        Tier 2 fans out the synonym swarm and runs the LLM
        grader-as-ranker on the fused pool.

        Returns a `RetrievalResult` carrying the tier, the ranked docs,
        and any filter intent that fired — the graph node merges this
        into RAGState directly. No info_out dict.
        """
        fast = await self._atry_fast_accept(query, top_k=top_k)
        if fast is not None:
            fast_query, fast_docs = fast
            return RetrievalResult.fast(query=fast_query, docs=fast_docs, tier=0)
        # Tier 1 (cached keyword multisearch) skips the LLM grader,
        # so it's unsafe when the user named a structured filter:
        # 'acme bucket' would let brand-filtered matches through
        # before the filter+noun reasoning runs. Probe filter
        # intent first; if confident, drop straight to the swarm.
        intent = await self._adetect_filter_intent(query)
        if intent.is_confident:
            info: dict[str, Any] = {}
            swarm_query, swarm_docs = await self._asynonym_swarm_retrieve(
                query,
                top_k=top_k,
                memory_context=memory_context,
                info_out=info,
                rerank_focus=rerank_focus,
            )
            return RetrievalResult(
                query=swarm_query,
                docs=swarm_docs,
                tier=2,
                filter_intent=info.get("filter_intent") or intent,
                filter_arm_hits=int(info.get("filter_arm_hits", 0)),
            )
        multi = await self._atry_keyword_multisearch(query, top_k=top_k)
        if multi is not None:
            multi_query, multi_docs = multi
            return RetrievalResult.fast(query=multi_query, docs=multi_docs, tier=1)
        info: dict[str, Any] = {}
        swarm_query, swarm_docs = await self._asynonym_swarm_retrieve(
            query,
            top_k=top_k,
            memory_context=memory_context,
            info_out=info,
            rerank_focus=rerank_focus,
        )
        return RetrievalResult(
            query=swarm_query,
            docs=swarm_docs,
            tier=2,
            filter_intent=info.get("filter_intent"),
            filter_arm_hits=int(info.get("filter_arm_hits", 0)),
        )

    async def _atry_keyword_multisearch(
        self,
        query: str,
        *,
        top_k: int | None = None,
    ) -> tuple[str, list[Document]] | None:
        """Tier-1 short-circuit: keyword search on original query + any
        cached synonym variants, fused via RRF.

        Returns docs only when:
          - the fused result has ≥ top_k docs, AND
          - the top BM25 score on the original-query arm clears
            `_fast_accept_score` (default 0.85), AND
          - synonym variants are cached for this query (no fresh LLM
            call here — that belongs to the full swarm).

        Designed to fire for ~90% of repeat queries after warmup, with
        zero LLM calls and no cross-encoder rerank.
        """
        from collections import defaultdict

        k = top_k or self.top_k
        limit = self._rerank_pool_size(k)
        seed = (query or "").strip()
        if not seed:
            return None

        score_th = self._fast_accept_score
        if score_th is None:
            return None

        # Variant lookup — cache only. Miss → skip this tier; full swarm
        # will generate them and warm the cache.
        n = max(1, int(getattr(self, "_n_synonym_variants", 5)))
        cached = await _cache.aload("multi-query-v1", n, seed)
        variants: list[str] = (
            list(cached[:n]) if cached and isinstance(cached, list) else []
        )

        # Parallel keyword fanout: original + each cached variant.
        orig_task = asyncio.create_task(
            self._afast_keyword_retrieve(seed, limit)
        )
        variant_tasks = [
            asyncio.create_task(self._afast_keyword_retrieve(v, limit))
            for v in variants
        ]
        results = await asyncio.gather(
            orig_task, *variant_tasks, return_exceptions=True
        )

        orig_result = results[0]
        if isinstance(orig_result, BaseException) or not orig_result:
            return None
        # Confidence gate: top score on the canonical-query arm must
        # clear the threshold. Variants only add coverage, not trust.
        top_score = float(orig_result[0].metadata.get("_rankingScore", 0.0))
        if top_score < score_th:
            return None

        # Token-coverage gate for MULTI-TOKEN queries: BM25 can score
        # high when one rare token (a brand) hits hard while the noun
        # is missing. Require the top doc's name to contain ≥ 60% of
        # substantive tokens, otherwise drop to the swarm where the
        # grader judges category. Single-token queries skip this
        # gate — a 1/1 coverage would be trivially satisfied by
        # curated search_terms anyway, and the swarm grader catches
        # the wrong-category cases (Akkuschrauber → Kaltasphalt) on
        # its own at the cost of one swarm round.
        sub_tokens = [t for t in seed.lower().split() if len(t) > 2]
        if len(sub_tokens) >= 2:
            top_name = str(
                orig_result[0].metadata.get("article_name")
                or orig_result[0].metadata.get("title")
                or orig_result[0].metadata.get("name")
                or ""
            ).lower()
            covered = sum(1 for t in sub_tokens if t in top_name)
            if covered / len(sub_tokens) < 0.6:
                return None

        # RRF fuse all arms (cheap — no LLM, no cross-encoder).
        rrf: dict[str, float] = defaultdict(float)
        docs_by_id: dict[str, Document] = {}
        rrf_k_const = 60.0
        for r in results:
            if isinstance(r, BaseException):
                continue
            for rank, doc in enumerate(r):
                doc_id = str(
                    doc.metadata.get("article_id")
                    or doc.metadata.get("id")
                    or rank
                )
                rrf[doc_id] += 1.0 / (rrf_k_const + rank)
                docs_by_id.setdefault(doc_id, doc)

        if len(docs_by_id) < k:
            return None

        sorted_ids = sorted(rrf.keys(), key=lambda i: -rrf[i])[:k]
        fused = [docs_by_id[i] for i in sorted_ids]
        return seed, fused

    async def _atry_fast_accept(
        self,
        query: str,
        *,
        top_k: int | None = None,
    ) -> tuple[str, list[Document]] | None:
        """Cheap short-circuit before the synonym-swarm runs.

        Two paths, mutually exclusive — both return early to avoid
        redundant work:

        1. Single-token id-like query (SKU, EAN, article ID, part
           number) → one keyword backend call. No LLM extraction. If it
           hits, return; if not, return None and let downstream handle.
        2. Short natural-language query without filter words → BM25
           fast-accept (existing logic). Cheap rerank + close-match
           grade.

        Returns None when neither path matches; caller falls through
        to the full swarm pipeline.
        """
        k = top_k or self.top_k
        limit = self._rerank_pool_size(k)
        q_stripped = query.strip()

        # 1. ID-like single-token fast-track. No LLM call. If the token
        # looks like an identifier and the keyword backend has it, ship
        # those docs. Mismatch → skip the BM25 path (an ID-shaped miss
        # won't benefit from fast-accept) and let the swarm try.
        if _looks_like_id(q_stripped):
            try:
                code_docs = await self._afast_keyword_retrieve(
                    q_stripped, limit
                )
            except Exception:
                return None
            if code_docs:
                return q_stripped, code_docs[:k]
            return None

        # 2. BM25 fast-accept for short non-filter natural-language
        # queries. Mirrors the gating in _aretrieve_documents_single.
        has_filter_word = any(
            w.lower().strip("?,!.") in self._filter_intent_words
            for w in query.split()
        )
        is_short = len(query.split()) <= self._short_query_threshold
        if has_filter_word or not is_short:
            return None

        score_th = self._fast_accept_score
        conf_th = self._fast_accept_confidence
        if score_th is None and conf_th is None:
            return None

        try:
            fast_docs = await self._afast_keyword_retrieve(query, limit)
        except Exception:
            return None
        if not fast_docs or len(fast_docs) < k:
            return None

        top_score = float(fast_docs[0].metadata.get("_rankingScore", 0.0))
        accept = score_th is not None and top_score >= score_th
        if not accept and conf_th is not None:
            try:
                rc = await self._arelevance_check(query, fast_docs)
            except Exception:
                return None
            accept = rc.makes_sense and rc.confidence >= conf_th
        if not accept:
            return None

        state = RAGState(
            question=query, query=query, documents=fast_docs, iterations=1
        )
        state = await self._arerank(state)
        if not state.documents:
            return None
        top_rerank = float(
            state.documents[0].metadata.get("_rerank_score", 0.0)
        )
        if top_rerank < 0.1:
            return None

        skip_th = self._close_match_min_top_rerank
        if skip_th is None or top_rerank < skip_th:
            state = await self._aclose_match_grade(state)
        return state.query, self._truncate_low_score(state.documents, k)

    async def _aresolve_variants(
        self, query: str, n: int = 5
    ) -> list[str]:
        """Cached or LLM-generated synonym variants. Shared by every
        agent that benefits from query expansion (keyword, hybrid).
        Returns [] on cache miss + LLM failure — caller falls back to
        raw query alone."""
        from langchain_core.messages import HumanMessage

        from . import prompts

        seed = (query or "").strip()
        if not seed:
            return []
        cached = await _cache.aload("multi-query-v1", n, seed)
        if cached and isinstance(cached, list):
            return list(cached[:n])
        try:
            result = cast(
                MultiQuery,
                await self._multi_query_chain.ainvoke(
                    [
                        self._sys(prompts.multi_query_swarm(n)),
                        HumanMessage(seed),
                    ]
                ),
            )
            raw = list(result.queries[:n]) if result.queries else []
            seed_lc = seed.lower().strip()
            seen: set[str] = set()
            variants: list[str] = []
            for v in raw:
                v_lc = v.lower().strip()
                if not v_lc or v_lc == seed_lc or v_lc in seen:
                    continue
                seen.add(v_lc)
                variants.append(v)
            if variants:
                await _cache.asave(
                    "multi-query-v1", n, seed, value=variants
                )
            return variants
        except Exception:
            return []


    async def _asynonym_swarm_retrieve(
        self,
        query: str,
        top_k: int | None = None,
        *,
        memory_context: str = "",
        info_out: dict[str, Any] | None = None,
        rerank_focus: str = "",
    ) -> tuple[str, list[Document]]:
        """Synonym-aware multi-search retrieval with RRF + final rerank.

        Forces the LLM to expand the query into N synonym/colloquial
        variants (`bieröffner` → `flaschenöffner`, `flex` → `winkelschleifer`),
        retrieves each in parallel, fuses results via Reciprocal Rank
        Fusion, then runs one final cross-encoder pass against the
        canonical query.

        Original query keeps the full agent pipeline (HyDE / filter intent /
        preprocess); variants take a fast bypass (raw backend search +
        per-variant rerank), so cost is bounded at:
          1 full agent call + N raw backend calls + 1 cross-encoder pass.
        """
        from collections import defaultdict

        from langchain_core.messages import HumanMessage

        from . import prompts

        k = top_k or self.top_k
        n = max(1, int(getattr(self, "_n_synonym_variants", 5)))

        # 1. Generate synonym/colloquial variants.
        variants: list[str] = []
        try:
            seed = (query or "").strip()
            if seed:
                cached = await _cache.aload("multi-query-v1", n, seed)
                if cached and isinstance(cached, list):
                    variants = list(cached[:n])
                else:
                    result = cast(
                        MultiQuery,
                        await self._multi_query_chain.ainvoke(
                            [
                                self._sys(prompts.multi_query_swarm(n)),
                                HumanMessage(seed),
                            ]
                        ),
                    )
                    raw_variants = (
                        list(result.queries[:n]) if result.queries else []
                    )
                    seed_lc = seed.lower().strip()
                    seen_lc: set[str] = set()
                    variants = []
                    for v in raw_variants:
                        v_lc = v.lower().strip()
                        if not v_lc or v_lc == seed_lc or v_lc in seen_lc:
                            continue
                        seen_lc.add(v_lc)
                        variants.append(v)
                    if variants:
                        await _cache.asave(
                            "multi-query-v1", n, seed, value=variants
                        )
        except Exception:
            variants = []

        # 2. Three-pool swarm — ALL arms are raw backend calls (no LLM,
        # no rerank, no per-arm preprocessing). Heavy steps (preprocess,
        # HyDE, reranker) only run AFTER the streaming grader decides
        # we need them, never per-arm. This is the key to the "super
        # fast keyword + synonym multisearch" target.
        #    - filter arm : strict filter search, NO fallback. Boosted
        #                   in RRF when fired.
        #    - orig arm   : raw backend BM25/vector search on canonical
        #                   query — cheap, no LLM.
        #    - variants   : raw backend per synonym, fuzzy.
        intent_task = asyncio.create_task(self._adetect_filter_intent(query))
        try:
            filter_intent: FilterIntent | None = await intent_task
        except Exception:
            filter_intent = None

        filter_intent_confident = (
            filter_intent is not None and filter_intent.is_confident
        )

        orig_task = asyncio.create_task(
            self._aorig_arm_retrieve(query, limit=k * 2)
        )
        variant_tasks = [
            asyncio.create_task(self._araw_backend_retrieve(v, limit=k * 2))
            for v in variants
        ]

        filter_arm_task: asyncio.Task[tuple[FilterIntent | None, list[Document]]] | None = None
        if filter_intent_confident:
            # Pass synonym variants — without them the filter arm only
            # ranks brand-matched docs by similarity to the user's slang
            # token (e.g. 'bottle opener') and surfaces irrelevant brand
            # items at top instead of the one that matches by description.
            filter_arm_task = asyncio.create_task(
                self._afilter_search_with_intent(
                    query, query, precomputed=filter_intent, variants=variants
                )
            )

        # 3. Wait for all arms in parallel and fuse via RRF. We used to
        # process arms as they completed and short-circuit on consensus,
        # but the filter arm is authoritative for brand-constrained
        # queries (bieröffner von ProOne → Multi-Tool 12 in 1) and we
        # never cancel it once intent is confident — so the early-stop
        # bookkeeping was dead weight. asyncio.gather is simpler and
        # the wall-clock difference is the slowest of {orig, variants,
        # filter} either way.
        all_tasks: list[asyncio.Task[Any]] = [orig_task, *variant_tasks]
        if filter_arm_task is not None:
            all_tasks.append(filter_arm_task)
        results = await asyncio.gather(*all_tasks, return_exceptions=True)

        filter_arm_docs: list[Document] = []
        rrf: dict[str, float] = defaultdict(float)
        docs_by_id: dict[str, Document] = {}
        rrf_k_const = 60.0
        for task, result in zip(all_tasks, results):
            if isinstance(result, BaseException):
                continue
            is_filter_arm = task is filter_arm_task
            is_orig_arm = task is orig_task
            if is_filter_arm:
                _, hits = result
                filter_arm_docs = list(hits)
                for rank, doc in enumerate(hits):
                    doc_id = str(
                        doc.metadata.get("article_id")
                        or doc.metadata.get("id")
                        or rank
                    )
                    # Filter arm boost: half-rank credit pushes
                    # exact-match docs to the top of fusion.
                    rrf[doc_id] += 1.0 / (rrf_k_const + rank // 2)
                    docs_by_id.setdefault(doc_id, doc)
            else:
                _, hits = result
                # Per-arm score gate: when the top hit's BM25 score is
                # weak (< 0.3), this arm is "no-signal" — usually a
                # synonym variant that doesn't exist in the corpus, or
                # HyDE on a slang token producing vector hallucinations.
                # Skip its RRF contribution so it can't drown real
                # matches from the canonical-noun variant.
                top_score = (
                    float(hits[0].metadata.get("_rankingScore", 0.0))
                    if hits
                    else 0.0
                )
                if top_score < 0.3 and not is_orig_arm:
                    continue
                for rank, doc in enumerate(hits):
                    doc_id = str(
                        doc.metadata.get("article_id")
                        or doc.metadata.get("id")
                        or rank
                    )
                    # Boost orig arm only if it produced a strong
                    # canonical match (top_score ≥ 0.7); otherwise
                    # treat it as one signal among the variants.
                    effective_rank = (
                        rank // 2 if is_orig_arm and top_score >= 0.7 else rank
                    )
                    rrf[doc_id] += 1.0 / (rrf_k_const + effective_rank)
                    docs_by_id.setdefault(doc_id, doc)

        if info_out is not None:
            info_out["filter_intent"] = filter_intent
            info_out["filter_arm_hits"] = len(filter_arm_docs)
            info_out["filter_attempted_but_empty"] = (
                filter_intent_confident and not filter_arm_docs
            )

        if not docs_by_id:
            return query, []

        # RRF surfaces the candidate pool — keep the top 4k so the LLM
        # grader (now the ranker) sees a wide enough pool to pull a
        # better #1 from rank 13+ (filter-arm boosted doc at rank 2 but
        # RRF rank 14 because junk SKUs vote across orig + variants).
        # Per-arm `_rankingScore` is meaningless
        # here (a variant arm scoring its own variant token, not the
        # canonical query), so we don't sort by it.
        sorted_ids = sorted(rrf.keys(), key=lambda i: -rrf[i])[: k * 4]
        fused = [docs_by_id[i] for i in sorted_ids]

        # 4. Final cross-encoder rerank — ALWAYS runs against the
        # canonical user query. If the previous iteration's grader
        # provided a `rerank_focus` hint (LLM saw the docs were
        # correct-but-misranked and proposed an augmented query),
        # rerank against THAT instead. The hint is structured-output
        # from `AnswerGrade.rerank_focus`, threaded back through state
        # and passed in here by `_aretrieve_node`.
        rerank_query = (rerank_focus or query).strip() or query
        cohere_confident = False
        if (
            getattr(self, "_enable_reranker", False)
            and self._reranker is not None
            and fused
        ):
            fused = await self._afinal_rerank_canonical(rerank_query, fused, k)
        # Schema-aware priority boost + auto-detected popularity
        # multiplier (in-stock, own-brand, sales). Gentle (~+10%) so
        # it shifts close calls without overriding the cross-encoder /
        # LLM-grader decisions. Runs in both rerank-on and rerank-off
        # paths.
        fused = self._apply_priority_boost(fused, query)
        if (
            getattr(self, "_enable_reranker", False)
            and self._reranker is not None
            and fused
        ):
            # Hybrid trust: when Cohere returns a confident top hit,
            # skip the LLM grader entirely — Cohere is faster (~200ms
            # vs ~5s) and equivalent quality on clear-winner queries.
            # Confident = high top score AND wide top-1 / top-k gap.
            # Tight calls fall through to the LLM grader for nuance
            # (brand+noun reasoning, colloquial-to-canonical mapping).
            if len(fused) >= 2:
                top1 = float(fused[0].metadata.get("_rerank_score", 0.0))
                tail_pos = min(len(fused) - 1, k - 1)
                tail_score = float(fused[tail_pos].metadata.get("_rerank_score", 0.0))
                cohere_confident = (
                    top1 >= self._reranker_trust_top_score
                    and (top1 - tail_score) >= self._reranker_trust_score_gap
                )

        # LLM grader-as-ranker on the head, unless Cohere was already
        # confident.
        if (
            getattr(self, "_enable_close_match_grader", True)
            and len(fused) > 1
            and not cohere_confident
        ):
            # Wider head — the grader is now BOTH filter and ranker, so
            # surfacing more candidates lets it pull a better #1 from
            # deeper in the pool (filter arm may push irrelevant brand
            # matches to the top, correct item sits at rank 15).
            head_size = max(k * 4, k + 12)
            head = fused[:head_size]
            try:
                ordered_ids = await self._allm_filter_relevance(query, head)
                # Escalation cascade: when the cheap grader rejects
                # the entire head, the query is likely hard (typo,
                # slang, ambiguous brand+noun). Re-grade with the
                # strong (thinking) model — slower per call, but only
                # fires when the cheap pass produced nothing usable.
                # Sparse-but-non-empty results are usually correct
                # selectivity, not low confidence.
                if not ordered_ids:
                    try:
                        strong_ids = await self._allm_filter_relevance(
                            query, head, strong=True
                        )
                        if strong_ids:
                            ordered_ids = strong_ids
                    except Exception:
                        pass
                if ordered_ids:
                    by_id = {_doc_id(d.metadata): d for d in head}
                    reordered = [
                        by_id[i] for i in ordered_ids if i in by_id
                    ]
                    if reordered:
                        # LLM order replaces RRF/rerank order in the head.
                        fused = reordered + fused[head_size:]
                # else: both graders rejected the head — leave fused
                # untouched. Showing the reranked best-effort beats
                # silently dropping every doc.
            except Exception:
                pass
        return query, fused[:k]

    async def _aorig_arm_retrieve(
        self, query: str, limit: int
    ) -> tuple[str, list[Document]]:
        """Orig swarm arm: HyDE-augmented embedding search on canonical
        query. Catches semantic synonyms (bieröffner → flaschenöffner)
        that raw token search would miss. HyDE LLM is cached after the
        first call per query, so warm queries pay zero LLM cost."""
        embedder = getattr(self, "embedder", None)
        hyde_text = ""
        if embedder and getattr(self, "_enable_hyde", False):
            try:
                hyde_text = await self._acompute_hyde(query)
            except Exception:
                hyde_text = ""
        embed_seed = hyde_text or query
        vector = await embedder.aembed(embed_seed) if embedder else None
        request = self._make_search_request(
            query, limit, vector=vector, show_ranking_score=True
        )
        asearch = getattr(self.backend, "asearch", None)
        if asearch is not None:
            hits = await asearch(request)
        else:
            hits = await asyncio.get_running_loop().run_in_executor(
                None, self.backend.search, request
            )
        docs = [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in (hits or [])
        ]
        return query, docs

    async def _araw_backend_retrieve(
        self, query: str, limit: int
    ) -> tuple[str, list[Document]]:
        """Backend.search() with no LLM steps — used for synonym variants."""
        embedder = getattr(self, "embedder", None)
        vector = await embedder.aembed(query) if embedder else None
        request = self._make_search_request(
            query, limit, vector=vector, show_ranking_score=True
        )
        asearch = getattr(self.backend, "asearch", None)
        if asearch is not None:
            hits = await asearch(request)
        else:
            hits = await asyncio.get_running_loop().run_in_executor(
                None, self.backend.search, request
            )
        docs = [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in (hits or [])
        ]
        return query, docs

    async def _afinal_rerank_canonical(
        self, query: str, hits: list[Document], top_k: int
    ) -> list[Document]:
        """Re-rerank fused candidates against the canonical user query.

        Writes `_rerank_score` and `_rankingScore` to each returned doc's
        metadata so the UI / caller sees scores against the *original*
        query — not the per-arm scores from RRF candidates (a variant
        arm's '_rankingScore' for "flansche" is meaningless when the
        user asked for "bieröffner").
        """
        if not hits:
            return hits
        # Match `_make_rerank_docs` — full markdown for v3.5+, truncate
        # only for older rerankers that respect 512-token caps.
        if self.rerank_chars and self.rerank_chars < 4096:
            rerank_docs = [_doc_to_grader_text(d)[: self.rerank_chars] for d in hits]
        else:
            rerank_docs = [_doc_to_grader_text(d) for d in hits]
        try:
            arerank = getattr(self._reranker, "arerank", None)
            if arerank is not None:
                results = await arerank(query, rerank_docs, top_k)
            else:
                results = await asyncio.get_running_loop().run_in_executor(
                    None, self._reranker.rerank, query, rerank_docs, top_k
                )
            # Defensive: sort by relevance_score descending regardless
            # of what the underlying reranker returns. Some Azure-hosted
            # Cohere deployments return input order; we force monotonic
            # output so display + elbow cut see consistent ranking.
            sorted_results = sorted(
                results, key=lambda r: r.relevance_score, reverse=True
            )
            ordered: list[Document] = []
            for r in sorted_results[:top_k]:
                doc = hits[r.index]
                doc.metadata["_rerank_score"] = float(r.relevance_score)
                # Overwrite the per-arm rankingScore so the sources panel
                # reflects relevance to the original query, not noise
                # from whichever variant arm first inserted the doc.
                doc.metadata["_rankingScore"] = float(r.relevance_score)
                ordered.append(doc)
            return ordered
        except Exception as exc:  # noqa: BLE001
            print(
                f"[synonym-swarm] final-rerank failed: {exc}", file=sys.stderr
            )
            return hits[:top_k]

    # =========================================================================
    # LEAN PARALLEL PIPELINE (keyword + synonym fan-out, AIChat-inspired)
    # =========================================================================

    async def _aprepare_node(self, state: RAGState) -> RAGState:
        """Prep: Tier-0 fast-accept, contextualize, preprocess, filter intent.

        If Tier-0 fires (ID fast-track), sets state.documents directly so the
        graph skips the parallel fanout and routes straight to generate.
        """
        t0 = time.perf_counter()

        # Tier 0: ID fast-track — no LLM, no synonym swarm
        fast = await self._atry_fast_accept(state.question)
        if fast is not None:
            fast_query, fast_docs = fast
            new = state.model_copy(update={
                "query": fast_query,
                "documents": fast_docs,
                "iterations": 1,
                "tier": 0,
            })
            self._trace(new, "prepare", t0, path="tier0", docs=len(fast_docs))
            return new

        intent_task: asyncio.Task[FilterIntent] | None = None
        if not state.history and state.filter_intent is None:
            intent_task = asyncio.create_task(
                self._adetect_filter_intent(state.question)
            )
        state = await self._acontextualize(state)
        state = await self._aroute_collections(state)
        state = await self._apreprocess(state)
        if intent_task is not None:
            try:
                intent = await intent_task
            except Exception:
                intent = FilterIntent(field=None, value="", operator="")
            state = state.model_copy(update={"filter_intent": intent})

        # Check alternative_to AFTER preprocess — it's detected from query text
        if state.alternative_to:
            _, docs = await self._aalternative_retrieve(
                state.query, state.alternative_to, self.top_k
            )
            new = state.model_copy(update={"documents": docs, "tier": 1, "iterations": 1})
            self._trace(new, "prepare", t0, path="alternative", docs=len(docs))
            return new

        self._trace(state, "prepare", t0, query=state.query)
        return state

    async def _aresolve_synonyms(
        self, query: str, n: int = 5
    ) -> tuple[list[str], str | None, list[str]]:
        """Synonym expansion, spell-correction, and negation extraction.

        Returns (synonyms, corrected_query, excluded_terms).
        Uses a dedicated prompt; cached separately from multi-query swarm.
        """
        from langchain_core.messages import HumanMessage

        seed = (query or "").strip()
        if not seed:
            return [], None, []
        cached = await _cache.aload("synonyms-v2", n, seed)
        if cached and isinstance(cached, dict):
            return (
                cached.get("synonyms", []),
                cached.get("corrected_query"),
                cached.get("excluded_terms", []),
            )
        try:
            result = cast(SynonymResult, await self._synonym_chain.ainvoke([
                self._sys(prompts.synonym_expansion(n)),
                HumanMessage(seed),
            ]))
            corrected = result.corrected_query or None
            excluded = [t.strip() for t in (result.excluded_terms or []) if t.strip()]
            effective = corrected or seed
            effective_lc = effective.lower()
            seen: set[str] = set()
            synonyms: list[str] = []
            for v in (result.queries or [])[:n]:
                v_lc = v.lower().strip()
                if not v_lc or v_lc == effective_lc or v_lc in seen:
                    continue
                seen.add(v_lc)
                synonyms.append(v)
            await _cache.asave(
                "synonyms-v2", n, seed,
                value={"synonyms": synonyms, "corrected_query": corrected, "excluded_terms": excluded},
            )
            return synonyms, corrected, excluded
        except Exception:
            return [], None, []

    async def _akeyword_search_node(self, state: RAGState) -> dict[str, Any]:
        """Branch A: Pure BM25 keyword search — works with any backend."""
        t0 = time.perf_counter()
        limit = self._rerank_pool_size(self.top_k)
        try:
            docs = await self._afast_keyword_retrieve(state.query, limit)
        except Exception:
            docs = []
        score = max((d.metadata.get("_rankingScore", 0.0) for d in docs), default=0.0)
        self._trace(
            state.model_copy(update={"keyword_documents": docs, "keyword_score": float(score)}),
            "keyword_search", t0, docs=len(docs), score=round(score, 3),
        )
        return {"keyword_documents": docs, "keyword_score": float(score)}

    async def _asynonym_search_node(self, state: RAGState) -> dict[str, Any]:
        """Branch B: Spell-correct + expand synonyms + extract negations, then BM25 search."""
        t0 = time.perf_counter()
        limit = self._rerank_pool_size(self.top_k)
        n = max(1, int(getattr(self, "_n_synonym_variants", 5)))

        synonyms: list[str] = []
        corrected_query: str | None = None
        excluded_terms: list[str] = []
        try:
            synonyms, corrected_query, excluded_terms = await self._aresolve_synonyms(state.query, n=n)
        except Exception:
            pass

        corrected: str = (
            corrected_query
            if corrected_query and corrected_query.lower() != state.query.lower()
            else ""
        )
        search_terms: list[str] = ([corrected] if corrected else []) + synonyms

        if not search_terms:
            self._trace(state, "synonym_search", t0, synonyms=0, docs=0)
            out: dict[str, Any] = {"synonym_documents": [], "synonyms": [], "synonym_score": 0.0}
            if excluded_terms:
                out["excluded_terms"] = excluded_terms
            return out

        tasks = [
            asyncio.create_task(self._afast_keyword_retrieve(term, limit))
            for term in search_terms
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_lists = [
            [d.metadata for d in r]
            for r in results
            if not isinstance(r, BaseException) and r
        ]
        if all_lists:
            fused = _rrf_fuse(all_lists)
            docs = [
                Document(page_content=self._hit_to_text(h), metadata=h)
                for h in fused[:limit]
            ]
        else:
            docs = []

        score = max((d.metadata.get("_rankingScore", 0.0) for d in docs), default=0.0)
        out = {
            "synonym_documents": docs,
            "synonyms": synonyms,
            "synonym_score": float(score),
        }
        if excluded_terms:
            out["excluded_terms"] = excluded_terms
        self._trace(
            state.model_copy(update={"synonym_documents": docs, "synonyms": synonyms, "synonym_score": float(score)}),
            "synonym_search", t0,
            synonyms=len(synonyms),
            corrected=corrected or None,
            excluded=len(excluded_terms),
            docs=len(docs),
            score=round(score, 3),
        )
        return out

    def _quality_gate(
        self, state: RAGState
    ) -> Literal["semantic_backup", "merge_rerank"]:
        """Route after fan-in: if max(keyword_score, synonym_score) < threshold → semantic."""
        threshold = self._fast_accept_score or 0.7
        best = max(state.keyword_score or 0.0, state.synonym_score or 0.0)
        if best >= threshold:
            return "merge_rerank"
        return "semantic_backup"

    async def _asemantic_backup_node(self, state: RAGState) -> dict[str, Any]:
        """Branch C: Full hybrid search (heavy vector) — only when A+B score low."""
        t0 = time.perf_counter()
        limit = self._rerank_pool_size(self.top_k)
        try:
            _, docs = await self._araw_backend_retrieve(state.query, limit)
        except Exception:
            docs = []
        self._trace(state.model_copy(update={"semantic_documents": docs}), "semantic_backup", t0, docs=len(docs))
        return {"semantic_documents": docs}

    async def _amerge_rerank_node(self, state: RAGState) -> RAGState:
        """Fan-in: dedup all pools, rerank against original query, apply boosts."""
        t0 = time.perf_counter()
        k_docs = state.keyword_documents or []
        syn_docs = state.synonym_documents or []
        sem_docs = state.semantic_documents or []

        seen: set[str] = set()
        unique: list[Document] = []
        for doc in k_docs + syn_docs + sem_docs:
            did = _doc_id(doc.metadata)
            if did not in seen:
                seen.add(did)
                unique.append(doc)

        if not unique:
            # No new docs — preserve previous iteration's docs to avoid
            # regressing to a worse answer on retry.
            new = state.model_copy(update={
                "documents": state.documents or [],
                "tier": 2,
                "iterations": state.iterations + 1,
                "grader_rerank_focus": "",
                "keyword_documents": [],
                "synonym_documents": [],
                "semantic_documents": [],
                "keyword_score": 0.0,
                "synonym_score": 0.0,
            })
            self._trace(new, "merge_rerank", t0, docs=0, pool=0)
            return new

        # Post-filter: remove docs that contain any negated term (case-insensitive)
        if state.excluded_terms:
            excl = [t.lower() for t in state.excluded_terms if t]

            def _matches_exclusion(doc: Document) -> bool:
                text = (doc.page_content + " " + " ".join(
                    str(v) for v in doc.metadata.values() if isinstance(v, str)
                )).lower()
                return any(e in text for e in excl)

            unique = [d for d in unique if not _matches_exclusion(d)]

        # Diversity pass before reranking — removes near-duplicate docs from
        # the pool so the reranker sees variety, not 10 variants of one product.
        pool_size = self._rerank_pool_size(self.top_k)
        diverse = _mmr_diverse(unique, lam=0.7, top_k=pool_size)

        focus = state.grader_rerank_focus or state.query
        ranked = await self._afinal_rerank_canonical(focus, diverse, self.top_k)
        ranked = self._apply_priority_boost(ranked or diverse[:self.top_k], state.query)

        new = state.model_copy(update={
            "documents": ranked,
            "tier": 2,
            "iterations": state.iterations + 1,
            "grader_rerank_focus": "",
            "keyword_documents": [],
            "synonym_documents": [],
            "semantic_documents": [],
            "keyword_score": 0.0,
            "synonym_score": 0.0,
        })
        self._trace(new, "merge_rerank", t0, docs=len(ranked), pool=len(unique))
        return new

    # =========================================================================

    def retrieve_documents(
        self, query: str, top_k: int | None = None
    ) -> tuple[str, list[Document]]:
        async def _retrieve() -> tuple[str, list[Document]]:
            r = await self._aretrieve_documents(query, top_k=top_k)
            return r.query, r.docs

        return _run_sync(_retrieve())

    async def ainvoke(self, question: str, *, config: Any = None) -> RAGState:
        init = RAGState(question=question, query=question)
        result = await self._graph.ainvoke(init, config=config)
        return result if isinstance(result, RAGState) else RAGState(**result)

    async def astream(self, question: str):
        result = await self._aretrieve_documents(question)
        docs = result.docs
        numbered = "\n\n---\n\n".join(
            f"[{i + 1}] {d.page_content}" for i, d in enumerate(docs[: self.top_k])
        )
        messages: list = [
            self._sys(prompts.ANSWER_SYSTEM),
            HumanMessage(f"Context:\n{numbered}\n\nQuestion: {question}"),
        ]
        async for chunk in self._gen_llm.astream(messages):
            content = getattr(chunk, "content", None)
            if content:
                yield str(content)

    async def astream_events(
        self,
        question: str,
        *,
        history: list[ConversationTurn] | None = None,
        config: Any = None,
    ):
        """Stream the full QA graph as tagged events for live UIs.

        Yields tuples of `(kind, payload)` where kind is one of:
          - "node":  payload = node name (str) — emitted when a graph
                     node finishes; lets a UI update a status spinner.
          - "token": payload = LLM token text (str) — emitted from the
                     generate node so a UI can render the answer as it
                     streams.
          - "state": payload = the current RAGState snapshot — emitted
                     once at the end; useful for surfacing sources.
        """
        init = RAGState(
            question=question,
            query=question,
            history=list(history or []),
        )
        last_state: RAGState | None = None
        async for mode, payload in self._graph.astream(
            init, config=config, stream_mode=["updates", "messages"]
        ):
            if mode == "updates" and isinstance(payload, dict):
                for node_name, node_payload in payload.items():
                    yield ("node", node_name)
                    if isinstance(node_payload, dict):
                        try:
                            base = (last_state or init).model_dump()
                            last_state = RAGState(**{**base, **node_payload})
                        except Exception:
                            pass
                    elif isinstance(node_payload, RAGState):
                        last_state = node_payload
            elif mode == "messages":
                try:
                    msg, meta = payload
                except Exception:
                    continue
                if (
                    getattr(msg, "content", None)
                    and isinstance(meta, dict)
                    and meta.get("langgraph_node") == "generate"
                ):
                    yield ("token", str(msg.content))
        if last_state is not None:
            yield ("state", last_state)

    def invoke(self, question: str, *, config: Any = None) -> RAGState:
        return _run_sync(self.ainvoke(question, config=config))

    async def abatch(self, questions: list[str]) -> list[RAGState]:
        return await asyncio.gather(*(self.ainvoke(q) for q in questions))

    def batch(self, questions: list[str]) -> list[RAGState]:
        return _run_sync(self.abatch(questions))

    async def achat(
        self,
        question: str,
        history: list[ConversationTurn] | None = None,
    ) -> RAGState:
        return cast(
            RAGState,
            await self._graph.ainvoke(
                RAGState(question=question, history=history or [])
            ),
        )

    def chat(
        self,
        question: str,
        history: list[ConversationTurn] | None = None,
    ) -> RAGState:
        return _run_sync(self.achat(question, history))

    async def ainvoke_agent(self, question: str) -> str:
        result = await self._agent.ainvoke({"messages": [HumanMessage(question)]})
        msgs = result.get("messages", [])
        return str(msgs[-1].content) if msgs else ""

    def invoke_agent(self, question: str) -> str:
        return _run_sync(self.ainvoke_agent(question))

    def query(self, question: str) -> str:
        return self.invoke(question).answer or ""
