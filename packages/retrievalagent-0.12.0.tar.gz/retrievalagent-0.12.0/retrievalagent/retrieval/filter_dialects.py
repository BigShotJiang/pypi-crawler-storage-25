"""Per-dialect translation from a FilterIntent into a backend-native
filter expression.

Each backend's `build_filter_expr` calls into one of these. Kept as
module-level fns rather than methods because they're pure — no
backend state needed — and grouping them here makes adding a new
dialect (e.g. Cypher, Mongo) a single-file change.
"""

from __future__ import annotations

from ..models import FilterIntent


def _escape_meili_value(v: str) -> str:
    return v.replace("\\", "\\\\").replace('"', '\\"')


def _escape_sql_value(v: str) -> str:
    return v.replace("'", "''")


def _meili_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    field_name = intent.field
    value = _escape_meili_value(intent.value)
    if op == "NOT_CONTAINS":
        parts = [f'NOT {field_name} CONTAINS "{value}"']
        for extra in intent.extra_excludes:
            parts.append(
                f'NOT {field_name} CONTAINS "{_escape_meili_value(extra)}"'
            )
    else:
        parts = [f'{field_name} {op} "{value}"']
    for af in intent.and_filters:
        if af.field:
            parts.append(_meili_filter_expr(af))
    return " AND ".join(parts)


def _sql_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    field_name = intent.field
    value = _escape_sql_value(intent.value)
    if op == "NOT_CONTAINS":
        parts = [f"{field_name} NOT ILIKE '%{value}%'"]
        for extra in intent.extra_excludes:
            parts.append(f"{field_name} NOT ILIKE '%{_escape_sql_value(extra)}%'")
    else:
        parts = [f"{field_name} {op} '{value}'"]
    for af in intent.and_filters:
        if af.field:
            parts.append(_sql_filter_expr(af))
    return " AND ".join(parts)


def _odata_filter_expr(intent: FilterIntent) -> str:
    op = intent.operator
    op_map = {"=": "eq", "!=": "ne", "<": "lt", "<=": "le", ">": "gt", ">=": "ge"}
    field_name = intent.field
    value = intent.value.replace("'", "''")
    if op == "NOT_CONTAINS":
        parts = [f"not search.ismatch('{value}', '{field_name}')"]
        for extra in intent.extra_excludes:
            esc = extra.replace("'", "''")
            parts.append(f"not search.ismatch('{esc}', '{field_name}')")
    else:
        parts = [f"{field_name} {op_map.get(op, op)} '{value}'"]
    for af in intent.and_filters:
        if af.field:
            parts.append(_odata_filter_expr(af))
    return " and ".join(parts)
