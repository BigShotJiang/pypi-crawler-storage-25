"""Typed result of a retrieval call.

`Retriever.aretrieve()` returns one of these instead of mutating an
opaque info dict and a state object — callers get every output of
the 3-tier ladder in one frozen value object.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.documents import Document

    from ..models import FilterIntent


@dataclass(frozen=True)
class RetrievalResult:
    """What the retrieval ladder returns to the graph node.

    - `query` is the (possibly preprocessed) query that produced these
      docs. Preserved so the generate stage can cite the canonical
      form.
    - `tier` records which rung of the ladder fired:
        0 = ID fast-track (no LLM, single keyword call)
        1 = keyword + cached-synonym multisearch (no LLM)
        2 = synonym swarm (LLM grader-as-ranker, full fanout)
      Tier 0/1 are "fast-path" — the graph skips the answer-quality
      LLM grader and the retry loop for them. That decision lives in
      `graph._decide_after_generate`, not as a redundant boolean here.
    - Filter fields surface what the filter arm did so downstream
      generate can ground the answer ("we filtered by brand X but
      found nothing" is a different message than "we found these").
      `filter_attempted_but_empty` is derived as
      `filter_intent.is_confident and filter_arm_hits == 0`.
    """

    query: str
    docs: list[Document]
    tier: int
    filter_intent: "FilterIntent | None" = None
    filter_arm_hits: int = 0

    @property
    def filter_attempted_but_empty(self) -> bool:
        return (
            self.filter_intent is not None
            and self.filter_intent.is_confident
            and self.filter_arm_hits == 0
        )

    @classmethod
    def empty(cls, query: str) -> "RetrievalResult":
        return cls(query=query, docs=[], tier=2)

    @classmethod
    def fast(cls, query: str, docs: "list[Document]", tier: int) -> "RetrievalResult":
        """Constructor for tier 0/1 hits — no filter info."""
        return cls(query=query, docs=docs, tier=tier)
