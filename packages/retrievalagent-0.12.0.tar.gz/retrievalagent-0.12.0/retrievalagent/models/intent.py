from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from langchain_core.documents import Document


class FilterIntent(BaseModel):
    reasoning: str = ""
    field: str | None
    value: str
    operator: str
    extra_excludes: list[str] = Field(
        default_factory=list,
        description="Additional values to exclude when operator is NOT_CONTAINS (e.g., 'nicht X oder Y' → value=X, extra_excludes=[Y]).",
    )
    and_filters: list["FilterIntent"] = Field(
        default_factory=list,
        description="Additional AND conditions for compound queries (e.g. supplier CONTAINS brand AND article_name NOT_CONTAINS type).",
    )

    @property
    def is_confident(self) -> bool:
        """The intent has all three pieces needed for a DB-level filter."""
        return bool(self.field and self.value and self.operator)

    def apply(self, docs: list[Document]) -> list[Document]:
        """Drop docs that violate any NOT_CONTAINS / != constraint
        encoded in this intent (primary or in `and_filters`).

        Concentrates the post-filter logic so callers don't need to
        reach into intent fields.
        """
        from ..retrieval.intent_match import _apply_intent_post_filter

        # Cast: _apply_intent_post_filter accepts FilterIntent, and
        # `self` IS a FilterIntent — Pyright's `Self` invariance rule
        # complains spuriously.
        return _apply_intent_post_filter(docs, self)  # type: ignore[arg-type]


class FieldRank(BaseModel):
    name: str = Field(description="Field name as listed in the input.")
    rank: int = Field(
        description="Importance rank: 0 = most informative for representing the document, 9 = least."
    )


class FieldPriority(BaseModel):
    ranks: list[FieldRank] = Field(
        default_factory=list,
        description="One entry per input field, every input field must appear exactly once.",
    )


class CollectionIntent(BaseModel):
    collections: list[str] = Field(default_factory=list)
