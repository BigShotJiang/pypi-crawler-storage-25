from __future__ import annotations

from typing import Any

from langchain_core.documents import Document
from pydantic import BaseModel, ConfigDict, Field

from .intent import FilterIntent


class ConversationTurn(BaseModel):
    question: str
    answer: str
    documents: list[Document] = Field(default_factory=list)


class RAGState(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    question: str = ""
    query: str = ""
    query_variants: list[str] = Field(default_factory=list)
    adaptive_semantic_ratio: float | None = None
    adaptive_fusion: str | None = None
    documents: list[Document] = Field(default_factory=list)
    candidate_pool: list[Document] = Field(default_factory=list)
    answer: str | None = None
    iterations: int = 0
    history: list[ConversationTurn] = Field(default_factory=list)
    filter_intent: "FilterIntent | None" = None
    filter_arm_hits: int = Field(
        default=0,
        description="Number of docs returned by the strict-filter swarm "
        "arm (zero fallback). Lets generate distinguish 'filter matched "
        "and supplied N docs' from 'filter detected but no exact match'.",
    )
    tier: int = Field(
        default=2,
        description="Which rung of the retrieval ladder produced the "
        "current docs. 0 = ID fast-track, 1 = keyword multisearch, "
        "2 = synonym swarm. Tier 0/1 hits skip the answer-quality LLM "
        "grade and the retry loop — encoded as a conditional graph edge "
        "after `generate` (NOT as an in-band skip flag). Replaces the "
        "former `fast_path` boolean; same routing semantics, but the "
        "value carries which fast tier fired for tracing.",
    )
    alternative_to: str | None = None
    selected_collections: list[str] = Field(default_factory=list)
    expert_fired: bool = False
    trace: list[dict[str, Any]] = Field(default_factory=list)
    grader_feedback: str | None = None
    grader_confidence: float | None = None
    retry_strategy: str | None = None
    pinpoint_code: str = ""
    is_followup: bool = False
    grader_rerank_focus: str = Field(
        default="",
        description="Augmented query for the next iteration's reranker, "
        "set by final_grade when the docs were correct but ranked wrong. "
        "Used by `_afinal_rerank_canonical` IN PLACE OF the raw user "
        "query when non-empty. Cleared after one iteration of use.",
    )
    memory_context: str = Field(
        default="",
        description="Highly-relevant search hints recalled from "
        "long-term memory — synonyms, aliases, brand spellings, "
        "informal→formal term mappings learned from past exchanges. "
        "Set by the read_memory node when score >= "
        "memory_relevance_threshold; used as an extra BM25 term "
        "during retrieval and as a system-prompt prefix during "
        "generation. Empty string when no memory met the bar.",
    )
    memory_should_store: bool = Field(
        default=False,
        description="Set by final_grade when the LLM decides this "
        "exchange revealed a corpus-general search fact (a synonym, "
        "alias, brand variant) that will help future retrieval. The "
        "write_memory node only writes when this is True.",
    )
    memory_fact: str = Field(
        default="",
        description="Distilled single-sentence search-fact (term "
        "mapping / alias) to persist when memory_should_store is True.",
    )

    excluded_terms: list[str] = Field(
        default_factory=list,
        description="Terms extracted from negation in the query "
        "(e.g. 'but not zero', 'nicht von Marke X', 'sans produit Y') "
        "to post-filter out of retrieved docs. General — not brand-specific.",
    )

    # --- Lean parallel pipeline (keyword + synonym + semantic fan-out) ---
    synonyms: list[str] = Field(default_factory=list)
    keyword_documents: list[Document] = Field(default_factory=list)
    synonym_documents: list[Document] = Field(default_factory=list)
    semantic_documents: list[Document] = Field(default_factory=list)
    keyword_score: float = 0.0
    synonym_score: float = 0.0
