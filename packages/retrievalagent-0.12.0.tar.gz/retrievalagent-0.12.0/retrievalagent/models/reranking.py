from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, Field


@dataclass
class RerankResult:
    index: int
    relevance_score: float


@runtime_checkable
class Reranker(Protocol):
    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]: ...


class RelevanceScore(BaseModel):
    score: float = Field(
        ge=0.0,
        le=1.0,
        description="Relevance score between 0.0 and 1.0.",
    )


class CloseMatchKeep(BaseModel):
    """Output of the LLM grader-as-ranker.

    Schema is deliberately minimal: just an ordered list of 1-based
    indices. No reasoning field — every output token slows the call
    and the structured-output JSON wrapper already gives us
    deterministic parsing without it.
    """

    keep: list[int] = Field(
        default_factory=list,
        description=(
            "1-based indices of relevant docs, ORDERED most → least "
            "relevant. First index is the top result. Drop irrelevant "
            "docs (don't include them). Indices only — small integers "
            "matching the [1] [2] [3] markers shown before each doc."
        ),
    )
