from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class QualityAssessment(BaseModel):
    reason: str
    sufficient: bool


class AnswerGrade(BaseModel):
    sufficient: bool
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str
    suggestion: str
    memory_worth_storing: bool = Field(
        default=False,
        description=(
            "True ONLY when this exchange revealed a corpus-general "
            "search fact (synonym, alias, brand spelling, typo, "
            "informal→formal term mapping) that will improve future "
            "retrieval on the same corpus. False for plain questions, "
            "single-doc facts, or anything specific to one user."
        ),
    )
    memory_confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description=(
            "Confidence that this mapping is correct AND broadly useful "
            "for future retrieval. Independent of answer confidence. "
            "Storage only happens when this exceeds "
            "memory_storage_threshold."
        ),
    )
    memory_fact: str = Field(
        default="",
        description=(
            "If memory_worth_storing is true, a single self-contained "
            "search-fact in the form 'X is also called Y' or "
            "'Query X refers to product type Y' (≤120 chars, plain "
            "prose). Empty string when not worth storing."
        ),
    )
    rerank_focus: str = Field(
        default="",
        description=(
            "Optional rerank-guidance hint. When the docs are roughly "
            "right but ranked wrong, the grader can write a short "
            "augmented query here (e.g. 'Flaschenöffner zum Bier "
            "öffnen' for the user's 'bieröffner') that the next "
            "iteration's reranker will score against, INSTEAD of the "
            "raw user query. Use only when reranking against the "
            "canonical query is the actual problem — otherwise leave "
            "empty so retrieval / rewrite handles it."
        ),
    )
    retry_strategy: Literal["widen", "narrow", "pinpoint"] | None = Field(
        default=None,
        description=(
            "How the next retrieval attempt should adjust scope. "
            "'widen': results were off-topic, missing, or too few — "
            "broaden the query, try synonyms or a different angle. "
            "'narrow': results are on-topic but too many similar "
            "variants — add a filter, attribute, or more specific term. "
            "'pinpoint': the question contains a very specific product "
            "identifier (article number, manufacturer code, EAN, GTIN) "
            "that should be extracted and looked up exactly. "
            "null when sufficient=true or strategy is unclear."
        ),
    )
    pinpoint_code: str = Field(
        default="",
        description=(
            "When retry_strategy='pinpoint', the exact identifier "
            "extracted from the question (e.g. '10.661.523.000FL', "
            "'37716367'). Empty otherwise."
        ),
    )


class RelevanceCheck(BaseModel):
    confidence: float
    makes_sense: bool


class RetrievalPlan(BaseModel):
    """LLM-emitted plan for how to handle this query — runs ONCE at
    the top of the graph. Replaces hardcoded routing decisions with a
    single LLM judgment about query intent.

    Maps to graph behavior:
      - smalltalk:        skip retrieval, generate direct ack
      - id_lookup:        Tier-0 fast track + skip rewrite loop
      - specific_product: standard retrieve path
      - category_browse:  retrieve with broader top_k
      - compare:          split into sub_queries, parallel retrieves
      - compound:         split into sub_queries, sequential retrieves
    """

    intent: str = Field(
        default="specific_product",
        description=(
            "One of: smalltalk, id_lookup, specific_product, "
            "category_browse, compare, compound. Defaults to "
            "specific_product when unsure (most general)."
        ),
    )
    sub_queries: list[str] = Field(
        default_factory=list,
        description=(
            "For 'compare' or 'compound' intents: 2-5 atomic sub-"
            "queries the system should retrieve separately. Empty "
            "for single-shot intents."
        ),
    )
    skip_retrieval: bool = Field(
        default=False,
        description=(
            "True only for smalltalk / pure conversational turns "
            "that need no documents. Default false."
        ),
    )
    rationale: str = Field(
        default="",
        description="One sentence explaining the classification.",
    )


