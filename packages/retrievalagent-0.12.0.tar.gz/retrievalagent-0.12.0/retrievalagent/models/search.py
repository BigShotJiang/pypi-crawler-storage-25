from __future__ import annotations

from pydantic import BaseModel, Field


class SearchQuery(BaseModel):
    reasoning: str = ""
    query: str
    variants: list[str] = []
    semantic_ratio: float = 0.5
    fusion: str = "rrf"
    alternative_to: str | None = None


class MultiQuery(BaseModel):
    queries: list[str]


class SynonymResult(BaseModel):
    queries: list[str]
    corrected_query: str | None = None
    excluded_terms: list[str] = []


class NoResultSuggestion(BaseModel):
    message: str = Field(
        description="Short explanation that nothing was found, written for the end-user."
    )
    suggestions: list[str] = Field(
        description="2-3 alternative queries the user could try, as short keyword strings."
    )


class ProductCodeQuery(BaseModel):
    is_product_code: bool = Field(
        description="True if the query is asking to look up a product by a specific code, ID, EAN, GTIN, barcode, or article number."
    )
    code: str | None = Field(
        default=None,
        description="The extracted numeric code (digits only, no prefix words). Null if not a product-code query.",
    )


class StandaloneQuery(BaseModel):
    query: str = Field(
        description="The rewritten standalone search query. If already standalone, return it unchanged."
    )
    is_followup: bool = Field(
        default=False,
        description=(
            "True if this is a follow-up to the previous turn that can be "
            "answered from the same documents (e.g. 'was kostet der erste?', "
            "'vergleiche die beiden', 'welche davon sind auf Lager?'). "
            "False if it is a new search requiring fresh retrieval."
        ),
    )


class HypotheticalDoc(BaseModel):
    text: str = Field(
        description="2-4 sentences written as if extracted from a relevant document. Domain terminology, specific identifiers, technical terms. No questions."
    )
