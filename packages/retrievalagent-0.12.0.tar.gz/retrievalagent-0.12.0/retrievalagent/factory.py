from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Callable, Literal

from .backend import SearchBackend
from .embed.embedder import Embedder, coerce_embedder

if TYPE_CHECKING:
    from .core import AgenticRAG

_BackendBuilder = Callable[
    [str, str | None, Callable[[str], list[float]] | None, dict[str, Any]],
    Any,
]


def _build_index_backend(
    cls_name: str, *, takes_endpoint: bool = False
) -> _BackendBuilder:
    """Builder for backends whose ctor signature is `(index, *, url=, embed_fn=)`."""

    def _build(
        index: str,
        url: str | None,
        embed_fn: Callable[[str], list[float]] | None,
        backend_kwargs: dict[str, Any],
    ) -> Any:
        from . import backend as _backend_mod

        cls = getattr(_backend_mod, cls_name)
        kw: dict[str, Any] = {}
        if url is not None:
            kw["endpoint" if takes_endpoint else "url"] = url
        if embed_fn is not None and cls_name not in _NO_EMBED_FN:
            kw["embed_fn"] = embed_fn
        kw.update(backend_kwargs)
        return cls(index, **kw)

    return _build


def _build_in_memory(
    index: str,
    url: str | None,
    embed_fn: Callable[[str], list[float]] | None,
    backend_kwargs: dict[str, Any],
) -> Any:
    from . import backend as _backend_mod

    kw: dict[str, Any] = {}
    if embed_fn is not None:
        kw["embed_fn"] = embed_fn
    kw.update(backend_kwargs)
    return _backend_mod.InMemoryBackend(**kw)


_NO_EMBED_FN: frozenset[str] = frozenset(
    {"MeilisearchBackend", "AzureAISearchBackend"}
)

# alias → builder. Adding a new backend = one line here + the impl class.
_BACKEND_BUILDERS: dict[str, _BackendBuilder] = {
    "memory": _build_in_memory,
    "in_memory": _build_in_memory,
    "inmemory": _build_in_memory,
    "chroma": _build_index_backend("ChromaDBBackend"),
    "chromadb": _build_index_backend("ChromaDBBackend"),
    "qdrant": _build_index_backend("QdrantBackend"),
    "lance": _build_index_backend("LanceDBBackend"),
    "lancedb": _build_index_backend("LanceDBBackend"),
    "duckdb": _build_index_backend("DuckDBBackend"),
    "duck": _build_index_backend("DuckDBBackend"),
    "pgvector": _build_index_backend("PgvectorBackend"),
    "postgres": _build_index_backend("PgvectorBackend"),
    "pg": _build_index_backend("PgvectorBackend"),
    "postgres_fts": _build_index_backend("PostgresFTSBackend"),
    "pg_fts": _build_index_backend("PostgresFTSBackend"),
    "sqlite": _build_index_backend("SQLiteFTSBackend"),
    "sqlite_fts": _build_index_backend("SQLiteFTSBackend"),
    "meilisearch": _build_index_backend("MeilisearchBackend"),
    "meili": _build_index_backend("MeilisearchBackend"),
    "azure": _build_index_backend("AzureAISearchBackend", takes_endpoint=True),
    "azure_ai_search": _build_index_backend(
        "AzureAISearchBackend", takes_endpoint=True
    ),
    "azureaisearch": _build_index_backend(
        "AzureAISearchBackend", takes_endpoint=True
    ),
}


_RerankerBuilder = Callable[[str | None, dict[str, Any]], Any]


def _build_reranker_for(cls_name: str) -> _RerankerBuilder:
    def _build(model: str | None, reranker_kwargs: dict[str, Any]) -> Any:
        from . import rerankers as _rerankers_mod

        cls = getattr(_rerankers_mod, cls_name)
        kw: dict[str, Any] = {}
        if model is not None:
            kw["model"] = model
        kw.update(reranker_kwargs)
        return cls(**kw)

    return _build


_RERANKER_BUILDERS: dict[str, _RerankerBuilder] = {
    "cohere": _build_reranker_for("CohereReranker"),
    "cohere-direct": _build_reranker_for("CohereDirectReranker"),
    "cohere_direct": _build_reranker_for("CohereDirectReranker"),
    "huggingface": _build_reranker_for("HuggingFaceReranker"),
    "hf": _build_reranker_for("HuggingFaceReranker"),
    "jina": _build_reranker_for("JinaReranker"),
    "llm": _build_reranker_for("LLMReranker"),
    "rerankers": _build_reranker_for("RerankersReranker"),
}


def _build_backend(
    backend_str: str,
    index: str,
    url: str | None,
    embed_fn: Callable[[str], list[float]] | None,
    backend_kwargs: dict[str, Any],
) -> Any:
    builder = _BACKEND_BUILDERS.get(backend_str.lower())
    if builder is None:
        raise ValueError(
            f"Unknown backend {backend_str!r}. "
            f"Choose from: {', '.join(sorted(_BACKEND_BUILDERS))}."
        )
    return builder(index, url, embed_fn, backend_kwargs)


def _build_collections_map(
    collections: list[str] | dict[str, str],
    *,
    backend_str: str,
    url: str | None,
    embed_fn: Callable[[str], list[float]] | None,
    backend_kwargs: dict[str, Any],
) -> dict[str, Any]:
    names = list(collections.keys() if isinstance(collections, dict) else collections)
    if not names:
        raise ValueError("collections must contain at least one name")
    return {
        name: _build_backend(backend_str, name, url, embed_fn, backend_kwargs)
        for name in names
    }


def _build_reranker(
    reranker_str: str,
    reranker_model: str | None,
    reranker_kwargs: dict[str, Any],
) -> Any:
    import warnings

    builder = _RERANKER_BUILDERS.get(reranker_str.lower())
    if builder is None:
        raise ValueError(
            f"Unknown reranker {reranker_str!r}. "
            f"Choose from: {', '.join(sorted(_RERANKER_BUILDERS))}."
        )
    try:
        return builder(reranker_model, reranker_kwargs)
    except Exception as exc:
        warnings.warn(
            f"{reranker_str!r} reranker unavailable ({exc}). "
            "Falling back to LLMReranker.",
            stacklevel=3,
        )
        return _build_reranker_for("LLMReranker")(None, {})


def _default_mem0_config() -> dict[str, Any] | None:
    """Auto-build a mem0 config from environment.

    If AZURE_OPENAI_API_KEY is set, build a config that points mem0's
    LLM and embedder at Azure OpenAI (matches our own model wiring).
    Otherwise return None and let mem0 use its OpenAI default
    (requires OPENAI_API_KEY).
    """
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        return None
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    chat_deployment = os.getenv(
        "AZURE_OPENAI_DEPLOYMENT", os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", "")
    )
    embed_deployment = os.getenv(
        "AZURE_OPENAI_EMBEDDING_DEPLOYMENT",
        os.getenv("AZURE_OPENAI_EMBED_DEPLOYMENT", ""),
    )
    if not (endpoint and api_key and chat_deployment and embed_deployment):
        return None
    azure_kwargs_chat = {
        "azure_deployment": chat_deployment,
        "api_key": api_key,
        "api_version": api_version,
        "azure_endpoint": endpoint,
    }
    azure_kwargs_embed = {
        "azure_deployment": embed_deployment,
        "api_key": api_key,
        "api_version": api_version,
        "azure_endpoint": endpoint,
    }
    return {
        "llm": {
            "provider": "azure_openai",
            "config": {
                "model": chat_deployment,
                "azure_kwargs": azure_kwargs_chat,
            },
        },
        "embedder": {
            "provider": "azure_openai",
            "config": {
                "model": embed_deployment,
                "azure_kwargs": azure_kwargs_embed,
            },
        },
    }


def init_agent(
    index: str = "",
    *,
    collections: list[str] | dict[str, str] | None = None,
    model: str | None = None,
    gen_model: str | None = None,
    backend: Literal[
        "memory", "in_memory", "inmemory",
        "meilisearch", "meili",
        "qdrant",
        "chroma", "chromadb",
        "lance", "lancedb",
        "duckdb", "duck",
        "pgvector", "postgres", "pg",
        "postgres_fts", "pg_fts",
        "sqlite", "sqlite_fts",
        "azure", "azure_ai_search", "azureaisearch",
    ] | SearchBackend | None = None,
    backend_url: str | None = None,
    backend_kwargs: dict[str, Any] | None = None,
    reranker: str | Any | None = None,
    reranker_model: str | None = None,
    reranker_kwargs: dict[str, Any] | None = None,
    embed_fn: Embedder | Callable[[str], list[float]] | None = None,
    memory: bool | str | Any = False,
    memory_config: dict[str, Any] | None = None,
    **kwargs: Any,
) -> "AgenticRAG":
    """One-line agent builder.

    Memory shortcut:
        memory=True            → mem0.Memory() with default settings
        memory="mem0"          → same
        memory=Memory(...)     → use the provided mem0/AsyncMemory instance
        memory=<langgraph store> → use as memory_store
        memory=False (default) → no long-term memory
    `memory_config` is forwarded to mem0.Memory.from_config when memory=True.
    """
    from .core import AgenticRAG

    memory_kind: str | None = None
    if memory is not False and memory is not None:
        if memory is True or memory == "mem0":
            from mem0 import Memory  # type: ignore[import-untyped]

            cfg = memory_config or _default_mem0_config()
            mem0_instance = Memory.from_config(cfg) if cfg else Memory()
            kwargs.setdefault("mem0_memory", mem0_instance)
            memory_kind = "mem0"
        elif hasattr(memory, "search") or hasattr(memory, "asearch"):
            cls_name = type(memory).__name__.lower()
            if "memory" in cls_name and "store" not in cls_name:
                kwargs.setdefault("mem0_memory", memory)
                memory_kind = f"mem0 ({type(memory).__name__})"
            else:
                kwargs.setdefault("memory_store", memory)
                memory_kind = f"langgraph store ({type(memory).__name__})"
        else:
            raise TypeError(
                f"Unsupported memory= value: {type(memory).__name__}. "
                "Pass True/'mem0', a mem0 Memory/AsyncMemory instance, "
                "or a LangGraph BaseStore."
            )

    if memory_kind:
        import sys as _sys

        print(
            f"[retrievalagent] memory enabled: {memory_kind} "
            "(read-gate=memory_relevance_threshold, "
            "write-gate=memory_storage_threshold; both env-overridable)",
            file=_sys.stderr,
        )

    # Normalize at the boundary so the rest of init_agent and the agent
    # itself see a single shape (Embedder | None). Backends still get a
    # callable since Embedder.__call__ delegates to .embed.
    resolved_embedder: Embedder | None = coerce_embedder(embed_fn)
    embed_fn_for_backend: Callable[[str], list[float]] | None = (
        resolved_embedder if resolved_embedder is not None else None
    )

    resolved_backend: Any = None
    resolved_collections: dict[str, Any] | None = None
    collection_descriptions: dict[str, str] | None = None

    if collections is not None:
        if isinstance(collections, dict):
            collection_descriptions = dict(collections)
        resolved_collections = _build_collections_map(
            collections,
            backend_str=backend if isinstance(backend, str) else "memory",
            url=backend_url,
            embed_fn=embed_fn_for_backend,
            backend_kwargs=backend_kwargs or {},
        )
    elif backend is None or isinstance(backend, str):
        if not index:
            raise ValueError("init_agent requires `index` or `collections`")
        resolved_backend = _build_backend(
            backend or "memory",
            index,
            backend_url,
            embed_fn_for_backend,
            backend_kwargs or {},
        )
    else:
        resolved_backend = backend

    resolved_reranker: Any | None = None
    if reranker is not None:
        if isinstance(reranker, str):
            resolved_reranker = _build_reranker(
                reranker, reranker_model, reranker_kwargs or {}
            )
        else:
            resolved_reranker = reranker

    def _coerce_model(m: Any) -> Any:
        """Accept either a langchain model string ("openai:gpt-5.4") or
        an already-built BaseChatModel-like instance. Strings go through
        AgenticRAG._resolve_llm so Azure-specific kwargs (azure_endpoint,
        api_version, api_key) get injected from AZURE_OPENAI_* env vars —
        init_chat_model alone only reads OPENAI_API_VERSION.
        """
        if isinstance(m, str):
            from .core import AgenticRAG

            return AgenticRAG._resolve_llm(m)
        return m

    if model is not None:
        llm = _coerce_model(model)
        kwargs["llm"] = llm
        kwargs["gen_llm"] = _coerce_model(gen_model) if gen_model else llm
    elif gen_model is not None:
        kwargs["gen_llm"] = _coerce_model(gen_model)

    if resolved_embedder is not None:
        # Pass the Embedder; AgenticRAG accepts both Embedder and callable.
        kwargs.setdefault("embed_fn", resolved_embedder)

    if resolved_reranker is not None:
        kwargs["reranker"] = resolved_reranker

    if "config" not in kwargs:
        from .config import RAGConfig

        kwargs["config"] = RAGConfig.auto()

    # Long-term memory writes are gated by the LLM final-grade decision.
    # If the user enabled memory but didn't touch final_grade, turn it on
    # automatically — otherwise the write_memory node would never fire.
    if memory_kind and hasattr(kwargs["config"], "enable_final_grade"):
        cfg_obj = kwargs["config"]
        if not cfg_obj.enable_final_grade:
            cfg_obj.enable_final_grade = True

    if resolved_collections is not None:
        return AgenticRAG(
            index=index or ",".join(resolved_collections),
            collections=resolved_collections,
            collection_descriptions=collection_descriptions,
            **kwargs,
        )
    return AgenticRAG(index=index, backend=resolved_backend, **kwargs)
