"""Score-fusion algorithms for hybrid retrieval (BM25 + vector).

`_rrf_fuse` is reciprocal-rank fusion — combines rankings without
needing comparable raw scores. `_dbsf_fuse` is distribution-based
score fusion — normalizes per-list min/max before summing, useful
when score scales differ wildly between BM25 and dense.
`_mmr_diverse` is Maximal Marginal Relevance — greedy diversity pass
over a pre-ranked Document list using bag-of-words Jaccard similarity.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.documents import Document


def _rrf_fuse(
    results: list[list[dict]],
    k: int = 60,
    ranking_score_weight: float = 0.0,
) -> list[dict]:
    scores: dict[str, float] = {}
    seen: dict[str, dict] = {}
    for ranked in results:
        for rank, doc in enumerate(ranked):
            dget = doc.get  # type: ignore[var-annotated]
            doc_id = dget("id") or dget("corpus_id") or str(doc)
            rrf = 1.0 / (k + rank + 1)
            if ranking_score_weight > 0.0:
                rrf *= 1.0 + ranking_score_weight * dget("_rankingScore", 0.5)
            scores[doc_id] = scores.get(doc_id, 0.0) + rrf
            seen.setdefault(doc_id, doc)
    return [seen[did] for did in sorted(scores, key=scores.__getitem__, reverse=True)]


def _mmr_diverse(
    docs: list[Document],
    lam: float = 0.7,
    top_k: int = 20,
) -> list[Document]:
    """Maximal Marginal Relevance diversity pass over a pre-ranked Document list.

    Uses bag-of-words Jaccard similarity — no embeddings required.
    lam=1.0 → pure relevance order; lam=0.0 → maximum diversity.
    Input docs are assumed sorted by descending relevance.
    """
    if len(docs) <= top_k:
        return docs

    def _words(doc: Document) -> frozenset[str]:
        return frozenset(doc.page_content[:400].lower().split())

    def _jaccard(a: frozenset[str], b: frozenset[str]) -> float:
        union = len(a | b)
        return len(a & b) / union if union else 0.0

    word_sets = [_words(d) for d in docs]
    relevance = [1.0 / (i + 1) for i in range(len(docs))]

    selected: list[int] = []
    selected_words: list[frozenset[str]] = []
    remaining = list(range(len(docs)))

    for _ in range(min(top_k, len(docs))):
        best_i, best_score = -1, float("-inf")
        for i in remaining:
            sim = 0.0
            ws_i = word_sets[i]
            for sw in selected_words:
                j = len(ws_i & sw) / len(ws_i | sw) if ws_i or sw else 0.0
                if j > sim:
                    sim = j
            score = lam * relevance[i] - (1.0 - lam) * sim
            if score > best_score:
                best_score, best_i = score, i
        selected.append(best_i)
        selected_words.append(word_sets[best_i])
        remaining.remove(best_i)

    return [docs[i] for i in selected]


def _dbsf_fuse(
    results: list[list[dict]],
    score_field: str = "_rankingScore",
) -> list[dict]:
    scores: dict[str, float] = {}
    seen: dict[str, dict] = {}
    for ranked in results:
        if not ranked:
            continue
        raw = [doc.get(score_field, 0.0) for doc in ranked]
        lo, hi = min(raw), max(raw)
        span = hi - lo if hi > lo else 1.0
        for doc, raw_score in zip(ranked, raw):
            dget = doc.get  # type: ignore[var-annotated]
            doc_id = dget("id") or dget("corpus_id") or str(doc)
            normalized = (raw_score - lo) / span
            scores[doc_id] = scores.get(doc_id, 0.0) + normalized
            seen.setdefault(doc_id, doc)
    return [seen[did] for did in sorted(scores, key=scores.__getitem__, reverse=True)]
