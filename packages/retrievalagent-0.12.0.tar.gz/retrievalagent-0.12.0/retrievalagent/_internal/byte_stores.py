"""Pluggable byte stores for LangChain CacheBackedEmbeddings.

LangChain's CacheBackedEmbeddings expects a key→bytes store with
mget/mset/mdelete/yield_keys. Redis and Postgres are useful for
shared caches across processes; LocalFileStore is built into
LangChain and used as the default fallback.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


class _RedisByteStore:
    def __init__(self, url: str) -> None:
        import redis as _redis  # type: ignore[import-not-found]  # ty: ignore[unresolved-import]

        self._client = _redis.Redis.from_url(url, decode_responses=False)

    def mget(self, keys: list[str]) -> list[bytes | None]:
        return self._client.mget(keys) if keys else []  # type: ignore[return-value]

    def mset(self, key_value_pairs: list[tuple[str, bytes]]) -> None:
        if key_value_pairs:
            self._client.mset(dict(key_value_pairs))

    def mdelete(self, keys: list[str]) -> None:
        if keys:
            self._client.delete(*keys)

    def yield_keys(self, *, prefix: str | None = None):  # type: ignore[return]
        pattern = f"{prefix}*" if prefix else "*"
        for k in self._client.scan_iter(pattern):
            yield k.decode() if isinstance(k, bytes) else k


class _PgByteStore:
    def __init__(self, dsn: str, table: str = "retrievalagent_lc_embed_cache") -> None:
        import psycopg  # type: ignore[import-not-found]

        self._dsn = dsn
        self._table = table
        with psycopg.connect(dsn) as conn:
            conn.execute(  # ty: ignore[no-matching-overload]
                f"CREATE TABLE IF NOT EXISTS {table} "  # noqa: S608
                "(key TEXT PRIMARY KEY, value BYTEA NOT NULL)"
            )
            conn.commit()

    def mget(self, keys: list[str]) -> list[bytes | None]:
        import psycopg  # type: ignore[import-not-found]

        if not keys:
            return []
        with psycopg.connect(self._dsn) as conn:
            return [
                (lambda row: bytes(row[0]) if row else None)(
                    conn.execute(
                        f"SELECT value FROM {self._table} WHERE key = %s",  # noqa: S608  # ty: ignore[invalid-argument-type]
                        (k,),
                    ).fetchone()
                )
                for k in keys
            ]

    def mset(self, key_value_pairs: list[tuple[str, bytes]]) -> None:
        import psycopg  # type: ignore[import-not-found]

        if not key_value_pairs:
            return
        with psycopg.connect(self._dsn) as conn:
            for key, value in key_value_pairs:
                conn.execute(
                    f"INSERT INTO {self._table}(key, value) VALUES (%s, %s) "  # noqa: S608  # ty: ignore[invalid-argument-type]
                    "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
                    (key, value),
                )
            conn.commit()

    def mdelete(self, keys: list[str]) -> None:
        import psycopg  # type: ignore[import-not-found]

        if not keys:
            return
        with psycopg.connect(self._dsn) as conn:
            for key in keys:
                conn.execute(
                    f"DELETE FROM {self._table} WHERE key = %s",  # noqa: S608  # ty: ignore[invalid-argument-type]
                    (key,),
                )
            conn.commit()

    def yield_keys(self, *, prefix: str | None = None):  # type: ignore[return]
        import psycopg  # type: ignore[import-not-found]

        with psycopg.connect(self._dsn) as conn:
            if prefix:
                rows = conn.execute(
                    f"SELECT key FROM {self._table} WHERE key LIKE %s",  # noqa: S608  # ty: ignore[invalid-argument-type]
                    (prefix + "%",),
                ).fetchall()
            else:
                rows = conn.execute(  # ty: ignore[no-matching-overload]
                    f"SELECT key FROM {self._table}"  # noqa: S608
                ).fetchall()
        yield from (row[0] for row in rows)


def _make_embed_byte_store(uri: str) -> Any:
    if uri.startswith(("redis://", "rediss://")):
        return _RedisByteStore(uri)
    if uri.startswith(("postgres://", "postgresql://")):
        return _PgByteStore(uri)
    from langchain.storage import LocalFileStore  # type: ignore[import-not-found]  # ty: ignore[unresolved-import]

    return LocalFileStore(str(Path(uri).expanduser()))
