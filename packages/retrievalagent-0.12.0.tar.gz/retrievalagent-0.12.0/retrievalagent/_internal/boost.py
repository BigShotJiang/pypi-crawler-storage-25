"""Backend-aware popularity boost seam.

`BoostSignals` packages the popularity-ranking signals discovered by
`helpers.schema_introspect._detect_index_signals` into a single value
object that backends can act on. The default `SearchBackend.boost_for_query`
implementation applies `boost_fn` client-side (preserving today's behaviour);
backends with native ranking (Meilisearch `sortable_attributes`, Qdrant decay
functions, Chroma KNN arithmetic) can override `boost_for_query` to push the
multiplier into the engine and avoid per-hit Python work.

The dataclass intentionally exposes the same four fields the introspection
helper already returns so the call-site stays one line:

    signals = BoostSignals.from_introspection(*_detect_index_signals(backend))
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

BoostFn = Callable[[dict], float]


@dataclass(frozen=True)
class BoostSignals:
    """Popularity-ranking signals derived from a backend's schema.

    Attributes:
        sort_fields: Backend-native sort directives (e.g. ``["sales:desc"]``).
            Already in the backend's wire format — Meili-style by default.
        boost_fn: Client-side multiplier ``(metadata) -> float`` for use when
            the backend cannot apply the boost natively. Returns 1.0 when no
            boost is desired.
        num_fields: Sortable numeric fields, primary first. Used by native
            implementations that build per-field decay functions.
        primary_bool: First sortable bool field — the schema's declared
            "preferred-item" flag. Used as a tie-breaker when relevance
            scores are equal.
    """

    sort_fields: list[str] = field(default_factory=list)
    boost_fn: BoostFn | None = None
    num_fields: list[str] = field(default_factory=list)
    primary_bool: str | None = None

    @property
    def is_empty(self) -> bool:
        """No signals to apply — caller can short-circuit."""
        return (
            not self.sort_fields
            and self.boost_fn is None
            and not self.num_fields
            and self.primary_bool is None
        )

    @classmethod
    def from_introspection(
        cls,
        sort_fields: list[str] | None,
        boost_fn: BoostFn | None,
        num_fields: list[str],
        primary_bool: str | None,
    ) -> "BoostSignals":
        """Adapter for `_detect_index_signals`'s 4-tuple return shape."""
        return cls(
            sort_fields=list(sort_fields or []),
            boost_fn=boost_fn,
            num_fields=list(num_fields),
            primary_bool=primary_bool,
        )


def apply_boost_fn(hits: list[dict], signals: BoostSignals) -> list[dict]:
    """Default client-side popularity boost.

    Multiplies each hit's ``_rerank_score`` (or a position-decay fallback
    when the cross-encoder hasn't run yet) by ``signals.boost_fn(hit)``,
    then sorts descending. Position decay preserves the caller's input
    ordering when reranks aren't available, so boost differences shift
    docs a few slots without overriding the relevance baseline.

    When ``boost_fn`` is None the input order is preserved — the caller's
    relevance ranking wins.

    This is the fallback used by `SearchBackend.boost_for_query`; backends
    with native scoring should override that method instead of calling this.
    """
    if not hits or signals.boost_fn is None:
        return list(hits)
    boost_fn = signals.boost_fn
    n = max(len(hits), 1)
    decay = 1.0 / max(n - 1, 1)

    indexed: list[tuple[int, dict]] = list(enumerate(hits))

    def _key(item: tuple[int, dict]) -> float:
        idx, hit = item
        rerank = hit.get("_rerank_score")
        if isinstance(rerank, (int, float)):
            base = float(rerank)
        else:
            base = 1.0 - idx * decay
        return base * boost_fn(hit)

    indexed.sort(key=_key, reverse=True)
    return [hit for _, hit in indexed]
