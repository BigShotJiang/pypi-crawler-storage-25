"""Sync ↔ async bridge.

`_run_sync` runs an async coroutine from sync code, even when an
event loop is already running (uses a worker thread to avoid the
"already running" RuntimeError). Used by `chat()`, `invoke()`, and
the sync wrappers around the async pipeline.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
from typing import Any, Coroutine


def _run_sync(coro: Coroutine[Any, Any, Any]) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()
