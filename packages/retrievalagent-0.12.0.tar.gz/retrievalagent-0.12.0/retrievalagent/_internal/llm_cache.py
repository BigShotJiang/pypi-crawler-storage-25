from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
from typing import Any

_ENABLED = os.environ.get("RAG_CACHE", "0").lower() in ("1", "true", "yes", "on")
_PG_URL = os.environ.get("RAG_CACHE_PG_URL") or os.environ.get("DATABASE_URL")
_DIR = os.environ.get("RAG_CACHE_DIR")

_mem: dict[str, Any] = {}
_pg_pool: Any = None
_pg_ready = False
_disk_ready = False


def _try_pg() -> Any:
    global _pg_pool, _pg_ready
    if _pg_ready:
        return _pg_pool
    _pg_ready = True
    if not (_ENABLED and _PG_URL):
        return None
    try:
        from psycopg_pool import ConnectionPool

        pool = ConnectionPool(_PG_URL, min_size=1, max_size=4, open=True)
        with pool.connection() as conn, conn.cursor() as cur:
            cur.execute(
                "CREATE TABLE IF NOT EXISTS retrievalagent_cache "
                "(key text PRIMARY KEY, value jsonb NOT NULL, "
                "created_at timestamptz DEFAULT now())"
            )
            conn.commit()
        _pg_pool = pool
        return pool
    except Exception:
        return None


def _disk_dir() -> Path | None:
    global _disk_ready
    if not (_ENABLED and _DIR):
        return None
    p = Path(_DIR)
    if not _disk_ready:
        try:
            p.mkdir(parents=True, exist_ok=True)
            _disk_ready = True
        except Exception:
            return None
    return p


def _hash(ns: str, *parts: Any) -> str:
    h = hashlib.sha256(ns.encode())
    for p in parts:
        h.update(b"\x00")
        h.update(repr(p).encode())
    return f"{ns}_{h.hexdigest()[:24]}"


def load(ns: str, *parts: Any) -> Any:
    """In-memory cache is always on (process-local, free). Disk and
    Postgres caches require `RAG_CACHE=1`. Without that flag we still
    de-duplicate within the running process — repeat queries within a
    session don't re-fire LLM calls.
    """
    key = _hash(ns, *parts)
    if _ENABLED:
        pool = _try_pg()
        if pool is not None:
            try:
                with pool.connection() as conn, conn.cursor() as cur:
                    cur.execute(
                        "SELECT value FROM retrievalagent_cache WHERE key=%s",
                        (key,),
                    )
                    row = cur.fetchone()
                    if row is not None:
                        return row[0]
            except Exception:
                pass
        d = _disk_dir()
        if d is not None:
            f = d / f"{key}.json"
            if f.exists():
                try:
                    return json.loads(f.read_text())
                except Exception:
                    pass
    return _mem.get(key)


def save(ns: str, *parts: Any, value: Any) -> None:
    """Always populate in-memory cache. Disk/Postgres only when
    `RAG_CACHE=1` is set.
    """
    key = _hash(ns, *parts)
    _mem[key] = value
    if not _ENABLED:
        return
    pool = _try_pg()
    if pool is not None:
        try:
            with pool.connection() as conn, conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO retrievalagent_cache(key, value) VALUES (%s, %s) "
                    "ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value",
                    (key, json.dumps(value)),
                )
                conn.commit()
        except Exception:
            pass
        return
    d = _disk_dir()
    if d is not None:
        try:
            (d / f"{key}.json").write_text(json.dumps(value))
        except Exception:
            pass


async def aload(ns: str, *parts: Any) -> Any:
    """Async wrapper around `load` — runs the sync I/O on a thread
    so async callers don't block the event loop on cache reads."""
    return await asyncio.to_thread(load, ns, *parts)


async def asave(ns: str, *parts: Any, value: Any) -> None:
    await asyncio.to_thread(lambda: save(ns, *parts, value=value))
