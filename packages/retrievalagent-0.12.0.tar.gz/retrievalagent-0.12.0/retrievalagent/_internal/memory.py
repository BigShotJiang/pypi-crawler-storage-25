"""Unified memory protocol for AgenticRAG.

Background
----------
AgenticRAG historically carried two parallel memory adapters wired into
``MemoryMixin``: a LangGraph ``BaseStore`` (``_memory_store``) and a
mem0 ``Memory`` / ``AsyncMemory`` (``_mem0_memory``).  Each had its own
read/write code path, its own signatures, and its own behavioural
quirks (only the mem0 path scored recalls against
``memory_relevance_threshold``).  Adding a third backend (Redis, hybrid,
…) meant another parallel path.

This module unifies the seam behind a single :class:`Memory` Protocol.
Adapters wrap the underlying storage; ``MemoryMixin`` becomes a thin
facade over ``list[Memory]`` so callers see one interface and new
backends plug in by satisfying the Protocol.

Design notes
------------
* ``MemoryItem`` is the wire-format record exchanged with adapters.
  ``score`` is populated by adapters that can compute one (mem0
  returns a similarity score); store-style adapters leave it ``None``.
* ``recall`` returns items already filtered by the adapter's own
  policy; the facade does not re-filter.  This preserves each
  adapter's legitimate behavioural differences (e.g. mem0's
  threshold-based gating).
* The protocol is intentionally narrow — ``add``/``recall``/``clear``.
  Anything richer (TTL, namespacing, batch ops) lives on the concrete
  adapter and is opaque to the facade.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

_log = logging.getLogger(__name__)


@dataclass(slots=True)
class MemoryItem:
    """A single memory record exchanged with :class:`Memory` adapters."""

    text: str
    user_id: str = "default"
    score: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class Memory(Protocol):
    """Async memory adapter.

    Implementations are responsible for any backend-specific filtering
    (e.g. relevance thresholds).  Callers see a single uniform API.
    """

    async def add(self, item: MemoryItem) -> None: ...

    async def recall(
        self, query: str, *, user_id: str = "default", k: int = 5
    ) -> list[MemoryItem]: ...

    async def clear(self, *, user_id: str | None = None) -> None: ...


class LangGraphStoreMemory:
    """Adapter over a LangGraph ``BaseStore``.

    The store has no native relevance score, so :attr:`MemoryItem.score`
    is left ``None``.  Items are namespaced by ``("memories", user_id)``.
    """

    def __init__(self, store: Any) -> None:
        self._store = store

    @property
    def raw(self) -> Any:
        """The wrapped LangGraph store (also used as agent ``store=``)."""
        return self._store

    async def add(self, item: MemoryItem) -> None:
        try:
            await self._store.aput(
                ("memories", item.user_id),
                str(uuid.uuid4()),
                {"text": item.text, "ts": time.time(), **item.metadata},
            )
        except Exception as e:
            _log.warning("langgraph store write failed: %s", e)

    async def recall(
        self, query: str, *, user_id: str = "default", k: int = 5
    ) -> list[MemoryItem]:
        try:
            results = await self._store.asearch(
                ("memories", user_id), query=query, limit=k
            )
        except Exception:
            return []
        out: list[MemoryItem] = []
        for r in results or []:
            value = getattr(r, "value", None) or {}
            text = value.get("text") if isinstance(value, dict) else None
            if not text:
                continue
            out.append(MemoryItem(text=str(text), user_id=user_id))
        return out

    async def clear(self, *, user_id: str | None = None) -> None:
        # LangGraph BaseStore has no bulk-delete; best effort: list+adelete.
        ns = ("memories", user_id or "default")
        try:
            results = await self._store.asearch(ns, query="", limit=1000)
        except Exception:
            return
        for r in results or []:
            key = getattr(r, "key", None)
            if key is None:
                continue
            try:
                await self._store.adelete(ns, key)
            except Exception as e:
                _log.warning("langgraph store delete failed: %s", e)


class Mem0Memory:
    """Adapter over a mem0 ``Memory`` / ``AsyncMemory`` instance.

    Applies a relevance threshold on recall.  Items below the threshold
    are dropped silently — the threshold is enforced by the adapter so
    the facade need not know about it.
    """

    def __init__(self, mem0: Any, *, relevance_threshold: float = 0.0) -> None:
        self._mem0 = mem0
        self.relevance_threshold = relevance_threshold

    @property
    def raw(self) -> Any:
        """The wrapped mem0 instance."""
        return self._mem0

    async def add(self, item: MemoryItem) -> None:
        try:
            add_fn = getattr(self._mem0, "aadd", None) or self._mem0.add
            messages = [{"role": "user", "content": item.text}]
            if inspect.iscoroutinefunction(add_fn):
                await add_fn(messages, user_id=item.user_id)
            else:
                await asyncio.to_thread(add_fn, messages, user_id=item.user_id)
        except Exception as e:
            _log.warning("mem0 write failed: %s", e)

    async def recall(
        self, query: str, *, user_id: str = "default", k: int = 5
    ) -> list[MemoryItem]:
        try:
            search_fn = getattr(self._mem0, "asearch", None) or self._mem0.search
            filters = {"user_id": user_id}
            if inspect.iscoroutinefunction(search_fn):
                results = await search_fn(query, filters=filters)
            else:
                results = await asyncio.to_thread(search_fn, query, filters=filters)
        except Exception:
            return []
        entries = (
            results.get("results", results) if isinstance(results, dict) else results
        )
        if not entries:
            return []
        out: list[MemoryItem] = []
        for r in entries[: max(k, 10)]:
            if not isinstance(r, dict):
                continue
            text = str(r.get("memory") or r)
            raw_score = r.get("score")
            try:
                score = float(raw_score) if raw_score is not None else None
            except (TypeError, ValueError):
                score = None
            if score is not None and score < self.relevance_threshold:
                continue
            out.append(
                MemoryItem(text=text, user_id=user_id, score=score, metadata=dict(r))
            )
            if len(out) >= k:
                break
        return out

    async def clear(self, *, user_id: str | None = None) -> None:
        try:
            del_fn = getattr(self._mem0, "adelete_all", None) or getattr(
                self._mem0, "delete_all", None
            )
            if del_fn is None:
                return
            kwargs = {"user_id": user_id} if user_id is not None else {}
            if inspect.iscoroutinefunction(del_fn):
                await del_fn(**kwargs)
            else:
                await asyncio.to_thread(del_fn, **kwargs)
        except Exception as e:
            _log.warning("mem0 clear failed: %s", e)


__all__ = ["Memory", "MemoryItem", "LangGraphStoreMemory", "Mem0Memory"]
