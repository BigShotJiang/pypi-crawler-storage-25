"""Embedder factories.

Two entry points:
  - `_make_azure_embed_fn` builds a self-caching callable that hits
    Azure OpenAI's embeddings endpoint, layered over the embed_cache
    (memory + disk + optional Redis/Postgres) and the LLM-call cache.
  - `embed_fn_from_langchain` adapts any LangChain Embeddings object
    into the `Callable[[str], list[float]]` shape the backends expect,
    optionally wrapping it in CacheBackedEmbeddings.

These will be lifted to a unified `Embedder` protocol (#8 in the
deepening plan); for now they remain free factories.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable

import requests as _requests

from .cache import _embed_cache_get, _embed_cache_put


def _make_azure_embed_fn(
    dimensions: int | None = None,
) -> Callable[[str], list[float]] | None:
    endpoint = (os.getenv("AZURE_OPENAI_ENDPOINT") or "").rstrip("/")
    api_key = os.getenv("AZURE_OPENAI_API_KEY") or ""
    deploy = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
    api_ver = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")

    env_dim = os.getenv("AZURE_OPENAI_EMBEDDING_DIM") or os.getenv("RAG_EMBED_DIM")
    if dimensions is None and env_dim:
        try:
            dimensions = int(env_dim)
        except ValueError:
            dimensions = None

    if not endpoint or not api_key:
        return None

    url = f"{endpoint}/openai/deployments/{deploy}/embeddings?api-version={api_ver}"
    session = _requests.Session()
    session.headers.update({"api-key": api_key, "Content-Type": "application/json"})

    from .._internal import llm_cache as _c

    cache_ns = f"{deploy}@{dimensions}" if dimensions else deploy
    body_extra = {"dimensions": dimensions} if dimensions else {}

    def _embed(text: str) -> list[float]:
        hit = _embed_cache_get(cache_ns, text)
        if hit is not None:
            return hit
        cached = _c.load("embed-v1", cache_ns, text)
        if cached is not None:
            vec = list(cached)
            _embed_cache_put(cache_ns, text, vec)
            return vec
        resp = session.post(url, json={"input": [text], **body_extra}, timeout=15)
        resp.raise_for_status()
        vec = resp.json()["data"][0]["embedding"]
        _c.save("embed-v1", cache_ns, text, value=vec)
        _embed_cache_put(cache_ns, text, vec)
        return vec

    setattr(
        _embed,
        "_retrievalagent_azure_rebuild",
        lambda dim: _make_azure_embed_fn(dimensions=dim),
    )
    return _embed


def embed_fn_from_langchain(
    embeddings: Any,
    *,
    prefer_query: bool = True,
    cache: str | Path | None = None,
    namespace: str = "embeddings",
) -> Callable[[str], list[float]]:
    cache_uri = (
        str(cache)
        if cache is not None
        else os.environ.get("RAG_EMBED_CACHE_URL", "").strip()
    )
    if cache_uri:
        from langchain.embeddings import CacheBackedEmbeddings  # type: ignore[import-not-found]  # ty: ignore[unresolved-import]

        from .._internal.byte_stores import _make_embed_byte_store

        store = _make_embed_byte_store(cache_uri)
        embeddings = CacheBackedEmbeddings.from_bytes_store(
            embeddings,
            store,
            namespace=namespace,
            query_embedding_store=store,
        )
        prefer_query = False

    if prefer_query:
        try:
            from langchain.embeddings import CacheBackedEmbeddings  # ty: ignore[unresolved-import]

            if isinstance(embeddings, CacheBackedEmbeddings):
                prefer_query = False
        except ImportError:
            pass

    if prefer_query and hasattr(embeddings, "embed_query"):
        return embeddings.embed_query  # type: ignore[no-any-return]
    if hasattr(embeddings, "embed_documents"):

        def _embed(text: str) -> list[float]:
            return embeddings.embed_documents([text])[0]

        return _embed
    raise TypeError(
        f"{type(embeddings).__name__} has neither .embed_query nor "
        ".embed_documents — not a LangChain Embeddings-compatible object."
    )
