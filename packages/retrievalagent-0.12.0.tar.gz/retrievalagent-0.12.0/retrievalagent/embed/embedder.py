"""Embedder protocol, base class, and concrete adapters.

A bare `Callable[[str], list[float]]` was the original embedding seam:
backends, the agent, and the tuner all received one. The callable hid
four properties that downstream code repeatedly needed:

  - the output dimension (for index column sizing and validation)
  - native async support (each caller open-coded `loop.run_in_executor`)
  - native batch support (each caller did `[fn(t) for t in texts]`)
  - rebuild capability (Azure can request a smaller-dim embedder)

`Embedder` (Protocol) declares the contract; `BaseEmbedder` is the
concrete base class our adapters inherit from. A Protocol is kept on
top so user-supplied embedder objects (or duck-typed test fakes) stay
compatible without forcing inheritance.

Backwards compatibility: every code path that took a callable still
accepts an Embedder (`__call__` delegates to `embed`), and
`CallableEmbedder` lifts a legacy callable into the new shape so the
factory layer can normalize on construction.
"""

from __future__ import annotations

import asyncio
import math
from typing import Any, Callable, Protocol, runtime_checkable


@runtime_checkable
class Embedder(Protocol):
    """A callable that maps text → vector, with metadata.

    The `name` is used as a cache namespace, so two embedders that
    produce different vectors must report different names. `dim` is
    the output vector length; backends use it to size index columns
    and to validate at construction time.

    `aembed`, `aembed_batch`, and `with_target_dim` are part of the
    protocol but `BaseEmbedder` provides workable defaults — concrete
    embedders only need to implement them when there's a faster
    native path.
    """

    name: str
    dim: int

    def __call__(self, text: str) -> list[float]: ...

    def embed(self, text: str) -> list[float]: ...

    async def aembed(self, text: str) -> list[float]: ...

    async def aembed_batch(self, texts: list[str]) -> list[list[float]]: ...

    def with_target_dim(self, target: int) -> "Embedder": ...


class BaseEmbedder:
    """Concrete base class for all in-tree embedders.

    Subclasses must set `name` and `dim` and override `embed`. The
    async/batch/with_target_dim methods have working defaults — only
    override when the provider has a faster native path (e.g. Azure
    requesting a smaller `dimensions` param, or a real batch endpoint).
    """

    name: str = ""
    dim: int = 0

    def embed(self, text: str) -> list[float]:
        raise NotImplementedError

    async def aembed(self, text: str) -> list[float]:
        return await asyncio.to_thread(self.embed, text)

    async def aembed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        return await asyncio.gather(*(self.aembed(t) for t in texts))

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]

    def with_target_dim(self, target: int) -> "Embedder":
        if target == self.dim and self.dim:
            return self
        return _AdaptedEmbedder(self, target)

    def __call__(self, text: str) -> list[float]:
        return self.embed(text)


class _AdaptedEmbedder(BaseEmbedder):
    """Truncate + L2 renorm wrapper used by `BaseEmbedder.with_target_dim`.

    Matryoshka-trained models (text-embedding-3-*, e5-mistral, ...)
    keep useful semantics under prefix slicing; renorm restores unit
    length so cosine similarity stays comparable across dims.
    """

    def __init__(self, base: Embedder, target_dim: int) -> None:
        self._base = base
        self.dim = target_dim
        self.name = f"{base.name}@{target_dim}"

    def embed(self, text: str) -> list[float]:
        vec = self._base.embed(text)
        if len(vec) == self.dim:
            return vec
        sliced = vec[: self.dim]
        norm = math.sqrt(sum(x * x for x in sliced)) or 1.0
        return [x / norm for x in sliced]

    async def aembed(self, text: str) -> list[float]:
        vec = await self._base.aembed(text)
        if len(vec) == self.dim:
            return vec
        sliced = vec[: self.dim]
        norm = math.sqrt(sum(x * x for x in sliced)) or 1.0
        return [x / norm for x in sliced]


class CallableEmbedder(BaseEmbedder):
    """Lifts a legacy `Callable[[str], list[float]]` into an Embedder.

    Used at the factory boundary so internal code can rely on the
    Embedder interface even when the user passed a bare callable.
    `dim` is auto-probed via a single test call if not supplied.
    """

    def __init__(
        self,
        fn: Callable[[str], list[float]],
        *,
        name: str | None = None,
        dim: int | None = None,
    ) -> None:
        self._fn = fn
        self.name = name or getattr(fn, "__name__", "callable_embedder")
        if dim is not None:
            self.dim = dim
        else:
            try:
                self.dim = len(fn("dim-probe"))
            except Exception:
                self.dim = 0

    def embed(self, text: str) -> list[float]:
        return self._fn(text)

    def __repr__(self) -> str:
        return f"CallableEmbedder(name={self.name!r}, dim={self.dim})"


# Legacy alias kept for any internal code that imported the old name.
_CallableEmbedder = CallableEmbedder


class AzureEmbedder(BaseEmbedder):
    """Embedder backed by Azure OpenAI's embeddings endpoint.

    Reads AZURE_OPENAI_* env vars; layered cache (memory + disk +
    optional Redis/Postgres) is shared with the legacy factory.
    Raises RuntimeError if the env is not configured.

    `with_target_dim` rebuilds via the Azure `dimensions=` parameter
    rather than truncating — for text-embedding-3-* this is the
    recommended path (the API returns properly-trained Matryoshka
    prefixes; truncation only approximates that).
    """

    def __init__(self, dimensions: int | None = None) -> None:
        from .factories import _make_azure_embed_fn

        fn = _make_azure_embed_fn(dimensions=dimensions)
        if fn is None:
            raise RuntimeError(
                "AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY must be set "
                "to construct AzureEmbedder."
            )
        import os as _os

        deploy = _os.getenv(
            "AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small"
        )
        env_dim = _os.getenv("AZURE_OPENAI_EMBEDDING_DIM") or _os.getenv(
            "RAG_EMBED_DIM"
        )
        resolved_dim = dimensions
        if resolved_dim is None and env_dim:
            try:
                resolved_dim = int(env_dim)
            except ValueError:
                resolved_dim = None

        self._fn = fn
        self._deploy = deploy
        self._configured_dim = resolved_dim
        self.name = f"{deploy}@{resolved_dim}" if resolved_dim else deploy
        self.dim = resolved_dim or 0

    def embed(self, text: str) -> list[float]:
        return self._fn(text)

    def with_target_dim(self, target: int) -> Embedder:
        if target == self.dim and self.dim:
            return self
        # Real rebuild — Azure returns a properly-trained prefix when
        # we pass `dimensions=`, which beats slice+renorm.
        try:
            return AzureEmbedder(dimensions=target)
        except RuntimeError:
            return _AdaptedEmbedder(self, target)


class LangChainEmbedder(BaseEmbedder):
    """Embedder wrapping any LangChain Embeddings object."""

    def __init__(
        self,
        embeddings: Any,
        *,
        name: str | None = None,
        dim: int | None = None,
        cache: str | None = None,
    ) -> None:
        from .factories import embed_fn_from_langchain

        self._fn = embed_fn_from_langchain(embeddings, cache=cache)
        self.name = name or type(embeddings).__name__
        if dim is not None:
            self.dim = dim
        else:
            try:
                self.dim = len(self._fn("dim-probe"))
            except Exception:
                self.dim = 0

    def embed(self, text: str) -> list[float]:
        return self._fn(text)


class EmbedAnythingEmbedder(BaseEmbedder):
    name: str
    dim: int

    def __init__(
        self,
        model_id: str = "sentence-transformers/all-MiniLM-L6-v2",
    ) -> None:
        try:
            import embed_anything as ea  # ty: ignore[unresolved-import]
        except ImportError as e:
            raise ImportError(
                "embed-anything is required for EmbedAnythingEmbedder. "
                "Install it with: pip install embed-anything"
            ) from e

        self._ea = ea
        self._model = ea.EmbeddingModel.from_pretrained_hf(model_id)
        self._model_id = model_id
        self.name = model_id
        try:
            self.dim = len(self.embed("dim-probe"))
        except Exception:
            self.dim = 0

    @classmethod
    def from_onnx(cls, which_model: object, **kwargs: object) -> EmbedAnythingEmbedder:
        try:
            import embed_anything as ea  # ty: ignore[unresolved-import]
        except ImportError as e:
            raise ImportError(
                "embed-anything is required for EmbedAnythingEmbedder. "
                "Install it with: pip install embed-anything"
            ) from e

        instance = cls.__new__(cls)
        instance._ea = ea
        instance._model = ea.EmbeddingModel.from_pretrained_onnx(which_model, **kwargs)
        instance._model_id = str(which_model)
        instance.name = str(which_model)
        try:
            instance.dim = len(instance.embed("dim-probe"))
        except Exception:
            instance.dim = 0
        return instance

    def embed(self, text: str) -> list[float]:
        data = self._ea.embed_query([text], embedder=self._model)
        return data[0].embedding

    def __repr__(self) -> str:
        return f"EmbedAnythingEmbedder({self._model_id!r})"


def coerce_embedder(
    value: "Embedder | Callable[[str], list[float]] | None",
) -> "Embedder | None":
    """Normalize a legacy callable or None into an Embedder | None.

    Used at every entry point that historically took `embed_fn`. The
    rest of the system can then assume `Embedder | None` without
    sprinkling `isinstance` checks. Embedder instances are returned
    unchanged; callables are wrapped in `CallableEmbedder`.
    """
    if value is None:
        return None
    if isinstance(value, Embedder):
        return value
    return CallableEmbedder(value)
