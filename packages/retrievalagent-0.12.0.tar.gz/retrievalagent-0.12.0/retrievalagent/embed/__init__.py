"""Embedder package public surface.

Re-exports the Embedder protocol, base class, and concrete adapters
so callers can `from retrievalagent.embed import Embedder, AzureEmbedder`
without reaching into submodules.
"""

from __future__ import annotations

from .embedder import (
    AzureEmbedder,
    BaseEmbedder,
    CallableEmbedder,
    Embedder,
    LangChainEmbedder,
    coerce_embedder,
)

try:
    from .embedder import EmbedAnythingEmbedder
except ImportError:  # pragma: no cover — embed_anything is optional
    EmbedAnythingEmbedder = None  # type: ignore[assignment, misc]  # ty: ignore[invalid-assignment]

__all__ = [
    "AzureEmbedder",
    "BaseEmbedder",
    "CallableEmbedder",
    "EmbedAnythingEmbedder",
    "Embedder",
    "LangChainEmbedder",
    "coerce_embedder",
]
