"""Per-process embedding cache (mem + disk + optional Redis/Postgres).

Layered: lookup hits the chosen backend (local disk, Redis, or
Postgres) keyed by SHA256(text). Local backend keeps a per-model
in-memory dict mirrored to ~/.cache/retrievalagent/embeddings/<model>.json
with a soft byte budget. Used by `_make_azure_embed_fn` to avoid
re-charging the embedding endpoint for repeated text.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import threading
from pathlib import Path
from typing import Any, Callable

_EMBED_CACHE_MAX_BYTES = 50 * 1024 * 1024
_EMBED_CACHE_LOCK = threading.Lock()
_EMBED_CACHE_MEM: dict[str, dict[str, list[float]]] = {}
_EMBED_CACHE_DIRTY: set[str] = set()
_EMBED_REDIS_CLIENT: Any = None
_EMBED_PG_POOL: Any = None
_EMBED_BACKEND_READY = False
_EMBED_BACKEND: str = "local"


def _embed_cache_enabled() -> bool:
    return os.environ.get("RAG_EMBED_CACHE", "1").lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def _embed_cache_backend() -> str:
    global _EMBED_BACKEND_READY, _EMBED_BACKEND, _EMBED_REDIS_CLIENT, _EMBED_PG_POOL
    if _EMBED_BACKEND_READY:
        return _EMBED_BACKEND
    _EMBED_BACKEND_READY = True
    url = os.environ.get("RAG_EMBED_CACHE_URL", "").strip()
    if url.startswith("redis://") or url.startswith("rediss://"):
        try:
            import redis  # type: ignore[import-not-found]  # ty: ignore[unresolved-import]

            _EMBED_REDIS_CLIENT = redis.Redis.from_url(url, decode_responses=False)
            _EMBED_REDIS_CLIENT.ping()
            _EMBED_BACKEND = "redis"
        except Exception:
            _EMBED_BACKEND = "local"
    elif url.startswith("postgres://") or url.startswith("postgresql://"):
        try:
            import logging as _logging

            _logging.getLogger("psycopg.pool").setLevel(_logging.CRITICAL)
            from psycopg_pool import ConnectionPool  # type: ignore[import-not-found]

            _EMBED_PG_POOL = ConnectionPool(
                url, min_size=1, max_size=4, open=False, timeout=2.0
            )
            _EMBED_PG_POOL.open(wait=True, timeout=2.0)
            with _EMBED_PG_POOL.connection() as conn, conn.cursor() as cur:
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS retrievalagent_embed_cache ("
                    "  model TEXT NOT NULL,"
                    "  key TEXT NOT NULL,"
                    "  vec JSONB NOT NULL,"
                    "  created_at TIMESTAMPTZ DEFAULT NOW(),"
                    "  PRIMARY KEY (model, key)"
                    ")"
                )
                conn.commit()
            _EMBED_BACKEND = "pg"
        except Exception:
            _EMBED_BACKEND = "local"
    else:
        _EMBED_BACKEND = "local"
    return _EMBED_BACKEND


def _embed_cache_dir() -> Path:
    return Path.home() / ".cache" / "retrievalagent" / "embeddings"


def _embed_cache_path(model: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", model) or "model"
    return _embed_cache_dir() / f"{safe}.json"


def _embed_text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _embed_cache_load(model: str) -> dict[str, list[float]]:
    if model in _EMBED_CACHE_MEM:
        return _EMBED_CACHE_MEM[model]
    path = _embed_cache_path(model)
    data: dict[str, list[float]] = {}
    if path.exists():
        try:
            raw = json.loads(path.read_text())
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if isinstance(v, list):
                        data[k] = [float(x) for x in v]
        except Exception:
            data = {}
    _EMBED_CACHE_MEM[model] = data
    return data


def _embed_cache_flush(model: str) -> None:
    if model not in _EMBED_CACHE_DIRTY:
        return
    data = _EMBED_CACHE_MEM.get(model)
    if data is None:
        return
    path = _embed_cache_path(model)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data))
        tmp.replace(path)
        _EMBED_CACHE_DIRTY.discard(model)
    except Exception:
        pass


def _embed_cache_trim(data: dict[str, list[float]]) -> None:
    if not data:
        return
    any_vec = next(iter(data.values()))
    per_entry = 70 + 18 * len(any_vec)
    max_entries = max(1, _EMBED_CACHE_MAX_BYTES // per_entry)
    while len(data) > max_entries:
        oldest = next(iter(data))
        del data[oldest]


def _embed_cache_get(model: str, text: str) -> list[float] | None:
    if not _embed_cache_enabled():
        return None
    key = _embed_text_hash(text)
    backend = _embed_cache_backend()
    if backend == "redis":
        try:
            raw = _EMBED_REDIS_CLIENT.get(f"retrievalagent:embed:{model}:{key}")
            return [float(x) for x in json.loads(raw)] if raw else None
        except Exception:
            return None
    if backend == "pg":
        try:
            with _EMBED_PG_POOL.connection() as conn, conn.cursor() as cur:
                cur.execute(
                    "SELECT vec FROM retrievalagent_embed_cache WHERE model=%s AND key=%s",
                    (model, key),
                )
                row = cur.fetchone()
                return [float(x) for x in row[0]] if row else None
        except Exception:
            return None
    with _EMBED_CACHE_LOCK:
        data = _embed_cache_load(model)
        vec = data.get(key)
        return list(vec) if vec is not None else None


def _embed_cache_put(model: str, text: str, vec: list[float]) -> None:
    if not _embed_cache_enabled():
        return
    key = _embed_text_hash(text)
    backend = _embed_cache_backend()
    if backend == "redis":
        try:
            _EMBED_REDIS_CLIENT.set(
                f"retrievalagent:embed:{model}:{key}", json.dumps(vec)
            )
        except Exception:
            pass
        return
    if backend == "pg":
        try:
            with _EMBED_PG_POOL.connection() as conn, conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO retrievalagent_embed_cache (model, key, vec) "
                    "VALUES (%s, %s, %s::jsonb) "
                    "ON CONFLICT (model, key) DO NOTHING",
                    (model, key, json.dumps(vec)),
                )
                conn.commit()
        except Exception:
            pass
        return
    with _EMBED_CACHE_LOCK:
        data = _embed_cache_load(model)
        if key in data:
            return
        data[key] = list(vec)
        _embed_cache_trim(data)
        _EMBED_CACHE_DIRTY.add(model)
        _embed_cache_flush(model)


def _adapt_embed_fn_to_dim(
    embed_fn: Callable[[str], list[float]],
    target_dim: int,
) -> Callable[[str], list[float]]:
    import math

    def _wrapped(text: str) -> list[float]:
        vec = embed_fn(text)
        if len(vec) == target_dim:
            return vec
        sliced = vec[:target_dim]
        norm = math.sqrt(sum(x * x for x in sliced)) or 1.0
        return [x / norm for x in sliced]

    return _wrapped


async def _embed_all_async(
    embed_fn: Callable[[str], list[float]],
    texts: list[str],
) -> list[list[float] | None]:
    loop = asyncio.get_running_loop()

    async def _one(text: str) -> list[float] | None:
        try:
            return await loop.run_in_executor(None, embed_fn, text)
        except Exception:
            return None

    return await asyncio.gather(*[_one(t) for t in texts])
