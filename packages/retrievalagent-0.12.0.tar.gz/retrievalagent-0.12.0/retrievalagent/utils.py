"""Misc utilities.

Most of what used to live here has been split into cohesive modules:
  - fusion.py        — RRF / DBSF score fusion
  - sync_bridge.py   — async↔sync bridging
  - byte_stores.py   — Redis/Postgres byte stores for LangChain caching
  - embed_cache.py   — embedding cache (mem + disk + Redis/Postgres)
  - embedders.py     — Azure / LangChain embed-fn factories

The names below remain importable from `retrievalagent.utils` to keep
external scripts working; new code should import from the canonical
module.
"""

from __future__ import annotations

import os

from stop_words import get_stop_words as _get_stop_words

from ._internal.byte_stores import _make_embed_byte_store, _PgByteStore, _RedisByteStore
from .embed.cache import (
    _adapt_embed_fn_to_dim,
    _embed_all_async,
    _embed_cache_backend,
    _embed_cache_dir,
    _embed_cache_enabled,
    _embed_cache_flush,
    _embed_cache_get,
    _embed_cache_load,
    _embed_cache_path,
    _embed_cache_put,
    _embed_cache_trim,
    _embed_text_hash,
)
from .embed.factories import _make_azure_embed_fn, embed_fn_from_langchain
from ._internal.fusion import _dbsf_fuse, _mmr_diverse, _rrf_fuse
from ._internal.sync_bridge import _run_sync

_DEFAULT_STOP_LANG = os.getenv("RAG_STOP_WORDS_LANG", "de")
_STOP_WORDS: frozenset[str] = frozenset(
    w.lower() for w in _get_stop_words(_DEFAULT_STOP_LANG)
)

_SKIP_FIELDS: frozenset[str] = frozenset(
    {
        "id",
        "url",
        "web_image_url",
        "update_date",
        "corpus_id",
        "language",
        "_id",
        "score",
        "_rankingScore",
        # Internal commercial / inventory / PII — never feed to LLM or surface
        "min_standard_cost",
        "max_standard_cost",
        "standard_cost",
        "stock_data",
        "total_stock_value",
        "total_stock_quantity",
        "total_qty_stock_unit_ltm",
        "sales_l12m",
        "total_sales_amount_ltm",
        "transactions_l12m",
        "supplier_id",
        "product_manager",
        "article_permitted_in_cluster_ids",
    }
)


def _strip_stop_words(text: str) -> str:
    return " ".join(w for w in text.split() if w.lower() not in _STOP_WORDS)


def _doc_id(meta: dict) -> str:
    mget = meta.get
    return str(mget("id") or mget("article_id") or mget("corpus_id", ""))


__all__ = [
    "_SKIP_FIELDS",
    "_STOP_WORDS",
    "_PgByteStore",
    "_RedisByteStore",
    "_adapt_embed_fn_to_dim",
    "_dbsf_fuse",
    "_doc_id",
    "_embed_all_async",
    "_embed_cache_backend",
    "_embed_cache_dir",
    "_embed_cache_enabled",
    "_embed_cache_flush",
    "_embed_cache_get",
    "_embed_cache_load",
    "_embed_cache_path",
    "_embed_cache_put",
    "_embed_cache_trim",
    "_embed_text_hash",
    "_make_azure_embed_fn",
    "_make_embed_byte_store",
    "_rrf_fuse",
    "_run_sync",
    "_strip_stop_words",
    "embed_fn_from_langchain",
]
