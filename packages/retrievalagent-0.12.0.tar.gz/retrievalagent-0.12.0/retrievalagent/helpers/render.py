from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_core.documents import Document

_HTML_TAG_RE = re.compile(r"<[^>]+>")

_MAX_LIST_ITEMS = 20
"""Cap bulky list values (stock_data per-warehouse, etc.) at this many
items when rendering for the grader. The LLM grader is now the final
ranker, so giving it the full spec sheet (akeneo_values, ETIM, EClass,
descriptions) materially improves judgment — Multi-Tool with 13+ akeneo
attributes was being truncated to 8, hiding category tags. Per-warehouse
stock arrays still get capped here, accept the small token overhead in
exchange for fewer wrong rankings."""


def _clean_string(s: str) -> str:
    if "<" in s:
        s = _HTML_TAG_RE.sub(" ", s)
    return " ".join(s.split())


_GRADER_CHARS = 600
"""Cap on doc text sent to the LLM grader. The page_content is already
ordered most-important fields first (the schema-discovery layer ranks
fields by importance and `_hit_to_text` emits in that order), so a
fixed character budget reliably keeps the discriminating fields in
view while cutting full spec sheets that don't help relevance
judgments."""


def _doc_to_grader_text(doc: Document) -> str:
    """Compact, generic summary for the LLM grader.

    The grader is the ranker — it just needs enough to decide
    relevance, not the full spec sheet. Cutting from full markdown
    (~800 tokens/doc) to ~150 tokens shrinks the dominant cost in the
    retrieval flow. Generic across schemas: relies on page_content
    being pre-sorted by field priority, no hardcoded field names.
    """
    return _clean_string(doc.page_content)[:_GRADER_CHARS]


def _render_value(v: Any, indent: int = 0) -> str:
    if isinstance(v, str):
        return _clean_string(v)
    if isinstance(v, bool) or isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, dict):
        lines: list[str] = []
        for k, val in v.items():
            rendered = _render_value(val, indent + 1)
            if not rendered:
                continue
            if "\n" in rendered:
                lines.append(f"- **{k}**:\n{rendered}")
            else:
                lines.append(f"- **{k}**: {rendered}")
        return "\n".join(lines)
    if isinstance(v, (list, tuple)):
        lines = []
        items = list(v)
        truncated = len(items) > _MAX_LIST_ITEMS
        for item in items[:_MAX_LIST_ITEMS]:
            if (
                isinstance(item, (list, tuple))
                and len(item) == 2
                and isinstance(item[0], str)
            ):
                rendered = _render_value(item[1], indent + 1)
                if not rendered:
                    continue
                if "\n" in rendered:
                    lines.append(f"- **{item[0]}**:\n{rendered}")
                else:
                    lines.append(f"- **{item[0]}**: {rendered}")
            else:
                rendered = _render_value(item, indent + 1)
                if rendered:
                    lines.append(f"- {rendered}")
        if truncated:
            lines.append(f"- (…{len(items) - _MAX_LIST_ITEMS} more)")
        return "\n".join(lines)
    return _clean_string(str(v))
