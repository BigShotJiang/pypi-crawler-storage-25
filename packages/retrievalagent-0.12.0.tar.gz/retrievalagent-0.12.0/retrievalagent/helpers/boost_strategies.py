"""Popularity-boost strategies — each one a different math choice.

Every strategy returns a `Callable[[dict], float]` that maps a doc's
metadata to a score multiplier (1.0 = no boost). Strategies are
swappable via `RAGConfig.boost_strategy`. Built so the same code path
can A/B test them on the same eval.

Each strategy operates on:
  - bool_fields: list of sortable bool fields, primary first
    (typically `is_own_brand`, `is_featured`, …)
  - num_fields: list of sortable numeric fields, primary first
    (typically `sales_l12m`, `total_sales_amount_ltm`, …)
  - samples: a corpus sample for distribution-based strategies

The first sortable field carries the most weight (the schema
designer's declared importance ordering).
"""

from __future__ import annotations

import bisect
import math
from typing import Any, Callable

BoostFn = Callable[[dict], float]


def make_none() -> BoostFn:
    """No boost. Sort/relevance only. Backend-side tie-break does
    the work via `sort_fields`."""

    def _fn(_meta: dict) -> float:
        return 1.0

    return _fn


def make_log_scale(
    bool_fields: list[str],
    num_fields: list[str],
    *,
    cap: float = 0.15,
) -> BoostFn:
    """Original strategy. Log-scaled numerics, position-weighted
    booleans, with `cap` as the total ceiling. Tuning knobs:
    `cap`, the per-field weight ladder. Adapts poorly across corpora
    with very different numeric scales (sales in cents vs millions
    look identical after log).
    """
    n_bool = max(len(bool_fields), 1)
    n_num = max(len(num_fields), 1)

    def _fn(meta: dict) -> float:
        bonus = 0.0
        for i, f in enumerate(bool_fields):
            if meta.get(f):
                bonus += (n_bool - i) / n_bool * 0.07
        for i, f in enumerate(num_fields):
            try:
                v = float(meta.get(f, 0) or 0)
            except (TypeError, ValueError):
                continue
            if v <= 0:
                continue
            weight = (n_num - i) / n_num
            bonus += weight * min(0.05, math.log1p(v) / 400.0)
        return 1.0 + min(bonus, cap)

    return _fn


def _value_quantiles(
    samples: list[dict], field: str
) -> list[float]:
    """Sorted values for percentile lookup. Drops missing/zero."""
    vals: list[float] = []
    for s in samples:
        v = s.get(field)
        if v is None:
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if f > 0:
            vals.append(f)
    vals.sort()
    return vals


def make_percentile(
    bool_fields: list[str],
    num_fields: list[str],
    samples: list[dict],
    *,
    cap: float = 0.15,
) -> BoostFn:
    """Boost a doc by its percentile rank in the corpus distribution.

    For each numeric field, doc's value position within the sample
    becomes a 0–1 weight. Top sales decile → 0.9 weight; median → 0.5;
    bottom decile → 0.1. Adapts to corpus automatically — no log-scale
    magic. Bool fields contribute fixed primary weight.

    Tuning knob: `cap` (one number — total max boost).
    """
    n_bool = max(len(bool_fields), 1)
    n_num = max(len(num_fields), 1)
    quantiles: dict[str, list[float]] = {
        f: _value_quantiles(samples, f) for f in num_fields
    }

    def _percentile(field: str, v: float) -> float:
        q = quantiles.get(field) or []
        if not q:
            return 0.0
        idx = bisect.bisect_right(q, v)
        return idx / len(q)

    def _fn(meta: dict) -> float:
        bonus = 0.0
        for i, f in enumerate(bool_fields):
            if meta.get(f):
                bonus += (n_bool - i) / n_bool * 0.07
        for i, f in enumerate(num_fields):
            try:
                v = float(meta.get(f, 0) or 0)
            except (TypeError, ValueError):
                continue
            if v <= 0:
                continue
            weight = (n_num - i) / n_num
            bonus += weight * 0.05 * _percentile(f, v)
        return 1.0 + min(bonus, cap)

    return _fn


def _mean_std(samples: list[dict], field: str) -> tuple[float, float]:
    vals: list[float] = []
    for s in samples:
        v = s.get(field)
        if v is None:
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if f > 0:
            vals.append(f)
    if not vals:
        return 0.0, 1.0
    mean = sum(vals) / len(vals)
    var = sum((x - mean) ** 2 for x in vals) / len(vals)
    std = math.sqrt(var) if var > 0 else 1.0
    return mean, std


def make_zscore(
    bool_fields: list[str],
    num_fields: list[str],
    samples: list[dict],
    *,
    cap: float = 0.15,
) -> BoostFn:
    """z-score → sigmoid boost. Each numeric value is normalized to
    a z-score against the corpus mean+std, then mapped through
    sigmoid into [0, 1]. Z=2 (two std above mean) → ~0.88 weight;
    z=0 (at mean) → 0.5; z=-2 → 0.12.

    Standard learned-to-rank shape. Sensitive to outliers (big
    sales pulls mean up); use percentile_rank if your distribution
    is heavy-tailed.

    Tuning knob: `cap`.
    """
    n_bool = max(len(bool_fields), 1)
    n_num = max(len(num_fields), 1)
    stats: dict[str, tuple[float, float]] = {
        f: _mean_std(samples, f) for f in num_fields
    }

    def _sigmoid(z: float) -> float:
        return 1.0 / (1.0 + math.exp(-z))

    def _fn(meta: dict) -> float:
        bonus = 0.0
        for i, f in enumerate(bool_fields):
            if meta.get(f):
                bonus += (n_bool - i) / n_bool * 0.07
        for i, f in enumerate(num_fields):
            try:
                v = float(meta.get(f, 0) or 0)
            except (TypeError, ValueError):
                continue
            if v <= 0:
                continue
            mean, std = stats[f]
            z = (v - mean) / std
            weight = (n_num - i) / n_num
            bonus += weight * 0.05 * _sigmoid(z)
        return 1.0 + min(bonus, cap)

    return _fn


def make_bayesian(
    bool_fields: list[str],
    num_fields: list[str],
    samples: list[dict],
    *,
    cap: float = 0.15,
    m: int = 10,
) -> BoostFn:
    """Bayesian smoothing — IMDb-top-250 style. The per-doc value `v`
    is smoothed toward the corpus prior (mean) with credibility
    weight `m`:

        smoothed = (n·v + m·prior) / (n + m)

    where `n` is taken as 1 (per-doc observation). Effect: docs with
    a small numeric value pull toward the prior, so a freak outlier
    can't dominate. Strong items still rank, but the boost is
    "earned" against the corpus baseline.

    Tuning knobs: `cap` and `m`. `m=10` means a doc's signal needs
    ~10 datapoints worth of confidence to fully claim its raw value.
    """
    n_bool = max(len(bool_fields), 1)
    n_num = max(len(num_fields), 1)
    priors: dict[str, float] = {}
    maxes: dict[str, float] = {}
    for f in num_fields:
        mean, _ = _mean_std(samples, f)
        priors[f] = mean
        # Scale max for normalization to [0, 1]
        vals = _value_quantiles(samples, f)
        maxes[f] = vals[-1] if vals else mean if mean > 0 else 1.0

    def _fn(meta: dict) -> float:
        bonus = 0.0
        for i, f in enumerate(bool_fields):
            if meta.get(f):
                bonus += (n_bool - i) / n_bool * 0.07
        for i, f in enumerate(num_fields):
            try:
                v = float(meta.get(f, 0) or 0)
            except (TypeError, ValueError):
                continue
            if v <= 0:
                continue
            prior = priors[f]
            mx = maxes[f] or 1.0
            smoothed = (1 * v + m * prior) / (1 + m)
            # Normalize smoothed to [0, 1] using corpus max.
            normalized = min(smoothed / mx, 1.0)
            weight = (n_num - i) / n_num
            bonus += weight * 0.05 * normalized
        return 1.0 + min(bonus, cap)

    return _fn


def make_tie_break(bool_fields: list[str]) -> BoostFn:
    """Pure tie-breaker. Returns a tiny additive bump ONLY for the
    primary sortable bool — assumes the backend already handles
    numeric ordering via `sort_fields`. No magic numbers; the
    'boost' here is just exposing the schema's declared preference
    flag to client-side code that can't otherwise see it.
    """
    if not bool_fields:
        return make_none()
    primary = bool_fields[0]

    def _fn(meta: dict) -> float:
        return 1.01 if meta.get(primary) else 1.0

    return _fn


def build(
    name: str,
    bool_fields: list[str],
    num_fields: list[str],
    samples: list[dict[str, Any]],
) -> BoostFn:
    """Strategy factory. Unknown names fall back to log_scale (today's
    default) so callers don't fail on typos."""
    if name == "none":
        return make_none()
    if name == "tie_break":
        return make_tie_break(bool_fields)
    if name == "percentile":
        return make_percentile(bool_fields, num_fields, samples)
    if name == "zscore":
        return make_zscore(bool_fields, num_fields, samples)
    if name == "bayesian":
        return make_bayesian(bool_fields, num_fields, samples)
    return make_log_scale(bool_fields, num_fields)
