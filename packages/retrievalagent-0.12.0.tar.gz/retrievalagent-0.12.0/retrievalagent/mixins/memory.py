"""Conversation-memory mixin for AgenticRAG.

Thin facade over a list of :class:`~retrievalagent._internal.memory.Memory`
adapters.  Each adapter owns its own backend specifics (LangGraph
``BaseStore``, mem0, …); the mixin just fans writes out and aggregates
recalls into ``state.memory_context``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from .._internal.memory import Memory, MemoryItem

if TYPE_CHECKING:
    from langchain_core.runnables.config import RunnableConfig

    from ..models import RAGState


_log = logging.getLogger(__name__)


def _user_id(config: RunnableConfig | None) -> str:
    return ((config or {}).get("configurable") or {}).get("user_id", "default")


class MemoryMixin:
    """Conversation-memory side of AgenticRAG.

    Holds ``self._memories: list[Memory]`` — adapters wrapping whatever
    long-term backends the agent was configured with.  ``read_memory``
    fans out a recall to every adapter and merges the results;
    ``write_memory`` fans out a single ``add`` to every adapter.

    Adapters are responsible for their own filtering (e.g. relevance
    threshold).  The facade does not re-filter — it just decides how
    many recalls to surface and assembles ``state.memory_context``.
    """

    _memories: list[Memory]
    memory_relevance_threshold: float

    if TYPE_CHECKING:

        def _spawn_background(self, coro: Any) -> Any: ...

    # ---- public-ish helpers ------------------------------------------------

    async def amemory_recall_all(
        self, query: str, *, user_id: str = "default", k: int = 5
    ) -> list[MemoryItem]:
        """Round-robin merge of all adapter recalls (deduped on text)."""
        if not self._memories:
            return []
        per_adapter: list[list[MemoryItem]] = []
        for m in self._memories:
            try:
                per_adapter.append(await m.recall(query, user_id=user_id, k=k))
            except Exception as e:
                _log.warning("memory recall failed: %s", e)
                per_adapter.append([])
        merged: list[MemoryItem] = []
        seen: set[str] = set()
        # Round-robin so each adapter gets a fair shot at the top of the list.
        for col in zip(*per_adapter, strict=False):
            for item in col:
                if item.text in seen:
                    continue
                seen.add(item.text)
                merged.append(item)
                if len(merged) >= k:
                    return merged
        # Tail: any remaining items past the shortest adapter.
        for col in per_adapter:
            for item in col:
                if item.text in seen:
                    continue
                seen.add(item.text)
                merged.append(item)
                if len(merged) >= k:
                    return merged
        return merged

    async def amemory_add_all(self, item: MemoryItem) -> None:
        """Fan an ``add`` out to every adapter."""
        for m in self._memories:
            try:
                await m.add(item)
            except Exception as e:
                _log.warning("memory add failed: %s", e)

    # ---- LangGraph node entry points --------------------------------------

    async def _aread_memory(
        self,
        state: RAGState,
        *,
        store: Any = None,
        config: RunnableConfig | None = None,
    ) -> dict:
        if not self._memories:
            return {}
        user_id = _user_id(config)
        items = await self.amemory_recall_all(state.question, user_id=user_id, k=5)
        if not items:
            return {}
        mem_text = "\n".join(f"- {it.text}" for it in items)
        trace_entry: dict[str, Any] = {
            "node": "read_memory",
            "memories": mem_text,
            "n_kept": len(items),
        }
        # If any adapter scored its recalls, surface the threshold for diagnostics.
        scored = [it for it in items if it.score is not None]
        if scored:
            trace_entry["threshold"] = self.memory_relevance_threshold
        return {
            "trace": state.trace + [trace_entry],
            "memory_context": mem_text,
        }

    async def _awrite_memory(
        self,
        state: RAGState,
        *,
        store: Any = None,
        config: RunnableConfig | None = None,
    ) -> dict:
        if not state.memory_should_store or not state.memory_fact:
            return {}
        if not self._memories:
            return {}
        user_id = _user_id(config)
        item = MemoryItem(text=state.memory_fact, user_id=user_id)
        self._spawn_background(self.amemory_add_all(item))
        return {}
