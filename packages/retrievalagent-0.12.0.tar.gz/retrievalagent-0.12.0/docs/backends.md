# Backends

retrievalagent supports 10 backends. Swap with a single string alias in `init_agent`, or pass a backend instance directly to `Agent`.

## Backend aliases

| Alias | Class | Install |
|-------|-------|---------|
| `"memory"` / `"in_memory"` | `InMemoryBackend` | _(built-in)_ |
| `"meilisearch"` | `MeilisearchBackend` | `retrievalagent[meilisearch]` |
| `"azure"` | `AzureAISearchBackend` | `retrievalagent[azure]` |
| `"chroma"` / `"chromadb"` | `ChromaDBBackend` | `retrievalagent[chromadb]` |
| `"lancedb"` / `"lance"` | `LanceDBBackend` | `retrievalagent[lancedb]` |
| `"qdrant"` | `QdrantBackend` | `retrievalagent[qdrant]` |
| `"pgvector"` / `"pg"` | `PgvectorBackend` | `retrievalagent[pgvector]` |
| `"postgres_fts"` / `"pg_fts"` | `PostgresFTSBackend` | `psycopg` |
| `"sqlite"` / `"sqlite_fts"` | `SQLiteFTSBackend` | _(built-in)_ |
| `"duckdb"` | `DuckDBBackend` | `retrievalagent[duckdb]` |

---

## InMemory

Zero dependencies. Good for testing, prototyping, and small datasets.

```python
from retrievalagent import Agent, InMemoryBackend

backend = InMemoryBackend(embed_fn=my_embed_fn)
backend.add_documents([{"content": "...", "id": "1"}])
rag = Agent(index="docs", backend=backend)
```

Or via `init_agent`:

```python
rag = init_agent("docs", backend="memory", embed_fn=my_embed_fn)
```

---

## Meilisearch

Full-text BM25 search with vector hybrid mode. Requires `pip install retrievalagent[meilisearch]`.

```python
from retrievalagent import init_agent

rag = init_agent(
    "my-index",
    backend="meilisearch",
    backend_url="http://localhost:7700",   # default
    backend_kwargs={"api_key": "masterKey"},
    embed_fn=my_embed_fn,
    model="openai:gpt-5.4",
)
```

Or directly:

```python
from retrievalagent.backend import MeilisearchBackend

backend = MeilisearchBackend(
    index="my-index",
    url="http://localhost:7700",
    api_key="masterKey",
    embed_fn=my_embed_fn,
)
```

---

## Azure AI Search

Supports native server-side vectorisation — no client-side `embed_fn` needed when an integrated vectorizer is configured.

```python
from retrievalagent import init_agent

rag = init_agent(
    "my-index",
    backend="azure",
    backend_url="https://my-search.search.windows.net",
    backend_kwargs={"api_key": "your-admin-key"},
    model="openai:gpt-5.4",
)
```

Credentials can also come from environment variables (`AZURE_SEARCH_ENDPOINT`, `AZURE_SEARCH_API_KEY`) or managed identity via `azure-identity`.

---

## ChromaDB

Local or remote. In-memory by default for testing.

```python
from retrievalagent import init_agent

rag = init_agent(
    "my-collection",
    backend="chroma",
    embed_fn=my_embed_fn,
    model="openai:gpt-5.4",
)
```

Persistent storage:

```python
from retrievalagent.backend import ChromaDBBackend

backend = ChromaDBBackend(
    collection="my-collection",
    embed_fn=my_embed_fn,
    client_settings={"chroma_db_impl": "duckdb+parquet", "persist_directory": "./chroma"},
)
```

---

## LanceDB

Columnar vector store. Fast for large datasets, no server required.

```python
from retrievalagent.backend import LanceDBBackend

backend = LanceDBBackend(
    table="docs",
    db_uri="./lancedb",
    embed_fn=my_embed_fn,
    vector_column="vector",
)
```

---

## Qdrant

High-performance vector database. Supports both `:memory:` and server modes.

```python
from retrievalagent import init_agent

rag = init_agent(
    "my-collection",
    backend="qdrant",
    backend_url="http://localhost:6333",
    embed_fn=my_embed_fn,
    model="openai:gpt-5.4",
)
```

In-memory (testing):

```python
from retrievalagent.backend import QdrantBackend

backend = QdrantBackend("my-collection", location=":memory:", embed_fn=my_embed_fn)
```

---

## pgvector

PostgreSQL with the pgvector extension. Supports full SQL filtering via ILIKE.

```python
from retrievalagent.backend import PgvectorBackend

backend = PgvectorBackend(
    table="documents",
    connection_string="postgresql://user:pass@localhost/mydb",
    embed_fn=my_embed_fn,
)
```

Docker Compose for local dev:

```yaml
services:
  postgres:
    image: pgvector/pgvector:pg16
    environment:
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"
```

---

## DuckDB

Embedded analytical database. No server, fast for local workloads.

```python
from retrievalagent.backend import DuckDBBackend

backend = DuckDBBackend(
    table="docs",
    db_path="./mydb.duckdb",
    embed_fn=my_embed_fn,
)
```

---

## PostgreSQL FTS (without pgvector)

Pure PostgreSQL full-text + SQL filters, no vector extension required.

```python
from retrievalagent.backend import PostgresFTSBackend

backend = PostgresFTSBackend(
    table="documents",
    dsn="postgresql://user:pass@localhost/mydb",
    content_column="content",
)
```

---

## SQLite FTS

SQLite with FTS5 when available, falling back to `LIKE` search otherwise.

```python
from retrievalagent.backend import SQLiteFTSBackend

backend = SQLiteFTSBackend(
    table="docs",
    db_path="./docs.sqlite3",
    content_column="content",
)
```

---

## Custom backend

Implement `SearchBackend` from `retrievalagent.backend`:

```python
from retrievalagent.backend import SearchBackend, SearchRequest, IndexConfig

class MyBackend(SearchBackend):
    def search(self, req: SearchRequest) -> list[dict]:
        ...

    def get_index_config(self) -> IndexConfig:
        ...

    def sample_documents(self, limit: int = 5, ...) -> list[dict]:
        ...
```
