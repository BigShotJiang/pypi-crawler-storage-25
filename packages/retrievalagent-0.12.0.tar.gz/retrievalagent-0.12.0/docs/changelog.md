# Changelog

## 0.12.0

- **Retry strategies** — grader classifies failures as `widen` (broaden), `narrow` (add filter), or `pinpoint` (exact product-code lookup); rewrite loop follows the strategy
- **Follow-up detection** — single structured LLM call in `_acontextualize` classifies + rewrites; `is_followup=true` injects previous turn's documents, skipping re-retrieval
- **LLM no-result suggestions** — zero-result termination calls the LLM for a multilingual "nothing found" message + 2–3 alternative queries
- **Score gate fix** — canonical query arm is always included in RRF fusion; 0.3 gate previously dropped natural-language queries where stopwords dilute BM25 scores
- **CLI modes** — `--retrieve` (top-k docs, no LLM), `--query` (single Q → stdout), `--plain` (readline REPL)
- **Typed `backend` parameter** — `Literal[...]` union for IDE autocomplete and type checking
- **Removed Optuna tuner** — `tuner.py`, `tuner_v2.py`, `dataset_builder.py` deleted; use `RAGConfig` + `custom_instructions` instead
- **Generic codebase** — removed all customer-specific hardcoding; `custom_instructions` / `instructions=` are the documented extension points
- Default `query_languages` changed from `["de", "fr", "it", "en"]` → `["en"]`

## 0.7.0

- **Lean parallel pipeline** — `prepare → [keyword_search ∥ synonym_search] → evaluate → quality_gate → [semantic_backup →] merge_rerank → generate`; replaces the old sequential multi-query swarm with a two-branch fan-out that is always on
- **Synonym node** — single LLM call in `_asynonym_search_node` produces spell-correction, synonym/alias expansion, and negation extraction; original `state.query` is never overwritten
- **Spell-correction as parallel BM25 term** — corrected form searched alongside original (`"troceknbeton"` → BM25 on `"troceknbeton"` + `"trockenbeton"`), not as a query overwrite
- **Negative filter extraction** — `"cola aber nicht zero"` → `RAGState.excluded_terms = ["zero"]`; post-filtered in `_amerge_rerank_node`; works for any negated concept
- **MMR diversity pass** — `_mmr_diverse(lam=0.7)` runs before reranking in `_amerge_rerank_node` to remove near-duplicate docs; bag-of-words Jaccard, no embeddings needed (source: `retrievalagent/_internal/fusion.py`)
- **Retry reasoning** — rewrite node passes the top-3 doc snippets to the LLM so it can reason about why the previous results were wrong
- **Model routing clarification** — `llm` (cheap/utility: synonyms, rewrite, quality-gate, default `gpt-5.4-mini`), `gen_llm` (generation, default `gpt-5.5`), `grader_llm` (configurable separately via `config.grader_model`)

## 0.6.5

- `mem0_memory=` parameter for LLM-based fact extraction with deduplication and conflict resolution
- Supports both `Memory` (sync via thread-pool) and `AsyncMemory` (native async)
- Strips retrieved documents from checkpointed state to keep context lean

## 0.6.4

- `auto_strategy=True` is now the default — retrievalagent is agentic out of the box
- Added multi-collection routing (`collections=` parameter) with LLM-based selection
- Added `_MultiBackend` with `_ACTIVE_COLLECTIONS` context-variable scoping
- Extended filter coverage: NOT CONTAINS (ILIKE) for LanceDB, DuckDB, pgvector; Qdrant server MatchText; Chroma AND filters
- Added `% ` to `_SAFE_FILTER_RE` to allow ILIKE patterns
- Cleaned repo of all internal product references

## 0.6.3

- Backend-aware filter translator (Meili, SQL ILIKE, OData, Chroma dict, Qdrant native)
- `build_filter_expr` per-backend helper

## 0.6.1 — 0.6.2

- LanceDB filter coverage and test suite
- Embedding API call cache (disk-based)

## 0.6.0

- Multi-query swarm retrieval
- LangGraph state machine refactor
- Async-native pipeline with `_run_sync` for sync wrappers

## Earlier

See [GitHub releases](https://github.com/bmsuisse/retrievalagent/releases) for full history.
