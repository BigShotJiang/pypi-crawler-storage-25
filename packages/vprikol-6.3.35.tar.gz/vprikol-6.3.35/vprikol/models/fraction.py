import datetime
from typing import List, Optional, Literal
from pydantic import BaseModel

class MembersPlayer(BaseModel):
    account_id: Optional[int]
    nickname: str
    is_online: bool
    is_leader: bool
    rank_number: int
    rank_label: Optional[str]
    ingame_id: Optional[int]
    nickname_color: Optional[int]


class MembersRecord(BaseModel):
    online_players: int
    leader_nickname: Optional[str]
    modified_at: Optional[datetime.datetime]
    modified_by: Literal["system", "admin"]


class MembersResponse(BaseModel):
    server_id: int
    fraction_id: int
    server_label: str
    fraction_label: str
    total_players: int
    total_online: int
    leader_nickname: Optional[str]
    is_leader_online: bool
    online_updated_at: datetime.datetime
    members_updated_at: datetime.datetime
    online_record: MembersRecord
    players: List[MembersPlayer]


class FractionMemberHistoryEntry(BaseModel):
    id: int
    server_id: int
    server_label: str
    nickname: str
    action: Literal["invite", "fraction_change", "rank_change", "uninvite"]
    old_fraction_id: Optional[int]
    old_fraction_label: Optional[str]
    new_fraction_id: Optional[int]
    new_fraction_label: Optional[str]
    old_rank_label: Optional[str]
    new_rank_label: Optional[str]
    old_rank_number: Optional[int]
    new_rank_number: Optional[int]
    created_at: datetime.datetime


class FractionMemberHistoryResponse(BaseModel):
    server_id: int
    server_label: str
    total: int
    limit: int
    offset: int
    data: List[FractionMemberHistoryEntry]


class LeaderEntry(BaseModel):
    fraction_id: int
    fraction_label: str
    nickname: str
    ingame_id: int
    phone_number: Optional[int]
    afk: Optional[int]


class LeadersResponse(BaseModel):
    data: List[LeaderEntry]
    server_id: int
    server_label: str
    updated_at: datetime.datetime


class InterviewEntry(BaseModel):
    fraction_id: int
    fraction_label: str
    place: Optional[str]
    time: Optional[str]


class InterviewsResponse(BaseModel):
    server_id: int
    server_label: str
    data: List[InterviewEntry]
    updated_at: datetime.datetime
