from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_chat_task_body_metadata import CreateChatTaskBodyMetadata


T = TypeVar("T", bound="CreateChatTaskBody")


@_attrs_define
class CreateChatTaskBody:
    """
    Attributes:
        subject (str):
        description (str):
        status (str | Unset):  Default: 'pending'.
        active_form (None | str | Unset):
        owner (None | str | Unset):
        blocks (list[str] | Unset):
        blocked_by (list[str] | Unset):
        metadata (CreateChatTaskBodyMetadata | Unset):
    """

    subject: str
    description: str
    status: str | Unset = "pending"
    active_form: None | str | Unset = UNSET
    owner: None | str | Unset = UNSET
    blocks: list[str] | Unset = UNSET
    blocked_by: list[str] | Unset = UNSET
    metadata: CreateChatTaskBodyMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        subject = self.subject

        description = self.description

        status = self.status

        active_form: None | str | Unset
        if isinstance(self.active_form, Unset):
            active_form = UNSET
        else:
            active_form = self.active_form

        owner: None | str | Unset
        if isinstance(self.owner, Unset):
            owner = UNSET
        else:
            owner = self.owner

        blocks: list[str] | Unset = UNSET
        if not isinstance(self.blocks, Unset):
            blocks = self.blocks

        blocked_by: list[str] | Unset = UNSET
        if not isinstance(self.blocked_by, Unset):
            blocked_by = self.blocked_by

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "subject": subject,
                "description": description,
            }
        )
        if status is not UNSET:
            field_dict["status"] = status
        if active_form is not UNSET:
            field_dict["active_form"] = active_form
        if owner is not UNSET:
            field_dict["owner"] = owner
        if blocks is not UNSET:
            field_dict["blocks"] = blocks
        if blocked_by is not UNSET:
            field_dict["blocked_by"] = blocked_by
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_chat_task_body_metadata import CreateChatTaskBodyMetadata

        d = dict(src_dict)
        subject = d.pop("subject")

        description = d.pop("description")

        status = d.pop("status", UNSET)

        def _parse_active_form(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        active_form = _parse_active_form(d.pop("active_form", UNSET))

        def _parse_owner(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        owner = _parse_owner(d.pop("owner", UNSET))

        blocks = cast(list[str], d.pop("blocks", UNSET))

        blocked_by = cast(list[str], d.pop("blocked_by", UNSET))

        _metadata = d.pop("metadata", UNSET)
        metadata: CreateChatTaskBodyMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = CreateChatTaskBodyMetadata.from_dict(_metadata)

        create_chat_task_body = cls(
            subject=subject,
            description=description,
            status=status,
            active_form=active_form,
            owner=owner,
            blocks=blocks,
            blocked_by=blocked_by,
            metadata=metadata,
        )

        return create_chat_task_body
