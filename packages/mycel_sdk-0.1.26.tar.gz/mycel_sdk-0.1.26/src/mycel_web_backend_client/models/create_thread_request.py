from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.mount_spec import MountSpec


T = TypeVar("T", bound="CreateThreadRequest")


@_attrs_define
class CreateThreadRequest:
    """
    Attributes:
        agent_user_id (str):
        sandbox (str | Unset):  Default: 'local'.
        sandbox_template_id (None | str | Unset):
        existing_sandbox_id (None | str | Unset):
        cwd (None | str | Unset):
        model (None | str | Unset):
        agent (None | str | Unset):
        bind_mounts (list[MountSpec] | Unset):
    """

    agent_user_id: str
    sandbox: str | Unset = "local"
    sandbox_template_id: None | str | Unset = UNSET
    existing_sandbox_id: None | str | Unset = UNSET
    cwd: None | str | Unset = UNSET
    model: None | str | Unset = UNSET
    agent: None | str | Unset = UNSET
    bind_mounts: list[MountSpec] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        agent_user_id = self.agent_user_id

        sandbox = self.sandbox

        sandbox_template_id: None | str | Unset
        if isinstance(self.sandbox_template_id, Unset):
            sandbox_template_id = UNSET
        else:
            sandbox_template_id = self.sandbox_template_id

        existing_sandbox_id: None | str | Unset
        if isinstance(self.existing_sandbox_id, Unset):
            existing_sandbox_id = UNSET
        else:
            existing_sandbox_id = self.existing_sandbox_id

        cwd: None | str | Unset
        if isinstance(self.cwd, Unset):
            cwd = UNSET
        else:
            cwd = self.cwd

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        else:
            model = self.model

        agent: None | str | Unset
        if isinstance(self.agent, Unset):
            agent = UNSET
        else:
            agent = self.agent

        bind_mounts: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.bind_mounts, Unset):
            bind_mounts = []
            for bind_mounts_item_data in self.bind_mounts:
                bind_mounts_item = bind_mounts_item_data.to_dict()
                bind_mounts.append(bind_mounts_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "agent_user_id": agent_user_id,
            }
        )
        if sandbox is not UNSET:
            field_dict["sandbox"] = sandbox
        if sandbox_template_id is not UNSET:
            field_dict["sandbox_template_id"] = sandbox_template_id
        if existing_sandbox_id is not UNSET:
            field_dict["existing_sandbox_id"] = existing_sandbox_id
        if cwd is not UNSET:
            field_dict["cwd"] = cwd
        if model is not UNSET:
            field_dict["model"] = model
        if agent is not UNSET:
            field_dict["agent"] = agent
        if bind_mounts is not UNSET:
            field_dict["bind_mounts"] = bind_mounts

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.mount_spec import MountSpec

        d = dict(src_dict)
        agent_user_id = d.pop("agent_user_id")

        sandbox = d.pop("sandbox", UNSET)

        def _parse_sandbox_template_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sandbox_template_id = _parse_sandbox_template_id(
            d.pop("sandbox_template_id", UNSET)
        )

        def _parse_existing_sandbox_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        existing_sandbox_id = _parse_existing_sandbox_id(
            d.pop("existing_sandbox_id", UNSET)
        )

        def _parse_cwd(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cwd = _parse_cwd(d.pop("cwd", UNSET))

        def _parse_model(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model = _parse_model(d.pop("model", UNSET))

        def _parse_agent(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent = _parse_agent(d.pop("agent", UNSET))

        _bind_mounts = d.pop("bind_mounts", UNSET)
        bind_mounts: list[MountSpec] | Unset = UNSET
        if _bind_mounts is not UNSET:
            bind_mounts = []
            for bind_mounts_item_data in _bind_mounts:
                bind_mounts_item = MountSpec.from_dict(bind_mounts_item_data)

                bind_mounts.append(bind_mounts_item)

        create_thread_request = cls(
            agent_user_id=agent_user_id,
            sandbox=sandbox,
            sandbox_template_id=sandbox_template_id,
            existing_sandbox_id=existing_sandbox_id,
            cwd=cwd,
            model=model,
            agent=agent,
            bind_mounts=bind_mounts,
        )

        return create_thread_request
