from enum import Enum


class SendMessageBodyDeliveryScope(str, Enum):
    ADDRESSED = "addressed"
    BROADCAST = "broadcast"

    def __str__(self) -> str:
        return str(self.value)
