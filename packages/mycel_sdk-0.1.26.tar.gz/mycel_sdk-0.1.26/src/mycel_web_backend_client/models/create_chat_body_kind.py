from enum import Enum


class CreateChatBodyKind(str, Enum):
    AUTO = "auto"
    DIRECT = "direct"
    GROUP = "group"

    def __str__(self) -> str:
        return str(self.value)
