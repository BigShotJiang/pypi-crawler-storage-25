from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.set_chat_workflow_body_config import SetChatWorkflowBodyConfig


T = TypeVar("T", bound="SetChatWorkflowBody")


@_attrs_define
class SetChatWorkflowBody:
    """
    Attributes:
        kind (str):
        state (str | Unset):  Default: 'active'.
        config (SetChatWorkflowBodyConfig | Unset):
    """

    kind: str
    state: str | Unset = "active"
    config: SetChatWorkflowBodyConfig | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind

        state = self.state

        config: dict[str, Any] | Unset = UNSET
        if not isinstance(self.config, Unset):
            config = self.config.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "kind": kind,
            }
        )
        if state is not UNSET:
            field_dict["state"] = state
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.set_chat_workflow_body_config import SetChatWorkflowBodyConfig

        d = dict(src_dict)
        kind = d.pop("kind")

        state = d.pop("state", UNSET)

        _config = d.pop("config", UNSET)
        config: SetChatWorkflowBodyConfig | Unset
        if isinstance(_config, Unset):
            config = UNSET
        else:
            config = SetChatWorkflowBodyConfig.from_dict(_config)

        set_chat_workflow_body = cls(
            kind=kind,
            state=state,
            config=config,
        )

        return set_chat_workflow_body
