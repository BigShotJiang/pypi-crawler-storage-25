from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_chat_task_body_metadata_type_0 import (
        UpdateChatTaskBodyMetadataType0,
    )


T = TypeVar("T", bound="UpdateChatTaskBody")


@_attrs_define
class UpdateChatTaskBody:
    """
    Attributes:
        status (None | str | Unset):
        subject (None | str | Unset):
        description (None | str | Unset):
        active_form (None | str | Unset):
        owner (None | str | Unset):
        blocks (list[str] | None | Unset):
        blocked_by (list[str] | None | Unset):
        metadata (None | Unset | UpdateChatTaskBodyMetadataType0):
    """

    status: None | str | Unset = UNSET
    subject: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    active_form: None | str | Unset = UNSET
    owner: None | str | Unset = UNSET
    blocks: list[str] | None | Unset = UNSET
    blocked_by: list[str] | None | Unset = UNSET
    metadata: None | Unset | UpdateChatTaskBodyMetadataType0 = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.update_chat_task_body_metadata_type_0 import (
            UpdateChatTaskBodyMetadataType0,
        )

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        subject: None | str | Unset
        if isinstance(self.subject, Unset):
            subject = UNSET
        else:
            subject = self.subject

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        active_form: None | str | Unset
        if isinstance(self.active_form, Unset):
            active_form = UNSET
        else:
            active_form = self.active_form

        owner: None | str | Unset
        if isinstance(self.owner, Unset):
            owner = UNSET
        else:
            owner = self.owner

        blocks: list[str] | None | Unset
        if isinstance(self.blocks, Unset):
            blocks = UNSET
        elif isinstance(self.blocks, list):
            blocks = self.blocks

        else:
            blocks = self.blocks

        blocked_by: list[str] | None | Unset
        if isinstance(self.blocked_by, Unset):
            blocked_by = UNSET
        elif isinstance(self.blocked_by, list):
            blocked_by = self.blocked_by

        else:
            blocked_by = self.blocked_by

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, UpdateChatTaskBodyMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if status is not UNSET:
            field_dict["status"] = status
        if subject is not UNSET:
            field_dict["subject"] = subject
        if description is not UNSET:
            field_dict["description"] = description
        if active_form is not UNSET:
            field_dict["active_form"] = active_form
        if owner is not UNSET:
            field_dict["owner"] = owner
        if blocks is not UNSET:
            field_dict["blocks"] = blocks
        if blocked_by is not UNSET:
            field_dict["blocked_by"] = blocked_by
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_chat_task_body_metadata_type_0 import (
            UpdateChatTaskBodyMetadataType0,
        )

        d = dict(src_dict)

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_subject(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subject = _parse_subject(d.pop("subject", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_active_form(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        active_form = _parse_active_form(d.pop("active_form", UNSET))

        def _parse_owner(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        owner = _parse_owner(d.pop("owner", UNSET))

        def _parse_blocks(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                blocks_type_0 = cast(list[str], data)

                return blocks_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        blocks = _parse_blocks(d.pop("blocks", UNSET))

        def _parse_blocked_by(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                blocked_by_type_0 = cast(list[str], data)

                return blocked_by_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        blocked_by = _parse_blocked_by(d.pop("blocked_by", UNSET))

        def _parse_metadata(
            data: object,
        ) -> None | Unset | UpdateChatTaskBodyMetadataType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = UpdateChatTaskBodyMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateChatTaskBodyMetadataType0, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        update_chat_task_body = cls(
            status=status,
            subject=subject,
            description=description,
            active_form=active_form,
            owner=owner,
            blocks=blocks,
            blocked_by=blocked_by,
            metadata=metadata,
        )

        return update_chat_task_body
