from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.mount_spec_mode import MountSpecMode
from ..types import UNSET, Unset

T = TypeVar("T", bound="MountSpec")


@_attrs_define
class MountSpec:
    """
    Attributes:
        source (str):
        target (str):
        mode (MountSpecMode | Unset):  Default: MountSpecMode.MOUNT.
        read_only (bool | Unset):  Default: False.
    """

    source: str
    target: str
    mode: MountSpecMode | Unset = MountSpecMode.MOUNT
    read_only: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source = self.source

        target = self.target

        mode: str | Unset = UNSET
        if not isinstance(self.mode, Unset):
            mode = self.mode.value

        read_only = self.read_only

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "source": source,
                "target": target,
            }
        )
        if mode is not UNSET:
            field_dict["mode"] = mode
        if read_only is not UNSET:
            field_dict["read_only"] = read_only

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        source = d.pop("source")

        target = d.pop("target")

        _mode = d.pop("mode", UNSET)
        mode: MountSpecMode | Unset
        if isinstance(_mode, Unset):
            mode = UNSET
        else:
            mode = MountSpecMode(_mode)

        read_only = d.pop("read_only", UNSET)

        mount_spec = cls(
            source=source,
            target=target,
            mode=mode,
            read_only=read_only,
        )

        mount_spec.additional_properties = d
        return mount_spec

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
