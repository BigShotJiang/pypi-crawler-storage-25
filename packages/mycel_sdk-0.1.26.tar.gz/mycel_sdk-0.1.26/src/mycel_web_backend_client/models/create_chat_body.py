from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_chat_body_kind import CreateChatBodyKind
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateChatBody")


@_attrs_define
class CreateChatBody:
    """
    Attributes:
        user_ids (list[str] | Unset): Other participant user ids. Do not include the authenticated user; the backend
            adds it from the bearer token.
        title (None | str | Unset):
        kind (CreateChatBodyKind | Unset):  Default: CreateChatBodyKind.AUTO.
    """

    user_ids: list[str] | Unset = UNSET
    title: None | str | Unset = UNSET
    kind: CreateChatBodyKind | Unset = CreateChatBodyKind.AUTO
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_ids: list[str] | Unset = UNSET
        if not isinstance(self.user_ids, Unset):
            user_ids = self.user_ids

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        kind: str | Unset = UNSET
        if not isinstance(self.kind, Unset):
            kind = self.kind.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user_ids is not UNSET:
            field_dict["user_ids"] = user_ids
        if title is not UNSET:
            field_dict["title"] = title
        if kind is not UNSET:
            field_dict["kind"] = kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_ids = cast(list[str], d.pop("user_ids", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        _kind = d.pop("kind", UNSET)
        kind: CreateChatBodyKind | Unset
        if isinstance(_kind, Unset):
            kind = UNSET
        else:
            kind = CreateChatBodyKind(_kind)

        create_chat_body = cls(
            user_ids=user_ids,
            title=title,
            kind=kind,
        )

        create_chat_body.additional_properties = d
        return create_chat_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
