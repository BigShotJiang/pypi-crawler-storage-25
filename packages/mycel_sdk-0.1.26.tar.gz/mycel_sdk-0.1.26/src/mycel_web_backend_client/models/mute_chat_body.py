from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="MuteChatBody")


@_attrs_define
class MuteChatBody:
    """
    Attributes:
        user_id (str):
        muted (bool):
        mute_until (float | None | Unset):
    """

    user_id: str
    muted: bool
    mute_until: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        muted = self.muted

        mute_until: float | None | Unset
        if isinstance(self.mute_until, Unset):
            mute_until = UNSET
        else:
            mute_until = self.mute_until

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "muted": muted,
            }
        )
        if mute_until is not UNSET:
            field_dict["mute_until"] = mute_until

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("user_id")

        muted = d.pop("muted")

        def _parse_mute_until(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        mute_until = _parse_mute_until(d.pop("mute_until", UNSET))

        mute_chat_body = cls(
            user_id=user_id,
            muted=muted,
            mute_until=mute_until,
        )

        mute_chat_body.additional_properties = d
        return mute_chat_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
