from enum import Enum


class MountSpecMode(str, Enum):
    COPY = "copy"
    MOUNT = "mount"

    def __str__(self) -> str:
        return str(self.value)
