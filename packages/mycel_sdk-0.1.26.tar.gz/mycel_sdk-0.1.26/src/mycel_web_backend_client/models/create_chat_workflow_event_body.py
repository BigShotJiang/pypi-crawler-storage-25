from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_chat_workflow_event_body_decision_states import (
        CreateChatWorkflowEventBodyDecisionStates,
    )
    from ..models.create_chat_workflow_event_body_final_state import (
        CreateChatWorkflowEventBodyFinalState,
    )
    from ..models.create_chat_workflow_event_body_metadata import (
        CreateChatWorkflowEventBodyMetadata,
    )
    from ..models.create_chat_workflow_event_body_rationales import (
        CreateChatWorkflowEventBodyRationales,
    )
    from ..models.create_chat_workflow_event_body_resource_refs_item import (
        CreateChatWorkflowEventBodyResourceRefsItem,
    )


T = TypeVar("T", bound="CreateChatWorkflowEventBody")


@_attrs_define
class CreateChatWorkflowEventBody:
    """
    Attributes:
        kind (str):
        resource_refs (list[CreateChatWorkflowEventBodyResourceRefsItem] | Unset):
        requested_by_user_id (None | str | Unset):
        decision_states (CreateChatWorkflowEventBodyDecisionStates | Unset):
        rationales (CreateChatWorkflowEventBodyRationales | Unset):
        final_state (CreateChatWorkflowEventBodyFinalState | Unset):
        metadata (CreateChatWorkflowEventBodyMetadata | Unset):
    """

    kind: str
    resource_refs: list[CreateChatWorkflowEventBodyResourceRefsItem] | Unset = UNSET
    requested_by_user_id: None | str | Unset = UNSET
    decision_states: CreateChatWorkflowEventBodyDecisionStates | Unset = UNSET
    rationales: CreateChatWorkflowEventBodyRationales | Unset = UNSET
    final_state: CreateChatWorkflowEventBodyFinalState | Unset = UNSET
    metadata: CreateChatWorkflowEventBodyMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind

        resource_refs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.resource_refs, Unset):
            resource_refs = []
            for resource_refs_item_data in self.resource_refs:
                resource_refs_item = resource_refs_item_data.to_dict()
                resource_refs.append(resource_refs_item)

        requested_by_user_id: None | str | Unset
        if isinstance(self.requested_by_user_id, Unset):
            requested_by_user_id = UNSET
        else:
            requested_by_user_id = self.requested_by_user_id

        decision_states: dict[str, Any] | Unset = UNSET
        if not isinstance(self.decision_states, Unset):
            decision_states = self.decision_states.to_dict()

        rationales: dict[str, Any] | Unset = UNSET
        if not isinstance(self.rationales, Unset):
            rationales = self.rationales.to_dict()

        final_state: dict[str, Any] | Unset = UNSET
        if not isinstance(self.final_state, Unset):
            final_state = self.final_state.to_dict()

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "kind": kind,
            }
        )
        if resource_refs is not UNSET:
            field_dict["resource_refs"] = resource_refs
        if requested_by_user_id is not UNSET:
            field_dict["requested_by_user_id"] = requested_by_user_id
        if decision_states is not UNSET:
            field_dict["decision_states"] = decision_states
        if rationales is not UNSET:
            field_dict["rationales"] = rationales
        if final_state is not UNSET:
            field_dict["final_state"] = final_state
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_chat_workflow_event_body_decision_states import (
            CreateChatWorkflowEventBodyDecisionStates,
        )
        from ..models.create_chat_workflow_event_body_final_state import (
            CreateChatWorkflowEventBodyFinalState,
        )
        from ..models.create_chat_workflow_event_body_metadata import (
            CreateChatWorkflowEventBodyMetadata,
        )
        from ..models.create_chat_workflow_event_body_rationales import (
            CreateChatWorkflowEventBodyRationales,
        )
        from ..models.create_chat_workflow_event_body_resource_refs_item import (
            CreateChatWorkflowEventBodyResourceRefsItem,
        )

        d = dict(src_dict)
        kind = d.pop("kind")

        _resource_refs = d.pop("resource_refs", UNSET)
        resource_refs: list[CreateChatWorkflowEventBodyResourceRefsItem] | Unset = UNSET
        if _resource_refs is not UNSET:
            resource_refs = []
            for resource_refs_item_data in _resource_refs:
                resource_refs_item = (
                    CreateChatWorkflowEventBodyResourceRefsItem.from_dict(
                        resource_refs_item_data
                    )
                )

                resource_refs.append(resource_refs_item)

        def _parse_requested_by_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        requested_by_user_id = _parse_requested_by_user_id(
            d.pop("requested_by_user_id", UNSET)
        )

        _decision_states = d.pop("decision_states", UNSET)
        decision_states: CreateChatWorkflowEventBodyDecisionStates | Unset
        if isinstance(_decision_states, Unset):
            decision_states = UNSET
        else:
            decision_states = CreateChatWorkflowEventBodyDecisionStates.from_dict(
                _decision_states
            )

        _rationales = d.pop("rationales", UNSET)
        rationales: CreateChatWorkflowEventBodyRationales | Unset
        if isinstance(_rationales, Unset):
            rationales = UNSET
        else:
            rationales = CreateChatWorkflowEventBodyRationales.from_dict(_rationales)

        _final_state = d.pop("final_state", UNSET)
        final_state: CreateChatWorkflowEventBodyFinalState | Unset
        if isinstance(_final_state, Unset):
            final_state = UNSET
        else:
            final_state = CreateChatWorkflowEventBodyFinalState.from_dict(_final_state)

        _metadata = d.pop("metadata", UNSET)
        metadata: CreateChatWorkflowEventBodyMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = CreateChatWorkflowEventBodyMetadata.from_dict(_metadata)

        create_chat_workflow_event_body = cls(
            kind=kind,
            resource_refs=resource_refs,
            requested_by_user_id=requested_by_user_id,
            decision_states=decision_states,
            rationales=rationales,
            final_state=final_state,
            metadata=metadata,
        )

        return create_chat_workflow_event_body
