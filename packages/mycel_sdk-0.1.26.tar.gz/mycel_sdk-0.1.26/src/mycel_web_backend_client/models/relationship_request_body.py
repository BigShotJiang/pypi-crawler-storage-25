from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="RelationshipRequestBody")


@_attrs_define
class RelationshipRequestBody:
    """
    Attributes:
        target_user_id (str):
        message (None | str | Unset):
    """

    target_user_id: str
    message: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        target_user_id = self.target_user_id

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "target_user_id": target_user_id,
            }
        )
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        target_user_id = d.pop("target_user_id")

        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))

        relationship_request_body = cls(
            target_user_id=target_user_id,
            message=message,
        )

        return relationship_request_body
