from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_chat_workflow_event_body_decision_states_type_0 import (
        UpdateChatWorkflowEventBodyDecisionStatesType0,
    )
    from ..models.update_chat_workflow_event_body_final_state_type_0 import (
        UpdateChatWorkflowEventBodyFinalStateType0,
    )
    from ..models.update_chat_workflow_event_body_metadata_type_0 import (
        UpdateChatWorkflowEventBodyMetadataType0,
    )
    from ..models.update_chat_workflow_event_body_rationales_type_0 import (
        UpdateChatWorkflowEventBodyRationalesType0,
    )


T = TypeVar("T", bound="UpdateChatWorkflowEventBody")


@_attrs_define
class UpdateChatWorkflowEventBody:
    """
    Attributes:
        state (None | str | Unset):
        decision_states (None | Unset | UpdateChatWorkflowEventBodyDecisionStatesType0):
        rationales (None | Unset | UpdateChatWorkflowEventBodyRationalesType0):
        final_state (None | Unset | UpdateChatWorkflowEventBodyFinalStateType0):
        metadata (None | Unset | UpdateChatWorkflowEventBodyMetadataType0):
        settled_at (float | None | Unset):
    """

    state: None | str | Unset = UNSET
    decision_states: None | Unset | UpdateChatWorkflowEventBodyDecisionStatesType0 = (
        UNSET
    )
    rationales: None | Unset | UpdateChatWorkflowEventBodyRationalesType0 = UNSET
    final_state: None | Unset | UpdateChatWorkflowEventBodyFinalStateType0 = UNSET
    metadata: None | Unset | UpdateChatWorkflowEventBodyMetadataType0 = UNSET
    settled_at: float | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.update_chat_workflow_event_body_decision_states_type_0 import (
            UpdateChatWorkflowEventBodyDecisionStatesType0,
        )
        from ..models.update_chat_workflow_event_body_final_state_type_0 import (
            UpdateChatWorkflowEventBodyFinalStateType0,
        )
        from ..models.update_chat_workflow_event_body_metadata_type_0 import (
            UpdateChatWorkflowEventBodyMetadataType0,
        )
        from ..models.update_chat_workflow_event_body_rationales_type_0 import (
            UpdateChatWorkflowEventBodyRationalesType0,
        )

        state: None | str | Unset
        if isinstance(self.state, Unset):
            state = UNSET
        else:
            state = self.state

        decision_states: dict[str, Any] | None | Unset
        if isinstance(self.decision_states, Unset):
            decision_states = UNSET
        elif isinstance(
            self.decision_states, UpdateChatWorkflowEventBodyDecisionStatesType0
        ):
            decision_states = self.decision_states.to_dict()
        else:
            decision_states = self.decision_states

        rationales: dict[str, Any] | None | Unset
        if isinstance(self.rationales, Unset):
            rationales = UNSET
        elif isinstance(self.rationales, UpdateChatWorkflowEventBodyRationalesType0):
            rationales = self.rationales.to_dict()
        else:
            rationales = self.rationales

        final_state: dict[str, Any] | None | Unset
        if isinstance(self.final_state, Unset):
            final_state = UNSET
        elif isinstance(self.final_state, UpdateChatWorkflowEventBodyFinalStateType0):
            final_state = self.final_state.to_dict()
        else:
            final_state = self.final_state

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, UpdateChatWorkflowEventBodyMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        settled_at: float | None | Unset
        if isinstance(self.settled_at, Unset):
            settled_at = UNSET
        else:
            settled_at = self.settled_at

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if state is not UNSET:
            field_dict["state"] = state
        if decision_states is not UNSET:
            field_dict["decision_states"] = decision_states
        if rationales is not UNSET:
            field_dict["rationales"] = rationales
        if final_state is not UNSET:
            field_dict["final_state"] = final_state
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if settled_at is not UNSET:
            field_dict["settled_at"] = settled_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_chat_workflow_event_body_decision_states_type_0 import (
            UpdateChatWorkflowEventBodyDecisionStatesType0,
        )
        from ..models.update_chat_workflow_event_body_final_state_type_0 import (
            UpdateChatWorkflowEventBodyFinalStateType0,
        )
        from ..models.update_chat_workflow_event_body_metadata_type_0 import (
            UpdateChatWorkflowEventBodyMetadataType0,
        )
        from ..models.update_chat_workflow_event_body_rationales_type_0 import (
            UpdateChatWorkflowEventBodyRationalesType0,
        )

        d = dict(src_dict)

        def _parse_state(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        state = _parse_state(d.pop("state", UNSET))

        def _parse_decision_states(
            data: object,
        ) -> None | Unset | UpdateChatWorkflowEventBodyDecisionStatesType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                decision_states_type_0 = (
                    UpdateChatWorkflowEventBodyDecisionStatesType0.from_dict(data)
                )

                return decision_states_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                None | Unset | UpdateChatWorkflowEventBodyDecisionStatesType0, data
            )

        decision_states = _parse_decision_states(d.pop("decision_states", UNSET))

        def _parse_rationales(
            data: object,
        ) -> None | Unset | UpdateChatWorkflowEventBodyRationalesType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                rationales_type_0 = (
                    UpdateChatWorkflowEventBodyRationalesType0.from_dict(data)
                )

                return rationales_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateChatWorkflowEventBodyRationalesType0, data)

        rationales = _parse_rationales(d.pop("rationales", UNSET))

        def _parse_final_state(
            data: object,
        ) -> None | Unset | UpdateChatWorkflowEventBodyFinalStateType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                final_state_type_0 = (
                    UpdateChatWorkflowEventBodyFinalStateType0.from_dict(data)
                )

                return final_state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateChatWorkflowEventBodyFinalStateType0, data)

        final_state = _parse_final_state(d.pop("final_state", UNSET))

        def _parse_metadata(
            data: object,
        ) -> None | Unset | UpdateChatWorkflowEventBodyMetadataType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = UpdateChatWorkflowEventBodyMetadataType0.from_dict(
                    data
                )

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateChatWorkflowEventBodyMetadataType0, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        def _parse_settled_at(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        settled_at = _parse_settled_at(d.pop("settled_at", UNSET))

        update_chat_workflow_event_body = cls(
            state=state,
            decision_states=decision_states,
            rationales=rationales,
            final_state=final_state,
            metadata=metadata,
            settled_at=settled_at,
        )

        return update_chat_workflow_event_body
