from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..models.send_message_body_delivery_scope import SendMessageBodyDeliveryScope
from ..types import UNSET, Unset

T = TypeVar("T", bound="SendMessageBody")


@_attrs_define
class SendMessageBody:
    """
    Attributes:
        content (str):
        mentioned_ids (list[str] | None | Unset):
        delivery_scope (SendMessageBodyDeliveryScope | Unset):  Default: SendMessageBodyDeliveryScope.BROADCAST.
        addressed_to_user_ids (list[str] | None | Unset):
        reply_to (None | str | Unset):
        enforce_caught_up (bool | Unset):  Default: False.
    """

    content: str
    mentioned_ids: list[str] | None | Unset = UNSET
    delivery_scope: SendMessageBodyDeliveryScope | Unset = (
        SendMessageBodyDeliveryScope.BROADCAST
    )
    addressed_to_user_ids: list[str] | None | Unset = UNSET
    reply_to: None | str | Unset = UNSET
    enforce_caught_up: bool | Unset = False

    def to_dict(self) -> dict[str, Any]:
        content = self.content

        mentioned_ids: list[str] | None | Unset
        if isinstance(self.mentioned_ids, Unset):
            mentioned_ids = UNSET
        elif isinstance(self.mentioned_ids, list):
            mentioned_ids = self.mentioned_ids

        else:
            mentioned_ids = self.mentioned_ids

        delivery_scope: str | Unset = UNSET
        if not isinstance(self.delivery_scope, Unset):
            delivery_scope = self.delivery_scope.value

        addressed_to_user_ids: list[str] | None | Unset
        if isinstance(self.addressed_to_user_ids, Unset):
            addressed_to_user_ids = UNSET
        elif isinstance(self.addressed_to_user_ids, list):
            addressed_to_user_ids = self.addressed_to_user_ids

        else:
            addressed_to_user_ids = self.addressed_to_user_ids

        reply_to: None | str | Unset
        if isinstance(self.reply_to, Unset):
            reply_to = UNSET
        else:
            reply_to = self.reply_to

        enforce_caught_up = self.enforce_caught_up

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "content": content,
            }
        )
        if mentioned_ids is not UNSET:
            field_dict["mentioned_ids"] = mentioned_ids
        if delivery_scope is not UNSET:
            field_dict["delivery_scope"] = delivery_scope
        if addressed_to_user_ids is not UNSET:
            field_dict["addressed_to_user_ids"] = addressed_to_user_ids
        if reply_to is not UNSET:
            field_dict["reply_to"] = reply_to
        if enforce_caught_up is not UNSET:
            field_dict["enforce_caught_up"] = enforce_caught_up

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        content = d.pop("content")

        def _parse_mentioned_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                mentioned_ids_type_0 = cast(list[str], data)

                return mentioned_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        mentioned_ids = _parse_mentioned_ids(d.pop("mentioned_ids", UNSET))

        _delivery_scope = d.pop("delivery_scope", UNSET)
        delivery_scope: SendMessageBodyDeliveryScope | Unset
        if isinstance(_delivery_scope, Unset):
            delivery_scope = UNSET
        else:
            delivery_scope = SendMessageBodyDeliveryScope(_delivery_scope)

        def _parse_addressed_to_user_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                addressed_to_user_ids_type_0 = cast(list[str], data)

                return addressed_to_user_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        addressed_to_user_ids = _parse_addressed_to_user_ids(
            d.pop("addressed_to_user_ids", UNSET)
        )

        def _parse_reply_to(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reply_to = _parse_reply_to(d.pop("reply_to", UNSET))

        enforce_caught_up = d.pop("enforce_caught_up", UNSET)

        send_message_body = cls(
            content=content,
            mentioned_ids=mentioned_ids,
            delivery_scope=delivery_scope,
            addressed_to_user_ids=addressed_to_user_ids,
            reply_to=reply_to,
            enforce_caught_up=enforce_caught_up,
        )

        return send_message_body
