from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.wait_runtime_inbox_api_runtime_inbox_wait_post_response_wait_runtime_inbox_api_runtime_inbox_wait_post import (
    WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    timeout_seconds: float | Unset = 25.0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["timeout_seconds"] = timeout_seconds

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/runtime/inbox/wait",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
    | None
):
    if response.status_code == 200:
        response_200 = WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    timeout_seconds: float | Unset = 25.0,
) -> Response[
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
]:
    """Wait Runtime Inbox

    Args:
        timeout_seconds (float | Unset):  Default: 25.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost]
    """

    kwargs = _get_kwargs(
        timeout_seconds=timeout_seconds,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    timeout_seconds: float | Unset = 25.0,
) -> (
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
    | None
):
    """Wait Runtime Inbox

    Args:
        timeout_seconds (float | Unset):  Default: 25.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
    """

    return sync_detailed(
        client=client,
        timeout_seconds=timeout_seconds,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    timeout_seconds: float | Unset = 25.0,
) -> Response[
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
]:
    """Wait Runtime Inbox

    Args:
        timeout_seconds (float | Unset):  Default: 25.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost]
    """

    kwargs = _get_kwargs(
        timeout_seconds=timeout_seconds,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    timeout_seconds: float | Unset = 25.0,
) -> (
    HTTPValidationError
    | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
    | None
):
    """Wait Runtime Inbox

    Args:
        timeout_seconds (float | Unset):  Default: 25.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WaitRuntimeInboxApiRuntimeInboxWaitPostResponseWaitRuntimeInboxApiRuntimeInboxWaitPost
    """

    return (
        await asyncio_detailed(
            client=client,
            timeout_seconds=timeout_seconds,
        )
    ).parsed
