"""Public SDK surface for Mycel CLI consumers."""

from .client import Client
from .errors import ApiError

__all__ = ["ApiError", "Client"]
