"""Public SDK facade backed by FastAPI/OpenAPI-generated transport."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .generated_adapter import GeneratedClientAdapter

GENERATED_PACKAGE_NAME = "mycel_web_backend_client"


def _strip_url(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip().rstrip("/")
    return stripped or None


def _resolve_generated_base_url(*, base_url: str | None) -> str:
    resolved = _strip_url(base_url)
    if resolved is None:
        raise RuntimeError("base_url is required")
    return resolved


@dataclass(frozen=True)
class Client:
    """Stable resource-group facade over the generated Mycel web client."""

    _adapter: GeneratedClientAdapter
    me: Any
    chats: Any
    messages: Any
    users: Any
    auth: Any
    agents: Any
    threads: Any
    relationships: Any
    notifications: Any

    def __init__(
        self,
        *,
        auth_token: str | None = None,
        base_url: str | None = None,
    ) -> None:
        resolved_base_url = _resolve_generated_base_url(base_url=base_url)
        adapter = GeneratedClientAdapter.from_package(
            GENERATED_PACKAGE_NAME,
            base_url=resolved_base_url,
            auth_token=auth_token,
        )

        object.__setattr__(self, "_adapter", adapter)
        object.__setattr__(self, "me", adapter.me)
        object.__setattr__(self, "chats", adapter.chats)
        object.__setattr__(self, "messages", adapter.messages)
        object.__setattr__(self, "users", adapter.users)
        object.__setattr__(self, "auth", adapter.auth)
        object.__setattr__(self, "agents", adapter.agents)
        object.__setattr__(self, "threads", adapter.threads)
        object.__setattr__(self, "relationships", adapter.relationships)
        object.__setattr__(self, "notifications", adapter.notifications)

    @classmethod
    def from_openapi_client_root(
        cls,
        package_root: str,
        *,
        base_url: str | None = None,
        auth_token: str | None = None,
    ) -> Client:
        resolved_base_url = _resolve_generated_base_url(base_url=base_url)
        instance = cls.__new__(cls)
        adapter = GeneratedClientAdapter.from_generated_root(
            package_root,
            base_url=resolved_base_url,
            auth_token=auth_token,
        )

        object.__setattr__(instance, "_adapter", adapter)
        object.__setattr__(instance, "me", adapter.me)
        object.__setattr__(instance, "chats", adapter.chats)
        object.__setattr__(instance, "messages", adapter.messages)
        object.__setattr__(instance, "users", adapter.users)
        object.__setattr__(instance, "auth", adapter.auth)
        object.__setattr__(instance, "agents", adapter.agents)
        object.__setattr__(instance, "threads", adapter.threads)
        object.__setattr__(instance, "relationships", adapter.relationships)
        object.__setattr__(instance, "notifications", adapter.notifications)
        return instance
