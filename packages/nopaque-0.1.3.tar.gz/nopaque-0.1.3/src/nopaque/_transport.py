"""Shared HTTP transport for sync + async clients.

Owns: URL composition, auth header injection, User-Agent, JSON (de)serialization,
error classification, per-request timeouts, and retry orchestration.
"""
from __future__ import annotations

import asyncio
import json as jsonlib
import time
from typing import Any

import httpx

from ._config import NopaqueConfig
from ._errors import (
    APIConnectionError,
    APITimeoutError,
    NopaqueAPIError,
    NopaqueError,
    RateLimitError,
    classify_status,
)
from ._request_options import RequestOptions, merge_options
from ._retry import RetryContext, delay_for, should_retry
from ._user_agent import compose_user_agent


def _merge_headers(
    config: NopaqueConfig, options: RequestOptions | None
) -> dict[str, str]:
    headers: dict[str, str] = {
        "x-api-key": config.api_key,
        "user-agent": compose_user_agent(),
        "accept": "application/json",
    }
    if config.default_headers:
        headers.update(config.default_headers)
    if options and options.get("headers"):
        headers.update(options["headers"])  # type: ignore[arg-type]
    return headers


def _build_url(config: NopaqueConfig, path: str) -> str:
    if not path.startswith("/"):
        path = "/" + path
    return f"{config.base_url}{path}"


def _raise_for_status(response: httpx.Response) -> None:
    """Map a non-2xx response to the appropriate typed exception."""
    if 200 <= response.status_code < 300:
        return
    try:
        body = response.json()
    except (ValueError, jsonlib.JSONDecodeError):
        body = {}
    error_message = body.get("error") if isinstance(body, dict) else None
    code = body.get("code") if isinstance(body, dict) else None
    details = body.get("details") if isinstance(body, dict) else None
    request_id = response.headers.get("x-request-id")

    cls = classify_status(response.status_code)
    if cls is RateLimitError:
        retry_after_raw = response.headers.get("retry-after")
        retry_after: float | None = None
        if retry_after_raw is not None:
            try:
                retry_after = float(retry_after_raw)
            except ValueError:
                retry_after = None
        raise RateLimitError(
            status=response.status_code,
            code=code,
            message=error_message or "rate limit exceeded",
            details=details,
            request_id=request_id,
            response=response,
            retry_after=retry_after,
        )
    raise cls(
        status=response.status_code,
        code=code,
        message=error_message or f"HTTP {response.status_code}",
        details=details,
        request_id=request_id,
        response=response,
    )


def _effective_max_retries(
    config: NopaqueConfig, options: RequestOptions | None
) -> int:
    if options and "max_retries" in options:
        return int(options["max_retries"])
    return config.max_retries


def _invoke_on_retry(
    config: NopaqueConfig, attempt: int, err: NopaqueError, delay: float
) -> None:
    if config.on_retry is None:
        return
    try:
        config.on_retry(attempt, err, delay)
    except Exception:
        # Never let a user callback break the request.
        pass


class SyncTransport:
    """Synchronous HTTP transport."""

    def __init__(
        self, config: NopaqueConfig, *, http_client: httpx.Client | None = None
    ) -> None:
        self._config = config
        self._client = http_client or httpx.Client(timeout=config.timeout)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: Any = None,
        request_options: RequestOptions | None = None,
    ) -> Any:
        headers = _merge_headers(self._config, request_options)
        url = _build_url(self._config, path)
        opts = merge_options(None, request_options)
        timeout = opts.get("timeout", self._config.timeout)
        ctx = RetryContext(
            max_retries=_effective_max_retries(self._config, request_options)
        )

        while True:
            before_send = True
            err: NopaqueError | None = None
            try:
                response = self._client.request(
                    method,
                    url,
                    params=params,
                    json=json,
                    headers=headers,
                    timeout=timeout,
                )
                before_send = False
                _raise_for_status(response)
            except httpx.TimeoutException as e:
                err = APITimeoutError(str(e))
            except httpx.HTTPError as e:
                err = APIConnectionError(str(e), cause=e)
            except NopaqueAPIError as e:
                err = e
            else:
                if response.status_code == 204 or not response.content:
                    return None
                return response.json()

            assert err is not None
            if not should_retry(method=method, error=err, before_send=before_send):
                raise err
            if ctx.exhausted():
                raise err
            delay = delay_for(attempt=ctx.attempts_used, error=err)
            _invoke_on_retry(self._config, ctx.attempts_used, err, delay)
            time.sleep(delay)
            ctx.record_attempt()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SyncTransport:
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.close()


class AsyncTransport:
    """Asynchronous HTTP transport."""

    def __init__(
        self,
        config: NopaqueConfig,
        *,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._client = http_client or httpx.AsyncClient(timeout=config.timeout)

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: Any = None,
        request_options: RequestOptions | None = None,
    ) -> Any:
        headers = _merge_headers(self._config, request_options)
        url = _build_url(self._config, path)
        opts = merge_options(None, request_options)
        timeout = opts.get("timeout", self._config.timeout)
        ctx = RetryContext(
            max_retries=_effective_max_retries(self._config, request_options)
        )

        while True:
            before_send = True
            err: NopaqueError | None = None
            try:
                response = await self._client.request(
                    method,
                    url,
                    params=params,
                    json=json,
                    headers=headers,
                    timeout=timeout,
                )
                before_send = False
                _raise_for_status(response)
            except httpx.TimeoutException as e:
                err = APITimeoutError(str(e))
            except httpx.HTTPError as e:
                err = APIConnectionError(str(e), cause=e)
            except NopaqueAPIError as e:
                err = e
            else:
                if response.status_code == 204 or not response.content:
                    return None
                return response.json()

            assert err is not None
            if not should_retry(method=method, error=err, before_send=before_send):
                raise err
            if ctx.exhausted():
                raise err
            delay = delay_for(attempt=ctx.attempts_used, error=err)
            _invoke_on_retry(self._config, ctx.attempts_used, err, delay)
            await asyncio.sleep(delay)
            ctx.record_attempt()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncTransport:
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        await self.aclose()
