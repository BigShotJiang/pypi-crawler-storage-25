"""
SSE (Server-Sent Events) streaming helper.

Provides async and buffered parsing helpers for SSE responses.
Used by dominus.ai.stream_agent(), dominus.ai.complete_stream(), and finite
execution replay surfaces that return `text/event-stream`.
"""
import json
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional
import httpx


def _decode_sse_payload(
    data_buffer: List[str],
    event_type: Optional[str],
) -> Optional[Dict[str, Any]]:
    if not data_buffer:
        return None

    data_str = "\n".join(data_buffer)
    if data_str == "[DONE]":
        return None

    try:
        data = json.loads(data_str)
    except json.JSONDecodeError:
        data = {"raw": data_str}

    if event_type:
        data["_event"] = event_type
    return data


async def stream_sse(
    response: httpx.Response,
    on_event: Optional[Callable[[Dict[str, Any]], None]] = None
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Parse SSE stream from httpx response.

    SSE format:
        event: event_name (optional)
        data: json_payload
        (blank line)

    Special handling:
        - data: [DONE] signals end of stream
        - Empty data lines are skipped
        - Non-JSON data lines are yielded as {"raw": data}

    Args:
        response: httpx.Response with streaming enabled
        on_event: Optional callback for each event (called before yield)

    Yields:
        Parsed JSON data from each SSE event
    """
    event_type = None
    data_buffer = []

    async for line in response.aiter_lines():
        line = line.strip()

        # Empty line = end of event
        if not line:
            if data_buffer:
                data = _decode_sse_payload(data_buffer, event_type)
                data_buffer = []
                event_type = None

                if data is None:
                    break

                if on_event:
                    on_event(data)
                yield data
            continue

        # Parse SSE fields
        if line.startswith("event:"):
            event_type = line[6:].strip()
        elif line.startswith("data:"):
            data_str = line[5:].strip()
            # Handle immediate [DONE] on same line
            if data_str == "[DONE]":
                break
            data_buffer.append(data_str)
        elif line.startswith("id:"):
            # Event ID - we don't track this currently
            pass
        elif line.startswith("retry:"):
            # Retry timeout - we don't use this currently
            pass
        elif line.startswith(":"):
            # Comment line - ignore
            pass


def parse_sse_text(payload: str) -> List[Dict[str, Any]]:
    """
    Parse a finite SSE payload that has already been fully buffered.

    Used by replay-style GET routes that return `text/event-stream` but are not
    long-lived subscriptions.
    """
    events: List[Dict[str, Any]] = []
    event_type: Optional[str] = None
    data_buffer: List[str] = []

    for raw_line in payload.splitlines():
        line = raw_line.strip()

        if not line:
            if data_buffer:
                data = _decode_sse_payload(data_buffer, event_type)
                data_buffer = []
                event_type = None
                if data is None:
                    break
                events.append(data)
            continue

        if line.startswith("event:"):
            event_type = line[6:].strip()
        elif line.startswith("data:"):
            data_str = line[5:].strip()
            if data_str == "[DONE]":
                break
            data_buffer.append(data_str)
        elif line.startswith("id:"):
            pass
        elif line.startswith("retry:"):
            pass
        elif line.startswith(":"):
            pass

    if data_buffer:
        data = _decode_sse_payload(data_buffer, event_type)
        if data is not None:
            events.append(data)

    return events


async def collect_stream(
    response: httpx.Response,
    on_event: Optional[Callable[[Dict[str, Any]], None]] = None
) -> Dict[str, Any]:
    """
    Collect all SSE events and return final aggregated result.

    Useful for collecting streaming responses into a single result.
    Looks for final_response or combines content deltas.

    Args:
        response: httpx.Response with streaming enabled
        on_event: Optional callback for each event

    Returns:
        Aggregated result dict with:
        - final_response: The last complete response (if present)
        - content: Concatenated content from all deltas
        - chunks: List of all chunks received
    """
    chunks = []
    content_parts = []
    final_response = None

    async for chunk in stream_sse(response, on_event):
        chunks.append(chunk)

        # Collect content deltas
        if "content" in chunk:
            content_parts.append(chunk["content"])
        elif "delta" in chunk and "content" in chunk["delta"]:
            content_parts.append(chunk["delta"]["content"])

        # Capture final response if present
        if "final_response" in chunk:
            final_response = chunk["final_response"]

    return {
        "final_response": final_response,
        "content": "".join(content_parts),
        "chunks": chunks,
        "chunk_count": len(chunks)
    }
