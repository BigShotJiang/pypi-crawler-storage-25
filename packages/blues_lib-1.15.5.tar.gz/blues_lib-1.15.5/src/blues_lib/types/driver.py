from typing import TypeAlias, TypedDict, Any, Literal, NotRequired

__all__ = [
  "DriverStartupOpts",
  "DriverMode",
  "DriverLocOpts",
  "LoginMode",
  "DriverDef",
]

DriverStartupOpts: TypeAlias = TypedDict("DriverStartupOpts", {
  "features": list[str],
  "caps": dict[str, Any],
  "arguments": list[str],
  "exp_options": dict[str, Any],
  "extensions": list[str],
  "cdp_cmds": dict[str, Any],
})

DriverMode: TypeAlias = Literal["remote", "chrome", "cft", "udc", "udcft", "context"]

DriverLocOpts: TypeAlias = TypedDict("DriverLocOpts", {
  "command_executor": str,
  "executable_path": str,
  "binary_location": str,
})

LoginMode: TypeAlias = Literal["account", "sms", "qrcode"]


class DriverDef(TypedDict):
  mode: DriverMode
  ephemeral: bool
  startup: DriverStartupOpts
  location: DriverLocOpts
  login: str
