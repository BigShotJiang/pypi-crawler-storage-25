import cmd
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
import os
import platform
import subprocess
from blues_lib.utils.file import FileWriter, FileReader, File

class Process(BaseAbility):
  
  def kill_chrome(self)->bool:
    '''
    Stop all chrome process
    @returns {int} : 0-success >0- failure
    '''
    return self.kill({"value":"chrome"})
  
  def kill(self, options:dict)->bool:
    '''
    Stop a app's all process
    @param {str} task_name : the app's process name
    @returns {int} : 0-success >0- failure
    '''
    system = platform.system().lower()
    name:str = options.get("value","")
    if not name:
      return False
    
    try:
      if 'windows' in system:
        # Windows system
        return os.system(f'taskkill /F /IM {name}.exe') == 0
      elif 'darwin' in system:
        # macOS system
        return os.system(f'pkill -f {name}') == 0
      elif 'linux' in system:
        # Linux system
        return os.system(f'pkill -f {name}') == 0
      else:
        # Unsupported system
        self._logger.warning(f"Unsupported operating system: {system}")
        return False
    except Exception as e:
      self._logger.warning(f"Error occurred while killing process: {e}")
      return False

  def agent_cmd(self, options: dict) -> any:
    '''
    use ai agent, write the result to a file and read it back
    '''
    cmd_output:str = self.shell_cmd(options)
    return self.__return_result(options,cmd_output)

  def agent_terminal(self, options: dict) -> str:
    '''
    use ai agent, write the result to a file and read it back
    '''
    cmd_output:str = self.shell_terminal(options)
    return self.__return_result(options,cmd_output,'terminal')

  def __return_result(self, options: dict, content: str, mode:str = 'cmd')->any:
    # return the agent created file content
    from_file:dict|str|bool = options.pop("from_file",{})
    if from_file:
      return self.__read_from_file(options,from_file,mode)

    # return the command output file path
    to_file:dict|str|bool = options.pop("to_file",{})
    if to_file and content:
      return self.__write_to_file(content,to_file)
    return content
  
  def __read_from_file(self, options: dict, from_file:dict|str|bool,mode:str = 'cmd')->str:
    if mode == 'terminal':
      options.setdefault("timeout",3600)
      options.setdefault("interval",30)
    input_file:str = File.get_abs_file(from_file)
    timeout:int|float = options.get("timeout",2)
    interval:int|float = options.get("interval",1)
    stat:bool = File.wait(input_file,timeout,interval)
    if not stat:
      self._logger.warning(f"Error: agent output file {input_file} does not exist")
      return ''

    ext:str = File.get_extension(input_file)
    if ext=='json':
      return FileReader.read_json(input_file)
    else:
      return FileReader.read_text(input_file)

  def __write_to_file(self, content:str,to_file:dict|str|bool)->str:
    # write command output to file
    out_file:str = File.get_abs_file(to_file)
    return FileWriter.write_text(out_file,content)

  def shell_cmd(self, options: dict) -> str:
    '''
    Execute shell command synchronously (blocking) and return output
    @note: This method blocks until command completes. Use shell_terminal() for non-blocking execution.
    @param {dict} options: 
      - command: str|list - the shell command to execute (string or list of args)
      - cwd: str (optional) - working directory before execution
      - timeout: int (optional) - timeout in seconds, default 3600 (60 minutes)
    @returns {str} : command output if success, error message if failure
    '''
    command, cwd = self.__parse_shell_options(options)
    timeout: int = options.get("timeout", 3600)
    
    if not command:
      error_msg = "Error: command is empty"
      self._logger.warning(error_msg)
      return error_msg

    shell = isinstance(command, str)
    
    # Windows 上列表形式的命令需要通过 cmd.exe 执行
    if isinstance(command, list) and platform.system().lower() == 'windows':
      def quote_arg(arg):
        return f'"{arg}"' if ' ' in arg else arg
      command = 'cmd /c ' + ' '.join(quote_arg(arg) for arg in command)
      shell = True

    try:
      result = subprocess.run(
        command,
        cwd=cwd,
        timeout=timeout,
        shell=shell,
        capture_output=True,
        encoding='utf-8',
        errors='replace',
        text=True
      )
      
      if result.returncode == 0:
        return result.stdout.strip()
      else:
        error_msg = f"Command execution failed with return code {result.returncode}"
        if result.stderr:
          error_msg += f"\nstderr: {result.stderr.strip()}"
        self._logger.error(error_msg)
        return error_msg
    except subprocess.TimeoutExpired:
      error_msg = f"Error: Command execution timed out after {timeout} seconds"
      self._logger.error(error_msg)
      return error_msg
    except Exception as e:
      error_msg = f"Error occurred while executing shell command: {e}"
      self._logger.error(error_msg)
      return error_msg

  def shell_terminal(self, options: dict) -> str:
    '''
    Execute command in a separate terminal window (non-blocking)
    @note: This method starts a new terminal window and returns immediately. 
           Use shell_cmd() to execute commands synchronously and capture output.
    @param {dict} options: 
      - command: str|list - the shell command to execute (string or list of args)
      - cwd: str (optional) - working directory before execution
    @returns {None} : always returns None
    '''
    command, cwd = self.__parse_shell_options(options)
    
    if not command:
      message = "Error: command is empty"
      self._logger.warning(message)
      return message
    
    if isinstance(command, list):
      def quote_arg(arg):
        return f'"{arg}"' if ' ' in arg else arg
      command = ' '.join(quote_arg(arg) for arg in command)
    
    system = platform.system().lower()

    try:
      if 'windows' in system:
        subprocess.Popen(
          ['start', 'cmd', '/k', command],
          cwd=cwd,
          shell=True,
          creationflags=subprocess.CREATE_NEW_CONSOLE
        )
      elif 'darwin' in system:
        import shlex
        cd_cmd = f'cd {shlex.quote(cwd)} && ' if cwd else ''
        full_cmd = f'{cd_cmd}{command}'
        script = f'tell application "Terminal"\n  do script "{full_cmd}"\nend tell'
        subprocess.run(['osascript', '-e', script], text=True)
      elif 'linux' in system:
        cd_cmd = f'cd "{cwd}" && ' if cwd else ''
        subprocess.Popen(
            ['gnome-terminal', '--', 'bash', '-c', f'{cd_cmd}{command}; exec bash']
        )
      else:
        message = f"Error: Unsupported operating system: {system}"
        self._logger.warning(message)
        return message
      message = f"Terminal started successfully with command: {command}"
      self._logger.info(message)
      return message
    except Exception as e:
      message = f"Error: Error occurred while starting terminal: {e}"
      self._logger.warning(message)
      return message
  
  def __parse_shell_options(self, options: dict) -> tuple[str|list, str|None]:
    '''
    Parse and validate shell command options
    @param {dict} options: command options
    @returns {tuple} : (command, cwd)
    '''
    command = options.get("command", "")
    if isinstance(command, str):
      command = command.strip()
    elif isinstance(command, list):
      command = [str(arg) for arg in command]
    cwd: str|None = options.get("cwd", "").strip() or None
    
    if cwd:
      cwd = os.path.normpath(cwd)
      self._logger.info(f"cwd: {cwd}")
    
    self._logger.info(f"command: {command}")
    return (command, cwd)
