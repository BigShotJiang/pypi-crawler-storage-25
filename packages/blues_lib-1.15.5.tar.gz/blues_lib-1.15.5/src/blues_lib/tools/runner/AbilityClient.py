import logging
from typing import Self
from blues_lib.types import AbilityExecError, BlockSeqError, ToolDef
from blues_lib.tools.runner.AbilityFacade import AbilityFacade
from blues_lib.tools.runner.AbilityExecutor import AbilityExecutor
from blues_lib.tools.runner.MetaLoader import MetaLoader
from blues_lib.tools.context import TaskContext
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility


class AbilityClient:
  '''
  调用AbilityFacade,提供：
  - 异常捕获与driver清理
  - 多AbilityFacade Flow调用
  - 直接从resource加载并执行的便捷方法
  '''
  _logger = logging.getLogger('airflow.task')

  @classmethod
  def repeat(cls, resource: dict | str, repeat_by: int | list = 0) -> list[any]:
    metas_seq = MetaLoader.repeat(resource, repeat_by)
    return cls.each(metas_seq)

  @classmethod
  def execute(cls, resource: dict | str, globals: dict | None = None, context: dict | None = None) -> any:
    metas:tuple[dict,dict] = MetaLoader.load(resource, globals, context)
    return cls.once(*metas)

  @classmethod
  def each(cls, metas_seq: list[tuple[dict,ToolDef]]) -> list[any]:
    results:list[any] = []
    for ctx,meta in metas_seq:
      result:any = cls.once(ctx,meta)
      results.append(result)
    return results

  @classmethod
  def once(cls,ctx:TaskContext|dict,meta:ToolDef)->any:
    """
    execute the method in the facade
    Args:
      meta (ToolDef): the method name
    Returns:
      list[any]: the method return
    """
    context = cls._get_context(ctx)
    name:str = meta.get('name')
    description:str = meta.get('description')
    options = meta.get('options')
    
    try:
      facade = AbilityFacade(context)
      result:dict =  facade.execute(name,options)
      context.add_stat(True,name,description)
      return result
    except (AbilityExecError,BlockSeqError,Exception) as e:
      tools:list[ToolDef] = options.get('block_seq_tools') or []
      AbilityExecutor(context).execute(tools)
      context.add_stat(False,name,description,str(e))
      return None
    finally:
      context.teardown()
      
  @classmethod
  def _get_context(cls,ctx:TaskContext|dict|None)->TaskContext:
    if isinstance(ctx,TaskContext):
      return ctx
    return TaskContext(ctx)

  @classmethod
  def register(cls,ability_classes:list[type[BaseAbility]]|type[BaseAbility])->Self:
    AbilityFacade.register(ability_classes)
    return cls
