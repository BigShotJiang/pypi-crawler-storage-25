import json
import logging


class TypeManager:
  """
  类型管理和数据处理工具类
  """

  _logger = logging.getLogger('airflow.task')

  @classmethod
  def last_index(cls, sequence: list | tuple, value: any) -> int:
    """
    获取序列中某个值最后一次出现的索引

    Args:
      sequence: 序列（列表或元组）
      value: 要查找的值

    Returns:
      最后一次出现的索引，如果没有匹配则返回-1
    """
    try:
      return (len(sequence) - 1) - sequence[::-1].index(value)
    except ValueError:
      return -1

  @classmethod
  def is_field_satisfied_dict(cls, value: dict, keys: list[str], is_value_required: bool = False) -> bool:
    """
    检查字典是否包含所有必需的键

    Args:
      value: 待检查的字典
      keys: 必需的键列表
      is_value_required: 每个必需字段的值是否不能为空（不支持空值）

    Returns:
      是否满足条件
    """
    if not value or not keys:
      return False

    for key in keys:
      if key not in value:
        return False
      if is_value_required:
        if not value.get(key):
          return False
    return True

  @classmethod
  def to_json(cls, content: any) -> any:
    """
    尝试将字符串解析为JSON对象

    Args:
      content: 待解析的内容

    Returns:
      解析后的JSON对象，如果不是字符串或解析失败则返回原值
    """
    if not content or not isinstance(content, str):
      return content

    try:
      content = json.loads(content)
    except json.JSONDecodeError as e:
      cls._logger.error(f'failed to parse json: {e}')
    return content
