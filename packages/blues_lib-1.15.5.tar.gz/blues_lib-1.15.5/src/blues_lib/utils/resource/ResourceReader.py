from importlib import resources
from typing import Any
from blues_lib.utils.file import FileReader
from blues_lib.utils.url import URIManager


class ResourceReader:
  """
  Universal package resource reader supporting multiple formats.
  Accepts both package objects and string package paths as input.
  Delegates to FileReader.read which auto-detects format by extension.
  Also handles URI placeholder rendering (recursively replacing URI strings with loaded content).
  """

  @classmethod
  def read(cls, package, resource_path, extension: str = ''):
    file_path = cls.get_resource_path(package, resource_path, extension)
    return FileReader.read(file_path, extension=extension)

  @classmethod
  def read_uri(cls, uri: str, extension: str = 'conf') -> Any:
    segments: dict[str, str] = URIManager.parse(uri)
    scheme: str = segments.get('scheme')
    netloc: str = segments.get('netloc', '')
    path: str = segments.get('path', '')

    package: str = f'blues_lib.resources.{scheme}'
    conf_file: str = netloc + path
    return cls.read(package, conf_file, extension)

  @classmethod
  def load(cls, resource: dict | str, extension: str = 'conf') -> dict:
    """
    Load resource and render URI placeholders recursively.

    Args:
      resource: Resource can be:
        - dict: Already loaded resource, will be recursively rendered
        - str of URI: e.g., "bizdata://task/jiemian/brief"
        - str of file path: e.g., "tests/tools/task/test"
      extension: Default extension for file path (default: conf)

    Returns:
      dict: The rendered resource with all URI placeholders replaced
    """
    if not isinstance(resource, str):
      return cls._render_node(resource)

    if URIManager.is_uri(resource):
      loaded = cls.read_uri(resource, extension)
      return cls._render_node(loaded)

    loaded = FileReader.read(resource)
    return cls._render_node(loaded)

  @classmethod
  def _render_node(cls, node: Any) -> Any:
    """
    Recursively traverse and replace URI placeholders.

    Args:
      node: Current node (string, dict, list, or other)

    Returns:
      The node with URI placeholders replaced
    """
    if isinstance(node, str):
      return cls._render_str_node(node)
    elif isinstance(node, dict):
      new_node = {}
      for key, value in node.items():
        new_node[key] = cls._render_node(value)
      return new_node
    elif isinstance(node, list):
      return [cls._render_node(item) for item in node]
    else:
      return node

  @classmethod
  def _render_str_node(cls, value: str) -> str:
    """
    Replace URI placeholders in string.

    Args:
      value: The string to process

    Returns:
      If value is a URI, returns loaded content; otherwise returns original value
    """
    if URIManager.is_uri(value):
      node_data: Any = cls.read_uri(value)
      return cls._render_node(node_data)
    return value

  @classmethod
  def get_resource_path(cls, package, resource_path, extension: str = ''):
    package_name = cls._get_package_name(package)
    pkg_dir = resources.files(package)

    if extension:
      file_path = pkg_dir.joinpath(f"{resource_path}.{extension}")
      if file_path.exists():
        return file_path

    file_path = pkg_dir.joinpath(resource_path)
    if not file_path.exists():
      raise FileNotFoundError(f"Resource not found in package [{package_name}]: {resource_path}")
    return file_path

  @classmethod
  def _get_package_name(cls, package):
    if hasattr(package, "__name__"):
      return package.__name__
    elif isinstance(package, str):
      return package
    raise TypeError("package must be a package object or string package path")
