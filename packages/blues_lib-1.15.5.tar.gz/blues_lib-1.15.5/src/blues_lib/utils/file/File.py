import os
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from blues_lib.utils.datetime import DateTimeManager


class File:
  """
  文件系统工具类，提供文件和目录操作功能
  """

  @classmethod
  def get_project_home(cls) -> str:
    """
    获取项目根目录

    Returns:
      项目根目录路径，从环境变量 PROJECT_HOME 获取
    """
    return os.environ.get('PROJECT_HOME') or ''

  @classmethod
  def get_project_test(cls) -> str:
    """
    获取项目测试目录

    Returns:
      项目测试目录路径，从环境变量 PROJECT_TEST 获取
    """
    return os.environ.get('PROJECT_TEST') or ''

  @classmethod
  def get_home(cls) -> str:
    """
    获取用户主目录

    Returns:
      用户主目录路径
    """
    return str(Path.home())

  @classmethod
  def get_blues_home(cls) -> str:
    """
    获取blues库的根目录

    Returns:
      blues库根目录路径
    """
    home: str = cls.get_home()
    dir_path: str = os.path.join(home, '.blues')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_cft_home(cls) -> str:
    """
    获取Chrome CFT资源目录

    Returns:
      Chrome CFT资源目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'cft')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_log_home(cls) -> str:
    """
    获取日志目录

    Returns:
      日志目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'log')
    return cls.makedirs(dir_path)

  @classmethod
  def get_today_log_home(cls, subdir: str | list[str] = '') -> str:
    """
    获取今日日志目录

    Args:
      subdir: 子目录，可以是字符串或字符串列表

    Returns:
      今日日志目录路径
    """
    today = datetime.now().strftime("%Y-%m-%d")
    root = cls.get_blues_log_home()
    subdir = subdir if isinstance(subdir, list) else [subdir]
    dir_path = os.path.join(root, today, *subdir)
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_download_home(cls) -> str:
    """
    获取下载目录

    Returns:
      下载目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'browser_download')
    return cls.makedirs(dir_path)

  @classmethod
  def get_today_download_home(cls, subdir: str | list[str] = '') -> str:
    """
    获取今日下载目录

    Args:
      subdir: 子目录，可以是字符串或字符串列表

    Returns:
      今日下载目录路径
    """
    today = datetime.now().strftime("%Y-%m-%d")
    root = cls.get_blues_download_home()
    subdir = subdir if isinstance(subdir, list) else [subdir]
    dir_path = os.path.join(root, today, *subdir)
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_cache_home(cls) -> str:
    """
    获取缓存目录

    Returns:
      缓存目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'cache')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_temp_home(cls) -> str:
    """
    获取临时目录

    Returns:
      临时目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'temp')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_file_home(cls) -> str:
    """
    获取文件存储目录

    Returns:
      文件存储目录路径
    """
    blues_home: str = cls.get_blues_home()
    dir_path: str = os.path.join(blues_home, 'file')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_dir_path(cls, subdir: str | list[str] = '') -> str:
    """
    获取blues库的标准目录路径

    Args:
      subdir: 子目录，可以是字符串或字符串列表

    Returns:
      标准目录路径
    """
    blues_home: str = cls.get_blues_home()
    dirs = subdir if isinstance(subdir, list) else [subdir]
    dir_path = os.path.join(blues_home, *dirs)
    cls.makedirs(dir_path)
    return dir_path

  @classmethod
  def get_blues_file_path(cls, subdir: str | list[str], filename: str, extension: str = 'txt') -> str:
    """
    获取基于blues库根目录的文件绝对路径

    Args:
      subdir: 子目录，可以是字符串或字符串列表
      filename: 文件名
      extension: 文件扩展名，默认为 'txt'

    Returns:
      文件绝对路径
    """
    dir_path = cls.get_blues_dir_path(subdir)
    filename = '%s.%s' % (filename, extension) if extension else filename
    return os.path.join(dir_path, filename)

  @classmethod
  def get_file_name(cls, prefix: str = '', name: str = '', suffix: str = '', extension: str = '') -> str:
    """
    生成文件名

    Args:
      prefix: 前缀
      name: 名称，默认为时间戳
      suffix: 后缀
      extension: 文件扩展名

    Returns:
      完整文件名
    """
    file_name = name if name else int(time.time() * 1000)
    if prefix:
      file_name = '%s-%s' % (prefix, file_name)
    if suffix:
      file_name = '%s-%s' % (file_name, suffix)
    if extension:
      file_name = '%s.%s' % (file_name, extension)
    return file_name

  @classmethod
  def get_abs_path(cls, root_dir: str, path: str) -> str:
    """
    获取文件的绝对路径

    Args:
      root_dir: 根目录
      path: 相对路径

    Returns:
      文件绝对路径
    """
    cur_path = os.path.realpath(__file__)
    root_path = os.path.join(cur_path.split(root_dir)[0], root_dir)
    return os.path.join(root_path, path)

  @classmethod
  def get_abs_file(cls, options: dict | str | bool) -> str:
    """
    获取文件绝对路径（支持多种输入格式）

    Args:
      options: 配置选项，可以是：
        - True: 生成UUID命名的临时文件
        - str: 直接作为绝对路径
        - dict: 包含配置的字典

    Returns:
      文件绝对路径
    """
    if options is True:
      options = {
        'filename': str(uuid.uuid4()) + '.txt',
      }

    if isinstance(options, str):
      options = {
        'absfile': options,
      }

    absfile: str = options.get("absfile") or ''
    if absfile:
      return absfile

    absdir: str | list[str] = options.get("absdir") or ''
    extension: str = options.get("extension") or 'txt'
    default_name: str = str(uuid.uuid4())
    filename: str = options.get("filename", default_name)
    name, ext = os.path.splitext(filename)
    ext = ext.lstrip('.') if ext else extension

    if absdir:
      absdir = absdir if isinstance(absdir, list) else [absdir]
      return os.path.join(*absdir, f'{name}.{ext}')

    options.setdefault('subdir', 'temp')
    subdir: str | list[str] = options.get("subdir")
    return File.get_blues_file_path(subdir, name, ext)

  @classmethod
  def exists(cls, path: str) -> bool:
    """
    检查目录或文件是否存在

    Args:
      path: 路径

    Returns:
      是否存在
    """
    return os.path.exists(path)

  @classmethod
  def is_dir_empty(cls, dir_path: str) -> bool:
    """
    检查目录是否为空

    Args:
      dir_path: 目录路径

    Returns:
      是否为空目录
    """
    return not bool(os.listdir(dir_path))

  @classmethod
  def filter_exists(cls, files: list[str]) -> list[str]:
    """
    过滤出存在的文件

    Args:
      files: 文件路径列表

    Returns:
      存在的文件路径列表
    """
    exists_files = []
    for file in files:
      if not cls.exists(file):
        continue
      exists_files.append(file)
    return exists_files

  @classmethod
  def makedirs(cls, dir_path: str) -> str:
    """
    创建目录（支持多级目录）

    Args:
      dir_path: 目录路径

    Returns:
      创建的目录路径
    """
    if not cls.exists(dir_path):
      os.makedirs(dir_path)
    return dir_path

  @classmethod
  def readfiles(cls, dir_path: str) -> list[str]:
    """
    读取目录中的文件列表（不递归子目录）

    Args:
      dir_path: 目录路径

    Returns:
      文件完整路径列表
    """
    file_list = []
    for root, dirs, files in os.walk(dir_path):
      for file in files:
        file_list.append(os.path.join(root, file))
    return file_list

  @classmethod
  def wait(cls, item_path: str, timeout: int | float = 1, interval: int | float = 1) -> bool:
    """
    等待文件或目录存在

    Args:
      item_path: 文件或目录路径
      timeout: 超时时间（秒），默认为1秒
      interval: 检查间隔（秒），默认为1秒

    Returns:
      是否在超时前存在
    """
    start_time = time.time()
    while not cls.exists(item_path) and time.time() - start_time < timeout:
      DateTimeManager.count_down({
        'duration': interval,
        'title': f'Waiting for {item_path} to exist'
      })
    return cls.exists(item_path)

  @classmethod
  def get_extension(cls, file_path: str, keep_dot: bool = False) -> str:
    """
    从文件路径获取扩展名

    Args:
      file_path: 文件完整路径/文件名
      keep_dot: 是否保留前面的点，默认False不带点

    Returns:
      扩展名，无后缀返回空字符串
    """
    suffix = Path(file_path).suffix
    if keep_dot:
      return suffix
    return suffix.lstrip(".")

  @classmethod
  def get_full_suffixes(cls, file_path: str) -> list[str]:
    """
    获取全部多级后缀

    Args:
      file_path: 文件路径

    Returns:
      后缀列表，例如 xxx.tar.gz -> ['.tar', '.gz']
    """
    return Path(file_path).suffixes

  @classmethod
  def is_dot_path(cls, file_path: str) -> bool:
    file_path = os.fspath(file_path)
    if '/' in file_path or '\\' in file_path:
      return False
    base, ext = os.path.splitext(file_path)
    return '.' in base

  @classmethod
  def ensure_extension(cls, file_path: str, extension: str) -> str:
    file_path = os.fspath(file_path)
    base, has_ext = os.path.splitext(file_path)
    if not has_ext:
      ext = extension if extension.startswith('.') else f'.{extension}'
      file_path += ext
    return file_path

  @classmethod
  def get_standard_path(cls, file_path: str, root_path: str = '', extension: str = '') -> str:
    file_path = os.fspath(file_path)
    if cls.is_dot_path(file_path):
      file_path = '/'.join(file_path.split('.'))

    if not os.path.isabs(file_path):
      root = root_path or cls.get_project_home()
      if root:
        file_path = os.path.join(root, file_path)

    return cls.ensure_extension(file_path, extension or 'txt')
