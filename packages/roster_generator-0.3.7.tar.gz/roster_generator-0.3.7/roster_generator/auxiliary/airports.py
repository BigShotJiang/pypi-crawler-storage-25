"""
Airport Catalogue

Extracts the unique set of airports that appear in the Markov transition
table (as departure or arrival) and enriches each entry with:

  - Rolling capacity (rolling_capacity): maximum observed 60-minute
    movement window across the full schedule period.

  - Burst capacity (burst_capacity): maximum observed 5-minute movement
    window across the full schedule period.

Output:
  - airports{suffix}.csv
      columns: airport_id, rolling_capacity, burst_capacity
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from roster_generator.config import PipelineConfig
from roster_generator.output import (
    DEFAULT_OUTPUT_MODE,
    OutputConfig,
    add_output_arguments,
    reset_log_file,
    roster_print,
)
from roster_generator.time_window import (
    DEFAULT_REFTZ,
    DEFAULT_WINDOW_LENGTH_HOURS,
    parse_datetime_series_to_reftz,
    shift_series_by_window_start,
)

# --- Column aliases ---

DEP_COL = "DEP_ICAO"
ARR_COL = "ARR_ICAO"
STD_COL = "STD_REFTZ"
STA_COL = "STA_REFTZ"
AIRLINE_COL = "AC_OPER"
AC_REG_COL = "AC_REG"



# --- Capacity computation ---

def _compute_capacities(
    schedule_df: pd.DataFrame,
    airports: list[str],
    *,
    reftz: str = DEFAULT_REFTZ,
    window_start_mins: int = 0,
    window_length_mins: int = DEFAULT_WINDOW_LENGTH_HOURS * 60,
    output_config: OutputConfig | None = None,
) -> pd.DataFrame:
    """Compute maximum rolling 60-minute and 5-minute movement capacities.

    Both departures and arrivals are combined into a single movement flow.
    Capacities are derived from the worst observed day across the entire
    schedule period.

    Parameters
    ----------
    schedule_df : pandas.DataFrame
        Full cleaned schedule with ``STD_REFTZ`` and ``STA_REFTZ`` columns.
    airports : list of str
        ICAO codes for which capacities should be computed.

    Returns
    -------
    pandas.DataFrame
        Columns: ``airport_id``, ``rolling_capacity``, ``burst_capacity``.
        Airports with no observed traffic receive a floor value of 1 for
        both columns.
    """
    roster_print("[Airports] Computing capacities (max rolling 60 min & 5 min)...", config=output_config)

    # Merge departures and arrivals into one movement stream
    deps = schedule_df[[DEP_COL, STD_COL]].dropna().copy()
    deps.columns = ["airport", "ts"]
    arrs = schedule_df[[ARR_COL, STA_COL]].dropna().copy()
    arrs.columns = ["airport", "ts"]

    all_moves = pd.concat([deps, arrs], ignore_index=True)
    all_moves["ts"] = parse_datetime_series_to_reftz(all_moves["ts"], reftz)
    all_moves.dropna(subset=["ts"], inplace=True)
    all_moves["ts_shifted"] = shift_series_by_window_start(all_moves["ts"], window_start_mins)

    # Restrict to airports of interest
    all_moves = all_moves[all_moves["airport"].isin(set(airports))]

    if all_moves.empty:
        return pd.DataFrame({
            "airport_id": airports,
            "rolling_capacity": 1,
            "burst_capacity": 1,
        })

    # Bin into 5-minute slots within each shifted REFTZ day.
    all_moves["date"] = all_moves["ts_shifted"].dt.date
    all_moves["minute_of_day"] = all_moves["ts_shifted"].dt.hour * 60 + all_moves["ts_shifted"].dt.minute
    if int(window_length_mins) < 24 * 60:
        all_moves = all_moves[all_moves["minute_of_day"] < int(window_length_mins)]
        if all_moves.empty:
            return pd.DataFrame({
                "airport_id": airports,
                "rolling_capacity": 1,
                "burst_capacity": 1,
            })
    all_moves["bin5"] = all_moves["minute_of_day"] // 5

    # Count movements per (airport, date, bin5)
    counts = all_moves.groupby(["airport", "date", "bin5"], sort=False).size()

    n_bins = max(1, int(window_length_mins) // 5)
    # Wide matrix: index = (airport, date), columns = bin5 [0..n_bins-1]
    daily_matrix = counts.unstack("bin5", fill_value=0)
    daily_matrix = daily_matrix.reindex(columns=range(n_bins), fill_value=0)

    # Burst capacity: max single 5-min bin per airport
    burst_caps = daily_matrix.max(axis=1).groupby("airport").max()

    # Rolling capacity: max 60-min rolling sum (window = 12 x 5-min bins)
    rolling_max = (
        daily_matrix.T
        .rolling(window=12, min_periods=12)
        .sum()
        .T
        .fillna(0)
        .max(axis=1)
        .groupby("airport")
        .max()
    )

    capacity_df = pd.DataFrame({
        "rolling_capacity": rolling_max,
        "burst_capacity": burst_caps,
    }).reset_index().rename(columns={"airport": "airport_id"})

    # Left-join against the full airport list; fill missing with floor = 1
    result = pd.DataFrame({"airport_id": airports}).merge(
        capacity_df, on="airport_id", how="left"
    )
    result["rolling_capacity"] = result["rolling_capacity"].fillna(1).astype(int).clip(lower=1)
    result["burst_capacity"] = result["burst_capacity"].fillna(1).astype(int).clip(lower=1)

    top5 = result.nlargest(5, "rolling_capacity")
    roster_print(
        f"[Airports] Computed capacities for {len(result)} airports. "
        f"Top 5 by rolling cap: "
        f"{top5[['airport_id', 'rolling_capacity', 'burst_capacity']].values.tolist()}",
        config=output_config,
    )

    return result


def _require_columns(df: pd.DataFrame, required: list[str], label: str) -> None:
    """Raise a clear error when required columns are missing."""
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns in {label}: {missing}")


# --- Public API ---

def generate_airports(config: PipelineConfig) -> None:
    """Extract the airport catalogue from the Markov table and schedule.

    Steps:

    1. Load the Markov CSV and collect all unique departure/arrival airport
       codes.
    2. If the schedule file is available, compute curfew hours and movement
       capacities for each airport.
    3. Save the result to ``output_dir/airports{suffix}.csv``.

    Parameters
    ----------
    config : PipelineConfig
        Paths and parameters for the pipeline.

    Raises
    ------
    FileNotFoundError
        If the Markov analysis file does not exist.
    """
    roster_print("[Airports] --- AIRPORT CATALOGUE ---", config=config)

    markov_path = config.analysis_path("markov")
    output_path = config.output_path("airports")

    if not markov_path.exists():
        raise FileNotFoundError(f"[Airports] Markov file not found: {markov_path}")

    # 1. Extract unique airports from the Markov table
    roster_print(f"[Airports] Markov file: {markov_path}", config=config)
    markov_df = pd.read_csv(markov_path)

    dep_airports = set(markov_df[DEP_COL].dropna().unique())
    arr_airports = set(markov_df[ARR_COL].dropna().unique())
    all_airports = sorted(dep_airports | arr_airports)

    roster_print(f"[Airports] {len(all_airports)} unique airports found in Markov table", config=config)

    airports_df = pd.DataFrame({"airport_id": all_airports})

    # 2. Enrich with curfews and capacities from the schedule
    if config.schedule_file.exists():
        roster_print(f"[Airports] Schedule: {config.schedule_file}", config=config)
        schedule_df = pd.read_csv(config.schedule_file)
        _require_columns(schedule_df, [DEP_COL, ARR_COL, STD_COL, STA_COL], "schedule")

        # Capacities
        capacity_df = _compute_capacities(
            schedule_df,
            all_airports,
            reftz=config.reftz,
            window_start_mins=config.window_start_mins,
            window_length_mins=config.window_length_mins,
            output_config=config,
        )
        airports_df = airports_df.merge(capacity_df, on="airport_id", how="left")
        airports_df["rolling_capacity"] = (
            airports_df["rolling_capacity"].fillna(1).astype(int).clip(lower=1)
        )
        airports_df["burst_capacity"] = (
            airports_df["burst_capacity"].fillna(1).astype(int).clip(lower=1)
        )
    else:
        roster_print(f"[Airports] Warning: schedule file not found ({config.schedule_file}). " "Skipping capacity computation.", config=config)
        airports_df["rolling_capacity"] = 1
        airports_df["burst_capacity"] = 1

    # 3. Persist
    config.output_dir.mkdir(parents=True, exist_ok=True)
    airports_df.to_csv(output_path, index=False)

    roster_print(f"[Airports] Saved: {output_path} ({len(airports_df)} airports)", config=config)
    roster_print("[Airports] --- SUCCESS ---", config=config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Airport catalogue builder")
    parser.add_argument("--schedule", type=str, required=True, help="Path to schedule CSV")
    parser.add_argument("--analysis-dir", type=str, required=True, help="Analysis output directory")
    parser.add_argument("--output-dir", type=str, required=True, help="Final output directory")
    parser.add_argument("--suffix", type=str, default="", help="Suffix for output filenames")
    parser.add_argument("--seed", type=int, default=42, help="RNG seed")
    add_output_arguments(parser)
    args = parser.parse_args()

    output_mode = args.output_mode or DEFAULT_OUTPUT_MODE
    cfg = PipelineConfig(
        schedule_file=Path(args.schedule),
        analysis_dir=Path(args.analysis_dir),
        output_dir=Path(args.output_dir),
        seed=args.seed,
        suffix=f"_{args.suffix}" if args.suffix else "",
        output_mode=output_mode,
        log_file=args.log_file,
    )
    reset_log_file(config=cfg)
    generate_airports(cfg)
