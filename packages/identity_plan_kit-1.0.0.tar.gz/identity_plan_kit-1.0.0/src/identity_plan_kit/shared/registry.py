"""Backward-compatible shim. Canonical location is ``identity_plan_kit.registry``.

Per Hexagonal/Clean architecture, ``shared/`` must not import from feature
packages (``auth``, ``rbac``, ``plans``). The registry — which references
every feature's models/entities/DTOs — therefore lives at
``identity_plan_kit.registry``. This module re-exports it so existing
consumers continue to work.
"""

from identity_plan_kit.registry import (
    DTORegistry,
    EntityRegistry,
    ExtensionConfig,
    ModelRegistry,
    get_default_extension_config,
)

__all__ = [
    "DTORegistry",
    "EntityRegistry",
    "ExtensionConfig",
    "ModelRegistry",
    "get_default_extension_config",
]
