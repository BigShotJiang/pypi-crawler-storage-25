"""Backward-compatible shim. Canonical location is ``identity_plan_kit.exception_handlers``.

Per Hexagonal/Clean architecture, ``shared/`` must not import from feature
packages (``auth``, ``rbac``, ``plans``). The handler-registration code that
binds feature-specific exceptions to FastAPI handlers therefore lives at
``identity_plan_kit.exception_handlers``. This module re-exports it so
existing consumers (``from identity_plan_kit.shared.exception_handlers
import register_exception_handlers``) keep working.
"""

from identity_plan_kit.exception_handlers import (
    base_error_handler,
    create_error_response,
    generic_exception_handler,
    http_exception_handler,
    register_exception_handlers,
    validation_exception_handler,
)

__all__ = [
    "base_error_handler",
    "create_error_response",
    "generic_exception_handler",
    "http_exception_handler",
    "register_exception_handlers",
    "validation_exception_handler",
]
