"""
SQLAdmin ModelViews for IdentityPlanKit.

Provides pre-configured admin views for all models:
- Auth: Users, UserProviders, RefreshTokens
- RBAC: Roles, Permissions, RolePermissions
- Plans: Plans, Features, PlanLimits, PlanPermissions, UserPlans, FeatureUsage
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sqladmin import Admin, ModelView
from sqlalchemy.exc import IntegrityError
from starlette.requests import Request
from wtforms import validators

from identity_plan_kit.auth.models.refresh_token import RefreshTokenModel
from identity_plan_kit.auth.models.user import UserModel
from identity_plan_kit.auth.models.user_provider import UserProviderModel
from identity_plan_kit.config import Environment
from identity_plan_kit.plans.models.feature import FeatureModel
from identity_plan_kit.plans.models.feature_usage import FeatureUsageModel
from identity_plan_kit.plans.models.plan import PlanModel
from identity_plan_kit.plans.models.plan_limit import PlanLimitModel
from identity_plan_kit.plans.models.plan_permission import PlanPermissionModel
from identity_plan_kit.plans.models.user_plan import UserPlanModel
from identity_plan_kit.rbac.models.permission import PermissionModel
from identity_plan_kit.rbac.models.role import RoleModel
from identity_plan_kit.rbac.models.role_permission import RolePermissionModel
from identity_plan_kit.shared.exceptions import BaseError, ValidationError
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)

if TYPE_CHECKING:
    from fastapi import FastAPI
    from sqlalchemy.ext.asyncio import AsyncEngine


# =============================================================================
# ERROR HANDLING UTILITIES
# =============================================================================


def _parse_integrity_error(exc: IntegrityError) -> str:
    """
    Parse IntegrityError to provide user-friendly error messages.

    Handles common constraint violations:
    - NOT NULL violations
    - UNIQUE constraint violations
    - FOREIGN KEY violations
    - CHECK constraint violations

    Note: Messages are intentionally generic to avoid exposing database schema details.
    """
    error_msg = str(exc.orig) if exc.orig else str(exc)

    # NOT NULL violation
    if "NotNullViolationError" in error_msg or "null value in column" in error_msg:
        return "A required field is missing. Please ensure all required fields are filled."

    # UNIQUE constraint violation
    if "UniqueViolationError" in error_msg or "duplicate key" in error_msg:
        # Check for common patterns to provide slightly more specific messages
        if "email" in error_msg.lower():
            return "This email address is already in use."
        if "code" in error_msg.lower():
            return "This code is already in use."
        return "A record with these values already exists. Please use unique values."

    # FOREIGN KEY violation
    if "ForeignKeyViolationError" in error_msg or "foreign key constraint" in error_msg:
        if "is still referenced" in error_msg:
            return "Cannot delete: this record is still referenced by other records."
        return "Invalid reference: the selected related record does not exist."

    # CHECK constraint violation
    if "CheckViolationError" in error_msg or "check constraint" in error_msg:
        return "Invalid value: does not meet validation requirements."

    # Generic fallback - no specific error details exposed
    return "A database constraint was violated. Please check your input and try again."


class AdminValidationError(ValidationError):
    """Validation error raised by admin operations."""

    code = "ADMIN_VALIDATION_ERROR"


class AdminSetupError(BaseError):
    """Raised when admin panel setup is misconfigured (e.g., no auth in production)."""

    code = "ADMIN_SETUP_ERROR"
    message = "Admin panel setup is misconfigured"
    status_code = 500


class BaseAdminView(ModelView):
    """
    Base admin view with common error handling and permission checking.

    Features:
    - Catches IntegrityErrors during create/update/delete operations
      and converts them to user-friendly error messages.
    - Enforces role-based permissions:
      - Superadmin: Full access (create, edit, delete)
      - Admin: View-only access

    The permission checking uses the AdminAuthBackend from the request's
    app state when available.

    Note: UI button visibility is controlled via custom templates that check
    request.session['admin_role']. This is thread-safe because SQLAdmin
    ModelView instances are singletons shared across requests.
    """

    def _get_auth_backend(self, request: Request) -> Any | None:
        """Get the authentication backend from the SQLAdmin sub-app on the request."""
        # SQLAdmin mounts as a sub-application, so request.app is the Admin's
        # internal Starlette app. setup_admin stores the backend on its state.
        app = getattr(request, "app", None)
        if app is None:
            return None
        backend = getattr(app, "authentication_backend", None)
        if backend is not None:
            return backend
        return getattr(getattr(app, "state", None), "_admin_auth_backend", None)

    def _is_superadmin(self, request: Request) -> bool:
        """Check if current user is superadmin."""
        auth_backend = self._get_auth_backend(request)
        if auth_backend and hasattr(auth_backend, "is_superadmin"):
            result = auth_backend.is_superadmin(request)
            logger.debug(
                "_is_superadmin_check",
                auth_backend_found=True,
                is_superadmin=result,
                admin_role=request.session.get("admin_role"),
            )
            return result
        # SECURITY: Deny by default when no auth backend is configured
        logger.warning(
            "_is_superadmin_no_auth_backend",
            message="No auth backend found, denying access for security",
        )
        return False

    def is_accessible(self, request: Request) -> bool:
        """
        Check if user can access this view (list/details).

        Requires an authenticated session. Both superadmin and admin can view;
        write actions are gated by insert_model/update_model/delete_model
        which call _is_superadmin directly. Templates additionally hide write
        buttons via is_superadmin_user(request).
        """
        return bool(request.session.get("admin_authenticated"))

    async def on_model_change(
        self, data: dict[str, Any], model: Any, is_created: bool, request: Request
    ) -> None:
        """Called before model is saved. Override for custom validation."""

    async def insert_model(self, request: Request, data: dict[str, Any]) -> Any:
        """Insert a new model instance with error handling and permission check."""
        if not self._is_superadmin(request):
            raise AdminValidationError("Permission denied: Only superadmin can create records.")
        try:
            return await super().insert_model(request, data)
        except IntegrityError as exc:
            raise AdminValidationError(_parse_integrity_error(exc)) from exc

    async def update_model(self, request: Request, pk: Any, data: dict[str, Any]) -> Any:
        """Update an existing model instance with error handling and permission check."""
        if not self._is_superadmin(request):
            raise AdminValidationError("Permission denied: Only superadmin can edit records.")
        try:
            return await super().update_model(request, pk, data)
        except IntegrityError as exc:
            raise AdminValidationError(_parse_integrity_error(exc)) from exc

    async def delete_model(self, request: Request, pk: Any) -> None:
        """Delete a model instance with error handling and permission check."""
        if not self._is_superadmin(request):
            raise AdminValidationError("Permission denied: Only superadmin can delete records.")
        try:
            return await super().delete_model(request, pk)
        except IntegrityError as exc:
            raise AdminValidationError(_parse_integrity_error(exc)) from exc


# =============================================================================
# AUTH ADMIN VIEWS
# =============================================================================


class UserAdmin(BaseAdminView, model=UserModel):
    """Admin view for User management."""

    name = "User"
    name_plural = "Users"
    icon = "fa-solid fa-user"
    category = "Authentication"

    # List view configuration
    column_list = [
        UserModel.id,
        UserModel.email,
        UserModel.role,
        UserModel.is_active,
        UserModel.is_verified,
        UserModel.created_at,
    ]
    column_searchable_list = [UserModel.email]
    column_sortable_list = [
        UserModel.email,
        UserModel.is_active,
        UserModel.is_verified,
        UserModel.created_at,
    ]
    column_default_sort = [(UserModel.created_at, True)]

    # Detail view configuration
    column_details_list = [
        UserModel.id,
        UserModel.email,
        UserModel.role,
        UserModel.is_active,
        UserModel.is_verified,
        UserModel.user_metadata,
        UserModel.created_at,
        UserModel.updated_at,
        UserModel.providers,
    ]

    # Form configuration - use relationship for dropdown selection
    form_columns = [
        UserModel.email,
        UserModel.role,  # Use relationship for proper dropdown
        UserModel.is_active,
        UserModel.is_verified,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "role": {
            "fields": ("code", "name"),
            "order_by": "name",
        }
    }

    # Form validation
    form_args = {
        "email": {"validators": [validators.DataRequired(), validators.Email()]},
        "role": {"validators": [validators.DataRequired()]},
    }

    # Export configuration
    column_export_list = [
        UserModel.id,
        UserModel.email,
        UserModel.role_id,
        UserModel.is_active,
        UserModel.is_verified,
        UserModel.created_at,
    ]
    can_export = True

    # Formatting
    column_formatters = {
        UserModel.is_active: lambda m, a: "Active" if m.is_active else "Inactive",
        UserModel.is_verified: lambda m, a: "Verified" if m.is_verified else "Unverified",
    }


class UserProviderAdmin(BaseAdminView, model=UserProviderModel):
    """Admin view for OAuth Provider links."""

    name = "OAuth Provider"
    name_plural = "OAuth Providers"
    icon = "fa-solid fa-link"
    category = "Authentication"

    column_list = [
        UserProviderModel.id,
        UserProviderModel.user,
        UserProviderModel.code,
        UserProviderModel.external_user_id,
    ]
    column_searchable_list = [UserProviderModel.external_user_id]
    column_sortable_list = [UserProviderModel.code]

    column_details_list = [
        UserProviderModel.id,
        UserProviderModel.user,
        UserProviderModel.code,
        UserProviderModel.external_user_id,
    ]

    # Form configuration - use relationship for proper dropdown
    form_columns = [
        UserProviderModel.user,  # Use relationship for proper dropdown
        UserProviderModel.code,
        UserProviderModel.external_user_id,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "user": {
            "fields": ("email",),
            "order_by": "email",
        }
    }

    # Form validation
    form_args = {
        "user": {"validators": [validators.DataRequired()]},
        "code": {"validators": [validators.DataRequired()]},
        "external_user_id": {"validators": [validators.DataRequired()]},
    }

    # Provider code choices
    form_choices = {
        "code": [
            ("google", "Google"),
            ("github", "GitHub"),
            ("microsoft", "Microsoft"),
            ("apple", "Apple"),
        ]
    }


class RefreshTokenAdmin(BaseAdminView, model=RefreshTokenModel):
    """Admin view for Refresh Token management."""

    name = "Refresh Token"
    name_plural = "Refresh Tokens"
    icon = "fa-solid fa-key"
    category = "Authentication"

    column_list = [
        RefreshTokenModel.id,
        RefreshTokenModel.user,
        RefreshTokenModel.expires_at,
        RefreshTokenModel.revoked_at,
        RefreshTokenModel.created_at,
        RefreshTokenModel.ip_address,
    ]
    column_sortable_list = [
        RefreshTokenModel.expires_at,
        RefreshTokenModel.created_at,
    ]
    column_default_sort = [(RefreshTokenModel.created_at, True)]

    column_details_list = [
        RefreshTokenModel.id,
        RefreshTokenModel.user,
        RefreshTokenModel.token_hash,
        RefreshTokenModel.expires_at,
        RefreshTokenModel.created_at,
        RefreshTokenModel.revoked_at,
        RefreshTokenModel.user_agent,
        RefreshTokenModel.ip_address,
    ]

    # Form configuration
    form_columns = [
        RefreshTokenModel.user,
        RefreshTokenModel.token_hash,
        RefreshTokenModel.expires_at,
        RefreshTokenModel.revoked_at,
        RefreshTokenModel.user_agent,
        RefreshTokenModel.ip_address,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "user": {
            "fields": ("email",),
            "order_by": "email",
        }
    }

    # Form validation
    form_args = {
        "user": {"validators": [validators.DataRequired()]},
        "token_hash": {"validators": [validators.DataRequired()]},
        "expires_at": {"validators": [validators.DataRequired()]},
    }


# =============================================================================
# RBAC ADMIN VIEWS
# =============================================================================


class RoleAdmin(BaseAdminView, model=RoleModel):
    """Admin view for Role management."""

    name = "Role"
    name_plural = "Roles"
    icon = "fa-solid fa-user-shield"
    category = "RBAC"

    column_list = [
        RoleModel.id,
        RoleModel.code,
        RoleModel.name,
    ]
    column_searchable_list = [RoleModel.code, RoleModel.name]
    column_sortable_list = [RoleModel.code, RoleModel.name]

    column_details_list = [
        RoleModel.id,
        RoleModel.code,
        RoleModel.name,
        RoleModel.permissions,
    ]

    form_columns = [
        RoleModel.code,
        RoleModel.name,
    ]

    # Form validation
    form_args = {
        "code": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
        "name": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
    }


class PermissionAdmin(BaseAdminView, model=PermissionModel):
    """Admin view for Permission management."""

    name = "Permission"
    name_plural = "Permissions"
    icon = "fa-solid fa-lock"
    category = "RBAC"

    column_list = [
        PermissionModel.id,
        PermissionModel.code,
        PermissionModel.type,
    ]
    column_searchable_list = [PermissionModel.code]
    column_sortable_list = [PermissionModel.code, PermissionModel.type]

    column_details_list = [
        PermissionModel.id,
        PermissionModel.code,
        PermissionModel.type,
    ]

    form_columns = [
        PermissionModel.code,
        PermissionModel.type,
    ]

    form_choices = {
        "type": [
            ("role", "Role Permission"),
            ("plan", "Plan Permission"),
        ]
    }

    # Form validation
    form_args = {
        "code": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
        "type": {"validators": [validators.DataRequired()]},
    }


class RolePermissionAdmin(BaseAdminView, model=RolePermissionModel):
    """Admin view for Role-Permission assignments."""

    name = "Role Permission"
    name_plural = "Role Permissions"
    icon = "fa-solid fa-user-lock"
    category = "RBAC"

    column_list = [
        RolePermissionModel.id,
        RolePermissionModel.role,
        RolePermissionModel.permission,
    ]
    column_sortable_list = [RolePermissionModel.role_id, RolePermissionModel.permission_id]

    column_details_list = [
        RolePermissionModel.id,
        RolePermissionModel.role,
        RolePermissionModel.permission,
    ]

    # Form configuration - use relationships for proper dropdowns
    form_columns = [
        RolePermissionModel.role,
        RolePermissionModel.permission,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "role": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
        "permission": {
            "fields": ("code",),
            "order_by": "code",
        },
    }

    # Form validation
    form_args = {
        "role": {"validators": [validators.DataRequired()]},
        "permission": {"validators": [validators.DataRequired()]},
    }


# =============================================================================
# PLAN ADMIN VIEWS
# =============================================================================


class PlanAdmin(BaseAdminView, model=PlanModel):
    """Admin view for Subscription Plan management."""

    name = "Plan"
    name_plural = "Plans"
    icon = "fa-solid fa-credit-card"
    category = "Plans"

    column_list = [
        PlanModel.id,
        PlanModel.code,
        PlanModel.name,
    ]
    column_searchable_list = [PlanModel.code, PlanModel.name]
    column_sortable_list = [PlanModel.code, PlanModel.name]

    column_details_list = [
        PlanModel.id,
        PlanModel.code,
        PlanModel.name,
        PlanModel.permissions,
        PlanModel.limits,
    ]

    form_columns = [
        PlanModel.code,
        PlanModel.name,
    ]

    # Form validation
    form_args = {
        "code": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
        "name": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
    }


class FeatureAdmin(BaseAdminView, model=FeatureModel):
    """Admin view for Feature management."""

    name = "Feature"
    name_plural = "Features"
    icon = "fa-solid fa-puzzle-piece"
    category = "Plans"

    column_list = [
        FeatureModel.id,
        FeatureModel.code,
        FeatureModel.name,
    ]
    column_searchable_list = [FeatureModel.code, FeatureModel.name]
    column_sortable_list = [FeatureModel.code, FeatureModel.name]

    column_details_list = [
        FeatureModel.id,
        FeatureModel.code,
        FeatureModel.name,
    ]

    form_columns = [
        FeatureModel.code,
        FeatureModel.name,
    ]

    # Form validation
    form_args = {
        "code": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
        "name": {"validators": [validators.DataRequired(), validators.Length(max=255)]},
    }


class PlanLimitAdmin(BaseAdminView, model=PlanLimitModel):
    """Admin view for Plan Limit management."""

    name = "Plan Limit"
    name_plural = "Plan Limits"
    icon = "fa-solid fa-gauge-high"
    category = "Plans"

    column_list = [
        PlanLimitModel.id,
        PlanLimitModel.plan,
        PlanLimitModel.feature,
        PlanLimitModel.feature_limit,
        PlanLimitModel.period,
    ]
    column_sortable_list = [
        PlanLimitModel.plan_id,
        PlanLimitModel.feature_id,
        PlanLimitModel.feature_limit,
    ]

    column_details_list = [
        PlanLimitModel.id,
        PlanLimitModel.plan,
        PlanLimitModel.feature,
        PlanLimitModel.feature_limit,
        PlanLimitModel.period,
    ]

    # Form configuration - use relationships for proper dropdowns
    form_columns = [
        PlanLimitModel.plan,
        PlanLimitModel.feature,
        PlanLimitModel.feature_limit,
        PlanLimitModel.period,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "plan": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
        "feature": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
    }

    form_choices = {
        "period": [
            ("daily", "Daily"),
            ("monthly", "Monthly"),
            ("lifetime", "Lifetime"),
        ]
    }

    # Form validation
    form_args = {
        "plan": {"validators": [validators.DataRequired()]},
        "feature": {"validators": [validators.DataRequired()]},
        "feature_limit": {"validators": [validators.DataRequired()]},
    }

    column_formatters = {
        PlanLimitModel.feature_limit: lambda m, a: "Unlimited"
        if m.feature_limit == -1
        else str(m.feature_limit),
    }


class PlanPermissionAdmin(BaseAdminView, model=PlanPermissionModel):
    """Admin view for Plan-Permission assignments."""

    name = "Plan Permission"
    name_plural = "Plan Permissions"
    icon = "fa-solid fa-handshake"
    category = "Plans"

    column_list = [
        PlanPermissionModel.id,
        PlanPermissionModel.plan,
        PlanPermissionModel.permission,
    ]
    column_sortable_list = [PlanPermissionModel.plan_id, PlanPermissionModel.permission_id]

    column_details_list = [
        PlanPermissionModel.id,
        PlanPermissionModel.plan,
        PlanPermissionModel.permission,
    ]

    # Form configuration - use relationships for proper dropdowns
    form_columns = [
        PlanPermissionModel.plan,
        PlanPermissionModel.permission,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "plan": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
        "permission": {
            "fields": ("code",),
            "order_by": "code",
        },
    }

    # Form validation
    form_args = {
        "plan": {"validators": [validators.DataRequired()]},
        "permission": {"validators": [validators.DataRequired()]},
    }


class UserPlanAdmin(BaseAdminView, model=UserPlanModel):
    """Admin view for User Plan subscriptions."""

    name = "User Plan"
    name_plural = "User Plans"
    icon = "fa-solid fa-user-tag"
    category = "Plans"

    column_list = [
        UserPlanModel.id,
        UserPlanModel.user_id,
        UserPlanModel.plan,
        UserPlanModel.started_at,
        UserPlanModel.ends_at,
    ]
    column_sortable_list = [
        UserPlanModel.started_at,
        UserPlanModel.ends_at,
    ]
    column_default_sort = [(UserPlanModel.started_at, True)]

    column_details_list = [
        UserPlanModel.id,
        UserPlanModel.user_id,
        UserPlanModel.plan,
        UserPlanModel.started_at,
        UserPlanModel.ends_at,
        UserPlanModel.custom_limits,
    ]

    # Form configuration - use relationship for plan dropdown
    # Note: user_id stays as UUID input since users are looked up by ID
    form_columns = [
        UserPlanModel.user_id,
        UserPlanModel.plan,
        UserPlanModel.started_at,
        UserPlanModel.ends_at,
        UserPlanModel.custom_limits,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "plan": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
    }

    # Form validation
    form_args = {
        "user_id": {"validators": [validators.DataRequired()]},
        "plan": {"validators": [validators.DataRequired()]},
        "started_at": {"validators": [validators.DataRequired()]},
        "ends_at": {"validators": [validators.DataRequired()]},
    }


class FeatureUsageAdmin(BaseAdminView, model=FeatureUsageModel):
    """Admin view for Feature Usage tracking."""

    name = "Feature Usage"
    name_plural = "Feature Usage"
    icon = "fa-solid fa-chart-line"
    category = "Plans"

    column_list = [
        FeatureUsageModel.id,
        FeatureUsageModel.user_plan_id,
        FeatureUsageModel.feature,
        FeatureUsageModel.feature_usage,
        FeatureUsageModel.start_period,
        FeatureUsageModel.end_period,
    ]
    column_sortable_list = [
        FeatureUsageModel.feature_usage,
        FeatureUsageModel.start_period,
        FeatureUsageModel.end_period,
    ]
    column_default_sort = [(FeatureUsageModel.start_period, True)]

    column_details_list = [
        FeatureUsageModel.id,
        FeatureUsageModel.user_plan_id,
        FeatureUsageModel.feature,
        FeatureUsageModel.feature_usage,
        FeatureUsageModel.start_period,
        FeatureUsageModel.end_period,
    ]

    # Form configuration
    form_columns = [
        FeatureUsageModel.user_plan_id,
        FeatureUsageModel.feature,
        FeatureUsageModel.feature_usage,
        FeatureUsageModel.start_period,
        FeatureUsageModel.end_period,
    ]

    # AJAX refs for searchable dropdowns
    form_ajax_refs = {
        "feature": {
            "fields": ("code", "name"),
            "order_by": "name",
        },
    }

    # Form validation
    form_args = {
        "user_plan_id": {"validators": [validators.DataRequired()]},
        "feature": {"validators": [validators.DataRequired()]},
        "feature_usage": {"validators": [validators.DataRequired()]},
        "start_period": {"validators": [validators.DataRequired()]},
        "end_period": {"validators": [validators.DataRequired()]},
    }


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def get_all_admin_views() -> list[type[ModelView]]:
    """
    Get all admin views in the recommended order.

    Returns a list of ModelView classes organized by category.
    """
    return [
        # Auth
        UserAdmin,
        UserProviderAdmin,
        RefreshTokenAdmin,
        # RBAC
        RoleAdmin,
        PermissionAdmin,
        RolePermissionAdmin,
        # Plans
        PlanAdmin,
        FeatureAdmin,
        PlanLimitAdmin,
        PlanPermissionAdmin,
        UserPlanAdmin,
        FeatureUsageAdmin,
    ]


def setup_admin(
    app: FastAPI,
    engine: AsyncEngine,
    *,
    title: str = "IdentityPlanKit Admin",
    base_url: str = "/admin",
    authentication_backend: Any | None = None,
    templates_dir: str | None = None,
) -> Admin:
    """
    Set up SQLAdmin with all IdentityPlanKit models.

    Args:
        app: FastAPI application instance
        engine: SQLAlchemy async engine
        title: Admin panel title
        base_url: Base URL for admin panel
        authentication_backend: Optional authentication backend for admin access.
            Use AdminAuthBackend for role-based permissions (superadmin/admin).
        templates_dir: Optional custom templates directory

    Returns:
        Configured Admin instance

    Example:
        from identity_plan_kit.admin import setup_admin, AdminAuthBackend

        # With role-based authentication (recommended):
        auth_backend = AdminAuthBackend(
            secret_key=config.secret_key.get_secret_value(),
            admin_email=config.admin_email,
            admin_password=config.admin_password.get_secret_value(),
            session_factory=kit.db_manager.async_session_factory,
        )
        admin = setup_admin(
            app,
            kit.db_manager.engine,
            authentication_backend=auth_backend,
        )

        # Without authentication (development only):
        admin = setup_admin(app, kit.db_manager.engine)
    """
    # SECURITY: Require authentication backend by default; fail-closed unless the
    # environment is explicitly set to development.
    if authentication_backend is None:
        env_raw = os.getenv("IPK_ENVIRONMENT", Environment.PRODUCTION.value)
        try:
            environment = Environment(env_raw.strip().lower())
        except ValueError:
            environment = Environment.PRODUCTION
        warning_msg = (
            "Admin panel is being set up WITHOUT authentication. "
            "This exposes sensitive user data, tokens, and configuration. "
            "Always provide an authentication_backend outside development."
        )
        if environment != Environment.DEVELOPMENT:
            logger.critical(
                "admin_no_authentication_blocked",
                message="Refusing to start admin panel without authentication outside development",
                base_url=base_url,
                environment=environment.value,
            )
            raise AdminSetupError(
                f"SECURITY ERROR: {warning_msg} "
                "Set IPK_ENVIRONMENT=development to bypass this check (not recommended)."
            )
        logger.warning(
            "admin_no_authentication",
            message=warning_msg,
            base_url=base_url,
        )

    # Use bundled templates for role-based permission UI if no custom templates_dir provided.
    # These templates check is_superadmin_user(request) to hide edit/delete buttons for non-superadmin.
    if templates_dir is None:
        templates_dir = str(Path(__file__).parent / "templates")

    # Build kwargs
    admin_kwargs: dict[str, Any] = {
        "app": app,
        "engine": engine,
        "title": title,
        "base_url": base_url,
        "templates_dir": templates_dir,
    }
    if authentication_backend is not None:
        admin_kwargs["authentication_backend"] = authentication_backend

    admin = Admin(**admin_kwargs)

    # Store auth backend on the Admin's internal Starlette app for permission checking.
    # SQLAdmin creates an internal Starlette app (admin.admin) that handles /admin/* requests.
    # When views call request.app, they get this internal app, not the FastAPI app.
    if authentication_backend is not None:
        admin.admin.state._admin_auth_backend = authentication_backend

    # Add Jinja2 global function for role-based permission checking in templates.
    # This is thread-safe because it checks request.session on each call,
    # unlike modifying ModelView instance attributes which are shared.
    def is_superadmin_user(request: Request) -> bool:
        """Check if current user is superadmin (for use in templates)."""
        if authentication_backend and hasattr(authentication_backend, "is_superadmin"):
            return authentication_backend.is_superadmin(request)
        # SECURITY: Deny by default when no auth backend is configured
        return False

    admin.templates.env.globals["is_superadmin_user"] = is_superadmin_user

    for view in get_all_admin_views():
        admin.add_view(view)

    return admin
