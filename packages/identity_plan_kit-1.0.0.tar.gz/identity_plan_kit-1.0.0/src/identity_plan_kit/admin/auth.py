"""
SQLAdmin Authentication Backend with role-based permissions.

Provides authentication for the SQLAdmin panel with two roles:
- Superadmin: Full permissions (create, edit, delete) - configured via env vars
- Admin: View-only permissions - created by superadmin in the database

Usage:
    from identity_plan_kit.admin import AdminAuthBackend, setup_admin

    # Create authentication backend
    auth_backend = AdminAuthBackend(
        secret_key=config.secret_key.get_secret_value(),
        admin_email=config.admin_email,
        admin_password=config.admin_password.get_secret_value(),
        session_factory=kit.db_manager.async_session_factory,
    )

    # Setup admin with authentication
    admin = setup_admin(
        app,
        kit.db_manager.engine,
        authentication_backend=auth_backend,
    )
"""

from __future__ import annotations

import secrets
from enum import Enum
from typing import TYPE_CHECKING

from pydantic import SecretStr
from sqladmin.authentication import AuthenticationBackend
from starlette.requests import Request
from starlette.responses import RedirectResponse

from identity_plan_kit.shared.audit import mask_email
from identity_plan_kit.shared.lockout import (
    AccountLockedError,
    LockoutConfig,
    LockoutManager,
)
from identity_plan_kit.shared.logging import get_logger
from identity_plan_kit.shared.state_store import get_state_store

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import async_sessionmaker

logger = get_logger(__name__)


class AdminRole(str, Enum):
    """Admin panel roles with different permission levels."""

    SUPERADMIN = "superadmin"  # Full permissions (env var admin)
    ADMIN = "admin"  # View-only permissions (DB admins created by superadmin)


class AdminAuthBackend(AuthenticationBackend):
    """
    Authentication backend for SQLAdmin with role-based permissions.

    Supports two types of admin users:
    1. Superadmin (from environment variables):
       - Has full permissions: can create, edit, delete all records
       - Credentials set via IPK_ADMIN_EMAIL and IPK_ADMIN_PASSWORD

    2. Admin (from database):
       - Has view-only permissions: can only view records
       - Created by superadmin via the admin panel
       - Must have 'admin' role in the database

    Session data stored:
        - admin_authenticated: bool
        - admin_email: str
        - admin_role: AdminRole value
    """

    def __init__(
        self,
        secret_key: str,
        admin_email: str | None = None,
        admin_password: SecretStr | str | None = None,
        session_factory: async_sessionmaker | None = None,
        lockout_config: LockoutConfig | None = None,
    ) -> None:
        """
        Initialize the admin authentication backend.

        Args:
            secret_key: Secret key for session signing
            admin_email: Superadmin email (from env vars)
            admin_password: Superadmin password (from env vars). Pass either a
                ``SecretStr`` or a plain string; the value is normalised to
                ``SecretStr`` so it does not appear in ``repr()`` or debug logs.
            session_factory: SQLAlchemy async session factory for DB admin lookup
            lockout_config: Optional lockout config (uses defaults otherwise)
        """
        super().__init__(secret_key)
        self._admin_email = admin_email
        if admin_password is None:
            self._admin_password: SecretStr | None = None
        elif isinstance(admin_password, SecretStr):
            self._admin_password = admin_password
        else:
            self._admin_password = SecretStr(admin_password)
        self._session_factory = session_factory
        self._lockout_config = lockout_config or LockoutConfig()
        self._lockout_manager: LockoutManager | None = None

    def _get_lockout_manager(self) -> LockoutManager:
        """Lazily build the lockout manager so the state store is initialised."""
        if self._lockout_manager is None:
            self._lockout_manager = LockoutManager(get_state_store(), self._lockout_config)
        return self._lockout_manager

    async def login(self, request: Request) -> bool:
        """
        Handle login form submission.

        Authenticates against:
        1. Superadmin credentials (from env vars) - gets full permissions
        2. Database users with 'admin' role - gets view-only permissions

        Returns:
            True if login successful, False otherwise
        """
        form = await request.form()
        email = form.get("username", "")
        password = form.get("password", "")

        if not email or not password:
            return False

        email_str = str(email)
        password_str = str(password)
        ip_address = request.client.host if request.client else None

        lockout = self._get_lockout_manager()

        # Block locked accounts before doing any password work — keeps the
        # admin-login surface free of timing oracles for locked emails.
        try:
            await lockout.check_lockout(email_str, ip_address)
        except AccountLockedError:
            logger.warning(
                "admin_login_locked",
                email=mask_email(email_str),
            )
            return False

        # Check superadmin credentials first (from env vars)
        if await self._authenticate_superadmin(email_str, password_str):
            await lockout.clear_failures(email_str, ip_address)
            request.session["admin_authenticated"] = True
            request.session["admin_email"] = email_str
            request.session["admin_role"] = AdminRole.SUPERADMIN.value
            logger.info(
                "admin_login_success",
                email=mask_email(email_str),
                role=AdminRole.SUPERADMIN.value,
            )
            return True

        # Check database admin users
        if await self._authenticate_db_admin(email_str, password_str):
            await lockout.clear_failures(email_str, ip_address)
            request.session["admin_authenticated"] = True
            request.session["admin_email"] = email_str
            request.session["admin_role"] = AdminRole.ADMIN.value
            logger.info(
                "admin_login_success",
                email=mask_email(email_str),
                role=AdminRole.ADMIN.value,
            )
            return True

        logger.warning(
            "admin_login_failed",
            email=mask_email(email_str),
        )
        try:
            await lockout.record_failure(
                email_str,
                ip_address,
                reason="admin_login_failed",
            )
        except AccountLockedError:
            # The failure that just tripped lockout — surface as failed login.
            pass
        return False

    async def logout(self, request: Request) -> bool:
        """Handle logout - clear session data."""
        email = request.session.get("admin_email", "unknown")
        request.session.clear()
        logger.info("admin_logout", email=mask_email(email))
        return True

    async def authenticate(self, request: Request) -> RedirectResponse | bool:
        """
        Check if user is authenticated.

        Returns:
            True if authenticated, RedirectResponse to login page otherwise
        """
        if request.session.get("admin_authenticated"):
            return True
        return RedirectResponse(request.url_for("admin:login"), status_code=302)

    async def _authenticate_superadmin(self, email: str, password: str) -> bool:
        """
        Authenticate against superadmin credentials from environment.

        Uses constant-time comparison to prevent timing attacks.
        """
        if not self._admin_email or not self._admin_password:
            return False

        # Use constant-time comparison for security
        # Encode to bytes to handle non-ASCII characters
        email_match = secrets.compare_digest(
            email.lower().encode("utf-8"), self._admin_email.lower().encode("utf-8")
        )
        password_match = secrets.compare_digest(
            password.encode("utf-8"),
            self._admin_password.get_secret_value().encode("utf-8"),
        )

        return email_match and password_match

    async def _authenticate_db_admin(self, email: str, password: str) -> bool:
        """
        Authenticate against database admin users.

        Looks up users with 'admin' role and verifies password hash. Runs a
        bcrypt verify on the not-found and OAuth-only paths so the timing
        profile of "no such admin" matches "wrong password" and an attacker
        cannot enumerate admin emails by measuring response latency.

        Note: This requires users to have a password_hash field and
        the 'admin' role assigned. For OAuth-only setups, superadmin
        is the only way to access the admin panel.
        """
        if not self._session_factory:
            return False

        try:
            # Import here to avoid circular imports
            from sqlalchemy import func, select

            from identity_plan_kit.auth.models.user import UserModel
            from identity_plan_kit.auth.services.auth_service import _timing_padding_hash
            from identity_plan_kit.rbac.models.role import RoleModel
            from identity_plan_kit.shared.security import verify_password

            async with self._session_factory() as session:
                # Query user with admin role. Use case-insensitive email match
                # so logins work regardless of the casing the user registered with.
                stmt = (
                    select(UserModel)
                    .join(RoleModel, UserModel.role_id == RoleModel.id)
                    .where(
                        func.lower(UserModel.email) == email.lower(),
                        RoleModel.code == "admin",
                        UserModel.is_active.is_(True),
                    )
                )
                result = await session.execute(stmt)
                user = result.scalar_one_or_none()

                if not user:
                    # Pad with bcrypt against a dummy hash to keep timing
                    # constant — otherwise non-existent emails return in
                    # ~1ms while existing emails take ~100ms (bcrypt).
                    verify_password(password, _timing_padding_hash())
                    return False

                # Check if user has password_hash (for password-based auth)
                if not user.password_hash:
                    verify_password(password, _timing_padding_hash())
                    logger.debug(
                        "admin_auth_no_password",
                        email=mask_email(email),
                        message="User has no password hash, cannot authenticate via password",
                    )
                    return False

                # Verify password using shared security utilities (bcrypt via passlib)
                return verify_password(password, user.password_hash)

        except Exception as e:
            logger.error(
                "admin_auth_error",
                error=str(e),
                email=mask_email(email),
            )
            return False

    def get_admin_role(self, request: Request) -> AdminRole | None:
        """
        Get the admin role from the current session.

        Returns:
            AdminRole if authenticated, None otherwise
        """
        if not request.session.get("admin_authenticated"):
            return None

        role_value = request.session.get("admin_role")
        if role_value:
            try:
                return AdminRole(role_value)
            except ValueError:
                return None
        return None

    def is_superadmin(self, request: Request) -> bool:
        """Check if current user is superadmin."""
        return self.get_admin_role(request) == AdminRole.SUPERADMIN

    def is_admin(self, request: Request) -> bool:
        """Check if current user is admin (view-only)."""
        return self.get_admin_role(request) == AdminRole.ADMIN

    def can_create(self, request: Request) -> bool:
        """Check if current user can create records."""
        return self.is_superadmin(request)

    def can_edit(self, request: Request) -> bool:
        """Check if current user can edit records."""
        return self.is_superadmin(request)

    def can_delete(self, request: Request) -> bool:
        """Check if current user can delete records."""
        return self.is_superadmin(request)
