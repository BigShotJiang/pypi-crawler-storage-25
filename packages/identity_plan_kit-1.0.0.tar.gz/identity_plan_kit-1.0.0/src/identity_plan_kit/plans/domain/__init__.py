"""Plans domain."""
