"""Plan repository for data access."""

from datetime import UTC, date, datetime, timedelta
from typing import Any
from uuid import UUID

from sqlalchemy import delete, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from identity_plan_kit.plans.domain.entities import (
    Feature,
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.domain.exceptions import (
    ForeignKeyViolationError,
    PlanAssignmentError,
)
from identity_plan_kit.plans.models.feature import FeatureModel
from identity_plan_kit.plans.models.plan import PlanModel
from identity_plan_kit.plans.models.plan_limit import PlanLimitModel
from identity_plan_kit.plans.models.plan_permission import PlanPermissionModel
from identity_plan_kit.plans.models.user_plan import UserPlanModel
from identity_plan_kit.shared.logging import get_logger
from identity_plan_kit.shared.repository import BaseRepository
from identity_plan_kit.shared.uuid7 import uuid7

logger = get_logger(__name__)

# Default "lifetime" plan duration in years from today
# Used when no ends_at is provided for plan assignment
LIFETIME_PLAN_YEARS = 100


class PlanRepository(BaseRepository[PlanModel, Plan]):
    """Repository for plan data access."""

    _model_class = PlanModel
    _entity_class = Plan

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def get_all_plans(self) -> list[Plan]:
        """
        Get all plans with their permissions and limits.

        This is an optimized method that loads all plans with their
        nested relationships in 3 queries (plans, permissions, limits)
        instead of N+1 queries.

        Returns:
            List of all Plan entities with permissions and limits
        """
        stmt = (
            select(PlanModel)
            .options(
                selectinload(PlanModel.permissions).selectinload(PlanPermissionModel.permission),
                selectinload(PlanModel.limits).selectinload(PlanLimitModel.feature),
            )
            .order_by(PlanModel.name)
        )
        result = await self._session.execute(stmt)
        models = result.scalars().all()

        return [self._plan_to_entity(model) for model in models]

    async def get_all_features(self) -> list[Feature]:
        """
        Get all features.

        Returns:
            List of all Feature entities
        """
        stmt = select(FeatureModel).order_by(FeatureModel.name)
        result = await self._session.execute(stmt)
        models = result.scalars().all()

        return [Feature(id=model.id, code=model.code, name=model.name) for model in models]

    async def get_plan_by_id(self, plan_id: UUID) -> Plan | None:
        """
        Get plan by ID with permissions and limits.

        Args:
            plan_id: Plan UUID

        Returns:
            Plan entity or None
        """
        stmt = (
            select(PlanModel)
            .options(
                selectinload(PlanModel.permissions).selectinload(PlanPermissionModel.permission),
                selectinload(PlanModel.limits).selectinload(PlanLimitModel.feature),
            )
            .where(PlanModel.id == plan_id)
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._plan_to_entity(model)

    async def get_plan_by_code(self, code: str) -> Plan | None:
        """
        Get plan by code.

        Args:
            code: Plan code (e.g., "pro")

        Returns:
            Plan entity or None
        """
        stmt = (
            select(PlanModel)
            .options(
                selectinload(PlanModel.permissions).selectinload(PlanPermissionModel.permission),
                selectinload(PlanModel.limits).selectinload(PlanLimitModel.feature),
            )
            .where(PlanModel.code == code)
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._plan_to_entity(model)

    async def acquire_user_plan_assignment_lock(self, user_id: UUID) -> None:
        """
        Serialise concurrent ``assign_plan`` calls for the same user.

        Acquires a transaction-level PostgreSQL advisory lock keyed by
        ``user_id``. The lock auto-releases on commit/rollback. Concurrent
        assigns for the *same* user block here; assigns for *different*
        users proceed in parallel.

        Why: ``SELECT FOR UPDATE ORDER BY ends_at DESC LIMIT 1`` does not
        fully serialise under READ COMMITTED — when no active plan exists,
        every concurrent transaction sees "no row to lock" and races to
        INSERT a new plan, producing duplicate active rows. A unique partial
        index on ``user_id`` filtered by ``ends_at >= CURRENT_DATE`` would
        be the schema-level fix, but PostgreSQL forbids non-IMMUTABLE
        functions like ``CURRENT_DATE`` in index predicates. Advisory locks
        sidestep the IMMUTABLE restriction and give us per-user mutual
        exclusion without needing a maintenance column.

        SQLite is used in unit tests and lacks ``pg_advisory_xact_lock`` —
        the call is skipped there; concurrency tests run against Postgres.
        """
        if self._session.bind is None or self._session.bind.dialect.name != "postgresql":
            return
        await self._session.execute(
            text(
                "SELECT pg_advisory_xact_lock("
                "hashtext('ipk:user_plan_assign:' || :user_id))"
            ),
            {"user_id": str(user_id)},
        )

    async def get_user_active_plan(
        self,
        user_id: UUID,
        for_update: bool = False,
        include_cancelled: bool = False,
    ) -> UserPlan | None:
        """
        Get user's active plan.

        Args:
            user_id: User UUID
            for_update: If True, lock the row for update (prevents race conditions
                in read-modify-write operations like custom limits merge)
            include_cancelled: If True, also return plans whose ``is_cancelled``
                flag is set but whose ``ends_at`` is still in the future
                (scheduled cancellation, plan still within its paid window).
                Default False — quota / feature-access callers must treat
                cancelled plans as inactive. Cancellation/immediate-expiry
                paths set this to True so they can act on the row.

        Returns:
            UserPlan entity or None
        """
        today = datetime.now(UTC).date()
        conditions = [
            UserPlanModel.user_id == user_id,
            UserPlanModel.started_at <= today,
            UserPlanModel.ends_at >= today,
        ]
        if not include_cancelled:
            conditions.append(UserPlanModel.is_cancelled.is_(False))

        stmt = (
            select(UserPlanModel)
            .options(selectinload(UserPlanModel.plan))
            .where(*conditions)
            .order_by(UserPlanModel.ends_at.desc())
            .limit(1)
        )

        # Apply row-level lock if requested (prevents race conditions)
        if for_update:
            stmt = stmt.with_for_update()

        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._user_plan_to_entity(model)

    async def get_user_active_plan_with_details(
        self, user_id: UUID
    ) -> tuple[UserPlan, Plan] | None:
        """
        Get user's active plan with full plan details (permissions and limits).

        This is an optimized method that loads everything in a single query,
        avoiding the N+1 problem of fetching user_plan then plan separately.

        Args:
            user_id: User UUID

        Returns:
            Tuple of (UserPlan, Plan) or None if no active plan
        """
        today = datetime.now(UTC).date()
        stmt = (
            select(UserPlanModel)
            .options(
                selectinload(UserPlanModel.plan).options(
                    selectinload(PlanModel.permissions).selectinload(
                        PlanPermissionModel.permission
                    ),
                    selectinload(PlanModel.limits).selectinload(PlanLimitModel.feature),
                )
            )
            .where(
                UserPlanModel.user_id == user_id,
                UserPlanModel.started_at <= today,
                UserPlanModel.ends_at >= today,
                UserPlanModel.is_cancelled.is_(False),
            )
            .order_by(UserPlanModel.ends_at.desc())
            .limit(1)
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        user_plan = self._user_plan_to_entity(model)
        plan = self._plan_to_entity(model.plan)

        return user_plan, plan

    async def get_plan_limit(
        self,
        plan_id: UUID,
        feature_code: str,
    ) -> PlanLimit | None:
        """
        Get limit for a feature in a plan.

        Args:
            plan_id: Plan UUID
            feature_code: Feature code

        Returns:
            PlanLimit entity or None
        """
        stmt = (
            select(PlanLimitModel)
            .join(FeatureModel)
            .options(selectinload(PlanLimitModel.feature))
            .where(
                PlanLimitModel.plan_id == plan_id,
                FeatureModel.code == feature_code,
            )
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._limit_to_entity(model)

    async def get_feature_by_code(self, code: str) -> Feature | None:
        """
        Get feature by code.

        Args:
            code: Feature code

        Returns:
            Feature entity or None
        """
        stmt = select(FeatureModel).where(FeatureModel.code == code)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return Feature(id=model.id, code=model.code, name=model.name)

    def _to_entity(self, model: PlanModel, extra_fields: dict[str, Any] | None = None) -> Plan:
        """Override BaseRepository hook so generic callers get a fully-built Plan."""
        return self._plan_to_entity(model)

    def _plan_to_entity(self, model: PlanModel) -> Plan:
        """
        Convert plan model to entity.

        Note: This method expects relationships (permissions, limits) to be loaded.
        Use selectinload() when querying plans.
        """
        permissions: set[str] = set()
        for pp in model.permissions:
            if pp.permission is None:
                logger.warning(
                    "plan_permission_missing_relationship",
                    plan_id=str(model.id),
                    plan_permission_id=str(pp.id),
                )
                continue
            permissions.add(pp.permission.code)

        limits: dict[str, PlanLimit] = {}
        for pl in model.limits:
            if pl.feature is None:
                logger.warning(
                    "plan_limit_missing_feature_relationship",
                    plan_id=str(model.id),
                    plan_limit_id=str(pl.id),
                )
                continue
            limits[pl.feature.code] = self._limit_to_entity(pl)

        return Plan(
            id=model.id,
            code=model.code,
            name=model.name,
            permissions=permissions,
            limits=limits,
        )

    def _user_plan_to_entity(self, model: UserPlanModel) -> UserPlan:
        """
        Convert user plan model to entity.

        Note: This method expects the plan relationship to be loaded.
        Use selectinload(UserPlanModel.plan) when querying user plans.
        """
        if model.plan is None:
            # This indicates a bug - plan relationship should always be loaded
            logger.error(
                "user_plan_missing_plan_relationship",
                user_plan_id=str(model.id),
                plan_id=str(model.plan_id),
            )
            raise RuntimeError(
                f"UserPlan {model.id} has no plan loaded. "
                "Ensure selectinload(UserPlanModel.plan) is used in the query."
            )

        return UserPlan(
            id=model.id,
            user_id=model.user_id,
            plan_id=model.plan_id,
            plan_code=model.plan.code,
            started_at=model.started_at,
            ends_at=model.ends_at,
            custom_limits=model.custom_limits or {},
        )

    def _limit_to_entity(self, model: PlanLimitModel) -> PlanLimit:
        """
        Convert limit model to entity.

        Note: This method expects the feature relationship to be loaded.
        """
        if model.feature is None:
            logger.error(
                "plan_limit_missing_feature_relationship",
                plan_limit_id=str(model.id),
                feature_id=str(model.feature_id),
            )
            raise RuntimeError(
                f"PlanLimit {model.id} has no feature loaded. "
                "Ensure selectinload(PlanLimitModel.feature) is used in the query."
            )

        period = PeriodType(model.period) if model.period else None
        return PlanLimit(
            id=model.id,
            plan_id=model.plan_id,
            feature_id=model.feature_id,
            feature_code=model.feature.code,
            limit=model.feature_limit,
            period=period,
        )

    async def create_user_plan(
        self,
        user_id: UUID,
        plan_id: UUID,
        started_at: date | None = None,
        ends_at: date | None = None,
        custom_limits: dict[str, Any] | None = None,
    ) -> UserPlan:
        """
        Create a user plan assignment.

        Args:
            user_id: User UUID
            plan_id: Plan UUID to assign
            started_at: Plan start date (defaults to today)
            ends_at: Plan end date (defaults to LIFETIME_PLAN_YEARS from now)
            custom_limits: Optional custom limits override

        Returns:
            Created UserPlan entity

        Raises:
            UserNotFoundError: If user_id doesn't exist
            PlanNotFoundError: If plan_id doesn't exist
            PlanAssignmentError: For other database constraint violations
        """
        today = datetime.now(UTC).date()
        # Default to "lifetime" plan if no end date specified.
        # Clamp Feb 29 to Feb 28 in non-leap target years to avoid ValueError.
        try:
            default_ends_at = date(today.year + LIFETIME_PLAN_YEARS, today.month, today.day)
        except ValueError:
            default_ends_at = date(today.year + LIFETIME_PLAN_YEARS, today.month, today.day - 1)
        model = UserPlanModel(
            id=uuid7(),
            user_id=user_id,
            plan_id=plan_id,
            started_at=started_at or today,
            ends_at=ends_at or default_ends_at,
            custom_limits=custom_limits or {},
        )

        # Use nested transaction (savepoint) to avoid corrupting outer UoW transaction
        # If flush fails, savepoint auto-rolls back without affecting parent transaction
        try:
            async with self._session.begin_nested():
                self._session.add(model)
                await self._session.flush()
        except IntegrityError as e:
            # Savepoint already rolled back automatically - no manual rollback needed
            error_msg = str(e.orig) if e.orig else str(e)

            # Classify foreign key violations strictly by FK constraint name.
            # Substring matches on "users"/"plans" misclassify any unrelated
            # constraint whose error text happens to contain those words.
            if "user_plans_user_id_fkey" in error_msg:
                logger.warning(
                    "user_plan_creation_fk_violation_user",
                    user_id=str(user_id),
                    plan_id=str(plan_id),
                )
                raise ForeignKeyViolationError("user_id", error_msg) from e

            if "user_plans_plan_id_fkey" in error_msg:
                logger.warning(
                    "user_plan_creation_fk_violation_plan",
                    user_id=str(user_id),
                    plan_id=str(plan_id),
                )
                raise ForeignKeyViolationError("plan_id", error_msg) from e

            # Generic constraint violation - log details internally, surface
            # a generic message so we don't leak internal schema/constraint
            # names to API consumers (CWE-209).
            logger.error(
                "user_plan_creation_failed",
                user_id=str(user_id),
                plan_id=str(plan_id),
                error=error_msg,
            )
            raise PlanAssignmentError(
                message="Failed to assign plan due to a database constraint violation",
                user_id=str(user_id),
                plan_id=str(plan_id),
            ) from e

        # Reload with relationships. ``session.refresh(model, ["plan"])`` is
        # a no-op under ``lazy="noload"`` (the strategy refuses to load), so
        # we re-fetch with explicit ``selectinload``.
        stmt = (
            select(UserPlanModel)
            .options(selectinload(UserPlanModel.plan))
            .where(UserPlanModel.id == model.id)
        )
        result = await self._session.execute(stmt)
        reloaded = result.scalar_one()

        logger.info(
            "user_plan_created",
            user_id=str(user_id),
            plan_id=str(plan_id),
        )

        return self._user_plan_to_entity(reloaded)

    async def get_user_plan_by_id(self, user_plan_id: UUID) -> UserPlan | None:
        """
        Get a user plan by its ID.

        Args:
            user_plan_id: UserPlan UUID

        Returns:
            UserPlan entity or None
        """
        stmt = (
            select(UserPlanModel)
            .options(selectinload(UserPlanModel.plan))
            .where(UserPlanModel.id == user_plan_id)
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._user_plan_to_entity(model)

    async def update_user_plan(
        self,
        user_plan_id: UUID,
        ends_at: date | None = None,
        custom_limits: dict[str, Any] | None = None,
    ) -> UserPlan | None:
        """
        Update a user plan.

        Args:
            user_plan_id: UserPlan UUID
            ends_at: New end date (None to keep current)
            custom_limits: New custom limits (None to keep current)

        Returns:
            Updated UserPlan entity or None if not found
        """
        # Build update values
        values: dict[str, Any] = {}
        if ends_at is not None:
            values["ends_at"] = ends_at
        if custom_limits is not None:
            values["custom_limits"] = custom_limits

        if not values:
            # Nothing to update, just return current
            return await self.get_user_plan_by_id(user_plan_id)

        stmt = (
            update(UserPlanModel)
            .where(UserPlanModel.id == user_plan_id)
            .values(**values)
            .returning(UserPlanModel.id)
        )
        result = await self._session.execute(stmt)
        updated_id = result.scalar_one_or_none()

        if updated_id is None:
            return None

        await self._session.flush()

        logger.info(
            "user_plan_updated",
            user_plan_id=str(user_plan_id),
            updates=list(values.keys()),
        )

        return await self.get_user_plan_by_id(user_plan_id)

    async def cancel_user_plan(
        self,
        user_id: UUID,
        immediate: bool = False,
    ) -> bool:
        """
        Cancel user's active plan.

        Args:
            user_id: User UUID
            immediate: If True, cancel immediately (ends_at = yesterday).
                      If False, plan is marked as cancelled but remains active
                      until current ends_at (scheduled cancellation).

        Returns:
            True if a plan was cancelled, False if no active plan found
        """
        # Use FOR UPDATE lock to prevent TOCTOU race condition in concurrent
        # cancellations. include_cancelled=True so a scheduled cancellation
        # can be converted to immediate cancellation when the caller passes
        # immediate=True on an already-scheduled-cancel plan.
        #
        # We need the model (not just the entity) to inspect is_cancelled
        # without re-querying — but get_user_active_plan returns the entity.
        # Use a direct query for the lock and inspect the model fields.
        today = datetime.now(UTC).date()
        stmt_select = (
            select(UserPlanModel)
            .where(
                UserPlanModel.user_id == user_id,
                UserPlanModel.started_at <= today,
                UserPlanModel.ends_at >= today,
            )
            .order_by(UserPlanModel.ends_at.desc())
            .limit(1)
            .with_for_update()
        )
        result = await self._session.execute(stmt_select)
        model = result.scalar_one_or_none()
        if model is None:
            return False

        # No-op fast path: re-cancelling an already-cancelled (scheduled) plan
        # with immediate=False would overwrite cancelled_at, corrupting the
        # billing audit trail. Return False so the service-layer caller knows
        # nothing happened — matches the contract for "no active plan".
        if model.is_cancelled and not immediate:
            return False

        now = datetime.now(UTC)
        values: dict[str, Any] = {}
        if not model.is_cancelled:
            # First cancellation — set the flag and stamp the timestamp.
            values["is_cancelled"] = True
            values["cancelled_at"] = now
        # Preserve the original cancelled_at when upgrading a scheduled
        # cancellation to immediate; only change ends_at.
        if immediate:
            values["ends_at"] = today - timedelta(days=1)

        stmt = update(UserPlanModel).where(UserPlanModel.id == model.id).values(**values)
        await self._session.execute(stmt)
        await self._session.flush()

        logger.info(
            "user_plan_cancelled",
            user_id=str(user_id),
            user_plan_id=str(model.id),
            immediate=immediate,
        )

        return True

    async def expire_user_plan(
        self,
        user_plan_id: UUID,
    ) -> bool:
        """
        Immediately expire a specific user plan.

        Args:
            user_plan_id: UserPlan UUID to expire

        Returns:
            True if plan was expired, False if not found
        """
        yesterday = datetime.now(UTC).date() - timedelta(days=1)
        stmt = (
            update(UserPlanModel)
            .where(UserPlanModel.id == user_plan_id)
            .values(ends_at=yesterday)
            .returning(UserPlanModel.id)
        )
        result = await self._session.execute(stmt)
        expired_id = result.scalar_one_or_none()

        if expired_id is None:
            return False

        await self._session.flush()

        logger.info(
            "user_plan_expired",
            user_plan_id=str(user_plan_id),
        )

        return True

    async def delete_user_plan(
        self,
        user_plan_id: UUID,
    ) -> bool:
        """
        Hard delete a user plan record.

        Note: This also deletes associated usage records (CASCADE).
        Use with caution - prefer expire_user_plan for soft delete.

        Args:
            user_plan_id: UserPlan UUID to delete

        Returns:
            True if deleted, False if not found
        """
        stmt = (
            delete(UserPlanModel)
            .where(UserPlanModel.id == user_plan_id)
            .returning(UserPlanModel.id)
        )
        result = await self._session.execute(stmt)
        deleted_id = result.scalar_one_or_none()

        if deleted_id is None:
            return False

        await self._session.flush()

        logger.warning(
            "user_plan_deleted",
            user_plan_id=str(user_plan_id),
        )

        return True
