"""Shared exceptions for plan cache modules."""

from identity_plan_kit.shared.exceptions import BaseError


class RedisRequiredError(BaseError):
    """Raised when Redis is required but not available."""

    code = "REDIS_REQUIRED"
    message = "Redis is required but not available"
    status_code = 503
