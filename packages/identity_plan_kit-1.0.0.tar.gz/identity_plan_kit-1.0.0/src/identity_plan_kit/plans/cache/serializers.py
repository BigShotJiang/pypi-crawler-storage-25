"""Shared serialization functions for Plan and UserPlan entities.

This module provides centralized serialization/deserialization logic
to prevent inconsistencies between plan_cache and user_plan_cache.
"""

from datetime import date
from uuid import UUID

from identity_plan_kit.plans.domain.entities import PeriodType, Plan, PlanLimit, UserPlan


def plan_to_dict(plan: Plan) -> dict:
    """Convert Plan entity to JSON-serializable dict."""
    return {
        "id": str(plan.id),
        "code": plan.code,
        "name": plan.name,
        "permissions": list(plan.permissions),
        "limits": {
            code: {
                "id": str(limit.id),
                "plan_id": str(limit.plan_id),
                "feature_id": str(limit.feature_id),
                "feature_code": limit.feature_code,
                "limit": limit.limit,
                "period": limit.period.value if limit.period else None,
            }
            for code, limit in plan.limits.items()
        },
    }


def dict_to_plan(data: dict) -> Plan:
    """Convert dict back to Plan entity."""
    limits = {}
    for code, limit_data in data.get("limits", {}).items():
        limits[code] = PlanLimit(
            id=UUID(limit_data["id"]),
            plan_id=UUID(limit_data["plan_id"]),
            feature_id=UUID(limit_data["feature_id"]),
            feature_code=limit_data["feature_code"],
            limit=limit_data["limit"],
            period=PeriodType(limit_data["period"]) if limit_data["period"] else None,
        )
    return Plan(
        id=UUID(data["id"]),
        code=data["code"],
        name=data["name"],
        permissions=set(data.get("permissions", [])),
        limits=limits,
    )


def user_plan_to_dict(user_plan: UserPlan) -> dict:
    """Convert UserPlan entity to JSON-serializable dict."""
    return {
        "id": str(user_plan.id),
        "user_id": str(user_plan.user_id),
        "plan_id": str(user_plan.plan_id),
        "plan_code": user_plan.plan_code,
        "started_at": user_plan.started_at.isoformat(),
        "ends_at": user_plan.ends_at.isoformat(),
        "custom_limits": user_plan.custom_limits,
    }


def dict_to_user_plan(data: dict) -> UserPlan:
    """Convert dict back to UserPlan entity."""
    return UserPlan(
        id=UUID(data["id"]),
        user_id=UUID(data["user_id"]),
        plan_id=UUID(data["plan_id"]),
        plan_code=data["plan_code"],
        started_at=date.fromisoformat(data["started_at"]),
        ends_at=date.fromisoformat(data["ends_at"]),
        custom_limits=data.get("custom_limits", {}),
    )
