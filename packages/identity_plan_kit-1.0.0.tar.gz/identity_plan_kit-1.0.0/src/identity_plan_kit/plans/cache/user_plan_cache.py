"""User plan cache for fast user plan lookups with Redis support."""

import asyncio
import json
import random
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any
from uuid import UUID

from identity_plan_kit.plans.cache.exceptions import RedisRequiredError
from identity_plan_kit.plans.cache.serializers import (
    dict_to_plan,
    dict_to_user_plan,
    plan_to_dict,
    user_plan_to_dict,
)
from identity_plan_kit.plans.domain.entities import Plan, UserPlan
from identity_plan_kit.shared.constants import (
    DEFAULT_MAX_CACHE_ENTRIES,
    REDIS_CIRCUIT_FAILURE_THRESHOLD,
    REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS,
    REDIS_CIRCUIT_RECOVERY_TIMEOUT,
    REDIS_RETRY_ATTEMPTS,
    REDIS_RETRY_BASE_DELAY,
    REDIS_SOCKET_CONNECT_TIMEOUT,
    REDIS_SOCKET_TIMEOUT,
)
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


class CacheCircuitState(Enum):
    """Circuit breaker states for cache."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


# Optional Redis support
try:
    import redis.asyncio as redis

    REDIS_AVAILABLE = True
except ImportError:
    redis = None  # type: ignore[assignment]
    REDIS_AVAILABLE = False


class AbstractUserPlanCache(ABC):
    """Abstract base class for user plan caching."""

    @abstractmethod
    async def get(self, user_id: UUID) -> tuple[UserPlan, Plan] | None:
        """Get cached user plan by user ID."""
        pass

    @abstractmethod
    async def set(
        self,
        user_id: UUID,
        user_plan: UserPlan,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """Cache user plan by user ID."""
        pass

    @abstractmethod
    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user plan by user ID."""
        pass

    @abstractmethod
    async def invalidate_all(self) -> None:
        """Invalidate all cached user plans."""
        pass

    def get_fetch_timestamp(self) -> float:
        """Get a monotonic timestamp for stale write prevention."""
        return time.monotonic()


@dataclass
class UserPlanCacheEntry:
    """Cache entry for user plan with expiration."""

    user_plan: UserPlan
    plan: Plan
    expires_at: datetime
    fetched_at: float = field(default_factory=time.monotonic)

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class InMemoryUserPlanCache(AbstractUserPlanCache):
    """
    In-memory user plan cache.

    Caches user plan assignments (by user_id) to reduce database queries.
    User plans change less frequently than usage, so caching provides
    significant benefit for quota check operations.

    Cache key: user_id (UUID)
    Cache value: (UserPlan, Plan) tuple with full plan details

    **Invalidation:**

    Call invalidate() when:
    - User's plan is assigned/changed
    - User's plan is cancelled
    - User's plan is extended
    - User's custom limits are updated

    Warning:
        For multi-instance deployments, use RedisUserPlanCache instead.
        In-memory cache invalidation only affects the local instance.
    """

    def __init__(
        self,
        ttl_seconds: int = 300,
        max_entries: int = DEFAULT_MAX_CACHE_ENTRIES,
    ) -> None:
        """
        Initialize user plan cache.

        Args:
            ttl_seconds: Cache TTL in seconds (default: 5 minutes, 0 to disable)
            max_entries: Maximum number of entries to cache (LRU eviction)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._ttl_seconds = ttl_seconds
        self._max_entries = max_entries
        self._cache: OrderedDict[UUID, UserPlanCacheEntry] = OrderedDict()
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0
        self._invalidated_at: OrderedDict[UUID, float] = OrderedDict()
        self._global_invalidated_at: float = 0.0

    async def get(self, user_id: UUID) -> tuple[UserPlan, Plan] | None:
        """
        Get cached user plan by user ID.

        Reads are intentionally lock-free for hot-path performance; writes
        are serialised via ``_write_lock`` with timestamp-based stale-write
        rejection.

        Args:
            user_id: User UUID

        Returns:
            Tuple of (UserPlan, Plan) or None if not cached/expired
        """
        if not self._enabled:
            return None

        entry = self._cache.get(user_id)

        if entry is None:
            return None

        if entry.is_expired:
            return None

        return entry.user_plan, entry.plan

    async def set(
        self,
        user_id: UUID,
        user_plan: UserPlan,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache user plan by user ID.

        Args:
            user_id: User UUID
            user_plan: UserPlan entity to cache
            plan: Plan entity with full details (permissions, limits)
            fetched_at: Monotonic timestamp when data was fetched from DB

        Returns:
            True if the entry was cached, False if rejected as stale
        """
        if not self._enabled:
            return False

        # Acquire lock to prevent TOCTOU race with invalidate()/invalidate_all()
        # The stale-write check and cache write must be atomic
        async with self._write_lock:
            if fetched_at is not None:
                if fetched_at < self._global_invalidated_at:
                    logger.debug(
                        "user_plan_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="global_invalidation",
                    )
                    return False

                key_invalidated_at = self._invalidated_at.get(user_id, 0.0)
                if fetched_at < key_invalidated_at:
                    logger.debug(
                        "user_plan_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="key_invalidation",
                    )
                    return False

            entry = UserPlanCacheEntry(
                user_plan=user_plan,
                plan=plan,
                expires_at=datetime.now(UTC) + self._ttl,
                fetched_at=fetched_at or time.monotonic(),
            )
            # LRU: bump to most-recently-used; evict oldest if over capacity
            self._cache[user_id] = entry
            self._cache.move_to_end(user_id)
            if len(self._cache) > self._max_entries:
                self._cache.popitem(last=False)
            return True

    async def invalidate(self, user_id: UUID) -> None:
        """
        Invalidate cached user plan by user ID.

        Args:
            user_id: User UUID to invalidate
        """
        async with self._write_lock:
            self._invalidated_at[user_id] = time.monotonic()
            self._invalidated_at.move_to_end(user_id)
            self._cache.pop(user_id, None)

            # LRU eviction: bound the invalidation timestamp dict too
            if len(self._invalidated_at) > self._max_entries:
                self._invalidated_at.popitem(last=False)

            logger.debug("user_plan_cache_invalidated", user_id=str(user_id))

    async def invalidate_all(self) -> None:
        """Invalidate all cached user plans."""
        async with self._write_lock:
            self._global_invalidated_at = time.monotonic()
            self._cache.clear()
            self._invalidated_at.clear()
            logger.info("user_plan_cache_cleared")

    async def cleanup_expired(self) -> int:
        """Remove expired entries from cache."""
        async with self._write_lock:
            expired_keys = [key for key, entry in self._cache.items() if entry.is_expired]
            for key in expired_keys:
                del self._cache[key]

            if expired_keys:
                logger.debug(
                    "user_plan_cache_cleanup",
                    removed_count=len(expired_keys),
                )

            return len(expired_keys)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)


class RedisUserPlanCache(AbstractUserPlanCache):
    """
    Redis-backed user plan cache for distributed deployments.

    Use this when running multiple application instances behind a load balancer.
    Ensures cache invalidation propagates to all instances.

    Features:
    - Circuit breaker: Fails fast when Redis is unavailable
    - Retry with exponential backoff: Handles transient failures
    - Configurable timeouts: Prevents hanging connections

    Requires: pip install redis
    """

    # Circuit breaker configuration (from constants)
    CIRCUIT_FAILURE_THRESHOLD = REDIS_CIRCUIT_FAILURE_THRESHOLD
    CIRCUIT_RECOVERY_TIMEOUT = REDIS_CIRCUIT_RECOVERY_TIMEOUT
    CIRCUIT_HALF_OPEN_MAX_CALLS = REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS

    # Atomic SETEX with timestamp check; rejects stale writes scheduled before
    # the most recent invalidation. Mirrors RedisPlanCache.
    LUA_SET_WITH_TIMESTAMP_CHECK = """
        local fetched_at = ARGV[3]
        if fetched_at == "nil" then
            redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
            return 1
        end
        fetched_at = tonumber(fetched_at)
        local global_inv = redis.call("GET", KEYS[2])
        if global_inv and tonumber(global_inv) > fetched_at then
            return 0
        end
        local key_inv = redis.call("GET", KEYS[3])
        if key_inv and tonumber(key_inv) > fetched_at then
            return 0
        end
        redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
        return 1
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        ttl_seconds: int = 300,
        key_prefix: str = "ipk:user_plan:",
        socket_timeout: float = REDIS_SOCKET_TIMEOUT,
        socket_connect_timeout: float = REDIS_SOCKET_CONNECT_TIMEOUT,
    ) -> None:
        """
        Initialize Redis user plan cache.

        Args:
            redis_url: Redis connection URL
            ttl_seconds: Cache TTL in seconds (0 to disable)
            key_prefix: Prefix for cache keys
            socket_timeout: Timeout for socket operations (default: 5s)
            socket_connect_timeout: Timeout for connection (default: 5s)
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "Redis support requires the 'redis' package. Install with: pip install redis"
            )

        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix
        self._socket_timeout = socket_timeout
        self._socket_connect_timeout = socket_connect_timeout
        self._enabled = ttl_seconds > 0
        self._client: redis.Redis[bytes] | None = None

        # Circuit breaker state
        self._circuit_state = CacheCircuitState.CLOSED
        self._circuit_failures = 0
        self._circuit_successes = 0
        self._circuit_opened_at: datetime | None = None
        self._circuit_half_open_calls = 0
        self._circuit_lock = asyncio.Lock()

    def _make_key(self, user_id: UUID) -> str:
        """Create cache key for user."""
        return f"{self._key_prefix}{user_id}"

    def _make_invalidation_key(self, user_id: UUID) -> str:
        """Create invalidation timestamp key for user."""
        return f"{self._key_prefix}_invalidated:{user_id}"

    def _make_global_invalidation_key(self) -> str:
        """Create global invalidation timestamp key."""
        return f"{self._key_prefix}_global_invalidated"

    async def _check_circuit(self) -> bool:
        """Check if circuit allows request."""
        async with self._circuit_lock:
            if self._circuit_state == CacheCircuitState.CLOSED:
                return True

            if self._circuit_state == CacheCircuitState.OPEN:
                if self._circuit_opened_at is not None:
                    elapsed = (datetime.now(UTC) - self._circuit_opened_at).total_seconds()
                    if elapsed >= self.CIRCUIT_RECOVERY_TIMEOUT:
                        self._circuit_state = CacheCircuitState.HALF_OPEN
                        self._circuit_half_open_calls = 0
                        self._circuit_successes = 0
                        logger.info("user_plan_cache_circuit_half_open")
                        return True
                return False

            if self._circuit_state == CacheCircuitState.HALF_OPEN:
                if self._circuit_half_open_calls < self.CIRCUIT_HALF_OPEN_MAX_CALLS:
                    self._circuit_half_open_calls += 1
                    return True
                return False

            return False

    async def _record_success(self) -> None:
        """Record successful operation."""
        async with self._circuit_lock:
            self._circuit_successes += 1
            if self._circuit_state == CacheCircuitState.HALF_OPEN:
                if self._circuit_successes >= 2:
                    self._circuit_state = CacheCircuitState.CLOSED
                    self._circuit_failures = 0
                    logger.info("user_plan_cache_circuit_closed")

    async def _record_failure(self) -> None:
        """Record failed operation."""
        async with self._circuit_lock:
            self._circuit_failures += 1
            if self._circuit_state == CacheCircuitState.CLOSED:
                if self._circuit_failures >= self.CIRCUIT_FAILURE_THRESHOLD:
                    self._circuit_state = CacheCircuitState.OPEN
                    self._circuit_opened_at = datetime.now(UTC)
                    logger.warning("user_plan_cache_circuit_open", failures=self._circuit_failures)
            elif self._circuit_state == CacheCircuitState.HALF_OPEN:
                self._circuit_state = CacheCircuitState.OPEN
                self._circuit_opened_at = datetime.now(UTC)
                logger.warning("user_plan_cache_circuit_reopened")

    async def _execute_with_retry(
        self,
        operation: str,
        func: Callable[..., Awaitable[Any]],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Execute Redis operation with circuit breaker and retry logic.

        Args:
            operation: Operation name for logging
            func: Async function to execute
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result from func, or None on failure

        Raises:
            Exception: Re-raises non-retryable exceptions
        """
        # Check circuit breaker
        if not await self._check_circuit():
            logger.warning(f"user_plan_cache_{operation}_circuit_open")
            return None

        last_error: Exception | None = None

        for attempt in range(REDIS_RETRY_ATTEMPTS):
            try:
                result = await func(*args, **kwargs)
                await self._record_success()
                return result
            except (
                TimeoutError,
                redis.ConnectionError,
                redis.TimeoutError,
                redis.ResponseError,
            ) as e:
                last_error = e

                if attempt < REDIS_RETRY_ATTEMPTS - 1:
                    delay = REDIS_RETRY_BASE_DELAY * (2**attempt)
                    jitter = random.uniform(0, 0.1 * delay)
                    await asyncio.sleep(delay + jitter)
                    logger.warning(
                        f"user_plan_cache_{operation}_retry",
                        attempt=attempt + 1,
                        error=str(e),
                    )
            except Exception as e:
                await self._record_failure()
                logger.error(f"user_plan_cache_{operation}_error", error=str(e))
                raise

        # Record single failure after all retries exhausted (matches RedisPlanCache).
        await self._record_failure()
        logger.error(
            f"user_plan_cache_{operation}_failed",
            attempts=REDIS_RETRY_ATTEMPTS,
            error=str(last_error),
        )
        return None

    async def connect(
        self,
        max_retries: int = 3,
        base_delay: float = 0.5,
    ) -> None:
        """Connect to Redis with exponential backoff retry."""
        self._client = redis.from_url(
            self._redis_url,
            encoding="utf-8",
            decode_responses=False,
            socket_timeout=self._socket_timeout,
            socket_connect_timeout=self._socket_connect_timeout,
        )

        last_error: Exception | None = None
        for attempt in range(max_retries):
            try:
                await self._client.ping()
                logger.info(
                    "redis_user_plan_cache_connected",
                    url=self._redis_url.split("@")[-1],
                )
                return
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)
                    logger.warning(
                        "redis_user_plan_cache_connection_retry",
                        attempt=attempt + 1,
                        max_retries=max_retries,
                        delay=delay,
                        error=str(e),
                    )
                    await asyncio.sleep(delay)

        await self._client.aclose()
        self._client = None
        raise ConnectionError(
            f"Failed to connect to Redis after {max_retries} attempts: {last_error}"
        )

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def get(self, user_id: UUID) -> tuple[UserPlan, Plan] | None:
        """Get cached user plan by user ID."""
        if not self._enabled or not self._client:
            return None

        async def _get_from_redis() -> bytes | None:
            key = self._make_key(user_id)
            return await self._client.get(key)  # type: ignore[union-attr]

        value = await self._execute_with_retry("get", _get_from_redis)
        if value is None:
            return None

        try:
            data = json.loads(value)
            user_plan = dict_to_user_plan(data["user_plan"])
            plan = dict_to_plan(data["plan"])
            return user_plan, plan
        except (json.JSONDecodeError, TypeError, KeyError) as e:
            logger.warning(
                "user_plan_cache_json_decode_error",
                user_id=str(user_id),
                error=str(e),
            )
            await self.invalidate(user_id)
            return None

    async def set(
        self,
        user_id: UUID,
        user_plan: UserPlan,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """Cache user plan by user ID with stale write prevention."""
        if not self._enabled or not self._client:
            return False

        key = self._make_key(user_id)
        global_inv_key = self._make_global_invalidation_key()
        inv_key = self._make_invalidation_key(user_id)

        try:
            value = json.dumps(
                {
                    "user_plan": user_plan_to_dict(user_plan),
                    "plan": plan_to_dict(plan),
                }
            )
        except (TypeError, ValueError) as e:
            logger.warning(
                "user_plan_cache_json_encode_error",
                user_id=str(user_id),
                error=str(e),
            )
            return False

        result = await self._execute_with_retry(
            "eval",
            self._client.eval,
            self.LUA_SET_WITH_TIMESTAMP_CHECK,
            3,
            key,
            global_inv_key,
            inv_key,
            value,
            str(self._ttl_seconds),
            str(fetched_at) if fetched_at is not None else "nil",
        )

        if result == 0:
            logger.debug("user_plan_cache_stale_write_rejected", user_id=str(user_id))
            return False

        return result == 1

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user plan by user ID with timestamp storage."""
        if not self._client:
            return

        # Store invalidation timestamp (2x TTL to outlive in-flight writes)
        timestamp = time.monotonic()
        inv_key = self._make_invalidation_key(user_id)
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        key = self._make_key(user_id)
        await self._execute_with_retry("delete", self._client.delete, key)
        logger.debug("user_plan_cache_invalidated", user_id=str(user_id))

    async def invalidate_all(self) -> None:
        """Invalidate all cached user plans with global timestamp."""
        if not self._client:
            return

        # Store global invalidation timestamp FIRST so in-flight writes are
        # rejected even if the SCAN below fails partway through.
        timestamp = time.monotonic()
        global_inv_key = self._make_global_invalidation_key()
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            global_inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        async def _invalidate_all_in_redis() -> int:
            pattern = f"{self._key_prefix}*"
            cursor = 0
            deleted = 0

            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)  # type: ignore[union-attr]
                if keys:
                    # Keep invalidation timestamp keys so in-flight writes stay rejected.
                    plan_keys = [
                        k
                        for k in keys
                        if not k.decode("utf-8").endswith("_global_invalidated")
                        and b"_invalidated:" not in k
                    ]
                    if plan_keys:
                        deleted += await self._client.delete(*plan_keys)  # type: ignore[union-attr]
                if cursor == 0:
                    break
            return deleted

        deleted = await self._execute_with_retry("invalidate_all", _invalidate_all_in_redis)
        if deleted is not None:
            logger.info("user_plan_cache_cleared", deleted=deleted)


class UserPlanCache(AbstractUserPlanCache):
    """
    User plan cache with automatic backend selection.

    Uses Redis if redis_url is provided, otherwise falls back to in-memory.
    This is the recommended class to use for user plan caching.

    Example:
        ```python
        # In-memory (single instance)
        cache = UserPlanCache(ttl_seconds=300)

        # Redis (multi-instance, fail if unavailable)
        cache = UserPlanCache(
            ttl_seconds=300,
            redis_url="redis://localhost:6379/0",
            require_redis=True,
        )
        await cache.connect()  # Required for Redis
        ```
    """

    def __init__(
        self,
        ttl_seconds: int = 300,
        redis_url: str | None = None,
        key_prefix: str = "ipk:user_plan:",
        require_redis: bool = False,
    ) -> None:
        """
        Initialize user plan cache.

        Args:
            ttl_seconds: Cache TTL in seconds (0 to disable)
            redis_url: Redis URL for distributed caching (optional)
            key_prefix: Prefix for Redis keys
            require_redis: If True, fail if Redis is not available.

        Raises:
            RedisRequiredError: If require_redis=True and Redis is not available.
        """
        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix

        if require_redis:
            if not redis_url:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for user plan cache but "
                    "redis_url is not configured."
                )
            if not REDIS_AVAILABLE:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for user plan cache but "
                    "the redis package is not installed. Install with: pip install redis"
                )

        if redis_url and REDIS_AVAILABLE:
            self._backend: AbstractUserPlanCache = RedisUserPlanCache(
                redis_url=redis_url,
                ttl_seconds=ttl_seconds,
                key_prefix=key_prefix,
            )
            self._is_redis = True
        else:
            if redis_url and not REDIS_AVAILABLE:
                logger.warning(
                    "redis_not_available_for_user_plan_cache",
                    message="Redis URL provided but redis package not installed. "
                    "Using in-memory cache.",
                )
            self._backend = InMemoryUserPlanCache(ttl_seconds=ttl_seconds)
            self._is_redis = False

    async def connect(self) -> None:
        """Connect to Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisUserPlanCache):
            await self._backend.connect()

    async def disconnect(self) -> None:
        """Disconnect from Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisUserPlanCache):
            await self._backend.disconnect()

    async def get(self, user_id: UUID) -> tuple[UserPlan, Plan] | None:
        """Get cached user plan by user ID."""
        return await self._backend.get(user_id)

    async def set(
        self,
        user_id: UUID,
        user_plan: UserPlan,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """Cache user plan by user ID."""
        return await self._backend.set(user_id, user_plan, plan, fetched_at=fetched_at)

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user plan by user ID."""
        await self._backend.invalidate(user_id)

    async def invalidate_all(self) -> None:
        """Invalidate all cached user plans."""
        await self._backend.invalidate_all()

    @property
    def size(self) -> int:
        """Get current cache size (in-memory only)."""
        if isinstance(self._backend, InMemoryUserPlanCache):
            return self._backend.size
        return -1

    @property
    def is_redis(self) -> bool:
        """Check if using Redis backend."""
        return self._is_redis
