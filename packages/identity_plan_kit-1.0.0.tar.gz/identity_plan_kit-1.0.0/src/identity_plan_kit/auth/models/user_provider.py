"""UserProvider SQLAlchemy model."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from identity_plan_kit.shared.models import BaseModel

if TYPE_CHECKING:
    from identity_plan_kit.auth.models.user import UserModel


class UserProviderModel(BaseModel):
    """
    OAuth provider link model.

    Links users to external OAuth providers (e.g., Google).
    """

    __tablename__ = "user_providers"
    __table_args__ = (Index("ix_user_providers_unique", "code", "external_user_id", unique=True),)

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    code: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )
    external_user_id: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        index=True,
    )

    user: Mapped[UserModel] = relationship(
        "UserModel",
        back_populates="providers",
    )

    def __repr__(self) -> str:
        return f"<UserProvider {self.code}:{self.external_user_id}>"
