"""Google OAuth service with resilience patterns."""

import asyncio
import secrets
from dataclasses import dataclass
from typing import Any

import httpx
from authlib.integrations.httpx_client import AsyncOAuth2Client
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from identity_plan_kit.auth.domain.exceptions import OAuthError
from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.shared.circuit_breaker import CircuitBreaker, CircuitBreakerError
from identity_plan_kit.shared.constants import (
    DEFAULT_RETRY_ATTEMPTS,
    OAUTH_MAX_CONCURRENT_CALLS,
    OAUTH_SEMAPHORE_ACQUIRE_TIMEOUT,
)
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)

GOOGLE_AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"  # noqa: S105
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"

# HTTP timeout configuration. Connect/pool kept tight; read/write longer to
# accommodate occasional Google latency on userinfo.
HTTP_TIMEOUT = httpx.Timeout(
    connect=5.0,
    read=10.0,
    write=10.0,
    pool=5.0,
)

# Retry only on transient network errors. HTTP 4xx (bad request) is never retried.
RETRYABLE_EXCEPTIONS = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.WriteTimeout,
    httpx.PoolTimeout,
    OSError,
    ConnectionError,
)

MAX_RETRY_ATTEMPTS = DEFAULT_RETRY_ATTEMPTS

# HTTP status code ranges for error handling
HTTP_CLIENT_ERROR_MIN = 400
HTTP_CLIENT_ERROR_MAX = 500
RETRY_MIN_WAIT = 0.5  # seconds
RETRY_MAX_WAIT = 5.0  # seconds

# Bulkhead and semaphore acquire timeout sourced from shared constants.
DEFAULT_MAX_CONCURRENT_CALLS = OAUTH_MAX_CONCURRENT_CALLS
SEMAPHORE_ACQUIRE_TIMEOUT = OAUTH_SEMAPHORE_ACQUIRE_TIMEOUT


@dataclass
class GoogleUserInfo:
    """
    Google user information from OAuth.

    Fields map to Google's userinfo endpoint response:
    https://www.googleapis.com/oauth2/v3/userinfo

    Example response:
    {
        "sub": "110248495921238986420",
        "email": "user@gmail.com",
        "email_verified": true,
        "name": "Иван Иванов",
        "given_name": "Иван",
        "family_name": "Иванов",
        "picture": "https://lh3.googleusercontent.com/...",
        "locale": "ru"
    }
    """

    id: str  # Google's 'sub' field - unique user identifier
    email: str
    email_verified: bool
    name: str | None  # Full display name
    given_name: str | None  # First name
    family_name: str | None  # Last name
    picture: str | None  # Profile picture URL


class SemaphoreTimeoutError(BaseError):
    """Raised when semaphore acquisition times out."""

    code = "OAUTH_SEMAPHORE_TIMEOUT"
    message = "OAuth service overloaded"
    status_code = 503


class GoogleOAuthService:
    """
    Service for Google OAuth2 authentication.

    Features:
    - Instance-scoped circuit breaker (P2 FIX: doesn't leak state between instances)
    - Bulkhead pattern with semaphore (P2 FIX: prevents connection pool exhaustion)
    - Semaphore acquisition timeout (prevents indefinite waiting)
    - Retry with exponential backoff for transient errors
    - Configurable timeouts
    """

    def __init__(
        self,
        config: IdentityPlanKitConfig,
        max_concurrent_calls: int = DEFAULT_MAX_CONCURRENT_CALLS,
        semaphore_timeout: float = SEMAPHORE_ACQUIRE_TIMEOUT,
    ) -> None:
        self._config = config
        self._client_id = config.google_client_id
        self._client_secret = config.google_client_secret.get_secret_value()
        self._redirect_uri = config.google_redirect_uri
        self._semaphore_timeout = semaphore_timeout

        # P2 FIX: Instance-scoped circuit breaker (doesn't leak between test runs)
        self._circuit_breaker = CircuitBreaker(
            name=f"google_oauth_{id(self)}",
            failure_threshold=5,
            recovery_timeout=60.0,
            half_open_max_calls=3,
            success_threshold=2,
            # Don't count client errors (4xx) as circuit breaker failures
            exclude_exceptions=(OAuthError,),
        )

        # P2 FIX: Bulkhead - limits concurrent calls to prevent overwhelming Google
        self._semaphore = asyncio.Semaphore(max_concurrent_calls)

        logger.debug(
            "google_oauth_service_initialized",
            max_concurrent_calls=max_concurrent_calls,
            semaphore_timeout=semaphore_timeout,
        )

    async def _acquire_semaphore(self) -> None:
        """
        Acquire semaphore with timeout.

        `asyncio.Semaphore.acquire()` returns None on success and raises on
        cancellation, so we don't need a truthiness check on the return value.
        On timeout we raise without holding the semaphore — the caller's
        finally must guard release with an `acquired` flag.

        Raises:
            SemaphoreTimeoutError: If semaphore cannot be acquired within timeout
        """
        try:
            await asyncio.wait_for(
                self._semaphore.acquire(),
                timeout=self._semaphore_timeout,
            )
        except TimeoutError as e:
            logger.warning(
                "oauth_semaphore_timeout",
                provider="google",
                timeout=self._semaphore_timeout,
            )
            raise SemaphoreTimeoutError(
                f"OAuth semaphore acquisition timed out after {self._semaphore_timeout}s"
            ) from e

    def get_authorization_url(self, state: str | None = None) -> tuple[str, str]:
        """
        Get Google OAuth authorization URL.

        Args:
            state: Optional state for CSRF protection (generated if not provided)

        Returns:
            Tuple of (authorization_url, state)
        """
        if state is None:
            state = secrets.token_urlsafe(32)

        client = AsyncOAuth2Client(
            client_id=self._client_id,
            redirect_uri=self._redirect_uri,
        )

        url, _ = client.create_authorization_url(
            GOOGLE_AUTHORIZE_URL,
            state=state,
            scope="openid email profile",
            access_type="offline",
            prompt="consent",
        )

        logger.debug("oauth_authorization_url_created", provider="google")

        return url, state

    async def exchange_code(self, code: str) -> dict[str, Any]:
        """
        Exchange authorization code for tokens.

        Args:
            code: Authorization code from callback

        Returns:
            Token response containing access_token, refresh_token, etc.

        Raises:
            OAuthError: If code exchange fails or circuit breaker is open
        """
        try:
            return await self._exchange_code_internal(code)
        except CircuitBreakerError as e:
            logger.warning(
                "oauth_circuit_breaker_open",
                provider="google",
                retry_after=e.retry_after,
            )
            raise OAuthError(
                message="Google OAuth service temporarily unavailable",
                provider="google",
            ) from e
        except SemaphoreTimeoutError as e:
            logger.warning(
                "oauth_semaphore_timeout",
                provider="google",
            )
            raise OAuthError(
                message="Google OAuth service is overloaded, please try again later",
                provider="google",
            ) from e

    async def _exchange_code_internal(self, code: str) -> dict[str, Any]:
        """Internal method for code exchange with retry, circuit breaker, and bulkhead."""

        @self._circuit_breaker.call
        @retry(
            retry=retry_if_exception_type(RETRYABLE_EXCEPTIONS),
            stop=stop_after_attempt(MAX_RETRY_ATTEMPTS),
            wait=wait_exponential(multiplier=RETRY_MIN_WAIT, max=RETRY_MAX_WAIT),
            before_sleep=before_sleep_log(logger, log_level=20),
            reraise=True,
        )
        async def _do_exchange() -> dict[str, Any]:
            # Bulkhead with timeout. `acquired` flag prevents over-release of the
            # semaphore when `_acquire_semaphore()` itself raises (timeout) —
            # otherwise `finally` would increment the counter without a matching
            # decrement, slowly defeating the bulkhead.
            acquired = False
            try:
                await self._acquire_semaphore()
                acquired = True
                async with AsyncOAuth2Client(
                    client_id=self._client_id,
                    client_secret=self._client_secret,
                    redirect_uri=self._redirect_uri,
                    timeout=HTTP_TIMEOUT,
                ) as client:
                    try:
                        token = await client.fetch_token(
                            GOOGLE_TOKEN_URL,
                            code=code,
                        )
                        logger.debug("oauth_code_exchanged", provider="google")
                        return dict(token)
                    except httpx.TimeoutException:
                        logger.warning(
                            "oauth_code_exchange_timeout",
                            provider="google",
                        )
                        raise
                    except httpx.HTTPStatusError as e:
                        if HTTP_CLIENT_ERROR_MIN <= e.response.status_code < HTTP_CLIENT_ERROR_MAX:
                            logger.exception(
                                "oauth_code_exchange_client_error",
                                provider="google",
                                status=e.response.status_code,
                            )
                            raise OAuthError(
                                message="Failed to exchange authorization code",
                                provider="google",
                            ) from e
                        logger.warning(
                            "oauth_code_exchange_server_error",
                            provider="google",
                            status=e.response.status_code,
                        )
                        raise
                    except Exception as e:
                        logger.exception(
                            "oauth_code_exchange_failed",
                            provider="google",
                            error=str(e),
                        )
                        raise OAuthError(
                            message="Failed to exchange authorization code",
                            provider="google",
                        ) from e
            finally:
                if acquired:
                    self._semaphore.release()

        return await _do_exchange()

    async def get_user_info(self, access_token: str) -> GoogleUserInfo:
        """
        Get user information from Google.

        Args:
            access_token: Google access token

        Returns:
            GoogleUserInfo with user details

        Raises:
            OAuthError: If fetching user info fails or circuit breaker is open
        """
        try:
            return await self._get_user_info_internal(access_token)
        except CircuitBreakerError as e:
            logger.warning(
                "oauth_circuit_breaker_open",
                provider="google",
                retry_after=e.retry_after,
            )
            raise OAuthError(
                message="Google OAuth service temporarily unavailable",
                provider="google",
            ) from e
        except SemaphoreTimeoutError as e:
            logger.warning(
                "oauth_semaphore_timeout",
                provider="google",
            )
            raise OAuthError(
                message="Google OAuth service is overloaded, please try again later",
                provider="google",
            ) from e

    async def _get_user_info_internal(self, access_token: str) -> GoogleUserInfo:
        """Internal method for user info fetch with retry, circuit breaker, and bulkhead."""

        @self._circuit_breaker.call
        @retry(
            retry=retry_if_exception_type(RETRYABLE_EXCEPTIONS),
            stop=stop_after_attempt(MAX_RETRY_ATTEMPTS),
            wait=wait_exponential(multiplier=RETRY_MIN_WAIT, max=RETRY_MAX_WAIT),
            before_sleep=before_sleep_log(logger, log_level=20),
            reraise=True,
        )
        async def _do_fetch() -> GoogleUserInfo:
            # Bulkhead with timeout — see _do_exchange for why we use `acquired`.
            acquired = False
            try:
                await self._acquire_semaphore()
                acquired = True
                async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                    try:
                        response = await client.get(
                            GOOGLE_USERINFO_URL,
                            headers={"Authorization": f"Bearer {access_token}"},
                        )
                        response.raise_for_status()
                        data = response.json()

                        logger.debug(
                            "oauth_user_info_fetched",
                            provider="google",
                            email=data.get("email"),
                        )

                        return GoogleUserInfo(
                            id=data["sub"],
                            email=data["email"],
                            email_verified=data.get("email_verified", False),
                            name=data.get("name"),
                            given_name=data.get("given_name"),
                            family_name=data.get("family_name"),
                            picture=data.get("picture"),
                        )
                    except httpx.TimeoutException:
                        logger.warning(
                            "oauth_user_info_timeout",
                            provider="google",
                        )
                        # Re-raise for retry
                        raise
                    except httpx.HTTPStatusError as e:
                        # HTTP errors - don't retry 4xx
                        if HTTP_CLIENT_ERROR_MIN <= e.response.status_code < HTTP_CLIENT_ERROR_MAX:
                            logger.exception(
                                "oauth_user_info_client_error",
                                provider="google",
                                status=e.response.status_code,
                            )
                            raise OAuthError(
                                message="Failed to retrieve user information",
                                provider="google",
                            ) from e
                        # 5xx errors are transient, will be retried
                        logger.warning(
                            "oauth_user_info_server_error",
                            provider="google",
                            status=e.response.status_code,
                        )
                        raise
                    except Exception as e:
                        logger.exception(
                            "oauth_user_info_failed",
                            provider="google",
                            error=str(e),
                        )
                        raise OAuthError(
                            message="Failed to retrieve user information",
                            provider="google",
                        ) from e
            finally:
                if acquired:
                    self._semaphore.release()

        return await _do_fetch()

    async def authenticate(self, code: str) -> GoogleUserInfo:
        """
        Complete OAuth flow: exchange code and get user info.

        Args:
            code: Authorization code from callback

        Returns:
            GoogleUserInfo with user details

        Raises:
            OAuthError: If authentication fails
        """
        tokens = await self.exchange_code(code)
        access_token = tokens.get("access_token")

        if not access_token:
            raise OAuthError(
                message="No access token in response",
                provider="google",
            )

        return await self.get_user_info(access_token)
