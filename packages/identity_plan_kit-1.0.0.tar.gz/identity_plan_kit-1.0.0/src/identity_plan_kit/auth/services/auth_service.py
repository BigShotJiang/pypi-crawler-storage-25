"""Authentication service."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime, timedelta
from functools import lru_cache
from typing import TYPE_CHECKING
from urllib.parse import urlparse
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from identity_plan_kit.auth.cache.auth_cache import AbstractAuthCache
from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.auth.domain.exceptions import (
    MetadataValidationError,
    PasswordValidationError,
    TokenExpiredError,
    TokenInvalidError,
    UserInactiveError,
    UserNotFoundError,
)
from identity_plan_kit.auth.repositories.token_repo import RefreshTokenRepository
from identity_plan_kit.auth.services.oauth_service import GoogleOAuthService
from identity_plan_kit.auth.uow import AuthUnitOfWork
from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.shared.audit import (
    audit_token_refreshed,
    audit_token_reuse_detected,
    audit_user_authenticated,
    audit_user_deactivated,
    audit_user_logout,
    audit_user_registered,
)
from identity_plan_kit.shared.constants import (
    UNSET,
    USER_DISPLAY_NAME_MAX_LENGTH,
    USER_METADATA_MAX_KEYS,
    USER_METADATA_MAX_SIZE_BYTES,
    USER_PICTURE_URL_MAX_LENGTH,
)
from identity_plan_kit.shared.exceptions import ValidationError
from identity_plan_kit.shared.lockout import AccountLockedError, LockoutConfig, LockoutManager
from identity_plan_kit.shared.logging import get_logger
from identity_plan_kit.shared.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    decrypt_from_cache,
    encrypt_for_cache,
    hash_password,
    hash_token,
    verify_password,
)
from identity_plan_kit.shared.state_store import get_state_store

if TYPE_CHECKING:
    from identity_plan_kit.registry import ExtensionConfig

logger = get_logger(__name__)

# Key prefix for refresh idempotency tracking
REFRESH_IDEMPOTENCY_PREFIX = "token_refresh:"

# Key prefix for logout tombstones. Set by ``logout()``; checked by
# ``refresh_tokens()`` before firing the reuse-detection branch so a stale
# multi-tab refresh that arrives *after* a legitimate logout is rejected as
# "session ended" instead of being escalated to suspected theft (which would
# deactivate the user's account).
LOGOUT_TOMBSTONE_PREFIX = "logout_tombstone:"

# Minimum password length for security (module-level constant per conventions).
MIN_PASSWORD_LENGTH = 8

# Pre-compiled regex for password complexity checks (avoid recompiling per call).
_PASSWORD_UPPER_RE = re.compile(r"[A-Z]")
_PASSWORD_DIGIT_RE = re.compile(r"\d")
_PASSWORD_SPECIAL_RE = re.compile(r"[!@#$%^&*(),.?\":{}|<>_\-+=\[\]\\\/;'`~]")


def _is_safe_picture_url(url: str) -> bool:
    """
    Whitelist-check a profile picture URL before persisting/caching it.

    Google profile pictures are HTTPS URLs. Anything else (javascript:, data:,
    file:, http:, internal hostnames presented by a crafted Google account)
    is dropped — apps render this value as <img src=...> or proxy it, so an
    unvalidated URL is both an XSS and an SSRF vector.
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    return parsed.scheme == "https" and bool(parsed.netloc)


@lru_cache(maxsize=1)
def _timing_padding_hash() -> str:
    """
    A bcrypt hash used solely as timing padding when verifying passwords for users
    that have no stored hash (OAuth-only). Computed once per process.
    """
    # The plaintext below is never used as a real password — it's just a stable
    # input for generating a single padding hash with the configured cost.
    return hash_password("ipk-timing-padding-not-a-real-password")


# Re-export for convenience
__all__ = ["AccountLockedError", "AuthService"]


class AuthService:
    """Service for authentication operations."""

    def __init__(
        self,
        config: IdentityPlanKitConfig,
        session_factory: async_sessionmaker[AsyncSession],
        lockout_config: LockoutConfig | None = None,
        extension_config: ExtensionConfig | None = None,
        auth_cache: AbstractAuthCache | None = None,
    ) -> None:
        """Initialize AuthService."""
        self._config = config
        self._session_factory = session_factory
        self._google_oauth = GoogleOAuthService(config)
        self._secret_key = config.secret_key.get_secret_value()
        self._algorithm = config.algorithm
        self._lockout_config = lockout_config or LockoutConfig()
        self._lockout_manager: LockoutManager | None = None
        self._extension_config = extension_config
        self._auth_cache = auth_cache

    def _create_uow(
        self,
        session: AsyncSession | None = None,
    ) -> AuthUnitOfWork:
        """Create a new Unit of Work instance."""
        return AuthUnitOfWork(
            self._session_factory,
            session=session,
            extension_config=self._extension_config,
        )

    def _get_lockout_manager(self) -> LockoutManager:
        """Get or create lockout manager (lazy initialization)."""
        if self._lockout_manager is None:
            self._lockout_manager = LockoutManager(
                get_state_store(),
                self._lockout_config,
            )
        return self._lockout_manager

    @property
    def google_oauth(self) -> GoogleOAuthService:
        """Get Google OAuth service."""
        return self._google_oauth

    async def get_user_from_token(
        self,
        token: str,
        include_role: bool = True,
    ) -> User:
        """Get user from access token."""
        payload = decode_token(
            token,
            self._secret_key,
            self._algorithm,
        )

        if payload.get("type") != "access":
            raise TokenInvalidError("Invalid token type")

        user_id = payload.get("sub")
        if not user_id:
            raise TokenInvalidError("Missing user ID in token")

        user_uuid = UUID(user_id)

        # Check auth cache first (if enabled).
        if self._auth_cache:
            cached_user = await self._auth_cache.get(user_uuid)
            if cached_user:
                if not cached_user.is_active:
                    raise UserInactiveError()
                logger.debug("auth_cache_hit", user_id=user_id)
                return cached_user

        # Cache miss or cache disabled — fetch from DB.
        # Capture the timestamp BEFORE the DB read so the stale-write check can
        # reject any cache write that races with a concurrent invalidation.
        fetch_timestamp = self._auth_cache.get_fetch_timestamp() if self._auth_cache else None

        async with self._create_uow() as uow:
            user = await uow.users.get_by_id(user_uuid, include_role=include_role)

            if user is None:
                raise UserNotFoundError()

            if not user.is_active:
                raise UserInactiveError()

        # Cache the user+role for future requests (best-effort, after commit).
        if self._auth_cache and include_role:
            try:
                await self._auth_cache.set(user_uuid, user, fetched_at=fetch_timestamp)
            except Exception:
                logger.warning("auth_cache_set_failed", user_id=str(user_uuid))

        return user

    async def authenticate_google(  # noqa: PLR0912
        self,
        code: str,
        default_role_code: str | None = None,
        user_agent: str | None = None,
        ip_address: str | None = None,
    ) -> tuple[User, str, str]:
        """
        Authenticate user via Google OAuth.

        Creates new user if not exists, or links Google account if email exists.
        """
        role_code = default_role_code or self._config.default_role_code
        plan_code = self._config.default_plan_code
        lockout = self._get_lockout_manager()

        # Check IP-based lockout before contacting Google (we don't know email yet).
        if ip_address:
            await lockout.check_lockout(f"ip:{ip_address}", ip_address)

        try:
            google_user = await self._google_oauth.authenticate(code)
        except Exception as e:
            logger.warning(
                "google_oauth_authentication_failed",
                error_type=type(e).__name__,
                ip_address=ip_address,
            )
            if ip_address:
                await lockout.record_failure(
                    f"ip:{ip_address}",
                    ip_address,
                    reason="oauth_code_invalid",
                    user_agent=user_agent,
                )
            raise

        await lockout.check_lockout(google_user.email, ip_address)

        async with self._create_uow() as uow:
            role = await uow.rbac.get_role_by_code(role_code)
            if role is None:
                # Server-side configuration issue — surface as a 422 (validation
                # error) rather than an unhandled 500. Generic message keeps
                # internal config details out of the response.
                raise ValidationError("Default role is not configured")

            plan = await uow.plans.get_plan_by_code(plan_code)
            if plan is None:
                raise ValidationError("Default plan is not configured")

            display_name = google_user.name
            if not display_name or not display_name.strip():
                display_name = google_user.email.split("@")[0]
            else:
                display_name = display_name.strip()

            if len(display_name) > USER_DISPLAY_NAME_MAX_LENGTH:
                display_name = display_name[:USER_DISPLAY_NAME_MAX_LENGTH]

            picture_url = google_user.picture
            if picture_url and not _is_safe_picture_url(picture_url):
                # Reject non-https, non-network-locator URLs to block
                # javascript:/data:/file: schemes (XSS) and metadata SSRF
                # vectors that can ride in on a crafted Google profile.
                picture_url = None
            if picture_url and len(picture_url) > USER_PICTURE_URL_MAX_LENGTH:
                # URL is too long, skip rather than truncate (would be invalid).
                picture_url = None

            # Race-condition safe: get existing user or create new one.
            # display_name and picture_url only used for NEW users.
            user, created = await uow.users.get_or_create_with_provider(
                email=google_user.email,
                role_id=role.id,
                provider_code="google",
                external_user_id=google_user.id,
                display_name=display_name,
                picture_url=picture_url,
                is_verified=google_user.email_verified,
            )

            if created:
                await uow.plans.create_user_plan(
                    user_id=user.id,
                    plan_id=plan.id,
                )
                logger.info(
                    "user_registered",
                    user_id=str(user.id),
                    provider="google",
                    default_plan=plan_code,
                )
                audit_user_registered(
                    user_id=user.id,
                    email=user.email,
                    provider="google",
                    ip_address=ip_address,
                    user_agent=user_agent,
                )
            else:
                logger.info(
                    "user_authenticated_existing",
                    user_id=str(user.id),
                    provider="google",
                )

            if not user.is_active:
                raise UserInactiveError()

            access_token, refresh_token = await self._create_and_store_tokens(
                user=user,
                token_repo=uow.tokens,
                user_agent=user_agent,
                ip_address=ip_address,
            )

            logger.info(
                "user_authenticated",
                user_id=str(user.id),
                provider="google",
            )

            audit_user_authenticated(
                user_id=user.id,
                email=user.email,
                provider="google",
                ip_address=ip_address,
                user_agent=user_agent,
            )

            await lockout.clear_failures(google_user.email, ip_address)
            if ip_address:
                await lockout.clear_failures(f"ip:{ip_address}", ip_address)

            return user, access_token, refresh_token

    async def refresh_tokens(  # noqa: PLR0912, PLR0915
        self,
        refresh_token: str,
        user_agent: str | None = None,
        ip_address: str | None = None,
    ) -> tuple[User, str, str]:
        """
        Refresh access token using refresh token (with rotation and idempotency).

        Idempotency: if the same refresh token is presented twice within the
        configured TTL, the second request returns the same tokens cached from
        the first call instead of (incorrectly) tripping reuse detection.
        """
        payload = decode_token(
            refresh_token,
            self._secret_key,
            self._algorithm,
            verify_exp=False,
        )

        if payload.get("type") != "refresh":
            raise TokenInvalidError("Invalid token type")

        token_hash = hash_token(refresh_token)
        idempotency_key = f"{REFRESH_IDEMPOTENCY_PREFIX}{token_hash}"
        state_store = get_state_store()

        # Step 1: idempotency hit path. If the cache entry is malformed or the
        # tokens cannot be decrypted, we delete the entry and reject the request
        # with TokenInvalidError. We deliberately do NOT fall through to the
        # normal rotation flow — falling through would re-look up the now-revoked
        # token and trigger the theft-detection branch against a legitimate retry.
        cached_result = await state_store.get(idempotency_key)
        if cached_result is not None and isinstance(cached_result, dict):
            cached_data: dict[str, str] = cached_result  # type: ignore[assignment]
            cached_user_id_str = cached_data.get("user_id")
            logger.debug("token_refresh_idempotency_hit", user_id=cached_user_id_str)

            encrypted_access = cached_data.get("access_token_enc")
            encrypted_refresh = cached_data.get("refresh_token_enc")

            if not (cached_user_id_str and encrypted_access and encrypted_refresh):
                logger.warning(
                    "token_refresh_idempotency_cache_malformed",
                    user_id=cached_user_id_str,
                )
                await state_store.delete(idempotency_key)
                raise TokenInvalidError("Session expired, please log in again")

            cached_access = decrypt_from_cache(encrypted_access, self._secret_key)
            cached_refresh = decrypt_from_cache(encrypted_refresh, self._secret_key)
            if not (cached_access and cached_refresh):
                logger.warning(
                    "token_refresh_idempotency_decryption_failed",
                    user_id=cached_user_id_str,
                )
                await state_store.delete(idempotency_key)
                raise TokenInvalidError("Session expired, please log in again")

            # Verify the user is still valid before returning cached tokens.
            async with self._create_uow() as uow:
                user = await uow.users.get_by_id(UUID(cached_user_id_str))
                if user is None:
                    raise UserNotFoundError()
                if not user.is_active:
                    raise UserInactiveError()
            return user, cached_access, cached_refresh

        # Step 2: rotation / theft-detection branch. We must persist the
        # deactivation BEFORE raising — letting the UoW commit guarantees this.
        # If we raised inside the UoW, rollback would silently discard the
        # security response.
        deactivated_user_id: UUID | None = None
        rotation_user: User | None = None
        rotation_access: str | None = None
        rotation_refresh: str | None = None

        async with self._create_uow() as uow:
            # Use get_by_hash_any so revoked tokens are observable here —
            # required for the reuse-detection branch below. Check is_revoked
            # BEFORE is_expired so a stolen-and-expired token still triggers
            # the security response instead of being dismissed as expired.
            stored_token = await uow.tokens.get_by_hash_any(token_hash, for_update=True)
            if stored_token is None:
                logger.warning("refresh_token_not_found")
                raise TokenInvalidError("Token not found")

            if stored_token.is_revoked:
                # Re-check the idempotency cache while holding the SELECT FOR
                # UPDATE lock. A concurrent retry of the same refresh token
                # can land here when the winning rotation has already revoked
                # the row but not yet committed the idempotency entry. In
                # that case the loser would otherwise trip theft detection
                # and deactivate a legitimate user. If the entry is now
                # present, the rotation is the loser's own retry — return the
                # cached tokens instead of escalating.
                retry_cached = await state_store.get(idempotency_key)
                if retry_cached is not None and isinstance(retry_cached, dict):
                    retry_user_id_str = retry_cached.get("user_id")
                    enc_access = retry_cached.get("access_token_enc")
                    enc_refresh = retry_cached.get("refresh_token_enc")
                    if retry_user_id_str and enc_access and enc_refresh:
                        retry_access = decrypt_from_cache(enc_access, self._secret_key)
                        retry_refresh = decrypt_from_cache(enc_refresh, self._secret_key)
                        if retry_access and retry_refresh:
                            user = await uow.users.get_by_id(UUID(retry_user_id_str))
                            if user is None:
                                raise UserNotFoundError()
                            if not user.is_active:
                                raise UserInactiveError()
                            logger.info(
                                "token_refresh_idempotency_hit_after_revoke",
                                user_id=retry_user_id_str,
                            )
                            return user, retry_access, retry_refresh

                # Logout tombstone check — distinguish "user explicitly
                # logged out" from "attacker replayed a rotated token".
                # Without this, a stale tab calling refresh after the user
                # clicked logout would trigger reuse detection and deactivate
                # the account. Tombstone set in ``logout()``.
                tombstone_key = f"{LOGOUT_TOMBSTONE_PREFIX}{token_hash}"
                try:
                    tombstone = await state_store.get(tombstone_key)
                except Exception:
                    tombstone = None
                if tombstone is not None:
                    logger.info(
                        "refresh_token_used_after_logout",
                        user_id=str(stored_token.user_id),
                    )
                    raise TokenInvalidError("Session ended")

                logger.critical(
                    "refresh_token_reuse_detected",
                    user_id=str(stored_token.user_id),
                    original_ip=stored_token.ip_address,
                    original_user_agent=stored_token.user_agent,
                    current_ip=ip_address,
                    current_user_agent=user_agent,
                )
                audit_token_reuse_detected(
                    user_id=stored_token.user_id,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    original_ip=stored_token.ip_address,
                    original_user_agent=stored_token.user_agent,
                )

                await uow.tokens.revoke_all_for_user(stored_token.user_id)
                victim = await uow.users.get_by_id(stored_token.user_id, for_update=True)
                if victim and victim.is_active:
                    await uow.users.deactivate(
                        stored_token.user_id,
                        reason="token_theft_suspected",
                    )
                    deactivated_user_id = stored_token.user_id
                    audit_user_deactivated(
                        user_id=stored_token.user_id,
                        reason="Automatic deactivation due to refresh token reuse (potential theft)",
                    )
                # Fall through — UoW commits the revocation/deactivation, then
                # we invalidate cache and raise outside the block.
            else:
                if stored_token.is_expired:
                    logger.warning(
                        "refresh_token_expired",
                        user_id=str(stored_token.user_id),
                    )
                    raise TokenExpiredError()

                # Normal rotation path.
                user = await uow.users.get_by_id(stored_token.user_id, for_update=True)
                if user is None:
                    raise UserNotFoundError()
                if not user.is_active:
                    raise UserInactiveError()

                await uow.tokens.revoke(stored_token.id)

                access_token, new_refresh_token = await self._create_and_store_tokens(
                    user=user,
                    token_repo=uow.tokens,
                    user_agent=user_agent,
                    ip_address=ip_address,
                )
                logger.info("tokens_refreshed", user_id=str(user.id))
                audit_token_refreshed(
                    user_id=user.id,
                    ip_address=ip_address,
                    user_agent=user_agent,
                )
                rotation_user = user
                rotation_access = access_token
                rotation_refresh = new_refresh_token

        # After UoW commit — handle the security response if applicable.
        if deactivated_user_id is not None:
            if self._auth_cache:
                try:
                    await self._auth_cache.invalidate(deactivated_user_id)
                except Exception:
                    logger.warning(
                        "auth_cache_invalidate_failed_on_deactivation",
                        user_id=str(deactivated_user_id),
                    )
            raise TokenInvalidError("Token has been revoked - account secured")

        # Defensive guard — should never trigger, all branches above raise or
        # set the rotation_* locals.
        if rotation_user is None or rotation_access is None or rotation_refresh is None:
            raise TokenInvalidError("Token refresh failed unexpectedly")

        # Idempotency cache write happens AFTER commit (best-effort). If it
        # fails we still return the issued tokens — the only consequence is
        # that a network retry won't get idempotency.
        user = rotation_user
        access_token = rotation_access
        new_refresh_token = rotation_refresh
        try:
            await state_store.set(
                idempotency_key,
                {
                    "user_id": str(user.id),
                    "access_token_enc": encrypt_for_cache(access_token, self._secret_key),
                    "refresh_token_enc": encrypt_for_cache(new_refresh_token, self._secret_key),
                },
                ttl_seconds=self._config.token_refresh_idempotency_ttl_seconds,
            )
        except Exception:
            logger.warning(
                "token_refresh_idempotency_cache_set_failed",
                user_id=str(user.id),
            )

        return user, access_token, new_refresh_token

    async def logout(
        self,
        user_id: UUID,
        refresh_token: str | None = None,
        everywhere: bool = False,
        ip_address: str | None = None,
    ) -> None:
        """Logout user by revoking tokens."""
        tokens_revoked = 0
        state_store = get_state_store()

        async with self._create_uow() as uow:
            if everywhere:
                tokens_revoked = await uow.tokens.revoke_all_for_user(user_id)
                logger.info(
                    "user_logged_out_everywhere",
                    user_id=str(user_id),
                    tokens_revoked=tokens_revoked,
                )
            elif refresh_token:
                token_hash = hash_token(refresh_token)
                stored_token = await uow.tokens.get_by_hash(token_hash)
                if stored_token:
                    await uow.tokens.revoke(stored_token.id)
                    tokens_revoked = 1
                    logger.info("user_logged_out", user_id=str(user_id))

                    # Clear idempotency cache entry — without this, a stale
                    # retry would hit the cache and receive the rotated
                    # tokens despite the logout.
                    idempotency_key = f"{REFRESH_IDEMPOTENCY_PREFIX}{token_hash}"
                    await state_store.delete(idempotency_key)

                    # Write a logout tombstone keyed by this token's hash so
                    # ``refresh_tokens()`` can distinguish a logout-revoked
                    # token from a rotation-revoked-and-replayed token (i.e.
                    # suspected theft). TTL bounded by the refresh token's
                    # natural lifetime — past that point the JWT is moot.
                    tombstone_key = f"{LOGOUT_TOMBSTONE_PREFIX}{token_hash}"
                    try:
                        await state_store.set(
                            tombstone_key,
                            {"reason": "logout"},
                            ttl_seconds=self._config.refresh_token_expire_days
                            * 86400,
                        )
                    except Exception:
                        # Tombstone is best-effort — if the state store is
                        # down, we fall back to the previous behaviour (a
                        # stale refresh after logout may trip theft detection).
                        logger.warning(
                            "logout_tombstone_set_failed",
                            user_id=str(user_id),
                            exc_info=True,
                        )

        # Cache invalidation happens AFTER commit.
        if self._auth_cache:
            try:
                await self._auth_cache.invalidate(user_id)
                logger.debug("auth_cache_invalidated_on_logout", user_id=str(user_id))
            except Exception:
                logger.warning("auth_cache_invalidate_failed_on_logout", user_id=str(user_id))

        audit_user_logout(
            user_id=user_id,
            everywhere=everywhere,
            tokens_revoked=tokens_revoked,
            ip_address=ip_address,
        )

    async def _create_and_store_tokens(
        self,
        user: User,
        token_repo: RefreshTokenRepository,
        user_agent: str | None = None,
        ip_address: str | None = None,
    ) -> tuple[str, str]:
        """Create access and refresh tokens for user and persist the refresh hash."""
        access_token = create_access_token(
            data={"sub": str(user.id)},
            secret_key=self._secret_key,
            algorithm=self._algorithm,
            expires_delta=timedelta(minutes=self._config.access_token_expire_minutes),
        )

        refresh_token, token_hash = create_refresh_token(
            data={"sub": str(user.id)},
            secret_key=self._secret_key,
            algorithm=self._algorithm,
            expires_delta=timedelta(days=self._config.refresh_token_expire_days),
        )

        expires_at = datetime.now(UTC) + timedelta(days=self._config.refresh_token_expire_days)
        await token_repo.create(
            user_id=user.id,
            token_hash=token_hash,
            expires_at=expires_at,
            user_agent=user_agent,
            ip_address=ip_address,
        )

        return access_token, refresh_token

    # =========================================================================
    # PROFILE MANAGEMENT
    # =========================================================================

    async def update_profile(
        self,
        user_id: UUID,
        display_name: str | None = None,
        picture_url: str | None | object = UNSET,
        metadata: dict | None | object = UNSET,
    ) -> User:
        """Update user profile (display_name, picture_url, metadata)."""
        if metadata is not UNSET and metadata is not None:
            self._validate_metadata(metadata)

        async with self._create_uow() as uow:
            user = await uow.users.update_profile(
                user_id=user_id,
                display_name=display_name,
                picture_url=picture_url,
                metadata=metadata,
            )

            if user is None:
                raise UserNotFoundError()

        # Cache invalidation after commit.
        if self._auth_cache:
            try:
                await self._auth_cache.invalidate(user_id)
            except Exception:
                logger.warning("auth_cache_invalidate_failed_on_update", user_id=str(user_id))

        return user

    def _validate_metadata(self, metadata: dict) -> None:
        """Validate metadata meets size/key/serializability constraints."""
        if not isinstance(metadata, dict):
            raise MetadataValidationError("Metadata must be a JSON object")

        if len(metadata) > USER_METADATA_MAX_KEYS:
            raise MetadataValidationError(
                f"Metadata exceeds maximum of {USER_METADATA_MAX_KEYS} keys"
            )

        try:
            serialized = json.dumps(metadata)
        except (TypeError, ValueError) as e:
            raise MetadataValidationError("Metadata contains non-serializable values") from e

        if len(serialized.encode()) > USER_METADATA_MAX_SIZE_BYTES:
            raise MetadataValidationError(
                f"Metadata exceeds maximum size of {USER_METADATA_MAX_SIZE_BYTES} bytes"
            )

    # =========================================================================
    # PASSWORD MANAGEMENT
    # =========================================================================

    async def set_user_password(
        self,
        user_id: UUID,
        password: str,
        *,
        require_admin_role: bool = True,
    ) -> bool:
        """Set password for a user (typically for admin panel access)."""
        self._validate_password(password)

        async with self._create_uow() as uow:
            user = await uow.users.get_by_id(user_id, for_update=True)

            if user is None:
                raise UserNotFoundError()

            if not user.is_active:
                raise UserInactiveError()

            # Distinguish between "no role loaded" (data integrity) and "wrong
            # role" (legitimate denial). Without this split, both surface as
            # the same misleading "not admin" error.
            if require_admin_role:
                if user.role_code is None:
                    logger.warning(
                        "set_password_role_not_loaded",
                        user_id=str(user_id),
                    )
                    raise PasswordValidationError("User role could not be verified")
                if user.role_code != "admin":
                    raise PasswordValidationError(
                        "Password can only be set for users with admin role"
                    )

            hashed = hash_password(password)
            success = await uow.users.set_password_hash(user_id, hashed)

            if success:
                logger.info(
                    "user_password_set",
                    user_id=str(user_id),
                    role=user.role_code,
                )

            return success

    async def verify_user_password(
        self,
        user_id: UUID,
        password: str,
    ) -> bool:
        """
        Verify a user's password.

        For users without a stored hash (OAuth-only), we run bcrypt against a
        constant padding hash anyway, so the timing profile of "wrong password"
        and "OAuth-only user" is indistinguishable.
        """
        async with self._create_uow() as uow:
            password_hash = await uow.users.get_password_hash(user_id)

            if password_hash is None:
                # Pad with bcrypt against a dummy hash to keep timing constant.
                verify_password(password, _timing_padding_hash())
                user = await uow.users.get_by_id(user_id)
                if user is None:
                    raise UserNotFoundError()
                return False

            return verify_password(password, password_hash)

    async def clear_user_password(
        self,
        user_id: UUID,
    ) -> bool:
        """Remove password from user (revert to OAuth-only)."""
        async with self._create_uow() as uow:
            user = await uow.users.get_by_id(user_id)

            if user is None:
                raise UserNotFoundError()

            success = await uow.users.clear_password_hash(user_id)

            if success:
                logger.info("user_password_cleared", user_id=str(user_id))

            return success

    def _validate_password(self, password: str) -> None:
        """Validate password meets minimum complexity requirements."""
        if len(password) < MIN_PASSWORD_LENGTH:
            raise PasswordValidationError(
                f"Password must be at least {MIN_PASSWORD_LENGTH} characters"
            )

        if not _PASSWORD_UPPER_RE.search(password):
            raise PasswordValidationError("Password must contain at least one uppercase letter")

        if not _PASSWORD_DIGIT_RE.search(password):
            raise PasswordValidationError("Password must contain at least one digit")

        if not _PASSWORD_SPECIAL_RE.search(password):
            raise PasswordValidationError("Password must contain at least one special character")

    # =========================================================================
    # CACHE MANAGEMENT
    # =========================================================================

    async def invalidate_auth_cache(self, user_id: UUID) -> None:
        """Invalidate auth cache for a user."""
        if self._auth_cache:
            await self._auth_cache.invalidate(user_id)
            logger.debug("auth_cache_invalidated_by_consumer", user_id=str(user_id))
