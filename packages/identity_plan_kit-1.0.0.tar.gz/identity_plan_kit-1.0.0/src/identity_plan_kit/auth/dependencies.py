"""Auth FastAPI dependencies."""

from collections.abc import Callable, Coroutine
from typing import Annotated, Any

from fastapi import Cookie, Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.auth.domain.exceptions import (
    AuthError,
    TokenExpiredError,
    TokenInvalidError,
    UserInactiveError,
    UserNotFoundError,
)
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)

# Bearer token security scheme
bearer_scheme = HTTPBearer(auto_error=False)


def _extract_token(
    credentials: HTTPAuthorizationCredentials | None,
    cookie_token: str | None,
) -> str | None:
    """Extract JWT token from either Authorization header or cookie."""
    if credentials:
        return credentials.credentials
    if cookie_token:
        return cookie_token
    return None


def current_user(
    include_role: bool = True,
) -> Callable[..., Coroutine[Any, Any, User]]:
    """
    Create a parameterized current-user dependency.

    Use this when you need to control whether role is loaded:

        @router.get("/generate")
        async def generate(
            user: Annotated[User, Depends(current_user(include_role=False))],
        ):
            ...

    Args:
        include_role: If True (default), eagerly load the user's role.
            Set to False to skip the role query when role info is not needed.
    """

    async def _get_user(
        request: Request,
        credentials: Annotated[
            HTTPAuthorizationCredentials | None,
            Depends(bearer_scheme),
        ] = None,
        access_token: Annotated[str | None, Cookie(alias="access_token")] = None,
    ) -> User:
        token = _extract_token(credentials, access_token)

        if not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )

        kit = request.app.state.identity_plan_kit
        auth_service = kit.auth_service

        try:
            return await auth_service.get_user_from_token(token, include_role=include_role)
        except TokenExpiredError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired",
                headers={"WWW-Authenticate": "Bearer"},
            ) from None
        except (TokenInvalidError, AuthError):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
                headers={"WWW-Authenticate": "Bearer"},
            ) from None
        except UserNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            ) from None
        except UserInactiveError:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is inactive",
            ) from None

    return _get_user


# Default current-user dependency — loads the user with role eagerly populated.
# Single source of truth: parametrize via `current_user(include_role=...)` for
# specialized variants instead of duplicating the body.
get_current_user = current_user(include_role=True)


async def get_optional_user(
    request: Request,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None,
        Depends(bearer_scheme),
    ] = None,
    access_token: Annotated[str | None, Cookie(alias="access_token")] = None,
) -> User | None:
    """Get the current user if authenticated, None otherwise."""
    token = _extract_token(credentials, access_token)

    if not token:
        return None

    try:
        kit = request.app.state.identity_plan_kit
        auth_service = kit.auth_service
        return await auth_service.get_user_from_token(token)
    except AuthError:
        # Expected auth errors (expired, invalid token, etc.) — return None.
        return None
    except Exception:
        # Unexpected errors (DB failures, config issues) — log and re-raise so
        # we don't silently mask infrastructure failures.
        logger.exception(
            "unexpected_error_in_optional_auth",
            has_token=bool(token),
        )
        raise


# Type aliases for dependency injection.
CurrentUser = Annotated[User, Depends(get_current_user)]
OptionalUser = Annotated[User | None, Depends(get_optional_user)]

# Optimized variant that skips role loading (saves 1 DB query). Use when role
# info is not needed for the endpoint.
CurrentUserNoRole = Annotated[User, Depends(current_user(include_role=False))]
