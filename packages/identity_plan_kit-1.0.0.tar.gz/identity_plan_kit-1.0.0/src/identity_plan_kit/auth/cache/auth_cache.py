"""Auth cache for fast user+role lookups with Redis support.

This cache eliminates +2 DB queries per authenticated request by caching user+role data.
"""

import asyncio
import json
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from uuid import UUID

from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.shared.constants import (
    AUTH_CACHE_TTL_SECONDS,
    DEFAULT_MAX_CACHE_ENTRIES,
    REDIS_CIRCUIT_FAILURE_THRESHOLD,
    REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS,
    REDIS_CIRCUIT_RECOVERY_TIMEOUT,
    REDIS_RETRY_ATTEMPTS,
    REDIS_RETRY_BASE_DELAY,
    REDIS_SOCKET_CONNECT_TIMEOUT,
    REDIS_SOCKET_TIMEOUT,
)
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)

# Optional Redis support
try:
    import redis.asyncio as redis

    REDIS_AVAILABLE = True
except ImportError:
    redis = None  # type: ignore[assignment]
    REDIS_AVAILABLE = False


class CacheCircuitState(Enum):
    """Circuit breaker states for cache."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


def _user_to_dict(user: User) -> dict:
    """Convert User entity to JSON-serializable dict."""
    return {
        "id": str(user.id),
        "email": user.email,
        "role_id": str(user.role_id),
        "display_name": user.display_name,
        "picture_url": user.picture_url,
        "metadata": user.metadata,
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "created_at": user.created_at.isoformat(),
        "updated_at": user.updated_at.isoformat(),
        "role_code": user.role_code,
        "permissions": list(user.permissions) if user.permissions else [],
    }


def _parse_utc_isoformat(value: str) -> datetime:
    """Parse ISO datetime, ensuring tzinfo=UTC for naive inputs."""
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed


def _dict_to_user(data: dict) -> User:
    """Convert dict back to User entity."""
    return User(
        id=UUID(data["id"]),
        email=data["email"],
        role_id=UUID(data["role_id"]),
        display_name=data["display_name"],
        picture_url=data.get("picture_url"),
        metadata=data.get("metadata", {}),
        is_active=data["is_active"],
        is_verified=data["is_verified"],
        created_at=_parse_utc_isoformat(data["created_at"]),
        updated_at=_parse_utc_isoformat(data["updated_at"]),
        role_code=data.get("role_code"),
        permissions=set(data.get("permissions", [])),
    )


class AbstractAuthCache(ABC):
    """Abstract base class for auth caching."""

    @abstractmethod
    async def get(self, user_id: UUID) -> User | None:
        """Get cached user by ID."""
        pass

    @abstractmethod
    async def set(
        self,
        user_id: UUID,
        user: User,
        fetched_at: float | None = None,
    ) -> bool:
        """Cache user by ID."""
        pass

    @abstractmethod
    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user by ID."""
        pass

    @abstractmethod
    async def invalidate_all(self) -> None:
        """Invalidate all cached users."""
        pass

    def get_fetch_timestamp(self) -> float:
        """Get a monotonic timestamp for stale write prevention."""
        return time.monotonic()


@dataclass
class AuthCacheEntry:
    """Cache entry with expiration and fetch timestamp for race condition prevention."""

    user: User
    expires_at: datetime
    fetched_at: float = field(default_factory=time.monotonic)

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class InMemoryAuthCache(AbstractAuthCache):
    """
    In-memory auth cache.

    Caches user+role data (by user_id) to reduce database queries.

    **Race Condition Prevention:**

    This cache prevents stale writes after invalidation using a timestamp-based
    approach. When invalidate() is called, it records the invalidation time.
    Subsequent set() calls only succeed if their fetch timestamp is newer than
    the last invalidation.

    Warning:
        For multi-instance deployments, use RedisAuthCache instead.
        In-memory cache invalidation only affects the local instance.
    """

    def __init__(
        self,
        ttl_seconds: int = AUTH_CACHE_TTL_SECONDS,
        max_entries: int = DEFAULT_MAX_CACHE_ENTRIES,
    ) -> None:
        """
        Initialize auth cache.

        Args:
            ttl_seconds: Cache TTL in seconds (default: 60 seconds, 0 to disable)
            max_entries: Maximum entries before LRU eviction (default: 10_000)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._ttl_seconds = ttl_seconds
        self._max_entries = max_entries
        self._cache: OrderedDict[UUID, AuthCacheEntry] = OrderedDict()
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0
        # Bounded LRU dict — pruned alongside _cache when entries are evicted
        self._invalidated_at: OrderedDict[UUID, float] = OrderedDict()
        self._global_invalidated_at: float = 0.0

    async def get(self, user_id: UUID) -> User | None:
        """
        Get cached user by ID.

        Reads are intentionally lock-free for hot-path performance. Writes
        are serialised via ``_write_lock`` with timestamp-based stale-write
        rejection, so concurrent invalidate() cannot leak past — the worst
        case is returning a value that is about to be evicted, no worse
        than its TTL window.

        Args:
            user_id: User UUID

        Returns:
            User entity or None if not cached/expired
        """
        if not self._enabled:
            return None

        entry = self._cache.get(user_id)

        if entry is None:
            return None

        if entry.is_expired:
            return None

        return entry.user

    async def set(
        self,
        user_id: UUID,
        user: User,
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache user by ID.

        Args:
            user_id: User UUID
            user: User entity to cache
            fetched_at: Monotonic timestamp when the user was fetched from DB.

        Returns:
            True if the entry was cached, False if rejected as stale
        """
        if not self._enabled:
            return False

        # Acquire lock to prevent TOCTOU race with invalidate()/invalidate_all()
        # The stale-write check and cache write must be atomic
        async with self._write_lock:
            if fetched_at is not None:
                if fetched_at < self._global_invalidated_at:
                    logger.debug(
                        "auth_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="global_invalidation",
                    )
                    return False

                key_invalidated_at = self._invalidated_at.get(user_id, 0.0)
                if fetched_at < key_invalidated_at:
                    logger.debug(
                        "auth_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="key_invalidation",
                    )
                    return False

            entry = AuthCacheEntry(
                user=user,
                expires_at=datetime.now(UTC) + self._ttl,
                fetched_at=fetched_at or time.monotonic(),
            )
            self._cache[user_id] = entry
            self._cache.move_to_end(user_id)
            # LRU eviction: drop oldest entries past the cap
            while len(self._cache) > self._max_entries:
                evicted_key, _ = self._cache.popitem(last=False)
                self._invalidated_at.pop(evicted_key, None)
            return True

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user by ID."""
        async with self._write_lock:
            self._invalidated_at[user_id] = time.monotonic()
            self._invalidated_at.move_to_end(user_id)
            self._cache.pop(user_id, None)
            # LRU eviction: cap invalidation tombstones to bound memory.
            # The 2x factor lets recent invalidations outlive their corresponding
            # cache entries (see Lua TTL pattern in RedisAuthCache).
            max_invalidations = self._max_entries * 2
            while len(self._invalidated_at) > max_invalidations:
                self._invalidated_at.popitem(last=False)
            logger.debug("auth_cache_invalidated", user_id=str(user_id))

    async def invalidate_all(self) -> None:
        """Invalidate all cached users."""
        async with self._write_lock:
            self._global_invalidated_at = time.monotonic()
            self._cache.clear()
            self._invalidated_at.clear()
            logger.info("auth_cache_cleared")

    async def cleanup_expired(self) -> int:
        """Remove expired entries from cache."""
        async with self._write_lock:
            expired_keys = [key for key, entry in self._cache.items() if entry.is_expired]
            for key in expired_keys:
                del self._cache[key]

            if expired_keys:
                logger.debug("auth_cache_cleanup", removed_count=len(expired_keys))

            return len(expired_keys)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)


class RedisAuthCache(AbstractAuthCache):
    """
    Redis-backed auth cache for distributed deployments.

    Use this when running multiple application instances behind a load balancer.
    Ensures cache invalidation propagates to all instances.

    Features:
    - Circuit breaker: Fails fast when Redis is unavailable
    - Retry with exponential backoff: Handles transient failures
    - Configurable timeouts: Prevents hanging connections

    Requires: pip install redis
    """

    # Circuit breaker configuration (from constants)
    CIRCUIT_FAILURE_THRESHOLD = REDIS_CIRCUIT_FAILURE_THRESHOLD
    CIRCUIT_RECOVERY_TIMEOUT = REDIS_CIRCUIT_RECOVERY_TIMEOUT
    CIRCUIT_HALF_OPEN_MAX_CALLS = REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS

    # Lua script for atomic set with stale write prevention
    # Checks invalidation timestamps before writing to prevent stale data
    LUA_SET_WITH_TIMESTAMP_CHECK = """
        local fetched_at = ARGV[3]
        if fetched_at == "nil" then
            redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
            return 1
        end
        fetched_at = tonumber(fetched_at)
        local global_inv = redis.call("GET", KEYS[2])
        if global_inv and tonumber(global_inv) > fetched_at then
            return 0
        end
        local key_inv = redis.call("GET", KEYS[3])
        if key_inv and tonumber(key_inv) > fetched_at then
            return 0
        end
        redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
        return 1
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        ttl_seconds: int = AUTH_CACHE_TTL_SECONDS,
        key_prefix: str = "ipk:auth:user:",
        socket_timeout: float = REDIS_SOCKET_TIMEOUT,
        socket_connect_timeout: float = REDIS_SOCKET_CONNECT_TIMEOUT,
    ) -> None:
        """
        Initialize Redis auth cache.

        Args:
            redis_url: Redis connection URL
            ttl_seconds: Cache TTL in seconds (0 to disable)
            key_prefix: Prefix for cache keys
            socket_timeout: Timeout for socket operations (default: 5s)
            socket_connect_timeout: Timeout for connection (default: 5s)
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "Redis support requires the 'redis' package. Install with: pip install redis"
            )

        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix
        self._socket_timeout = socket_timeout
        self._socket_connect_timeout = socket_connect_timeout
        self._enabled = ttl_seconds > 0
        self._client: redis.Redis[bytes] | None = None

        # Circuit breaker state
        self._circuit_state = CacheCircuitState.CLOSED
        self._circuit_failures = 0
        self._circuit_successes = 0
        self._circuit_opened_at: datetime | None = None
        self._circuit_half_open_calls = 0
        self._circuit_lock = asyncio.Lock()

    def _make_key(self, user_id: UUID) -> str:
        """Create cache key for user."""
        return f"{self._key_prefix}{user_id}"

    def _make_invalidation_key(self, user_id: UUID) -> str:
        """
        Create invalidation timestamp key for user.

        Strip a trailing ``:`` from ``key_prefix`` before re-appending so the
        invalidation marker is always separated from the prefix by exactly one
        ``:``. Without this, a caller that configures ``key_prefix`` without a
        trailing ``:`` produces keys that collide with user-data keys under
        the SCAN pattern used by ``invalidate_all``.
        """
        prefix = self._key_prefix.rstrip(":")
        return f"{prefix}:_invalidated:{user_id}"

    def _make_global_invalidation_key(self) -> str:
        """Create global invalidation timestamp key."""
        prefix = self._key_prefix.rstrip(":")
        return f"{prefix}:_global_invalidated"

    async def _check_circuit(self) -> bool:
        """Check if circuit allows request."""
        async with self._circuit_lock:
            if self._circuit_state == CacheCircuitState.CLOSED:
                return True

            if self._circuit_state == CacheCircuitState.OPEN:
                if self._circuit_opened_at is not None:
                    elapsed = (datetime.now(UTC) - self._circuit_opened_at).total_seconds()
                    if elapsed >= self.CIRCUIT_RECOVERY_TIMEOUT:
                        self._circuit_state = CacheCircuitState.HALF_OPEN
                        self._circuit_half_open_calls = 0
                        self._circuit_successes = 0
                        logger.info("auth_cache_circuit_half_open")
                        return True
                return False

            if self._circuit_state == CacheCircuitState.HALF_OPEN:
                if self._circuit_half_open_calls < self.CIRCUIT_HALF_OPEN_MAX_CALLS:
                    self._circuit_half_open_calls += 1
                    return True
                return False

            return False

    # Circuit breaker success threshold for recovery
    CIRCUIT_SUCCESS_THRESHOLD = 2

    async def _record_success(self) -> None:
        """Record successful operation."""
        async with self._circuit_lock:
            self._circuit_successes += 1
            if (
                self._circuit_state == CacheCircuitState.HALF_OPEN
                and self._circuit_successes >= self.CIRCUIT_SUCCESS_THRESHOLD
            ):
                self._circuit_state = CacheCircuitState.CLOSED
                self._circuit_failures = 0
                logger.info("auth_cache_circuit_closed")

    async def _record_failure(self) -> None:
        """Record failed operation."""
        async with self._circuit_lock:
            self._circuit_failures += 1
            if self._circuit_state == CacheCircuitState.CLOSED:
                if self._circuit_failures >= self.CIRCUIT_FAILURE_THRESHOLD:
                    self._circuit_state = CacheCircuitState.OPEN
                    self._circuit_opened_at = datetime.now(UTC)
                    logger.warning("auth_cache_circuit_open", failures=self._circuit_failures)
            elif self._circuit_state == CacheCircuitState.HALF_OPEN:
                self._circuit_state = CacheCircuitState.OPEN
                self._circuit_opened_at = datetime.now(UTC)
                logger.warning("auth_cache_circuit_reopened")

    async def _execute_with_retry(
        self,
        operation: str,
        func: Callable[..., Awaitable[object]],
        *args: object,
        **kwargs: object,
    ) -> object | None:
        """Execute Redis operation with retry and circuit breaker."""
        if not await self._check_circuit():
            logger.debug("auth_cache_circuit_rejected", operation=operation)
            return None

        last_error: Exception | None = None
        for attempt in range(REDIS_RETRY_ATTEMPTS):
            try:
                result = await func(*args, **kwargs)
            except (redis.ConnectionError, redis.TimeoutError, OSError) as e:
                last_error = e
                if attempt < REDIS_RETRY_ATTEMPTS - 1:
                    delay = REDIS_RETRY_BASE_DELAY * (2**attempt)
                    logger.warning(
                        "auth_cache_retry",
                        operation=operation,
                        attempt=attempt + 1,
                        delay=delay,
                    )
                    await asyncio.sleep(delay)
            else:
                # Success - record and return
                await self._record_success()
                return result

        # Record single failure after all retries exhausted
        await self._record_failure()
        logger.warning("auth_cache_operation_failed", operation=operation, error=str(last_error))
        return None

    async def connect(
        self,
        max_retries: int = 3,
        base_delay: float = 0.5,
    ) -> None:
        """Connect to Redis with exponential backoff retry and timeouts."""
        self._client = redis.from_url(
            self._redis_url,
            encoding="utf-8",
            decode_responses=False,
            socket_timeout=self._socket_timeout,
            socket_connect_timeout=self._socket_connect_timeout,
        )

        last_error: Exception | None = None
        for attempt in range(max_retries):
            try:
                await self._client.ping()
            except (redis.ConnectionError, redis.TimeoutError, OSError) as e:
                last_error = e
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)
                    logger.warning(
                        "redis_auth_cache_connection_retry",
                        attempt=attempt + 1,
                        max_retries=max_retries,
                        delay=delay,
                        error=str(e),
                    )
                    await asyncio.sleep(delay)
            else:
                # Connection successful
                logger.info(
                    "redis_auth_cache_connected",
                    url=self._redis_url.split("@")[-1],
                )
                return

        # All connection attempts failed
        await self._client.aclose()
        self._client = None
        raise ConnectionError(
            f"Failed to connect to Redis after {max_retries} attempts: {last_error}"
        )

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def get(self, user_id: UUID) -> User | None:
        """Get cached user by ID with retry and circuit breaker."""
        if not self._enabled or not self._client:
            return None

        key = self._make_key(user_id)
        value = await self._execute_with_retry("get", self._client.get, key)
        if value is None:
            return None

        try:
            data = json.loads(value)
            return _dict_to_user(data)
        except (json.JSONDecodeError, TypeError, KeyError) as e:
            logger.warning(
                "auth_cache_json_decode_error",
                user_id=str(user_id),
                error=str(e),
            )
            await self.invalidate(user_id)
            return None

    async def set(
        self,
        user_id: UUID,
        user: User,
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache user by ID with retry, circuit breaker, and stale write prevention.

        Uses a Lua script to atomically check invalidation timestamps before writing,
        preventing stale data from being cached after invalidation.
        """
        if not self._enabled or not self._client:
            return False

        key = self._make_key(user_id)
        global_inv_key = self._make_global_invalidation_key()
        inv_key = self._make_invalidation_key(user_id)

        try:
            value = json.dumps(_user_to_dict(user))
        except (TypeError, ValueError) as e:
            logger.warning(
                "auth_cache_json_encode_error",
                user_id=str(user_id),
                error=str(e),
            )
            return False

        # Execute Lua script atomically checking timestamps
        result = await self._execute_with_retry(
            "eval",
            self._client.eval,
            self.LUA_SET_WITH_TIMESTAMP_CHECK,
            3,  # number of keys
            key,
            global_inv_key,
            inv_key,
            value,
            str(self._ttl_seconds),
            str(fetched_at) if fetched_at is not None else "nil",
        )

        if result == 0:
            logger.debug("auth_cache_stale_write_rejected", user_id=str(user_id))
            return False

        return result == 1

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user by ID with retry and timestamp storage."""
        if not self._client:
            return

        # Store invalidation timestamp (2x TTL to outlive in-flight writes)
        timestamp = time.monotonic()
        inv_key = self._make_invalidation_key(user_id)
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        key = self._make_key(user_id)
        await self._execute_with_retry("delete", self._client.delete, key)
        logger.debug("auth_cache_invalidated", user_id=str(user_id))

    async def invalidate_all(self) -> None:
        """Invalidate all cached users with retry and global timestamp."""
        if not self._client:
            return

        # Store global invalidation timestamp FIRST
        timestamp = time.monotonic()
        global_inv_key = self._make_global_invalidation_key()
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            global_inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        # Then delete all user keys (excluding invalidation timestamps)
        pattern = f"{self._key_prefix}*"
        cursor = 0
        deleted = 0
        scan_completed = True

        while True:
            result = await self._execute_with_retry(
                "scan", self._client.scan, cursor, match=pattern, count=100
            )
            if result is None:
                # Circuit open or all retries exhausted — partial scan
                scan_completed = False
                break
            cursor, keys = result
            if keys:
                # Filter out invalidation timestamp keys (consistent bytes-only checks)
                user_keys = [
                    k for k in keys if b"_global_invalidated" not in k and b"_invalidated:" not in k
                ]
                if user_keys:
                    del_result = await self._execute_with_retry(
                        "delete", self._client.delete, *user_keys
                    )
                    if del_result is None:
                        scan_completed = False
                    else:
                        deleted += del_result
            if cursor == 0:
                break

        if scan_completed:
            logger.info("auth_cache_cleared", deleted=deleted)
        else:
            logger.warning(
                "auth_cache_clear_partial",
                deleted=deleted,
                reason="circuit_breaker_or_redis_error",
            )


class RedisRequiredError(BaseError):
    """Raised when Redis is required but not available for auth cache."""

    code = "REDIS_REQUIRED"
    message = "Redis is required but not available"
    status_code = 500


class AuthCache(AbstractAuthCache):
    """
    Auth cache with automatic backend selection.

    Uses Redis if redis_url is provided, otherwise falls back to in-memory.
    This is the recommended class to use for auth caching.

    Example:
        ```python
        # In-memory (single instance)
        cache = AuthCache(ttl_seconds=60)

        # Redis (multi-instance, fail if unavailable)
        cache = AuthCache(
            ttl_seconds=60,
            redis_url="redis://localhost:6379/0",
            require_redis=True,
        )
        await cache.connect()  # Required for Redis
        ```
    """

    def __init__(
        self,
        ttl_seconds: int = AUTH_CACHE_TTL_SECONDS,
        redis_url: str | None = None,
        key_prefix: str = "ipk:auth:user:",
        require_redis: bool = False,
    ) -> None:
        """
        Initialize auth cache.

        Args:
            ttl_seconds: Cache TTL in seconds (0 to disable)
            redis_url: Redis URL for distributed caching (optional)
            key_prefix: Prefix for Redis keys
            require_redis: If True, fail if Redis is not available.

        Raises:
            RedisRequiredError: If require_redis=True and Redis is not available.
        """
        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix

        if require_redis:
            if not redis_url:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for auth cache but "
                    "redis_url is not configured."
                )
            if not REDIS_AVAILABLE:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for auth cache but "
                    "the redis package is not installed. Install with: pip install redis"
                )

        if redis_url and REDIS_AVAILABLE:
            self._backend: AbstractAuthCache = RedisAuthCache(
                redis_url=redis_url,
                ttl_seconds=ttl_seconds,
                key_prefix=key_prefix,
            )
            self._is_redis = True
        else:
            if redis_url and not REDIS_AVAILABLE:
                logger.warning(
                    "redis_not_available_for_auth_cache",
                    message="Redis URL provided but redis package not installed. "
                    "Using in-memory cache.",
                )
            self._backend = InMemoryAuthCache(ttl_seconds=ttl_seconds)
            self._is_redis = False

    async def connect(self) -> None:
        """Connect to Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisAuthCache):
            await self._backend.connect()

    async def disconnect(self) -> None:
        """Disconnect from Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisAuthCache):
            await self._backend.disconnect()

    async def get(self, user_id: UUID) -> User | None:
        """Get cached user by ID."""
        return await self._backend.get(user_id)

    async def set(
        self,
        user_id: UUID,
        user: User,
        fetched_at: float | None = None,
    ) -> bool:
        """Cache user by ID."""
        return await self._backend.set(user_id, user, fetched_at=fetched_at)

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached user by ID."""
        await self._backend.invalidate(user_id)

    async def invalidate_all(self) -> None:
        """Invalidate all cached users."""
        await self._backend.invalidate_all()

    async def cleanup_expired(self) -> int:
        """Remove expired entries from cache (in-memory only)."""
        if isinstance(self._backend, InMemoryAuthCache):
            return await self._backend.cleanup_expired()
        return 0

    @property
    def size(self) -> int:
        """Get current cache size (in-memory only)."""
        if isinstance(self._backend, InMemoryAuthCache):
            return self._backend.size
        return -1

    @property
    def is_redis(self) -> bool:
        """Check if using Redis backend."""
        return self._is_redis
