"""User repository for data access."""

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.auth.models.user import UserModel
from identity_plan_kit.auth.models.user_provider import UserProviderModel
from identity_plan_kit.shared.audit import mask_email
from identity_plan_kit.shared.constants import UNSET
from identity_plan_kit.shared.logging import get_logger
from identity_plan_kit.shared.repository import BaseRepository

if TYPE_CHECKING:
    from typing import Self

    from identity_plan_kit.registry import EntityRegistry, ModelRegistry

logger = get_logger(__name__)

M = TypeVar("M", bound=UserModel)
E = TypeVar("E", bound=User)

# Base User entity fields (used to identify extended fields on subclasses)
_BASE_USER_FIELDS: frozenset[str] = frozenset(
    {
        "id",
        "email",
        "role_id",
        "display_name",
        "picture_url",
        "metadata",
        "is_active",
        "is_verified",
        "created_at",
        "updated_at",
        "role_code",
        "permissions",
    }
)


class UserRepository(BaseRepository[M, E]):
    """
    Repository for user data access.

    Supports generic model and entity types for extensibility.
    By default uses UserModel and User, but can be configured
    to use extended versions.

    Type Parameters:
        M: The user model type (default: UserModel)
        E: The user entity type (default: User)
    """

    _model_class: type[M] = UserModel  # type: ignore[assignment]
    _entity_class: type[E] = User  # type: ignore[assignment]
    _provider_model_class: type = UserProviderModel

    def __init__(
        self,
        session: AsyncSession,
        model_class: type[M] | None = None,
        entity_class: type[E] | None = None,
        provider_model_class: type | None = None,
    ) -> None:
        """Initialize the user repository."""
        super().__init__(session, model_class=model_class, entity_class=entity_class)
        if provider_model_class is not None:
            self._provider_model_class = provider_model_class

    @classmethod
    def from_registry(
        cls,
        session: AsyncSession,
        models: ModelRegistry,
        entities: EntityRegistry,
    ) -> Self:
        """Create repository from registries."""
        return cls(
            session=session,
            model_class=models.get_user_model(),
            entity_class=entities.get_user_entity(),
            provider_model_class=models.get_user_provider_model(),
        )

    async def get_by_id(
        self,
        user_id: UUID,
        for_update: bool = False,
        include_role: bool = True,
    ) -> E | None:
        """Get user by ID."""
        stmt = select(self._model_class).where(self._model_class.id == user_id)

        if include_role:
            stmt = stmt.options(selectinload(self._model_class.role))

        if for_update:
            stmt = stmt.with_for_update()

        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._to_entity(model)

    async def get_by_email(
        self,
        email: str,
        for_update: bool = False,
        include_role: bool = True,
    ) -> E | None:
        """Get user by email address."""
        stmt = select(self._model_class).where(self._model_class.email == email)

        if include_role:
            stmt = stmt.options(selectinload(self._model_class.role))

        if for_update:
            stmt = stmt.with_for_update()

        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._to_entity(model)

    async def get_by_provider(
        self,
        provider_code: str,
        external_user_id: str,
    ) -> E | None:
        """Get user by OAuth provider."""
        stmt = (
            select(self._model_class)
            .join(self._provider_model_class)
            .options(selectinload(self._model_class.role))
            .where(
                self._provider_model_class.code == provider_code,
                self._provider_model_class.external_user_id == external_user_id,
            )
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._to_entity(model)

    async def _reload_with_role(
        self,
        model_id: UUID,
        *,
        load_providers: bool = False,
    ) -> M:
        """
        Re-fetch a user with its ``role`` (and optionally ``providers``)
        relationship populated.

        ``UserModel.role`` is configured with ``lazy="noload"`` so
        ``session.refresh(model, ["role"])`` is a no-op — it returns the
        model with ``role`` set to ``None``, which makes ``_to_entity``
        populate ``role_code=None`` and break downstream callers that
        depend on it (e.g. admin password gating). An explicit SELECT
        with ``selectinload`` is the only way to populate the relation.
        """
        options = [selectinload(self._model_class.role)]
        if load_providers:
            options.append(selectinload(self._model_class.providers))
        stmt = (
            select(self._model_class)
            .options(*options)
            .where(self._model_class.id == model_id)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one()

    async def create(
        self,
        email: str,
        role_id: UUID,
        display_name: str | None = None,
        picture_url: str | None = None,
        is_verified: bool = False,
        **extra_fields: object,
    ) -> E:
        """Create a new user."""
        if display_name is None:
            display_name = email.split("@")[0]

        model = self._create_model(
            email=email,
            role_id=role_id,
            display_name=display_name,
            picture_url=picture_url,
            is_verified=is_verified,
            **extra_fields,
        )
        self._session.add(model)
        await self._session.flush()
        reloaded = await self._reload_with_role(model.id)

        return self._to_entity(reloaded)

    async def create_with_provider(
        self,
        email: str,
        role_id: UUID,
        provider_code: str,
        external_user_id: str,
        display_name: str | None = None,
        picture_url: str | None = None,
        is_verified: bool = True,
        **extra_fields: object,
    ) -> E:
        """Create a new user with OAuth provider link."""
        if display_name is None:
            display_name = email.split("@")[0]

        user_model = self._create_model(
            email=email,
            role_id=role_id,
            display_name=display_name,
            picture_url=picture_url,
            is_verified=is_verified,
            **extra_fields,
        )
        self._session.add(user_model)
        await self._session.flush()

        provider_model = self._provider_model_class(
            user_id=user_model.id,
            code=provider_code,
            external_user_id=external_user_id,
        )
        self._session.add(provider_model)
        await self._session.flush()

        reloaded = await self._reload_with_role(user_model.id, load_providers=True)

        return self._to_entity(reloaded)

    async def get_or_create_with_provider(
        self,
        email: str,
        role_id: UUID,
        provider_code: str,
        external_user_id: str,
        display_name: str | None = None,
        picture_url: str | None = None,
        is_verified: bool = True,
        **extra_fields: object,
    ) -> tuple[E, bool]:
        """Get existing user or create new one with provider (race-condition safe)."""
        user = await self.get_by_provider(provider_code, external_user_id)
        if user:
            return user, False

        user = await self.get_by_email(email, for_update=True)
        if user:
            await self.add_provider(user.id, provider_code, external_user_id)
            return user, False

        try:
            async with self._session.begin_nested():
                user = await self.create_with_provider(
                    email=email,
                    role_id=role_id,
                    provider_code=provider_code,
                    external_user_id=external_user_id,
                    display_name=display_name,
                    picture_url=picture_url,
                    is_verified=is_verified,
                    **extra_fields,
                )
                return user, True
        except IntegrityError as e:
            logger.warning(
                "user_create_race_condition_handled",
                email=mask_email(email),
                provider=provider_code,
            )
            # Fix P2 #4: Lock the row to prevent further race windows during link
            user = await self.get_by_email(email, for_update=True)
            if user:
                existing_provider = await self.get_by_provider(provider_code, external_user_id)
                if not existing_provider:
                    try:
                        await self.add_provider(user.id, provider_code, external_user_id)
                    except IntegrityError:
                        logger.debug(
                            "provider_link_race_condition_handled",
                            email=mask_email(email),
                            provider=provider_code,
                        )
                return user, False
            raise RuntimeError(f"User creation race condition but user not found: {email}") from e

    async def add_provider(
        self,
        user_id: UUID,
        provider_code: str,
        external_user_id: str,
    ) -> None:
        """Add OAuth provider to existing user."""
        provider_model = self._provider_model_class(
            user_id=user_id,
            code=provider_code,
            external_user_id=external_user_id,
        )
        self._session.add(provider_model)
        await self._session.flush()

    async def update(self, user: E) -> E:
        """Update user data with FOR UPDATE lock to prevent lost updates."""
        stmt = select(self._model_class).where(self._model_class.id == user.id).with_for_update()
        result = await self._session.execute(stmt)
        model = result.scalar_one()

        model.email = user.email
        model.role_id = user.role_id
        model.display_name = user.display_name
        model.picture_url = user.picture_url
        model.user_metadata = user.metadata
        model.is_active = user.is_active
        model.is_verified = user.is_verified

        self._copy_extended_fields(user, model)

        await self._session.flush()
        reloaded = await self._reload_with_role(model.id)

        return self._to_entity(reloaded)

    async def deactivate(
        self,
        user_id: UUID,
        reason: str | None = None,
    ) -> bool:
        """Deactivate a user account."""
        from sqlalchemy import update  # noqa: PLC0415

        stmt = (
            update(self._model_class)
            .where(
                self._model_class.id == user_id,
                self._model_class.is_active == True,  # noqa: E712
            )
            .values(is_active=False)
        )
        result = await self._session.execute(stmt)
        await self._session.flush()

        deactivated = result.rowcount > 0

        if deactivated:
            logger.warning(
                "user_deactivated",
                user_id=str(user_id),
                reason=reason,
            )

        return deactivated

    async def reactivate(
        self,
        user_id: UUID,
        reason: str | None = None,
    ) -> bool:
        """Reactivate a user account."""
        from sqlalchemy import update  # noqa: PLC0415

        stmt = (
            update(self._model_class)
            .where(
                self._model_class.id == user_id,
                self._model_class.is_active == False,  # noqa: E712
            )
            .values(is_active=True)
        )
        result = await self._session.execute(stmt)
        await self._session.flush()

        reactivated = result.rowcount > 0

        if reactivated:
            logger.info(
                "user_reactivated",
                user_id=str(user_id),
                reason=reason,
            )

        return reactivated

    async def update_profile(
        self,
        user_id: UUID,
        display_name: str | None = None,
        picture_url: str | None | object = UNSET,
        metadata: dict | None | object = UNSET,
        **extra_fields: object,
    ) -> E | None:
        """Update user profile fields with partial-merge metadata semantics."""
        stmt = select(self._model_class).where(self._model_class.id == user_id).with_for_update()
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        if display_name is not None:
            model.display_name = display_name

        if picture_url is not UNSET:
            model.picture_url = picture_url  # type: ignore[assignment]

        if metadata is not UNSET:
            if metadata is None:
                model.user_metadata = {}
            else:
                existing = model.user_metadata or {}
                model.user_metadata = {**existing, **metadata}  # type: ignore[dict-item]

        for field_name, value in extra_fields.items():
            if hasattr(model, field_name):
                setattr(model, field_name, value)

        await self._session.flush()
        reloaded = await self._reload_with_role(model.id)

        logger.info("user_profile_updated", user_id=str(user_id))

        return self._to_entity(reloaded)

    async def set_password_hash(
        self,
        user_id: UUID,
        password_hash: str,
    ) -> bool:
        """Set password hash for a user (race-condition safe via SELECT FOR UPDATE)."""
        stmt = select(self._model_class).where(self._model_class.id == user_id).with_for_update()
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return False

        model.password_hash = password_hash
        await self._session.flush()

        logger.info("user_password_hash_set", user_id=str(user_id))

        return True

    async def get_password_hash(
        self,
        user_id: UUID,
    ) -> str | None:
        """Get password hash for a user (None if no password / OAuth-only)."""
        stmt = select(self._model_class.password_hash).where(self._model_class.id == user_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def clear_password_hash(
        self,
        user_id: UUID,
    ) -> bool:
        """Remove password hash from user."""
        stmt = select(self._model_class).where(self._model_class.id == user_id).with_for_update()
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return False

        model.password_hash = None
        await self._session.flush()

        logger.info("user_password_hash_cleared", user_id=str(user_id))

        return True

    def _to_entity(self, model: M, extra_fields: dict[str, Any] | None = None) -> E:
        """
        Convert ORM model to domain entity.

        Maps `model.user_metadata` -> entity `metadata` (since SQLAlchemy reserves
        `metadata` as a class attribute, the model exposes it as `user_metadata`).
        Also resolves `role_code` from the loaded `role` relationship.
        """
        entity_kwargs: dict[str, Any] = {
            "id": model.id,
            "email": model.email,
            "role_id": model.role_id,
            "display_name": model.display_name,
            "picture_url": model.picture_url,
            "metadata": model.user_metadata or {},
            "is_active": model.is_active,
            "is_verified": model.is_verified,
            "created_at": model.created_at,
            "updated_at": model.updated_at,
            "role_code": model.role.code if model.role else None,
        }

        self._add_extended_entity_fields(model, entity_kwargs)

        if extra_fields:
            entity_kwargs.update(extra_fields)

        return self._entity_class(**entity_kwargs)

    def _add_extended_entity_fields(self, model: M, entity_kwargs: dict[str, Any]) -> None:
        """Add extended fields from model to entity kwargs (for subclassed entities)."""
        if not dataclasses.is_dataclass(self._entity_class):
            return

        entity_fields = {f.name for f in dataclasses.fields(self._entity_class)}
        extended_fields = entity_fields - _BASE_USER_FIELDS

        for field_name in extended_fields:
            if hasattr(model, field_name):
                entity_kwargs[field_name] = getattr(model, field_name)

    def _copy_extended_fields(self, entity: E, model: M) -> None:
        """Copy extended entity fields back to model on update."""
        if not dataclasses.is_dataclass(entity):
            return

        entity_fields = {f.name for f in dataclasses.fields(entity)}
        extended_fields = entity_fields - _BASE_USER_FIELDS

        for field_name in extended_fields:
            if hasattr(model, field_name) and hasattr(entity, field_name):
                setattr(model, field_name, getattr(entity, field_name))
