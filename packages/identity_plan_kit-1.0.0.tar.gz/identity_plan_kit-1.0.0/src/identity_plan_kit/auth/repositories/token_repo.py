"""Refresh token repository."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, TypeVar
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from identity_plan_kit.auth.domain.entities import RefreshToken
from identity_plan_kit.auth.models.refresh_token import RefreshTokenModel
from identity_plan_kit.shared.logging import get_logger
from identity_plan_kit.shared.repository import BaseRepository

if TYPE_CHECKING:
    from typing import Self

    from identity_plan_kit.registry import EntityRegistry, ModelRegistry

logger = get_logger(__name__)

M = TypeVar("M", bound=RefreshTokenModel)
E = TypeVar("E", bound=RefreshToken)


class RefreshTokenRepository(BaseRepository[M, E]):
    """
    Repository for refresh token data access.

    Supports generic model and entity types for extensibility.

    Type Parameters:
        M: The token model type (default: RefreshTokenModel)
        E: The token entity type (default: RefreshToken)
    """

    _model_class: type[M] = RefreshTokenModel  # type: ignore[assignment]
    _entity_class: type[E] = RefreshToken  # type: ignore[assignment]

    @classmethod
    def from_registry(
        cls,
        session: AsyncSession,
        models: ModelRegistry,
        entities: EntityRegistry,
    ) -> Self:
        """Create repository from registries."""
        return cls(
            session=session,
            model_class=models.get_refresh_token_model(),
            entity_class=entities.get_refresh_token_entity(),
        )

    async def create(
        self,
        user_id: UUID,
        token_hash: str,
        expires_at: datetime,
        user_agent: str | None = None,
        ip_address: str | None = None,
        **extra_fields: object,
    ) -> E:
        """Create a new refresh token."""
        model = self._create_model(
            user_id=user_id,
            token_hash=token_hash,
            expires_at=expires_at,
            user_agent=user_agent,
            ip_address=ip_address,
            **extra_fields,
        )
        self._session.add(model)
        await self._session.flush()

        logger.debug(
            "refresh_token_created",
            user_id=str(user_id),
            token_id=str(model.id),
        )

        return self._to_entity(model)

    async def get_by_hash(
        self,
        token_hash: str,
        for_update: bool = False,
    ) -> E | None:
        """Get refresh token by its hash (only non-revoked tokens)."""
        stmt = select(self._model_class).where(
            self._model_class.token_hash == token_hash,
            self._model_class.revoked_at.is_(None),
        )

        if for_update:
            stmt = stmt.with_for_update()

        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._to_entity(model)

    async def get_by_hash_any(
        self,
        token_hash: str,
        for_update: bool = False,
    ) -> E | None:
        """
        Get refresh token by its hash, including revoked ones.

        Used by reuse-detection: a revoked token presented again signals
        potential theft, so the caller must be able to observe the revoked
        row instead of treating it as "not found".
        """
        stmt = select(self._model_class).where(
            self._model_class.token_hash == token_hash,
        )

        if for_update:
            stmt = stmt.with_for_update()

        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            return None

        return self._to_entity(model)

    async def revoke(self, token_id: UUID) -> None:
        """Revoke a refresh token."""
        stmt = (
            update(self._model_class)
            .where(self._model_class.id == token_id)
            .values(revoked_at=datetime.now(UTC))
        )
        await self._session.execute(stmt)
        await self._session.flush()

        logger.info("refresh_token_revoked", token_id=str(token_id))

    async def revoke_all_for_user(self, user_id: UUID) -> int:
        """Revoke all refresh tokens for a user."""
        stmt = (
            update(self._model_class)
            .where(
                self._model_class.user_id == user_id,
                self._model_class.revoked_at.is_(None),
            )
            .values(revoked_at=datetime.now(UTC))
        )
        result = await self._session.execute(stmt)
        await self._session.flush()

        count = result.rowcount
        logger.info(
            "refresh_tokens_revoked_all",
            user_id=str(user_id),
            count=count,
        )

        return count

    async def cleanup_expired(self, batch_size: int = 1000) -> int:
        """
        Delete expired and revoked tokens in batches.

        Uses FOR UPDATE SKIP LOCKED to allow concurrent cleanup operations
        to process different batches without conflicts.
        """
        from sqlalchemy import delete  # noqa: PLC0415

        select_stmt = (
            select(self._model_class.id)
            .where(
                (self._model_class.expires_at < datetime.now(UTC))
                | (self._model_class.revoked_at.is_not(None))
            )
            .limit(batch_size)
            .with_for_update(skip_locked=True)
        )
        result = await self._session.execute(select_stmt)
        ids_to_delete = [row[0] for row in result.fetchall()]

        if not ids_to_delete:
            return 0

        delete_stmt = delete(self._model_class).where(self._model_class.id.in_(ids_to_delete))
        delete_result = await self._session.execute(delete_stmt)
        await self._session.flush()

        count = delete_result.rowcount
        logger.info(
            "refresh_tokens_cleaned",
            count=count,
            batch_size=batch_size,
            has_more=count == batch_size,
        )

        return count
