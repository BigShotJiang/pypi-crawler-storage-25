"""RBAC FastAPI dependencies."""

from collections.abc import Callable
from typing import Any

from fastapi import Depends, Request

from identity_plan_kit.auth.dependencies import CurrentUser
from identity_plan_kit.rbac.domain.exceptions import PermissionDeniedError
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


def requires_permission(permission_code: str) -> Callable[..., Any]:
    """
    Dependency that requires a specific permission.

    `PermissionDeniedError` propagates to the global error handler, which maps
    `AuthorizationError` subclasses to HTTP 403 with the standard envelope.

    Usage:
        @app.get("/admin/users")
        @requires_permission("users:read")
        async def list_users(user: CurrentUser):
            ...
    """

    async def dependency(
        request: Request,
        user: CurrentUser,
    ) -> None:
        kit = request.app.state.identity_plan_kit
        rbac_service = kit.rbac_service

        await rbac_service.require_permission(
            user_id=user.id,
            role_id=user.role_id,
            permission_code=permission_code,
        )

    return Depends(dependency)


def requires_role(role_code: str) -> Callable[..., Any]:
    """
    Dependency that requires a specific role.

    Usage:
        @app.get("/admin/dashboard")
        @requires_role("admin")
        async def admin_dashboard(user: CurrentUser):
            ...
    """

    async def dependency(
        request: Request,
        user: CurrentUser,
    ) -> None:
        kit = request.app.state.identity_plan_kit
        rbac_service = kit.rbac_service

        # Fail closed if the user's role wasn't loaded (e.g., the endpoint
        # used `CurrentUserNoRole`). Coercing None to "" via `or ""` was a
        # silent bypass when paired with `requires_role("")`.
        if user.role_code is None:
            logger.warning(
                "role_check_skipped_no_role_loaded",
                user_id=str(user.id),
                required_role=role_code,
            )
            raise PermissionDeniedError()

        await rbac_service.require_role(
            user_role_code=user.role_code,
            required_role_code=role_code,
        )

    return Depends(dependency)


def requires_any_permission(*permission_codes: str) -> Callable[..., Any]:
    """
    Dependency that requires any of the specified permissions.

    Usage:
        @app.get("/content")
        @requires_any_permission("content:read", "content:admin")
        async def get_content(user: CurrentUser):
            ...
    """

    async def dependency(
        request: Request,
        user: CurrentUser,
    ) -> None:
        kit = request.app.state.identity_plan_kit
        rbac_service = kit.rbac_service

        for code in permission_codes:
            if await rbac_service.check_permission(
                user_id=user.id,
                role_id=user.role_id,
                permission_code=code,
            ):
                return

        raise PermissionDeniedError()

    return Depends(dependency)
