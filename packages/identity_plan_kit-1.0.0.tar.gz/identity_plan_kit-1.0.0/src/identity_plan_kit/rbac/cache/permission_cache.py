"""Permission cache for fast permission checks."""

import asyncio
import json
import random
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any
from uuid import UUID

from identity_plan_kit.shared.constants import (
    REDIS_CIRCUIT_FAILURE_THRESHOLD,
    REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS,
    REDIS_CIRCUIT_RECOVERY_TIMEOUT,
    REDIS_RETRY_ATTEMPTS,
    REDIS_RETRY_BASE_DELAY,
    REDIS_SOCKET_CONNECT_TIMEOUT,
    REDIS_SOCKET_TIMEOUT,
)
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


class CacheCircuitState(Enum):
    """Circuit breaker states for cache."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


# Optional Redis support
try:
    import redis.asyncio as redis

    REDIS_AVAILABLE = True
except ImportError:
    redis = None  # type: ignore[assignment]
    REDIS_AVAILABLE = False


class AbstractPermissionCache(ABC):
    """Abstract base class for permission caching."""

    @abstractmethod
    async def get(self, user_id: UUID) -> set[str] | None:
        """Get cached permissions for user."""
        pass

    @abstractmethod
    async def set(
        self,
        user_id: UUID,
        permissions: set[str],
        fetched_at: float | None = None,
    ) -> bool:
        """Cache permissions for user."""
        pass

    @abstractmethod
    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached permissions for user."""
        pass

    @abstractmethod
    async def invalidate_all(self) -> None:
        """Invalidate all cached permissions."""
        pass

    def get_fetch_timestamp(self) -> float:
        """Get a monotonic timestamp for stale write prevention."""
        return time.monotonic()


@dataclass
class CacheEntry:
    """Cache entry with expiration and fetch timestamp for race condition prevention."""

    permissions: set[str]
    expires_at: datetime
    fetched_at: float = field(default_factory=time.monotonic)

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class InMemoryPermissionCache(AbstractPermissionCache):
    """
    In-memory permission cache.

    Caches user permissions with configurable TTL to reduce database queries.
    Thread-safe using asyncio locks.
    Uses LRU (Least Recently Used) eviction when cache reaches MAX_ENTRIES.

    **Race Condition Prevention:**

    Prevents stale writes after invalidation using a timestamp-based approach.
    invalidate() records the invalidation time; subsequent set() calls only
    succeed if their fetch timestamp is newer than the last invalidation.

    Warning:
        For multi-instance deployments, use RedisPermissionCache instead.
        In-memory cache invalidation only affects the local instance.
    """

    MAX_ENTRIES = 10000  # Maximum number of cached user permissions

    def __init__(self, ttl_seconds: int = 60) -> None:
        """
        Initialize permission cache.

        Args:
            ttl_seconds: Cache TTL in seconds (0 to disable caching)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._cache: OrderedDict[UUID, CacheEntry] = OrderedDict()
        # `_write_lock` protects all mutations of `_cache` (set/invalidate/cleanup
        # and the LRU `move_to_end` performed on read). Naming follows the
        # convention used by `InMemoryAuthCache` / `InMemoryPlanCache`.
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0
        # Stale-write prevention: invalidation timestamps. Tombstones are kept
        # past TTL so an in-flight set() with an older fetched_at is rejected
        # (mirrors the 2x TTL window used by RedisPermissionCache).
        self._invalidated_at: OrderedDict[UUID, float] = OrderedDict()
        self._global_invalidated_at: float = 0.0

    async def get(self, user_id: UUID) -> set[str] | None:
        """
        Get cached permissions for user.

        Reads are intentionally lock-free for hot-path performance — matches
        the InMemoryAuthCache / InMemoryUserPlanCache pattern. The regression
        test ``test_concurrent_cache_reads`` fails if this method takes the
        write lock. LRU ordering is maintained by ``set()`` under the lock;
        we accept that ``get()`` does not refresh recency.

        Args:
            user_id: User UUID

        Returns:
            Set of permission codes or None if not cached/expired
        """
        if not self._enabled:
            return None

        entry = self._cache.get(user_id)

        if entry is None:
            return None

        if entry.is_expired:
            return None

        return entry.permissions

    async def set(
        self,
        user_id: UUID,
        permissions: set[str],
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache permissions for user.

        Args:
            user_id: User UUID
            permissions: Set of permission codes
            fetched_at: Monotonic timestamp captured before the DB fetch.
                When provided, the write is rejected if it predates the most
                recent invalidate()/invalidate_all() call.

        Returns:
            True if cached, False if rejected as stale or caching disabled.
        """
        if not self._enabled:
            return False

        async with self._write_lock:
            if fetched_at is not None:
                if fetched_at < self._global_invalidated_at:
                    logger.debug(
                        "permission_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="global_invalidation",
                    )
                    return False

                key_invalidated_at = self._invalidated_at.get(user_id, 0.0)
                if fetched_at < key_invalidated_at:
                    logger.debug(
                        "permission_cache_stale_write_rejected",
                        user_id=str(user_id),
                        reason="key_invalidation",
                    )
                    return False

            if len(self._cache) >= self.MAX_ENTRIES and user_id not in self._cache:
                evicted_key, _ = self._cache.popitem(last=False)
                self._invalidated_at.pop(evicted_key, None)
                logger.debug(
                    "permission_cache_eviction",
                    evicted_user=str(evicted_key),
                    cache_size=len(self._cache),
                )

            self._cache[user_id] = CacheEntry(
                permissions=permissions.copy(),
                expires_at=datetime.now(UTC) + self._ttl,
                fetched_at=fetched_at or time.monotonic(),
            )
            self._cache.move_to_end(user_id)
            return True

    async def invalidate(self, user_id: UUID) -> None:
        """
        Invalidate cached permissions for user.

        Args:
            user_id: User UUID
        """
        async with self._write_lock:
            self._invalidated_at[user_id] = time.monotonic()
            self._invalidated_at.move_to_end(user_id)
            self._cache.pop(user_id, None)
            # Cap tombstones at 2x cache cap so they outlive their entries.
            max_invalidations = self.MAX_ENTRIES * 2
            while len(self._invalidated_at) > max_invalidations:
                self._invalidated_at.popitem(last=False)

    async def invalidate_all(self) -> None:
        """Invalidate all cached permissions."""
        async with self._write_lock:
            self._global_invalidated_at = time.monotonic()
            self._cache.clear()
            self._invalidated_at.clear()
            logger.info("permission_cache_cleared")

    async def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Returns:
            Number of entries removed
        """
        async with self._write_lock:
            now = datetime.now(UTC)
            expired = [uid for uid, entry in self._cache.items() if entry.expires_at < now]
            for uid in expired:
                del self._cache[uid]

            if expired:
                logger.debug("cache_cleanup", removed=len(expired))

            return len(expired)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)


class RedisPermissionCache(AbstractPermissionCache):
    """
    Redis-backed permission cache for distributed deployments.

    Use this when running multiple application instances behind a load balancer.
    Ensures cache invalidation propagates to all instances.

    Features:
    - Circuit breaker: Fails fast when Redis is unavailable
    - Retry with exponential backoff: Handles transient failures
    - Configurable timeouts: Prevents hanging connections
    - Stale-write prevention: Lua script atomically rejects writes that predate
      the most recent invalidation timestamp.

    Requires: pip install redis
    """

    # Circuit breaker configuration (from constants)
    CIRCUIT_FAILURE_THRESHOLD = REDIS_CIRCUIT_FAILURE_THRESHOLD
    CIRCUIT_RECOVERY_TIMEOUT = REDIS_CIRCUIT_RECOVERY_TIMEOUT
    CIRCUIT_HALF_OPEN_MAX_CALLS = REDIS_CIRCUIT_HALF_OPEN_MAX_CALLS

    # Lua script for atomic set with stale-write prevention.
    # Mirrors the script used by RedisAuthCache / RedisPlanCache.
    LUA_SET_WITH_TIMESTAMP_CHECK = """
        local fetched_at = ARGV[3]
        if fetched_at == "nil" then
            redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
            return 1
        end
        fetched_at = tonumber(fetched_at)
        local global_inv = redis.call("GET", KEYS[2])
        if global_inv and tonumber(global_inv) > fetched_at then
            return 0
        end
        local key_inv = redis.call("GET", KEYS[3])
        if key_inv and tonumber(key_inv) > fetched_at then
            return 0
        end
        redis.call("SETEX", KEYS[1], tonumber(ARGV[2]), ARGV[1])
        return 1
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        ttl_seconds: int = 60,
        key_prefix: str = "rbac:permission:",
        socket_timeout: float = REDIS_SOCKET_TIMEOUT,
        socket_connect_timeout: float = REDIS_SOCKET_CONNECT_TIMEOUT,
    ) -> None:
        """
        Initialize Redis permission cache.

        Args:
            redis_url: Redis connection URL
            ttl_seconds: Cache TTL in seconds (0 to disable)
            key_prefix: Prefix for cache keys (follows `{feature}:{entity}:` convention)
            socket_timeout: Timeout for socket operations (default: 5s)
            socket_connect_timeout: Timeout for connection (default: 5s)
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "Redis support requires the 'redis' package. Install it with: pip install redis"
            )

        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix
        self._socket_timeout = socket_timeout
        self._socket_connect_timeout = socket_connect_timeout
        self._enabled = ttl_seconds > 0
        self._client: redis.Redis[bytes] | None = None

        # Circuit breaker state
        self._circuit_state = CacheCircuitState.CLOSED
        self._circuit_failures = 0
        self._circuit_successes = 0
        self._circuit_opened_at: datetime | None = None
        self._circuit_half_open_calls = 0
        self._circuit_lock = asyncio.Lock()

    def _make_key(self, user_id: UUID) -> str:
        """Create cache key for user."""
        return f"{self._key_prefix}{user_id}"

    def _make_invalidation_key(self, user_id: UUID) -> str:
        """Create invalidation timestamp key for user (colon-separated)."""
        prefix = self._key_prefix.rstrip(":")
        return f"{prefix}:_invalidated:{user_id}"

    def _make_global_invalidation_key(self) -> str:
        """Create global invalidation timestamp key (colon-separated)."""
        prefix = self._key_prefix.rstrip(":")
        return f"{prefix}:_global_invalidated"

    async def _check_circuit(self) -> bool:
        """Check if circuit allows request."""
        async with self._circuit_lock:
            if self._circuit_state == CacheCircuitState.CLOSED:
                return True

            if self._circuit_state == CacheCircuitState.OPEN:
                if self._circuit_opened_at is not None:
                    elapsed = (datetime.now(UTC) - self._circuit_opened_at).total_seconds()
                    if elapsed >= self.CIRCUIT_RECOVERY_TIMEOUT:
                        self._circuit_state = CacheCircuitState.HALF_OPEN
                        self._circuit_half_open_calls = 0
                        self._circuit_successes = 0
                        logger.info("permission_cache_circuit_half_open")
                        return True
                return False

            if self._circuit_state == CacheCircuitState.HALF_OPEN:
                if self._circuit_half_open_calls < self.CIRCUIT_HALF_OPEN_MAX_CALLS:
                    self._circuit_half_open_calls += 1
                    return True
                return False

            return False

    async def _record_success(self) -> None:
        """Record successful operation."""
        async with self._circuit_lock:
            self._circuit_successes += 1
            if self._circuit_state == CacheCircuitState.CLOSED:
                # Reset failure count on success to prevent gradual circuit
                # trips from intermittent failures accumulating over long uptimes.
                self._circuit_failures = 0
            elif self._circuit_state == CacheCircuitState.HALF_OPEN:
                if self._circuit_successes >= 2:
                    self._circuit_state = CacheCircuitState.CLOSED
                    self._circuit_failures = 0
                    logger.info("permission_cache_circuit_closed")

    async def _record_failure(self) -> None:
        """Record failed operation."""
        async with self._circuit_lock:
            self._circuit_failures += 1
            if self._circuit_state == CacheCircuitState.CLOSED:
                if self._circuit_failures >= self.CIRCUIT_FAILURE_THRESHOLD:
                    self._circuit_state = CacheCircuitState.OPEN
                    self._circuit_opened_at = datetime.now(UTC)
                    logger.warning("permission_cache_circuit_open", failures=self._circuit_failures)
            elif self._circuit_state == CacheCircuitState.HALF_OPEN:
                self._circuit_state = CacheCircuitState.OPEN
                self._circuit_opened_at = datetime.now(UTC)
                logger.warning("permission_cache_circuit_reopened")

    async def _execute_with_retry(
        self,
        operation: str,
        func: Callable[..., Awaitable[Any]],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Execute Redis operation with circuit breaker and retry logic.

        Records a single failure after the retry budget is exhausted (matches
        RedisAuthCache / RedisPlanCache). Recording per-attempt would inflate
        the failure counter and trip the circuit even when the operation
        eventually succeeds within the retry budget.

        `redis.ResponseError` (WRONGTYPE / OOM / READONLY / NOSCRIPT) is a
        protocol-level rejection, not a transient failure, so it is treated
        as non-retryable: we record one failure and re-raise.
        """
        if not await self._check_circuit():
            logger.warning(f"permission_cache_{operation}_circuit_open")
            return None

        last_error: Exception | None = None

        for attempt in range(REDIS_RETRY_ATTEMPTS):
            try:
                result = await func(*args, **kwargs)
                await self._record_success()
                return result
            except (TimeoutError, redis.ConnectionError, redis.TimeoutError, OSError) as e:
                last_error = e
                if attempt < REDIS_RETRY_ATTEMPTS - 1:
                    delay = REDIS_RETRY_BASE_DELAY * (2**attempt)
                    jitter = random.uniform(0, 0.1 * delay)
                    await asyncio.sleep(delay + jitter)
                    logger.warning(
                        f"permission_cache_{operation}_retry",
                        attempt=attempt + 1,
                        error=str(e),
                    )
            except Exception as e:
                await self._record_failure()
                logger.error(f"permission_cache_{operation}_error", error=str(e))
                raise

        await self._record_failure()
        logger.error(
            f"permission_cache_{operation}_failed",
            attempts=REDIS_RETRY_ATTEMPTS,
            error=str(last_error),
        )
        return None

    async def connect(
        self,
        max_retries: int = 3,
        base_delay: float = 0.5,
    ) -> None:
        """
        Connect to Redis with exponential backoff retry.

        Args:
            max_retries: Maximum number of connection attempts
            base_delay: Base delay in seconds (doubles each retry)
        """
        self._client = redis.from_url(
            self._redis_url,
            encoding="utf-8",
            decode_responses=False,
            socket_timeout=self._socket_timeout,
            socket_connect_timeout=self._socket_connect_timeout,
        )

        last_error: Exception | None = None
        for attempt in range(max_retries):
            try:
                await self._client.ping()
                logger.info(
                    "redis_permission_cache_connected",
                    url=self._redis_url.split("@")[-1],
                )
                return
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)
                    logger.warning(
                        "redis_connection_retry",
                        attempt=attempt + 1,
                        max_retries=max_retries,
                        delay=delay,
                        error=str(e),
                    )
                    await asyncio.sleep(delay)

        await self._client.aclose()
        self._client = None
        raise ConnectionError(
            f"Failed to connect to Redis after {max_retries} attempts: {last_error}"
        )

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def get(self, user_id: UUID) -> set[str] | None:
        """Get cached permissions for user."""
        if not self._enabled or not self._client:
            return None

        async def _get_from_redis() -> bytes | None:
            key = self._make_key(user_id)
            return await self._client.get(key)  # type: ignore[union-attr]

        value = await self._execute_with_retry("get", _get_from_redis)
        if value is None:
            return None

        try:
            return set(json.loads(value))
        except (json.JSONDecodeError, TypeError) as e:
            logger.warning(
                "cache_json_decode_error",
                user_id=str(user_id),
                error=str(e),
            )
            await self.invalidate(user_id)
            return None

    async def set(
        self,
        user_id: UUID,
        permissions: set[str],
        fetched_at: float | None = None,
    ) -> bool:
        """Cache permissions for user with stale-write prevention."""
        if not self._enabled or not self._client:
            return False

        key = self._make_key(user_id)
        global_inv_key = self._make_global_invalidation_key()
        inv_key = self._make_invalidation_key(user_id)

        try:
            value = json.dumps(list(permissions))
        except (TypeError, ValueError) as e:
            logger.warning(
                "cache_json_encode_error",
                user_id=str(user_id),
                error=str(e),
            )
            return False

        result = await self._execute_with_retry(
            "eval",
            self._client.eval,
            self.LUA_SET_WITH_TIMESTAMP_CHECK,
            3,
            key,
            global_inv_key,
            inv_key,
            value,
            str(self._ttl_seconds),
            str(fetched_at) if fetched_at is not None else "nil",
        )

        if result == 0:
            logger.debug("permission_cache_stale_write_rejected", user_id=str(user_id))
            return False

        return result == 1

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached permissions for user (records timestamp for stale-write check)."""
        if not self._client:
            return

        timestamp = time.monotonic()
        inv_key = self._make_invalidation_key(user_id)
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        key = self._make_key(user_id)
        await self._execute_with_retry("delete", self._client.delete, key)

    async def invalidate_all(self) -> None:
        """
        Invalidate all cached permissions.

        Writes the global invalidation timestamp FIRST so in-flight set() calls
        are rejected by the Lua script even if the SCAN+DEL phase fails partway.
        """
        if not self._client:
            return

        timestamp = time.monotonic()
        global_inv_key = self._make_global_invalidation_key()
        await self._execute_with_retry(
            "setex",
            self._client.setex,
            global_inv_key,
            self._ttl_seconds * 2,
            str(timestamp),
        )

        async def _invalidate_all_in_redis() -> int:
            pattern = f"{self._key_prefix}*"
            cursor = 0
            deleted = 0

            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)  # type: ignore[union-attr]
                if keys:
                    user_keys = [
                        k
                        for k in keys
                        if b"_global_invalidated" not in k and b"_invalidated:" not in k
                    ]
                    if user_keys:
                        deleted += await self._client.delete(*user_keys)  # type: ignore[union-attr]
                if cursor == 0:
                    break
            return deleted

        deleted = await self._execute_with_retry("invalidate_all", _invalidate_all_in_redis)
        if deleted is not None:
            logger.info("permission_cache_cleared", deleted=deleted)


class RedisRequiredError(BaseError):
    """Raised when Redis is required but not available for permission cache."""

    code = "REDIS_REQUIRED"
    message = "Redis is required but not available"
    status_code = 503


class PermissionCache(AbstractPermissionCache):
    """
    Permission cache with automatic backend selection.

    Uses Redis if redis_url is provided, otherwise falls back to in-memory.
    This is the recommended class to use for permission caching.

    Example:
        ```python
        # In-memory (single instance)
        cache = PermissionCache(ttl_seconds=60)

        # Redis (multi-instance, fail if unavailable)
        cache = PermissionCache(
            ttl_seconds=60,
            redis_url="redis://localhost:6379/0",
            require_redis=True,
        )
        await cache.connect()  # Required for Redis
        ```
    """

    def __init__(
        self,
        ttl_seconds: int = 60,
        redis_url: str | None = None,
        key_prefix: str = "rbac:permission:",
        require_redis: bool = False,
    ) -> None:
        """
        Initialize permission cache.

        Args:
            ttl_seconds: Cache TTL in seconds (0 to disable)
            redis_url: Redis URL for distributed caching (optional)
            key_prefix: Prefix for Redis keys (follows `{feature}:{entity}:` convention)
            require_redis: If True, fail if Redis is not available. Use this in
                          production multi-instance deployments to prevent silent
                          fallback to in-memory storage.

        Raises:
            RedisRequiredError: If require_redis=True and Redis is not available.
        """
        self._redis_url = redis_url
        self._ttl_seconds = ttl_seconds
        self._key_prefix = key_prefix

        if require_redis:
            if not redis_url:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for permission cache but "
                    "redis_url is not configured. Set IPK_REDIS_URL environment variable "
                    "or disable require_redis for single-instance deployments."
                )
            if not REDIS_AVAILABLE:
                raise RedisRequiredError(
                    "Redis is required (require_redis=True) for permission cache but "
                    "the redis package is not installed. Install with: pip install redis"
                )

        if redis_url and REDIS_AVAILABLE:
            self._backend: AbstractPermissionCache = RedisPermissionCache(
                redis_url=redis_url,
                ttl_seconds=ttl_seconds,
                key_prefix=key_prefix,
            )
            self._is_redis = True
        else:
            if redis_url and not REDIS_AVAILABLE:
                logger.warning(
                    "redis_not_available_for_cache",
                    message="Redis URL provided but redis package not installed. "
                    "Using in-memory cache. Install with: pip install redis",
                )
            self._backend = InMemoryPermissionCache(ttl_seconds=ttl_seconds)
            self._is_redis = False

    async def connect(self) -> None:
        """Connect to Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisPermissionCache):
            await self._backend.connect()

    async def disconnect(self) -> None:
        """Disconnect from Redis (if using Redis backend)."""
        if self._is_redis and isinstance(self._backend, RedisPermissionCache):
            await self._backend.disconnect()

    async def get(self, user_id: UUID) -> set[str] | None:
        """Get cached permissions for user."""
        return await self._backend.get(user_id)

    async def set(
        self,
        user_id: UUID,
        permissions: set[str],
        fetched_at: float | None = None,
    ) -> bool:
        """Cache permissions for user."""
        return await self._backend.set(user_id, permissions, fetched_at=fetched_at)

    async def invalidate(self, user_id: UUID) -> None:
        """Invalidate cached permissions for user."""
        await self._backend.invalidate(user_id)

    async def invalidate_all(self) -> None:
        """Invalidate all cached permissions."""
        await self._backend.invalidate_all()

    @property
    def size(self) -> int:
        """Get current cache size (in-memory only)."""
        if isinstance(self._backend, InMemoryPermissionCache):
            return self._backend.size
        return -1  # Unknown for Redis
