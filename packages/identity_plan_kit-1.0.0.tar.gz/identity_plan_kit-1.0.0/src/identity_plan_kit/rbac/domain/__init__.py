"""RBAC domain."""
