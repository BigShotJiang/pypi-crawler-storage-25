"""RBAC service for permission management."""

import asyncio
from collections import OrderedDict
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.rbac.cache.permission_cache import PermissionCache
from identity_plan_kit.rbac.domain.entities import Permission, PermissionType, Role
from identity_plan_kit.rbac.domain.exceptions import PermissionDeniedError, RoleNotFoundError
from identity_plan_kit.rbac.uow import RBACUnitOfWork
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)

# Maximum number of per-key fetch locks to keep in memory
MAX_FETCH_LOCKS = 10000

# Maximum eviction probes when MAX_FETCH_LOCKS is hit. Bounds time spent
# scanning for an unlocked lock; if all probed locks are held the new entry
# is skipped (worst case: stampede protection degrades to thundering herd).
_FETCH_LOCK_EVICT_PROBES = 64


class RBACService:
    """Service for RBAC operations."""

    def __init__(
        self,
        config: IdentityPlanKitConfig,
        session_factory: async_sessionmaker[AsyncSession],
    ) -> None:
        self._config = config
        self._session_factory = session_factory
        self._cache = PermissionCache(
            ttl_seconds=config.permission_cache_ttl_seconds,
            redis_url=config.redis_url,
            require_redis=config.require_redis,
        )
        # Cache stampede protection: per-key locks with bounded LRU eviction.
        self._fetch_locks: OrderedDict[UUID, asyncio.Lock] = OrderedDict()
        self._fetch_locks_lock = asyncio.Lock()

    def _create_uow(
        self,
        session: AsyncSession | None = None,
        auto_commit: bool = True,
    ) -> RBACUnitOfWork:
        """Create a new Unit of Work instance."""
        return RBACUnitOfWork(
            self._session_factory,
            session=session,
            auto_commit=auto_commit,
        )

    async def startup(self) -> None:
        """Connect cache backend (required for Redis)."""
        await self._cache.connect()

    async def shutdown(self) -> None:
        """Disconnect cache backend."""
        await self._cache.disconnect()

    async def get_role(self, role_id: UUID) -> Role:
        """Get role by ID. Raises RoleNotFoundError if missing."""
        async with self._create_uow(auto_commit=False) as uow:
            role = await uow.rbac.get_role_by_id(role_id)

            if role is None:
                raise RoleNotFoundError()

            return role

    async def get_role_by_code(self, code: str) -> Role:
        """Get role by code. Raises RoleNotFoundError if missing."""
        async with self._create_uow(auto_commit=False) as uow:
            role = await uow.rbac.get_role_by_code(code)

            if role is None:
                raise RoleNotFoundError(code)

            return role

    async def get_user_permissions(
        self,
        user_id: UUID,
        role_id: UUID,
    ) -> set[str]:
        """Get all permissions for a user (cached)."""
        cached = await self._cache.get(user_id)
        if cached is not None:
            return cached

        lock = await self._acquire_fetch_lock(user_id)

        async with lock:
            cached = await self._cache.get(user_id)
            if cached is not None:
                return cached

            # Capture timestamp BEFORE the DB fetch so the Lua/in-memory stale-write
            # guard rejects this set() if invalidate() runs between fetch and write.
            fetched_at = self._cache.get_fetch_timestamp()

            async with self._create_uow(auto_commit=False) as uow:
                permissions = await uow.rbac.get_role_permissions(role_id)

            # Best-effort cache write (cache-standards.md): a non-retryable Redis
            # error here must not crash the auth check — we already have the
            # permissions from DB and can serve the request.
            try:
                await self._cache.set(user_id, permissions, fetched_at=fetched_at)
            except Exception as e:
                logger.warning(
                    "permission_cache_set_failed",
                    user_id=str(user_id),
                    error=str(e),
                )

            logger.debug(
                "permissions_loaded",
                user_id=str(user_id),
                count=len(permissions),
            )

            return permissions

    async def _acquire_fetch_lock(self, user_id: UUID) -> asyncio.Lock:
        """
        Get or create a per-user fetch lock with bounded eviction.

        Evicts up to `_FETCH_LOCK_EVICT_PROBES` of the oldest unlocked entries
        when the dict is full. If every probed lock is held, the new lock is
        still inserted; the dict can briefly exceed `MAX_FETCH_LOCKS` but the
        excess is reclaimed on the next call once any lock is released.
        """
        async with self._fetch_locks_lock:
            existing = self._fetch_locks.get(user_id)
            if existing is not None:
                self._fetch_locks.move_to_end(user_id)
                return existing

            if len(self._fetch_locks) >= MAX_FETCH_LOCKS:
                self._evict_unlocked_fetch_locks()

            lock = asyncio.Lock()
            self._fetch_locks[user_id] = lock
            return lock

    def _evict_unlocked_fetch_locks(self) -> None:
        """Probe oldest entries and evict any that are not currently held."""
        # Snapshot the first N keys; modifying the dict mid-iteration is unsafe.
        candidates = []
        for key in self._fetch_locks:
            candidates.append(key)
            if len(candidates) >= _FETCH_LOCK_EVICT_PROBES:
                break

        for key in candidates:
            existing = self._fetch_locks.get(key)
            if existing is not None and not existing.locked():
                del self._fetch_locks[key]
                # Stop after reclaiming one slot; we only need room for the new lock.
                return

    async def check_permission(
        self,
        user_id: UUID,
        role_id: UUID,
        permission_code: str,
    ) -> bool:
        """Check if user has a specific permission."""
        permissions = await self.get_user_permissions(user_id, role_id)
        has_permission = permission_code in permissions

        if not has_permission:
            logger.debug(
                "permission_check_failed",
                user_id=str(user_id),
                permission=permission_code,
            )

        return has_permission

    async def require_permission(
        self,
        user_id: UUID,
        role_id: UUID,
        permission_code: str,
    ) -> None:
        """Raise PermissionDeniedError if user lacks the permission."""
        has_permission = await self.check_permission(user_id, role_id, permission_code)

        if not has_permission:
            logger.warning(
                "permission_denied",
                user_id=str(user_id),
                permission=permission_code,
            )
            raise PermissionDeniedError(permission_code)

    async def require_role(
        self,
        user_role_code: str,
        required_role_code: str,
    ) -> None:
        """Raise PermissionDeniedError if user's role does not match."""
        if user_role_code != required_role_code:
            logger.warning(
                "role_check_failed",
                user_role=user_role_code,
                required_role=required_role_code,
            )
            # Use the generic class-level message; the required role code is
            # an internal authz detail and must not be returned to the client
            # (CWE-209). Server-side context is in the warning log above.
            raise PermissionDeniedError()

    async def create_role(self, code: str, name: str) -> Role:
        """
        Create a new role.

        No cache invalidation: a brand-new role has no users assigned yet.
        """
        async with self._create_uow() as uow:
            return await uow.rbac.create_role(code, name)

    async def create_permission(self, code: str, type: PermissionType) -> Permission:
        """
        Create a new permission.

        No cache invalidation: a brand-new permission isn't linked to any role yet.
        """
        async with self._create_uow() as uow:
            return await uow.rbac.create_permission(code, type)

    async def assign_permission_to_role(
        self,
        role_id: UUID,
        permission_id: UUID,
    ) -> None:
        """
        Assign a permission to a role and invalidate the entire cache.

        We invalidate all cached permissions because the service does not track
        which users currently hold this role; per-user invalidation is impossible
        without an additional lookup. This matches the cache-standards.md two-layer
        ordering: write inside the UoW, invalidate after commit.
        """
        async with self._create_uow() as uow:
            await uow.rbac.assign_permission_to_role(role_id, permission_id)

        await self._cache.invalidate_all()

    async def invalidate_user_cache(self, user_id: UUID) -> None:
        """Invalidate cached permissions for a user (call on role change)."""
        await self._cache.invalidate(user_id)
        logger.debug("user_cache_invalidated", user_id=str(user_id))

    async def invalidate_all_cache(self) -> None:
        """Invalidate all cached permissions (call on global role/permission change)."""
        await self._cache.invalidate_all()
