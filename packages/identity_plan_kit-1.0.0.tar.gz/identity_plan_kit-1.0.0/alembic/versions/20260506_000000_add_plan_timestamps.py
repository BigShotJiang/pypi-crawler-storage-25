"""Add created_at and updated_at to plan-feature tables.

Revision ID: 005_add_plan_timestamps
Revises: 004_add_user_metadata
Create Date: 2026-05-06 00:00:00.000000

Brings plan-feature tables (plans, features, plan_limits, plan_permissions,
user_plans, feature_usage) under the standard BaseModel that mandates audit
columns. Existing rows are backfilled to ``now()`` via server_default.
"""
from __future__ import annotations

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "005_add_plan_timestamps"
down_revision: str | None = "004_add_user_metadata"
branch_labels: str | list[str] | None = None
depends_on: str | list[str] | None = None


_TABLES = (
    "plans",
    "features",
    "plan_limits",
    "plan_permissions",
    "user_plans",
    "feature_usage",
)


def upgrade() -> None:
    """Add created_at/updated_at to plan-feature tables."""
    for table in _TABLES:
        op.add_column(
            table,
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
            ),
        )
        op.add_column(
            table,
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
            ),
        )


def downgrade() -> None:
    """Remove created_at/updated_at from plan-feature tables."""
    for table in _TABLES:
        op.drop_column(table, "updated_at")
        op.drop_column(table, "created_at")
