"""Add metadata JSONB column to users table.

Revision ID: 004_add_user_metadata
Revises: 003_add_display_name_picture
Create Date: 2025-02-14 00:00:00.000000

This migration adds a flexible JSONB metadata column to users for
integrator-specific data (country, notification preferences, feature flags, etc.).
"""
from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "004_add_user_metadata"
down_revision: str | None = "003_add_display_name_picture"
branch_labels: str | list[str] | None = None
depends_on: str | list[str] | None = None


def upgrade() -> None:
    """Add metadata JSONB column to users table."""
    op.add_column(
        "users",
        sa.Column(
            "metadata",
            JSONB,
            nullable=True,
            server_default=sa.text("'{}'::jsonb"),
        ),
    )


def downgrade() -> None:
    """Remove metadata column from users table."""
    op.drop_column("users", "metadata")
