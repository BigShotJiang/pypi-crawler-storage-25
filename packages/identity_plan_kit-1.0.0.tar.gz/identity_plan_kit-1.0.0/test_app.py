#!/usr/bin/env python3
"""Test application for optimization fixes.

Usage:
    python test_app.py

Environment variables (from .env.test):
    IPK_DATABASE_URL - PostgreSQL connection
    IPK_REDIS_URL - Redis connection
    IPK_SECRET_KEY - JWT secret
    IPK_GOOGLE_CLIENT_ID - OAuth client ID
    IPK_GOOGLE_CLIENT_SECRET - OAuth client secret
    IPK_GOOGLE_REDIRECT_URI - OAuth redirect URI
"""
import os
from uuid import UUID

from fastapi import FastAPI, HTTPException
from identity_plan_kit import (
    CurrentUser,
    IdentityPlanKit,
    IdentityPlanKitConfig,
)

# Load environment variables from .env.test if it exists
try:
    from dotenv import load_dotenv

    if os.path.exists(".env.test"):
        load_dotenv(".env.test")
        print("✅ Loaded environment from .env.test")
    elif os.path.exists(".env"):
        load_dotenv(".env")
        print("✅ Loaded environment from .env")
except ImportError:
    print("⚠️  python-dotenv not installed, using existing environment variables")

# Configure
try:
    config = IdentityPlanKitConfig()
    print(f"✅ Configuration loaded (environment: {config.environment})")
except Exception as e:
    print(f"❌ Failed to load configuration: {e}")
    print("\nMake sure these environment variables are set:")
    print("  - IPK_DATABASE_URL")
    print("  - IPK_SECRET_KEY")
    print("  - IPK_GOOGLE_CLIENT_ID")
    print("  - IPK_GOOGLE_CLIENT_SECRET")
    print("  - IPK_GOOGLE_REDIRECT_URI")
    exit(1)

# Create kit
kit = IdentityPlanKit(
    config,
    startup_timeout=30.0,
    shutdown_drain_timeout=30.0,
)

# Create app with lifespan
app = FastAPI(
    title="IPK Optimization Test API",
    description="Test endpoints for validating optimization fixes",
    version="1.0.0",
    lifespan=kit.lifespan,
)

# Setup routes (auth, health, etc.)
kit.setup(
    app,
    register_error_handlers=True,
    include_health_routes=True,
    include_request_id=True,
)

print(f"✅ Routes mounted under: {config.api_prefix}{config.auth_prefix}")


# ============================================================================
# Test Endpoints
# ============================================================================


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "IPK Optimization Test API",
        "version": "1.0.0",
        "environment": config.environment.value,
        "endpoints": {
            "health": "/health",
            "auth": f"{config.api_prefix}{config.auth_prefix}",
            "tests": "/test",
            "admin": "/admin",
        },
        "testing": {
            "protected": "/test/protected",
            "quota": "/test/quota/{feature_code}",
            "permission": "/test/permission/{permission_code}",
            "plan": "/test/plan/{plan_code}",
        },
    }


@app.get("/test")
async def test_index():
    """Test endpoints index."""
    return {
        "message": "Test endpoints for optimization validation",
        "endpoints": [
            "GET /test/protected - Test authentication",
            "GET /test/quota/{feature_code} - Test quota consumption (CODE-1)",
            "GET /test/permission/{permission_code} - Test permission check (SEC-5)",
            "POST /test/plan/{plan_code} - Test plan assignment (PAT-1)",
            "GET /test/config - Show current configuration",
        ],
    }


@app.get("/test/config")
async def test_config():
    """Show current configuration (non-sensitive)."""
    return {
        "environment": config.environment.value,
        "api_prefix": config.api_prefix,
        "auth_prefix": config.auth_prefix,
        "database_pool_size": config.database_pool_size,
        "database_echo": config.database_echo,
        "redis_url": "***" if config.redis_url else None,
        "access_token_expire_minutes": config.access_token_expire_minutes,
        "refresh_token_expire_days": config.refresh_token_expire_days,
        "permission_cache_ttl_seconds": config.permission_cache_ttl_seconds,
        "plan_cache_ttl_seconds": config.plan_cache_ttl_seconds,
        "enable_metrics": config.enable_metrics,
    }


@app.get("/test/protected")
async def test_protected(user: CurrentUser):
    """Test authentication.

    This endpoint requires a valid access token.

    Returns:
        User information if authenticated
    """
    return {
        "message": "Authentication successful",
        "user": {
            "id": str(user.id),
            "email": user.email,
            "role_id": str(user.role_id) if user.role_id else None,
            "is_active": user.is_active,
        },
    }


@app.get("/test/quota/{feature_code}")
async def test_quota(
    feature_code: str,
    user: CurrentUser,
    amount: int = 1,
):
    """Test quota consumption.

    This validates CODE-1 fix: custom limit of 0 should be respected.

    Args:
        feature_code: Feature to check quota for
        amount: Amount to consume (default: 1)

    Returns:
        Quota usage information
    """
    usage = await kit.plan_service.check_and_consume_quota(
        user_id=user.id,
        feature_code=feature_code,
        amount=amount,
    )

    return {
        "feature_code": feature_code,
        "has_access": usage.has_access,
        "used": usage.used,
        "limit": usage.limit,
        "remaining": usage.remaining,
        "period": usage.period.value if usage.period else None,
        "reset_at": usage.reset_at.isoformat() if usage.reset_at else None,
    }


@app.get("/test/permission/{permission_code}")
async def test_permission(
    permission_code: str,
    user: CurrentUser,
):
    """Test permission check.

    This validates SEC-5 fix: error messages should not leak permission codes.

    Args:
        permission_code: Permission to check

    Returns:
        Permission check result
    """
    try:
        await kit.rbac_service.require_permission(
            user_id=user.id,
            role_id=user.role_id,
            permission_code=permission_code,
        )
        return {
            "permission_code": permission_code,
            "has_permission": True,
            "message": "Permission granted",
        }
    except HTTPException as e:
        # Check if error message leaks permission code (should not after SEC-5 fix)
        leaks_code = permission_code in str(e.detail)
        return {
            "permission_code": permission_code,
            "has_permission": False,
            "error_detail": e.detail,
            "error_status": e.status_code,
            "validation": {
                "leaks_permission_code": leaks_code,
                "fix_status": "❌ NEEDS FIX" if leaks_code else "✅ FIXED",
            },
        }


@app.post("/test/plan/{plan_code}")
async def test_assign_plan(
    plan_code: str,
    target_user_id: UUID,
    current_user: CurrentUser,
    custom_limits: dict[str, int] | None = None,
):
    """Test plan assignment.

    This validates PAT-1 fix: session.rollback() should not corrupt UoW.

    Args:
        plan_code: Plan to assign (e.g., "free", "pro")
        target_user_id: User to assign plan to
        custom_limits: Optional custom limits (e.g., {"api_calls": 0})

    Returns:
        Plan assignment result
    """
    # Check admin permission
    try:
        await kit.rbac_service.require_permission(
            user_id=current_user.id,
            role_id=current_user.role_id,
            permission_code="admin.plans.manage",
        )
    except HTTPException:
        raise HTTPException(
            status_code=403,
            detail="You do not have permission to manage plans",
        )

    # Assign plan
    try:
        user_plan = await kit.plan_service.assign_plan(
            user_id=target_user_id,
            plan_code=plan_code,
            custom_limits=custom_limits,
        )

        return {
            "user_id": str(user_plan.user_id),
            "plan_id": str(user_plan.plan_id),
            "plan_code": plan_code,
            "status": user_plan.status,
            "custom_limits": custom_limits,
            "message": "Plan assigned successfully",
        }
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to assign plan: {str(e)}",
        )


@app.get("/test/health")
async def test_health():
    """Test health check endpoints."""
    return {
        "message": "Health check endpoints available",
        "endpoints": {
            "full": "/health",
            "liveness": "/health/live",
            "readiness": "/health/ready",
        },
    }


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    import uvicorn

    print("\n" + "=" * 70)
    print("IPK Optimization Test API")
    print("=" * 70)
    print(f"Environment: {config.environment.value}")
    print(f"Database: {config.database_url.split('@')[-1]}")  # Hide credentials
    print(f"Redis: {config.redis_url or 'Not configured'}")
    print(f"API Prefix: {config.api_prefix or '/'}")
    print(f"Auth Prefix: {config.auth_prefix}")
    print("=" * 70)
    print("\nStarting server on http://0.0.0.0:8000")
    print("\nAvailable endpoints:")
    print("  - http://0.0.0.0:8000 (API info)")
    print("  - http://0.0.0.0:8000/test (Test endpoints)")
    print("  - http://0.0.0.0:8000/health (Health check)")
    print("  - http://0.0.0.0:8000/admin (Admin panel)")
    print(f"  - http://0.0.0.0:8000{config.api_prefix}{config.auth_prefix} (Auth)")
    print("\n" + "=" * 70 + "\n")

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="debug" if config.is_development else "info",
    )
