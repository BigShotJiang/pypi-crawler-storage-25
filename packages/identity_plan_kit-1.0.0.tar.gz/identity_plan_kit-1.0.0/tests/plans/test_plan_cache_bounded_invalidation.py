"""Test bounded _invalidated_at dict with LRU eviction.

This test suite verifies that the _invalidated_at dict doesn't grow unbounded,
fixing the memory leak issue (C3).
"""

import asyncio
import time

import pytest

from identity_plan_kit.plans.cache.plan_cache import InMemoryPlanCache
from identity_plan_kit.plans.domain.entities import Plan


@pytest.fixture
def sample_plan():
    """Create a sample plan for testing."""
    return Plan(
        id=1,
        code="test",
        name="Test Plan",
    )


class TestBoundedInvalidationDict:
    """Test that _invalidated_at dict is bounded with LRU eviction."""

    @pytest.mark.asyncio
    async def test_invalidated_at_dict_bounded_at_max_entries(self, sample_plan):
        """Test that _invalidated_at dict doesn't exceed max_entries."""
        # Create cache with small max_entries for testing
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=100)

        # Invalidate 150 distinct keys (50 more than max)
        for i in range(150):
            await cache.invalidate(f"plan_{i}")

        # Should be capped at max_entries
        assert len(cache._invalidated_at) == 100

    @pytest.mark.asyncio
    async def test_lru_eviction_removes_oldest_entries(self, sample_plan):
        """Test that LRU eviction removes the oldest invalidation timestamps."""
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=10)

        # Invalidate 15 keys
        for i in range(15):
            await cache.invalidate(f"plan_{i}")
            await asyncio.sleep(0.001)  # Small delay to ensure ordering

        # Dict should be capped at 10
        assert len(cache._invalidated_at) == 10

        # The first 5 keys should have been evicted (oldest)
        for i in range(5):
            assert f"plan_{i}" not in cache._invalidated_at

        # The last 10 keys should still be present
        for i in range(5, 15):
            assert f"plan_{i}" in cache._invalidated_at

    @pytest.mark.asyncio
    async def test_invalidation_with_cache_set_respects_bound(self, sample_plan):
        """Test that invalidation after caching entries respects max_entries."""
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=50)

        # Cache and then invalidate 100 plans
        for i in range(100):
            plan = Plan(
                id=i + 1,
                code=f"plan_{i}",
                name=f"Plan {i}",
            )
            await cache.set(f"plan_{i}", plan, fetched_at=time.monotonic())
            await cache.invalidate(f"plan_{i}")

        # Invalidation dict should be bounded
        assert len(cache._invalidated_at) == 50

    @pytest.mark.asyncio
    async def test_max_entries_default_value(self):
        """Test that default max_entries is set correctly."""
        cache = InMemoryPlanCache(ttl_seconds=300)
        # DEFAULT_MAX_CACHE_ENTRIES is 10000
        assert cache._max_entries == 10000

    @pytest.mark.asyncio
    async def test_invalidate_all_clears_bounded_dict(self):
        """Test that invalidate_all() still clears the entire dict."""
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=50)

        # Invalidate many entries
        for i in range(100):
            await cache.invalidate(f"plan_{i}")

        # Should be capped at 50
        assert len(cache._invalidated_at) == 50

        # invalidate_all() should clear everything
        await cache.invalidate_all()
        assert len(cache._invalidated_at) == 0

    @pytest.mark.asyncio
    async def test_concurrent_invalidation_maintains_bound(self, sample_plan):
        """Test that concurrent invalidations maintain the size bound."""
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=100)

        async def invalidate_batch(start: int, count: int):
            for i in range(start, start + count):
                await cache.invalidate(f"plan_{i}")

        # Run concurrent invalidation batches
        await asyncio.gather(
            invalidate_batch(0, 50),
            invalidate_batch(50, 50),
            invalidate_batch(100, 50),
            invalidate_batch(150, 50),
        )

        # Should be capped at max_entries even with concurrent access
        assert len(cache._invalidated_at) <= 100


class TestCleanupExpiredInvalidations:
    """Test that cleanup_expired() cleans old invalidation timestamps."""

    @pytest.mark.asyncio
    async def test_cleanup_removes_old_invalidation_timestamps(self, sample_plan):
        """Test that cleanup_expired() removes invalidation timestamps older than TTL."""
        # Create cache with 1 second TTL
        cache = InMemoryPlanCache(ttl_seconds=1, max_entries=1000)

        # Invalidate a plan
        await cache.invalidate("old_plan")
        assert "old_plan" in cache._invalidated_at

        # Wait for TTL to pass
        await asyncio.sleep(1.5)

        # Cleanup should remove the old invalidation timestamp
        removed = await cache.cleanup_expired()
        assert "old_plan" not in cache._invalidated_at

    @pytest.mark.asyncio
    async def test_cleanup_keeps_recent_invalidation_timestamps(self, sample_plan):
        """Test that cleanup_expired() keeps recent invalidation timestamps."""
        cache = InMemoryPlanCache(ttl_seconds=10, max_entries=1000)

        # Invalidate a plan
        await cache.invalidate("recent_plan")
        assert "recent_plan" in cache._invalidated_at

        # Cleanup immediately - should keep the recent timestamp
        await cache.cleanup_expired()
        assert "recent_plan" in cache._invalidated_at

    @pytest.mark.asyncio
    async def test_cleanup_expired_entries_and_invalidations(self, sample_plan):
        """Test that cleanup removes both expired entries and old invalidations."""
        cache = InMemoryPlanCache(ttl_seconds=1, max_entries=1000)

        # Cache a plan
        await cache.set("test_plan", sample_plan, fetched_at=time.monotonic())
        assert "test_plan" in cache._cache

        # Invalidate another plan
        await cache.invalidate("other_plan")
        assert "other_plan" in cache._invalidated_at

        # Wait for TTL
        await asyncio.sleep(1.5)

        # Cleanup should remove both
        removed = await cache.cleanup_expired()
        assert "test_plan" not in cache._cache
        assert "other_plan" not in cache._invalidated_at

    @pytest.mark.asyncio
    async def test_cleanup_mixed_old_and_recent_timestamps(self):
        """Test cleanup with mix of old and recent invalidation timestamps."""
        cache = InMemoryPlanCache(ttl_seconds=2, max_entries=1000)

        # Invalidate old plans
        for i in range(5):
            await cache.invalidate(f"old_plan_{i}")

        # Wait for these to become stale
        await asyncio.sleep(2.5)

        # Invalidate recent plans
        for i in range(5):
            await cache.invalidate(f"recent_plan_{i}")

        # Cleanup should only remove old ones
        await cache.cleanup_expired()

        # Old plans should be gone
        for i in range(5):
            assert f"old_plan_{i}" not in cache._invalidated_at

        # Recent plans should remain
        for i in range(5):
            assert f"recent_plan_{i}" in cache._invalidated_at


class TestMemoryLeakPrevention:
    """Test that the fixes prevent memory leaks in long-running scenarios."""

    @pytest.mark.asyncio
    async def test_sustained_invalidation_doesnt_grow_unbounded(self):
        """Test that sustained invalidation over time doesn't cause unbounded growth."""
        cache = InMemoryPlanCache(ttl_seconds=300, max_entries=100)

        # Simulate a long-running process with continuous invalidations
        for batch in range(10):
            for i in range(50):
                await cache.invalidate(f"plan_{batch}_{i}")

            # Dict should never exceed max_entries
            assert len(cache._invalidated_at) <= 100

        # Final size should be exactly max_entries
        assert len(cache._invalidated_at) == 100

    @pytest.mark.asyncio
    async def test_periodic_cleanup_controls_growth(self):
        """Test that periodic cleanup keeps memory usage under control."""
        cache = InMemoryPlanCache(ttl_seconds=1, max_entries=1000)

        # Add many invalidations
        for i in range(500):
            await cache.invalidate(f"plan_{i}")

        assert len(cache._invalidated_at) == 500

        # Wait for TTL
        await asyncio.sleep(1.5)

        # Cleanup should remove all old timestamps
        await cache.cleanup_expired()
        assert len(cache._invalidated_at) == 0

    @pytest.mark.asyncio
    async def test_lru_eviction_prevents_unbounded_growth(self):
        """Test that LRU eviction alone prevents unbounded growth."""
        cache = InMemoryPlanCache(ttl_seconds=3600, max_entries=100)  # Long TTL

        # Continuously invalidate without cleanup
        for i in range(1000):
            await cache.invalidate(f"plan_{i}")

        # Should still be bounded at max_entries despite no cleanup
        assert len(cache._invalidated_at) == 100
