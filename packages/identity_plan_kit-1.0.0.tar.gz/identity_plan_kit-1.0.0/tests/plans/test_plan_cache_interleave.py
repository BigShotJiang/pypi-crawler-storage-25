"""Tests for PlanCache interleave and partial failure scenarios.

Tests cover:
- P2 #9: Concurrent set_all and individual invalidate don't corrupt state
- P2 #10: If UoW commit fails, cache is NOT invalidated (stale data not served)

CRITICAL: These tests verify edge cases in cache consistency under
interleaved operations and transaction failures.
"""

import asyncio
from datetime import date, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.cache.plan_cache import InMemoryPlanCache, PlanCache
from identity_plan_kit.plans.cache.user_plan_cache import InMemoryUserPlanCache
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.domain.exceptions import UserPlanNotFoundError
from identity_plan_kit.plans.services.plan_service import PlanService

pytestmark = pytest.mark.anyio


def _make_plan(code: str) -> Plan:
    plan_id = uuid4()
    return Plan(
        id=plan_id,
        code=code,
        name=f"Plan {code}",
        permissions={"read"},
        limits={
            "api_calls": PlanLimit(
                id=uuid4(),
                plan_id=plan_id,
                feature_id=uuid4(),
                feature_code="api_calls",
                limit=100,
                period=PeriodType.DAILY,
            ),
        },
    )


def _make_user_plan(user_id=None, plan_code="free") -> UserPlan:
    return UserPlan(
        id=uuid4(),
        user_id=user_id or uuid4(),
        plan_id=uuid4(),
        plan_code=plan_code,
        started_at=date.today() - timedelta(days=10),
        ends_at=date.today() + timedelta(days=20),
        custom_limits={},
    )


class TestSetAllInterleave:
    """P2 #9: Concurrent set_all and individual invalidate don't corrupt cache."""

    async def test_invalidate_during_set_all_clears_invalidated_plan(self):
        """
        If invalidate("plan_2") runs during set_all([plan_1, plan_2, plan_3]),
        the final state should NOT contain stale plan_2 data.

        set_all() populates individual plans after setting the all-plans list.
        An invalidate() between these steps should take precedence.
        """
        cache = InMemoryPlanCache(ttl_seconds=60)
        plans = [_make_plan(f"plan_{i}") for i in range(3)]

        # Populate cache initially
        await cache.set_all(plans)

        # Now simulate: admin updates plan_2, invalidating it
        await cache.invalidate("plan_1")

        # Verify plan_1 is gone, others remain
        assert await cache.get("plan_1") is None
        assert await cache.get("plan_0") is not None
        assert await cache.get("plan_2") is not None

        # The all-plans cache should also be cleared by invalidate()
        assert await cache.get_all() is None

    async def test_concurrent_set_all_and_invalidate_no_crash(self):
        """Concurrent set_all and invalidate operations don't cause errors."""
        cache = InMemoryPlanCache(ttl_seconds=60)
        errors = []

        async def set_all_writer():
            for i in range(20):
                try:
                    plans = [_make_plan(f"plan_{j}") for j in range(5)]
                    await cache.set_all(plans)
                except Exception as e:
                    errors.append(f"set_all error: {e}")
                await asyncio.sleep(0)

        async def invalidator():
            for i in range(50):
                try:
                    await cache.invalidate(f"plan_{i % 5}")
                except Exception as e:
                    errors.append(f"invalidate error: {e}")
                await asyncio.sleep(0)

        async def reader():
            for _ in range(100):
                try:
                    # Read individual plans
                    for j in range(5):
                        result = await cache.get(f"plan_{j}")
                        if result is not None:
                            assert result.code == f"plan_{j}"
                    # Read all plans
                    all_plans = await cache.get_all()
                    if all_plans is not None:
                        for p in all_plans:
                            assert p.code.startswith("plan_")
                except Exception as e:
                    errors.append(f"reader error: {e}")
                await asyncio.sleep(0)

        await asyncio.gather(
            set_all_writer(),
            invalidator(),
            reader(),
        )

        assert len(errors) == 0, f"Errors during interleaved operations: {errors}"

    async def test_set_all_invalidate_all_interleave(self):
        """Concurrent set_all and invalidate_all don't corrupt state."""
        cache = InMemoryPlanCache(ttl_seconds=60)
        errors = []

        async def set_all_writer():
            for _ in range(20):
                try:
                    plans = [_make_plan(f"plan_{j}") for j in range(5)]
                    fetch_ts = cache.get_fetch_timestamp()
                    await cache.set_all(plans, fetched_at=fetch_ts)
                except Exception as e:
                    errors.append(f"set_all error: {e}")
                await asyncio.sleep(0)

        async def invalidator():
            for _ in range(10):
                try:
                    await cache.invalidate_all()
                except Exception as e:
                    errors.append(f"invalidate_all error: {e}")
                await asyncio.sleep(0.01)

        await asyncio.gather(set_all_writer(), invalidator())

        assert len(errors) == 0, f"Errors: {errors}"

    async def test_stale_set_all_rejected_after_invalidate_all(self):
        """set_all with old fetch_ts after invalidate_all is rejected."""
        cache = InMemoryPlanCache(ttl_seconds=60)
        plans = [_make_plan(f"plan_{i}") for i in range(3)]

        fetch_ts = cache.get_fetch_timestamp()
        await asyncio.sleep(0.001)
        await cache.invalidate_all()

        result = await cache.set_all(plans, fetched_at=fetch_ts)

        assert result is False
        assert await cache.get_all() is None
        for i in range(3):
            assert await cache.get(f"plan_{i}") is None

    async def test_set_all_populates_individual_and_all_atomically(self):
        """set_all must populate both all-plans cache and individual plans."""
        cache = InMemoryPlanCache(ttl_seconds=60)
        plans = [_make_plan(f"plan_{i}") for i in range(3)]

        result = await cache.set_all(plans)
        assert result is True

        # All-plans cache populated
        all_cached = await cache.get_all()
        assert all_cached is not None
        assert len(all_cached) == 3

        # Individual plans also populated
        for i in range(3):
            cached = await cache.get(f"plan_{i}")
            assert cached is not None
            assert cached.code == f"plan_{i}"


class TestPartialFailureRollback:
    """P2 #10: If UoW commit fails, cache must NOT be invalidated.

    The service pattern is:
        async with self._create_uow() as uow:
            # ... DB operations ...
        # Cache invalidation happens here (AFTER UoW exits)

    If an exception occurs inside the UoW, the UoW rolls back and
    the code after `async with` doesn't execute. Therefore cache
    invalidation is skipped, which is correct - stale cache data
    reflects the actual DB state since the transaction was rolled back.
    """

    async def test_assign_plan_failure_does_not_invalidate_cache(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If assign_plan fails during UoW, cache remains populated."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        # Pre-populate cache with existing plan
        old_plan = _make_plan("free")
        old_user_plan = _make_user_plan(user_id=user_id, plan_code="free")
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, old_user_plan, old_plan)
        service._user_plan_cache = cache

        # Mock UoW that fails during plan creation
        mock_uow = AsyncMock()
        mock_uow.plans.get_plan_by_code = AsyncMock(return_value=_make_plan("pro"))
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=old_user_plan)
        mock_uow.plans.expire_user_plan = AsyncMock()
        mock_uow.plans.create_user_plan = AsyncMock(
            side_effect=RuntimeError("DB connection lost")
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def uow_exit(exc_type, exc_val, exc_tb):
            # Simulate rollback on error
            if exc_type is not None:
                return False  # Don't suppress exception

        mock_uow.__aexit__ = AsyncMock(side_effect=uow_exit)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            with pytest.raises(RuntimeError, match="DB connection lost"):
                await service.assign_plan(
                    user_id=user_id,
                    plan_code="pro",
                    expire_current=True,
                )

        # CRITICAL: Cache should still have the old data (NOT invalidated)
        cached = await cache.get(user_id)
        assert cached is not None, (
            "Cache was invalidated despite transaction failure! "
            "This would cause stale data on next request."
        )
        up, p = cached
        assert p.code == "free"  # Still the old plan

    async def test_extend_plan_failure_does_not_invalidate_cache(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If extend_plan fails during UoW, cache remains populated."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        old_plan = _make_plan("pro")
        old_user_plan = _make_user_plan(user_id=user_id, plan_code="pro")
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, old_user_plan, old_plan)
        service._user_plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=old_user_plan)
        mock_uow.plans.update_user_plan = AsyncMock(
            side_effect=RuntimeError("DB timeout")
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def uow_exit(exc_type, exc_val, exc_tb):
            if exc_type is not None:
                return False

        mock_uow.__aexit__ = AsyncMock(side_effect=uow_exit)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            with pytest.raises(RuntimeError, match="DB timeout"):
                await service.extend_plan(
                    user_id=user_id,
                    new_ends_at=date.today() + timedelta(days=60),
                )

        # Cache should still have old data
        cached = await cache.get(user_id)
        assert cached is not None
        up, p = cached
        assert p.code == "pro"

    async def test_cancel_plan_failure_does_not_invalidate_cache(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If cancel_plan fails during UoW, cache remains populated."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        old_plan = _make_plan("pro")
        old_user_plan = _make_user_plan(user_id=user_id, plan_code="pro")
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, old_user_plan, old_plan)
        service._user_plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.plans.cancel_user_plan = AsyncMock(
            side_effect=RuntimeError("Deadlock detected")
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def uow_exit(exc_type, exc_val, exc_tb):
            if exc_type is not None:
                return False

        mock_uow.__aexit__ = AsyncMock(side_effect=uow_exit)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            with pytest.raises(RuntimeError, match="Deadlock detected"):
                await service.cancel_plan(user_id=user_id, immediate=True)

        # Cache should still have old data
        cached = await cache.get(user_id)
        assert cached is not None

    async def test_update_plan_limits_failure_does_not_invalidate_cache(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If update_plan_limits fails during UoW, cache remains populated."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        old_plan = _make_plan("pro")
        old_user_plan = _make_user_plan(user_id=user_id, plan_code="pro")
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, old_user_plan, old_plan)
        service._user_plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=old_user_plan)
        mock_uow.plans.update_user_plan = AsyncMock(
            side_effect=RuntimeError("Constraint violation")
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def uow_exit(exc_type, exc_val, exc_tb):
            if exc_type is not None:
                return False

        mock_uow.__aexit__ = AsyncMock(side_effect=uow_exit)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            with pytest.raises(RuntimeError, match="Constraint violation"):
                await service.update_plan_limits(
                    user_id=user_id,
                    custom_limits={"api_calls": 5000},
                )

        # Cache should still have old data
        cached = await cache.get(user_id)
        assert cached is not None
