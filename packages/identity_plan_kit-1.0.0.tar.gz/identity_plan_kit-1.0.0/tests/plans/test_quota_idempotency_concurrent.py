"""Concurrent tests for quota idempotency.

Tests cover:
- Concurrent check_and_consume_quota with same idempotency key
- Concurrent check_and_consume_quota with different idempotency keys
- Idempotency key prevents double consumption
- Race between first write and duplicate read

CRITICAL: These tests verify that two concurrent check_and_consume_quota calls
with the same idempotency key result in exactly one consumption, not two.
"""

import asyncio
from datetime import date, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.cache.user_plan_cache import InMemoryUserPlanCache
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.domain.exceptions import QuotaExceededError
from identity_plan_kit.plans.dto.usage import UsageInfo
from identity_plan_kit.plans.services.plan_service import PlanService
from identity_plan_kit.shared.state_store import InMemoryStateStore, StateStoreManager

pytestmark = pytest.mark.anyio


# Test fixtures
TEST_USER_ID = UUID("12345678-1234-1234-1234-123456789012")
TEST_FEATURE_ID = UUID("00000001-0000-0000-0000-000000000001")
TEST_PLAN_ID = UUID("00000002-0000-0000-0000-000000000002")


def _make_plan() -> Plan:
    return Plan(
        id=TEST_PLAN_ID,
        code="free",
        name="Free Plan",
        permissions={"read:data"},
        limits={
            "api_calls": PlanLimit(
                id=uuid4(),
                plan_id=TEST_PLAN_ID,
                feature_id=TEST_FEATURE_ID,
                feature_code="api_calls",
                limit=100,
                period=PeriodType.DAILY,
            ),
        },
    )


def _make_user_plan() -> UserPlan:
    return UserPlan(
        id=uuid4(),
        user_id=TEST_USER_ID,
        plan_id=TEST_PLAN_ID,
        plan_code="free",
        started_at=date.today() - timedelta(days=10),
        ends_at=date.today() + timedelta(days=20),
        custom_limits={},
    )


def _create_service_with_state_store(
    mock_config: IdentityPlanKitConfig,
    state_store_manager: StateStoreManager,
    atomic_consume_side_effect=None,
) -> tuple[PlanService, AsyncMock]:
    """Create a PlanService with mocked UoW and real state store."""
    mock_session_factory = MagicMock()

    # Override idempotency TTL to be non-zero
    mock_config_with_ttl = IdentityPlanKitConfig(
        database_url=mock_config.database_url,
        secret_key=mock_config.secret_key.get_secret_value(),
        google_client_id=mock_config.google_client_id,
        google_client_secret=mock_config.google_client_secret.get_secret_value(),
        google_redirect_uri=mock_config.google_redirect_uri,
        quota_idempotency_ttl_seconds=60,
    )

    service = PlanService(
        config=mock_config_with_ttl,
        session_factory=mock_session_factory,
        state_store_manager=state_store_manager,
        user_plan_cache_ttl_seconds=0,  # Disable cache for direct DB testing
    )

    plan = _make_plan()
    user_plan = _make_user_plan()

    # Track how many times atomic_check_and_consume is actually called
    call_count = 0

    async def counting_consume(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if atomic_consume_side_effect:
            return await atomic_consume_side_effect(*args, **kwargs)
        return call_count * 10  # Return incrementing usage

    mock_uow = AsyncMock()
    mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
        return_value=(user_plan, plan)
    )
    mock_uow.plans.get_user_active_plan = AsyncMock(return_value=user_plan)
    mock_uow.usage.atomic_check_and_consume = AsyncMock(side_effect=counting_consume)
    mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
    mock_uow.__aexit__ = AsyncMock(return_value=None)

    return service, mock_uow


class TestConcurrentIdempotencyKey:
    """Test concurrent quota consumption with same idempotency key."""

    async def test_same_key_consumes_once(
        self,
        mock_config: IdentityPlanKitConfig,
        state_store_manager: StateStoreManager,
    ):
        """Two concurrent calls with same idempotency key consume quota only once."""
        service, mock_uow = _create_service_with_state_store(
            mock_config, state_store_manager
        )
        idempotency_key = "test-key-123"

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # First call should consume
            result1 = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key=idempotency_key,
            )

            # Second call with same key should return cached result
            result2 = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key=idempotency_key,
            )

        # Both should return the same usage
        assert result1.used == result2.used
        assert result1.feature_code == result2.feature_code

        # atomic_check_and_consume should only be called ONCE
        assert mock_uow.usage.atomic_check_and_consume.call_count == 1, (
            f"Expected 1 DB call, got {mock_uow.usage.atomic_check_and_consume.call_count}. "
            "Idempotency key did not prevent double consumption!"
        )

    async def test_different_keys_consume_independently(
        self,
        mock_config: IdentityPlanKitConfig,
        state_store_manager: StateStoreManager,
    ):
        """Different idempotency keys consume quota independently."""
        service, mock_uow = _create_service_with_state_store(
            mock_config, state_store_manager
        )

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result1 = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="key-1",
            )

            result2 = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="key-2",
            )

        # Both should have consumed independently
        assert mock_uow.usage.atomic_check_and_consume.call_count == 2

    async def test_concurrent_same_key_first_wins(
        self,
        mock_config: IdentityPlanKitConfig,
        state_store_manager: StateStoreManager,
    ):
        """
        When multiple concurrent requests use same idempotency key,
        only one should consume quota. Others should get cached result.

        Note: Due to the sequential nature of asyncio in a single event loop,
        this test verifies the idempotency guarantee even if the requests
        are serialized by the event loop scheduler.
        """
        service, mock_uow = _create_service_with_state_store(
            mock_config, state_store_manager
        )
        idempotency_key = "concurrent-key"

        async def consume():
            with patch.object(service, "_create_uow", return_value=mock_uow):
                return await service.check_and_consume_quota(
                    user_id=TEST_USER_ID,
                    feature_code="api_calls",
                    amount=10,
                    idempotency_key=idempotency_key,
                )

        # Fire 5 concurrent requests with same key
        results = await asyncio.gather(*[consume() for _ in range(5)])

        # All should return valid results
        assert all(isinstance(r, UsageInfo) for r in results)
        assert all(r.feature_code == "api_calls" for r in results)

        # Only the first one should have hit the DB
        # (subsequent ones find the cached idempotency result)
        assert mock_uow.usage.atomic_check_and_consume.call_count == 1, (
            f"Expected 1 DB call, got {mock_uow.usage.atomic_check_and_consume.call_count}. "
            "Concurrent idempotent requests consumed quota multiple times!"
        )

    async def test_no_key_always_consumes(
        self,
        mock_config: IdentityPlanKitConfig,
        state_store_manager: StateStoreManager,
    ):
        """Without idempotency key, every call consumes quota."""
        service, mock_uow = _create_service_with_state_store(
            mock_config, state_store_manager
        )

        with patch.object(service, "_create_uow", return_value=mock_uow):
            for _ in range(5):
                await service.check_and_consume_quota(
                    user_id=TEST_USER_ID,
                    feature_code="api_calls",
                    amount=10,
                    # No idempotency_key
                )

        assert mock_uow.usage.atomic_check_and_consume.call_count == 5


class TestIdempotencyCacheResilience:
    """Test idempotency behavior when state store has issues."""

    async def test_state_store_error_on_read_still_consumes(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If state store fails on read, quota consumption still proceeds."""
        mock_session_factory = MagicMock()

        # Create a state store that fails on reads
        failing_store = AsyncMock()
        failing_store.get = AsyncMock(side_effect=Exception("Redis down"))
        failing_store.set = AsyncMock()  # Set works

        manager = MagicMock(spec=StateStoreManager)
        manager.is_initialized = True
        manager.store = failing_store

        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost:5432/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="test-client-id",
            google_client_secret="test-client-secret",
            google_redirect_uri="http://localhost:8000/auth/google/callback",
            quota_idempotency_ttl_seconds=60,
        )

        service = PlanService(
            config=config,
            session_factory=mock_session_factory,
            state_store_manager=manager,
            user_plan_cache_ttl_seconds=0,
        )

        plan = _make_plan()
        user_plan = _make_user_plan()

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            return_value=(user_plan, plan)
        )
        mock_uow.usage.atomic_check_and_consume = AsyncMock(return_value=10)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # Should succeed despite state store read failure
            result = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="failing-key",
            )

        assert result.used == 10
        # DB was hit (no cache short-circuit)
        mock_uow.usage.atomic_check_and_consume.assert_called_once()

    async def test_state_store_error_on_write_still_returns_result(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """If state store fails on write, result is still returned (just not cached)."""
        mock_session_factory = MagicMock()

        failing_store = AsyncMock()
        failing_store.get = AsyncMock(return_value=None)  # Read works
        failing_store.set = AsyncMock(side_effect=Exception("Redis down"))

        manager = MagicMock(spec=StateStoreManager)
        manager.is_initialized = True
        manager.store = failing_store

        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost:5432/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="test-client-id",
            google_client_secret="test-client-secret",
            google_redirect_uri="http://localhost:8000/auth/google/callback",
            quota_idempotency_ttl_seconds=60,
        )

        service = PlanService(
            config=config,
            session_factory=mock_session_factory,
            state_store_manager=manager,
            user_plan_cache_ttl_seconds=0,
        )

        plan = _make_plan()
        user_plan = _make_user_plan()

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            return_value=(user_plan, plan)
        )
        mock_uow.usage.atomic_check_and_consume = AsyncMock(return_value=10)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="write-fail-key",
            )

        # Result should be returned even though caching failed
        assert result.used == 10
        assert result.feature_code == "api_calls"


class TestIdempotencyWithDisabledTTL:
    """Test idempotency when TTL is 0 (disabled)."""

    async def test_zero_ttl_disables_idempotency(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """When quota_idempotency_ttl_seconds=0, idempotency is disabled."""
        mock_session_factory = MagicMock()

        # Config with TTL=0 (default from mock_config)
        service = PlanService(
            config=mock_config,
            session_factory=mock_session_factory,
            user_plan_cache_ttl_seconds=0,
        )

        plan = _make_plan()
        user_plan = _make_user_plan()

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            return_value=(user_plan, plan)
        )
        mock_uow.usage.atomic_check_and_consume = AsyncMock(return_value=10)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # Both calls should consume, even with same key
            await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="same-key",
            )
            await service.check_and_consume_quota(
                user_id=TEST_USER_ID,
                feature_code="api_calls",
                amount=10,
                idempotency_key="same-key",
            )

        # Both should have consumed
        assert mock_uow.usage.atomic_check_and_consume.call_count == 2
