"""Concurrent tests for user plan cache.

Tests cover:
- Concurrent get/set operations
- Stale write prevention under concurrent load
- Invalidation during reads/writes
- invalidate_all during operations
- Write lock atomicity verification
- High contention mixed operations

CRITICAL: These tests ensure InMemoryUserPlanCache maintains integrity
under concurrent access patterns, validating the _write_lock fix.
"""

import asyncio
from datetime import UTC, date, datetime, timedelta
from uuid import uuid4

import pytest

from identity_plan_kit.plans.cache.user_plan_cache import (
    InMemoryUserPlanCache,
    UserPlanCache,
    UserPlanCacheEntry,
)
from identity_plan_kit.plans.domain.entities import Plan, PlanLimit, PeriodType, UserPlan

pytestmark = pytest.mark.anyio


def create_test_plan(code: str, name: str | None = None) -> Plan:
    """Create a test plan entity."""
    return Plan(
        id=uuid4(),
        code=code,
        name=name or f"Test Plan {code}",
        permissions={"read", "write"},
        limits={},
    )


def create_test_user_plan(
    user_id=None,
    plan_code: str = "free",
) -> UserPlan:
    """Create a test user plan entity."""
    return UserPlan(
        id=uuid4(),
        user_id=user_id or uuid4(),
        plan_id=uuid4(),
        plan_code=plan_code,
        started_at=date.today(),
        ends_at=date.today() + timedelta(days=365),
        custom_limits={},
    )


class TestConcurrentGetSet:
    """Test concurrent get and set operations."""

    async def test_concurrent_gets_same_user(self):
        """Multiple concurrent gets return consistent data."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_id = uuid4()
        plan = create_test_plan("pro", "Pro Plan")
        user_plan = create_test_user_plan(user_id=user_id, plan_code="pro")
        await cache.set(user_id, user_plan, plan)

        async def reader(reader_id: int):
            results = []
            for _ in range(50):
                result = await cache.get(user_id)
                results.append(result)
            return results

        all_results = await asyncio.gather(*[reader(i) for i in range(10)])

        for reader_results in all_results:
            for result in reader_results:
                assert result is not None
                up, p = result
                assert p.code == "pro"
                assert p.name == "Pro Plan"
                assert up.user_id == user_id

    async def test_concurrent_sets_same_user(self):
        """Concurrent sets to same user don't corrupt data."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_id = uuid4()
        corruptions = []

        async def writer(writer_id: int):
            for i in range(20):
                plan = create_test_plan("plan", f"Writer {writer_id} v{i}")
                user_plan = create_test_user_plan(user_id=user_id, plan_code="plan")
                await cache.set(user_id, user_plan, plan)

        async def reader():
            for _ in range(100):
                result = await cache.get(user_id)
                if result is not None:
                    up, p = result
                    if not p.name.startswith("Writer"):
                        corruptions.append(p.name)
                    if up.user_id != user_id:
                        corruptions.append(f"Wrong user_id: {up.user_id}")
                await asyncio.sleep(0)

        await asyncio.gather(
            writer(1), writer(2), writer(3),
            reader(), reader(),
        )

        assert len(corruptions) == 0, f"Data corruptions found: {corruptions}"

    async def test_concurrent_sets_different_users(self):
        """Concurrent sets to different users all succeed."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_ids = [uuid4() for _ in range(100)]

        async def writer(start: int, count: int):
            for i in range(start, start + count):
                plan = create_test_plan(f"plan_{i}")
                user_plan = create_test_user_plan(
                    user_id=user_ids[i], plan_code=f"plan_{i}"
                )
                await cache.set(user_ids[i], user_plan, plan)

        await asyncio.gather(
            writer(0, 20),
            writer(20, 20),
            writer(40, 20),
            writer(60, 20),
            writer(80, 20),
        )

        for i in range(100):
            result = await cache.get(user_ids[i])
            assert result is not None, f"User plan {i} not found in cache"
            up, p = result
            assert p.code == f"plan_{i}"


class TestConcurrentInvalidation:
    """Test cache invalidation under concurrency."""

    async def test_invalidate_during_reads(self):
        """Invalidation during reads doesn't cause errors."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_ids = [uuid4() for _ in range(50)]

        for uid in user_ids:
            plan = create_test_plan("plan")
            user_plan = create_test_user_plan(user_id=uid)
            await cache.set(uid, user_plan, plan)

        errors = []

        async def reader():
            for i in range(200):
                try:
                    await cache.get(user_ids[i % 50])
                except Exception as e:
                    errors.append(str(e))
                await asyncio.sleep(0)

        async def invalidator():
            for uid in user_ids:
                await cache.invalidate(uid)
                await asyncio.sleep(0.001)

        await asyncio.gather(reader(), reader(), invalidator())

        assert len(errors) == 0, f"Errors during concurrent access: {errors}"

    async def test_invalidate_all_during_operations(self):
        """invalidate_all during other operations is safe."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        errors = []
        user_ids = [uuid4() for _ in range(100)]

        async def writer():
            for i in range(100):
                try:
                    plan = create_test_plan(f"plan_{i}")
                    user_plan = create_test_user_plan(user_id=user_ids[i])
                    await cache.set(user_ids[i], user_plan, plan)
                except Exception as e:
                    errors.append(f"Writer error: {e}")
                await asyncio.sleep(0)

        async def reader():
            for i in range(100):
                try:
                    await cache.get(user_ids[i % 50])
                except Exception as e:
                    errors.append(f"Reader error: {e}")
                await asyncio.sleep(0)

        async def invalidator():
            for _ in range(10):
                try:
                    await cache.invalidate_all()
                except Exception as e:
                    errors.append(f"Invalidator error: {e}")
                await asyncio.sleep(0.01)

        await asyncio.gather(writer(), reader(), invalidator())

        assert len(errors) == 0, f"Errors during operations: {errors}"


class TestStaleWritePrevention:
    """Test stale write prevention after invalidation.

    These tests verify that the _write_lock ensures atomic
    check-and-write, preventing stale data from being re-cached
    after invalidation.
    """

    async def test_stale_write_rejected_after_invalidation(self):
        """Writes with fetch_ts before invalidation are rejected."""
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()
        plan = create_test_plan("pro")
        user_plan = create_test_user_plan(user_id=user_id, plan_code="pro")

        fetch_ts = cache.get_fetch_timestamp()
        await asyncio.sleep(0.001)
        await cache.invalidate(user_id)

        result = await cache.set(user_id, user_plan, plan, fetched_at=fetch_ts)

        assert result is False
        assert await cache.get(user_id) is None

    async def test_fresh_write_accepted_after_invalidation(self):
        """Writes with fetch_ts after invalidation are accepted."""
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()
        plan = create_test_plan("pro")
        user_plan = create_test_user_plan(user_id=user_id, plan_code="pro")

        await cache.invalidate(user_id)
        await asyncio.sleep(0.001)
        fetch_ts = cache.get_fetch_timestamp()

        result = await cache.set(user_id, user_plan, plan, fetched_at=fetch_ts)

        assert result is True
        assert await cache.get(user_id) is not None

    async def test_stale_write_rejected_after_invalidate_all(self):
        """Writes with fetch_ts before invalidate_all are rejected."""
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_ids = [uuid4() for _ in range(5)]

        fetch_timestamps = [cache.get_fetch_timestamp() for _ in range(5)]

        await asyncio.sleep(0.001)
        await cache.invalidate_all()

        for i, uid in enumerate(user_ids):
            plan = create_test_plan(f"plan_{i}")
            user_plan = create_test_user_plan(user_id=uid)
            result = await cache.set(uid, user_plan, plan, fetched_at=fetch_timestamps[i])
            assert result is False

    async def test_concurrent_invalidation_and_set_race(self):
        """
        Simulates race between fetch-set and invalidation.

        Timeline:
        - T=0: Request A fetches user plan from DB (fetch_ts=T0)
        - T=1: Admin updates plan, calls invalidate()
        - T=2: Request A tries to set stale data (should be rejected)
        """
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()
        plan_v1 = create_test_plan("pro", "Pro v1")
        plan_v2 = create_test_plan("pro", "Pro v2")
        user_plan_v1 = create_test_user_plan(user_id=user_id, plan_code="pro")
        user_plan_v2 = create_test_user_plan(user_id=user_id, plan_code="pro")

        fetch_ts_a = cache.get_fetch_timestamp()

        async def slow_db_fetch():
            """Simulates slow DB query trying to cache stale data."""
            await asyncio.sleep(0.1)
            return await cache.set(
                user_id, user_plan_v1, plan_v1, fetched_at=fetch_ts_a
            )

        async def admin_update():
            """Admin invalidates then caches new version."""
            await asyncio.sleep(0.05)
            await cache.invalidate(user_id)
            fresh_ts = cache.get_fetch_timestamp()
            await cache.set(user_id, user_plan_v2, plan_v2, fetched_at=fresh_ts)

        results = await asyncio.gather(slow_db_fetch(), admin_update())

        assert results[0] is False  # Stale write rejected

        cached = await cache.get(user_id)
        assert cached is not None
        _, p = cached
        assert p.name == "Pro v2"

    async def test_set_without_fetch_ts_always_succeeds(self):
        """For backwards compatibility, set without fetch_ts always succeeds."""
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()
        plan = create_test_plan("pro")
        user_plan = create_test_user_plan(user_id=user_id, plan_code="pro")

        await cache.invalidate(user_id)

        result = await cache.set(user_id, user_plan, plan)
        assert result is True
        assert await cache.get(user_id) is not None

    async def test_concurrent_stale_writes_all_rejected(self):
        """Multiple concurrent stale writes are all rejected after invalidation."""
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()

        # All fetch timestamps obtained before invalidation
        fetch_timestamps = [cache.get_fetch_timestamp() for _ in range(10)]
        await asyncio.sleep(0.001)
        await cache.invalidate(user_id)

        async def stale_writer(idx: int):
            plan = create_test_plan(f"stale_{idx}")
            user_plan = create_test_user_plan(user_id=user_id)
            return await cache.set(
                user_id, user_plan, plan, fetched_at=fetch_timestamps[idx]
            )

        results = await asyncio.gather(*[stale_writer(i) for i in range(10)])

        # ALL should be rejected
        assert all(r is False for r in results), (
            f"Some stale writes were accepted: {results}"
        )
        assert await cache.get(user_id) is None


class TestWriteLockAtomicity:
    """Test that _write_lock ensures atomicity of check-and-write."""

    async def test_lock_free_get_not_blocked_by_write(self):
        """Lock-free gets should not be blocked by write operations."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_id = uuid4()
        plan = create_test_plan("pro")
        user_plan = create_test_user_plan(user_id=user_id)
        await cache.set(user_id, user_plan, plan)

        read_count = 0

        async def slow_writer():
            async with cache._write_lock:
                await asyncio.sleep(0.5)

        async def fast_reader():
            nonlocal read_count
            start = datetime.now(UTC)
            for _ in range(100):
                await cache.get(user_id)
                read_count += 1
            elapsed = (datetime.now(UTC) - start).total_seconds()
            return elapsed

        writer_task = asyncio.create_task(slow_writer())
        await asyncio.sleep(0.1)

        reader_times = await asyncio.gather(*[fast_reader() for _ in range(5)])

        await writer_task

        for elapsed in reader_times:
            assert elapsed < 0.4, (
                f"Reader took {elapsed:.2f}s, likely blocked by write lock"
            )

    async def test_concurrent_set_and_invalidate_serialized(self):
        """set() and invalidate() are serialized through the write lock."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_id = uuid4()
        operations_order: list[str] = []

        original_set = cache.set
        original_invalidate = cache.invalidate

        async def tracked_set(*args, **kwargs):
            result = await original_set(*args, **kwargs)
            operations_order.append("set")
            return result

        async def tracked_invalidate(*args, **kwargs):
            await original_invalidate(*args, **kwargs)
            operations_order.append("invalidate")

        cache.set = tracked_set  # type: ignore[assignment]
        cache.invalidate = tracked_invalidate  # type: ignore[assignment]

        async def writer():
            for i in range(20):
                plan = create_test_plan(f"plan_{i}")
                user_plan = create_test_user_plan(user_id=user_id)
                await cache.set(user_id, user_plan, plan)

        async def invalidator():
            for _ in range(20):
                await cache.invalidate(user_id)

        await asyncio.gather(writer(), invalidator())

        # Should have exactly 40 operations (no crashes or missed ops)
        assert len(operations_order) == 40


class TestHighContention:
    """Test behavior under high contention scenarios."""

    async def test_high_contention_mixed_operations(self):
        """High volume mixed operations complete without deadlock."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        user_ids = [uuid4() for _ in range(20)]
        completed = {"sets": 0, "gets": 0, "invalidates": 0}

        async def setter():
            for i in range(100):
                uid = user_ids[i % 20]
                plan = create_test_plan(f"plan_{i % 20}")
                user_plan = create_test_user_plan(user_id=uid)
                await cache.set(uid, user_plan, plan)
                completed["sets"] += 1

        async def getter():
            for i in range(200):
                await cache.get(user_ids[i % 20])
                completed["gets"] += 1

        async def invalidator():
            for i in range(50):
                await cache.invalidate(user_ids[i % 20])
                completed["invalidates"] += 1
                await asyncio.sleep(0.001)

        try:
            await asyncio.wait_for(
                asyncio.gather(
                    setter(), setter(),
                    getter(), getter(),
                    invalidator(),
                ),
                timeout=10.0,
            )
        except asyncio.TimeoutError:
            pytest.fail(f"Deadlock detected! Completed: {completed}")

        assert completed["sets"] == 200
        assert completed["gets"] == 400
        assert completed["invalidates"] == 50

    async def test_size_during_concurrent_writes(self):
        """Size property returns consistent values during writes."""
        cache = InMemoryUserPlanCache(ttl_seconds=300)
        sizes_seen: list[int] = []

        async def writer():
            for i in range(100):
                uid = uuid4()
                plan = create_test_plan(f"plan_{i}")
                user_plan = create_test_user_plan(user_id=uid)
                await cache.set(uid, user_plan, plan)
                await asyncio.sleep(0)

        async def reader():
            for _ in range(200):
                sizes_seen.append(cache.size)
                await asyncio.sleep(0)

        await asyncio.gather(writer(), reader())

        assert all(isinstance(s, int) for s in sizes_seen)
        assert all(s >= 0 for s in sizes_seen)


class TestCleanupConcurrency:
    """Test cleanup operations under concurrency."""

    async def test_cleanup_during_access(self):
        """Cleanup during access operations is safe."""
        cache = InMemoryUserPlanCache(ttl_seconds=1)
        user_ids = [uuid4() for _ in range(50)]

        for uid in user_ids:
            plan = create_test_plan("plan")
            user_plan = create_test_user_plan(user_id=uid)
            await cache.set(uid, user_plan, plan)

        await asyncio.sleep(1.1)

        fresh_user_ids = [uuid4() for _ in range(50)]
        for uid in fresh_user_ids:
            plan = create_test_plan("plan")
            user_plan = create_test_user_plan(user_id=uid)
            await cache.set(uid, user_plan, plan)

        errors = []

        async def reader():
            all_ids = user_ids + fresh_user_ids
            for i in range(200):
                try:
                    await cache.get(all_ids[i % 100])
                except Exception as e:
                    errors.append(str(e))
                await asyncio.sleep(0)

        async def cleaner():
            for _ in range(5):
                try:
                    await cache.cleanup_expired()
                except Exception as e:
                    errors.append(f"Cleanup error: {e}")
                await asyncio.sleep(0.01)

        await asyncio.gather(reader(), reader(), cleaner())

        assert len(errors) == 0, f"Errors: {errors}"
