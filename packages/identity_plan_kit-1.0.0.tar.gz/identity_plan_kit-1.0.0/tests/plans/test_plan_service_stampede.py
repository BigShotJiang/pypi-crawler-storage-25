"""Tests for PlanService stampede protection and cache efficiency.

Tests cover:
- P1 #5: get_plan() stampede protection (per-key locking reduces concurrent misses to 1 DB query)
- P2 #8: Query count assertions (cache hits avoid DB queries entirely)

CRITICAL: These tests verify that the per-key locking in PlanService prevents
cache stampede, and that cached lookups never touch the database.
"""

import asyncio
from datetime import date, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.cache.plan_cache import InMemoryPlanCache, PlanCache
from identity_plan_kit.plans.cache.user_plan_cache import InMemoryUserPlanCache
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.services.plan_service import PlanService

pytestmark = pytest.mark.anyio


TEST_USER_ID = UUID("12345678-1234-1234-1234-123456789012")


def _make_plan(code: str = "pro") -> Plan:
    plan_id = uuid4()
    return Plan(
        id=plan_id,
        code=code,
        name=f"{code.title()} Plan",
        permissions={"read:data"},
        limits={
            "api_calls": PlanLimit(
                id=uuid4(),
                plan_id=plan_id,
                feature_id=uuid4(),
                feature_code="api_calls",
                limit=100,
                period=PeriodType.DAILY,
            ),
        },
    )


def _make_user_plan(user_id=TEST_USER_ID, plan_code: str = "free") -> UserPlan:
    return UserPlan(
        id=uuid4(),
        user_id=user_id,
        plan_id=uuid4(),
        plan_code=plan_code,
        started_at=date.today() - timedelta(days=10),
        ends_at=date.today() + timedelta(days=20),
        custom_limits={},
    )


class TestGetPlanStampedeProtection:
    """P1 #5: Test that get_plan() has stampede protection.

    When multiple concurrent requests miss the cache for the same plan_code,
    only ONE should query the database. Others wait on the per-key lock
    and find the cached result.
    """

    async def test_concurrent_get_plan_single_db_query(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """10 concurrent get_plan() calls for same plan_code → 1 DB query."""
        db_query_count = 0
        plan = _make_plan("pro")

        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            plan_cache_ttl_seconds=60,
        )

        # Replace cache with real in-memory cache
        cache = PlanCache(ttl_seconds=60)
        service._plan_cache = cache

        async def mock_get_plan_by_code(code):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.05)  # Simulate DB latency
            return plan

        mock_uow = AsyncMock()
        mock_uow.plans.get_plan_by_code = AsyncMock(side_effect=mock_get_plan_by_code)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(
                *[service.get_plan("pro") for _ in range(10)]
            )

        # All should return valid plans
        assert all(r is not None for r in results)
        assert all(r.code == "pro" for r in results)

        # CRITICAL: Only 1 DB query due to stampede protection
        assert db_query_count == 1, (
            f"Expected 1 DB query (stampede protection), got {db_query_count}. "
            f"Per-key locking is not preventing cache stampede!"
        )

    async def test_different_plan_codes_query_independently(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Different plan_codes should each trigger their own DB query."""
        db_query_count = 0
        plans = {code: _make_plan(code) for code in ["free", "pro", "enterprise"]}

        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            plan_cache_ttl_seconds=60,
        )
        cache = PlanCache(ttl_seconds=60)
        service._plan_cache = cache

        async def mock_get_plan_by_code(code):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.02)
            return plans[code]

        mock_uow = AsyncMock()
        mock_uow.plans.get_plan_by_code = AsyncMock(side_effect=mock_get_plan_by_code)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(
                service.get_plan("free"),
                service.get_plan("pro"),
                service.get_plan("enterprise"),
            )

        assert len(results) == 3
        assert db_query_count == 3  # One per unique plan code

    async def test_stampede_protection_with_mixed_plan_codes(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Mixed plan codes: each unique code gets 1 query, duplicates share."""
        db_queries: dict[str, int] = {}
        plans = {code: _make_plan(code) for code in ["free", "pro"]}

        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            plan_cache_ttl_seconds=60,
        )
        cache = PlanCache(ttl_seconds=60)
        service._plan_cache = cache

        async def mock_get_plan_by_code(code):
            db_queries[code] = db_queries.get(code, 0) + 1
            await asyncio.sleep(0.05)
            return plans[code]

        mock_uow = AsyncMock()
        mock_uow.plans.get_plan_by_code = AsyncMock(side_effect=mock_get_plan_by_code)
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # 5 requests for "free", 5 for "pro"
            tasks = (
                [service.get_plan("free") for _ in range(5)]
                + [service.get_plan("pro") for _ in range(5)]
            )
            results = await asyncio.gather(*tasks)

        assert all(r is not None for r in results)
        # Each plan code should have exactly 1 DB query
        assert db_queries.get("free", 0) == 1, f"free queries: {db_queries.get('free', 0)}"
        assert db_queries.get("pro", 0) == 1, f"pro queries: {db_queries.get('pro', 0)}"


class TestCacheHitQueryCount:
    """P2 #8: Verify cache hits avoid DB queries entirely."""

    async def test_get_plan_cache_hit_zero_queries(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """get_plan() with warm cache should make 0 DB queries."""
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            plan_cache_ttl_seconds=60,
        )

        # Pre-populate cache
        plan = _make_plan("pro")
        cache = PlanCache(ttl_seconds=60)
        await cache.set("pro", plan)
        service._plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_plan_by_code = AsyncMock()

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.get_plan("pro")

        assert result.code == "pro"
        # DB should NOT be called
        mock_uow.plans.get_plan_by_code.assert_not_called()

    async def test_get_user_plan_with_details_cache_hit_zero_queries(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """get_user_plan_with_details() with warm cache → 0 DB queries."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        plan = _make_plan("pro")
        user_plan = _make_user_plan(user_id=user_id, plan_code="pro")

        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, user_plan, plan)
        service._user_plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock()

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.get_user_plan_with_details(user_id)

        assert result is not None
        up, p = result
        assert p.code == "pro"
        # DB should NOT be called
        mock_uow.plans.get_user_active_plan_with_details.assert_not_called()

    async def test_check_feature_access_cache_hit_zero_queries(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """check_feature_access() with warm user plan cache → 0 DB queries."""
        user_id = uuid4()
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        plan = _make_plan("pro")
        user_plan = _make_user_plan(user_id=user_id, plan_code="pro")

        cache = InMemoryUserPlanCache(ttl_seconds=60)
        await cache.set(user_id, user_plan, plan)
        service._user_plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock()

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.check_feature_access(user_id, "api_calls")

        assert result is True
        # DB should NOT be called
        mock_uow.plans.get_user_active_plan_with_details.assert_not_called()

    async def test_concurrent_cache_hits_zero_queries(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """50 concurrent get_plan() with warm cache → 0 DB queries."""
        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            plan_cache_ttl_seconds=60,
        )

        plan = _make_plan("pro")
        cache = PlanCache(ttl_seconds=60)
        await cache.set("pro", plan)
        service._plan_cache = cache

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_plan_by_code = AsyncMock()

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(
                *[service.get_plan("pro") for _ in range(50)]
            )

        assert all(r.code == "pro" for r in results)
        mock_uow.plans.get_plan_by_code.assert_not_called()
