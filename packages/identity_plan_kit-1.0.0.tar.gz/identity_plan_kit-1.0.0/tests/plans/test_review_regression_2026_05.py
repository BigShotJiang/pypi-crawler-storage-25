"""Regression tests for the 2026-05 plans-module review fixes.

Each test below exists to lock in a specific bug fix so it cannot silently
regress. The original review report and fix order is summarised in the
top-level commit message and project memory; the test names mirror that
report so failures are self-documenting.
"""

import asyncio
from collections import OrderedDict
from datetime import date, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.cache.exceptions import RedisRequiredError
from identity_plan_kit.plans.cache.user_plan_cache import (
    InMemoryUserPlanCache,
    UserPlanCacheEntry,
)
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.domain.exceptions import (
    ForeignKeyViolationError,
    PlanAssignmentError,
    PlanExpiredError,
    QuotaExceededError,
)
from identity_plan_kit.plans.repositories.plan_repo import PlanRepository
from identity_plan_kit.plans.repositories.usage_repo import (
    QuotaExceededInRepoError,
    UsageRepository,
)
from identity_plan_kit.plans.services.plan_service import (
    MAX_FETCH_LOCKS,
    PlanService,
)
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.state_store import InMemoryStateStore, StateStoreManager

pytestmark = pytest.mark.anyio


# ---------------------------------------------------------------------------
# Finding 1: idempotency state-store write must happen AFTER UoW commit
# ---------------------------------------------------------------------------


class TestIdempotencyWrittenAfterUowCommit:
    async def test_state_store_set_called_after_uow_exit(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
        mock_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """Regression: phantom-idempotency on commit failure.

        Original bug: state_store.set was inside ``async with uow``. If the
        UoW commit later failed, retries would see a cached UsageInfo even
        though quota had not been consumed.
        """
        order: list[str] = []

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(side_effect=lambda: (order.append("uow_enter"), mock_uow)[1])

        async def _aexit(*args: object, **kwargs: object) -> None:
            order.append("uow_exit")

        mock_uow.__aexit__ = AsyncMock(side_effect=_aexit)
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            return_value=(mock_user_plan, mock_plan)
        )
        mock_uow.usage.atomic_check_and_consume = AsyncMock(return_value=1)

        store = InMemoryStateStore()
        await store.start()
        manager = StateStoreManager()
        manager._store = store  # type: ignore[attr-defined]
        manager._initialized = True  # type: ignore[attr-defined]

        async def _tracked_set(*args: object, **kwargs: object) -> None:
            order.append("state_store_set")
            await store.set(*args, **kwargs)  # type: ignore[arg-type]

        tracked_store = MagicMock(wraps=store)
        tracked_store.set = AsyncMock(side_effect=_tracked_set)
        manager._store = tracked_store  # type: ignore[attr-defined]

        service = PlanService(
            mock_config,
            MagicMock(),
            state_store_manager=manager,
        )

        with patch.object(service, "_create_uow", return_value=mock_uow):
            await service.check_and_consume_quota(
                user_id=mock_user.id,
                feature_code="api_calls",
                amount=1,
                idempotency_key="key-1",
            )

        await store.stop()

        # The state_store.set call MUST come strictly after uow_exit.
        assert "uow_exit" in order, "UoW context never closed"
        assert "state_store_set" in order, "Idempotency cache was not written"
        assert order.index("state_store_set") > order.index(
            "uow_exit"
        ), f"state_store.set ran before UoW commit: {order}"


# ---------------------------------------------------------------------------
# Finding 2: get_usage_info must raise PlanExpiredError on cached expired plan
# ---------------------------------------------------------------------------


class TestGetUsageInfoExpiredFromCache:
    async def test_cached_expired_plan_raises_and_invalidates(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
        mock_expired_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """Regression: expired plans served from cache returned stale usage."""
        service = PlanService(mock_config, MagicMock())

        # Seed the in-memory user-plan cache with an expired entry directly.
        await service._user_plan_cache.set(
            mock_user.id,
            mock_expired_user_plan,
            mock_plan,
        )

        # Sanity check: cache hit before the call.
        cached = await service._user_plan_cache.get(mock_user.id)
        assert cached is not None

        # No UoW should ever be reached because we error out before DB usage
        # query — but if the implementation did fall through, the mock would
        # fail loudly.
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.usage.get_current_usage = AsyncMock(
            side_effect=AssertionError(
                "get_current_usage must not be reached for expired plans"
            )
        )

        with patch.object(service, "_create_uow", return_value=mock_uow):
            with pytest.raises(PlanExpiredError):
                await service.get_usage_info(mock_user.id, "api_calls")

        # Cache must have been invalidated.
        assert await service._user_plan_cache.get(mock_user.id) is None


# ---------------------------------------------------------------------------
# Finding 3: fast-fail QuotaExceededInRepoError must report real usage
# ---------------------------------------------------------------------------


class TestQuotaExceededFastFailUsesRealUsage:
    async def test_fast_fail_fetches_current_usage_for_error(self) -> None:
        """Regression: fast-fail used current_usage=0 producing wrong client errors."""
        # Build a mock session whose first execute() (the get_current_usage
        # SELECT inside the fast-fail branch) returns 50.
        mock_session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none = MagicMock(return_value=50)
        mock_session.execute = AsyncMock(return_value=mock_result)

        repo = UsageRepository(mock_session)

        with pytest.raises(QuotaExceededInRepoError) as exc_info:
            await repo.atomic_check_and_consume(
                user_plan_id=uuid4(),
                feature_id=uuid4(),
                amount=150,  # > limit triggers fast-fail
                limit=100,
                period=PeriodType.DAILY,
            )

        # Real current_usage propagates, not the old hardcoded 0.
        assert exc_info.value.current_usage == 50
        assert exc_info.value.limit == 100
        assert exc_info.value.requested == 150


# ---------------------------------------------------------------------------
# Finding 4: plan cache TTL must source from IdentityPlanKitConfig by default
# ---------------------------------------------------------------------------


class TestPlanCacheTTLFromConfig:
    def test_cache_ttl_defaults_to_config_value(self) -> None:
        """Regression: hardcoded 300s ignored config.plan_cache_ttl_seconds."""
        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost:5432/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="x",
            google_client_secret="y",
            google_redirect_uri="http://localhost/cb",
            plan_cache_ttl_seconds=42,
        )

        service = PlanService(config, MagicMock())

        # Both caches end up wrapping the in-memory backend at TTL=42.
        plan_backend = service._plan_cache._backend  # type: ignore[attr-defined]
        user_plan_backend = service._user_plan_cache._backend  # type: ignore[attr-defined]
        assert plan_backend._ttl_seconds == 42  # type: ignore[attr-defined]
        assert user_plan_backend._ttl_seconds == 42  # type: ignore[attr-defined]

    def test_cache_disabled_when_config_ttl_zero(self) -> None:
        """Regression: IPK_PLAN_CACHE_TTL_SECONDS=0 must actually disable cache."""
        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost:5432/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="x",
            google_client_secret="y",
            google_redirect_uri="http://localhost/cb",
            plan_cache_ttl_seconds=0,
        )

        service = PlanService(config, MagicMock())
        plan_backend = service._plan_cache._backend  # type: ignore[attr-defined]
        user_plan_backend = service._user_plan_cache._backend  # type: ignore[attr-defined]
        assert plan_backend._enabled is False  # type: ignore[attr-defined]
        assert user_plan_backend._enabled is False  # type: ignore[attr-defined]

    def test_explicit_constructor_override_still_works(self) -> None:
        """Backwards-compat: callers can still override TTL explicitly."""
        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost:5432/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="x",
            google_client_secret="y",
            google_redirect_uri="http://localhost/cb",
            plan_cache_ttl_seconds=600,
        )

        service = PlanService(
            config,
            MagicMock(),
            plan_cache_ttl_seconds=10,
            user_plan_cache_ttl_seconds=20,
        )
        plan_backend = service._plan_cache._backend  # type: ignore[attr-defined]
        user_plan_backend = service._user_plan_cache._backend  # type: ignore[attr-defined]
        assert plan_backend._ttl_seconds == 10  # type: ignore[attr-defined]
        assert user_plan_backend._ttl_seconds == 20  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Finding 5: FK violation classification must use constraint names only
# ---------------------------------------------------------------------------


class _FakeNestedTxn:
    """Minimal async-context-manager that re-raises whatever flush() raises."""

    async def __aenter__(self) -> "_FakeNestedTxn":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> bool:
        return False  # never swallow


def _make_integrity_error(message: str) -> IntegrityError:
    """Build an IntegrityError whose ``.orig`` stringifies to ``message``."""
    orig = Exception(message)
    return IntegrityError("stmt", {}, orig)


class TestFKClassificationStrict:
    async def _run_create(self, message: str) -> None:
        mock_session = AsyncMock()
        mock_session.begin_nested = MagicMock(return_value=_FakeNestedTxn())
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock(side_effect=_make_integrity_error(message))

        repo = PlanRepository(mock_session)
        await repo.create_user_plan(user_id=uuid4(), plan_id=uuid4())

    async def test_user_fk_constraint_classified_as_user_id(self) -> None:
        """Real FK violation on user_plans_user_id_fkey -> user_id constraint."""
        with pytest.raises(ForeignKeyViolationError) as exc_info:
            await self._run_create(
                'insert violates foreign key constraint "user_plans_user_id_fkey"'
            )
        assert exc_info.value.constraint_name == "user_id"

    async def test_plan_fk_constraint_classified_as_plan_id(self) -> None:
        with pytest.raises(ForeignKeyViolationError) as exc_info:
            await self._run_create(
                'insert violates foreign key constraint "user_plans_plan_id_fkey"'
            )
        assert exc_info.value.constraint_name == "plan_id"

    async def test_unrelated_constraint_with_users_substring_not_misclassified(
        self,
    ) -> None:
        """Regression: a CHECK constraint mentioning the word "users"
        must NOT be mistaken for a user_id FK violation."""
        with pytest.raises(PlanAssignmentError):
            await self._run_create(
                'new row violates check constraint "ck_max_users_per_org"'
            )

    async def test_unrelated_constraint_with_plans_substring_not_misclassified(
        self,
    ) -> None:
        with pytest.raises(PlanAssignmentError):
            await self._run_create(
                'duplicate key value violates unique constraint "uq_billing_plans_lookup"'
            )


# ---------------------------------------------------------------------------
# Finding 6: per-key fetch lock dicts must be LRU-bounded
# ---------------------------------------------------------------------------


class TestFetchLockDictsBounded:
    async def test_user_plan_fetch_locks_bounded(
        self, mock_config: IdentityPlanKitConfig
    ) -> None:
        service = PlanService(mock_config, MagicMock())
        # Simulate insertion of MAX_FETCH_LOCKS + 50 unique users by
        # exercising the same allocation block used at runtime.
        for _ in range(MAX_FETCH_LOCKS + 50):
            uid = uuid4()
            async with service._user_plan_fetch_locks_lock:
                if uid in service._user_plan_fetch_locks:
                    service._user_plan_fetch_locks.move_to_end(uid)
                else:
                    service._user_plan_fetch_locks[uid] = asyncio.Lock()
                    if len(service._user_plan_fetch_locks) > MAX_FETCH_LOCKS:
                        service._user_plan_fetch_locks.popitem(last=False)

        assert len(service._user_plan_fetch_locks) <= MAX_FETCH_LOCKS
        assert isinstance(service._user_plan_fetch_locks, OrderedDict)

    async def test_plan_fetch_locks_bounded(
        self, mock_config: IdentityPlanKitConfig
    ) -> None:
        service = PlanService(mock_config, MagicMock())
        for i in range(MAX_FETCH_LOCKS + 50):
            code = f"plan-{i}"
            async with service._fetch_locks_lock:
                if code in service._fetch_locks:
                    service._fetch_locks.move_to_end(code)
                else:
                    service._fetch_locks[code] = asyncio.Lock()
                    if len(service._fetch_locks) > MAX_FETCH_LOCKS:
                        service._fetch_locks.popitem(last=False)

        assert len(service._fetch_locks) <= MAX_FETCH_LOCKS
        assert isinstance(service._fetch_locks, OrderedDict)


# ---------------------------------------------------------------------------
# Finding 7: PlanAssignmentError must not leak raw DB error text (CWE-209)
# ---------------------------------------------------------------------------


class TestPlanAssignmentErrorMessageGeneric:
    async def test_message_does_not_contain_db_internals(self) -> None:
        mock_session = AsyncMock()
        mock_session.begin_nested = MagicMock(return_value=_FakeNestedTxn())
        mock_session.add = MagicMock()
        leaked_detail = (
            'duplicate key value violates unique constraint "uq_secret_internal_xyz"'
        )
        mock_session.flush = AsyncMock(
            side_effect=_make_integrity_error(leaked_detail)
        )

        repo = PlanRepository(mock_session)
        with pytest.raises(PlanAssignmentError) as exc_info:
            await repo.create_user_plan(user_id=uuid4(), plan_id=uuid4())

        # The DB-internal constraint name MUST NOT appear in the user-facing
        # message; details still get logged internally.
        assert "uq_secret_internal_xyz" not in exc_info.value.message
        assert "duplicate key" not in exc_info.value.message


# ---------------------------------------------------------------------------
# Finding 8 + 9: cache + repo signal exceptions must inherit BaseError
# ---------------------------------------------------------------------------


class TestExceptionsInheritBaseError:
    def test_redis_required_error_is_base_error(self) -> None:
        assert issubclass(RedisRequiredError, BaseError)
        # Has the project-mandated metadata for HTTP mapping.
        assert RedisRequiredError.code == "REDIS_REQUIRED"
        assert RedisRequiredError.status_code == 503

    def test_quota_exceeded_in_repo_error_is_base_error(self) -> None:
        assert issubclass(QuotaExceededInRepoError, BaseError)
        err = QuotaExceededInRepoError(current_usage=10, limit=20, requested=15)
        assert isinstance(err, BaseError)
        assert err.current_usage == 10
        assert err.limit == 20
        assert err.requested == 15


# ---------------------------------------------------------------------------
# Finding 10: rename of the shadowed `result` variable — behavior preserved
# ---------------------------------------------------------------------------


class TestCheckAndConsumeQuotaReturnsUsageInfo:
    async def test_returns_correct_usage_info(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
        mock_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """Regression sentinel for the variable rename: same behavior, no
        accidental tuple/UsageInfo confusion in the hot path."""
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            return_value=(mock_user_plan, mock_plan)
        )
        mock_uow.usage.atomic_check_and_consume = AsyncMock(return_value=7)

        service = PlanService(mock_config, MagicMock())
        with patch.object(service, "_create_uow", return_value=mock_uow):
            usage = await service.check_and_consume_quota(
                user_id=mock_user.id,
                feature_code="api_calls",
                amount=1,
            )

        assert usage.feature_code == "api_calls"
        assert usage.used == 7
        assert usage.limit == 100
        assert usage.remaining == 93


# ---------------------------------------------------------------------------
# Finding 11: InMemoryUserPlanCache LRU eviction
# ---------------------------------------------------------------------------


class TestInMemoryUserPlanCacheLRUEviction:
    async def test_eviction_drops_oldest_entry(self) -> None:
        cache = InMemoryUserPlanCache(ttl_seconds=300, max_entries=3)

        ids = [uuid4() for _ in range(5)]
        plan = Plan(
            id=1,
            code="free",
            name="Free",
            permissions=set(),
            limits={},
        )

        for i, uid in enumerate(ids):
            up = UserPlan(
                id=i + 1,
                user_id=uid,
                plan_id=1,
                plan_code="free",
                started_at=date.today(),
                ends_at=date.today() + timedelta(days=30),
                custom_limits={},
            )
            await cache.set(uid, up, plan)

        # Only the last 3 IDs should remain; the first 2 are evicted.
        assert cache.size == 3
        assert await cache.get(ids[0]) is None
        assert await cache.get(ids[1]) is None
        for uid in ids[2:]:
            assert await cache.get(uid) is not None

    async def test_invalidate_dict_also_bounded(self) -> None:
        cache = InMemoryUserPlanCache(ttl_seconds=300, max_entries=3)
        for _ in range(10):
            await cache.invalidate(uuid4())

        # The invalidation-timestamp dict must respect the same bound.
        assert len(cache._invalidated_at) <= 3  # type: ignore[attr-defined]
