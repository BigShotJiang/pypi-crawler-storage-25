"""Test circuit breaker behavior for RedisPlanCache.

This test suite verifies that circuit breaker thresholds work correctly
after fixing the retry failure counting issue (C2).
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from identity_plan_kit.plans.cache.plan_cache import CacheCircuitState, RedisPlanCache
from identity_plan_kit.shared.constants import REDIS_CIRCUIT_FAILURE_THRESHOLD


# Mock Redis exceptions
class MockConnectionError(Exception):
    """Mock redis.ConnectionError."""

    pass


class MockTimeoutError(Exception):
    """Mock redis.TimeoutError."""

    pass


@pytest.fixture(autouse=True)
def mock_redis_module():
    """Mock redis module and its exceptions."""
    redis_module = MagicMock()
    redis_module.ConnectionError = MockConnectionError
    redis_module.TimeoutError = MockTimeoutError
    with patch.dict("sys.modules", {"redis.asyncio": redis_module, "redis": redis_module}):
        with patch("identity_plan_kit.plans.cache.plan_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.plans.cache.plan_cache.redis", redis_module):
                yield redis_module


@pytest.fixture
def mock_redis_client():
    """Create a mock Redis client."""
    client = AsyncMock()
    return client


@pytest.fixture
def redis_cache(mock_redis_client):
    """Create a RedisPlanCache instance with mocked Redis client."""
    cache = RedisPlanCache(
        redis_url="redis://localhost:6379/0",
        ttl_seconds=300,
    )
    cache._client = mock_redis_client
    return cache


class TestCircuitBreakerThresholds:
    """Test that circuit breaker thresholds work correctly."""

    @pytest.mark.asyncio
    async def test_single_operation_with_retries_counts_as_one_failure(self, redis_cache, mock_redis_client):
        """Test that an operation with 3 retry attempts counts as 1 failure, not 3."""
        # Make Redis operation fail on all attempts
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")

        # Execute one operation that will retry 3 times
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "test_key")

        # Should return None after retries exhausted
        assert result is None

        # Verify the operation was attempted 3 times (initial + 2 retries)
        assert mock_redis_client.get.call_count == 3

        # Circuit breaker should have recorded exactly 1 failure
        assert redis_cache._circuit_failures == 1
        assert redis_cache._circuit_state == CacheCircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_circuit_opens_after_threshold_operations_not_attempts(self, redis_cache, mock_redis_client):
        """Test that circuit opens after 5 failed operations (not 5 failed attempts).

        With REDIS_RETRY_ATTEMPTS=3 and CIRCUIT_FAILURE_THRESHOLD=5:
        - Old behavior: 2 operations × 3 attempts each = 6 failures → circuit opens
        - New behavior: 5 operations × 3 attempts each = 5 failures → circuit opens

        This test verifies the new behavior.
        """
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")

        # Execute 4 operations - circuit should remain CLOSED
        for i in range(4):
            result = await redis_cache._execute_with_retry("get", mock_redis_client.get, f"key_{i}")
            assert result is None
            assert redis_cache._circuit_state == CacheCircuitState.CLOSED, f"Circuit opened prematurely after {i + 1} operations"
            assert redis_cache._circuit_failures == i + 1

        # The 5th operation should open the circuit
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "key_5")
        assert result is None
        assert redis_cache._circuit_state == CacheCircuitState.OPEN
        assert redis_cache._circuit_failures == REDIS_CIRCUIT_FAILURE_THRESHOLD

        # Total Redis attempts should be 5 operations × 3 attempts = 15
        assert mock_redis_client.get.call_count == 15

    @pytest.mark.asyncio
    async def test_successful_operation_records_no_failure(self, redis_cache, mock_redis_client):
        """Test that successful operations don't increment failure counter."""
        mock_redis_client.get.return_value = b'{"plan": "data"}'

        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "test_key")

        assert result == b'{"plan": "data"}'
        assert redis_cache._circuit_failures == 0
        assert redis_cache._circuit_successes == 1
        assert redis_cache._circuit_state == CacheCircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_mixed_success_and_failure_operations(self, redis_cache, mock_redis_client):
        """Test circuit breaker with mixed success/failure operations."""
        # 2 failures
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")
        for i in range(2):
            result = await redis_cache._execute_with_retry("get", mock_redis_client.get, f"key_{i}")
            assert result is None

        assert redis_cache._circuit_failures == 2

        # 1 success
        mock_redis_client.get.side_effect = None
        mock_redis_client.get.return_value = b'{"plan": "data"}'
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "success_key")
        assert result is not None

        # Failures should still be 2 (not reset in CLOSED state - that's a known issue H5)
        assert redis_cache._circuit_failures == 2

        # 3 more failures should open the circuit (total 5)
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")
        for i in range(3):
            result = await redis_cache._execute_with_retry("get", mock_redis_client.get, f"key_{i + 2}")
            assert result is None

        assert redis_cache._circuit_state == CacheCircuitState.OPEN
        assert redis_cache._circuit_failures == 5

    @pytest.mark.asyncio
    async def test_operation_with_partial_success(self, redis_cache, mock_redis_client):
        """Test operation that fails on first 2 attempts then succeeds on 3rd."""
        # Fail twice, then succeed
        mock_redis_client.get.side_effect = [
            MockConnectionError("Fail 1"),
            MockConnectionError("Fail 2"),
            b'{"plan": "data"}',  # Success on 3rd attempt
        ]

        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "test_key")

        # Should return the successful result
        assert result == b'{"plan": "data"}'

        # Should record as a success, not a failure
        assert redis_cache._circuit_failures == 0
        assert redis_cache._circuit_successes == 1
        assert redis_cache._circuit_state == CacheCircuitState.CLOSED

        # Should have made 3 attempts
        assert mock_redis_client.get.call_count == 3


class TestCircuitBreakerStates:
    """Test circuit breaker state transitions."""

    @pytest.mark.asyncio
    async def test_circuit_opens_and_rejects_operations(self, redis_cache, mock_redis_client):
        """Test that opened circuit rejects operations without calling Redis."""
        # Force circuit to open by causing 5 failures
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")
        for i in range(5):
            await redis_cache._execute_with_retry("get", mock_redis_client.get, f"key_{i}")

        assert redis_cache._circuit_state == CacheCircuitState.OPEN

        # Reset call count
        mock_redis_client.get.reset_mock()

        # Next operation should be rejected without calling Redis
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "rejected_key")
        assert result is None
        assert mock_redis_client.get.call_count == 0  # Redis was not called

    @pytest.mark.asyncio
    async def test_circuit_transitions_to_half_open(self, redis_cache, mock_redis_client):
        """Test that circuit transitions to HALF_OPEN after recovery timeout."""
        from datetime import UTC, datetime, timedelta

        # Force circuit to open
        mock_redis_client.get.side_effect = MockConnectionError("Connection failed")
        for i in range(5):
            await redis_cache._execute_with_retry("get", mock_redis_client.get, f"key_{i}")

        assert redis_cache._circuit_state == CacheCircuitState.OPEN

        # Simulate recovery timeout passing
        redis_cache._circuit_opened_at = datetime.now(UTC) - timedelta(seconds=61)  # RECOVERY_TIMEOUT is 60s

        # Reset Redis to succeed
        mock_redis_client.get.side_effect = None
        mock_redis_client.get.return_value = b'{"plan": "data"}'

        # Check circuit should transition to HALF_OPEN
        is_open = await redis_cache._check_circuit()
        assert is_open is True
        assert redis_cache._circuit_state == CacheCircuitState.HALF_OPEN

    @pytest.mark.asyncio
    async def test_half_open_closes_after_successes(self, redis_cache, mock_redis_client):
        """Test that HALF_OPEN circuit closes after 2 consecutive successes."""
        # Force circuit to HALF_OPEN state
        redis_cache._circuit_state = CacheCircuitState.HALF_OPEN
        redis_cache._circuit_failures = 0
        redis_cache._circuit_successes = 0

        mock_redis_client.get.return_value = b'{"plan": "data"}'

        # First success
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "key_1")
        assert result is not None
        assert redis_cache._circuit_state == CacheCircuitState.HALF_OPEN  # Still half-open after 1 success

        # Second success should close the circuit
        result = await redis_cache._execute_with_retry("get", mock_redis_client.get, "key_2")
        assert result is not None
        assert redis_cache._circuit_state == CacheCircuitState.CLOSED
        assert redis_cache._circuit_failures == 0
