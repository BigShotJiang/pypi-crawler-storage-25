"""Tests for service-level cache invalidation ordering.

Tests cover:
- Cache invalidation happens AFTER UoW commit (not inside)
- Concurrent requests don't re-cache pre-commit (stale) data
- assign_plan, cancel_plan, extend_plan, update_plan_limits all follow correct ordering

CRITICAL: These tests validate the P1 fix where cache invalidation was moved
AFTER the `async with uow` block to prevent concurrent requests from re-caching
pre-commit data between the invalidation and the commit.
"""

import asyncio
from datetime import date, timedelta
from unittest.mock import AsyncMock, MagicMock, call, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.cache.user_plan_cache import InMemoryUserPlanCache
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.services.plan_service import PlanService

pytestmark = pytest.mark.anyio


# Test constants
TEST_USER_ID = UUID("12345678-1234-1234-1234-123456789012")
TEST_PLAN_ID = UUID("00000001-0000-0000-0000-000000000001")
TEST_PRO_PLAN_ID = UUID("00000002-0000-0000-0000-000000000002")


def _make_plan(code: str = "free", plan_id=TEST_PLAN_ID) -> Plan:
    return Plan(
        id=plan_id,
        code=code,
        name=f"{code.title()} Plan",
        permissions={"read:data"},
        limits={
            "api_calls": PlanLimit(
                id=uuid4(),
                plan_id=plan_id,
                feature_id=uuid4(),
                feature_code="api_calls",
                limit=100,
                period=PeriodType.DAILY,
            ),
        },
    )


def _make_user_plan(
    user_id=TEST_USER_ID,
    plan_code: str = "free",
    plan_id=TEST_PLAN_ID,
) -> UserPlan:
    return UserPlan(
        id=uuid4(),
        user_id=user_id,
        plan_id=plan_id,
        plan_code=plan_code,
        started_at=date.today() - timedelta(days=10),
        ends_at=date.today() + timedelta(days=20),
        custom_limits={},
    )


class TestAssignPlanCacheOrdering:
    """Verify assign_plan invalidates cache AFTER commit."""

    async def test_cache_invalidated_after_uow_exits(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Cache invalidation must happen after UoW __aexit__ (commit)."""
        call_order: list[str] = []

        # Mock UoW that tracks commit timing
        mock_uow = AsyncMock()
        mock_uow.plans.get_plan_by_code = AsyncMock(return_value=_make_plan("pro", TEST_PRO_PLAN_ID))
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=_make_user_plan())
        mock_uow.plans.expire_user_plan = AsyncMock()
        mock_uow.plans.create_user_plan = AsyncMock(
            return_value=_make_user_plan(plan_code="pro", plan_id=TEST_PRO_PLAN_ID)
        )

        async def track_aexit(*args, **kwargs):
            call_order.append("uow_commit")

        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(side_effect=track_aexit)

        # Mock cache that tracks invalidation timing
        mock_cache = AsyncMock(spec=InMemoryUserPlanCache)
        mock_cache.get = AsyncMock(return_value=None)
        mock_cache.get_fetch_timestamp = MagicMock(return_value=0.0)

        async def track_invalidate(*args, **kwargs):
            call_order.append("cache_invalidate")

        mock_cache.invalidate = AsyncMock(side_effect=track_invalidate)

        mock_session_factory = MagicMock()
        service = PlanService(mock_config, mock_session_factory)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            service._user_plan_cache = mock_cache
            await service.assign_plan(
                user_id=TEST_USER_ID,
                plan_code="pro",
                expire_current=True,
            )

        # CRITICAL: cache_invalidate must come AFTER uow_commit
        assert call_order == ["uow_commit", "cache_invalidate"], (
            f"Wrong ordering! Expected ['uow_commit', 'cache_invalidate'], "
            f"got {call_order}. Cache invalidation happened before commit!"
        )

    async def test_concurrent_read_during_assign_sees_fresh_data(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """
        Concurrent request should not re-cache stale pre-commit data.

        Scenario:
        1. Request A calls assign_plan → enters UoW, changes DB
        2. Request B calls get_user_plan_with_details → cache miss → fetches old data
        3. Request A commits → invalidates cache
        4. Request B tries to cache old data → must be rejected (stale write)
        """
        # Use real InMemoryUserPlanCache to test stale write prevention
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        user_id = uuid4()

        old_plan = _make_plan("free")
        old_user_plan = _make_user_plan(user_id=user_id, plan_code="free")

        # Pre-populate cache with old data
        await cache.set(user_id, old_user_plan, old_plan)

        # Simulate: Request B fetches before invalidation
        fetch_ts_before = cache.get_fetch_timestamp()

        await asyncio.sleep(0.001)

        # Simulate: Request A commits and invalidates
        await cache.invalidate(user_id)

        # Simulate: Request B tries to cache stale data
        result = await cache.set(
            user_id, old_user_plan, old_plan, fetched_at=fetch_ts_before
        )

        # Stale write must be rejected
        assert result is False
        assert await cache.get(user_id) is None


class TestCancelPlanCacheOrdering:
    """Verify cancel_plan invalidates cache AFTER commit."""

    async def test_cache_invalidated_after_uow_exits(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Cache invalidation must happen after UoW __aexit__ (commit)."""
        call_order: list[str] = []

        mock_uow = AsyncMock()
        mock_uow.plans.cancel_user_plan = AsyncMock(return_value=True)

        async def track_aexit(*args, **kwargs):
            call_order.append("uow_commit")

        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(side_effect=track_aexit)

        mock_cache = AsyncMock(spec=InMemoryUserPlanCache)

        async def track_invalidate(*args, **kwargs):
            call_order.append("cache_invalidate")

        mock_cache.invalidate = AsyncMock(side_effect=track_invalidate)

        mock_session_factory = MagicMock()
        service = PlanService(mock_config, mock_session_factory)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            service._user_plan_cache = mock_cache
            await service.cancel_plan(user_id=TEST_USER_ID, immediate=True)

        assert call_order == ["uow_commit", "cache_invalidate"], (
            f"Wrong ordering: {call_order}"
        )


class TestExtendPlanCacheOrdering:
    """Verify extend_plan invalidates cache AFTER commit."""

    async def test_cache_invalidated_after_uow_exits(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Cache invalidation must happen after UoW __aexit__ (commit)."""
        call_order: list[str] = []
        user_plan = _make_user_plan()

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=user_plan)
        mock_uow.plans.update_user_plan = AsyncMock(return_value=user_plan)

        async def track_aexit(*args, **kwargs):
            call_order.append("uow_commit")

        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(side_effect=track_aexit)

        mock_cache = AsyncMock(spec=InMemoryUserPlanCache)

        async def track_invalidate(*args, **kwargs):
            call_order.append("cache_invalidate")

        mock_cache.invalidate = AsyncMock(side_effect=track_invalidate)

        mock_session_factory = MagicMock()
        service = PlanService(mock_config, mock_session_factory)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            service._user_plan_cache = mock_cache
            await service.extend_plan(
                user_id=TEST_USER_ID,
                new_ends_at=date.today() + timedelta(days=60),
            )

        assert call_order == ["uow_commit", "cache_invalidate"], (
            f"Wrong ordering: {call_order}"
        )


class TestUpdatePlanLimitsCacheOrdering:
    """Verify update_plan_limits invalidates cache AFTER commit."""

    async def test_cache_invalidated_after_uow_exits(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Cache invalidation must happen after UoW __aexit__ (commit)."""
        call_order: list[str] = []
        user_plan = _make_user_plan()

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan = AsyncMock(return_value=user_plan)
        mock_uow.plans.update_user_plan = AsyncMock(return_value=user_plan)

        async def track_aexit(*args, **kwargs):
            call_order.append("uow_commit")

        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(side_effect=track_aexit)

        mock_cache = AsyncMock(spec=InMemoryUserPlanCache)

        async def track_invalidate(*args, **kwargs):
            call_order.append("cache_invalidate")

        mock_cache.invalidate = AsyncMock(side_effect=track_invalidate)

        mock_session_factory = MagicMock()
        service = PlanService(mock_config, mock_session_factory)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            service._user_plan_cache = mock_cache
            await service.update_plan_limits(
                user_id=TEST_USER_ID,
                custom_limits={"api_calls": 5000},
            )

        assert call_order == ["uow_commit", "cache_invalidate"], (
            f"Wrong ordering: {call_order}"
        )


class TestCacheStampedeProtection:
    """Test that get_user_plan_with_details has stampede protection."""

    async def test_concurrent_cache_miss_only_one_db_query(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """
        Multiple concurrent cache misses should result in only one DB query.

        Without stampede protection, N concurrent misses cause N DB queries.
        With per-key locking + double-check, only the first miss hits DB;
        the rest wait and find the cached result.
        """
        db_query_count = 0
        user_id = uuid4()
        plan = _make_plan("pro")
        user_plan = _make_user_plan(user_id=user_id, plan_code="pro")

        mock_session_factory = MagicMock()
        service = PlanService(
            mock_config,
            mock_session_factory,
            user_plan_cache_ttl_seconds=60,
        )

        # Replace cache with real one
        cache = InMemoryUserPlanCache(ttl_seconds=60)
        service._user_plan_cache = cache

        # Mock UoW that tracks query count
        async def mock_get_details(*args, **kwargs):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.05)  # Simulate DB latency
            return (user_plan, plan)

        mock_uow = AsyncMock()
        mock_uow.plans.get_user_active_plan_with_details = AsyncMock(
            side_effect=mock_get_details
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # Fire 10 concurrent requests
            results = await asyncio.gather(
                *[service.get_user_plan_with_details(user_id) for _ in range(10)]
            )

        # All should get results
        assert all(r is not None for r in results)

        # Only 1 DB query should have been made (stampede protection)
        assert db_query_count == 1, (
            f"Expected 1 DB query (stampede protection), got {db_query_count}. "
            f"Per-key locking with double-check is not working!"
        )
