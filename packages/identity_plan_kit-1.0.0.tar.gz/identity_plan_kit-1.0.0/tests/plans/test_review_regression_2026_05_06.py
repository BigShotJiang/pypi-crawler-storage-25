"""Regression tests for the 2026-05-06 plans-module review fixes.

Each test below pins a specific bug fix from the comprehensive review so it
cannot silently regress. Test names mirror the finding numbers in the review
report.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.plans.cache.user_plan_cache import RedisUserPlanCache
from identity_plan_kit.plans.domain.entities import (
    PeriodType,
    Plan,
    PlanLimit,
    UserPlan,
)
from identity_plan_kit.plans.domain.exceptions import (
    ForeignKeyViolationError,
    PlanAuthorizationError,
)
from identity_plan_kit.plans.models.feature import FeatureModel
from identity_plan_kit.plans.models.feature_usage import FeatureUsageModel
from identity_plan_kit.plans.models.plan import PlanModel
from identity_plan_kit.plans.models.plan_limit import PlanLimitModel
from identity_plan_kit.plans.models.plan_permission import PlanPermissionModel
from identity_plan_kit.plans.models.user_plan import UserPlanModel
from identity_plan_kit.plans.repositories.plan_repo import PlanRepository
from identity_plan_kit.plans.repositories.usage_repo import (
    QuotaExceededInRepoError,
    UsageRepository,
)
from identity_plan_kit.plans.services.plan_service import PlanService
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.models import BaseModel, TimestampMixin
from identity_plan_kit.shared.repository import BaseRepository

pytestmark = pytest.mark.anyio


# ---------------------------------------------------------------------------
# Finding P1 #1 + #3: RedisUserPlanCache.set must succeed and use Lua check
# ---------------------------------------------------------------------------


class TestRedisUserPlanCacheSet:
    """Originally `set()` returned False on every successful Redis call because
    the inner closure returned None. After the fix it must return True for
    Redis success and False only when the Lua timestamp check rejects the
    write or the cache is disabled.
    """

    @pytest.fixture
    def make_cache(self, mock_user_plan: UserPlan, mock_plan: Plan) -> Any:
        if "redis.asyncio" not in sys.modules:
            pytest.skip("redis not installed")

        def _make() -> tuple[RedisUserPlanCache, AsyncMock]:
            cache = RedisUserPlanCache(ttl_seconds=300)
            mock_client = AsyncMock()
            cache._client = mock_client  # type: ignore[assignment]
            return cache, mock_client

        return _make

    async def test_set_returns_true_on_redis_success(
        self,
        make_cache: Any,
        mock_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """Lua script returns 1 on a successful write; set() must surface True."""
        cache, mock_client = make_cache()
        mock_client.eval = AsyncMock(return_value=1)

        result = await cache.set(
            mock_user_plan.user_id,
            mock_user_plan,
            mock_plan,
        )

        assert result is True

    async def test_set_returns_false_when_lua_rejects_stale_write(
        self,
        make_cache: Any,
        mock_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """Lua returns 0 when fetched_at predates an invalidation timestamp."""
        cache, mock_client = make_cache()
        mock_client.eval = AsyncMock(return_value=0)

        result = await cache.set(
            mock_user_plan.user_id,
            mock_user_plan,
            mock_plan,
            fetched_at=1.0,
        )

        assert result is False

    async def test_set_uses_lua_with_three_keys(
        self,
        make_cache: Any,
        mock_user_plan: UserPlan,
        mock_plan: Plan,
    ) -> None:
        """The Lua call must pass key + global_inv_key + key_inv_key (3 keys)."""
        cache, mock_client = make_cache()
        mock_client.eval = AsyncMock(return_value=1)

        await cache.set(
            mock_user_plan.user_id,
            mock_user_plan,
            mock_plan,
            fetched_at=42.0,
        )

        # eval(script, num_keys, *keys, *args)
        args = mock_client.eval.call_args.args
        assert args[0] == cache.LUA_SET_WITH_TIMESTAMP_CHECK
        assert args[1] == 3, "Lua call must reference 3 keys"

        keys = args[2:5]
        assert keys[0] == cache._make_key(mock_user_plan.user_id)
        assert keys[1] == cache._make_global_invalidation_key()
        assert keys[2] == cache._make_invalidation_key(mock_user_plan.user_id)

        # fetched_at sentinel must be the stringified value, not "nil".
        assert args[7] == "42.0"

    async def test_invalidate_records_timestamp_for_lua_check(
        self,
        make_cache: Any,
        mock_user_plan: UserPlan,
    ) -> None:
        """invalidate() must SETEX the per-user invalidation key the Lua reads."""
        cache, mock_client = make_cache()
        mock_client.setex = AsyncMock(return_value=True)
        mock_client.delete = AsyncMock(return_value=1)

        await cache.invalidate(mock_user_plan.user_id)

        # The first SETEX writes the per-key invalidation timestamp.
        assert mock_client.setex.await_count == 1
        setex_args = mock_client.setex.call_args.args
        assert setex_args[0] == cache._make_invalidation_key(mock_user_plan.user_id)
        assert setex_args[1] == cache._ttl_seconds * 2

    async def test_invalidate_all_records_global_timestamp_first(
        self,
        make_cache: Any,
    ) -> None:
        """invalidate_all() must write the global timestamp BEFORE running SCAN.

        If SCAN fails partway, in-flight writes still see the timestamp and
        will be rejected by the Lua check on next set().
        """
        cache, mock_client = make_cache()

        order: list[str] = []

        async def _setex(key: str, *_a: object, **_k: object) -> bool:
            order.append(f"setex:{key}")
            return True

        async def _scan(*_a: object, **_k: object) -> tuple[int, list[bytes]]:
            order.append("scan")
            return 0, []

        mock_client.setex = AsyncMock(side_effect=_setex)
        mock_client.scan = AsyncMock(side_effect=_scan)
        mock_client.delete = AsyncMock(return_value=0)

        await cache.invalidate_all()

        # Global timestamp written before any SCAN occurred.
        scan_idx = order.index("scan")
        global_setex = next(
            i for i, op in enumerate(order)
            if op.endswith("_global_invalidated")
        )
        assert global_setex < scan_idx


# ---------------------------------------------------------------------------
# Finding P2 #7: _record_failure should fire once per operation, not per retry
# ---------------------------------------------------------------------------


class TestRedisUserPlanCacheCircuitBreakerCounting:
    """Bug: `_record_failure` was called inside the retry loop, so a single
    transient Redis blip incremented the breaker REDIS_RETRY_ATTEMPTS times.
    Now it must fire exactly once after all retries are exhausted.
    """

    async def test_single_failure_recorded_after_all_retries(self) -> None:
        if "redis.asyncio" not in sys.modules:
            pytest.skip("redis not installed")

        import redis.asyncio as redis  # noqa: PLC0415

        cache = RedisUserPlanCache(ttl_seconds=300)
        cache._client = AsyncMock()  # type: ignore[assignment]

        async def _always_fail() -> None:
            raise redis.ConnectionError("boom")

        with patch.object(cache, "_record_failure", new=AsyncMock()) as mock_rec:
            await cache._execute_with_retry("get", _always_fail)

        assert mock_rec.await_count == 1, (
            f"expected single _record_failure call, got {mock_rec.await_count}"
        )


# ---------------------------------------------------------------------------
# Finding P1 #2: negative amount must not decrement quota
# ---------------------------------------------------------------------------


class TestNegativeAmountQuotaBypass:
    """Originally callers could pass amount=-N; the upsert
    ``feature_usage + amount`` then decremented the counter, restoring quota
    they had legitimately consumed. The fix rejects amount<=0 at every
    entry point.
    """

    async def test_record_usage_rejects_zero(self) -> None:
        repo = UsageRepository(AsyncMock())
        with pytest.raises(ValueError, match="positive integer"):
            await repo.record_usage(uuid4(), uuid4(), amount=0, period=PeriodType.DAILY)

    async def test_record_usage_rejects_negative(self) -> None:
        repo = UsageRepository(AsyncMock())
        with pytest.raises(ValueError, match="positive integer"):
            await repo.record_usage(uuid4(), uuid4(), amount=-5, period=PeriodType.DAILY)

    async def test_atomic_check_and_consume_rejects_zero(self) -> None:
        repo = UsageRepository(AsyncMock())
        with pytest.raises(ValueError, match="positive"):
            await repo.atomic_check_and_consume(
                user_plan_id=uuid4(),
                feature_id=uuid4(),
                amount=0,
                limit=100,
                period=PeriodType.DAILY,
            )

    async def test_atomic_check_and_consume_rejects_negative_when_unlimited(
        self,
    ) -> None:
        """Even with limit=-1 (unlimited) negative amount must not decrement."""
        repo = UsageRepository(AsyncMock())
        with pytest.raises(ValueError, match="positive"):
            await repo.atomic_check_and_consume(
                user_plan_id=uuid4(),
                feature_id=uuid4(),
                amount=-10,
                limit=-1,
                period=PeriodType.DAILY,
            )

    async def test_atomic_check_and_consume_rejects_negative_when_limited(
        self,
    ) -> None:
        repo = UsageRepository(AsyncMock())
        with pytest.raises(ValueError, match="positive"):
            await repo.atomic_check_and_consume(
                user_plan_id=uuid4(),
                feature_id=uuid4(),
                amount=-10,
                limit=100,
                period=PeriodType.DAILY,
            )

    async def test_service_check_and_consume_quota_rejects_zero(
        self,
        mock_config: Any,
    ) -> None:
        service = PlanService(mock_config, MagicMock())
        with pytest.raises(ValueError, match="positive integer"):
            await service.check_and_consume_quota(
                user_id=uuid4(),
                feature_code="api_calls",
                amount=0,
            )

    async def test_service_check_and_consume_quota_rejects_negative(
        self,
        mock_config: Any,
    ) -> None:
        service = PlanService(mock_config, MagicMock())
        with pytest.raises(ValueError, match="positive integer"):
            await service.check_and_consume_quota(
                user_id=uuid4(),
                feature_code="api_calls",
                amount=-100,
            )


# ---------------------------------------------------------------------------
# Finding P1 #4: repositories inherit BaseRepository[M, E]
# ---------------------------------------------------------------------------


class TestRepositoriesUseBaseRepository:
    """Rule: layer-standards.md mandates BaseRepository[M, E] for all repos."""

    def test_plan_repository_subclasses_base_repository(self) -> None:
        assert issubclass(PlanRepository, BaseRepository)
        assert PlanRepository._model_class is PlanModel  # type: ignore[misc]
        assert PlanRepository._entity_class is Plan  # type: ignore[misc]

    def test_usage_repository_subclasses_base_repository(self) -> None:
        assert issubclass(UsageRepository, BaseRepository)
        assert UsageRepository._model_class is FeatureUsageModel  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Finding P1 #5: plan models inherit BaseModel and have audit timestamps
# ---------------------------------------------------------------------------


class TestPlanModelsExtendBaseModel:
    """Rule: CLAUDE.md base-class table mandates BaseModel for UUID PK models.

    BaseModel = Base + UUIDPrimaryKeyMixin + TimestampMixin. Inheritance is
    what gives the audit columns; a model with its own ad-hoc timestamps
    would still violate the rule.
    """

    @pytest.mark.parametrize(
        "model_cls",
        [
            PlanModel,
            UserPlanModel,
            PlanLimitModel,
            PlanPermissionModel,
            FeatureModel,
            FeatureUsageModel,
        ],
    )
    def test_model_inherits_from_base_model(self, model_cls: type) -> None:
        assert issubclass(model_cls, BaseModel)
        assert issubclass(model_cls, TimestampMixin)

    @pytest.mark.parametrize(
        "model_cls",
        [
            PlanModel,
            UserPlanModel,
            PlanLimitModel,
            PlanPermissionModel,
            FeatureModel,
            FeatureUsageModel,
        ],
    )
    def test_model_table_has_timestamp_columns(self, model_cls: type) -> None:
        columns = {c.name for c in model_cls.__table__.columns}  # type: ignore[attr-defined]
        assert "created_at" in columns
        assert "updated_at" in columns


# ---------------------------------------------------------------------------
# Finding P2 #6: get_all_plans must serialize concurrent cold-cache fetches
# ---------------------------------------------------------------------------


class TestGetAllPlansStampedeProtection:
    """Originally N concurrent callers on a cold cache all hit the DB. Now a
    single lock funnels them so only the first caller fetches; the rest read
    from cache after the lock releases.
    """

    async def test_concurrent_callers_hit_db_once(
        self,
        mock_config: Any,
        mock_plan: Plan,
    ) -> None:
        service = PlanService(mock_config, MagicMock())
        plans = [mock_plan]

        db_call_count = 0

        async def _slow_get_all_plans() -> list[Plan]:
            nonlocal db_call_count
            db_call_count += 1
            await asyncio.sleep(0.01)
            return plans

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.plans.get_all_plans = AsyncMock(side_effect=_slow_get_all_plans)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(*[service.get_all_plans() for _ in range(10)])

        assert db_call_count == 1, (
            f"stampede protection broken — {db_call_count} concurrent DB hits"
        )
        for r in results:
            assert r == plans


# ---------------------------------------------------------------------------
# Finding P2 #8: PlanAuthorizationError message must not embed UUID
# ---------------------------------------------------------------------------


class TestPlanAuthorizationErrorMessageHasNoUUID:
    """Rule: error-handling.md forbids UUIDs in exception message strings.

    Caller info (target_user_id) stays on attributes / details only.
    """

    async def test_message_excludes_target_user_uuid(
        self,
        mock_config: Any,
    ) -> None:
        target = uuid4()

        async def _deny(*_a: object, **_k: object) -> bool:
            return False

        service = PlanService(mock_config, MagicMock(), authorization_callback=_deny)

        with pytest.raises(PlanAuthorizationError) as exc_info:
            await service._check_authorization("assign_plan", target)

        # Message must NOT contain the UUID; attribute must.
        assert str(target) not in exc_info.value.message
        assert exc_info.value.target_user_id == str(target)


# ---------------------------------------------------------------------------
# Finding P2 #9: ForeignKeyViolationError must inherit BaseError
# ---------------------------------------------------------------------------


class TestForeignKeyViolationErrorInheritance:
    """Rule: every feature exception must inherit from BaseError or subclasses
    so the global error handler can surface ``code`` and ``status_code``.
    """

    def test_foreign_key_violation_is_base_error(self) -> None:
        assert issubclass(ForeignKeyViolationError, BaseError)

    def test_foreign_key_violation_has_error_code_and_status(self) -> None:
        err = ForeignKeyViolationError("user_id", "users_pkey violation")
        assert err.code == "FK_VIOLATION"
        assert err.status_code == 409
        # constraint_name is preserved as an attribute for service translation.
        assert err.constraint_name == "user_id"


# ---------------------------------------------------------------------------
# Finding P1 #5 (data side): migration adds the timestamp columns
# ---------------------------------------------------------------------------


class TestPlanTimestampMigrationExists:
    """Lock in that the alembic migration adding created_at/updated_at to plan
    tables ships and references the right tables. Without this, the model
    change above ships without the corresponding DB columns.
    """

    def test_migration_file_lists_all_six_plan_tables(self) -> None:
        from importlib import util  # noqa: PLC0415
        from pathlib import Path  # noqa: PLC0415

        migration_path = (
            Path(__file__).parents[2]
            / "alembic"
            / "versions"
            / "20260506_000000_add_plan_timestamps.py"
        )
        assert migration_path.exists(), f"missing migration: {migration_path}"

        spec = util.spec_from_file_location("plan_timestamps_mig", migration_path)
        assert spec is not None and spec.loader is not None
        mod = util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        expected = {
            "plans",
            "features",
            "plan_limits",
            "plan_permissions",
            "user_plans",
            "feature_usage",
        }
        assert set(mod._TABLES) == expected
        assert mod.down_revision == "004_add_user_metadata"
