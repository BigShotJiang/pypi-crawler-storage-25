"""Auth feature tests."""
