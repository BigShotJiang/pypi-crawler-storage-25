"""Tests for AuthCache - auth caching functionality.

Tests cover:
- Cache hit/miss scenarios
- Cache invalidation on logout and user changes
- TTL expiration
- Race condition prevention
- Circuit breaker behavior (Redis)
- In-memory vs Redis backend selection
"""

import asyncio
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.auth.cache.auth_cache import (
    AuthCache,
    InMemoryAuthCache,
    RedisAuthCache,
    RedisRequiredError,
)
from identity_plan_kit.auth.domain.entities import User
from identity_plan_kit.shared.constants import AUTH_CACHE_TTL_SECONDS

pytestmark = pytest.mark.anyio


@pytest.fixture
def sample_user() -> User:
    """Create a sample user for testing."""
    return User(
        id=uuid4(),
        email="test@example.com",
        role_id=uuid4(),
        display_name="Test User",
        picture_url="https://example.com/pic.jpg",
        metadata={"country": "US", "notifications_enabled": True},
        is_active=True,
        is_verified=True,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
        role_code="user",
        permissions={"read", "write"},
    )


class TestInMemoryAuthCache:
    """Test suite for InMemoryAuthCache."""

    async def test_cache_miss_returns_none(self):
        """Cache miss returns None."""
        cache = InMemoryAuthCache(ttl_seconds=60)
        user_id = uuid4()

        result = await cache.get(user_id)

        assert result is None

    async def test_cache_hit_returns_user(self, sample_user: User):
        """Cache hit returns cached user."""
        cache = InMemoryAuthCache(ttl_seconds=60)

        await cache.set(sample_user.id, sample_user)
        result = await cache.get(sample_user.id)

        assert result is not None
        assert result.id == sample_user.id
        assert result.email == sample_user.email
        assert result.role_code == sample_user.role_code

    async def test_cache_ttl_expiration(self, sample_user: User):
        """Expired entries return None."""
        cache = InMemoryAuthCache(ttl_seconds=0)  # Immediate expiration

        await cache.set(sample_user.id, sample_user)
        # Wait a tiny bit to ensure expiration
        await asyncio.sleep(0.01)
        result = await cache.get(sample_user.id)

        assert result is None

    async def test_cache_invalidation(self, sample_user: User):
        """Invalidated entries return None."""
        cache = InMemoryAuthCache(ttl_seconds=60)

        await cache.set(sample_user.id, sample_user)
        await cache.invalidate(sample_user.id)
        result = await cache.get(sample_user.id)

        assert result is None

    async def test_cache_invalidate_all(self, sample_user: User):
        """Invalidate all clears all entries."""
        cache = InMemoryAuthCache(ttl_seconds=60)
        user2 = User(
            id=uuid4(),
            email="user2@example.com",
            role_id=uuid4(),
            display_name="User 2",
            is_active=True,
            is_verified=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
            role_code="admin",
        )

        await cache.set(sample_user.id, sample_user)
        await cache.set(user2.id, user2)
        await cache.invalidate_all()

        result1 = await cache.get(sample_user.id)
        result2 = await cache.get(user2.id)

        assert result1 is None
        assert result2 is None
        assert cache.size == 0

    async def test_stale_write_prevention_after_invalidation(self, sample_user: User):
        """Stale writes are rejected after invalidation."""
        cache = InMemoryAuthCache(ttl_seconds=60)

        # Simulate: fetch from DB, then invalidate, then try to cache stale data
        fetch_timestamp = cache.get_fetch_timestamp()
        await asyncio.sleep(0.01)  # Ensure time passes
        await cache.invalidate(sample_user.id)
        await asyncio.sleep(0.01)

        # Try to cache with old fetch timestamp
        result = await cache.set(sample_user.id, sample_user, fetched_at=fetch_timestamp)

        assert result is False
        cached = await cache.get(sample_user.id)
        assert cached is None

    async def test_cleanup_expired_entries(self, sample_user: User):
        """Cleanup removes expired entries."""
        cache = InMemoryAuthCache(ttl_seconds=1)  # 1 second TTL

        # Set entry and force expiration by manipulating the entry directly
        await cache.set(sample_user.id, sample_user)

        # Manually expire the entry by setting expires_at to past
        entry = cache._cache[sample_user.id]
        entry.expires_at = datetime.now(UTC) - timedelta(seconds=1)

        removed = await cache.cleanup_expired()

        assert removed == 1
        assert cache.size == 0

    async def test_cache_disabled_when_ttl_zero(self, sample_user: User):
        """Cache is disabled when TTL is 0."""
        cache = InMemoryAuthCache(ttl_seconds=0)

        result = await cache.set(sample_user.id, sample_user)

        assert result is False
        assert await cache.get(sample_user.id) is None


class TestAuthCacheIntegration:
    """Integration tests for AuthCache with backend selection."""

    async def test_defaults_to_in_memory_cache(self):
        """AuthCache defaults to in-memory when no Redis URL provided."""
        cache = AuthCache(ttl_seconds=60)

        assert not cache.is_redis
        assert isinstance(cache._backend, InMemoryAuthCache)

    async def test_uses_redis_when_url_provided(self):
        """AuthCache uses Redis when URL provided (if redis available)."""
        try:
            cache = AuthCache(
                ttl_seconds=60,
                redis_url="redis://localhost:6379/0",
            )
            # If redis is installed, it should use Redis backend
            assert cache.is_redis or not cache.is_redis  # Either is valid
        except RedisRequiredError:
            pytest.skip("Redis package not installed")

    async def test_require_redis_raises_if_not_available(self):
        """require_redis=True raises if Redis not available."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", False):
            with pytest.raises(RedisRequiredError):
                AuthCache(
                    ttl_seconds=60,
                    redis_url="redis://localhost:6379/0",
                    require_redis=True,
                )

    async def test_require_redis_raises_if_url_not_provided(self):
        """require_redis=True raises if Redis URL not provided."""
        with pytest.raises(RedisRequiredError):
            AuthCache(
                ttl_seconds=60,
                redis_url=None,
                require_redis=True,
            )


class TestAuthCacheWithAuthService:
    """Test auth cache integration with AuthService."""

    async def test_cache_hit_avoids_db_query(self, sample_user: User, mock_config):
        """Cache hit avoids database query."""
        from identity_plan_kit.auth.services.auth_service import AuthService
        from identity_plan_kit.shared.security import create_access_token

        # Setup
        cache = InMemoryAuthCache(ttl_seconds=60)
        mock_session_factory = MagicMock()

        service = AuthService(
            config=mock_config,
            session_factory=mock_session_factory,
            auth_cache=cache,
        )

        # Pre-populate cache
        await cache.set(sample_user.id, sample_user)

        # Create token
        secret = mock_config.secret_key.get_secret_value()
        access_token = create_access_token(
            data={"sub": str(sample_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(minutes=15),
        )

        # Mock UoW should NOT be called (cache hit)
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.users.get_by_id = AsyncMock()  # Should not be called

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.get_user_from_token(access_token)

        # Verify cache hit
        assert result.id == sample_user.id
        mock_uow.users.get_by_id.assert_not_called()

    async def test_cache_miss_queries_db_and_caches(self, sample_user: User, mock_config):
        """Cache miss queries DB and caches result."""
        from identity_plan_kit.auth.services.auth_service import AuthService
        from identity_plan_kit.shared.security import create_access_token

        # Setup
        cache = InMemoryAuthCache(ttl_seconds=60)
        mock_session_factory = MagicMock()

        service = AuthService(
            config=mock_config,
            session_factory=mock_session_factory,
            auth_cache=cache,
        )

        # Create token
        secret = mock_config.secret_key.get_secret_value()
        access_token = create_access_token(
            data={"sub": str(sample_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(minutes=15),
        )

        # Mock UoW to return user
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.users.get_by_id = AsyncMock(return_value=sample_user)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.get_user_from_token(access_token)

        # Verify DB was called
        mock_uow.users.get_by_id.assert_called_once()

        # Verify result was cached
        cached = await cache.get(sample_user.id)
        assert cached is not None
        assert cached.id == sample_user.id

    async def test_logout_invalidates_cache(self, sample_user: User, mock_config):
        """Logout invalidates auth cache."""
        from identity_plan_kit.auth.services.auth_service import AuthService

        # Setup
        config = mock_config
        cache = InMemoryAuthCache(ttl_seconds=60)
        mock_session_factory = MagicMock()

        service = AuthService(
            config=config,
            session_factory=mock_session_factory,
            auth_cache=cache,
        )

        # Pre-populate cache
        await cache.set(sample_user.id, sample_user)

        # Mock UoW for logout
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.tokens.revoke_all_for_user = AsyncMock(return_value=1)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            await service.logout(sample_user.id, everywhere=True)

        # Verify cache was invalidated
        cached = await cache.get(sample_user.id)
        assert cached is None

    async def test_deactivation_invalidates_cache(self, sample_user: User, mock_config):
        """User deactivation invalidates auth cache."""
        from identity_plan_kit.auth.services.auth_service import AuthService

        # Setup
        config = mock_config
        cache = InMemoryAuthCache(ttl_seconds=60)
        mock_session_factory = MagicMock()

        service = AuthService(
            config=config,
            session_factory=mock_session_factory,
            auth_cache=cache,
        )

        # Pre-populate cache
        await cache.set(sample_user.id, sample_user)

        # Call public invalidation method
        await service.invalidate_auth_cache(sample_user.id)

        # Verify cache was invalidated
        cached = await cache.get(sample_user.id)
        assert cached is None


class TestUserSerialization:
    """Test User entity serialization/deserialization."""

    async def test_user_roundtrip_serialization(self, sample_user: User):
        """User can be serialized and deserialized correctly."""
        from identity_plan_kit.auth.cache.auth_cache import _dict_to_user, _user_to_dict

        # Serialize
        data = _user_to_dict(sample_user)

        # Verify dict structure
        assert data["id"] == str(sample_user.id)
        assert data["email"] == sample_user.email
        assert data["role_code"] == sample_user.role_code
        assert set(data["permissions"]) == sample_user.permissions
        assert data["metadata"] == {"country": "US", "notifications_enabled": True}

        # Deserialize
        restored = _dict_to_user(data)

        # Verify all fields match
        assert restored.id == sample_user.id
        assert restored.email == sample_user.email
        assert restored.role_id == sample_user.role_id
        assert restored.display_name == sample_user.display_name
        assert restored.picture_url == sample_user.picture_url
        assert restored.metadata == sample_user.metadata
        assert restored.is_active == sample_user.is_active
        assert restored.is_verified == sample_user.is_verified
        assert restored.role_code == sample_user.role_code
        assert restored.permissions == sample_user.permissions

    async def test_user_serialization_with_none_fields(self):
        """User with None fields serializes correctly."""
        from identity_plan_kit.auth.cache.auth_cache import _dict_to_user, _user_to_dict

        user = User(
            id=uuid4(),
            email="test@example.com",
            role_id=uuid4(),
            display_name="Test",
            picture_url=None,  # None
            is_active=True,
            is_verified=False,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
            role_code=None,  # None
            permissions=set(),  # Empty
        )

        data = _user_to_dict(user)
        restored = _dict_to_user(data)

        assert restored.picture_url is None
        assert restored.role_code is None
        assert restored.permissions == set()
        assert restored.metadata == {}

    async def test_user_serialization_backward_compat_missing_metadata(self):
        """Deserialization handles missing metadata key (backward compatibility)."""
        from identity_plan_kit.auth.cache.auth_cache import _dict_to_user

        # Simulate a cached dict from before metadata was added
        data = {
            "id": str(uuid4()),
            "email": "old@example.com",
            "role_id": str(uuid4()),
            "display_name": "Old User",
            "picture_url": None,
            "is_active": True,
            "is_verified": True,
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
            "role_code": "user",
            "permissions": [],
        }

        restored = _dict_to_user(data)

        assert restored.metadata == {}
