"""
Regression tests for the comprehensive auth-module review (2026-05-06).

Each test below targets a specific bug identified by the four parallel review
agents (security, concurrency, architecture, code). Tests are grouped by the
review section that surfaced the bug. Keep these tests passing to avoid
re-introducing the regressions they cover.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from identity_plan_kit.auth.cache.auth_cache import (
    InMemoryAuthCache,
    RedisRequiredError,
)
from identity_plan_kit.auth.domain.entities import RefreshToken, User, UserProvider
from identity_plan_kit.auth.domain.exceptions import (
    TokenInvalidError,
)
from identity_plan_kit.auth.dto.requests import UpdateProfileRequest
from identity_plan_kit.auth.handlers.oauth_routes import (
    OAUTH_CODE_PATTERN,
    _validate_redirect_url,
)
from identity_plan_kit.auth.models.refresh_token import RefreshTokenModel
from identity_plan_kit.auth.models.user_provider import UserProviderModel
from identity_plan_kit.auth.repositories.token_repo import RefreshTokenRepository
from identity_plan_kit.auth.repositories.user_repo import UserRepository
from identity_plan_kit.auth.services.auth_service import AuthService
from identity_plan_kit.auth.services.oauth_service import SemaphoreTimeoutError
from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.shared.exceptions import BaseError
from identity_plan_kit.shared.models import BaseModel
from identity_plan_kit.shared.repository import BaseRepository
from identity_plan_kit.shared.security import (
    create_refresh_token,
    encrypt_for_cache,
)

pytestmark = pytest.mark.anyio


# =============================================================================
# P1 — Architecture: Models inherit BaseModel; Repositories inherit BaseRepository
# =============================================================================


class TestArchitectureBaseClasses:
    """Architecture rule: models extend BaseModel; repos extend BaseRepository."""

    def test_refresh_token_model_extends_base_model(self) -> None:
        # BaseModel provides UUID7 PK + TimestampMixin (created_at + updated_at).
        assert issubclass(RefreshTokenModel, BaseModel)
        # Both timestamp columns are inherited via TimestampMixin.
        assert hasattr(RefreshTokenModel, "created_at")
        assert hasattr(RefreshTokenModel, "updated_at")

    def test_user_provider_model_extends_base_model(self) -> None:
        assert issubclass(UserProviderModel, BaseModel)
        assert hasattr(UserProviderModel, "created_at")
        assert hasattr(UserProviderModel, "updated_at")

    def test_user_repository_extends_base_repository(self) -> None:
        # Without this, the repo reimplements _extract_model_fields / _create_model
        # from scratch (DRY + arch-rule violation).
        assert issubclass(UserRepository, BaseRepository)

    def test_refresh_token_repository_extends_base_repository(self) -> None:
        assert issubclass(RefreshTokenRepository, BaseRepository)


# =============================================================================
# P1/P3 — Exceptions inherit BaseError (architecture rule)
# =============================================================================


class TestExceptionBaseClasses:
    """All custom exceptions must inherit from BaseError (per error-handling.md)."""

    def test_redis_required_error_is_base_error(self) -> None:
        assert issubclass(RedisRequiredError, BaseError)
        # And carries a status code (used by the global error handler).
        err = RedisRequiredError("test")
        assert err.status_code == 500
        assert err.code == "REDIS_REQUIRED"

    def test_semaphore_timeout_error_is_base_error(self) -> None:
        assert issubclass(SemaphoreTimeoutError, BaseError)
        err = SemaphoreTimeoutError("test")
        assert err.status_code == 503
        assert err.code == "OAUTH_SEMAPHORE_TIMEOUT"


# =============================================================================
# P1 — Open redirect via prefix matching (security S1)
# =============================================================================


class TestRedirectURLValidation:
    """
    `_validate_redirect_url` parses scheme+host exactly. Naive `startswith`
    matching is bypassable: with allowlist `https://app.com`, the attacker
    can pass `https://app.com.evil.com/...` or `https://app.com@evil.com/...`.
    """

    @pytest.fixture
    def cfg(self) -> IdentityPlanKitConfig:
        return IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="x",
            google_client_secret="y",
            google_redirect_uri="http://localhost/cb",
            oauth_allowed_redirect_urls=["https://app.example.com"],
        )

    def test_allows_exact_host(self, cfg: IdentityPlanKitConfig) -> None:
        url = "https://app.example.com/dashboard"
        assert _validate_redirect_url(url, cfg) == url

    def test_rejects_prefix_attack_subdomain(self, cfg: IdentityPlanKitConfig) -> None:
        # `app.example.com.evil.com` is NOT `app.example.com`.
        assert _validate_redirect_url(
            "https://app.example.com.evil.com/steal", cfg
        ) is None

    def test_rejects_userinfo_attack(self, cfg: IdentityPlanKitConfig) -> None:
        # Browser parses `app.example.com@evil.com` as userinfo + host=evil.com.
        assert _validate_redirect_url(
            "https://app.example.com@evil.com/steal", cfg
        ) is None

    def test_rejects_scheme_mismatch(self, cfg: IdentityPlanKitConfig) -> None:
        # http != https.
        assert _validate_redirect_url("http://app.example.com/x", cfg) is None

    def test_rejects_empty_allowlist(self) -> None:
        cfg = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost/test",
            secret_key="test-secret-key-that-is-at-least-32-chars",
            google_client_id="x",
            google_client_secret="y",
            google_redirect_uri="http://localhost/cb",
            oauth_allowed_redirect_urls=[],
        )
        assert _validate_redirect_url("https://anything.com/", cfg) is None

    def test_rejects_non_http_scheme(self, cfg: IdentityPlanKitConfig) -> None:
        assert _validate_redirect_url("javascript:alert(1)", cfg) is None
        assert _validate_redirect_url("file:///etc/passwd", cfg) is None


# =============================================================================
# P2 — OAuth code regex accepts real Google codes & rejects junk (security S3 / code F11)
# =============================================================================


class TestOAuthCodePattern:
    """The pattern must accept real Google codes (incl. `=`/`+`) and tolerate length."""

    def test_accepts_typical_google_code(self) -> None:
        # Real-world example: 4/0Ax... base64 with - and _.
        code = "4/0AfJohXn7-real_long_google_code_with_padding=="
        assert OAUTH_CODE_PATTERN.match(code) is not None

    def test_accepts_long_code(self) -> None:
        # Codes can exceed 200 chars in practice. Pattern allows up to 512.
        code = "a" * 500
        assert OAUTH_CODE_PATTERN.match(code) is not None

    def test_rejects_too_short(self) -> None:
        assert OAUTH_CODE_PATTERN.match("short") is None

    def test_rejects_control_chars(self) -> None:
        assert OAUTH_CODE_PATTERN.match("valid_chars\x00with_null_byte") is None
        assert OAUTH_CODE_PATTERN.match("with\nnewline_in_code") is None


# =============================================================================
# P1 — InMemoryAuthCache LRU eviction (concurrency #1, arch #5)
# =============================================================================


class TestInMemoryAuthCacheLRU:
    """`_cache` and `_invalidated_at` must be bounded — both grew unboundedly."""

    async def test_cache_evicts_oldest_when_at_capacity(self) -> None:
        cache = InMemoryAuthCache(ttl_seconds=60, max_entries=3)

        users = [
            User(
                id=uuid4(),
                email=f"u{i}@x.com",
                role_id=uuid4(),
                display_name=f"User {i}",
                is_active=True,
            )
            for i in range(5)
        ]

        for u in users:
            await cache.set(u.id, u)

        # Only 3 most-recent entries remain.
        assert cache.size == 3
        # The first two were evicted.
        assert await cache.get(users[0].id) is None
        assert await cache.get(users[1].id) is None
        # The last three are still cached.
        assert await cache.get(users[2].id) is not None
        assert await cache.get(users[3].id) is not None
        assert await cache.get(users[4].id) is not None

    async def test_invalidated_at_dict_is_bounded(self) -> None:
        cache = InMemoryAuthCache(ttl_seconds=60, max_entries=10)

        # Invalidate a large number of distinct user_ids.
        for _ in range(200):
            await cache.invalidate(uuid4())

        # The tombstone dict is capped at 2x max_entries (=20 here).
        # Without LRU eviction this dict would grow unboundedly with every
        # logout, deactivation, or profile update.
        assert len(cache._invalidated_at) <= cache._max_entries * 2


# =============================================================================
# P1 — Idempotency cache: malformed/decryption-failure raises, doesn't fall through
#       (code F2 — falling through tripped theft detection on legit retries)
# =============================================================================


class TestIdempotencyCacheRejection:
    """When the idempotency cache is malformed, raise — don't fall through."""

    async def test_malformed_cache_entry_raises_token_invalid(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        secret = mock_config.secret_key.get_secret_value()
        token, _ = create_refresh_token(
            data={"sub": str(mock_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(days=30),
        )

        # Cache hit but missing encrypted-token fields.
        bad_cache = {"user_id": str(mock_user.id), "new_token_hash": "stale"}
        mock_state_store = AsyncMock()
        mock_state_store.get = AsyncMock(return_value=bad_cache)
        mock_state_store.delete = AsyncMock()

        service = AuthService(mock_config, MagicMock())

        # Even though uow is mocked, we should never reach get_by_hash if the
        # decryption-failure path correctly raises TokenInvalidError.
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.get_state_store",
                return_value=mock_state_store,
            ),
            pytest.raises(TokenInvalidError),
        ):
            await service.refresh_tokens(token)

        # Stale cache entry was deleted (so future retries don't loop).
        mock_state_store.delete.assert_called_once()
        # We never went near the rotation UoW path — that's the whole point:
        # falling through against a revoked token would trigger account
        # deactivation against a legitimate retrying client.
        mock_uow.tokens.get_by_hash_any.assert_not_called()

    async def test_decryption_failure_raises_and_clears_cache(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        secret = mock_config.secret_key.get_secret_value()
        token, _ = create_refresh_token(
            data={"sub": str(mock_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(days=30),
        )

        # Cache has the right shape but the encrypted blobs were encrypted
        # with a different key (key rotation / tampering).
        wrong_key = "different-secret-key-also-32-chars-yes"
        cache_entry = {
            "user_id": str(mock_user.id),
            "access_token_enc": encrypt_for_cache("a", wrong_key),
            "refresh_token_enc": encrypt_for_cache("b", wrong_key),
        }
        mock_state_store = AsyncMock()
        mock_state_store.get = AsyncMock(return_value=cache_entry)
        mock_state_store.delete = AsyncMock()

        service = AuthService(mock_config, MagicMock())
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.get_state_store",
                return_value=mock_state_store,
            ),
            pytest.raises(TokenInvalidError),
        ):
            await service.refresh_tokens(token)

        mock_state_store.delete.assert_called_once()
        mock_uow.tokens.get_by_hash_any.assert_not_called()


# =============================================================================
# P1 — Idempotency cache write must happen AFTER UoW commit (code F1, concurrency #2)
# =============================================================================


class TestIdempotencyCacheWriteOrdering:
    """`state_store.set` must run after the UoW exits, not inside it."""

    async def test_idempotency_cache_set_called_after_uow_exit(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        secret = mock_config.secret_key.get_secret_value()
        refresh_tok, token_hash = create_refresh_token(
            data={"sub": str(mock_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(days=30),
        )

        stored_token = RefreshToken(
            id=uuid4(),
            user_id=mock_user.id,
            token_hash=token_hash,
            expires_at=datetime.now(UTC) + timedelta(days=30),
            created_at=datetime.now(UTC),
        )

        order: list[str] = []

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def aexit_record(*args, **kwargs):
            order.append("uow_exit")
            return None

        mock_uow.__aexit__ = AsyncMock(side_effect=aexit_record)
        mock_uow.tokens.get_by_hash_any = AsyncMock(return_value=stored_token)
        mock_uow.users.get_by_id = AsyncMock(return_value=mock_user)
        mock_uow.tokens.revoke = AsyncMock()
        mock_uow.tokens.create = AsyncMock()

        mock_state_store = AsyncMock()
        mock_state_store.get = AsyncMock(return_value=None)  # No idempotency hit

        async def set_record(*args, **kwargs):
            order.append("idempotency_set")

        mock_state_store.set = AsyncMock(side_effect=set_record)

        service = AuthService(mock_config, MagicMock())

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.get_state_store",
                return_value=mock_state_store,
            ),
        ):
            await service.refresh_tokens(refresh_tok)

        # Critical ordering: UoW commit (exit) MUST happen before the idempotency
        # cache is updated. Otherwise the cache could record tokens that were
        # never durably persisted (failed commit), and a retry would receive
        # tokens that fail every subsequent use.
        assert order == ["uow_exit", "idempotency_set"], (
            f"Idempotency cache must be written AFTER UoW commit, got: {order}"
        )


# =============================================================================
# P2 — picture_url normalization at DTO level (code F6/F7)
# =============================================================================


class TestUpdateProfileRequest:
    """Empty-string `picture_url` should be normalized to None at the DTO."""

    def test_empty_string_picture_url_becomes_none(self) -> None:
        req = UpdateProfileRequest(picture_url="")
        assert req.picture_url is None

    def test_non_empty_picture_url_passes_through(self) -> None:
        req = UpdateProfileRequest(picture_url="https://example.com/a.png")
        assert req.picture_url == "https://example.com/a.png"

    def test_none_picture_url_stays_none(self) -> None:
        req = UpdateProfileRequest(picture_url=None)
        assert req.picture_url is None


# =============================================================================
# P3 — verify_user_password timing-safe for OAuth-only users (security S6 / code F17)
# =============================================================================


class TestVerifyUserPasswordTimingSafe:
    """OAuth-only users (no password hash) must still go through bcrypt."""

    async def test_no_hash_runs_bcrypt_for_timing_padding(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        # When get_password_hash returns None, the service should still call
        # verify_password against a constant padding hash to keep timing
        # indistinguishable from a real-but-wrong password attempt.
        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.users.get_password_hash = AsyncMock(return_value=None)
        mock_uow.users.get_by_id = AsyncMock(return_value=mock_user)

        service = AuthService(mock_config, MagicMock())

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.verify_password"
            ) as mock_verify,
        ):
            mock_verify.return_value = False
            result = await service.verify_user_password(mock_user.id, "any-password")

        assert result is False
        # Crucially, verify_password WAS called even though there is no hash —
        # this is the timing padding.
        mock_verify.assert_called_once()


# =============================================================================
# P3 — UserProvider validation (architecture cleanup)
# =============================================================================


class TestUserProviderValidation:
    """Provider codes are constrained to a known set."""

    def test_known_provider_code_accepted(self) -> None:
        UserProvider(
            id=uuid4(),
            user_id=uuid4(),
            code="google",
            external_user_id="ext-1",
        )

    def test_unknown_provider_code_rejected(self) -> None:
        with pytest.raises(ValueError, match="Invalid provider code"):
            UserProvider(
                id=uuid4(),
                user_id=uuid4(),
                code="evil-provider",
                external_user_id="ext-1",
            )

    def test_valid_codes_is_classvar_not_field(self) -> None:
        # If VALID_PROVIDER_CODES leaks as a dataclass field, instances would
        # require it as a constructor arg — verify this hasn't regressed.
        import dataclasses

        field_names = {f.name for f in dataclasses.fields(UserProvider)}
        assert "VALID_PROVIDER_CODES" not in field_names


# =============================================================================
# P1 — OAuth semaphore must not over-release on acquire timeout
#       (concurrency #8, code F3)
# =============================================================================


class TestOAuthSemaphoreNoOverRelease:
    """
    The bulkhead semaphore must NOT be released when `_acquire_semaphore` itself
    times out. Releasing without an acquire silently grows the effective
    concurrency ceiling each time — defeating the bulkhead.
    """

    async def test_timeout_does_not_over_release(
        self,
        mock_config: IdentityPlanKitConfig,
    ) -> None:
        from identity_plan_kit.auth.services.oauth_service import GoogleOAuthService

        service = GoogleOAuthService(
            mock_config, max_concurrent_calls=2, semaphore_timeout=0.05
        )

        # Hold both semaphore slots to force every subsequent acquire to time out.
        await service._semaphore.acquire()
        await service._semaphore.acquire()
        assert service._semaphore.locked() or service._semaphore._value == 0  # type: ignore[attr-defined]

        # Several acquire attempts that all time out.
        for _ in range(5):
            with pytest.raises(SemaphoreTimeoutError):
                await service._acquire_semaphore()

        # Slots still pinned by our two manual acquires — the timed-out
        # acquires must not have released anyone else's slot.
        assert service._semaphore._value == 0  # type: ignore[attr-defined]

        # Release the two we manually took.
        service._semaphore.release()
        service._semaphore.release()
        assert service._semaphore._value == 2  # type: ignore[attr-defined]


# =============================================================================
# P1 — Token-theft path persists deactivation (concurrency #3 / code F5 / arch #7)
# =============================================================================


class TestTokenTheftDeactivationPersisted:
    """
    When refresh-token reuse is detected, the deactivation MUST be committed to
    DB. The previous code raised inside the UoW, causing the rollback to silently
    discard the deactivation — a security failure.
    """

    async def test_revoked_token_path_does_not_raise_inside_uow(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        secret = mock_config.secret_key.get_secret_value()
        refresh_tok, token_hash = create_refresh_token(
            data={"sub": str(mock_user.id)},
            secret_key=secret,
            algorithm=mock_config.algorithm,
            expires_delta=timedelta(days=30),
        )

        # A token that was already revoked (theft scenario).
        revoked = RefreshToken(
            id=uuid4(),
            user_id=mock_user.id,
            token_hash=token_hash,
            expires_at=datetime.now(UTC) + timedelta(days=30),
            created_at=datetime.now(UTC),
            revoked_at=datetime.now(UTC) - timedelta(seconds=10),
        )

        events: list[str] = []

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)

        async def aexit(exc_type, exc_val, exc_tb):
            # Critical assertion: by the time the UoW exits, no exception
            # has been raised inside it — so the deactivation actually commits.
            events.append(f"uow_exit:{exc_type.__name__ if exc_type else 'clean'}")
            return None

        mock_uow.__aexit__ = AsyncMock(side_effect=aexit)
        mock_uow.tokens.get_by_hash_any = AsyncMock(return_value=revoked)
        mock_uow.tokens.revoke_all_for_user = AsyncMock(return_value=2)
        mock_uow.users.get_by_id = AsyncMock(return_value=mock_user)

        async def deactivate(*args, **kwargs):
            events.append("deactivate")
            return True

        mock_uow.users.deactivate = AsyncMock(side_effect=deactivate)

        mock_state_store = AsyncMock()
        mock_state_store.get = AsyncMock(return_value=None)

        service = AuthService(mock_config, MagicMock())

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.get_state_store",
                return_value=mock_state_store,
            ),
            pytest.raises(TokenInvalidError),
        ):
            await service.refresh_tokens(refresh_tok)

        # 1) Deactivation was called.
        assert "deactivate" in events
        # 2) UoW exited CLEANLY (no exception inside), so the deactivation
        #    actually committed. Previous buggy code raised TokenInvalidError
        #    inside the UoW, causing rollback and silently losing the
        #    deactivation.
        assert "uow_exit:clean" in events


# =============================================================================
# P1 — Auth cache invalidation is best-effort (no propagation on cache failure)
# =============================================================================


class TestAuthCacheInvalidationBestEffort:
    """Cache invalidation failures must not break the surrounding service call."""

    async def test_logout_succeeds_even_if_cache_invalidate_fails(
        self,
        mock_config: IdentityPlanKitConfig,
        mock_user: User,
    ) -> None:
        # A failing auth cache.
        failing_cache = AsyncMock()
        failing_cache.invalidate = AsyncMock(side_effect=RuntimeError("redis down"))

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.tokens.revoke_all_for_user = AsyncMock(return_value=1)

        service = AuthService(mock_config, MagicMock(), auth_cache=failing_cache)

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch(
                "identity_plan_kit.auth.services.auth_service.get_state_store",
                return_value=AsyncMock(),
            ),
        ):
            # Logout should NOT propagate the cache failure.
            await service.logout(user_id=mock_user.id, everywhere=True)

        # Cache.invalidate WAS attempted...
        failing_cache.invalidate.assert_called_once_with(mock_user.id)


# =============================================================================
# Smoke test for `_to_entity` mapping `user_metadata` -> `metadata`
# =============================================================================


class TestUserRepositoryEntityMapping:
    """
    `metadata` is reserved by SQLAlchemy declarative; the model uses
    `user_metadata` and the entity exposes it as `metadata`. Verify the
    repo's `_to_entity` performs the mapping correctly even though the
    base class would otherwise read the SQLAlchemy `MetaData` registry.
    """

    def test_to_entity_maps_user_metadata_to_metadata(self) -> None:
        # Synthesize a model-like object with a role.
        role_obj = MagicMock()
        role_obj.code = "user"

        model = MagicMock()
        model.id = uuid4()
        model.email = "x@y.com"
        model.role_id = uuid4()
        model.display_name = "X"
        model.picture_url = None
        model.user_metadata = {"k": "v"}
        model.is_active = True
        model.is_verified = True
        model.created_at = datetime.now(UTC)
        model.updated_at = datetime.now(UTC)
        model.role = role_obj

        repo = UserRepository(session=MagicMock())
        entity = repo._to_entity(model)

        assert entity.metadata == {"k": "v"}
        assert entity.role_code == "user"


# =============================================================================
# Bulkhead semaphore can stack-up timeouts cleanly (no resource warnings either)
# =============================================================================


class TestSemaphoreTimeoutCleanup:
    """A timeout must not leak a half-acquired semaphore reference."""

    async def test_timeout_no_pending_waiter_after_failure(
        self,
        mock_config: IdentityPlanKitConfig,
    ) -> None:
        from identity_plan_kit.auth.services.oauth_service import GoogleOAuthService

        svc = GoogleOAuthService(
            mock_config, max_concurrent_calls=1, semaphore_timeout=0.05
        )

        # Hold the only slot.
        await svc._semaphore.acquire()

        # Trigger a timeout, then yield to let asyncio cleanup waiters.
        with pytest.raises(SemaphoreTimeoutError):
            await svc._acquire_semaphore()

        await asyncio.sleep(0)  # let any cleanup complete

        # Release; the slot returns cleanly.
        svc._semaphore.release()
        # Sanity: another acquire should succeed now.
        await asyncio.wait_for(svc._semaphore.acquire(), timeout=0.5)
        svc._semaphore.release()


# =============================================================================
# OAuth error parameter is not reflected in the response detail (security S2)
# =============================================================================


class TestOAuthCallbackErrorReflection:
    """
    The `error` query parameter must not be reflected verbatim in the response.
    Old code emitted `detail=f"OAuth error: {error}"` which let an attacker
    inject content into the response body.
    """

    def test_error_param_is_not_reflected(self) -> None:
        # Validate the source code itself. We don't spin up a full FastAPI app
        # here — it's enough to check that the handler does NOT format `error`
        # into the response detail (which is the actual vector).
        from pathlib import Path

        src = Path(
            "src/identity_plan_kit/auth/handlers/oauth_routes.py"
        ).read_text()

        # The old code had `detail=f"OAuth error: {error}"`. New code must not.
        assert 'detail=f"OAuth error: {error}"' not in src
        # And it should now use a generic, safe message.
        assert (
            "Authentication was cancelled or failed" in src
            or "Authentication failed" in src
        )
