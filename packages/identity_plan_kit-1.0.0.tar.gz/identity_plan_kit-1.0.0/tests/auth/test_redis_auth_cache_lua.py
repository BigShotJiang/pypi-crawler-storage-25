"""Tests for RedisAuthCache Lua script stale-write prevention.

Tests cover:
- Lua script rejects writes when global invalidation timestamp > fetched_at
- Lua script rejects writes when key invalidation timestamp > fetched_at
- Lua script accepts writes when fetched_at > all invalidation timestamps
- Lua script accepts writes when fetched_at is "nil" (backwards compat)
- set() correctly passes arguments to Lua script via eval()
- invalidate() stores timestamp keys for Lua script to check

CRITICAL: These tests verify that the Lua script in RedisAuthCache
atomically prevents stale data from being cached after invalidation.
"""

import asyncio
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from identity_plan_kit.auth.cache.auth_cache import (
    RedisAuthCache,
    InMemoryAuthCache,
    _user_to_dict,
    _dict_to_user,
)
from identity_plan_kit.auth.domain.entities import User

pytestmark = pytest.mark.anyio


def _make_user(user_id=None, display_name="Test User") -> User:
    return User(
        id=user_id or uuid4(),
        email="test@example.com",
        role_id=uuid4(),
        display_name=display_name,
        is_active=True,
        is_verified=True,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
        role_code="user",
        permissions={"read"},
    )


class TestLuaScriptLogic:
    """Test the Lua script logic via mock Redis eval() calls.

    The Lua script checks:
    1. If fetched_at == "nil" → always accept (SETEX)
    2. If global_invalidation > fetched_at → reject (return 0)
    3. If key_invalidation > fetched_at → reject (return 0)
    4. Otherwise → accept (SETEX, return 1)
    """

    async def test_stale_write_rejected_by_global_invalidation(self):
        """Lua script returns 0 when global_inv > fetched_at."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client
                mock_client.ping = AsyncMock()

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                user = _make_user()
                # Simulate Lua script returning 0 (stale write rejected)
                mock_client.eval = AsyncMock(return_value=0)

                result = await cache.set(user.id, user, fetched_at=100.0)

                assert result is False
                # Verify eval was called with the Lua script
                mock_client.eval.assert_called_once()
                call_args = mock_client.eval.call_args
                # Args: script, num_keys, key, global_inv_key, inv_key, value, ttl, fetched_at
                assert call_args[0][0] == RedisAuthCache.LUA_SET_WITH_TIMESTAMP_CHECK
                assert call_args[0][1] == 3  # 3 keys
                # fetched_at should be passed as string "100.0"
                assert call_args[0][7] == "100.0"

    async def test_stale_write_rejected_by_key_invalidation(self):
        """Lua script returns 0 when key_inv > fetched_at."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                user = _make_user()
                mock_client.eval = AsyncMock(return_value=0)

                result = await cache.set(user.id, user, fetched_at=50.0)

                assert result is False

    async def test_fresh_write_accepted(self):
        """Lua script returns 1 when fetched_at > all invalidation timestamps."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                user = _make_user()
                mock_client.eval = AsyncMock(return_value=1)

                result = await cache.set(user.id, user, fetched_at=200.0)

                assert result is True

    async def test_nil_fetched_at_always_accepted(self):
        """Lua script accepts write when fetched_at is "nil" (backwards compat)."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                user = _make_user()
                mock_client.eval = AsyncMock(return_value=1)

                result = await cache.set(user.id, user, fetched_at=None)

                assert result is True
                # Verify "nil" is passed as fetched_at
                call_args = mock_client.eval.call_args
                assert call_args[0][7] == "nil"


class TestInvalidationStoresTimestamp:
    """Verify that invalidate() stores a timestamp key for Lua script use."""

    async def test_invalidate_stores_timestamp_key(self):
        """invalidate() must SETEX a timestamp key with 2x TTL."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client
                mock_client.setex = AsyncMock(return_value=True)
                mock_client.delete = AsyncMock(return_value=1)

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                user_id = uuid4()
                await cache.invalidate(user_id)

                # setex should be called for the invalidation timestamp key
                setex_calls = mock_client.setex.call_args_list
                assert len(setex_calls) >= 1

                # First setex call is the invalidation timestamp
                inv_call = setex_calls[0]
                inv_key = inv_call[0][0]
                inv_ttl = inv_call[0][1]

                assert f"_invalidated:{user_id}" in inv_key
                assert inv_ttl == 120  # 2x TTL (60 * 2)

    async def test_invalidate_all_stores_global_timestamp(self):
        """invalidate_all() must SETEX a global timestamp key with 2x TTL."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client
                mock_client.setex = AsyncMock(return_value=True)
                mock_client.scan = AsyncMock(return_value=(0, []))

                cache = RedisAuthCache(ttl_seconds=60)
                cache._client = mock_client

                await cache.invalidate_all()

                setex_calls = mock_client.setex.call_args_list
                assert len(setex_calls) >= 1

                # First setex call is the global invalidation timestamp
                global_call = setex_calls[0]
                global_key = global_call[0][0]
                global_ttl = global_call[0][1]

                assert "_global_invalidated" in global_key
                assert global_ttl == 120


class TestSetArgumentPassing:
    """Verify set() passes correct arguments to the Lua script."""

    async def test_set_passes_correct_keys_and_args(self):
        """set() must pass: KEYS=[data_key, global_inv_key, key_inv_key], ARGV=[value, ttl, fetched_at]."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                mock_client = AsyncMock()
                mock_redis_mod.from_url.return_value = mock_client

                cache = RedisAuthCache(
                    ttl_seconds=300,
                    key_prefix="ipk:auth:user:",
                )
                cache._client = mock_client

                user_id = uuid4()
                user = _make_user(user_id=user_id)
                mock_client.eval = AsyncMock(return_value=1)

                await cache.set(user_id, user, fetched_at=42.5)

                call_args = mock_client.eval.call_args[0]

                # arg[0]: Lua script
                assert call_args[0] == RedisAuthCache.LUA_SET_WITH_TIMESTAMP_CHECK

                # arg[1]: num keys = 3
                assert call_args[1] == 3

                # arg[2]: KEYS[1] = data key
                data_key = call_args[2]
                assert data_key == f"ipk:auth:user:{user_id}"

                # arg[3]: KEYS[2] = global invalidation key
                global_inv_key = call_args[3]
                assert global_inv_key == "ipk:auth:user:_global_invalidated"

                # arg[4]: KEYS[3] = per-key invalidation key
                key_inv_key = call_args[4]
                assert key_inv_key == f"ipk:auth:user:_invalidated:{user_id}"

                # arg[5]: ARGV[1] = serialized user JSON
                import json
                value = json.loads(call_args[5])
                assert value["id"] == str(user_id)

                # arg[6]: ARGV[2] = TTL as string
                assert call_args[6] == "300"

                # arg[7]: ARGV[3] = fetched_at as string
                assert call_args[7] == "42.5"

    async def test_disabled_cache_returns_false(self):
        """set() returns False when cache is disabled (ttl=0)."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                cache = RedisAuthCache(ttl_seconds=0)
                cache._client = AsyncMock()

                user = _make_user()
                result = await cache.set(user.id, user)

                assert result is False

    async def test_no_client_returns_false(self):
        """set() returns False when not connected."""
        with patch("identity_plan_kit.auth.cache.auth_cache.REDIS_AVAILABLE", True):
            with patch("identity_plan_kit.auth.cache.auth_cache.redis") as mock_redis_mod:
                cache = RedisAuthCache(ttl_seconds=60)
                # _client is None (not connected)

                user = _make_user()
                result = await cache.set(user.id, user)

                assert result is False
