"""Integration tests for service-level race conditions.

Tests concurrent operations through the service layer (not just repository),
validating that FOR UPDATE locks, cache invalidation ordering, and stampede
protection work correctly end-to-end.

Covers:
- Concurrent assign_plan with expire_current=True (P0: duplicate active plans)
- Concurrent extend_plan (P2: FOR UPDATE serialization)
- Service-level concurrent quota consumption (cache + DB interaction)
"""

import asyncio
from datetime import date, timedelta
from uuid import UUID

import pytest
from sqlalchemy import select, func, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
)

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.domain.exceptions import (
    PlanNotFoundError,
    QuotaExceededError,
    UserPlanNotFoundError,
)
from identity_plan_kit.plans.models.feature_usage import FeatureUsageModel
from identity_plan_kit.plans.models.user_plan import UserPlanModel
from identity_plan_kit.plans.services.plan_service import PlanService

# Skip if testcontainers not available
pytest.importorskip("testcontainers")


async def create_service_test_infrastructure(
    session: AsyncSession,
    suffix: str,
) -> tuple[UUID, str, str, str]:
    """Create test data and return (user_id, free_plan_code, pro_plan_code, feature_code)."""
    from identity_plan_kit.auth.models.user import UserModel
    from identity_plan_kit.plans.models.feature import FeatureModel
    from identity_plan_kit.plans.models.plan import PlanModel
    from identity_plan_kit.plans.models.plan_limit import PlanLimitModel
    from identity_plan_kit.rbac.models.role import RoleModel

    role = RoleModel(code=f"user_{suffix}", name="Test Role")
    session.add(role)
    await session.flush()

    user = UserModel(
        email=f"svc_test_{suffix}@example.com",
        role_id=role.id,
        display_name=f"Service Test {suffix}",
        is_active=True,
        is_verified=True,
    )
    session.add(user)
    await session.flush()

    free_code = f"free_{suffix}"
    pro_code = f"pro_{suffix}"
    feature_code = f"api_calls_{suffix}"

    free_plan = PlanModel(code=free_code, name="Free Plan")
    pro_plan = PlanModel(code=pro_code, name="Pro Plan")
    session.add(free_plan)
    session.add(pro_plan)
    await session.flush()

    feature = FeatureModel(code=feature_code, name="API Calls")
    session.add(feature)
    await session.flush()

    free_limit = PlanLimitModel(
        plan_id=free_plan.id,
        feature_id=feature.id,
        feature_limit=100,
        period="daily",
    )
    pro_limit = PlanLimitModel(
        plan_id=pro_plan.id,
        feature_id=feature.id,
        feature_limit=1000,
        period="daily",
    )
    session.add(free_limit)
    session.add(pro_limit)
    await session.flush()

    return user.id, free_code, pro_code, feature_code


def create_test_config(database_url: str) -> IdentityPlanKitConfig:
    """Create a minimal config for testing."""
    return IdentityPlanKitConfig(
        database_url=database_url,
        secret_key="test-secret-key-that-is-at-least-32-characters-long",
        google_client_id="test-client-id",
        google_client_secret="test-client-secret",
        google_redirect_uri="http://localhost/callback",
        quota_idempotency_ttl_seconds=0,
    )


class TestConcurrentAssignPlanWithExpireCurrent:
    """Tests for concurrent assign_plan with expire_current=True.

    CRITICAL: Two concurrent assign_plan calls with expire_current=True must
    result in exactly ONE active plan, not duplicates.
    """

    async def test_concurrent_assign_plan_serialized_by_for_update(
        self,
        db_engine: AsyncEngine,
        database_url: str,
    ) -> None:
        """
        Concurrent assign_plan(expire_current=True) must serialize via FOR UPDATE.

        Without FOR UPDATE, both calls could read the same active plan,
        both expire it, and both create new plans → duplicate active plans.
        With FOR UPDATE, the second call blocks until the first commits.
        """
        session_factory = async_sessionmaker(
            db_engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        # Setup: create user with an initial free plan
        async with session_factory() as setup_session:
            async with setup_session.begin():
                user_id, free_code, pro_code, feature_code = (
                    await create_service_test_infrastructure(
                        setup_session, f"assign_expire_{id(db_engine)}"
                    )
                )

        config = create_test_config(database_url)

        # Assign initial plan
        service = PlanService(
            config=config,
            session_factory=session_factory,
            plan_cache_ttl_seconds=0,
            user_plan_cache_ttl_seconds=0,
        )
        await service.assign_plan(user_id=user_id, plan_code=free_code)

        # Now fire concurrent upgrades to pro
        async def upgrade_to_pro(attempt: int) -> object:
            svc = PlanService(
                config=config,
                session_factory=session_factory,
                plan_cache_ttl_seconds=0,
                user_plan_cache_ttl_seconds=0,
            )
            return await svc.assign_plan(
                user_id=user_id,
                plan_code=pro_code,
                expire_current=True,
            )

        tasks = [upgrade_to_pro(i) for i in range(5)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Count results
        successes = [r for r in results if not isinstance(r, Exception)]
        errors = [r for r in results if isinstance(r, Exception)]

        # At least one should succeed
        assert len(successes) >= 1, f"No successful assignments. Errors: {errors}"

        # CRITICAL: Verify only ONE active plan exists
        async with session_factory() as verify_session:
            today = date.today()
            result = await verify_session.execute(
                select(func.count(UserPlanModel.id)).where(
                    UserPlanModel.user_id == user_id,
                    UserPlanModel.started_at <= today,
                    UserPlanModel.ends_at >= today,
                    UserPlanModel.is_cancelled == False,  # noqa: E712
                )
            )
            active_count = result.scalar()

        # With FOR UPDATE, concurrent calls are serialized:
        # - First caller locks the active plan row, expires it, creates new
        # - Second caller waits, then reads the new plan (or finds no plan to expire)
        # All succeed, but only the latest plan should be active
        # (previous ones got expired by subsequent calls)
        assert active_count == 1, (
            f"RACE CONDITION: Expected exactly 1 active plan, found {active_count}. "
            f"Concurrent assign_plan created duplicate active plans!"
        )


class TestConcurrentExtendPlan:
    """Tests for concurrent extend_plan operations."""

    async def test_concurrent_extend_plan_serialized(
        self,
        db_engine: AsyncEngine,
        database_url: str,
    ) -> None:
        """
        Concurrent extend_plan calls should be serialized by FOR UPDATE.
        The last writer wins, and the final date should be one of the requested dates.
        """
        session_factory = async_sessionmaker(
            db_engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        async with session_factory() as setup_session:
            async with setup_session.begin():
                user_id, free_code, _, _ = await create_service_test_infrastructure(
                    setup_session, f"extend_{id(db_engine)}"
                )

        config = create_test_config(database_url)
        service = PlanService(
            config=config,
            session_factory=session_factory,
            plan_cache_ttl_seconds=0,
            user_plan_cache_ttl_seconds=0,
        )

        # Assign initial plan
        await service.assign_plan(user_id=user_id, plan_code=free_code)

        # Fire concurrent extensions with different dates
        dates = [
            date.today() + timedelta(days=30 + i * 10)
            for i in range(5)
        ]

        async def extend(new_date: date) -> object:
            svc = PlanService(
                config=config,
                session_factory=session_factory,
                plan_cache_ttl_seconds=0,
                user_plan_cache_ttl_seconds=0,
            )
            return await svc.extend_plan(user_id=user_id, new_ends_at=new_date)

        tasks = [extend(d) for d in dates]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        successes = [r for r in results if not isinstance(r, Exception)]
        assert len(successes) >= 1, "At least one extension should succeed"

        # Verify plan has a valid end date (one of the requested dates)
        async with session_factory() as verify_session:
            result = await verify_session.execute(
                select(UserPlanModel.ends_at).where(
                    UserPlanModel.user_id == user_id,
                    UserPlanModel.is_cancelled == False,  # noqa: E712
                ).order_by(UserPlanModel.id.desc()).limit(1)
            )
            final_ends_at = result.scalar_one()

        assert final_ends_at in dates, (
            f"Final ends_at ({final_ends_at}) should be one of the requested dates"
        )


class TestConcurrentServiceQuota:
    """Tests for service-level concurrent quota consumption.

    Unlike test_quota_concurrency.py which tests the repository directly,
    these tests go through PlanService.check_and_consume_quota to validate
    the full stack: cache lookups, idempotency, and atomic DB operations.
    """

    async def test_concurrent_quota_never_exceeds_limit(
        self,
        db_engine: AsyncEngine,
        database_url: str,
    ) -> None:
        """
        Concurrent check_and_consume_quota through the service must never
        allow total usage to exceed the plan limit.
        """
        session_factory = async_sessionmaker(
            db_engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        async with session_factory() as setup_session:
            async with setup_session.begin():
                user_id, free_code, _, feature_code = (
                    await create_service_test_infrastructure(
                        setup_session, f"quota_svc_{id(db_engine)}"
                    )
                )

        config = create_test_config(database_url)

        # Assign plan first
        service = PlanService(
            config=config,
            session_factory=session_factory,
            plan_cache_ttl_seconds=0,
            user_plan_cache_ttl_seconds=0,
        )
        await service.assign_plan(user_id=user_id, plan_code=free_code)

        # Fire 20 concurrent consumption requests (each consuming 10, limit=100)
        async def consume(attempt: int) -> tuple[bool, int]:
            svc = PlanService(
                config=config,
                session_factory=session_factory,
                plan_cache_ttl_seconds=0,
                user_plan_cache_ttl_seconds=0,
            )
            try:
                result = await svc.check_and_consume_quota(
                    user_id=user_id,
                    feature_code=feature_code,
                    amount=10,
                )
                return (True, result.used)
            except QuotaExceededError:
                return (False, 0)

        tasks = [consume(i) for i in range(20)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        successes = [r for r in results if isinstance(r, tuple) and r[0]]
        failures = [r for r in results if isinstance(r, tuple) and not r[0]]
        exceptions = [r for r in results if isinstance(r, Exception)]

        # CRITICAL: Verify total usage never exceeds limit
        async with session_factory() as verify_session:
            result = await verify_session.execute(
                select(FeatureUsageModel.feature_usage).where(
                    FeatureUsageModel.user_plan_id.isnot(None),
                ).order_by(FeatureUsageModel.id.desc()).limit(1)
            )
            # Get the max usage from the user's plan
            all_usage = await verify_session.execute(
                text("""
                    SELECT fu.feature_usage
                    FROM feature_usage fu
                    JOIN user_plans up ON fu.user_plan_id = up.id
                    WHERE up.user_id = :user_id
                """).bindparams(user_id=user_id)
            )
            rows = all_usage.fetchall()
            total_usage = sum(row[0] for row in rows) if rows else 0

        assert total_usage <= 100, (
            f"CRITICAL: Usage ({total_usage}) exceeded limit (100)! "
            f"Service-level TOCTOU vulnerability!"
        )

        # Exactly 10 should succeed (10 * 10 = 100), 10 should fail
        assert len(successes) == 10, (
            f"Expected 10 successes, got {len(successes)} "
            f"(failures={len(failures)}, exceptions={len(exceptions)})"
        )
        assert total_usage == 100, f"Expected total usage of 100, got {total_usage}"
