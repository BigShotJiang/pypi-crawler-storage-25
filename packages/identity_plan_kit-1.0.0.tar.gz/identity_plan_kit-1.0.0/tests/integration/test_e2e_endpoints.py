"""End-to-end integration tests for all IdentityPlanKit HTTP endpoints.

Tests hit real FastAPI endpoints with a real PostgreSQL database via testcontainers.
Covers all auth, profile, plans, and health endpoints with happy paths, edge cases,
and error scenarios.

Key bugs validated:
- Ellipsis sentinel mismatch between handler/service/repo (picture_url/metadata)
- Profile update with only display_name should not corrupt other fields
- MetadataValidationError returns 422 (not 401)
- PasswordValidationError returns 422 (not 401)
"""

from __future__ import annotations

from datetime import date, timedelta
from uuid import UUID, uuid4

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

pytest.importorskip("testcontainers")

from fastapi import FastAPI, Request, Response
from testcontainers.postgres import PostgresContainer

from identity_plan_kit import IdentityPlanKit
from identity_plan_kit.auth.dependencies import CurrentUser
from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.dependencies import FeatureUsage, requires_plan
from identity_plan_kit.shared.database import Base
from identity_plan_kit.shared.graceful_shutdown import ServiceMode, get_shutdown_state
from identity_plan_kit.shared.security import create_access_token

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(scope="module")
def postgres_container():
    container = PostgresContainer("postgres:15-alpine")
    container.start()
    yield container
    container.stop()


@pytest.fixture(scope="module")
def database_url(postgres_container: PostgresContainer) -> str:
    sync_url = postgres_container.get_connection_url()
    return sync_url.replace("psycopg2", "asyncpg")


@pytest.fixture
async def db_engine(database_url: str):
    engine = create_async_engine(database_url, echo=False, pool_size=10, max_overflow=20)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest.fixture
def session_factory(db_engine: AsyncEngine) -> async_sessionmaker[AsyncSession]:
    return async_sessionmaker(db_engine, class_=AsyncSession, expire_on_commit=False)


@pytest.fixture
def config(database_url: str) -> IdentityPlanKitConfig:
    return IdentityPlanKitConfig(
        database_url=database_url,
        secret_key="test-secret-key-at-least-32-characters-long-for-development",
        google_client_id="test-client-id",
        google_client_secret="test-client-secret",
        google_redirect_uri="http://localhost:8000/auth/google/callback",
        rate_limit_login="1000/minute",
        rate_limit_callback="1000/minute",
        rate_limit_refresh="1000/minute",
        rate_limit_logout="1000/minute",
        rate_limit_profile="1000/minute",
        rate_limit_plans="1000/minute",
        cookie_secure=False,
        auth_cache_ttl_seconds=0,
        enable_usage_tracking=True,
    )


@pytest.fixture
async def kit(config: IdentityPlanKitConfig, session_factory):
    # Reset global shutdown state from any prior test
    state = get_shutdown_state()
    state.mode = ServiceMode.NORMAL
    state.shutdown_started_at = None

    k = IdentityPlanKit(config, session_factory=session_factory)
    await k.startup()
    yield k
    await k.shutdown()


@pytest.fixture
def app(kit: IdentityPlanKit) -> FastAPI:
    app = FastAPI()
    kit.setup(app, include_health_routes=True)

    @app.get("/test/requires-plan")
    async def test_requires_plan(
        user: CurrentUser,
        _=requires_plan(),
    ):
        return {"ok": True}

    @app.get("/test/requires-specific-plan")
    async def test_requires_specific_plan(
        user: CurrentUser,
        _=requires_plan("pro"),
    ):
        return {"ok": True}

    @app.post("/test/consume-feature")
    async def test_consume_feature(
        request: Request,
        response: Response,
        user: CurrentUser,
        usage: FeatureUsage("api_calls", consume=1),
    ):
        return {
            "used": usage.used,
            "limit": usage.limit,
            "remaining": usage.remaining,
            "period": usage.period,
        }

    @app.get("/test/check-feature")
    async def test_check_feature(
        request: Request,
        response: Response,
        user: CurrentUser,
        usage: FeatureUsage("api_calls", consume=0),
    ):
        return {
            "used": usage.used,
            "limit": usage.limit,
            "remaining": usage.remaining,
        }

    @app.get("/test/check-nonexistent-feature")
    async def test_check_nonexistent_feature(
        request: Request,
        response: Response,
        user: CurrentUser,
        usage: FeatureUsage("nonexistent_feature", consume=0),
    ):
        return {"ok": True}

    return app


@pytest.fixture
async def client(app: FastAPI):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def seed_data(session_factory) -> dict:
    """Seed roles, permissions, plans, features, plan_limits, and test users."""
    async with session_factory() as session:
        async with session.begin():
            # Roles
            await session.execute(
                text("INSERT INTO roles (id, code, name) VALUES (gen_random_uuid(), 'user', 'User')")
            )
            await session.execute(
                text("INSERT INTO roles (id, code, name) VALUES (gen_random_uuid(), 'admin', 'Admin')")
            )
            role_row = await session.execute(text("SELECT id FROM roles WHERE code = 'user'"))
            role_id = role_row.scalar_one()
            admin_role_row = await session.execute(text("SELECT id FROM roles WHERE code = 'admin'"))
            admin_role_id = admin_role_row.scalar_one()

            # Permissions
            await session.execute(
                text(
                    "INSERT INTO permissions (id, code, type) VALUES "
                    "(gen_random_uuid(), 'movies:read', 'role'), "
                    "(gen_random_uuid(), 'movies:write', 'role'), "
                    "(gen_random_uuid(), 'exports:read', 'plan')"
                )
            )
            perm_rows = await session.execute(
                text("SELECT id FROM permissions WHERE type = 'role'")
            )
            for pid in [r[0] for r in perm_rows.fetchall()]:
                await session.execute(
                    text(
                        "INSERT INTO role_permissions (id, role_id, permission_id) "
                        "VALUES (gen_random_uuid(), :rid, :pid)"
                    ).bindparams(rid=role_id, pid=pid)
                )

            # Plans: free and pro
            await session.execute(
                text("INSERT INTO plans (id, code, name) VALUES (gen_random_uuid(), 'free', 'Free Plan')")
            )
            await session.execute(
                text("INSERT INTO plans (id, code, name) VALUES (gen_random_uuid(), 'pro', 'Pro Plan')")
            )
            plan_id = (await session.execute(text("SELECT id FROM plans WHERE code = 'free'"))).scalar_one()
            pro_plan_id = (await session.execute(text("SELECT id FROM plans WHERE code = 'pro'"))).scalar_one()

            # Plan permission
            plan_perm_id = (
                await session.execute(text("SELECT id FROM permissions WHERE code = 'exports:read'"))
            ).scalar_one()
            await session.execute(
                text(
                    "INSERT INTO plan_permissions (id, plan_id, permission_id) "
                    "VALUES (gen_random_uuid(), :plan_id, :perm_id)"
                ).bindparams(plan_id=plan_id, perm_id=plan_perm_id)
            )

            # Features
            await session.execute(
                text("INSERT INTO features (id, code, name) VALUES (gen_random_uuid(), 'api_calls', 'API Calls')")
            )
            await session.execute(
                text("INSERT INTO features (id, code, name) VALUES (gen_random_uuid(), 'exports', 'Exports')")
            )
            feature_id = (
                await session.execute(text("SELECT id FROM features WHERE code = 'api_calls'"))
            ).scalar_one()
            exports_feature_id = (
                await session.execute(text("SELECT id FROM features WHERE code = 'exports'"))
            ).scalar_one()

            # Plan limits: free plan gets 100 daily api_calls, 5 daily exports
            await session.execute(
                text(
                    "INSERT INTO plan_limits (id, plan_id, feature_id, feature_limit, period) "
                    "VALUES (gen_random_uuid(), :plan_id, :feat_id, 100, 'daily')"
                ).bindparams(plan_id=plan_id, feat_id=feature_id)
            )
            await session.execute(
                text(
                    "INSERT INTO plan_limits (id, plan_id, feature_id, feature_limit, period) "
                    "VALUES (gen_random_uuid(), :plan_id, :feat_id, 5, 'daily')"
                ).bindparams(plan_id=plan_id, feat_id=exports_feature_id)
            )

            # Pro plan: unlimited api_calls
            await session.execute(
                text(
                    "INSERT INTO plan_limits (id, plan_id, feature_id, feature_limit, period) "
                    "VALUES (gen_random_uuid(), :plan_id, :feat_id, -1, 'daily')"
                ).bindparams(plan_id=pro_plan_id, feat_id=feature_id)
            )

            # Test user (active, with picture)
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, picture_url, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'test@example.com', :role_id, 'Test User', "
                    "'https://example.com/pic.jpg', true, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'test@example.com'"))
            ).scalar_one()

            # User plan for test user
            await session.execute(
                text(
                    "INSERT INTO user_plans (id, user_id, plan_id, started_at, ends_at, "
                    "custom_limits, is_cancelled) "
                    "VALUES (gen_random_uuid(), :uid, :pid, :start, :end, '{}', false)"
                ).bindparams(
                    uid=user_id,
                    pid=plan_id,
                    start=date.today(),
                    end=date.today() + timedelta(days=30),
                )
            )

            # Inactive user
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'inactive@example.com', :role_id, "
                    "'Inactive', false, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            inactive_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'inactive@example.com'"))
            ).scalar_one()

            # User with metadata
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, metadata, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'meta@example.com', :role_id, "
                    "'Meta User', '{\"theme\": \"dark\", \"lang\": \"en\"}'::jsonb, "
                    "true, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            meta_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'meta@example.com'"))
            ).scalar_one()

            # User plan for meta user
            await session.execute(
                text(
                    "INSERT INTO user_plans (id, user_id, plan_id, started_at, ends_at, "
                    "custom_limits, is_cancelled) "
                    "VALUES (gen_random_uuid(), :uid, :pid, :start, :end, '{}', false)"
                ).bindparams(
                    uid=meta_user_id,
                    pid=plan_id,
                    start=date.today(),
                    end=date.today() + timedelta(days=30),
                )
            )

            # User without any plan
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'noplan@example.com', :role_id, "
                    "'No Plan', true, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            noplan_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'noplan@example.com'"))
            ).scalar_one()

            # User with expired plan
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'expired@example.com', :role_id, "
                    "'Expired Plan', true, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            expired_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'expired@example.com'"))
            ).scalar_one()

            # Expired user plan (ended yesterday)
            await session.execute(
                text(
                    "INSERT INTO user_plans (id, user_id, plan_id, started_at, ends_at, "
                    "custom_limits, is_cancelled) "
                    "VALUES (gen_random_uuid(), :uid, :pid, :start, :end, '{}', false)"
                ).bindparams(
                    uid=expired_user_id,
                    pid=plan_id,
                    start=date.today() - timedelta(days=31),
                    end=date.today() - timedelta(days=1),
                )
            )

            # User with nearly exhausted quota
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'quota@example.com', :role_id, "
                    "'Quota User', true, true, now(), now())"
                ).bindparams(role_id=role_id)
            )
            quota_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'quota@example.com'"))
            ).scalar_one()

            # Plan for quota user
            await session.execute(
                text(
                    "INSERT INTO user_plans (id, user_id, plan_id, started_at, ends_at, "
                    "custom_limits, is_cancelled) "
                    "VALUES (gen_random_uuid(), :uid, :pid, :start, :end, '{}', false)"
                ).bindparams(
                    uid=quota_user_id,
                    pid=plan_id,
                    start=date.today(),
                    end=date.today() + timedelta(days=30),
                )
            )
            quota_user_plan_id = (
                await session.execute(
                    text("SELECT id FROM user_plans WHERE user_id = :uid").bindparams(uid=quota_user_id)
                )
            ).scalar_one()

            # Pre-seed usage at 99/100
            await session.execute(
                text(
                    "INSERT INTO feature_usage (id, user_plan_id, feature_id, feature_usage, "
                    "start_period, end_period) "
                    "VALUES (gen_random_uuid(), :upid, :fid, 99, :start, :end)"
                ).bindparams(
                    upid=quota_user_plan_id,
                    fid=feature_id,
                    start=date.today(),
                    end=date.today(),
                )
            )

            # Admin user (for password management tests)
            await session.execute(
                text(
                    "INSERT INTO users (id, email, role_id, display_name, "
                    "is_active, is_verified, created_at, updated_at) "
                    "VALUES (gen_random_uuid(), 'admin@example.com', :role_id, "
                    "'Admin User', true, true, now(), now())"
                ).bindparams(role_id=admin_role_id)
            )
            admin_user_id = (
                await session.execute(text("SELECT id FROM users WHERE email = 'admin@example.com'"))
            ).scalar_one()

    return {
        "role_id": role_id,
        "admin_role_id": admin_role_id,
        "plan_id": plan_id,
        "pro_plan_id": pro_plan_id,
        "feature_id": feature_id,
        "exports_feature_id": exports_feature_id,
        "user_id": user_id,
        "inactive_user_id": inactive_user_id,
        "meta_user_id": meta_user_id,
        "noplan_user_id": noplan_user_id,
        "expired_user_id": expired_user_id,
        "quota_user_id": quota_user_id,
        "quota_user_plan_id": quota_user_plan_id,
        "admin_user_id": admin_user_id,
    }


SECRET = "test-secret-key-at-least-32-characters-long-for-development"


def _make_token(user_id: UUID, expired: bool = False) -> str:
    delta = timedelta(minutes=-5) if expired else timedelta(minutes=15)
    return create_access_token(
        data={"sub": str(user_id)},
        secret_key=SECRET,
        algorithm="HS256",
        expires_delta=delta,
    )


def _auth(user_id: UUID) -> dict[str, str]:
    return {"Authorization": f"Bearer {_make_token(user_id)}"}


# =============================================================================
# Health Endpoints
# =============================================================================


class TestHealthEndpoints:
    async def test_liveness(self, client: AsyncClient, seed_data):
        resp = await client.get("/health/live")
        assert resp.status_code == 200
        assert resp.json()["status"] == "alive"

    async def test_readiness(self, client: AsyncClient, seed_data):
        resp = await client.get("/health/ready")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ready"

    async def test_full_health(self, client: AsyncClient, seed_data):
        resp = await client.get("/health")
        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] in ("healthy", "degraded")
        assert "components" in body
        assert "uptime_seconds" in body
        assert "version" in body
        assert "timestamp" in body

    async def test_health_has_components(self, client: AsyncClient, seed_data):
        resp = await client.get("/health")
        body = resp.json()
        assert len(body["components"]) >= 1

    async def test_liveness_during_shutdown(self, client: AsyncClient, seed_data):
        """Liveness should still return 200 even during graceful shutdown."""
        state = get_shutdown_state()
        original_mode = state.mode
        state.mode = ServiceMode.DRAINING
        try:
            resp = await client.get("/health/live")
            # During draining, the middleware blocks ALL requests with 503
            assert resp.status_code == 503
        finally:
            state.mode = original_mode


# =============================================================================
# Graceful Shutdown
# =============================================================================


class TestGracefulShutdown:
    async def test_503_during_draining(self, client: AsyncClient, seed_data):
        state = get_shutdown_state()
        original_mode = state.mode
        state.mode = ServiceMode.DRAINING
        try:
            resp = await client.get("/auth/me", headers=_auth(seed_data["user_id"]))
            assert resp.status_code == 503
            body = resp.json()
            assert "shutting down" in body["error"].lower()
            assert resp.headers.get("Retry-After") == "30"
        finally:
            state.mode = original_mode

    async def test_503_during_shutdown(self, client: AsyncClient, seed_data):
        state = get_shutdown_state()
        original_mode = state.mode
        state.mode = ServiceMode.SHUTDOWN
        try:
            resp = await client.get("/plans")
            assert resp.status_code == 503
        finally:
            state.mode = original_mode


# =============================================================================
# GET /auth/me
# =============================================================================


class TestGetMe:
    async def test_returns_user(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["email"] == "test@example.com"
        assert data["displayName"] == "Test User"
        assert data["isActive"] is True
        assert data["roleCode"] == "user"
        assert data["isVerified"] is True
        assert "id" in data
        assert "createdAt" in data

    async def test_no_token_401(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me")
        assert resp.status_code == 401

    async def test_invalid_token_401(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers={"Authorization": "Bearer garbage"})
        assert resp.status_code == 401

    async def test_expired_token_401(self, client: AsyncClient, seed_data):
        token = _make_token(seed_data["user_id"], expired=True)
        resp = await client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 401

    async def test_inactive_user_403(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["inactive_user_id"]))
        assert resp.status_code == 403

    async def test_cookie_auth(self, client: AsyncClient, seed_data):
        token = _make_token(seed_data["user_id"])
        client.cookies.set("access_token", token)
        resp = await client.get("/auth/me")
        assert resp.status_code == 200
        assert resp.json()["data"]["email"] == "test@example.com"
        client.cookies.clear()

    async def test_nonexistent_user_401(self, client: AsyncClient, seed_data):
        fake_id = uuid4()
        resp = await client.get("/auth/me", headers=_auth(fake_id))
        assert resp.status_code == 401

    async def test_malformed_bearer_prefix(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers={"Authorization": "Token abc123"})
        assert resp.status_code == 401

    async def test_empty_bearer_token(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers={"Authorization": "Bearer "})
        assert resp.status_code == 401

    async def test_user_with_metadata(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["meta_user_id"]))
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["metadata"]["theme"] == "dark"
        assert data["metadata"]["lang"] == "en"

    async def test_user_without_picture(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["noplan_user_id"]))
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["pictureUrl"] is None


# =============================================================================
# GET /auth/profile
# =============================================================================


class TestGetProfile:
    async def test_returns_profile_with_permissions_and_plan(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["email"] == "test@example.com"
        assert isinstance(data["userPermissions"], list)
        assert len(data["userPermissions"]) >= 1
        assert data["plan"] is not None
        assert data["plan"]["code"] == "free"
        assert data["plan"]["isActive"] is True

    async def test_no_token_401(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile")
        assert resp.status_code == 401

    async def test_user_without_plan(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["noplan_user_id"]))
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["plan"] is None
        assert data["email"] == "noplan@example.com"

    async def test_profile_permissions_sorted(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["user_id"]))
        data = resp.json()["data"]
        perms = data["userPermissions"]
        assert perms == sorted(perms)

    async def test_profile_plan_permissions_sorted(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["user_id"]))
        data = resp.json()["data"]
        plan_perms = data["plan"]["permissions"]
        assert plan_perms == sorted(plan_perms)

    async def test_inactive_user_403(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["inactive_user_id"]))
        assert resp.status_code == 403


# =============================================================================
# PATCH /auth/profile — Ellipsis bug regression tests + edge cases
# =============================================================================


class TestUpdateProfile:
    async def test_update_display_name_only(self, client: AsyncClient, seed_data):
        """Regression: updating only display_name must NOT send Ellipsis to DB."""
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "New Name"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["displayName"] == "New Name"
        assert data["pictureUrl"] == "https://example.com/pic.jpg"

    async def test_update_display_name_preserves_metadata(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "Updated Meta"},
            headers=_auth(seed_data["meta_user_id"]),
        )
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["displayName"] == "Updated Meta"
        assert data["metadata"]["theme"] == "dark"
        assert data["metadata"]["lang"] == "en"

    async def test_update_picture_url(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"pictureUrl": "https://new-pic.com/avatar.png"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["pictureUrl"] == "https://new-pic.com/avatar.png"

    async def test_clear_picture_url(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"pictureUrl": ""},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["pictureUrl"] is None

    async def test_merge_metadata(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": {"new_key": "value"}},
            headers=_auth(seed_data["meta_user_id"]),
        )
        assert resp.status_code == 200
        meta = resp.json()["data"]["metadata"]
        assert meta["new_key"] == "value"
        assert "theme" in meta

    async def test_clear_metadata(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": None},
            headers=_auth(seed_data["meta_user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["metadata"] == {}

    async def test_update_all_fields(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={
                "displayName": "Full Update",
                "pictureUrl": "https://full.com/pic.png",
                "metadata": {"key": "val"},
            },
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["displayName"] == "Full Update"
        assert data["pictureUrl"] == "https://full.com/pic.png"
        assert data["metadata"]["key"] == "val"

    async def test_empty_body_400(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 400

    async def test_no_token_401(self, client: AsyncClient, seed_data):
        resp = await client.patch("/auth/profile", json={"displayName": "X"})
        assert resp.status_code == 401

    async def test_display_name_too_long(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "x" * 101},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422

    async def test_display_name_empty_string(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": ""},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422

    async def test_picture_url_too_long(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"pictureUrl": "https://x.com/" + "a" * 500},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422

    async def test_metadata_too_many_keys(self, client: AsyncClient, seed_data):
        big_meta = {f"key_{i}": f"val_{i}" for i in range(51)}
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": big_meta},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422

    async def test_inactive_user_403(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "Should Fail"},
            headers=_auth(seed_data["inactive_user_id"]),
        )
        assert resp.status_code == 403

    async def test_metadata_large_payload_422(self, client: AsyncClient, seed_data):
        """Metadata exceeding 16KB should be rejected."""
        large_meta = {"key": "x" * 20000}
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": large_meta},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422

    async def test_metadata_nested_objects(self, client: AsyncClient, seed_data):
        """Nested metadata should be accepted if within size limits."""
        nested_meta = {
            "preferences": {"theme": "dark", "font_size": 14},
            "settings": {"notifications": True},
        }
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": nested_meta},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        meta = resp.json()["data"]["metadata"]
        assert meta["preferences"]["theme"] == "dark"

    async def test_metadata_empty_dict_treated_as_no_update(self, client: AsyncClient, seed_data):
        """Empty metadata dict {} should merge (no-op), not clear."""
        # First set some metadata
        await client.patch(
            "/auth/profile",
            json={"metadata": {"existing": "data"}},
            headers=_auth(seed_data["user_id"]),
        )
        # Then send empty dict
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": {}},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        meta = resp.json()["data"]["metadata"]
        assert "existing" in meta

    async def test_display_name_exactly_100_chars(self, client: AsyncClient, seed_data):
        name = "x" * 100
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": name},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == name

    async def test_display_name_exactly_1_char(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "A"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == "A"

    async def test_display_name_with_unicode(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "Тест Юзер"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == "Тест Юзер"

    async def test_display_name_with_emoji(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "User 🎉"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == "User 🎉"

    async def test_metadata_with_numeric_values(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": {"count": 42, "ratio": 3.14, "flag": True}},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        meta = resp.json()["data"]["metadata"]
        assert meta["count"] == 42
        assert meta["ratio"] == 3.14
        assert meta["flag"] is True

    async def test_metadata_exactly_50_keys(self, client: AsyncClient, seed_data):
        meta = {f"key_{i}": f"val_{i}" for i in range(50)}
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": meta},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200

    async def test_picture_url_exactly_500_chars(self, client: AsyncClient, seed_data):
        url = "https://x.com/" + "a" * (500 - len("https://x.com/"))
        resp = await client.patch(
            "/auth/profile",
            json={"pictureUrl": url},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200

    async def test_unknown_fields_ignored(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "Valid", "unknown_field": "ignored"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == "Valid"

    async def test_wrong_content_type(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            content="displayName=test",
            headers={**_auth(seed_data["user_id"]), "Content-Type": "text/plain"},
        )
        assert resp.status_code == 422


# =============================================================================
# GET /auth/google/login
# =============================================================================


class TestGoogleLogin:
    async def test_returns_oauth_url(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/google/login")
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert "url" in data
        assert "accounts.google.com" in data["url"]
        assert "state" in data

    async def test_invalid_redirect_url_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/login",
            params={"redirect_url": "https://evil.com/steal"},
        )
        assert resp.status_code == 400

    async def test_state_is_unique_per_request(self, client: AsyncClient, seed_data):
        resp1 = await client.get("/auth/google/login")
        resp2 = await client.get("/auth/google/login")
        assert resp1.json()["data"]["state"] != resp2.json()["data"]["state"]


# =============================================================================
# POST /auth/refresh
# =============================================================================


class TestRefreshToken:
    async def test_no_cookie_401(self, client: AsyncClient, seed_data):
        resp = await client.post("/auth/refresh")
        assert resp.status_code == 401
        body = resp.json()
        assert body["success"] is False
        assert "not provided" in body["error"]["message"].lower()

    async def test_invalid_refresh_token_401(self, client: AsyncClient, seed_data):
        client.cookies.set("refresh_token", "invalid-token-value")
        resp = await client.post("/auth/refresh")
        assert resp.status_code == 401
        client.cookies.clear()

    async def test_garbage_jwt_refresh_token_401(self, client: AsyncClient, seed_data):
        client.cookies.set("refresh_token", "eyJhbGciOiJIUzI1NiJ9.garbage.invalid")
        resp = await client.post("/auth/refresh")
        assert resp.status_code == 401
        client.cookies.clear()


# =============================================================================
# POST /auth/logout
# =============================================================================


class TestLogout:
    async def test_no_token_401(self, client: AsyncClient, seed_data):
        resp = await client.post("/auth/logout")
        assert resp.status_code == 401

    async def test_logout_with_valid_token(self, client: AsyncClient, seed_data):
        resp = await client.post("/auth/logout", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 204

    async def test_logout_inactive_user_403(self, client: AsyncClient, seed_data):
        resp = await client.post("/auth/logout", headers=_auth(seed_data["inactive_user_id"]))
        assert resp.status_code == 403

    async def test_logout_expired_token_401(self, client: AsyncClient, seed_data):
        token = _make_token(seed_data["user_id"], expired=True)
        resp = await client.post("/auth/logout", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 401


# =============================================================================
# GET /plans
# =============================================================================


class TestGetAllPlans:
    async def test_returns_plans(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        assert resp.status_code == 200
        plans = resp.json()["data"]["plans"]
        assert len(plans) >= 2
        free_plan = next(p for p in plans if p["code"] == "free")
        assert free_plan["name"] == "Free Plan"
        assert len(free_plan["limits"]) >= 1
        api_limit = next(l for l in free_plan["limits"] if l["featureCode"] == "api_calls")
        assert api_limit["limit"] == 100
        assert api_limit["period"] == "daily"

    async def test_plan_permissions(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        free_plan = next(p for p in resp.json()["data"]["plans"] if p["code"] == "free")
        assert "exports:read" in free_plan["permissions"]

    async def test_public_endpoint_no_auth_required(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        assert resp.status_code == 200

    async def test_pro_plan_unlimited_feature(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        pro_plan = next(p for p in resp.json()["data"]["plans"] if p["code"] == "pro")
        api_limit = next(l for l in pro_plan["limits"] if l["featureCode"] == "api_calls")
        assert api_limit["limit"] == -1

    async def test_plans_have_ids(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        for plan in resp.json()["data"]["plans"]:
            assert "id" in plan


# =============================================================================
# GET /plans/features
# =============================================================================


class TestGetAllFeatures:
    async def test_returns_features(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans/features")
        assert resp.status_code == 200
        features = resp.json()["data"]["features"]
        assert len(features) >= 2
        codes = [f["code"] for f in features]
        assert "api_calls" in codes
        assert "exports" in codes

    async def test_public_endpoint_no_auth_required(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans/features")
        assert resp.status_code == 200

    async def test_features_have_ids(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans/features")
        for feature in resp.json()["data"]["features"]:
            assert "id" in feature
            assert "name" in feature
            assert "code" in feature


# =============================================================================
# GET /auth/google/callback (error cases)
# =============================================================================


class TestGoogleCallback:
    async def test_missing_state_400(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/google/callback", params={"code": "a" * 30})
        assert resp.status_code == 400

    async def test_invalid_code_format_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "short", "state": "abc"},
        )
        assert resp.status_code == 400

    async def test_invalid_state_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "state": "invalid-state-token"},
        )
        assert resp.status_code == 400

    async def test_oauth_error_param_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "error": "access_denied"},
        )
        assert resp.status_code == 400

    async def test_state_consumed_once(self, client: AsyncClient, seed_data):
        """Same state token should not be reusable."""
        # First get a valid state
        login_resp = await client.get("/auth/google/login")
        state = login_resp.json()["data"]["state"]

        # First callback attempt with valid state (will fail at Google auth, but state gets consumed)
        await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "state": state},
        )
        # State got consumed (even if callback fails for other reasons)

        # Second attempt with same state should fail with invalid state
        resp2 = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "state": state},
        )
        assert resp2.status_code == 400
        assert "state" in resp2.json()["error"]["message"].lower()

    async def test_code_with_special_chars(self, client: AsyncClient, seed_data):
        """OAuth codes can contain forward slash, dash, dot, underscore."""
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "4/0AY0e-abc_def-123.xyz" + "a" * 10, "state": "test"},
        )
        # Should pass code format validation but fail on state
        assert resp.status_code == 400
        assert "state" in resp.json()["error"]["message"].lower()

    async def test_code_too_short_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 19, "state": "test"},
        )
        assert resp.status_code == 400

    async def test_code_too_long_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 201, "state": "test"},
        )
        assert resp.status_code == 400

    async def test_code_with_invalid_chars_400(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 20 + "!@#$%^&*()", "state": "test"},
        )
        assert resp.status_code == 400

    async def test_error_access_denied(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "error": "access_denied"},
        )
        assert resp.status_code == 400
        assert "access_denied" in resp.json()["error"]["message"].lower()

    async def test_error_server_error(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/auth/google/callback",
            params={"code": "a" * 30, "error": "server_error"},
        )
        assert resp.status_code == 400


# =============================================================================
# Plan Dependencies (requires_plan, requires_feature)
# =============================================================================


class TestRequiresPlan:
    async def test_user_with_plan_passes(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/requires-plan",
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200

    async def test_user_without_plan_402(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/requires-plan",
            headers=_auth(seed_data["noplan_user_id"]),
        )
        assert resp.status_code in (402, 404)

    async def test_user_with_expired_plan_402(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/requires-plan",
            headers=_auth(seed_data["expired_user_id"]),
        )
        assert resp.status_code in (402, 404)

    async def test_wrong_plan_code_403(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/requires-specific-plan",
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 403

    async def test_unauthenticated_401(self, client: AsyncClient, seed_data):
        resp = await client.get("/test/requires-plan")
        assert resp.status_code == 401


class TestRequiresFeature:
    async def test_check_feature_access(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/check-feature",
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["limit"] == 100
        assert body["remaining"] >= 0
        assert "X-Quota-Limit" in resp.headers
        assert "X-Quota-Used" in resp.headers
        assert "X-Quota-Remaining" in resp.headers
        assert "X-Quota-Period" in resp.headers

    async def test_consume_feature_quota(self, client: AsyncClient, seed_data):
        resp = await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["period"] == "daily"
        assert body["limit"] == 100

    async def test_quota_nearly_exhausted(self, client: AsyncClient, seed_data):
        """User with 99/100 usage can consume 1 more."""
        resp = await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["quota_user_id"]),
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["used"] == 100
        assert body["remaining"] == 0

    async def test_quota_exceeded_429(self, client: AsyncClient, seed_data):
        """User at limit should get 429 on next consumption."""
        # First consume to hit exactly 100
        await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["quota_user_id"]),
        )
        # Next attempt should exceed
        resp = await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["quota_user_id"]),
        )
        assert resp.status_code == 429
        body = resp.json()
        assert body["error"]["code"] == "QUOTA_EXCEEDED"
        assert "X-Quota-Limit" in resp.headers

    async def test_feature_not_in_plan_403(self, client: AsyncClient, seed_data):
        resp = await client.get(
            "/test/check-nonexistent-feature",
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 403

    async def test_no_plan_402(self, client: AsyncClient, seed_data):
        resp = await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["noplan_user_id"]),
        )
        assert resp.status_code in (402, 404)

    async def test_expired_plan_402(self, client: AsyncClient, seed_data):
        resp = await client.post(
            "/test/consume-feature",
            headers=_auth(seed_data["expired_user_id"]),
        )
        assert resp.status_code in (402, 404)

    async def test_idempotency_key_prevents_double_consumption(self, client: AsyncClient, seed_data):
        """Same idempotency key should not double-consume quota."""
        headers = {
            **_auth(seed_data["user_id"]),
            "X-Idempotency-Key": "test-idem-key-123",
        }
        resp1 = await client.post("/test/consume-feature", headers=headers)
        assert resp1.status_code == 200
        used1 = resp1.json()["used"]

        resp2 = await client.post("/test/consume-feature", headers=headers)
        assert resp2.status_code == 200
        used2 = resp2.json()["used"]

        assert used2 == used1

    async def test_different_idempotency_keys_consume_separately(self, client: AsyncClient, seed_data):
        headers1 = {
            **_auth(seed_data["user_id"]),
            "X-Idempotency-Key": "key-A",
        }
        headers2 = {
            **_auth(seed_data["user_id"]),
            "X-Idempotency-Key": "key-B",
        }
        resp1 = await client.post("/test/consume-feature", headers=headers1)
        assert resp1.status_code == 200
        used1 = resp1.json()["used"]

        resp2 = await client.post("/test/consume-feature", headers=headers2)
        assert resp2.status_code == 200
        used2 = resp2.json()["used"]

        assert used2 == used1 + 1


# =============================================================================
# Response envelope format
# =============================================================================


class TestResponseFormat:
    async def test_success_envelope(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["user_id"]))
        body = resp.json()
        assert body["success"] is True
        assert "data" in body

    async def test_plans_envelope(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        body = resp.json()
        assert body["success"] is True
        assert "data" in body

    async def test_error_envelope_401(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me")
        body = resp.json()
        assert body["success"] is False
        assert "error" in body
        assert "code" in body["error"]
        assert "message" in body["error"]

    async def test_error_envelope_400(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={},
            headers=_auth(seed_data["user_id"]),
        )
        body = resp.json()
        assert body["success"] is False
        assert body["error"]["code"] == "BAD_REQUEST"

    async def test_error_envelope_422(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": ""},
            headers=_auth(seed_data["user_id"]),
        )
        body = resp.json()
        assert body["success"] is False
        assert body["error"]["code"] == "VALIDATION_ERROR"

    async def test_error_envelope_403(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["inactive_user_id"]))
        body = resp.json()
        assert body["success"] is False
        assert body["error"]["code"] in ("UNAUTHORIZED", "FORBIDDEN")

    async def test_metadata_validation_error_is_422(self, client: AsyncClient, seed_data):
        """MetadataValidationError must return 422, NOT 401."""
        big_meta = {f"key_{i}": f"val_{i}" for i in range(51)}
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": big_meta},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 422
        assert resp.json()["error"]["code"] in ("VALIDATION_ERROR", "METADATA_VALIDATION_FAILED")

    async def test_404_for_nonexistent_endpoint(self, client: AsyncClient, seed_data):
        resp = await client.get("/nonexistent")
        assert resp.status_code == 404

    async def test_405_for_wrong_method(self, client: AsyncClient, seed_data):
        resp = await client.delete("/auth/me", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 405


# =============================================================================
# Sequential profile update consistency
# =============================================================================


class TestProfileUpdateSequence:
    async def test_multiple_updates_are_consistent(self, client: AsyncClient, seed_data):
        headers = _auth(seed_data["user_id"])

        await client.patch("/auth/profile", json={"displayName": "Step1"}, headers=headers)
        await client.patch(
            "/auth/profile",
            json={"pictureUrl": "https://step2.com/pic.png"},
            headers=headers,
        )
        await client.patch(
            "/auth/profile",
            json={"metadata": {"step": "3"}},
            headers=headers,
        )

        resp = await client.get("/auth/me", headers=headers)
        assert resp.status_code == 200
        data = resp.json()["data"]
        assert data["displayName"] == "Step1"
        assert data["pictureUrl"] == "https://step2.com/pic.png"
        assert data["metadata"]["step"] == "3"

    async def test_clear_then_set_picture(self, client: AsyncClient, seed_data):
        headers = _auth(seed_data["user_id"])

        resp = await client.patch("/auth/profile", json={"pictureUrl": ""}, headers=headers)
        assert resp.status_code == 200
        assert resp.json()["data"]["pictureUrl"] is None

        resp = await client.patch(
            "/auth/profile",
            json={"pictureUrl": "https://restored.com/pic.png"},
            headers=headers,
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["pictureUrl"] == "https://restored.com/pic.png"

    async def test_clear_then_set_metadata(self, client: AsyncClient, seed_data):
        headers = _auth(seed_data["meta_user_id"])

        # Clear
        resp = await client.patch("/auth/profile", json={"metadata": None}, headers=headers)
        assert resp.status_code == 200
        assert resp.json()["data"]["metadata"] == {}

        # Set new
        resp = await client.patch(
            "/auth/profile",
            json={"metadata": {"new": "data"}},
            headers=headers,
        )
        assert resp.status_code == 200
        assert resp.json()["data"]["metadata"]["new"] == "data"

    async def test_idempotent_display_name_update(self, client: AsyncClient, seed_data):
        headers = _auth(seed_data["user_id"])

        await client.patch("/auth/profile", json={"displayName": "Same"}, headers=headers)
        resp = await client.patch("/auth/profile", json={"displayName": "Same"}, headers=headers)
        assert resp.status_code == 200
        assert resp.json()["data"]["displayName"] == "Same"


# =============================================================================
# Password management (service-level, called via kit)
# =============================================================================


class TestPasswordManagement:
    async def test_set_password_for_admin(self, kit: IdentityPlanKit, seed_data):
        result = await kit.auth_service.set_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        assert result is True

    async def test_verify_correct_password(self, kit: IdentityPlanKit, seed_data):
        await kit.auth_service.set_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        result = await kit.auth_service.verify_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        assert result is True

    async def test_verify_wrong_password(self, kit: IdentityPlanKit, seed_data):
        await kit.auth_service.set_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        result = await kit.auth_service.verify_user_password(
            seed_data["admin_user_id"],
            "WrongP@ss1",
        )
        assert result is False

    async def test_password_too_short_422(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import PasswordValidationError

        with pytest.raises(PasswordValidationError):
            await kit.auth_service.set_user_password(
                seed_data["admin_user_id"],
                "Short1!",
            )

    async def test_password_no_uppercase_422(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import PasswordValidationError

        with pytest.raises(PasswordValidationError):
            await kit.auth_service.set_user_password(
                seed_data["admin_user_id"],
                "nouppercase1!",
            )

    async def test_password_no_digit_422(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import PasswordValidationError

        with pytest.raises(PasswordValidationError):
            await kit.auth_service.set_user_password(
                seed_data["admin_user_id"],
                "NoDigitHere!",
            )

    async def test_password_no_special_char_422(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import PasswordValidationError

        with pytest.raises(PasswordValidationError):
            await kit.auth_service.set_user_password(
                seed_data["admin_user_id"],
                "NoSpecial1",
            )

    async def test_set_password_non_admin_rejected(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import PasswordValidationError

        with pytest.raises(PasswordValidationError):
            await kit.auth_service.set_user_password(
                seed_data["user_id"],
                "StrongP@ss1",
            )

    async def test_set_password_nonexistent_user(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import UserNotFoundError

        with pytest.raises(UserNotFoundError):
            await kit.auth_service.set_user_password(
                uuid4(),
                "StrongP@ss1",
            )

    async def test_clear_password(self, kit: IdentityPlanKit, seed_data):
        await kit.auth_service.set_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        result = await kit.auth_service.clear_user_password(seed_data["admin_user_id"])
        assert result is True

        # After clearing, verify should return False
        result = await kit.auth_service.verify_user_password(
            seed_data["admin_user_id"],
            "StrongP@ss1",
        )
        assert result is False

    async def test_verify_no_password_returns_false(self, kit: IdentityPlanKit, seed_data):
        """User without a password (OAuth-only) returns False, not error."""
        result = await kit.auth_service.verify_user_password(
            seed_data["user_id"],
            "AnyP@ss1",
        )
        assert result is False

    async def test_set_password_inactive_user_rejected(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import UserInactiveError

        with pytest.raises(UserInactiveError):
            await kit.auth_service.set_user_password(
                seed_data["inactive_user_id"],
                "StrongP@ss1",
                require_admin_role=False,
            )


# =============================================================================
# Concurrent operations
# =============================================================================


class TestConcurrentOperations:
    async def test_concurrent_profile_updates(self, client: AsyncClient, seed_data):
        """Multiple concurrent profile updates should not corrupt data."""
        import asyncio

        headers = _auth(seed_data["user_id"])

        async def update_name(name: str):
            return await client.patch(
                "/auth/profile", json={"displayName": name}, headers=headers
            )

        results = await asyncio.gather(
            update_name("Concurrent1"),
            update_name("Concurrent2"),
            update_name("Concurrent3"),
        )

        assert all(r.status_code == 200 for r in results)

        # Final state should be one of the updates
        resp = await client.get("/auth/me", headers=headers)
        assert resp.json()["data"]["displayName"] in (
            "Concurrent1",
            "Concurrent2",
            "Concurrent3",
        )

    async def test_concurrent_feature_consumption(self, client: AsyncClient, seed_data):
        """Concurrent quota consumption should not exceed limits."""
        import asyncio

        headers = _auth(seed_data["user_id"])

        async def consume():
            return await client.post("/test/consume-feature", headers=headers)

        results = await asyncio.gather(*[consume() for _ in range(5)])

        success_count = sum(1 for r in results if r.status_code == 200)
        assert success_count >= 1


# =============================================================================
# Edge cases for camelCase serialization
# =============================================================================


class TestCamelCaseSerialization:
    async def test_response_uses_camel_case(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/me", headers=_auth(seed_data["user_id"]))
        data = resp.json()["data"]
        assert "displayName" in data
        assert "pictureUrl" in data
        assert "roleCode" in data
        assert "isActive" in data
        assert "isVerified" in data
        assert "createdAt" in data
        # These should NOT be present
        assert "display_name" not in data
        assert "picture_url" not in data
        assert "role_code" not in data

    async def test_request_accepts_camel_case(self, client: AsyncClient, seed_data):
        resp = await client.patch(
            "/auth/profile",
            json={"displayName": "CamelTest"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 200

    async def test_profile_response_camel_case(self, client: AsyncClient, seed_data):
        resp = await client.get("/auth/profile", headers=_auth(seed_data["user_id"]))
        data = resp.json()["data"]
        assert "userPermissions" in data
        assert "isActive" in data

    async def test_plans_response_camel_case(self, client: AsyncClient, seed_data):
        resp = await client.get("/plans")
        plan = resp.json()["data"]["plans"][0]
        assert "featureCode" in plan["limits"][0] or "feature_code" not in plan["limits"][0]


# =============================================================================
# Auth service edge cases (service-level)
# =============================================================================


class TestAuthServiceEdgeCases:
    async def test_get_user_from_invalid_token(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import TokenInvalidError

        with pytest.raises(TokenInvalidError):
            await kit.auth_service.get_user_from_token("not-a-jwt-token")

    async def test_update_profile_nonexistent_user(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import UserNotFoundError

        with pytest.raises(UserNotFoundError):
            await kit.auth_service.update_profile(
                user_id=uuid4(),
                display_name="Ghost",
            )

    async def test_metadata_validation_non_serializable(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import MetadataValidationError

        with pytest.raises(MetadataValidationError):
            await kit.auth_service.update_profile(
                user_id=seed_data["user_id"],
                metadata={"bad": object()},
            )

    async def test_metadata_validation_max_size(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import MetadataValidationError

        with pytest.raises(MetadataValidationError):
            await kit.auth_service.update_profile(
                user_id=seed_data["user_id"],
                metadata={"huge": "x" * 20000},
            )

    async def test_metadata_validation_max_keys(self, kit: IdentityPlanKit, seed_data):
        from identity_plan_kit.auth.domain.exceptions import MetadataValidationError

        with pytest.raises(MetadataValidationError):
            await kit.auth_service.update_profile(
                user_id=seed_data["user_id"],
                metadata={f"k{i}": "v" for i in range(51)},
            )

    async def test_update_profile_with_unset_sentinel(self, kit: IdentityPlanKit, seed_data):
        """UNSET sentinel should not be passed to DB."""
        from identity_plan_kit.shared.constants import UNSET

        user = await kit.auth_service.update_profile(
            user_id=seed_data["user_id"],
            display_name="SentinelTest",
            picture_url=UNSET,
            metadata=UNSET,
        )
        assert user.display_name == "SentinelTest"


# =============================================================================
# HTTP method handling
# =============================================================================


class TestHTTPMethodHandling:
    async def test_get_profile_with_post_405(self, client: AsyncClient, seed_data):
        resp = await client.post("/auth/me", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 405

    async def test_patch_plans_405(self, client: AsyncClient, seed_data):
        resp = await client.patch("/plans", json={})
        assert resp.status_code == 405

    async def test_delete_profile_405(self, client: AsyncClient, seed_data):
        resp = await client.delete("/auth/profile", headers=_auth(seed_data["user_id"]))
        assert resp.status_code == 405

    async def test_put_profile_405(self, client: AsyncClient, seed_data):
        resp = await client.put(
            "/auth/profile",
            json={"displayName": "test"},
            headers=_auth(seed_data["user_id"]),
        )
        assert resp.status_code == 405
