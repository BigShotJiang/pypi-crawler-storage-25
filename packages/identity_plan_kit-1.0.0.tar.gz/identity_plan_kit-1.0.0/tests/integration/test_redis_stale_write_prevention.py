"""Integration tests for Redis stale write prevention.

This test suite verifies that RedisPlanCache properly prevents stale writes
using Lua scripts and invalidation timestamps (C1 fix).

Requires Redis to be available (uses testcontainers).
"""

import asyncio
import time
from uuid import uuid4

import pytest
from testcontainers.redis import RedisContainer

from identity_plan_kit.plans.cache.plan_cache import RedisPlanCache
from identity_plan_kit.plans.domain.entities import Plan


@pytest.fixture(scope="module")
def redis_container():
    """Start Redis container for testing."""
    container = RedisContainer("redis:7-alpine")
    container.start()
    yield container
    container.stop()


@pytest.fixture
async def redis_cache(redis_container):
    """Create RedisPlanCache with test Redis instance."""
    # Build Redis URL from container properties
    host = redis_container.get_container_host_ip()
    port = redis_container.get_exposed_port(6379)
    redis_url = f"redis://{host}:{port}/0"

    cache = RedisPlanCache(redis_url=redis_url, ttl_seconds=5)
    await cache.connect()
    yield cache
    await cache.invalidate_all()  # Clean up
    await cache.disconnect()


@pytest.fixture
def sample_plan():
    """Create a sample plan for testing."""
    return Plan(id=uuid4(), code="test", name="Test Plan")


class TestRedisStaleWritePrevention:
    """Test that Redis properly prevents stale writes."""

    @pytest.mark.asyncio
    async def test_set_without_timestamp_always_succeeds(self, redis_cache, sample_plan):
        """Test that writes without fetched_at bypass timestamp check (backwards compat)."""
        # Invalidate first
        await redis_cache.invalidate("test")

        # Set without timestamp should succeed
        result = await redis_cache.set("test", sample_plan, fetched_at=None)
        assert result is True

        # Verify it was cached
        cached = await redis_cache.get("test")
        assert cached is not None
        assert cached.code == "test"

    @pytest.mark.asyncio
    async def test_stale_write_rejected_after_key_invalidation(self, redis_cache, sample_plan):
        """Test that stale writes are rejected after key-specific invalidation."""
        # Get timestamp before invalidation
        old_ts = time.monotonic()

        # Invalidate the plan
        await redis_cache.invalidate("test")

        # Wait a bit to ensure timestamp difference
        await asyncio.sleep(0.01)

        # Try to write with old timestamp (stale)
        result = await redis_cache.set("test", sample_plan, fetched_at=old_ts)
        assert result is False

        # Verify nothing was cached
        cached = await redis_cache.get("test")
        assert cached is None

    @pytest.mark.asyncio
    async def test_fresh_write_accepted_after_invalidation(self, redis_cache, sample_plan):
        """Test that fresh writes are accepted after invalidation."""
        # Invalidate the plan
        await redis_cache.invalidate("test")

        # Get fresh timestamp AFTER invalidation
        fresh_ts = time.monotonic()

        # Wait to ensure timestamp is definitely after invalidation
        await asyncio.sleep(0.01)

        # Write with fresh timestamp should succeed
        result = await redis_cache.set("test", sample_plan, fetched_at=fresh_ts)
        assert result is True

        # Verify it was cached
        cached = await redis_cache.get("test")
        assert cached is not None

    @pytest.mark.asyncio
    async def test_stale_write_rejected_after_global_invalidation(self, redis_cache, sample_plan):
        """Test that stale writes are rejected after invalidate_all()."""
        # Get timestamp before global invalidation
        old_ts = time.monotonic()

        # Global invalidation
        await redis_cache.invalidate_all()

        # Wait a bit
        await asyncio.sleep(0.01)

        # Try to write with old timestamp (stale)
        result = await redis_cache.set("test", sample_plan, fetched_at=old_ts)
        assert result is False

        # Verify nothing was cached
        cached = await redis_cache.get("test")
        assert cached is None

    @pytest.mark.asyncio
    async def test_fresh_write_accepted_after_global_invalidation(self, redis_cache, sample_plan):
        """Test that fresh writes are accepted after invalidate_all()."""
        # Global invalidation
        await redis_cache.invalidate_all()

        # Get fresh timestamp AFTER global invalidation
        fresh_ts = time.monotonic()

        # Wait to ensure timestamp is after
        await asyncio.sleep(0.01)

        # Write with fresh timestamp should succeed
        result = await redis_cache.set("test", sample_plan, fetched_at=fresh_ts)
        assert result is True

        # Verify it was cached
        cached = await redis_cache.get("test")
        assert cached is not None

    @pytest.mark.asyncio
    async def test_key_specific_vs_global_invalidation_precedence(self, redis_cache, sample_plan):
        """Test that both key-specific and global invalidation are checked."""
        # Get old timestamp
        old_ts = time.monotonic()

        # Key-specific invalidation
        await redis_cache.invalidate("test")
        await asyncio.sleep(0.01)

        # Get mid timestamp (after key invalidation, before global)
        mid_ts = time.monotonic()

        # Global invalidation
        await redis_cache.invalidate_all()
        await asyncio.sleep(0.01)

        # Get fresh timestamp (after both)
        fresh_ts = time.monotonic()

        # Old timestamp should be rejected
        result = await redis_cache.set("test", sample_plan, fetched_at=old_ts)
        assert result is False

        # Mid timestamp (after key, before global) should be rejected by global check
        result = await redis_cache.set("test", sample_plan, fetched_at=mid_ts)
        assert result is False

        # Fresh timestamp (after both) should succeed
        result = await redis_cache.set("test", sample_plan, fetched_at=fresh_ts)
        assert result is True

    @pytest.mark.asyncio
    async def test_concurrent_invalidate_and_set_race(self, redis_cache, sample_plan):
        """Test concurrent invalidation and set operations."""
        async def writer(code: str, delay: float):
            await asyncio.sleep(delay)
            ts = time.monotonic()
            await redis_cache.set(code, sample_plan, fetched_at=ts)

        async def invalidator(code: str, delay: float):
            await asyncio.sleep(delay)
            await redis_cache.invalidate(code)

        # Run multiple concurrent operations
        await asyncio.gather(
            writer("test1", 0.01),
            invalidator("test1", 0.02),
            writer("test1", 0.03),
            invalidator("test2", 0.01),
            writer("test2", 0.02),
        )

        # No assertion - just verify no exceptions/crashes

    @pytest.mark.asyncio
    async def test_invalidation_timestamps_stored_with_ttl(self, redis_cache, sample_plan):
        """Test that invalidation timestamps are stored in Redis with proper TTL."""
        # Invalidate a plan
        await redis_cache.invalidate("test")

        # Check that invalidation timestamp key exists in Redis
        inv_key = redis_cache._make_invalidation_key("test")
        ttl = await redis_cache._client.ttl(inv_key)

        # Should have TTL set (2x plan TTL = 10 seconds)
        assert ttl > 0
        assert ttl <= redis_cache._ttl_seconds * 2

    @pytest.mark.asyncio
    async def test_global_invalidation_timestamp_stored(self, redis_cache, sample_plan):
        """Test that global invalidation timestamp is stored in Redis."""
        # Global invalidation
        await redis_cache.invalidate_all()

        # Check that global invalidation key exists
        global_inv_key = redis_cache._make_global_invalidation_key()
        ttl = await redis_cache._client.ttl(global_inv_key)

        # Should have TTL set
        assert ttl > 0
        assert ttl <= redis_cache._ttl_seconds * 2

    @pytest.mark.asyncio
    async def test_multiple_plans_independent_invalidation(self, redis_cache, sample_plan):
        """Test that invalidating one plan doesn't affect others."""
        plan_a = Plan(id=uuid4(), code="plan_a", name="Plan A")
        plan_b = Plan(id=uuid4(), code="plan_b", name="Plan B")

        # Cache both plans
        ts = time.monotonic()
        await redis_cache.set("plan_a", plan_a, fetched_at=ts)
        await redis_cache.set("plan_b", plan_b, fetched_at=ts)

        # Invalidate plan_a
        await redis_cache.invalidate("plan_a")

        # Get fresh timestamp
        fresh_ts = time.monotonic()
        await asyncio.sleep(0.01)

        # Stale write to plan_a should be rejected
        result_a = await redis_cache.set("plan_a", plan_a, fetched_at=ts)
        assert result_a is False

        # But plan_b should still accept the stale timestamp (not invalidated)
        result_b = await redis_cache.set("plan_b", plan_b, fetched_at=ts)
        assert result_b is True

        # Fresh write to plan_a should succeed
        result_a_fresh = await redis_cache.set("plan_a", plan_a, fetched_at=fresh_ts)
        assert result_a_fresh is True


class TestRedisLuaScriptEdgeCases:
    """Test edge cases in Lua script logic."""

    @pytest.mark.asyncio
    async def test_lua_script_handles_nil_timestamp(self, redis_cache, sample_plan):
        """Test Lua script correctly handles 'nil' timestamp string."""
        result = await redis_cache.set("test", sample_plan, fetched_at=None)
        assert result is True

    @pytest.mark.asyncio
    async def test_lua_script_handles_zero_timestamp(self, redis_cache, sample_plan):
        """Test Lua script handles zero timestamp (should be accepted as valid)."""
        # Invalidate first
        await redis_cache.invalidate("test")

        # Wait for timestamp to be non-zero
        await asyncio.sleep(0.01)

        # Try to set with timestamp 0 (before any invalidation)
        result = await redis_cache.set("test", sample_plan, fetched_at=0.0)
        assert result is False  # Should be rejected (too old)

    @pytest.mark.asyncio
    async def test_lua_script_with_very_large_timestamp(self, redis_cache, sample_plan):
        """Test Lua script handles future timestamps gracefully."""
        # Use timestamp far in the future
        future_ts = time.monotonic() + 1000000

        result = await redis_cache.set("test", sample_plan, fetched_at=future_ts)
        assert result is True  # Should succeed (newer than any invalidation)


class TestBackwardsCompatibility:
    """Test that changes maintain backwards compatibility."""

    @pytest.mark.asyncio
    async def test_set_without_timestamp_still_works(self, redis_cache, sample_plan):
        """Existing code that doesn't pass fetched_at should still work."""
        result = await redis_cache.set("test", sample_plan)
        assert result is True

        cached = await redis_cache.get("test")
        assert cached is not None

    @pytest.mark.asyncio
    async def test_invalidate_without_timestamp_check_still_works(self, redis_cache, sample_plan):
        """Invalidation should work even if writes don't use timestamps."""
        # Cache without timestamp
        await redis_cache.set("test", sample_plan)

        # Invalidate
        await redis_cache.invalidate("test")

        # Verify deleted
        cached = await redis_cache.get("test")
        assert cached is None

    @pytest.mark.asyncio
    async def test_mixed_timestamped_and_non_timestamped_writes(self, redis_cache, sample_plan):
        """Test that timestamped and non-timestamped writes can coexist."""
        ts = time.monotonic()

        # Write with timestamp
        result1 = await redis_cache.set("test1", sample_plan, fetched_at=ts)
        assert result1 is True

        # Write without timestamp
        result2 = await redis_cache.set("test2", sample_plan)
        assert result2 is True

        # Both should be cached
        assert await redis_cache.get("test1") is not None
        assert await redis_cache.get("test2") is not None
