"""Regression tests pinning down the fixes from the shared/ comprehensive review.

Each test corresponds to one finding in the audit. They are grouped by theme:

* BaseError inheritance — every shared exception inherits BaseError so the
  global error handler maps it to a structured 4xx/5xx response.
* PII / log injection — IPs are hashed before becoming state-store keys, emails
  are masked in audit calls, attacker-controlled headers cannot inject CRLF.
* Trusted-proxy IP extraction — the rightmost X-Forwarded-For entry wins.
* Concurrency — record_failure is serialized; the cleanup scheduler does not
  deadlock; the graceful-shutdown manager mutates state under its lock; the
  state-store manager cancels its sync-init startup task on close.
* Cryptographic domain separation — Fernet keys go through HKDF with a label.
* Config-driven runtime values — pool_recycle, max_overflow, and health-check
  timeouts come from IdentityPlanKitConfig.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.shared.audit import (
    audit_account_locked,
    audit_user_authenticated,
    audit_user_registered,
    log_audit_event,
)
from identity_plan_kit.shared.circuit_breaker import CircuitBreakerError
from identity_plan_kit.shared.database import (
    DatabaseConnectionError,
    DatabaseStartupTimeoutError,
)
from identity_plan_kit.shared.exceptions import (
    AuthenticationError,
    BaseError,
    ValidationError,
)
from identity_plan_kit.shared.graceful_shutdown import (
    DegradedModeManager,
    ServiceMode,
    ShutdownState,
)
from identity_plan_kit.shared.health import (
    DEFAULT_COMPONENT_HEALTH_CHECK_TIMEOUT,
    HealthChecker,
)
from identity_plan_kit.shared.http_utils import get_client_ip
from identity_plan_kit.shared.lockout import (
    AccountLockedError,
    LockoutConfig,
    LockoutManager,
    _sanitize_reason,
)
from identity_plan_kit.shared.request_id import _sanitize_trace_header
from identity_plan_kit.auth.domain.exceptions import (
    TokenError,
    TokenExpiredError,
    TokenInvalidError,
)
from identity_plan_kit.shared.security import (
    _CACHE_ENCRYPTION_HKDF_INFO,
    _derive_fernet_key,
)
from identity_plan_kit.shared.state_store import (
    InMemoryStateStore,
    InvalidKeyError,
    RedisRequiredError,
    StateStoreManager,
)


# ---------------------------------------------------------------------------
# BaseError inheritance (P0 #4–9)
# ---------------------------------------------------------------------------


class TestBaseErrorInheritance:
    """Every shared exception must inherit BaseError so the global handler
    can serialize it to a structured response. Bare ``Exception`` subclasses
    bypass the registered handlers and produce raw 500s with internals leaked.
    """

    @pytest.mark.parametrize(
        "exc_cls",
        [
            CircuitBreakerError,
            AccountLockedError,
            TokenError,
            TokenExpiredError,
            TokenInvalidError,
            InvalidKeyError,
            RedisRequiredError,
            DatabaseConnectionError,
            DatabaseStartupTimeoutError,
        ],
    )
    def test_inherits_base_error(self, exc_cls):
        assert issubclass(exc_cls, BaseError), (
            f"{exc_cls.__name__} must inherit BaseError so error-handling.md "
            "compliance holds"
        )

    def test_token_errors_are_authentication_errors(self):
        """Token errors map to 401 in the error handler."""
        assert issubclass(TokenError, AuthenticationError)
        assert issubclass(TokenExpiredError, TokenError)
        assert issubclass(TokenInvalidError, TokenError)

    def test_invalid_key_error_is_validation_error(self):
        """InvalidKeyError surfaces as 422 via ValidationError lineage."""
        assert issubclass(InvalidKeyError, ValidationError)
        assert InvalidKeyError().status_code == 422

    def test_circuit_breaker_error_serializes_with_to_dict(self):
        """BaseError contract: every shared exception exposes ``to_dict``."""
        err = CircuitBreakerError("google_oauth", retry_after=12.5)
        body = err.to_dict()
        assert body["success"] is False
        assert body["error"]["code"] == "CIRCUIT_OPEN"
        assert body["error"]["context"]["retry_after"] == 12.5
        assert err.status_code == 503

    def test_account_locked_error_serializes_with_to_dict(self):
        unlock_at = datetime.now(UTC) + timedelta(minutes=5)
        err = AccountLockedError(
            identifier="user@example.com", unlock_at=unlock_at, failed_attempts=5
        )
        body = err.to_dict()
        assert body["error"]["code"] == "ACCOUNT_LOCKED"
        assert body["error"]["context"]["failed_attempts"] == 5
        # Identifier MUST NOT leak into the serialized body.
        assert "user@example.com" not in str(body["error"]["context"])


# ---------------------------------------------------------------------------
# PII protection in lockout key + audit log (P0 #2, #3, P3 #26)
# ---------------------------------------------------------------------------


class TestLockoutIPHashing:
    """Raw IPs must never appear in the state-store key.

    Without hashing, an attacker controlling X-Forwarded-For can mint
    unbounded counter buckets — bypassing per-IP lockout entirely.
    """

    def _config(self) -> LockoutConfig:
        return LockoutConfig(max_attempts=3, track_by_ip=True)

    def test_make_key_hashes_ip(self):
        manager = LockoutManager(InMemoryStateStore(), self._config())
        key = manager._make_key("user@example.com", ip_address="203.0.113.50")
        assert "203.0.113.50" not in key, "raw IP must not appear in state-store key"

    def test_make_key_hashes_ipv6(self):
        manager = LockoutManager(InMemoryStateStore(), self._config())
        key = manager._make_key("user@example.com", ip_address="2001:db8::1")
        assert "2001:db8" not in key, "raw IPv6 must not appear in state-store key"
        assert "::1" not in key

    def test_distinct_ips_produce_distinct_keys(self):
        manager = LockoutManager(InMemoryStateStore(), self._config())
        k1 = manager._make_key("u@x.com", ip_address="1.1.1.1")
        k2 = manager._make_key("u@x.com", ip_address="2.2.2.2")
        assert k1 != k2, "different IPs must still bucket separately"


class TestAccountLockedAuditMaskingFromLockoutManager:
    """``LockoutManager`` must mask the email before forwarding to the audit
    helper, otherwise plaintext PII enters the security audit stream even
    when ``IPK_MASK_PII_IN_AUDIT_LOGS`` is ``true`` (the default)."""

    @pytest.mark.asyncio
    async def test_trigger_lockout_masks_email_in_audit_call(self):
        store = InMemoryStateStore()
        await store.start()
        try:
            manager = LockoutManager(
                store,
                LockoutConfig(max_attempts=2, lockout_duration_seconds=60),
            )
            with patch(
                "identity_plan_kit.shared.lockout.audit_account_locked"
            ) as mocked:
                await manager.record_failure("user@example.com", reason="bad_pw")
                with pytest.raises(AccountLockedError):
                    await manager.record_failure("user@example.com", reason="bad_pw")

            assert mocked.called
            kwargs = mocked.call_args.kwargs
            assert kwargs["email"] != "user@example.com"
            assert "user@example.com" not in (kwargs["email"] or "")
        finally:
            await store.stop()


class TestAuditUserEventEmailMasking:
    """Successful auth audits must mask the email — they previously logged
    plaintext, diverging from ``audit_failed_login_attempt``."""

    def _capture(self, fn, **kwargs):
        captured: list = []
        with patch(
            "identity_plan_kit.shared.audit.log_audit_event",
            side_effect=captured.append,
        ):
            fn(**kwargs)
        return captured[0].to_dict()

    def test_audit_user_registered_masks_email(self):
        from uuid import uuid4

        body = self._capture(
            audit_user_registered,
            user_id=uuid4(),
            email="alice@example.com",
            provider="google",
        )
        assert body["actor"]["email"] != "alice@example.com"

    def test_audit_user_authenticated_masks_email(self):
        from uuid import uuid4

        body = self._capture(
            audit_user_authenticated,
            user_id=uuid4(),
            email="alice@example.com",
            provider="google",
        )
        assert body["actor"]["email"] != "alice@example.com"

    def test_audit_account_locked_takes_seconds_not_minutes(self):
        """Field renamed from ``lock_duration_minutes`` to
        ``lock_duration_seconds`` to comply with layer-standards.md."""
        captured: list = []
        with patch(
            "identity_plan_kit.shared.audit.log_audit_event",
            side_effect=captured.append,
        ):
            audit_account_locked(lock_duration_seconds=900)
        details = captured[0].to_dict()["details"]
        assert details["lock_duration_seconds"] == 900
        assert "lock_duration_minutes" not in details


# ---------------------------------------------------------------------------
# Header injection / log poisoning (P1 #13, #15)
# ---------------------------------------------------------------------------


class TestTraceHeaderSanitization:
    """``X-Request-ID`` / ``X-Correlation-ID`` are reflected back in response
    headers AND bound into structlog context. Unsanitized values let a
    client inject CRLF (CWE-93)."""

    @pytest.mark.parametrize(
        "evil",
        [
            "abc\r\nX-Injected: evil",
            "abc\nfoo",
            "abc\rfoo",
            "x" * 200,  # over the length cap
            "has spaces",
            "has;semicolons",
        ],
    )
    def test_unsafe_values_are_rejected(self, evil):
        assert _sanitize_trace_header(evil) is None

    @pytest.mark.parametrize(
        "good",
        [
            "abc-123",
            "ABC.def_GHI",
            "0123456789",
            "trace-id-with-dashes",
        ],
    )
    def test_safe_values_pass_through(self, good):
        assert _sanitize_trace_header(good) == good

    def test_none_passes_through(self):
        assert _sanitize_trace_header(None) is None


class TestLockoutReasonSanitization:
    """A free-form ``reason`` string must not allow CRLF into the audit log
    or the state-store value."""

    def test_strips_crlf(self):
        assert _sanitize_reason("bad\r\nlogin") == "bad  login"

    def test_caps_length(self):
        long = "x" * 1000
        assert len(_sanitize_reason(long)) <= 64

    def test_empty_normalizes_to_unknown(self):
        assert _sanitize_reason("   ") == "unknown"


# ---------------------------------------------------------------------------
# Trusted-proxy IP extraction (P1 #14)
# ---------------------------------------------------------------------------


class TestRightmostXForwardedFor:
    """The rightmost X-Forwarded-For entry is the one our trusted edge proxy
    appended; the leftmost is fully attacker-controlled. Earlier code took
    ``[0]`` — letting any client forge their apparent IP and bypass per-IP
    rate limiting."""

    def _request(self, *, header: str | None = None, client_host: str | None = None):
        request = MagicMock()
        request.headers.get = lambda name, default=None: (
            header if name == "X-Forwarded-For" else default
        )
        if client_host is None:
            request.client = None
        else:
            request.client = MagicMock()
            request.client.host = client_host
        return request

    def test_chain_returns_rightmost(self):
        request = self._request(
            header="203.0.113.50, 70.41.3.18, 150.172.238.178",
            client_host="10.0.0.1",
        )
        assert get_client_ip(request, trust_proxy=True) == "150.172.238.178"

    def test_single_ip_unaffected(self):
        request = self._request(header="203.0.113.50", client_host="10.0.0.1")
        assert get_client_ip(request, trust_proxy=True) == "203.0.113.50"


# ---------------------------------------------------------------------------
# Lockout concurrency under InMemoryStateStore (P2 #22)
# ---------------------------------------------------------------------------


class TestLockoutRecordFailureSerialization:
    """``record_failure`` reads-modifies-writes against the state store. The
    underlying ``set`` is unconditional, so without an instance lock two
    concurrent callers each "win" with their own version=1 — losing one of
    the increments and undercounting attempts."""

    @pytest.mark.asyncio
    async def test_concurrent_failures_are_all_counted(self):
        store = InMemoryStateStore()
        await store.start()
        try:
            manager = LockoutManager(
                store,
                LockoutConfig(
                    max_attempts=1000,  # high so we just count, never lock
                    lockout_duration_seconds=60,
                    attempt_window_seconds=60,
                    track_by_ip=False,
                ),
            )

            async def one():
                await manager.record_failure("u@x.com", reason="bad")

            await asyncio.gather(*(one() for _ in range(20)))

            assert await manager.get_failure_count("u@x.com") == 20
        finally:
            await store.stop()


# ---------------------------------------------------------------------------
# Graceful shutdown atomicity (P1 #11, #12)
# ---------------------------------------------------------------------------


class TestShutdownStateModeAtomicity:
    """``set_mode`` was added so ``graceful_shutdown_context`` can flip to
    ``SHUTDOWN`` under the existing async lock — the bare assignment used
    earlier raced with middleware reads of ``state.mode``."""

    @pytest.mark.asyncio
    async def test_set_mode_takes_state_lock(self):
        state = ShutdownState()
        await state.set_mode(ServiceMode.SHUTDOWN)
        assert state.mode is ServiceMode.SHUTDOWN

    @pytest.mark.asyncio
    async def test_set_mode_serializes_with_other_writes(self):
        state = ShutdownState()
        await state.start_draining()
        await state.set_mode(ServiceMode.SHUTDOWN)
        assert state.mode is ServiceMode.SHUTDOWN


class TestDegradedModeIterationSafety:
    """``should_skip_feature`` must not iterate ``_unhealthy_dependencies``
    while another coroutine mutates it — that raises ``RuntimeError: Set
    changed size during iteration`` in CPython."""

    @pytest.mark.asyncio
    async def test_should_skip_feature_handles_concurrent_mutation(self):
        manager = DegradedModeManager()

        async def churn():
            for i in range(200):
                await manager.mark_dependency_unhealthy(f"dep-{i}")
                await manager.mark_dependency_healthy(f"dep-{i}")

        async def reader():
            for _ in range(200):
                # Should never raise even while churn() mutates the set.
                manager.should_skip_feature("caching")

        await asyncio.gather(churn(), reader())


# ---------------------------------------------------------------------------
# State store startup task cleanup (P2 #21)
# ---------------------------------------------------------------------------


class TestStateStoreManagerStartupTaskCleanup:
    """``close()`` must reap the sync-init startup task; otherwise the
    InMemoryStateStore's cleanup loop keeps running after we drop our
    reference to it."""

    @pytest.mark.asyncio
    async def test_close_awaits_startup_task(self):
        manager = StateStoreManager()
        manager._init_sync_in_memory()
        startup_task = manager._startup_task
        assert startup_task is not None

        await manager.close()
        assert startup_task.done()
        assert manager._startup_task is None


# ---------------------------------------------------------------------------
# HKDF domain separation for cache encryption key (P3 #25)
# ---------------------------------------------------------------------------


class TestFernetKeyDerivation:
    """The cache encryption key is derived via HKDF with a domain-separation
    label — bare SHA-256 would let a leaked secret be reused as the JWT
    signing key (no separation)."""

    def test_derived_key_is_not_raw_sha256(self):
        import base64
        import hashlib

        secret = "a" * 32
        derived = _derive_fernet_key(secret)

        sha = base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest())
        assert derived != sha, "key must go through HKDF, not bare SHA-256"

    def test_derived_key_is_fernet_compatible(self):
        from cryptography.fernet import Fernet

        secret = "b" * 32
        Fernet(_derive_fernet_key(secret))  # does not raise

    def test_hkdf_label_is_domain_specific(self):
        assert b"identity-plan-kit" in _CACHE_ENCRYPTION_HKDF_INFO
        assert b"cache-encryption" in _CACHE_ENCRYPTION_HKDF_INFO


# ---------------------------------------------------------------------------
# Config-driven runtime values (P1 #17–20, #23)
# ---------------------------------------------------------------------------


class TestConfigDrivenRuntimeValues:
    """Pool sizing, recycle interval, and health-check timeout were
    hardcoded; layer-standards.md requires they come from
    ``IdentityPlanKitConfig``. These tests fail if a future change reverts
    the wiring back to literals."""

    def _config(self, **overrides) -> IdentityPlanKitConfig:
        return IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://x:y@localhost:5432/z",
            secret_key="k" * 32,
            google_client_id="cid",
            google_client_secret="csec",
            google_redirect_uri="https://example.com/cb",
            **overrides,
        )

    def test_database_max_overflow_is_configurable(self):
        config = self._config(database_max_overflow=42)
        assert config.database_max_overflow == 42

    def test_database_pool_recycle_is_configurable(self):
        config = self._config(database_pool_recycle_seconds=7200)
        assert config.database_pool_recycle_seconds == 7200

    def test_health_check_timeout_is_configurable(self):
        config = self._config(health_check_timeout_seconds=12.5)
        assert config.health_check_timeout_seconds == 12.5

    def test_lockout_durations_are_in_seconds(self):
        """Per layer-standards.md, all TTLs are seconds."""
        config = self._config()
        assert hasattr(config, "lockout_duration_seconds")
        assert hasattr(config, "lockout_window_seconds")

    def test_health_checker_uses_configured_timeout(self):
        checker = HealthChecker(version="1.0.0", check_timeout=2.5)
        assert checker._check_timeout == 2.5

    def test_health_checker_default_is_module_default(self):
        checker = HealthChecker(version="1.0.0")
        assert checker._check_timeout == DEFAULT_COMPONENT_HEALTH_CHECK_TIMEOUT


# ---------------------------------------------------------------------------
# Cleanup scheduler restart safety (P1 #10)
# ---------------------------------------------------------------------------


class TestCleanupSchedulerRestartLockSafety:
    """``_attempt_restart`` previously called ``asyncio.create_task`` while
    holding the threading.Lock. The done-callback for that very task tries
    to reacquire the same lock — if start/stop were ever invoked from a
    different thread, the event loop would block on lock contention."""

    @pytest.mark.asyncio
    async def test_attempt_restart_creates_task_outside_lock(self):
        """The restart path must not hold ``self._lock`` while calling
        asyncio.create_task. We assert this structurally by patching
        ``create_task`` and verifying the lock is releasable while the
        patched function runs."""
        from identity_plan_kit.shared.cleanup_scheduler import (
            CleanupConfig,
            CleanupScheduler,
        )

        async def cleanup(_: int) -> int:
            return 0

        scheduler = CleanupScheduler(
            cleanup_func=cleanup,
            config=CleanupConfig(
                token_cleanup_enabled=True,
                max_consecutive_failures=10,
            ),
        )
        scheduler._running = True

        observed_lock_state: list[bool] = []
        real_create_task = asyncio.create_task

        def fake_create_task(coro, *args, **kwargs):
            # When the scheduler calls create_task we should NOT be holding
            # the threading lock — i.e. acquire(blocking=False) must succeed.
            acquired = scheduler._lock.acquire(blocking=False)
            observed_lock_state.append(acquired)
            if acquired:
                scheduler._lock.release()
            return real_create_task(coro, *args, **kwargs)

        with patch("asyncio.create_task", side_effect=fake_create_task):
            scheduler._attempt_restart()
            # Drain any task that may have been scheduled
            await asyncio.sleep(0)

        scheduler._running = False
        if scheduler._task is not None:
            scheduler._task.cancel()
            try:
                await scheduler._task
            except (asyncio.CancelledError, BaseException):
                pass

        assert observed_lock_state == [True], (
            "create_task must run with the lock unheld so the done-callback "
            "cannot deadlock against a concurrent stop()"
        )


# ---------------------------------------------------------------------------
# Exception handler env detection (P1 #16)
# ---------------------------------------------------------------------------


class TestGenericExceptionHandlerDefaultsToProduction:
    """Without the kit attached to ``app.state`` (or with no config), the
    handler must default to production mode and refuse to leak details.
    The earlier check used ``hasattr`` and would silently allow any non-
    "production" string to enable dev-mode leaks."""

    @pytest.mark.asyncio
    async def test_no_kit_attached_returns_no_details(self):
        from identity_plan_kit.shared.exception_handlers import (
            generic_exception_handler,
        )
        import json

        request = MagicMock()
        request.url.path = "/whatever"
        request.app.state = MagicMock(spec=[])  # no identity_plan_kit attribute

        response = await generic_exception_handler(request, RuntimeError("oops"))
        body = json.loads(bytes(response.body).decode())
        assert "RuntimeError" not in json.dumps(body)
        assert "oops" not in json.dumps(body)
