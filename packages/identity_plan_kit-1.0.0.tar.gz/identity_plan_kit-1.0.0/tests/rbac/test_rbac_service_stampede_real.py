"""Tests for RBACService stampede protection using the real service.

Tests cover:
- Concurrent get_user_permissions() for same user_id → 1 DB query (stampede protection)
- Different user_ids query independently
- LRU eviction of per-key locks doesn't break functionality
- Stampede protection works after cache invalidation

CRITICAL: Unlike test_rbac_cache_stampede.py which uses MockRBACService (and thus
documents the ABSENCE of stampede protection), these tests use the REAL RBACService
which has per-key locking via OrderedDict + LRU eviction.
"""

import asyncio
from collections import OrderedDict
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.rbac.cache.permission_cache import InMemoryPermissionCache
from identity_plan_kit.rbac.services.rbac_service import RBACService, MAX_FETCH_LOCKS

pytestmark = pytest.mark.anyio


class TestRealServiceStampedeProtection:
    """Test stampede protection with the real RBACService implementation."""

    async def test_concurrent_same_user_single_db_query(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """
        10 concurrent get_user_permissions() for same user_id → 1 DB query.

        The real RBACService uses per-key locking:
        1. First request acquires lock, hits DB, caches result
        2. Others wait on lock, then find cached result (double-check)
        """
        db_query_count = 0
        user_id = uuid4()
        role_id = uuid4()
        expected_perms = {"read", "write", "admin"}

        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)

        # Replace cache with real InMemory cache
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        async def mock_get_role_permissions(rid):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.05)  # Simulate DB latency
            return expected_perms

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(
            side_effect=mock_get_role_permissions
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(
                *[service.get_user_permissions(user_id, role_id) for _ in range(10)]
            )

        # All should return correct permissions
        assert all(r == expected_perms for r in results)

        # CRITICAL: Only 1 DB query due to stampede protection
        assert db_query_count == 1, (
            f"Expected 1 DB query (stampede protection), got {db_query_count}. "
            f"Per-key locking in RBACService is not working!"
        )

    async def test_different_users_query_independently(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Different user_ids should each trigger their own DB query."""
        db_query_count = 0
        users = [(uuid4(), uuid4()) for _ in range(5)]
        expected_perms = {"read", "write"}

        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        async def mock_get_role_permissions(rid):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.02)
            return expected_perms

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(
            side_effect=mock_get_role_permissions
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            results = await asyncio.gather(
                *[service.get_user_permissions(uid, rid) for uid, rid in users]
            )

        assert all(r == expected_perms for r in results)
        assert db_query_count == 5  # One per unique user

    async def test_stampede_protection_after_invalidation(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """After invalidation, stampede protection still works on re-fetch."""
        db_query_count = 0
        user_id = uuid4()
        role_id = uuid4()
        expected_perms = {"read", "write"}

        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        async def mock_get_role_permissions(rid):
            nonlocal db_query_count
            db_query_count += 1
            await asyncio.sleep(0.05)
            return expected_perms

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(
            side_effect=mock_get_role_permissions
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # First call populates cache
            await service.get_user_permissions(user_id, role_id)
            assert db_query_count == 1

            # Invalidate cache
            await service.invalidate_user_cache(user_id)

            # Now fire concurrent requests again
            results = await asyncio.gather(
                *[service.get_user_permissions(user_id, role_id) for _ in range(10)]
            )

        assert all(r == expected_perms for r in results)
        # Should be 2 total: first call + 1 after invalidation (not 11!)
        assert db_query_count == 2, (
            f"Expected 2 DB queries (initial + 1 after invalidation), got {db_query_count}"
        )

    async def test_cache_hit_after_stampede_zero_queries(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """After stampede populates cache, subsequent calls make 0 queries."""
        db_query_count = 0
        user_id = uuid4()
        role_id = uuid4()

        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        async def mock_get_role_permissions(rid):
            nonlocal db_query_count
            db_query_count += 1
            return {"read"}

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(
            side_effect=mock_get_role_permissions
        )
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # First call
            await service.get_user_permissions(user_id, role_id)
            assert db_query_count == 1

            # 50 more calls - all should be cache hits
            await asyncio.gather(
                *[service.get_user_permissions(user_id, role_id) for _ in range(50)]
            )

        assert db_query_count == 1  # No additional queries


class TestLRULockEviction:
    """Test LRU eviction of per-key locks in RBACService."""

    async def test_locks_are_evicted_when_capacity_exceeded(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """When fetch_locks exceeds MAX_FETCH_LOCKS, oldest are evicted."""
        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        # Verify fetch_locks is an OrderedDict
        assert isinstance(service._fetch_locks, OrderedDict)

        # Manually populate with MAX_FETCH_LOCKS entries
        for _ in range(MAX_FETCH_LOCKS):
            uid = uuid4()
            service._fetch_locks[uid] = asyncio.Lock()

        assert len(service._fetch_locks) == MAX_FETCH_LOCKS

        # Now trigger a new user lookup which needs a new lock
        new_user_id = uuid4()
        role_id = uuid4()

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(return_value={"read"})
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            result = await service.get_user_permissions(new_user_id, role_id)

        assert result == {"read"}
        # New user's lock should be in the dict
        assert new_user_id in service._fetch_locks

    async def test_existing_lock_moves_to_end(
        self,
        mock_config: IdentityPlanKitConfig,
    ):
        """Accessing an existing lock should move it to end (MRU position)."""
        mock_session_factory = MagicMock()
        service = RBACService(mock_config, mock_session_factory)
        service._cache = InMemoryPermissionCache(ttl_seconds=60)

        user_id = uuid4()
        role_id = uuid4()

        mock_uow = AsyncMock()
        mock_uow.rbac.get_role_permissions = AsyncMock(return_value={"read"})
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            # First call creates the lock
            await service.get_user_permissions(user_id, role_id)

        # Add more entries to push user_id away from end
        for _ in range(5):
            service._fetch_locks[uuid4()] = asyncio.Lock()

        # Invalidate cache and call again
        await service.invalidate_user_cache(user_id)

        with patch.object(service, "_create_uow", return_value=mock_uow):
            await service.get_user_permissions(user_id, role_id)

        # user_id should be at end (most recently used)
        last_key = list(service._fetch_locks.keys())[-1]
        assert last_key == user_id
