"""Regression tests for the review fixes applied to the RBAC module.

Each test is named for the review-finding ID it locks in:

    C1 - get_role_permissions filters by PermissionType.ROLE
    C2 - assign_permission_to_role invalidates the cache after commit
    C3 - _fetch_locks growth is bounded under held-lock pressure
    H1 - Closed-state circuit failures reset on success
    H2 - IntegrityError on writes surfaces as ConflictError
    H3 - RBACRepository inherits BaseRepository[RoleModel, Role]
    H4 - PermissionDeniedError propagates (no HTTPException catch in deps)
    H5 - InMemoryPermissionCache uses _write_lock (cache-standards.md)
    H6 - RBACUnitOfWork forwards auto_commit to BaseUnitOfWork
    M1 - _execute_with_retry stops retrying when circuit trips mid-loop
    M3 - requires_any_permission is exported from identity_plan_kit.rbac
"""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4  # noqa: F401 - UUID kept for type annotations

import pytest
from sqlalchemy.exc import IntegrityError

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.rbac import requires_any_permission
from identity_plan_kit.rbac.cache.permission_cache import (
    CacheCircuitState,
    InMemoryPermissionCache,
    RedisPermissionCache,
)
from identity_plan_kit.rbac.dependencies import requires_permission, requires_role
from identity_plan_kit.rbac.domain.entities import PermissionType
from identity_plan_kit.rbac.domain.exceptions import PermissionDeniedError
from identity_plan_kit.rbac.repositories.rbac_repo import RBACRepository
from identity_plan_kit.rbac.services.rbac_service import (
    MAX_FETCH_LOCKS,
    RBACService,
)
from identity_plan_kit.rbac.uow import RBACUnitOfWork
from identity_plan_kit.shared.exceptions import ConflictError
from identity_plan_kit.shared.repository import BaseRepository

pytestmark = pytest.mark.anyio


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_service(
    mock_config: IdentityPlanKitConfig,
    *,
    cache: Any | None = None,
    uow_factory: Any | None = None,
) -> RBACService:
    """Build an RBACService with overrideable cache/UoW for unit tests."""
    service = RBACService(config=mock_config, session_factory=AsyncMock())
    if cache is not None:
        service._cache = cache  # type: ignore[assignment]
    if uow_factory is not None:
        service._create_uow = uow_factory  # type: ignore[method-assign]
    return service


class _StubUoW:
    """Minimal async context manager exposing a `.rbac` repo mock."""

    def __init__(self, rbac: AsyncMock) -> None:
        self.rbac = rbac

    async def __aenter__(self) -> "_StubUoW":
        return self

    async def __aexit__(self, *_: Any) -> None:
        return None


# ---------------------------------------------------------------------------
# C1 - get_role_permissions must filter by PermissionType.ROLE
# ---------------------------------------------------------------------------


class TestC1RoleTypeFilter:
    async def test_query_includes_role_type_filter(self) -> None:
        """The compiled SQL must constrain `permissions.type = 'role'`."""
        repo = RBACRepository(session=AsyncMock())

        captured: dict[str, Any] = {}

        async def fake_execute(stmt: Any) -> Any:
            captured["stmt"] = stmt
            result = AsyncMock()
            result.fetchall = lambda: []
            return result

        repo._session.execute = fake_execute  # type: ignore[method-assign]

        await repo.get_role_permissions(uuid4())

        compiled = str(captured["stmt"].compile(compile_kwargs={"literal_binds": True}))
        assert "permissions.type" in compiled
        assert "'role'" in compiled, (
            "get_role_permissions must filter PermissionModel.type == 'role' "
            "to prevent plan-type permissions from leaking through role grants. "
            f"Got: {compiled}"
        )


# ---------------------------------------------------------------------------
# C2 - assign_permission_to_role invalidates cache AFTER UoW commit
# ---------------------------------------------------------------------------


class TestC2CacheInvalidationOnAssign:
    async def test_assign_permission_to_role_invalidates_all_after_commit(
        self,
        mock_config: IdentityPlanKitConfig,
    ) -> None:
        """assign_permission_to_role must call cache.invalidate_all after the UoW exits."""
        order: list[str] = []

        rbac_repo = AsyncMock()

        async def repo_assign(*_: Any, **__: Any) -> None:
            order.append("repo_write")

        rbac_repo.assign_permission_to_role.side_effect = repo_assign

        class TrackedUoW(_StubUoW):
            async def __aexit__(self, *args: Any) -> None:
                order.append("uow_commit")

        cache = AsyncMock()

        async def cache_invalidate_all() -> None:
            order.append("cache_invalidate_all")

        cache.invalidate_all.side_effect = cache_invalidate_all

        service = _make_service(
            mock_config,
            cache=cache,
            uow_factory=lambda **_: TrackedUoW(rbac_repo),
        )

        await service.assign_permission_to_role(uuid4(), uuid4())

        assert order == ["repo_write", "uow_commit", "cache_invalidate_all"], (
            f"Cache invalidation must run AFTER UoW commit. Got: {order}"
        )


# ---------------------------------------------------------------------------
# C3 - _fetch_locks bounded growth even when oldest locks are held
# ---------------------------------------------------------------------------


class TestC3FetchLocksBounded:
    async def test_fetch_lock_dict_does_not_grow_when_oldest_unlocked(
        self,
        mock_config: IdentityPlanKitConfig,
    ) -> None:
        """When MAX_FETCH_LOCKS is reached and oldest locks are free, eviction reclaims a slot."""
        service = _make_service(mock_config)

        # Pre-populate to capacity with unlocked entries.
        for _ in range(MAX_FETCH_LOCKS):
            service._fetch_locks[uuid4()] = asyncio.Lock()

        await service._acquire_fetch_lock(uuid4())

        assert len(service._fetch_locks) <= MAX_FETCH_LOCKS, (
            "When the oldest lock is unlocked, _acquire_fetch_lock must evict one "
            "to make room for the new entry."
        )

    async def test_fetch_lock_dict_excess_reclaimed_on_next_call(
        self,
        mock_config: IdentityPlanKitConfig,
    ) -> None:
        """Even if all probed oldest locks are held, growth is reclaimed once any lock frees."""
        service = _make_service(mock_config)

        # Fill to capacity with HELD locks - eviction probes will all fail.
        held: list[asyncio.Lock] = []
        held_keys: list[UUID] = []
        for _ in range(MAX_FETCH_LOCKS):
            lock = asyncio.Lock()
            await lock.acquire()
            held.append(lock)
            key = uuid4()
            held_keys.append(key)
            service._fetch_locks[key] = lock

        # First call: cannot evict, dict grows by one.
        new_key_1 = uuid4()
        await service._acquire_fetch_lock(new_key_1)
        size_after_first = len(service._fetch_locks)
        assert size_after_first == MAX_FETCH_LOCKS + 1

        # Release one of the oldest held locks; next eviction should reclaim it.
        held[0].release()
        del service._fetch_locks[held_keys[0]]  # caller would normally release & forget
        # Simulate competition: re-add an unlocked one at the front so eviction probes find it.
        recyclable_key = uuid4()
        service._fetch_locks[recyclable_key] = asyncio.Lock()
        # Move recyclable to the front so eviction probes it first.
        service._fetch_locks.move_to_end(recyclable_key, last=False)

        new_key_2 = uuid4()
        await service._acquire_fetch_lock(new_key_2)

        assert len(service._fetch_locks) <= MAX_FETCH_LOCKS + 1, (
            "Once any old lock becomes evictable, _acquire_fetch_lock must "
            "reclaim a slot rather than growing the dict unbounded."
        )

        # Cleanup
        for lock in held[1:]:
            lock.release()


# ---------------------------------------------------------------------------
# H1 - circuit failures reset on closed-state success
# ---------------------------------------------------------------------------


class TestH1CircuitFailureReset:
    async def test_success_in_closed_state_resets_failure_counter(self) -> None:
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        # Simulate accumulated intermittent failures while CLOSED.
        cache._circuit_state = CacheCircuitState.CLOSED
        cache._circuit_failures = cache.CIRCUIT_FAILURE_THRESHOLD - 1

        await cache._record_success()

        assert cache._circuit_failures == 0, (
            "A success in CLOSED state must reset _circuit_failures so the "
            "circuit doesn't slowly trip from accumulating intermittent errors."
        )

    async def test_success_in_half_open_still_closes_circuit_at_two(self) -> None:
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        cache._circuit_state = CacheCircuitState.HALF_OPEN
        cache._circuit_successes = 1
        cache._circuit_failures = 5

        await cache._record_success()  # 2nd half-open success → close

        assert cache._circuit_state == CacheCircuitState.CLOSED
        assert cache._circuit_failures == 0


# ---------------------------------------------------------------------------
# H2 - IntegrityError → ConflictError
# ---------------------------------------------------------------------------


class TestH2IntegrityErrorWrapped:
    async def test_create_role_wraps_integrity_error(self) -> None:
        repo = RBACRepository(session=AsyncMock())
        repo._session.add = lambda _: None  # type: ignore[method-assign]
        repo._session.flush = AsyncMock(  # type: ignore[method-assign]
            side_effect=IntegrityError("dup", {}, Exception("dup"))
        )

        with pytest.raises(ConflictError):
            await repo.create_role(code="admin", name="Admin")

    async def test_create_permission_wraps_integrity_error(self) -> None:
        repo = RBACRepository(session=AsyncMock())
        repo._session.add = lambda _: None  # type: ignore[method-assign]
        repo._session.flush = AsyncMock(  # type: ignore[method-assign]
            side_effect=IntegrityError("dup", {}, Exception("dup"))
        )

        with pytest.raises(ConflictError):
            await repo.create_permission(code="users:read", type=PermissionType.ROLE)

    async def test_assign_permission_wraps_integrity_error(self) -> None:
        repo = RBACRepository(session=AsyncMock())
        repo._session.add = lambda _: None  # type: ignore[method-assign]
        repo._session.flush = AsyncMock(  # type: ignore[method-assign]
            side_effect=IntegrityError("dup", {}, Exception("dup"))
        )

        with pytest.raises(ConflictError):
            await repo.assign_permission_to_role(uuid4(), uuid4())


# ---------------------------------------------------------------------------
# H3 - RBACRepository inherits BaseRepository
# ---------------------------------------------------------------------------


class TestH3BaseRepositoryInheritance:
    def test_rbac_repo_inherits_base_repository(self) -> None:
        assert issubclass(RBACRepository, BaseRepository), (
            "layer-standards.md mandates BaseRepository[M, E] inheritance."
        )

    def test_rbac_repo_has_model_and_entity_class_attrs(self) -> None:
        assert RBACRepository._model_class.__name__ == "RoleModel"
        assert RBACRepository._entity_class.__name__ == "Role"


# ---------------------------------------------------------------------------
# H4 - PermissionDeniedError propagates from dependencies
# ---------------------------------------------------------------------------


class TestH4PermissionDeniedPropagates:
    async def test_requires_permission_dep_raises_domain_exception(
        self,
        mock_user: Any,
    ) -> None:
        """The dep must let PermissionDeniedError propagate (no HTTPException catch)."""
        # Extract the inner async dependency function from the FastAPI Depends().
        inner = requires_permission("users:read").dependency
        request = AsyncMock()
        rbac_service = AsyncMock()
        rbac_service.require_permission = AsyncMock(
            side_effect=PermissionDeniedError("users:read")
        )
        request.app.state.identity_plan_kit.rbac_service = rbac_service

        with pytest.raises(PermissionDeniedError):
            await inner(request, mock_user)

    async def test_requires_role_dep_raises_domain_exception(
        self,
        mock_user: Any,
    ) -> None:
        inner = requires_role("admin").dependency
        request = AsyncMock()
        rbac_service = AsyncMock()
        rbac_service.require_role = AsyncMock(
            side_effect=PermissionDeniedError(message="Required role: admin")
        )
        request.app.state.identity_plan_kit.rbac_service = rbac_service

        with pytest.raises(PermissionDeniedError):
            await inner(request, mock_user)

    async def test_requires_any_permission_raises_domain_exception(
        self,
        mock_user: Any,
    ) -> None:
        inner = requires_any_permission("a:read", "b:read").dependency
        request = AsyncMock()
        rbac_service = AsyncMock()
        rbac_service.check_permission = AsyncMock(return_value=False)
        request.app.state.identity_plan_kit.rbac_service = rbac_service

        with pytest.raises(PermissionDeniedError):
            await inner(request, mock_user)


# ---------------------------------------------------------------------------
# H5 - InMemoryPermissionCache uses _write_lock
# ---------------------------------------------------------------------------


class TestH5WriteLockNamingConvention:
    def test_in_memory_cache_exposes_write_lock(self) -> None:
        cache = InMemoryPermissionCache(ttl_seconds=60)
        assert hasattr(cache, "_write_lock"), (
            "cache-standards.md requires InMemory caches to protect writes "
            "with `_write_lock` (matching InMemoryAuthCache / InMemoryPlanCache)."
        )
        assert isinstance(cache._write_lock, asyncio.Lock)


# ---------------------------------------------------------------------------
# H6 - RBACUnitOfWork forwards auto_commit, BaseUnitOfWork rolls back read-only
# ---------------------------------------------------------------------------


class TestH6AutoCommitForwarded:
    def test_rbac_uow_accepts_auto_commit_kwarg(self) -> None:
        uow = RBACUnitOfWork(
            session_factory=AsyncMock(),
            auto_commit=False,
        )
        assert uow._auto_commit is False

    def test_rbac_uow_default_auto_commits(self) -> None:
        uow = RBACUnitOfWork(session_factory=AsyncMock())
        assert uow._auto_commit is True

    async def test_read_only_uow_rolls_back_instead_of_commit(self) -> None:
        """auto_commit=False on a clean exit must rollback (not commit) to release locks."""
        session = AsyncMock()
        session.commit = AsyncMock()
        session.rollback = AsyncMock()
        session.close = AsyncMock()

        # async_sessionmaker is callable synchronously and returns an AsyncSession;
        # use MagicMock so calling it doesn't yield a coroutine.
        factory = MagicMock(return_value=session)

        uow = RBACUnitOfWork(session_factory=factory, auto_commit=False)
        async with uow:
            pass

        session.commit.assert_not_called()
        session.rollback.assert_awaited_once()

    async def test_auto_commit_uow_commits_on_clean_exit(self) -> None:
        """auto_commit=True (default) must commit on a clean exit."""
        session = AsyncMock()
        session.commit = AsyncMock()
        session.rollback = AsyncMock()
        session.close = AsyncMock()

        factory = MagicMock(return_value=session)

        uow = RBACUnitOfWork(session_factory=factory)
        async with uow:
            pass

        session.commit.assert_awaited_once()
        session.rollback.assert_not_called()


# ---------------------------------------------------------------------------
# M1 - retry loop aborts when the circuit trips mid-loop
# ---------------------------------------------------------------------------


class TestM1MidRetryCircuitCheck:
    async def test_retry_loop_records_single_failure_per_call(self) -> None:
        """
        A single call that exhausts the retry budget records ONE failure,
        not one per attempt. Recording per-attempt would inflate the failure
        counter and trip the circuit when the operation eventually succeeds
        (this matches RedisAuthCache / RedisPlanCache).
        """
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        cache._circuit_state = CacheCircuitState.CLOSED
        cache._circuit_failures = 0

        import redis.asyncio as redis_asyncio  # noqa: PLC0415

        async def always_fails() -> None:
            raise redis_asyncio.ConnectionError("simulated")

        result = await cache._execute_with_retry("test_op", always_fails)

        assert result is None
        # Three retry attempts, but only ONE failure recorded.
        assert cache._circuit_failures == 1, (
            "Per-attempt failure recording would inflate the counter; the retry "
            f"budget should record one failure per call. Got {cache._circuit_failures}."
        )


# ---------------------------------------------------------------------------
# M3 - requires_any_permission is exported
# ---------------------------------------------------------------------------


class TestM3ExportRequiresAnyPermission:
    def test_requires_any_permission_importable_from_package(self) -> None:
        from identity_plan_kit import rbac as rbac_pkg

        assert "requires_any_permission" in rbac_pkg.__all__
        assert hasattr(rbac_pkg, "requires_any_permission")
