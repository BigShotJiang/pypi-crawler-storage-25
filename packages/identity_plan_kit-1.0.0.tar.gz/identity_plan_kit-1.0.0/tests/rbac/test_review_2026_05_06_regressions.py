"""Regression tests for the 2026-05-06 RBAC review.

Each `Test*` class corresponds to one finding from the comprehensive RBAC
review. The class docstring states the bug and the test asserts the fix
holds — re-introducing the bug would flip these assertions.

Findings covered:
  R1 - Permission cache stale-write prevention (Lua + timestamps)
  R2 - Circuit breaker: single failure recorded per call (not per attempt)
  R3 - Circuit breaker: redis.ResponseError no longer treated as retryable
  R4 - RedisRequiredError inherits BaseError (not bare Exception)
  R5 - Cache key prefix follows {feature}:{entity}: convention
  R6 - get_user_permissions wraps cache.set in try/except (best-effort)
  R7 - PermissionDeniedError does not leak permission code in message
  R8 - require_role does not leak required role code in message
  R9 - permission_denied_handler does not return permission code to client
  R10 - requires_role fails closed when user.role_code is None
  R11 - RolePermissionModel relationships use lazy="noload"
  R12 - admin_auth_error log path masks the email
"""

from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from identity_plan_kit.rbac.cache.permission_cache import (
    InMemoryPermissionCache,
    RedisPermissionCache,
    RedisRequiredError,
)
from identity_plan_kit.rbac.domain.exceptions import PermissionDeniedError
from identity_plan_kit.rbac.models.role_permission import RolePermissionModel
from identity_plan_kit.rbac.services.rbac_service import RBACService
from identity_plan_kit.shared.exceptions import BaseError

pytestmark = pytest.mark.anyio


# ---------------------------------------------------------------------------
# R1 - Stale-write prevention in permission cache
# ---------------------------------------------------------------------------


class TestR1StaleWritePrevention:
    """
    Bug: ``InMemoryPermissionCache.set`` had no invalidation-timestamp check
    and ``RedisPermissionCache.set`` used a plain ``SETEX``. An in-flight DB
    fetch that completed AFTER an ``invalidate()`` would overwrite the empty
    key with stale data and survive the entire TTL.

    Fix: Track per-key + global invalidation timestamps. ``set`` rejects any
    write whose ``fetched_at`` predates the most recent invalidation.
    """

    async def test_in_memory_set_rejects_stale_write_after_global_invalidate(self) -> None:
        cache = InMemoryPermissionCache(ttl_seconds=60)
        user_id = uuid4()

        fetched_at = cache.get_fetch_timestamp()
        # Simulate: another coroutine calls invalidate_all() while our DB
        # fetch is still in flight.
        await asyncio.sleep(0)
        await cache.invalidate_all()

        accepted = await cache.set(user_id, {"users:read"}, fetched_at=fetched_at)

        assert accepted is False, "Stale write must be rejected"
        assert await cache.get(user_id) is None

    async def test_in_memory_set_rejects_stale_write_after_key_invalidate(self) -> None:
        cache = InMemoryPermissionCache(ttl_seconds=60)
        user_id = uuid4()

        fetched_at = cache.get_fetch_timestamp()
        await asyncio.sleep(0)
        await cache.invalidate(user_id)

        accepted = await cache.set(user_id, {"users:read"}, fetched_at=fetched_at)

        assert accepted is False
        assert await cache.get(user_id) is None

    async def test_in_memory_set_accepts_fresh_write_after_invalidate(self) -> None:
        """A fetch started AFTER the invalidate is fresh and must be cached."""
        cache = InMemoryPermissionCache(ttl_seconds=60)
        user_id = uuid4()

        await cache.invalidate(user_id)
        # Fresh fetch after the invalidation
        fetched_at = cache.get_fetch_timestamp()
        accepted = await cache.set(user_id, {"users:read"}, fetched_at=fetched_at)

        assert accepted is True
        assert await cache.get(user_id) == {"users:read"}

    async def test_in_memory_set_without_fetched_at_skips_check(self) -> None:
        """fetched_at=None preserves backward compat (no stale-write guard)."""
        cache = InMemoryPermissionCache(ttl_seconds=60)
        user_id = uuid4()

        await cache.invalidate_all()
        # Caller didn't pass fetched_at — write is allowed.
        accepted = await cache.set(user_id, {"users:read"})
        assert accepted is True

    def test_redis_cache_has_lua_timestamp_check_script(self) -> None:
        """The Redis backend ships a Lua atomic stale-write guard."""
        assert hasattr(RedisPermissionCache, "LUA_SET_WITH_TIMESTAMP_CHECK")
        script = RedisPermissionCache.LUA_SET_WITH_TIMESTAMP_CHECK
        assert "fetched_at" in script
        assert "global_inv" in script
        assert "key_inv" in script

    def test_redis_cache_has_invalidation_key_helpers(self) -> None:
        """Per-key and global invalidation timestamp keys exist."""
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        user_id = uuid4()

        assert "_invalidated:" in cache._make_invalidation_key(user_id)
        assert cache._make_global_invalidation_key().endswith("_global_invalidated")


# ---------------------------------------------------------------------------
# R2 - Circuit breaker: single failure per call (not per attempt)
# ---------------------------------------------------------------------------


class TestR2CircuitBreakerSingleFailure:
    """
    Bug: ``_execute_with_retry`` recorded a failure on EVERY retry attempt.
    With ``REDIS_RETRY_ATTEMPTS=3`` and ``CIRCUIT_FAILURE_THRESHOLD=5``,
    three transient hiccups (each succeeding on attempt 3) accumulated
    9 failures + 3 successes -> circuit opened despite every operation
    completing.

    Fix: Record one failure per call AFTER retry budget is exhausted.
    """

    async def test_eventually_successful_call_records_no_failure(self) -> None:
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        cache._circuit_failures = 0

        import redis.asyncio as redis_asyncio  # noqa: PLC0415

        call_count = 0

        async def fail_then_succeed() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise redis_asyncio.ConnectionError("transient")
            return "ok"

        result = await cache._execute_with_retry("test", fail_then_succeed)

        assert result == "ok"
        # Old buggy code: 2 failures + 1 success -> circuit_failures==2
        # Fixed code: 0 failures because the call ultimately succeeded.
        assert cache._circuit_failures == 0


# ---------------------------------------------------------------------------
# R3 - redis.ResponseError is non-retryable
# ---------------------------------------------------------------------------


class TestR3ResponseErrorNotRetryable:
    """
    Bug: ``redis.ResponseError`` (WRONGTYPE / OOM / READONLY / NOSCRIPT)
    was retried alongside ConnectionError/TimeoutError. ResponseError is a
    server protocol-level rejection — retrying wastes time and can replay
    a broken write.

    Fix: ResponseError falls through to the catch-all and is re-raised
    after recording one failure. No retries.
    """

    async def test_response_error_is_raised_immediately(self) -> None:
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        cache._circuit_failures = 0

        import redis  # noqa: PLC0415

        call_count = 0

        async def raises_response_error() -> None:
            nonlocal call_count
            call_count += 1
            raise redis.ResponseError("WRONGTYPE Operation against a key holding the wrong kind of value")

        with pytest.raises(redis.ResponseError):
            await cache._execute_with_retry("test", raises_response_error)

        assert call_count == 1, "ResponseError must not be retried"
        assert cache._circuit_failures == 1


# ---------------------------------------------------------------------------
# R4 - RedisRequiredError inherits BaseError
# ---------------------------------------------------------------------------


class TestR4RedisRequiredErrorBaseError:
    """
    Bug: ``RedisRequiredError`` inherited bare ``Exception``, bypassing the
    standard ``BaseError`` envelope at the global handler.

    Fix: Inherit from ``BaseError`` with ``status_code=503`` (matches
    ``plans/cache/exceptions.py`` reference pattern).
    """

    def test_inherits_from_base_error(self) -> None:
        assert issubclass(RedisRequiredError, BaseError)

    def test_has_envelope_fields(self) -> None:
        err = RedisRequiredError("Redis unavailable")
        assert err.code == "REDIS_REQUIRED"
        assert err.status_code == 503
        # to_dict() works via BaseError
        envelope = err.to_dict()
        assert envelope["success"] is False
        assert envelope["error"]["code"] == "REDIS_REQUIRED"


# ---------------------------------------------------------------------------
# R5 - Cache key prefix follows {feature}:{entity}: convention
# ---------------------------------------------------------------------------


class TestR5KeyConvention:
    """
    Bug: Default ``key_prefix`` was ``ipk:perms:``, violating the
    ``{feature}:{entity}:{identifier}`` convention from cache-standards.md
    (see ``auth:user:{user_id}``, ``plans:user_plan:{user_id}``).

    Fix: Default to ``rbac:permission:`` so keys are
    ``rbac:permission:{user_id}``.
    """

    def test_redis_cache_default_prefix(self) -> None:
        cache = RedisPermissionCache(redis_url="redis://localhost:6379/0")
        user_id = uuid4()

        key = cache._make_key(user_id)

        assert key.startswith("rbac:permission:")
        assert key == f"rbac:permission:{user_id}"

    def test_facade_default_prefix(self) -> None:
        from identity_plan_kit.rbac.cache.permission_cache import PermissionCache

        cache = PermissionCache(ttl_seconds=60, redis_url="redis://localhost:6379/0")

        backend = cache._backend
        assert isinstance(backend, RedisPermissionCache)
        assert backend._key_prefix == "rbac:permission:"


# ---------------------------------------------------------------------------
# R6 - Best-effort cache.set in get_user_permissions
# ---------------------------------------------------------------------------


class TestR6BestEffortCacheSet:
    """
    Bug: A non-retryable Redis error (e.g., AUTH failure, ResponseError)
    raised from ``cache.set()`` propagated through ``get_user_permissions``,
    crashing the auth dependency with a 500 even though we already had the
    permissions from DB.

    Fix: Wrap ``cache.set`` in try/except per cache-standards.md best-effort
    rule. The DB result is returned regardless of cache write outcome.
    """

    async def test_cache_set_exception_does_not_crash_permission_check(self) -> None:
        from identity_plan_kit.config import IdentityPlanKitConfig

        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost/test",
            secret_key="x" * 32,
            google_client_id="id",
            google_client_secret="secret",
            google_redirect_uri="http://localhost/cb",
        )

        permissions = {"users:read"}

        mock_uow = AsyncMock()
        mock_uow.__aenter__ = AsyncMock(return_value=mock_uow)
        mock_uow.__aexit__ = AsyncMock(return_value=None)
        mock_uow.rbac.get_role_permissions = AsyncMock(return_value=permissions)

        mock_cache = AsyncMock()
        mock_cache.get = AsyncMock(return_value=None)
        mock_cache.get_fetch_timestamp = MagicMock(return_value=1.0)
        mock_cache.set = AsyncMock(side_effect=RuntimeError("Redis exploded"))

        service = RBACService(config, MagicMock())

        with (
            patch.object(service, "_create_uow", return_value=mock_uow),
            patch.object(service, "_cache", mock_cache),
        ):
            user_id = uuid4()
            role_id = uuid4()
            # Must NOT raise even though cache.set blew up.
            result = await service.get_user_permissions(user_id, role_id)

        assert result == permissions
        mock_cache.set.assert_called_once()


# ---------------------------------------------------------------------------
# R7 - PermissionDeniedError does not leak permission code in message
# ---------------------------------------------------------------------------


class TestR7PermissionCodeNotInMessage:
    """
    Bug: ``PermissionDeniedError("admin:write")`` produced
    ``message="Permission denied: admin:write"``. Any authenticated user
    could probe endpoints and enumerate the entire permission taxonomy
    from the 403 response body (CWE-209).

    Fix: ``message`` is always the generic class-level string. The
    permission code is preserved as ``permission_code`` attribute for
    server-side logging only.
    """

    def test_message_does_not_contain_permission_code(self) -> None:
        err = PermissionDeniedError("admin:write")

        assert "admin:write" not in err.message
        assert "admin:write" not in str(err)
        assert err.message == "Permission denied"

    def test_permission_code_preserved_as_attribute(self) -> None:
        err = PermissionDeniedError("admin:write")

        assert err.permission == "admin:write"
        assert err.permission_code == "admin:write"

    def test_no_details_dict_with_permission_code(self) -> None:
        """The leaked permission MUST NOT be in details either."""
        err = PermissionDeniedError("admin:write")

        # Either no details, or details without 'permission' key.
        assert err.details is None or "permission" not in (err.details or {})


# ---------------------------------------------------------------------------
# R8 - require_role does not leak required role code
# ---------------------------------------------------------------------------


class TestR8RequireRoleNoLeak:
    """
    Bug: ``require_role`` raised ``PermissionDeniedError(message=
    "Required role: admin")``, exposing the internal role taxonomy of the
    endpoint to any authenticated user (CWE-209).

    Fix: Use the generic class-level message; log the role context
    server-side only.
    """

    async def test_role_mismatch_message_does_not_leak_required_role(self) -> None:
        from identity_plan_kit.config import IdentityPlanKitConfig

        config = IdentityPlanKitConfig(
            database_url="postgresql+asyncpg://test:test@localhost/test",
            secret_key="x" * 32,
            google_client_id="id",
            google_client_secret="secret",
            google_redirect_uri="http://localhost/cb",
        )
        service = RBACService(config, MagicMock())

        with pytest.raises(PermissionDeniedError) as exc_info:
            await service.require_role("user", "superadmin")

        assert "superadmin" not in str(exc_info.value)
        assert "superadmin" not in exc_info.value.message


# ---------------------------------------------------------------------------
# R9 - permission_denied_handler does not return permission code to client
# ---------------------------------------------------------------------------


class TestR9HandlerNoLeakDetails:
    """
    Bug: ``permission_denied_handler`` forwarded ``details={"permission":
    permission_code}`` to the response body, leaking the authz scheme.

    Fix: Drop the ``details`` argument from ``create_error_response`` for
    permission_denied responses. The code remains in the server-side log
    only.
    """

    async def test_handler_response_omits_details(self) -> None:
        import json

        from fastapi import Request

        from identity_plan_kit.exception_handlers import permission_denied_handler

        scope = {
            "type": "http",
            "method": "GET",
            "path": "/admin/users",
            "headers": [],
            "query_string": b"",
        }
        request = Request(scope)
        exc = PermissionDeniedError("admin:write")

        response = await permission_denied_handler(request, exc)
        body = json.loads(response.body)

        # Whatever the envelope shape, "admin:write" must not appear anywhere.
        body_str = json.dumps(body)
        assert "admin:write" not in body_str, (
            f"Permission code leaked in response body: {body_str}"
        )


# ---------------------------------------------------------------------------
# R10 - requires_role fails closed when user.role_code is None
# ---------------------------------------------------------------------------


class TestR10RequiresRoleNoneRoleCode:
    """
    Bug: ``dependencies.requires_role`` did
    ``user_role_code=user.role_code or ""``. With ``user.role_code=None``
    (e.g., from ``CurrentUserNoRole``), the silent ``""`` coercion would
    PASS for an endpoint declared as ``requires_role("")`` — a footgun.

    Fix: Fail closed with ``PermissionDeniedError`` when ``role_code`` is
    None. The user_role_code is never coerced to "".
    """

    async def test_none_role_code_fails_closed(self) -> None:
        from identity_plan_kit.rbac.dependencies import requires_role

        dep = requires_role("admin").dependency
        request = MagicMock()
        request.app.state.identity_plan_kit.rbac_service = AsyncMock()

        user = MagicMock()
        user.role_code = None
        user.id = uuid4()

        with pytest.raises(PermissionDeniedError):
            await dep(request, user)

    async def test_none_role_code_does_not_call_service(self) -> None:
        """Verify we never invoke require_role with `""` for a None role."""
        from identity_plan_kit.rbac.dependencies import requires_role

        dep = requires_role("admin").dependency
        request = MagicMock()
        rbac_service = AsyncMock()
        request.app.state.identity_plan_kit.rbac_service = rbac_service

        user = MagicMock()
        user.role_code = None
        user.id = uuid4()

        with pytest.raises(PermissionDeniedError):
            await dep(request, user)

        rbac_service.require_role.assert_not_called()


# ---------------------------------------------------------------------------
# R11 - RolePermissionModel relationships use lazy="noload"
# ---------------------------------------------------------------------------


class TestR11RelationshipsNoload:
    """
    Bug: ``RolePermissionModel.role`` had no explicit ``lazy=`` (defaulted
    to ``"select"`` -> async lazy-load -> MissingGreenlet) and
    ``RolePermissionModel.permission`` used ``lazy="selectin"``, both
    diverging from database-patterns.md ("``lazy=\"noload\"`` on all
    relationships").

    Fix: Both relationships use ``lazy="noload"``. Callers in
    ``rbac_repo.py`` already chain explicit ``selectinload`` for queries
    that need the permission code.
    """

    def test_role_relationship_uses_noload(self) -> None:
        rel = RolePermissionModel.__mapper__.relationships["role"]
        assert rel.lazy == "noload"

    def test_permission_relationship_uses_noload(self) -> None:
        rel = RolePermissionModel.__mapper__.relationships["permission"]
        assert rel.lazy == "noload"


# ---------------------------------------------------------------------------
# R12 - admin_auth_error log path masks email
# ---------------------------------------------------------------------------


class TestR12AdminAuthErrorMasksEmail:
    """
    Bug: ``admin/auth.py`` ``_authenticate_db_admin`` logged plaintext
    email on the exception path while ``login()`` correctly used
    ``mask_email``.

    Fix: Use ``mask_email`` in the exception path too.
    """

    async def test_db_error_masks_email_in_log(self) -> None:
        from identity_plan_kit.admin.auth import AdminAuthBackend

        # Force the inner DB query to raise.
        session_factory = MagicMock(side_effect=RuntimeError("db down"))
        backend = AdminAuthBackend(
            secret_key="x" * 32,
            admin_email=None,
            admin_password=None,
            session_factory=session_factory,
        )

        captured: dict[str, object] = {}

        def fake_error(event: str, **kwargs: object) -> None:
            captured["event"] = event
            captured.update(kwargs)

        with patch("identity_plan_kit.admin.auth.logger") as mock_logger:
            mock_logger.error = fake_error
            result = await backend._authenticate_db_admin("alice@example.com", "pw")

        assert result is False
        # Email must NOT appear verbatim in the log args.
        assert captured.get("event") == "admin_auth_error"
        logged_email = captured.get("email")
        assert logged_email != "alice@example.com", (
            f"plaintext email leaked into admin_auth_error log: {logged_email}"
        )
