"""
User metadata example for IdentityPlanKit.

Shows how to use the metadata JSONB field on users to store
custom per-user data (country, preferences, feature flags, etc.)
without subclassing models or entities.

Metadata supports partial merge semantics:
- Sending a dict merges keys into existing metadata
- Sending null clears all metadata

Run:
    IPK_ENV_FILE=examples/playing/.env.local uv run examples/playing/user_metadata.py
"""

from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse

from identity_plan_kit import IdentityPlanKit, IdentityPlanKitConfig
from identity_plan_kit.auth import CurrentUser
from identity_plan_kit.shared.http_utils import get_client_ip

config = IdentityPlanKitConfig(
    access_token_expire_minutes=15,
    refresh_token_expire_days=30,
)

kit = IdentityPlanKit(config)

app = FastAPI(
    title="User Metadata Example",
    lifespan=kit.lifespan,
)

kit.setup(app)


# =============================================================================
# Simulated GeoIP service (replace with a real one like geoip2 / ipinfo)
# =============================================================================

COUNTRY_DB: dict[str, str] = {
    "1.2.3.4": "US",
    "5.6.7.8": "DE",
}


async def detect_country(ip: str | None) -> str | None:
    """Look up country from IP address. Replace with a real GeoIP provider."""
    if ip is None:
        return None
    return COUNTRY_DB.get(ip)


# =============================================================================
# Custom Google OAuth callback with country detection
# =============================================================================

@app.get("/auth/google/callback")
async def google_callback_with_metadata(request: Request) -> RedirectResponse:
    """
    Custom Google OAuth callback that detects country from IP and stores
    it in user metadata right after authentication.

    This replaces the default /auth/google/callback with extra logic.
    """
    code = request.query_params.get("code")
    if not code:
        return RedirectResponse("/login?error=missing_code")

    auth_service = request.app.state.identity_plan_kit.auth_service
    ip = get_client_ip(request, trust_proxy=config.trust_proxy_headers)

    # 1. Authenticate with Google (creates user if first login)
    user, access_token, refresh_token = await auth_service.authenticate_google(
        code=code,
        ip_address=ip,
        user_agent=request.headers.get("user-agent"),
    )

    # 2. Detect country from IP and save to metadata
    country = await detect_country(ip)
    if country:
        await auth_service.update_profile(
            user_id=user.id,
            metadata={
                "country": country,
                "signup_ip": ip,
                "notifications_enabled": True,
            },
        )

    # 3. Redirect to frontend with tokens in cookies
    response = RedirectResponse("/dashboard")
    response.set_cookie("access_token", access_token, httponly=True, secure=True)
    return response


# =============================================================================
# Reading metadata
# =============================================================================

@app.get("/me")
async def get_me(user: CurrentUser) -> dict[str, Any]:
    """Read metadata from the authenticated user."""
    return {
        "id": str(user.id),
        "email": user.email,
        "country": user.metadata.get("country"),
        "notifications": user.metadata.get("notifications_enabled", True),
        "all_metadata": user.metadata,
    }


# =============================================================================
# Updating metadata (partial merge)
# =============================================================================

@app.patch("/me/preferences")
async def update_preferences(
    request: Request,
    user: CurrentUser,
) -> dict[str, Any]:
    """
    Update user preferences stored in metadata.

    Partial merge: existing keys are preserved, only provided keys are updated.

    Examples:
        # Set preferences:
        PATCH /me/preferences
        {"theme": "dark", "language": "en"}

        # Update one key (others preserved):
        PATCH /me/preferences
        {"notifications_enabled": false}
        # Result: {"country": "US", "theme": "dark", "language": "en", "notifications_enabled": false}

        # Clear all metadata:
        PATCH /me/preferences  with body: null
    """
    body = await request.json()

    auth_service = request.app.state.identity_plan_kit.auth_service
    updated_user = await auth_service.update_profile(
        user_id=user.id,
        metadata=body,  # dict to merge, or None to clear
    )

    return {
        "id": str(updated_user.id),
        "metadata": updated_user.metadata,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
