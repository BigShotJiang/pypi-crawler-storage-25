---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# Feature Structure

## Current Features

| Feature | Tier | Description |
|---------|------|-------------|
| `auth` | Standard | OAuth (Google), JWT, user management, refresh tokens |
| `rbac` | Standard | Roles, permissions, role-based access checks |
| `plans` | Complex | Subscription plans, features, quotas, usage tracking |
| `admin` | Minimal | SQLAdmin panel integration |
| `shared` | Infrastructure | Base classes, exceptions, security, health, metrics |

## Feature Tiers

| Tier | When | Create These | Skip These |
|------|------|-------------|------------|
| **Minimal** | No own DB models, read-only or external | handler, service, dependencies | domain, models, repo, UoW, exceptions |
| **Standard** | Own DB models, basic CRUD | + domain entities, models, repo, UoW, exceptions | |
| **Complex** | Multiple concerns, concurrency, multi-layer cache | + split services/repos/cache | |

## Layer Decision Rules

### Services
- **1 file** — single cohesive concern (all tiers)
- **Split** — only when feature has 3+ independent workflows

### Repositories
- **0** — Minimal tier (no DB)
- **1 file** — Standard tier, single entity concern
- **Split by entity** — when repos span 3+ unrelated entities

### Unit of Work
- **0** — Minimal tier (no DB)
- **1 class** — Standard tier or Complex with shared repo access
- **Split 1:1 with services** — only when services access non-overlapping repos

### Domain
- **0 files** — Minimal tier with no business logic
- **1 file** — Standard tier (entity + value object together)
- **1 file per entity concern** — Complex tier with 3+ distinct entities

### Cache
- **Inline** — private methods on service for simple cache ops
- **Directory with abstract + implementations** — when feature needs Redis + InMemory support

### Handlers
- **1 file** — Minimal and Standard tiers
- **Split 1:1 with services** — only for workflow-heavy Complex features

### Models
- **0** — Minimal tier
- **1+ files** — one per model or grouped by concern

### Exceptions
- **Single file, always** — never splits regardless of tier
- **Skip entirely** — if no feature-specific exceptions needed

## Anti-Patterns Checklist

| Anti-Pattern | Fix |
|---|---|
| Dead exceptions — empty files never imported | Don't create speculative exception files |
| Empty domain layer — wraps data with zero logic | Skip domain for minimal-tier features |
| DTO explosion — many identical DTOs | Single shared DTO |
| Premature workflow split | Keep single service until 3+ independent workflows |
