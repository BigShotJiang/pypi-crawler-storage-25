---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# Cache Standards

## Key Convention

`{feature}:{entity}:{identifier}` (e.g., `auth:user:{user_id}`, `plans:user_plan:{user_id}`)

Use simple key formatting with UUIDs: `f"auth:user:{user_id}"`

## Architecture

Each feature defines its own abstract cache with Redis and InMemory implementations:
- `AbstractPermissionCache` / `InMemoryPermissionCache` / `RedisPermissionCache`
- `AbstractPlanCache` / `InMemoryPlanCache` / `RedisPlanCache`
- `AbstractAuthCache` / `InMemoryAuthCache` / `RedisAuthCache`

## TTLs

All from `IdentityPlanKitConfig`, never hardcode.

## Invalidation Ordering (Two-Layer)

1. Mark DB staleness IN-TRANSACTION (inside `async with UoW`)
2. Invalidate Redis/InMemory cache AFTER commit (outside `async with UoW`)
3. Best-effort cache writes — wrap in try/except, log failures
4. InMemory caches use LRU eviction with bounded max entries

## In-Memory Cache Pattern

Use `OrderedDict` with max size for LRU eviction. Protect writes with `asyncio.Lock` (`_write_lock`).

## Redis Cache Pattern

Redis caches include built-in circuit breaker logic (`CacheCircuitState`) to handle Redis failures gracefully — fall through to DB on circuit open.
