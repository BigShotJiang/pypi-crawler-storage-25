---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# Database Patterns

## Concurrency

**Pessimistic Locking (Primary Strategy):**
- `SELECT FOR UPDATE` for read-modify-write — acquires row-level lock until commit/rollback
- Only in concrete repos where race conditions are real (e.g., `get_for_update()`)

**Atomic get_or_create:**
- `INSERT ON CONFLICT DO NOTHING` then `SELECT FOR UPDATE` if conflict occurred
- Prevents race conditions on insert

**Count with Locking:**
- `SELECT id FOR UPDATE` when enforcing limits (e.g., max preferences) — locks rows, minimizes data transfer

## Resilience

| Pattern | Where | How |
|---------|-------|-----|
| Rate Limiting | Handlers | slowapi `@limiter.limit()` with config-driven limits |
| Circuit Breaker | Redis caches | `CircuitBreaker` class from `shared/circuit_breaker.py` |
| Timeouts | DB statements | `database_statement_timeout_ms` in config (default 30s) |
| Graceful Shutdown | App lifecycle | `shutdown_grace_period_seconds` in config |

**Circuit Breaker:**
- Single `CircuitBreaker` class with states: `CLOSED`, `OPEN`, `HALF_OPEN`
- Built-in circuit breaker logic in cache implementations for Redis failure tolerance
- On circuit open, cache misses fall through to DB (no errors surfaced)

## N+1 Prevention

- **Eager loading** via `selectinload` — preferred for one-to-many (avoids cartesian product)
- **`lazy="noload"` on all relationships** — prevents accidental lazy loading; always use explicit `selectinload`
- Define load options per query (full/summary/minimal)

## Model Conversion

Repositories use `BaseRepository[M, E]` generic with:
- `_to_entity(model)` — convert ORM model to domain entity
- `_create_model(**kwargs)` — create ORM model from kwargs
- `_extract_model_fields(model)` — extract field dict from model
