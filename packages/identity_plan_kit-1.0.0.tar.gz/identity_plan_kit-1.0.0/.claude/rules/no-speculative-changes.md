# No Speculative Changes
[HIGH PRIORITY]
**Rule of thumb: ship fixes for bugs that exist today. Do NOT ship defenses against bugs that *might* exist tomorrow.**
<SIMPLICITY WINS>

Reviews surface two kinds of findings. Treat them differently.

## Ship these (real impact):

- **Bug** — code returns the wrong answer, crashes, leaks resources, or violates a documented contract on a real input that the system can produce today. File:line + reproduction.
- **Rule violation** — code diverges from `.claude/rules/*.md`. The rule is the source of truth; bring the code into compliance.
- **Security issue** — exploitable today by a real actor with current code (CSRF, injection, auth bypass, IDOR, secret leak, fail-open auth check, etc.).
- **Standards-driven consistency** — when the rules require a uniform pattern (e.g., `response_model=` on every route), bring outliers into compliance.

## Do NOT ship these (speculative):

- **"What if a future caller…"** — a hypothetical future refactor that misuses an API. The current callers are correct; the defense is paying real complexity for an imagined bug.
- **"What if the cache shape changes…"** — schema versioning on a payload whose shape has not changed and is not changing. Add the version when you make the migration, not preemptively.
- **"What if this gets called from a hot path…"** — performance defense against a hypothetical future call site. Profile the real hot path; optimize the proven bottleneck.
- **"This could be safer if…"** — refactors that re-shape working code without fixing a defect. Extracting helpers, splitting factories, renaming for clarity, adding documentation comments to working code, etc., when there is no defect.
- **"Defense-in-depth against future regressions"** — assertions, guards, and runtime checks for invariants the codebase already enforces structurally.
- **"This is technically inconsistent with that other module"** — only fix when it's actually a rule violation. Two cohesive patterns that diverge by design are fine.

## How to decide

For every proposed change, answer: **what real input or scenario, reachable today, makes the current code wrong?** If the answer is "if someone in the future does X" — **don't ship it**. If the answer is "this curl command produces a 500 / corrupts data / leaks secrets / bypasses auth" — ship it.

A reviewer flagging "future-migration safety" or "future-caller misuse" is **not** sufficient justification. Acknowledge the finding, judge it against this rule, and skip if speculative.

## When in doubt

- Skip. The conservative default is to not change working code.
- If the standards in `.claude/rules/*.md` require it, ship it (rule violation = real impact).
- If the user asks for it, ship it.
- Otherwise: leave the code alone.

## Why this matters

Endless speculative refactors:
- Inflate diffs and PR review burden without fixing real defects
- Introduce regressions in working code (every change has a non-zero risk of breaking something)
- Drive an infinite loop of review → speculative fix → review → speculative fix
- Train the team to mistake activity for progress

Stop when the code is correct against today's inputs and consistent with the rules. That is "done."
