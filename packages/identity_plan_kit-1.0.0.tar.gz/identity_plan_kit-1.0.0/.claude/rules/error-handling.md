---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# Error Handling

## Error Chain

```
Repository (returns None/False) -> Service (raises BaseError subclass) -> Handler (propagates) -> Global Error Handler (maps to HTTP)
```

- **Repository**: returns None or empty results when not found. Returns False from delete/update when entity missing. NEVER raises NotFoundError.
- **Service**: checks repo results, raises NotFoundError with generic messages. Enforces business rules.
- **Handler**: calls service, lets exceptions propagate. NEVER catches and re-raises.
- **"Not found" is a business decision, not a data access concern.**

## Exception Hierarchy

All exceptions inherit from `BaseError` (in `shared/exceptions.py`):

| Exception | HTTP Status | Use When |
|-----------|-------------|----------|
| `NotFoundError` | 404 | Entity not found by ID |
| `ValidationError` | 422 | Business rule violation |
| `AuthenticationError` | 401 | Invalid credentials, expired token |
| `AuthorizationError` | 403 | Insufficient permissions |
| `ConflictError` | 409 | Duplicate, collision, constraint violation |
| `RateLimitError` | 429 | Rate limit exceeded |
| `BaseError` | 500 (fallback) | Unmatched error — treat as bug |

Additional specialized exceptions:
- `AccountLockedError` (in `shared/lockout.py`)
- `CircuitBreakerError` (in `shared/circuit_breaker.py`)

## Rules

- Always inherit from `BaseError` or its subclasses — never bare `Exception`
- Never inherit from HTTP exceptions — leaks HTTP into domain
- Never include UUIDs in exception message strings — keep as attributes only
- Never `str(exc)` to client — use generic messages, log details internally
- Generic 500 messages — error handler must not leak internal details (CWE-209)
