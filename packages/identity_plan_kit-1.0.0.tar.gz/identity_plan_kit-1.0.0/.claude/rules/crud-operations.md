---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# CRUD Operations Standards

Pick the right pattern per scenario. All operations follow: Handler -> Service -> Repository -> DB.

---

## READ Patterns

| Pattern | When | How | Notes |
| ------- | ---- | --- | ----- |
| **Single by ID** | Detail view | Query with `selectinload` for relations | Return None if not found |
| **Single by ID (cached)** | Frequent access | Service: cache check -> DB -> cache set (best-effort) | |
| **Filtered list** | Bounded results | Query with filters | Always apply soft-delete filter if applicable |
| **Batch by IDs** | Loading entities from an ID list | `.in_()` clause | Guard batch size (`<= 100`) |

---

## CREATE Patterns

| Pattern | When | Mechanism |
| ------- | ---- | --------- |
| **Simple insert** | No uniqueness concerns | Standard insert. Wrap `IntegrityError` as domain exception |
| **Atomic get-or-create** | Concurrent creation risk | `INSERT ON CONFLICT DO NOTHING` then `SELECT FOR UPDATE` |
| **Create with max limit** | Enforce per-user limits | `SELECT id FOR UPDATE` (count+lock) -> check limit -> insert |

---

## UPDATE Patterns

| Pattern | When | Mechanism |
| ------- | ---- | --------- |
| **Simple update** | No race concern | Standard UPDATE query |
| **Pessimistic lock + update** | Real race condition risk | `SELECT FOR UPDATE` -> validate -> modify -> UPDATE |
| **Direct field update** | No entity load needed (soft delete, mark stale) | Direct UPDATE with WHERE clause |
| **Retry on collision** | Generated unique values (tokens, slugs) | `tenacity` retry wrapping the persist call |

**Domain updates:** Use `dataclasses.replace()` or domain methods returning new instances.

---

## DELETE Patterns

| Pattern | When | Mechanism |
| ------- | ---- | --------- |
| **Soft delete** | Recoverable content | UPDATE: set `is_deleted=True, updated_at=now()` |
| **Hard delete** | Permanent removal | DELETE with ownership in WHERE clause |
| **CASCADE delete** | Parent with children | Delete parent only — CASCADE handles children |
