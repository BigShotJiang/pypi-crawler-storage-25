---
paths:
  - "src/identity_plan_kit/**/*.py"
---

# Layer-by-Layer Standards

## Handler

- Thin layer — HTTP concerns only
- Rate limiting on all endpoints via slowapi `@limiter.limit()` with config-driven limits
- Flow: call service -> map to DTO -> return
- Use `Annotated[str, Path(...)]` for path params with constraints
- Let exceptions propagate to the global error handler
- **NEVER** check for None and raise NotFoundError — that's the service's job

## Service

- Cache check before DB query; cache set after (best-effort — log failures, don't re-raise)
- UoW for all DB operations
- Invalidate cache after writes (after UoW commit, not inside)
- All TTLs from `IdentityPlanKitConfig` — never hardcode
- Use `TypedDict` parameter objects when methods have >10 params
- Enrich entities directly after update instead of re-fetching from DB
- Scope retry decorators narrowly — only wrap the retryable operation
- **NEVER** import HTTP exceptions — services raise only `BaseError` subclasses

## Domain

- **Entities** (persisted, have identity): plain `@dataclass`
- **Value objects** (no identity, computed/transient): `@dataclass(frozen=True)`
- Use for validation and business logic
- Split entity file when >500 lines OR >3 concerns
- No cache serialization in domain — keep entities pure

## Repository

- Inherit from `BaseRepository[M, E]` (M = model type, E = entity type)
- Return domain entities (not models) via `_to_entity()`
- Explicit eager loading via `selectinload` parameters
- Wrap `IntegrityError` as domain exceptions (never leak SQLAlchemy)
- Use atomic `INSERT ON CONFLICT` for race conditions
- Split when >10 methods spanning multiple concerns

## UoW

- **Standard (auto-commit):** `async with EntityUnitOfWork(session_factory=sf) as uow:`
- **Read-only:** pass `auto_commit=False`
- **External session:** `BaseUnitOfWork` accepts external session for shared transactions
- Match UoW classes to service concerns for clear responsibility boundaries

## DTO

- Inherit from `BaseRequest` (requests) or `BaseResponse` (responses)
- Wrap in `ResponseModel[T]` for API envelope
- Split when file >400 lines OR handles >3 concerns
- Group related request/response DTOs together

## Exceptions

All feature exceptions MUST inherit from `BaseError` or its subclasses. See `error-handling.md` for the full hierarchy.

## Dependencies

- Each feature has a `dependencies.py` with a DI container
- External dependencies (session_factory, cache) injected from infrastructure
- Services as Singletons (stateless)

## Settings

- Single `IdentityPlanKitConfig` class (Pydantic BaseSettings)
- Default env prefix: `IPK_`
- Supports: direct instantiation, `from_env(prefix=)`, `from_settings(settings, mapping=)`
- All cache TTLs in **seconds** (never minutes)
- Never hardcode rate limits — use config fields
