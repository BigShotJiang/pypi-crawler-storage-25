from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Callable, TypedDict

from ssot_contracts import load_document_manifest as contracts_load_document_manifest
from ssot_contracts import read_packaged_document_bytes as contracts_read_packaged_document_bytes
from ssot_contracts import read_packaged_document_text as contracts_read_packaged_document_text
from ssot_contracts.contract_data import CONTRACT_DATA


DOCUMENT_KINDS = ("adr", "spec")
DOCUMENT_SECTIONS = CONTRACT_DATA["document_contract"]["sections"]
DOCUMENT_ID_PREFIXES = {"adr": "adr:", "spec": "spc:"}
DOCUMENT_FILENAME_PREFIXES = CONTRACT_DATA["document_contract"]["filename_prefixes"]
DOCUMENT_PATH_KEYS = CONTRACT_DATA["document_contract"]["path_keys"]
DOCUMENT_RESERVATION_KEYS = CONTRACT_DATA["document_contract"]["reservation_keys"]
DOCUMENT_FILE_SUFFIXES = (".json", ".yaml")
DOCUMENT_ORIGINS = {"ssot-core", "ssot-origin", "repo-local", "extension-pack"}
EXTENSION_PACK_RESERVATION_PREFIX = "extension-pack:"
DOCUMENT_STATUSES = tuple(CONTRACT_DATA["choice_sets"]["document_statuses"])
CREATE_ALLOWED_STATUSES = ("draft", "in_review", "accepted", "rejected", "withdrawn")
TERMINAL_STATUSES = ("rejected", "withdrawn", "superseded", "retired")
TRANSITION_RULES = {
    "draft": {"in_review", "accepted", "rejected", "withdrawn"},
    "in_review": {"draft", "accepted", "rejected", "withdrawn"},
    "accepted": {"superseded", "retired"},
    "rejected": set(),
    "withdrawn": set(),
    "superseded": set(),
    "retired": set(),
}
SPEC_KINDS = set(CONTRACT_DATA["choice_sets"]["spec_kinds"])
DOCUMENT_SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
DOCUMENT_FILENAME_PATTERNS = {
    "adr": re.compile(r"^ADR-(?P<number>\d{4})-(?P<slug>[a-z0-9-]+)\.(?:json|yaml)$"),
    "spec": re.compile(r"^SPEC-(?P<number>\d{4})-(?P<slug>[a-z0-9-]+)\.(?:json|yaml)$"),
}


class StatusNote(TypedDict, total=False):
    status: str
    note: str
    at: str
    actor: str
    reason: str


class SpecRow(TypedDict, total=False):
    id: str
    number: int
    slug: str
    title: str
    path: str
    origin: str
    managed: bool
    immutable: bool
    package_version: str
    content_sha256: str
    kind: str
    status: str
    adr_ids: list[str]
    supersedes: list[str]
    superseded_by: list[str]
    status_notes: list[StatusNote]


class DocumentCatalogProvider(TypedDict):
    catalog_id: str
    trusted_by_default: bool
    load_manifest: Callable[[str], list[dict[str, Any]]]
    read_text: Callable[[str, str], str]
    read_bytes: Callable[[str, str], bytes]


def format_document_number(number: int) -> str:
    return f"{number:04d}"


def normalize_document_id(kind: str, number: int) -> str:
    return f"{DOCUMENT_ID_PREFIXES[kind]}{format_document_number(number)}"


def build_document_filename(kind: str, number: int, slug: str) -> str:
    return f"{DOCUMENT_FILENAME_PREFIXES[kind]}-{format_document_number(number)}-{slug}.yaml"


def build_document_path(paths: dict[str, str], kind: str, number: int, slug: str) -> str:
    root = paths[DOCUMENT_PATH_KEYS[kind]].strip("/\\")
    return Path(root, build_document_filename(kind, number, slug)).as_posix()


def document_path_variants(paths: dict[str, str], kind: str, number: int, slug: str) -> set[str]:
    canonical = Path(build_document_path(paths, kind, number, slug))
    return {canonical.as_posix(), canonical.with_suffix(".json").as_posix()}


def document_path_has_supported_suffix(path: str) -> bool:
    return any(path.endswith(suffix) for suffix in DOCUMENT_FILE_SUFFIXES)


def parse_document_filename(kind: str, filename: str) -> tuple[int, str] | None:
    match = DOCUMENT_FILENAME_PATTERNS[kind].match(filename)
    if match is None:
        return None
    return int(match.group("number")), match.group("slug")


def reservation_kind_key(kind: str) -> str:
    return DOCUMENT_RESERVATION_KEYS[kind]


def section_for_document_kind(kind: str) -> str:
    return DOCUMENT_SECTIONS[kind]


def default_document_id_reservations() -> dict[str, list[dict[str, Any]]]:
    reservations = CONTRACT_DATA["document_contract"]["default_reservations"]
    return {
        "adr": [dict(row) for row in reservations["adr"]],
        "spec": [dict(row) for row in reservations["spec"]],
    }


_DOCUMENT_CATALOG_PROVIDERS: list[DocumentCatalogProvider] = [
    {
        "catalog_id": "ssot-origin",
        "trusted_by_default": True,
        "load_manifest": contracts_load_document_manifest,
        "read_text": contracts_read_packaged_document_text,
        "read_bytes": contracts_read_packaged_document_bytes,
    }
]


def extension_pack_reservation_owner(catalog_id: str) -> str:
    return f"{EXTENSION_PACK_RESERVATION_PREFIX}{catalog_id}"


def is_extension_pack_reservation_owner(owner: object) -> bool:
    return isinstance(owner, str) and owner.startswith(EXTENSION_PACK_RESERVATION_PREFIX) and len(owner) > len(
        EXTENSION_PACK_RESERVATION_PREFIX
    )


def load_document_manifest(kind: str, *, include_untrusted: bool = False) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for provider in _DOCUMENT_CATALOG_PROVIDERS:
        if not include_untrusted and not provider["trusted_by_default"]:
            continue
        for raw_entry in provider["load_manifest"](kind):
            entry = dict(raw_entry)
            entry.setdefault("catalog_id", provider["catalog_id"])
            entry.setdefault("trusted", provider["trusted_by_default"])
            entries.append(entry)
    return entries


def read_manifest_document_text(kind: str, manifest_entry: dict[str, Any]) -> str:
    catalog_id = str(manifest_entry.get("catalog_id", "ssot-origin"))
    for provider in _DOCUMENT_CATALOG_PROVIDERS:
        if provider["catalog_id"] == catalog_id:
            return provider["read_text"](kind, str(manifest_entry["filename"]))
    raise ValueError(f"Unknown document catalog provider: {catalog_id}")


def read_manifest_document_bytes(kind: str, manifest_entry: dict[str, Any]) -> bytes:
    catalog_id = str(manifest_entry.get("catalog_id", "ssot-origin"))
    for provider in _DOCUMENT_CATALOG_PROVIDERS:
        if provider["catalog_id"] == catalog_id:
            return provider["read_bytes"](kind, str(manifest_entry["filename"]))
    raise ValueError(f"Unknown document catalog provider: {catalog_id}")


def canonical_manifest_document_sha256(kind: str, manifest_entry: dict[str, Any]) -> str:
    from ssot_registry.util.document_io import (
        build_document_payload,
        document_body_from_payload,
        dump_document_text,
        load_document_text,
        normalize_document_payload,
    )

    authored_payload = normalize_document_payload(
        kind,
        load_document_text(read_manifest_document_text(kind, manifest_entry), source=f"packaged:{manifest_entry['filename']}"),
    )
    row: dict[str, Any] = {
        "id": manifest_entry["id"],
        "number": manifest_entry["number"],
        "slug": manifest_entry["slug"],
        "title": manifest_entry["title"],
        "status": manifest_entry.get("status", "draft"),
        "origin": manifest_entry["origin"],
        "supersedes": manifest_entry.get("supersedes", []),
        "superseded_by": manifest_entry.get("superseded_by", []),
        "status_notes": manifest_entry.get("status_notes", []),
    }
    if kind == "spec":
        row["kind"] = manifest_entry.get("kind", "normative")
        row["adr_ids"] = manifest_entry.get("adr_ids", [])
    rendered = dump_document_text(
        build_document_payload(kind, row, document_body_from_payload(kind, authored_payload)),
        Path(str(manifest_entry["target_path"])),
    )
    return hashlib.sha256(rendered.encode("utf-8")).hexdigest()


def read_packaged_document_text(kind: str, filename: str) -> str:
    return contracts_read_packaged_document_text(kind, filename)


def read_packaged_document_bytes(kind: str, filename: str) -> bytes:
    return contracts_read_packaged_document_bytes(kind, filename)
