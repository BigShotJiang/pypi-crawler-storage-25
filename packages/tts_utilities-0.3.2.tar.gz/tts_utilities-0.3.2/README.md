# Teamtools Studio Utilities

![Project logo](https://github.com/NASA-JPL-Teamtools-Studio/teamtools-documentation/blob/main/docs/images/tts_image_artifacts/tts_utilities.png)

## About Teamtools Studio

Teamtools Studio Utilities is part of JPL's Teamtools Studio (TTS).

TTS is an effort originated in JPL's Planning and Execution section to centralize shared repositories across missions. This benefits JPL by reducing cost through reducing duplicated code, collaborating across missions, and unifying standards for development and design across JPL.

Although Planning and Execution is primarily concerned with flight operations, the TTS suite has been generalized and atomized to the point where many of these tools are applicable during other mission phases and even in non-spaceflight contexts. Through our work flying space missions, we hope to provide tools to the open source community that have utility in data analysis or planning for any complex system where failure is not an option.

For more infomation on how to contribute, and how these libraries form a complete ecosystem for high reliability data analysis, see the [Full TTS Documentation](https://github.com/NASA-JPL-Teamtools-Studio/teamtools-documentation/).

## What is Teamtools Studio Utilities?

### Overview

Teamtools Studio Utilities is a helper library to improve the quality of life of Teamtools Studio developers. It is
required by all Teamtools Studio libraries in order to support versions of Python back to 3.6 while still using a modern
method of packaging. All TTS libraries include both a pyproject.toml and setup.py file, but only the pyproject.toml is
a source of truth. setup.py only calls a utility from this library to convert the information in the toml file into the
Pythonic format expected by Python versions prior to 3.8.

The most important thing here for most developrs is the common TTS logger.

### Projects Currently Supported

* Europa Clipper
* Mars 2020/Perseverance
* Mars Sample Return/Sample Retrieval Lander
* Mars Science Laboratory/Curiosity
* Mars Reconnaisance Orbiter
* NISAR
* Orbiting Carbon Observatory 2 (OCO-2)

## Architecture

### TTS dependencies

* None
