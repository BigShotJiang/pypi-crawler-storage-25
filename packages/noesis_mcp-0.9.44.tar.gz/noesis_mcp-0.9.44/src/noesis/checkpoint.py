"""Checkpoint, PID, metrics, rejection tracking, file locking, and validation."""

import os, sys, json, time, fcntl
from pathlib import Path
from datetime import datetime, timezone

# ── Config ────────────────────────────────────────────────────────────────
MCP_SOURCE_DIR = Path.home() / "mcp-work" / "src" / "noesis"
SAFE_WRITE_ROOT = MCP_SOURCE_DIR.parent  # repo root — all writes must stay within
SCRIPTS_DIR = Path.home() / ".hermes" / "scripts"
CHECKPOINT_FILE = SCRIPTS_DIR / "mcp_self_improve_checkpoint.json"
LOG_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve.log"
WISHES_FILE = Path.home() / "mcp-work" / "wishes.txt"
META_WISHES_FILE = Path.home() / ".hermes" / "scripts" / "meta_wish_approved.json"
PID_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve.pid"
PAUSE_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve.pause"
METRICS_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve_metrics.json"
MAX_ITERATIONS = 200
DRY_RUN = False  # Set by --dry-run flag



def validate_write_path(filename: str, root: Path = SAFE_WRITE_ROOT) -> Path | None:
    """Validate that a file path stays within the allowed project directory.

    Prevents path traversal attacks (e.g. '../../etc/passwd').
    Returns the resolved Path if valid, None if the path escapes the root.

    Works for any project — root defaults to MCP_SOURCE_DIR.parent (repo root)
    but can be overridden per-deployment.
    """
    # Resolve the target path
    target = (root / filename).resolve()
    root_resolved = root.resolve()

    # Check if target is within root
    try:
        target.relative_to(root_resolved)
        return target
    except ValueError:
        log(f"[SECURITY] Path traversal blocked: {filename} escapes {root_resolved}")
        return None

API_TIMEOUT = 360
DEBATE_ROUNDS = 3          # max judge-reject → retry cycles per wish
MAX_CONTEXT_FILES = 8      # max files to read per debate turn
WATCH_INTERVAL = 60        # seconds to sleep when Scout finds nothing
ARCHITECT_COOLDOWN = 3600  # seconds between architect-scout runs (1h)


# ── Logging ───────────────────────────────────────────────────────────────────
def log(msg: str, print_it: bool = True) -> None:
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    line = f"[{ts}] {msg}"
    if print_it:
        print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOG_FILE.open("a").write(line + "\n")


# ── Checkpoint ────────────────────────────────────────────────────────────────
def load_checkpoint() -> dict:
    """Load checkpoint with shared lock to prevent reading during a write."""
    if CHECKPOINT_FILE.exists():
        try:
            with open(CHECKPOINT_FILE, "r") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                data = json.loads(f.read())
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                return data
        except Exception:
            pass
    return {
        "iterations": 0,
        "applied_patches": [],
        "done": False,
        "wish_index": 0,
        "debate_round": 0,
        "last_wish": None,
    }


def save_checkpoint(cp: dict) -> None:
    """Save checkpoint with exclusive lock, atomic write, and backup rotation."""
    cp["last_updated"] = datetime.now(timezone.utc).isoformat()
    CHECKPOINT_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(cp, indent=2, default=str)

    # Rotate backups: keep last 3
    MAX_BACKUPS = 3
    for i in range(MAX_BACKUPS - 1, 0, -1):
        older = CHECKPOINT_FILE.with_suffix(f".bak{i}")
        newer = CHECKPOINT_FILE.with_suffix(f".bak{i+1}") if i < MAX_BACKUPS else None
        if i == MAX_BACKUPS - 1:
            older_backup = CHECKPOINT_FILE.with_suffix(f".bak{MAX_BACKUPS}")
            if older_backup.exists():
                older_backup.unlink()
        if older.exists():
            older.rename(CHECKPOINT_FILE.with_suffix(f".bak{i+1}"))
    if CHECKPOINT_FILE.exists():
        CHECKPOINT_FILE.rename(CHECKPOINT_FILE.with_suffix(".bak1"))

    # Atomic write: write to temp file, then rename
    tmp = CHECKPOINT_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    tmp.rename(CHECKPOINT_FILE)


def track_metric(event: str) -> None:
    """Track pipeline events: wish_proposed, wish_approved, wish_rejected, audit_rejected, layer1_failed."""
    try:
        metrics = {} if not METRICS_FILE.exists() else json.loads(METRICS_FILE.read_text())
    except Exception:
        metrics = {}
    metrics[event] = metrics.get(event, 0) + 1
    metrics["last_updated"] = datetime.now(timezone.utc).isoformat()
    METRICS_FILE.parent.mkdir(parents=True, exist_ok=True)
    METRICS_FILE.write_text(json.dumps(metrics, indent=2))


def acquire_pid_file() -> bool:
    """Check if another instance is running. If not, write our PID. Returns True if acquired."""
    if PID_FILE.exists():
        try:
            old_pid = int(PID_FILE.read_text().strip())
            # Check if process is still alive
            os.kill(old_pid, 0)
            log(f"[PID] Another instance running (PID {old_pid}). Exiting.")
            return False
        except (ProcessLookupError, ValueError):
            # Process dead or PID file corrupt — safe to proceed
            pass
        except PermissionError:
            # Process exists but owned by different user — assume it's running
            log(f"[PID] Another instance may be running (permission denied checking PID). Exiting.")
            return False

    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    log(f"[PID] Acquired PID file (PID {os.getpid()})")
    return True


def release_pid_file() -> None:
    """Remove PID file on clean shutdown."""
    try:
        if PID_FILE.exists() and PID_FILE.read_text().strip() == str(os.getpid()):
            PID_FILE.unlink()
    except Exception:
        pass


# ── Persistent rejection store ─────────────────────────────────────────────────
REJECTIONS_FILE = Path.home() / ".hermes" / "scripts" / "noesis_rejections.json"


def save_rejection_reason(wish: str, reason: str) -> None:
    """Persist a wish→reason mapping so Architect can read it next run."""
    try:
        rejections = {} if not REJECTIONS_FILE.exists() else json.loads(REJECTIONS_FILE.read_text())
    except Exception:
        rejections = {}
    # Normalize wish to a comparable key
    normalized = wish.strip()
    rejections[normalized] = {"reason": reason, "timestamp": datetime.now(timezone.utc).isoformat()}
    REJECTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    REJECTIONS_FILE.write_text(json.dumps(rejections, indent=2))


def load_rejection_reasons() -> dict:
    """Load all rejection reasons from persistent store.

    The file format is {"rejection_reasons": {...}, ...}. Returns only the
    rejection_reasons sub-dict so callers can iterate wish→reason pairs.
    """
    try:
        if not REJECTIONS_FILE.exists():
            return {}
        raw = json.loads(REJECTIONS_FILE.read_text())
        # Support both flat format and {"rejection_reasons": {...}} wrapper
        if isinstance(raw, dict) and "rejection_reasons" in raw:
            return raw["rejection_reasons"]
        elif isinstance(raw, dict):
            # Filter out non-reason top-level keys
            return {k: v for k, v in raw.items()
                    if k not in ("rejections", "timestamp", "version")}
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def save_meta_wish(wish: str, proposal: str) -> None:
    """Persist an approved meta-wish proposal to the approved list."""
    try:
        approved = [] if not META_WISHES_FILE.exists() else json.loads(META_WISHES_FILE.read_text())
    except Exception:
        approved = []
    approved.append({
        "wish": wish,
        "proposal": proposal,
        "timestamp": datetime.now(timezone.utc).isoformat()
    })
    META_WISHES_FILE.parent.mkdir(parents=True, exist_ok=True)
    META_WISHES_FILE.write_text(json.dumps(approved, indent=2))
    log(f"[META-WISH] Saved to {META_WISHES_FILE}")


# ── File locks: prevent concurrent-wish conflicts ─────────────────────────────
LOCKS_FILE = Path.home() / ".hermes" / "scripts" / "noesis_file_locks.json"


def load_locks() -> dict:
    try:
        return {} if not LOCKS_FILE.exists() else json.loads(LOCKS_FILE.read_text())
    except Exception:
        return {}


def save_locks(lock_map: dict) -> None:
    LOCKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOCKS_FILE.write_text(json.dumps(lock_map, indent=2))


def claim_files(file_list: list[str]) -> tuple[bool, list[str]]:
    """Claim files for the current wish. Returns (claimed_ok, already_locked_by_us).
    Call this after Proposer produces code_blocks (we now know which files it targets)."""
    locks = load_locks()
    my_claims = [f for f, w in locks.items() if w == "current"]
    locked_by_others = [f for f in file_list if f in locks and locks[f] != "current"]
    if locked_by_others:
        return False, []
    for f in file_list:
        locks[f] = "current"
    save_locks(locks)
    return True, my_claims


def release_files(file_list: list[str]) -> None:
    """Release file locks held by the current wish."""
    locks = load_locks()
    for f in file_list:
        if locks.get(f) == "current":
            del locks[f]
    save_locks(locks)


# ── Adaptive debate rounds ─────────────────────────────────────────────────────
def adaptive_debate_rounds(severity: str) -> int:
    """Return effective debate rounds based on Critic severity.
    Blockers/high need fewer retries — either the Defender can fix it or it can't."""
    return {  # (severity → rounds, reason)
        "blocker": (1, "Defender can't resolve fundamental flaws in one round"),
        "high":    (1, "High-severity issues are either fixable immediately or not worth iterating"),
        "medium":  (2, "Standard debate rounds for addressable concerns"),
        "low":     (3, "Style/nitpicks may need multiple rounds of refinement"),
    }.get(severity, (3, "Default"))[0]




# Re-export constants for other modules
__all__ = [
    'MCP_SOURCE_DIR', 'SAFE_WRITE_ROOT', 'CHECKPOINT_FILE', 'LOG_FILE',
    'WISHES_FILE', 'META_WISHES_FILE', 'PID_FILE', 'PAUSE_FILE', 'METRICS_FILE',
    'MAX_ITERATIONS', 'DRY_RUN', 'API_TIMEOUT', 'DEBATE_ROUNDS', 'MAX_CONTEXT_FILES',
    'WATCH_INTERVAL', 'ARCHITECT_COOLDOWN',
    'validate_write_path', 'log', 'load_checkpoint', 'save_checkpoint',
    'track_metric', 'acquire_pid_file', 'release_pid_file',
    'save_rejection_reason', 'load_rejection_reasons', 'save_meta_wish',
    'load_locks', 'save_locks', 'claim_files', 'release_files',
    'adaptive_debate_rounds',
]
