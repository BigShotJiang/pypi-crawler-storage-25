"""Pipeline agent definitions: Proposer, Critic, Defender, Synthesizer, Judge, Auditor."""

import re
from pathlib import Path
from checkpoint import log, MCP_SOURCE_DIR, MAX_CONTEXT_FILES
from api_clients import call_minimax, call_deepseek_r1, call_mimo
from prompts import (
    SYSTEM_PROPOSER, SYSTEM_CRITIC, SYSTEM_DEFENDER,
    SYSTEM_SYNTHESIZER, SYSTEM_JUDGE, SYSTEM_AUDITOR,
)

def agent_proposer(wish: str, messages: list[dict]) -> tuple[str, list[dict]]:
    """Run the Proposer agent via MiniMax. Returns (proposal_text, updated_messages).
    
    Extracts the target file from [SCOUT: filename.py] tag in wish and only
    reads that file, plus a compact signature map of all other files.
    """
    # 🧪 EXPERIMENTAL: Handle meta-wishes (no target file) — ask for markdown proposal
    if wish.startswith("[META]"):
        track_metric("wish_proposed")
        log(f"  🧪 EXPERIMENTAL: Processing meta-wish, requesting markdown output")
        task = f"""WISH: {wish}

This is a process/workflow improvement wish — not a code change.
Do NOT output any code. Instead, write a structured markdown proposal (2-3 sections)
that explains: what to change, why it's needed, and how to implement it.
Use ## headings, keep it concise, no code blocks.
"""
        content = call_minimax(task, system=SYSTEM_PROPOSER, max_tokens=2000)
        return content, []

    # Extract target file from wish tag (e.g. [SCOUT: server.py])
    target_file = None
    m = re_module.search(r'\[SCOUT:\s*(\S+\.py)\]', wish)
    if m:
        target_file = m.group(1)
    
    files = {}
    for fp in get_source_files():
        files[str(fp)] = read_file_content(fp)
    
    # If we have a target file, read it fully and use compact map for others
    if target_file:
        # Find the full path
        target_path = MCP_SOURCE_DIR / target_file
        if not target_path.exists():
            target_path = MCP_SOURCE_DIR.parent / target_file
        
        full_content = target_path.read_text(errors="ignore") if target_path.exists() else "[FILE NOT FOUND]"
        # Truncate large files to save tokens — 500 lines is enough context
        full_lines = full_content.splitlines()
        if len(full_lines) > 500:
            full_content = "\n".join(full_lines[:500]) + f"\n# ... ({len(full_lines) - 500} more lines, truncated)"
        other_files = {k: v for k, v in files.items() if Path(k).name != target_file}
        other_snapshot = format_codebase_snapshot(other_files, max_chars=12000)
        
        task = f"""WISH: {wish}

## TARGET FILE: {target_file}
{full_content}

## ALL OTHER FILES (signatures only)
{get_file_map()}

Produce your response using the EXACT format in your system prompt."""
    else:
        # No target file — use compact snapshot of all
        codebase_snapshot = format_codebase_snapshot(files, max_chars=20000)
        task = f"""WISH: {wish}

## FULL PROJECT SOURCE (compact)
{codebase_snapshot}

Produce your response using the EXACT format in your system prompt."""
    
    content = call_minimax(task, system=SYSTEM_PROPOSER, max_tokens=2000)
    return content, []





def agent_auditor(original_file: Path, patched_content: str, wish: str,
                  severity: str = "low") -> tuple[str, list[dict]]:
    """Run the Auditor agent via DeepSeek R1 to catch logic/runtime bugs.

    Reviews a unified diff between original and patched version — focuses
    the auditor on what actually changed rather than re-reading full files.
    Falls back to truncated full files for new files (no original).

    Returns (verdict_text, updated_messages).
    """
    import difflib

    original_content = original_file.read_text(errors="ignore") if original_file.exists() else ""

    # Generate unified diff — much smaller than full files
    if original_content:
        diff = "\n".join(difflib.unified_diff(
            original_content.splitlines(),
            patched_content.splitlines(),
            fromfile=f"original/{original_file.name}",
            tofile=f"patched/{original_file.name}",
            lineterm="",
        ))
        # If diff is too large, truncate it
        if len(diff) > 4000:
            diff = diff[:4000] + f"\n... (truncated, {len(diff)} chars total)"
        file_context = f"DIFF (what changed):\n{diff}"
    else:
        # New file — show truncated content
        file_context = f"NEW FILE ({original_file.name}):\n{patched_content[:3000]}"

    task = (
        f"WISH: {wish}\n\n"
        f"{file_context}\n\n"
        f"SEVERITY: {severity.upper()}\n\n"
        f"Review the changes against the wish. "
        f"Produce your response using the EXACT format in your system prompt."
    )
    content = call_deepseek_r1(task, system=SYSTEM_AUDITOR)
    return content, []


def agent_critic(proposal: str, messages: list[dict]) -> tuple[str, list[dict]]:
    """Run the Critic agent via Straico DeepSeek R1 (adversarial reasoning).
    
    Returns (critique_text, updated_messages) — messages always empty (stateless).
    """
    task = f"PROPOSAL TO REVIEW:\n{proposal}"
    content = call_deepseek_r1(task, system=SYSTEM_CRITIC)
    return content, []


def agent_defender(proposal: str, critique: str, messages: list[dict]) -> tuple[str, list[dict]]:
    """Run the Defender agent. Returns (defense_text, updated_messages)."""
    task = (
        f"ORIGINAL PROPOSAL:\n{proposal}\n\n"
        f"CRITIC'S CONCERNS:\n{critique}\n\n"
        f"Produce your response using the EXACT format in your system prompt."
    )
    content = call_minimax(task, system=SYSTEM_DEFENDER, max_tokens=800)
    return content, []


def agent_synthesizer(proposal: str, defense: str, messages: list[dict]) -> tuple[str, list[dict]]:
    """Run the Synthesizer agent. Returns (synthesis_text, updated_messages)."""
    task = (
        f"ORIGINAL PROPOSAL:\n{proposal}\n\n"
        f"DEFENDER RESPONSE:\n{defense}\n\n"
        f"Produce your response using the EXACT format in your system prompt."
    )
    content = call_minimax(task, system=SYSTEM_SYNTHESIZER, max_tokens=1000)
    return content, []


def agent_judge(proposal: str, synthesis: str, messages: list[dict],
                severity: str = "low") -> tuple[str, list[dict]]:
    """Run the Judge agent via Straico (Llama 3.1 Nemotron).

    Returns (verdict_text, updated_messages) — messages always empty (stateless).
    severity is passed so Judge knows how seriously to weigh Critic concerns.
    """
    task = (
        f"PROPOSAL:\n{proposal}\n\n"
        f"SYNTHESIS:\n{synthesis}\n\n"
        f"CRITIC SEVERITY: {severity.upper()}\n\n"
        f"Produce your response using the EXACT format in your system prompt."
    )
    content = call_mimo(task, system=SYSTEM_JUDGE, max_tokens=2048)
    return content, []


# ── JSON code extraction ──────────────────────────────────────────────────────
def extract_code_from_proposal(content: str) -> list[dict]:
    """Extract [{{"file": "...", "content": "..."}}] from Proposer output.
    
    Handles four formats:
    1. ```json [{{"file": "...", "content": "..."}}] ``` (standard)
    2. ``` [{{"file": "...", "content": "..."}}] ``` (no language tag)
    3. [COMPLEXITY: ...]\n```json ...``` (cognitive pipeline prefix)
    4. Bare JSON array/object (no fences)
    """
    # Strip [COMPLEXITY: ...] prefix from cognitive pipeline responses
    content = re_module.sub(r'^\s*\[COMPLEXITY:[^\]]*\]\s*', '', content).strip()
    
    # Try fenced JSON blocks first
    for regex in [
        r"```json\s*(.*?)\s*```",
        r"```\s*(.*?)\s*```",
    ]:
        for m in re_module.finditer(regex, content, re_module.DOTALL):
            try:
                parsed = json.loads(m.group(1).strip())
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict) and "file" in item and "content" in item:
                            return parsed
                elif isinstance(parsed, dict) and "file" in parsed:
                    return [parsed]
            except json.JSONDecodeError:
                pass
    
    # Try bare JSON array — scan for '[{' or '[ {"'
    for m in re_module.finditer(r'\[\s*\{', content):
        start = m.start()
        # Find the matching closing bracket
        depth = 0
        for i, ch in enumerate(content[start:], start=start):
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    try:
                        parsed = json.loads(content[start:i+1])
                        if isinstance(parsed, list):
                            for item in parsed:
                                if isinstance(item, dict) and "file" in item and "content" in item:
                                    return parsed
                        elif isinstance(parsed, dict) and "file" in parsed:
                            return [parsed]
                    except json.JSONDecodeError:
                        pass
                    break

    # 🧪 EXPERIMENTAL: Markdown fallback — extract markdown sections for meta-wishes
    log(f"  🧪 EXPERIMENTAL: No code blocks found, trying markdown extraction")
    # Match markdown sections: ## Heading or ### Heading followed by content
    md_match = re_module.search(
        r'(?:^|\n)(##?\s+.+?(?:\n(?:\n|.+?)+)?)(?=\n##|\n#|\Z)',
        content,
        re_module.DOTALL
    )
    if md_match:
        md_content = md_match.group(1).strip()
        if len(md_content) > 50:
            log(f"  🧪 EXPERIMENTAL: Found markdown proposal ({len(md_content)} chars)")
            return [{"file": "PROPOSAL.md", "content": md_content}]

    return []




__all__ = [
    'agent_proposer', 'agent_critic', 'agent_defender',
    'agent_synthesizer', 'agent_judge', 'agent_auditor',
    'extract_code_from_proposal',
]
