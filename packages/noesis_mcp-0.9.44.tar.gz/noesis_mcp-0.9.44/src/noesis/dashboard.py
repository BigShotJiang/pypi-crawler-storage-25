"""Noesis Terminal Dashboard — live pipeline visualization.

Usage:
    noesis watch              # live dashboard
    noesis watch --refresh 2  # refresh every 2 seconds
"""

import json
import time
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich import box

# ── Paths ─────────────────────────────────────────────────────────────────
SCRIPTS_DIR = Path.home() / ".hermes" / "scripts"
CHECKPOINT_FILE = SCRIPTS_DIR / "mcp_self_improve_checkpoint.json"
METRICS_FILE = SCRIPTS_DIR / "mcp_self_improve_metrics.json"
LOG_FILE = SCRIPTS_DIR / "mcp_self_improve.log"
PAUSE_FILE = SCRIPTS_DIR / "mcp_self_improve.pause"
PID_FILE = SCRIPTS_DIR / "mcp_self_improve.pid"
WISHES_FILE = Path.home() / "mcp-work" / "wishes.txt"
META_WISHES_FILE = SCRIPTS_DIR / "meta_wish_approved.json"
REJECTIONS_FILE = SCRIPTS_DIR / "noesis_rejections.json"

console = Console()


# ── Data readers ──────────────────────────────────────────────────────────
def read_checkpoint() -> dict:
    try:
        return json.loads(CHECKPOINT_FILE.read_text()) if CHECKPOINT_FILE.exists() else {}
    except Exception:
        return {}


def read_metrics() -> dict:
    try:
        return json.loads(METRICS_FILE.read_text()) if METRICS_FILE.exists() else {}
    except Exception:
        return {}


def read_last_log_lines(n: int = 15) -> list[str]:
    """Read last N lines from the log file."""
    if not LOG_FILE.exists():
        return []
    try:
        result = subprocess.run(
            ["tail", "-n", str(n), str(LOG_FILE)],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip().split("\n") if result.stdout.strip() else []
    except Exception:
        return []


def is_daemon_running() -> bool:
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", "mcp-self-improve"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() == "active"
    except Exception:
        return False


def get_daemon_pid() -> Optional[str]:
    if PID_FILE.exists():
        try:
            return PID_FILE.read_text().strip()
        except Exception:
            pass
    return None


def get_uptime() -> str:
    """Get daemon uptime from PID."""
    pid = get_daemon_pid()
    if not pid:
        return "unknown"
    try:
        result = subprocess.run(
            ["ps", "-o", "etime=", "-p", pid],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.stdout.strip() else "unknown"
    except Exception:
        return "unknown"


def get_memory() -> str:
    """Get daemon memory usage."""
    pid = get_daemon_pid()
    if not pid:
        return "unknown"
    try:
        result = subprocess.run(
            ["ps", "-o", "rss=", "-p", pid],
            capture_output=True, text=True, timeout=5,
        )
        if result.stdout.strip():
            rss_kb = int(result.stdout.strip())
            return f"{rss_kb // 1024}MB"
    except Exception:
        pass
    return "unknown"


def parse_log_activity(lines: list[str]) -> list[dict]:
    """Parse log lines into activity entries."""
    activity = []
    for line in reversed(lines):
        if not line.strip():
            continue
        entry = {"time": "", "icon": "·", "text": line[:80]}
        # Extract timestamp
        if line.startswith("[") and "]" in line:
            ts_str = line[1:line.index("]")]
            try:
                dt = datetime.fromisoformat(ts_str)
                entry["time"] = dt.strftime("%H:%M:%S")
            except Exception:
                entry["time"] = ts_str[:8]
            line = line[line.index("]")+1:].strip()

        # Determine icon
        if "✓" in line or "APPLIED" in line or "APPROVED" in line:
            entry["icon"] = "✓"
            entry["color"] = "green"
        elif "✗" in line or "REJECTED" in line or "❌" in line:
            entry["icon"] = "✗"
            entry["color"] = "red"
        elif "CRITIC" in line:
            entry["icon"] = "⟳"
            entry["color"] = "yellow"
        elif "PROPOSER" in line:
            entry["icon"] = "✎"
            entry["color"] = "cyan"
        elif "JUDGE" in line:
            entry["icon"] = "⚖"
            entry["color"] = "magenta"
        elif "Scout" in line or "SCOUT" in line:
            entry["icon"] = "🔍"
            entry["color"] = "blue"
        elif "Architect" in line:
            entry["icon"] = "🏗"
            entry["color"] = "blue"
        elif "MIMO" in line:
            entry["icon"] = "◆"
            entry["color"] = "cyan"
        elif "DEEPSEEK" in line:
            entry["icon"] = "◆"
            entry["color"] = "blue"
        elif "MINIMAX" in line:
            entry["icon"] = "◆"
            entry["color"] = "green"
        else:
            entry["color"] = "white"

        entry["text"] = line[:75]
        activity.append(entry)
        if len(activity) >= 12:
            break
    return activity


def detect_pipeline_stage(lines: list[str]) -> dict:
    """Detect current pipeline stage from recent log lines."""
    stage = {
        "scout": "idle",
        "proposer": "idle",
        "critic": "idle",
        "defender": "idle",
        "judge": "idle",
        "auditor": "idle",
        "current_wish": "",
        "critic_text": "",
    }
    for line in reversed(lines):
        if "Analyzing" in line and "Scout" in line:
            stage["scout"] = "active"
        elif "PROPOSER" in line and "drafting" in line:
            stage["proposer"] = "active"
            stage["scout"] = "done"
        elif "CRITIC" in line and "analyzing" in line:
            stage["critic"] = "active"
            stage["proposer"] = "done"
        elif "CRITIC" in line and "verdict:" in line:
            stage["critic"] = "done"
            if "APPROVED" in line:
                stage["critic_verdict"] = "approved"
            else:
                stage["critic_verdict"] = "rejected"
        elif "DEFENDER" in line:
            stage["defender"] = "active"
        elif "JUDGE" in line and "Meta-wish" in line:
            stage["judge"] = "active"
        elif "JUDGE" in line and "VERDICT:" in line:
            stage["judge"] = "done"
        elif "AUDITOR" in line:
            stage["auditor"] = "active"
        elif "WISH" in line and "round" in line:
            # Extract wish text
            if "]" in line:
                wish_part = line[line.index("]")+1:].strip()
                if ":" in wish_part:
                    wish_part = wish_part[wish_part.index(":")+1:].strip()
                stage["current_wish"] = wish_part[:80]
    return stage


# ── Layout builders ───────────────────────────────────────────────────────
def build_header() -> Panel:
    """Build the header panel."""
    running = is_daemon_running()
    uptime = get_uptime()
    status = "[green]● Running[/green]" if running else "[red]○ Stopped[/red]"
    pause_status = ""
    if PAUSE_FILE.exists():
        pause_status = " [yellow]⏸ PAUSED[/yellow]"

    title = Text()
    title.append("NOESIS v0.9.44", style="bold white")
    title.append(" — Self-Improvement Pipeline", style="dim white")

    info = Text()
    info.append(f"  {status}{pause_status}", style="bold")
    info.append(f"  │  Uptime: {uptime}", style="dim")
    info.append(f"  │  Memory: {get_memory()}", style="dim")

    pid = get_daemon_pid()
    if pid:
        info.append(f"  │  PID: {pid}", style="dim")

    return Panel(
        Align.center(info),
        title=title,
        border_style="blue",
        box=box.DOUBLE,
    )


def build_pipeline(stage: dict) -> Panel:
    """Build the pipeline visualization."""
    agents = [
        ("SCOUT", "mimo", stage.get("scout", "idle")),
        ("PROPOSER", "MiniMax", stage.get("proposer", "idle")),
        ("CRITIC", "DeepSeek", stage.get("critic", "idle")),
        ("DEFENDER", "MiniMax", stage.get("defender", "idle")),
        ("JUDGE", "mimo", stage.get("judge", "idle")),
    ]

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_row()
    # Agent boxes
    names = Table(show_header=False, box=None, padding=0)
    models = Table(show_header=False, box=None, padding=0)
    statuses = Table(show_header=False, box=None, padding=0)
    arrows = Table(show_header=False, box=None, padding=0)

    for name, model, status in agents:
        if status == "active":
            status_icon = "[yellow]⟳[/yellow]"
            name_style = "bold yellow"
        elif status == "done":
            status_icon = "[green]✓[/green]"
            name_style = "green"
        else:
            status_icon = "[dim]·[/dim]"
            name_style = "dim"

        names.add_row(Text(f" {name} ", style=name_style))
        models.add_row(Text(f" {model} ", style="dim"))
        statuses.add_row(Text(f"  {status_icon}  "))

    # Build horizontal layout
    pipeline_table = Table(show_header=False, box=None, padding=0, expand=True)
    pipeline_table.add_column(ratio=1)
    pipeline_table.add_column(ratio=1)
    pipeline_table.add_column(ratio=1)
    pipeline_table.add_column(ratio=1)
    pipeline_table.add_column(ratio=1)

    row_names = []
    row_models = []
    row_status = []
    for name, model, status in agents:
        if status == "active":
            row_names.append(Text(f" {name} ", style="bold yellow"))
            row_models.append(Text(f" {model} ", style="dim"))
            row_status.append(Text("  ⟳  ", style="yellow"))
        elif status == "done":
            row_names.append(Text(f" {name} ", style="green"))
            row_models.append(Text(f" {model} ", style="dim"))
            row_status.append(Text("  ✓  ", style="green"))
        else:
            row_names.append(Text(f" {name} ", style="dim"))
            row_models.append(Text(f" {model} ", style="dim"))
            row_status.append(Text("  ·  ", style="dim"))

    pipeline_table.add_row(*row_names)
    pipeline_table.add_row(*row_models)
    pipeline_table.add_row(*row_status)

    return Panel(pipeline_table, title="[bold]Pipeline[/bold]", border_style="cyan", box=box.ROUNDED)


def build_wish(stage: dict) -> Panel:
    """Build the current wish panel."""
    wish = stage.get("current_wish", "")
    if not wish:
        wish = "[dim]No active wish — Scout hunting...[/dim]"

    critic_text = stage.get("critic_text", "")
    content = Text()
    content.append("WISH: ", style="bold")
    content.append(wish + "\n\n", style="white")

    if stage.get("critic") == "active":
        content.append("CRITIC (DeepSeek R1) — reviewing...\n", style="bold yellow")
        content.append("[dim]Analyzing proposal for flaws...[/dim]\n")
    elif stage.get("critic_verdict"):
        verdict = stage["critic_verdict"]
        if verdict == "approved":
            content.append("CRITIC: ", style="bold")
            content.append("APPROVED\n", style="bold green")
        else:
            content.append("CRITIC: ", style="bold")
            content.append("REJECTED\n", style="bold red")

    return Panel(content, title="[bold]Current Wish[/bold]", border_style="yellow", box=box.ROUNDED)


def build_metrics(metrics: dict, checkpoint: dict) -> Panel:
    """Build the metrics panel."""
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="bold", justify="right")

    # Token usage
    tokens_mimo = metrics.get("tokens_mimo", 0)
    tokens_deepseek = metrics.get("tokens_deepseek", 0)
    tokens_minimax = metrics.get("tokens_minimax", 0)
    tokens_total = metrics.get("tokens_total", 0)

    table.add_row("Tokens", "")
    table.add_row("  mimo", f"{tokens_mimo:,}")
    table.add_row("  DeepSeek", f"{tokens_deepseek:,}")
    table.add_row("  MiniMax", f"{tokens_minimax:,}")
    table.add_row("  ─────────", "─────────")
    table.add_row("  TOTAL", f"[bold]{tokens_total:,}[/bold]")
    table.add_row("", "")

    # Wish stats
    proposed = metrics.get("wish_proposed", 0)
    approved = metrics.get("wish_approved", 0)
    rejected = proposed - approved
    rate = f"{(approved/proposed*100):.0f}%" if proposed > 0 else "—"

    table.add_row("Wishes", "")
    table.add_row("  Proposed", f"{proposed}")
    table.add_row("  Approved", f"[green]{approved}[/green]")
    table.add_row("  Rejected", f"[red]{rejected}[/red]")
    table.add_row("  Win Rate", f"[bold]{rate}[/bold]")
    table.add_row("", "")

    # Daemon stats
    iterations = checkpoint.get("iterations", 0)
    max_iter = 200
    table.add_row("Daemon", "")
    table.add_row("  Iterations", f"{iterations}/{max_iter}")
    table.add_row("  Applied", f"{len(checkpoint.get('applied_patches', []))}")

    return Panel(table, title="[bold]Metrics[/bold]", border_style="green", box=box.ROUNDED)


def build_activity(lines: list[str]) -> Panel:
    """Build the recent activity panel."""
    activity = parse_log_activity(lines)

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Time", style="dim", width=8)
    table.add_column("Icon", width=3)
    table.add_column("Event", ratio=1)

    for entry in activity:
        icon = Text(entry["icon"], style=entry.get("color", "white"))
        text = Text(entry["text"], style="dim")
        # Highlight key parts
        if "APPLIED" in entry["text"] or "✓" in entry["text"]:
            text.stylize("green", 0, len(entry["text"]))
        elif "REJECTED" in entry["text"] or "✗" in entry["text"]:
            text.stylize("red", 0, len(entry["text"]))
        table.add_row(entry["time"], icon, text)

    if not activity:
        table.add_row("", "", "[dim]No activity yet...[/dim]")

    return Panel(table, title="[bold]Recent Activity[/bold]", border_style="magenta", box=box.ROUNDED)


def build_architect(checkpoint: dict) -> Panel:
    """Build the architect status panel."""
    content = Text()
    architect_last = checkpoint.get("architect_last_run")
    if architect_last:
        elapsed = int(time.time() - architect_last)
        remaining = max(0, 3600 - elapsed)
        if remaining > 0:
            mins = remaining // 60
            content.append(f"Cooldown: {mins}m remaining\n", style="yellow")
        else:
            content.append("Cooldown: expired — ready\n", style="green")
        content.append(f"Last run: {elapsed // 60}m ago\n", style="dim")
    else:
        content.append("Never run\n", style="dim")

    # Rejection count
    try:
        if REJECTIONS_FILE.exists():
            data = json.loads(REJECTIONS_FILE.read_text())
            reasons = data.get("rejection_reasons", {})
            content.append(f"Rejections: {len(reasons)}\n", style="dim")
    except Exception:
        pass

    # Meta-wishes
    try:
        if META_WISHES_FILE.exists():
            meta = json.loads(META_WISHES_FILE.read_text())
            content.append(f"Meta-wishes: {len(meta)}\n", style="dim")
    except Exception:
        pass

    return Panel(content, title="[bold]Architect[/bold]", border_style="blue", box=box.ROUNDED)


def build_dashboard() -> Layout:
    """Build the full dashboard layout."""
    layout = Layout()

    # Read data
    checkpoint = read_checkpoint()
    metrics = read_metrics()
    log_lines = read_last_log_lines(20)
    stage = detect_pipeline_stage(log_lines)

    # Build layout tree
    layout.split(
        Layout(name="header", size=3),
        Layout(name="body"),
        Layout(name="footer", size=3),
    )

    layout["header"].update(build_header())

    # Body: pipeline + wish on top, metrics + activity on bottom
    layout["body"].split_row(
        Layout(name="left", ratio=2),
        Layout(name="right", ratio=1),
    )

    layout["left"].split(
        Layout(name="pipeline", size=7),
        Layout(name="wish"),
        Layout(name="activity"),
    )

    layout["right"].split(
        Layout(name="metrics"),
        Layout(name="architect"),
    )

    layout["pipeline"].update(build_pipeline(stage))
    layout["wish"].update(build_wish(stage))
    layout["activity"].update(build_activity(log_lines))
    layout["metrics"].update(build_metrics(metrics, checkpoint))
    layout["architect"].update(build_architect(checkpoint))

    # Footer
    footer_text = Text()
    footer_text.append("  [q]uit  [p]ause  [r]esume  [s]tatus  ", style="dim")
    footer_text.append("│  ", style="dim")
    footer_text.append("Ctrl+C to exit", style="dim")
    layout["footer"].update(Panel(footer_text, border_style="dim"))

    return layout


# ── Main entry point ──────────────────────────────────────────────────────
def run_dashboard(refresh_rate: float = 3.0):
    """Run the live dashboard."""
    console.clear()
    try:
        with Live(
            build_dashboard(),
            console=console,
            refresh_per_second=1 / refresh_rate,
            screen=True,
        ) as live:
            while True:
                time.sleep(refresh_rate)
                live.update(build_dashboard())
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard closed.[/dim]")


if __name__ == "__main__":
    run_dashboard()
