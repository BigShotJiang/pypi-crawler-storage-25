"""Canonical built-in skill projections for Aegis product surfaces."""

from __future__ import annotations

from collections.abc import Mapping

from .hub import builtin_skill_catalog_entries
from .runtime import SkillDefinition


def builtin_skill_definitions(enabled_overrides: Mapping[str, bool]) -> tuple[SkillDefinition, ...]:
    return tuple(
        entry.to_skill_definition(enabled_override=enabled_overrides.get(entry.skill_id))
        for entry in builtin_skill_catalog_entries(enabled_overrides)
    )
