"""Public inventory of the procedural skill surface."""

SKILL_SURFACES = (
    "SkillScope",
    "SkillDependency",
    "SkillDefinition",
    "SkillCatalogVisibility",
    "SkillCatalogEntry",
    "SkillActivationRecord",
    "SkillManifest",
    "SkillManifestLoadRecord",
    "SkillLoader",
    "SkillCatalog",
    "JsonSkillLoader",
    "InMemorySkillCatalog",
    "SkillRuntime",
)
