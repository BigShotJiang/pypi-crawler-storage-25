"""Session and inspection methods for the API runtime app."""


from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
import json
from typing import Any, Mapping
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    provider_selection_from_payload,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore
from packages.context import ContextRuntime
from packages.contracts import ContextBundle, EventEnvelope, ExecutionResult, GoalNode, MemoryRecord, ProfileState, SessionState, ActivityGraph
from packages.kernel import KernelDependencies, KernelOutcome, KernelService, KernelTurnRequest, ObservationPipeline, StateReconciler
from packages.learning import LearningRuntime
from packages.evidence import MemoryRuntime
from packages.kernel.memory_recovery import memory_retrieval_scopes
from packages.operator import (
    MemoryOperatorDetail,
    MemorySearchHit,
    ProcedureOperatorDetail,
    build_audit_surface,
    build_memory_operator_surface,
    build_procedure_operator_surface,
    build_profile_operator_surface,
    build_activity_operator_surface,
    library_procedure_overlays,
)
from packages.planning import PlanningService
from packages.session import SessionLineageService, SessionResumeResult
from packages.storage import RuntimeStorageRepository
from packages.tools import BuiltinToolDependencies, build_tool_runtime
from packages.tools.adapters import DeliveryMessageSurfaceAdapter, StructuredClarifySurface
from packages.tools.browser_backend import create_playwright_browser_backend

from .capabilities import (
    APIContextCapability,
    APIDeliveryCapability,
    APIMemoryCapability,
    APIModelProvider,
    APIPlanningCapability,
    APITelemetrySink,
    APIToolExecution,
)
from .state_runtime import APIContinuityInspection, APIStateService
from .tool_surfaces import APIMemoryManagementSurface

from .api_runtime_support import (
    APIAppConfig,
    APIResponse,
    APISessionCreationResult,
    APISessionInspection,
    APISessionLifecycleResult,
    APIResumeResult,
    APITurnRecord,
    APITurnResult,
    _coerce_str_tuple,
    _json_bytes,
    _jsonable,
    _now,
    _optional_bool,
    _optional_datetime,
    _optional_str,
    _read_json_bytes,
    _split_path,
)


def _latest_turn_record(self, session_id: str):
    turns = self._turns.get(session_id, ())
    return turns[-1] if turns else None


def _latest_turn_intent(self, session_id: str):
    latest_turn = _latest_turn_record(self, session_id)
    return latest_turn.outcome.intent if latest_turn is not None else None


def _embedding_status(self) -> str | None:
    status = str(self.model_provider.describe().get("embedding_bootstrap_status") or "").strip()
    return status or None


def _opened_scopes_for_session(self, session_id: str, *, session: SessionState, graph: ActivityGraph | None):
    intent = _latest_turn_intent(self, session_id)
    if intent is None:
        return ()
    continuity = self.session_lineage.continuity_state(
        session,
        lineage=self.repository.lineage(session_id),
        active_goal_id=graph.active_goal_id if graph is not None else None,
    )
    return memory_retrieval_scopes(session, continuity=continuity, intent=intent)

def create_session(
    self,
    *,
    profile_id: str,
    display_name: str,
    mode: str,
    workspace_id: str | None = None,
    clone_path: str | None = None,
    preferences: tuple[str, ...] = (),
    enabled_capabilities: tuple[str, ...] = (),
    provider_profile: Mapping[str, Any] | None = None,
    session_id: str | None = None,
) -> APISessionCreationResult:
    profile = ProfileState(
        profile_id=profile_id,
        display_name=display_name,
        mode=mode,
        clone_path=clone_path,
        preferences=preferences,
        enabled_capabilities=enabled_capabilities,
    )
    if provider_profile is not None:
        selection = provider_selection_from_payload(provider_profile)
        active_profile = selection.strong_profile
        weak_profile = selection.weak_profile
        if active_profile is None or weak_profile is None:
            raise ValueError("provider_profile must include strong_profile and weak_profile objects")
        self.auth_store.register(active_profile)
        self.auth_store.register(weak_profile)
        self.model_provider.set_active_profiles(
            strong_provider_profile_id=active_profile.profile_id,
            weak_provider_profile_id=weak_profile.profile_id,
            provider_id=active_profile.provider_id,
            intent_mode=selection.intent_mode,
        )
    elif self.model_provider.active_profile() is None and self.auth_store.list():
        active_profile = self.auth_store.list()[0]
        self.model_provider.set_active_profiles(
            strong_provider_profile_id=active_profile.profile_id,
            weak_provider_profile_id=active_profile.profile_id,
            provider_id=active_profile.provider_id,
        )
    session = self.session_lineage.start_session(
        profile,
        workspace_id=workspace_id,
        session_id=session_id,
    )
    self.personal_state.ensure_profile_state(profile, sync_source="api.create-session")
    return APISessionCreationResult(profile=profile, session=session)

def interrupt_session(self, session_id: str, *, interruption_state: str) -> APISessionLifecycleResult:
    session = self.session_lineage.interrupt_session(session_id, interruption_state=interruption_state)
    return APISessionLifecycleResult(session=session)

def resume_session(self, session_id: str, *, child_session_id: str | None = None) -> APIResumeResult:
    result: SessionResumeResult = self.session_lineage.resume_session(
        session_id,
        child_session_id=child_session_id,
    )
    return APIResumeResult(parent=result.parent, session=result.session, lineage=result.lineage)

def _load_activity_graph(self, session_id: str) -> ActivityGraph:
    graph = self.repository.load_activity_graph(session_id)
    if graph is None:
        raise KeyError(session_id)
    return graph

def list_goals(self, session_id: str) -> tuple[GoalNode, ...]:
    graph = self.repository.load_activity_graph(session_id)
    if graph is None:
        return ()
    return graph.goals

def list_memories(self, session_id: str) -> tuple[MemoryRecord, ...]:
    return tuple(self.memory_runtime.store.list(session_id=session_id))

def inspect_identity(self, *, session_id: str | None = None, profile_id: str | None = None):
    return self.personal_state.inspect_identity(session_id=session_id, profile_id=profile_id)

def update_identity_state(
    self,
    *,
    session_id: str | None = None,
    profile_id: str | None = None,
    display_name: str | None = None,
    personality_preset: str | None = None,
    initiative: str | None = None,
    charter_text: str | None = None,
    clear_charter: bool = False,
):
    return self.personal_state.update_identity_state(
        session_id=session_id,
        profile_id=profile_id,
        display_name=display_name,
        personality_preset=personality_preset,
        initiative=initiative,
        charter_text=charter_text,
        clear_charter=clear_charter,
    )

def inspect_user(self, *, session_id: str | None = None, profile_id: str | None = None):
    return self.personal_state.inspect_user(session_id=session_id, profile_id=profile_id)

def update_user_state(
    self,
    *,
    session_id: str | None = None,
    profile_id: str | None = None,
    text: str | None = None,
    fields: dict[str, object] | None = None,
    append: bool = False,
    clear: bool = False,
):
    return self.personal_state.update_user_state(
        session_id=session_id,
        profile_id=profile_id,
        text=text,
        fields=fields,
        append=append,
        clear=clear,
    )

def inspect_relationship(self, *, session_id: str | None = None, profile_id: str | None = None):
    return self.personal_state.inspect_relationship(session_id=session_id, profile_id=profile_id)

def update_relationship_state(
    self,
    *,
    session_id: str | None = None,
    profile_id: str | None = None,
    text: str | None = None,
    append: bool = False,
    clear: bool = False,
):
    return self.personal_state.update_relationship_state(
        session_id=session_id,
        profile_id=profile_id,
        text=text,
        append=append,
        clear=clear,
    )

def inspect_continuity(self, session_id: str) -> APIContinuityInspection:
    return self.personal_state.inspect_continuity(session_id)

def inspect_context_frame(self, session_id: str):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    goals = self.list_goals(session_id)
    memories = self.list_memories(session_id)
    latest_turn = _latest_turn_record(self, session_id)
    hot_turns = tuple(
        part
        for part in (
            str(latest_turn.request.get("prompt") or "").strip() if latest_turn is not None else "",
            latest_turn.outcome.execution.summary.strip() if latest_turn is not None else "",
        )
        if part
    )
    library = self.repository.load_procedure_library(session.profile_id)
    procedure_overlays = library_procedure_overlays(
        goals=goals,
        procedures=library.procedures if library is not None else (),
    )
    return self.context_runtime.assemble_detailed(
        session,
        goals,
        memories,
        hot_turns=hot_turns,
        profile_snapshot_refs=(
            f"profile:{session.profile_id}:identity",
            f"profile:{session.profile_id}:user",
            f"profile:{session.profile_id}:relationship",
        ),
        procedure_overlays=procedure_overlays,
        intent=latest_turn.outcome.intent if latest_turn is not None else None,
    )

def inspect_profile_surface(self, session_id: str):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    profile = self.repository.load_profile(session.profile_id)
    if profile is None:
        raise KeyError(session.profile_id)
    return build_profile_operator_surface(
        session_id=session_id,
        profile_id=profile.profile_id,
        profile_mode=profile.mode,
        identity=self.inspect_identity(session_id=session_id),
        user=self.inspect_user(session_id=session_id),
        relationship=self.inspect_relationship(session_id=session_id),
    )

def patch_profile_surface(self, session_id: str, payload: Mapping[str, Any]):
    if any(key in payload for key in {"display_name", "name", "personality_preset", "initiative", "charter_text", "text", "content", "clear_charter"}):
        self.update_identity_state(
            session_id=session_id,
            display_name=_optional_str(payload.get("display_name") or payload.get("name")),
            personality_preset=_optional_str(payload.get("personality_preset")),
            initiative=_optional_str(payload.get("initiative")),
            charter_text=_optional_str(payload.get("charter_text") or payload.get("text") or payload.get("content")),
            clear_charter=bool(payload.get("clear_charter", False)),
        )
    if any(key in payload for key in {"user_text", "user_content", "user_fields", "user_append", "user_clear"}):
        self.update_user_state(
            session_id=session_id,
            text=_optional_str(payload.get("user_text") or payload.get("user_content")),
            fields=payload.get("user_fields") if isinstance(payload.get("user_fields"), dict) else None,
            append=bool(payload.get("user_append", False)),
            clear=bool(payload.get("user_clear", False)),
        )
    if any(key in payload for key in {"relationship_text", "relationship_content", "relationship_append", "relationship_clear"}):
        self.update_relationship_state(
            session_id=session_id,
            text=_optional_str(payload.get("relationship_text") or payload.get("relationship_content")),
            append=bool(payload.get("relationship_append", False)),
            clear=bool(payload.get("relationship_clear", False)),
        )
    return self.inspect_profile_surface(session_id)

def inspect_activity_surface(self, session_id: str):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    continuity = self.inspect_continuity(session_id)
    graph = self.repository.load_activity_graph(session_id)
    intent = _latest_turn_intent(self, session_id)
    return build_activity_operator_surface(
        session_id=session_id,
        active_goal_id=continuity.active_goal_id,
        active_goal_reason=continuity.wake_summary,
        wake_action=continuity.wake_action,
        wake_factors=continuity.wake_factors,
        goal_graph_revision=graph.revision_id if graph is not None else None,
        goals=graph.goals if graph is not None else (),
        intent=intent,
        opened_scopes=_opened_scopes_for_session(self, session_id, session=session, graph=graph),
        embedding_status=_embedding_status(self),
    )

def inspect_memory_surface(self, session_id: str):
    memories = tuple(
        MemoryOperatorDetail(
            memory=memory,
            state=self.memory_runtime.store.state(memory.memory_id),
            lineage=self.memory_runtime.store.lineage(memory.memory_id),
        )
        for memory in self.list_memories(session_id)
    )
    return build_memory_operator_surface(session_id=session_id, memories=memories)

def search_memory_surface(self, session_id: str, *, query: str, limit: int = 5):
    retrieval = self.memory_runtime.retrieve(
        session_id,
        query,
        goal_ids=tuple(goal.goal_id for goal in self.list_goals(session_id)),
        limit=limit,
    )
    memories = tuple(
        MemoryOperatorDetail(
            memory=memory,
            state=self.memory_runtime.store.state(memory.memory_id),
            lineage=self.memory_runtime.store.lineage(memory.memory_id),
        )
        for memory in self.list_memories(session_id)
    )
    hits = tuple(
        MemorySearchHit(memory=candidate.record, score=candidate.score, reasons=candidate.reasons)
        for candidate in retrieval.candidates
    )
    return build_memory_operator_surface(
        session_id=session_id,
        memories=memories,
        search_query=query,
        search_hits=hits,
        scope_reason=retrieval.scope_reason,
        index_policy=self.memory_runtime.index_policy(),
    )

def inspect_procedure_surface(self, session_id: str, *, minimum_support: int = 2):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    library = self.repository.load_procedure_library(session.profile_id)
    learning = LearningRuntime(self.repository)
    candidates = learning.list_procedure_candidates(
        profile_id=session.profile_id,
        session_id=session_id,
        minimum_support=minimum_support,
    )
    procedures = tuple(
        ProcedureOperatorDetail(
            procedure=procedure,
            verification=(
                self.repository.load_verification_bundle(procedure.verification_bundle_id)
                if procedure.verification_bundle_id is not None
                else None
            ),
        )
        for procedure in (library.procedures if library is not None else ())
    )
    return build_procedure_operator_surface(
        session_id=session_id,
        profile_id=session.profile_id,
        procedures=procedures,
        candidates=candidates,
    )

def inspect_procedure_detail(self, session_id: str, procedure_id: str):
    surface = self.inspect_procedure_surface(session_id)
    for detail in surface.procedures:
        if detail.procedure.procedure_id == procedure_id:
            return detail
    raise KeyError(procedure_id)

def patch_procedure_surface(self, session_id: str, procedure_id: str, payload: Mapping[str, Any]):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    learning = LearningRuntime(self.repository)
    updated = learning.patch_procedure(
        profile_id=session.profile_id,
        procedure_id=procedure_id,
        title=_optional_str(payload.get("title")),
        summary=_optional_str(payload.get("summary") or payload.get("content")),
        trigger_refs=_coerce_str_tuple(payload.get("trigger_refs")) if payload.get("trigger_refs") is not None else None,
        status=_optional_str(payload.get("status")),
    )
    return ProcedureOperatorDetail(
        procedure=updated,
        verification=(
            self.repository.load_verification_bundle(updated.verification_bundle_id)
            if updated.verification_bundle_id is not None
            else None
        ),
    )

def retire_procedure_surface(self, session_id: str, procedure_id: str):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    learning = LearningRuntime(self.repository)
    retired = learning.retire_procedure(profile_id=session.profile_id, procedure_id=procedure_id)
    return ProcedureOperatorDetail(
        procedure=retired,
        verification=(
            self.repository.load_verification_bundle(retired.verification_bundle_id)
            if retired.verification_bundle_id is not None
            else None
        ),
    )

def inspect_audit_surface(self, session_id: str):
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    graph = self.repository.load_activity_graph(session_id)
    intent = _latest_turn_intent(self, session_id)
    opened_scopes = _opened_scopes_for_session(self, session_id, session=session, graph=graph)
    work = self.inspect_activity_surface(session_id)
    context_result = self.inspect_context_frame(session_id)
    return build_audit_surface(
        session_id=session_id,
        active_goal_id=work.active_goal_id,
        active_goal_reason=work.active_goal_reason,
        context_result=context_result,
        intent=intent,
        opened_scopes=opened_scopes,
        embedding_status=_embedding_status(self),
    )

def inspect_session(self, session_id: str) -> APISessionInspection:
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    profile = self.repository.load_profile(session.profile_id)
    if profile is None:
        raise KeyError(session.profile_id)
    lineage = self.repository.lineage(session_id)
    latest_turn = self._turns.get(session_id, [])[-1] if self._turns.get(session_id) else None
    graph = self.repository.load_activity_graph(session_id)
    goals = graph.goals if graph is not None else ()
    memories = tuple(self.memory_runtime.store.list(session_id=session_id))
    memory_count = len(memories)
    telemetry_count = len(self.telemetry.events)
    provider_profile = self.model_provider.active_profile()
    return APISessionInspection(
        profile=profile,
        session=session,
        lineage=lineage,
        goals=goals,
        memories=memories,
        latest_turn=latest_turn,
        memory_count=memory_count,
        telemetry_count=telemetry_count,
        goal_graph_revision=graph.revision_id if graph is not None else None,
        goal_status_counts=graph.status_counts() if graph is not None else {},
        provider_profile=provider_profile,
    )
