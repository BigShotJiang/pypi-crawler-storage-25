"""Turn execution and HTTP dispatch methods for the API runtime app."""


from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
import json
from typing import Any, Mapping
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    provider_profile_from_payload,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore
from packages.context import ContextRuntime
from packages.contracts import ContextBundle, EventEnvelope, ExecutionResult, GoalNode, MemoryRecord, ProfileState, SessionState, ActivityGraph
from packages.kernel import KernelDependencies, KernelOutcome, KernelService, KernelTurnRequest, ObservationPipeline, StateReconciler
from packages.learning import LearningRuntime
from packages.evidence import MemoryRuntime
from packages.operator import (
    MemoryOperatorDetail,
    MemorySearchHit,
    ProcedureOperatorDetail,
    build_audit_surface,
    build_memory_operator_surface,
    build_procedure_operator_surface,
    build_profile_operator_surface,
    build_activity_operator_surface,
    library_procedure_overlays,
)
from packages.planning import PlanningService
from packages.session import SessionLineageService, SessionResumeResult
from packages.storage import RuntimeStorageRepository
from packages.tools import BuiltinToolDependencies, build_tool_runtime
from packages.tools.adapters import DeliveryMessageSurfaceAdapter, StructuredClarifySurface
from packages.tools.browser_backend import create_playwright_browser_backend

from .capabilities import (
    APIContextCapability,
    APIDeliveryCapability,
    APIMemoryCapability,
    APIModelProvider,
    APIPlanningCapability,
    APITelemetrySink,
    APIToolExecution,
)
from .state_runtime import APIContinuityInspection, APIStateService
from .tool_surfaces import APIMemoryManagementSurface

from .api_runtime_support import (
    APIAppConfig,
    APIResponse,
    APISessionCreationResult,
    APISessionInspection,
    APIResumeResult,
    APITurnRecord,
    APITurnResult,
    _coerce_str_tuple,
    _json_bytes,
    _jsonable,
    _now,
    _optional_bool,
    _optional_datetime,
    _optional_str,
    _read_json_bytes,
    _split_path,
)

def run_turn(
    self,
    session_id: str,
    *,
    prompt: str,
    goal_query: str | None = None,
    tool_name: str | None = None,
    tool_arguments: Mapping[str, Any] | None = None,
    delivery_payload: Mapping[str, Any] | None = None,
) -> APITurnResult:
    session = self.repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    profile = self.repository.load_profile(session.profile_id)
    if profile is None:
        raise KeyError(session.profile_id)
    previous_goal_graph = self.repository.load_activity_graph(session_id) or ActivityGraph(session_id=session_id)
    event = EventEnvelope(
        event_id=f"api:{session_id}:turn:{uuid4().hex}",
        event_type="turn.received",
        session_id=session_id,
        source="api",
        payload={
            "message": prompt,
            "content": prompt,
            "summary": prompt,
            "goal_query": goal_query or "",
            "tool_name": tool_name or "",
        },
    )
    outcome = self.kernel.run(
        KernelTurnRequest(
            event=event,
            prompt=prompt,
            goal_query=goal_query,
            tool_name=tool_name,
            tool_arguments=dict(tool_arguments or {}),
            delivery_payload=dict(delivery_payload or {}),
        )
    )
    observation = ObservationPipeline().observe_turn(
        inbound_event=event,
        execution=outcome.execution,
        previous_goal_graph=previous_goal_graph,
        reconciled_goal_graph=outcome.goal_graph,
        selected_goal_id=(
            outcome.decision.selected_move.goal_id
            if outcome.decision is not None and outcome.decision.selected_move.goal_id
            else outcome.goal_graph.active_goal_id
        ),
        decision_summary=(
            outcome.decision.rationale.summary
            if outcome.decision is not None and outcome.decision.rationale.summary.strip()
            else outcome.execution.summary
        ),
        source="api",
    )
    StateReconciler().reconcile_turn(
        repository=self.repository,
        memory_runtime=self.memory_runtime,
        observation=observation,
    )
    self.personal_state.apply_turn_profile_delta(
        session_id=session_id,
        user_fields=dict(observation.profile_delta.user_fields),
        preference_updates=observation.profile_delta.preference_updates,
        relationship_notes=observation.profile_delta.relationship_notes,
    )
    record = APITurnRecord(
        request={
            "prompt": prompt,
            "goal_query": goal_query,
            "tool_name": tool_name,
            "tool_arguments": dict(tool_arguments or {}),
            "delivery_payload": dict(delivery_payload or {}),
        },
        outcome=outcome,
        recorded_at=_now(),
    )
    self._turns.setdefault(session_id, []).append(record)
    inspection = self.inspect_session(session_id)
    return APITurnResult(
        session=inspection.session,
        outcome=outcome,
        latest_turn=record,
        inspection=inspection,
    )

def dispatch(self, method: str, path: str, body: bytes | None = None) -> APIResponse:
    if method.upper() == "GET" and path == "/healthz":
        return APIResponse(200, {"status": "ok", "service": "aegis-api"})

    try:
        parts = _split_path(path)
        if not parts:
            return APIResponse(404, {"error": "not_found"})
        if parts[0] == "providers":
            return self._dispatch_providers(method, parts[1:], body)
        if parts[0] != "sessions":
            return APIResponse(404, {"error": "not_found"})
        if method.upper() == "POST" and len(parts) == 1:
            payload = _read_json_bytes(body)
            result = self.create_session(
                profile_id=str(payload["profile_id"]),
                display_name=str(payload["display_name"]),
                mode=str(payload["mode"]),
                workspace_id=payload.get("workspace_id"),
                clone_path=payload.get("clone_path"),
                preferences=tuple(payload.get("preferences", ())),
                enabled_capabilities=tuple(payload.get("enabled_capabilities", ())),
                provider_profile=payload.get("provider_profile"),
                session_id=payload.get("session_id"),
            )
            return APIResponse(201, _jsonable(result.to_record()))
        if len(parts) < 2:
            return APIResponse(404, {"error": "not_found"})
        session_id = parts[1]
        if method.upper() == "GET" and len(parts) == 2:
            return APIResponse(200, _jsonable(self.inspect_session(session_id).to_record()))
        if method.upper() == "POST" and len(parts) == 3 and parts[2] == "interrupt":
            payload = _read_json_bytes(body)
            result = self.interrupt_session(session_id, interruption_state=str(payload["interruption_state"]))
            return APIResponse(200, _jsonable(result.to_record()))
        if method.upper() == "POST" and len(parts) == 3 and parts[2] == "resume":
            payload = _read_json_bytes(body)
            result = self.resume_session(session_id, child_session_id=payload.get("child_session_id"))
            return APIResponse(200, _jsonable(result.to_record()))
        if method.upper() == "POST" and len(parts) == 3 and parts[2] == "turns":
            payload = _read_json_bytes(body)
            result = self.run_turn(
                session_id,
                prompt=str(payload["prompt"]),
                goal_query=payload.get("goal_query"),
                tool_name=payload.get("tool_name"),
                tool_arguments=payload.get("tool_arguments"),
                delivery_payload=payload.get("delivery_payload"),
            )
            return APIResponse(200, _jsonable(result.to_record()))
        if len(parts) == 3 and parts[2] in {"profile", "activity", "memory", "procedure", "audit"}:
            surface = parts[2]
            if surface == "profile":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "profile": self.inspect_profile_surface(session_id)}))
                if method.upper() in {"PATCH", "POST"}:
                    payload = _read_json_bytes(body)
                    return APIResponse(200, _jsonable({"session_id": session_id, "profile": self.patch_profile_surface(session_id, payload)}))
            if surface == "activity":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "activity": self.inspect_activity_surface(session_id)}))
                if method.upper() == "POST":
                    payload = _read_json_bytes(body)
                    result = self.create_goal(
                        session_id,
                        title=str(payload["title"]),
                        status=str(payload.get("status", "active")),
                        priority=str(payload.get("priority", "medium")),
                        owner=str(payload.get("owner", "shared")),
                        parent_goal_id=_optional_str(payload.get("parent_goal_id")),
                        dependency_refs=payload.get("dependency_refs"),
                        evidence_refs=payload.get("evidence_refs"),
                        related_memory_ids=payload.get("related_memory_ids"),
                        review_checkpoint=_optional_str(payload.get("review_checkpoint")),
                        deadline=payload.get("deadline"),
                        time_sensitivity=_optional_str(payload.get("time_sensitivity")),
                        reason=_optional_str(payload.get("reason")),
                        activate=_optional_bool(payload.get("activate")),
                    )
                    return APIResponse(201, _jsonable({"session_id": session_id, "activity": self.inspect_activity_surface(session_id), "activity_item": result["goal"]}))
            if surface == "memory":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "memory": self.inspect_memory_surface(session_id)}))
            if surface == "procedure" and method.upper() == "GET":
                return APIResponse(200, _jsonable({"session_id": session_id, "procedure": self.inspect_procedure_surface(session_id)}))
            if surface == "audit" and method.upper() == "GET":
                return APIResponse(200, _jsonable({"session_id": session_id, "audit": self.inspect_audit_surface(session_id)}))
        if len(parts) == 3 and parts[2] in {"identity", "user", "relationship", "continuity"}:
            surface = parts[2]
            if surface == "identity":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "identity": self.inspect_identity(session_id=session_id)}))
                if method.upper() in {"PATCH", "POST"}:
                    payload = _read_json_bytes(body)
                    result = self.update_identity_state(
                        session_id=session_id,
                        display_name=_optional_str(payload.get("display_name") or payload.get("name")),
                        personality_preset=_optional_str(payload.get("personality_preset")),
                        initiative=_optional_str(payload.get("initiative")),
                        charter_text=_optional_str(payload.get("charter_text") or payload.get("text") or payload.get("content")),
                        clear_charter=bool(payload.get("clear_charter", False)),
                    )
                    return APIResponse(200, _jsonable({"session_id": session_id, "identity": result}))
            if surface == "user":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "user": self.inspect_user(session_id=session_id)}))
                if method.upper() in {"PATCH", "POST"}:
                    payload = _read_json_bytes(body)
                    result = self.update_user_state(
                        session_id=session_id,
                        text=_optional_str(payload.get("text") or payload.get("content")),
                        fields=payload.get("fields") if isinstance(payload.get("fields"), dict) else None,
                        append=bool(payload.get("append", False)),
                        clear=bool(payload.get("clear", False)),
                    )
                    return APIResponse(200, _jsonable({"session_id": session_id, "user": result}))
            if surface == "relationship":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "relationship": self.inspect_relationship(session_id=session_id)}))
                if method.upper() in {"PATCH", "POST"}:
                    payload = _read_json_bytes(body)
                    result = self.update_relationship_state(
                        session_id=session_id,
                        text=_optional_str(payload.get("text") or payload.get("content")),
                        append=bool(payload.get("append", False)),
                        clear=bool(payload.get("clear", False)),
                    )
                    return APIResponse(200, _jsonable({"session_id": session_id, "relationship": result}))
            if surface == "continuity" and method.upper() == "GET":
                return APIResponse(200, _jsonable(self.inspect_continuity(session_id).to_record()))
        if len(parts) == 3 and parts[2] in {"goals", "memories"}:
            if parts[2] == "goals":
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "goals": self.list_goals(session_id)}))
                if method.upper() == "POST":
                    payload = _read_json_bytes(body)
                    result = self.create_goal(
                        session_id,
                        title=str(payload["title"]),
                        status=str(payload.get("status", "active")),
                        priority=str(payload.get("priority", "medium")),
                        owner=str(payload.get("owner", "shared")),
                        parent_goal_id=_optional_str(payload.get("parent_goal_id")),
                        dependency_refs=payload.get("dependency_refs"),
                        evidence_refs=payload.get("evidence_refs"),
                        related_memory_ids=payload.get("related_memory_ids"),
                        review_checkpoint=_optional_str(payload.get("review_checkpoint")),
                        deadline=payload.get("deadline"),
                        time_sensitivity=_optional_str(payload.get("time_sensitivity")),
                        reason=_optional_str(payload.get("reason")),
                        activate=_optional_bool(payload.get("activate")),
                    )
                    return APIResponse(201, _jsonable(result))
            if method.upper() == "GET":
                return APIResponse(200, _jsonable({"session_id": session_id, "memories": self.list_memories(session_id)}))
        if len(parts) == 4 and parts[2] == "memory" and parts[3] == "search":
            payload = _read_json_bytes(body)
            query = _optional_str(payload.get("query"))
            if query is None:
                raise ValueError("memory search query is required")
            limit = int(payload.get("limit", 5))
            return APIResponse(200, _jsonable({"session_id": session_id, "memory": self.search_memory_surface(session_id, query=query, limit=limit)}))
        if len(parts) == 4 and parts[2] == "activity":
            goal_id = parts[3]
            if method.upper() == "GET":
                return APIResponse(200, _jsonable({"session_id": session_id, "activity_item": self.inspect_goal(session_id, goal_id), "activity": self.inspect_activity_surface(session_id)}))
            payload = _read_json_bytes(body)
            if method.upper() in {"PATCH", "POST"}:
                result = self.update_goal(
                    session_id,
                    goal_id,
                    title=payload.get("title"),
                    status=payload.get("status"),
                    priority=payload.get("priority"),
                    owner=payload.get("owner"),
                    dependency_refs=payload.get("dependency_refs"),
                    evidence_refs=payload.get("evidence_refs"),
                    related_memory_ids=payload.get("related_memory_ids"),
                    review_checkpoint=payload.get("review_checkpoint"),
                    deadline=payload.get("deadline"),
                    time_sensitivity=payload.get("time_sensitivity"),
                    reason=payload.get("reason"),
                )
                return APIResponse(200, _jsonable({"session_id": session_id, "activity_item": result["goal"], "before": result["before"], "activity": self.inspect_activity_surface(session_id)}))
            if method.upper() == "DELETE":
                result = self.delete_goal(session_id, goal_id, reason=str(payload.get("reason", "")))
                return APIResponse(200, _jsonable({"session_id": session_id, "activity_item": result["goal"], "before": result["before"], "activity": self.inspect_activity_surface(session_id)}))
        if len(parts) == 4 and parts[2] == "memory":
            memory_id = parts[3]
            if method.upper() == "GET":
                return APIResponse(200, _jsonable({
                    "session_id": session_id,
                    "memory": MemoryOperatorDetail(
                        memory=self.inspect_memory(session_id, memory_id)["memory"],
                        state=self.memory_runtime.store.state(memory_id),
                        lineage=self.memory_runtime.store.lineage(memory_id),
                    ),
                }))
            payload = _read_json_bytes(body)
            if method.upper() in {"PATCH", "POST"}:
                if "corrected_content" in payload:
                    result = self.correct_memory(
                        session_id,
                        memory_id,
                        corrected_content=str(payload["corrected_content"]),
                        reason=str(payload.get("reason", "")),
                        actor=str(payload.get("actor", "user")),
                    )
                    return APIResponse(200, _jsonable(result))
                if "pinned" in payload:
                    result = self.pin_memory(
                        session_id,
                        memory_id,
                        pinned=bool(payload.get("pinned")),
                        reason=str(payload.get("reason", "")),
                        actor=str(payload.get("actor", "user")),
                    )
                    return APIResponse(200, _jsonable(result))
                raise ValueError("memory patch requires corrected_content or pinned")
            if method.upper() == "DELETE":
                result = self.delete_memory(
                    session_id,
                    memory_id,
                    reason=str(payload.get("reason", "")),
                    actor=str(payload.get("actor", "user")),
                )
                return APIResponse(200, _jsonable(result))
        if len(parts) == 4 and parts[2] == "procedure":
            procedure_id = parts[3]
            if method.upper() == "GET":
                return APIResponse(200, _jsonable({"session_id": session_id, "procedure": self.inspect_procedure_detail(session_id, procedure_id)}))
            payload = _read_json_bytes(body)
            if method.upper() in {"PATCH", "POST"}:
                return APIResponse(200, _jsonable({"session_id": session_id, "procedure": self.patch_procedure_surface(session_id, procedure_id, payload)}))
            if method.upper() == "DELETE":
                return APIResponse(200, _jsonable({"session_id": session_id, "procedure": self.retire_procedure_surface(session_id, procedure_id)}))
        if len(parts) == 4 and parts[2] == "goals":
            goal_id = parts[3]
            if method.upper() == "GET":
                return APIResponse(200, _jsonable(self.inspect_goal(session_id, goal_id)))
            payload = _read_json_bytes(body)
            if method.upper() in {"PATCH", "POST"}:
                result = self.update_goal(
                    session_id,
                    goal_id,
                    title=payload.get("title"),
                    status=payload.get("status"),
                    priority=payload.get("priority"),
                    owner=payload.get("owner"),
                    dependency_refs=payload.get("dependency_refs"),
                    evidence_refs=payload.get("evidence_refs"),
                    related_memory_ids=payload.get("related_memory_ids"),
                    review_checkpoint=payload.get("review_checkpoint"),
                    deadline=payload.get("deadline"),
                    time_sensitivity=payload.get("time_sensitivity"),
                    reason=payload.get("reason"),
                )
                return APIResponse(200, _jsonable(result))
            if method.upper() == "DELETE":
                result = self.delete_goal(session_id, goal_id, reason=str(payload.get("reason", "")))
                return APIResponse(200, _jsonable(result))
        if len(parts) == 4 and parts[2] == "memories":
            memory_id = parts[3]
            if method.upper() == "GET":
                return APIResponse(200, _jsonable(self.inspect_memory(session_id, memory_id)))
            payload = _read_json_bytes(body)
            if method.upper() in {"PATCH", "POST"}:
                result = self.correct_memory(
                    session_id,
                    memory_id,
                    corrected_content=str(payload["corrected_content"]),
                    reason=str(payload.get("reason", "")),
                    actor=str(payload.get("actor", "user")),
                )
                return APIResponse(200, _jsonable(result))
            if method.upper() == "DELETE":
                result = self.delete_memory(
                    session_id,
                    memory_id,
                    reason=str(payload.get("reason", "")),
                    actor=str(payload.get("actor", "user")),
                )
                return APIResponse(200, _jsonable(result))
        return APIResponse(404, {"error": "not_found"})
    except KeyError as error:
        return APIResponse(404, {"error": "not_found", "missing": str(error)})
    except (ValueError, TypeError) as error:
        return APIResponse(400, {"error": "bad_request", "detail": str(error)})

def _dispatch_providers(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
    if method.upper() == "GET" and len(parts) == 0:
        return APIResponse(200, _jsonable(self.list_providers()))
    if method.upper() == "GET" and len(parts) == 1 and parts[0] == "doctor":
        return APIResponse(200, _jsonable(self.doctor_provider()))
    if method.upper() == "GET" and len(parts) == 2 and parts[0] == "setup":
        return APIResponse(200, _jsonable(self.setup_provider(parts[1])))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "default":
        payload = _read_json_bytes(body)
        provider_profile = payload.get("provider_profile")
        if not isinstance(provider_profile, dict):
            raise ValueError("provider_profile must be an object containing strong_profile, weak_profile, and intent_mode")
        result = self.set_default_provider(provider_profile)
        return APIResponse(200, _jsonable(result))
    if method.upper() == "POST" and len(parts) == 1 and parts[0] == "test":
        payload = _read_json_bytes(body)
        result = self.test_provider(prompt=str(payload.get("prompt", "Summarize the current provider configuration.")))
        return APIResponse(200, _jsonable(result))
    return APIResponse(404, {"error": "not_found"})

def __call__(self, environ: Mapping[str, Any], start_response: Any) -> list[bytes]:
    method = str(environ.get("REQUEST_METHOD", "GET"))
    path = str(environ.get("PATH_INFO", "/"))
    body = environ.get("wsgi.input")
    payload = body.read() if body is not None else b""
    response = self.dispatch(method, path, payload)
    start_response(
        f"{response.status_code} {'OK' if response.status_code < 400 else 'ERROR'}",
        list(response.headers),
    )
    return [_json_bytes(response.payload)]
