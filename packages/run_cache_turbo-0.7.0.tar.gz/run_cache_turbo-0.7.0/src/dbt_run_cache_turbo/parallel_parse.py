"""Parallel parsing for dbt-core's ManifestLoader.

Replaces ManifestLoader.parse_project with a parallelized version using
ProcessPoolExecutor with fork.  Each parallel phase creates a fresh pool
so that forked workers always inherit the current manifest and project
state via copy-on-write.
"""

from __future__ import annotations

import dataclasses
import multiprocessing as mp
import os
import time
import traceback
import typing as t
from concurrent.futures import ProcessPoolExecutor

from dbt.contracts.files import SchemaSourceFile
from dbt.parser.base import ConfiguredParser, FileBlock
from dbt.parser.common import GenericTestBlock
from dbt.parser.hooks import HookParser
from dbt.parser.manifest import ParserInfo
from dbt.parser.read_files import ParseFileType, load_source_file
from dbt.parser.schemas import ModelPatchParser, NodePatchParser, SchemaParser
from dbt.parser.snapshots import SnapshotParser
from dbt_run_cache_turbo import parse_cache
from hash_utils import dict_hash

try:
    from dbt.parser.schema_generic_tests import SchemaGenericTestParser
except ImportError:
    SchemaGenericTestParser = None  # type: ignore[assignment,misc]

if t.TYPE_CHECKING:
    from dbt.config import RuntimeConfig
    from dbt.contracts.graph.manifest import Manifest
    from dbt.parser.base import Parser
    from dbt.parser.manifest import ManifestLoader


# ---------------------------------------------------------------------------
# Globals and pool helpers
# ---------------------------------------------------------------------------

# Worker state — set in main process before fork so workers inherit it via COW.
# These must NOT be passed as pool.map arguments (RuntimeConfig can contain
# unpicklable closures like oauth_service_principal on Databricks).
_manifest: t.Optional[Manifest] = None
_project: t.Optional[RuntimeConfig] = None
_root_project: t.Optional[RuntimeConfig] = None

_CPU_COUNT = min(
    len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else os.cpu_count() or 1, 8
)

_HAS_FORK = "fork" in mp.get_all_start_methods()


def _max_workers() -> int:
    env = os.environ.get("RUN_CACHE_PARSE_WORKERS")
    return int(env) if env is not None else _CPU_COUNT


def _new_pool(max_workers: int = 0) -> ProcessPoolExecutor:
    """Create a fresh pool. Uses fork if available (faster, COW), otherwise spawn."""
    return ProcessPoolExecutor(
        max_workers=max_workers or _max_workers(),
        mp_context=mp.get_context("fork" if _HAS_FORK else "spawn"),
    )


def _noop(*_args: t.Any, **_kwargs: t.Any) -> None:
    pass


def _batch(items: t.List, n: int = 0) -> t.List[t.List]:
    n = n or _max_workers()
    size = max(1, len(items) // n)
    return [items[i : i + size] for i in range(0, len(items), size)]


class TestResult(t.NamedTuple):
    """Phase 2 → Phase 3 handoff.

    Only the fields below need to cross the process boundary — everything else
    (unique_id, file_id, config.enabled, etc.) is read from the pickled node
    directly on main, so we don't pay to load the pickle twice on warm runs.
    """

    cache_key: str
    yaml_key: str
    target_name: str


# Schema YAML keys that do NOT produce test blocks. Phase 2 test workers skip
# these since Phase 1a workers already handled them.
_SKIP_KEYS = frozenset(
    {
        "sources",
        "macros",
        "data_tests",
        "tests",  # dbt 1.7 name for data_tests
        "analyses",
        "exposures",
        "functions",
        "metrics",
        "groups",
        "semantic_models",
        "unit_tests",
        "saved_queries",
    }
)


# ---------------------------------------------------------------------------
# Top-level installer
# ---------------------------------------------------------------------------


def install_parallel_parse() -> None:
    """Install parallel parsing overrides on ManifestLoader.

    Requires fork-based multiprocessing so workers inherit manifest state
    via copy-on-write. On platforms without fork (Windows), only the async
    manifest write is installed.

    Note: dbt's read_files phase is left serial. A parallel version was tried
    and measurably slower on partial parses (dbt calls get_source_files once
    per project × parser type — lots of near-empty batches where fork +
    teardown dominates the actual file-read work).
    """
    install_async_manifest_write()

    if not _HAS_FORK or _max_workers() <= 1:
        return

    # Parallel parsing: monkey-patch ManifestLoader.parse_project
    from dbt.parser.manifest import ManifestLoader

    cached_target_path: t.Optional[str] = None
    cached_state_hash: t.Optional[str] = None

    def parse_project_override(
        self: ManifestLoader, project: t.Any, parser_files: dict, parser_types: list
    ) -> None:
        nonlocal cached_target_path, cached_state_hash

        # Lazily compute on first call (after macros are loaded).
        # These derive from root_project/manifest, not the per-project arg,
        # so they're the same across all calls.
        if cached_state_hash is None:
            cached_target_path = self.root_project.project_target_path
            os.makedirs(os.path.join(cached_target_path, "parse_cache"), exist_ok=True)

            # Single hash covering vars, profile, target, dbt version, project
            # configs, env vars (from state_check) plus all macro SQL content.
            sc = self.manifest.state_check
            cached_state_hash = parse_cache.key(
                sc.vars_hash.checksum,
                sc.profile_hash.checksum,
                sc.project_env_vars_hash.checksum,
                *sorted(f"{k}:{v.checksum}" for k, v in sc.project_hashes.items()),
                *sorted(f"{uid}:{m.macro_sql}" for uid, m in self.manifest.macros.items()),
            )

        parallel_parse_project(
            self,
            project,
            parser_files,
            parser_types,
            target_path=cached_target_path,
            state_hash=cached_state_hash,
        )

    ManifestLoader.parse_project = parse_project_override  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# parallel_parse_project — replaces ManifestLoader.parse_project
# ---------------------------------------------------------------------------


def parallel_parse_project(
    loader: ManifestLoader,
    project: RuntimeConfig,
    parser_files: dict,
    parser_types: t.List[t.Type[Parser]],
    target_path: str,
    state_hash: str,
) -> None:
    """Drop-in replacement for ManifestLoader.parse_project.

    Non-schema ConfiguredParser subclasses are dispatched to a worker pool.
    Schema files use four-phase processing (see _parse_schema_with_parallel_tests).
    """
    # Copied from dbt-core: ManifestLoader.parse_project setup
    manifest: Manifest = loader.manifest
    root_project = loader.root_project
    perf_info = loader._perf_info
    project_loader_info = perf_info._project_index[project.project_name]
    partially_parsing = loader.partially_parsing
    start_timer = time.perf_counter()
    total_parsed_path_count = 0

    # Copied from dbt-core: ManifestLoader.parse_project parser loop.
    # dbt-core runs all parsers serially; we dispatch SchemaParser and
    # ConfiguredParser subclasses to worker pools instead.
    for parser_cls in parser_types:
        parser_name = parser_cls.__name__
        if not (file_ids := parser_files.get(parser_name)):
            continue

        project_parsed_path_count = 0
        parser_start_timer = time.perf_counter()

        if issubclass(parser_cls, SchemaParser):
            # New: parallel test parsing (replaces serial SchemaParser loop)
            _parse_schema_with_parallel_tests(
                loader,
                project,
                manifest,
                root_project,
                file_ids,
                partially_parsing,
                target_path,
                state_hash,
            )
            project_parsed_path_count = len(file_ids)
        elif not issubclass(parser_cls, ConfiguredParser) or issubclass(parser_cls, SnapshotParser):
            # Copied from dbt-core: ManifestLoader.parse_project serial path.
            # Non-ConfiguredParser and SnapshotParser run serial.
            parser = parser_cls(project, manifest, root_project)
            for file_id in file_ids:
                block = FileBlock(manifest.files[file_id])
                parser.parse_file(block)
                project_parsed_path_count += 1
        else:
            # New: parallel node parsing (replaces serial ConfiguredParser loop)
            _parse_nodes_with_pool(
                manifest,
                project,
                root_project,
                parser_cls,
                file_ids,
                target_path=target_path,
                state_hash=state_hash,
            )
            project_parsed_path_count = len(file_ids)

        # Copied from dbt-core: ManifestLoader.parse_project ParserInfo tracking.
        # resource_type is a @property that returns a constant NodeType (e.g. NodeType.Model)
        # without using self, so fget(None) is safe to call without an instance.
        project_loader_info.parsers.append(
            ParserInfo(
                parser=parser_cls.resource_type.fget(None),  # type: ignore[attr-defined]
                parsed_path_count=project_parsed_path_count,
                elapsed=time.perf_counter() - parser_start_timer,
            )
        )
        total_parsed_path_count += project_parsed_path_count

    # Copied from dbt-core: ManifestLoader.parse_project HookParser handling
    if not partially_parsing and HookParser in parser_types:
        hook_parser = HookParser(project, manifest, root_project)
        path = hook_parser.get_path()
        file = load_source_file(path, ParseFileType.Hook, project.project_name, {})
        if file:
            file_block = FileBlock(file)
            hook_parser.parse_file(file_block)

    # Copied from dbt-core: ManifestLoader.parse_project perf tracking
    elapsed = time.perf_counter() - start_timer
    project_loader_info.parsed_path_count += total_parsed_path_count
    project_loader_info.elapsed += elapsed
    perf_info.parsed_path_count += total_parsed_path_count


# ---------------------------------------------------------------------------
# Node parsing helpers (models, seeds, analyses, etc.)
# ---------------------------------------------------------------------------


def _parse_nodes_with_pool(
    manifest: Manifest,
    project: RuntimeConfig,
    root_project: RuntimeConfig,
    parser_cls: t.Type[Parser],
    file_ids: t.List[str],
    target_path: str,
    state_hash: str,
) -> None:
    """Parse file_ids in parallel. Workers write nodes to disk cache;
    main process reads them back and merges into manifest."""
    global _manifest, _project, _root_project

    args = [(parser_cls, batch) for batch in _batch(file_ids)]

    # Set in main process so fork inherits state + patches.
    # RuntimeConfig is stored as a global (not passed via pool.map) because
    # it can contain unpicklable closures (e.g. Databricks oauth).
    _manifest = manifest
    _project = project
    _root_project = root_project
    install_fast_model_render(target_path, state_hash)

    # Always fork — running _parse_node_batch on main would invoke
    # dbt_extractor (Rust/rayon) in the main process and poison every
    # subsequent fork with inherited-but-missing rayon thread state.
    now = time.time()
    with _new_pool() as pool:
        for results in pool.map(_parse_node_batch, args):
            for file_id, model_name, cache_key in results:
                node = parse_cache.node.get(target_path, model_name, cache_key)
                if node is None:
                    raise RuntimeError(f"Cache miss after worker write: {model_name}")
                # Stamp created_at so ManifestLoader._process_refs populates
                # depends_on.nodes — it skips nodes with created_at older
                # than started_at, and the pickled node has a stale time.
                node.created_at = now
                source_file = manifest.files[file_id]
                if node.config.enabled:
                    manifest.add_node(source_file, node)
                else:
                    manifest.add_disabled(source_file, node)


def _parse_node_batch(
    args: t.Tuple[t.Type[Parser], t.List[str]],
) -> t.List[t.Tuple[str, str, str]]:
    """Worker: parse a batch of files. Nodes are written to disk via parse_cache.

    Returns (file_id, model_name, cache_key) tuples — main reads the pickled
    node once and pulls config.enabled etc. off the node directly, so we don't
    load the pickle twice on warm runs.
    """
    parser_cls, file_ids = args
    assert _manifest and _project and _root_project
    parser = parser_cls(_project, _manifest, _root_project)

    # dbt's default add_result_node would insert the node into the worker's
    # forked manifest — but main is the source of truth, so noop it.
    parser.add_result_node = _noop  # type: ignore[assignment]

    results: t.List[t.Tuple[str, str, str]] = []
    for file_id in file_ids:
        block = FileBlock(_manifest.files[file_id])
        try:
            parser.parse_file(block)
        except Exception:
            # Re-raise as RuntimeError with the full traceback string.
            # dbt exceptions (e.g. CaughtMacroErrorWithNodeError) often have
            # unpicklable __init__ signatures, so ProcessPoolExecutor can't
            # send them back to the main process — you'd just get a generic
            # BrokenProcessPool error with no context.
            raise RuntimeError(traceback.format_exc()) from None
        model_name, cache_key = _cache_info.get(file_id, ("", ""))
        results.append((file_id, model_name, cache_key))

    return results


def _model_cache_key(source_file: AnySourceFile, resource_type: str, state_hash: str) -> str:
    # file_id includes project prefix (e.g. "my_project://models/foo.sql"),
    # preventing collisions between packages with identical file paths.
    # resource_type prevents collisions when the same file is claimed by
    # multiple parsers (e.g. a file under both model-paths and test-paths).
    return parse_cache.key(
        source_file.checksum.checksum, source_file.file_id, resource_type, state_hash
    )


_orig_parse_node: t.Optional[t.Callable] = None

# Mapping from file_id to (model_name, cache_key), written by cached_parse_node
# and read by the capture callback in _parse_node_batch.
_cache_info: t.Dict[str, t.Tuple[str, str]] = {}


def install_fast_model_render(target_path: str, state_hash: str) -> None:
    """Install cache-aware parse_node on all ConfiguredParser subclasses.

    On cache hit, skip node creation, Jinja rendering, and config resolution.
    On cache miss, parse normally with full Jinja and write to cache.
    """
    global _orig_parse_node
    if _orig_parse_node is None:
        _orig_parse_node = ConfiguredParser.parse_node

    def cached_parse_node(self: ConfiguredParser, block: FileBlock) -> t.Any:
        source_file = block.file
        model_name = block.name
        key = _model_cache_key(source_file, self.resource_type.value, state_hash)

        _cache_info[source_file.file_id] = (model_name, key)

        # _parse_nodes_with_pool workers noop add_result_node (main adds to the
        # real manifest). In that case, skip loading the pickle here — main
        # loads it once in _parse_nodes_with_pool and pulls all the fields it
        # needs from the loaded node.
        if self.add_result_node is _noop and parse_cache.node.exists(target_path, model_name, key):
            return None

        if (cached_node := parse_cache.node.get(target_path, model_name, key)) is not None:
            # Stamp created_at = now so ManifestLoader._process_refs populates
            # depends_on.nodes — it skips anything whose created_at predates
            # this parse's started_at, and the pickled node was created in a
            # prior parse with stale time + empty depends_on.
            cached_node.created_at = time.time()
            self.add_result_node(block, cached_node)
            return cached_node

        node = _orig_parse_node(self, block)
        parse_cache.node.put(target_path, model_name, key, node)
        return node

    ConfiguredParser.parse_node = cached_parse_node  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Schema / generic test parsing helpers
# ---------------------------------------------------------------------------


def _run_unit_tests_serial(
    project: t.Any,
    manifest: Manifest,
    root_project: t.Any,
    file_ids: t.List[str],
    partially_parsing: bool,
) -> None:
    """Phase 1b: run UnitTestParser on schema files that have unit_tests keys.

    Kept serial because UnitTestParser reads manifest.source_lookup which is
    populated only after Phase 1a-apply merges every schema file's sources.
    """
    try:
        from dbt.parser.unit_tests import UnitTestParser
        from dbt.parser.schemas import YamlBlock
    except ImportError:
        return

    schema_parser = SchemaParser(project, manifest, root_project)
    for file_id in file_ids:
        sf = manifest.files[file_id]
        assert isinstance(sf, SchemaSourceFile)
        dct = sf.pp_dict if partially_parsing else sf.dict_from_yaml
        if not (dct and "unit_tests" in dct):
            continue
        block = FileBlock(sf)
        yaml_block = YamlBlock.from_file_block(block, {"unit_tests": dct["unit_tests"]})
        UnitTestParser(schema_parser, yaml_block).parse()


def _parse_schema_with_parallel_tests(
    loader: ManifestLoader,
    project: t.Any,
    manifest: Manifest,
    root_project: t.Any,
    file_ids: t.List[str],
    partially_parsing: bool,
    target_path: str,
    state_hash: str,
) -> None:
    """Parse schema files in four phases (1a/1b/2/3/4).

    Phase 1a (workers, parallel): Workers run SchemaParser.parse_file with
        unit_tests and generic tests noop'd — handles model/seed/snapshot
        patches, sources, exposures, metrics, groups, semantic_models,
        saved_queries, functions, disabled entries, and macro patches. Each
        worker writes one pickle per schema file to target/schema_cache/.
    Phase 1a-apply (main, serial): Read payloads back and apply to the real
        manifest in filesystem_search order; manifest.add_* populates
        source_lookup / ref_lookup / disabled_lookup.
    Phase 1b (main, serial): Run UnitTestParser on files with unit_tests —
        kept serial because it reads source_lookup built across all files.
    Phase 2 (workers, parallel): Workers parse generic tests with patches
        and sources noop'd.
    Phase 3 (main, serial): Read test nodes from disk, add to manifest.
    Phase 4 (main, serial): Fix up attached_node references.
    """
    global _manifest, _project, _root_project

    os.makedirs(os.path.join(target_path, "test_cache"), exist_ok=True)

    # Phase 1a: parallel schema file parsing (patches, sources, exposures,
    # metrics, groups, semantic_models, saved_queries, functions, disabled,
    # macro patches). Generic tests and unit_tests are deferred.
    _manifest = manifest
    _project = project
    _root_project = root_project

    os.makedirs(os.path.join(target_path, "schema_cache"), exist_ok=True)

    phase1a_args = [
        (batch, partially_parsing, target_path, state_hash) for batch in _batch(file_ids)
    ]
    # Always fork — running the worker on main would invoke dbt_extractor
    # (Rust/rayon) in the main process and poison every subsequent fork with
    # inherited-but-missing rayon thread state.
    phase1a_results: t.List[t.Tuple[str, str]] = []
    with _new_pool() as pool:
        for batch_results in pool.map(_parse_schema_phase1_batch, phase1a_args):
            phase1a_results.extend(batch_results)

    # Phase 1a-apply: replay payloads onto real manifest in filesystem_search
    # order. The order of phase1a_results follows the input batch order, which
    # follows file_ids, which follows filesystem_search — matches the old
    # serial Phase 1 behavior exactly.

    files_needing_unit_tests: t.List[str] = []
    for file_id, cache_key in phase1a_results:
        payload = parse_cache.schema.get(target_path, cache_key)
        if payload is None:
            raise RuntimeError(f"Schema cache miss after worker write: {file_id}")
        _apply_schema_file_payload(manifest, payload)
        if payload.get("has_unit_tests"):
            files_needing_unit_tests.append(file_id)

    # Phase 1b: serial unit_test parsing on main. At this point all sources
    # from every schema file are in manifest + source_lookup, so UnitTestParser
    # can resolve cross-file source refs correctly.
    if files_needing_unit_tests:
        _run_unit_tests_serial(
            project, manifest, root_project, files_needing_unit_tests, partially_parsing
        )

    # Phase 2: parallel test parsing
    _manifest = manifest
    _project = project
    _root_project = root_project

    args = [(batch, partially_parsing, target_path, state_hash) for batch in _batch(file_ids)]

    # Always fork — same reason as Phase 1a above.
    all_results: t.List[TestResult] = []
    with _new_pool() as pool:
        for results in pool.map(_parse_schema_tests_batch, args):
            all_results.extend(results)

    # Phase 3: read test nodes from disk → add to manifest.
    # Stamp created_at = now on every test node so ManifestLoader._process_refs
    # populates depends_on.nodes — it skips anything whose created_at predates
    # this parse's started_at, and cache-hit replay would otherwise feed it
    # stale pickled tests whose depends_on.nodes is still empty.
    test_nodes = []
    now = time.time()
    for cache_key, yaml_key, target_name in all_results:
        node = parse_cache.test.get(target_path, cache_key)
        if node is None:
            raise RuntimeError(f"Failed to read test node from cache: {cache_key}")

        source_file = manifest.files.get(node.file_id)
        if source_file is None:
            raise RuntimeError(f"Cannot find source file for test node: {node.unique_id}")

        node.created_at = now
        test_from = {"key": yaml_key, "name": target_name}
        if node.config.enabled:
            manifest.add_node(source_file, node, test_from)
        else:
            manifest.add_disabled(source_file, node, test_from)
        test_nodes.append(node)

    # Phase 4: fix up attached_node — workers had a snapshot of manifest at fork.
    # Adapted from the attached_node logic in SchemaGenericTestParser.render_test_update,
    # but re-done here because workers had a stale manifest.
    # RefArgs is a dataclass with .name, .package, .version.
    for node in test_nodes:
        if node.attached_node:
            continue
        for ref in node.refs:
            attached_id = manifest.ref_lookup.get_unique_id(ref.name, ref.package, ref.version)
            if attached_id and attached_id in manifest.nodes:
                node.attached_node = attached_id
                node.group = manifest.nodes[attached_id].group
                break


def _parse_schema_tests_batch(
    args: t.Tuple[t.List[str], bool, str, str],
) -> t.List[TestResult]:
    """Worker: parse schema files for generic tests, write test nodes to disk.

    Patches and sources are NOT applied here — they were already handled in
    Phase 1a. Workers only extract test blocks and parse generic tests.

    Returns (unique_id, cache_key, enabled, file_id, yaml_key, target_name) tuples.
    """
    file_ids, partially_parsing, target_path, state_hash = args
    assert _manifest and _project and _root_project

    parser = SchemaParser(_project, _manifest, _root_project)

    results: t.List[TestResult] = []

    # dbt 1.7 uses "test" for the field/kwarg; 1.8+ uses "data_test".
    field_names = {f.name for f in dataclasses.fields(GenericTestBlock)}
    test_field = "data_test" if "data_test" in field_names else "test"

    def cached_parse_node(self: t.Any, block: GenericTestBlock) -> t.Any:
        """Replacement for SchemaGenericTestParser.parse_node that adds disk caching.

        Adapted from the call to SchemaGenericTestParser.parse_generic_test
        but wraps it with cache lookup/write.
        """
        source_file = block.file
        test_def = getattr(block, test_field)
        yaml_key = block.target.yaml_key
        target_name = block.target.name
        cache_key = _test_cache_key(
            source_file.checksum.checksum,
            target_name,
            test_def,
            block.column_name or "",
            state_hash,
        )

        # Cache hit — record the key and bail; main loads the pickle once
        # in Phase 3. Loading here would just duplicate that work.
        if parse_cache.test.exists(target_path, cache_key):
            results.append(TestResult(cache_key, yaml_key, target_name))
            return None

        # Cache miss — parse and pickle for the next run.
        node = self.parse_generic_test(
            target=block.target,
            **{test_field: test_def},
            tags=block.tags,
            column_name=block.column_name,
            schema_file_id=block.file.file_id,
            version=block.version,
        )
        parse_cache.test.put(target_path, cache_key, node)
        results.append(TestResult(cache_key, yaml_key, target_name))
        return node

    # Save originals before patching so we can restore — this function may run
    # on the main process and must not leave permanent patches.
    orig_gen_parse_node = SchemaGenericTestParser.parse_node  # type: ignore[attr-defined]
    orig_node_patch = NodePatchParser.parse_patch
    orig_model_patch = ModelPatchParser.parse_patch
    orig_add_yaml_snapshots = getattr(SchemaParser, "_add_yaml_snapshot_nodes_to_manifest", None)

    # Workers only parse generic tests. All other schema work (patches, sources,
    # exposures, groups, metrics, etc.) was handled in Phase 1a. We filter dct
    # to only test-producing keys (models/seeds/snapshots) and noop parse_patch
    # so the PatchParser.parse() loop still extracts test blocks but doesn't
    # apply patches. _add_yaml_snapshot_nodes_to_manifest is also noop'd since
    # snapshot nodes were already added in Phase 1a.
    SchemaGenericTestParser.parse_node = cached_parse_node  # type: ignore[assignment]
    # Noop the 2 classes that define their own parse_patch. Other patch parsers
    # (TestablePatchParser, AnalysisPatchParser, FunctionPatchParser) inherit
    # from NodePatchParser so they're covered by that noop.
    NodePatchParser.parse_patch = _noop  # type: ignore[assignment]
    ModelPatchParser.parse_patch = _noop  # type: ignore[assignment]
    # _add_yaml_snapshot_nodes_to_manifest only exists in dbt 1.11+
    if orig_add_yaml_snapshots is not None:
        SchemaParser._add_yaml_snapshot_nodes_to_manifest = lambda self, *a, **kw: None  # type: ignore[assignment]

    try:
        for file_id in file_ids:
            block = FileBlock(_manifest.files[file_id])
            assert isinstance(block.file, SchemaSourceFile)
            full_dct = block.file.pp_dict if partially_parsing else block.file.dict_from_yaml
            dct = {k: v for k, v in full_dct.items() if k not in _SKIP_KEYS} if full_dct else None
            if dct:
                try:
                    parser.parse_file(block, dct=dct)
                except Exception:
                    raise RuntimeError(traceback.format_exc()) from None
    finally:
        SchemaGenericTestParser.parse_node = orig_gen_parse_node  # type: ignore[assignment]
        NodePatchParser.parse_patch = orig_node_patch
        ModelPatchParser.parse_patch = orig_model_patch
        if orig_add_yaml_snapshots is not None:
            SchemaParser._add_yaml_snapshot_nodes_to_manifest = orig_add_yaml_snapshots  # type: ignore[assignment]

    return results


def _test_cache_key(
    file_checksum: str,
    target_name: str,
    test_def: t.Dict[str, t.Any],  # raw YAML test definition, e.g. {"not_null": {}}
    column_name: str,
    state_hash: str,
) -> str:
    test_identity = str(dict_hash(test_def))
    return parse_cache.key(file_checksum, target_name, test_identity, column_name, state_hash)


# ---------------------------------------------------------------------------
# Parallel Phase 1a — schema file parsing (patches, sources, exposures, ...)
# ---------------------------------------------------------------------------


def _capture_schema_file_payload(
    manifest: "Manifest", source_file: SchemaSourceFile
) -> t.Dict[str, t.Any]:
    """Walk SchemaSourceFile tracking fields and collect the manifest objects
    each refers to. Returned dict is the payload written to schema_cache.

    Several tracking fields were added in newer dbt versions (e.g. snapshots,
    saved_queries, semantic_models, unit_tests, functions, generated_metrics) —
    every access uses getattr with a [] default for dbt 1.7/1.8 compatibility.
    """

    def _collect(uids: t.Iterable[str], collection: t.Mapping[str, t.Any]) -> t.Dict[str, t.Any]:
        return {uid: collection[uid] for uid in uids if uid in collection}

    def _field(name: str) -> t.List[str]:
        return list(getattr(source_file, name, None) or [])

    metric_uids = _field("metrics") + _field("generated_metrics")
    snapshot_uids = _field("snapshots")

    # disabled: manifest.disabled is Dict[unique_id, List[Node]]. Ship the
    # whole list for every unique_id that belongs to this schema file — the
    # worker's fork reflects the authoritative post-parse state for these uids
    # (pre-existing entries plus any newly-disabled ones parse_file added).
    disabled_uids = (
        set(_field("ndp"))
        | set(_field("sources"))
        | set(snapshot_uids)
        | set(_field("exposures"))
        | set(metric_uids)
        | set(_field("saved_queries"))
        | set(_field("semantic_models"))
        | set(_field("unit_tests"))
        | set(_field("groups"))
        | set(_field("functions"))
    )
    disabled: t.Dict[str, t.List[t.Any]] = {
        uid: list(manifest.disabled[uid]) for uid in disabled_uids if uid in manifest.disabled
    }

    yaml_dct = source_file.pp_dict or source_file.dfy or {}

    mcp = getattr(source_file, "mcp", None)
    macro_patch_uids = list(mcp.values()) if isinstance(mcp, dict) else []

    def _coll(name: str) -> t.Mapping[str, t.Any]:
        return getattr(manifest, name, None) or {}

    return {
        "source_file": source_file,
        "nodes": _collect(_field("ndp") + snapshot_uids, _coll("nodes")),
        "sources": _collect(_field("sources"), _coll("sources")),
        "exposures": _collect(_field("exposures"), _coll("exposures")),
        "metrics": _collect(metric_uids, _coll("metrics")),
        "groups": _collect(_field("groups"), _coll("groups")),
        "semantic_models": _collect(_field("semantic_models"), _coll("semantic_models")),
        "saved_queries": _collect(_field("saved_queries"), _coll("saved_queries")),
        "functions": _collect(_field("functions"), _coll("functions")),
        "disabled": disabled,
        # mcp maps patch_name -> unique_id; we need unique_ids to look up macros.
        "macro_patches": _collect(macro_patch_uids, _coll("macros")),
        "has_unit_tests": isinstance(yaml_dct, dict) and "unit_tests" in yaml_dct,
    }


def _apply_schema_file_payload(manifest: "Manifest", payload: t.Dict[str, t.Any]) -> None:
    """Replay a captured schema-file payload onto a real manifest.

    Direct-assigns into manifest.{nodes, sources, exposures, ...} rather than
    calling manifest.add_* — the worker already ran add_* on its forked
    manifest (so the pickled source_file's tracking lists already contain the
    uids), and calling add_* again on main would re-append them, producing
    duplicates that break PartialParsing.remove_tests and friends. Lookup
    caches (_source_lookup, _disabled_lookup, etc.) are invalidated at the
    end so they rebuild lazily on next access.

    Stamps created_at = now on every applied object so ManifestLoader
    .process_docs and _process_refs re-run — both skip anything whose
    created_at predates this parse's started_at, and cache-hit replay would
    otherwise feed them stale pickled objects.
    """
    sf: SchemaSourceFile = payload["source_file"]
    manifest.files[sf.file_id] = sf
    now = time.time()

    def _stamp_and_merge(collection_name: str, items: t.Dict[str, t.Any]) -> None:
        coll = getattr(manifest, collection_name, None)
        if coll is None or not items:
            return
        for obj in items.values():
            obj.created_at = now
        coll.update(items)

    _stamp_and_merge("nodes", payload["nodes"])
    _stamp_and_merge("macros", payload["macro_patches"])
    _stamp_and_merge("sources", payload["sources"])
    _stamp_and_merge("exposures", payload["exposures"])
    _stamp_and_merge("metrics", payload["metrics"])
    _stamp_and_merge("groups", payload["groups"])
    _stamp_and_merge("semantic_models", payload["semantic_models"])
    _stamp_and_merge("saved_queries", payload["saved_queries"])
    _stamp_and_merge("functions", payload["functions"])

    # Disabled: REPLACE manifest.disabled[uid] with the worker's list. The
    # worker's fork had the pre-parse state for each uid and parse_file
    # mutated it in place, so the worker's list is the authoritative
    # post-parse state for those uids.
    if payload["disabled"]:
        for uid, nodes in payload["disabled"].items():
            for n in nodes:
                n.created_at = now
            manifest.disabled[uid] = nodes

    # Invalidate cached lookups so they rebuild from the updated collections.
    for attr in (
        "_source_lookup",
        "_ref_lookup",
        "_disabled_lookup",
        "_analysis_lookup",
        "_singular_test_lookup",
        "_semantic_model_by_measure_lookup",
        "_function_lookup",
    ):
        if hasattr(manifest, attr):
            setattr(manifest, attr, None)


def _parse_schema_phase1_batch(
    args: t.Tuple[t.List[str], bool, str, str],
) -> t.List[t.Tuple[str, str]]:
    """Worker: parse a batch of schema files. For each file, either hit the
    cache (return key) or run SchemaParser.parse_file with unit_tests and
    generic tests noop'd, then pickle the payload. Returns (file_id, cache_key).
    """
    file_ids, partially_parsing, target_path, state_hash = args
    assert _manifest and _project and _root_project

    # Save originals before patching so we can restore — this function may run
    # on the main process and must not leave permanent patches.
    orig_gen_parse_node = SchemaGenericTestParser.parse_node  # type: ignore[attr-defined]
    try:
        from dbt.parser.unit_tests import UnitTestParser

        orig_ut_parse: t.Optional[t.Callable] = UnitTestParser.parse
    except ImportError:
        UnitTestParser = None  # type: ignore[assignment,misc]
        orig_ut_parse = None

    # Noop generic tests (Phase 2) and unit_tests (Phase 1b).
    SchemaGenericTestParser.parse_node = _noop  # type: ignore[assignment]
    if UnitTestParser is not None:
        UnitTestParser.parse = _noop  # type: ignore[assignment]

    parser = SchemaParser(_project, _manifest, _root_project)
    results: t.List[t.Tuple[str, str]] = []

    try:
        for file_id in file_ids:
            source_file = _manifest.files[file_id]
            assert isinstance(source_file, SchemaSourceFile)

            cache_key = parse_cache.key(
                source_file.checksum.checksum, source_file.file_id, state_hash
            )

            # Cache hit — record the key and bail; main will pickle.load it
            # once in Phase 1a-apply. Loading it here would just duplicate
            # that work.
            if parse_cache.schema.exists(target_path, cache_key):
                results.append((file_id, cache_key))
                continue

            block = FileBlock(source_file)
            dct = source_file.pp_dict if partially_parsing else source_file.dict_from_yaml
            try:
                parser.parse_file(block, dct=dct)
            except Exception:
                raise RuntimeError(traceback.format_exc()) from None

            payload = _capture_schema_file_payload(_manifest, source_file)
            parse_cache.schema.put(target_path, cache_key, payload)
            results.append((file_id, cache_key))
    finally:
        SchemaGenericTestParser.parse_node = orig_gen_parse_node  # type: ignore[assignment]
        if UnitTestParser is not None and orig_ut_parse is not None:
            UnitTestParser.parse = orig_ut_parse  # type: ignore[assignment]

    return results


# ---------------------------------------------------------------------------
# Async manifest rewrite — fire-and-forget background process
# ---------------------------------------------------------------------------


def _write_manifest_worker(target_path: str) -> None:
    """Read partial parse, build maps, write manifest.json + semantic_manifest.json.

    Adapted from dbt-core: write_manifest but reads from the serialized
    partial_parse.msgpack on disk instead of the in-memory manifest.

    Writes to temporary files first, then atomically renames them so that
    concurrent readers never see a truncated manifest.
    """
    import dbt.parser.manifest as pm

    from dbt.contracts.graph.manifest import Manifest

    msgpack_path = os.path.join(target_path, pm.PARTIAL_PARSE_FILE_NAME)
    with open(msgpack_path, "rb") as f:
        manifest = Manifest.from_msgpack(f.read())

    manifest.build_parent_and_child_maps()

    writable = manifest.writable_manifest()
    manifest_path = os.path.join(target_path, pm.MANIFEST_FILE_NAME)
    tmp_manifest_path = manifest_path + ".tmp"
    writable.write(tmp_manifest_path)
    os.replace(tmp_manifest_path, manifest_path)

    from dbt.contracts.graph.semantic_manifest import SemanticManifest

    semantic_path = os.path.join(target_path, pm.SEMANTIC_MANIFEST_FILE_NAME)
    tmp_semantic_path = semantic_path + ".tmp"
    SemanticManifest(manifest).write_json_to_file(tmp_semantic_path)
    os.replace(tmp_semantic_path, semantic_path)


def install_async_manifest_write() -> None:
    """Monkey-patch write_manifest to run in a fire-and-forget background process."""
    import dbt.parser.manifest as pm

    orig_write_manifest = pm.write_manifest

    def async_write_manifest(manifest: object, target_path: str, which: object = None) -> None:
        if _max_workers() == 0:
            return orig_write_manifest(manifest, target_path, which)
        pool = _new_pool(max_workers=1)
        pool.submit(_write_manifest_worker, target_path)
        manifest_path = os.path.join(target_path, pm.MANIFEST_FILE_NAME)
        # add_artifact_produced and ArtifactWritten only exist in dbt 1.11+
        if hasattr(pm, "add_artifact_produced"):
            pm.add_artifact_produced(manifest_path)
        if hasattr(pm, "ArtifactWritten"):
            pm.fire_event(
                pm.ArtifactWritten(artifact_type="WritableManifest", artifact_path=manifest_path)
            )

    pm.write_manifest = async_write_manifest
