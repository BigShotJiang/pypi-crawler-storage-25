"""Lazy macro namespace — avoid allocating MacroGenerators for every macro per node.

dbt's default ManifestContext._build_namespace allocates a MacroGenerator for
every macro in scope on every node compile. This module replaces the namespace
with a lazy Mapping that materializes MacroGenerators only on first access,
plus a Jinja Context subclass that falls through to the namespace so macros
don't need to be expanded into the template's variable dict.
"""

from __future__ import annotations

import functools
import typing as t
from collections.abc import Iterator, Mapping

from jinja2.runtime import Context, missing

from dbt.adapters.factory import get_adapter_package_names
from dbt.clients.jinja import MacroGenerator, MacroStack
from dbt.context.base import BaseContext
from dbt.context.macro_resolver import TestMacroNamespace
from dbt.context.manifest import ManifestContext
from dbt.exceptions import DuplicateMacroNameError, PackageNotFoundForMacroError
from dbt.include.global_project import PROJECT_NAME as GLOBAL_PROJECT_NAME

try:
    from dbt_common.clients.jinja import MacroFuzzEnvironment, NativeSandboxEnvironment
except ImportError:
    # dbt < 1.8 — environments live in dbt.clients.jinja; may be absent entirely.
    import dbt.clients.jinja as _jinja_mod

    MacroFuzzEnvironment = getattr(_jinja_mod, "MacroFuzzEnvironment", None)  # type: ignore[assignment]
    NativeSandboxEnvironment = getattr(_jinja_mod, "NativeSandboxEnvironment", None)  # type: ignore[assignment]

if t.TYPE_CHECKING:
    from dbt.contracts.graph.nodes import Macro

MACRO_NAMESPACE_KEY = "__macro_namespace__"
MacroFlatNamespace = t.Dict[str, "Macro"]


class NamespaceFallbackContext(Context):
    def resolve_or_missing(self, key: str) -> t.Any:
        rv = super().resolve_or_missing(key)
        if rv is missing:
            ns = self.parent.get(MACRO_NAMESPACE_KEY)
            if ns is not None:
                try:
                    return ns[key]
                except KeyError:
                    pass
        return rv


class MacroNamespaceTemplate:
    """Shared namespace structure — one per (project, search_package, adapter)."""

    __slots__ = (
        "global_namespace",
        "local_namespace",
        "global_project_namespace",
        "packages",
        "all_keys",
    )

    def __init__(
        self,
        global_namespace: MacroFlatNamespace,
        local_namespace: MacroFlatNamespace,
        global_project_namespace: MacroFlatNamespace,
        packages: t.Dict[str, MacroFlatNamespace],
    ):
        self.global_namespace = global_namespace
        self.local_namespace = local_namespace
        self.global_project_namespace = global_project_namespace
        self.packages = packages
        self.all_keys: t.Set[str] = {GLOBAL_PROJECT_NAME}
        self.all_keys.update(local_namespace)
        self.all_keys.update(global_namespace)
        self.all_keys.update(packages)
        self.all_keys.update(global_project_namespace)


class LazyMacroNamespace(Mapping):
    """Per-context Mapping that lazily wraps Macro objects in MacroGenerator."""

    def __init__(
        self,
        template: MacroNamespaceTemplate,
        ctx: t.Dict[str, t.Any],
        node: t.Optional[t.Any],
        thread_ctx: MacroStack,
    ):
        self.template = template
        self.ctx = ctx
        self.node = node
        self.thread_ctx = thread_ctx
        self._macro_cache: t.Dict[str, MacroGenerator] = {}
        self._package_cache: t.Dict[str, t.Dict[str, MacroGenerator]] = {}

    def _make(self, macro: "Macro") -> MacroGenerator:
        return MacroGenerator(macro, self.ctx, self.node, self.thread_ctx)

    def _get_macro(self, key: str, macro: "Macro") -> MacroGenerator:
        gen = self._macro_cache.get(key)
        if gen is None:
            gen = self._make(macro)
            self._macro_cache[key] = gen
        return gen

    def _get_package(self, key: str, macros: MacroFlatNamespace) -> t.Dict[str, MacroGenerator]:
        cached = self._package_cache.get(key)
        if cached is None:
            cached = {name: self._make(macro) for name, macro in macros.items()}
            self._package_cache[key] = cached
        return cached

    def __getitem__(self, key: str) -> t.Any:
        gen = self._macro_cache.get(key)
        if gen is not None:
            return gen
        pkg_cached = self._package_cache.get(key)
        if pkg_cached is not None:
            return pkg_cached
        tmpl = self.template
        macro = tmpl.local_namespace.get(key) or tmpl.global_namespace.get(key)
        if macro is not None:
            return self._get_macro(key, macro)
        pkg = tmpl.packages.get(key)
        if pkg is not None:
            return self._get_package(key, pkg)
        if key == GLOBAL_PROJECT_NAME:
            return self._get_package(GLOBAL_PROJECT_NAME, tmpl.global_project_namespace)
        macro = tmpl.global_project_namespace.get(key)
        if macro is not None:
            return self._get_macro(key, macro)
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        return iter(self.template.all_keys)

    def __len__(self) -> int:
        return len(self.template.all_keys)

    def __contains__(self, key: object) -> bool:
        return key in self.template.all_keys

    def get_from_package(
        self, package_name: t.Optional[str], name: str
    ) -> t.Optional[MacroGenerator]:
        # Required by dbt.context.providers.BaseMacroResolver.dispatch.
        if package_name is None:
            return self.get(name)
        if package_name == GLOBAL_PROJECT_NAME:
            macro = self.template.global_project_namespace.get(name)
        elif package_name in self.template.packages:
            macro = self.template.packages[package_name].get(name)
        else:
            raise PackageNotFoundForMacroError(package_name)
        if macro is None:
            return None
        return self._get_macro(f"{package_name}.{name}", macro)

    def expand_collisions_into(self, dct: dict) -> None:
        """Materialize macros whose names collide with existing context keys."""
        tmpl = self.template
        for ns in (tmpl.global_namespace, tmpl.local_namespace):
            for name, macro in ns.items():
                if name in dct:
                    dct[name] = self._get_macro(name, macro)


class NamespaceFallbackDict(dict):
    """Dict that falls through to LazyMacroNamespace for missing keys.

    Needed because dbt materialization macros do ``context[package_name]`` via
    dict __getitem__, which bypasses Jinja's resolve_or_missing.
    """

    __slots__ = ("_namespace",)

    def __init__(self, base: dict, namespace: LazyMacroNamespace):
        super().__init__(base)
        self._namespace = namespace

    def __missing__(self, key: str) -> t.Any:
        return self._namespace[key]

    def __contains__(self, key: object) -> bool:
        return super().__contains__(key) or key in self._namespace

    def get(self, key: str, default: t.Any = None) -> t.Any:
        try:
            return self[key]
        except KeyError:
            return default


def get_macros_by_package(manifest: t.Any) -> t.Dict[str, t.Dict[str, "Macro"]]:
    """Shim for dbt < 1.9, which lacks Manifest.get_macros_by_package()."""
    if hasattr(manifest, "get_macros_by_package"):
        return manifest.get_macros_by_package()
    result: t.Dict[str, t.Dict[str, "Macro"]] = {}
    for macro in manifest.macros.values():
        result.setdefault(macro.package_name, {})[macro.name] = macro
    return result


@functools.lru_cache
def _adapter_packages(credentials_type: str) -> t.Tuple[str, ...]:
    return tuple(get_adapter_package_names(credentials_type))


def build_namespace_template(
    root_package: str,
    search_package: str,
    internal_packages: t.Sequence[str],
    macros_by_package: t.Dict[str, t.Dict[str, "Macro"]],
) -> MacroNamespaceTemplate:
    internal_set = set(internal_packages)
    global_ns: MacroFlatNamespace = {}
    local_ns: MacroFlatNamespace = {}
    internal_pkgs: t.Dict[str, MacroFlatNamespace] = {}
    packages: t.Dict[str, MacroFlatNamespace] = {}

    for pkg_macros in macros_by_package.values():
        for macro in pkg_macros.values():
            pkg = macro.package_name
            name = macro.name
            is_internal = pkg in internal_set
            pkg_dict = (internal_pkgs if is_internal else packages).setdefault(pkg, {})
            if name in pkg_dict:
                raise DuplicateMacroNameError(pkg_dict[name], macro, pkg)
            pkg_dict[name] = macro

            if not is_internal:
                if pkg == search_package:
                    local_ns[name] = macro
                elif pkg == root_package:
                    global_ns[name] = macro

    global_project_ns: MacroFlatNamespace = {}
    for pkg in reversed(internal_packages):
        if pkg in internal_pkgs:
            global_project_ns.update(internal_pkgs[pkg])

    return MacroNamespaceTemplate(
        global_namespace=global_ns,
        local_namespace=local_ns,
        global_project_namespace=global_project_ns,
        packages=packages,
    )


def get_or_build_template(ctx: t.Any) -> MacroNamespaceTemplate:
    internal_packages = _adapter_packages(ctx.config.credentials.type)
    cache_key = (ctx.config.project_name, ctx.search_package, internal_packages)

    cache = getattr(ctx.manifest, "_namespace_template_cache", None)
    if cache is None:
        cache = {}
        ctx.manifest._namespace_template_cache = cache  # type: ignore[attr-defined]

    template = cache.get(cache_key)
    if template is None:
        template = build_namespace_template(
            root_package=ctx.config.project_name,
            search_package=ctx.search_package,
            internal_packages=internal_packages,
            macros_by_package=get_macros_by_package(ctx.manifest),
        )
        cache[cache_key] = template
    return template


def install_lazy_macros() -> None:
    """Monkey-patch dbt-core to use lazy macro namespace resolution."""
    if getattr(ManifestContext, "_lazy_macros_installed", False):
        return
    ManifestContext._lazy_macros_installed = True  # type: ignore[attr-defined]

    if MacroFuzzEnvironment is not None:
        MacroFuzzEnvironment.context_class = NamespaceFallbackContext  # type: ignore[assignment]
    if NativeSandboxEnvironment is not None:
        NativeSandboxEnvironment.context_class = NamespaceFallbackContext  # type: ignore[assignment]

    def patched_build_namespace(self: t.Any) -> LazyMacroNamespace:
        template = get_or_build_template(self)
        # self.model exists on ProviderContext but not ManifestContext.
        node = getattr(self, "model", None)
        return LazyMacroNamespace(template, self._ctx, node, self.macro_stack)

    def patched_to_dict(self: t.Any) -> dict:
        dct = BaseContext.to_dict(self)
        ns = self.namespace
        if isinstance(ns, TestMacroNamespace):
            dct.update(ns.local_namespace)
            dct.update(ns.project_namespace)
        elif isinstance(ns, LazyMacroNamespace):
            dct[MACRO_NAMESPACE_KEY] = ns
            ns.expand_collisions_into(dct)
            dct["context"] = NamespaceFallbackDict(dct, ns)
        else:
            dct.update(ns)
        return dct

    ManifestContext._build_namespace = patched_build_namespace  # type: ignore[assignment]
    ManifestContext.to_dict = patched_to_dict  # type: ignore[assignment]
