"""Skip duplicate jsonschema validations using shape_hash.

Monkey-patches dbtClassMixin.validate and jsonschema_validate to skip
jsonschema when a dict with the same structural shape has already been
validated for that class/schema.

jsonschema validates structure (required keys, value types) not string
content, so dicts with the same "shape" always produce the same result.
This collapses ~56K validate calls to ~50 unique shapes.
"""

from __future__ import annotations

from hash_utils import shape_hash


def install_validation_cache() -> None:
    """Monkey-patch dbtClassMixin.validate and jsonschema_validate to skip duplicates."""
    try:
        from dbt_common.dataclass_schema import dbtClassMixin
    except ImportError:
        try:
            from dbt.dataclass_schema import dbtClassMixin  # type: ignore[no-redef]  # dbt 1.7
        except ImportError:
            return

    _orig_validate = dbtClassMixin.validate.__func__
    _seen: set[tuple[type, int]] = set()

    def _cached_validate(cls: type, data: object) -> None:
        if isinstance(data, dict):
            key = (cls, shape_hash(data))
            if key in _seen:
                return
            _orig_validate(cls, data)
            _seen.add(key)
        else:
            _orig_validate(cls, data)

    dbtClassMixin.validate = classmethod(_cached_validate)  # type: ignore[assignment]

    # Also cache jsonschema_validate, called during read_files for every YAML
    # schema file. It validates the raw dict against dbt's resources_schema()
    # to emit deprecation warnings. Same shape → same validation result.
    try:
        from dbt.jsonschemas.jsonschemas import jsonschema_validate as _orig_jv
        import dbt.jsonschemas.jsonschemas as _jv_mod
    except ImportError:
        return

    _seen_jv: set[int] = set()

    def _cached_jv(schema: object, json: object, file_path: str) -> None:
        if isinstance(json, dict):
            h = shape_hash(json)
            if h in _seen_jv:
                return
            _orig_jv(schema, json, file_path)
            _seen_jv.add(h)
        else:
            _orig_jv(schema, json, file_path)

    _jv_mod.jsonschema_validate = _cached_jv  # type: ignore[assignment]
