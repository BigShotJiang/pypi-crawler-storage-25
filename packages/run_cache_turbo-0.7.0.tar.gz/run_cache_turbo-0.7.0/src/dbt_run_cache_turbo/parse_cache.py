"""File-based pickle caches used by turbo's parsing hot paths.

Three namespaces:

* ``parse_cache.node`` — one entry per manifest node (model, seed, snapshot,
  analysis, singular test). Hit rate skips ``ConfiguredParser.parse_node`` —
  no Jinja render, no config resolution. Entries live at
  ``target/parse_cache/<model_name>__<cache_key>.pkl``.

* ``parse_cache.schema`` — one entry per schema YAML file, holding the full
  Phase 1a payload (patched nodes, sources, exposures, metrics, …). Hit
  rate skips the entire Phase 1a worker. Entries live at
  ``target/schema_cache/<cache_key>.pkl``.

* ``parse_cache.test`` — one entry per generic test node (Phase 2). Hit rate
  skips Jinja rendering of the test template. Entries live at
  ``target/test_cache/<cache_key>.pkl``.

All namespaces share the same fnv64 key function and the same pickle
read/write primitives; they differ only in the on-disk path layout.
"""

from __future__ import annotations

import os
import pickle
import typing as t

from hash_utils import fnv64

if t.TYPE_CHECKING:
    from dbt.contracts.graph.nodes import ManifestNode


def key(*parts: str) -> str:
    """FNV-1a 64-bit hash of the '|'-joined parts, as unsigned hex.

    The mask is needed because Python's int is signed arbitrary-precision,
    so a raw hex of fnv64() can start with '-' for negative values.
    """
    return f"{fnv64('|'.join(parts).encode()) & 0xFFFFFFFFFFFFFFFF:x}"


def _read(path: str) -> t.Optional[t.Any]:
    try:
        with open(path, "rb") as f:
            return pickle.load(f)  # noqa: S301
    except FileNotFoundError:
        return None
    except Exception:
        # Corrupt pickle — remove so a subsequent put can rewrite it.
        try:
            os.unlink(path)
        except OSError:
            pass
        return None


def _write(path: str, value: t.Any) -> None:
    try:
        with open(path, "wb") as f:
            pickle.dump(value, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        pass


class node:
    """Per-node cache: target/parse_cache/<model_name>__<cache_key>.pkl."""

    @staticmethod
    def _path(target_path: str, model_name: str, cache_key: str) -> str:
        # Clip model_name to 150 chars to stay well under typical filename limits.
        return os.path.join(target_path, "parse_cache", f"{model_name[:150]}__{cache_key}.pkl")

    @staticmethod
    def exists(target_path: str, model_name: str, cache_key: str) -> bool:
        """Probe for a cache entry without loading it.

        Use this when the caller only needs to know a hit occurred — e.g.
        when main will load the pickle itself later and the worker just
        needs to short-circuit.
        """
        return os.path.exists(node._path(target_path, model_name, cache_key))

    @staticmethod
    def get(target_path: str, model_name: str, cache_key: str) -> t.Optional["ManifestNode"]:
        return _read(node._path(target_path, model_name, cache_key))

    @staticmethod
    def put(
        target_path: str, model_name: str, cache_key: str, manifest_node: "ManifestNode"
    ) -> None:
        _write(node._path(target_path, model_name, cache_key), manifest_node)


class _FlatCache:
    """Shared logic for namespaces that store one pickle per cache_key under
    a per-namespace subdirectory of target/.
    """

    _subdir = ""

    @classmethod
    def _path(cls, target_path: str, cache_key: str) -> str:
        return os.path.join(target_path, cls._subdir, f"{cache_key}.pkl")

    @classmethod
    def exists(cls, target_path: str, cache_key: str) -> bool:
        """Probe for a cache entry without loading it. See node.exists."""
        return os.path.exists(cls._path(target_path, cache_key))

    @classmethod
    def get(cls, target_path: str, cache_key: str) -> t.Optional[t.Any]:
        return _read(cls._path(target_path, cache_key))

    @classmethod
    def put(cls, target_path: str, cache_key: str, value: t.Any) -> None:
        _write(cls._path(target_path, cache_key), value)


class schema(_FlatCache):
    """Per-schema-file cache: target/schema_cache/<cache_key>.pkl."""

    _subdir = "schema_cache"


class test(_FlatCache):
    """Per-generic-test cache: target/test_cache/<cache_key>.pkl."""

    _subdir = "test_cache"
