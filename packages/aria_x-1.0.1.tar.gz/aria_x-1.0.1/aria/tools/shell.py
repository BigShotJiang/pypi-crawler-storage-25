import os
import subprocess


def run_command(command: str, cwd: str = None, path: str = None) -> str:
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True,
            text=True, timeout=120, cwd=cwd or path or os.getcwd()
        )
        out = (result.stdout + result.stderr).strip()
        return out[:8000] if out else "(no output)"
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (120s)"
    except Exception as e:
        return f"ERROR: {e}"


def run_tests(command: str = None, cwd: str = None) -> str:
    cmd = command or "pytest" if _has_pytest() else "python -m unittest discover"
    result = run_command(cmd, cwd=cwd)
    return result


def _has_pytest():
    import shutil
    return shutil.which("pytest") is not None
