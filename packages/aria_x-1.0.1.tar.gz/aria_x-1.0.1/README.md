# ◉ ARIA
### Autonomous Reasoning and Intelligent Agent

> Your project-aware coding partner. Reason before action.

ARIA is an open-source CLI agent that works inside your project boundaries like a senior engineer — it plans before acting, validates its work, and remembers context across sessions.

---

## Demo

```
◉ aria(my-project) › Build a REST API with FastAPI and test it

  ? What endpoints should the API have?
  Answer: GET /health, POST /items, GET /items

─────────────────── Plan ───────────────────
  Goal: Build FastAPI REST API

  1. Scaffold project with venv + git
  2. Write main.py with endpoints
  3. Install dependencies
  4. Run server and test with curl
  5. Update README

Proceed? (yes / no / modify): yes

  1. new_project  'fastapi-api'
  2. write_file   'main.py'
  3. run_command  '.venv/bin/pip install -r requirements.txt'
     │ Successfully installed fastapi uvicorn
  4. run_command  'curl http://localhost:8000/health'
     │ {"status":"ok"}

─────────────────── Report ─────────────────
✅ API built and tested successfully.
Files: main.py, requirements.txt, README.md
Run: uvicorn main:app --reload
```

---

## Features

- **Plan before action** — shows you what it will do, waits for approval
- **Validates everything** — runs code, reads output, fixes errors automatically
- **Project memory** — remembers stack, decisions, and context across sessions
- **Project isolation** — auto-creates git, venv, .env, .gitignore, README
- **Approval system** — asks before dangerous operations
- **Beautiful diffs** — shows exactly what changed in every file
- **Git tools** — commit, diff, branch from natural language
- **Streaming responses** — real-time output, not a black box

---

## Install

```bash
pip install aria-agent
```

Requirements: Python 3.10+, [Ollama](https://ollama.com) (for local/cloud models)

---

## Usage

```bash
# Run with default model
aria

# Run with specific model
aria --model nemotron-3-super:cloud

# Run with custom workspace
aria --workspace ~/my-projects
```

---

## Slash Commands

| Command | Description |
|---|---|
| `/help` | Show all commands |
| `/status` | Session info — model, workspace, turns |
| `/clear` | Clear conversation history |
| `/model <name>` | Switch model mid-session |
| `/workspace <path>` | Change workspace |
| `/apikey` | Update API key |
| `/projects` | List all ARIA projects |
| `/memory` | Show persistent memory |
| `/tools` | List all agent tools |
| `/exit` | Exit ARIA |

---

## Models

ARIA works with any Ollama-compatible model:

```bash
aria --model nemotron-3-super:cloud   # Ollama cloud
aria --model llama3.3                  # Local via Ollama
aria --model qwen2.5-coder:32b         # Local coding model
```

---

## How it works

Every task follows this workflow:

```
Clarify → Plan → Approve → Execute → Validate → Remember → Report
```

ARIA never silently modifies your system. Every action is visible, every dangerous operation requires your approval.

---

## Project Memory

ARIA stores project context in `~/.aria/`:

```
~/.aria/
├── user_memory.json       # Your preferences
└── projects/
    └── my-project/
        ├── meta.json      # Stack, status, path
        ├── memory.json    # Key decisions
        └── progress.md   # Milestone history
```

---

## Built by

**Sumit** — independent developer

---

## Contact

For feedback, collaborations, or business inquiries:

**Email:** samsungsumitv461@gmail.com  
**GitHub:** [Lonerider007](https://github.com/Lonerider007)

---

## License

MIT
