# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
End-to-end CLI tests that exercise full command flows through the typer runner.

Each test mocks the qbraid-core client and runs the actual CLI command, covering
argument parsing, data formatting, error handling, and output rendering in one shot.
"""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import typer.testing

from qbraid_cli.compute.app import compute_app
from qbraid_cli.devices.app import devices_app
from qbraid_cli.envs import envs_app
from qbraid_cli.jobs.app import jobs_app
from qbraid_cli.kernels.app import kernels_app
from qbraid_cli.projects.app import projects_app
from qbraid_cli.troubleshoot.app import troubleshoot_app

runner = typer.testing.CliRunner()


# =============================================================================
# Devices
# =============================================================================


class TestDevicesE2E:
    """E2E tests for devices list and get commands."""

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_list_devices_no_filter(self, mock_client_cls):
        """List all devices, verify table output."""
        mock_device = MagicMock()
        mock_device.qrn = "qbraid:ibm:simulator_statevector"
        mock_device.status.value = "ONLINE"
        mock_device.deviceType = "SIMULATOR"
        mock_device.vendor = "ibm"

        mock_client = MagicMock()
        mock_client.list_devices.return_value = [mock_device]
        mock_client_cls.return_value = mock_client

        result = runner.invoke(devices_app, ["list"])

        assert result.exit_code == 0
        assert "qbraid:ibm:simulator_statevector" in result.stdout
        assert "ONLINE" in result.stdout
        assert "Displaying 1 devices" in result.stdout

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_list_devices_empty(self, mock_client_cls):
        """List devices with no results."""
        mock_client = MagicMock()
        mock_client.list_devices.return_value = []
        mock_client_cls.return_value = mock_client

        result = runner.invoke(devices_app, ["list"])

        assert result.exit_code == 0
        assert "Displaying 0 devices" in result.stdout

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_get_device(self, mock_client_cls):
        """Get a single device by QRN."""
        mock_device = MagicMock()
        mock_device.model_dump.return_value = {
            "qrn": "qbraid:ibm:simulator_statevector",
            "status": "ONLINE",
            "deviceType": "SIMULATOR",
            "vendor": "ibm",
        }
        mock_client = MagicMock()
        mock_client.get_device.return_value = mock_device
        mock_client_cls.return_value = mock_client

        result = runner.invoke(devices_app, ["get", "qbraid:ibm:simulator_statevector"])

        assert result.exit_code == 0
        assert "simulator_statevector" in result.stdout


# =============================================================================
# Jobs
# =============================================================================


class TestJobsE2E:
    """E2E tests for jobs list and get commands."""

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_list_jobs(self, mock_client_cls):
        """List jobs with various statuses, verify status coloring logic."""
        mock_job_completed = MagicMock()
        mock_job_completed.jobQrn = "qbraid:job:abc123"
        mock_job_completed.status.value = "COMPLETED"
        mock_job_completed.timeStamps = MagicMock()
        mock_job_completed.timeStamps.createdAt = datetime(2026, 1, 15, 10, 30)

        mock_job_failed = MagicMock()
        mock_job_failed.jobQrn = "qbraid:job:def456"
        mock_job_failed.status.value = "FAILED"
        mock_job_failed.timeStamps = MagicMock()
        mock_job_failed.timeStamps.createdAt = None

        mock_client = MagicMock()
        mock_client.list_jobs.return_value = [mock_job_completed, mock_job_failed]
        mock_client_cls.return_value = mock_client

        result = runner.invoke(jobs_app, ["list"])

        assert result.exit_code == 0
        assert "qbraid:job:abc123" in result.stdout
        assert "COMPLETED" in result.stdout
        assert "qbraid:job:def456" in result.stdout
        assert "FAILED" in result.stdout
        assert "Displaying 2 jobs" in result.stdout

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_list_jobs_empty(self, mock_client_cls):
        """No jobs returns clean message."""
        mock_client = MagicMock()
        mock_client.list_jobs.return_value = []
        mock_client_cls.return_value = mock_client

        result = runner.invoke(jobs_app, ["list"])

        assert result.exit_code == 0
        assert "No jobs found" in result.stdout

    @patch("qbraid_core.services.runtime.QuantumRuntimeClient")
    def test_get_job(self, mock_client_cls):
        """Get a single job by QRN."""
        mock_job = MagicMock()
        mock_job.model_dump.return_value = {
            "jobQrn": "qbraid:job:abc123",
            "status": "COMPLETED",
            "deviceQrn": "qbraid:ibm:sim",
        }
        mock_client = MagicMock()
        mock_client.get_job.return_value = mock_job
        mock_client_cls.return_value = mock_client

        result = runner.invoke(jobs_app, ["get", "qbraid:job:abc123"])

        assert result.exit_code == 0
        assert "abc123" in result.stdout


# =============================================================================
# Projects
# =============================================================================


class TestProjectsE2E:
    """E2E tests for projects commands."""

    @patch("qbraid_core.services.projects.ProjectsClient")
    def test_list_projects(self, mock_client_cls):
        """List projects with table output."""
        mock_client = MagicMock()
        mock_client.list_projects.return_value = [
            {
                "slug": "quantum-intro",
                "title": "Intro to Quantum",
                "envSlugs": ["qiskit_1x0", "cirq_1x0"],
                "githubUrl": "https://github.com/qBraid/quantum-intro",
            },
            {
                "slug": "ml-qml",
                "title": "Quantum ML",
                "envSlugs": [],
                "githubUrl": "",
            },
        ]
        mock_client_cls.return_value = mock_client

        result = runner.invoke(projects_app, ["list"])

        assert result.exit_code == 0
        assert "quantum-intro" in result.stdout
        assert "Intro to Quantum" in result.stdout
        assert "2" in result.stdout  # env count
        assert "ml-qml" in result.stdout

    @patch("qbraid_core.services.projects.ProjectsClient")
    def test_list_projects_empty(self, mock_client_cls):
        """No projects returns clean message."""
        mock_client = MagicMock()
        mock_client.list_projects.return_value = []
        mock_client_cls.return_value = mock_client

        result = runner.invoke(projects_app, ["list"])

        assert result.exit_code == 0
        assert "No projects found" in result.stdout

    @patch("qbraid_core.services.projects.ProjectsClient")
    def test_get_project(self, mock_client_cls):
        """Get a single project by slug."""
        mock_client = MagicMock()
        mock_client.get_project.return_value = {
            "slug": "quantum-intro",
            "title": "Intro to Quantum",
            "description": "A beginner guide",
        }
        mock_client_cls.return_value = mock_client

        result = runner.invoke(projects_app, ["get", "quantum-intro"])

        assert result.exit_code == 0
        assert "quantum-intro" in result.stdout

    @patch("qbraid_core.services.projects.ProjectsClient")
    def test_list_projects_with_search(self, mock_client_cls):
        """Search filter is passed through."""
        mock_client = MagicMock()
        mock_client.list_projects.return_value = []
        mock_client_cls.return_value = mock_client

        runner.invoke(projects_app, ["list", "--search", "quantum"])

        mock_client.list_projects.assert_called_once_with(
            search="quantum", featured=None, category=None, visibility=None
        )


# =============================================================================
# Compute (server, profiles, sessions, ssh)
# =============================================================================


class TestComputeE2E:
    """E2E tests for compute commands."""

    @patch("qbraid_cli.compute.app._get_client")
    def test_status_stopped(self, mock_get_client):
        """Server status when no server is running."""
        mock_client = MagicMock()
        mock_client.get_server_status.return_value = MagicMock(
            server_running=False,
            server_starting=False,
            current_profile=None,
            cluster_id="default",
        )
        mock_get_client.return_value = mock_client

        result = runner.invoke(compute_app, ["status"])

        assert result.exit_code == 0
        assert "No server running" in result.stdout

    @patch("qbraid_cli.compute.app._get_client")
    def test_status_running(self, mock_get_client):
        """Server status when server is running."""
        mock_client = MagicMock()
        mock_client.get_server_status.return_value = MagicMock(
            server_running=True,
            server_starting=False,
            current_profile="2vCPU_4GB",
            cluster_id="default",
            url=None,
        )
        mock_get_client.return_value = mock_client

        result = runner.invoke(compute_app, ["status"])

        assert result.exit_code == 0
        assert "2vCPU_4GB" in result.stdout

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_profiles_list(self, mock_client_cls):
        """List compute profiles."""
        mock_profile = MagicMock()
        mock_profile.slug = "2vCPU_4GB"
        mock_profile.display_name = "2 vCPU / 4 GB"
        mock_profile.cpu_guarantee = 2.0
        mock_profile.mem_guarantee = "4G"
        mock_profile.gpu = False
        mock_profile.has_capacity = True
        mock_profile.plan = "standard"
        mock_profile.profile_type = MagicMock(value="global")

        mock_client = MagicMock()
        mock_client.list_profiles.return_value = [mock_profile]
        mock_client_cls.return_value = mock_client

        result = runner.invoke(compute_app, ["profiles", "list"])

        assert result.exit_code == 0
        assert "2vCPU_4GB" in result.stdout

    @patch("qbraid_cli.compute.app._get_client")
    def test_down_no_server(self, mock_get_client):
        """Stop when no server is running."""
        mock_client = MagicMock()
        mock_client.get_server_status.return_value = MagicMock(server_running=False, server_starting=False)
        mock_get_client.return_value = mock_client

        result = runner.invoke(compute_app, ["down"])

        assert result.exit_code == 0
        assert "No server" in result.stdout


# =============================================================================
# Envs
# =============================================================================


class TestEnvsE2E:
    """E2E tests for envs commands."""

    @patch("qbraid_cli.envs.app.installed_envs_data")
    def test_list_multiple_envs(self, mock_installed):
        """List multiple envs with mixed aliases."""
        mock_installed.return_value = (
            {
                "env1": Path("/path/to/env1"),
                "env2": Path("/path/to/env2"),
                "env3": Path("/path/to/env3"),
            },
            {
                "Qiskit": "env1",
                "env1": "env1",
                "Cirq": "env2",
                "env2": "env2",
                "env3": "env3",
            },
        )

        result = runner.invoke(envs_app, ["list"])

        assert result.exit_code == 0
        assert "Qiskit" in result.stdout
        assert "Cirq" in result.stdout
        assert "env3" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_available_envs(self, mock_emc_cls):
        """List available environments from the cloud."""
        mock_client = MagicMock()
        mock_client.get_available_environments.return_value = {
            "environments": [
                {
                    "slug": "qiskit_1x0_abc",
                    "name": "Qiskit 1.0",
                    "description": "IBM Qiskit",
                    "python_version": "3.11",
                    "available_for_installation": True,
                }
            ],
            "pagination": {"page": 1, "totalPages": 1, "total": 1},
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["available"])

        assert result.exit_code == 0
        assert "qiskit_1x0_abc" in result.stdout


# =============================================================================
# Kernels
# =============================================================================


class TestKernelsE2E:
    """E2E tests for kernels commands."""

    @patch("qbraid_core.services.environments.kernels.get_all_kernels")
    def test_list_kernels(self, mock_kernels):
        """List kernels with multiple entries."""
        mock_kernels.return_value = {
            "python3": {"resource_dir": "/usr/share/jupyter/kernels/python3"},
            "qiskit_env": {"resource_dir": "/home/user/.local/share/jupyter/kernels/qiskit_env"},
        }

        result = runner.invoke(kernels_app, ["list"])

        assert result.exit_code == 0
        assert "python3" in result.stdout
        assert "qiskit_env" in result.stdout


# =============================================================================
# Troubleshoot
# =============================================================================


class TestTroubleshootE2E:
    """E2E tests for troubleshoot command."""

    @patch("qbraid_cli.troubleshoot.app._render_report")
    @patch("qbraid_core.diagnostics.run_diagnostics")
    def test_full_diagnostics(self, mock_diag, _mock_render):
        """Run full diagnostics with all categories."""
        mock_report = MagicMock()
        mock_diag.return_value = mock_report

        result = runner.invoke(troubleshoot_app, [])

        assert result.exit_code == 0
        mock_diag.assert_called_once()

    @patch("qbraid_cli.troubleshoot.app._render_report")
    @patch("qbraid_core.diagnostics.run_diagnostics")
    def test_single_category(self, mock_diag, _mock_render):
        """Run diagnostics for auth only."""
        mock_report = MagicMock()
        mock_diag.return_value = mock_report

        result = runner.invoke(troubleshoot_app, ["--auth"])

        assert result.exit_code == 0
        call_kwargs = mock_diag.call_args.kwargs
        assert call_kwargs["categories"] == ["auth"]


# =============================================================================
# Compute SSH
# =============================================================================


class TestComputeSshE2E:
    """E2E tests for compute ssh commands."""

    @patch("qbraid_core.services.compute.ssh.list_pod_ssh_configs")
    @patch("qbraid_core.services.compute.ssh.get_qbraid_ssh_config_path")
    def test_ssh_config_with_hosts(self, mock_path, mock_list):
        """Show SSH config with configured hosts."""
        mock_path_obj = MagicMock()
        mock_path_obj.exists.return_value = True
        mock_path_obj.read_text.return_value = "Host qbraid-lab\n  HostName lab.qbraid.com\n"
        mock_path.return_value = mock_path_obj
        mock_list.return_value = ["qbraid-lab"]

        from qbraid_cli.compute.ssh import ssh_app

        result = runner.invoke(ssh_app, ["config"])

        assert result.exit_code == 0
        assert "qbraid-lab" in result.stdout

    @patch("qbraid_core.services.compute.ssh.remove_pod_ssh_config")
    def test_ssh_remove(self, mock_remove):
        """Remove SSH config for a host."""
        mock_remove.return_value = True

        from qbraid_cli.compute.ssh import ssh_app

        result = runner.invoke(ssh_app, ["remove", "qbraid-lab", "--force"])

        assert result.exit_code == 0
        mock_remove.assert_called_once_with("lab")


# =============================================================================
# Compute Server (start, stop, url, status detail)
# =============================================================================


class TestComputeServerE2E:
    """E2E tests for compute server subcommands."""

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_server_start(self, mock_client_cls):
        """Start a server with a profile."""
        mock_response = MagicMock()
        mock_response.message = "Server starting"
        mock_response.profile = "2vCPU_4GB"
        mock_response.cluster_id = "default"
        mock_response.status = "starting"

        mock_client = MagicMock()
        mock_client.start_server.return_value = mock_response
        mock_client_cls.return_value = mock_client

        from qbraid_cli.compute.server import server_app

        result = runner.invoke(server_app, ["start", "2vCPU_4GB"])

        assert result.exit_code == 0
        assert "Server starting" in result.stdout
        assert "2vCPU_4GB" in result.stdout

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_server_stop_force(self, mock_client_cls):
        """Stop server with --force."""
        mock_response = MagicMock()
        mock_response.message = "Server stopped"
        mock_response.cluster_id = "default"
        mock_response.status = "stopped"

        mock_client = MagicMock()
        mock_client.stop_server.return_value = mock_response
        mock_client_cls.return_value = mock_client

        from qbraid_cli.compute.server import server_app

        result = runner.invoke(server_app, ["stop", "--force"])

        assert result.exit_code == 0
        assert "Server stopped" in result.stdout

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_server_status_detailed(self, mock_client_cls):
        """Server status with full details panel."""
        mock_status = MagicMock()
        mock_status.server_running = True
        mock_status.server_starting = False
        mock_status.current_profile = "4vCPU_8GB"
        mock_status.cluster_id = "cluster-abc"
        mock_status.url = None
        mock_status.server_details = MagicMock(started="2026-01-01 12:00", url=None)
        mock_status.user_info = MagicMock(name="testuser")

        mock_client = MagicMock()
        mock_client.get_server_status.return_value = mock_status
        mock_client.get_profile.return_value = MagicMock(ide="lab")
        mock_client_cls.return_value = mock_client

        from qbraid_cli.compute.server import server_app

        result = runner.invoke(server_app, ["status"])

        assert result.exit_code == 0
        assert "4vCPU_8GB" in result.stdout
        assert "testuser" in result.stdout

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_server_url_no_server(self, mock_client_cls):
        """Server URL when no server running."""
        mock_client = MagicMock()
        mock_client.get_server_status.return_value = MagicMock(server_running=False)
        mock_client_cls.return_value = mock_client

        from qbraid_cli.compute.server import server_app

        result = runner.invoke(server_app, ["url"])

        assert result.exit_code == 1
        assert "No server running" in result.stdout


# =============================================================================
# Compute Profiles (info, create-try, delete)
# =============================================================================


class TestComputeProfilesE2E:
    """E2E tests for compute profiles subcommands."""

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_profiles_info(self, mock_client_cls):
        """Get detailed profile info."""
        mock_profile = MagicMock()
        mock_profile.slug = "2vCPU_4GB"
        mock_profile.display_name = "2 vCPU / 4 GB"
        mock_profile.description = "Standard compute"
        mock_profile.plan = "standard"
        mock_profile.visibility = "public"
        mock_profile.gpu = False
        mock_profile.ide = "lab"
        mock_profile.cluster_id = "default"
        mock_profile.has_capacity = True
        mock_profile.resources = MagicMock()
        mock_profile.resources.cpu.guarantee = 2.0
        mock_profile.resources.cpu.limit = 4.0
        mock_profile.resources.memory.guarantee = "4G"
        mock_profile.resources.memory.limit = "8G"
        mock_profile.rate_dollar = None
        mock_profile.rate_time_frame = None

        mock_client = MagicMock()
        mock_client.get_profile.return_value = mock_profile
        mock_client_cls.return_value = mock_client

        result = runner.invoke(compute_app, ["profiles", "info", "2vCPU_4GB"])

        assert result.exit_code == 0
        assert "2 vCPU / 4 GB" in result.stdout


# =============================================================================
# Envs (info, health, publish, share, groups, registry)
# =============================================================================


class TestEnvsSubcommandsE2E:
    """E2E tests for envs sub-group commands."""

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_groups_list(self, mock_emc_cls):
        """List environment groups."""
        mock_client = MagicMock()
        mock_client.get_environment_groups.return_value = {
            "environment_groups": [
                {
                    "displayName": "Qiskit",
                    "slug": "qiskit",
                    "description": "IBM Qiskit environments",
                    "environments": ["qiskit_1x0", "qiskit_0x9"],
                }
            ]
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["groups", "list"])

        assert result.exit_code == 0
        assert "Qiskit" in result.stdout
        assert "qiskit" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_groups_info(self, mock_emc_cls):
        """Get group details."""
        mock_client = MagicMock()
        mock_client.get_environment_group_by_slug.return_value = {
            "displayName": "Qiskit",
            "slug": "qiskit",
            "description": "IBM Qiskit environments",
            "environments": ["qiskit_1x0", "qiskit_0x9"],
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["groups", "info", "qiskit"])

        assert result.exit_code == 0
        assert "Qiskit" in result.stdout
        assert "qiskit_1x0" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_publish_status(self, mock_emc_cls):
        """Check publish status."""
        mock_client = MagicMock()
        mock_client.get_publish_status.return_value = "approved"
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["publish", "status", "my_env_abc"])

        assert result.exit_code == 0
        assert "approved" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_share_list(self, mock_emc_cls):
        """List users with access to an environment."""
        mock_client = MagicMock()
        mock_client.get_environment_shared_with.return_value = {
            "shared_with": [
                {"email": "alice@example.com", "access": "read"},
                {"email": "bob@example.com", "access": "write"},
            ]
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["share", "list", "my_env_abc"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_available_empty(self, mock_emc_cls):
        """Available envs with no results."""
        mock_client = MagicMock()
        mock_client.get_available_environments.return_value = {
            "environments": [],
            "pagination": {},
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["available"])

        assert result.exit_code == 0
        assert "No environments available" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_available_pagination(self, mock_emc_cls):
        """Available envs with pagination info."""
        mock_client = MagicMock()
        mock_client.get_available_environments.return_value = {
            "environments": [
                {
                    "slug": f"env_{i}",
                    "name": f"Env {i}",
                    "description": "Test",
                    "available_for_installation": True,
                }
                for i in range(3)
            ],
            "pagination": {"page": 1, "totalPages": 3, "total": 9},
        }
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["available"])

        assert result.exit_code == 0
        assert "Page 1 of 3" in result.stdout
        assert "Next: --page 2" in result.stdout


# =============================================================================
# Skills (list, search, info, install, uninstall)
# =============================================================================


class TestSkillsE2E:
    """E2E tests for skills commands."""

    @patch("qbraid_core.services.skills.SkillsClient")
    def test_skills_list(self, mock_client_cls):
        """List skills with table output."""
        mock_skill = MagicMock()
        mock_skill.slug = "quantum-circuits"
        mock_skill.name = "Quantum Circuits"
        mock_skill.description = "Build and run quantum circuits"
        mock_skill.visibility = MagicMock(value="public")
        mock_skill.download_count = 42

        mock_client = MagicMock()
        mock_client.list_skills.return_value = [mock_skill]
        mock_client_cls.return_value = mock_client

        from qbraid_cli.skills.app import skills_app

        result = runner.invoke(skills_app, ["list"])

        assert result.exit_code == 0
        assert "quantum-circuits" in result.stdout
        assert "Showing 1 skills" in result.stdout

    @patch("qbraid_core.services.skills.SkillsClient")
    def test_skills_list_empty(self, mock_client_cls):
        """No skills found."""
        mock_client = MagicMock()
        mock_client.list_skills.return_value = []
        mock_client_cls.return_value = mock_client

        from qbraid_cli.skills.app import skills_app

        result = runner.invoke(skills_app, ["list"])

        assert result.exit_code == 0
        assert "No skills found" in result.stdout

    @patch("qbraid_core.services.skills.SkillsClient")
    def test_skills_search(self, mock_client_cls):
        """Search for skills."""
        mock_skill = MagicMock()
        mock_skill.slug = "qiskit-helper"
        mock_skill.name = "Qiskit Helper"
        mock_skill.description = "Helps with Qiskit"

        mock_client = MagicMock()
        mock_client.list_skills.return_value = [mock_skill]
        mock_client_cls.return_value = mock_client

        from qbraid_cli.skills.app import skills_app

        result = runner.invoke(skills_app, ["search", "qiskit"])

        assert result.exit_code == 0
        assert "qiskit-helper" in result.stdout

    @patch("qbraid_core.services.skills.SkillsClient")
    def test_skills_info(self, mock_client_cls):
        """Get detailed skill info."""
        mock_skill = MagicMock()
        mock_skill.slug = "quantum-circuits"
        mock_skill.name = "Quantum Circuits"
        mock_skill.version = "1.0.0"
        mock_skill.description = "Build quantum circuits"
        mock_skill.tags = ["quantum", "circuits"]
        mock_skill.app_id = None
        mock_skill.download_count = 42
        mock_skill.visibility = MagicMock(value="public")
        mock_skill.review_status = None
        mock_skill.compatibility = ["claude-code"]
        mock_skill.owner_email = "dev@qbraid.com"

        mock_client = MagicMock()
        mock_client.get_skill.return_value = mock_skill
        mock_client_cls.return_value = mock_client

        from qbraid_cli.skills.app import skills_app

        result = runner.invoke(skills_app, ["info", "quantum-circuits"])

        assert result.exit_code == 0
        assert "Quantum Circuits" in result.stdout
        assert "1.0.0" in result.stdout
        assert "claude-code" in result.stdout


# =============================================================================
# Agents
# =============================================================================


class TestAgentsE2E:
    """E2E tests for agents commands."""

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_list_empty(self, mock_registry_cls):
        """List agents with no sessions."""
        mock_registry = MagicMock()
        mock_registry.load_registry.return_value = MagicMock(sessions=[])
        mock_registry.search_sessions.return_value = []
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["list", "--no-interactive"])

        assert result.exit_code == 0
        assert "No matching agent sessions" in result.stdout

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_list_with_sessions(self, mock_registry_cls):
        """List agents with active sessions in table format."""
        import time

        mock_session = MagicMock()
        mock_session.session_id = "abc12345-6789"
        mock_session.tool = MagicMock(value="claude")
        mock_session.status = MagicMock(value="working")
        mock_session.tmux_window = "worker-0"
        mock_session.terminal_name = None
        mock_session.cwd = "/home/user/project"
        mock_session.model_name = "claude-sonnet-4-20250514"
        mock_session.cost_usd = 0.05
        mock_session.started_at = time.time() - 3600
        mock_session.last_activity = time.time() - 60
        mock_session.compute_id = None
        mock_session.tags = ["dev"]
        mock_session.pid = 12345
        mock_session.model_dump.return_value = {"session_id": "abc12345-6789"}

        mock_registry = MagicMock()
        mock_registry.search_sessions.return_value = [mock_session]
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["list", "--no-interactive"])

        assert result.exit_code == 0
        assert "abc12345" in result.stdout
        assert "worker-0" in result.stdout

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_list_json_output(self, mock_registry_cls):
        """List agents with --json flag."""
        mock_session = MagicMock()
        mock_session.session_id = "test-session"
        mock_session.tool = MagicMock(value="claude")
        mock_session.status = MagicMock(value="idle")
        mock_session.model_dump.return_value = {"sessionId": "test-session", "tool": "claude"}

        mock_registry = MagicMock()
        mock_registry.search_sessions.return_value = [mock_session]
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["list", "--json"])

        assert result.exit_code == 0
        assert "test-session" in result.stdout

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_status_session(self, mock_registry_cls):
        """Get detailed status for a session."""
        import time

        mock_session = MagicMock()
        mock_session.session_id = "abc12345-6789"
        mock_session.tool = MagicMock(value="claude")
        mock_session.status = MagicMock(value="working")
        mock_session.tmux_window = "worker-0"
        mock_session.terminal_name = None
        mock_session.tmux_session = "qbraid-agents"
        mock_session.cwd = "/home/user/project"
        mock_session.model_name = "claude-sonnet-4-20250514"
        mock_session.cost_usd = 0.05
        mock_session.total_tokens = 5000
        mock_session.started_at = time.time() - 3600
        mock_session.last_activity = time.time() - 60
        mock_session.pid = 12345
        mock_session.compute_id = None
        mock_session.git = None
        mock_session.tags = []
        mock_session.transcript_path = None
        mock_session.tasks = []
        mock_session.port = None

        mock_registry = MagicMock()
        all_sessions = MagicMock()
        all_sessions.sessions = [mock_session]
        mock_registry.load_registry.return_value = all_sessions
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["status", "abc12345"])

        assert result.exit_code == 0
        assert "abc12345" in result.stdout
        assert "working" in result.stdout

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_status_not_found(self, mock_registry_cls):
        """Status for non-existent session."""
        mock_registry = MagicMock()
        all_sessions = MagicMock()
        all_sessions.sessions = []
        mock_registry.load_registry.return_value = all_sessions
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["status", "nonexistent"])

        assert result.exit_code == 1

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_kill_session(self, mock_registry_cls):
        """Kill a session by ID."""
        mock_session = MagicMock()
        mock_session.session_id = "abc12345-6789"
        mock_session.tmux_window = "worker-0"
        mock_session.terminal_name = None
        mock_session.pid = 12345
        mock_session.compute_id = None
        mock_session.tmux_session = "qbraid-agents"

        mock_registry = MagicMock()
        all_sessions = MagicMock()
        all_sessions.sessions = [mock_session]
        mock_registry.load_registry.return_value = all_sessions
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["kill", "abc12345"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_discover_empty(self, mock_registry_cls):
        """Discover with no new sessions found."""
        mock_registry = MagicMock()
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        with patch("qbraid_core.services.agents.detect_sessions", return_value=[]):
            result = runner.invoke(agents_app, ["discover"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.agents.AgentSessionRegistryManager")
    def test_update_session(self, mock_registry_cls):
        """Update a session's metadata."""
        mock_session = MagicMock()
        mock_session.session_id = "abc12345-6789"
        mock_session.tmux_window = "worker-0"
        mock_session.terminal_name = None

        mock_registry = MagicMock()
        all_sessions = MagicMock()
        all_sessions.sessions = [mock_session]
        mock_registry.load_registry.return_value = all_sessions
        mock_registry.update_session.return_value = mock_session
        mock_registry_cls.return_value = mock_registry

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["update", "abc12345", "--name", "new-name"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.agents.AgentLauncher")
    def test_read_session(self, mock_launcher_cls):
        """Read recent terminal output from a session."""
        mock_launcher = MagicMock()
        mock_launcher.read.return_value = "Some terminal output\nMore output"
        mock_launcher_cls.return_value = mock_launcher

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["read", "abc12345"])

        assert result.exit_code == 0
        assert "Some terminal output" in result.stdout

    @patch("qbraid_core.services.agents.AgentLauncher")
    def test_send_text(self, mock_launcher_cls):
        """Send text to a running agent."""
        mock_launcher = MagicMock()
        mock_launcher.send.return_value = None
        mock_launcher_cls.return_value = mock_launcher

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["send", "abc12345", "--text", "hello agent"])

        assert result.exit_code == 0


# =============================================================================
# Envs publish, share, registry flows
# =============================================================================


class TestEnvsPublishFlowsE2E:
    """E2E tests for envs publish request/cancel/review/approve/deny."""

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_publish_request(self, mock_emc_cls):
        """Request to publish an environment."""
        mock_client = MagicMock()
        mock_client.request_publish.return_value = {"status": "requested"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["publish", "request", "my_env_abc"])

        assert result.exit_code == 0
        assert "Publish request submitted" in result.stdout

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_publish_cancel(self, mock_emc_cls):
        """Cancel a publish request."""
        mock_client = MagicMock()
        mock_client.revoke_publish_request.return_value = {"status": "cancelled"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["publish", "cancel", "my_env_abc"])

        assert result.exit_code == 0
        assert "cancelled" in result.stdout.lower()

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_publish_review(self, mock_emc_cls):
        """Mark environment as under review."""
        mock_client = MagicMock()
        mock_client.set_publish_pending.return_value = {"status": "pending"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["publish", "review", "my_env_abc"])

        assert result.exit_code == 0
        assert "under review" in result.stdout.lower()

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_share_create_code(self, mock_emc_cls):
        """Generate a share code."""
        mock_client = MagicMock()
        mock_client.generate_share_code.return_value = {"code": "ABC123", "slug": "my_env_abc"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["share", "create-code", "my_env_abc"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_share_redeem_code(self, mock_emc_cls):
        """Redeem a share code."""
        mock_client = MagicMock()
        mock_client.redeem_share_code.return_value = {"slug": "shared_env", "name": "Shared Env"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["share", "redeem-code", "ABC123"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_share_delete_code(self, mock_emc_cls):
        """Delete a share code."""
        mock_client = MagicMock()
        mock_client.delete_share_code.return_value = {"status": "deleted"}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["share", "delete-code", "my_env_abc"])

        assert result.exit_code == 0

    @patch("qbraid_core.services.environments.client.EnvironmentManagerClient")
    def test_envs_groups_empty(self, mock_emc_cls):
        """List groups when none exist."""
        mock_client = MagicMock()
        mock_client.get_environment_groups.return_value = {"environment_groups": []}
        mock_emc_cls.return_value = mock_client

        result = runner.invoke(envs_app, ["groups", "list"])

        assert result.exit_code == 0
        assert "No environment groups found" in result.stdout


# =============================================================================
# Agents approve
# =============================================================================


class TestAgentsApproveE2E:
    """E2E tests for agents approve command."""

    @patch("qbraid_core.services.agents.AgentLauncher")
    def test_approve(self, mock_launcher_cls):
        """Approve a tool-use prompt."""
        mock_launcher = MagicMock()
        mock_launcher.approve.return_value = None
        mock_launcher_cls.return_value = mock_launcher

        from qbraid_cli.agents.app import agents_app

        result = runner.invoke(agents_app, ["approve", "abc12345"])

        assert result.exit_code == 0


# =============================================================================
# Compute usage and sessions
# =============================================================================


class TestComputeUsageE2E:
    """E2E tests for compute usage and sessions."""

    @patch("qbraid_cli.compute.app._get_client")
    def test_usage(self, mock_get_client):
        """Show compute usage summary."""
        mock_client = MagicMock()
        mock_usage = MagicMock()
        mock_usage.summary = MagicMock(
            total_sessions=5,
            cpu_sessions=3,
            gpu_sessions=2,
            total_hours=10.5,
            total_compute_hours_deducted=8.0,
            total_credits_charged=2.5,
        )
        mock_usage.compute_hours = None
        mock_usage.daily = None
        mock_client.get_usage.return_value = mock_usage
        mock_get_client.return_value = mock_client

        result = runner.invoke(compute_app, ["usage"])

        assert result.exit_code == 0
        assert "Usage Summary" in result.stdout

    @patch("qbraid_core.services.compute.ComputeClient")
    def test_compute_list(self, mock_client_cls):
        """Quick list profiles alias."""
        mock_profile = MagicMock()
        mock_profile.slug = "gpu_a100"
        mock_profile.display_name = "A100 GPU"
        mock_profile.gpu = True
        mock_profile.has_capacity = True
        mock_profile.plan = "pro"
        mock_profile.profile_type = MagicMock(value="global")

        mock_client = MagicMock()
        mock_client.list_profiles.return_value = [mock_profile]
        mock_client_cls.return_value = mock_client

        result = runner.invoke(compute_app, ["list"])

        assert result.exit_code == 0
        assert "gpu_a100" in result.stdout
