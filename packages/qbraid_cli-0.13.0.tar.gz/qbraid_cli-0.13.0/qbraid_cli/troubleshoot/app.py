# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""
Module defining the 'qbraid troubleshoot' command.

"""

import json
import shutil
import subprocess

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

troubleshoot_app = typer.Typer(
    help=(
        "Diagnose qBraid platform issues.\n\n"
        "Diagnose and troubleshoot qBraid platform issues.\n"
        "Runs automated checks on authentication, configuration,\n"
        "network connectivity, JupyterLab integration, environments,\n"
        "and system compatibility.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Debug authentication or connectivity issues\n"
        "  \u2022 Verify JupyterLab extension setup\n"
        "  \u2022 Check environment health\n"
        "  \u2022 Generate a bug report for support"
    ),
    invoke_without_command=True,
)


STATUS_SYMBOLS = {
    "pass": "[green]\u2714[/green]",
    "warn": "[yellow]\u26a0[/yellow]",
    "fail": "[red]\u2718[/red]",
    "skip": "[dim]-[/dim]",
    "error": "[red]\u2620[/red]",
}

STATUS_COLORS = {
    "pass": "green",
    "warn": "yellow",
    "fail": "red",
    "skip": "dim",
    "error": "red",
}


def _render_report(report, console: Console) -> None:
    """Render a diagnostic report to the console."""
    # Group by category
    categories: dict[str, list] = {}
    for result in report.results:
        categories.setdefault(result.category, []).append(result)

    for category, checks in categories.items():
        table = Table(
            title=f"  {category.upper()}",
            title_style="bold",
            show_header=False,
            box=None,
            pad_edge=False,
        )
        table.add_column("Status", width=3)
        table.add_column("Check", ratio=1)

        for check in checks:
            symbol = STATUS_SYMBOLS.get(check.status.value, "?")
            color = STATUS_COLORS.get(check.status.value, "white")

            msg = check.message
            if check.fix_hint and check.status.value in ("fail", "warn"):
                msg += f"\n    [dim]Fix: {check.fix_hint}[/dim]"

            table.add_row(symbol, f"[{color}]{msg}[/{color}]")

        console.print(table)
        console.print()

    # Summary
    summary = report.summary()
    if report.failures or report.errors:
        console.print(Panel(f"[red bold]{summary}[/red bold]", border_style="red"))
    elif report.warnings:
        console.print(Panel(f"[yellow]{summary}[/yellow]", border_style="yellow"))
    else:
        console.print(Panel(f"[green]{summary}[/green]", border_style="green"))


@troubleshoot_app.callback(invoke_without_command=True)
def troubleshoot(
    ctx: typer.Context,
    auth: bool = typer.Option(False, "--auth", help="Run authentication checks only"),
    config: bool = typer.Option(False, "--config", help="Run configuration checks only"),
    network: bool = typer.Option(False, "--network", help="Run network checks only"),
    jlab: bool = typer.Option(False, "--jlab", help="Run JupyterLab checks only"),
    envs: bool = typer.Option(False, "--envs", help="Run environment checks only"),
    system: bool = typer.Option(False, "--system", help="Run system checks only"),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output including per-environment checks",
    ),
    export: bool = typer.Option(False, "--export", help="Export diagnostic report as JSON"),
    report: bool = typer.Option(False, "--report", help="Open a GitHub issue with diagnostic results"),
) -> None:
    """Run diagnostic checks on your qBraid setup."""
    if ctx.invoked_subcommand is not None:
        return

    console = Console()

    # Determine categories
    category_flags = {
        "auth": auth,
        "config": config,
        "network": network,
        "jupyterlab": jlab,
        "environments": envs,
        "system": system,
    }

    selected = [k for k, v in category_flags.items() if v]
    categories = selected if selected else None  # None = all

    console.print("[bold]Running diagnostics...[/bold]\n")

    try:
        from qbraid_core.diagnostics import run_diagnostics

        diagnostic_report = run_diagnostics(categories=categories, verbose=verbose)
    except ImportError:
        console.print("[red]qbraid-core diagnostics module not available. Update qbraid-core.[/red]")
        raise typer.Exit(1)
    except Exception as exc:
        console.print(f"[red]Diagnostics failed: {exc}[/red]")
        raise typer.Exit(1)

    _render_report(diagnostic_report, console)

    if export:
        report_dict = diagnostic_report.to_dict()
        output_file = "qbraid_diagnostics.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(report_dict, f, indent=2)
        console.print(f"\n[dim]Report exported to {output_file}[/dim]")

    if report:
        _open_github_issue(diagnostic_report, console)


def _open_github_issue(diagnostic_report, console: Console) -> None:
    """Open a GitHub issue with diagnostic results."""
    # Only open an issue if there are actual failures
    if not diagnostic_report.failures and not diagnostic_report.errors:
        console.print("[yellow]No failures detected — skipping issue creation.[/yellow]")
        return

    body = diagnostic_report.to_github_issue_body()

    # Build a title from the first failure
    first_failure = (diagnostic_report.failures or diagnostic_report.errors)[0]
    title = f"[Diagnostic] {first_failure.name}: {first_failure.message[:80]}"

    gh_bin = shutil.which("gh")
    if not gh_bin:
        console.print("\n[yellow]GitHub CLI (gh) not installed. Issue body below:[/yellow]\n")
        console.print(Panel(body, title="GitHub Issue Body", border_style="dim"))
        console.print("[dim]Install gh: https://cli.github.com/[/dim]")
        return

    # Confirm with user
    console.print(f"\n[bold]Opening GitHub issue:[/bold] {title}")
    confirm = typer.confirm("Create this issue on qBraid/community?")
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        return

    try:
        result = subprocess.run(
            [
                gh_bin,
                "issue",
                "create",
                "--repo",
                "qBraid/community",
                "--title",
                title,
                "--body",
                body,
                "--label",
                "bug,diagnostics",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )

        if result.returncode == 0:
            issue_url = result.stdout.strip()
            console.print(f"[green]Issue created: {issue_url}[/green]")
        else:
            console.print(f"[red]Failed to create issue: {result.stderr}[/red]")
            console.print("\n[dim]Issue body:[/dim]")
            console.print(Panel(body, border_style="dim"))
    except Exception as exc:
        console.print(f"[red]Error creating issue: {exc}[/red]")
        console.print(Panel(body, title="Issue Body", border_style="dim"))
