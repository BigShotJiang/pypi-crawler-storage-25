# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid skills' namespace.

"""

from enum import Enum
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from qbraid_cli.handlers import handle_error, run_progress_task

skills_app = typer.Typer(
    help=(
        "Create, install, and share AI coding skills.\n\n"
        "Skills are reusable prompt templates and tools that give AI agents\n"
        "specialized capabilities \u2014 like running quantum circuits, deploying\n"
        "to specific platforms, or following team conventions.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Give your AI agent domain-specific knowledge\n"
        "  \u2022 Share team-specific workflows with collaborators\n"
        "  \u2022 Install community-built skills from the catalog\n"
        "  \u2022 Create custom skills for your projects\n\n"
        "Quick start:\n"
        "  qbraid skills list             # Browse available skills\n"
        "  qbraid skills install <slug>   # Install a skill\n"
        "  qbraid skills create           # Create a new skill"
    ),
    no_args_is_help=True,
)


class SkillTargetOption(str, Enum):
    """Target AI coding tool for skill installation."""

    CLAUDE_CODE = "claude-code"
    CODEX = "codex"
    CURSOR = "cursor"
    COPILOT = "copilot"
    ALL = "all"


class VisibilityOption(str, Enum):
    """Skill visibility level."""

    PRIVATE = "private"
    PUBLIC = "public"
    SHARED = "shared"


# =============================================================================
# Core Commands
# =============================================================================


@skills_app.command(name="list")
def skills_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search query for skills"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Filter by tags (comma-separated)"),
    visibility: Optional[VisibilityOption] = typer.Option(
        None, "--visibility", "-v", help="Filter by visibility"
    ),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum number of results"),
) -> None:
    """List available qBraid skills."""

    def fetch_skills():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        tag_list = tags.split(",") if tags else None
        vis = visibility.value if visibility else None
        return client.list_skills(query=query, tags=tag_list, visibility=vis, limit=limit)

    try:
        skills = run_progress_task(fetch_skills)

        console = Console()

        if not skills:
            console.print("[dim]No skills found.[/dim]")
            return

        table = Table(title="Available Skills")
        table.add_column("Slug", style="cyan", no_wrap=True)
        table.add_column("Name", style="white")
        table.add_column("Description", style="dim")
        table.add_column("Visibility", style="green")
        table.add_column("Downloads", justify="right", style="yellow")

        for skill in skills:
            desc = (
                skill.description[:40] + "..."
                if skill.description and len(skill.description) > 40
                else (skill.description or "")
            )
            table.add_row(
                skill.slug,
                skill.name,
                desc,
                skill.visibility.value if skill.visibility else "private",
                str(skill.download_count),
            )

        console.print(table)
        console.print(f"\n[italic]Showing {len(skills)} skills[/italic]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to list skills: {err}")


@skills_app.command(name="search")
def skills_search(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum number of results"),
) -> None:
    """Search for qBraid skills."""

    def fetch_skills():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.list_skills(query=query, limit=limit)

    try:
        skills = run_progress_task(fetch_skills)

        console = Console()

        if not skills:
            console.print(f"[dim]No skills found matching '{query}'.[/dim]")
            return

        table = Table(title=f"Search Results: '{query}'")
        table.add_column("Slug", style="cyan", no_wrap=True)
        table.add_column("Name", style="white")
        table.add_column("Description", style="dim")

        for skill in skills:
            desc = (
                skill.description[:50] + "..."
                if skill.description and len(skill.description) > 50
                else (skill.description or "")
            )
            table.add_row(skill.slug, skill.name, desc)

        console.print(table)

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to search skills: {err}")


@skills_app.command(name="info")
def skills_info(
    slug: str = typer.Argument(..., help="The skill slug to get info for"),
) -> None:
    """Get detailed information about a skill."""

    def fetch_skill():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.get_skill(slug)

    try:
        skill = run_progress_task(fetch_skill)

        console = Console()
        console.print(f"\n[bold cyan]{skill.name}[/bold cyan] ({skill.slug})")
        console.print(f"[dim]Version: {skill.version}[/dim]\n")

        if skill.description:
            console.print(f"{skill.description}\n")

        if skill.tags:
            console.print(f"[green]Tags:[/green] {', '.join(skill.tags)}")

        if skill.app_id:
            console.print(f"[blue]Linked App:[/blue] {skill.app_id}")

        console.print(f"[yellow]Downloads:[/yellow] {skill.download_count}")
        console.print(f"[dim]Visibility: {skill.visibility.value if skill.visibility else 'private'}[/dim]")

        if skill.review_status:
            console.print(f"[magenta]Review Status:[/magenta] {skill.review_status.value}")

        if skill.compatibility:
            console.print(f"[cyan]Compatible with:[/cyan] {', '.join(skill.compatibility)}")

        if skill.owner_email:
            console.print(f"[dim]Owner: {skill.owner_email}[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to get skill info: {err}")


# =============================================================================
# Install/Uninstall Commands
# =============================================================================


@skills_app.command(name="install")
def skills_install(
    slug: str = typer.Argument(..., help="The skill slug to install"),
    target: SkillTargetOption = typer.Option(
        SkillTargetOption.CLAUDE_CODE,
        "--target",
        "-t",
        help="Target AI coding tool(s) to install for",
    ),
) -> None:
    """Install a skill for AI coding tools.

    By default, installs to Claude Code (~/.claude/skills/).
    Use --target all to install to all supported tools.
    """

    def install_skill():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.install_skill(slug, target=target.value)

    console = Console()

    try:
        console.print(f"[dim]Installing skill '{slug}'...[/dim]")
        installed_paths = run_progress_task(install_skill)

        console.print(f"\n[green]✓[/green] Skill '{slug}' installed successfully!\n")

        for target_name, path in installed_paths.items():
            console.print(f"  [cyan]{target_name}[/cyan]: {path}")

        console.print("\n[dim]The skill is now available in your AI coding tool(s).[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to install skill: {err}")


@skills_app.command(name="uninstall")
def skills_uninstall(
    slug: str = typer.Argument(..., help="The skill slug to uninstall"),
    target: SkillTargetOption = typer.Option(
        SkillTargetOption.ALL,
        "--target",
        "-t",
        help="Target AI coding tool(s) to uninstall from",
    ),
) -> None:
    """Uninstall a skill from AI coding tools.

    By default, uninstalls from all supported tools.
    """

    def uninstall_skill():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.uninstall_skill(slug, target=target.value)

    console = Console()

    try:
        results = run_progress_task(uninstall_skill)

        removed_any = any(results.values())

        if removed_any:
            console.print(f"\n[green]✓[/green] Skill '{slug}' uninstalled:\n")
            for target_name, was_removed in results.items():
                if was_removed:
                    console.print(f"  [green]✓[/green] {target_name}")
                else:
                    console.print(f"  [dim]- {target_name} (not installed)[/dim]")
        else:
            console.print(f"[yellow]Skill '{slug}' was not installed in any location.[/yellow]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to uninstall skill: {err}")


@skills_app.command(name="installed")
def skills_installed(
    target: Optional[SkillTargetOption] = typer.Option(
        None,
        "--target",
        "-t",
        help="Show skills for specific tool only",
    ),
) -> None:
    """List locally installed skills."""

    def list_installed():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        if target:
            return {target.value: client.list_installed_skills(target=target.value)}
        return client.list_all_installed_skills()

    console = Console()

    try:
        results = run_progress_task(list_installed)

        has_any = any(skills for skills in results.values())

        if not has_any:
            console.print("[dim]No skills installed.[/dim]")
            return

        console.print("\n[bold]Installed Skills[/bold]\n")

        for target_name, skills in results.items():
            if skills:
                console.print(f"[cyan]{target_name}[/cyan]:")
                for skill_slug in skills:
                    console.print(f"  • {skill_slug}")
            else:
                console.print(f"[dim]{target_name}: (none)[/dim]")

        console.print("")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to list installed skills: {err}")


@skills_app.command(name="check")
def skills_check(
    slug: str = typer.Argument(..., help="The skill slug to check"),
) -> None:
    """Check if a skill is installed and where."""

    def check_skill():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.is_skill_installed_anywhere(slug)

    console = Console()

    try:
        results = run_progress_task(check_skill)

        installed_anywhere = any(results.values())

        if installed_anywhere:
            console.print(f"\n[green]✓[/green] Skill '{slug}' is installed:\n")
            for target_name, is_installed in results.items():
                if is_installed:
                    console.print(f"  [green]✓[/green] {target_name}")
                else:
                    console.print(f"  [dim]- {target_name}[/dim]")
        else:
            console.print(f"\n[yellow]Skill '{slug}' is not installed anywhere.[/yellow]")
            console.print(f"\n[dim]Install it with: qbraid skills install {slug}[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to check skill: {err}")


# =============================================================================
# Sharing Commands
# =============================================================================


@skills_app.command(name="share")
def skills_share(
    slug: str = typer.Argument(..., help="The skill slug to share"),
    email: str = typer.Argument(..., help="Email of user to share with"),
    write: bool = typer.Option(False, "--write", "-w", help="Grant write permission (default is read-only)"),
) -> None:
    """Share a skill with another user."""

    def share_skill():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        permissions = ["read", "write"] if write else ["read"]
        return client.share_skill(slug, email, permissions)

    console = Console()

    try:
        run_progress_task(share_skill)
        perm_str = "read/write" if write else "read"
        console.print(f"\n[green]✓[/green] Skill '{slug}' shared with {email} ({perm_str} access)")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to share skill: {err}")


@skills_app.command(name="unshare")
def skills_unshare(
    slug: str = typer.Argument(..., help="The skill slug"),
    email: str = typer.Argument(..., help="Email of user to revoke access from"),
) -> None:
    """Revoke a user's access to a skill."""

    def revoke_access():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.revoke_skill_access(slug, email, ["read", "write"])

    console = Console()

    try:
        run_progress_task(revoke_access)
        console.print(f"\n[green]✓[/green] Access revoked for {email} on skill '{slug}'")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to revoke access: {err}")


@skills_app.command(name="shared-with")
def skills_shared_with(
    slug: str = typer.Argument(..., help="The skill slug"),
) -> None:
    """List users with access to a skill."""

    def get_shared():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.get_shared_users(slug)

    console = Console()

    try:
        result = run_progress_task(get_shared)

        console.print(f"\n[bold]Users with access to '{slug}'[/bold]\n")

        if result.read_access_users:
            console.print("[cyan]Read Access:[/cyan]")
            for user in result.read_access_users:
                name = f" ({user.name})" if user.name else ""
                console.print(f"  • {user.email}{name}")

        if result.write_access_users:
            console.print("[cyan]Write Access:[/cyan]")
            for user in result.write_access_users:
                name = f" ({user.name})" if user.name else ""
                console.print(f"  • {user.email}{name}")

        if not result.read_access_users and not result.write_access_users:
            console.print("[dim]No users have been granted access.[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to get shared users: {err}")


@skills_app.command(name="share-code")
def skills_share_code(
    slug: str = typer.Argument(..., help="The skill slug"),
) -> None:
    """Generate a share code for a skill."""

    def generate_code():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.generate_share_code(slug)

    console = Console()

    try:
        result = run_progress_task(generate_code)
        console.print(f"\n[green]✓[/green] Share code generated for '{slug}':\n")
        console.print(f"  [bold cyan]{result.code}[/bold cyan]\n")
        console.print("[dim]Anyone with this code can redeem read access using:[/dim]")
        console.print(f"  qbraid skills redeem {result.code}")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to generate share code: {err}")


@skills_app.command(name="redeem")
def skills_redeem(
    code: str = typer.Argument(..., help="The share code to redeem"),
) -> None:
    """Redeem a skill share code.

    Redeems a share code to get access to a skill.
    """

    def redeem_code():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.redeem_share_code(code)

    console = Console()

    try:
        result = run_progress_task(redeem_code)

        if result.already_had_access:
            console.print(f"\n[yellow]You already have access to '{result.name}' ({result.slug})[/yellow]")
        else:
            console.print(f"\n[green]✓[/green] Access granted to '{result.name}' ({result.slug})")
            console.print(f"\n[dim]Install it with: qbraid skills install {result.slug}[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to redeem share code: {err}")


# =============================================================================
# Publishing Commands
# =============================================================================


@skills_app.command(name="request-publish")
def skills_request_publish(
    slug: str = typer.Argument(..., help="The skill slug to publish"),
) -> None:
    """Request to publish a skill publicly."""

    def request_pub():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.request_publish(slug)

    console = Console()

    try:
        run_progress_task(request_pub)
        console.print(f"\n[green]✓[/green] Publish request submitted for '{slug}'")
        console.print("[dim]Your skill will be reviewed by the qBraid team.[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to request publish: {err}")


@skills_app.command(name="revoke-publish")
def skills_revoke_publish(
    slug: str = typer.Argument(..., help="The skill slug"),
) -> None:
    """Revoke a pending publish request."""

    def revoke_pub():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.revoke_publish_request(slug)

    console = Console()

    try:
        run_progress_task(revoke_pub)
        console.print(f"\n[green]✓[/green] Publish request revoked for '{slug}'")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to revoke publish request: {err}")


# =============================================================================
# Admin Commands
# =============================================================================


@skills_app.command(name="pending-reviews")
def skills_pending_reviews(
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum number of results"),
) -> None:
    """List skills pending review (admin only)."""

    def list_pending():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.list_pending_reviews(limit=limit)

    console = Console()

    try:
        skills = run_progress_task(list_pending)

        if not skills:
            console.print("[dim]No skills pending review.[/dim]")
            return

        table = Table(title="Skills Pending Review")
        table.add_column("Slug", style="cyan", no_wrap=True)
        table.add_column("Name", style="white")
        table.add_column("Owner", style="dim")
        table.add_column("Status", style="yellow")

        for skill in skills:
            table.add_row(
                skill.slug,
                skill.name,
                skill.owner_email or "Unknown",
                skill.review_status.value if skill.review_status else "NONE",
            )

        console.print(table)

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to list pending reviews: {err}")


@skills_app.command(name="approve-publish")
def skills_approve_publish(
    slug: str = typer.Argument(..., help="The skill slug to approve"),
) -> None:
    """Approve skill publishing.

    Approves a skill for publishing (admin only).
    """

    def approve():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.approve_publish(slug)

    console = Console()

    try:
        run_progress_task(approve)
        console.print(f"\n[green]✓[/green] Skill '{slug}' approved and published!")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to approve publish: {err}")


@skills_app.command(name="deny-publish")
def skills_deny_publish(
    slug: str = typer.Argument(..., help="The skill slug to deny"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Reason for denial"),
) -> None:
    """Deny a publish request (admin only)."""

    def deny():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.deny_publish(slug, reason=reason)

    console = Console()

    try:
        run_progress_task(deny)
        console.print(f"\n[green]✓[/green] Publish request denied for '{slug}'")
        if reason:
            console.print(f"[dim]Reason: {reason}[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to deny publish: {err}")


@skills_app.command(name="mark-pending")
def skills_mark_pending(
    slug: str = typer.Argument(..., help="The skill slug"),
) -> None:
    """Mark a skill as under review (admin only)."""

    def mark():
        from qbraid_core.services.skills import SkillsClient

        client = SkillsClient()
        return client.mark_pending_review(slug)

    console = Console()

    try:
        run_progress_task(mark)
        console.print(f"\n[green]✓[/green] Skill '{slug}' marked as under review")

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to mark as pending: {err}")


# =============================================================================
# CRUD Commands
# =============================================================================


@skills_app.command(name="create")
def skills_create(
    name: str = typer.Option(..., "--name", "-n", help="Display name for the skill (1-100 chars)"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Skill description (max 500 chars)"
    ),
    version: str = typer.Option("1.0.0", "--version", "-v", help="Skill version"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags"),
    visibility: VisibilityOption = typer.Option(
        VisibilityOption.PRIVATE, "--visibility", help="Skill visibility"
    ),
    directory: Optional[str] = typer.Option(
        None, "--dir", help="Path to skill directory to upload after creation"
    ),
) -> None:
    """Create a new skill.

    Optionally upload a directory with --dir.
    """
    from pathlib import Path

    from qbraid_core.services.skills import SkillsClient
    from qbraid_core.services.skills.schemas import SkillCreateRequest
    from qbraid_core.services.skills.schemas import Visibility as CoreVisibility

    console = Console()

    tag_list = [t.strip() for t in tags.split(",")] if tags else None

    request = SkillCreateRequest(
        name=name,
        description=description,
        version=version,
        tags=tag_list,
        visibility=CoreVisibility(visibility.value),
    )

    try:
        client = SkillsClient()
        result = run_progress_task(
            client.create_skill,
            request,
            description="Creating skill...",
        )

        console.print("\n[green]✓[/green] Skill created successfully!")
        console.print(f"  Name: [bold]{result.skill.name}[/bold]")
        console.print(f"  Slug: {result.skill.slug}")

        if directory:
            skill_dir = Path(directory).resolve()
            if not skill_dir.is_dir():
                console.print(f"[red]❌ Directory not found: {skill_dir}[/red]")
                raise typer.Exit(code=1)

            upload_result = run_progress_task(
                client.upload_skill,
                result.skill.slug,
                skill_dir,
                description="Uploading skill...",
            )
            size_kb = upload_result.get("size_bytes", 0) / 1024
            console.print(f"  Uploaded: {size_kb:.1f} KB")
            console.print(f"\n[dim]Install with: qbraid skills install {result.skill.slug}[/dim]")
        else:
            if result.upload_url:
                console.print(
                    f"\n[dim]Upload your skill directory with: "
                    f"qbraid skills upload {result.skill.slug} --dir <path>[/dim]"
                )

    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to create skill: {err}")


@skills_app.command(name="upload")
def skills_upload(
    slug: str = typer.Argument(..., help="The skill slug to upload to"),
    directory: str = typer.Option(..., "--dir", help="Path to skill directory to upload"),
) -> None:
    """Upload files to a skill.

    Uploads a skill directory to an existing skill.
    """
    from pathlib import Path

    from qbraid_core.services.skills import SkillsClient

    console = Console()

    skill_dir = Path(directory).resolve()
    if not skill_dir.is_dir():
        console.print(f"[red]❌ Directory not found: {skill_dir}[/red]")
        raise typer.Exit(code=1)

    try:
        client = SkillsClient()
        result = run_progress_task(
            client.upload_skill,
            slug,
            skill_dir,
            description="Uploading skill...",
        )
        size_kb = result.get("size_bytes", 0) / 1024
        console.print(f"\n[green]✓[/green] Skill '{slug}' uploaded successfully!")
        console.print(f"  Size: {size_kb:.1f} KB")
        console.print(f"\n[dim]Install with: qbraid skills install {slug}[/dim]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        error_msg = str(err).lower()
        if "not found" in error_msg:
            console.print(f"[red]❌ Skill '{slug}' not found.[/red]")
        else:
            handle_error(message=f"Failed to upload skill: {err}")


@skills_app.command(name="update")
def skills_update(
    slug: str = typer.Argument(..., help="The skill slug to update"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New display name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="New version"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="New comma-separated tags"),
    visibility: Optional[VisibilityOption] = typer.Option(None, "--visibility", help="New visibility"),
) -> None:
    """Update skill metadata."""
    from qbraid_core.services.skills import SkillsClient

    console = Console()

    tag_list = [t.strip() for t in tags.split(",")] if tags else None

    def do_update():
        client = SkillsClient()
        return client.update_skill(
            slug,
            name=name,
            description=description,
            version=version,
            tags=tag_list,
            visibility=visibility.value if visibility else None,
        )

    try:
        run_progress_task(do_update, description="Updating skill...")

        console.print(f"\n[green]✓[/green] Skill '{slug}' updated successfully!")
        if name:
            console.print(f"  Name: [bold]{name}[/bold]")

    except Exception as err:  # pylint: disable=broad-exception-caught
        error_msg = str(err).lower()
        if "not found" in error_msg:
            console.print(f"[red]❌ Skill '{slug}' not found.[/red]")
        else:
            handle_error(message=f"Failed to update skill: {err}")


@skills_app.command(name="delete")
def skills_delete(
    slug: str = typer.Argument(..., help="The skill slug to delete"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Delete a skill (owner or admin only)."""
    from qbraid_core.services.skills import SkillsClient

    console = Console()

    if not auto_confirm:
        console.print(
            f"\n[bold red]⚠️  Warning:[/bold red] This will permanently delete "
            f"the skill [bold]{slug}[/bold].\n"
            "This operation [bold]CANNOT[/bold] be undone.\n"
        )
        if not typer.confirm("Are you sure you want to continue?"):
            raise typer.Exit()

    try:
        client = SkillsClient()
        run_progress_task(
            client.delete_skill,
            slug,
            description="Deleting skill...",
        )
        console.print(f"\n[green]✓[/green] Skill '{slug}' deleted successfully.")

    except Exception as err:  # pylint: disable=broad-exception-caught
        error_msg = str(err).lower()
        if "not found" in error_msg:
            console.print(f"[red]❌ Skill '{slug}' not found.[/red]")
        elif "permission" in error_msg or "admin" in error_msg:
            console.print("[red]❌ Permission denied. Only the owner or admin can delete this skill.[/red]")
        else:
            handle_error(message=f"Failed to delete skill: {err}")


if __name__ == "__main__":
    skills_app()
