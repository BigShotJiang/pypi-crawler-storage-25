# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid skills namespace.

"""

from .app import skills_app

__all__ = ["skills_app"]
