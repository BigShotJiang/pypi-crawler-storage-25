# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid kernels' namespace.

"""

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from qbraid_cli.handlers import handle_error, run_progress_task

kernels_app = typer.Typer(
    help=(
        "Add, remove, and repair Jupyter kernels.\n\n"
        "Manage Jupyter kernel specs for qBraid environments. Each environment\n"
        "can have its own kernel visible in JupyterLab's launcher.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Make an environment available as a Jupyter kernel\n"
        "  \u2022 Fix a broken kernel that points to a missing environment\n"
        "  \u2022 Clean up orphaned kernels from deleted environments"
    ),
    no_args_is_help=True,
)


@kernels_app.command(name="list")
def kernels_list():
    """List all available kernels."""
    from qbraid_core.services.environments.kernels import get_all_kernels

    console = Console()
    # Get the list of kernelspecs
    kernelspecs: dict = get_all_kernels()

    if len(kernelspecs) == 0:
        console.print("No qBraid kernels are active.")
        console.print("\nUse 'qbraid kernels add' to add a new kernel.")
        return

    longest_kernel_name = max(len(kernel_name) for kernel_name in kernelspecs)
    spacing = longest_kernel_name + 10

    output_lines = []
    output_lines.append("# qbraid kernels:")
    output_lines.append("#")
    output_lines.append("")

    # Ensure 'python3' kernel is printed first if it exists
    default_kernel_name = "python3"
    python3_kernel_info = kernelspecs.pop(default_kernel_name, None)
    if python3_kernel_info:
        line = f"{default_kernel_name.ljust(spacing)}{python3_kernel_info['resource_dir']}"
        output_lines.append(line)
    # print rest of the kernels
    for kernel_name, kernel_info in sorted(kernelspecs.items()):
        line = f"{kernel_name.ljust(spacing)}{kernel_info['resource_dir']}"
        output_lines.append(line)

    final_output = "\n".join(output_lines)

    console.print(final_output)


@kernels_app.command(name="add")
def kernels_add(
    environment: str = typer.Argument(
        ..., help="Name of environment for which to add ipykernel. Values from 'qbraid envs list'."
    ),
):
    """Add a kernel to Jupyter."""
    from qbraid_core.services.environments import EnvironmentRegistryManager
    from qbraid_core.services.environments.kernels import (
        add_kernels,
        ensure_ipykernel,
        is_kernel_installed,
    )

    console = Console()

    # Check if kernel is already installed
    if is_kernel_installed(environment):
        console.print(f"[yellow]⚠️  Kernel for '{environment}' is already installed.[/yellow]")
        console.print("Use 'qbraid kernels list' to see all installed kernels.")
        return

    # Get environment path from registry
    try:
        registry = EnvironmentRegistryManager()
        entry = None
        try:
            entry = registry.get_environment(environment)
        except (typer.Exit, SystemExit):
            raise
        except Exception:
            pass

        if not entry:
            result = registry.find_by_name(environment)
            if result:
                _, entry = result

        if not entry:
            console.print(f"[red]❌ Environment '{environment}' not found.[/red]")
            raise typer.Exit(1)

        env_path = Path(entry.path)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        console.print(f"[red]❌ Error looking up environment: {e}[/red]")
        raise typer.Exit(1)

    # Ensure ipykernel is installed in the environment
    console.print(f"Checking ipykernel in '{entry.name}'...")
    success, msg = ensure_ipykernel(env_path)
    if success:
        console.print(f"[green]✓[/green] {msg}")
    else:
        console.print(f"[red]✗[/red] {msg}")
        console.print("\n[yellow]Cannot add kernel without ipykernel installed.[/yellow]")
        raise typer.Exit(1)

    try:
        add_kernels(environment)
    except ValueError as e:
        handle_error(
            message=f"Failed to add kernel(s): {e}",
            include_traceback=True,
        )
        raise typer.Exit(1)

    console.print(f"[green]✅ Successfully added '{environment}' kernel(s).[/green]")
    console.print("\nUse 'qbraid kernels list' to see all installed kernels.")


@kernels_app.command(name="remove")
def kernels_remove(
    environment: str = typer.Argument(
        ...,
        help=("Name of environment for which to remove ipykernel. Values from 'qbraid envs list'."),
    ),
):
    """Remove a kernel from Jupyter."""
    from qbraid_core.services.environments.kernels import is_kernel_installed, remove_kernels

    console = Console()

    # Check if kernel is installed
    if not is_kernel_installed(environment):
        console.print(f"[yellow]⚠️  Kernel for '{environment}' is not installed.[/yellow]")
        console.print("Use 'qbraid kernels list' to see installed kernels.")
        return

    try:
        remove_kernels(environment)
    except ValueError as e:
        handle_error(
            message=f"Failed to remove kernel(s): {e}",
            include_traceback=True,
        )
        raise typer.Exit(1)

    console.print(f"[green]✅ Successfully removed '{environment}' kernel(s).[/green]")


@kernels_app.command(name="status")
def kernels_status(
    environment: str = typer.Argument(..., help="Environment name or env_id to check kernel status."),
):
    """Check kernel status for an environment."""
    from qbraid_core.services.environments import EnvironmentRegistryManager
    from qbraid_core.services.environments.kernels import (
        is_kernel_installed,
        validate_kernel,
    )

    console = Console()

    # Get environment path from registry
    try:
        registry = EnvironmentRegistryManager()
        # Try by env_id first using get_environment
        entry = None
        try:
            entry = registry.get_environment(environment)
        except Exception:
            pass

        if not entry:
            # Try by name
            result = registry.find_by_name(environment)
            if result:
                _, entry = result

        if not entry:
            console.print(f"[red]❌ Environment '{environment}' not found.[/red]")
            raise typer.Exit(1)

        env_path = Path(entry.path)
    except Exception as e:
        console.print(f"[red]❌ Error looking up environment: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"🔍 Kernel status for: [bold]{entry.name}[/bold] ({entry.env_id})\n")

    # Check if installed in Jupyter
    installed = is_kernel_installed(environment)
    if installed:
        console.print("[green]✓[/green] Kernel is installed in Jupyter")
    else:
        console.print("[yellow]○[/yellow] Kernel is NOT installed in Jupyter")

    # Validate kernel.json
    is_valid, message = validate_kernel(env_path)
    if is_valid:
        console.print(f"[green]✓[/green] {message}")
    else:
        console.print(f"[red]✗[/red] {message}")

    # Show actions
    console.print("\n[bold]Actions:[/bold]")
    if not installed:
        console.print(f"  Install: [bold]qbraid kernels add {environment}[/bold]")
    else:
        console.print(f"  Remove:  [bold]qbraid kernels remove {environment}[/bold]")
    if not is_valid:
        console.print(f"  Repair:  [bold]qbraid kernels repair {environment}[/bold]")


@kernels_app.command(name="repair")
def kernels_repair(
    environment: str = typer.Argument(..., help="Environment name or env_id to repair kernel."),
):
    """Repair a kernel's Python path.

    Fixes kernel.json with the correct Python path.
    """
    from qbraid_core.services.environments import EnvironmentRegistryManager
    from qbraid_core.services.environments.kernels import ensure_ipykernel, repair_kernel

    console = Console()

    # Get environment path from registry
    try:
        registry = EnvironmentRegistryManager()
        # Try by env_id first using get_environment
        entry = None
        try:
            entry = registry.get_environment(environment)
        except Exception:
            pass

        if not entry:
            # Try by name
            result = registry.find_by_name(environment)
            if result:
                _, entry = result

        if not entry:
            console.print(f"[red]❌ Environment '{environment}' not found.[/red]")
            raise typer.Exit(1)

        env_path = Path(entry.path)
    except Exception as e:
        console.print(f"[red]❌ Error looking up environment: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"🔧 Repairing kernel for: [bold]{entry.name}[/bold]\n")

    # Ensure ipykernel is installed
    console.print("Checking ipykernel...")
    success, msg = run_progress_task(
        ensure_ipykernel,
        env_path,
        description="Ensuring ipykernel is installed...",
        error_message="Failed to check ipykernel",
    )
    if success:
        console.print(f"[green]✓[/green] {msg}")
    else:
        console.print(f"[red]✗[/red] {msg}")
        raise typer.Exit(1)

    # Repair kernel.json
    repaired, messages = repair_kernel(env_path)
    if repaired:
        console.print(f"[green]✓[/green] Kernel repaired: {messages}")
    else:
        console.print(f"[dim]○[/dim] {messages}")

    console.print("\n[green]✅ Kernel repair completed![/green]")
    console.print(f"\nTo add kernel to Jupyter: [bold]qbraid kernels add {environment}[/bold]")


@kernels_app.command(name="clean")
def kernels_clean(
    slug: Optional[str] = typer.Argument(None, help="Kernel name to remove directly (no validation check)."),
    auto_confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Remove orphaned kernels.

    Removes kernels whose Python environment no longer exists.
    Without arguments, scans all kernels and prompts to remove broken ones.
    With a kernel name, removes it directly without checking validity.
    """
    from qbraid_core.services.environments.kernels import (
        find_orphaned_kernels,
        remove_kernel_by_name,
    )

    console = Console()

    # Direct removal by name
    if slug:
        removed = remove_kernel_by_name(slug)
        if removed:
            console.print(f"[green]✓[/green] Removed kernel '{slug}'.")
        else:
            console.print(f"[yellow]Kernel '{slug}' not found.[/yellow]")
        return

    # Scan for orphaned kernels
    console.print("Scanning kernels...")
    orphaned = find_orphaned_kernels()

    if not orphaned:
        console.print("[green]All kernels are healthy.[/green]")
        return

    console.print(f"\nFound [bold]{len(orphaned)}[/bold] orphaned kernel(s):\n")

    for k in orphaned:
        console.print(f"  [red]✗[/red] [bold]{k['name']}[/bold]")
        if k["python_path"]:
            console.print(f"    Python: {k['python_path']}")
        console.print(f"    Reason: {k['reason']}")
        console.print()

    if not auto_confirm:
        console.print("[dim]To remove one at a time: qbraid kernels clean <kernel-name>[/dim]\n")
        if not typer.confirm(f"Remove all {len(orphaned)} orphaned kernel(s)?"):
            console.print("Cancelled.")
            raise typer.Exit()

    removed_count = 0
    for k in orphaned:
        try:
            remove_kernel_by_name(k["name"])
            console.print(f"  [green]✓[/green] Removed {k['name']}")
            removed_count += 1
        except Exception as e:
            console.print(f"  [red]✗[/red] Failed to remove {k['name']}: {e}")

    console.print(f"\n[green]Cleaned {removed_count}/{len(orphaned)} kernel(s).[/green]")


if __name__ == "__main__":
    kernels_app()
