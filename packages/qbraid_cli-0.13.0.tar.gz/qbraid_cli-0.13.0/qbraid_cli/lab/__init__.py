# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid lab namespace.

"""

from .app import app as lab_app

__all__ = ["lab_app"]
