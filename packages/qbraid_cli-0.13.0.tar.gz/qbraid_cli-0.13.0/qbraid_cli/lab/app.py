# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid lab' namespace.

Uses sys.argv parsing to forward all arguments to jupyter-lab. This avoids
the Typer/Click argument interception issue where unknown --flags would be
rejected before our code runs.
"""

import os
import sys

import click
import typer

app = typer.Typer(help="Launch qBraid Lab (JupyterLab).")


@app.callback(invoke_without_command=True)
def lab_command(_ctx: typer.Context):
    """Launch qBraid Lab (JupyterLab).

    All arguments are forwarded directly to jupyter-lab.

    Examples:
        qbraid lab                           # launch with defaults\n
        qbraid lab --port 9999 --no-browser  # custom port, no browser\n
        qbraid lab --notebook-dir ~/projects # set working directory\n
        qbraid lab --dev-mode --debug        # forwarded to jupyter-lab
    """
    # Extract args after 'lab' from the original sys.argv.
    # ctx.args is empty because Typer intercepts --flags before we see them.
    # sys.argv parsing is the only reliable way to forward unknown flags.
    argv = sys.argv
    try:
        lab_index = argv.index("lab")
        jupyter_args = argv[lab_index + 1 :]
    except ValueError:
        jupyter_args = []

    try:
        os.execvp("jupyter-lab", ["jupyter-lab"] + jupyter_args)
    except FileNotFoundError:
        raise click.UsageError(
            "jupyter-lab is not installed or not on PATH. Install qBraid Lab first: pip install qbraid-lab"
        )
