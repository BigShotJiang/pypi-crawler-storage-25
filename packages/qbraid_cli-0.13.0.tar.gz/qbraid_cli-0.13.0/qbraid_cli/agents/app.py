# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Agents CLI - Monitor and manage AI coding agent sessions."""

import os
import re
import signal
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import click
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from qbraid_cli.handlers import handle_error, run_progress_task

agents_app = typer.Typer(
    help=(
        "Manage AI coding agent sessions.\n\n"
        "Launch, monitor, and control AI coding agents.\n"
        "Run Claude Code, OpenCode, or Codex in managed tmux sessions. Send\n"
        "instructions, stream transcripts, handle permissions, and orchestrate\n"
        "multiple agents \u2014 all from one place. Works locally and on remote\n"
        "compute servers via SSH.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Spin up agents on specific repos or projects\n"
        "  \u2022 Watch what agents are doing in real-time\n"
        "  \u2022 Approve or deny tool-use permissions remotely\n"
        "  \u2022 Manage agents running on cloud compute machines\n"
        "  \u2022 Resume previous coding sessions\n\n"
        "Getting started:\n"
        "  qbraid agents launch                    # Interactive launch\n"
        "  qbraid agents list                      # Show active sessions\n"
        "  qbraid agents watch <name>              # Stream live activity\n"
        '  qbraid agents send <name> --text "..."  # Send instructions'
    ),
    no_args_is_help=True,
)

hooks_app = typer.Typer(
    help="Manage agent lifecycle hooks.",
    no_args_is_help=True,
)

agents_app.add_typer(hooks_app, name="hooks")

console = Console()


def _get_registry():
    """Get AgentSessionRegistryManager instance."""
    from qbraid_core.services.agents import AgentSessionRegistryManager

    return AgentSessionRegistryManager()


def _ssh_cmd(ssh_alias: str, remote_cmd: str, timeout: int = 30) -> str:
    """Run a qbraid CLI command on a remote compute server via SSH.

    Returns stdout on success, raises typer.Exit on failure.
    """
    import subprocess as _sp

    result = _sp.run(
        ["ssh", "-o", "ConnectTimeout=10", ssh_alias, remote_cmd],
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout,
    )
    if result.returncode != 0:
        console.print(f"[red]Remote command failed: {result.stderr.strip()}[/red]")
        raise typer.Exit(code=1)
    return result.stdout


def _status_style(status_value: str) -> str:
    """Return a rich style string for a given agent status."""
    styles = {
        "working": "green",
        "waiting": "yellow",
        "idle": "dim",
        "error": "red",
        "stopped": "red",
    }
    return styles.get(status_value, "dim")


def _truncate(text: str, max_len: int = 40) -> str:
    """Truncate a string with ellipsis if it exceeds max_len."""
    if not text:
        return "-"
    if len(text) <= max_len:
        return text
    return "..." + text[-(max_len - 3) :]


def _format_timestamp(ts: Optional[float]) -> str:
    """Format a Unix timestamp to a human-readable string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromtimestamp(ts)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (OSError, ValueError):
        return "-"


def _time_ago(ts: Optional[float]) -> str:
    """Return a human-readable time-ago string like '2h ago', '3d ago'."""
    if not ts:
        return ""
    age = time.time() - ts
    if age < 0:
        return "just now"
    if age < 60:
        return f"{int(age)}s ago"
    if age < 3600:
        return f"{int(age / 60)}m ago"
    if age < 86400:
        return f"{int(age / 3600)}h ago"
    return f"{int(age / 86400)}d ago"


def _since_to_timestamp(since_str: str) -> float:
    """Parse a human-readable time window string into a Unix timestamp.

    Supported formats:
        "30m" or "30min" -> 30 minutes ago
        "1h" or "1hr"   -> 1 hour ago
        "2d"            -> 2 days ago

    Returns:
        Unix timestamp representing the start of the window.

    Raises:
        typer.BadParameter: If the format is not recognized.
    """
    match = re.match(r"^(\d+)\s*(m|min|h|hr|d)$", since_str.strip().lower())
    if not match:
        raise typer.BadParameter(f"Invalid time window: {since_str!r}. Use e.g. '30m', '1h', '2d'.")
    value = int(match.group(1))
    unit = match.group(2)
    if unit in ("m", "min"):
        seconds = value * 60
    elif unit in ("h", "hr"):
        seconds = value * 3600
    elif unit == "d":
        seconds = value * 86400
    else:
        raise typer.BadParameter(f"Invalid time unit: {unit!r}. Use 'm', 'h', or 'd'.")
    return time.time() - seconds


def _find_session_by_prefix(registry, session_id: str):
    """Find a session by ID, prefix, or name from the registry.

    Searches session_id (exact/prefix), then tmux_window and terminal_name.
    Returns the matched AgentSession or None.
    """
    all_sessions = registry.load_registry().sessions

    # Try session_id exact or prefix match first
    for s in all_sessions:
        if s.session_id == session_id or s.session_id.startswith(session_id):
            return s

    # Try name match (tmux_window or terminal_name)
    for s in all_sessions:
        if (s.tmux_window and s.tmux_window == session_id) or (
            s.terminal_name and s.terminal_name == session_id
        ):
            return s

    return None


# =============================================================================
# Register / Deregister (hidden -- called by hooks via stdin pipe)
# =============================================================================


@agents_app.command("register", hidden=True)
def agents_register():
    """Register an agent session.

    Reads session data from stdin JSON (used by hooks).
    """
    import json
    import sys

    try:
        raw = sys.stdin.read().strip()
        if not raw:
            raise typer.Exit(code=0)

        data = json.loads(raw)

        from qbraid_core.services.agents import AgentSessionRegistryManager

        registry = AgentSessionRegistryManager()
        session_id = registry.register_from_hook_payload(data)
        if session_id is None:
            raise typer.Exit(code=0)

    except (typer.Exit, SystemExit):
        raise
    except Exception:
        # Hooks must never fail visibly
        raise typer.Exit(code=0)


@agents_app.command("deregister", hidden=True)
def agents_deregister():
    """Deregister an agent session.

    Reads session data from stdin JSON (used by hooks).
    """
    import json
    import sys

    try:
        raw = sys.stdin.read().strip()
        if not raw:
            raise typer.Exit(code=0)

        data = json.loads(raw)

        from qbraid_core.services.agents import AgentSessionRegistryManager

        registry = AgentSessionRegistryManager()

        session_id = data.get("session_id", data.get("id"))
        pid = data.get("pid")

        # Try to find and deregister by session_id, then by pid
        if session_id:
            try:
                registry.deregister_session(session_id=session_id)
                raise typer.Exit(code=0)
            except Exception:
                pass

        if pid:
            session = registry.find_by_pid(int(pid))
            if session:
                registry.deregister_session(session_id=session.session_id)

    except (typer.Exit, SystemExit):
        raise
    except Exception:
        # Hooks must never fail visibly
        raise typer.Exit(code=0)


# =============================================================================
# List command
# =============================================================================


@agents_app.command("list")
def agents_list(
    tool: Optional[str] = typer.Option(None, "--tool", "-t", help="Filter by tool (claude, codeq, codex)"),
    status: Optional[str] = typer.Option(None, "--status", help="Filter by status"),
    tag: Optional[list[str]] = typer.Option(None, "--tag", help="Filter by tag (repeatable)"),
    since: Optional[str] = typer.Option(None, "--since", help="Time window (e.g., '1h', '30m', '2d')"),
    compute: Optional[str] = typer.Option(
        None, "--compute", "-c", help="SSH alias for remote compute (runs list on remote)"
    ),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Text search across name/cwd/tags"),
    all_sessions: bool = typer.Option(False, "--all", "-a", help="Include stopped sessions"),
    limit: int = typer.Option(25, "--limit", "-l", help="Entries per page", min=1),
    page: int = typer.Option(1, "--page", "-p", help="Page number (non-interactive mode)", min=1),
    sort: str = typer.Option(
        "recent", "--sort", help="Sort by: recent, oldest, name, tool, status, cwd, model"
    ),
    no_interactive: bool = typer.Option(False, "--no-interactive", help="Disable interactive pagination"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON array (for programmatic use)"),
):
    """List agent sessions.

    Use --compute to list on a remote server.
    """
    try:
        import sys

        # Remote compute: SSH and run list there
        if compute:
            import shlex
            import subprocess

            remote_flags = ["qbraid", "agents", "list", "--no-interactive"]
            if tool:
                remote_flags.extend(["--tool", shlex.quote(tool)])
            if all_sessions:
                remote_flags.append("--all")
            if since:
                remote_flags.extend(["--since", shlex.quote(since)])
            if sort != "recent":
                remote_flags.extend(["--sort", shlex.quote(sort)])
            if status:
                remote_flags.extend(["--status", shlex.quote(status)])
            if search:
                remote_flags.extend(["--search", shlex.quote(search)])
            if json_output:
                remote_flags.append("--json")
            remote_flags.extend(["--limit", str(limit)])
            remote_flags.extend(["--page", str(page)])

            console.print(f"[dim]Listing agents on {compute}...[/dim]")
            result = subprocess.run(
                ["ssh", "-o", "ConnectTimeout=10", compute, " ".join(remote_flags)],
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
            if result.returncode == 0:
                console.print(result.stdout)
            else:
                console.print(f"[red]Failed: {result.stderr.strip()}[/red]")
            return

        registry = _get_registry()
        registry.prune_dead_sessions()
        registry.refresh_discovered_sessions()

        # Also prune managed tmux sessions (dead windows, exited agents)
        try:
            from qbraid_core.services.agents import AgentLauncher

            launcher = AgentLauncher(registry=registry)
            launcher.prune_managed_sessions()
        except Exception:
            pass  # tmux may not be available

        # Parse --since flag into a unix timestamp
        since_ts = None
        if since:
            since_ts = _since_to_timestamp(since)

        sessions = registry.search_sessions(
            tool=tool,
            status=status,
            tags=tag,
            since=since_ts,
            compute_id=compute,
            text_search=search,
            include_stopped=all_sessions,
        )

        if not sessions:
            if json_output:
                print("[]")
            else:
                console.print("[dim]No matching agent sessions.[/dim]")
                console.print()
                console.print("[dim]Run 'qbraid agents discover' to scan for running agents.[/dim]")
            return

        # JSON output mode
        if json_output:
            import json as _json

            output = [s.model_dump(mode="json", by_alias=True, exclude_none=True) for s in sessions]
            print(_json.dumps(output, indent=2))
            return

        # Sort
        sort_key = sort.lower()
        if sort_key in ("recent", "newest"):
            sessions.sort(key=lambda s: s.last_activity or s.started_at or 0, reverse=True)
        elif sort_key in ("oldest", "old"):
            sessions.sort(key=lambda s: s.last_activity or s.started_at or 0)
        elif sort_key == "name":
            sessions.sort(key=lambda s: (s.tmux_window or s.terminal_name or "zzz").lower())
        elif sort_key == "tool":
            sessions.sort(key=lambda s: s.tool.value if s.tool else "zzz")
        elif sort_key == "status":
            order = {"working": 0, "waiting": 1, "idle": 2, "error": 3, "stopped": 4}
            sessions.sort(key=lambda s: order.get(s.status.value if s.status else "idle", 9))
        elif sort_key in ("cwd", "folder", "project"):
            sessions.sort(key=lambda s: (s.cwd or "zzz").lower())
        elif sort_key == "model":
            sessions.sort(key=lambda s: (s.model_name or "zzz").lower())

        total = len(sessions)
        total_pages = (total + limit - 1) // limit
        title_suffix = "All" if all_sessions else "Active"

        # Interactive mode: default on when stdout is a terminal
        interactive = not no_interactive and sys.stdout.isatty() and total_pages > 1

        def _render_page(pg: int) -> None:
            start = (pg - 1) * limit
            end = start + limit
            page_sessions = sessions[start:end]

            page_info = f" · page {pg}/{total_pages}" if total_pages > 1 else ""
            table = Table(title=f"{title_suffix} Agent Sessions ({total}){page_info}")
            table.add_column("Session ID", style="cyan", no_wrap=True)
            table.add_column("Name", no_wrap=True)
            table.add_column("Tool")
            table.add_column("Status")
            table.add_column("Model")
            table.add_column("Project / CWD")
            table.add_column("PID", justify="right")

            for s in page_sessions:
                sid = s.session_id[:8] if s.session_id else "-"
                name_val = s.tmux_window or s.terminal_name or ""
                # Clean up legacy "external-XXXXX" names
                if name_val.startswith("external-"):
                    name_val = ""
                # Truncate long titles
                if name_val and len(name_val) > 25:
                    name_val = name_val[:22] + "..."
                # Fallback: use last folder from CWD
                if not name_val and s.cwd:
                    name_val = Path(s.cwd).name
                tool_val = s.tool.value if s.tool else "-"
                status_val = s.status.value if s.status else "idle"
                style = _status_style(status_val)

                # Add time-ago to status
                age_ts = s.last_activity or s.started_at
                age_str = _time_ago(age_ts)
                status_display = f"[{style}]{status_val}[/{style}]"
                if age_str:
                    status_display += f" [dim]({age_str})[/dim]"

                model = s.model_name or "-"
                cwd_val = _truncate(s.cwd or "", max_len=40)
                pid = str(s.pid) if s.pid else "-"

                table.add_row(
                    sid,
                    name_val,
                    tool_val,
                    status_display,
                    model,
                    cwd_val,
                    pid,
                )

            console.print(table)
            console.print(f"[dim]Showing {start + 1}-{min(end, total)} of {total}[/dim]")

        if interactive:
            current_page = 1
            while True:
                _render_page(current_page)
                if current_page >= total_pages:
                    break
                try:
                    choice = console.input("[dim]\\[n]ext / \\[p]rev / \\[q]uit: [/dim]").strip().lower()
                except (KeyboardInterrupt, EOFError):
                    break
                if choice in ("n", "next", ""):
                    current_page = min(current_page + 1, total_pages)
                elif choice in ("p", "prev"):
                    current_page = max(current_page - 1, 1)
                elif choice in ("q", "quit"):
                    break
        else:
            _render_page(page)
            if total_pages > 1:
                console.print(f"[dim]Use --page {page + 1} for next page, or remove --no-interactive.[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Discover command
# =============================================================================


@agents_app.command("discover")
def agents_discover(
    full: bool = typer.Option(False, "--full", "-f", help="Full data enrichment for all sessions (slower)"),
    compute: Optional[str] = typer.Option(
        None, "--compute", "-c", help="Sync sessions from remote compute server (SSH alias)"
    ),
):
    """Discover new agent sessions.

    Scans transcript files and registers new agent sessions.
    """
    try:
        from functools import partial

        from qbraid_core.services.agents import AgentSessionRegistryManager, detect_sessions

        registry = AgentSessionRegistryManager()
        registry.prune_dead_sessions()

        # Remote compute: run discover on the remote machine
        if compute:
            console.print(f"[dim]Discovering sessions on {compute}...[/dim]")
            remote_flags = "qbraid agents discover"
            if full:
                remote_flags += " --full"
            try:
                output = _ssh_cmd(compute, remote_flags, timeout=120)
                console.print(output)
            except (typer.Exit, SystemExit):
                pass
            except Exception as e:
                console.print(f"[red]Remote discover failed: {e}[/red]")
            return

        desc = (
            "Scanning for agent sessions (full enrichment)..." if full else "Scanning for agent sessions..."
        )
        discovered = run_progress_task(
            partial(detect_sessions, enrich_all=full),
            description=desc,
            include_error_traceback=False,
        )

        if not discovered:
            console.print("[dim]No agent sessions found.[/dim]")
            return

        registered_count = registry.merge_discovered_sessions(discovered)

        table = Table(title=f"Discovered Sessions ({len(discovered)})")
        table.add_column("Session ID", style="cyan", no_wrap=True)
        table.add_column("Tool")
        table.add_column("Status")
        table.add_column("Model")
        table.add_column("Project / CWD")

        for s in discovered:
            sid = s.session_id[:8] if s.session_id else "-"
            tool_val = s.tool.value if s.tool else "-"
            status_val = s.status.value if s.status else "idle"
            style = _status_style(status_val)
            model = s.model_name or "-"
            cwd = _truncate(s.cwd or "", max_len=40)

            table.add_row(
                sid,
                tool_val,
                f"[{style}]{status_val}[/{style}]",
                model,
                cwd,
            )

        console.print(table)

        if registered_count > 0:
            console.print(f"\n[green]{registered_count} session(s) registered.[/green]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Status command
# =============================================================================


@agents_app.command("status")
def agents_status(
    session_id: str = typer.Argument(..., help="Session ID (full or prefix)"),
):
    """Show detailed status for an agent session."""
    try:
        from qbraid_core.services.agents import AgentSessionRegistryManager

        registry = AgentSessionRegistryManager()

        # Support prefix and name matching
        match = None
        all_sessions = registry.load_registry().sessions

        for s in all_sessions:
            if s.session_id == session_id or s.session_id.startswith(session_id):
                match = s
                break

        # Also try name matching
        if not match:
            match = _find_session_by_prefix(registry, session_id)

        if not match:
            console.print(f"[red]Session not found: {session_id}[/red]")
            console.print("[dim]Use 'qbraid agents list' to see active sessions.[/dim]")
            raise typer.Exit(code=1)

        # Build detail lines
        s = match
        status_val = s.status.value if s.status else "idle"
        style = _status_style(status_val)

        lines = []
        lines.append(f"[bold]Session ID:[/bold]  {s.session_id}")
        name_val = s.tmux_window or s.terminal_name
        if name_val:
            lines.append(f"[bold]Name:[/bold]        {name_val}")
        lines.append(f"[bold]Tool:[/bold]        {s.tool.value if s.tool else '-'}")
        lines.append(f"[bold]PID:[/bold]         {s.pid or '-'}")
        lines.append(f"[bold]Status:[/bold]      [{style}]{status_val}[/{style}]")
        lines.append(f"[bold]Model:[/bold]       {s.model_name or '-'}")
        lines.append(f"[bold]CWD:[/bold]         {s.cwd or '-'}")

        # Tmux info
        if s.tmux_session:
            lines.append(f"[bold]Tmux:[/bold]        {s.tmux_session}:{s.tmux_window or '-'}")

        # Compute info
        if s.compute_id:
            lines.append(f"[bold]Compute:[/bold]     {s.compute_id}")
            if s.cluster_id:
                lines.append(f"[bold]Cluster:[/bold]     {s.cluster_id}")

        # Git info
        if s.git:
            lines.append(f"[bold]Git Branch:[/bold]  {s.git.branch or '-'}")
            if s.git.remote_url:
                lines.append(f"[bold]Remote:[/bold]      {s.git.remote_url}")
            if s.git.is_worktree:
                lines.append("[bold]Worktree:[/bold]    yes")

        # Cost and tokens
        if s.cost_usd is not None:
            lines.append(f"[bold]Cost (USD):[/bold]  ${s.cost_usd:.4f}")
        if s.total_tokens is not None:
            lines.append(f"[bold]Tokens:[/bold]      {s.total_tokens:,}")

        # MCP servers
        if s.mcp_servers:
            lines.append(f"[bold]MCP Servers:[/bold] {', '.join(s.mcp_servers)}")

        # Tags
        if s.tags:
            lines.append(f"[bold]Tags:[/bold]        {', '.join(s.tags)}")

        # Agent type
        if s.agent_type:
            lines.append(f"[bold]Agent Type:[/bold]  {s.agent_type}")

        # Tasks
        if s.tasks:
            lines.append("")
            lines.append("[bold]Tasks:[/bold]")
            for t in s.tasks:
                task_status = t.status or "pending"
                task_style = (
                    "green"
                    if task_status == "completed"
                    else "yellow" if task_status == "in_progress" else "dim"
                )
                active_form = f" - {t.active_form}" if t.active_form else ""
                lines.append(f"  [{task_style}]{task_status}[/{task_style}] {t.subject}{active_form}")

        # Timestamps
        lines.append("")
        lines.append(f"[bold]Started:[/bold]     {_format_timestamp(s.started_at)}")
        lines.append(f"[bold]Last Active:[/bold] {_format_timestamp(s.last_activity)}")

        # Team info
        if s.team_id:
            lines.append(f"[bold]Team ID:[/bold]    {s.team_id}")
        if s.role:
            lines.append(f"[bold]Role:[/bold]       {s.role}")

        # Transcript path
        if s.transcript_path:
            lines.append(f"[bold]Transcript:[/bold]  {s.transcript_path}")

        panel = Panel(
            "\n".join(lines),
            title=f"Agent Session [{s.session_id[:8]}]",
            border_style="cyan",
        )
        console.print(panel)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Update command
# =============================================================================


@agents_app.command("update")
def agents_update(
    session_id: str = typer.Argument(..., help="Session ID (full or prefix)"),
    tags: Optional[list[str]] = typer.Option(
        None, "--tag", help="Tag to add (can be repeated)", show_default=False
    ),
    name: Optional[str] = typer.Option(None, "--name", help="Set terminal name for the session"),
    model: Optional[str] = typer.Option(
        None, "--model", help="Set model name (e.g. claude-sonnet-4-20250514)"
    ),
    cwd: Optional[str] = typer.Option(None, "--cwd", help="Set working directory for the session"),
    status: Optional[str] = typer.Option(
        None, "--status", help="Set session status (working, waiting, idle, error, stopped)"
    ),
):
    """Update metadata fields on an agent session."""
    try:
        from qbraid_core.services.agents import (
            AgentSessionNotFoundError,
            AgentSessionRegistryManager,
        )

        registry = AgentSessionRegistryManager()

        # Support prefix and name matching
        match = _find_session_by_prefix(registry, session_id)
        if not match:
            console.print(f"[red]Session not found: {session_id}[/red]")
            console.print("[dim]Use 'qbraid agents list' to see active sessions.[/dim]")
            raise typer.Exit(code=1)
        matched_id = match.session_id
        existing_tags = match.tags or []

        # Build updates dict from provided flags
        updates: dict = {}

        if name is not None:
            updates["terminal_name"] = name

        if model is not None:
            updates["model_name"] = model

        if cwd is not None:
            updates["cwd"] = cwd

        if status is not None:
            valid_statuses = {"working", "waiting", "idle", "error", "stopped"}
            if status not in valid_statuses:
                valid_opts = ", ".join(sorted(valid_statuses))
                console.print(f"[red]Invalid status: {status!r}." f" Must be one of: {valid_opts}[/red]")
                raise typer.Exit(code=1)
            updates["status"] = status

        if tags:
            # Append new tags to existing ones, deduplicated while preserving order
            merged = list(existing_tags)
            for t in tags:
                if t not in merged:
                    merged.append(t)
            updates["tags"] = merged

        if not updates:
            console.print(
                "[yellow]No updates specified. Use --name, --model, --cwd, --status, or --tag.[/yellow]"
            )
            raise typer.Exit(code=0)

        updated = registry.update_session(matched_id, **updates)

        # Display updated session info
        status_val = updated.status.value if updated.status else "idle"
        style = _status_style(status_val)

        lines = []
        lines.append(f"[bold]Session ID:[/bold]  {updated.session_id}")
        lines.append(f"[bold]Tool:[/bold]        {updated.tool.value if updated.tool else '-'}")
        lines.append(f"[bold]Status:[/bold]      [{style}]{status_val}[/{style}]")
        lines.append(f"[bold]Model:[/bold]       {updated.model_name or '-'}")
        lines.append(f"[bold]Name:[/bold]        {updated.terminal_name or '-'}")
        lines.append(f"[bold]CWD:[/bold]         {updated.cwd or '-'}")
        if updated.tags:
            lines.append(f"[bold]Tags:[/bold]        {', '.join(updated.tags)}")

        panel = Panel(
            "\n".join(lines),
            title=f"Updated Session [{updated.session_id[:8]}]",
            border_style="green",
        )
        console.print(panel)

    except (typer.Exit, SystemExit):
        raise
    except AgentSessionNotFoundError:
        console.print(f"[red]Session not found: {session_id}[/red]")
        console.print("[dim]Use 'qbraid agents list' to see active sessions.[/dim]")
        raise typer.Exit(code=1)
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Kill command
# =============================================================================


@agents_app.command("kill")
def agents_kill(
    target: str = typer.Argument(..., help="Agent name, ID prefix, or PID"),
    force: bool = typer.Option(False, "--force", "-f", help="Use SIGKILL instead of SIGTERM"),
):
    """Stop an agent by name, session ID, or PID."""
    try:
        from qbraid_core.services.agents import AgentSessionRegistryManager

        registry = AgentSessionRegistryManager()
        all_sessions = registry.load_registry().sessions

        # Try to find sessions matching the target
        # 1. Exact PID match (if target is numeric)
        # 2. Session ID / prefix match
        # 3. Name match (tmux_window or terminal_name)
        matches = []
        target_is_pid = target.isdigit()

        if target_is_pid:
            pid_val = int(target)
            matches = [s for s in all_sessions if s.pid == pid_val]

        if not matches:
            matches = [
                s
                for s in all_sessions
                if (
                    s.session_id == target
                    or s.session_id.startswith(target)
                    or (s.tmux_window and s.tmux_window == target)
                    or (s.terminal_name and s.terminal_name == target)
                )
            ]

        if not matches:
            console.print(f"[red]No session found matching '{target}'.[/red]")
            raise typer.Exit(code=1)

        # If multiple matches, show filtered picker
        if len(matches) > 1:
            import questionary

            console.print(f"[yellow]Multiple sessions match '{target}':[/yellow]")
            choices = []
            for s in matches:
                sid = s.session_id[:8]
                tool_val = s.tool.value if s.tool else "?"
                status_val = s.status.value if s.status else "?"
                name_val = s.tmux_window or s.terminal_name or ""
                pid_display = str(s.pid) if s.pid else "-"
                cwd_display = s.cwd or ""
                if len(cwd_display) > 25:
                    cwd_display = "..." + cwd_display[-22:]
                label = (
                    f"{sid}  {tool_val:<8} {status_val:<8}" f" pid={pid_display:<6} {cwd_display}  {name_val}"
                )
                choices.append(questionary.Choice(title=label, value=s.session_id))

            selected = questionary.select(
                "Select a session to kill:",
                choices=choices,
                instruction="(use arrow keys)",
            ).ask()
            if selected is None:
                raise typer.Exit()

            matches = [s for s in matches if s.session_id == selected]

        session = matches[0]
        pid = session.pid

        # For tmux-managed sessions, kill the tmux window
        if session.tmux_session and session.tmux_window:
            try:
                import subprocess

                subprocess.run(
                    ["tmux", "kill-window", "-t", f"{session.tmux_session}:{session.tmux_window}"],
                    capture_output=True,
                    check=False,
                )
                console.print(f"[green]Killed tmux window '{session.tmux_window}'.[/green]")
            except Exception:
                pass

        # Send signal to the process if we have a valid PID
        if pid and pid > 0:
            sig = signal.SIGKILL if force else signal.SIGTERM
            sig_name = "SIGKILL" if force else "SIGTERM"
            try:
                os.kill(pid, 0)  # check alive
                os.kill(pid, sig)
                console.print(f"[green]Sent {sig_name} to process {pid}.[/green]")
            except (OSError, ProcessLookupError):
                console.print(f"[dim]Process {pid} already stopped.[/dim]")

        # Mark stopped in registry
        registry.deregister_session(session_id=session.session_id)
        console.print(
            f"[dim]Session {session.session_id[:8]} "
            f"({session.terminal_name or session.tmux_window or '-'}) stopped.[/dim]"
        )

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Launch command
# =============================================================================


def _interactive_launch(console_: Console) -> dict:
    """Walk user through agent launch interactively.

    Returns dict with keys matching launch() parameters.
    """
    import questionary

    console_.print("\n[bold]Launch an AI coding agent[/bold]\n")

    # Tool selection
    tool_choices = [
        questionary.Choice("Claude Code", value="claude"),
        questionary.Choice("Claude Code (auto-approve)", value="claude-auto"),
        questionary.Choice("OpenCode (codeq)", value="codeq"),
        questionary.Choice("Codex", value="codex"),
    ]
    tool = questionary.select(
        "Select tool:",
        choices=tool_choices,
        instruction="(use arrow keys)",
    ).ask()
    if tool is None:
        raise typer.Exit()

    # Working directory
    cwd = questionary.text(
        "Working directory:",
        default=os.getcwd(),
    ).ask()
    if cwd is None:
        raise typer.Exit()

    # GitHub repo (optional, with autocomplete)
    repo_input = None
    try:
        from qbraid_core.services.agents.launcher import list_github_repos

        console_.print("[dim]Fetching GitHub repos...[/dim]", end="")
        gh_repos = list_github_repos(limit=100)
        console_.print(
            f" [dim]({len(gh_repos)} found)[/dim]" if gh_repos else " [dim](gh not available)[/dim]"
        )

        if gh_repos:
            repo_input = questionary.autocomplete(
                "GitHub repo (optional, type to search):",
                choices=gh_repos + [""],
                default="",
                validate=lambda _: True,
            ).ask()
        else:
            repo_input = questionary.text(
                "GitHub repo URL (optional, e.g., org/repo or URL):",
                default="",
            ).ask()
    except Exception:
        repo_input = questionary.text(
            "GitHub repo URL (optional, e.g., org/repo or URL):",
            default="",
        ).ask()

    if repo_input is None:
        raise typer.Exit()

    # Agent name
    name = questionary.text(
        "Agent name (optional):",
        default="",
    ).ask()
    if name is None:
        raise typer.Exit()

    # Agent type
    type_choices = [
        questionary.Choice("worker (default)", value="worker"),
        questionary.Choice("leader", value="leader"),
        questionary.Choice("observer", value="observer"),
        questionary.Choice("reviewer", value="reviewer"),
        questionary.Choice("none", value=""),
    ]
    agent_type = questionary.select(
        "Agent type:",
        choices=type_choices,
        instruction="(use arrow keys)",
    ).ask()
    if agent_type is None:
        raise typer.Exit()

    # Instructions
    instructions = questionary.text(
        "Initial instructions (optional):",
        default="",
    ).ask()
    if instructions is None:
        raise typer.Exit()

    # Tags
    tags_str = questionary.text(
        "Tags (comma-separated, optional):",
        default="",
    ).ask()
    if tags_str is None:
        raise typer.Exit()

    return {
        "tool": tool,
        "cwd": cwd.strip() or None,
        "name": name.strip() or None,
        "instructions": instructions.strip() or None,
        "repo": repo_input.strip() or None,
        "agent_type": agent_type or None,
        "tags": [t.strip() for t in tags_str.split(",") if t.strip()] or None,
    }


def _interactive_attach(console_: Console) -> str:
    """Show interactive session picker for attach.

    Returns the selected session_id.
    """
    import questionary

    registry = _get_registry()
    sessions = registry.get_active_sessions()

    # Only show sessions with tmux info (attachable)
    tmux_sessions = [s for s in sessions if s.tmux_session and s.tmux_window]

    if not tmux_sessions:
        non_tmux_count = len(sessions) - len(tmux_sessions)
        console_.print("[yellow]No attachable sessions found.[/yellow]")
        if non_tmux_count > 0:
            console_.print(f"[dim]{non_tmux_count} active session(s) exist but have no tmux info.[/dim]")
        console_.print("[dim]Use 'qbraid agents launch' to start a managed session.[/dim]")
        raise typer.Exit()

    choices = []
    for s in tmux_sessions:
        sid = s.session_id[:8]
        tool_val = s.tool.value if s.tool else "?"
        status_val = s.status.value if s.status else "?"
        cwd_display = s.cwd or ""
        if len(cwd_display) > 35:
            cwd_display = "..." + cwd_display[-32:]
        window = s.tmux_window or ""
        label = f"{sid}  {tool_val:<8} {status_val:<8} {cwd_display:<35} {window}"
        choices.append(questionary.Choice(title=label, value=s.session_id))

    selected = questionary.select(
        "Select a session to attach:",
        choices=choices,
        instruction="(use arrow keys)",
    ).ask()
    if selected is None:
        raise typer.Exit()

    return selected


@agents_app.command("launch")
def agents_launch(
    tool: Optional[str] = typer.Option(
        None, "--tool", "-t", help="Agent tool (claude, claude-auto, codeq, codex)"
    ),
    cwd: Optional[str] = typer.Option(None, "--cwd", help="Working directory"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Agent name"),
    instructions: Optional[str] = typer.Option(None, "--instructions", "-i", help="Initial instructions"),
    repo: Optional[str] = typer.Option(
        None, "--repo", "-r", help="GitHub repo URL, org/repo, or issue/PR URL"
    ),
    agent_type: Optional[str] = typer.Option(
        None, "--type", help="Agent type: leader, worker, observer, reviewer"
    ),
    parent: Optional[str] = typer.Option(None, "--parent", help="Parent session ID"),
    team: Optional[str] = typer.Option(None, "--team", help="Team ID"),
    tag: Optional[list[str]] = typer.Option(None, "--tag", help="Tags (repeatable)"),
    compute: Optional[str] = typer.Option(
        None, "--compute", "-c", help="SSH alias for remote compute server"
    ),
):
    """Launch an AI coding agent.

    Starts the agent in a managed tmux session.
    """
    try:
        from qbraid_core.services.agents import AgentLauncher, AgentLauncherError

        # Interactive mode if no tool specified
        if tool is None:
            result = _interactive_launch(console)
            tool = result["tool"]
            cwd = cwd or result.get("cwd")
            name = name or result.get("name")
            instructions = instructions or result.get("instructions")
            agent_type = agent_type or result.get("agent_type")
            tag = tag or result.get("tags")
            repo = repo or result.get("repo")

        launcher = AgentLauncher()

        # Remote launch via SSH
        if compute:
            console.print(f"[dim]Launching on remote compute: {compute}...[/dim]")
            session = launcher.remote_launch(
                ssh_alias=compute,
                tool=tool,
                cwd=cwd,
                name=name,
                instructions=instructions,
                agent_type=agent_type,
                tags=tag,
            )
        else:

            def _clone_progress(msg: str):
                console.print(f"[dim]{msg}[/dim]")

            session = launcher.launch(
                tool=tool,
                cwd=cwd,
                name=name,
                instructions=instructions,
                repo=repo,
                agent_type=agent_type,
                parent_session_id=parent,
                team_id=team,
                tags=tag,
                progress_callback=_clone_progress if repo else None,
            )

        status_val = session.status.value if session.status else "idle"
        style = _status_style(status_val)

        lines = []
        lines.append(f"[bold]Session ID:[/bold]    {session.session_id}")
        lines.append(f"[bold]Tool:[/bold]          {session.tool.value if session.tool else '-'}")
        lines.append(f"[bold]Status:[/bold]        [{style}]{status_val}[/{style}]")
        if session.compute_id:
            lines.append(f"[bold]Compute:[/bold]       {session.compute_id}")
        lines.append(f"[bold]Tmux Session:[/bold] {session.tmux_session or '-'}")
        lines.append(f"[bold]Tmux Window:[/bold]  {session.tmux_window or '-'}")
        lines.append(f"[bold]PID:[/bold]           {session.pid or '-'}")
        lines.append(f"[bold]CWD:[/bold]           {session.cwd or '-'}")
        if session.tags:
            lines.append(f"[bold]Tags:[/bold]          {', '.join(session.tags)}")

        panel = Panel(
            "\n".join(lines),
            title=f"Launched Agent [{session.session_id[:8]}]",
            border_style="green",
        )
        console.print(panel)
        console.print()
        console.print("[dim]Attach to the tmux session with:[/dim]")
        console.print(f"  tmux attach -t {session.tmux_session}")

    except AgentLauncherError as e:
        console.print(
            Panel(
                str(e),
                title="Launch Error",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Resume command
# =============================================================================


def _interactive_resume(console_: Console) -> str:
    """Show interactive session picker for resume.

    Shows stopped and active sessions that have transcript info.
    Returns the selected session_id.
    """
    import questionary

    registry = _get_registry()
    all_sessions = registry.load_registry().sessions

    # Show sessions that could be resumed (have a session_id, prefer recent)
    resumable = sorted(
        [s for s in all_sessions if s.session_id],
        key=lambda s: s.last_activity or s.started_at or 0,
        reverse=True,
    )

    if not resumable:
        console_.print("[yellow]No sessions found to resume.[/yellow]")
        raise typer.Exit()

    # Limit to most recent 50 for usability
    resumable = resumable[:50]

    choices = []
    for s in resumable:
        sid = s.session_id[:8]
        tool_val = s.tool.value if s.tool else "?"
        status_val = s.status.value if s.status else "?"
        cwd_display = s.cwd or ""
        if len(cwd_display) > 30:
            cwd_display = "..." + cwd_display[-27:]
        name_display = s.tmux_window or s.terminal_name or ""

        # Time ago
        ts = s.last_activity or s.started_at
        age_str = ""
        if ts:
            age_s = time.time() - ts
            if age_s < 3600:
                age_str = f"{int(age_s / 60)}m ago"
            elif age_s < 86400:
                age_str = f"{int(age_s / 3600)}h ago"
            else:
                age_str = f"{int(age_s / 86400)}d ago"

        label = f"{sid}  {tool_val:<8} {status_val:<8} {cwd_display:<30} {age_str:<8} {name_display}"
        choices.append(questionary.Choice(title=label, value=s.session_id))

    selected = questionary.select(
        "Select a session to resume:",
        choices=choices,
        instruction="(use arrow keys)",
    ).ask()
    if selected is None:
        raise typer.Exit()

    return selected


@agents_app.command("resume")
def agents_resume(
    session_id: Optional[str] = typer.Argument(
        None, help="Session ID, prefix, or name. Omit for interactive picker."
    ),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Agent name for the resumed session"),
):
    """Resume a previous agent session.

    Resumes in a managed tmux window.
    """
    try:
        from qbraid_core.services.agents import AgentLauncher, AgentLauncherError

        # Interactive mode if no session_id provided
        if session_id is None:
            session_id = _interactive_resume(console)

        launcher = AgentLauncher()

        # Try resume — handle active session and ambiguous matches
        try:
            session = launcher.resume(session_id=session_id, name=name)
        except AgentLauncherError as e:
            err_msg = str(e)

            # Active session — offer attach/fork/cancel
            if err_msg.startswith("ACTIVE_SESSION:"):
                parts = err_msg.split(":")
                active_sid = parts[1]
                tmux_sess = parts[2]
                tmux_win = parts[3]

                console.print(
                    f"[yellow]Session {active_sid[:8]} is currently active "
                    f"in tmux window '{tmux_win}'.[/yellow]"
                )
                choice = (
                    console.input("  \\[a]ttach to existing / \\[f]ork as new session / \\[c]ancel: ")
                    .strip()
                    .lower()
                )

                if choice in ("a", "attach"):
                    target = f"{tmux_sess}:{tmux_win}"
                    console.print(f"[dim]Attaching to {target}... (Ctrl+b d to detach)[/dim]")
                    os.execvp("tmux", ["tmux", "attach", "-t", target])
                elif choice in ("f", "fork"):
                    # Resume with --fork flag by forcing a new session ID
                    # Mark original as still active, create a fork
                    registry = _get_registry()
                    original = None
                    for s in registry.load_registry().sessions:
                        if s.session_id == active_sid:
                            original = s
                            break
                    if original:
                        tool_value = original.tool.value if original.tool else "claude"
                        fork_name = name or f"{tmux_win}-fork"
                        # Launch fresh with same tool and cwd
                        session = launcher.launch(
                            tool=tool_value,
                            cwd=original.cwd,
                            name=fork_name,
                            instructions=None,
                        )
                    else:
                        console.print("[red]Could not find original session to fork.[/red]")
                        raise typer.Exit(code=1)
                else:
                    raise typer.Exit()

                # Skip the normal resume output below if we attached
                if choice in ("a", "attach"):
                    return

            elif "Multiple sessions match" not in err_msg:
                raise

            # Show filtered picker with only matching sessions
            import questionary

            registry = _get_registry()
            all_sessions = registry.load_registry().sessions
            matches = [
                s
                for s in all_sessions
                if (
                    s.session_id == session_id
                    or s.session_id.startswith(session_id)
                    or (s.tmux_window and s.tmux_window == session_id)
                    or (s.terminal_name and s.terminal_name == session_id)
                )
            ]
            matches.sort(key=lambda s: s.last_activity or s.started_at or 0, reverse=True)

            choices = []
            for s in matches:
                sid = s.session_id[:8]
                tool_val = s.tool.value if s.tool else "?"
                status_val = s.status.value if s.status else "?"
                cwd_display = s.cwd or ""
                if len(cwd_display) > 30:
                    cwd_display = "..." + cwd_display[-27:]
                age_str = _time_ago(s.last_activity or s.started_at)
                label = f"{sid}  {tool_val:<8} {status_val:<8} {cwd_display:<30} {age_str}"
                choices.append(questionary.Choice(title=label, value=s.session_id))

            console.print(f"[yellow]Multiple sessions match '{session_id}':[/yellow]")
            selected = questionary.select(
                "Select a session to resume:",
                choices=choices,
                instruction="(use arrow keys)",
            ).ask()
            if selected is None:
                raise typer.Exit()

            session = launcher.resume(session_id=selected, name=name)

        status_val = session.status.value if session.status else "idle"
        style = _status_style(status_val)

        lines = []
        lines.append(f"[bold]Session ID:[/bold]    {session.session_id}")
        lines.append(f"[bold]Tool:[/bold]          {session.tool.value if session.tool else '-'}")
        lines.append(f"[bold]Status:[/bold]        [{style}]{status_val}[/{style}]")
        lines.append(f"[bold]Tmux Session:[/bold] {session.tmux_session or '-'}")
        lines.append(f"[bold]Tmux Window:[/bold]  {session.tmux_window or '-'}")
        lines.append(f"[bold]CWD:[/bold]           {session.cwd or '-'}")

        panel = Panel(
            "\n".join(lines),
            title=f"Resumed Session [{session.session_id[:8]}]",
            border_style="blue",
        )
        console.print(panel)
        console.print()
        console.print("[dim]Attach with:[/dim]")
        console.print(f"  qbraid agents attach {session.tmux_window or session.session_id[:8]}")

    except AgentLauncherError as e:
        console.print(Panel(str(e), title="Resume Error", border_style="red"))
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Send command
# =============================================================================


@agents_app.command("send")
def agents_send(
    session_id: str = typer.Argument(..., help="Session ID (prefix match)"),
    text: str = typer.Option(..., "--text", "-m", help="Text to send"),
    compute: Optional[str] = typer.Option(None, "--compute", "-c", help="SSH alias for remote compute"),
):
    """Send text to a running agent's terminal."""
    try:
        if compute:
            import shlex

            _ssh_cmd(compute, f"qbraid agents send {shlex.quote(session_id)} --text {shlex.quote(text)}")
            console.print(f"[green]Sent text to session {session_id} on {compute}.[/green]")
            return

        from qbraid_core.services.agents import AgentLauncher, AgentLauncherError

        launcher = AgentLauncher()
        launcher.send(session_id, text)
        console.print(f"[green]Sent text to session {session_id}.[/green]")

    except (AgentLauncherError,) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Read command
# =============================================================================


@agents_app.command("read")
def agents_read(
    session_id: str = typer.Argument(..., help="Session ID (prefix match)"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to capture"),
    compute: Optional[str] = typer.Option(None, "--compute", "-c", help="SSH alias for remote compute"),
):
    """Read recent terminal output from an agent."""
    try:
        if compute:
            import shlex

            output = _ssh_cmd(compute, f"qbraid agents read {shlex.quote(session_id)} --lines {lines}")
            console.print(output)
            return

        from qbraid_core.services.agents import AgentLauncher, AgentLauncherError

        launcher = AgentLauncher()
        output = launcher.read(session_id, lines)
        console.print(output)

    except (AgentLauncherError,) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Approve command
# =============================================================================


@agents_app.command("approve")
def agents_approve(
    session_id: str = typer.Argument(..., help="Session ID (prefix match)"),
):
    """Approve a tool-use prompt.

    Sends 'y' + Enter to the agent's terminal.
    """
    try:
        from qbraid_core.services.agents import AgentLauncher, AgentLauncherError

        launcher = AgentLauncher()
        launcher.approve(session_id)
        console.print(f"[green]Approval sent to session {session_id}.[/green]")

    except (AgentLauncherError,) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Watch command
# =============================================================================


def _entry_style(entry_type: str) -> str:
    """Return a rich style for a transcript entry type."""
    styles = {
        "assistant_text": "green",
        "tool_call": "yellow",
        "tool_result": "cyan",
        "user_message": "blue",
        "user_text": "blue",
        "thinking": "dim",
        "turn_end": "dim",
        "status_change": "magenta",
    }
    return styles.get(entry_type, "")


def _check_permission_prompt(tmux_session: str, tmux_window: str) -> Optional[list[str]]:
    """Read the tmux pane and check for a permission prompt.

    Returns a list of option strings if a prompt is detected, None otherwise.
    """
    import subprocess

    result = subprocess.run(
        ["tmux", "capture-pane", "-t", f"{tmux_session}:{tmux_window}", "-p", "-S", "-60"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return None

    pane_text = result.stdout

    # Look for Claude's permission prompt markers
    if "Do you want to" not in pane_text and "Allow" not in pane_text:
        return None

    # Extract numbered options using regex — handles ANSI/unicode prefixes
    # Claude's format: "❯ 1. Yes" / "  2. Yes, allow..." / "  3. No"
    # Options may wrap across multiple lines in the terminal.
    options: list[str] = []
    pane_lines = pane_text.splitlines()
    for i, line in enumerate(pane_lines):
        match = re.search(r"(\d+)\.\s+(.+)", line)
        if match:
            num = int(match.group(1))
            text = match.group(2).strip()
            if num == len(options) + 1 and text:
                # Collect continuation lines (lines until next numbered option,
                # blank line, or "Esc to cancel" marker)
                for j in range(i + 1, len(pane_lines)):
                    cont = pane_lines[j].strip()
                    if not cont or re.search(r"^\d+\.", cont) or "Esc to cancel" in cont:
                        break
                    text += " " + cont
                options.append(f"{num}. {text}")

    return options if options else None


def _send_permission_choice(tmux_session: str, tmux_window: str, choice_idx: int) -> None:
    """Send arrow key presses and Enter to select a permission option."""
    import subprocess

    target = f"{tmux_session}:{tmux_window}"

    # Arrow down from position 1 (default) to the chosen option
    for _ in range(choice_idx):
        subprocess.run(["tmux", "send-keys", "-t", target, "Down"], check=False)
        time.sleep(0.05)

    subprocess.run(["tmux", "send-keys", "-t", target, "Enter"], check=False)


@agents_app.command("watch")
def agents_watch(
    session_id: str = typer.Argument(..., help="Session ID (prefix match)"),
    lines: int = typer.Option(20, "--lines", "-n", help="Initial history lines"),
    interactive: bool = typer.Option(
        True, "--interactive/--no-interactive", help="Prompt for permission decisions"
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        help="Stream-only mode: emit JSON events, no interactive prompts (for frontends)",
    ),
    compute: Optional[str] = typer.Option(None, "--compute", "-c", help="SSH alias for remote compute"),
):
    """Stream agent transcript.

    Streams live transcript from an agent session.
    """
    try:
        # Remote watch: SSH and stream from remote
        if compute:
            import shlex
            import subprocess as _sp

            remote_flags = f"qbraid agents watch {shlex.quote(session_id)} --stream --lines {lines}"
            console.print(f"[dim]Watching {session_id} on {compute}... (Ctrl+C to stop)[/dim]")

            proc = _sp.Popen(  # pylint: disable=consider-using-with
                ["ssh", "-o", "ConnectTimeout=10", compute, remote_flags],
                stdout=_sp.PIPE,
                stderr=_sp.PIPE,
                text=True,
            )
            try:
                assert proc.stdout is not None
                for line in iter(proc.stdout.readline, ""):
                    line = line.strip()
                    if not line:
                        continue
                    if stream:
                        # Pass through JSON events
                        print(line, flush=True)
                    else:
                        # Parse and render
                        try:
                            import json as _json

                            event = _json.loads(line)
                            entry_type = event.get("type", "unknown")
                            content = event.get("content", "")
                            ts = event.get("timestamp")
                            ts_str = ""
                            if ts:
                                try:
                                    ts_str = datetime.fromtimestamp(ts).strftime("%H:%M:%S") + " "
                                except (OSError, ValueError):
                                    pass
                            tool_name = event.get("tool_name", "")
                            tool_info = (
                                f" ({tool_name})"
                                if tool_name and entry_type in ("tool_call", "tool_result")
                                else ""
                            )
                            style = _entry_style(entry_type)
                            line_text = (
                                f"[dim]{ts_str}[/dim]"
                                f"[{style}]{entry_type}[/{style}]"
                                f"{tool_info}: [{style}]{content}[/{style}]"
                            )
                            console.print(line_text, highlight=False)
                        except Exception:
                            console.print(line, highlight=False)
            except KeyboardInterrupt:
                proc.terminate()
                console.print("\n[dim]Stopped watching.[/dim]")
            finally:
                proc.terminate()
                proc.wait()
            return

        from qbraid_core.services.agents import get_parser_for_tool, watch_transcript

        registry = _get_registry()
        session = _find_session_by_prefix(registry, session_id)

        if not session:
            console.print(f"[red]Session not found: {session_id}[/red]")
            console.print("[dim]Use 'qbraid agents list' to see active sessions.[/dim]")
            raise typer.Exit(code=1)

        tool_value = session.tool.value if session.tool else None

        # OpenCode uses SQLite DB instead of transcript files
        is_opencode = tool_value == "codeq"

        if not is_opencode:
            transcript_path = session.transcript_path
            if not transcript_path:
                console.print(f"[red]Session {session_id} has no transcript path.[/red]")
                raise typer.Exit(code=1)

        parser_name = get_parser_for_tool(tool_value) if tool_value and not is_opencode else None

        # Permission handling via hooks (file-based, not tmux scraping)
        can_prompt = interactive and not stream
        can_notify = stream

        # Resolve the session ID used for permission files
        perm_session_id = session.session_id

        # Register that we're watching — the PreToolUse hook checks for this
        # file before polling. If absent, hook falls through immediately.
        from qbraid_core.services.agents.permissions import start_watching, stop_watching

        if can_prompt or can_notify:
            start_watching(perm_session_id)

        if not stream:
            sid_short = session.session_id[:8]
            console.print(f"[dim]Watching transcript for session" f" {sid_short}... (Ctrl+C to stop)[/dim]")
            if can_prompt:
                console.print("[dim]Permission prompts will be shown inline (via hooks).[/dim]")
            console.print()

        # OpenCode port (used for both watch and permissions)
        oc_port = session.port if is_opencode else None

        # Choose the right watcher based on tool
        if is_opencode:
            from qbraid_core.services.agents.discovery import watch_opencode_session

            # Resolve OpenCode's native session ID from the API or DB
            # Our registry uses a UUID, but SQLite uses ses_XXXX
            oc_native_sid = session.session_id
            if oc_port:
                try:
                    from qbraid_core.services.agents.opencode_api import list_opencode_sessions

                    oc_sessions = list_opencode_sessions(oc_port)
                    # Find the most recent session in the same CWD
                    for ocs in oc_sessions:
                        if ocs.get("directory") == session.cwd:
                            oc_native_sid = ocs["id"]
                            break
                    else:
                        # Fallback: most recent session
                        if oc_sessions:
                            oc_native_sid = oc_sessions[0]["id"]
                except Exception:
                    pass

            entry_source = watch_opencode_session(
                oc_native_sid,
                initial_entries=lines,
            )
        else:
            entry_source = watch_transcript(
                Path(transcript_path),
                parser_name=parser_name,
                initial_entries=lines,
            )

        # Permission checking runs in a background thread that only DETECTS
        # requests and sets a flag. The main loop handles user interaction
        # (stdin can't be read from multiple threads safely).
        import threading

        from qbraid_core.services.agents.permissions import get_pending_request, respond_to_request

        perm_stop_event = threading.Event()
        perm_pending = threading.Event()  # Set when a permission request is detected
        perm_data: dict = {}  # Stores the current request

        # oc_port already defined above for both watch and permissions

        def _permission_detector():
            """Background thread that detects permission requests."""
            while not perm_stop_event.is_set():
                if not perm_pending.is_set():
                    request = None

                    if oc_port:
                        # OpenCode: poll HTTP API for pending permissions
                        try:
                            from qbraid_core.services.agents.opencode_api import (
                                list_pending_permissions,
                            )

                            pending = list_pending_permissions(oc_port)
                            if pending:
                                p = pending[0]
                                request = {
                                    "tool_name": p.get("permission", "tool"),
                                    "summary": ", ".join(p.get("patterns", [])),
                                    "tool_input": p.get("metadata", {}),
                                    "opencode_request_id": p.get("id"),
                                    "opencode_port": oc_port,
                                }
                        except Exception:
                            pass
                    else:
                        # Claude/Codex: check file-based permission request
                        request = get_pending_request(perm_session_id)

                    if request:
                        perm_data.update(request)
                        perm_pending.set()

                        if can_notify:
                            import json as _json

                            notification = {
                                "type": "permission_required",
                                "session_id": perm_session_id,
                                "tool_name": request.get("tool_name", "?"),
                                "summary": request.get("summary", ""),
                                "tool_input": request.get("tool_input", {}),
                            }
                            if request.get("opencode_request_id"):
                                notification["opencode_request_id"] = request["opencode_request_id"]
                                notification["opencode_port"] = oc_port
                            print(_json.dumps(notification), flush=True)

                        # Wait for main loop to clear the flag
                        while perm_pending.is_set() and not perm_stop_event.is_set():
                            time.sleep(0.5)

                time.sleep(0.5)

        if can_prompt or can_notify:
            perm_thread = threading.Thread(target=_permission_detector, daemon=True)
            perm_thread.start()

        # Main loop: interleave transcript entries with permission checks.
        # We can't block on the transcript generator because the hook blocks
        # Claude from writing entries. Instead, run the generator in a thread
        # and consume from a queue.
        import queue

        entry_queue: queue.Queue = queue.Queue()
        gen_done = threading.Event()

        def _entry_producer():
            """Feed transcript entries into the queue."""
            try:
                for entry in entry_source:
                    entry_queue.put(entry)
            except Exception:
                pass
            finally:
                gen_done.set()

        entry_thread = threading.Thread(target=_entry_producer, daemon=True)
        entry_thread.start()

        while not gen_done.is_set() or not entry_queue.empty():
            # Check for permission requests first
            if can_prompt and perm_pending.is_set():
                tool_name = perm_data.get("tool_name", "?")
                summary = perm_data.get("summary", "")

                console.print()
                console.print(f"[bold yellow]Permission required:[/bold yellow] [bold]{tool_name}[/bold]")
                console.print(f"[dim]{summary}[/dim]")
                console.print("  [bold]1.[/bold] Allow")
                console.print("  [bold]2.[/bold] Deny")
                console.print("  [bold]3.[/bold] Pass to agent (show Claude's prompt)")

                # Helper to send the permission response
                oc_req_id = perm_data.get("opencode_request_id")
                oc_req_port = perm_data.get("opencode_port")

                def _send_response(decision: str, reason: str = ""):
                    if oc_req_id and oc_req_port:
                        # OpenCode: reply via HTTP API
                        from qbraid_core.services.agents.opencode_api import reply_to_permission

                        oc_reply_map = {"allow": "once", "deny": "reject", "ask": "once"}
                        reply_to_permission(oc_req_port, oc_req_id, oc_reply_map.get(decision, "once"))
                    else:
                        # Claude: reply via file
                        respond_to_request(perm_session_id, decision, reason)

                try:
                    choice = console.input("[dim]> [/dim]").strip()
                    if choice == "1":
                        _send_response("allow")
                        console.print("[green]Allowed.[/green]")
                    elif choice == "2":
                        _send_response("deny", "Denied by user in watch mode")
                        console.print("[red]Denied.[/red]")
                    elif choice == "3":
                        _send_response("ask")
                        console.print("[dim]Passed to agent's terminal.[/dim]")
                    else:
                        _send_response("ask")
                        console.print("[dim]Invalid — passed to agent's terminal.[/dim]")
                except (KeyboardInterrupt, EOFError):
                    _send_response("ask")

                perm_pending.clear()
                perm_data.clear()
                # Delete the request file to prevent re-detection (Claude only)
                if not oc_req_id:
                    req_file = (
                        Path(os.path.expanduser("~/.qbraid/permissions")) / f"{perm_session_id}.request.json"
                    )
                    req_file.unlink(missing_ok=True)
                continue

            # Drain available transcript entries
            try:
                entry = entry_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            ts_str = ""
            if entry.timestamp:
                try:
                    dt = datetime.fromtimestamp(entry.timestamp)
                    ts_str = dt.strftime("%H:%M:%S")
                except (OSError, ValueError):
                    ts_str = ""

            entry_type = entry.type or "unknown"
            content = (entry.content or "").replace("\n", " ")
            style = _entry_style(entry_type)

            # Build the line: [timestamp] type: content
            prefix = f"[dim]{ts_str}[/dim] " if ts_str else ""
            type_label = f"[{style}]{entry_type}[/{style}]" if style else entry_type

            # Add tool name for tool_call / tool_result
            tool_info = ""
            if entry.tool_name and entry_type in ("tool_call", "tool_result"):
                tool_info = f" ({entry.tool_name})"

            if stream:
                import json as _json

                event = {
                    "type": entry_type,
                    "timestamp": entry.timestamp,
                    "content": entry.content or "",
                    "tool_name": entry.tool_name,
                    "model": entry.model,
                    "cost_usd": entry.cost_usd,
                    "token_count": entry.token_count,
                }
                print(_json.dumps({k: v for k, v in event.items() if v is not None}), flush=True)
            else:
                line = f"{prefix}{type_label}{tool_info}: [{style}]{content}[/{style}]"
                console.print(line, highlight=False)

    except KeyboardInterrupt:
        console.print("\n[dim]Stopped watching.[/dim]")
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)
    finally:
        # Stop the permission poller thread and clean up
        try:
            perm_stop_event.set()
        except Exception:
            pass
        try:
            from qbraid_core.services.agents.permissions import stop_watching

            if "perm_session_id" in dir():
                stop_watching(perm_session_id)
        except Exception:
            pass


# =============================================================================
# Attach command
# =============================================================================


@agents_app.command("attach")
def agents_attach(
    session_id: Optional[str] = typer.Argument(
        None, help="Session ID (prefix match). Omit for interactive picker."
    ),
    compute: Optional[str] = typer.Option(None, "--compute", "-c", help="SSH alias for remote compute"),
):
    """Attach to an agent's terminal.

    Opens an interactive tmux window for the agent session.
    """
    try:
        # Remote attach: SSH + tmux attach
        if compute:
            import shlex

            if session_id:
                # Attach to specific window
                console.print(f"[dim]Attaching to {session_id} on {compute}... (Ctrl+b d to detach)[/dim]")
                os.execvp(
                    "ssh",
                    [
                        "ssh",
                        "-t",
                        compute,
                        f"tmux attach -t qbraid-agents:{shlex.quote(session_id)}",
                    ],
                )
            else:
                # Attach to the tmux session (user picks window)
                console.print(f"[dim]Attaching to qbraid-agents on {compute}... (Ctrl+b d to detach)[/dim]")
                os.execvp("ssh", ["ssh", "-t", compute, "tmux attach -t qbraid-agents"])
            return

        # Interactive mode if no session_id provided
        if session_id is None:
            session_id = _interactive_attach(console)

        registry = _get_registry()
        session = _find_session_by_prefix(registry, session_id)

        if not session:
            console.print(f"[red]Session not found: {session_id}[/red]")
            console.print("[dim]Use 'qbraid agents list' to see active sessions.[/dim]")
            raise typer.Exit(code=1)

        tmux_session = session.tmux_session
        tmux_window = session.tmux_window

        if not tmux_session or not tmux_window:
            console.print(
                f"[red]Session {session.session_id[:8]} has no tmux info. "
                "It may not have been launched via 'qbraid agents launch'.[/red]"
            )
            raise typer.Exit(code=1)

        target = f"{tmux_session}:{tmux_window}"

        # Verify tmux session/window still exists before attaching
        import subprocess

        check = subprocess.run(
            ["tmux", "has-session", "-t", tmux_session],
            capture_output=True,
            check=False,
        )
        if check.returncode != 0:
            console.print(f"[red]Tmux session '{tmux_session}' no longer exists.[/red]")
            console.print("[dim]The agent may have been killed or the tmux session was closed.[/dim]")
            raise typer.Exit(code=1)

        console.print(f"[dim]Attaching to {target}... (Ctrl+b d to detach)[/dim]")

        # For remote sessions (has compute_id), SSH into the machine first
        if session.compute_id:
            alias = session.compute_id
            os.execvp("ssh", ["ssh", "-t", alias, f"tmux attach -t {target}"])
        else:
            os.execvp("tmux", ["tmux", "attach", "-t", target])

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Clean command
# =============================================================================


@agents_app.command("clean")
def agents_clean(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Clean up orphaned sessions.

    Removes orphaned tmux windows and stopped sessions.
    """
    try:
        import subprocess

        from qbraid_core.services.agents import AgentLauncher

        registry = _get_registry()
        launcher = AgentLauncher(registry=registry)

        # 1. Prune managed sessions (dead tmux windows, exited agents)
        pruned = launcher.prune_managed_sessions()
        if pruned:
            console.print(f"[green]Pruned {len(pruned)} dead managed session(s).[/green]")

        # 2. Prune PID-based dead sessions
        pruned_pids = registry.prune_dead_sessions()
        if pruned_pids:
            console.print(f"[green]Pruned {len(pruned_pids)} dead PID-based session(s).[/green]")

        # 3. Check for orphaned tmux windows (in qbraid-agents session but
        #    not tracked in registry)
        tmux_windows = launcher.list_windows()
        tracked_windows = set()
        for s in registry.load_registry().sessions:
            if s.tmux_window and s.tmux_session == "qbraid-agents":
                tracked_windows.add(s.tmux_window)

        orphaned = [
            w
            for w in tmux_windows
            if w["window_name"] != "_control" and w["window_name"] not in tracked_windows
        ]

        if orphaned:
            console.print(f"\n[yellow]Found {len(orphaned)} orphaned tmux window(s):[/yellow]")
            for w in orphaned:
                console.print(
                    f"  {w['window_name']}  (pid={w.get('pane_pid', '?')}," f" cmd={w.get('command', '?')})"
                )

            if not yes:
                try:
                    if not typer.confirm("\nKill orphaned windows?"):
                        console.print("[dim]Skipped.[/dim]")
                        return
                except click.exceptions.Abort:
                    console.print("\n[dim]Skipped.[/dim]")
                    return

            for w in orphaned:
                subprocess.run(
                    ["tmux", "kill-window", "-t", f"qbraid-agents:{w['window_name']}"],
                    capture_output=True,
                    check=False,
                )
            console.print(f"[green]Killed {len(orphaned)} orphaned window(s).[/green]")

        # 4. If qbraid-agents session is empty (only _control), kill it
        remaining = launcher.list_windows()
        if len(remaining) <= 1:  # only _control or empty
            subprocess.run(
                ["tmux", "kill-session", "-t", "qbraid-agents"],
                capture_output=True,
                check=False,
            )
            console.print("[dim]Removed empty qbraid-agents tmux session.[/dim]")

        if not pruned and not pruned_pids and not orphaned:
            console.print("[dim]Nothing to clean up.[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


# =============================================================================
# Hooks subcommands
# =============================================================================


@hooks_app.command("install")
def hooks_install(
    tool: Optional[str] = typer.Option(
        None, "--tool", "-t", help="Install hooks for a specific tool (claude, codeq, codex)"
    ),
):
    """Install agent lifecycle hooks.

    Installs hooks for AI coding tools.
    """
    try:
        if tool:
            tool = tool.lower()
            valid_tools = {"claude", "codeq", "codex"}
            if tool not in valid_tools:
                valid_opts = ", ".join(sorted(valid_tools))
                console.print(f"[red]Unknown tool: {tool}." f" Must be one of: {valid_opts}[/red]")
                raise typer.Exit(code=1)

            result = None
            if tool == "claude":
                from qbraid_core.services.agents import install_claude_hooks

                result = run_progress_task(
                    install_claude_hooks,
                    description=f"Installing hooks for {tool}...",
                    include_error_traceback=False,
                )
            elif tool == "codeq":
                from qbraid_core.services.agents import install_opencode_hooks

                result = run_progress_task(
                    install_opencode_hooks,
                    description=f"Installing hooks for {tool}...",
                    include_error_traceback=False,
                )
            elif tool == "codex":
                from qbraid_core.services.agents import install_codex_hooks

                result = run_progress_task(
                    install_codex_hooks,
                    description=f"Installing hooks for {tool}...",
                    include_error_traceback=False,
                )

            if result and result.get("status") == "installed":
                console.print(f"[green]Hooks installed for {tool}.[/green]")
                console.print(f"[dim]  {result.get('path', '')}[/dim]")
            else:
                console.print(f"[red]Failed to install hooks for {tool}.[/red]")
                raise typer.Exit(code=1)
        else:
            from qbraid_core.services.agents import install_all_hooks

            results = run_progress_task(
                install_all_hooks,
                description="Installing hooks for all tools...",
                include_error_traceback=False,
            )

            for tool_name, result in results.items():
                status = result.get("status", "unknown")
                if status == "installed":
                    console.print(f"  [green]{tool_name}[/green]: installed")
                    console.print(f"    [dim]{result.get('path', '')}[/dim]")
                elif status == "error":
                    console.print(f"  [red]{tool_name}[/red]: {result.get('error', 'unknown error')}")
                else:
                    console.print(f"  [yellow]{tool_name}[/yellow]: {status}")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)


@hooks_app.command("uninstall")
def hooks_uninstall():
    """Remove agent lifecycle hooks.

    Removes hooks from all supported tools.
    """
    try:
        from qbraid_core.services.agents import uninstall_all_hooks

        results = run_progress_task(
            uninstall_all_hooks,
            description="Removing hooks...",
            include_error_traceback=False,
        )

        for tool_name, result in results.items():
            status = result.get("status", "unknown")
            if status == "uninstalled":
                console.print(f"  [green]{tool_name}[/green]: removed")
            elif status == "not_found":
                console.print(f"  [dim]{tool_name}[/dim]: no hooks found")
            elif status == "error":
                console.print(f"  [red]{tool_name}[/red]: {result.get('error', 'unknown error')}")
            else:
                console.print(f"  [yellow]{tool_name}[/yellow]: {status}")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(message=str(e))
        raise typer.Exit(code=1)
