# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Agents CLI subcommand."""

from .app import agents_app

__all__ = ["agents_app"]
