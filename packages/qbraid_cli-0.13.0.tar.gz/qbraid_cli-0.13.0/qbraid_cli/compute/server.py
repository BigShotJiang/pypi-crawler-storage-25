# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""Server management CLI commands."""

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel

from qbraid_cli.handlers import handle_error, run_progress_task

server_app = typer.Typer(help="Manage compute servers.", no_args_is_help=True)
console = Console()

# Known user-facing errors that should be displayed cleanly (no traceback)
_USER_FACING_ERRORS = (
    "ComputePaymentRequiredError",
    "ComputeInsufficientTierError",
    "ComputePermissionError",
    "ComputeProfileNotFoundError",
)


def _is_user_facing_error(err: Exception) -> bool:
    """Check if error should be displayed without traceback."""
    return type(err).__name__ in _USER_FACING_ERRORS


def _mask_url_token(url: str) -> str:
    """Strip or mask the token query parameter from a URL for safe display."""
    import re

    return re.sub(r"([?&])token=[^&]+", r"\1token=****", url)


def _get_client():
    """Get ComputeClient instance."""
    from qbraid_core.services.compute import ComputeClient

    return ComputeClient()


@server_app.command("status")
def server_status(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    show_url: bool = typer.Option(False, "--show-url", help="Show full server URL with auth token"),
):
    """Check server status."""
    try:
        client = _get_client()

        def fetch():
            return client.get_server_status(cluster_id)

        status = run_progress_task(
            fetch,
            description="Checking server status...",
            include_error_traceback=False,
        )

        # Determine status
        if status.server_running:
            status_str = "[green]Running[/green]"
            status_icon = "[green]●[/green]"
        elif status.server_starting:
            status_str = "[yellow]Starting[/yellow]"
            status_icon = "[yellow]●[/yellow]"
        else:
            status_str = "[dim]Stopped[/dim]"
            status_icon = "[dim]○[/dim]"

        # Resolve IDE and full URL for running servers
        ide = None
        lab_url = None
        if (status.server_running or status.server_starting) and status.current_profile:
            try:
                profile = client.get_profile(status.current_profile)
                ide = profile.ide
            except Exception:
                pass

            if ide and ide != "ssh":
                # BMA clusters: URL is already in server status response
                if status.url:
                    lab_url = status.url
                else:
                    # Legacy clusters: build URL from session token
                    try:
                        token_resp = client.get_session_token(cluster_id)
                        hub_domain = f"{token_resp.cluster_id}.qbraid.com"
                        username = status.user_info.name if status.user_info else token_resp.token.user
                        lab_url = (
                            f"https://{hub_domain}/user/{username}" f"/lab?token={token_resp.token.token}"
                        )
                    except Exception:
                        pass

        # Build status panel
        lines = [
            f"Status:   {status_icon} {status_str}",
            f"Cluster:  {status.cluster_id}",
        ]

        if status.current_profile:
            lines.append(f"Profile:  [cyan]{status.current_profile}[/cyan]")

        if lab_url:
            display_url = lab_url if show_url else _mask_url_token(lab_url)
            lines.append(f"URL:      [link={lab_url}]{display_url}[/link]")

        if status.server_details:
            if status.server_details.started:
                lines.append(f"Started:  {status.server_details.started}")

        if status.user_info:
            lines.append(f"User:     {status.user_info.name}")

        panel = Panel(
            "\n".join(lines),
            title="Server Status",
            border_style="cyan" if status.server_running else "dim",
        )
        console.print(panel)

        if status.server_running:
            console.print()
            console.print("[dim]SSH:[/dim] qbraid compute ssh setup")
            console.print("[dim]Stop:[/dim] qbraid compute server stop")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=not _is_user_facing_error(e))
        raise typer.Exit(code=1)


@server_app.command("start")
def server_start(
    profile_slug: str = typer.Argument(..., help="Profile slug to start"),
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for server to be ready"),
    timeout: int = typer.Option(120, "--timeout", "-t", help="Wait timeout in seconds"),
    ssh: bool = typer.Option(False, "--ssh", help="Configure SSH after start"),
):
    """Start a server with the specified profile."""
    try:
        client = _get_client()

        def start():
            return client.start_server(profile_slug, cluster_id)

        response = run_progress_task(
            start,
            description=f"Starting server with '{profile_slug}'...",
            include_error_traceback=False,
        )

        console.print(f"[green]{response.message}[/green]")
        console.print(f"  Profile: {response.profile}")
        console.print(f"  Cluster: {response.cluster_id}")
        console.print(f"  Status: {response.status}")

        if wait:
            console.print()

            def wait_ready():
                return client.wait_for_server(timeout=timeout, cluster_id=cluster_id)

            try:
                status = run_progress_task(
                    wait_ready,
                    description="Waiting for server to be ready...",
                    include_error_traceback=False,
                )

                if status.server_details and status.server_details.url:
                    console.print(f"  URL: {status.server_details.url}")

            except TimeoutError:
                console.print(f"[yellow]Server did not start within {timeout}s[/yellow]")
                console.print("Check status: qbraid compute server status")
                raise typer.Exit(code=1)

        if ssh:
            console.print()
            console.print("Configuring SSH...")

            status = client.get_server_status(cluster_id)
            token = None
            username = None
            hub_host = None

            if status.url:
                import re
                from urllib.parse import parse_qs, urlparse

                parsed = urlparse(status.url)
                token = parse_qs(parsed.query).get("token", [None])[0]
                hub_host = parsed.hostname

                user_match = re.search(r"/user/(.+?)/(lab|ssh|tree|vscode)(\?|$)", parsed.path)
                if user_match:
                    username = user_match.group(1)

            if not username:
                username = status.user_info.name if status.user_info else None

            if not token or not username:
                console.print("[yellow]Could not extract token for SSH setup.[/yellow]")
                console.print("Run 'qbraid compute ssh setup' manually.")
                raise typer.Exit(code=1)

            from qbraid_core.services.compute import setup_qbraid_ssh

            ssh_config = setup_qbraid_ssh(
                username=username,
                token=token,
                hub_domain=hub_host,
            )

            console.print("[green]SSH configured![/green]")
            console.print()
            console.print(f"  SSH:    [cyan]{ssh_config['ssh_command']}[/cyan]")
            console.print(f"  VSCode: [dim]{ssh_config['vscode_command']}[/dim]")
            console.print(f"  Cursor: [dim]{ssh_config['cursor_command']}[/dim]")

        else:
            console.print()
            console.print("[dim]Configure SSH: qbraid compute ssh setup[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=not _is_user_facing_error(e))
        raise typer.Exit(code=1)


@server_app.command("stop")
def server_stop(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Stop the current server."""
    if not force:
        confirm = typer.confirm("Stop the running server?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(code=0)

    try:
        client = _get_client()

        def stop():
            return client.stop_server(cluster_id)

        response = run_progress_task(
            stop,
            description="Stopping server...",
            include_error_traceback=False,
        )

        console.print(f"[green]{response.message}[/green]")
        console.print(f"  Cluster: {response.cluster_id}")
        console.print(f"  Status: {response.status}")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=not _is_user_facing_error(e))
        raise typer.Exit(code=1)


@server_app.command("url")
def server_url(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
):
    """Print the full server URL with auth token.

    Use this to get a clickable URL for browser access or to pass
    the token to other tools. The token is intentionally shown in full.
    """
    try:
        client = _get_client()
        status = client.get_server_status(cluster_id)

        if not status.server_running:
            console.print("[dim]No server running.[/dim]")
            raise typer.Exit(code=1)

        lab_url = status.url
        if not lab_url:
            try:
                token_resp = client.get_session_token(cluster_id)
                hub_domain = f"{token_resp.cluster_id}.qbraid.com"
                username = status.user_info.name if status.user_info else token_resp.token.user
                lab_url = f"https://{hub_domain}/user/{username}/lab?token={token_resp.token.token}"
            except Exception:
                pass

        if lab_url:
            console.print(lab_url)
        else:
            console.print("[yellow]Could not resolve server URL.[/yellow]")
            raise typer.Exit(code=1)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=not _is_user_facing_error(e))
        raise typer.Exit(code=1)


@server_app.command("stop-all")
def server_stop_all(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Stop all servers across all organizations."""
    if not force:
        confirm = typer.confirm("Stop ALL running servers?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(code=0)

    try:
        client = _get_client()

        def stop():
            return client.stop_all_servers(cluster_id)

        run_progress_task(
            stop,
            description="Stopping all servers...",
            include_error_traceback=False,
        )

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=not _is_user_facing_error(e))
        raise typer.Exit(code=1)
