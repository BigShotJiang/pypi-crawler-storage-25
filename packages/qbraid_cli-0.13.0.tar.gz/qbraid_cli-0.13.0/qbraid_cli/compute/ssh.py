# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""SSH configuration and connection CLI commands."""

import os
import subprocess
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from qbraid_cli.handlers import handle_error, run_progress_task

ssh_app = typer.Typer(help="SSH access to compute servers.", no_args_is_help=True)
console = Console()


def _get_client():
    """Get ComputeClient instance."""
    from qbraid_core.services.compute import ComputeClient

    return ComputeClient()


@ssh_app.command("setup")
def ssh_setup(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    tool: Optional[str] = typer.Option(
        None,
        "--tool",
        "-t",
        help="Configure for specific tool: vscode, cursor, claude-code, codex",
    ),
    alias: Optional[str] = typer.Option(
        None, "--alias", "-a", help="SSH config alias (default: qbraid-{cluster})"
    ),
):
    """Configure SSH for the server.

    Sets up SSH config with a ProxyCommand that tunnels SSH through
    the jupyter-server-proxy WebSocket endpoint. No websocat required.
    """
    try:
        client = _get_client()

        # Check if server is running
        console.print("Checking server status...")
        status = client.get_server_status(cluster_id)

        if not status.server_running:
            console.print("[yellow]No server is currently running.[/yellow]")
            console.print("Start a server first: qbraid compute server start <profile>")
            raise typer.Exit(code=1)

        # Extract token, hostname, and user path from server status URL
        # URL format: https://<host>/user/<username>/s-<session>/<ide>?token=<token>
        console.print("Getting session token...")
        token = None
        username = None
        resolved_cluster = status.cluster_id
        hub_host = None

        if status.url:
            import re
            from urllib.parse import parse_qs, urlparse

            parsed = urlparse(status.url)
            token = parse_qs(parsed.query).get("token", [None])[0]
            hub_host = parsed.hostname

            # Extract user path prefix: everything between /user/ and /lab or /ssh or end
            # e.g., /user/507f1f-kanavs/s-0e146b01/lab → 507f1f-kanavs/s-0e146b01
            user_match = re.search(r"/user/(.+?)/(lab|ssh|tree|vscode)(\?|$)", parsed.path)
            if user_match:
                username = user_match.group(1)
            else:
                # Fallback: use user_info.name
                username = status.user_info.name if status.user_info else None

        if not token:
            console.print("[red]Could not extract token from server URL.[/red]")
            raise typer.Exit(code=1)
        if not username:
            console.print("[red]Could not determine username from server status.[/red]")
            raise typer.Exit(code=1)

        # Get IDE type from the running profile
        ide = "lab"  # default
        if status.current_profile:
            try:
                profile = client.get_profile(status.current_profile)
                ide = profile.ide or "lab"
            except Exception:
                pass  # Fall back to "lab"

        # Configure SSH (generates key, registers with pod, writes config)
        from qbraid_core.services.compute import setup_qbraid_ssh

        console.print("Configuring SSH...")
        ssh_config = setup_qbraid_ssh(
            username=username,
            token=token,
            cluster_id=resolved_cluster,
            host_alias=alias,
            ide=ide,
            hub_domain=hub_host,
        )

        console.print()
        console.print("[bold green]SSH configured![/bold green]")

        if ssh_config.get("key_generated"):
            console.print(f"[dim]Generated new SSH key: {ssh_config['identity_file']}[/dim]")
        else:
            console.print(f"[dim]Using existing SSH key: {ssh_config['identity_file']}[/dim]")

        console.print()

        # Show connection commands
        panel_lines = [
            "[bold]SSH:[/bold]",
            f"  {ssh_config['ssh_command']}",
            "",
            "[bold]SFTP:[/bold]",
            f"  {ssh_config['sftp_command']}",
            "",
            "[bold]VSCode:[/bold]",
            f"  {ssh_config['vscode_command']}",
            "",
            "[bold]Cursor:[/bold]",
            f"  {ssh_config['cursor_command']}",
        ]

        panel = Panel(
            "\n".join(panel_lines),
            title="Connection Commands",
            border_style="green",
        )
        console.print(panel)

        console.print()
        console.print(f"[dim]Config file: {ssh_config['config_file']}[/dim]")

        # Tool-specific setup
        if tool:
            console.print()
            _configure_tool(tool, ssh_config)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e), include_traceback=False)
        raise typer.Exit(code=1)


def _configure_tool(tool: str, ssh_config: dict):
    """Configure a specific remote development tool."""
    tool = tool.lower()
    host_alias = ssh_config["host_alias"]

    if tool == "vscode":
        console.print("[bold]VSCode Remote-SSH Setup:[/bold]")
        console.print("1. Install 'Remote - SSH' extension")
        console.print("2. Press Ctrl+Shift+P, type 'Remote-SSH: Connect to Host'")
        console.print(f"3. Select '{host_alias}'")
        console.print()
        console.print(f"Or run: {ssh_config['vscode_command']}")

    elif tool == "cursor":
        console.print("[bold]Cursor Remote Setup:[/bold]")
        console.print("1. Open Cursor")
        console.print("2. Press Ctrl+Shift+P, type 'Remote-SSH: Connect to Host'")
        console.print(f"3. Select '{host_alias}'")
        console.print()
        console.print(f"Or run: {ssh_config['cursor_command']}")

    elif tool == "claude-code":
        console.print("[bold]Claude Code Remote Setup:[/bold]")
        console.print(f"Run: claude --remote {host_alias}")

    elif tool == "codex":
        console.print("[bold]Codex Remote Setup:[/bold]")
        console.print(f"Use SSH host: {host_alias}")

    else:
        console.print(f"[yellow]Unknown tool: {tool}[/yellow]")
        console.print("Supported tools: vscode, cursor, claude-code, codex")


@ssh_app.command("connect")
def ssh_connect(
    alias: Optional[str] = typer.Option(
        None, "--alias", "-a", help="SSH config alias (auto-detected if not set)"
    ),
):
    """SSH into the running server.

    This opens an interactive SSH session to the server.
    """
    try:
        from qbraid_core.services.compute.ssh import (
            get_qbraid_ssh_config_path,
            list_pod_ssh_configs,
        )

        config_path = get_qbraid_ssh_config_path()
        if not config_path.exists():
            console.print("[yellow]SSH not configured.[/yellow]")
            console.print("Run 'qbraid compute ssh setup' first.")
            raise typer.Exit(code=1)

        # Auto-detect alias if not provided
        if alias is None:
            aliases = list_pod_ssh_configs()
            if not aliases:
                console.print("[yellow]No SSH hosts configured.[/yellow]")
                console.print("Run 'qbraid compute ssh setup' first.")
                raise typer.Exit(code=1)
            if len(aliases) == 1:
                alias = aliases[0]
            else:
                console.print("[yellow]Multiple SSH hosts configured:[/yellow]")
                for a in aliases:
                    console.print(f"  {a}")
                console.print()
                console.print("Use --alias to specify which host to connect to.")
                raise typer.Exit(code=1)

        content = config_path.read_text()
        # Match exact Host entry (not substrings)
        import re as _re

        if not _re.search(rf"^Host\s+{_re.escape(alias)}\s*$", content, _re.MULTILINE):
            console.print(f"[yellow]SSH alias '{alias}' not found.[/yellow]")
            console.print("Run 'qbraid compute ssh setup' first.")
            raise typer.Exit(code=1)

        # Execute SSH
        console.print(f"Connecting to {alias}...")
        os.execvp("ssh", ["ssh", alias])

    except FileNotFoundError:
        console.print("[red]SSH client not found.[/red]")
        raise typer.Exit(code=1)
    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@ssh_app.command("token")
def ssh_token(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    raw: bool = typer.Option(False, "--raw", "-r", help="Output raw token only"),
):
    """Get SSH session token.

    Retrieves a JupyterHub session token for SSH access.
    """
    try:
        client = _get_client()

        def fetch():
            return client.get_session_token(cluster_id)

        token_resp = run_progress_task(
            fetch,
            description="Getting session token...",
            include_error_traceback=False,
        )

        if raw:
            console.print(token_resp.token.token)
        else:
            console.print("\n[bold]Session Token[/bold]")
            console.print()
            console.print(f"  Token: [cyan]{token_resp.token.token[:20]}...[/cyan]")
            console.print(f"  User: {token_resp.token.user}")
            console.print(f"  Cluster: {token_resp.cluster_id}")
            console.print(f"  Scopes: {', '.join(token_resp.token.scopes)}")

            if token_resp.token.expires_at:
                console.print(f"  Expires: {token_resp.token.expires_at}")

            console.print()
            console.print("[dim]Use --raw to output only the token value[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@ssh_app.command("config")
def ssh_config(
    edit: bool = typer.Option(False, "--edit", "-e", help="Open config in editor"),
):
    """Show or edit SSH configuration."""
    try:
        from qbraid_core.services.compute.ssh import (
            get_qbraid_ssh_config_path,
            list_pod_ssh_configs,
        )

        config_path = get_qbraid_ssh_config_path()

        if edit:
            editor = os.environ.get("EDITOR", "nano")
            if config_path.exists():
                subprocess.run([editor, str(config_path)], check=False)
            else:
                console.print("[yellow]No SSH config exists yet.[/yellow]")
                console.print("Run 'qbraid compute ssh setup' first.")
            return

        # Show config
        if not config_path.exists():
            console.print("[dim]No qBraid SSH config found.[/dim]")
            console.print(f"Config path: {config_path}")
            console.print()
            console.print("Run 'qbraid compute ssh setup' to configure SSH.")
            return

        content = config_path.read_text()
        aliases = list_pod_ssh_configs()

        console.print("[bold]SSH Configuration[/bold]")
        console.print(f"[dim]File: {config_path}[/dim]")
        console.print()

        if aliases:
            table = Table(title="Configured Hosts")
            table.add_column("Alias", style="cyan")
            table.add_column("Status", style="green")

            for alias in aliases:
                table.add_row(alias, "Configured")

            console.print(table)
        else:
            console.print("[dim]No hosts configured.[/dim]")

        console.print()
        console.print("[bold]Config Contents:[/bold]")
        console.print(content)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@ssh_app.command("remove")
def ssh_remove(
    alias: str = typer.Argument(..., help="SSH alias to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Remove SSH configuration for a host."""
    if not force:
        confirm = typer.confirm(f"Remove SSH config for '{alias}'?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(code=0)

    try:
        from qbraid_core.services.compute.ssh import remove_pod_ssh_config

        # Extract slug from alias if it starts with "qbraid-"
        slug = alias
        if alias.startswith("qbraid-"):
            slug = alias[7:]  # Remove "qbraid-" prefix

        removed = remove_pod_ssh_config(slug)

        if removed:
            console.print(f"[green]Removed SSH config for '{alias}'.[/green]")
        else:
            console.print(f"[yellow]SSH config for '{alias}' not found.[/yellow]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)
