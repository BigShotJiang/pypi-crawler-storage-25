# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""Profile management CLI commands."""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from qbraid_cli.handlers import handle_error, run_progress_task

profiles_app = typer.Typer(help="Manage compute profiles.", no_args_is_help=True)
console = Console()


def _get_client():
    """Get ComputeClient instance."""
    from qbraid_core.services.compute import ComputeClient

    return ComputeClient()


@profiles_app.command("list")
def profiles_list(
    plan: Optional[str] = typer.Option(None, "--plan", "-p", help="Filter by plan tier"),
    gpu: Optional[bool] = typer.Option(None, "--gpu", "-g", help="Filter GPU profiles"),
    has_capacity: Optional[bool] = typer.Option(None, "--has-capacity", "-c", help="Filter by capacity"),
    cluster_id: Optional[str] = typer.Option(None, "--cluster", help="Filter by cluster"),
    limit: int = typer.Option(50, "--limit", "-l", help="Results per page"),
):
    """List available compute profiles."""
    try:
        client = _get_client()

        def fetch():
            return client.list_profiles(
                plan=plan,
                gpu=gpu,
                has_capacity=has_capacity,
                cluster_id=cluster_id,
                limit=limit,
            )

        profiles = run_progress_task(
            fetch,
            description="Fetching profiles...",
            include_error_traceback=False,
        )

        if not profiles:
            console.print("No profiles found.")
            return

        table = Table(title="Compute Profiles")
        table.add_column("Slug", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("Plan", style="yellow")
        table.add_column("Type", style="magenta")
        table.add_column("GPU", style="green")
        table.add_column("Capacity", style="blue")

        for profile in profiles:
            gpu_str = "Yes" if profile.gpu else "No"
            capacity_str = "Yes" if profile.has_capacity else "No"
            profile_type = getattr(profile, "profile_type", "global")
            if hasattr(profile_type, "value"):
                profile_type = profile_type.value

            table.add_row(
                profile.slug,
                profile.display_name or profile.slug,
                getattr(profile, "plan", "-") or "-",
                profile_type,
                gpu_str,
                capacity_str,
            )

        console.print(table)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@profiles_app.command("info")
def profiles_info(
    slug: str = typer.Argument(..., help="Profile slug"),
):
    """Get detailed profile information."""
    try:
        client = _get_client()

        def fetch():
            return client.get_profile(slug)

        profile = run_progress_task(
            fetch,
            description=f"Fetching profile '{slug}'...",
            include_error_traceback=False,
        )

        console.print(f"\n[bold cyan]{profile.display_name}[/bold cyan] ({profile.slug})")
        console.print()

        if profile.description:
            console.print(f"{profile.description}")
            console.print()

        # Basic info
        console.print(f"[dim]Plan:[/dim] {profile.plan or 'N/A'}")
        console.print(f"[dim]Visibility:[/dim] {profile.visibility}")
        console.print(f"[dim]GPU:[/dim] {'Yes' if profile.gpu else 'No'}")
        console.print(f"[dim]IDE:[/dim] {profile.ide}")
        console.print(f"[dim]Cluster:[/dim] {profile.cluster_id or 'Default'}")
        console.print(f"[dim]Has Capacity:[/dim] {'Yes' if profile.has_capacity else 'No'}")

        # Resources
        if profile.resources:
            console.print()
            console.print("[bold]Resources:[/bold]")
            console.print(f"  CPU: {profile.resources.cpu.guarantee} - {profile.resources.cpu.limit} cores")
            console.print(
                f"  Memory: {profile.resources.memory.guarantee} - {profile.resources.memory.limit}"
            )

        # Pricing
        if profile.pricing:
            console.print()
            console.print("[bold]Pricing:[/bold]")
            if profile.pricing.is_free:
                console.print("  Free")
            else:
                console.print(f"  ${profile.pricing.rate_dollar}/{profile.pricing.rate_time_frame}")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@profiles_app.command("create-try")
def profiles_create_try(
    image: str = typer.Option(..., "--image", "-i", help="Base Docker image (required)"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Display name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    cpu: Optional[float] = typer.Option(None, "--cpu", help="CPU cores (guarantee and limit)"),
    memory: Optional[str] = typer.Option(None, "--mem", "-m", help="Memory (e.g., '8G')"),
    gpu: bool = typer.Option(False, "--gpu", "-g", help="Enable GPU"),
    ide: str = typer.Option("lab", "--ide", help="IDE type: lab, vscode, ssh"),
    features: Optional[str] = typer.Option(None, "--features", "-f", help="Features (e.g., 'claude,codeq')"),
):
    """Create a try-mode profile.

    Standard+ plan required.
    Try-mode profiles use on-the-fly overlay injection - no build step required.
    """
    try:
        client = _get_client()

        def create():
            return client.create_try_profile(
                base_image=image,
                display_name=name,
                description=description,
                cpu_guarantee=cpu,
                cpu_limit=cpu,
                mem_guarantee=memory,
                mem_limit=memory,
                gpu=gpu,
                ide=ide,
                features=features,
            )

        response = run_progress_task(
            create,
            description="Creating try-mode profile...",
            include_error_traceback=False,
        )

        console.print()
        console.print("[bold green]Profile created![/bold green]")
        console.print(f"  Slug: [cyan]{response.slug}[/cyan]")
        console.print(f"  Type: {response.profile_type.value}")
        console.print(f"  Image: {response.image}")
        console.print(f"  IDE: {response.ide}")
        console.print(f"  Has Capacity: {'Yes' if response.has_capacity else 'No'}")
        console.print()
        console.print(f"Start with: [dim]qbraid compute server start {response.slug}[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@profiles_app.command("create-save")
def profiles_create_save(
    image: str = typer.Option(..., "--image", "-i", help="Base Docker image (required)"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Display name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    cpu: Optional[float] = typer.Option(None, "--cpu", help="CPU cores (guarantee and limit)"),
    memory: Optional[str] = typer.Option(None, "--mem", "-m", help="Memory (e.g., '8G')"),
    gpu: bool = typer.Option(False, "--gpu", "-g", help="Enable GPU"),
    ide: str = typer.Option("lab", "--ide", help="IDE type: lab, vscode, ssh"),
    features: Optional[str] = typer.Option(None, "--features", "-f", help="Features (e.g., 'claude,codeq')"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for build to complete"),
    timeout: int = typer.Option(600, "--timeout", "-t", help="Build timeout in seconds"),
):
    """Create a save-mode profile.

    Pro+ plan required.
    Save-mode profiles trigger a Cloud Build to create a permanent overlay image.
    Use --wait to wait for the build to complete.
    """
    try:
        client = _get_client()

        def create():
            return client.create_save_profile(
                base_image=image,
                display_name=name,
                description=description,
                cpu_guarantee=cpu,
                cpu_limit=cpu,
                mem_guarantee=memory,
                mem_limit=memory,
                gpu=gpu,
                ide=ide,
                features=features,
            )

        response = run_progress_task(
            create,
            description="Creating save-mode profile...",
            include_error_traceback=False,
        )

        console.print()
        console.print("[bold green]Profile created![/bold green]")
        console.print(f"  Slug: [cyan]{response.slug}[/cyan]")
        console.print(f"  Type: {response.profile_type.value}")
        console.print(f"  Base Image: {response.base_image}")

        if response.build_info:
            console.print(f"  Build ID: {response.build_info.build_id}")
            console.print(f"  Build Status: [yellow]{response.build_info.status.value}[/yellow]")
            if response.build_info.log_url:
                console.print(f"  Build Logs: {response.build_info.log_url}")

        if wait and response.build_info:
            console.print()
            console.print("Waiting for build to complete...")

            def wait_build():
                return client.wait_for_build(response.slug, timeout=timeout)

            try:
                final_status = run_progress_task(
                    wait_build,
                    description="Building...",
                    include_error_traceback=False,
                )
                console.print(f"  Final Status: [green]{final_status.build_info.status.value}[/green]")
            except TimeoutError:
                console.print("[yellow]Build timed out. Check status with:[/yellow]")
                console.print(f"  qbraid compute profiles build-status {response.slug}")
            except Exception as build_err:
                console.print(f"[red]Build failed: {build_err}[/red]")

        else:
            console.print()
            console.print(
                "Check build status:" f" [dim]qbraid compute profiles build-status {response.slug}[/dim]"
            )

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@profiles_app.command("build-status")
def profiles_build_status(
    slug: str = typer.Argument(..., help="Profile slug"),
):
    """Check build status for a save-mode profile."""
    try:
        client = _get_client()

        def fetch():
            return client.get_build_status(slug)

        status = run_progress_task(
            fetch,
            description="Checking build status...",
            include_error_traceback=False,
        )

        console.print(f"\n[bold]Build Status for {slug}[/bold]")
        console.print()

        build = status.build_info
        status_color = {
            "SUCCESS": "green",
            "FAILURE": "red",
            "TIMEOUT": "red",
            "CANCELLED": "yellow",
            "QUEUED": "blue",
            "WORKING": "cyan",
        }.get(build.status.value, "white")

        console.print(f"  Status: [{status_color}]{build.status.value}[/{status_color}]")
        console.print(f"  Build ID: {build.build_id}")

        if build.start_time:
            console.print(f"  Started: {build.start_time}")
        if build.finish_time:
            console.print(f"  Finished: {build.finish_time}")
        if build.log_url:
            console.print(f"  Logs: {build.log_url}")

        console.print()
        console.print(f"  Image: {status.image}")
        console.print(f"  Has Capacity: {'Yes' if status.has_capacity else 'No'}")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@profiles_app.command("delete")
def profiles_delete(
    slug: str = typer.Argument(..., help="Profile slug to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a user-owned profile."""
    if not force:
        confirm = typer.confirm(f"Delete profile '{slug}'?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(code=0)

    try:
        client = _get_client()

        def delete():
            return client.delete_profile(slug)

        response = run_progress_task(
            delete,
            description=f"Deleting profile '{slug}'...",
            include_error_traceback=False,
        )

        if response.deleted:
            console.print(f"[green]Profile '{slug}' deleted.[/green]")
        else:
            console.print(f"[yellow]Profile '{slug}' was not deleted.[/yellow]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)
