# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""Compute CLI - Manage profiles, servers, and SSH access."""

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from qbraid_cli.handlers import handle_error, run_progress_task

from .profiles import profiles_app
from .server import server_app
from .ssh import ssh_app

compute_app = typer.Typer(
    help=(
        "Manage cloud compute and SSH.\n\n"
        "Manage cloud compute servers, profiles, and SSH access.\n"
        "Start GPU or CPU servers on qBraid infrastructure. SSH in from any\n"
        "terminal, connect your IDE (VS Code, Cursor), or launch AI agents\n"
        "on remote hardware. Persistent storage across sessions.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Run heavy workloads on cloud GPUs without local setup\n"
        "  \u2022 SSH into a cloud dev environment from your terminal\n"
        "  \u2022 Connect VS Code or Cursor to a remote server\n"
        "  \u2022 Launch AI agents on more powerful hardware\n\n"
        "Quick start:\n"
        "  qbraid compute up <profile>    # Start server + configure SSH\n"
        "  qbraid compute status          # Check server status\n"
        "  qbraid compute ssh connect     # SSH into running server\n"
        "  qbraid compute down            # Stop server"
    ),
    no_args_is_help=True,
)
console = Console()

# Add subcommand groups
compute_app.add_typer(profiles_app, name="profiles")
compute_app.add_typer(server_app, name="server")
compute_app.add_typer(ssh_app, name="ssh")


def _get_client():
    """Get ComputeClient instance."""
    from qbraid_core.services.compute import ComputeClient

    return ComputeClient()


# =============================================================================
# Convenience Commands
# =============================================================================


@compute_app.command("up")
def compute_up(
    profile_slug: str = typer.Argument(..., help="Profile slug to start"),
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    timeout: int = typer.Option(120, "--timeout", "-t", help="Server start timeout"),
    no_ssh: bool = typer.Option(False, "--no-ssh", help="Skip SSH configuration"),
):
    """Start server and configure SSH.

    Waits for the server to be ready. This is a convenience command that combines:
    - qbraid compute server start <profile> --wait
    - qbraid compute ssh setup

    Example:
        qbraid compute up 2vCPU_4GB
    """
    try:
        client = _get_client()

        # Check if server is already running
        status = client.get_server_status(cluster_id)
        if status.server_running:
            console.print(f"[yellow]Server already running with profile: {status.current_profile}[/yellow]")
            console.print()
            if not no_ssh:
                console.print("Configuring SSH...")
                _setup_ssh(client, cluster_id)
            return

        # Start server
        console.print(f"Starting server with profile '[cyan]{profile_slug}[/cyan]'...")

        def start():
            return client.start_server(profile_slug, cluster_id)

        run_progress_task(
            start,
            description="Starting...",
            include_error_traceback=False,
        )

        # Wait for server
        def wait():
            return client.wait_for_server(timeout=timeout, cluster_id=cluster_id)

        try:
            status = run_progress_task(
                wait,
                description="Waiting for server to be ready...",
                include_error_traceback=False,
            )
        except TimeoutError:
            console.print(f"[yellow]Server did not start within {timeout}s[/yellow]")
            console.print("Check status: qbraid compute server status")
            raise typer.Exit(code=1)

        # Configure SSH
        if not no_ssh:
            console.print()
            _setup_ssh(client, cluster_id)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


def _setup_ssh(client, cluster_id: Optional[str]):
    """Configure SSH for the running server."""
    from qbraid_core.services.compute import setup_qbraid_ssh

    token_resp = client.get_session_token(cluster_id)
    status = client.get_server_status(cluster_id)
    username = status.user_info.name if status.user_info else token_resp.token.user

    ssh_config = setup_qbraid_ssh(
        username=username,
        token=token_resp.token.token,
        cluster_id=token_resp.cluster_id,
    )

    # Show connection info
    panel_lines = [
        "[bold cyan]SSH[/bold cyan]",
        f"  {ssh_config['ssh_command']}",
        "",
        "[bold blue]VSCode[/bold blue]",
        f"  {ssh_config['vscode_command']}",
        "",
        "[bold magenta]Cursor[/bold magenta]",
        f"  {ssh_config['cursor_command']}",
    ]

    panel = Panel(
        "\n".join(panel_lines),
        title="Connect with",
        border_style="green",
    )
    console.print(panel)


@compute_app.command("down")
def compute_down(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    cleanup_ssh: bool = typer.Option(False, "--cleanup-ssh", help="Remove SSH config"),
):
    """Stop the running server.

    Example:
        qbraid compute down
        qbraid compute down --cleanup-ssh
    """
    try:
        client = _get_client()

        # Check if server is running
        status = client.get_server_status(cluster_id)
        if not status.server_running and not status.server_starting:
            console.print("[dim]No server is currently running.[/dim]")
            return

        if not force:
            profile = status.current_profile or "unknown"
            confirm = typer.confirm(f"Stop server (profile: {profile})?")
            if not confirm:
                console.print("Cancelled.")
                raise typer.Exit(code=0)

        # Stop server
        def stop():
            return client.stop_server(cluster_id)

        run_progress_task(
            stop,
            description="Stopping server...",
            include_error_traceback=False,
        )

        # Cleanup SSH if requested
        if cleanup_ssh:
            from qbraid_core.services.compute.ssh import remove_pod_ssh_config

            # Remove default qbraid-lab config
            removed = remove_pod_ssh_config("lab")
            if removed:
                console.print("[dim]SSH config removed.[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@compute_app.command("status")
def compute_status(
    cluster_id: Optional[str] = typer.Option(None, "--cluster", "-c", help="Cluster ID"),
):
    """Check server status.

    Quick status check (alias for 'server status').
    """
    try:
        client = _get_client()

        status = client.get_server_status(cluster_id)

        if status.server_running:
            console.print(f"[green]●[/green] Running: [cyan]{status.current_profile}[/cyan]")

            # Show clickable URL for non-SSH IDE profiles
            ide = None
            if status.current_profile:
                try:
                    profile = client.get_profile(status.current_profile)
                    ide = profile.ide
                except Exception:
                    pass

            if ide and ide != "ssh":
                lab_url = status.url if status.url else None
                if not lab_url:
                    try:
                        token_resp = client.get_session_token(cluster_id)
                        hub_domain = f"{token_resp.cluster_id}.qbraid.com"
                        username = status.user_info.name if status.user_info else token_resp.token.user
                        lab_url = (
                            f"https://{hub_domain}/user/{username}" f"/lab?token={token_resp.token.token}"
                        )
                    except Exception:
                        pass
                if lab_url:
                    from .server import _mask_url_token

                    console.print(f"  [link={lab_url}]{_mask_url_token(lab_url)}[/link]")
        elif status.server_starting:
            console.print("[yellow]●[/yellow] Starting...")
        else:
            console.print("[dim]○[/dim] No server running")
            console.print()
            console.print("[dim]Start with: qbraid compute up <profile>[/dim]")

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@compute_app.command("list")
def compute_list(
    gpu: bool = typer.Option(False, "--gpu", "-g", help="Show only GPU profiles"),
    available: bool = typer.Option(False, "--available", "-a", help="Show only available profiles"),
    limit: int = typer.Option(20, "--limit", "-l", help="Number of results"),
):
    """List compute profiles.

    Quick list profiles (alias for 'profiles list').
    """
    from .profiles import profiles_list

    profiles_list(
        plan=None,
        gpu=gpu if gpu else None,
        has_capacity=True if available else None,
        cluster_id=None,
        limit=limit,
    )


# =============================================================================
# Sessions & Usage Commands
# =============================================================================


@compute_app.command("sessions")
def compute_sessions(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of sessions to show"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (active, ended)"),
    session_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type (cpu, gpu)"),
    days: Optional[int] = typer.Option(None, "--days", "-d", help="Show sessions from last N days"),
):
    """List compute sessions."""
    try:
        client = _get_client()

        sessions = run_progress_task(
            lambda: client.list_sessions(limit=limit, status=status, session_type=session_type, days=days),
            description="Fetching sessions...",
        )

        if not sessions:
            console.print("[dim]No sessions found.[/dim]")
            return

        table = Table(title=f"Compute Sessions (showing {len(sessions)})")
        table.add_column("Profile", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Type")
        table.add_column("vCPUs", justify="right")
        table.add_column("Duration", justify="right")
        table.add_column("Credits", justify="right")
        table.add_column("Started")

        for s in sessions:
            status_style = "green" if s.status == "active" else "dim"
            duration = f"{s.total_minutes:.0f}m" if s.total_minutes else "-"
            credits_balance = f"{s.total_credits_charged:.2f}" if s.total_credits_charged else "0.00"
            started = s.start_time.strftime("%Y-%m-%d %H:%M") if s.start_time else "-"

            table.add_row(
                s.profile_slug or "-",
                f"[{status_style}]{s.status or '-'}[/{status_style}]",
                s.session_type or "-",
                str(s.v_cpus or "-"),
                duration,
                credits_balance,
                started,
            )

        console.print(table)

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)


@compute_app.command("usage")
def compute_usage(
    days: Optional[int] = typer.Option(None, "--days", "-d", help="Number of days (default: 30)"),
    timezone: Optional[str] = typer.Option(None, "--tz", help="Timezone (e.g. America/New_York)"),
    daily: bool = typer.Option(False, "--daily", help="Show daily breakdown"),
):
    """Show compute usage summary."""
    try:
        client = _get_client()

        usage = run_progress_task(
            lambda: client.get_usage(days=days, timezone=timezone),
            description="Fetching usage data...",
        )

        # Summary
        if usage.summary:
            s = usage.summary
            console.print()
            console.print("[bold]Compute Usage Summary[/bold]")
            console.print()
            console.print(f"  Total sessions:       {s.total_sessions}")
            console.print(f"    CPU:                {s.cpu_sessions}")
            console.print(f"    GPU:                {s.gpu_sessions}")
            console.print(f"  Total hours:          {s.total_hours:.2f}")
            console.print(f"  Compute hours used:   {s.total_compute_hours_deducted:.2f}")
            console.print(f"  Credits charged:      {s.total_credits_charged:.2f}")

        # Compute hours balance
        if usage.compute_hours:
            ch = usage.compute_hours
            console.print()
            console.print("[bold]Compute Hours[/bold]")
            if "total" in ch:
                console.print(f"  Total:     {ch['total']:.2f}")
            if "used" in ch:
                console.print(f"  Used:      {ch['used']:.2f}")
            if "remaining" in ch:
                console.print(f"  Remaining: {ch['remaining']:.2f}")

        # Daily breakdown
        if daily and usage.daily:
            console.print()
            table = Table(title="Daily Breakdown")
            table.add_column("Date")
            table.add_column("Hours", justify="right")
            table.add_column("Sessions", justify="right")
            table.add_column("Credits", justify="right")

            for d in usage.daily:
                table.add_row(
                    d.date,
                    f"{d.total_hours:.2f}",
                    str(d.session_count),
                    f"{d.credits_charged:.2f}",
                )

            console.print(table)

        console.print()

    except (typer.Exit, SystemExit):
        raise
    except Exception as e:
        handle_error(str(e))
        raise typer.Exit(code=1)
