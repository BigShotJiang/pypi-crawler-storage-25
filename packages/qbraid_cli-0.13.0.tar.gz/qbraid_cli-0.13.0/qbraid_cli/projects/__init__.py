# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid projects namespace

"""

from .app import projects_app

__all__ = ["projects_app"]
