# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid projects' namespace.

"""

from typing import Any, Optional

import typer
from rich.console import Console

from qbraid_cli.handlers import handle_error, print_formatted_data, run_progress_task

projects_app = typer.Typer(
    help=(
        "Browse and install qBraid Hub projects.\n\n"
        "Hub projects are GitHub-hosted templates with optional pre-configured\n"
        "environments. Use 'qbraid projects install <slug>' to clone a project\n"
        "and install its environments in one step."
    ),
    no_args_is_help=True,
)


@projects_app.command(name="list")
def projects_list(
    search: Optional[str] = typer.Option(
        None, "--search", "-s", help="Search query across title and description"
    ),
    featured: bool = typer.Option(False, "--featured", "-f", help="Show only featured projects"),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category"),
    visibility: Optional[str] = typer.Option(
        None, "--visibility", "-v", help="Filter by visibility: 'public' or 'private'"
    ),
) -> None:
    """List qBraid Hub projects."""
    console = Console()

    def fetch_projects():
        from qbraid_core.services.projects import ProjectsClient

        client = ProjectsClient()
        return client.list_projects(
            search=search,
            featured=featured if featured else None,
            category=category,
            visibility=visibility,
        )

    try:
        projects = run_progress_task(fetch_projects, description="Fetching projects...")
    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to list projects: {err}")
        return

    if not projects:
        console.print("[dim]No projects found.[/dim]")
        return

    from rich.table import Table

    table = Table(title=f"qBraid Hub Projects ({len(projects)})")
    table.add_column("Slug", style="cyan", no_wrap=True)
    table.add_column("Title")
    table.add_column("Envs")
    table.add_column("GitHub")

    for proj in projects:
        slug = proj.get("slug", "-")
        title = proj.get("title", "-")
        env_slugs = proj.get("envSlugs") or []
        envs = str(len(env_slugs)) if env_slugs else "-"
        github_url = proj.get("githubUrl", "") or ""
        repo = "/".join(github_url.rstrip("/").split("/")[-2:]) if github_url else "-"
        table.add_row(slug, title, envs, repo)

    console.print(table)


@projects_app.command(name="get")
def projects_get(
    slug: str = typer.Argument(..., help="The slug of the project to fetch."),
    fmt: bool = typer.Option(True, "--no-fmt", help="Disable rich formatting (output raw data)"),
) -> None:
    """Get project metadata.

    Fetches metadata for a single qBraid Hub project.
    """

    def fetch_project():
        from qbraid_core.services.projects import ProjectsClient

        client = ProjectsClient()
        return client.get_project(slug)

    try:
        project: dict[str, Any] = run_progress_task(
            fetch_project, description=f"Fetching project '{slug}'..."
        )
    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Failed to fetch project '{slug}': {err}")
        return

    print_formatted_data(project, fmt)


@projects_app.command(name="install")
def projects_install(
    slug: str = typer.Argument(..., help="The slug of the project to install."),
    target_dir: Optional[str] = typer.Option(
        None,
        "--target-dir",
        "-t",
        help="Directory to clone the project into (defaults to ~/).",
    ),
    no_envs: bool = typer.Option(
        False,
        "--no-envs",
        help="Skip installing the project's associated environments.",
    ),
) -> None:
    """Install a Hub project.

    Clone the repo and install envs.
    Automatically handles platform and Python version mismatches:
    - Platform mismatch: creates a similar local environment instead
    - Python mismatch + uv available: installs the required Python, then downloads
    - Python mismatch + no uv: creates a similar local environment instead
    """
    console = Console()

    from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.percentage:>3.0f}%"),
        console=console,
        transient=False,
    )

    task_id = progress.add_task("Starting...", total=100)

    def on_progress(step: str, percent: int, message: str) -> None:
        progress.update(task_id, description=f"[{step}] {message}", completed=percent)

    try:
        with progress:
            from qbraid_core.services.projects import (
                ProjectInstallError,
                ProjectNotFoundError,
                ProjectsClient,
            )

            client = ProjectsClient()
            result = client.install_project(
                slug=slug,
                target_dir=target_dir,
                install_envs=not no_envs,
                progress_callback=on_progress,
            )
            progress.update(task_id, completed=100)
    except ProjectNotFoundError as err:
        handle_error(message=f"Project '{slug}' not found: {err}")
        return
    except ProjectInstallError as err:
        handle_error(message=f"Install failed: {err}")
        return
    except Exception as err:  # pylint: disable=broad-exception-caught
        handle_error(message=f"Unexpected error: {err}")
        return

    project = result.get("project", {})
    title = project.get("title", slug)
    clone_path = result.get("clone_path", "?")
    envs_installed = result.get("envs_installed", [])
    env_errors = result.get("env_errors", [])

    console.print()
    console.print(f"[green]\u2713[/green] Installed project [bold]{title}[/bold]")
    console.print(f"  Cloned to: [cyan]{clone_path}[/cyan]")
    if envs_installed:
        console.print(f"  Envs installed: [green]{', '.join(envs_installed)}[/green]")
    if env_errors:
        console.print("  [yellow]Some environments failed to install:[/yellow]")
        for err_entry in env_errors:
            console.print(f"    \u2022 {err_entry.get('slug', '?')}: {err_entry.get('error', '?')}")


if __name__ == "__main__":
    projects_app()
