# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid pip namespace

"""

from .app import pip_app

__all__ = ["pip_app"]
