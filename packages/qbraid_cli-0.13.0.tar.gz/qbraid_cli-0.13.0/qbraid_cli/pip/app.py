# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid pip' namespace.

"""

import subprocess
import sys
from pathlib import Path

import typer
from qbraid_core.system.exceptions import QbraidSystemError
from qbraid_core.system.executables import get_active_python_path

from qbraid_cli.handlers import handle_error
from qbraid_cli.pip.hooks import get_env_cfg_path, safe_set_include_sys_packages

pip_app = typer.Typer(help="Run pip command in active qBraid environment.", no_args_is_help=True)


def _get_env_id_from_python_path(python_exe: Path) -> str | None:
    """Extract env_id from python executable path if it's a qBraid environment."""
    try:
        from qbraid_core.services.environments import EnvironmentRegistryManager

        registry = EnvironmentRegistryManager()
        return registry.find_env_by_python_path(python_exe)
    except Exception:  # pylint: disable=broad-exception-caught
        return None


def _update_registry_after_install(env_id: str) -> None:
    """Update registry with current packages after pip install."""
    try:
        from qbraid_core.services.environments import update_registry_packages

        update_registry_packages(env_id)
    except Exception:  # pylint: disable=broad-exception-caught
        pass  # Silently fail - don't break pip install if registry update fails


@pip_app.command("install", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def pip_install(ctx: typer.Context):
    """Run pip install in environment.

    Performs pip install action with open-ended arguments and options.
    """
    try:
        python_exe = get_active_python_path()
        cfg_path = get_env_cfg_path(python_exe)
    except QbraidSystemError:
        python_exe = Path(sys.executable)
        cfg_path = None

    # Get env_id before install for registry update
    env_id = _get_env_id_from_python_path(python_exe) if python_exe else None

    safe_set_include_sys_packages(False, cfg_path)

    command = [str(python_exe), "-m", "pip", "install"] + ctx.args
    success = False

    try:
        subprocess.check_call(command)
        success = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        handle_error(message="Failed carry-out pip command.")
    finally:
        safe_set_include_sys_packages(True, cfg_path)

        # Update registry with new packages if install succeeded
        if success and env_id:
            _update_registry_after_install(env_id)


if __name__ == "__main__":
    pip_app()
