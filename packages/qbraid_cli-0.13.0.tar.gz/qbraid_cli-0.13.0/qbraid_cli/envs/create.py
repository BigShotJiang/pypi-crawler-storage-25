# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module supporting 'qbraid envs create' command.

"""

from __future__ import annotations

from qbraid_core.services.environments.schema import EnvironmentConfig


def create_venv(*args, **kwargs) -> None:
    """Create a python virtual environment for the qBraid environment."""
    from qbraid_core.services.environments import create_local_venv

    return create_local_venv(*args, **kwargs)


def update_state_json(*ags, **kwargs) -> None:
    """Update the state.json file for the qBraid environment."""
    from qbraid_core.services.environments.state import update_state_json as update_state

    return update_state(*ags, **kwargs)


def create_qbraid_env_assets(
    env_id: str,
    env_id_path: str,
    env_config: EnvironmentConfig,
    kernel_logo_url: str | None = None,
    logo_url: dict | None = None,
    auto_add_kernels: bool = False,
    owner: dict | None = None,
    groups: list | None = None,
) -> None:
    """Create a qBraid environment including python venv, PS1 configs,
    kernel resource files, and qBraid state.json."""
    from qbraid_core.services.environments.create import create_qbraid_env_assets as create_assets

    return create_assets(
        env_id,
        env_id_path,
        env_config,
        kernel_logo_url=kernel_logo_url,
        logo_url=logo_url,
        auto_add_kernels=auto_add_kernels,
        owner=owner,
        groups=groups,
    )
