# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Environment group management CLI commands."""

from typing import Optional

import typer
from rich.console import Console

groups_app = typer.Typer(
    help="Manage environment groups.",
    no_args_is_help=True,
)
console = Console()


@groups_app.command("list")
def groups_list():
    """
    List all environment groups.

    Environment groups are collections of related environments. Use the group
    slug when uploading an environment to add it to a group.

    Examples:
        $ qbraid envs groups list
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    try:
        client = EnvironmentManagerClient()

        console.print("Fetching environment groups...\n")

        result = client.get_environment_groups()
        groups = result.get("environment_groups", [])

        if not groups:
            console.print("[yellow]No environment groups found.[/yellow]")
            return

        console.print(f"[bold]Environment Groups ({len(groups)}):[/bold]\n")

        for group in groups:
            name = group.get("displayName") or group.get("name", "Unnamed")
            slug = group.get("slug", "N/A")
            description = group.get("description", "")
            env_count = len(group.get("environments", []))

            console.print(f"[bold]{name}[/bold] ({slug})")
            if description:
                console.print(f"  {description[:100]}{'...' if len(description) > 100 else ''}")
            console.print(f"  Environments: {env_count}")
            console.print("")

        console.print("[dim]Use 'qbraid envs groups info <slug>' for details on a specific group.[/dim]")
        console.print("[dim]Use 'qbraid envs upload <env> --group <slug>' to add env to a group.[/dim]")

    except Exception as err:
        console.print(f"[red]Failed to fetch groups:[/red] {err}")
        raise typer.Exit(1)


@groups_app.command("info")
def groups_info(
    group_slug: str = typer.Argument(..., help="Group slug to get details for"),
):
    """Show environment group details.

    Examples:
        $ qbraid envs groups info quantum_sdk
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    try:
        client = EnvironmentManagerClient()

        console.print(f"Fetching group: [bold]{group_slug}[/bold]\n")

        try:
            group = client.get_environment_group_by_slug(group_slug)
        except Exception as err:
            console.print(f"[red]Group '{group_slug}' not found or access denied.[/red]")
            console.print(f"[dim]{err}[/dim]")
            raise typer.Exit(1)

        console.print(f"[bold]{group.get('displayName') or group.get('name', group_slug)}[/bold]")
        console.print(f"  Slug: {group.get('slug', 'N/A')}")
        if group.get("description"):
            console.print(f"  Description: {group.get('description')}")

        environments = group.get("environments", [])
        if environments:
            console.print(f"\n[bold]Environments ({len(environments)}):[/bold]")
            for env in environments:
                console.print(f"  • {env}")
        else:
            console.print("\n  [dim]No environments in this group.[/dim]")

        console.print(f"\n[dim]Use with upload: qbraid envs upload <env> --group {group_slug}[/dim]")

    except Exception as err:
        console.print(f"[red]Failed to fetch groups:[/red] {err}")
        raise typer.Exit(1)


@groups_app.command("create")
def groups_create(
    display_name: str = typer.Argument(..., help="Display name for the group (1-100 chars)"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Group description (max 500 chars)"
    ),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags"),
    category: Optional[str] = typer.Option(
        None, "--category", "-c", help="Category: 'package' or 'subject-matter'"
    ),
    visibility: Optional[str] = typer.Option(
        None, "--visibility", "-v", help="Visibility: 'private' or 'public'"
    ),
    environments: Optional[str] = typer.Option(
        None, "--envs", "-e", help="Comma-separated environment slugs to include"
    ),
    latest_env: Optional[str] = typer.Option(
        None, "--latest", "-l", help="Environment slug to set as the current version"
    ),
):
    """
    (Admin) Create a new environment group.

    Environment groups are collections of related environments, typically
    different versions of the same package or tool.

    Examples:
        $ qbraid envs groups create "Qiskit" --description "IBM Qiskit environments"
        $ qbraid envs groups create "Cirq" --category package --visibility public
        $ qbraid envs groups create "PennyLane" --envs "pen_1x0,pen_0x9" --latest pen_1x0
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    try:
        client = EnvironmentManagerClient()

        # Parse comma-separated values
        tag_list = [t.strip() for t in tags.split(",")] if tags else None
        env_list = [e.strip() for e in environments.split(",")] if environments else None

        console.print(f"Creating environment group: [bold]{display_name}[/bold]\n")

        result = client.create_environment_group(
            display_name=display_name,
            description=description,
            tags=tag_list,
            category=category,
            visibility=visibility,
            environments=env_list,
            latest_env=latest_env,
        )

        console.print("[green]✅ Environment group created successfully![/green]")
        console.print(
            f"   Name: [bold]" f"{result.get('displayName') or result.get('name', display_name)}[/bold]"
        )
        console.print(f"   Slug: {result.get('slug', 'N/A')}")
        if result.get("environments"):
            console.print(f"   Environments: {len(result.get('environments', []))}")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed to create group:[/red] {err}")
        raise typer.Exit(1)


@groups_app.command("update")
def groups_update(
    group_slug: str = typer.Argument(..., help="Slug of the group to update"),
    display_name: Optional[str] = typer.Option(None, "--name", "-n", help="New display name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    add_envs: Optional[str] = typer.Option(
        None, "--add", "-a", help="Comma-separated environment slugs to add"
    ),
    remove_envs: Optional[str] = typer.Option(
        None, "--remove", "-r", help="Comma-separated environment slugs to remove"
    ),
    latest_env: Optional[str] = typer.Option(
        None, "--latest", "-l", help="Set the current version environment slug"
    ),
    category: Optional[str] = typer.Option(
        None, "--category", "-c", help="Category: 'package' or 'subject-matter'"
    ),
    visibility: Optional[str] = typer.Option(
        None, "--visibility", "-v", help="Visibility: 'private' or 'public'"
    ),
):
    """
    (Admin) Update an environment group.

    Use --add and --remove for delta updates to the environment list.
    Use --latest to set which environment is the "current" version.

    Examples:
        $ qbraid envs groups update qiskit --add qiskit_1x0abc --latest qiskit_1x0abc
        $ qbraid envs groups update cirq --remove cirq_0x8xyz,cirq_0x7def
        $ qbraid envs groups update pennylane --name "PennyLane SDK" --visibility public
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    try:
        client = EnvironmentManagerClient()

        # Parse comma-separated values
        add_list = [e.strip() for e in add_envs.split(",")] if add_envs else None
        remove_list = [e.strip() for e in remove_envs.split(",")] if remove_envs else None

        console.print(f"Updating environment group: [bold]{group_slug}[/bold]\n")

        client.update_environment_group(
            group_slug=group_slug,
            display_name=display_name,
            description=description,
            add_envs=add_list,
            remove_envs=remove_list,
            latest_env=latest_env,
            category=category,
            visibility=visibility,
        )

        console.print("[green]✅ Environment group updated successfully![/green]")
        console.print(f"   Slug: [bold]{group_slug}[/bold]")
        if add_list:
            console.print(f"   Added: {', '.join(add_list)}")
        if remove_list:
            console.print(f"   Removed: {', '.join(remove_list)}")
        if latest_env:
            console.print(f"   Latest: {latest_env}")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed to update group:[/red] {err}")
        raise typer.Exit(1)


@groups_app.command("delete")
def groups_delete(
    group_slug: str = typer.Argument(..., help="Slug of the group to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """
    (Admin) Delete an environment group.

    This removes the group but does not delete the environments in it.

    Examples:
        $ qbraid envs groups delete old_group
        $ qbraid envs groups delete old_group --yes
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    if not yes:
        if not typer.confirm(f"Are you sure you want to delete the group '{group_slug}'?"):
            console.print("Cancelled.")
            raise typer.Exit(0)

    try:
        client = EnvironmentManagerClient()

        console.print(f"Deleting environment group: [bold]{group_slug}[/bold]\n")

        client.delete_environment_group(group_slug)

        console.print("[green]✅ Environment group deleted successfully![/green]")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed to delete group:[/red] {err}")
        raise typer.Exit(1)
