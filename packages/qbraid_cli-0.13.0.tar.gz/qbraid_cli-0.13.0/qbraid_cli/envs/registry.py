# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Local environment registry management CLI commands."""

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from qbraid_cli.handlers import handle_error, run_progress_task

registry_app = typer.Typer(
    help="Manage the local environment registry.",
    no_args_is_help=True,
)
console = Console()


@registry_app.command("add")
def registry_add(
    path: Path = typer.Argument(..., exists=True, dir_okay=True, file_okay=False),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="Alias for the environment"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Name/slug for the environment"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y"),
):
    """Register an external environment.

    Allows you to use existing Python environments (conda, venv, etc.)
    with qBraid commands like kernel management and activation.

    Examples:
        $ qbraid envs registry add /path/to/my_env --alias myenv
        $ qbraid envs registry add ~/conda/envs/quantum --name quantum_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def register():
        emc = EnvironmentManagerClient()
        result = emc.register_external_environment(
            path=path,
            name=alias or name or path.name,
        )
        return result

    # Get info first to show user
    try:
        from qbraid_core.system.executables import is_valid_python

        python_candidates = [
            path / "bin" / "python",
            path / "bin" / "python3",
            path / "Scripts" / "python.exe",
        ]

        python_path = None
        for candidate in python_candidates:
            if is_valid_python(candidate):
                python_path = candidate
                break

        if not python_path:
            handle_error(
                error_type="ValidationError",
                message=f"No valid Python executable found in {path}",
            )
            return

        # Confirm with user
        if not auto_confirm:
            console.print("\n[bold]📦 Registering external environment:[/bold]")
            console.print(f"   Path: {path}")
            console.print(f"   Name: {alias or name or path.name}")
            console.print(f"   Python: {python_path}")

            if not typer.confirm("\nProceed with registration?"):
                typer.echo("❌ Registration cancelled.")
                return

        result = run_progress_task(
            register,
            description="Registering environment...",
            error_message="Failed to register environment",
        )

        typer.echo(f"\n✅ Environment '{result['name']}' registered successfully!")
        typer.echo(f"   Env ID: {result['env_id']}")
        typer.echo("\nYou can now:")
        typer.echo(f"   - Add kernel: qbraid kernels add {result['name']}")
        typer.echo("   - View in list: qbraid envs list")

    except Exception as e:
        handle_error(message=str(e))


@registry_app.command("remove")
def registry_remove(
    name: str = typer.Argument(..., help="Name or alias of environment to unregister"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y"),
):
    """Unregister an external environment.

    This only removes the environment from qBraid's registry.
    The actual environment files are NOT deleted.
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def unregister(slug: str):
        emc = EnvironmentManagerClient()
        result = emc.unregister_external_environment(slug)
        return result

    # Find environment
    try:
        from qbraid_core.services.environments.registry import EnvironmentRegistryManager

        registry_mgr = EnvironmentRegistryManager()
        # Try to find by name first, then by env_id
        found = registry_mgr.find_by_name(name)
        if not found:
            found = registry_mgr.find_by_env_id(name)

        if not found:
            handle_error(
                error_type="NotFoundError",
                message=f"Environment '{name}' not found in registry. "
                "Use name (if unique) or env_id to reference the environment.",
            )
            return

        env_id, entry = found

        if entry.type != "external":
            console.print(f"[yellow]⚠️  Warning: '{name}' is a qBraid-managed environment.[/yellow]")
            console.print(f"   Use 'qbraid envs uninstall --name {name}' to fully remove it.")
            return

        if not auto_confirm:
            console.print(f"\n[yellow]⚠️  Unregistering environment '{entry.name}'[/yellow]")
            console.print(f"   Env ID: {env_id}")
            console.print(f"   Path: {entry.path}")
            console.print(f"   Type: {entry.type}")
            console.print(f"\n   Note: Files at {entry.path} will NOT be deleted.")

            if not typer.confirm("\nProceed?"):
                typer.echo("❌ Unregistration cancelled.")
                return

        run_progress_task(
            unregister,
            env_id,  # Can be name or env_id - method handles both
            description="Unregistering environment...",
            error_message="Failed to unregister environment",
        )

        typer.echo(f"✅ Environment '{name}' unregistered from qBraid.")

    except Exception as e:
        handle_error(message=str(e))


@registry_app.command("sync")
def registry_sync():
    """Sync the environment registry.

    This will:
    - Remove registry entries for deleted environments
    - Auto-discover new environments in default paths
    - Verify all registered paths still exist
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def sync():
        emc = EnvironmentManagerClient()
        stats = emc.sync_registry()
        return stats

    result = run_progress_task(
        sync,
        description="Synchronizing environment registry...",
        error_message="Failed to sync registry",
    )

    if result["discovered"] > 0:
        console.print(
            f"[green]✅ Registry synced: {result['discovered']}" " new environment(s) discovered[/green]"
        )
    elif result["removed"] > 0:
        console.print(f"[green]✅ Registry synced: {result['removed']} invalid entry(ies) removed[/green]")
    else:
        console.print("[green]✅ Registry synced: No changes detected[/green]")

    # Show summary
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"   Verified: {result['verified']}")
    console.print(f"   Discovered: {result['discovered']}")
    console.print(f"   Removed: {result['removed']}")
