# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Publish management CLI commands for qBraid environments."""

from typing import Optional

import typer
from rich.console import Console

from qbraid_cli.handlers import run_progress_task

publish_app = typer.Typer(
    help="Manage environment publishing.",
    no_args_is_help=True,
)
console = Console()


@publish_app.command("request")
def publish_request(
    slug: str = typer.Argument(..., help="Environment slug (from upload)"),
):
    """Request to publish environment.

    Submits your uploaded environment to the public catalog for admin review. Once approved,
    it will be publicly visible and installable by all users.

    The environment must be uploaded first with 'qbraid envs upload'.

    Examples:
        $ qbraid envs publish request my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def request_publish():
        client = EnvironmentManagerClient()
        return client.request_publish(slug)

    console.print(f"📤 Requesting to publish: [bold]{slug}[/bold]\n")

    try:
        run_progress_task(
            request_publish,
            description="Submitting publish request...",
            error_message="Failed to submit publish request",
        )

        console.print("\n[green]✅ Publish request submitted![/green]")
        console.print(f"📍 Slug: [bold]{slug}[/bold]")
        console.print("📊 Status: [yellow]requested[/yellow]")
        console.print("\n💡 Your request will be reviewed by qBraid admins.")
        console.print(f"   Check status with: [bold]qbraid envs publish status {slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "already" in error_msg.lower():
            console.print(f"[yellow]⚠️  {error_msg}[/yellow]")
        else:
            console.print(f"[red]❌ Failed to request publish:[/red] {err}")
        raise typer.Exit(1)


@publish_app.command("status")
def publish_status(
    slug: str = typer.Argument(..., help="Environment slug to check"),
):
    """Check publish status.

    Check the publishing status of an environment.
    Status values:
        - none: Not submitted for publishing
        - requested: Waiting for admin review
        - pending: Under admin review
        - approved: Published to public catalog
        - denied: Publish request was denied

    Examples:
        $ qbraid envs publish status my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def get_status():
        client = EnvironmentManagerClient()
        return client.get_publish_status(slug)

    try:
        status = run_progress_task(
            get_status,
            description="Checking publish status...",
            error_message="Failed to get publish status",
        )

        # Color-code status
        status_colors = {
            "none": "dim",
            "requested": "yellow",
            "pending": "cyan",
            "approved": "green",
            "denied": "red",
        }
        color = status_colors.get(status, "white")

        console.print(f"\n📊 Publish Status for [bold]{slug}[/bold]")
        console.print(f"   Status: [{color}]{status}[/{color}]")

        # Show helpful next steps
        if status == "none":
            console.print(f"\n💡 To request publishing: [bold]qbraid envs publish request {slug}[/bold]")
        elif status == "requested":
            console.print("\n⏳ Waiting for admin review...")
            console.print(f"   To cancel: [bold]qbraid envs publish cancel {slug}[/bold]")
        elif status == "pending":
            console.print("\n🔍 Currently under admin review...")
        elif status == "approved":
            console.print("\n🎉 Environment is publicly available!")
            console.print(f"   Install with: [bold]qbraid envs install {slug}[/bold]")
        elif status == "denied":
            console.print("\n❌ Publish request was denied.")
            console.print(f"   To resubmit: [bold]qbraid envs publish request {slug}[/bold]")

    except Exception as err:
        console.print(f"[red]❌ Failed to get status:[/red] {err}")
        raise typer.Exit(1)


@publish_app.command("cancel")
def publish_cancel(
    slug: str = typer.Argument(..., help="Environment slug"),
):
    """
    Cancel a pending publish request.

    This withdraws your publish request before it's approved.
    You can resubmit later with 'qbraid envs publish request'.

    Examples:
        $ qbraid envs publish cancel my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def revoke_request():
        client = EnvironmentManagerClient()
        return client.revoke_publish_request(slug)

    console.print(f"🚫 Cancelling publish request for: [bold]{slug}[/bold]\n")

    try:
        run_progress_task(
            revoke_request,
            description="Cancelling publish request...",
            error_message="Failed to cancel publish request",
        )

        console.print("[green]✅ Publish request cancelled.[/green]")
        console.print("   Environment remains private/shared only.")
        console.print(f"\n💡 To resubmit: [bold]qbraid envs publish request {slug}[/bold]")

    except Exception as err:
        console.print(f"[red]❌ Failed to cancel:[/red] {err}")
        raise typer.Exit(1)


@publish_app.command("review")
def publish_review(
    slug: str = typer.Argument(..., help="Environment slug to review"),
):
    """(Admin) Mark as under review.

    Transitions the environment from 'requested' to 'pending' status,
    indicating an admin is actively reviewing it.

    Examples:
        $ qbraid envs publish review my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def set_pending():
        client = EnvironmentManagerClient()
        return client.set_publish_pending(slug)

    console.print(f"🔍 Marking as under review: [bold]{slug}[/bold]\n")

    try:
        run_progress_task(
            set_pending,
            description="Updating status to pending...",
            error_message="Failed to update status",
        )

        console.print("[green]✅ Environment marked as under review.[/green]")
        console.print("   Status: [cyan]pending[/cyan]")
        console.print("\n💡 Next steps:")
        console.print(f"   • Approve: [bold]qbraid envs publish approve {slug}[/bold]")
        console.print(f'   • Deny: [bold]qbraid envs publish deny {slug} --message "reason"[/bold]')

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)


@publish_app.command("approve")
def publish_approve(
    slug: str = typer.Argument(..., help="Environment slug to approve"),
    group: Optional[str] = typer.Option(
        None, "--group", "-g", help="Add environment to this group after approval"
    ),
    skip_group_prompt: bool = typer.Option(False, "--no-group", help="Skip the group assignment prompt"),
):
    """(Admin) Approve and publish.

    Approve and publish an environment to the public catalog.
    This makes the environment publicly visible and installable by all users.
    After approval, you'll be prompted to add the environment to a group
    if it's not already in one.

    Examples:
        $ qbraid envs publish approve my_env_abc123
        $ qbraid envs publish approve my_env_abc123 --group qiskit
        $ qbraid envs publish approve my_env_abc123 --no-group
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    client = EnvironmentManagerClient()

    def approve():
        return client.approve_publish(slug)

    console.print(f"✅ Approving environment: [bold]{slug}[/bold]\n")

    try:
        run_progress_task(
            approve,
            description="Approving and publishing...",
            error_message="Failed to approve",
        )

        console.print("[green]✅ Environment published successfully![/green]")
        console.print(f"   Slug: [bold]{slug}[/bold]")
        console.print("   Visibility: [green]public[/green]")
        console.print("\n🎉 Users can now install with:")
        console.print(f"   [bold]qbraid envs install {slug}[/bold]")

        # Handle group assignment
        target_group = group

        if not target_group and not skip_group_prompt:
            # Check if env is already in any groups
            try:
                env_data = client.get_environment_by_slug(slug)
                env_groups = env_data.get("groups", [])

                if not env_groups:
                    console.print("\n[yellow]⚠️  This environment is not in any group.[/yellow]")
                    console.print("[dim]Environment groups help users discover related environments.[/dim]\n")

                    if typer.confirm("Would you like to add it to a group?"):
                        # Show available groups
                        groups_result = client.get_environment_groups()
                        available_groups = groups_result.get("environment_groups", [])

                        if available_groups:
                            console.print("\n[bold]Available groups:[/bold]")
                            for i, grp in enumerate(available_groups, 1):
                                grp_name = grp.get("displayName") or grp.get("name", "Unnamed")
                                grp_slug = grp.get("slug", "N/A")
                                console.print(f"  {i}. {grp_name} ({grp_slug})")

                            console.print("")
                            target_group = typer.prompt(
                                "Enter group slug (or press Enter to skip)",
                                default="",
                            )
                            if not target_group.strip():
                                target_group = None
                        else:
                            console.print(
                                "[dim]No groups available. "
                                "Create one with: qbraid envs groups create[/dim]"
                            )
            except Exception as grp_err:
                console.print(f"[dim]Could not check group status: {grp_err}[/dim]")

        # Add to group if specified
        if target_group:
            try:
                console.print(f"\nAdding to group: [bold]{target_group}[/bold]...")
                client.update_environment_group(
                    group_slug=target_group,
                    add_envs=[slug],
                    latest_env=slug,
                )
                console.print(f"[green]✅ Added to group '{target_group}' as latest version[/green]")
            except Exception as grp_err:
                console.print(f"[yellow]⚠️  Could not add to group:[/yellow] {grp_err}")
                console.print(
                    f"[dim]You can add manually with: "
                    f"qbraid envs groups update {target_group} --add {slug}[/dim]"
                )

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)


@publish_app.command("deny")
def publish_deny(
    slug: str = typer.Argument(..., help="Environment slug to deny"),
    message: Optional[str] = typer.Option(None, "--message", "-m", help="Reason for denial (sent to owner)"),
):
    """
    (Admin) Deny a publish request.

    The owner will be notified with the denial reason.

    Examples:
        $ qbraid envs publish deny my_env_abc123
        $ qbraid envs publish deny my_env_abc123 --message "Missing documentation"
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def deny():
        client = EnvironmentManagerClient()
        return client.deny_publish(slug, message=message)

    console.print(f"❌ Denying publish request: [bold]{slug}[/bold]")
    if message:
        console.print(f"   Reason: {message}")
    console.print("")

    try:
        run_progress_task(
            deny,
            description="Denying publish request...",
            error_message="Failed to deny",
        )

        console.print("[yellow]✅ Publish request denied.[/yellow]")
        console.print("   Owner has been notified.")

    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        else:
            console.print(f"[red]❌ Failed:[/red] {err}")
        raise typer.Exit(1)
