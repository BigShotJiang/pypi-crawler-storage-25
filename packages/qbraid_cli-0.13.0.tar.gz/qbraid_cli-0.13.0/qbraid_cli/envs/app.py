# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""
Module defining commands in the 'qbraid envs' namespace.

"""

import shlex
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import typer
from qbraid_core.services.environments.schema import EnvironmentConfig
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)

from qbraid_cli.envs.create import create_qbraid_env_assets, create_venv
from qbraid_cli.envs.data_handling import get_envs_data as installed_envs_data
from qbraid_cli.envs.data_handling import validate_env_name
from qbraid_cli.handlers import QbraidException, handle_error, run_progress_task

from .groups import groups_app
from .publish import publish_app
from .registry import registry_app
from .share import share_app

if TYPE_CHECKING:
    from qbraid_core.services.environments.client import EnvironmentManagerClient as EMC

envs_app = typer.Typer(
    help=(
        "Manage Python environments.\n\n"
        "Create, install, upload, and share Python environments.\n"
        "Isolated Python environments with automatic Jupyter kernel integration.\n"
        "Create environments locally, upload them to the cloud, share with\n"
        "teammates, or install pre-built environments from the catalog. Works\n"
        "identically on qBraid Lab and local machines.\n\n"
        "Use this when you want to:\n"
        "  \u2022 Set up a reproducible Python environment for a project\n"
        "  \u2022 Share your environment with collaborators\n"
        "  \u2022 Install a pre-configured environment (e.g., qBraid SDK, Qiskit)\n"
        "  \u2022 Publish an environment to the public catalog\n\n"
        "Quick start:\n"
        "  qbraid envs create             # Create new environment\n"
        "  qbraid envs available          # Browse installable environments\n"
        "  qbraid envs install <slug>     # Install from cloud\n"
        "  qbraid envs list               # List local environments\n"
        "  qbraid envs upload <name>      # Upload to cloud"
    ),
    no_args_is_help=True,
)

# Register sub-groups
envs_app.add_typer(publish_app, name="publish")
envs_app.add_typer(share_app, name="share")
envs_app.add_typer(groups_app, name="groups")
envs_app.add_typer(registry_app, name="registry")


def _get_current_user_owner() -> Optional[dict[str, str]]:
    """Try to get current user info for environment ownership."""
    try:
        from qbraid_core import QbraidSessionV1

        session = QbraidSessionV1()
        return session.get_current_user_owner()
    except Exception:  # pylint: disable=broad-exception-caught
        return None


def _parse_requirements_file(file_path: str) -> dict[str, str]:
    """Parse a requirements.txt file into a dict of {package: version_spec}."""
    from qbraid_core.services.environments import parse_requirements_file

    return parse_requirements_file(file_path)


def _fetch_logo_choices() -> list[dict]:
    """Fetch available company logos from API. Returns empty list on failure."""
    # TODO: Implement this in qbraid-core
    return []


def _interactive_create(console: Console) -> dict:
    """Walk user through environment creation interactively.

    Returns dict with keys: name, description, tags, logo, requirements, kernel_name
    """
    import questionary

    console.print("\n[bold]Create a new qBraid environment[/bold]\n")

    # Name (required)
    name = questionary.text(
        "Environment name:",
        validate=lambda val: True if val.strip() else "Name is required",
    ).ask()
    if name is None:
        raise typer.Exit()

    # Description
    description = questionary.text(
        "Description (optional):",
        default="",
    ).ask()
    if description is None:
        raise typer.Exit()

    # Tags
    tags_str = questionary.text(
        "Tags (comma-separated, optional):",
        default="",
    ).ask()
    if tags_str is None:
        raise typer.Exit()

    # Logo selection
    console.print("\n[dim]Fetching available logos...[/dim]")
    logos = _fetch_logo_choices()
    logo_name = None
    if logos:
        logo_names = [l["name"] for l in logos]
        logo_choices = ["python (default)"] + logo_names
        selected = questionary.select(
            "Select a logo:",
            choices=logo_choices,
            default="python (default)",
            instruction="(use arrow keys)",
        ).ask()
        if selected is None:
            raise typer.Exit()
        if selected != "python (default)":
            logo_name = selected

    # Requirements file
    requirements_path = questionary.text(
        "Path to requirements.txt (optional):",
        default="",
    ).ask()
    if requirements_path is None:
        raise typer.Exit()

    # Kernel name
    kernel_name = questionary.text(
        "Kernel display name (optional):",
        default="",
    ).ask()
    if kernel_name is None:
        raise typer.Exit()

    return {
        "name": name.strip(),
        "description": description.strip() or None,
        "tags": [t.strip() for t in tags_str.split(",") if t.strip()] or None,
        "logo": logo_name,
        "requirements": requirements_path.strip() or None,
        "kernel_name": kernel_name.strip() or None,
    }


@envs_app.command(name="create")
def envs_create(  # pylint: disable=too-many-statements
    name: str = typer.Option(None, "--name", "-n", help="Name of the environment to create"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Short description of the environment"
    ),
    logo: Optional[str] = typer.Option(
        None, "--logo", "-l", help="Company name for logo (e.g., 'ibm', 'google')"
    ),
    requirements: Optional[str] = typer.Option(
        None, "--requirements", "-r", help="Path to requirements.txt file"
    ),
    kernel_name: Optional[str] = typer.Option(
        None, "--kernel-name", "-k", help="Display name for Jupyter kernel"
    ),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y", help="Automatically answer 'yes' to all prompts"),
) -> None:
    """Create a new qBraid environment.

    Run without options for an interactive walkthrough, or provide options via flags.
    """
    console = Console()
    interactive = name is None

    if interactive:
        # Interactive mode: walk user through each field
        form = _interactive_create(console)
        name = form["name"]
        description = form["description"]
        tags = ",".join(form["tags"]) if form["tags"] else None
        logo = form["logo"]
        requirements = form["requirements"]
        kernel_name = form["kernel_name"]

    # Validate name
    if not validate_env_name(name):
        handle_error(
            error_type="ValueError",
            include_traceback=False,
            message=f"Invalid environment name '{name}'.",
        )

    # Parse requirements file if provided
    python_packages = None
    if requirements:
        try:
            python_packages = _parse_requirements_file(requirements)
        except ValueError as err:
            handle_error(error_type="ValueError", include_traceback=False, message=str(err))

    # Parse tags
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None

    # Build config
    env_config = EnvironmentConfig(
        name=name,
        description=description or None,
        tags=tag_list,
        logo=logo,
        kernel_name=kernel_name,
        python_packages=python_packages,
    )

    # Resolve logo URLs if logo specified
    logo_url = None  # {"light": url, "dark": url} for registry
    kernel_logo_url = None  # single URL for kernel dir
    if logo:
        try:
            from qbraid_core.services.environments.client import EnvironmentManagerClient

            emc = EnvironmentManagerClient()
            resolved = emc.resolve_logos(logo)
            logo_url = {"light": resolved.get("light"), "dark": resolved.get("dark")}
            kernel_logo_url = resolved.get("light") or resolved.get("dark")
        except Exception as err:  # pylint: disable=broad-exception-caught
            console.print(f"[yellow]Warning: Could not resolve logo '{logo}': {err}[/yellow]")

    # Gather local data
    def gather_local_data() -> tuple[Path, str]:
        """Gather local environment data for creation."""
        from qbraid_core.services.environments import get_default_envs_paths

        env_path = get_default_envs_paths()[0]
        result = subprocess.run(
            [sys.executable, "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
        python_version = (result.stdout or result.stderr).strip().removeprefix("Python ")
        return env_path, python_version

    from qbraid_core.services.environments.registry import generate_env_id

    local_data_out: tuple[Path, str] = run_progress_task(
        gather_local_data,
        description="Solving environment...",
        error_message="Failed to create qBraid environment",
    )

    env_path, python_version = local_data_out
    env_config.python_version = python_version

    from qbraid_core.services.environments.paths import make_env_dir_name

    env_id = generate_env_id()
    env_id_path = env_path / make_env_dir_name(name, env_id)

    # Display summary
    console.print("\n[bold]## Environment Summary ##[/bold]\n")
    console.print(f"  name:         {env_config.name}")
    console.print(f"  description:  {env_config.description or '[dim]None[/dim]'}")
    console.print(f"  tags:         {', '.join(env_config.tags) if env_config.tags else '[dim]None[/dim]'}")
    console.print(f"  logo:         {logo or '[dim]python (default)[/dim]'}")
    console.print(f"  kernelName:   {env_config.kernel_name or '[dim]auto[/dim]'}")
    if python_packages:
        console.print(f"  packages:     {len(python_packages)} from {requirements}")
    console.print(f"  env_id:       {env_id}")
    console.print(f"\n  location:     {env_id_path}")
    console.print(f"  python:       {python_version.strip()}\n")

    user_confirmation = auto_confirm or typer.confirm("Proceed", default=True)
    if not user_confirmation:
        typer.echo("qBraidSystemExit: Exiting.")
        raise typer.Exit()

    console.print("")

    # Get current user info for ownership
    owner = _get_current_user_owner()

    run_progress_task(
        create_qbraid_env_assets,
        env_id,
        env_id_path,
        env_config,
        kernel_logo_url,
        logo_url,
        False,  # auto_add_kernels
        owner,
        None,  # groups
        description="Generating qBraid assets...",
        error_message="Failed to create qBraid environment",
    )

    run_progress_task(
        create_venv,
        env_id_path,
        env_config.shell_prompt,
        None,  # python_exe (use default)
        env_id,  # env_id for registry package tracking
        description="Creating virtual environment...",
        error_message="Failed to create qBraid environment",
    )

    if env_config.python_packages:
        from qbraid_core.services.environments import pip_install

        packages_list = [f"{pkg}{ver}" if ver else pkg for pkg, ver in env_config.python_packages.items()]
        console.print(f"\n📥 Installing {len(packages_list)} packages...")
        result = run_progress_task(
            pip_install,
            env_id,
            packages_list,
            description="Installing packages...",
            error_message="Failed during package installation",
        )
        if result and not result.get("success"):
            console.print(
                "\n[yellow]⚠️  Some packages could not be installed. "
                "Run `qbraid envs activate` and use pip directly to retry.[/yellow]"
            )

    console.print(
        f"\n[bold green]Successfully created qBraid environment: "
        f"[/bold green][bold magenta]{name}[/bold magenta]\n"
    )
    typer.echo("# To activate this environment, use")
    typer.echo("#")
    typer.echo(f"#     $ qbraid envs activate {shlex.quote(name)}")
    typer.echo("#")
    typer.echo("# To deactivate an active environment, use")
    typer.echo("#")
    typer.echo("#     $ deactivate")


@envs_app.command(name="uninstall")
def envs_uninstall(
    name: str = typer.Option(..., "-n", "--name", help="Name of the environment to remove"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y", help="Automatically answer 'yes' to all prompts"),
) -> None:
    """Remove a local environment.

    Removes a qBraid environment from your filesystem.
    """
    import asyncio

    def uninstall_environment(slug: str) -> dict:
        """Uninstall a qBraid environment using async method."""
        from qbraid_core.services.environments.client import EnvironmentManagerClient

        emc = EnvironmentManagerClient()

        # Run async uninstall method
        result = asyncio.run(emc.uninstall_environment_local(slug, delete_metadata=True, force=auto_confirm))
        return result

    def gather_local_data(env_name: str) -> tuple[Path | None, str | None]:
        """Get environment path and env_id from name, env_id, or slug."""
        installed, aliases = installed_envs_data()
        # Try to find by name first, then by env_id
        if env_name in aliases:
            env_id = aliases[env_name]
            path = installed[env_id]
            return path, env_id
        if env_name in installed:
            # Direct env_id lookup
            path = installed[env_name]
            return path, env_name

        # Fall back to slug lookup via registry
        try:
            from qbraid_core.services.environments.registry import EnvironmentRegistryManager

            registry_mgr = EnvironmentRegistryManager()
            match = registry_mgr.find_by_slug(env_name)
            if match:
                env_id, entry = match
                if entry.path.exists():
                    return entry.path, env_id
        except Exception:
            pass

        return None, None

    env_path, env_id = gather_local_data(name)

    if env_path is None:
        console = Console()
        console.print(f"\n[yellow]Environment '{name}' not found.[/yellow]")
        console.print("[dim]You can reference an environment by its name (if unique), env_id, or slug.[/dim]")
        console.print("[dim]Run 'qbraid envs list' to see all installed environments.[/dim]")
        raise typer.Exit(0)

    confirmation_message = (
        f"⚠️  Warning: You are about to delete the environment '{name}' "
        f"located at '{env_path}'.\n"
        "This will remove all local packages and permanently delete all "
        "of its associated qBraid environment metadata.\n"
        "This operation CANNOT be undone.\n\n"
        "Are you sure you want to continue?"
    )

    if auto_confirm or typer.confirm(confirmation_message, abort=True):
        typer.echo("")
        result = run_progress_task(
            uninstall_environment,
            env_id,  # Can be name or env_id - method handles both
            description="Deleting environment...",
            error_message="Failed to delete qBraid environment",
        )

        if result.get("deleted_metadata"):
            typer.echo(f"✅ Environment '{name}' successfully removed (local files and metadata).")
        else:
            typer.echo(f"✅ Environment '{name}' successfully removed (local files only).")


@envs_app.command(name="delete")
def envs_delete(
    slug: str = typer.Argument(..., help="Slug of the cloud environment to delete"),
    auto_confirm: bool = typer.Option(False, "--yes", "-y", help="Automatically answer 'yes' to all prompts"),
) -> None:
    """(Admin) Delete a cloud environment.

    Removes the DB entry and storage files.
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    if not auto_confirm:
        console.print(
            f"\n[bold red]⚠️  Warning:[/bold red] This will permanently delete "
            f"the cloud environment [bold]{slug}[/bold].\n"
            "This removes the database entry and all associated storage files.\n"
            "This operation [bold]CANNOT[/bold] be undone.\n"
        )
        if not typer.confirm("Are you sure you want to continue?"):
            raise typer.Exit()

    try:
        client = EnvironmentManagerClient()
        client.delete_environment(slug)
        console.print(f"\n[green]✅ Cloud environment '{slug}' deleted successfully.[/green]")
    except Exception as err:
        error_msg = str(err)
        if "permission" in error_msg.lower() or "admin" in error_msg.lower():
            console.print("[red]❌ Admin access required.[/red]")
        elif "not found" in error_msg.lower():
            console.print(f"[red]❌ Environment '{slug}' not found.[/red]")
        else:
            console.print(f"[red]❌ Failed to delete environment:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="list")
def envs_list():
    """List installed qBraid environments."""
    from qbraid_core.services.environments.registry import EnvironmentRegistryManager

    installed, aliases = installed_envs_data(use_registry=True)
    console = Console()

    if len(installed) == 0:
        console.print(
            "No qBraid environments installed.\n\n" + "Use 'qbraid envs create' to create a new environment.",
            style="yellow",
        )
        return

    # Get registry to access name and env_id
    registry_mgr = EnvironmentRegistryManager()

    # Build list of (name, env_id, path) tuples
    env_list = []
    for env_id, path in installed.items():
        try:
            entry = registry_mgr.get_environment(env_id)
            env_list.append((entry.name, env_id, path))
        except Exception:
            # Fallback if registry lookup fails
            # Try to get name from aliases
            name = None
            for alias, eid in aliases.items():
                if eid == env_id and alias != env_id:
                    name = alias
                    break
            if not name:
                name = env_id
            env_list.append((name, env_id, path))

    # Sort: default first, then by name
    sorted_env_list = sorted(
        env_list,
        key=lambda x: (x[0] != "default", str(x[2]).startswith(str(Path.home())), x[0]),
    )

    current_env_path = Path(sys.executable).parent.parent.parent

    # Calculate column widths
    max_name_length = max(len(str(name)) for name, _, _ in sorted_env_list) if sorted_env_list else 0
    max_env_id_length = max(len(str(env_id)) for _, env_id, _ in sorted_env_list) if sorted_env_list else 0
    name_width = max(max_name_length, 4)  # At least "Name"
    env_id_width = max(max_env_id_length, 6)  # At least "Env ID"

    output_lines = []
    output_lines.append("# qbraid environments:")
    output_lines.append("#")
    output_lines.append("")

    # Header
    header = f"{'Name'.ljust(name_width + 2)}{'Env ID'.ljust(env_id_width + 2)}Path"
    output_lines.append(header)
    output_lines.append("")

    # Data rows
    for name, env_id, path in sorted_env_list:
        mark = "*" if path == current_env_path else " "
        line = f"{name.ljust(name_width + 2)}{env_id.ljust(env_id_width + 2)}{mark} {path}"
        output_lines.append(line)

    final_output = "\n".join(output_lines)

    console.print(final_output)


@envs_app.command(name="activate")
def envs_activate(
    name: str = typer.Argument(..., help="Name of the environment. Values from 'qbraid envs list'."),
):
    """Activate qBraid environment.

    NOTE: Currently only works on qBraid Lab platform, and select few other OS types.
    """
    from qbraid_core.services.environments.registry import EnvironmentRegistryManager

    # Get environment details from registry by looking up alias
    _, aliases = installed_envs_data(use_registry=True)
    # Find the env_id from the alias (name or env_id)
    env_id = aliases.get(name)

    if not env_id:
        raise typer.BadParameter(f"Environment '{name}' not found.")

    # Get the environment entry
    registry_mgr = EnvironmentRegistryManager()
    entry = registry_mgr.get_environment(env_id)
    env_path = Path(entry.path)

    # The venv is always at pyenv/ subdirectory
    # (shell_prompt is for the PS1 display name, not the directory)
    venv_path = env_path / "pyenv"

    from .activate import activate_pyvenv

    activate_pyvenv(venv_path)


@envs_app.command(name="available")
def envs_available(
    page: Optional[int] = typer.Option(None, "--page", "-p", help="Page number for pagination (default: 1)"),
    limit: Optional[int] = typer.Option(
        None, "--limit", "-l", help="Number of environments per page (default: 20)"
    ),
):
    """List installable environments.

    Shows available pre-built environments for installation.
    """

    def get_available_environments():
        """Get available environments from the API."""
        from qbraid_core.services.environments.client import EnvironmentManagerClient

        emc = EnvironmentManagerClient()
        return emc.get_available_environments(page=page, limit=limit)

    try:
        result = run_progress_task(
            get_available_environments,
            description="Fetching available environments...",
            error_message="Failed to fetch available environments",
        )
    except QbraidException:
        # If API fails, show a helpful message
        console = Console()
        console.print("[yellow]Unable to fetch available environments from qBraid service.[/yellow]")
        console.print("This feature requires:")
        console.print("• qBraid Lab environment, or")
        console.print("• Valid qBraid API credentials configured")
        console.print("\nTo configure credentials, run: [bold]qbraid configure[/bold]")
        return

    console = Console()
    environments = result.get("environments", [])
    pagination = result.get("pagination", {})

    if not environments:
        console.print("No environments available for installation.")
        return

    # Check if we're on cloud or local
    is_cloud = any(env.get("available_for_installation", False) for env in environments)

    # Display header
    if is_cloud:
        status_text = "[bold green]✓ Available for installation[/bold green]"
    else:
        status_text = "[bold yellow]⚠ Not available (local environment)[/bold yellow]"

    console.print(f"\n# Available qBraid Environments ({status_text})")

    # Show pagination info if available
    if pagination:
        current_page = pagination.get("page", 1)
        total_pages = pagination.get("totalPages", 1)
        total_count = pagination.get("total", len(environments))
        console.print(f"# Page {current_page} of {total_pages} (Total: {total_count} environments)")
    else:
        console.print(f"# Total: {len(environments)} environments")

    console.print("#")
    console.print("")

    # Calculate column widths
    max_name_len = max(len(env.get("displayName", env.get("name", ""))) for env in environments)
    max_slug_len = max(len(env.get("slug", "")) for env in environments)
    name_width = min(max_name_len + 2, 30)
    slug_width = min(max_slug_len + 2, 20)

    # Display environments
    for env in environments:
        name = env.get("displayName", env.get("name", "N/A"))
        slug = env.get("slug", "N/A")
        description = env.get("description", "No description")
        available = env.get("available_for_installation", False)

        # Truncate long names/slugs
        if len(name) > 28:
            name = name[:25] + "..."
        if len(slug) > 18:
            slug = slug[:15] + "..."
        if len(description) > 60:
            description = description[:57] + "..."

        status_icon = "✓" if available else "⚠"
        status_color = "green" if available else "yellow"

        console.print(
            f"[{status_color}]{status_icon}[/{status_color}] "
            f"{name.ljust(name_width)} "
            f"[dim]({slug.ljust(slug_width)})[/dim] "
            f"{description}"
        )

    # Show pagination navigation hints
    if pagination:
        current_page = pagination.get("page", 1)
        total_pages = pagination.get("totalPages", 1)
        console.print("")
        if total_pages > 1:
            nav_hints = []
            if current_page > 1:
                nav_hints.append(f"Previous: --page {current_page - 1}")
            if current_page < total_pages:
                nav_hints.append(f"Next: --page {current_page + 1}")
            if nav_hints:
                console.print(f"[dim]{' | '.join(nav_hints)}[/dim]")

    # Show usage hint
    console.print("")
    if is_cloud:
        console.print("[dim]To install an environment, note its slug and use:[/dim]")
        console.print("[dim]  qbraid envs install <slug>[/dim]")
    else:
        console.print("[dim]Environment installation is only available on qBraid Lab.[/dim]")
        console.print("[dim]Create custom environments with: qbraid envs create[/dim]")


@envs_app.command(name="info")
def envs_info(
    identifier: str = typer.Argument(..., help="Environment identifier (env_id or slug)"),
):
    """Show environment details.

    Get detailed information about an environment.
    Accepts either a local env_id or a cloud slug. Shows information from
    both local registry and cloud catalog when available.

    Examples:
        $ qbraid envs info qiskit_1.0       # By slug (cloud + local if installed)
        $ qbraid envs info a1b2             # By env_id (local only)
        $ qbraid envs info my_custom_abc123 # Custom environment
    """
    from qbraid_core.services.environments import EnvironmentRegistryManager

    console = Console()

    # Try to find in local registry first
    local_entry = None
    local_entries = []
    slug_to_query = None

    try:
        registry = EnvironmentRegistryManager()

        # First try by env_id (exact match)
        found = registry.find_by_env_id(identifier)
        if found:
            _, local_entry = found
            local_entries = [local_entry]
            slug_to_query = local_entry.slug  # May be None for local-only envs
        else:
            # Try by slug (may return multiple installations)
            slug_results = registry.find_all_by_slug(identifier)
            if slug_results:
                local_entries = [entry for _, entry in slug_results]
                slug_to_query = identifier
            else:
                # Not found locally, try cloud with this identifier as slug
                slug_to_query = identifier
    except Exception:
        # Registry not available - try cloud only
        slug_to_query = identifier

    # Try to fetch from cloud API
    cloud_env = None
    if slug_to_query:
        try:
            from qbraid_core.services.environments.client import EnvironmentManagerClient

            def get_cloud_info():
                client = EnvironmentManagerClient()
                return client.get_environment_by_slug(slug_to_query)

            cloud_env = run_progress_task(
                get_cloud_info,
                description="Fetching environment details...",
                error_message="Failed to fetch from cloud",
            )
        except Exception:
            # Cloud lookup failed - that's OK if we have local info
            pass

    # If nothing found anywhere, exit with error
    if not local_entries and not cloud_env:
        console.print(f"[red]❌ Environment not found:[/red] {identifier}")
        console.print("[dim]Not found in local registry or cloud catalog.[/dim]")
        raise typer.Exit(1)

    # --- Display Cloud Info (if available) ---
    if cloud_env:
        name = cloud_env.get("displayName") or cloud_env.get("name") or "N/A"
        description = cloud_env.get("description") or "No description"
        owner_data = cloud_env.get("owner") or {}
        if isinstance(owner_data, dict):
            owner = owner_data.get("username") or owner_data.get("email") or "Unknown"
        else:
            owner = owner_data or cloud_env.get("userId") or "Unknown"
        python_version = cloud_env.get("pythonVersion") or "Unknown"
        visibility = cloud_env.get("visibility") or "private"
        tags = cloud_env.get("tags") or []
        image_tag = cloud_env.get("imageTag") or cloud_env.get("image_tag") or "N/A"
        available = cloud_env.get("available_for_installation", False)

        visibility_colors = {"public": "green", "private": "yellow", "shared": "cyan"}
        vis_color = visibility_colors.get(visibility, "white")

        console.print(f"\n📦 [bold]{name}[/bold]")
        console.print(f"   [dim]{description}[/dim]")

        console.print("\n[bold]☁️  Cloud Info:[/bold]")
        console.print(f"   Slug:            {slug_to_query}")
        console.print(f"   Owner:           {owner}")
        console.print(f"   Python:          {python_version}")
        console.print(f"   Visibility:      [{vis_color}]{visibility}[/{vis_color}]")
        console.print(f"   Image Tag:       {image_tag}")

        if tags:
            console.print(f"   Tags:            {', '.join(tags)}")

        # Publish status
        review_status = cloud_env.get("reviewStatus")
        if review_status:
            status_colors = {
                "none": "dim",
                "requested": "yellow",
                "pending": "cyan",
                "approved": "green",
                "denied": "red",
            }
            color = status_colors.get(review_status, "white")
            console.print(f"   Publish Status:  [{color}]{review_status}[/{color}]")

    # --- Display Local Info (if available) ---
    if local_entries:
        # If no cloud info, show header from local entry
        if not cloud_env:
            entry = local_entries[0]
            console.print(f"\n📦 [bold]{entry.name}[/bold]")
            if entry.description:
                console.print(f"   [dim]{entry.description}[/dim]")

        console.print(f"\n[bold]💻 Local Installation{'s' if len(local_entries) > 1 else ''}:[/bold]")

        for entry in local_entries:
            kernels_dir = Path(entry.path) / "kernels"
            has_kernel = (
                kernels_dir.is_dir() and any(kernels_dir.iterdir()) if kernels_dir.exists() else False
            )
            kernel_status = "✓ kernel" if has_kernel else "○ no kernel"
            env_type = getattr(entry.type, "value", None) or str(entry.type)

            console.print(f"\n   [bold]env_id:[/bold] {entry.env_id}")
            console.print(f"   Path:            {entry.path}")
            console.print(f"   Type:            {env_type}")
            if entry.python_version:
                console.print(f"   Python:          {entry.python_version}")
            if entry.python_executable:
                console.print(f"   Executable:      {entry.python_executable}")
            if entry.platform:
                console.print(f"   Platform:        {entry.platform}")
            if entry.kernel_name:
                console.print(f"   Kernel:          {entry.kernel_name} [{kernel_status}]")
            else:
                console.print(f"   Kernel:          [{kernel_status}]")
            if entry.shell_prompt:
                console.print(f"   Shell Prompt:    {entry.shell_prompt}")
            if entry.installed_at:
                console.print(f"   Installed:       {entry.installed_at}")
            elif entry.registered_at:
                console.print(f"   Registered:      {entry.registered_at}")
            if entry.slug:
                console.print(f"   Slug:            {entry.slug}")
    elif cloud_env:
        console.print("\n[bold]💻 Local Installation:[/bold]")
        console.print("   [dim]Not installed locally[/dim]")

    # --- Show Actions ---
    console.print("\n[bold]Actions:[/bold]")

    if cloud_env:
        available = cloud_env.get("available_for_installation", False)
        visibility = cloud_env.get("visibility", "private")

        if available and not local_entries:
            console.print(f"   Install:  [bold]qbraid envs install {slug_to_query}[/bold]")
        if visibility == "private":
            console.print(f"   Share:    [bold]qbraid envs share create-code {slug_to_query}[/bold]")
            console.print(f"   Publish:  [bold]qbraid envs publish request {slug_to_query}[/bold]")

    if local_entries:
        entry = local_entries[0]
        if not entry.slug:
            # Local-only environment - can be uploaded
            console.print(f"   Upload:   [bold]qbraid envs upload {entry.env_id}[/bold]")
        kernels_dir = Path(entry.path) / "kernels"
        has_kernel = kernels_dir.is_dir() and any(kernels_dir.iterdir()) if kernels_dir.exists() else False
        if not has_kernel:
            console.print(f"   Add kernel: [bold]qbraid kernels add {entry.env_id}[/bold]")
        console.print(f"   Activate: [bold]qbraid envs activate {entry.env_id}[/bold]")
        console.print(f"   Remove:   [bold]qbraid envs uninstall --name {entry.env_id}[/bold]")


def _create_similar_environment(
    env_info: dict,
    target_dir: str,
    console: Console,
) -> dict:
    """Create a local environment with similar packages to the cloud environment.

    Args:
        env_info: Environment metadata from API (contains packages, name, etc.)
        target_dir: Directory to create the environment in
        console: Rich console for output

    Returns:
        dict with env_id and path of created environment
    """
    from qbraid_core.services.environments.registry import generate_env_id

    # Extract packages from cloud environment
    packages_list = env_info.get("packages") or env_info.get("packagesInImage") or []
    if not packages_list:
        console.print("[yellow]⚠️  No package list available from cloud environment.[/yellow]")
        packages_list = []

    # Generate env_id and path
    env_id = generate_env_id()
    env_path = Path(target_dir) / env_id

    # Create config from cloud env metadata - preserve as much as possible
    env_name = env_info.get("displayName") or env_info.get("name") or f"local_{env_id}"
    cloud_slug = env_info.get("slug")

    # Use original description or note that it's a local recreation
    description = env_info.get("description")
    if not description:
        description = f"Local recreation of {cloud_slug or 'cloud environment'}"

    env_config = EnvironmentConfig(
        name=env_name,
        description=description,
        tags=env_info.get("tags"),
        kernel_name=env_info.get("kernelName"),
        shell_prompt=env_info.get("shellPrompt"),
        python_version=env_info.get("pythonVersion"),  # May differ from local Python
        visibility=env_info.get("visibility", "private"),
    )

    # Get logo URL from cloud environment (if available)
    logo_url = env_info.get("logo")  # {"light": "https://...", "dark": "https://..."}

    console.print(f"\n📦 Creating local environment: [bold]{env_name}[/bold]")
    console.print(f"📂 Location: {env_path}")
    if packages_list:
        console.print(f"📋 Packages to install: {len(packages_list)}")
    console.print("")

    # Get current user info for ownership (best-effort, works if logged in)
    owner = _get_current_user_owner()

    # Derive kernel logo URL from logo_url dict
    install_kernel_logo_url = None
    if logo_url:
        install_kernel_logo_url = logo_url.get("light") or logo_url.get("dark")

    # Create qBraid assets (metadata files, logos)
    run_progress_task(
        create_qbraid_env_assets,
        env_id,
        env_path,
        env_config,
        install_kernel_logo_url,  # kernel_logo_url
        logo_url,  # logo_url for registry
        False,  # auto_add_kernels
        owner,  # owner info for the creator
        None,  # groups
        description="Generating qBraid assets...",
        error_message="Failed to create environment assets",
    )

    # Create virtual environment
    run_progress_task(
        create_venv,
        env_path,
        env_config.shell_prompt,
        None,  # python_exe (use default)
        env_id,  # env_id for registry
        description="Creating virtual environment...",
        error_message="Failed to create virtual environment",
    )

    # Install packages if available (uses pip_install which auto-updates registry)
    if packages_list:
        console.print(f"\n📥 Installing {len(packages_list)} packages...")

        from qbraid_core.services.environments import pip_install

        result = run_progress_task(
            pip_install,
            env_id,
            packages_list,
            description="Installing packages...",
            error_message="Failed during package installation",
        )

        if result:
            if not result.get("success"):
                console.print(
                    "\n[yellow]⚠️  Some packages could not be installed"
                    " (likely platform-specific or conflicting):[/yellow]"
                )
                output = result.get("output", "")
                # Show relevant error lines
                error_lines = [l for l in output.split("\n") if "ERROR" in l or "Could not find" in l]
                for line in error_lines[:5]:
                    console.print(f"   {line.strip()}")
                if len(error_lines) > 5:
                    console.print("   ... and more errors")
            else:
                console.print("\n[green]✓[/green] Successfully installed packages")

    return {
        "env_id": env_id,
        "path": str(env_path),
        "name": env_name,
    }


@envs_app.command(name="install")
def envs_install(
    env_slug: str = typer.Argument(..., help="Environment slug to install (from 'qbraid envs available')"),
    temp: bool = typer.Option(
        False, "--temp", "-t", help="Install as temporary environment (faster, non-persistent)"
    ),
    target_dir: str = typer.Option(
        None, "--target", help="Custom target directory (defaults to ~/.qbraid/environments)"
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Automatically proceed with default options without prompting"
    ),
):
    """Install an environment.

    Installs a pre-built environment from cloud storage.
    If the environment was built for a different platform or requires a Python
    version not available on your system, you'll be offered options to either
    create a similar local environment or proceed with the download anyway.
    """

    async def install_environment_async():
        """Async wrapper for environment installation."""
        from qbraid_core.services.environments import install_python
        from qbraid_core.services.environments.client import EnvironmentManagerClient
        from qbraid_core.services.environments.preflight import check_env_install_preflight

        # Determine target directory
        if target_dir:
            install_dir = target_dir
        elif temp:
            install_dir = "/opt/environments"
        else:
            install_dir = str(Path.home() / ".qbraid" / "environments")

        console = Console()
        emc = EnvironmentManagerClient()

        # Fetch environment metadata
        try:
            env_info = emc.get_environment_by_slug(env_slug)
        except Exception as e:
            console.print(f"[red]❌ Failed to fetch environment info: {e}[/red]")
            raise typer.Exit(1)

        env_name = env_info.get("displayName") or env_info.get("name") or env_slug
        env_python = env_info.get("pythonVersion")

        console.print(f"\n📦 Environment: [bold]{env_name}[/bold] ({env_slug})")
        if env_info.get("description"):
            console.print(f"   {env_info.get('description')[:80]}...")

        # ═══════════════════════════════════════════════════════════════════
        # Pre-flight compatibility checks (shared with projects install)
        # ═══════════════════════════════════════════════════════════════════
        preflight = check_env_install_preflight(env_info)

        console.print(f"   Platform: {preflight.env_platform or 'unknown'}")
        console.print(f"   Python: {env_python or 'unknown'}")
        console.print("")

        create_local_instead = False

        # STEP 1: Platform check
        if not preflight.platform_compatible:
            console.print("[yellow]⚠️  Platform Mismatch[/yellow]")
            console.print(f"   This environment was built for [bold]{preflight.env_platform}[/bold]")
            console.print(f"   Your system is [bold]{preflight.current_platform}[/bold]")
            console.print("")
            console.print("   The downloaded environment may not work correctly on your system.")
            console.print("")

            if yes:
                console.print("[dim]Using --yes flag: creating local environment instead[/dim]")
                create_local_instead = True
            else:
                console.print("What would you like to do?")
                console.print("  [bold][1][/bold] Create a similar environment locally (Recommended)")
                console.print("  [bold][2][/bold] Download anyway (may not work)")
                console.print("  [bold][3][/bold] Cancel")
                console.print("")

                choice = typer.prompt("Choose an option", default="1")

                if choice == "1":
                    create_local_instead = True
                elif choice == "2":
                    console.print("[dim]Proceeding with download...[/dim]")
                else:
                    console.print("Installation cancelled.")
                    raise typer.Exit(0)

        # STEP 2: Python version check (only if not creating local)
        if not create_local_instead and not preflight.python_available:
            console.print("[yellow]⚠️  Python Version Not Found[/yellow]")
            console.print(f"   This environment requires [bold]Python {preflight.required_python}[/bold]")
            console.print(f"   Python {preflight.required_python} is not available on your system.")
            console.print("")

            if yes:
                if preflight.uv_available:
                    console.print("[dim]Using --yes flag: installing Python via uv[/dim]")
                    try:
                        install_python(preflight.required_python)
                        console.print(f"[green]✓[/green] Installed Python {preflight.required_python}")
                    except Exception as e:
                        console.print(f"[red]Failed to install Python: {e}[/red]")
                        console.print("[dim]Falling back to creating local environment[/dim]")
                        create_local_instead = True
                else:
                    console.print("[dim]Using --yes flag: uv not available, creating local environment[/dim]")
                    create_local_instead = True
            else:
                console.print("What would you like to do?")
                console.print(
                    "  [bold][1][/bold] Create a similar environment"
                    " with your current Python (Recommended)"
                )
                if preflight.uv_available:
                    console.print(
                        f"  [bold][2][/bold] Install Python"
                        f" {preflight.required_python} via uv, then download"
                    )
                else:
                    console.print(
                        f"  [dim][2] Install Python"
                        f" {preflight.required_python}"
                        " via uv (uv not available)[/dim]"
                    )
                console.print("  [bold][3][/bold] Cancel")
                console.print("")

                choice = typer.prompt("Choose an option", default="1")

                if choice == "1":
                    create_local_instead = True
                elif choice == "2":
                    if preflight.uv_available:
                        console.print(f"\n📥 Installing Python {preflight.required_python}...")
                        try:
                            install_python(preflight.required_python)
                            console.print(f"[green]✓[/green] Installed Python {preflight.required_python}")
                        except Exception as e:
                            console.print(f"[red]❌ Failed to install Python: {e}[/red]")
                            raise typer.Exit(1)
                    else:
                        console.print(
                            "[red]❌ uv is not available. Install uv"
                            " first: https://docs.astral.sh/uv/[/red]"
                        )
                        raise typer.Exit(1)
                else:
                    console.print("Installation cancelled.")
                    raise typer.Exit(0)

        # ═══════════════════════════════════════════════════════════════════
        # STEP 3: Create Local Environment OR Download from Cloud
        # ═══════════════════════════════════════════════════════════════════
        if create_local_instead:
            # Create a local environment with similar packages
            try:
                result = _create_similar_environment(env_info, install_dir, console)

                console.print("")
                console.print("[green]✅ Local environment created successfully![/green]")
                console.print(f"📍 Location: [bold]{result['path']}[/bold]")
                console.print(f"🆔 Env ID: [dim]{result['env_id']}[/dim]")
                console.print("")
                console.print("🎯 Next steps:")
                console.print(f"• Activate: [bold]qbraid envs activate {result['env_id']}[/bold]")
                console.print(f"• Add kernel: [bold]qbraid kernels add {result['env_id']}[/bold]")
                console.print("• List all: [bold]qbraid envs list[/bold]")

            except Exception as e:
                console.print(f"[red]❌ Failed to create local environment: {e}[/red]")
                raise typer.Exit(1)

        else:
            # Download from cloud storage (original flow)
            try:
                console.print(f"🚀 Downloading environment: [bold]{env_slug}[/bold]")
                if temp:
                    console.print(f"📂 Target: [dim]{install_dir}[/dim] (temporary)")
                else:
                    console.print(f"📂 Target: [dim]{install_dir}[/dim]")
                console.print("")

                progress_columns = (
                    SpinnerColumn(),
                    TextColumn("{task.description}"),
                    BarColumn(),
                    DownloadColumn(),
                    TransferSpeedColumn(),
                    TimeElapsedColumn(),
                )

                with Progress(*progress_columns, transient=True) as progress:
                    tasks: dict[str, int] = {}

                    def get_task(stage: str, description: str, total: Optional[int]) -> int:
                        task_id = tasks.get(stage)
                        if task_id is None:
                            task_total = total if total and total > 0 else None
                            task_id = progress.add_task(description, total=task_total)
                            tasks[stage] = task_id
                        return task_id

                    def progress_callback(stage: str, completed: int, total: int) -> None:
                        total_value = total if total and total > 0 else None
                        if stage == "download":
                            task_id = get_task("download", "Downloading environment...", total_value)
                            task = progress.tasks[task_id]
                            if total_value and (task.total is None or task.total == 0):
                                progress.update(task_id, total=total_value)
                            progress.update(task_id, completed=completed)
                        elif stage == "extract":
                            task_id = get_task("extract", "Extracting files...", total_value)
                            task = progress.tasks[task_id]
                            if total_value:
                                if task.total is None or task.total == 0:
                                    progress.update(task_id, total=total_value)
                                progress.update(task_id, completed=completed)
                            else:
                                progress.update(task_id, completed=task.completed + 1)

                    result = await emc.install_environment_from_storage(
                        slug=env_slug,
                        target_dir=install_dir,
                        temp=temp,
                        overwrite=yes,
                        progress_callback=progress_callback,
                        auto_install_python=False,  # We handled Python above
                    )

                console.print("")
                console.print("[green]✅ Installation completed![/green]")
                console.print(f"📍 Location: [bold]{result['target_dir']}[/bold]")
                if "size_mb" in result:
                    console.print(f"💾 Size: [dim]{result['size_mb']:.1f} MB[/dim]")
                if "env_id" in result:
                    console.print(f"🆔 Env ID: [dim]{result['env_id']}[/dim]")

                # Display any warnings
                warnings = result.get("warnings", [])
                if warnings:
                    console.print("")
                    for warning in warnings:
                        console.print(f"[yellow]⚠️  {warning}[/yellow]")

                if temp:
                    console.print("[yellow]⚠️  Temporary environment - will be deleted on restart[/yellow]")

                env_activation_id = result.get("env_id", env_slug)
                console.print("")
                console.print("🎯 Next steps:")
                console.print(f"• Activate: [bold]qbraid envs activate {env_activation_id}[/bold]")
                console.print(f"• Add kernel: [bold]qbraid kernels add {env_activation_id}[/bold]")
                console.print("• List all: [bold]qbraid envs list[/bold]")

            except Exception as e:
                err_name = type(e).__name__
                if err_name == "EnvironmentValidationError" and "already exists" in str(e):
                    console.print("[yellow]⚠️ Installation skipped: Environment already exists.[/yellow]")
                else:
                    console.print(f"[red]❌ Installation failed: {e}[/red]")
                raise typer.Exit(1)

    # Run async function
    import asyncio

    try:
        asyncio.run(install_environment_async())
    except KeyboardInterrupt:
        console = Console()
        console.print("\n[yellow]⚠️  Installation cancelled by user[/yellow]")
        raise typer.Exit(1)


@envs_app.command(name="upload")
def envs_upload(
    identifier: str = typer.Argument(..., help="Environment name (if unique) or env_id to upload"),
    slug: Optional[str] = typer.Option(
        None, "--slug", "-s", help="Re-upload to existing slug (replaces previous upload)"
    ),
    group_slug: Optional[str] = typer.Option(
        None, "--group", "-g", help="Environment group to add this environment to"
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", "-o", help="Overwrite existing uploaded environment"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """Upload an environment.

    Upload environment to qBraid cloud storage (private by default).
    This uploads your local environment to make it available for sharing
    with specific users. Use 'qbraid envs publish request' after upload to request
    public visibility.

    Examples:
        $ qbraid envs upload my_custom_env
        $ qbraid envs upload a1b2 --overwrite
        $ qbraid envs upload my_env --group quantum_sdk
        $ qbraid envs upload my_env --slug existing_slug_abc123  # Re-upload
    """
    import asyncio

    from qbraid_core.services.environments.client import EnvironmentManagerClient

    console = Console()

    # Warning for re-upload (when slug is provided)
    if slug:
        console.print("[yellow]Re-upload Warning:[/yellow]")
        console.print("  Re-uploading to an existing slug will:")
        console.print("  • Reset visibility to [bold]private[/bold]")
        console.print("  • Reset review status to [bold]NONE[/bold]")
        console.print("  • Require re-requesting publish if previously approved\n")

        if not yes:
            if not typer.confirm("Proceed with re-upload?", default=False):
                console.print("Upload cancelled.")
                raise typer.Exit(0)

    async def upload_environment_async():
        """Async wrapper for environment upload."""
        client = EnvironmentManagerClient()

        progress_columns = (
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
        )

        with Progress(*progress_columns, console=console, transient=False) as progress:
            tasks: dict[str, int] = {}

            def get_task(stage: str, description: str, total: Optional[int]) -> int:
                task_id = tasks.get(stage)
                if task_id is None:
                    task_total = total if total and total > 0 else 100
                    task_id = progress.add_task(description, total=task_total)
                    tasks[stage] = task_id
                return task_id

            def progress_callback(stage: str, completed: int, total: int) -> None:
                total_value = total if total and total > 0 else 100
                if stage == "prepare":
                    task_id = get_task("prepare", "Preparing environment...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)
                elif stage == "archive":
                    task_id = get_task("archive", "Creating archive...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)
                elif stage == "upload":
                    task_id = get_task("upload", "Uploading to cloud...", total_value)
                    progress.update(task_id, completed=completed, total=total_value)

            result = await client.upload_environment(
                identifier=identifier,
                slug=slug,
                group_slug=group_slug,
                overwrite=overwrite,
                progress_callback=progress_callback,
            )

        return result

    console.print(f"Uploading environment: [bold]{identifier}[/bold]\n")

    try:
        result = asyncio.run(upload_environment_async())

        console.print("\n[green]✅ Upload completed![/green]")
        console.print(f"📍 Slug: [bold]{result.get('slug', 'N/A')}[/bold]")
        console.print(f"🆔 Env ID: {result.get('env_id', 'N/A')}")
        console.print("\n🎯 Next steps:")
        console.print(f"   • Share: [bold]qbraid envs share create-code {result.get('slug')}[/bold]")
        console.print(f"   • Publish: [bold]qbraid envs publish request {result.get('slug')}[/bold]")

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Upload cancelled by user[/yellow]")
        raise typer.Exit(1)
    except Exception as err:
        console.print(f"\n[red]❌ Upload failed:[/red] {err}")
        raise typer.Exit(1)


@envs_app.command(name="health")
def envs_health(
    identifier: str = typer.Argument(..., help="Environment name or env_id to check"),
):
    """
    Check the health of an environment.

    This performs comprehensive checks on the virtual environment:
    - Python symlinks and executables
    - pyvenv.cfg configuration
    - Activate scripts
    - Kernel configuration (if present)

    Examples:
        $ qbraid envs health my_env
        $ qbraid envs health a1b2
    """
    from qbraid_core.services.environments import (
        EnvironmentRegistryManager,
        is_kernel_installed,
        is_venv_healthy,
        validate_kernel,
    )

    console = Console()

    # Get environment from registry
    try:
        registry = EnvironmentRegistryManager()
        # Try by env_id first using get_environment
        entry = None
        try:
            entry = registry.get_environment(identifier)
        except Exception:
            pass

        if not entry:
            # Try by name
            result = registry.find_by_name(identifier)
            if result:
                _, entry = result

        if not entry:
            console.print(f"[red]❌ Environment '{identifier}' not found.[/red]")
            raise typer.Exit(1)

        env_path = Path(entry.path)
    except Exception as e:
        console.print(f"[red]❌ Error looking up environment: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"🔍 Health check for: [bold]{entry.name}[/bold] ({entry.env_id})")
    console.print(f"   Path: {env_path}\n")

    # Check venv health
    health_result = is_venv_healthy(env_path)

    if health_result.is_healthy:
        console.print("[green]✓[/green] Environment is healthy")
    else:
        console.print("[red]✗[/red] Environment has issues")

    # Show Python info
    if health_result.python_version:
        console.print(f"[green]✓[/green] Python version: {health_result.python_version}")
    if health_result.python_executable:
        console.print(f"[green]✓[/green] Python executable: {health_result.python_executable}")

    # Show issues
    if health_result.issues:
        console.print(f"\n[bold]Issues found ({len(health_result.issues)}):[/bold]")
        for issue in health_result.issues:
            severity_color = "red" if issue.severity == "error" else "yellow"
            repairable = "[dim](repairable)[/dim]" if issue.repairable else "[dim](manual fix required)[/dim]"
            console.print(
                f"  [{severity_color}]●[/{severity_color}]"
                f" [{issue.category}] {issue.message}"
                f" {repairable}"
            )
            if issue.path:
                console.print(f"      Path: {issue.path}")

    # Check kernel status
    console.print("\n[bold]Kernel Status:[/bold]")
    kernel_valid, kernel_msg = validate_kernel(env_path)
    kernel_installed = is_kernel_installed(identifier)

    if kernel_valid:
        console.print(f"[green]✓[/green] {kernel_msg}")
    else:
        console.print(f"[yellow]○[/yellow] {kernel_msg}")

    if kernel_installed:
        console.print("[green]✓[/green] Kernel is installed in Jupyter")
    else:
        console.print("[yellow]○[/yellow] Kernel is NOT installed in Jupyter")

    # Show actions
    console.print("\n[bold]Actions:[/bold]")
    if not health_result.is_healthy:
        console.print(f"  Repair environment: [bold]qbraid envs repair {identifier}[/bold]")
    if not kernel_installed:
        console.print(f"  Install kernel: [bold]qbraid kernels add {identifier}[/bold]")
    if not kernel_valid:
        console.print(f"  Repair kernel: [bold]qbraid kernels repair {identifier}[/bold]")


@envs_app.command(name="repair")
def envs_repair(
    identifier: str = typer.Argument(..., help="Environment name or env_id to repair"),
    auto_install_python: bool = typer.Option(
        False, "--auto-install", "-a", help="Automatically install Python via uv if needed"
    ),
):
    """
    Repair a broken environment.

    This attempts to fix common issues:
    - Broken Python symlinks
    - Invalid pyvenv.cfg paths
    - Broken activate scripts
    - Invalid kernel.json paths

    Use --auto-install to automatically install Python via uv if the
    required version is not available.

    Examples:
        $ qbraid envs repair my_env
        $ qbraid envs repair a1b2 --auto-install
    """
    from qbraid_core.services.environments import (
        EnvironmentRegistryManager,
        is_venv_healthy,
        repair_venv,
    )
    from qbraid_core.services.environments.kernels import repair_kernel

    console = Console()

    # Get environment from registry
    try:
        registry = EnvironmentRegistryManager()
        # Try by env_id first using get_environment
        entry = None
        try:
            entry = registry.get_environment(identifier)
        except Exception:
            pass

        if not entry:
            # Try by name
            result = registry.find_by_name(identifier)
            if result:
                _, entry = result

        if not entry:
            console.print(f"[red]❌ Environment '{identifier}' not found.[/red]")
            raise typer.Exit(1)

        env_path = Path(entry.path)
    except Exception as e:
        console.print(f"[red]❌ Error looking up environment: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"🔧 Repairing environment: [bold]{entry.name}[/bold] ({entry.env_id})")
    console.print(f"   Path: {env_path}\n")

    # Check current health
    health_before = is_venv_healthy(env_path)
    if health_before.is_healthy:
        console.print("[green]✓[/green] Environment is already healthy!")
        console.print("\nNo repairs needed.")
        return

    console.print(f"Found {len(health_before.issues)} issue(s) to fix...\n")

    # Attempt repair
    try:
        _, actions = run_progress_task(
            repair_venv,
            env_path,
            None,  # python_version (auto-detect)
            auto_install_python,
            description="Repairing virtual environment...",
            error_message="Repair failed",
        )

        if actions:
            console.print("[bold]Repair actions:[/bold]")
            for action in actions:
                console.print(f"  [green]✓[/green] {action}")

        # Also repair kernel if present
        kernels_dir = env_path / "kernels"
        if kernels_dir.exists():
            console.print("\nRepairing kernel...")
            kernel_success, kernel_msg = repair_kernel(env_path)
            if kernel_success:
                console.print(f"  [green]✓[/green] {kernel_msg}")
            else:
                console.print(f"  [dim]○[/dim] {kernel_msg}")

        # Check health after repair
        health_after = is_venv_healthy(env_path)
        if health_after.is_healthy:
            console.print("\n[green]✅ Environment repaired successfully![/green]")
        else:
            console.print("\n[yellow]⚠️  Some issues remain:[/yellow]")
            for issue in health_after.issues:
                console.print(f"  [yellow]●[/yellow] {issue.message}")

    except Exception as e:
        console.print(f"\n[red]❌ Repair failed: {e}[/red]")
        if "Python" in str(e) and not auto_install_python:
            console.print("\n💡 Try with --auto-install to install Python automatically:")
            console.print(f"   [bold]qbraid envs repair {identifier} --auto-install[/bold]")
        raise typer.Exit(1)


@envs_app.command(name="pythons")
def envs_pythons():
    """List available Python versions.

    Shows all Python installations found on the system, including:
    - System Python (PATH)
    - uv-managed Python
    - Conda environments
    - Homebrew (macOS)
    - pyenv installations

    Use this to see which Python versions are available for creating
    new environments.

    Examples:
        $ qbraid envs pythons
    """
    from qbraid_core.services.environments import (
        find_system_pythons,
        get_current_platform,
        is_uv_available,
    )

    console = Console()

    console.print("🐍 Discovering Python interpreters...\n")

    # Show platform info
    platform = get_current_platform()
    uv_available = is_uv_available()

    console.print("[bold]System Info:[/bold]")
    console.print(f"   Platform: {platform}")
    console.print(f"   uv available: {'[green]Yes[/green]' if uv_available else '[yellow]No[/yellow]'}")
    console.print("")

    # Find all Pythons
    pythons = find_system_pythons(include_invalid=True)

    if not pythons:
        console.print("[yellow]No Python interpreters found.[/yellow]")
        if uv_available:
            console.print("\n💡 Install Python with uv:")
            console.print("   [bold]uv python install 3.11[/bold]")
        return

    console.print(f"[bold]Found {len(pythons)} Python interpreter(s):[/bold]\n")

    # Group by source
    by_source: dict = {}
    for p in pythons:
        source = p.source
        if source not in by_source:
            by_source[source] = []
        by_source[source].append(p)

    for source, interpreters in sorted(by_source.items()):
        console.print(f"[bold]{source.upper()}:[/bold]")
        for p in sorted(interpreters, key=lambda x: x.version, reverse=True):
            status = "[green]✓[/green]" if p.is_valid else "[red]✗[/red]"
            version_display = p.version if p.version else "unknown"
            console.print(f"  {status} Python {version_display:8} {p.path}")
            if p.error:
                console.print(f"      [red]Error: {p.error}[/red]")
        console.print("")

    if uv_available:
        console.print("[dim]💡 Install additional Python versions with: uv python install <version>[/dim]")


@envs_app.command(name="config")
def envs_config(
    environment: str = typer.Argument(..., help="Environment name, env_id, or slug"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Update environment description"
    ),
    tags: Optional[str] = typer.Option(
        None, "--tags", help="Replace tags (comma-separated, use '' to clear)"
    ),
    add_tag: Optional[list[str]] = typer.Option(None, "--add-tag", help="Append a tag (repeatable)"),
    remove_tag: Optional[list[str]] = typer.Option(None, "--remove-tag", help="Remove a tag (repeatable)"),
    kernel_name: Optional[str] = typer.Option(
        None, "--kernel-name", help="Update Jupyter kernel display name"
    ),
    system_site_packages: Optional[str] = typer.Option(
        None,
        "--system-site-packages",
        help="Enable/disable inheriting packages from parent Python (true/false)",
    ),
):
    """View or update environment configuration.

    Without flags, prints the current config. With flags, applies the updates
    and prints the new state. Multiple update flags can be combined in one call.

    Examples:
        $ qbraid envs config 5dcc
        $ qbraid envs config myenv --description "Quantum sim env"
        $ qbraid envs config myenv --tags "quantum,sim,gpu"
        $ qbraid envs config myenv --add-tag gpu --add-tag cuda
        $ qbraid envs config myenv --remove-tag deprecated
        $ qbraid envs config myenv --system-site-packages true
    """
    from qbraid_core.services.environments.registry import EnvironmentRegistryManager

    console = Console()
    registry = EnvironmentRegistryManager()
    entry = None
    env_id = None

    # Resolve env_id by env_id, name, or slug
    try:
        entry = registry.get_environment(environment)
        env_id = environment
    except Exception:  # pylint: disable=broad-exception-caught
        pass

    if not entry:
        result = registry.find_by_name(environment)
        if result:
            env_id, entry = result

    if not entry:
        try:
            result = registry.find_by_slug(environment)
            if result:
                env_id, entry = result
        except Exception:  # pylint: disable=broad-exception-caught
            pass

    if not entry or not env_id:
        console.print(f"[red]Environment '{environment}' not found.[/red]")
        raise typer.Exit(1)

    updates: dict = {}

    # Tags: --tags replaces wholesale; --add-tag/--remove-tag are incremental.
    # If both are given, --tags is applied first, then add/remove on top.
    if tags is not None:
        updates["tags"] = [t.strip() for t in tags.split(",") if t.strip()]
    if add_tag or remove_tag:
        current = list(updates.get("tags", entry.tags or []))
        for t in add_tag or []:
            if t not in current:
                current.append(t)
        for t in remove_tag or []:
            if t in current:
                current.remove(t)
        updates["tags"] = current

    if description is not None:
        updates["description"] = description
    if kernel_name is not None:
        updates["kernel_name"] = kernel_name

    if updates:
        try:
            registry.update_environment(env_id, **updates)
        except Exception as err:  # pylint: disable=broad-exception-caught
            console.print(f"[red]Failed to update registry:[/red] {err}")
            raise typer.Exit(1)

    if system_site_packages is not None:
        from qbraid_core.services.environments.packages import set_system_site_packages

        ssp_value = system_site_packages.lower() in ("true", "1", "yes", "on")
        try:
            set_system_site_packages(env_id, ssp_value)
        except Exception as err:  # pylint: disable=broad-exception-caught
            console.print(f"[red]Failed to update system_site_packages:[/red] {err}")
            raise typer.Exit(1)

    # Reload entry to reflect any updates, then print current state
    entry = registry.get_environment(env_id)

    from qbraid_core.services.environments.packages import get_system_site_packages

    try:
        ssp = get_system_site_packages(env_id)
        ssp_status = "[green]enabled[/green]" if ssp else "[yellow]disabled[/yellow]"
    except Exception:  # pylint: disable=broad-exception-caught
        ssp_status = "[dim]unknown[/dim]"

    console.print(f"\n[bold]{entry.name}[/bold] ({env_id})\n")
    if entry.slug:
        console.print(f"  Slug:                  {entry.slug}")
    console.print(f"  Description:           {entry.description or '[dim]none[/dim]'}")
    console.print(f"  Tags:                  {', '.join(entry.tags) if entry.tags else '[dim]none[/dim]'}")
    console.print(f"  Kernel name:           {entry.kernel_name or '[dim]auto[/dim]'}")
    console.print(f"  Visibility:            {entry.visibility}")
    if entry.groups:
        console.print(f"  Groups:                {', '.join(entry.groups)}")
    console.print(f"  System site-packages:  {ssp_status}")
    console.print(f"  Python version:        {entry.python_version or '[dim]unknown[/dim]'}")
    console.print(f"  Platform:              {entry.platform or '[dim]unknown[/dim]'}")
    console.print(f"  Type:                  {entry.type}")
    console.print(f"  Logo:                  {'set' if entry.logo_url else '[dim]default[/dim]'}")
    console.print(f"  Path:                  {entry.path}\n")


if __name__ == "__main__":
    envs_app()
