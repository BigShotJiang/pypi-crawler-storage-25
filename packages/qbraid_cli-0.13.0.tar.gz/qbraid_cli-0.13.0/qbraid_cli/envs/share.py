# Copyright (c) 2026, qBraid Development Team
# All rights reserved.

"""Share management CLI commands for qBraid environments."""

import typer
from rich.console import Console
from rich.table import Table

from qbraid_cli.handlers import run_progress_task

share_app = typer.Typer(
    help="Manage environment sharing via share codes.",
    no_args_is_help=True,
)
console = Console()


@share_app.command("list")
def share_list(
    slug: str = typer.Argument(..., help="Environment slug to check"),
):
    """List users with access.

    Shows all users with read or write access to the specified environment.

    Examples:
        $ qbraid envs share list my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def get_shared():
        client = EnvironmentManagerClient()
        return client.get_environment_shared_with(slug)

    try:
        result = run_progress_task(
            get_shared,
            description="Fetching shared users...",
            error_message="Failed to get shared users",
        )

        read_users = result.get("readAccessUsers", [])
        write_users = result.get("writeAccessUsers", [])

        console.print(f"\n📋 Sharing info for [bold]{slug}[/bold]\n")

        if not read_users and not write_users:
            console.print("[dim]This environment is not shared with anyone.[/dim]")
            console.print(
                f"\n💡 Generate a share code: " f"[bold]qbraid envs share create-code {slug}[/bold]"
            )
            return

        # Create table
        table = Table(show_header=True, header_style="bold")
        table.add_column("Email", style="cyan")
        table.add_column("Permissions", style="green")

        # Track users we've already added (to avoid duplicates)
        seen_emails = set()

        # Add write users first (they have more permissions)
        for email in write_users:
            if email not in seen_emails:
                table.add_row(str(email), "read, write, execute")
                seen_emails.add(email)

        # Add read-only users
        for email in read_users:
            if email not in seen_emails:
                table.add_row(str(email), "read, execute")
                seen_emails.add(email)

        console.print(table)
        console.print(f"\n[dim]Total: {len(seen_emails)} user(s)[/dim]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print("[red]❌ Environment not found.[/red]")
        elif "owner" in error_msg.lower():
            console.print("[red]❌ Only the owner can view sharing settings.[/red]")
        else:
            console.print(f"[red]❌ Failed to get shared users:[/red] {err}")
        raise typer.Exit(1)


@share_app.command("create-code")
def share_create_code(
    slug: str = typer.Argument(..., help="Environment slug to generate share code for"),
):
    """Generate a share code.

    Creates an 8-character code that others can redeem with
    'qbraid envs share redeem-code' to gain read access to your environment.
    Only the owner can generate codes.

    Generating a new code invalidates any previous code for this environment.

    Examples:
        $ qbraid envs share create-code my_env_abc123
        Share code: ABC12XYZ

        # Share the code with collaborators, they can redeem it with:
        $ qbraid envs share redeem-code ABC12XYZ
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def generate_code():
        client = EnvironmentManagerClient()
        return client.generate_share_code(slug)

    console.print(f"🔑 Generating share code for: [bold]{slug}[/bold]\n")

    try:
        result = run_progress_task(
            generate_code,
            description="Generating share code...",
            error_message="Failed to generate share code",
        )

        code = result.get("code", "N/A")
        console.print("[green]✅ Share code generated![/green]\n")
        console.print(f"   Code: [bold cyan]{code}[/bold cyan]\n")
        console.print("[dim]Share this code with collaborators. They can redeem it with:[/dim]")
        console.print(f"   [bold]qbraid envs share redeem-code {code}[/bold]\n")
        console.print("[dim]Note: Generating a new code will invalidate this one.[/dim]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print("[red]❌ Environment not found.[/red] Make sure it's uploaded first.")
        elif "owner" in error_msg.lower():
            console.print("[red]❌ Only the owner can generate a share code.[/red]")
        else:
            console.print(f"[red]❌ Failed to generate share code:[/red] {err}")
        raise typer.Exit(1)


@share_app.command("delete-code")
def share_delete_code(
    slug: str = typer.Argument(..., help="Environment slug to delete share code for"),
):
    """
    Delete the share code for an environment.

    Removes the share code, preventing new users from redeeming it.
    Users who have already redeemed the code keep their access.

    Examples:
        $ qbraid envs share delete-code my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def delete_code():
        client = EnvironmentManagerClient()
        return client.delete_share_code(slug)

    console.print(f"🗑️  Deleting share code for: [bold]{slug}[/bold]\n")

    try:
        run_progress_task(
            delete_code,
            description="Deleting share code...",
            error_message="Failed to delete share code",
        )

        console.print("[green]✅ Share code deleted![/green]")
        console.print("[dim]New users can no longer redeem the old code.[/dim]")

    except Exception as err:
        error_msg = str(err)
        if "not found" in error_msg.lower():
            console.print("[red]❌ Environment not found.[/red]")
        elif "owner" in error_msg.lower():
            console.print("[red]❌ Only the owner can delete the share code.[/red]")
        else:
            console.print(f"[red]❌ Failed to delete share code:[/red] {err}")
        raise typer.Exit(1)


@share_app.command("redeem-code")
def share_redeem_code(
    code: str = typer.Argument(..., help="Share code to redeem"),
):
    """Redeem a share code.

    Redeem a share code to gain access to an environment.
    Enter a share code received from an environment owner to gain read access.
    The code is case-insensitive.

    Examples:
        $ qbraid envs share redeem-code ABC12XYZ
        Access granted to: My Environment (my_env_abc123)

        # After redeeming, you can install the environment:
        $ qbraid envs install my_env_abc123
    """
    from qbraid_core.services.environments.client import EnvironmentManagerClient

    def redeem():
        client = EnvironmentManagerClient()
        return client.redeem_share_code(code)

    console.print(f"🎟️  Redeeming share code: [bold]{code.upper()}[/bold]\n")

    try:
        result = run_progress_task(
            redeem,
            description="Redeeming share code...",
            error_message="Failed to redeem share code",
        )

        env_name = result.get("name", "Unknown")
        env_slug = result.get("slug", "unknown")
        already_had = result.get("alreadyHadAccess", False)

        if already_had:
            console.print("[yellow]ℹ️  You already have access to this environment.[/yellow]\n")
        else:
            console.print("[green]✅ Access granted![/green]\n")

        console.print(f"   Environment: [bold]{env_name}[/bold]")
        console.print(f"   Slug: [cyan]{env_slug}[/cyan]\n")
        console.print(f"💡 Install with: [bold]qbraid envs install {env_slug}[/bold]")

    except Exception as err:
        error_msg = str(err)
        if "invalid" in error_msg.lower() or "not found" in error_msg.lower():
            console.print("[red]❌ Invalid share code.[/red] Please check and try again.")
        elif "owner" in error_msg.lower():
            console.print("[red]❌ You are already the owner of this environment.[/red]")
        else:
            console.print(f"[red]❌ Failed to redeem share code:[/red] {err}")
        raise typer.Exit(1)
