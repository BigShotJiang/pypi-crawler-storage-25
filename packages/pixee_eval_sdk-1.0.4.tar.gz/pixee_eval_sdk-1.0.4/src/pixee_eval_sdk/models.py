from __future__ import annotations

from typing import Any


def field(value: Any, render_hint: str, **metadata: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"value": value, "render_hint": render_hint}
    if metadata:
        result["metadata"] = metadata
    return result


def code_field(value: str, language: str = "python") -> dict[str, Any]:
    return field(value, "code", language=language)


def diff_field(value: str) -> dict[str, Any]:
    return field(value, "diff")


def markdown_field(value: str) -> dict[str, Any]:
    return field(value, "markdown")


def key_value_field(value: dict[str, Any]) -> dict[str, Any]:
    return field(value, "key_value")


def json_field(value: Any) -> dict[str, Any]:
    return field(value, "json")


def text_field(value: str) -> dict[str, Any]:
    return field(value, "text")


def badge_field(value: str, color: str = "gray") -> dict[str, Any]:
    return field(value, "badge", color=color)


# --- Rich render hint builders ---


def decoration(
    file_path: str,
    start_line: int,
    style: str,
    *,
    start_column: int | None = None,
    end_line: int | None = None,
    end_column: int | None = None,
) -> dict[str, Any]:
    return {
        "file_path": file_path,
        "start_line": start_line,
        "start_column": start_column,
        "end_line": end_line,
        "end_column": end_column,
        "style": style,
    }


def callout(
    file_path: str,
    line: int,
    message: str,
    style: str = "blue",
) -> dict[str, Any]:
    return {
        "file_path": file_path,
        "line": line,
        "message": message,
        "style": style,
    }


def banner_item(
    label: str,
    value: str,
    style: str | None = None,
) -> dict[str, str]:
    item: dict[str, str] = {"label": label, "value": value}
    if style:
        item["style"] = style
    return item


def step(
    label: str,
    description: str,
    file_path: str,
    line: int,
) -> dict[str, Any]:
    return {
        "label": label,
        "description": description,
        "file_path": file_path,
        "line": line,
    }


def annotated_code_field(
    files: dict[str, dict[str, str]],
    decorations: list[dict[str, Any]] | None = None,
    callouts: list[dict[str, Any]] | None = None,
    active_file: str | None = None,
) -> dict[str, Any]:
    value: dict[str, Any] = {
        "files": files,
        "decorations": decorations or [],
        "callouts": callouts or [],
    }
    if active_file:
        value["active_file"] = active_file
    return field(value, "annotated_code")


def banner_field(items: list[dict[str, str]]) -> dict[str, Any]:
    return field({"items": items}, "banner")


def step_list_field(
    steps: list[dict[str, Any]],
    linked_field: str | None = None,
) -> dict[str, Any]:
    if linked_field:
        return field({"steps": steps}, "step_list", linked_field=linked_field)
    return field({"steps": steps}, "step_list")


def case_layout(
    sections: list[dict[str, Any]],
) -> dict[str, Any]:
    return {"sections": sections}


def layout_section(
    fields: list[str],
    arrangement: str = "stack",
    sizes: list[str] | None = None,
) -> dict[str, Any]:
    section: dict[str, Any] = {"fields": fields, "arrangement": arrangement}
    if sizes:
        section["sizes"] = sizes
    return section
