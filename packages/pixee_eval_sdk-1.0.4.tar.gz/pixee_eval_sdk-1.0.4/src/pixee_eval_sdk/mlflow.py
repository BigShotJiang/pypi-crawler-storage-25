"""Convention-enforcing wrapper around MLflow for benchmark runs.

Example — using extractors (recommended)::

    session = BenchmarkSession(
        "triage-sonar", "triage", strategy="decision-tree",
        input_extractors={
            "finding_context": lambda c: text_field(c.context),
            "finding_metadata": lambda c: key_value_field(c.metadata),
        },
        output_extractors={
            "tldr": lambda r: text_field(r.tldr) if r.tldr else None,
            "full_report": lambda r: markdown_field(r.report) if r.report else None,
        },
    )

    with session:
        for case_obj in cases:
            with session.case(case_obj.name, case_obj=case_obj) as ct:
                result = await run(case_obj)
                ct.log_result(result)   # score + evaluations + outputs

Example — manual control::

    with BenchmarkSession("triage-sonar", "triage", strategy="default") as session:
        with session.case("SonarUnsafeDigest",
            inputs={"code": code_field(src, "java")},
        ) as ct:
            result = run_evaluation(...)
            ct.set_outputs({"reasoning": markdown_field(result.reasoning)})
            ct.log_score(0.85)
            ct.log_evaluation("correctness", passed=True, score=1.0)
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

import mlflow
import mlflow.tracking
from mlflow.entities import SpanType

from pixee_eval_sdk.conventions import Tags, feature_for_benchmark_type

logger = logging.getLogger(__name__)


def _safe(fn: Any, *args: Any, **kwargs: Any) -> Any:
    """Call *fn* and swallow exceptions, logging a warning on failure."""
    try:
        return fn(*args, **kwargs)
    except Exception:
        logger.warning("MLflow call failed: %s", fn.__name__, exc_info=True)
        return None


def _separate_render_hints(
    fields: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split ``{key: {value, render_hint, metadata?}}`` dicts into raw values and hints.

    Returns ``(raw_values, hints_spec)`` where *raw_values* maps each key to
    its plain ``value`` and *hints_spec* contains the render-hint declarations
    suitable for ``bcc.render_hints``.
    """
    raw: dict[str, Any] = {}
    hints: dict[str, Any] = {}
    for key, field in fields.items():
        if isinstance(field, dict) and "render_hint" in field:
            raw[key] = field["value"]
            hint_entry: dict[str, Any] = {"render_hint": field["render_hint"]}
            if field.get("metadata"):
                hint_entry["metadata"] = field["metadata"]
            hints[key] = hint_entry
        else:
            # Plain value — no render hint
            raw[key] = field
    return raw, hints


def _run_extractors(
    extractors: dict[str, Callable[..., Any]], obj: Any
) -> dict[str, Any]:
    """Run a dict of named extractors against *obj*, skipping ``None`` returns."""
    fields: dict[str, Any] = {}
    for key, fn in extractors.items():
        try:
            val = fn(obj)
        except Exception:
            logger.debug("Extractor %r failed", key, exc_info=True)
            continue
        if val is not None:
            fields[key] = val
    return fields


class CaseTrace:
    """Context manager for a single benchmark case within a run."""

    def __init__(
        self,
        session: BenchmarkSession,
        case_id: str,
        *,
        inputs: dict[str, Any] | None = None,
        iteration: int | None = None,
    ) -> None:
        self._session = session
        self._case_id = case_id
        self._iteration = iteration
        self._raw_inputs: dict[str, Any] = {}
        self._input_hints: dict[str, Any] = {}
        self._raw_outputs: dict[str, Any] = {}
        self._output_hints: dict[str, Any] = {}
        self._score: float | None = None
        self._evaluations: list[dict[str, Any]] = []
        self._span: Any = None
        self._span_cm: Any = None

        if inputs:
            self._raw_inputs, self._input_hints = _separate_render_hints(inputs)

    def __enter__(self) -> CaseTrace:
        span_name = self._case_id
        if self._iteration is not None:
            span_name = f"{self._case_id}[{self._iteration}]"

        # mlflow.start_span() is a context manager (generator), not a direct call.
        # We must enter it to get the actual LiveSpan object.
        try:
            self._span_cm = mlflow.start_span(
                name=span_name,
                span_type=SpanType.CHAIN,
            )
            self._span = self._span_cm.__enter__()
            if self._raw_inputs:
                self._span.set_inputs(self._raw_inputs)
        except Exception:
            logger.warning("Failed to start case span", exc_info=True)
            self._span = None
            self._span_cm = None
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return

        # Set span outputs
        if self._raw_outputs:
            _safe(self._span.set_outputs, self._raw_outputs)

        # Build render hints
        render_hints: dict[str, Any] = {}
        if self._input_hints:
            render_hints["inputs"] = self._input_hints
        if self._output_hints:
            render_hints["outputs"] = self._output_hints

        # Set trace tags and preview BEFORE ending the span, so they are
        # included in the trace payload when it is exported to the server.
        trace_tags: dict[str, str] = {Tags.CASE_ID: self._case_id}
        if render_hints:
            trace_tags[Tags.RENDER_HINTS] = json.dumps(render_hints)
        _safe(
            mlflow.update_current_trace,
            request_preview=self._case_id,
            tags=trace_tags,
        )

        # Exit the span context manager (ends the span, finalizes the trace)
        _safe(self._span_cm.__exit__, exc_type, exc_val, exc_tb)

        # Log assessments via mlflow.log_assessment() (works on finalized traces)
        trace_id = self._span.trace_id
        source = mlflow.entities.AssessmentSource(
            source_type="CODE", source_id="pixee-eval-sdk"
        )

        if self._score is not None:
            _safe(
                mlflow.log_assessment,
                trace_id=trace_id,
                assessment=mlflow.entities.Feedback(
                    name="score", value=self._score, source=source
                ),
            )

        for ev in self._evaluations:
            feedback_value = ev.get("value")
            if feedback_value is None:
                if ev.get("passed") is not None:
                    feedback_value = "yes" if ev["passed"] else "no"

            metadata = {}
            if ev.get("score") is not None:
                metadata["numeric_score"] = str(ev["score"])
            if ev.get("expectation") is not None:
                metadata["expectation"] = str(ev["expectation"])
                _safe(
                    mlflow.log_assessment,
                    trace_id=trace_id,
                    assessment=mlflow.entities.Expectation(
                        name=ev["name"],
                        value=ev["expectation"],
                        source=source,
                        metadata=metadata,
                    ),
                )

            _safe(
                mlflow.log_assessment,
                trace_id=trace_id,
                assessment=mlflow.entities.Feedback(
                    name=ev["name"],
                    value=feedback_value,
                    source=source,
                    rationale=ev.get("rationale"),
                    metadata=metadata or None,
                ),
            )

        # Record for session-level aggregation
        self._session._record_case(self._score, self._evaluations)

        return None

    def set_outputs(self, outputs: dict[str, Any]) -> None:
        """Set the outputs for this case. Accepts field-helper dicts."""
        self._raw_outputs, self._output_hints = _separate_render_hints(outputs)

    def log_score(self, score: float) -> None:
        """Set the overall score (0-1) for this case."""
        self._score = score

    def log_evaluation(
        self,
        name: str,
        *,
        passed: bool | None = None,
        score: float = 0.0,
        value: Any = None,
        rationale: str | None = None,
        expectation: Any = None,
    ) -> None:
        """Record a named evaluation criterion for this case."""
        self._evaluations.append(
            {
                "name": name,
                "passed": passed,
                "score": score,
                "value": value,
                "rationale": rationale,
                "expectation": expectation,
            }
        )

    def log_result(self, result: Any) -> None:
        """Log score, evaluations, and outputs from a duck-typed result object.

        Accepts any object with a ``.score`` attribute (float) and an
        ``.evaluations`` iterable of objects with ``name``, ``passed``,
        ``score``, ``value``, ``rationale``, and ``expectation`` attributes.

        If the session was created with ``output_extractors``, they are applied
        to ``result.result`` (the inner domain result) to set outputs
        automatically.  Each extractor receives the inner result and should
        return a field-helper dict or ``None`` to skip the field.

        This replaces::

            ct.log_score(result.score)
            for ev in result.evaluations:
                ct.log_evaluation(ev.name, passed=ev.passed, ...)
            if result.result:
                ct.set_outputs({...})

        With::

            ct.log_result(result)
        """
        if hasattr(result, "score"):
            self.log_score(result.score)
        for ev in getattr(result, "evaluations", []):
            self.log_evaluation(
                getattr(ev, "name", "unknown"),
                passed=getattr(ev, "passed", None),
                score=getattr(ev, "score", 0.0),
                value=getattr(ev, "value", None),
                rationale=getattr(ev, "rationale", None),
                expectation=getattr(ev, "expectation", None),
            )
        # Auto-extract outputs using session-level extractors
        inner = getattr(result, "result", None)
        if inner is not None and self._session._output_extractors:
            outputs = _run_extractors(self._session._output_extractors, inner)
            if outputs:
                self.set_outputs(outputs)

    def set_trace_tags(self, tags: dict[str, str]) -> None:
        """Set arbitrary trace tags beyond the default ``bcc.case_id``."""
        if tags:
            _safe(mlflow.update_current_trace, tags=tags)

    def set_span_attributes(self, attrs: dict[str, Any]) -> None:
        """Set attributes on the current span."""
        if self._span is not None:
            for key, value in attrs.items():
                _safe(self._span.set_attribute, key, value)

    def set_response_preview(self, preview: str) -> None:
        """Set the response preview for the current trace."""
        _safe(mlflow.update_current_trace, response_preview=preview)

    def append_inputs(self, inputs: dict[str, Any]) -> None:
        """Merge additional inputs into the span after the initial set."""
        new_raw, new_hints = _separate_render_hints(inputs)
        self._raw_inputs.update(new_raw)
        self._input_hints.update(new_hints)
        if self._span is not None:
            _safe(self._span.set_inputs, self._raw_inputs)


class BenchmarkSession:
    """Context manager for a full benchmark run.

    Creates (or reuses) an MLflow experiment with the appropriate BCC tags,
    starts a run, and provides the :meth:`case` method for logging individual
    case traces.
    """

    def __init__(
        self,
        benchmark_name: str,
        benchmark_type: str,
        *,
        strategy: str | None = None,
        params: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        mode: str = "experiment",
        suite: str | None = None,
        run_name: str | None = None,
        input_extractors: dict[str, Callable[..., Any]] | None = None,
        output_extractors: dict[str, Callable[..., Any]] | None = None,
    ) -> None:
        self._benchmark_name = benchmark_name
        self._benchmark_type = benchmark_type
        self._strategy = strategy
        self._params = params or {}
        self._user_tags = tags or []
        self._mode = mode
        self._suite = suite
        self._run_name = run_name
        self._input_extractors = input_extractors or {}
        self._output_extractors = output_extractors or {}

        self._run: Any = None
        self._experiment_id: str | None = None
        self._case_scores: list[float] = []
        self._case_evaluations: list[list[dict[str, Any]]] = []

    def __enter__(self) -> BenchmarkSession:
        # Create or get experiment
        client = mlflow.tracking.MlflowClient()
        exp = _safe(client.get_experiment_by_name, self._benchmark_name)
        if exp is not None:
            self._experiment_id = exp.experiment_id
        else:
            self._experiment_id = _safe(
                client.create_experiment, self._benchmark_name
            )

        # Set experiment-level tags
        if self._experiment_id:
            _safe(
                client.set_experiment_tag,
                self._experiment_id,
                Tags.BENCHMARK_TYPE,
                self._benchmark_type,
            )
            feature = feature_for_benchmark_type(self._benchmark_type)
            if feature:
                _safe(
                    client.set_experiment_tag,
                    self._experiment_id,
                    Tags.FEATURE,
                    feature,
                )

        # Start run
        _safe(mlflow.set_experiment, experiment_id=self._experiment_id)
        run_name = self._run_name or self._strategy or None
        self._run = _safe(mlflow.start_run, run_name=run_name)

        if self._run is None:
            return self

        # Log params
        if self._strategy:
            _safe(mlflow.log_param, "strategy", self._strategy)
        for k, v in self._params.items():
            val = json.dumps(v) if not isinstance(v, str) else v
            _safe(mlflow.log_param, k, val)

        # Set run-level tags
        _safe(mlflow.set_tag, Tags.MODE, self._mode)
        if self._suite:
            _safe(mlflow.set_tag, Tags.SUITE, self._suite)
        for tag in self._user_tags:
            _safe(mlflow.set_tag, f"{Tags.TAG_PREFIX}{tag}", tag)

        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._run is None:
            return

        # Compute and log aggregate metrics
        total = len(self._case_scores)
        if total > 0:
            avg_score = sum(self._case_scores) / total
            passed = sum(1 for s in self._case_scores if s >= 0.5)
            _safe(mlflow.log_metric, "aggregate_score", avg_score)
            _safe(mlflow.log_metric, "pass_rate", passed / total)
            _safe(mlflow.log_metric, "total_results", total)
            _safe(mlflow.log_metric, "passed_count", passed)

        # End run
        status = "FAILED" if exc_type is not None else "FINISHED"
        _safe(mlflow.end_run, status=status)

        return None

    @property
    def run_id(self) -> str | None:
        """The MLflow run ID, or None if not started."""
        if self._run is None:
            return None
        return self._run.info.run_id

    @property
    def experiment_id(self) -> str | None:
        """The MLflow experiment ID."""
        return self._experiment_id

    def case(
        self,
        case_id: str,
        *,
        case_obj: Any = None,
        inputs: dict[str, Any] | None = None,
        iteration: int | None = None,
    ) -> CaseTrace:
        """Return a context manager for a single benchmark case.

        If ``case_obj`` is provided and the session has ``input_extractors``,
        inputs are automatically extracted from the case object.  Explicit
        ``inputs`` are merged on top (overriding extracted values).
        """
        extracted = (
            _run_extractors(self._input_extractors, case_obj)
            if case_obj is not None and self._input_extractors
            else {}
        )
        if inputs:
            extracted.update(inputs)
        return CaseTrace(
            self, case_id, inputs=extracted or None, iteration=iteration
        )

    def _record_case(
        self, score: float | None, evaluations: list[dict[str, Any]]
    ) -> None:
        """Called by CaseTrace.__exit__ to accumulate results for aggregation."""
        if score is not None:
            self._case_scores.append(score)
        self._case_evaluations.append(evaluations)

    def log_metrics(self, metrics: dict[str, float]) -> None:
        """Log run-level metrics (e.g. error_rate, avg_case_duration_seconds)."""
        _safe(mlflow.log_metrics, metrics)

    def log_artifact(self, path: str | Path) -> None:
        """Log a file as a run artifact."""
        _safe(mlflow.log_artifact, str(path))

    def set_notes(self, markdown: str) -> None:
        """Set run notes (displayed in the MLflow UI)."""
        _safe(mlflow.set_tag, "mlflow.note.content", markdown)

    def log_params(self, params: dict[str, Any]) -> None:
        """Log additional run parameters after construction."""
        for k, v in params.items():
            val = json.dumps(v) if not isinstance(v, str) else v
            _safe(mlflow.log_param, k, val)
