"""Phase 3 tests: policy cache, tracked client, customer sessions, enforcement.

Covers policy cache TTL/dedup/fail-open, tracked transport with provider parsers,
429 denial interception, TeeByteStream, proxy detection, customer sessions,
ns.openai/ns.anthropic shorthands.
"""
from __future__ import annotations

import json
import time
import pytest
import httpx
import respx

from nullspend import (
    NullSpend,
    NullSpendError,
    BudgetExceededError,
    MandateViolationError,
    SessionLimitExceededError,
    VelocityExceededError,
    TagBudgetExceededError,
    LoopDetectedError,
    CostEventInput,
    CostReportingConfig,
    CustomerSession,
    create_tracked_client,
)
from nullspend._policy_cache import (
    PolicyCache,
    PolicyResponse,
    PolicyBudget,
    MandateResult,
    BudgetResult,
    _parse_policy_response,
)
from nullspend._tracked_client import (
    TrackedTransport,
    TeeByteStream,
    _is_tracked_route,
    _is_proxied,
    _parse_denial_payload,
    _dispatch_denial,
    _estimate_cost_microdollars,
    _extract_model_from_body,
    _is_streaming_request,
    _is_streaming_response,
    _extract_openai_usage,
    _extract_anthropic_usage,
    _safe_denied,
)

BASE = "https://nullspend.dev"


# ---- Provider Parsers ----


class TestProviderParsers:
    def test_openai_tracked_routes(self):
        assert _is_tracked_route("openai", "https://api.openai.com/v1/chat/completions", "POST")
        assert _is_tracked_route("openai", "https://api.openai.com/v1/completions", "POST")
        assert _is_tracked_route("openai", "https://api.openai.com/v1/embeddings", "POST")
        assert not _is_tracked_route("openai", "https://api.openai.com/v1/models", "GET")
        assert not _is_tracked_route("openai", "https://api.openai.com/v1/chat/completions", "GET")

    def test_anthropic_tracked_routes(self):
        assert _is_tracked_route("anthropic", "https://api.anthropic.com/v1/messages", "POST")
        assert not _is_tracked_route("anthropic", "https://api.anthropic.com/v1/messages", "GET")
        assert not _is_tracked_route("anthropic", "https://api.anthropic.com/v1/models", "POST")

    def test_extract_model_from_body(self):
        assert _extract_model_from_body(b'{"model": "gpt-4o"}') == "gpt-4o"
        assert _extract_model_from_body(b'{"model": "claude-sonnet-4-5"}') == "claude-sonnet-4-5"
        assert _extract_model_from_body(b'{}') is None
        assert _extract_model_from_body(None) is None
        assert _extract_model_from_body(b'invalid json') is None

    def test_is_streaming_request(self):
        assert _is_streaming_request(b'{"stream": true}')
        assert not _is_streaming_request(b'{"stream": false}')
        assert not _is_streaming_request(b'{}')
        assert not _is_streaming_request(None)

    def test_extract_openai_usage(self):
        assert _extract_openai_usage({"usage": {"prompt_tokens": 100, "completion_tokens": 50}}) is not None
        assert _extract_openai_usage({"usage": {}}) is None
        assert _extract_openai_usage({}) is None

    def test_extract_anthropic_usage(self):
        usage, detail = _extract_anthropic_usage({"usage": {"input_tokens": 100, "output_tokens": 50}})
        assert usage is not None
        assert detail is None
        usage2, detail2 = _extract_anthropic_usage({"usage": {
            "input_tokens": 100, "output_tokens": 50,
            "cache_creation": {"ephemeral_5m_input_tokens": 200},
        }})
        assert usage2 is not None
        assert detail2 is not None


# ---- Policy Cache ----


class TestPolicyCache:
    def test_basic_fetch_and_cache(self):
        call_count = [0]
        def fetch():
            call_count[0] += 1
            return {"budget": None, "restrictions_active": False}

        pc = PolicyCache(fetch_fn=fetch, ttl_s=60.0)
        p1 = pc.get_policy()
        p2 = pc.get_policy()
        assert p1 is not None
        assert p1 is p2  # Same cached object
        assert call_count[0] == 1  # Only fetched once

    def test_ttl_expiry(self):
        call_count = [0]
        def fetch():
            call_count[0] += 1
            return {"budget": None, "restrictions_active": False}

        pc = PolicyCache(fetch_fn=fetch, ttl_s=0.01)
        pc.get_policy()
        time.sleep(0.02)
        pc.get_policy()
        assert call_count[0] == 2

    def test_fail_open_returns_stale(self):
        call_count = [0]
        def fetch():
            call_count[0] += 1
            if call_count[0] > 1:
                raise ConnectionError("network down")
            return {"budget": None, "restrictions_active": False}

        pc = PolicyCache(fetch_fn=fetch, ttl_s=0.01)
        p1 = pc.get_policy()
        assert p1 is not None
        time.sleep(0.02)
        p2 = pc.get_policy()
        assert p2 is p1  # Stale cache returned

    def test_fail_open_returns_none_if_no_cache(self):
        def fetch():
            raise ConnectionError("never works")

        errors = []
        pc = PolicyCache(fetch_fn=fetch, on_error=lambda e: errors.append(e))
        result = pc.get_policy()
        assert result is None
        assert len(errors) == 1

    def test_invalidate_clears_cache(self):
        call_count = [0]
        def fetch():
            call_count[0] += 1
            return {"budget": None, "restrictions_active": False}

        pc = PolicyCache(fetch_fn=fetch, ttl_s=60.0)
        pc.get_policy()
        assert call_count[0] == 1
        pc.invalidate()
        pc.get_policy()
        assert call_count[0] == 2

    def test_check_mandate_no_policy(self):
        pc = PolicyCache(fetch_fn=lambda: {"budget": None}, ttl_s=60.0)
        result = pc.check_mandate("openai", "gpt-4o")
        assert result.allowed is True

    def test_check_mandate_allowed(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "allowed_providers": ["openai", "anthropic"],
            "allowed_models": ["gpt-4o", "claude-sonnet-4-5"],
        }, ttl_s=60.0)
        pc.get_policy()
        assert pc.check_mandate("openai", "gpt-4o").allowed is True

    def test_check_mandate_provider_denied(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "allowed_providers": ["openai"],
        }, ttl_s=60.0)
        pc.get_policy()
        result = pc.check_mandate("anthropic", "claude-sonnet-4-5")
        assert result.allowed is False
        assert result.mandate == "allowed_providers"
        assert result.requested == "anthropic"

    def test_check_mandate_model_denied(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "allowed_models": ["gpt-4o-mini"],
        }, ttl_s=60.0)
        pc.get_policy()
        result = pc.check_mandate("openai", "gpt-5")
        assert result.allowed is False
        assert result.mandate == "allowed_models"

    def test_check_budget_allowed(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 5_000_000,
                "max_microdollars": 10_000_000,
                "spend_microdollars": 5_000_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        result = pc.check_budget(1_000_000)
        assert result.allowed is True
        assert result.remaining == 5_000_000

    def test_check_budget_denied(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 100,
                "max_microdollars": 10_000_000,
                "spend_microdollars": 9_999_900,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        result = pc.check_budget(1_000)
        assert result.allowed is False
        assert result.remaining == 100
        assert result.entity_type == "org"

    def test_get_session_limit(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "session_limit_microdollars": 5_000_000,
        }, ttl_s=60.0)
        pc.get_policy()
        assert pc.get_session_limit() == 5_000_000

    def test_get_session_limit_none(self):
        pc = PolicyCache(fetch_fn=lambda: {}, ttl_s=60.0)
        pc.get_policy()
        assert pc.get_session_limit() is None

    # ---- Fetch timeout (PERF-2) ----

    def test_fetch_timeout_falls_open_to_none(self):
        import time as _time
        errors: list[Exception] = []

        def slow_fetch() -> dict[str, Any]:
            _time.sleep(2.0)
            return {"budget": None}

        pc = PolicyCache(
            fetch_fn=slow_fetch,
            ttl_s=60.0,
            on_error=lambda e: errors.append(e),
            fetch_timeout_s=0.1,
        )
        result = pc.get_policy()
        assert result is None
        assert len(errors) == 1
        assert isinstance(errors[0], TimeoutError)

    def test_fetch_timeout_preserves_stale_cache(self):
        import time as _time
        calls = {"n": 0}

        def fetch() -> dict[str, Any]:
            calls["n"] += 1
            if calls["n"] == 1:
                return {"budget": None, "restrictions_active": False}
            _time.sleep(2.0)
            return {"budget": None, "restrictions_active": True}

        pc = PolicyCache(
            fetch_fn=fetch,
            ttl_s=0.05,
            fetch_timeout_s=0.1,
        )
        first = pc.get_policy()
        assert first is not None
        _time.sleep(0.1)  # age past TTL
        stale = pc.get_policy()  # second fetch hangs → falls open to first
        assert stale is first

    def test_fetch_timeout_disabled_when_zero(self):
        pc = PolicyCache(
            fetch_fn=lambda: {"budget": None},
            ttl_s=60.0,
            fetch_timeout_s=0,
        )
        assert pc.get_policy() is not None


# ---- Proxy Detection ----


class TestProxyDetection:
    def test_url_origin_match(self):
        assert _is_proxied("https://proxy.nullspend.dev/v1/chat/completions", "https://proxy.nullspend.dev", None)

    def test_url_origin_mismatch(self):
        assert not _is_proxied("https://api.openai.com/v1/chat/completions", "https://proxy.nullspend.dev", None)

    def test_port_strict(self):
        assert not _is_proxied("https://proxy.nullspend.dev:8443/v1/chat", "https://proxy.nullspend.dev", None)

    def test_no_proxy_url(self):
        assert not _is_proxied("https://api.openai.com/v1/chat", None, None)

    def test_header_fallback(self):
        assert _is_proxied("https://custom.proxy.com/v1/chat", "https://proxy.nullspend.dev",
                          {"x-nullspend-key": "ns_live_sk_..."})


# ---- Denial Parsing ----


class TestDenialParsing:
    def test_parses_budget_exceeded(self):
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {"entity_type": "org", "entity_id": "org-1",
                           "remaining_microdollars": 0,
                           "budget_limit_microdollars": 10_000_000,
                           "budget_spend_microdollars": 10_000_000},
                "upgrade_url": "https://nullspend.dev/upgrade",
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed is not None
        assert parsed["code"] == "budget_exceeded"
        assert parsed["upgrade_url"] == "https://nullspend.dev/upgrade"

    def test_returns_none_without_denied_header(self):
        response = httpx.Response(429, json={"error": {"code": "rate_limited"}})
        assert _parse_denial_payload(response) is None

    def test_returns_none_for_malformed_body(self):
        response = httpx.Response(429, headers={"x-nullspend-denied": "1"}, text="not json")
        assert _parse_denial_payload(response) is None

    def test_dispatch_budget_exceeded(self):
        with pytest.raises(BudgetExceededError):
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {"remaining_microdollars": 0},
                "upgrade_url": "https://nullspend.dev/upgrade",
                "retry_after_seconds": None,
            }, None, None)

    def test_dispatch_velocity_exceeded(self):
        with pytest.raises(VelocityExceededError):
            _dispatch_denial({
                "code": "velocity_exceeded",
                "details": {"limitMicrodollars": 1000, "windowSeconds": 60},
                "upgrade_url": None,
                "retry_after_seconds": 30,
            }, None, None)

    def test_dispatch_session_limit(self):
        with pytest.raises(SessionLimitExceededError):
            _dispatch_denial({
                "code": "session_limit_exceeded",
                "details": {"session_spend_microdollars": 5000, "session_limit_microdollars": 5000},
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, None, None)

    def test_dispatch_tag_budget(self):
        with pytest.raises(TagBudgetExceededError):
            _dispatch_denial({
                "code": "tag_budget_exceeded",
                "details": {"tag_key": "env", "tag_value": "prod"},
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, None, None)

    def test_dispatch_unknown_code_surfaces_drift(self):
        errors = []
        _dispatch_denial({
            "code": "new_unknown_code",
            "details": {},
            "upgrade_url": None,
            "retry_after_seconds": None,
        }, None, lambda e: errors.append(e))
        assert len(errors) == 1
        assert "Unknown denial code" in str(errors[0])


# ---- Safe Denied ----


class TestSafeDenied:
    def test_calls_callback(self):
        reasons = []
        _safe_denied(lambda r: reasons.append(r), {"type": "budget"}, None)
        assert len(reasons) == 1

    def test_swallows_callback_error(self):
        def bad_callback(r):
            raise ValueError("boom")
        errors = []
        _safe_denied(bad_callback, {"type": "budget"}, lambda e: errors.append(e))
        assert len(errors) == 1

    def test_none_callback_is_noop(self):
        _safe_denied(None, {"type": "budget"}, None)  # Should not raise


# ---- Cost Estimation ----


class TestCostEstimation:
    def test_known_model(self):
        est = _estimate_cost_microdollars("openai", "gpt-4o", b'{"max_tokens": 1000}')
        assert est > 0

    def test_unknown_model(self):
        # P1 fix: unknown models return $1 fallback (not 0) to prevent
        # fail-open budget bypass on new/unpriced models.
        assert _estimate_cost_microdollars("openai", "unknown", None) == 1_000_000

    def test_no_model(self):
        # P1 fix: no model returns $1 fallback (not 0)
        assert _estimate_cost_microdollars("openai", None, None) == 1_000_000

    def test_default_max_tokens(self):
        est = _estimate_cost_microdollars("openai", "gpt-4o", b'{}')
        assert est > 0  # Uses default 4096


# ---- Customer Session ----


class TestCustomerSession:
    def test_creates_session(self):
        ns = NullSpend(api_key="test")
        session = ns.customer("acme")
        assert isinstance(session, CustomerSession)
        assert session.customer_id == "acme"
        assert session.openai is not None
        assert session.anthropic is not None
        ns.close()

    def test_validates_customer_id(self):
        ns = NullSpend(api_key="test")
        with pytest.raises(NullSpendError, match="invalid characters"):
            ns.customer("acme/evil")
        ns.close()

    def test_caches_per_provider(self):
        ns = NullSpend(api_key="test")
        session = ns.customer("acme")
        assert session.openai is session.openai  # Same object (property is cached on session)
        ns.close()


# ---- ns.openai / ns.anthropic shorthands ----


class TestClientShorthands:
    def test_openai_shorthand(self):
        ns = NullSpend(api_key="test")
        client = ns.openai
        assert isinstance(client, httpx.Client)
        assert ns.openai is client  # Cached
        ns.close()

    def test_anthropic_shorthand(self):
        ns = NullSpend(api_key="test")
        client = ns.anthropic
        assert isinstance(client, httpx.Client)
        assert ns.anthropic is client
        ns.close()


# ---- Proxy URL Validation ----


class TestProxyUrlValidation:
    def test_valid_https(self):
        ns = NullSpend(api_key="test", proxy_url="https://proxy.nullspend.dev")
        assert ns._proxy_url == "https://proxy.nullspend.dev"
        ns.close()

    def test_valid_http(self):
        ns = NullSpend(api_key="test", proxy_url="http://localhost:8080")
        assert ns._proxy_url == "http://localhost:8080"
        ns.close()

    def test_rejects_ftp(self):
        with pytest.raises(NullSpendError, match="http or https"):
            NullSpend(api_key="test", proxy_url="ftp://bad.com")

    def test_strips_trailing_slash(self):
        ns = NullSpend(api_key="test", proxy_url="https://proxy.nullspend.dev/")
        assert ns._proxy_url == "https://proxy.nullspend.dev"
        ns.close()

    def test_env_var_fallback(self):
        import os
        from unittest.mock import patch
        with patch.dict(os.environ, {"NULLSPEND_PROXY_URL": "https://env-proxy.example.com"}):
            ns = NullSpend(api_key="test")
            assert ns._proxy_url == "https://env-proxy.example.com"
            ns.close()


# ---- Parse Policy Response ----


class TestParsePolicyResponse:
    def test_full_response(self):
        policy = _parse_policy_response({
            "budget": {
                "remaining_microdollars": 5_000_000,
                "max_microdollars": 10_000_000,
                "spend_microdollars": 5_000_000,
                "period_end": "2026-05-01",
                "entity_type": "org",
                "entity_id": "org-1",
            },
            "allowed_models": ["gpt-4o"],
            "allowed_providers": ["openai"],
            "restrictions_active": True,
            "session_limit_microdollars": 1_000_000,
        })
        assert policy.budget is not None
        assert policy.budget.remaining_microdollars == 5_000_000
        assert policy.allowed_models == ["gpt-4o"]
        assert policy.restrictions_active is True
        assert policy.session_limit_microdollars == 1_000_000

    def test_empty_response(self):
        policy = _parse_policy_response({})
        assert policy.budget is None
        assert policy.allowed_models is None
        assert policy.restrictions_active is False


# ---- TrackedTransport end-to-end ----


class TestTrackedTransportE2E:
    def _make_transport(self, handler, provider="openai", **kwargs):
        """Helper to create a TrackedTransport with a mock inner transport."""
        mock_transport = httpx.MockTransport(handler)
        return TrackedTransport(
            transport=mock_transport,
            provider=provider,
            **kwargs,
        )

    def test_header_injection(self):
        """Customer, tags, traceId, actionId headers are injected."""
        captured = {}
        def handler(request):
            captured.update(dict(request.headers))
            return httpx.Response(200, json={"id": "msg_1", "usage": {"prompt_tokens": 10, "completion_tokens": 5}})

        transport = self._make_transport(
            handler,
            customer="acme",
            tags={"env": "prod"},
            trace_id="trace-123",
            action_id="act-456",
        )
        client = httpx.Client(transport=transport)
        client.post("https://api.openai.com/v1/chat/completions",
                     json={"model": "gpt-4o", "messages": []})

        assert captured["x-nullspend-customer"] == "acme"
        assert json.loads(captured["x-nullspend-tags"]) == {"env": "prod"}
        assert captured["x-nullspend-traceid"] == "trace-123"
        assert captured["x-nullspend-actionid"] == "act-456"
        client.close()

    def test_non_tracked_route_passes_through(self):
        """Non-tracked routes (GET, /models) are passed through without modification."""
        def handler(request):
            return httpx.Response(200, json={"models": []})

        transport = self._make_transport(handler, customer="acme")
        client = httpx.Client(transport=transport)
        resp = client.get("https://api.openai.com/v1/models")
        assert resp.status_code == 200
        # Customer header should still be injected (headers are added for ALL requests)
        client.close()

    def test_non_streaming_cost_extraction(self):
        """Non-streaming response extracts usage and queues cost event."""
        queued = []
        def handler(request):
            return httpx.Response(200, json={
                "id": "chatcmpl-1",
                "model": "gpt-4o",
                "choices": [{"message": {"content": "Hello"}}],
                "usage": {"prompt_tokens": 100, "completion_tokens": 50},
            })

        transport = self._make_transport(
            handler,
            queue_cost=lambda evt: queued.append(evt),
        )
        client = httpx.Client(transport=transport)
        resp = client.post("https://api.openai.com/v1/chat/completions",
                          json={"model": "gpt-4o", "messages": [{"role": "user", "content": "Hi"}]})
        assert resp.status_code == 200

        assert len(queued) == 1
        assert queued[0].provider == "openai"
        assert queued[0].model == "gpt-4o"
        assert queued[0].input_tokens == 100
        assert queued[0].output_tokens == 50
        assert queued[0].cost_microdollars > 0
        client.close()

    def test_streaming_cost_extraction_via_tee(self):
        """Streaming response wraps stream with TeeByteStream for cost extraction."""
        queued = []

        class SSEStream(httpx.SyncByteStream):
            def __iter__(self):
                yield b'data: {"model": "gpt-4o", "choices": [{"delta": {"content": "Hi"}}]}\n\n'
                yield b'data: {"usage": {"prompt_tokens": 50, "completion_tokens": 20}}\n\n'
                yield b'data: [DONE]\n\n'

        def handler(request):
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=SSEStream(),
            )

        transport = self._make_transport(
            handler,
            queue_cost=lambda evt: queued.append(evt),
        )
        client = httpx.Client(transport=transport)
        resp = client.post("https://api.openai.com/v1/chat/completions",
                          json={"model": "gpt-4o", "messages": [], "stream": True})

        # Consumer must iterate the stream to trigger cost extraction
        chunks = list(resp.iter_bytes())
        assert len(chunks) >= 1  # May be combined into fewer chunks
        # Cost event should be queued after stream completes
        assert len(queued) == 1
        assert queued[0].input_tokens == 50
        assert queued[0].output_tokens == 20
        client.close()

    def test_proxy_429_interception(self):
        """Proxy 429 with X-NullSpend-Denied header raises BudgetExceededError."""
        def handler(request):
            return httpx.Response(429, headers={"x-nullspend-denied": "1"}, json={
                "error": {
                    "code": "budget_exceeded",
                    "message": "Budget exceeded",
                    "details": {"remaining_microdollars": 0},
                },
            })

        transport = self._make_transport(
            handler,
            proxy_url="https://api.openai.com",
            enforcement=True,
        )
        client = httpx.Client(transport=transport)
        with pytest.raises(BudgetExceededError):
            client.post("https://api.openai.com/v1/chat/completions",
                       json={"model": "gpt-4o", "messages": []})
        client.close()

    def test_upstream_429_not_intercepted(self):
        """Upstream 429 (no X-NullSpend-Denied) passes through as-is."""
        def handler(request):
            return httpx.Response(429, json={"error": {"message": "rate limited"}})

        transport = self._make_transport(
            handler,
            proxy_url="https://api.openai.com",
            enforcement=True,
        )
        client = httpx.Client(transport=transport)
        resp = client.post("https://api.openai.com/v1/chat/completions",
                          json={"model": "gpt-4o", "messages": []})
        assert resp.status_code == 429  # Passed through, no exception
        client.close()

    def test_stream_injection_adds_include_usage(self):
        """OpenAI streaming requests get stream_options.include_usage injected."""
        captured_body = {}
        def handler(request):
            captured_body["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "x", "usage": {"prompt_tokens": 1, "completion_tokens": 1}})

        transport = self._make_transport(handler)
        client = httpx.Client(transport=transport)
        client.post("https://api.openai.com/v1/chat/completions",
                    json={"model": "gpt-4o", "messages": [], "stream": True})

        assert captured_body["body"]["stream_options"]["include_usage"] is True
        client.close()

    def test_session_spend_accumulation(self):
        """Session spend accumulates across multiple requests."""
        queued = []
        call_count = [0]
        def handler(request):
            call_count[0] += 1
            return httpx.Response(200, json={
                "model": "gpt-4o",
                "usage": {"prompt_tokens": 100, "completion_tokens": 50},
            })

        transport = self._make_transport(
            handler,
            session_id="sess-1",
            queue_cost=lambda evt: queued.append(evt),
        )
        client = httpx.Client(transport=transport)

        for _ in range(3):
            client.post("https://api.openai.com/v1/chat/completions",
                       json={"model": "gpt-4o", "messages": []})

        assert len(queued) == 3
        assert transport._session_spend > 0
        # Each request costs the same, so spend should be 3x a single event
        assert transport._session_spend == queued[0].cost_microdollars * 3
        client.close()

    def test_enforcement_mandate_block(self):
        """Mandate violation blocks the request before it reaches the transport."""
        from nullspend._policy_cache import PolicyCache

        pc = PolicyCache(fetch_fn=lambda: {
            "allowed_models": ["gpt-4o-mini"],
        }, ttl_s=60.0)
        pc.get_policy()

        def handler(request):
            pytest.fail("Transport should not be called when mandate blocks")

        transport = self._make_transport(
            handler,
            enforcement=True,
            policy_cache=pc,
        )
        client = httpx.Client(transport=transport)
        with pytest.raises(MandateViolationError):
            client.post("https://api.openai.com/v1/chat/completions",
                       json={"model": "gpt-5", "messages": []})
        client.close()

    def test_enforcement_budget_block(self):
        """Budget exceeded blocks the request before it reaches the transport."""
        from nullspend._policy_cache import PolicyCache

        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 1,  # Almost nothing left
                "max_microdollars": 100,
                "spend_microdollars": 99,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
            },
        }, ttl_s=60.0)
        pc.get_policy()

        def handler(request):
            pytest.fail("Transport should not be called when budget blocks")

        transport = self._make_transport(
            handler,
            enforcement=True,
            policy_cache=pc,
        )
        client = httpx.Client(transport=transport)
        with pytest.raises(BudgetExceededError):
            client.post("https://api.openai.com/v1/chat/completions",
                       json={"model": "gpt-4o", "messages": []})
        client.close()

    def test_error_response_not_tracked(self):
        """Non-2xx responses are not cost-tracked."""
        queued = []
        def handler(request):
            return httpx.Response(400, json={"error": {"message": "bad request"}})

        transport = self._make_transport(
            handler,
            queue_cost=lambda evt: queued.append(evt),
        )
        client = httpx.Client(transport=transport)
        resp = client.post("https://api.openai.com/v1/chat/completions",
                          json={"model": "gpt-4o", "messages": []})
        assert resp.status_code == 400
        assert len(queued) == 0  # No cost event for errors
        client.close()

    def test_anthropic_non_streaming_extraction(self):
        """Anthropic non-streaming response extracts usage correctly."""
        queued = []
        def handler(request):
            return httpx.Response(200, json={
                "id": "msg_1",
                "model": "claude-sonnet-4-5",
                "usage": {"input_tokens": 200, "output_tokens": 100},
            })

        transport = self._make_transport(
            handler,
            provider="anthropic",
            queue_cost=lambda evt: queued.append(evt),
        )
        client = httpx.Client(transport=transport)
        client.post("https://api.anthropic.com/v1/messages",
                    json={"model": "claude-sonnet-4-5", "messages": []})

        assert len(queued) == 1
        assert queued[0].provider == "anthropic"
        assert queued[0].input_tokens == 200
        client.close()


# ---- NullSpend.close() cleanup ----


class TestCloseCleanup:
    def test_close_closes_tracked_clients(self):
        ns = NullSpend(api_key="test")
        openai_client = ns.openai
        anthropic_client = ns.anthropic
        ns.close()
        # After close, the tracked clients should be closed
        # httpx.Client raises RuntimeError if used after close
        with pytest.raises(RuntimeError):
            openai_client.get("https://example.com")


# ---- _queue_cost_direct observability ----


class TestQueueCostDirectLogging:
    @respx.mock
    def test_logs_first_error(self, caplog):
        import logging
        respx.post(f"{BASE}/api/cost-events").mock(
            return_value=httpx.Response(500, json={"error": {"message": "Internal"}})
        )
        ns = NullSpend(api_key="key")
        with caplog.at_level(logging.WARNING, logger="nullspend"):
            ns._queue_cost_direct(CostEventInput(
                provider="openai", model="gpt-4o",
                input_tokens=100, output_tokens=50, cost_microdollars=1500,
            ))
        assert any("Failed to report cost event" in r.message for r in caplog.records)
        ns.close()


# ---- Finalization Reserve ----


class TestFinalizationReservePolicyCache:
    """Tests for finalization_reserve_microdollars in PolicyCache."""

    def test_check_budget_strict_block_subtracts_reserve(self):
        """strict_block policy subtracts reserve from remaining."""
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 10_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 90_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 3_000,
                "policy": "strict_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        # effective remaining = 10_000 - 3_000 = 7_000
        result = pc.check_budget(7_000)
        assert result.allowed is True
        assert result.remaining == 7_000

        # 8_000 > 7_000 effective → denied
        result2 = pc.check_budget(8_000)
        assert result2.allowed is False
        assert result2.remaining == 7_000

    def test_check_budget_soft_block_no_subtraction(self):
        """soft_block policy does NOT subtract reserve."""
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 10_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 90_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 3_000,
                "policy": "soft_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        # effective remaining = 10_000 (no subtraction for soft_block)
        result = pc.check_budget(10_000)
        assert result.allowed is True
        assert result.remaining == 10_000

    def test_check_budget_finalize_true_skips_reserve(self):
        """finalize=True bypasses reserve subtraction even on strict_block."""
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 10_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 90_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 3_000,
                "policy": "strict_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()

        # Without finalize, effective = 7_000 → 10_000 exceeds
        denied = pc.check_budget(10_000)
        assert denied.allowed is False

        # With finalize, effective = 10_000 → exactly fits
        allowed = pc.check_budget(10_000, finalize=True)
        assert allowed.allowed is True
        assert allowed.remaining == 10_000

    def test_check_budget_no_reserve_unchanged(self):
        """When reserve is 0, behavior is unchanged."""
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 5_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 95_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 0,
                "policy": "strict_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        result = pc.check_budget(5_000)
        assert result.allowed is True
        assert result.remaining == 5_000

    def test_get_finalization_reserve_returns_value(self):
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 10_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 90_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 3_000,
                "policy": "strict_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()
        assert pc.get_finalization_reserve() == 3_000

    def test_get_finalization_reserve_returns_none_no_budget(self):
        pc = PolicyCache(fetch_fn=lambda: {}, ttl_s=60.0)
        pc.get_policy()
        assert pc.get_finalization_reserve() is None

    def test_get_finalization_reserve_returns_none_no_cache(self):
        pc = PolicyCache(fetch_fn=lambda: {}, ttl_s=60.0)
        # Don't call get_policy — cache is None
        assert pc.get_finalization_reserve() is None

    def test_parse_policy_response_with_finalization_reserve(self):
        """_parse_policy_response correctly parses finalization_reserve_microdollars and policy."""
        policy = _parse_policy_response({
            "budget": {
                "remaining_microdollars": 5_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 95_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 2_000,
                "policy": "soft_block",
            },
        })
        assert policy.budget is not None
        assert policy.budget.finalization_reserve_microdollars == 2_000
        assert policy.budget.policy == "soft_block"

    def test_parse_policy_response_defaults(self):
        """Missing finalization_reserve defaults to 0, missing policy defaults to strict_block."""
        policy = _parse_policy_response({
            "budget": {
                "remaining_microdollars": 5_000,
                "max_microdollars": 100_000,
                "spend_microdollars": 95_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
            },
        })
        assert policy.budget is not None
        assert policy.budget.finalization_reserve_microdollars == 0
        assert policy.budget.policy == "strict_block"


class TestFinalizationReserveTrackedTransport:
    """Tests for finalize option in TrackedTransport."""

    def _make_transport(self, handler, provider="openai", **kwargs):
        mock_transport = httpx.MockTransport(handler)
        return TrackedTransport(
            transport=mock_transport,
            provider=provider,
            **kwargs,
        )

    def test_finalize_true_injects_header_in_proxy_mode(self):
        """finalize=True injects X-NullSpend-Finalize: 1 header."""
        captured = {}
        def handler(request):
            captured.update(dict(request.headers))
            return httpx.Response(200, json={
                "id": "msg_1",
                "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            })

        transport = self._make_transport(
            handler,
            proxy_url="https://api.openai.com",
            finalize=True,
        )
        client = httpx.Client(transport=transport)
        client.post("https://api.openai.com/v1/chat/completions",
                     json={"model": "gpt-4o", "messages": []})
        assert captured.get("x-nullspend-finalize") == "1"
        client.close()

    def test_finalize_false_no_header(self):
        """finalize=False does NOT inject X-NullSpend-Finalize header."""
        captured = {}
        def handler(request):
            captured.update(dict(request.headers))
            return httpx.Response(200, json={
                "id": "msg_1",
                "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            })

        transport = self._make_transport(
            handler,
            proxy_url="https://api.openai.com",
            finalize=False,
        )
        client = httpx.Client(transport=transport)
        client.post("https://api.openai.com/v1/chat/completions",
                     json={"model": "gpt-4o", "messages": []})
        assert "x-nullspend-finalize" not in captured
        client.close()

    def test_finalize_default_no_header(self):
        """Default (no finalize) does NOT inject X-NullSpend-Finalize header."""
        captured = {}
        def handler(request):
            captured.update(dict(request.headers))
            return httpx.Response(200, json={
                "id": "msg_1",
                "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            })

        transport = self._make_transport(handler)
        client = httpx.Client(transport=transport)
        client.post("https://api.openai.com/v1/chat/completions",
                     json={"model": "gpt-4o", "messages": []})
        assert "x-nullspend-finalize" not in captured
        client.close()

    def test_finalize_true_direct_mode_passes_to_check_budget(self):
        """finalize=True in direct mode passes finalize to policy_cache.check_budget.

        The gpt-4o cost estimate is ~43.5B microdollars (tokens * perMTok rates,
        not divided by 1M — this is a known pre-existing scale in the estimate).
        We set remaining just above the estimate so the reserve makes the difference.
        """
        from nullspend._policy_cache import PolicyCache

        # gpt-4o estimate ≈ 43_460_000_000
        # Set remaining = 44_000_000_000 with reserve = 1_000_000_000
        # → effective without finalize = 43_000_000_000 < estimate → denied
        # → effective with finalize = 44_000_000_000 > estimate → allowed
        pc = PolicyCache(fetch_fn=lambda: {
            "budget": {
                "remaining_microdollars": 44_000_000_000,
                "max_microdollars": 100_000_000_000,
                "spend_microdollars": 56_000_000_000,
                "period_end": None,
                "entity_type": "org",
                "entity_id": "org-1",
                "finalization_reserve_microdollars": 1_000_000_000,
                "policy": "strict_block",
            },
        }, ttl_s=60.0)
        pc.get_policy()

        def handler(request):
            return httpx.Response(200, json={
                "model": "gpt-4o",
                "usage": {"prompt_tokens": 1, "completion_tokens": 1},
            })

        # Without finalize, effective = 43B < ~43.46B estimate → denied
        transport_no_fin = self._make_transport(
            handler,
            enforcement=True,
            policy_cache=pc,
        )
        client = httpx.Client(transport=transport_no_fin)
        with pytest.raises(BudgetExceededError):
            client.post("https://api.openai.com/v1/chat/completions",
                         json={"model": "gpt-4o", "messages": []})
        client.close()

        # With finalize, effective = 44B > ~43.46B estimate → allowed
        transport_fin = self._make_transport(
            handler,
            enforcement=True,
            finalize=True,
            policy_cache=pc,
        )
        client2 = httpx.Client(transport=transport_fin)
        resp = client2.post("https://api.openai.com/v1/chat/completions",
                             json={"model": "gpt-4o", "messages": []})
        assert resp.status_code == 200
        client2.close()


class TestFinalizationReserveDenialParsing:
    """Tests for finalization fields in denial parsing."""

    def test_budget_exceeded_with_finalization_fields(self):
        """Denial with finalization fields populates BudgetExceededError."""
        with pytest.raises(BudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {
                    "remaining_microdollars": 0,
                    "entity_type": "org",
                    "entity_id": "org-1",
                    "budget_limit_microdollars": 100_000,
                    "budget_spend_microdollars": 100_000,
                    "finalization_reserve_microdollars": 3_000,
                    "finalization_remaining_microdollars": 7_000,
                },
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, None, None)
        err = exc_info.value
        assert err.finalization_reserve_microdollars == 3_000
        assert err.finalization_remaining_microdollars == 7_000

    def test_customer_budget_exceeded_with_finalization_fields(self):
        """Customer denial with finalization fields populates BudgetExceededError."""
        with pytest.raises(BudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "customer_budget_exceeded",
                "details": {
                    "remaining_microdollars": 500,
                    "customer_id": "cust-1",
                    "budget_limit_microdollars": 50_000,
                    "budget_spend_microdollars": 49_500,
                    "finalization_reserve_microdollars": 5_000,
                    "finalization_remaining_microdollars": 10_000,
                },
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, None, None)
        err = exc_info.value
        assert err.entity_type == "customer"
        assert err.finalization_reserve_microdollars == 5_000
        assert err.finalization_remaining_microdollars == 10_000

    def test_budget_exceeded_without_finalization_fields_defaults_none(self):
        """Denial without finalization fields: None (backward compat)."""
        with pytest.raises(BudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {
                    "remaining_microdollars": 0,
                },
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, None, None)
        err = exc_info.value
        assert err.finalization_reserve_microdollars is None
        assert err.finalization_remaining_microdollars is None

    def test_denial_on_denied_callback_gets_finalization_fields(self):
        """on_denied callback receives finalization fields in reason dict."""
        reasons = []
        with pytest.raises(BudgetExceededError):
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {
                    "remaining_microdollars": 0,
                    "finalization_reserve_microdollars": 2_000,
                    "finalization_remaining_microdollars": 8_000,
                },
                "upgrade_url": None,
                "retry_after_seconds": None,
            }, lambda r: reasons.append(r), None)
        assert len(reasons) == 1
        assert reasons[0]["finalizationReserve"] == 2_000
        assert reasons[0]["finalizationRemaining"] == 8_000


# ---- Recovery Field ----


class TestRecoveryFieldParsing:
    """Tests for recovery field parsing in _parse_denial_payload."""

    def test_parses_recovery_from_denial_body(self):
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {"budget_limit_microdollars": 5_000_000},
                "recovery": {
                    "retryable": False,
                    "owner_action_required": True,
                    "retry_after_seconds": None,
                    "docs": None,
                },
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed is not None
        assert parsed["recovery"] is not None
        assert parsed["recovery"]["retryable"] is False
        assert parsed["recovery"]["owner_action_required"] is True
        assert parsed["recovery"]["retry_after_seconds"] is None
        assert parsed["recovery"]["docs"] is None

    def test_recovery_none_when_absent(self):
        """Old proxy without recovery field — backward compat."""
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {},
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed is not None
        assert parsed["recovery"] is None

    def test_recovery_none_when_malformed(self):
        """recovery is a string instead of dict — treated as absent."""
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {},
                "recovery": "not a dict",
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed is not None
        assert parsed["recovery"] is None

    def test_recovery_with_retry_after_seconds(self):
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1", "retry-after": "45"},
            json={"error": {
                "code": "velocity_exceeded",
                "message": "Rate limit exceeded",
                "details": {},
                "recovery": {
                    "retryable": True,
                    "owner_action_required": False,
                    "retry_after_seconds": 45,
                    "docs": None,
                },
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed is not None
        assert parsed["recovery"]["retryable"] is True
        assert parsed["recovery"]["retry_after_seconds"] == 45

    def test_recovery_docs_preserves_string(self):
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {},
                "recovery": {
                    "retryable": False,
                    "owner_action_required": True,
                    "retry_after_seconds": None,
                    "docs": "https://docs.nullspend.dev/errors/budget-exceeded",
                },
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed["recovery"]["docs"] == "https://docs.nullspend.dev/errors/budget-exceeded"

    def test_recovery_docs_empty_string_becomes_none(self):
        """Empty docs string treated as None — prevents agents fetching empty URL."""
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "budget_exceeded",
                "message": "Budget exceeded",
                "details": {},
                "recovery": {
                    "retryable": False,
                    "owner_action_required": True,
                    "retry_after_seconds": None,
                    "docs": "",
                },
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed["recovery"]["docs"] is None

    def test_recovery_negative_retry_after_becomes_none(self):
        response = httpx.Response(
            429,
            headers={"x-nullspend-denied": "1"},
            json={"error": {
                "code": "velocity_exceeded",
                "message": "Rate limit exceeded",
                "details": {},
                "recovery": {
                    "retryable": True,
                    "owner_action_required": False,
                    "retry_after_seconds": -5,
                    "docs": None,
                },
            }},
        )
        parsed = _parse_denial_payload(response)
        assert parsed["recovery"]["retry_after_seconds"] is None


class TestRecoveryFieldOnErrors:
    """Tests that recovery is passed through to error classes."""

    def test_budget_exceeded_has_recovery(self):
        recovery = {"retryable": False, "owner_action_required": True,
                     "retry_after_seconds": None, "docs": None}
        with pytest.raises(BudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {"remaining_microdollars": 0},
                "upgrade_url": None,
                "retry_after_seconds": None,
                "recovery": recovery,
            }, None, None)
        assert exc_info.value.recovery == recovery

    def test_velocity_exceeded_has_recovery(self):
        recovery = {"retryable": True, "owner_action_required": False,
                     "retry_after_seconds": 45, "docs": None}
        with pytest.raises(VelocityExceededError) as exc_info:
            _dispatch_denial({
                "code": "velocity_exceeded",
                "details": {"limitMicrodollars": 10_000_000},
                "upgrade_url": None,
                "retry_after_seconds": 45,
                "recovery": recovery,
            }, None, None)
        assert exc_info.value.recovery == recovery

    def test_session_limit_has_recovery(self):
        recovery = {"retryable": False, "owner_action_required": False,
                     "retry_after_seconds": None, "docs": None}
        with pytest.raises(SessionLimitExceededError) as exc_info:
            _dispatch_denial({
                "code": "session_limit_exceeded",
                "details": {"session_spend_microdollars": 1000,
                            "session_limit_microdollars": 1000},
                "upgrade_url": None,
                "retry_after_seconds": None,
                "recovery": recovery,
            }, None, None)
        assert exc_info.value.recovery == recovery

    def test_tag_budget_has_recovery(self):
        recovery = {"retryable": False, "owner_action_required": True,
                     "retry_after_seconds": None, "docs": None}
        with pytest.raises(TagBudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "tag_budget_exceeded",
                "details": {"tag_key": "env", "tag_value": "prod"},
                "upgrade_url": None,
                "retry_after_seconds": None,
                "recovery": recovery,
            }, None, None)
        assert exc_info.value.recovery == recovery

    def test_loop_detected_has_recovery(self):
        recovery = {"retryable": True, "owner_action_required": False,
                     "retry_after_seconds": 5, "docs": None}
        with pytest.raises(LoopDetectedError) as exc_info:
            _dispatch_denial({
                "code": "loop_detected",
                "details": {"type": "per_key", "model": "gpt-4o",
                            "callCount": 50, "windowSeconds": 60, "maxCalls": 50},
                "upgrade_url": None,
                "retry_after_seconds": None,
                "recovery": recovery,
            }, None, None)
        assert exc_info.value.recovery == recovery

    def test_recovery_none_when_proxy_omits(self):
        """Old proxy response without recovery — error.recovery is None."""
        with pytest.raises(BudgetExceededError) as exc_info:
            _dispatch_denial({
                "code": "budget_exceeded",
                "details": {"remaining_microdollars": 0},
                "upgrade_url": None,
                "retry_after_seconds": None,
                "recovery": None,
            }, None, None)
        assert exc_info.value.recovery is None
