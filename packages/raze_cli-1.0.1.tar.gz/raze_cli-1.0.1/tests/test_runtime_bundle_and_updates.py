from __future__ import annotations

import json
from pathlib import Path

from raze_cli.runtime_bundle import inspect_bundle, resolve_bundle_root, save_bundle_installation
from raze_cli.updates import build_update_status, compare_versions


def test_resolve_bundle_root_prefers_registered_bundle(monkeypatch, tmp_path: Path):
    data_dir = tmp_path / "data"
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    save_bundle_installation(bundle_root, data_dir=data_dir, source="test")

    resolved = resolve_bundle_root(data_dir=data_dir, workspace_root=tmp_path / "missing")

    assert resolved == bundle_root.resolve()


def test_inspect_bundle_reads_manifest_and_detects_bundled_dashboard(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / "services" / "core").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (root / "employees").mkdir()
    (root / "packages" / "shared-specs").mkdir(parents=True)

    manifest = {
        "bundle_version": "1.0.0",
        "components": {
            "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
            "dashboard": {
                "label": "Dashboard",
                "kind": "web-runtime",
                "source_path": "apps/dashboard",
                "dist_path": "apps/dashboard/dist",
                "required": True,
            },
            "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
            "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
        },
    }
    (root / "distribution" / "raze-bundle.json").write_text(json.dumps(manifest), encoding="utf-8")

    status = inspect_bundle(explicit_root=str(root))

    assert status.bundle_version == "1.0.0"
    assert status.dashboard_mode == "bundled-static"
    assert status.dashboard_dist_path == (root / "apps" / "dashboard" / "dist").resolve()
    assert any(component.key == "core" and component.present for component in status.components)


def test_compare_versions_handles_patch_updates():
    assert compare_versions("1.0.1", "1.0.0") > 0
    assert compare_versions("1.0.0", "1.0.0") == 0
    assert compare_versions("0.9.9", "1.0.0") < 0


def test_build_update_status_supports_local_manifest_file(tmp_path: Path):
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.2.0",
                "instructions": "Replace the local bundle manually.",
                "download_page_url": "https://example.com/raze/releases",
            }
        ),
        encoding="utf-8",
    )

    status = build_update_status(current_version="1.0.0", source=str(manifest_path))

    assert status["status"] == "update_available"
    assert status["update_available"] is True
    assert status["latest_version"] == "1.2.0"
