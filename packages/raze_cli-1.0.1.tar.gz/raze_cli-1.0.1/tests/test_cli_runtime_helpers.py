from __future__ import annotations

import sys
from pathlib import Path

from typer.testing import CliRunner


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "cli"))

from raze_cli import main  # noqa: E402

runner = CliRunner()


def _empty_bundle_status() -> main.BundleStatus:
    return main.BundleStatus(
        root=None,
        manifest_path=None,
        manifest={},
        components=[],
        bundle_version=None,
        release_manifest_url=None,
        dashboard_mode="unavailable",
        dashboard_source_path=None,
        dashboard_dist_path=None,
        core_path=None,
    )


def test_get_source_tree_root_detects_expected_layout(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    (workspace / "services" / "core").mkdir(parents=True)
    (workspace / "apps" / "dashboard").mkdir(parents=True)

    monkeypatch.setattr(main, "get_workspace_root", lambda: workspace)

    assert main.get_source_tree_root() == workspace


def test_render_dashboard_command_returns_none_without_source_tree(monkeypatch):
    monkeypatch.setattr(main, "get_source_tree_root", lambda: None)

    assert main._render_dashboard_command(52000) is None


def test_render_dashboard_command_uses_dashboard_source_dir(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    dashboard_dir = workspace / "apps" / "dashboard"
    dashboard_dir.mkdir(parents=True)
    (workspace / "services" / "core").mkdir(parents=True)

    monkeypatch.setattr(main, "get_source_tree_root", lambda: workspace)

    command = main._render_dashboard_command(52000)
    assert command == f"cd {dashboard_dir} && npm run dev -- --port 52000"


def test_can_launch_installed_core_returns_false_when_package_is_missing(monkeypatch):
    def fake_find_spec(_name: str):
        raise ModuleNotFoundError("No module named 'raze_core'")

    monkeypatch.setattr(main.importlib.util, "find_spec", fake_find_spec)

    assert main._can_launch_installed_core() is False


def test_dashboard_handles_missing_runtime_without_traceback(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None: _empty_bundle_status())
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: False)
    monkeypatch.setattr(main, "_render_dashboard_command", lambda port=52000: None)

    async def discover_none():
        return None

    monkeypatch.setattr(main.client, "discover_core", discover_none)

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 1
    assert "no local runtime bundle is registered on this machine yet" in result.output.lower()
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output
    assert "Traceback" not in result.output


def test_setup_skips_dashboard_prompt_when_runtime_is_missing(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None: _empty_bundle_status())
    monkeypatch.setattr(main, "_dashboard_launch_ready", lambda status: False)
    monkeypatch.setattr(main, "_create_config", lambda config_path: config_path.write_text("providers: []\n", encoding="utf-8"))

    result = runner.invoke(main.app, ["setup"])

    assert result.exit_code == 0
    assert "Skipping dashboard launch until the local runtime bundle is ready." in result.output
    assert "Open the local dashboard after setup?" not in result.output


def test_doctor_reports_missing_runtime_guidance(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None: _empty_bundle_status())
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: False)

    async def raise_missing_core():
        raise RuntimeError("Core unavailable")

    monkeypatch.setattr(main.client, "run_doctor", raise_missing_core)

    result = runner.invoke(main.app, ["doctor"])

    assert result.exit_code == 0
    assert "Core runtime: not installed and no local runtime bundle is registered" in result.output
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output
