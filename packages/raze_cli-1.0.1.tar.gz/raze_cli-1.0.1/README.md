# RAZE CLI

RAZE CLI is the local command line entrypoint for the RAZE runtime.

## Install

```bash
pip install raze-cli
```

This installs the CLI manager. The local Core and Dashboard runtime still need to be available through a registered RAZE runtime bundle.

Optional gRPC transport support:

```bash
pip install "raze-cli[grpc]"
```

## First run

```bash
raze setup
raze bootstrap --bundle-dir <bundle-root>
raze doctor
raze dashboard
```

If you only installed `raze-cli` and have not unpacked the local RAZE runtime bundle yet, `raze dashboard` will now stop with guided recovery steps instead of crashing.

## What the CLI expects

- A writable local runtime directory via `RAZE_DATA_DIR` or the default user data path
- A registered local runtime bundle or reachable `raze_core` runtime when you want to use Core-backed commands
- A bundled dashboard build that Core can serve, or the dashboard source tree for dev-only launches
- When `grpcio` is installed and Core exposes the localhost control plane, the CLI will prefer gRPC automatically and fall back to REST when needed

## Common commands

```bash
raze config
raze list
raze install research-employee
raze run research-employee
raze reset-db --yes
```
