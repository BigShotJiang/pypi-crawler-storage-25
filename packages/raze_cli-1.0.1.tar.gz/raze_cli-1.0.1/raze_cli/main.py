"""RAZE CLI entrypoint."""

from __future__ import annotations

import asyncio
import importlib.util
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
import typer
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.table import Table

from raze_cli import __version__
from raze_cli.api_client import RazeAPIClient
from raze_cli.runtime_bundle import (
    BundleStatus,
    find_source_tree_root,
    inspect_bundle,
    load_update_status,
    save_bundle_installation,
    save_update_status,
)
from raze_cli.updates import build_update_status


app = typer.Typer(
    name="raze",
    help="RAZE - Local-First AI Workforce Platform",
    no_args_is_help=True,
)
console = Console()
client = RazeAPIClient()


def get_raze_dir() -> Path:
    return Path(os.environ.get("RAZE_DATA_DIR", Path.home() / ".raze"))


def get_db_path() -> Path:
    return get_raze_dir() / "raze.db"


def get_runtime_path() -> Path:
    return get_raze_dir() / "runtime.json"


def get_workspace_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def get_source_tree_root() -> Optional[Path]:
    return find_source_tree_root(get_workspace_root())


async def _dashboard_running(port: int) -> bool:
    try:
        async with httpx.AsyncClient(timeout=2.0) as http:
            response = await http.get(f"http://127.0.0.1:{port}")
        return response.status_code < 500
    except Exception:
        return False


def _render_dashboard_command(port: int = 52000) -> Optional[str]:
    source_root = get_source_tree_root()
    if not source_root:
        return None
    dashboard_dir = source_root / "apps" / "dashboard"
    return f"cd {dashboard_dir} && npm run dev -- --port {port}"


def _can_launch_installed_core() -> bool:
    try:
        if importlib.util.find_spec("raze_core") is None:
            return False
        return importlib.util.find_spec("raze_core.main") is not None
    except ModuleNotFoundError:
        return False
    except Exception:
        return False


def _bundle_has_core(status: BundleStatus) -> bool:
    return bool(status.core_path and status.core_path.exists())


def _bundle_has_dashboard(status: BundleStatus) -> bool:
    return status.dashboard_mode != "unavailable"


def _dashboard_launch_ready(status: BundleStatus) -> bool:
    has_core = _bundle_has_core(status) or _can_launch_installed_core()
    has_dashboard = _bundle_has_dashboard(status) or (_render_dashboard_command() is not None)
    return has_core and has_dashboard


def _print_runtime_recovery_guidance(status: BundleStatus):
    if status.root:
        console.print("  [yellow]The registered local runtime bundle is incomplete.[/yellow]")
        if not _bundle_has_core(status):
            console.print("  Missing Core runtime: [dim]services\\core[/dim]")
        if not _bundle_has_dashboard(status):
            console.print("  Missing dashboard runtime: [dim]apps\\dashboard\\dist[/dim] or dashboard source tree")
        if status.manifest_path:
            console.print(f"  Registered manifest: [dim]{status.manifest_path}[/dim]")
        console.print("  Replace or repair the local RAZE bundle, then rerun [cyan]raze bootstrap --bundle-dir <bundle-root>[/cyan].")
        return

    console.print("  [yellow]The RAZE CLI is installed, but no local runtime bundle is registered on this machine yet.[/yellow]")
    console.print("  Expected next steps:")
    console.print("  1. Download or unpack the local RAZE runtime bundle.")
    console.print("  2. Run [cyan]raze bootstrap --bundle-dir <bundle-root>[/cyan]")
    console.print("  3. Run [cyan]raze doctor[/cyan] to verify Core and dashboard availability.")
    console.print("  4. Run [cyan]raze dashboard[/cyan]")
    console.print("  [dim]Expected bundle manifest: <bundle-root>\\distribution\\raze-bundle.json[/dim]")
    console.print("  [dim]Advanced fallback: install raze_core into the same Python environment only when you are intentionally using a developer layout.[/dim]")


def _bundle_status(explicit_root: Optional[str] = None) -> BundleStatus:
    status = inspect_bundle(
        explicit_root=explicit_root,
        data_dir=get_raze_dir(),
        workspace_root=get_workspace_root(),
    )
    if status.root:
        source = "explicit" if explicit_root else ("source-tree" if status.dashboard_mode == "source-tree" else "auto")
        try:
            save_bundle_installation(status.root, data_dir=get_raze_dir(), source=source)
        except PermissionError:
            pass
    return status


def _render_dashboard_bundle_command(status: BundleStatus, port: int) -> Optional[str]:
    if not status.dashboard_source_path or not status.dashboard_source_path.exists():
        return None
    return f"cd {status.dashboard_source_path} && npm run dev -- --port {port}"


def _render_core_command(status: BundleStatus) -> Optional[str]:
    if status.core_path and status.core_path.exists():
        return f"cd {status.core_path} && python -m raze_core.main"
    if _can_launch_installed_core():
        return "python -m raze_core.main"
    return None


def _render_update_summary(update_status: dict) -> str:
    status = update_status.get("status")
    if status == "update_available":
        return f"update available -> {update_status.get('latest_version')}"
    if status == "up_to_date":
        return f"up to date ({update_status.get('current_version')})"
    if status == "error":
        return f"check failed: {update_status.get('error') or 'unknown error'}"
    return "not configured"


def _start_core_process(status: BundleStatus) -> subprocess.Popen[bytes]:
    command = [sys.executable, "-m", "raze_core.main"]
    core_dir = status.core_path if status.core_path and status.core_path.exists() else None
    env = os.environ.copy()
    if status.root:
        env.setdefault("RAZE_BUNDLE_DIR", str(status.root))

    if sys.platform == "win32":
        creation_flags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
        return subprocess.Popen(
            command,
            cwd=str(core_dir) if core_dir else None,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation_flags,
        )

    return subprocess.Popen(
        command,
        cwd=str(core_dir) if core_dir else None,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _docker_local_status() -> tuple[str, str]:
    docker_path = shutil.which("docker")
    if not docker_path:
        return (
            "fail",
            "Docker Desktop is not installed. Install Docker Desktop for Windows before running Docker-backed employees.",
        )

    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception as exc:
        return ("warn", f"Docker is installed but could not be checked: {exc}")

    if result.returncode == 0:
        return ("pass", f"Docker Desktop is running ({docker_path})")

    stderr = (result.stderr or result.stdout or "").strip()
    lowered = stderr.lower()
    if "createfile" in lowered or "pipe/docker_engine" in lowered or "npipe" in lowered:
        return (
            "warn",
            "Docker Desktop is installed, but the Docker engine pipe is unavailable. Start Docker Desktop and wait for 'Engine running'.",
        )
    if "cannot connect to the docker daemon" in lowered or "is the docker daemon running" in lowered:
        return (
            "warn",
            "Docker is installed, but the Docker engine is not running. Start Docker Desktop and retry.",
        )
    return ("warn", f"Docker is installed but not ready: {stderr or 'unknown error'}")


@app.command()
def setup():
    """First-time setup: configure your RAZE environment."""
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] - First-time setup",
        border_style="cyan",
    ))

    raze_dir = get_raze_dir()
    raze_dir.mkdir(parents=True, exist_ok=True)
    console.print(f"  Data directory: [dim]{raze_dir}[/dim]")

    config_path = raze_dir / "config.yaml"
    if config_path.exists():
        if Confirm.ask("  Config already exists. Overwrite?", default=False):
            _create_config(config_path)
        else:
            console.print("  Keeping existing config.")
    else:
        _create_config(config_path)

    bundle_status = _bundle_status()
    if bundle_status.root:
        console.print(f"  Runtime bundle: [dim]{bundle_status.root}[/dim]")
        if not _bundle_has_core(bundle_status) or not _bundle_has_dashboard(bundle_status):
            _print_runtime_recovery_guidance(bundle_status)
    else:
        _print_runtime_recovery_guidance(bundle_status)

    console.print()
    if not _dashboard_launch_ready(bundle_status):
        console.print("  Skipping dashboard launch until the local runtime bundle is ready.")
        console.print("  [dim]Next step: raze bootstrap --bundle-dir <bundle-root>[/dim]")
        return

    if Confirm.ask("  Open the local dashboard after setup?", default=True):
        dashboard()


def _create_config(config_path: Path):
    console.print()
    console.print("  Configure your LLM provider:")
    console.print("  1. OpenAI")
    console.print("  2. Ollama (local)")
    console.print("  3. Anthropic")
    console.print("  4. Google Gemini")
    console.print("  5. Groq")
    console.print("  6. xAI")
    console.print("  7. Mistral")
    console.print("  8. OpenAI-compatible endpoint")
    console.print("  9. Custom endpoint")

    choice = Prompt.ask("  Select provider", choices=["1", "2", "3", "4", "5", "6", "7", "8", "9"], default="1")

    if choice == "1":
        provider_type = "openai"
        name = Prompt.ask("  Provider name", default="OpenAI")
        base_url = Prompt.ask("  Base URL", default="https://api.openai.com/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="gpt-4o")
    elif choice == "2":
        provider_type = "ollama"
        name = "Ollama"
        base_url = Prompt.ask("  Ollama URL", default="http://localhost:11434")
        api_key = None
        model = Prompt.ask("  Model", default="qwen3.5:9b")
    elif choice == "3":
        provider_type = "anthropic"
        name = Prompt.ask("  Provider name", default="Anthropic")
        base_url = Prompt.ask("  Base URL", default="https://api.anthropic.com/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="claude-sonnet-4-6")
    elif choice == "4":
        provider_type = "gemini"
        name = Prompt.ask("  Provider name", default="Google Gemini")
        base_url = Prompt.ask("  Base URL", default="https://generativelanguage.googleapis.com/v1beta")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="gemini-3-flash-preview")
    elif choice == "5":
        provider_type = "groq"
        name = Prompt.ask("  Provider name", default="Groq")
        base_url = Prompt.ask("  Base URL", default="https://api.groq.com/openai/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="llama-3.1-8b-instant")
    elif choice == "6":
        provider_type = "xai"
        name = Prompt.ask("  Provider name", default="xAI")
        base_url = Prompt.ask("  Base URL", default="https://api.x.ai/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="grok-4-1-fast-non-reasoning")
    elif choice == "7":
        provider_type = "mistral"
        name = Prompt.ask("  Provider name", default="Mistral")
        base_url = Prompt.ask("  Base URL", default="https://api.mistral.ai/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="mistral-large-latest")
    elif choice == "8":
        provider_type = "openai_compatible"
        name = Prompt.ask("  Provider name", default="OpenAI-compatible")
        base_url = Prompt.ask("  Base URL", default="https://example.com/v1")
        api_key = Prompt.ask("  API key", password=True)
        model = Prompt.ask("  Model", default="model-name")
    else:
        provider_type = "custom"
        name = Prompt.ask("  Provider name", default="Custom")
        base_url = Prompt.ask("  Base URL")
        api_key = Prompt.ask("  API key (optional)", password=True, default="") or None
        model = Prompt.ask("  Model")

    provider_id = name.lower().replace(" ", "-")

    # Validate URL format before persisting
    base_url = base_url.strip().rstrip("/")
    if not base_url.startswith(("http://", "https://")):
        console.print(f"  [yellow]Warning: Base URL '{base_url}' does not start with http:// or https://[/yellow]")
        console.print("  [yellow]This may cause connection failures. Please verify the URL.[/yellow]")

    config = {
        "providers": [{
            "id": provider_id,
            "name": name,
            "type": provider_type,
            "base_url": base_url,
            "api_key": api_key,
            "model": model,
            "is_default": True,
        }],
        "default_provider": provider_id,
        "fallback_provider": None,
        "core_version": "1.0.0",
    }

    with open(config_path, "w", encoding="utf-8") as handle:
        yaml.dump(config, handle, default_flow_style=False)

    console.print(f"  Config saved to [dim]{config_path}[/dim]")


@app.command()
def bootstrap(
    bundle_dir: Optional[str] = typer.Option(None, "--bundle-dir", help="Explicit path to a local RAZE runtime bundle"),
):
    """Register and validate the local runtime bundle for this machine."""
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] - Runtime bootstrap",
        border_style="cyan",
    ))

    status = _bundle_status(bundle_dir)
    if not status.root:
        console.print("  [red]No runtime bundle was detected.[/red]")
        console.print("  Set [cyan]RAZE_BUNDLE_DIR[/cyan], pass [cyan]--bundle-dir[/cyan], or run from the RAZE source tree.")
        console.print("  Expected bundle manifest: [dim]<bundle-root>\\distribution\\raze-bundle.json[/dim]")
        raise typer.Exit(1)

    console.print(f"  Bundle root: [dim]{status.root}[/dim]")
    if status.manifest_path:
        console.print(f"  Bundle manifest: [dim]{status.manifest_path}[/dim]")
    else:
        console.print("  [yellow]Bundle manifest is missing. Add distribution\\raze-bundle.json before packaging this runtime.[/yellow]")

    if status.bundle_version:
        console.print(f"  Bundle version: [cyan]{status.bundle_version}[/cyan]")
    console.print(f"  Dashboard mode: [cyan]{status.dashboard_mode}[/cyan]")

    table = Table(title="Bundle Components")
    table.add_column("Component", style="cyan")
    table.add_column("Kind")
    table.add_column("Required")
    table.add_column("Present")
    table.add_column("Path")

    missing_required = False
    for component in status.components:
        missing_required = missing_required or (component.required and not component.present)
        table.add_row(
            component.label,
            component.kind,
            "yes" if component.required else "no",
            "[green]yes[/green]" if component.present else "[red]no[/red]",
            str(component.path) if component.path else "-",
        )
    console.print(table)

    if missing_required:
        console.print("  [yellow]One or more required runtime components are missing.[/yellow]")
        console.print("  The CLI will keep guiding the user instead of assuming the bundle is complete.")
        raise typer.Exit(1)

    try:
        save_bundle_installation(status.root, data_dir=get_raze_dir(), source="bootstrap")
    except PermissionError:
        console.print("  [red]Could not save bundle registration because the active RAZE data directory is not writable.[/red]")
        console.print(f"  [dim]Set RAZE_DATA_DIR to a writable local path, then rerun: raze bootstrap --bundle-dir {status.root}[/dim]")
        raise typer.Exit(1)

    console.print("  Runtime bundle registration saved successfully.")


@app.command()
def dashboard():
    """Ensure Core is running, then open the local dashboard URL."""
    console.print(Panel.fit(
        "[bold magenta]RAZE[/bold magenta] - Dashboard launcher",
        border_style="magenta",
    ))

    bundle_status = _bundle_status()
    if bundle_status.root:
        console.print(f"  Runtime bundle: [dim]{bundle_status.root}[/dim]")
        if bundle_status.bundle_version:
            console.print(f"  Bundle version: [cyan]{bundle_status.bundle_version}[/cyan]")
        console.print(f"  Dashboard mode: [cyan]{bundle_status.dashboard_mode}[/cyan]")
    else:
        console.print("  [yellow]No registered runtime bundle found. The CLI will fall back to installed modules and source-tree hints.[/yellow]")

    console.print("  Checking for a running Core instance...")
    discovered_port = asyncio.run(client.discover_core())

    if discovered_port:
        console.print(f"  Core found on [cyan]{discovered_port}[/cyan]")
    else:
        manual_core_command = _render_core_command(bundle_status)
        if not manual_core_command:
            console.print("  [red]Core is not running and no launchable local Core runtime was detected.[/red]")
            _print_runtime_recovery_guidance(bundle_status)
            raise typer.Exit(1)

        console.print("  Core is not running. Starting it in the background...")
        try:
            proc = _start_core_process(bundle_status)
            console.print(f"  Core process started (PID {proc.pid}). Waiting for readiness...")
            time.sleep(0.5)
            if proc.poll() is not None:
                console.print("  [red]Core exited immediately before becoming ready.[/red]")
                console.print("  This usually means the local runtime is incomplete or the installed Core package is missing.")
                console.print(f"  [dim]Run manually: {manual_core_command}[/dim]")
                raise typer.Exit(1)
        except typer.Exit:
            raise
        except Exception as exc:
            console.print(f"  [red]Failed to start Core: {exc}[/red]")
            console.print(f"  [dim]Run manually: {manual_core_command}[/dim]")
            raise typer.Exit(1)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("  Waiting for Core to become ready...", total=None)
            ready = asyncio.run(client.wait_for_ready(timeout=20))
            if not ready:
                progress.update(task, description="  Core did not respond in time")
                console.print("  [yellow]Core may still be starting. Check the Core logs directly.[/yellow]")
                console.print(f"  [dim]Run manually: {manual_core_command}[/dim]")
                raise typer.Exit(1)
            progress.update(task, description="  Core is ready")

        discovered_port = asyncio.run(client.discover_core())

    if not discovered_port:
        console.print("  [red]Could not determine the active Core port.[/red]")
        raise typer.Exit(1)

    settings = None
    try:
        settings = asyncio.run(client.get_settings())
        console.print(f"  Core API: [cyan]{settings['core_url']}[/cyan]")
        if settings["core_port"] != settings["preferred_core_port"]:
            console.print(
                f"  [yellow]Preferred port {settings['preferred_core_port']} was unavailable. "
                f"Core is using {settings['core_port']} instead.[/yellow]"
            )
        console.print(f"  Database: [dim]{settings['db_path']}[/dim]")
    except Exception:
        console.print(f"  Core API: [cyan]http://127.0.0.1:{discovered_port}[/cyan]")

    dashboard_port = int(settings["dashboard_port"]) if settings else 52000

    if bundle_status.dashboard_mode == "bundled-static":
        dashboard_url = settings["core_url"] if settings else f"http://127.0.0.1:{discovered_port}"
        console.print("  Bundled dashboard build detected. Core can serve the dashboard directly.")
        console.print(f"  Opening dashboard: [bold cyan]{dashboard_url}[/bold cyan]")
        webbrowser.open(dashboard_url)
        return

    dashboard_url = f"http://localhost:{dashboard_port}"
    dashboard_running = asyncio.run(_dashboard_running(dashboard_port))
    if dashboard_running:
        console.print(f"  Opening dashboard: [bold cyan]{dashboard_url}[/bold cyan]")
        webbrowser.open(dashboard_url)
        return

    console.print(f"  [yellow]Dashboard dev server is not running on port {dashboard_port}.[/yellow]")
    dashboard_command = _render_dashboard_bundle_command(bundle_status, dashboard_port) or _render_dashboard_command(dashboard_port)
    if dashboard_command:
        console.print("  Start it in a new terminal:")
        console.print(f"  [dim]{dashboard_command}[/dim]")
        console.print("  The dashboard proxy reads the active Core port from the RAZE runtime state.")
        return

    console.print("  [yellow]No dashboard runtime was detected in the current bundle.[/yellow]")
    console.print("  Include a built dashboard at [dim]apps\\dashboard\\dist[/dim] for bundled serving, or keep the dashboard source tree for local dev launches.")


@app.command()
def install(
    employee: str = typer.Argument(..., help="Employee ID to install"),
    dev: Optional[str] = typer.Option(None, "--dev", help="Local path for dev mode install"),
):
    """Install an employee from the curated registry."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Installing {employee}...", total=None)
        try:
            result = asyncio.run(client.install_employee(employee, dev))
            progress.update(task, description=f"Installed {result['name']} v{result['version']}")
        except Exception as exc:
            progress.update(task, description=f"Failed: {exc}")
            raise typer.Exit(1)


@app.command()
def run(employee: str = typer.Argument(..., help="Employee ID to run")):
    """Start a Docker-backed employee."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Starting {employee}...", total=None)
        try:
            result = asyncio.run(client.run_employee(employee))
            progress.update(task, description=f"{result['name']} is {result['status']} on port {result.get('port', '?')}")
        except Exception as exc:
            progress.update(task, description=f"Failed: {exc}")
            raise typer.Exit(1)


@app.command()
def stop(employee: str = typer.Argument(..., help="Employee ID to stop")):
    """Stop a running employee."""
    try:
        result = asyncio.run(client.stop_employee(employee))
        console.print(f"  Stopped {result['name']}")
    except Exception as exc:
        console.print(f"  Failed: {exc}")
        raise typer.Exit(1)


@app.command(name="list")
def list_cmd(
    registry: bool = typer.Option(False, "--registry", help="Show available employees from the registry"),
):
    """List installed employees or browse the registry."""
    if registry:
        try:
            entries = asyncio.run(client.list_registry())
        except Exception as exc:
            console.print(f"  Failed to connect to Core: {exc}")
            raise typer.Exit(1)

        table = Table(title="RAZE Employee Registry")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Version")
        table.add_column("Installed", justify="center")

        for entry in entries:
            table.add_row(
                entry["id"],
                entry["name"],
                entry["version"],
                "yes" if entry.get("installed") else "",
            )
        console.print(table)
        return

    try:
        employees = asyncio.run(client.list_employees())
    except Exception as exc:
        console.print(f"  Failed to connect to Core: {exc}")
        raise typer.Exit(1)

    if not employees:
        console.print("  No employees installed. Run [cyan]raze install <employee>[/cyan]")
        return

    table = Table(title="Installed Employees")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Status")
    table.add_column("Port", justify="right")

    for employee in employees:
        table.add_row(
            employee["id"],
            employee["name"],
            employee["version"],
            employee["status"],
            str(employee.get("port", "")),
        )
    console.print(table)


@app.command()
def doctor():
    """Run system diagnostics."""
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] Doctor",
        border_style="cyan",
    ))

    try:
        report = asyncio.run(client.run_doctor())
    except Exception:
        console.print("  Core is not running. Running local checks only...")
        _run_local_doctor()
        return

    overall = report["overall"]
    color = {"healthy": "green", "degraded": "yellow", "unhealthy": "red"}.get(overall, "white")
    console.print(f"  Overall: [{color}]{overall.upper()}[/{color}]")
    console.print()

    for check in report["checks"]:
        icon = {"pass": "OK", "warn": "WARN", "fail": "FAIL"}.get(check["status"], "?")
        tone = {"pass": "green", "warn": "yellow", "fail": "red"}.get(check["status"], "white")
        console.print(f"  [{tone}]{icon}[/{tone}] {check['name']}: {check['message']}")
        if check.get("details"):
            console.print(f"    [dim]{check['details']}[/dim]")


def _run_local_doctor():
    console.print(f"  Python: {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    console.print(f"  Platform: {sys.platform}")

    docker_status, docker_message = _docker_local_status()
    docker_color = {"pass": "green", "warn": "yellow", "fail": "red"}.get(docker_status, "white")
    console.print(f"  [{docker_color}]Docker:[/{docker_color}] {docker_message}")

    config_path = get_raze_dir() / "config.yaml"
    if config_path.exists():
        console.print(f"  Config: {config_path}")
    else:
        console.print("  Config: not found. Run [cyan]raze setup[/cyan]")

    console.print(f"  Database: {get_db_path()}")
    runtime_path = get_runtime_path()
    if runtime_path.exists():
        console.print(f"  Runtime state: {runtime_path}")

    bundle_status = _bundle_status()
    if bundle_status.root:
        console.print(f"  Bundle root: {bundle_status.root}")
        console.print(f"  Dashboard mode: {bundle_status.dashboard_mode}")
        console.print(f"  Core runtime: {'bundled' if _bundle_has_core(bundle_status) else 'missing from bundle'}")
        if not _bundle_has_core(bundle_status) or not _bundle_has_dashboard(bundle_status):
            _print_runtime_recovery_guidance(bundle_status)
    elif _can_launch_installed_core():
        console.print("  Core runtime: installed in the active Python environment")
    else:
        console.print("  [yellow]Core runtime: not installed and no local runtime bundle is registered[/yellow]")
        _print_runtime_recovery_guidance(bundle_status)


@app.command()
def update(
    manifest: Optional[str] = typer.Option(
        None,
        "--manifest",
        help="Optional local file path or URL for a release manifest. Keeps publishing manual.",
    ),
):
    """Check for RAZE updates without performing any publish or install action."""
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] Update Check",
        border_style="cyan",
    ))

    bundle_status = _bundle_status()
    current_version = bundle_status.bundle_version or __version__
    release_source = manifest or bundle_status.release_manifest_url or os.environ.get("RAZE_RELEASE_MANIFEST_URL")
    default_instructions = (
        (bundle_status.manifest.get("manual_update") or {}).get("instructions")
        if bundle_status.manifest
        else None
    )

    status_payload = build_update_status(
        current_version=current_version,
        source=release_source,
        default_instructions=default_instructions,
    )
    try:
        save_update_status(status_payload, get_raze_dir())
    except PermissionError:
        console.print("  [yellow]Could not persist update status because the active RAZE data directory is not writable.[/yellow]")

    console.print(f"  Current version: [cyan]{status_payload['current_version']}[/cyan]")
    if bundle_status.root:
        console.print(f"  Bundle root: [dim]{bundle_status.root}[/dim]")

    status_label = status_payload["status"]
    if status_label == "update_available":
        console.print(f"  [yellow]Update available:[/yellow] {status_payload['latest_version']}")
    elif status_label == "up_to_date":
        console.print(f"  [green]Up to date.[/green] Latest known version is {status_payload['latest_version']}.")
    elif status_label == "error":
        console.print(f"  [red]Update check failed:[/red] {status_payload.get('error')}")
    else:
        console.print("  [yellow]Update checks are not configured for this local bundle yet.[/yellow]")

    if status_payload.get("source"):
        console.print(f"  Manifest source: [dim]{status_payload['source']}[/dim]")
    if status_payload.get("download_page_url"):
        console.print(f"  Download page: [dim]{status_payload['download_page_url']}[/dim]")
    if status_payload.get("instructions"):
        console.print(f"  Guidance: {status_payload['instructions']}")


@app.command()
def config():
    """Show current local RAZE configuration paths and provider settings."""
    config_path = get_raze_dir() / "config.yaml"
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] Configuration",
        border_style="cyan",
    ))

    if not config_path.exists():
        console.print("  No configuration found. Run [cyan]raze setup[/cyan]")
        raise typer.Exit(1)

    with open(config_path, encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}

    for provider in data.get("providers", []):
        console.print(f"  Provider: [cyan]{provider['name']}[/cyan] ({provider['type']})")
        console.print(f"    Base URL: {provider['base_url']}")
        console.print(f"    Model: {provider['model']}")
        console.print(f"    API Key: {'configured' if provider.get('api_key') else 'not set'}")

    console.print(f"\n  Config file: [dim]{config_path}[/dim]")
    console.print(f"  Data dir: [dim]{get_raze_dir()}[/dim]")
    console.print(f"  Database: [dim]{get_db_path()}[/dim]")
    console.print(f"  Runtime state: [dim]{get_runtime_path()}[/dim]")


@app.command()
def status():
    """Show the current local runtime status and important paths."""
    console.print(Panel.fit(
        "[bold cyan]RAZE[/bold cyan] Status",
        border_style="cyan",
    ))

    raze_dir = get_raze_dir()
    runtime_path = get_runtime_path()
    console.print(f"  Data dir: [dim]{raze_dir}[/dim]")
    console.print(f"  Config: [dim]{raze_dir / 'config.yaml'}[/dim]")
    console.print(f"  Database: [dim]{get_db_path()}[/dim]")
    console.print(f"  Runtime state: [dim]{runtime_path}[/dim]")

    bundle_status = _bundle_status()
    if bundle_status.root:
        console.print(f"  Bundle root: [dim]{bundle_status.root}[/dim]")
        if bundle_status.bundle_version:
            console.print(f"  Bundle version: [cyan]{bundle_status.bundle_version}[/cyan]")
        console.print(f"  Dashboard mode: [cyan]{bundle_status.dashboard_mode}[/cyan]")
        console.print(f"  Core runtime: [cyan]{'bundled' if _bundle_has_core(bundle_status) else 'missing from bundle'}[/cyan]")
    else:
        console.print("  [yellow]Bundle root: not registered[/yellow]")
        if _can_launch_installed_core():
            console.print("  Core runtime: [cyan]installed in the active Python environment[/cyan]")
        else:
            console.print("  [yellow]Core runtime: not installed[/yellow]")

    docker_status, docker_message = _docker_local_status()
    docker_color = {"pass": "green", "warn": "yellow", "fail": "red"}.get(docker_status, "white")
    console.print(f"  [{docker_color}]Docker:[/{docker_color}] {docker_message}")

    discovered_port = asyncio.run(client.discover_core())
    if discovered_port:
        console.print(f"  Core: [green]running[/green] on [cyan]{client.base_url}[/cyan]")
        try:
            settings = asyncio.run(client.get_settings())
            console.print(f"  Dashboard port: [cyan]{settings['dashboard_port']}[/cyan]")
            console.print(f"  gRPC status: [dim]{settings.get('grpc_status', 'disabled')}[/dim]")
        except Exception as exc:
            console.print(f"  [yellow]Core is reachable but settings lookup failed: {exc}[/yellow]")
    else:
        console.print("  [yellow]Core is not currently responding.[/yellow]")
        manual_core_command = _render_core_command(bundle_status)
        if manual_core_command:
            console.print(f"  [dim]Manual Core start: {manual_core_command}[/dim]")
        else:
            _print_runtime_recovery_guidance(bundle_status)

    dashboard_command = _render_dashboard_bundle_command(bundle_status, 52000) or _render_dashboard_command()
    if dashboard_command and bundle_status.dashboard_mode != "bundled-static":
        console.print(f"  [dim]Dashboard dev command: {dashboard_command}[/dim]")
    elif bundle_status.dashboard_mode == "bundled-static":
        console.print("  [dim]Dashboard build can be served directly by Core when available.[/dim]")

    update_status = load_update_status(get_raze_dir())
    if update_status:
        console.print(f"  Update status: [dim]{_render_update_summary(update_status)}[/dim]")


@app.command("reset-db")
def reset_db(
    yes: bool = typer.Option(False, "--yes", help="Reset without interactive confirmation"),
    backup: bool = typer.Option(True, "--backup/--no-backup", help="Backup the existing database first"),
):
    """Dev-safe local database reset."""
    db_path = get_db_path()
    if not db_path.exists():
        console.print(f"  Database does not exist yet: [dim]{db_path}[/dim]")
        return

    if not yes:
        confirmed = Confirm.ask(
            f"  Reset the local database at {db_path}? This is intended for disposable dev data only.",
            default=False,
        )
        if not confirmed:
            console.print("  Database reset cancelled.")
            return

    try:
        if backup:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            backup_path = db_path.with_name(f"raze.db.backup-{timestamp}")
            db_path.replace(backup_path)
            console.print(f"  Database moved to [dim]{backup_path}[/dim]")
        else:
            db_path.unlink()
            console.print(f"  Deleted [dim]{db_path}[/dim]")
    except PermissionError:
        console.print("  [red]Could not reset the database because it is in use. Stop RAZE Core first.[/red]")
        raise typer.Exit(1)

    console.print("  Local database reset complete. Restart RAZE Core to recreate the schema.")


if __name__ == "__main__":
    app()
