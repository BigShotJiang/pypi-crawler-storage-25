"""Helpers for resolving the local RAZE runtime bundle."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


BUNDLE_MANIFEST_RELATIVE_PATH = Path("distribution") / "raze-bundle.json"
BUNDLE_INSTALLATION_FILE = "bundle-installation.json"
UPDATE_STATUS_FILE = "update-status.json"


@dataclass
class BundleComponentStatus:
    key: str
    label: str
    kind: str
    required: bool
    path: Optional[Path]
    present: bool


@dataclass
class BundleStatus:
    root: Optional[Path]
    manifest_path: Optional[Path]
    manifest: dict[str, Any]
    components: list[BundleComponentStatus]
    bundle_version: Optional[str]
    release_manifest_url: Optional[str]
    dashboard_mode: str
    dashboard_source_path: Optional[Path]
    dashboard_dist_path: Optional[Path]
    core_path: Optional[Path]


def get_data_dir() -> Path:
    return Path(os.environ.get("RAZE_DATA_DIR", Path.home() / ".raze"))


def _load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, payload: dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path


def get_bundle_installation_path(data_dir: Optional[Path] = None) -> Path:
    return (data_dir or get_data_dir()) / BUNDLE_INSTALLATION_FILE


def load_bundle_installation(data_dir: Optional[Path] = None) -> dict[str, Any]:
    path = get_bundle_installation_path(data_dir)
    if not path.exists():
        return {}
    return _load_json(path)


def save_bundle_installation(
    root: Path,
    *,
    data_dir: Optional[Path] = None,
    source: str = "manual",
) -> Path:
    payload = {
      "bundle_root": str(root.resolve()),
      "source": source,
      "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    return _write_json(get_bundle_installation_path(data_dir), payload)


def get_update_status_path(data_dir: Optional[Path] = None) -> Path:
    return (data_dir or get_data_dir()) / UPDATE_STATUS_FILE


def load_update_status(data_dir: Optional[Path] = None) -> dict[str, Any]:
    path = get_update_status_path(data_dir)
    if not path.exists():
        return {}
    return _load_json(path)


def save_update_status(payload: dict[str, Any], data_dir: Optional[Path] = None) -> Path:
    return _write_json(get_update_status_path(data_dir), payload)


def find_source_tree_root(start: Optional[Path] = None) -> Optional[Path]:
    candidate = (start or Path(__file__).resolve().parents[2]).resolve()
    if (candidate / "services" / "core").exists() and (candidate / "apps" / "dashboard").exists():
        return candidate
    return None


def resolve_bundle_root(
    *,
    explicit_root: Optional[str] = None,
    data_dir: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> Optional[Path]:
    if explicit_root:
        candidate = Path(explicit_root).expanduser().resolve()
        if candidate.exists():
            return candidate

    env_root = os.environ.get("RAZE_BUNDLE_DIR", "").strip()
    if env_root:
        candidate = Path(env_root).expanduser().resolve()
        if candidate.exists():
            return candidate

    installation = load_bundle_installation(data_dir)
    registered_root = str(installation.get("bundle_root") or "").strip()
    if registered_root:
        candidate = Path(registered_root).expanduser().resolve()
        if candidate.exists():
            return candidate

    return find_source_tree_root(workspace_root)


def load_bundle_manifest(root: Path) -> tuple[Optional[Path], dict[str, Any]]:
    manifest_path = root / BUNDLE_MANIFEST_RELATIVE_PATH
    if not manifest_path.exists():
        return None, {}
    return manifest_path, _load_json(manifest_path)


def inspect_bundle(
    *,
    explicit_root: Optional[str] = None,
    data_dir: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> BundleStatus:
    root = resolve_bundle_root(explicit_root=explicit_root, data_dir=data_dir, workspace_root=workspace_root)
    if not root:
        return BundleStatus(
            root=None,
            manifest_path=None,
            manifest={},
            components=[],
            bundle_version=None,
            release_manifest_url=None,
            dashboard_mode="unavailable",
            dashboard_source_path=None,
            dashboard_dist_path=None,
            core_path=None,
        )

    manifest_path, manifest = load_bundle_manifest(root)
    components: list[BundleComponentStatus] = []
    dashboard_source_path: Optional[Path] = None
    dashboard_dist_path: Optional[Path] = None
    core_path: Optional[Path] = None

    for key, spec in (manifest.get("components") or {}).items():
        required = bool(spec.get("required", False))
        label = str(spec.get("label") or key.replace("_", " ").title())
        kind = str(spec.get("kind") or "unknown")

        if key == "dashboard":
            source_rel = spec.get("source_path")
            dist_rel = spec.get("dist_path")
            dashboard_source_path = (root / source_rel).resolve() if source_rel else None
            dashboard_dist_path = (root / dist_rel).resolve() if dist_rel else None
            present = bool(
                (dashboard_dist_path and (dashboard_dist_path / "index.html").exists())
                or (dashboard_source_path and dashboard_source_path.exists())
            )
            components.append(
                BundleComponentStatus(
                    key=key,
                    label=label,
                    kind=kind,
                    required=required,
                    path=dashboard_dist_path if dashboard_dist_path and (dashboard_dist_path / "index.html").exists() else dashboard_source_path,
                    present=present,
                )
            )
            continue

        rel_path = spec.get("path")
        component_path = (root / rel_path).resolve() if rel_path else None
        present = bool(component_path and component_path.exists())
        if key == "core":
            core_path = component_path
        components.append(
            BundleComponentStatus(
                key=key,
                label=label,
                kind=kind,
                required=required,
                path=component_path,
                present=present,
            )
        )

    if dashboard_dist_path and (dashboard_dist_path / "index.html").exists():
        dashboard_mode = "bundled-static"
    elif dashboard_source_path and dashboard_source_path.exists():
        dashboard_mode = "source-tree"
    else:
        dashboard_mode = "unavailable"

    return BundleStatus(
        root=root,
        manifest_path=manifest_path,
        manifest=manifest,
        components=components,
        bundle_version=str(manifest.get("bundle_version") or "") or None,
        release_manifest_url=str(manifest.get("release_manifest_url") or "") or None,
        dashboard_mode=dashboard_mode,
        dashboard_source_path=dashboard_source_path,
        dashboard_dist_path=dashboard_dist_path,
        core_path=core_path,
    )
