"""RAZE CLI - Local AI workforce platform."""

__version__ = "1.0.0"
