from __future__ import annotations
import json
from pathlib import Path
from core.infra.filesystem import Filesystem
from core.infra.config import Config
from core.infra.time_tracking import TimeTracker
from core.infra.token_tracking import TokenTracker
from core.domain.task import TaskManager
from core.domain.progress import ProgressTracker


def _resolve(task_id: str) -> tuple[Filesystem, Config, TaskManager]:
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    cfg = Config(fs)
    tm = TaskManager(fs, cfg)
    return fs, cfg, tm


def cmd_score(args: list[str]) -> dict:
    if args and args[0] == "record":
        return _cmd_score_record(args[1:])

    task_id = args[0] if args else "unknown"
    fs, _, tm = _resolve(task_id)
    try:
        task = tm.show(task_id)
    except Exception:
        return {"task_id": task_id, "scores": [], "average": None}

    # Read from task.json score_history (primary source)
    if task.score_history:
        latest = task.score_history[-1]
        return {
            "task_id": task_id,
            "scores": [{"role": r, "total": s} for r, s in latest.get("roles", {}).items()],
            "average": latest.get("average"),
            "iteration": latest.get("iteration"),
        }

    # Fallback: read from report files
    scores = []
    for it in range(1, task.iteration + 1):
        report_dir = fs.report_dir(task_id, it)
        if not report_dir.exists():
            continue
        for role in ["code_reviewer", "qa", "pm", "designer"]:
            rf = report_dir / "reviews" / f"{role}_report.json"
            if not fs.file_exists(rf):
                rf = report_dir / f"{role}_report.json"
            if fs.file_exists(rf):
                data = fs.read_json(rf)
                scores.append({
                    "role": role,
                    "iteration": it,
                    "total": data.get("total", 0),
                })
    avg = round(sum(s["total"] for s in scores) / len(scores), 2) if scores else None
    return {"task_id": task_id, "scores": scores, "average": avg}


def _cmd_score_record(args: list[str]) -> dict:
    """Record evaluation scores: kanban score record TASK-001 --code-reviewer 8.5 ..."""
    if not args:
        return {"error": "task_id required"}
    task_id = args[0]
    _, _, tm = _resolve(task_id)
    scores = {}
    i = 1
    while i < len(args):
        role = args[i].lstrip("-").replace("-", "_")
        if i + 1 < len(args):
            try:
                scores[role] = float(args[i + 1])
                i += 2
            except (ValueError, TypeError):
                i += 1
        else:
            i += 1

    if not scores:
        return {"error": "no scores provided"}

    task = tm.show(task_id)
    avg = round(sum(scores.values()) / len(scores), 2)
    # Update task scores
    current_scores = dict(task.scores)
    current_scores.update(scores)
    history = list(task.score_history)
    history.append({
        "iteration": task.iteration,
        "average": avg,
        "roles": scores,
    })
    tm.update(task_id, scores=current_scores, score_history=history)
    return {"task_id": task_id, "scores": scores, "average": avg, "recorded": True}


def cmd_summary(args: list[str]) -> dict:
    task_id = args[0] if args else "unknown"
    fs, _, tm = _resolve(task_id)
    try:
        task = tm.show(task_id)
    except Exception:
        return {"task_id": task_id, "summary": "task not found"}
    progress = ProgressTracker(fs)
    return {
        "task_id": task.id,
        "title": task.title,
        "status": task.status.value,
        "phase": task.phase.value,
        "iteration": task.iteration,
        "progress": progress.progress(task_id),
    }


def cmd_progress(args: list[str]) -> dict:
    task_id = args[0] if args else "unknown"
    fs, _, _ = _resolve(task_id)
    tracker = ProgressTracker(fs)
    return {"task_id": task_id, "progress": tracker.progress(task_id)}


def cmd_time(args: list[str]) -> dict:
    sub = args[0] if args else "report"
    # If first arg is not a known subcommand, treat as task_id for report
    if sub not in ("start", "end", "track", "report"):
        sub, task_id = "report", sub
    else:
        task_id = args[1] if len(args) > 1 else "unknown"
    fs, _, _ = _resolve(task_id)
    tracker = TimeTracker(fs.kanban_dir / "reports" / "time_tracking.json")

    if sub == "start":
        phase = args[2] if len(args) > 2 else "unknown"
        tracker.start_phase(task_id, phase)
        return {"task_id": task_id, "phase": phase, "action": "started"}
    if sub == "end":
        phase = args[2] if len(args) > 2 else "unknown"
        tracker.end_phase(task_id, phase)
        return {"task_id": task_id, "phase": phase, "action": "ended"}
    if sub == "track":
        agent = ""
        elapsed = 0.0
        i = 2
        while i < len(args):
            if args[i] == "--agent" and i + 1 < len(args):
                agent = args[i + 1]; i += 2
            elif args[i] == "--elapsed" and i + 1 < len(args):
                elapsed = float(args[i + 1]); i += 2
            elif args[i] == "--phase" and i + 1 < len(args):
                task_id = args[i + 1] if task_id == "unknown" else task_id; i += 2
            else:
                i += 1
        if agent:
            tracker.track_agent(task_id, task_id, agent, elapsed)
        return {"task_id": task_id, "agent": agent, "elapsed": elapsed}
    return {"task_id": task_id, "time": tracker.report(task_id)}


def cmd_tokens(args: list[str]) -> dict:
    sub = args[0] if args else "report"
    # If first arg is not a known subcommand, treat as task_id for report
    if sub not in ("track", "report"):
        sub, task_id = "report", sub
    else:
        task_id = args[1] if len(args) > 1 else "unknown"
    fs, _, _ = _resolve(task_id)
    tracker = TokenTracker(fs.kanban_dir / "reports" / "token_tracking.json")

    if sub == "track":
        tokens = 0
        phase = ""
        agent = ""
        i = 2
        while i < len(args):
            if args[i] == "--tokens" and i + 1 < len(args):
                tokens = int(args[i + 1]); i += 2
            elif args[i] == "--phase" and i + 1 < len(args):
                phase = args[i + 1]; i += 2
            elif args[i] == "--agent" and i + 1 < len(args):
                agent = args[i + 1]; i += 2
            else:
                i += 1
        tracker.track(task_id, tokens, phase, agent)
        return {"task_id": task_id, "phase": phase, "agent": agent, "tokens": tokens}

    return {"task_id": task_id, "tokens": tracker.report(task_id)}


def cmd_dashboard(args: list[str]) -> dict:
    from core.infra.dashboard import DashboardBuilder
    fs, _, _ = _resolve("")
    builder = DashboardBuilder(fs.tasks_dir)
    return {"dashboard": builder.build()}
