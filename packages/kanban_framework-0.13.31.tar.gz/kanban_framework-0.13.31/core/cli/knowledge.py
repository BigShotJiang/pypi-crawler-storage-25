from __future__ import annotations
from pathlib import Path
from core.infra.filesystem import Filesystem
from core.domain.knowledge import KnowledgeManager


def dispatch(args: list[str]) -> dict:
    sub = args[0] if args else "search"
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    km = KnowledgeManager(fs)

    if sub == "search":
        return _handle_search(km, args[1:])
    if sub == "semantic":
        return _handle_semantic(km, args[1:])
    if sub == "hybrid":
        return _handle_hybrid(km, args[1:])
    if sub == "add":
        return _handle_add(km, args[1:])
    if sub == "domains":
        return {"domains": km.get_domains()}
    if sub == "match":
        return _handle_match(km, args[1:])
    if sub == "stale":
        return {"stale_ids": km.mark_stale_entries()}
    if sub == "gaps":
        return {"gaps": km.get_knowledge_gap_report()}
    if sub == "migrate":
        return {"migrated": km.migrate_legacy_log()}
    if sub == "import":
        return _handle_import(km, args[1:])
    if sub == "learn":
        return _handle_learn(km, args[1:])
    if sub == "similar":
        return _handle_similar(km, args[1:])
    if sub == "usage":
        return _handle_usage(km, args[1:])
    if sub == "health":
        return _handle_health(km)
    if sub == "conflicts":
        return _handle_conflicts(km, args[1:])
    if sub == "choose":
        return _handle_choose(km, args[1:])
    return {"subcommand": sub, "results": []}


def _handle_search(km: KnowledgeManager, args: list[str]) -> dict:
    domain = None
    tag = None
    task = None
    keyword = ""
    i = 0
    while i < len(args):
        if args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--tag" and i + 1 < len(args):
            tag = args[i + 1]; i += 2
        elif args[i] == "--task" and i + 1 < len(args):
            task = args[i + 1]; i += 2
        else:
            keyword = args[i]; i += 1

    if tag:
        results = km.search_by_tag(tag)
        return {"tag": tag, "results": results, "count": len(results)}
    if task:
        results = km.search_by_task(task)
        return {"task": task, "results": results, "count": len(results)}
    if domain and keyword:
        domain_results = km.search_by_domain(domain)
        results = [r for r in domain_results if keyword.lower() in r.get("title", "").lower()
                   or keyword.lower() in r.get("content", "").lower()]
        return {"domain": domain, "keyword": keyword, "results": results, "count": len(results)}
    if domain:
        results = km.search_by_domain(domain)
        return {"domain": domain, "results": results, "count": len(results)}
    results = km.search(keyword) if keyword else []
    return {"keyword": keyword, "results": results, "count": len(results)}


def _handle_semantic(km: KnowledgeManager, args: list[str]) -> dict:
    query = " ".join(args)
    limit = 20
    results = km.search_semantic(query, limit=limit)
    return {"query": query, "mode": "semantic", "results": results, "count": len(results)}


def _handle_hybrid(km: KnowledgeManager, args: list[str]) -> dict:
    query = " ".join(args)
    limit = 20
    results = km.search_hybrid(query, limit=limit)
    return {"query": query, "mode": "hybrid", "results": results, "count": len(results)}


def _handle_add(km: KnowledgeManager, args: list[str]) -> dict:
    kwargs: dict = {"domain": "infra", "category": "工具", "title": "", "content": "",
                     "code_example": "", "source": {}, "status": "active"}
    i = 0
    while i < len(args):
        if args[i] in ("--domain", "--category", "--title", "--severity", "--status"):
            key = args[i][2:]
            kwargs[key] = args[i + 1]; i += 2
        elif args[i] == "--tags":
            kwargs["tags"] = args[i + 1].split(","); i += 2
        elif args[i] == "--content":
            kwargs["content"] = args[i + 1]; i += 2
        elif args[i] == "--code-example":
            kwargs["code_example"] = args[i + 1]; i += 2
        elif args[i] == "--source" and i + 1 < len(args):
            import json as _json
            try:
                kwargs["source"] = _json.loads(args[i + 1])
            except _json.JSONDecodeError:
                kwargs["source"] = {"raw": args[i + 1]}
            i += 2
        else:
            i += 1
    entry = km.add_entry(**kwargs)
    return {"added": entry["id"], "title": entry["title"]}


def _handle_import(km: KnowledgeManager, args: list[str]) -> dict:
    import json as _json
    file_path = None
    i = 0
    while i < len(args):
        if args[i] == "--entry-file" and i + 1 < len(args):
            file_path = args[i + 1]; i += 2
        else:
            i += 1
    if not file_path:
        return {"error": "--entry-file required"}
    data = _json.loads(Path(file_path).read_text(encoding="utf-8"))
    entries = data.get("entries", [])
    added = []
    for e in entries:
        entry = km.add_entry(
            domain=e.get("domain", "infra"),
            category=e.get("category", "工具"),
            title=e["title"],
            content=e["content"],
            tags=e.get("tags", []),
            severity=e.get("severity", "medium"),
            source=e.get("source", {}),
        )
        added.append(entry["id"])
    return {"imported": len(added), "ids": added}


def _handle_learn(km: KnowledgeManager, args: list[str]) -> dict:
    path = ""
    domain = ""
    follow_deps = True  # default: follow imports
    activate = False
    i = 0
    while i < len(args):
        if args[i] == "--path" and i + 1 < len(args):
            path = args[i + 1]; i += 2
        elif args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--no-follow-deps":
            follow_deps = False; i += 1
        elif args[i] == "--activate":
            activate = True; i += 1
        else:
            i += 1
    if not path:
        return {"error": "--path required"}
    if not domain:
        return {"error": "--domain required"}

    from pathlib import Path as _Path
    import re as _re
    p = _Path(path)
    if not p.exists():
        return {"error": f"path not found: {path}"}

    # Collect code files
    code_files: list[dict] = []
    deps_found: list[str] = []
    if p.is_file():
        code_files.append({"path": str(p), "content": p.read_text(encoding="utf-8")[:3000]})
        deps_found = _find_imports(p.read_text(encoding="utf-8"), p.parent)
    elif p.is_dir():
        for f in sorted(p.rglob("*.py")):
            if f.is_file():
                content = f.read_text(encoding="utf-8")[:3000]
                code_files.append({"path": str(f), "content": content})
                if follow_deps:
                    deps_found.extend(_find_imports(content, f.parent))

    # Deduplicate and resolve dependency paths
    deps_found = sorted(set(deps_found))
    dep_files: list[dict] = []
    for dep_path in deps_found:
        dep_p = _Path(dep_path)
        if dep_p.is_file() and dep_p.suffix == ".py":
            dep_files.append({"path": dep_path, "content": dep_p.read_text(encoding="utf-8")[:3000]})

    # Check what's already in KB for these modules
    known_modules: list[str] = []
    new_modules: list[str] = []
    for cf in code_files + dep_files:
        module_name = _Path(cf["path"]).stem
        existing = km.search_by_tag(f"module:{module_name}")
        if existing:
            known_modules.append(module_name)
        else:
            new_modules.append(module_name)

    status = "active" if activate else "draft"
    return {
        "action": "learn",
        "domain": domain,
        "path": str(p),
        "target_files": len(code_files),
        "dependency_files": len(dep_files),
        "deps_found": deps_found[:20],
        "known_modules": known_modules,
        "new_modules": new_modules,
        "code_files": code_files + dep_files,
        "activate": activate,
        "instruction": (
            f"Read the code files above. For each file, check if the module is already in known_modules. "
            f"Only extract NEW understanding for modules in new_modules={new_modules}. "
            f"For each new module, call knowledge add with domain='{domain}', status='{status}', "
            f"category=架构, title='<module_name> 模块结构与职责', "
            f"content='模块职责、关键函数/类、依赖关系', "
            f"tags=['biz:{domain}', 'module:<name>', 'stack:python'], "
            f"code_example='关键接口代码片段'. "
            f"Follow knowledge-accumulation-guide.md boundary rules."
        ),
    }


def _find_imports(content: str, parent_dir) -> list[str]:
    """Find local/relative module imports in Python code. Returns resolved file paths."""
    import re

    # Find project root (where .kanban/ lives)
    root = parent_dir
    while root.parent != root and not (root / ".kanban").is_dir():
        root = root.parent

    deps = []
    for m in re.finditer(
        r'(?:^from\s+(\S+)\s+import)|(?:^import\s+(\S+))',
        content, re.MULTILINE
    ):
        mod_path = m.group(1) or m.group(2)
        if not mod_path:
            continue

        # Skip stdlib
        if mod_path.split(".")[0] in ("__future__", "os", "sys", "json", "re", "math",
                                        "pathlib", "datetime", "time", "collections",
                                        "typing", "dataclasses", "random", "enum", "abc",
                                        "itertools", "functools", "io", "subprocess",
                                        "logging", "hashlib", "shutil", "tempfile"):
            continue

        # Relative import: from .xxx import → xxx.py in same dir
        if mod_path.startswith("."):
            clean = mod_path.lstrip(".")
            candidate = parent_dir / f"{clean}.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue
            candidate = parent_dir / clean / "__init__.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue

        # Absolute or sibling import: try resolve relative to project root
        parts = mod_path.split(".")
        # Try as file path relative to root parent
        candidate = root.parent / f"{'/'.join(parts)}.py"
        if candidate.is_file():
            deps.append(str(candidate))
            continue

        # Simple sibling import: import xxx
        if len(parts) == 1:
            candidate = parent_dir / f"{parts[0]}.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue
    return deps


def _handle_similar(km: KnowledgeManager, args: list[str]) -> dict:
    tags: list[str] = []
    i = 0
    while i < len(args):
        if args[i] == "--tags" and i + 1 < len(args):
            tags = args[i + 1].split(","); i += 2
        else:
            i += 1
    results = km.find_similar_pitfalls(tags)
    return {"tags": tags, "similar": results, "count": len(results)}


def _handle_usage(km: KnowledgeManager, args: list[str]) -> dict:
    entry_id = ""
    task_id = ""
    i = 0
    while i < len(args):
        if args[i] == "--entry-id" and i + 1 < len(args):
            entry_id = args[i + 1]; i += 2
        elif args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        else:
            i += 1
    km.record_usage(entry_id, task_id)
    return {"entry_id": entry_id, "task_id": task_id, "recorded": True}


def _handle_health(km: KnowledgeManager) -> dict:
    stale_ids = km.mark_stale_entries()
    gaps = km.get_knowledge_gap_report()
    total = len(km._all_entry_ids())
    active = total - len(stale_ids)
    return {
        "total_entries": total,
        "active": active,
        "stale_count": len(stale_ids),
        "stale_ids": stale_ids,
        "knowledge_gaps": gaps,
    }


def _handle_conflicts(km: KnowledgeManager, args: list[str]) -> dict:
    task_id = ""
    i = 0
    while i < len(args):
        if args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        else:
            i += 1
    if not task_id:
        return {"error": "--task-id required"}
    conflicts = km.find_conflicting_solutions(task_id)
    return {"task_id": task_id, "conflicts": conflicts, "count": len(conflicts)}


def _handle_choose(km: KnowledgeManager, args: list[str]) -> dict:
    from datetime import datetime, timezone
    task_id = ""
    choice_id = ""
    selected = ""
    rationale = ""
    i = 0
    while i < len(args):
        if args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        elif args[i] == "--choice-id" and i + 1 < len(args):
            choice_id = args[i + 1]; i += 2
        elif args[i] == "--selected" and i + 1 < len(args):
            selected = args[i + 1]; i += 2
        elif args[i] == "--rationale" and i + 1 < len(args):
            rationale = args[i + 1]; i += 2
        else:
            i += 1
    if not task_id or not choice_id or not selected:
        return {"error": "--task-id, --choice-id, --selected required"}

    fs = km._fs
    task_dir = fs.task_dir(task_id)
    fs.ensure_dir(task_dir)
    choices_path = task_dir / "plan_choices.json"
    choices = fs.read_json(choices_path) if fs.file_exists(choices_path) else {"choices": []}

    now = datetime.now(timezone.utc).isoformat()
    choices["choices"].append({
        "id": choice_id,
        "selected": selected,
        "rationale": rationale,
        "selected_at": now,
    })
    fs.write_json(choices_path, choices)
    return {"task_id": task_id, "choice_id": choice_id, "selected": selected, "recorded": True}


def _handle_match(km: KnowledgeManager, args: list[str]) -> dict:
    text = " ".join(args)
    domains = km.match_domain(text)
    return {"text": text, "matched_domains": domains}
