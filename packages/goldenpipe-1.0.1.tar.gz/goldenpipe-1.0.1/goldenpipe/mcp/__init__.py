"""MCP server for GoldenPipe."""
