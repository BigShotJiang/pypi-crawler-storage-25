"""Textual TUI for GoldenPipe."""
