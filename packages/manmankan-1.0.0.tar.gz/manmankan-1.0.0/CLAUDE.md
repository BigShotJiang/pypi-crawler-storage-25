# CLAUDE.md · manmankan AI 协作纪律

> 本文件是给 AI 编程助手（Claude Code / GitHub Copilot / Codex / Cursor 等）的硬约束。
> 人类 contributor 也适用。
> manmankan 是公开的 MIT 开源项目，已发布到 PyPI 与 GitHub。
> AI 协作产出直接进入永久公开档案，因此对 AI 输出有比私有项目**严苛得多**的语言纪律。

---

## 1. 核心原则

**写之前先想 — 这条信息在 5 年后被 GitHub 上一个素未谋面的 contributor 看到，会不会显得奇怪 / 暴露内部语境 / 让维护者难堪？**

manmankan 所有 commit / changelog / docs / 代码注释都是**永久公开档案**：

- 一旦 push 到 `origin/main`，即使删除也会留底（GitHub forks / archive 镜像 / search index）
- 一旦发布到 PyPI，包内 metadata（含 README / CHANGELOG）**完全无法修改**，只能 yank

---

## 2. 禁用词表（绝对红线 · 任何公开输出禁止出现）

### 2.1 维护者私人称谓 / 昵称
- 任何在 GitHub 公开身份页之外的称呼
- 不在公开介绍出现的称谓 / 项目内部口语化称呼

**必用替代**：用户 / 维护者 / 开发者

### 2.2 维护者其他工作区 / 项目代号
- 任何**本仓库 README 未公开介绍**的兄弟项目名
- 内部工作区代号 / 私有 git 仓库代号

**必用替代**：完全不引用（manmankan 是独立项目）

### 2.3 AI 工具自身署名
- `Claude` / `Codex` / `GitHub Copilot` / `Cursor` / `Plan agent` / `Plan subagent` / `Explore agent`
- `claude.com/claude-code` 等 AI 工具 promo 链接
- `🤖 Generated with [Claude Code](...)` 等 AI 生成标记
- `Co-authored-by: Claude` / `Co-authored-by: <任何 AI 工具>` 等 trailer

**必用替代**：完全删除 attribution，由 maintainer 统一署名

### 2.4 AI 协作过程语境
- `audit-must-user-test` / `audit 漏判` / `user-test 漏判` 等内部协作过程词
- `LOCKED 准则` / `LOCKED 工作流` / 内部 ADR 编号
- `合伙人 mode` / `主会话` / `subagent` 等 AI 协作架构语
- 私有 memory 文件名引用（`feedback_xxx.md` / `project_xxx.md` 等）
- `用户拍板` / `维护者拍板` / `和 X 讨论` / `X 建议` 类 attribution

**必用替代**：直接陈述结论 / 用通用工程语言（"测试" / "实测" / "已确认"）

### 2.5 维护者个人 / 账户信息
- 持仓金额 / 账户底子 / 资产规模
- 维护者其他平台账号 / 私有 alias

**必用替代**：完全零提及

### 2.6 跨项目语境（其他赛道 / 其他项目）
- 任何不属于 manmankan 项目本身的策略 / 监管 / 平台名称

**必用替代**：完全零提及（manmankan 边界 = A 股自选股 CLI 工具）

---

## 3. 公开输出规范

### 3.1 Commit message
- Conventional Commits 格式（`feat:` / `fix:` / `docs:` / `refactor:` / `test:` / `chore:`）
- subject 简洁描述「做了什么」（用户视角）
- body 描述「why + how」· **不写**「谁建议 / 谁审 / 谁拍板」
- **绝对不带** `Co-authored-by: <AI>` trailer
- **绝对不带** `🤖 Generated with <AI>` 类签名行
- **绝对不带** AI 工具的 promo 链接

❌ 反例：
```
fix(scan): 大 watchlist 卡死

Co-authored-by: Claude Opus 4.7 (1M context)
🤖 Generated with [Claude Code](https://claude.com/claude-code)
```

✅ 正例：
```
fix(scan): 大 watchlist 卡死体验 · 并发 + 进度条

v0.3.0 串行拉取 172 只可能阻塞 ≥ 9 分钟无反馈。
fetch_batch 改用 ThreadPoolExecutor (默认并发 5) · 总时间降到 ~30-90s。
加 rich.Progress 进度条 · 实时显示进度 % + 已用时间。
```

### 3.2 CHANGELOG.md
- **用户视角**：用户能感知到什么变化、为什么需要
- "Why" 段写**用户痛点**或**技术原因**，不写**与谁讨论**
- 涉及隐私 / 用语修复的 entry，用中性表述（"措辞规范化"），**不**暗示被修复内容的性质（避免 Streisand 效应引诱读者翻 PyPI 旧版）

❌ 反例：「v0.X.Y 含项目内部私人称谓」「audit 漏判教训」「[audit-must-user-test] LOCKED 准则」
✅ 正例：「CHANGELOG / docs 措辞规范化」「测试覆盖漏判」「「真实规模 + 错误路径」必须纳入发布前测试」

### 3.3 设计文档 / Roadmap
- 不写"X agent 产出 + Y 整理 + Z 拍板" 等 AI 协作脚注
- 不引用内部 LOCKED memory 名 / 内部 feedback 文件名
- 角色名用通用工程角色：「维护者」/「代码审查者」/「实施评审」
- 不用：`Plan agent` / `Claude` / `subagent` / `PM 角色` / `架构师角色`

### 3.4 代码注释
- 解释 why（非平凡决策 / 隐藏约束 / 已知坑）
- ❌ "Claude 建议" / "和维护者讨论后" / "audit step #N" / 私有 memory 引用 / LOCKED 准则名
- ✅ "akshare push2his 对部分 IP 段持续封禁 · retry 无效 · 改 fallback 顺序"

### 3.5 PR 描述 / Issue 评论
- 同 commit message 规范
- 不暴露内部 sprint 视角

---

## 4. 发布前自检（强制）

### 4.1 一次性配置 git pre-commit hook（推荐）

```bash
git config core.hooksPath .githooks
```

启用后每次 `git commit` 自动跑禁用词扫描 + ruff lint。

### 4.2 手动跑

```bash
bash scripts/check-privacy-leaks.sh
```

非零退出 = 立即停止 + 修完再 commit。

### 4.3 release 前 checklist

- [ ] `bash scripts/check-privacy-leaks.sh` 通过
- [ ] 检查 `git log --pretty=full <last-tag>..HEAD` 无 AI co-author trailer
- [ ] 检查 CHANGELOG 对应版本段无内部协作过程词
- [ ] PyPI metadata（pyproject.toml description / keywords）干净

---

## 5. 不可逆操作的特殊责任

### 5.1 PyPI 发布
PyPI wheel/sdist **完全不可修改**，只能 yank（标记弃用，元数据永久存档）。release 前的隐私审查 = **一次性最高责任**动作。

### 5.2 GitHub commit history rewrite
`git filter-repo` + `git push --force` 可清掉历史泄漏，但：
- 破坏所有 fork / clone（contributors 必须重新拉）
- 已被搜索引擎 / GitHub archive / 镜像收录的页面留底

### 5.3 AI assistant 行为约束
未由维护者明确指示前，**绝不**自主执行：
- `git push --force` / `git push --force-with-lease` 到 main
- `git filter-repo` / `git filter-branch` 重写历史
- `pypi yank` / `twine yank` 任何已发布版本
- 删除已发布 git tag

---

## 6. AI 工具署名问题（明确立场）

GitHub 业界惯例支持 `Co-authored-by: <AI tool>` trailer · **本仓库明确不采用**：

- AI 工具是维护者使用的**实现工具**，不是独立 contributor
- AI 工具 footprint 出现在公开 commit history = AI 协作上下文泄漏
- 维护者对所有 commit 内容**完全负责**，不需要 AI 共同署名分担

**结论**：所有 commit / PR / release notes 中**零提及任何 AI 工具名**。由 maintainer (`piklen`) 统一署名。

---

## 7. 发现泄漏的处理

### 7.1 已发现但未 commit
直接修复 + 不带 attribution 重新 commit。

### 7.2 已 commit 但未 push
- `git commit --amend` 或 `git rebase -i HEAD~N` 重写本地历史
- 重写时不能引入新 AI co-author trailer

### 7.3 已 push 到 GitHub 但未发版
- 优先：fix-forward 加新 commit 修复
- 严重时：`git filter-repo` rewrite history + force push（**必须** maintainer 明确批准）

### 7.4 已发布到 PyPI
- PyPI 包**完全不可改**
- 修复版本：patch bump（如 v0.3.3.4 → v0.3.3.5）
- 严重泄漏：`pypi yank <package>==<version>` 标记弃用

---

## 8. 这份纪律的来源

2026-05-10 maintainer 全面 audit 发现 v0.3.3.x 系列含 AI 协作上下文 + 内部代号 + 内部私人语境。修复后立纪律防再犯。

---

**违反本文件任何一条 = 视为 P0 issue**

*Last updated: 2026-05-10*
