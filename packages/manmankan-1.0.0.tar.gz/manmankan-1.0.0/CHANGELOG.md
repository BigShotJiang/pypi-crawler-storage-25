# Changelog

本项目所有重大变更记录在此文件中。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [1.0.0] - 2026-05-10

### 首次正式发布

慢慢看 (manmankan) v1.0.0 是项目首次正式 release。
早期 v0.x 系列 (PyPI 上 v0.1.0 ~ v0.3.3.6) 已 yank · **v1.0.0 是稳定起点**。

### Added · 核心功能

**位置扫描** `kan scan`
- 全景扫描自选股 10 周期位置 (3/5/7/10/15/30/60/90/120/180 日)
- `--high` 高点模式 / `-S --signal` 仅显示有共振信号 / `--diff` 增量模式
- `--exclude-st` 排除 ST/*ST
- 多周期共振信号自动高亮 (×N 标记)
- 终端宽度自适应 (130+ 列 10 周期 · 100 列 6 周期 · 80 列 4 周期 · 共振列始终可见)

**筛选模式**
- `kan low N [N2 ...]` / `kan high N [N2 ...]` 触及阈值筛选 (≤5% 低点 / ≥95% 高点 · 支持多周期)

**连续涨跌看板** `kan trend`
- `--latest N` 近 N 天走势
- `--down N` / `--up N` 筛选连续涨/跌 (N 范围 2-30)
- `--candle` 阳线阴线口径
- 涨跌停自动标记
- 平盘穿透不断连续 (行业惯例)

**单只详情**
- `kan info <代码>` 全周期位置 + 涨跌 + 共振统计

**自选股管理**
- `kan add` 支持代码 + 名称搜索 + 批量 (`kan add 茅台 五粮液`)
- `kan remove` 支持名称 + 批量
- `kan list` (显示总数) / `kan import` (CSV 批量) / `kan clear`
- `kan uninstall` 一次清数据 + 看包卸载命令 (自动检测 uv tool / pipx / pip)

**数据层**
- 多源 K 线 fallback: `baostock → 新浪 → 东财 → 腾讯`
- 本地 Parquet 缓存 (`~/.local/share/kan/data/` · XDG 规范)
- 7 天 A 股代码-名称缓存 + 自动过期更新
- `kan fetch [--force]` 手动刷新
- 跨板块交易单位适配 (主板 / 科创板 / 创业板 / 北交所)

**Shell 集成**
- `kan completion install [shell]` 一键启用 zsh / bash / fish / powershell 命令前缀补全
- 任意命令首次启动自动启用补全 (`KAN_NO_COMPLETION_AUTOINSTALL=1` 可关闭 · 非 TTY 跳过)

**合规**
- 强制风险提示
- 关键词黑名单 (买卖建议 / 推荐 / 目标价等)
- 板块差异化涨跌停限制 (按 2026-07-06 政策日期切换)

### 项目治理

- `CLAUDE.md` AI 协作纪律 (适用所有 contributors · 含禁用词表 + commit/changelog/docs/code 规范)
- `scripts/check-privacy-leaks.sh` 自动 lint (36 个禁用词扫描)
- `.githooks/pre-commit` git commit 自动检查 (启用方式 `git config core.hooksPath .githooks`)
- `CONTRIBUTING.md` 含「公开输出语言规范」+「AI 协助开发」段
- `SECURITY.md` 漏洞报告流程 (GitHub Private Vulnerability Reporting)

### 安装

```bash
# 推荐 (uv tool · 隔离环境 + 全局可用)
uv tool install manmankan
kan --version

# 或 pipx
pipx install manmankan

# 或标准 pip (虚拟环境内)
python3 -m venv ~/.kan-venv && source ~/.kan-venv/bin/activate
pip install manmankan
```

### 系统要求

- Python 3.11+
- macOS / Linux / Windows
- 主要依赖: akshare / baostock / pandas / pydantic / rich / typer / pyarrow

### 数据使用条款

⚠️ AKShare 官方声明数据 "仅限学术研究用途 (Academic Research Only)"。本工具继承此限制，**仅供个人研究 / 教育用途，不得用于商业产品 / SaaS / 二次分发**。

[1.0.0]: https://github.com/piklen/manmankan/releases/tag/v1.0.0
