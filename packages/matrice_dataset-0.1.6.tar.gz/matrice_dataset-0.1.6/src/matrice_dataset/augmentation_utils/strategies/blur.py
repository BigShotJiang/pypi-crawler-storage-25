import logging

import albumentations as A
import numpy as np

from ..base import ImageAugmentationStrategy


class BlurAugmentation(ImageAugmentationStrategy):
    def __init__(self, blur_limit: int = 5, prob: float = 1.0):
        self.transform = A.Compose(
            [A.Blur(blur_limit=blur_limit, p=1.0)],
            bbox_params=A.BboxParams(format="coco", label_fields=["class_labels"]),
        )

    def apply(
        self, image: np.ndarray, bboxes: list[list[float]], bbox_format: str = "coco"
    ) -> tuple[np.ndarray, int, int, list[list[float]]]:
        logging.debug(f"blur original bounding boxes: {bboxes}")
        class_labels = ["object"] * len(bboxes)
        augmented = self.transform(image=image, bboxes=bboxes, class_labels=class_labels)
        aug_image = augmented["image"]
        aug_bboxes = augmented["bboxes"]
        logging.debug("Blur applied with limit")
        return aug_image, aug_image.shape[0], aug_image.shape[1], aug_bboxes
