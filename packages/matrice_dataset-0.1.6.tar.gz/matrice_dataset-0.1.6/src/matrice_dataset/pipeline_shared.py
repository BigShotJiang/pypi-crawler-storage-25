"""Shared utilities for image_data_augmentation and data_generation pipelines.

This module consolidates code that was duplicated between those two modules:
- ImageDataItem
- get_kafka_brokers
- get_object_key_from_url
- PaginatedDataManager (base class)
- UploadURLManager (base class)
"""

import json
import logging
import threading
import time
from urllib.parse import urlparse

import cv2
import numpy as np
import requests
from kafka import KafkaConsumer, KafkaProducer, TopicPartition

MIN_DIM = 1.0


class ImageDataItemBase:
    """Represents an image dataset item with all necessary metadata.

    Shared base for augmentation and synthetic generation pipelines.
    """

    def __init__(self, json_data: dict):
        self.json_data = json_data.copy()
        self.id = json_data.get("ID") or json_data.get("_id")
        self.dataset_id = json_data.get("DatasetID") or json_data.get("_idDataset")
        self.file_location = json_data.get("FileLocation") or json_data.get("fileLocation")
        self.file_name = json_data.get("FileName") or json_data.get("filename")
        self.height = json_data.get("Height") or json_data.get("height")
        self.width = json_data.get("Width") or json_data.get("width")
        self.area = json_data.get("Area") or json_data.get("area")
        self.version_info = json_data.get("versionInfo") or json_data.get("version_info", [])
        self.image = None
        self.augmented_image = None
        self.upload_url = None

    def get_bboxes(self, source_version) -> list[list[float]]:
        """Extract bounding boxes from version info"""
        bboxes = []
        for version in self.version_info:
            if version.get("version") == source_version:
                if version.get("annotation"):
                    for annotation in version["annotation"]:
                        if annotation.get("bbox"):
                            bboxes.append(annotation["bbox"])

        bboxes = [[x, y, max(w, MIN_DIM), max(h, MIN_DIM)] for (x, y, w, h) in bboxes if w > 0 and h > 0]

        logging.debug(f"Extracted bounding boxes: {bboxes}")
        return bboxes

    def update_bboxes(self, new_bboxes: list[list[float]], source_version: str):
        """Update bounding boxes in version info"""
        bbox_index = 0
        for version in self.version_info:
            if version.get("version") == source_version:
                if version.get("annotation"):
                    for annotation in version["annotation"]:
                        if annotation.get("bbox") and bbox_index < len(new_bboxes):
                            annotation["bbox"] = new_bboxes[bbox_index]
                            logging.debug(
                                f"Updated bbox for version {version.get('version', 'unknown')}: {annotation['bbox']}"
                            )
                            bbox_index += 1

    def update_dimensions(self, new_height: int, new_width: int):
        """Update image dimensions"""
        self.json_data["height"] = new_height
        self.json_data["width"] = new_width
        self.json_data["area"] = float(new_height * new_width)
        self.height = new_height
        self.width = new_width
        self.area = float(new_height * new_width)

    def get_json_data(self) -> dict:
        """Get the updated JSON data"""
        return self.json_data


def get_kafka_brokers():
    try:
        kafka_ip = "35.238.188.103"
        kafka_port = 9092
        kafka_brokers = f"{kafka_ip}:{kafka_port}"
        return kafka_brokers
    except Exception as e:
        logging.error(f"Error retrieving Kafka broker details: {e}")
        raise


def get_object_key_from_url(source_url: str) -> str:
    parsed_url = urlparse(source_url)
    if "amazonaws.com" in parsed_url.netloc:
        path_segments = parsed_url.path.strip("/").split("/")
        if len(path_segments) >= 3:
            return "/".join(path_segments[1:])
        raise ValueError("Invalid AWS URL format")
    if "storage.googleapis.com" in parsed_url.netloc:
        path_segments = parsed_url.path.strip("/").split("/")
        if len(path_segments) >= 1:
            return "/".join(path_segments)
        raise ValueError("Invalid GCP URL format")
    raise ValueError(f"Unsupported URL format: {source_url}")


def _create_kafka_producer(bootstrap_servers):
    """Create a standard Kafka producer."""
    return KafkaProducer(
        bootstrap_servers=[bootstrap_servers] if isinstance(bootstrap_servers, str) else bootstrap_servers,
        value_serializer=lambda x: json.dumps(x).encode("utf-8"),
        max_block_ms=5000,
        retries=3,
    )


def _create_kafka_consumer(bootstrap_servers, consumer_group):
    """Create a standard Kafka consumer with shared config."""
    return KafkaConsumer(
        bootstrap_servers=[bootstrap_servers] if isinstance(bootstrap_servers, str) else bootstrap_servers,
        enable_auto_commit=True,
        auto_commit_interval_ms=1000,
        group_id=consumer_group,
        value_deserializer=lambda x: json.loads(x.decode("utf-8")),
        consumer_timeout_ms=5000,
        session_timeout_ms=3000000,
        heartbeat_interval_ms=10000,
        max_poll_interval_ms=30000000,
        auto_offset_reset="latest",
        fetch_max_wait_ms=1000,
        request_timeout_ms=310000000,
        connections_max_idle_ms=320000000,
    )


class BasePaginatedDataManager:
    """Manages paginated data requests and responses via Kafka.

    Shared base for augmentation and synthetic generation pipelines.
    Subclasses override `_id_field` and `_consumer_group_prefix`.
    """

    _id_field = None  # Override in subclass: "augmentation_id" or "synthetic_data_generation_id"
    _consumer_group_prefix = "pipeline_consumer"

    def __init__(
        self,
        request_topic: str,
        response_topic: str,
        bootstrap_servers: str,
        consumer_group: str = None,
        page_size: int = 100,
        max_retries: int = 3,
        retry_delay: int = 5,
    ):
        self.request_topic = request_topic
        self.response_topic = response_topic
        self.broker = bootstrap_servers
        self.consumer_group = consumer_group or self._consumer_group_prefix
        self.page_size = page_size
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.current_page = 0
        self.total_pages = None
        self.is_complete = False
        self.pending_requests = {}
        self.received_pages = {}
        self.lock = threading.Lock()

        self.producer = _create_kafka_producer(self.broker)
        self.consumer = _create_kafka_consumer(self.broker, self.consumer_group)
        self.new_response_topic = TopicPartition(self.response_topic, partition=0)
        self.consumer.assign([self.new_response_topic])

    def request_page(
        self,
        page_number: int,
        dataset_id: str = None,
        source_version: str = "v1.0",
        **kwargs,
    ) -> bool:
        try:
            logging.debug(f"Requesting page {page_number} for dataset {dataset_id}")
            request_data = {
                "page_number": page_number,
                "page_size": self.page_size,
                "dataset_id": dataset_id,
                "timestamp": int(time.time()),
                "version": source_version,
                **kwargs,
            }
            with self.lock:
                self.pending_requests[page_number] = time.time()

            self.producer.send(self.request_topic, value=request_data)
            logging.debug(f"Requested page {page_number}")
            return True
        except Exception as e:
            logging.error(f"Error requesting page {page_number}: {e}")
            return False

    def check_for_responses(
        self,
        expected_id: str = None,
        item_class=None,
    ) -> list:
        """Poll for responses, filtering by expected_id using self._id_field."""
        items = []
        try:
            message_batch = self.consumer.poll(timeout_ms=100000)
            logging.debug(f"Polled {len(message_batch)} messages from Kafka")
            for topic_partition, messages in message_batch.items():
                for message in messages:
                    try:
                        response_data = message.value
                        if expected_id and self._id_field and response_data.get(self._id_field) != expected_id:
                            continue
                        page_number = response_data.get("page")
                        page_data = response_data.get("items", [])
                        total_items = response_data.get("total")
                        total_pages = total_items // self.page_size

                        if page_number is not None:
                            with self.lock:
                                if page_number in self.pending_requests:
                                    del self.pending_requests[page_number]
                                self.received_pages[page_number] = page_data
                                if total_pages is not None:
                                    self.total_pages = total_pages

                            for item_data in page_data:
                                if item_class:
                                    items.append(item_class(item_data))
                                else:
                                    items.append(item_data)

                            logging.debug(f"Received page {page_number} with {len(page_data)} items")
                    except Exception as e:
                        logging.error(f"Error processing response message: {e}")
        except Exception as e:
            logging.debug(f"No messages available or error polling: {e}")
        return items

    def is_pagination_complete(self) -> bool:
        with self.lock:
            return len(self.received_pages) >= self.total_pages and len(self.pending_requests) == 0


class BaseUploadURLManager:
    """Manages upload URL requests and responses via Kafka.

    Shared base for augmentation and synthetic generation pipelines.
    Subclasses override `_id_field`.
    """

    _id_field = None  # Override: "augmentation_id" or "synthetic_data_generation_id"

    def __init__(
        self,
        request_topic: str,
        response_topic: str,
        bootstrap_servers: str,
        consumer_group: str = "upload_url_consumer",
    ):
        self.request_topic = request_topic
        self.response_topic = response_topic
        self.consumer_group = consumer_group
        self.pending_requests = 0
        self.available_urls = []
        self.lock = threading.Lock()

        self.producer = _create_kafka_producer(bootstrap_servers)
        self.consumer = _create_kafka_consumer(bootstrap_servers, self.consumer_group)
        self.new_response_topic = TopicPartition(self.response_topic, partition=0)
        self.consumer.assign([self.new_response_topic])

    def request_upload_url(self, dataset_id: str, id_value: str = None) -> bool:
        try:
            request_data = {"dataset_id": dataset_id}
            if self._id_field and id_value:
                request_data[self._id_field] = id_value
            with self.lock:
                self.pending_requests += 1

            future = self.producer.send(self.request_topic, value=request_data)
            future.get(timeout=10)
            logging.debug(f"Requested upload URL for dataset {dataset_id}")
            return True
        except Exception as e:
            logging.error(f"Error requesting upload URL for dataset {dataset_id}: {e}")
            with self.lock:
                self.pending_requests = max(0, self.pending_requests - 1)
            return False

    def get_upload_url(self, timeout_seconds: int = 60, expected_id: str = None) -> str | None:
        start_time = time.time()
        poll_attempts = 0
        max_poll_attempts = timeout_seconds // 5

        while time.time() - start_time < timeout_seconds and poll_attempts < max_poll_attempts:
            with self.lock:
                if self.available_urls:
                    url = self.available_urls.pop(0)
                    logging.debug("Retrieved upload URL from cache")
                    return url

            try:
                self._poll_for_responses(expected_id=expected_id)
                poll_attempts += 1
            except Exception as e:
                logging.warning(f"Error during polling attempt {poll_attempts}: {e}")
                time.sleep(1)

            time.sleep(0.5)

        logging.error(
            f"Timeout waiting for upload URL after {timeout_seconds} seconds and {poll_attempts} poll attempts"
        )
        return None

    def _poll_for_responses(self, expected_id: str = None):
        try:
            message_batch = self.consumer.poll(timeout_ms=100000)
            if not message_batch:
                logging.debug("No upload URL messages received in this poll")
                return

            messages_processed = 0
            for topic_partition, messages in message_batch.items():
                for message in messages:
                    try:
                        response_data = message.value
                        messages_processed += 1
                        if expected_id and self._id_field and response_data.get(self._id_field) != expected_id:
                            logging.debug(f"Skipping response for ID {response_data.get(self._id_field)}")
                            continue

                        upload_url = response_data.get("uploadPath")
                        if upload_url:
                            with self.lock:
                                self.available_urls.append(upload_url)
                                self.pending_requests = max(0, self.pending_requests - 1)
                            logging.debug("Received and cached upload URL")
                        else:
                            logging.warning(f"Response missing uploadPath: {response_data}")
                    except Exception as e:
                        logging.error(f"Error processing upload URL response: {e}")
            if messages_processed > 0:
                logging.debug(f"Processed {messages_processed} upload URL messages")
        except Exception as e:
            if "timeout" not in str(e).lower():
                logging.warning(f"Error polling for upload URL responses: {e}")

    def has_pending_requests(self) -> bool:
        with self.lock:
            return self.pending_requests > 0

    def close(self):
        try:
            if hasattr(self, "consumer"):
                self.consumer.close()
            if hasattr(self, "producer"):
                self.producer.close()
        except Exception as e:
            logging.error(f"Error closing UploadURLManager: {e}")


def download_image_from_url(dataset_item, file_location: str):
    """Download an image from a URL and attach it to the dataset item.

    Shared between augmentation and generation pipelines.
    Returns the item on success, None on failure.
    """
    try:
        logging.debug(f"Downloading image for item {dataset_item.id} from {file_location}")
        response = requests.get(file_location, timeout=30)
        response.raise_for_status()

        image_array = np.frombuffer(response.content, np.uint8)
        image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

        if image is None:
            logging.error(f"Failed to decode image for item {dataset_item.id}")
            return None

        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        dataset_item.image = image
        logging.debug(f"Downloaded image for item {dataset_item.id} with shape {image.shape}")
        return dataset_item
    except Exception as e:
        logging.error(f"Error downloading image: {e}")
        return None


def upload_and_publish_image(
    dataset_item,
    new_items_producer,
    new_items_topic,
    pipeline_config,
    source_version_attr,
    target_version_attr,
    id_from_field,
    id_config_field,
    extra_fields=None,
):
    """Upload augmented/generated image and publish to Kafka.

    Shared logic between augmentation and generation upload stages.
    """
    try:
        logging.debug(f"Uploading image for item {dataset_item.id}")
        if dataset_item.augmented_image is None:
            logging.error(f"No augmented image found for dataset item {dataset_item.id}")
            return None

        image_bgr = cv2.cvtColor(dataset_item.augmented_image, cv2.COLOR_RGB2BGR)
        _, img_encoded = cv2.imencode(".jpg", image_bgr)
        img_bytes = img_encoded.tobytes()
        file_size_mb = len(img_bytes) / (1024 * 1024)

        upload_response = requests.put(
            dataset_item.upload_url,
            data=img_bytes,
            headers={"Content-Type": "image/jpeg"},
            timeout=30,
        )

        if upload_response.status_code in [200, 201, 204]:
            logging.debug(f"Uploaded image for item {dataset_item.id}")
            full_url = dataset_item.upload_url.split("?")[0]
            s3_key = get_object_key_from_url(full_url)

            dataset_item.json_data["fileLocation"] = s3_key
            dataset_item.json_data["fileSize"] = file_size_mb
            dataset_item.json_data["Status"] = "completed"
            dataset_item.json_data["_id"] = ""

            # Apply extra fields (augmentationApplied, promptApplied, etc.)
            if extra_fields:
                dataset_item.json_data.update(extra_fields)

            source_version = getattr(pipeline_config, source_version_attr)
            target_version = getattr(pipeline_config, target_version_attr)
            dataset_item.json_data["versionInfo"] = [
                {**i, "version": target_version}
                for i in dataset_item.json_data["versionInfo"]
                if i.get("version") == source_version
            ]
            dataset_item.json_data[id_from_field] = dataset_item.id
            dataset_item.json_data[id_config_field] = getattr(
                pipeline_config,
                id_config_field.replace("_id", "_id").lstrip("_id")
                if id_config_field.startswith("_id")
                else id_config_field,
                "",
            )

            new_items_producer.send(new_items_topic, value=dataset_item.get_json_data())
            logging.debug(f"Published new dataset item to topic {new_items_topic}")
            return dataset_item
        logging.error(f"Failed to upload image for item {dataset_item.id}. Status: {upload_response.status_code}")
        dataset_item.json_data["Status"] = "failed"
        dataset_item.json_data["UploadError"] = f"HTTP {upload_response.status_code}"
        return dataset_item
    except Exception as e:
        logging.error(f"Error in upload and publish stage: {e}")
        if dataset_item:
            dataset_item.json_data["Status"] = "failed"
            dataset_item.json_data["UploadError"] = str(e)
            return dataset_item
        return None
