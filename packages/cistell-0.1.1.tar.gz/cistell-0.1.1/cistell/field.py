"""Configuration field descriptor and type mapping utilities."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Generic, TypeVar, cast

if TYPE_CHECKING:
    from cistell.root import ConfigRoot

T = TypeVar("T")

ConfigLoader = Callable[[str], dict[str, str]]
ConfigFieldMapper = Callable[[Any, type[T]], T]


def default_config_field_mapper(value: Any, expected_type: type[T]) -> T:
    """Convert a value to the expected type for a config field."""
    if isinstance(value, expected_type):
        return value
    try:
        callable_type = cast("Callable[[Any], T]", expected_type)
        return callable_type(value)  # type conversion
    except (ValueError, TypeError) as ex:
        msg = f"Invalid type. Expected {expected_type} instead {type(value)}."
        raise TypeError(msg) from ex


class ConfigField(Generic[T]):
    """Define each typed field from a ConfigBase instance.

    This class is used to define typed configuration fields within a ConfigBase
    subclass. It ensures type consistency and supports value validation and casting.

    :param T default_value:
        The default value for the configuration field.
    :param Optional[ConfigFieldMapper] mapper:
        An optional function to map or transform the value.
    :param bool secret:
        If True, the field is treated as secret (redacted in repr/explain/safe_dict).
    """

    def __init__(
        self,
        default_value: T,
        mapper: ConfigFieldMapper[T] | None = None,
        *,
        secret: bool = False,
    ) -> None:
        self._default_value: T = default_value
        self._mapper = mapper or default_config_field_mapper
        self._secret: bool = secret

    def __get__(self, instance: ConfigRoot | None, owner: type[object]) -> T:
        del owner
        if instance is None:
            return self._default_value
        return instance._config_values.get(self, self._default_value)  # type: ignore[no-any-return]  # dict stores Any, runtime guarantees T via mapper

    def __set__(self, instance: ConfigRoot, value: Any) -> None:
        instance._config_values[self] = self._mapper(value, type(self._default_value))
