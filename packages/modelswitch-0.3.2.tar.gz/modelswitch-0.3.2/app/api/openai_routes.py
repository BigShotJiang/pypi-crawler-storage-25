from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from app.utils.message_converter import _to_dict
from app.utils.tracking import track_request, StreamAccumulator
from app.utils.logging import get_protocol_logger

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/openai/models")
@router.get("/v1/models")
async def list_models(request: Request):
    """列出所有已配置的虚拟模型（OpenAI 兼容格式）"""
    chain_router = request.app.state.chain_router
    model_names = chain_router.list_models()

    import time

    models_data = []
    for name in model_names:
        model_config = chain_router.get_model(name)
        models_data.append(
            {
                "id": name,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "modelswitch",
                "permission": [],
                "root": name,
                "parent": None,
                "description": model_config.description if model_config else "",
            }
        )

    return JSONResponse(
        content={
            "object": "list",
            "data": models_data,
        }
    )


@router.post("/openai/chat/completions")
@router.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """OpenAI 兼容的聊天补全接口（支持流式和非流式）"""
    chain_router = request.app.state.chain_router

    body = await request.json()
    model = body.get("model", "")
    messages = body.get("messages", [])
    stream = body.get("stream", False)

    # 获取 request_id
    request_id = getattr(request.state, "request_id", "")

    # 创建协议日志器
    protocol_logger = get_protocol_logger(request_id, "openai")

    # 分析请求体结构
    has_tools = "tools" in body and body["tools"]
    has_tool_choice = "tool_choice" in body
    has_response_format = "response_format" in body
    extra_params = []
    for key in body.keys():
        if key not in ("model", "messages", "stream", "temperature", "top_p",
                       "max_tokens", "stop", "presence_penalty", "frequency_penalty",
                       "user", "tools", "tool_choice", "response_format"):
            extra_params.append(key)

    protocol_logger.log_request_body(
        model=model,
        stream=stream,
        has_tools=has_tools,
        has_tool_choice=has_tool_choice,
        has_response_format=has_response_format,
        extra_params=extra_params,
    )

    # 模型权限检查
    api_key_config = getattr(request.state, "api_key_config", None)
    if api_key_config:
        allowed_models = api_key_config.get("allowed_models", [])
        if allowed_models and model not in allowed_models:
            protocol_logger.log_protocol_warning(
                warning_type="model_not_allowed",
                msg=f"Model '{model}' not in allowed_models: {allowed_models}",
            )
            return JSONResponse(
                status_code=403,
                content={
                    "error": {
                        "message": f"Model '{model}' not allowed for this API key",
                        "type": "forbidden",
                    }
                },
            )

    # 提取额外参数（跳过空列表/空字典，如 tools: [] 会被上游拒绝）
    kwargs = {}
    skipped_empty = []
    standard_params_found = {}
    for key in (
        "temperature",
        "top_p",
        "max_tokens",
        "stop",
        "presence_penalty",
        "frequency_penalty",
        "user",
        "tools",
        "tool_choice",
        "response_format",
    ):
        if key in body:
            val = body[key]
            if val is None or (isinstance(val, (list, dict)) and not val):
                skipped_empty.append(key)
                continue
            kwargs[key] = val
            standard_params_found[key] = val

    # 提取非标准参数（传递给 extra_body）
    extension_params = {}
    for key in extra_params:
        val = body.get(key)
        if val is not None:
            extension_params[key] = val
            kwargs[key] = val

    protocol_logger.log_params_extracted(
        standard_params=standard_params_found,
        extension_params=extension_params if extension_params else None,
        skipped_empty=skipped_empty,
    )

    # Tools 处理日志
    if has_tools:
        tools_list = body.get("tools", [])
        tool_names = [t.get("function", {}).get("name", t.get("name", "unknown"))
                      for t in tools_list[:10]]
        protocol_logger.log_tools_handling(
            tools_count=len(tools_list),
            tool_choice=body.get("tool_choice"),
            tools_preview=tool_names,
        )

    if stream:
        # 流式请求：检查 stream_options
        requested_stream_options = body.get("stream_options")
        protocol_logger.log_stream_options(
            requested=requested_stream_options,
            applied=None,  # adapter 层会处理
        )
        return await _handle_stream(
            request, chain_router, model, messages, request_id, kwargs
        )
    else:
        return await _handle_non_stream(
            request, chain_router, model, messages, request_id, kwargs
        )


async def _handle_non_stream(
    request, chain_router, model, messages, request_id, kwargs
):
    """处理非流式请求"""
    result = await chain_router.execute_chat(
        model=model,
        messages=messages,
        stream=False,
        request_id=request_id,
        **kwargs,
    )

    api_key_alias = getattr(request.state, "api_key_name", "")
    await track_request(
        request.app.state, request_id, model, result, api_key_alias, messages=messages
    )

    if not result.success:
        return JSONResponse(
            status_code=result.status_code,
            content={
                "error": {
                    "message": result.error,
                    "type": "upstream_error",
                    "code": "server_error",
                }
            },
            headers={"X-Request-ID": request_id},
        )

    resp_body = result.body
    if resp_body is None:
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "message": "Empty response from upstream",
                    "type": "upstream_error",
                }
            },
        )

    if hasattr(resp_body, "model_dump"):
        response_data = resp_body.model_dump(exclude_none=True)
    elif hasattr(resp_body, "to_dict"):
        response_data = resp_body.to_dict()
    else:
        response_data = str(resp_body)

    return JSONResponse(
        content=response_data,
        headers={
            "X-Request-ID": request_id,
            "X-Adapter-Name": (result.adapter_name or "").encode("latin-1", errors="replace").decode("latin-1"),
        },
    )


async def _handle_stream(request, chain_router, model, messages, request_id, kwargs):
    """处理流式请求"""
    model_config = chain_router.get_model(model)
    if not model_config:
        error_msg = {
            "error": {
                "message": f"Model '{model}' not found",
                "type": "invalid_request_error",
            }
        }
        error_json = json.dumps(error_msg)

        async def error_gen():
            yield f"data: {error_json}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(error_gen(), media_type="text/event-stream")

    result = await chain_router.execute_chat(
        model=model,
        messages=messages,
        stream=True,
        request_id=request_id,
        **kwargs,
    )

    if not result.success:
        api_key_alias = getattr(request.state, "api_key_name", "")
        await track_request(
            request.app.state,
            request_id,
            model,
            result,
            api_key_alias,
            messages=messages,
        )

        async def error_gen():
            yield f"data: {json.dumps({'error': {'message': result.error, 'type': 'upstream_error'}})}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(error_gen(), media_type="text/event-stream")

    adapter_name = result.adapter_name
    api_key_alias = getattr(request.state, "api_key_name", "")
    accumulator = StreamAccumulator()

    async def generate():
        try:
            if result.stream:
                async for chunk in result.stream:
                    if isinstance(chunk, dict) and chunk.get("_stream_error"):
                        yield f"data: {json.dumps(chunk.get('error', chunk), ensure_ascii=False)}\n\n"
                        yield "data: [DONE]\n\n"
                        return

                    chunk_data = _to_dict(chunk)
                    if not isinstance(chunk_data, dict):
                        chunk_data = str(chunk)

                    # 累积输出内容
                    accumulator.process_chunk(chunk_data)

                    yield f"data: {json.dumps(chunk_data, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"
        except asyncio.CancelledError:
            # Client disconnected - don't try to send error, just propagate
            logger.debug(f"[{request_id}] Stream cancelled by client disconnect")
            raise
        except Exception as e:
            yield f"data: {json.dumps({'error': {'message': str(e), 'type': 'stream_error'}})}\n\n"
            yield "data: [DONE]\n\n"
        finally:
            info = getattr(result, "_stream_adapter_info", None)
            if info:
                result.adapter_name = info.get("name", "")
                result.latency_ms = info.get("latency", 0.0)
                if info.get("usage"):
                    result.usage = info["usage"]

            stream_output = accumulator.get_output_summary()

            await track_request(
                request.app.state,
                request_id,
                model,
                result,
                api_key_alias,
                messages=messages,
                stream_output=stream_output,
            )

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Request-ID": request_id,
            "X-Adapter-Name": (adapter_name or "").encode("latin-1", errors="replace").decode("latin-1"),
        },
    )
