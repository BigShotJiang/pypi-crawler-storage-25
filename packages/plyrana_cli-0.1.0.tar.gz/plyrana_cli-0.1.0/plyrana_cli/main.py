"""plyrana CLI entry point — `plyrana <subcommand>`.

Subcommands:
  auth          login / logout / status
  devices       list / get / claim / unclaim
  variables     list / get / set / history
  automations   list / run / toggle
  system        health / license / integrations / metrics
  config        show / set-url / clear
"""

from __future__ import annotations

import typer

from . import __version__
from .commands import automations, auth, config_cmd, devices, system, variables


app = typer.Typer(
    name="plyrana",
    help="Plyrana CLI — manage a Plyrana IoT Device Hub from your terminal.",
    no_args_is_help=True,
    add_completion=True,
)

app.add_typer(auth.app, name="auth", help="Authentication: login / logout / status.")
app.add_typer(devices.app, name="devices", help="List, inspect, claim and unclaim devices.")
app.add_typer(variables.app, name="variables", help="Read and write device variables.")
app.add_typer(automations.app, name="automations", help="List, run, toggle automations.")
app.add_typer(system.app, name="system", help="Health, license and integration status.")
app.add_typer(config_cmd.app, name="config", help="CLI configuration (base URL, token).")


@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", help="Print version and exit."),
) -> None:
    if version:
        typer.echo(f"plyrana {__version__}")
        raise typer.Exit(code=0)
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


if __name__ == "__main__":
    app()
