"""Thin httpx wrapper used by all CLI commands."""

from __future__ import annotations

import httpx
import typer

from .config import Config


class PlyranaAPIError(Exception):
    def __init__(self, status: int, detail: str) -> None:
        super().__init__(f"HTTP {status}: {detail}")
        self.status = status
        self.detail = detail


def require_auth(cfg: Config) -> None:
    if not cfg.is_authenticated:
        typer.secho(
            "Not authenticated. Run: plyrana auth login --email <you> --password <pw>",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=2)


def http(cfg: Config, method: str, path: str, **kwargs) -> httpx.Response:
    """Perform an API call. Path is relative (e.g. '/api/v1/devices')."""
    url = cfg.base_url + path
    headers = kwargs.pop("headers", {}) or {}
    if cfg.token:
        headers["Authorization"] = f"Bearer {cfg.token}"
    timeout = kwargs.pop("timeout", 30.0)
    try:
        response = httpx.request(method, url, headers=headers, timeout=timeout, **kwargs)
    except httpx.RequestError as exc:
        typer.secho(f"Network error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=3) from exc

    if response.status_code >= 400:
        try:
            detail = response.json()
        except ValueError:
            detail = response.text
        raise PlyranaAPIError(response.status_code, str(detail))

    return response


def get(cfg: Config, path: str, **kwargs) -> httpx.Response:
    return http(cfg, "GET", path, **kwargs)


def post(cfg: Config, path: str, json: dict | None = None, **kwargs) -> httpx.Response:
    return http(cfg, "POST", path, json=json, **kwargs)


def put(cfg: Config, path: str, json: dict | None = None, **kwargs) -> httpx.Response:
    return http(cfg, "PUT", path, json=json, **kwargs)


def delete(cfg: Config, path: str, **kwargs) -> httpx.Response:
    return http(cfg, "DELETE", path, **kwargs)
