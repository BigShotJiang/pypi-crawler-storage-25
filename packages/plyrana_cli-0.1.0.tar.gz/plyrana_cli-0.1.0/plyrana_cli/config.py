"""Plyrana CLI config: load/save token + base URL from ~/.plyrana/config.json."""

from __future__ import annotations

import json
import os
from pathlib import Path


DEFAULT_BASE_URL = "http://localhost:8000"
CONFIG_DIR = Path(os.path.expanduser("~")) / ".plyrana"
CONFIG_PATH = CONFIG_DIR / "config.json"


class Config:
    def __init__(self, base_url: str = DEFAULT_BASE_URL, token: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token

    @classmethod
    def load(cls) -> "Config":
        """Load from file + env-var overrides. Env beats file."""
        data: dict = {}
        if CONFIG_PATH.exists():
            try:
                data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                data = {}

        base_url = os.environ.get("PLYRANA_URL") or data.get("base_url") or DEFAULT_BASE_URL
        token = os.environ.get("PLYRANA_TOKEN") or data.get("token")
        return cls(base_url=base_url, token=token)

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(
            json.dumps({"base_url": self.base_url, "token": self.token}, indent=2),
            encoding="utf-8",
        )
        # Best-effort: restrict to user only (0600). No-op on Windows without admin.
        try:
            os.chmod(CONFIG_PATH, 0o600)
        except OSError:
            pass

    def clear(self) -> None:
        if CONFIG_PATH.exists():
            CONFIG_PATH.unlink()

    @property
    def is_authenticated(self) -> bool:
        return bool(self.token)
