"""plyrana-cli — Terminal client for the Plyrana IoT Device Hub."""

__version__ = "0.1.0"
