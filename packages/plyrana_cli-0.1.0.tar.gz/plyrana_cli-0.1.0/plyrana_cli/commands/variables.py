"""Variables subcommand: list / get / set / history."""

from __future__ import annotations

import json as json_lib
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from ..client import PlyranaAPIError, get, post, put, require_auth
from ..config import Config


app = typer.Typer()
console = Console()


def _coerce_value(raw: str) -> Any:
    """Coerce a CLI string to int/float/bool/json/string."""
    lower = raw.lower()
    if lower in {"true", "false"}:
        return lower == "true"
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    if raw.startswith(("{", "[")):
        try:
            return json_lib.loads(raw)
        except json_lib.JSONDecodeError:
            pass
    return raw


@app.command("list")
def list_variables(
    device_uid: str | None = typer.Option(None, "--device", "-d", help="Filter by device UID."),
) -> None:
    """List variable definitions (optionally per device)."""
    cfg = Config.load()
    require_auth(cfg)
    if device_uid:
        path = f"/api/v1/variables/device/{device_uid}"
    else:
        path = "/api/v1/variables/defs"
    try:
        response = get(cfg, path)
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    data = response.json()
    variables = data if isinstance(data, list) else data.get("items", [])

    if not variables:
        console.print("[dim]No variables found.[/]")
        return

    table = Table(title=f"Variables ({len(variables)})")
    table.add_column("Key", style="cyan")
    table.add_column("Name")
    table.add_column("Type", style="magenta")
    table.add_column("Unit", style="dim")
    for var in variables:
        table.add_row(
            str(var.get("key", "-")),
            var.get("name") or "-",
            var.get("var_type", "-"),
            var.get("unit") or "-",
        )
    console.print(table)


@app.command("get")
def get_variable(
    device_uid: str = typer.Argument(..., help="Device UID."),
    key: str = typer.Argument(..., help="Variable key."),
) -> None:
    """Read the current value of a variable."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(cfg, f"/api/v1/devices/{device_uid}/variables/{key}")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print_json(data=response.json())


@app.command("set")
def set_variable(
    device_uid: str = typer.Argument(..., help="Device UID."),
    key: str = typer.Argument(..., help="Variable key."),
    value: str = typer.Argument(..., help="Value (auto-cast bool/int/float/JSON)."),
) -> None:
    """Write a new value to a variable."""
    cfg = Config.load()
    require_auth(cfg)
    payload = {"value": _coerce_value(value)}
    try:
        response = put(cfg, f"/api/v1/devices/{device_uid}/variables/{key}", json=payload)
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print(f"[green]Set[/] {device_uid}.{key} = [bold]{payload['value']!r}[/]")
    console.print_json(data=response.json())


@app.command("history")
def history(
    device_uid: str = typer.Argument(..., help="Device UID."),
    key: str = typer.Argument(..., help="Variable key."),
    limit: int = typer.Option(20, "--limit", "-n", help="Max samples."),
) -> None:
    """Show recent history for a variable."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(
            cfg,
            f"/api/v1/devices/{device_uid}/variables/{key}/history",
            params={"limit": limit},
        )
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    samples = response.json()
    if not samples:
        console.print("[dim]No history samples.[/]")
        return

    table = Table(title=f"{device_uid}.{key} history")
    table.add_column("Timestamp", style="dim")
    table.add_column("Value", style="cyan")
    for sample in samples[:limit]:
        table.add_row(
            str(sample.get("timestamp", "-")),
            str(sample.get("value", "-")),
        )
    console.print(table)
