"""System subcommand: health / license / integrations / metrics."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from ..client import PlyranaAPIError, get, require_auth
from ..config import Config


app = typer.Typer()
console = Console()


@app.command("health")
def health() -> None:
    """Public backend health check (no auth)."""
    cfg = Config.load()
    try:
        response = get(cfg, "/health")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    data = response.json()
    status = data.get("status", "unknown")
    version = data.get("version", "?")
    color = "green" if status == "ok" else "red"
    console.print(f"[{color}]{status.upper()}[/] (version {version}) @ {cfg.base_url}")


@app.command("license")
def license_info() -> None:
    """Show current license (CE / Pro / Enterprise)."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(cfg, "/api/v1/license")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    lic = response.json()
    table = Table(title="License")
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    for key in ("license_id", "issued_to", "edition", "expires_at", "signed", "valid"):
        table.add_row(key, str(lic.get(key, "-")))

    limits = lic.get("limits", {})
    for key, value in limits.items():
        display = "∞" if value == -1 else str(value)
        table.add_row(f"limits.{key}", display)

    console.print(table)


@app.command("integrations")
def integrations_status() -> None:
    """Aggregated status of MQTT / HA / Prometheus / Grafana integrations."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(cfg, "/api/v1/integrations/status")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print_json(data=response.json())


@app.command("metrics")
def metrics() -> None:
    """Fetch raw Prometheus metrics output (text/plain)."""
    cfg = Config.load()
    try:
        response = get(cfg, "/metrics")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print(response.text)
