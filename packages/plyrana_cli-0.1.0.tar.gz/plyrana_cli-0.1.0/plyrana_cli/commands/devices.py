"""Devices subcommand: list / get / claim / unclaim."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from ..client import PlyranaAPIError, delete, get, post, require_auth
from ..config import Config


app = typer.Typer()
console = Console()


@app.command("list")
def list_devices(
    limit: int = typer.Option(50, "--limit", "-n", help="Max rows to show."),
    device_type: str | None = typer.Option(None, "--type", help="Filter by device type."),
) -> None:
    """List all devices in your org."""
    cfg = Config.load()
    require_auth(cfg)

    params = {"limit": limit}
    if device_type:
        params["device_type"] = device_type

    try:
        response = get(cfg, "/api/v1/devices", params=params)
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    data = response.json()
    devices = data if isinstance(data, list) else data.get("items", [])

    if not devices:
        console.print("[dim]No devices found.[/]")
        return

    table = Table(title=f"Devices ({len(devices)})")
    table.add_column("UID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Type", style="magenta")
    table.add_column("Status")
    table.add_column("Last seen", style="dim")

    for dev in devices[:limit]:
        table.add_row(
            dev.get("uid", "-"),
            dev.get("name") or "-",
            dev.get("device_type", "-"),
            "[green]online[/]" if dev.get("online") else "[red]offline[/]",
            dev.get("last_seen_at") or "-",
        )
    console.print(table)


@app.command("get")
def get_device(uid: str = typer.Argument(..., help="Device UID.")) -> None:
    """Show full details for a device."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(cfg, f"/api/v1/devices/{uid}")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    console.print_json(data=response.json())


@app.command("claim")
def claim_device(uid: str = typer.Argument(..., help="Device UID to claim.")) -> None:
    """Claim an unclaimed device for your organization."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = post(cfg, f"/api/v1/devices/{uid}/claim")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print(f"[green]Claimed[/] device [bold]{uid}[/]")
    console.print_json(data=response.json())


@app.command("unclaim")
def unclaim_device(uid: str = typer.Argument(..., help="Device UID to unclaim.")) -> None:
    """Release a device back to the pool."""
    cfg = Config.load()
    require_auth(cfg)
    if not typer.confirm(f"Really unclaim device {uid}?"):
        raise typer.Exit(code=0)
    try:
        post(cfg, f"/api/v1/devices/{uid}/unclaim")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print(f"[green]Unclaimed[/] device [bold]{uid}[/]")
