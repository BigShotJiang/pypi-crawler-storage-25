"""Auth subcommand: login, logout, status."""

from __future__ import annotations

import getpass

import typer
from rich.console import Console

from ..client import PlyranaAPIError, get, post
from ..config import Config


app = typer.Typer()
console = Console()


@app.command("login")
def login(
    email: str = typer.Option(..., "--email", "-e", prompt=True, help="Your email address."),
    password: str | None = typer.Option(
        None,
        "--password",
        "-p",
        help="Your password (will be prompted if omitted).",
    ),
    url: str | None = typer.Option(
        None, "--url", help="Plyrana base URL (override ~/.plyrana/config.json)."
    ),
) -> None:
    """Authenticate and save a JWT token to ~/.plyrana/config.json."""
    cfg = Config.load()
    if url:
        cfg.base_url = url.rstrip("/")
    if not password:
        password = getpass.getpass("Password: ")

    try:
        response = post(
            cfg,
            "/api/v1/auth/login",
            json={"email": email, "password": password},
        )
    except PlyranaAPIError as exc:
        typer.secho(f"Login failed: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    data = response.json()
    cfg.token = data.get("access_token")
    if not cfg.token:
        typer.secho("Login response missing 'access_token'", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    cfg.save()
    console.print(f"[green]Logged in[/] as [bold]{email}[/] at [dim]{cfg.base_url}[/]")


@app.command("logout")
def logout() -> None:
    """Remove the saved token."""
    cfg = Config.load()
    cfg.clear()
    console.print("[green]Logged out[/] — ~/.plyrana/config.json removed.")


@app.command("status")
def status() -> None:
    """Show current login status and identity."""
    cfg = Config.load()
    console.print(f"[bold]Base URL:[/] {cfg.base_url}")
    if not cfg.is_authenticated:
        console.print("[yellow]Not authenticated.[/]")
        console.print("Run: [cyan]plyrana auth login --email <you>[/]")
        raise typer.Exit(code=0)

    try:
        response = get(cfg, "/api/v1/users/me")
    except PlyranaAPIError as exc:
        typer.secho(f"Auth check failed: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    me = response.json()
    console.print(
        f"[green]Authenticated[/] as [bold]{me.get('email')}[/] (role: {me.get('role')})"
    )
