"""Config subcommand: show / set-url / clear."""

from __future__ import annotations

import typer
from rich.console import Console

from ..config import Config


app = typer.Typer()
console = Console()


@app.command("show")
def show() -> None:
    """Show current CLI configuration."""
    cfg = Config.load()
    console.print(f"[bold]Base URL:[/] {cfg.base_url}")
    if cfg.token:
        console.print(f"[bold]Token:[/] {cfg.token[:20]}... [dim](stored)[/]")
    else:
        console.print("[yellow]No token[/] — run 'plyrana auth login'.")


@app.command("set-url")
def set_url(url: str = typer.Argument(..., help="New base URL.")) -> None:
    """Change the Plyrana base URL."""
    cfg = Config.load()
    cfg.base_url = url.rstrip("/")
    cfg.save()
    console.print(f"[green]Base URL set to[/] {cfg.base_url}")


@app.command("clear")
def clear() -> None:
    """Delete the config file (token + URL)."""
    cfg = Config.load()
    cfg.clear()
    console.print("[green]Config cleared[/] — ~/.plyrana/config.json removed.")
