"""Automations subcommand: list / run / toggle."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from ..client import PlyranaAPIError, get, post, put, require_auth
from ..config import Config


app = typer.Typer()
console = Console()


@app.command("list")
def list_automations() -> None:
    """List all automations in your org."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = get(cfg, "/api/v1/automations")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    data = response.json()
    automations = data if isinstance(data, list) else data.get("items", [])

    if not automations:
        console.print("[dim]No automations found.[/]")
        return

    table = Table(title=f"Automations ({len(automations)})")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Trigger", style="magenta")
    table.add_column("Enabled")
    table.add_column("Last run", style="dim")
    for auto in automations:
        table.add_row(
            str(auto.get("id", "-")),
            auto.get("name") or "-",
            auto.get("trigger_type", "-"),
            "[green]yes[/]" if auto.get("enabled") else "[red]no[/]",
            auto.get("last_triggered_at") or "-",
        )
    console.print(table)


@app.command("run")
def run_automation(
    automation_id: int = typer.Argument(..., help="Automation ID."),
) -> None:
    """Manually trigger an automation (runs actions once, bypassing trigger)."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = post(cfg, f"/api/v1/automations/{automation_id}/run")
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    console.print(f"[green]Triggered[/] automation #{automation_id}")
    console.print_json(data=response.json())


@app.command("toggle")
def toggle_automation(
    automation_id: int = typer.Argument(..., help="Automation ID."),
    enabled: bool = typer.Option(True, "--on/--off", help="Turn automation on or off."),
) -> None:
    """Enable or disable an automation."""
    cfg = Config.load()
    require_auth(cfg)
    try:
        response = put(
            cfg,
            f"/api/v1/automations/{automation_id}",
            json={"enabled": enabled},
        )
    except PlyranaAPIError as exc:
        typer.secho(f"Error: {exc.detail}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    state = "on" if enabled else "off"
    console.print(f"[green]Automation #{automation_id} is now {state}[/]")
    console.print_json(data=response.json())
