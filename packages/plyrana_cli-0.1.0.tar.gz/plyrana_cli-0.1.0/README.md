# plyrana-cli — Terminal client for Plyrana

Thin command-line client for the Plyrana IoT Device Hub REST API. Great for CI/CD, scripting, batch operations.

## Install

```bash
pip install plyrana-cli
# dev install from source:
pip install -e ./cli
```

## First run

```bash
# Point to your hub
plyrana config set-url https://hub.example.com

# Login (password prompt if omitted)
plyrana auth login --email admin@example.com

# Verify
plyrana auth status
```

## Commands

### Auth
```bash
plyrana auth login --email <EMAIL>
plyrana auth logout
plyrana auth status
```

### Devices
```bash
plyrana devices list [--limit 50] [--type hardware]
plyrana devices get <UID>
plyrana devices claim <UID>
plyrana devices unclaim <UID>
```

### Variables
```bash
plyrana variables list [--device <UID>]
plyrana variables get <UID> <KEY>
plyrana variables set <UID> <KEY> <VALUE>        # auto-cast: 22.5 / true / '{"x":1}'
plyrana variables history <UID> <KEY> [--limit 20]
```

### Automations
```bash
plyrana automations list
plyrana automations run <ID>
plyrana automations toggle <ID> --on | --off
```

### System
```bash
plyrana system health         # public, no auth
plyrana system license        # CE / Pro / Enterprise + limits
plyrana system integrations   # MQTT / HA / Prometheus / Grafana status
plyrana system metrics        # Prometheus text-format
```

### Config
```bash
plyrana config show
plyrana config set-url <URL>
plyrana config clear
```

## Auth storage

Tokens are stored in `~/.plyrana/config.json` with `0600` perms (best-effort on Windows).

Override via env:
- `PLYRANA_URL=https://hub.example.com`
- `PLYRANA_TOKEN=eyJ...`

Env beats file — great for CI.

## Example: CI smoke-test

```bash
export PLYRANA_URL=https://hub.example.com
export PLYRANA_TOKEN=$PLYRANA_CI_TOKEN
plyrana system health || exit 1
plyrana devices list --limit 1 || exit 1
```

## License

AGPL-3.0 — see [LICENSE](../LICENSE) in the main repo.
