"""阿里云 STS 凭证解密

API 返回的 AccessKeyId 和 AccessKeySecret 使用字符替换加密，
本模块提供对应的解密函数。
"""

_IN_TAB = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789!@#$%^&*()"
_OUT_TAB = "nopqrstuvwxyzabcdefghijklmNOPQRSTUVWXYZABCDEFGHIJKLM987654321)(*&^%$#@!"

# 预构建解密映射表: OUT_TAB[i] -> IN_TAB[i]
_DECRYPT_MAP = str.maketrans(_OUT_TAB, _IN_TAB)


def decrypt_credential(text: str) -> str:
    """解密单个凭证字符串

    Args:
        text: 加密后的凭证文本

    Returns:
        解密后的明文
    """
    if not text:
        return text
    return text.translate(_DECRYPT_MAP)
