"""controlzero test <tool> dry-runs a tool call against the policy."""

from click.testing import CliRunner

from controlzero.cli.main import cli


def test_test_command_allow(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text(
        """
version: "1"
rules:
  - allow: "read_*"
  - deny: "*"
"""
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["test", "read_file", "--policy", str(p)])
    assert result.exit_code == 0
    assert "ALLOW" in result.output


def test_test_command_deny(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text(
        """
version: "1"
rules:
  - deny: "delete_*"
"""
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["test", "delete_file", "--policy", str(p)])
    assert result.exit_code == 3  # custom exit code for deny
    assert "DENY" in result.output


def test_test_command_with_args(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text("version: '1'\nrules:\n  - allow: '*'\n")
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["test", "tool", "--policy", str(p), "--args", '{"key":"val"}'],
    )
    assert result.exit_code == 0


def test_test_command_invalid_args_json(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text("version: '1'\nrules:\n  - allow: '*'\n")
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["test", "tool", "--policy", str(p), "--args", "not-json"],
    )
    assert result.exit_code == 2
    assert "not valid JSON" in result.output
