"""Multiple Client instances must NOT duplicate audit lines.

Before the per-instance component fix, two Client objects in the same process
would each install a loguru sink with the same filter, causing every audit
line to be written multiple times.
"""

import json

from controlzero import Client


def test_two_clients_do_not_duplicate_audit_lines(tmp_path):
    log1 = tmp_path / "client1.log"
    log2 = tmp_path / "client2.log"

    cz1 = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(log1),
    )
    cz2 = Client(
        policy={"rules": [{"deny": "*"}]},
        log_path=str(log2),
    )

    cz1.guard("tool_a", {"x": 1})
    cz2.guard("tool_b", {"y": 2})

    cz1.close()
    cz2.close()

    lines1 = [line for line in log1.read_text().splitlines() if line.strip()]
    lines2 = [line for line in log2.read_text().splitlines() if line.strip()]

    # Each log file must contain ONLY its own client's audit line
    assert len(lines1) == 1, f"client1 log should have 1 line, got {len(lines1)}: {lines1}"
    assert len(lines2) == 1, f"client2 log should have 1 line, got {len(lines2)}: {lines2}"

    parsed1 = json.loads(lines1[0])
    parsed2 = json.loads(lines2[0])

    assert parsed1["tool"] == "tool_a"
    assert parsed2["tool"] == "tool_b"

    # And the decisions should be from each client's own policy
    assert parsed1["decision"] == "allow"
    assert parsed2["decision"] == "deny"


def test_three_clients_concurrent(tmp_path):
    """Stress: three clients in the same process, each gets exactly its own logs."""
    logs = [tmp_path / f"c{i}.log" for i in range(3)]
    clients = [
        Client(policy={"rules": [{"allow": "*"}]}, log_path=str(p)) for p in logs
    ]
    for i, cz in enumerate(clients):
        for j in range(5):
            cz.guard(f"tool_{i}_{j}")
    for cz in clients:
        cz.close()

    for i, log in enumerate(logs):
        lines = [line for line in log.read_text().splitlines() if line.strip()]
        assert len(lines) == 5, f"client {i} should have exactly 5 lines, got {len(lines)}"
        for line in lines:
            parsed = json.loads(line)
            assert parsed["tool"].startswith(f"tool_{i}_")
