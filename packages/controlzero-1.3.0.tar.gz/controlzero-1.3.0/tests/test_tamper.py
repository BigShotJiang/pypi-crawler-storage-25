"""Unit tests for the v0.2 tamper protection primitives."""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path

import pytest

from controlzero.tamper import (
    HashChain,
    TamperDetectedError,
    load_or_create_secret,
    load_signed_file,
    require_bundle,
    sign_bundle,
    verify_bundle,
    write_signed_file,
)


# ---------------------------------------------------------------------------
# HMAC bundle signing
# ---------------------------------------------------------------------------


def test_sign_and_verify_roundtrip():
    secret = os.urandom(32)
    payload = b"policy bundle content"
    sig = sign_bundle(payload, secret)
    assert verify_bundle(payload, sig, secret) is True


def test_verify_fails_when_payload_mutated():
    secret = os.urandom(32)
    sig = sign_bundle(b"original", secret)
    assert verify_bundle(b"mutated", sig, secret) is False


def test_verify_fails_when_secret_wrong():
    sig = sign_bundle(b"data", os.urandom(32))
    assert verify_bundle(b"data", sig, os.urandom(32)) is False


def test_verify_rejects_bad_base64():
    assert verify_bundle(b"data", "not base64!!!", os.urandom(32)) is False


def test_sign_rejects_short_secret():
    with pytest.raises(ValueError):
        sign_bundle(b"data", b"short")


def test_require_bundle_raises_on_mismatch():
    with pytest.raises(TamperDetectedError):
        require_bundle(b"data", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", os.urandom(32))


def test_require_bundle_passes_on_valid():
    secret = os.urandom(32)
    sig = sign_bundle(b"data", secret)
    require_bundle(b"data", sig, secret)  # no exception


def test_write_and_load_signed_file(tmp_path: Path):
    secret = os.urandom(32)
    payload = b'{"version": "1", "rules": []}'
    path = tmp_path / "policy.signed"
    write_signed_file(path, payload, secret)
    assert path.exists()
    got = load_signed_file(path, secret)
    assert got == payload


def test_load_signed_file_detects_tamper(tmp_path: Path):
    secret = os.urandom(32)
    path = tmp_path / "policy.signed"
    write_signed_file(path, b"original", secret)
    # Tamper with the payload
    envelope = json.loads(path.read_text())
    envelope["payload"] = base64.b64encode(b"tampered").decode("ascii")
    path.write_text(json.dumps(envelope))
    with pytest.raises(TamperDetectedError):
        load_signed_file(path, secret)


def test_load_signed_file_rejects_malformed(tmp_path: Path):
    path = tmp_path / "policy.signed"
    path.write_text("not json")
    with pytest.raises(ValueError):
        load_signed_file(path, os.urandom(32))


def test_load_signed_file_rejects_missing_fields(tmp_path: Path):
    path = tmp_path / "policy.signed"
    path.write_text(json.dumps({"foo": "bar"}))
    with pytest.raises(ValueError):
        load_signed_file(path, os.urandom(32))


def test_write_signed_file_has_600_perms(tmp_path: Path):
    secret = os.urandom(32)
    path = tmp_path / "policy.signed"
    write_signed_file(path, b"x", secret)
    mode = path.stat().st_mode & 0o777
    assert mode == 0o600


# ---------------------------------------------------------------------------
# Hash-chained audit log
# ---------------------------------------------------------------------------


def test_chain_append_adds_prev_and_entry_hash(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    e = chain.append({"tool": "bash", "decision": "allow"})
    assert "prev_hash" in e
    assert "entry_hash" in e
    assert len(e["entry_hash"]) == 64  # sha256 hex


def test_chain_consecutive_entries_link(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    e1 = chain.append({"tool": "bash", "decision": "allow"})
    e2 = chain.append({"tool": "read", "decision": "allow"})
    assert e2["prev_hash"] == e1["entry_hash"]


def test_chain_verify_passes_on_intact_chain(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    entries = [chain.append({"i": i}) for i in range(5)]
    ok, bad_idx = chain.verify(entries)
    assert ok is True
    assert bad_idx is None


def test_chain_verify_detects_deletion(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    entries = [chain.append({"i": i}) for i in range(5)]
    # Remove middle entry
    del entries[2]
    ok, bad_idx = chain.verify(entries)
    assert ok is False
    assert bad_idx == 2


def test_chain_verify_detects_reorder(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    entries = [chain.append({"i": i}) for i in range(4)]
    entries[1], entries[2] = entries[2], entries[1]
    ok, bad_idx = chain.verify(entries)
    assert ok is False
    assert bad_idx == 1


def test_chain_verify_detects_mutation(tmp_path: Path):
    chain = HashChain(tmp_path / "audit.log")
    entries = [chain.append({"tool": "bash"})]
    entries[0]["tool"] = "rm"  # tamper content; entry_hash no longer matches
    ok, bad_idx = chain.verify(entries)
    assert ok is False
    assert bad_idx == 0


def test_chain_anchor_persisted_across_instances(tmp_path: Path):
    log = tmp_path / "audit.log"
    chain1 = HashChain(log)
    e1 = chain1.append({"i": 1})
    chain2 = HashChain(log)  # new instance, same log path
    e2 = chain2.append({"i": 2})
    # e2 should start from e1's hash because the anchor persisted
    assert e2["prev_hash"] == e1["entry_hash"]


def test_chain_anchor_file_mode_600(tmp_path: Path):
    log = tmp_path / "audit.log"
    HashChain(log)
    anchor = log.with_suffix(".log.anchor")
    assert anchor.exists()
    mode = anchor.stat().st_mode & 0o777
    assert mode == 0o600


# ---------------------------------------------------------------------------
# Secret management
# ---------------------------------------------------------------------------


def test_load_or_create_secret_generates_on_missing(tmp_path: Path):
    path = tmp_path / "tamper.key"
    secret = load_or_create_secret(path)
    assert len(secret) == 32
    assert path.exists()
    mode = path.stat().st_mode & 0o777
    assert mode == 0o600


def test_load_or_create_secret_reads_existing(tmp_path: Path):
    path = tmp_path / "tamper.key"
    first = load_or_create_secret(path)
    second = load_or_create_secret(path)
    assert first == second
