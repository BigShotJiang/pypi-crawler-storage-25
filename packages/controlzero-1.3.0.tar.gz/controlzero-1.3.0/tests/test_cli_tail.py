"""controlzero tail prints last N lines."""

from click.testing import CliRunner

from controlzero.cli.main import cli


def test_tail_missing_log_errors():
    runner = CliRunner()
    result = runner.invoke(cli, ["tail", "--log", "/nonexistent.log"])
    assert result.exit_code == 1
    assert "not found" in result.output


def test_tail_prints_last_lines(tmp_path):
    # Run tail with a small N and a file that exists.
    # We can't easily test the follow behavior without threading, so we just
    # verify the prints the head + ^C path. Use a tiny file and SIGINT trick.
    log = tmp_path / "audit.log"
    log.write_text("line1\nline2\nline3\n")

    runner = CliRunner()
    # Send a Ctrl+C immediately by mocking time.sleep to raise.
    import time
    original_sleep = time.sleep
    time.sleep = lambda *_: (_ for _ in ()).throw(KeyboardInterrupt())
    try:
        result = runner.invoke(cli, ["tail", "--log", str(log), "--lines", "2"])
    finally:
        time.sleep = original_sleep

    assert "line2" in result.output
    assert "line3" in result.output
