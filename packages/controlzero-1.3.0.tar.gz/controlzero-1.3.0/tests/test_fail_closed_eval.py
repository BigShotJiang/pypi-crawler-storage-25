"""Fail-closed on evaluator crash. NEVER allow on error."""

from unittest.mock import patch

from controlzero import Client


def test_evaluator_crash_returns_deny(tmp_log):
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
    )
    # Force the evaluator to raise
    with patch.object(cz._evaluator, "evaluate", side_effect=RuntimeError("boom")):
        result = cz.guard("anything", {})
    assert result.decision == "deny"
    assert "Failing closed" in result.reason
    assert "boom" in result.reason
    cz.close()
