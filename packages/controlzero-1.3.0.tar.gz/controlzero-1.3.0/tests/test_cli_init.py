"""controlzero init writes a template file."""

from click.testing import CliRunner

from controlzero.cli.main import cli


def test_init_writes_default_template(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(cli, ["init"])
    assert result.exit_code == 0
    assert (tmp_path / "controlzero.yaml").exists()
    text = (tmp_path / "controlzero.yaml").read_text()
    assert "version" in text
    assert "rules" in text
    assert "Hello World" in text


def test_init_refuses_to_overwrite(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "controlzero.yaml").write_text("existing")
    runner = CliRunner()
    result = runner.invoke(cli, ["init"])
    assert result.exit_code == 1
    assert "already exists" in result.output


def test_init_force_overwrites(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "controlzero.yaml").write_text("existing")
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--force"])
    assert result.exit_code == 0
    assert "Hello World" in (tmp_path / "controlzero.yaml").read_text()


def test_init_custom_output(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--out", "custom.yaml"])
    assert result.exit_code == 0
    assert (tmp_path / "custom.yaml").exists()
