"""No policy, no API key: pass-through with one-time stderr warning."""

from controlzero import Client


def test_pass_through_with_warning(capsys):
    cz = Client()
    result = cz.guard("anything", {})
    captured = capsys.readouterr()
    assert "no policy configured" in captured.err.lower()
    assert result.allowed
    assert result.policy_id == "<noop>"
    cz.close()


def test_warning_only_once_per_process(capsys):
    cz1 = Client()
    cz1.guard("a")
    first = capsys.readouterr().err

    cz2 = Client()
    cz2.guard("b")
    second = capsys.readouterr().err

    assert "no policy" in first.lower()
    assert "no policy" not in second.lower()
    cz1.close()
    cz2.close()
