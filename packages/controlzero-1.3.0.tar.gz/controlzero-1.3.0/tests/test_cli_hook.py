"""Tests for `controlzero hook-check` and `controlzero install claude-code`."""

import json
from pathlib import Path

from click.testing import CliRunner

from controlzero.cli.main import cli


def write_policy(tmp_path: Path, rules: list) -> Path:
    p = tmp_path / "policy.yaml"
    import yaml

    p.write_text(yaml.safe_dump({"version": "1", "rules": rules}))
    return p


# ---------------------------------------------------------------------
# hook-check
# ---------------------------------------------------------------------


def test_hook_check_allow(tmp_path):
    """Allow rule -> exit 0, no stdout."""
    p = write_policy(tmp_path, [{"allow": "*"}])
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "ls"}})
    result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
    assert result.exit_code == 0, result.output
    assert result.output.strip() == ""


def test_hook_check_deny(tmp_path):
    """Deny rule -> exit 2, stdout JSON block decision."""
    p = write_policy(
        tmp_path,
        [
            {"deny": "Bash", "reason": "Bash blocked"},
            {"allow": "*"},
        ],
    )
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}})
    result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
    assert result.exit_code == 2, result.output
    decision = json.loads(result.output)
    assert decision["decision"] == "block"
    assert "Bash" in decision["reason"] or "blocked" in decision["reason"].lower()


def test_hook_check_empty_stdin_allows(tmp_path):
    """Empty stdin -> exit 0 (never break the agent)."""
    runner = CliRunner()
    result = runner.invoke(cli, ["hook-check"], input="")
    assert result.exit_code == 0


def test_hook_check_malformed_json_allows(tmp_path):
    """Malformed JSON -> warn to stderr, exit 0 (never break the agent)."""
    runner = CliRunner()
    result = runner.invoke(cli, ["hook-check"], input="not json at all")
    assert result.exit_code == 0


def test_hook_check_no_policy_file_allows(tmp_path, monkeypatch):
    """No policy file anywhere -> warn, exit 0."""
    # chdir to an empty dir and clear the global path
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        "controlzero.cli.main.GLOBAL_POLICY_PATH",
        tmp_path / "nonexistent.yaml",
    )
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash"})
    result = runner.invoke(cli, ["hook-check"], input=payload)
    assert result.exit_code == 0
    # The warning goes to stderr; CliRunner captures it in output by default
    assert "no policy" in (result.output or "").lower() or result.exit_code == 0


def test_hook_check_missing_tool_name_allows(tmp_path):
    """Payload missing tool_name -> warn, exit 0."""
    p = write_policy(tmp_path, [{"allow": "*"}])
    runner = CliRunner()
    result = runner.invoke(
        cli, ["hook-check", "--policy", str(p)], input=json.dumps({})
    )
    assert result.exit_code == 0


def test_hook_check_camel_case_keys(tmp_path):
    """Accept toolName / toolInput in addition to snake_case for client compat."""
    p = write_policy(
        tmp_path,
        [{"deny": "DangerousTool"}, {"allow": "*"}],
    )
    runner = CliRunner()
    payload = json.dumps({"toolName": "DangerousTool", "toolInput": {}})
    result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
    assert result.exit_code == 2


def test_hook_check_invalid_policy_allows(tmp_path):
    """Invalid policy file -> warn, exit 0 (do not brick the agent)."""
    p = tmp_path / "bad.yaml"
    p.write_text("rules: not-a-list")
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash"})
    result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
    assert result.exit_code == 0


def test_hook_check_per_project_policy_wins(tmp_path, monkeypatch):
    """./controlzero.yaml in cwd takes precedence over global."""
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.chdir(project)

    project_policy = project / "controlzero.yaml"
    import yaml

    project_policy.write_text(
        yaml.safe_dump({"version": "1", "rules": [{"deny": "*"}]})
    )

    # Pretend the global policy is permissive
    global_policy = tmp_path / "global.yaml"
    global_policy.write_text(
        yaml.safe_dump({"version": "1", "rules": [{"allow": "*"}]})
    )
    monkeypatch.setattr("controlzero.cli.main.GLOBAL_POLICY_PATH", global_policy)

    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash"})
    result = runner.invoke(cli, ["hook-check"], input=payload)
    # Project policy wins -> deny -> exit 2
    assert result.exit_code == 2


# ---------------------------------------------------------------------
# install claude-code
# ---------------------------------------------------------------------


def test_install_claude_code_creates_files(tmp_path, monkeypatch):
    """install claude-code writes the global policy and patches settings.json."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    # Re-import to pick up patched home
    import importlib
    import controlzero.cli.main as cli_main

    importlib.reload(cli_main)

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["install", "claude-code"])
    assert result.exit_code == 0, result.output

    policy_path = fake_home / ".controlzero" / "policy.yaml"
    settings_path = fake_home / ".claude" / "settings.json"

    assert policy_path.exists()
    assert "version" in policy_path.read_text()
    assert "rules" in policy_path.read_text()

    assert settings_path.exists()
    settings = json.loads(settings_path.read_text())
    pre_tool = settings["hooks"]["PreToolUse"]
    assert any(
        h.get("command") == "controlzero hook-check"
        for block in pre_tool
        for h in block.get("hooks", [])
    )


def test_install_claude_code_idempotent(tmp_path, monkeypatch):
    """Running install twice does not duplicate the hook block."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    import importlib
    import controlzero.cli.main as cli_main

    importlib.reload(cli_main)

    runner = CliRunner()
    runner.invoke(cli_main.cli, ["install", "claude-code"])
    runner.invoke(cli_main.cli, ["install", "claude-code"])

    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    pre_tool = settings["hooks"]["PreToolUse"]
    cz_hooks = [
        h
        for block in pre_tool
        for h in block.get("hooks", [])
        if h.get("command") == "controlzero hook-check"
    ]
    assert len(cz_hooks) == 1, f"expected 1 cz hook, got {len(cz_hooks)}"


def test_install_claude_code_preserves_other_hooks(tmp_path, monkeypatch):
    """Existing PreToolUse hooks (not ours) are preserved."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    claude_dir = fake_home / ".claude"
    claude_dir.mkdir()
    settings_path = claude_dir / "settings.json"
    settings_path.write_text(
        json.dumps(
            {
                "hooks": {
                    "PreToolUse": [
                        {
                            "matcher": "*",
                            "hooks": [
                                {
                                    "type": "command",
                                    "command": "some-other-tool",
                                    "timeout": 1000,
                                }
                            ],
                        }
                    ]
                }
            }
        )
    )

    import importlib
    import controlzero.cli.main as cli_main

    importlib.reload(cli_main)

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["install", "claude-code"])
    assert result.exit_code == 0, result.output

    settings = json.loads(settings_path.read_text())
    commands = [
        h.get("command")
        for block in settings["hooks"]["PreToolUse"]
        for h in block.get("hooks", [])
    ]
    assert "some-other-tool" in commands
    assert "controlzero hook-check" in commands


def test_install_claude_code_skips_existing_policy(tmp_path, monkeypatch):
    """If ~/.controlzero/policy.yaml exists, do not overwrite without --force."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cz_dir = fake_home / ".controlzero"
    cz_dir.mkdir()
    existing = cz_dir / "policy.yaml"
    existing.write_text("# my custom policy\nversion: '1'\nrules:\n  - allow: '*'\n")

    import importlib
    import controlzero.cli.main as cli_main

    importlib.reload(cli_main)

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["install", "claude-code"])
    assert result.exit_code == 0
    assert existing.read_text().startswith("# my custom policy")


def test_install_claude_code_force_overwrites(tmp_path, monkeypatch):
    """--force replaces an existing policy file."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cz_dir = fake_home / ".controlzero"
    cz_dir.mkdir()
    existing = cz_dir / "policy.yaml"
    existing.write_text("# old\n")

    import importlib
    import controlzero.cli.main as cli_main

    importlib.reload(cli_main)

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["install", "claude-code", "--force"])
    assert result.exit_code == 0
    assert "Claude Code template" in existing.read_text() or "version" in existing.read_text()
