"""Hybrid mode strict: raises instead of warning."""

import pytest

from controlzero import Client
from controlzero.errors import HostedModeNotImplemented, HybridModeError


def test_strict_hosted_raises_typed_exception(monkeypatch):
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    with pytest.raises(HybridModeError, match="manual policy override"):
        Client(
            policy={"rules": [{"deny": "delete_*"}]},
            strict_hosted=True,
        )


def test_hybrid_error_is_runtime_error_subclass():
    """Backward-compat: HybridModeError still catches as RuntimeError."""
    assert issubclass(HybridModeError, RuntimeError)


def test_strict_hosted_does_not_raise_in_pure_local():
    """No API key + local policy is fine even with strict_hosted=True."""
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        strict_hosted=True,
        log_path="/tmp/cz-strict.log",
    )
    assert cz.guard("anything").allowed
    cz.close()


def test_pure_hosted_refuses_to_construct(monkeypatch):
    """SECURITY: API key + no local policy must NOT silently allow everything.

    Hosted mode is not yet implemented in this slim package, so the only sane
    behavior is to refuse construction with a clear error pointing the user
    to either provide a local policy or install the legacy package.
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    with pytest.raises(HostedModeNotImplemented, match="hosted mode"):
        Client()


def test_pure_hosted_refuses_with_explicit_api_key():
    with pytest.raises(HostedModeNotImplemented):
        Client(api_key="cz_live_fakekey")


def test_hosted_not_implemented_is_notimplemented_subclass():
    """Catching NotImplementedError still works."""
    assert issubclass(HostedModeNotImplemented, NotImplementedError)
