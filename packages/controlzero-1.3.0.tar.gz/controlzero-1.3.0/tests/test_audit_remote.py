"""Tests for the remote audit sink (audit_remote.py).

Coverage matrix:
  - POSITIVE: enrolled SDK, guard() call, entry appears in both local + remote buffer
  - FLUSH: buffer reaches MAX_BUFFER_SIZE, flush fires, POST succeeds, buffer cleared
  - TIMEOUT: mock server slow (3s), flush times out, entries retained for retry
  - AUTH FAILURE: mock server returns 401, sink disables itself
  - NOT ENROLLED: no enrollment state, no remote sink created, local file still works
  - CLOSE: cz.close() flushes remaining entries
  - CONCURRENT: multiple guard() calls from different threads, no buffer corruption
  - HOOK CHECK FLOW: full hook-check with enrolled state, verify both local + remote get entry
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from controlzero.audit_remote import (
    FLUSH_INTERVAL_S,
    FLUSH_TIMEOUT_S,
    MAX_BUFFER_SIZE,
    RemoteAuditSink,
    _AuthExpiredError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_enrollment_state(
    tmp_path: Path,
    api_url: str = "https://api.controlzero.ai",
    org_id: str = "org_test_123",
    machine_id: str = "machine_test_456",
):
    """Write a minimal enrollment state file and keypair to tmp_path."""
    from controlzero.enrollment import (
        EnrollmentState,
        generate_keypair,
        save_private_key,
        save_state,
    )

    priv, pub_pem = generate_keypair()
    state = EnrollmentState(
        machine_id=machine_id,
        org_id=org_id,
        api_url=api_url,
        hostname="test-host",
        fingerprint_hint="abc123",
        machine_pubkey_pem=pub_pem,
        enrolled_at="2026-04-09T00:00:00Z",
    )
    save_state(state, tmp_path)
    save_private_key(priv, tmp_path)
    return state


def _make_sink(
    api_url: str = "https://api.controlzero.ai",
    org_id: str = "org_test_123",
    machine_id: str = "machine_test_456",
    state_dir: Path | None = None,
) -> RemoteAuditSink:
    """Create a sink with the flush timer cancelled (tests control flushing)."""
    sink = RemoteAuditSink(
        api_url=api_url,
        machine_token="",
        org_id=org_id,
        machine_id=machine_id,
        state_dir=state_dir,
    )
    # Cancel the periodic timer so tests control when flushes happen
    sink._cancel_flush_timer()
    return sink


def _sample_entry(**overrides) -> dict:
    """Return a local audit entry dict (the shape _audit_decision produces)."""
    entry = {
        "decision": "allow",
        "tool": "Bash",
        "method": "*",
        "policy_id": "allow-all",
        "reason": "Default allow",
        "args_keys": ["command"],
        "mode": "local",
    }
    entry.update(overrides)
    return entry


# ---------------------------------------------------------------------------
# POSITIVE: entry appears in both local file AND remote buffer
# ---------------------------------------------------------------------------


def test_enrolled_guard_populates_both_local_and_remote(tmp_path):
    """When enrolled, guard() writes to local audit AND remote sink buffer."""
    state = _make_enrollment_state(tmp_path)
    log_path = tmp_path / "audit.log"

    with patch("controlzero.enrollment.load_state", return_value=state):
        from controlzero.client import Client

        cz = Client(
            policy={"version": "1", "rules": [{"allow": "*"}]},
            log_path=str(log_path),
        )
        # The remote sink should have been created
        assert cz._remote_sink is not None
        # Cancel timer to avoid background flushes
        cz._remote_sink._cancel_flush_timer()

        decision = cz.guard("Bash", {"command": "ls"})
        assert decision.allowed

        # Local audit log was written
        assert cz._audit is not None

        # Remote buffer has 1 entry
        buf = cz._remote_sink.buffer
        assert len(buf) == 1
        assert buf[0]["tool_name"] == "Bash"
        assert buf[0]["decision"] == "allow"

        cz._remote_sink._cancel_flush_timer()
        cz.close()


# ---------------------------------------------------------------------------
# FLUSH: buffer full triggers flush, POST succeeds, buffer cleared
# ---------------------------------------------------------------------------


def test_flush_on_buffer_full(tmp_path):
    """When buffer reaches MAX_BUFFER_SIZE, flush fires and clears buffer."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    post_calls = []

    def fake_post_batch(batch):
        post_calls.append(batch)

    # Replace _post_batch to avoid real HTTP
    sink._post_batch = fake_post_batch

    # Fill buffer to trigger flush
    for i in range(MAX_BUFFER_SIZE):
        sink.log(_sample_entry(tool=f"tool_{i}"))

    # Give the async flush thread time to complete
    time.sleep(0.5)

    # Buffer should be cleared after successful flush
    assert len(sink.buffer) == 0
    assert len(post_calls) == 1
    assert len(post_calls[0]) == MAX_BUFFER_SIZE

    sink.close()


# ---------------------------------------------------------------------------
# TIMEOUT: slow server, entries retained for retry
# ---------------------------------------------------------------------------


def test_flush_timeout_retains_entries(tmp_path):
    """When flush times out, entries stay in buffer for next attempt."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    import httpx as real_httpx

    def fake_post_batch(batch):
        raise real_httpx.TimeoutException("timed out")

    sink._post_batch = fake_post_batch

    # Add some entries
    for i in range(5):
        sink.log(_sample_entry(tool=f"tool_{i}"))

    assert len(sink.buffer) == 5

    # Sync flush should fail due to timeout
    sink._flush_sync()

    # Entries retained for retry
    assert len(sink.buffer) == 5
    assert not sink.disabled

    sink.close()


# ---------------------------------------------------------------------------
# AUTH FAILURE: 401 disables the sink
# ---------------------------------------------------------------------------


def test_401_disables_sink(tmp_path):
    """When server returns 401, sink disables itself permanently."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    def fake_post_batch(batch):
        raise _AuthExpiredError("server returned 401")

    sink._post_batch = fake_post_batch

    sink.log(_sample_entry())
    assert len(sink.buffer) == 1

    sink._flush_sync()

    assert sink.disabled
    assert len(sink.buffer) == 0  # buffer cleared on disable

    # Subsequent logs are dropped
    sink.log(_sample_entry(tool="after_disable"))
    assert len(sink.buffer) == 0

    sink.close()


# ---------------------------------------------------------------------------
# NOT ENROLLED: no remote sink, local file still works
# ---------------------------------------------------------------------------


def test_not_enrolled_no_remote_sink(tmp_path):
    """Without enrollment state, Client has no remote sink."""
    log_path = tmp_path / "audit.log"

    with patch("controlzero.enrollment.load_state", return_value=None):
        from controlzero.client import Client

        cz = Client(
            policy={"version": "1", "rules": [{"allow": "*"}]},
            log_path=str(log_path),
        )
        assert cz._remote_sink is None

        # guard() still works -- local audit only
        decision = cz.guard("Bash", {"command": "ls"})
        assert decision.allowed
        cz.close()


def test_enrollment_import_error_no_remote_sink(tmp_path):
    """If enrollment module cannot be imported, no remote sink is created."""
    log_path = tmp_path / "audit.log"

    with patch(
        "controlzero.client.RemoteAuditSink"
    ) as mock_cls:
        # Make load_state import fail
        with patch.dict("sys.modules", {"controlzero.enrollment": None}):
            from importlib import reload
            import controlzero.client as client_mod

            # The ImportError in _init_remote_sink should be caught
            cz = client_mod.Client(
                policy={"version": "1", "rules": [{"allow": "*"}]},
                log_path=str(log_path),
            )
            assert cz._remote_sink is None
            cz.close()


# ---------------------------------------------------------------------------
# CLOSE: cz.close() flushes remaining entries
# ---------------------------------------------------------------------------


def test_close_flushes_buffer(tmp_path):
    """close() does a synchronous flush before shutting down."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    post_calls = []

    def fake_post_batch(batch):
        post_calls.append(batch)

    sink._post_batch = fake_post_batch

    sink.log(_sample_entry(tool="tool_1"))
    sink.log(_sample_entry(tool="tool_2"))
    sink.log(_sample_entry(tool="tool_3"))
    assert len(sink.buffer) == 3

    sink.close()

    # POST was called with the 3 entries
    assert len(post_calls) == 1
    assert len(post_calls[0]) == 3


# ---------------------------------------------------------------------------
# CONCURRENT: multiple threads, no buffer corruption
# ---------------------------------------------------------------------------


def test_concurrent_log_no_corruption(tmp_path):
    """Multiple threads logging concurrently do not corrupt the buffer."""
    sink = _make_sink(state_dir=tmp_path)
    num_threads = 10
    entries_per_thread = 20
    total_expected = num_threads * entries_per_thread
    barrier = threading.Barrier(num_threads)

    def worker(thread_id):
        barrier.wait()
        for i in range(entries_per_thread):
            sink.log(_sample_entry(tool=f"thread_{thread_id}_tool_{i}"))

    # Temporarily disable flush-on-full to keep all entries in the buffer
    original_max = 50
    with patch("controlzero.audit_remote.MAX_BUFFER_SIZE", total_expected + 1):
        threads = [
            threading.Thread(target=worker, args=(tid,))
            for tid in range(num_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

    # All entries should be in the buffer with no duplicates or corruption
    buf = sink.buffer
    assert len(buf) == total_expected
    # Every entry should have a tool_name
    assert all(e.get("tool_name") for e in buf)

    sink.close()


# ---------------------------------------------------------------------------
# WIRE FORMAT: verify mapping from local entry to backend shape
# ---------------------------------------------------------------------------


def test_wire_format_mapping():
    """Verify _to_wire_format produces the shape the backend expects."""
    sink = _make_sink()

    entry = _sample_entry(
        decision="deny",
        tool="dangerous_tool",
        policy_id="deny-dangerous",
        reason="Tool is blocked",
    )
    wire = sink._to_wire_format(entry)

    assert "id" in wire  # UUID string
    assert wire["tool_name"] == "dangerous_tool"
    assert wire["decision"] == "deny"
    assert wire["policy_id"] == "deny-dangerous"
    assert wire["reason"] == "Tool is blocked"
    assert wire["mode"] == "local"
    assert "hostname" in wire
    assert "user" in wire
    assert "ts" in wire

    sink._cancel_flush_timer()
    sink.close()


# ---------------------------------------------------------------------------
# HOOK CHECK FLOW: full hook-check with enrolled state
# ---------------------------------------------------------------------------


def test_hook_check_enrolled_writes_both_sinks(tmp_path):
    """Full hook-check flow: enrolled machine gets both local + remote audit."""
    import yaml
    from click.testing import CliRunner

    from controlzero.cli.main import cli

    # Write a policy file
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(
        yaml.safe_dump({"version": "1", "rules": [{"allow": "*"}]})
    )

    # Set up enrollment state
    state = _make_enrollment_state(tmp_path)

    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "ls"}})

    # Patch load_state so the Client picks up enrollment
    # Patch the remote sink's _post_batch to capture calls
    post_calls = []

    def fake_post_batch(self, batch):
        post_calls.append(batch)

    with patch("controlzero.enrollment.load_state", return_value=state):
        with patch.object(RemoteAuditSink, "_post_batch", fake_post_batch):
            with patch.object(RemoteAuditSink, "_start_flush_timer"):
                runner = CliRunner()
                result = runner.invoke(
                    cli,
                    ["hook-check", "--policy", str(policy_path)],
                    input=payload,
                )

    assert result.exit_code == 0, result.output

    # close() should have triggered a flush with our entry
    assert len(post_calls) == 1
    batch = post_calls[0]
    assert len(batch) == 1
    assert batch[0]["tool_name"] == "Bash"
    assert batch[0]["decision"] == "allow"


# ---------------------------------------------------------------------------
# EDGE: empty buffer flush is a no-op
# ---------------------------------------------------------------------------


def test_flush_empty_buffer_is_noop(tmp_path):
    """Flushing an empty buffer does not make any HTTP calls."""
    sink = _make_sink(state_dir=tmp_path)

    post_calls = []

    def fake_post_batch(batch):
        post_calls.append(batch)

    sink._post_batch = fake_post_batch
    sink._flush_sync()
    assert len(post_calls) == 0

    sink.close()


# ---------------------------------------------------------------------------
# EDGE: server 503 retains entries (transient error)
# ---------------------------------------------------------------------------


def test_503_retains_entries_for_retry(tmp_path):
    """A 503 from the backend is treated as transient; entries are retained."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    def fake_post_batch(batch):
        raise RuntimeError("audit ingest returned HTTP 503: Service Unavailable")

    sink._post_batch = fake_post_batch

    sink.log(_sample_entry())
    sink.log(_sample_entry(tool="ReadFile"))
    assert len(sink.buffer) == 2

    sink._flush_sync()

    # Entries retained -- not disabled
    assert len(sink.buffer) == 2
    assert not sink.disabled

    sink.close()


# ---------------------------------------------------------------------------
# _post_batch integration: verify it calls httpx with correct shape
# ---------------------------------------------------------------------------


def test_post_batch_sends_signed_request(tmp_path):
    """_post_batch calls httpx.post with signed headers and correct body."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"accepted": 1, "dropped": 0}

    batch = [sink._to_wire_format(_sample_entry())]

    with patch("httpx.post", return_value=mock_resp) as mock_post:
        sink._post_batch(batch)

    # Verify httpx.post was called
    assert mock_post.call_count == 1
    call_kwargs = mock_post.call_args
    url = call_kwargs[0][0] if call_kwargs[0] else call_kwargs[1].get("url", "")
    assert "/api/audit" in url

    # Verify body has entries
    content = call_kwargs[1].get("content") or call_kwargs.kwargs.get("content")
    body = json.loads(content)
    assert "entries" in body
    assert len(body["entries"]) == 1

    # Verify signed headers present
    headers = call_kwargs[1].get("headers") or call_kwargs.kwargs.get("headers")
    assert "X-CZ-Machine-ID" in headers
    assert "X-CZ-Signature" in headers

    sink.close()


def test_post_batch_401_raises_auth_expired(tmp_path):
    """_post_batch raises _AuthExpiredError on 401."""
    state = _make_enrollment_state(tmp_path)
    sink = _make_sink(state_dir=tmp_path)

    mock_resp = MagicMock()
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    batch = [sink._to_wire_format(_sample_entry())]

    with patch("httpx.post", return_value=mock_resp):
        with pytest.raises(_AuthExpiredError):
            sink._post_batch(batch)

    sink.close()
