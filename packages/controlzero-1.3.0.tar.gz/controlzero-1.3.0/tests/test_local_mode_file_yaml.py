"""Local mode loading from a YAML file. Happy + negative paths."""

import pytest

from controlzero import Client, PolicyLoadError, PolicyValidationError


def test_load_yaml_file(tmp_path, tmp_log):
    p = tmp_path / "policy.yaml"
    p.write_text(
        """
version: "1"
rules:
  - deny: "delete_*"
  - allow: "read_*"
"""
    )
    cz = Client(policy_file=str(p), log_path=str(tmp_log))
    assert cz.guard("delete_thing").decision == "deny"
    assert cz.guard("read_thing").decision == "allow"
    cz.close()


def test_yaml_file_not_found_raises():
    with pytest.raises(PolicyLoadError, match="not found"):
        Client(policy_file="/nonexistent/path.yaml", log_path="/tmp/x.log")


def test_yaml_parse_error_raises(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("not: valid: yaml: [unclosed")
    with pytest.raises(PolicyLoadError, match="YAML parse error"):
        Client(policy_file=str(p), log_path="/tmp/x.log")


def test_yaml_empty_file_raises(tmp_path):
    p = tmp_path / "empty.yaml"
    p.write_text("")
    with pytest.raises(PolicyValidationError, match="empty"):
        Client(policy_file=str(p), log_path="/tmp/x.log")


def test_yaml_root_must_be_mapping(tmp_path):
    p = tmp_path / "list.yaml"
    p.write_text("- just\n- a\n- list\n")
    with pytest.raises(PolicyValidationError, match="mapping"):
        Client(policy_file=str(p), log_path="/tmp/x.log")


def test_unsupported_format_raises(tmp_path):
    p = tmp_path / "policy.txt"
    p.write_text("not yaml")
    with pytest.raises(PolicyLoadError, match="unsupported file format"):
        Client(policy_file=str(p), log_path="/tmp/x.log")


def test_pathlib_path_works(tmp_path, tmp_log):
    p = tmp_path / "policy.yaml"
    p.write_text("version: '1'\nrules:\n  - allow: '*'\n")
    cz = Client(policy_file=p, log_path=str(tmp_log))  # pass Path, not str
    assert cz.guard("anything").decision == "allow"
    cz.close()
