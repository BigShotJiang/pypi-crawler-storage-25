"""controlzero validate exits 0 on valid, non-zero on invalid."""

from click.testing import CliRunner

from controlzero.cli.main import cli


def test_validate_clean_file(tmp_path):
    p = tmp_path / "good.yaml"
    p.write_text(
        """
version: "1"
rules:
  - deny: "delete_*"
  - allow: "read_*"
"""
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["validate", str(p)])
    assert result.exit_code == 0
    assert "OK" in result.output
    assert "2 rules" in result.output


def test_validate_invalid_file(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("rules: []\n")  # empty rules array is invalid
    runner = CliRunner()
    result = runner.invoke(cli, ["validate", str(p)])
    assert result.exit_code == 1
    assert "INVALID" in result.output


def test_validate_missing_file():
    runner = CliRunner()
    result = runner.invoke(cli, ["validate", "/nonexistent.yaml"])
    assert result.exit_code != 0
