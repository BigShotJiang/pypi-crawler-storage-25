"""Local mode loading from a JSON file."""

import json

import pytest

from controlzero import Client, PolicyLoadError


def test_load_json_file(tmp_path, tmp_log):
    p = tmp_path / "policy.json"
    p.write_text(
        json.dumps(
            {
                "version": "1",
                "rules": [
                    {"deny": "delete_*"},
                    {"allow": "read_*"},
                ],
            }
        )
    )
    cz = Client(policy_file=str(p), log_path=str(tmp_log))
    assert cz.guard("delete_thing").decision == "deny"
    assert cz.guard("read_thing").decision == "allow"
    cz.close()


def test_json_parse_error_raises(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("{not valid json}")
    with pytest.raises(PolicyLoadError, match="JSON parse error"):
        Client(policy_file=str(p), log_path="/tmp/x.log")
