"""When the log path is not writable, fall back to stderr.

Note: we mock loguru.add to raise OSError instead of relying on real
filesystem permissions, because Docker often runs as root which bypasses
chmod-based permission checks.
"""

from unittest.mock import patch

from controlzero import Client


def test_unwritable_path_falls_back_to_stderr(capsys, tmp_path):
    bad_log = tmp_path / "audit.log"

    # Force loguru.add to raise OSError as if the path were unwritable
    from loguru import logger as _logger
    original_add = _logger.add

    def fake_add(*args, **kwargs):
        raise OSError("Permission denied (simulated)")

    with patch.object(_logger, "add", side_effect=fake_add):
        cz = Client(
            policy={"rules": [{"allow": "*"}]},
            log_path=str(bad_log),
        )
        cz.guard("anything", {})
        cz.close()

    captured = capsys.readouterr()
    assert "falling back to stderr" in captured.err.lower()
    # The audit line itself also gets printed to stderr in fallback mode
    assert "anything" in captured.err
