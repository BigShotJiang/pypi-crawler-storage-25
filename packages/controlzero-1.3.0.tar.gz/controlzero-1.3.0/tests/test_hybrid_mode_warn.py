"""Hybrid mode: API key + local policy emits a WARN log on init."""

import sys

import pytest

from controlzero import Client


def test_hybrid_warns_to_stderr(monkeypatch, capsys):
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    cz = Client(
        policy={"rules": [{"deny": "delete_*"}]},
    )
    captured = capsys.readouterr()
    assert "manual policy override" in captured.err
    assert "WARNING" in captured.err
    cz.close()


def test_hybrid_warns_only_once_per_process(monkeypatch, capsys):
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    Client(policy={"rules": [{"allow": "*"}]})
    first = capsys.readouterr().err

    Client(policy={"rules": [{"allow": "*"}]})
    second = capsys.readouterr().err

    assert "manual policy override" in first
    assert "manual policy override" not in second
