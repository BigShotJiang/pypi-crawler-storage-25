"""Shared pytest fixtures for the controlzero test suite."""

import os
import sys

import pytest

# Reset module-level warning state before each test so order does not matter.
import controlzero.client as _client_mod


@pytest.fixture(autouse=True)
def reset_warning_state():
    _client_mod._NO_POLICY_WARNED = False
    _client_mod._HYBRID_WARNED = False
    yield


@pytest.fixture(autouse=True)
def clear_env(monkeypatch):
    """Make sure no env vars leak between tests."""
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
    monkeypatch.delenv("CONTROLZERO_POLICY_FILE", raising=False)
    yield


@pytest.fixture
def tmp_log(tmp_path):
    """Provide a temp log file path."""
    return tmp_path / "test-controlzero.log"
