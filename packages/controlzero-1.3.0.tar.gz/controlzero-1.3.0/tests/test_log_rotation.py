"""Local audit log writes and rotation config is applied."""

from controlzero import Client


def test_audit_log_writes_to_file(tmp_log):
    cz = Client(
        policy={"rules": [{"deny": "delete_*"}, {"allow": "*"}]},
        log_path=str(tmp_log),
    )
    cz.guard("delete_file", {"path": "/tmp/foo"})
    cz.guard("read_file", {"path": "/tmp/bar"})
    cz.close()

    assert tmp_log.exists()
    text = tmp_log.read_text(encoding="utf-8")
    assert "delete_file" in text
    assert "read_file" in text
    assert "deny" in text
    assert "allow" in text


def test_audit_log_uses_json_format_by_default(tmp_log):
    import json

    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
    )
    cz.guard("test_tool", {"key": "value"})
    cz.close()

    text = tmp_log.read_text(encoding="utf-8")
    lines = [line for line in text.splitlines() if line.strip()]
    assert lines, "no audit lines written"
    parsed = json.loads(lines[-1])
    assert parsed["tool"] == "test_tool"
    assert parsed["decision"] == "allow"


def test_audit_log_pretty_format(tmp_log):
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
        log_format="pretty",
    )
    cz.guard("test_tool", {})
    cz.close()

    text = tmp_log.read_text(encoding="utf-8")
    assert " | " in text
    assert "test_tool" in text


def test_log_rotation_size_config_accepted(tmp_log):
    """Just exercise the path. Loguru handles actual rotation under load."""
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
        log_rotation="10 MB",
        log_retention="7 days",
        log_compression="gz",
    )
    cz.guard("a", {})
    cz.close()
    assert tmp_log.exists()
