"""controlzero init -t {template} writes the right template."""

import pytest
from click.testing import CliRunner

from controlzero.cli.main import cli, DEFAULT_TEMPLATES


@pytest.mark.parametrize("template", DEFAULT_TEMPLATES)
def test_each_template_writes(tmp_path, monkeypatch, template):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "-t", template])
    assert result.exit_code == 0, result.output
    text = (tmp_path / "controlzero.yaml").read_text()
    assert "version" in text
    assert "rules" in text


def test_unknown_template_rejected(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "-t", "nonexistent-template"])
    assert result.exit_code != 0
