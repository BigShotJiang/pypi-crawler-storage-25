"""Tests for tamper detection in the hook-check path.

Validates that hook_check() actually uses the tamper protection primitives
from controlzero.tamper (verify_bundle, HashChain) which were previously
tested but never called from the hook-check code path.

Coverage:
  - Policy file unchanged after signing -> tamper_detected=false
  - Policy file modified after signing -> tamper_detected=true + stderr warning
  - No .sig file -> skip check (backwards compatible), tamper_detected=false
  - Audit log hash chain intact -> no warning, audit_chain_broken=false
  - Audit log hash chain broken -> warning on stderr, audit_chain_broken=true
"""

from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

# We need to reload the CLI module after monkey-patching Path.home()
# so that module-level constants (GLOBAL_POLICY_DIR etc.) pick up
# the fake home directory.


def _reload_cli(fake_home: Path):
    """Reload the CLI module with a patched Path.home() pointing to fake_home."""
    import controlzero.cli.main as cli_module

    with patch.object(Path, "home", return_value=fake_home):
        importlib.reload(cli_module)
    return cli_module


def _write_minimal_policy(policy_path: Path) -> None:
    """Write a minimal valid policy file."""
    policy_path.parent.mkdir(parents=True, exist_ok=True)
    policy_path.write_text(
        "rules:\n  - allow: '*'\n    reason: 'allow all for testing'\n",
        encoding="utf-8",
    )


def _sign_policy(policy_path: Path, key_path: Path) -> None:
    """Create an HMAC signature file for the policy."""
    from controlzero.tamper import load_or_create_secret, sign_bundle

    secret = load_or_create_secret(key_path)
    payload = policy_path.read_bytes()
    sig = sign_bundle(payload, secret)
    sig_path = policy_path.with_suffix(policy_path.suffix + ".sig")
    sig_path.write_text(sig, encoding="utf-8")


def _write_chained_audit_log(audit_path: Path, entries: list[dict]) -> None:
    """Write audit entries using the HashChain to produce a valid chain."""
    from controlzero.tamper import HashChain

    chain = HashChain(audit_path)
    lines = []
    for entry in entries:
        chained = chain.append(entry)
        lines.append(json.dumps(chained, sort_keys=True))
    audit_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Policy tamper detection
# ---------------------------------------------------------------------------


class TestPolicyTamperDetection:
    """Tests for HMAC-based policy file tamper detection in hook-check."""

    def test_no_sig_file_skips_check(self, tmp_path: Path):
        """When no .sig file exists, tamper check is skipped (backwards compatible)."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        _write_minimal_policy(policy_path)
        # No .sig file created

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        # Should allow (exit 0) with no tamper warning
        assert result.exit_code == 0
        assert "tamper detected" not in (result.output or "")

    def test_policy_unchanged_after_signing(self, tmp_path: Path):
        """Signed policy that has not been modified -> tamper_detected=false."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        key_path = policy_dir / "tamper.key"
        _write_minimal_policy(policy_path)
        _sign_policy(policy_path, key_path)

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "tamper detected" not in (result.output or "")

    def test_policy_modified_after_signing(self, tmp_path: Path):
        """Policy modified after signing -> tamper_detected=true, stderr warning."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        key_path = policy_dir / "tamper.key"
        _write_minimal_policy(policy_path)
        _sign_policy(policy_path, key_path)

        # Tamper with the policy AFTER signing -- keep an allow-all rule
        # so the tool call itself is still permitted; we are testing that
        # the tamper WARNING fires, not that the tool is denied.
        policy_path.write_text(
            "rules:\n  - allow: '*'\n    reason: 'tampered allow-all'\n",
            encoding="utf-8",
        )

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        # Still allows (fail-open for CLI) but warns on stderr
        assert result.exit_code == 0
        assert "tamper detected" in (result.output or "").lower()
        assert "HMAC mismatch" in (result.output or "")

    def test_sig_file_exists_but_no_key(self, tmp_path: Path):
        """Sig file exists but tamper key is missing -> skip check with warning."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        _write_minimal_policy(policy_path)

        # Write a fake .sig file but no tamper.key
        sig_path = policy_path.with_suffix(policy_path.suffix + ".sig")
        sig_path.write_text("fakesig", encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "tamper key is missing" in (result.output or "")


# ---------------------------------------------------------------------------
# Audit log hash chain verification
# ---------------------------------------------------------------------------


class TestAuditChainVerification:
    """Tests for hash chain verification of the audit log in hook-check."""

    def test_no_audit_log_no_warning(self, tmp_path: Path):
        """When no audit log exists, no chain warning is emitted."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        _write_minimal_policy(policy_path)

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "chain broken" not in (result.output or "")

    def test_intact_chain_no_warning(self, tmp_path: Path):
        """Audit log with intact hash chain -> no warning."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        audit_path = policy_dir / "audit.log"
        _write_minimal_policy(policy_path)

        # Write a valid chained audit log
        _write_chained_audit_log(
            audit_path,
            [
                {"tool": "bash", "decision": "allow"},
                {"tool": "read", "decision": "allow"},
            ],
        )

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "chain broken" not in (result.output or "")

    def test_broken_chain_warns(self, tmp_path: Path):
        """Audit log with a tampered entry -> warns on stderr."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        audit_path = policy_dir / "audit.log"
        _write_minimal_policy(policy_path)

        # Write a valid chained audit log first
        _write_chained_audit_log(
            audit_path,
            [
                {"tool": "bash", "decision": "allow"},
                {"tool": "read", "decision": "allow"},
                {"tool": "write", "decision": "deny"},
            ],
        )

        # Now tamper: rewrite the second entry to change the tool name
        lines = audit_path.read_text(encoding="utf-8").strip().splitlines()
        entry = json.loads(lines[1])
        entry["tool"] = "TAMPERED"
        lines[1] = json.dumps(entry, sort_keys=True)
        audit_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        # Should still allow (fail-open) but warn about chain breakage
        assert result.exit_code == 0
        assert "chain broken" in (result.output or "")

    def test_empty_audit_log_no_warning(self, tmp_path: Path):
        """Empty audit log file -> no warning."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        audit_path = policy_dir / "audit.log"
        _write_minimal_policy(policy_path)
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        audit_path.write_text("", encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "chain broken" not in (result.output or "")

    def test_audit_log_without_chain_fields_skips(self, tmp_path: Path):
        """Audit entries without entry_hash/prev_hash are skipped (old format)."""
        fake_home = tmp_path / "home"
        cli_mod = _reload_cli(fake_home)

        policy_dir = fake_home / ".controlzero"
        policy_path = policy_dir / "policy.yaml"
        audit_path = policy_dir / "audit.log"
        _write_minimal_policy(policy_path)
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        # Write old-format entries without hash chain fields
        old_entries = [
            json.dumps({"tool": "bash", "decision": "allow"}),
            json.dumps({"tool": "read", "decision": "allow"}),
        ]
        audit_path.write_text("\n".join(old_entries) + "\n", encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(
            cli_mod.hook_check,
            [],
            input=json.dumps({"tool_name": "echo", "tool_input": {"msg": "hi"}}),
        )
        assert result.exit_code == 0
        assert "chain broken" not in (result.output or "")
