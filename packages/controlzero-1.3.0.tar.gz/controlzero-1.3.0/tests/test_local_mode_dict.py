"""Local mode with a dict policy. Happy + negative paths."""

import pytest

from controlzero import Client, PolicyDeniedError, PolicyValidationError


def test_hello_world_deny_decision(tmp_log):
    cz = Client(
        policy={"rules": [{"deny": "delete_*", "reason": "Hello"}]},
        log_path=str(tmp_log),
    )
    result = cz.guard("delete_file", {"path": "/tmp/foo"})
    assert result.decision == "deny"
    assert result.denied is True
    assert result.allowed is False
    cz.close()


def test_hello_world_allow_decision(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"deny": "delete_*"},
                {"allow": "read_*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("read_file", {"path": "/tmp/foo"}).decision == "allow"
    cz.close()


def test_default_fail_closed_on_no_match(tmp_log):
    cz = Client(
        policy={"rules": [{"allow": "read_*"}]},
        log_path=str(tmp_log),
    )
    # exec_command does not match any rule -> denied (fail-closed)
    result = cz.guard("exec_command", {})
    assert result.decision == "deny"
    cz.close()


def test_raise_on_deny_raises():
    cz = Client(policy={"rules": [{"deny": "delete_*"}]}, log_path="/tmp/cz-test.log")
    with pytest.raises(PolicyDeniedError) as exc_info:
        cz.guard("delete_file", {}, raise_on_deny=True)
    assert exc_info.value.decision.denied
    cz.close()


def test_dict_with_no_rules_field_raises():
    with pytest.raises(PolicyValidationError) as exc_info:
        Client(policy={"version": "1"}, log_path="/tmp/cz-test.log")
    assert "rules" in str(exc_info.value)


def test_dict_with_empty_rules_raises():
    with pytest.raises(PolicyValidationError):
        Client(policy={"version": "1", "rules": []}, log_path="/tmp/cz-test.log")


def test_dict_rule_with_both_deny_and_allow_raises():
    with pytest.raises(PolicyValidationError) as exc_info:
        Client(
            policy={"rules": [{"deny": "x", "allow": "y"}]},
            log_path="/tmp/cz-test.log",
        )
    assert "both" in str(exc_info.value).lower()


def test_dict_rule_with_no_effect_raises():
    with pytest.raises(PolicyValidationError):
        Client(
            policy={"rules": [{"reason": "missing effect"}]},
            log_path="/tmp/cz-test.log",
        )


def test_passing_both_dict_and_file_raises():
    with pytest.raises(ValueError, match="not both"):
        Client(policy={"rules": []}, policy_file="x.yaml")


def test_tool_method_pattern(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"deny": "github:delete_repo"},
                {"allow": "github:*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("github", method="delete_repo").decision == "deny"
    assert cz.guard("github", method="list_repos").decision == "allow"
    cz.close()
