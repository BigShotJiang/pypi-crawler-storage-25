"""Glob matching via fnmatch. Verifies the patterns advertised in templates work."""

from controlzero import Client


def test_bare_tool_name_glob(tmp_log):
    cz = Client(
        policy={"rules": [{"deny": "delete_*"}, {"allow": "*"}]},
        log_path=str(tmp_log),
    )
    assert cz.guard("delete_file").decision == "deny"
    assert cz.guard("delete_repo").decision == "deny"
    assert cz.guard("read_file").decision == "allow"
    cz.close()


def test_tool_method_exact(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"deny": "github:delete_repo"},
                {"allow": "github:*"},
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("github", method="delete_repo").decision == "deny"
    assert cz.guard("github", method="list_repos").decision == "allow"
    assert cz.guard("github", method="get_pr").decision == "allow"
    cz.close()


def test_method_wildcard_across_any_tool(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"allow": "*:read"},
                {"allow": "*:list"},
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("fs", method="read").decision == "allow"
    assert cz.guard("db", method="read").decision == "allow"
    assert cz.guard("fs", method="write").decision == "deny"
    cz.close()


def test_resource_glob_in_suffix(tmp_log):
    """The bug that broke the cost-cap template: glob patterns inside the
    resource suffix (e.g. 'model:claude-haiku-*') must work, not just at the
    colon position."""
    cz = Client(
        policy={
            "rules": [
                {
                    "allow": "llm_call",
                    "resources": ["model:claude-haiku-*"],
                    "reason": "Haiku is cheap",
                },
                {
                    "deny": "llm_call",
                    "resources": ["model:claude-opus-*"],
                    "reason": "Opus is expensive",
                },
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    haiku = cz.guard("llm_call", context={"resource": "model:claude-haiku-3-5-20241022"})
    opus = cz.guard("llm_call", context={"resource": "model:claude-opus-4-20250101"})
    assert haiku.decision == "allow", f"expected allow, got {haiku.decision} ({haiku.reason})"
    assert opus.decision == "deny", f"expected deny, got {opus.decision} ({opus.reason})"
    cz.close()


def test_cost_cap_template_end_to_end(tmp_log):
    """The shipped cost-cap template must actually do what its comments claim."""
    from pathlib import Path
    template_path = Path(__file__).parent.parent / "controlzero" / "cli" / "templates" / "cost-cap.yaml"
    assert template_path.exists()

    cz = Client(policy_file=template_path, log_path=str(tmp_log))

    # Allowed: Haiku
    r = cz.guard("llm_call", context={"resource": "model:claude-haiku-3-5-20241022"})
    assert r.decision == "allow", f"Haiku should be allowed, got {r.decision} ({r.reason})"

    # Allowed: Sonnet
    r = cz.guard("llm_call", context={"resource": "model:claude-sonnet-4-5-20250929"})
    assert r.decision == "allow", f"Sonnet should be allowed, got {r.decision} ({r.reason})"

    # Allowed: gpt-4o-mini exact
    r = cz.guard("llm_call", context={"resource": "model:gpt-4o-mini"})
    assert r.decision == "allow"

    # Denied: Opus
    r = cz.guard("llm_call", context={"resource": "model:claude-opus-4-20250101"})
    assert r.decision == "deny"

    # Denied: gpt-4-32k exact
    r = cz.guard("llm_call", context={"resource": "model:gpt-4-32k"})
    assert r.decision == "deny"

    cz.close()


def test_universal_wildcard(tmp_log):
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
    )
    assert cz.guard("anything").allowed
    assert cz.guard("anything", method="anything").allowed
    cz.close()
