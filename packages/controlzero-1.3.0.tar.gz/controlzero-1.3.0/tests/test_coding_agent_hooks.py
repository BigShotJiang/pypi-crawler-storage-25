"""Comprehensive test suite for coding-agent hook policy evaluation.

Tests the full spectrum of policy enforcement behavior for the
controlzero hook system used by Claude Code, Gemini CLI, and Codex CLI.

Coverage matrix
---------------
POSITIVE (policy blocks correctly):
  1. deny-bash rule blocks Bash tool
  2. deny-shell rule blocks run_shell_command
  3. deny with glob pattern delete_* blocks delete_file, delete_repo
  4. First-match-wins: deny before allow catches the call
  5. Multiple deny rules, each blocks its target

NEGATIVE (policy allows correctly):
  6. Read tool allowed by explicit allow rule
  7. Write tool allowed by catch-all allow: '*'
  8. Tool not matching any deny passes through to catch-all allow
  9. Empty policy (no rules) fails closed (deny by default)

REGRESSION (the exact bug the user hit):
  10. Gemini template with only allow: '*' allows Bash
  11. Claude Code template with deny-bash blocks Bash
  12. Install claude-code when gemini policy exists: verify warning
  13. Install with --force overwrites gemini policy with claude-code policy
  14. Policy with deny-bash + allow-everything: Bash denied, Read allowed, Write allowed

EDGE CASES:
  15. hook-check with missing policy file: allows (does not brick agent)
  16. hook-check with malformed JSON stdin: allows (does not brick agent)
  17. hook-check with empty stdin: allows
  18. hook-check with missing tool_name: allows
  19. Case sensitivity: "bash" vs "Bash" vs "BASH"
  20. Glob patterns: "mcp__*__delete_*" matches "mcp__database__delete_table"
"""

from __future__ import annotations

import importlib
import json
import os
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from controlzero._internal.enforcer import PolicyEvaluator
from controlzero._internal.types import PolicyRule
from controlzero.cli.main import cli
from controlzero.policy_loader import load_policy


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def write_policy(tmp_path: Path, rules: list) -> Path:
    p = tmp_path / "policy.yaml"
    p.write_text(yaml.safe_dump({"version": "1", "rules": rules}))
    return p


def _setup_fake_home(tmp_path, monkeypatch):
    """Create a fake home directory and reload cli.main so constants update."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
    import controlzero.cli.main as cli_main
    importlib.reload(cli_main)
    return fake_home, cli_main


def _extract_decision_json(output: str) -> dict:
    """Extract the JSON decision block from hook-check output.

    The output may contain log lines (from loguru) before the JSON. We
    search for the last line that looks like a JSON object with a
    'decision' key.
    """
    for line in reversed(output.strip().splitlines()):
        line = line.strip()
        if line.startswith("{") and '"decision"' in line:
            return json.loads(line)
    raise ValueError(f"No decision JSON found in output:\n{output}")


# ===========================================================================
# POSITIVE: policy blocks correctly
# ===========================================================================

class TestPositiveDenyBlocks:
    """Tests 1-5: deny rules block the correct tool calls."""

    def test_01_deny_bash_blocks_bash(self, tmp_path):
        """deny: 'Bash' blocks the Bash tool."""
        p = write_policy(tmp_path, [
            {"id": "deny-bash", "deny": "Bash", "reason": "Bash blocked"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "ls"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2
        decision = _extract_decision_json(result.output)
        assert decision["decision"] == "block"

    def test_02_deny_shell_blocks_run_shell_command(self, tmp_path):
        """deny: 'run_shell_command' blocks Gemini CLI's shell tool."""
        p = write_policy(tmp_path, [
            {"id": "deny-shell", "deny": "run_shell_command", "reason": "Shell blocked"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "run_shell_command", "tool_input": {"command": "rm -rf /"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2
        decision = _extract_decision_json(result.output)
        assert decision["decision"] == "block"

    def test_03_deny_glob_delete_star_blocks_delete_file_and_repo(self, tmp_path):
        """deny: 'delete_*' blocks delete_file and delete_repo."""
        p = write_policy(tmp_path, [
            {"id": "deny-delete", "deny": "delete_*", "reason": "No deletions"},
            {"allow": "*"},
        ])
        runner = CliRunner()

        for tool in ("delete_file", "delete_repo"):
            payload = json.dumps({"tool_name": tool, "tool_input": {}})
            result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
            assert result.exit_code == 2, f"{tool} should be denied but exit_code={result.exit_code}"

    def test_04_first_match_wins_deny_before_allow(self, tmp_path):
        """First-match-wins: deny before allow catches the call."""
        p = write_policy(tmp_path, [
            {"deny": "Bash", "reason": "Deny first"},
            {"allow": "Bash"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2

    def test_05_multiple_deny_rules_each_blocks_its_target(self, tmp_path):
        """Multiple deny rules each block their own target."""
        p = write_policy(tmp_path, [
            {"deny": "Bash", "reason": "No Bash"},
            {"deny": "Edit", "reason": "No Edit"},
            {"deny": "Write", "reason": "No Write"},
            {"allow": "*"},
        ])
        runner = CliRunner()

        for tool in ("Bash", "Edit", "Write"):
            payload = json.dumps({"tool_name": tool, "tool_input": {}})
            result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
            assert result.exit_code == 2, f"{tool} should be blocked"

        # Read should still pass
        payload = json.dumps({"tool_name": "Read", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0


# ===========================================================================
# NEGATIVE: policy allows correctly
# ===========================================================================

class TestNegativeAllows:
    """Tests 6-9: allow rules and fail-closed behavior."""

    def test_06_read_allowed_by_explicit_allow(self, tmp_path):
        """Read tool allowed by explicit allow rule."""
        p = write_policy(tmp_path, [
            {"deny": "Bash"},
            {"allow": "Read", "reason": "Read is safe"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Read", "tool_input": {"file_path": "/tmp/x"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_07_write_allowed_by_catch_all(self, tmp_path):
        """Write tool allowed by catch-all allow: '*'."""
        p = write_policy(tmp_path, [
            {"deny": "Bash"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Write", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_08_unmatched_tool_passes_to_catch_all(self, tmp_path):
        """Tool not matching any deny passes through to catch-all allow."""
        p = write_policy(tmp_path, [
            {"deny": "Bash"},
            {"deny": "Edit"},
            {"allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "WebFetch", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_09_empty_policy_fails_closed(self):
        """Policy with no rules: evaluator denies by default (fail-closed)."""
        evaluator = PolicyEvaluator(rules=[])
        decision = evaluator.evaluate("Bash")
        assert decision.denied
        assert "fail-closed" in (decision.reason or "").lower()


# ===========================================================================
# REGRESSION: the exact bug the user hit
# ===========================================================================

class TestRegressionGeminiPolicyBug:
    """Tests 10-14: the cross-agent policy overwrite regression."""

    def test_10_gemini_template_allow_only_allows_bash(self, tmp_path):
        """Gemini template with only allow: '*' allows Bash (documents behavior)."""
        p = write_policy(tmp_path, [
            {"id": "allow-everything-else", "allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0, "Allow-only policy should let Bash through"

    def test_11_claude_code_template_with_deny_blocks_bash(self, tmp_path):
        """Policy with deny-bash blocks Bash (what SHOULD happen)."""
        p = write_policy(tmp_path, [
            {"id": "deny-bash", "deny": "Bash", "reason": "Bash blocked"},
            {"id": "allow-everything-else", "allow": "*"},
        ])
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2, "Deny-bash policy should block Bash"

    def test_12_install_claude_code_warns_when_gemini_policy_has_no_deny(
        self, tmp_path, monkeypatch
    ):
        """Installing claude-code when gemini policy exists: verify warning message."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        # Pre-install gemini policy (allow-only, no deny rules)
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        policy = cz_dir / "policy.yaml"
        policy.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [{"id": "allow-everything-else", "allow": "*"}],
        }))

        runner = CliRunner()
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 0

        # The warning goes to stderr but CliRunner mixes stdout+stderr into output
        combined = result.output
        assert "WARNING" in combined
        assert "deny rules" in combined.lower()
        assert "--force" in combined
        assert "--merge" in combined

    def test_13_install_force_overwrites_gemini_with_claude_code(
        self, tmp_path, monkeypatch
    ):
        """Install with --force overwrites gemini policy with claude-code policy."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        # Pre-install gemini policy
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        policy = cz_dir / "policy.yaml"
        policy.write_text("# gemini original\nversion: '1'\nrules:\n  - allow: '*'\n")

        runner = CliRunner()
        result = runner.invoke(cli_main.cli, ["install", "claude-code", "--force"])
        assert result.exit_code == 0

        # Policy should now contain claude-code template content
        new_content = policy.read_text()
        assert "Claude Code" in new_content or "claude-code" in new_content.lower()
        assert "gemini original" not in new_content

    def test_14_deny_bash_plus_allow_everything(self, tmp_path):
        """Policy with deny-bash + allow-everything: Bash denied, Read/Write allowed."""
        p = write_policy(tmp_path, [
            {"id": "deny-bash", "deny": "Bash", "reason": "No shell access"},
            {"id": "allow-everything", "allow": "*"},
        ])
        runner = CliRunner()

        # Bash should be denied
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "whoami"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2

        # Read should be allowed
        payload = json.dumps({"tool_name": "Read", "tool_input": {"file_path": "/tmp/x"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

        # Write should be allowed
        payload = json.dumps({"tool_name": "Write", "tool_input": {"file_path": "/tmp/x"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0


# ===========================================================================
# EDGE CASES
# ===========================================================================

class TestEdgeCases:
    """Tests 15-20: boundary conditions, resilience, pattern matching."""

    def test_15_missing_policy_file_allows(self, tmp_path, monkeypatch):
        """hook-check with missing policy file: allows (does not brick agent)."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "controlzero.cli.main.GLOBAL_POLICY_PATH",
            tmp_path / "nonexistent.yaml",
        )
        runner = CliRunner()
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}})
        result = runner.invoke(cli, ["hook-check"], input=payload)
        assert result.exit_code == 0

    def test_16_malformed_json_stdin_allows(self):
        """hook-check with malformed JSON stdin: allows (does not brick agent)."""
        runner = CliRunner()
        result = runner.invoke(cli, ["hook-check"], input="this is {not valid json")
        assert result.exit_code == 0

    def test_17_empty_stdin_allows(self):
        """hook-check with empty stdin: allows."""
        runner = CliRunner()
        result = runner.invoke(cli, ["hook-check"], input="")
        assert result.exit_code == 0

    def test_18_missing_tool_name_allows(self, tmp_path):
        """hook-check with missing tool_name: allows."""
        p = write_policy(tmp_path, [{"deny": "*"}])
        runner = CliRunner()
        payload = json.dumps({"tool_input": {"some": "data"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_19_case_sensitivity(self, tmp_path):
        """Case sensitivity: fnmatch is case-sensitive. 'Bash' != 'bash' != 'BASH'."""
        p = write_policy(tmp_path, [
            {"deny": "Bash", "reason": "Only exact Bash"},
            {"allow": "*"},
        ])
        runner = CliRunner()

        # "Bash" should be denied (exact match)
        payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2, "Exact 'Bash' should be denied"

        # "bash" (lowercase) should be ALLOWED (case-sensitive mismatch)
        payload = json.dumps({"tool_name": "bash", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0, "Lowercase 'bash' should NOT match deny 'Bash'"

        # "BASH" (uppercase) should be ALLOWED (case-sensitive mismatch)
        payload = json.dumps({"tool_name": "BASH", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0, "Uppercase 'BASH' should NOT match deny 'Bash'"

    def test_20_mcp_glob_pattern(self, tmp_path):
        """Glob: 'mcp__*__delete_*' matches 'mcp__database__delete_table'."""
        p = write_policy(tmp_path, [
            {"deny": "mcp__*__delete_*", "reason": "No MCP deletes"},
            {"allow": "*"},
        ])
        runner = CliRunner()

        # Should be denied
        payload = json.dumps({"tool_name": "mcp__database__delete_table", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2, "mcp__database__delete_table should match mcp__*__delete_*"

        # Non-delete MCP tool should be allowed
        payload = json.dumps({"tool_name": "mcp__database__list_tables", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0


# ===========================================================================
# MERGE FLAG TESTS
# ===========================================================================

class TestMergeFlag:
    """Tests for the --merge flag that adds template deny rules to existing policy."""

    def test_merge_adds_deny_sections_to_existing_policy(
        self, tmp_path, monkeypatch
    ):
        """--merge inserts template deny rule comments into existing policy."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        policy = cz_dir / "policy.yaml"
        policy.write_text(
            "version: '1'\n\nrules:\n"
            "  - id: allow-everything-else\n"
            "    allow: '*'\n"
            "    reason: 'Default allow.'\n"
        )

        runner = CliRunner()
        result = runner.invoke(cli_main.cli, ["install", "claude-code", "--merge"])
        assert result.exit_code == 0
        assert "Merged" in result.output

        merged_content = policy.read_text()
        # The merged content should still have the allow rule
        assert "allow" in merged_content
        # It should have deny examples from the template (as comments)
        assert "DENY:" in merged_content or "deny" in merged_content.lower()

    def test_merge_preserves_existing_rules(self, tmp_path, monkeypatch):
        """--merge preserves existing custom rules."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        policy = cz_dir / "policy.yaml"
        original = (
            "version: '1'\n\nrules:\n"
            "  - id: my-custom-deny\n"
            "    deny: 'dangerous_tool'\n"
            "    reason: 'Custom rule'\n"
            "  - id: allow-everything-else\n"
            "    allow: '*'\n"
        )
        policy.write_text(original)

        runner = CliRunner()
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli", "--merge"])
        assert result.exit_code == 0

        merged = policy.read_text()
        assert "my-custom-deny" in merged
        assert "dangerous_tool" in merged

    def test_no_warning_when_policy_has_deny_rules(self, tmp_path, monkeypatch):
        """No warning is emitted when existing policy already has deny rules."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        policy = cz_dir / "policy.yaml"
        policy.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [
                {"id": "deny-bash", "deny": "Bash", "reason": "Blocked"},
                {"allow": "*"},
            ],
        }))

        runner = CliRunner()
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 0

        combined = result.output
        assert "WARNING" not in combined


# ===========================================================================
# EVALUATOR UNIT TESTS (direct, no CLI)
# ===========================================================================

class TestEvaluatorDirect:
    """Direct tests against the PolicyEvaluator, bypassing CLI overhead."""

    def test_deny_rule_evaluator(self):
        """Evaluator correctly denies a matching tool."""
        rules = load_policy({
            "version": "1",
            "rules": [
                {"deny": "Bash", "reason": "No shell"},
                {"allow": "*"},
            ],
        })
        ev = PolicyEvaluator(rules=rules)
        d = ev.evaluate("Bash")
        assert d.denied
        assert d.reason == "No shell"

    def test_allow_rule_evaluator(self):
        """Evaluator correctly allows a non-matching tool."""
        rules = load_policy({
            "version": "1",
            "rules": [
                {"deny": "Bash"},
                {"allow": "*"},
            ],
        })
        ev = PolicyEvaluator(rules=rules)
        d = ev.evaluate("Read")
        assert d.allowed

    def test_no_rules_fail_closed(self):
        """No rules loaded: fail-closed default."""
        ev = PolicyEvaluator(rules=[])
        d = ev.evaluate("anything")
        assert d.denied
        assert "fail-closed" in (d.reason or "").lower()

    def test_glob_star_matches_all(self):
        """'*' pattern matches any tool name."""
        rules = load_policy({
            "version": "1",
            "rules": [{"allow": "*"}],
        })
        ev = PolicyEvaluator(rules=rules)
        for tool in ("Bash", "Read", "Write", "Edit", "mcp__foo__bar"):
            d = ev.evaluate(tool)
            assert d.allowed, f"'*' should allow {tool}"

    def test_glob_prefix_pattern(self):
        """'mcp__*' matches any tool starting with mcp__."""
        rules = load_policy({
            "version": "1",
            "rules": [
                {"deny": "mcp__*", "reason": "No MCP"},
                {"allow": "*"},
            ],
        })
        ev = PolicyEvaluator(rules=rules)
        d = ev.evaluate("mcp__database__list")
        assert d.denied
        d = ev.evaluate("Bash")
        assert d.allowed

    def test_evaluated_rules_count(self):
        """evaluated_rules reflects how many rules were checked."""
        rules = load_policy({
            "version": "1",
            "rules": [
                {"deny": "A"},
                {"deny": "B"},
                {"deny": "C"},
                {"allow": "*"},
            ],
        })
        ev = PolicyEvaluator(rules=rules)
        # "C" matches rule 3 (index 2), so evaluated_rules should be 3
        d = ev.evaluate("C")
        assert d.evaluated_rules == 3
        # "D" matches catch-all at rule 4, so evaluated_rules should be 4
        d = ev.evaluate("D")
        assert d.evaluated_rules == 4


# ===========================================================================
# HELPER FUNCTION UNIT TESTS
# ===========================================================================

class TestHelperFunctions:
    """Unit tests for the helper functions added in the fix."""

    def test_policy_has_deny_rules_true(self, tmp_path):
        """_policy_has_deny_rules returns True when deny rules exist."""
        from controlzero.cli.main import _policy_has_deny_rules
        p = tmp_path / "policy.yaml"
        p.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [
                {"deny": "Bash", "reason": "No shell"},
                {"allow": "*"},
            ],
        }))
        assert _policy_has_deny_rules(p) is True

    def test_policy_has_deny_rules_false(self, tmp_path):
        """_policy_has_deny_rules returns False when only allow rules exist."""
        from controlzero.cli.main import _policy_has_deny_rules
        p = tmp_path / "policy.yaml"
        p.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [{"allow": "*"}],
        }))
        assert _policy_has_deny_rules(p) is False

    def test_policy_has_deny_rules_bad_file(self, tmp_path):
        """_policy_has_deny_rules returns False for unparseable files."""
        from controlzero.cli.main import _policy_has_deny_rules
        p = tmp_path / "policy.yaml"
        p.write_text("this is not yaml: [[[")
        assert _policy_has_deny_rules(p) is False

    def test_policy_has_deny_rules_missing_file(self, tmp_path):
        """_policy_has_deny_rules returns False for missing files."""
        from controlzero.cli.main import _policy_has_deny_rules
        p = tmp_path / "nonexistent.yaml"
        assert _policy_has_deny_rules(p) is False


# ===========================================================================
# API KEY OPTION TESTS
# ===========================================================================

class TestApiKeyOption:
    """Tests for the --api-key option on install commands."""

    def test_api_key_validation_valid_live(self):
        """cz_live_ prefix is accepted."""
        from controlzero.cli.main import _validate_api_key
        assert _validate_api_key("cz_live_abc123") is True

    def test_api_key_validation_valid_test(self):
        """cz_test_ prefix is accepted."""
        from controlzero.cli.main import _validate_api_key
        assert _validate_api_key("cz_test_abc123") is True

    def test_api_key_validation_invalid(self):
        """Invalid prefixes are rejected."""
        from controlzero.cli.main import _validate_api_key
        assert _validate_api_key("sk_live_abc123") is False
        assert _validate_api_key("invalid") is False
        assert _validate_api_key("") is False
        assert _validate_api_key("cz_invalid_abc") is False

    def test_install_claude_code_with_api_key_writes_config(
        self, tmp_path, monkeypatch
    ):
        """install claude-code --api-key writes config.yaml with the key."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "claude-code", "--api-key", "cz_live_testkey123"],
        )
        assert result.exit_code == 0

        config_path = fake_home / ".controlzero" / "config.yaml"
        assert config_path.exists()
        config = yaml.safe_load(config_path.read_text())
        assert config["api_key"] == "cz_live_testkey123"

    def test_install_claude_code_with_api_key_updates_hook_command(
        self, tmp_path, monkeypatch
    ):
        """install claude-code --api-key includes env var in hook command."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "claude-code", "--api-key", "cz_live_testkey123"],
        )
        assert result.exit_code == 0

        settings_path = fake_home / ".claude" / "settings.json"
        settings = json.loads(settings_path.read_text())
        pre_tool = settings["hooks"]["PreToolUse"]
        assert len(pre_tool) == 1
        hook_cmd = pre_tool[0]["hooks"][0]["command"]
        assert "CONTROLZERO_API_KEY=cz_live_testkey123" in hook_cmd
        assert "controlzero hook-check" in hook_cmd

    def test_install_gemini_cli_with_api_key_updates_hook_command(
        self, tmp_path, monkeypatch
    ):
        """install gemini-cli --api-key includes env var in hook command."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "gemini-cli", "--api-key", "cz_test_geminikey"],
        )
        assert result.exit_code == 0

        settings_path = fake_home / ".gemini" / "settings.json"
        settings = json.loads(settings_path.read_text())
        before_tool = settings["hooks"]["BeforeTool"]
        assert len(before_tool) == 1
        assert "CONTROLZERO_API_KEY=cz_test_geminikey" in before_tool[0]["command"]

    def test_install_codex_cli_with_api_key_updates_wrapper(
        self, tmp_path, monkeypatch
    ):
        """install codex-cli --api-key includes env var in wrapper script."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "codex-cli", "--api-key", "cz_live_codexkey"],
        )
        assert result.exit_code == 0

        wrapper_path = fake_home / ".codex" / "hooks" / "controlzero.sh"
        assert wrapper_path.exists()
        wrapper_text = wrapper_path.read_text()
        assert "CONTROLZERO_API_KEY=cz_live_codexkey" in wrapper_text

    def test_install_with_invalid_api_key_exits_with_error(
        self, tmp_path, monkeypatch
    ):
        """install with invalid --api-key prints error and exits non-zero."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "claude-code", "--api-key", "invalid_key"],
        )
        assert result.exit_code != 0
        assert "Invalid API key format" in result.output

    def test_install_without_api_key_shows_hint(
        self, tmp_path, monkeypatch
    ):
        """install without --api-key shows tip about the option."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "claude-code"],
        )
        assert result.exit_code == 0
        assert "Tip: Pass --api-key" in result.output

    def test_install_with_api_key_shows_dashboard_message(
        self, tmp_path, monkeypatch
    ):
        """install with --api-key shows dashboard sync message."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            ["install", "claude-code", "--api-key", "cz_live_abc"],
        )
        assert result.exit_code == 0
        assert "Audit logs will sync" in result.output
        assert "https://app.controlzero.ai/audit" in result.output

    def test_hook_check_reads_api_key_from_config(
        self, tmp_path, monkeypatch
    ):
        """hook-check reads API key from config.yaml when env var not set."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        # Write config.yaml with API key
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        config_path = cz_dir / "config.yaml"
        config_path.write_text(yaml.safe_dump({"api_key": "cz_live_fromconfig"}))

        # Write a simple allow-all policy
        policy_path = cz_dir / "policy.yaml"
        policy_path.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [{"allow": "*"}],
        }))

        # Ensure env var is NOT set
        monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
        # Patch GLOBAL_POLICY_PATH and GLOBAL_POLICY_DIR to use fake home
        monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", cz_dir)
        monkeypatch.setattr(cli_main, "GLOBAL_POLICY_PATH", policy_path)
        monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", cz_dir / "audit.log")

        runner = CliRunner()
        payload = json.dumps({"tool_name": "Read", "tool_input": {}})
        result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)
        assert result.exit_code == 0

        # The env var should have been set by hook-check reading config.yaml
        assert os.environ.get("CONTROLZERO_API_KEY") == "cz_live_fromconfig"

        # Clean up env var
        monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    def test_hook_check_env_var_takes_precedence(
        self, tmp_path, monkeypatch
    ):
        """CONTROLZERO_API_KEY env var takes precedence over config.yaml."""
        fake_home, cli_main = _setup_fake_home(tmp_path, monkeypatch)

        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir(parents=True)
        config_path = cz_dir / "config.yaml"
        config_path.write_text(yaml.safe_dump({"api_key": "cz_live_fromconfig"}))

        policy_path = cz_dir / "policy.yaml"
        policy_path.write_text(yaml.safe_dump({
            "version": "1",
            "rules": [{"allow": "*"}],
        }))

        monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fromenv")
        monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", cz_dir)
        monkeypatch.setattr(cli_main, "GLOBAL_POLICY_PATH", policy_path)
        monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", cz_dir / "audit.log")

        runner = CliRunner()
        payload = json.dumps({"tool_name": "Read", "tool_input": {}})
        result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)
        assert result.exit_code == 0

        # Env var should remain as the original, not overwritten by config
        assert os.environ.get("CONTROLZERO_API_KEY") == "cz_live_fromenv"

        monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
