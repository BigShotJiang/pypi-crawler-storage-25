"""When API key is set (hybrid mode), log_* options are ignored with a warning."""

import warnings

from controlzero import Client


def test_log_options_warn_in_hybrid_mode(monkeypatch):
    """Hybrid mode (api key + local policy): log_* options have no effect
    because audit ships to remote, so we warn the user."""
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        Client(
            policy={"rules": [{"allow": "*"}]},
            log_path="/tmp/custom.log",
            log_rotation="1 MB",
        )
        assert any(
            "log_*" in str(warning.message) for warning in w
        ), f"expected log_* warning, got: {[str(x.message) for x in w]}"


def test_log_options_silent_in_pure_local(tmp_log):
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        cz = Client(
            policy={"rules": [{"allow": "*"}]},
            log_path=str(tmp_log),
            log_rotation="1 MB",
        )
        # No warning expected
        log_warnings = [x for x in w if "log_*" in str(x.message)]
        assert not log_warnings
        cz.close()
