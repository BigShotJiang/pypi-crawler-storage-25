"""Local policy evaluator. Pure Python, in-process, fail-closed by default.

Copied from the proven control_zero.policy.enforcer module and adapted for the
local-first surface. The eval logic is identical so behavior is consistent
across hosted and local modes.

Pattern matching uses Python's stdlib fnmatch (shell-style globs). All friendly
shorthand (e.g. "delete_*" -> "delete_*:*") is normalized in policy_loader.py
BEFORE rules reach this evaluator. By the time rules arrive here, every action
is canonical "tool:method" form. This keeps the evaluator simple and matches
the legacy hosted engine's behavior.

DLP scanning (added 2026-04-09): after the tool-name policy check, the
evaluator optionally scans tool arguments for PII, secrets, and sensitive data
patterns. A "block" DLP match overrides an "allow" decision. "detect" matches
are recorded in the audit entry without blocking.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from typing import Any, Optional

from controlzero._internal.dlp_scanner import (
    DLPMatch,
    DLPScanner,
    extract_text_from_args,
)
from controlzero._internal.types import PolicyRule


@dataclass
class PolicyDecision:
    """Result of a policy evaluation.

    Attributes:
        effect: One of "allow", "deny", "warn", "audit".
        decision: Alias for effect, for ergonomic Hello World code.
        policy_id: ID of the rule that matched, or None if no match.
        reason: Human-readable reason for the decision.
        evaluated_rules: How many rules were checked before a match.
        dlp_findings: List of DLP match dicts for the audit trail.
    """
    effect: str
    policy_id: Optional[str] = None
    reason: Optional[str] = None
    evaluated_rules: int = 0
    dlp_findings: list[dict] = field(default_factory=list)

    @property
    def decision(self) -> str:
        """Alias for `effect`. Reads more naturally in user code."""
        return self.effect

    @property
    def allowed(self) -> bool:
        """True if the call was allowed."""
        return self.effect == "allow"

    @property
    def denied(self) -> bool:
        """True if the call was denied."""
        return self.effect == "deny"


class PolicyDeniedError(Exception):
    """Raised by `Client.guard(..., raise_on_deny=True)` when a policy denies an action."""

    def __init__(self, decision: PolicyDecision):
        self.decision = decision
        super().__init__(
            f"Policy denied: {decision.reason or 'no reason provided'}"
        )


class PolicyEvaluator:
    """In-process policy evaluator. Fail-closed by default.

    Loads a list of internal `PolicyRule` objects and evaluates tool calls
    against them in order. The first matching rule wins. If no rule matches,
    the call is denied (fail-closed).

    Optionally accepts a DLPScanner to inspect tool arguments for sensitive
    content after the tool-name policy check passes.

    All pattern matching uses `fnmatch.fnmatchcase` (shell-style globs):
        *           matches everything
        delete_*    matches anything starting with "delete_"
        github:*    matches any method on the github tool
        *:read      matches the read method on any tool
        model:*-haiku-*  matches any model with -haiku- in its name
    """

    def __init__(
        self,
        rules: Optional[list[PolicyRule]] = None,
        dlp_scanner: Optional[DLPScanner] = None,
    ):
        self._rules: list[PolicyRule] = rules or []
        self._dlp_scanner: Optional[DLPScanner] = dlp_scanner

    def load(self, rules: list[PolicyRule]) -> None:
        """Replace the rule set."""
        self._rules = list(rules)

    def set_dlp_scanner(self, scanner: DLPScanner) -> None:
        """Set or replace the DLP scanner."""
        self._dlp_scanner = scanner

    def evaluate(
        self,
        tool: str,
        method: str = "*",
        context: Optional[dict] = None,
        args: Optional[dict] = None,
    ) -> PolicyDecision:
        """Evaluate a tool call against the loaded rules.

        Args:
            tool: Tool name (e.g. "delete_file", "github").
            method: Optional method name. Defaults to "*" which matches any.
            context: Optional context dict with `resource` and `tags` keys.
            args: Optional tool arguments dict. Scanned for DLP patterns if
                  a DLPScanner is configured.

        Returns:
            PolicyDecision. Always returns; never raises.
        """
        action = f"{tool}:{method}"
        resource = (context or {}).get("resource")
        evaluated = 0

        for rule in self._rules:
            evaluated += 1
            if not _glob_any(rule.actions, action):
                continue
            if rule.resources:
                if not resource or not _glob_any(rule.resources, resource):
                    continue
            decision = PolicyDecision(
                effect=rule.effect,
                policy_id=rule.id or rule.name or None,
                # User-provided reason wins. Falls back to canned text only if
                # the rule had no `reason:` field in the source policy.
                reason=rule.reason or f"Matched rule {rule.id or rule.name}".strip(),
                evaluated_rules=evaluated,
            )
            # DLP scan: only when the policy decision is "allow" and args exist
            if decision.allowed and args and self._dlp_scanner is not None:
                decision = self._apply_dlp_scan(decision, args)
            return decision

        # Fail-closed default. No matching rule means deny.
        return PolicyDecision(
            effect="deny",
            reason="No matching policy rule (fail-closed default)",
            evaluated_rules=evaluated,
        )

    def _apply_dlp_scan(
        self, decision: PolicyDecision, args: dict
    ) -> PolicyDecision:
        """Run DLP scanner on tool arguments and update decision if needed.

        If any DLP rule has action="block", the decision is overridden to DENY.
        If rules have action="detect" or "mask", findings are attached to the
        decision for audit but the call is still allowed.
        """
        if self._dlp_scanner is None:
            return decision

        text = extract_text_from_args(args)
        if not text:
            return decision

        matches = self._dlp_scanner.scan(text)
        if not matches:
            return decision

        findings = self._dlp_scanner.get_findings_for_audit(matches)
        decision.dlp_findings = findings

        if self._dlp_scanner.has_blocking_match(matches):
            # Find the first blocking rule for the reason message
            blocking = next(m for m in matches if m.action == "block")
            return PolicyDecision(
                effect="deny",
                policy_id=decision.policy_id,
                reason=(
                    f"DLP rule '{blocking.rule_name}' matched "
                    f"{blocking.category} content in tool arguments"
                ),
                evaluated_rules=decision.evaluated_rules,
                dlp_findings=findings,
            )

        return decision


def _glob_any(patterns: list[str], value: str) -> bool:
    """True if any pattern matches the value via fnmatch.fnmatchcase.

    fnmatchcase is case-sensitive (matches policy semantics) and supports the
    same syntax users learn from .gitignore: *, ?, [seq], [!seq].
    """
    for p in patterns:
        if fnmatch.fnmatchcase(value, p):
            return True
    return False
