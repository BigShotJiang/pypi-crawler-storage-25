"""DLP (Data Loss Prevention) scanner for tool argument inspection.

Scans text content from tool arguments for PII, secrets, and sensitive data
patterns. Used by the policy evaluator to block or flag tool calls whose
arguments contain sensitive content, even when the tool itself is allowed by
policy rules.

Two pattern sources:
  1. Built-in patterns: high-confidence regexes shipped with the SDK.
     Always active, zero config. Work in local-only mode.
  2. Custom rules: loaded from the policy file's `dlp_rules:` section
     or pulled from backend for enrolled SDKs.

Secret-category matches store a SHA-256 hash of the matched text, never the
plaintext. This is consistent with the browser extension's HMAC approach.

Pattern categories:
  pii       - Personally identifiable information (SSN, RRN, etc.)
  financial - Financial data (credit cards, IBAN, etc.)
  healthcare- HIPAA-relevant identifiers (NPI, DEA, etc.)
  secret    - API keys, tokens, credentials, connection strings
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Built-in patterns grouped by category.
# All builtins use action="detect". Admins add action="block" via custom rules.
# ---------------------------------------------------------------------------

# --- PII: United States ---
_PII_US = [
    {
        "id": "builtin-us-ssn",
        "name": "US SSN",
        "pattern": r"\b\d{3}-\d{2}-\d{4}\b",
        "category": "pii",
        "region": "us",
    },
    {
        "id": "builtin-us-phone",
        "name": "US Phone",
        "pattern": r"\b(?:\+1[- ]?)?\(?\d{3}\)?[- ]?\d{3}[- ]?\d{4}\b",
        "category": "pii",
        "region": "us",
    },
]

# --- PII: Korea ---
_PII_KR = [
    {
        "id": "builtin-kr-rrn",
        "name": "Korean RRN",
        "pattern": r"\b\d{6}-[1-4]\d{6}\b",
        "category": "pii",
        "region": "kr",
    },
    {
        "id": "builtin-kr-phone",
        "name": "Korean Phone",
        "pattern": r"\b01[016789]-\d{3,4}-\d{4}\b",
        "category": "pii",
        "region": "kr",
    },
    {
        "id": "builtin-kr-brn",
        "name": "Korean BRN",
        "pattern": r"\b\d{3}-\d{2}-\d{5}\b",
        "category": "pii",
        "region": "kr",
    },
    {
        "id": "builtin-kr-drivers-license",
        "name": "Korean Driver License",
        "pattern": r"\b\d{2}-\d{2}-\d{6}-\d{2}\b",
        "category": "pii",
        "region": "kr",
    },
    {
        "id": "builtin-kr-passport",
        "name": "Korean Passport",
        "pattern": r"\b[MS]\d{8}\b",
        "category": "pii",
        "region": "kr",
    },
    {
        "id": "builtin-kr-bank-account",
        "name": "Korean Bank Account",
        "pattern": r"\b\d{3,4}-\d{2,6}-\d{2,6}\b",
        "category": "pii",
        "region": "kr",
    },
]

# --- PII: Japan ---
_PII_JP = [
    {
        "id": "builtin-jp-my-number-individual",
        "name": "Japanese My Number (Individual)",
        "pattern": r"\b\d{4}\s?\d{4}\s?\d{4}\b",
        "category": "pii",
        "region": "jp",
    },
    {
        "id": "builtin-jp-my-number-corporate",
        "name": "Japanese My Number (Corporate)",
        "pattern": r"\b\d{13}\b",
        "category": "pii",
        "region": "jp",
    },
    {
        "id": "builtin-jp-phone",
        "name": "Japanese Phone",
        "pattern": r"\b0[789]0-\d{4}-\d{4}\b",
        "category": "pii",
        "region": "jp",
    },
]

# --- PII: Europe ---
_PII_EU = [
    {
        "id": "builtin-uk-nin",
        "name": "UK National Insurance Number",
        "pattern": r"\b[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b",
        "category": "pii",
        "region": "uk",
    },
    {
        "id": "builtin-de-tax-id",
        "name": "German Tax ID (Steuer-ID)",
        "pattern": r"\b\d{11}\b",
        "category": "pii",
        "region": "de",
    },
    {
        "id": "builtin-fr-nir",
        "name": "French NIR (Social Security)",
        "pattern": r"\b[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}\b",
        "category": "pii",
        "region": "fr",
    },
]

# --- PII: India ---
_PII_IN = [
    {
        "id": "builtin-in-aadhaar",
        "name": "Indian Aadhaar",
        "pattern": r"\b\d{4}\s\d{4}\s\d{4}\b",
        "category": "pii",
        "region": "in",
    },
    {
        "id": "builtin-in-pan",
        "name": "Indian PAN",
        "pattern": r"\b[A-Z]{5}\d{4}[A-Z]\b",
        "category": "pii",
        "region": "in",
    },
]

# --- PII: Brazil ---
_PII_BR = [
    {
        "id": "builtin-br-cpf",
        "name": "Brazilian CPF",
        "pattern": r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b",
        "category": "pii",
        "region": "br",
    },
]

# --- PII: Other regions ---
_PII_OTHER = [
    {
        "id": "builtin-ca-sin",
        "name": "Canadian SIN",
        "pattern": r"\b\d{3}-\d{3}-\d{3}\b",
        "category": "pii",
        "region": "ca",
    },
    {
        "id": "builtin-au-tfn",
        "name": "Australian TFN",
        "pattern": r"\b\d{3}\s?\d{3}\s?\d{2,3}\b",
        "category": "pii",
        "region": "au",
    },
    {
        "id": "builtin-sg-nric",
        "name": "Singapore NRIC/FIN",
        "pattern": r"\b[STFGM]\d{7}[A-Z]\b",
        "category": "pii",
        "region": "sg",
    },
    {
        "id": "builtin-hk-id",
        "name": "Hong Kong ID",
        "pattern": r"\b[A-Z]{1,2}\d{6}\(?[0-9A]\)?\b",
        "category": "pii",
        "region": "hk",
    },
]

# --- PII: Global ---
_PII_GLOBAL = [
    {
        "id": "builtin-email",
        "name": "Email Address",
        "pattern": r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
        "category": "pii",
        "region": "global",
    },
]

# --- Financial ---
_FINANCIAL = [
    {
        "id": "builtin-credit-card",
        "name": "Credit Card",
        "pattern": (
            r"\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6(?:011|5\d{2})"
            r"|35(?:2[89]|[3-8]\d))"
            r"[- ]?\d{4}[- ]?\d{4}[- ]?\d{3,4}\b"
        ),
        "category": "financial",
        "region": "global",
    },
    {
        "id": "builtin-iban",
        "name": "IBAN",
        "pattern": r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}(?:[A-Z0-9]{0,18})\b",
        "category": "financial",
        "region": "global",
    },
    {
        "id": "builtin-swift-bic",
        "name": "SWIFT/BIC Code",
        "pattern": r"\b[A-Z]{6}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b",
        "category": "financial",
        "region": "global",
    },
    {
        "id": "builtin-us-routing",
        "name": "US Routing Number",
        "pattern": r"\b[0-3]\d{8}\b",
        "category": "financial",
        "region": "us",
    },
    {
        "id": "builtin-bitcoin-address",
        "name": "Bitcoin Address",
        "pattern": r"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b",
        "category": "financial",
        "region": "global",
    },
    {
        "id": "builtin-ethereum-address",
        "name": "Ethereum Address",
        "pattern": r"\b0x[0-9a-fA-F]{40}\b",
        "category": "financial",
        "region": "global",
    },
]

# --- Healthcare (HIPAA) ---
_HEALTHCARE = [
    {
        "id": "builtin-us-npi",
        "name": "US NPI",
        "pattern": r"\b\d{10}\b",
        "category": "healthcare",
        "region": "us",
    },
    {
        "id": "builtin-us-dea",
        "name": "US DEA Number",
        "pattern": r"\b[ABCDEFGHJKLMNPRSTUXabcdefghjklmnprstux][A-Za-z9]\d{7}\b",
        "category": "healthcare",
        "region": "us",
    },
]

# --- Secrets: Cloud Providers ---
_SECRET_CLOUD = [
    {
        "id": "builtin-aws-access-key",
        "name": "AWS Access Key",
        "pattern": r"\bAKIA[0-9A-Z]{16}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-aws-secret-key",
        "name": "AWS Secret Key",
        "pattern": r"\b[A-Za-z0-9/+=]{40}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-gcp-api-key",
        "name": "GCP API Key",
        "pattern": r"\bAIza[0-9A-Za-z_-]{35}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-gcp-service-account",
        "name": "GCP Service Account Key",
        "pattern": r'"type"\s*:\s*"service_account"',
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-azure-client-secret",
        "name": "Azure Client Secret",
        "pattern": r"\b[a-zA-Z0-9~._-]{34}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-azure-sas-token",
        "name": "Azure SAS Token",
        "pattern": r"sv=\d{4}-\d{2}-\d{2}&[a-zA-Z0-9%&=_.-]+sig=[a-zA-Z0-9%+/=]+",
        "category": "secret",
        "region": "global",
    },
]

# --- Secrets: AI Providers ---
_SECRET_AI = [
    {
        "id": "builtin-openai-key",
        "name": "OpenAI API Key",
        "pattern": r"\bsk-(?:proj-)?[a-zA-Z0-9_-]{20,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-anthropic-key",
        "name": "Anthropic API Key",
        "pattern": r"\bsk-ant-[a-zA-Z0-9_-]{90,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-huggingface-token",
        "name": "HuggingFace Token",
        "pattern": r"\bhf_[a-zA-Z0-9]{34}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-cohere-key",
        "name": "Cohere API Key",
        "pattern": r"\b[a-zA-Z0-9]{40}\b",
        "category": "secret",
        "region": "global",
    },
]

# --- Secrets: Database Connection Strings ---
_SECRET_DB = [
    {
        "id": "builtin-postgres-url",
        "name": "PostgreSQL Connection String",
        "pattern": r"postgres(?:ql)?://[^\s:]+:[^\s@]+@[^\s]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-mysql-url",
        "name": "MySQL Connection String",
        "pattern": r"mysql://[^\s:]+:[^\s@]+@[^\s]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-mongodb-url",
        "name": "MongoDB Connection String",
        "pattern": r"mongodb(?:\+srv)?://[^\s:]+:[^\s@]+@[^\s]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-redis-url",
        "name": "Redis Connection String",
        "pattern": r"rediss?://[^\s:]*:[^\s@]+@[^\s]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-jwt-token",
        "name": "JWT Token",
        "pattern": r"\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b",
        "category": "secret",
        "region": "global",
    },
]

# --- Secrets: SaaS / Developer Tools ---
_SECRET_SAAS = [
    {
        "id": "builtin-github-pat",
        "name": "GitHub PAT",
        "pattern": r"\b(?:ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{82})\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-gitlab-pat",
        "name": "GitLab PAT",
        "pattern": r"\bglpat-[A-Za-z0-9_-]{20,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-slack-bot-token",
        "name": "Slack Bot Token",
        "pattern": r"\bxoxb-[0-9]+-[0-9]+-[a-zA-Z0-9]+\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-slack-webhook",
        "name": "Slack Webhook URL",
        "pattern": r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-stripe-secret",
        "name": "Stripe Secret Key",
        "pattern": r"\b(?:sk_live|sk_test)_[A-Za-z0-9]{24,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-stripe-publishable",
        "name": "Stripe Publishable Key",
        "pattern": r"\b(?:pk_live|pk_test)_[A-Za-z0-9]{24,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-sendgrid-key",
        "name": "SendGrid API Key",
        "pattern": r"\bSG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-npm-token",
        "name": "npm Token",
        "pattern": r"\bnpm_[A-Za-z0-9]{36}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-pypi-token",
        "name": "PyPI Token",
        "pattern": r"\bpypi-[A-Za-z0-9_-]{150,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-controlzero-key",
        "name": "Control Zero API Key",
        "pattern": r"\bcz_(?:live|test)_[A-Za-z0-9]{20,}\b",
        "category": "secret",
        "region": "global",
    },
]

# --- Secrets: Infrastructure ---
_SECRET_INFRA = [
    {
        "id": "builtin-ssh-private-key",
        "name": "SSH Private Key",
        "pattern": r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-pem-certificate",
        "name": "PEM Certificate",
        "pattern": r"-----BEGIN CERTIFICATE-----",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-vault-token",
        "name": "Vault Token",
        "pattern": r"\bhvs\.[a-zA-Z0-9_-]{24,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-doppler-token",
        "name": "Doppler Token",
        "pattern": r"\bdp\.st\.[a-zA-Z0-9]{40,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-datadog-api-key",
        "name": "Datadog API Key",
        "pattern": r"\b[a-f0-9]{32}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-sentry-dsn",
        "name": "Sentry DSN",
        "pattern": r"https://[a-f0-9]+@[a-z0-9.]+\.ingest\.sentry\.io/\d+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-bearer-token",
        "name": "Bearer Token (Authorization Header)",
        "pattern": r"[Aa]uthorization:\s*Bearer\s+[A-Za-z0-9_.-]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-amqp-url",
        "name": "AMQP/RabbitMQ Connection String",
        "pattern": r"amqps?://[^\s:]+:[^\s@]+@[^\s]+",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-linear-key",
        "name": "Linear API Key",
        "pattern": r"\blin_api_[a-zA-Z0-9]{40,}\b",
        "category": "secret",
        "region": "global",
    },
    {
        "id": "builtin-newrelic-key",
        "name": "New Relic API Key",
        "pattern": r"\bNRAK-[A-Z0-9]{27}\b",
        "category": "secret",
        "region": "global",
    },
]


# Assemble all built-in patterns with action="detect"
BUILTIN_PATTERNS: list[dict[str, Any]] = []
for _group in [
    _PII_US, _PII_KR, _PII_JP, _PII_EU, _PII_IN, _PII_BR, _PII_OTHER,
    _PII_GLOBAL,
    _FINANCIAL,
    _HEALTHCARE,
    _SECRET_CLOUD, _SECRET_AI, _SECRET_DB, _SECRET_SAAS, _SECRET_INFRA,
]:
    for _p in _group:
        _entry = dict(_p)
        _entry.setdefault("action", "detect")
        BUILTIN_PATTERNS.append(_entry)


@dataclass
class DLPRule:
    """A single DLP scanning rule."""

    id: str
    name: str
    pattern: str
    category: str  # "pii", "financial", "secret", "healthcare"
    action: str  # "detect", "block", "mask"
    region: str = "global"
    compiled: Optional[re.Pattern] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if self.compiled is None:
            self.compiled = re.compile(self.pattern)


@dataclass
class DLPMatch:
    """A single DLP match result."""

    rule_id: str
    rule_name: str
    category: str
    action: str
    matched_text: str  # plaintext for pii/financial, SHA-256 hash for secret
    offset: int
    count: int = 1


class DLPScanner:
    """Scans text for DLP pattern matches.

    Loads built-in patterns on init. Custom rules can be added via
    `add_rules()` or passed during construction.
    """

    def __init__(
        self,
        custom_rules: Optional[list[dict[str, Any]]] = None,
        enable_builtins: bool = True,
    ):
        self._rules: list[DLPRule] = []
        if enable_builtins:
            self._load_rules(BUILTIN_PATTERNS)
        if custom_rules:
            self._load_rules(custom_rules)

    def _load_rules(self, raw_rules: list[dict[str, Any]]) -> None:
        """Parse and compile a list of raw rule dicts into DLPRule objects."""
        for raw in raw_rules:
            try:
                compiled = re.compile(raw["pattern"])
                self._rules.append(
                    DLPRule(
                        id=raw.get("id", ""),
                        name=raw.get("name", raw.get("id", "unnamed")),
                        pattern=raw["pattern"],
                        category=raw.get("category", "pii"),
                        action=raw.get("action", "detect"),
                        region=raw.get("region", "global"),
                        compiled=compiled,
                    )
                )
            except re.error:
                # Skip rules with invalid regex. Silently dropping is safer
                # than crashing the hook.
                continue

    def add_rules(self, raw_rules: list[dict[str, Any]]) -> None:
        """Add custom rules on top of existing ones."""
        self._load_rules(raw_rules)

    @property
    def rule_count(self) -> int:
        """Number of loaded rules."""
        return len(self._rules)

    def scan(self, text: str) -> list[DLPMatch]:
        """Scan text against all loaded DLP rules.

        Args:
            text: The text to scan. Typically concatenated string values
                  extracted from tool arguments.

        Returns:
            List of DLPMatch objects for each rule that matched.
            For secret-category rules, matched_text is a SHA-256 hash.
        """
        if not text or not self._rules:
            return []

        matches: list[DLPMatch] = []
        for rule in self._rules:
            if rule.compiled is None:
                continue
            found = list(rule.compiled.finditer(text))
            if not found:
                continue

            for m in found:
                raw_text = m.group(0)

                # Secret-category: hash the matched text, never store plaintext
                if rule.category == "secret":
                    display_text = hashlib.sha256(
                        raw_text.encode("utf-8")
                    ).hexdigest()
                else:
                    display_text = raw_text

                matches.append(
                    DLPMatch(
                        rule_id=rule.id,
                        rule_name=rule.name,
                        category=rule.category,
                        action=rule.action,
                        matched_text=display_text,
                        offset=m.start(),
                    )
                )

        return matches

    def has_blocking_match(self, matches: list[DLPMatch]) -> bool:
        """Check if any match has action='block'."""
        return any(m.action == "block" for m in matches)

    def get_findings_for_audit(self, matches: list[DLPMatch]) -> list[dict]:
        """Convert matches to audit-safe findings.

        For secret-category matches, only count is included (no text).
        For other categories, the matched text is included.
        """
        findings: list[dict] = []
        for m in matches:
            entry: dict[str, Any] = {
                "rule_id": m.rule_id,
                "category": m.category,
                "action": m.action,
                "count": m.count,
            }
            # Never include matched text for secrets in audit
            if m.category != "secret":
                entry["matched_text"] = m.matched_text
            findings.append(entry)
        return findings


def extract_text_from_args(args: Any) -> str:
    """Recursively extract all string values from a nested dict/list structure.

    Handles nested dicts, lists, and mixed structures. Non-string leaf
    values are converted to their string representation.

    Args:
        args: The tool arguments (typically a dict from JSON).

    Returns:
        A single string with all extracted values joined by newlines.
    """
    parts: list[str] = []
    _extract_recursive(args, parts)
    return "\n".join(parts)


def _extract_recursive(obj: Any, parts: list[str]) -> None:
    """Walk a nested structure and collect string representations."""
    if isinstance(obj, str):
        parts.append(obj)
    elif isinstance(obj, dict):
        for v in obj.values():
            _extract_recursive(v, parts)
    elif isinstance(obj, (list, tuple)):
        for item in obj:
            _extract_recursive(item, parts)
    elif obj is not None:
        # Convert numbers, bools, etc. to string for scanning
        parts.append(str(obj))


def load_dlp_rules_from_policy(policy_data: dict) -> list[dict[str, Any]]:
    """Extract DLP rules from a policy dict's `dlp_rules:` section.

    Args:
        policy_data: The raw parsed policy dict (before rule translation).

    Returns:
        List of raw DLP rule dicts, or empty list if no dlp_rules section.
    """
    dlp_rules = policy_data.get("dlp_rules")
    if not dlp_rules or not isinstance(dlp_rules, list):
        return []

    valid: list[dict[str, Any]] = []
    for rule in dlp_rules:
        if not isinstance(rule, dict):
            continue
        if "pattern" not in rule:
            continue
        # Filter to SDK scope if scopes are specified
        scopes = rule.get("scopes")
        if scopes and isinstance(scopes, list) and "sdk" not in scopes:
            continue
        valid.append(rule)
    return valid
