"""Internal type definitions. Public users should import from controlzero, not here."""

from typing import Any, Optional
from pydantic import BaseModel, Field


class PolicyRule(BaseModel):
    """Internal canonical representation of a single policy rule.

    The user-facing schema (see policy_loader) is friendlier; this is what the
    evaluator consumes after translation.
    """
    id: str = ""
    name: str = ""
    effect: str  # "allow" or "deny"
    actions: list[str] = Field(default_factory=list)
    resources: list[str] = Field(default_factory=list)
    conditions: dict[str, Any] = Field(default_factory=dict)
    reason: str = ""  # Human-readable explanation, surfaced in audit + denies
