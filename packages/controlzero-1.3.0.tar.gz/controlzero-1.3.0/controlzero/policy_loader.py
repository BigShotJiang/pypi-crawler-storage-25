"""Load and validate policies from dict, YAML file, or JSON file.

Translates the friendly user-facing schema into internal `PolicyRule` objects
that the evaluator consumes.

User-facing schema (the "Hello World" form):

    version: "1"
    rules:
      - id: hello-world           # optional
        deny: "delete_*"          # tool name pattern, OR "tool:method"
        reason: "Hello World"
      - allow: "read_*"
      - deny: "*"
        when:
          model: "claude-opus-*"

Internal schema (what the evaluator sees) is a list of PolicyRule with explicit
effect, actions, and resources fields. The translation handles shorthand:
- "delete_*" -> action ["delete_*:*"] (any method on matching tools)
- "github:list_*" -> action ["github:list_*"]
- "*" -> action ["*"]
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Union

from controlzero._internal.types import PolicyRule
from controlzero.errors import PolicyLoadError, PolicyValidationError

PolicyInput = Union[dict, str, Path]


def _canonicalize_action(pattern: str) -> str:
    """Translate a user-facing action pattern to canonical "tool:method" form.

    Rules:
      "*"             -> "*"            (universal, matches any tool:method)
      "delete_*"      -> "delete_*:*"   (no colon = match any method on matching tools)
      "github:*"      -> "github:*"     (already canonical)
      "github:list_*" -> "github:list_*"
      "*:read"        -> "*:read"
    """
    if pattern == "*":
        return "*"
    if ":" in pattern:
        return pattern
    return f"{pattern}:*"


def load_policy(source: PolicyInput) -> list[PolicyRule]:
    """Load a policy from a dict, file path, or Path object.

    Args:
        source: A dict matching the user-facing schema, OR a path to a YAML/JSON
                file, OR a pathlib.Path.

    Returns:
        A list of internal PolicyRule objects ready for the evaluator.

    Raises:
        PolicyLoadError: file not found, parse error, or unsupported format.
        PolicyValidationError: schema invalid, with a list of bad fields.
    """
    if isinstance(source, dict):
        return _validate_and_translate(source, source_label="<dict>")

    if isinstance(source, (str, Path)):
        path = Path(source)
        return _load_from_file(path)

    raise PolicyLoadError(
        f"unsupported policy source type: {type(source).__name__}",
        source=str(source),
    )


def _load_from_file(path: Path) -> list[PolicyRule]:
    if not path.exists():
        raise PolicyLoadError(
            f"policy file not found: {path}",
            source=str(path),
        )

    suffix = path.suffix.lower()
    text = path.read_text(encoding="utf-8")

    if suffix in (".yaml", ".yml"):
        try:
            import yaml  # local import: pyyaml is a hard dep but only needed for files
        except ImportError as e:
            raise PolicyLoadError(
                "pyyaml is required to load YAML policy files. "
                "Install with: pip install controlzero[dev] or pip install pyyaml",
                source=str(path),
                cause=e,
            ) from e
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            raise PolicyLoadError(
                f"YAML parse error: {e}",
                source=str(path),
                cause=e,
            ) from e
    elif suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise PolicyLoadError(
                f"JSON parse error at line {e.lineno}, column {e.colno}: {e.msg}",
                source=str(path),
                cause=e,
            ) from e
    else:
        raise PolicyLoadError(
            f"unsupported file format: {suffix} (use .yaml, .yml, or .json)",
            source=str(path),
        )

    if data is None:
        raise PolicyValidationError(
            ["policy file is empty"],
            source=str(path),
        )
    if not isinstance(data, dict):
        raise PolicyValidationError(
            [f"policy root must be a mapping/object, got {type(data).__name__}"],
            source=str(path),
        )

    return _validate_and_translate(data, source_label=str(path))


def _validate_and_translate(data: dict, source_label: str) -> list[PolicyRule]:
    errors: list[str] = []

    version = data.get("version", "1")
    if version != "1":
        errors.append(f"unsupported version {version!r}, expected '1'")

    rules_raw = data.get("rules")
    if rules_raw is None:
        errors.append("missing required field 'rules'")
    elif not isinstance(rules_raw, list):
        errors.append(f"'rules' must be a list, got {type(rules_raw).__name__}")
    elif len(rules_raw) == 0:
        errors.append("'rules' must contain at least one rule")

    if errors:
        raise PolicyValidationError(errors, source=source_label)

    out: list[PolicyRule] = []
    for i, raw in enumerate(rules_raw):
        rule_errors = []
        if not isinstance(raw, dict):
            errors.append(f"rules[{i}]: must be a mapping, got {type(raw).__name__}")
            continue

        # Determine effect from the keys present
        has_deny = "deny" in raw
        has_allow = "allow" in raw
        explicit_effect = raw.get("effect")

        if explicit_effect:
            if explicit_effect not in ("allow", "deny", "warn", "audit"):
                rule_errors.append(
                    f"rules[{i}].effect: must be one of allow/deny/warn/audit, got {explicit_effect!r}"
                )
            effect = explicit_effect
            pattern = raw.get("action") or raw.get("actions")
        elif has_deny and has_allow:
            rule_errors.append(
                f"rules[{i}]: cannot set both 'deny' and 'allow' on the same rule"
            )
            effect = None
            pattern = None
        elif has_deny:
            effect = "deny"
            pattern = raw["deny"]
        elif has_allow:
            effect = "allow"
            pattern = raw["allow"]
        else:
            rule_errors.append(
                f"rules[{i}]: must specify one of 'deny', 'allow', or 'effect'"
            )
            effect = None
            pattern = None

        if effect and pattern is None:
            rule_errors.append(f"rules[{i}]: missing tool pattern")

        if rule_errors:
            errors.extend(rule_errors)
            continue

        # Normalize pattern to a list of canonical "tool:method" strings.
        # Friendly forms users write:
        #   "delete_*"           -> "delete_*:*"      (no colon = match any method)
        #   "github:list_*"      -> "github:list_*"   (already canonical)
        #   "*"                  -> "*"               (universal)
        # This translation lives ONLY here so the evaluator stays simple.
        if isinstance(pattern, str):
            raw_patterns = [pattern]
        elif isinstance(pattern, list):
            if not all(isinstance(p, str) for p in pattern):
                errors.append(f"rules[{i}]: pattern list must contain only strings")
                continue
            raw_patterns = pattern
        else:
            errors.append(f"rules[{i}]: pattern must be a string or list of strings")
            continue

        actions = [_canonicalize_action(p) for p in raw_patterns]

        # Normalize resource(s) to a list
        resources_raw = raw.get("resources") or raw.get("resource") or []
        if isinstance(resources_raw, str):
            resources = [resources_raw]
        elif isinstance(resources_raw, list):
            resources = list(resources_raw)
        else:
            errors.append(f"rules[{i}]: 'resources' must be a string or list")
            continue

        out.append(
            PolicyRule(
                id=str(raw.get("id", "")),
                name=str(raw.get("name", raw.get("id", f"rule-{i}"))),
                effect=effect,
                actions=actions,
                resources=resources,
                conditions=raw.get("when") or raw.get("conditions") or {},
                reason=str(raw.get("reason", "")),
            )
        )

    if errors:
        raise PolicyValidationError(errors, source=source_label)

    return out
