"""Local audit log sink built on loguru.

When the SDK runs without an API key, audit entries are written to a local file
with rotation. This module isolates the loguru config so the rest of the SDK
does not depend on loguru directly.

When an API key is set, this module is bypassed entirely and audit goes to the
remote forwarder. The user-supplied log_* options are ignored with a warning
(see Client.__init__).
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


class LocalAuditLogger:
    """Writes audit entries to a local rotated log file via loguru.

    Falls back to stderr if the configured log path is not writable.
    """

    def __init__(
        self,
        log_path: str = "./controlzero.log",
        rotation: str = "daily",
        retention: str = "30 days",
        compression: Optional[str] = None,
        log_format: str = "json",
    ):
        self._log_path = log_path
        self._rotation = rotation
        self._retention = retention
        self._compression = compression
        self._format = log_format
        self._logger = None
        self._sink_id: Optional[int] = None
        self._fallback = False
        # Per-instance component tag prevents cross-instance log duplication
        # when multiple Client objects exist in the same process. Each loguru
        # sink filters on its own component string.
        self._component = f"controlzero.audit.{id(self)}"
        self._setup()

    def _setup(self) -> None:
        try:
            from loguru import logger as _logger
        except ImportError:
            print(
                "controlzero: loguru not installed, audit logs will go to stderr.",
                file=sys.stderr,
            )
            self._fallback = True
            return

        path = Path(self._log_path)
        try:
            # Make sure the parent directory exists and is writable
            parent = path.parent
            if str(parent) and not parent.exists():
                parent.mkdir(parents=True, exist_ok=True)

            # Translate "daily" sugar to a loguru-friendly value
            rotation_value: Any = self._rotation
            if self._rotation == "daily":
                rotation_value = "00:00"

            self._logger = _logger.bind(component=self._component)
            # Add a dedicated sink filtered on this instance's component tag,
            # so each Client gets its own sink and lines never duplicate
            # across instances. Capture self._component in the lambda's
            # default arg to avoid late-binding issues.
            comp = self._component
            self._sink_id = _logger.add(
                str(path),
                rotation=rotation_value,
                retention=self._retention,
                compression=self._compression,
                serialize=False,  # we format ourselves
                format="{message}",
                filter=lambda record, c=comp: record["extra"].get("component") == c,
                enqueue=True,  # async-safe
            )
        except (OSError, PermissionError) as e:
            print(
                f"controlzero: cannot write to {self._log_path} ({e}), "
                "falling back to stderr.",
                file=sys.stderr,
            )
            self._fallback = True

    def log(self, entry: dict) -> None:
        """Write a single audit entry."""
        line = self._format_entry(entry)
        if self._fallback or self._logger is None:
            print(line, file=sys.stderr)
            return
        self._logger.info(line)

    def _format_entry(self, entry: dict) -> str:
        # Always include a timestamp in UTC ISO 8601
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            **entry,
        }
        if self._format == "pretty":
            # Compact human-readable form: ts | decision | tool | reason
            parts = [
                record.get("ts", ""),
                record.get("decision", "?"),
                record.get("tool", "?"),
                record.get("reason", ""),
            ]
            return " | ".join(str(p) for p in parts)
        return json.dumps(record, default=str)

    def close(self) -> None:
        if self._logger is not None and self._sink_id is not None:
            try:
                from loguru import logger as _logger
                _logger.remove(self._sink_id)
            except Exception:
                pass
            self._sink_id = None
