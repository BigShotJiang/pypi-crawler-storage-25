"""controlzero CLI: init, validate, test, tail.

This is the on-ramp for new users. `controlzero init` writes a sample policy
file with annotated examples; that file IS the tutorial.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path
from typing import Optional

import click
import yaml

from controlzero import Client, __version__
from controlzero.errors import PolicyLoadError, PolicyValidationError
from controlzero.policy_loader import load_policy
from controlzero.tamper import HashChain, load_or_create_secret, sign_bundle, verify_bundle

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEFAULT_TEMPLATES = [
    "generic",
    "rag",
    "mcp",
    "cost-cap",
    "claude-code",
    "langchain",
    "crewai",
    "cursor",
    "autogen",
]

# Where the global policy lives when controlzero is used as a Claude Code hook.
# Per-project ./controlzero.yaml takes precedence (the SDK already does this).
GLOBAL_POLICY_DIR = Path.home() / ".controlzero"
GLOBAL_POLICY_PATH = GLOBAL_POLICY_DIR / "policy.yaml"
GLOBAL_POLICY_SIG_PATH = GLOBAL_POLICY_DIR / "policy.yaml.sig"
GLOBAL_TAMPER_KEY_PATH = GLOBAL_POLICY_DIR / "tamper.key"
GLOBAL_AUDIT_PATH = GLOBAL_POLICY_DIR / "audit.log"


@click.group()
@click.version_option(__version__, prog_name="controlzero")
def cli():
    """ControlZero: AI agent governance, policies, and audit.

    Get started in 30 seconds:

      controlzero init           Write a sample policy.yaml
      controlzero validate       Lint your policy file
      controlzero test <tool>    Dry-run a tool call against the policy
      controlzero tail           Follow the local audit log
    """


@cli.command()
@click.option(
    "--template",
    "-t",
    type=click.Choice(DEFAULT_TEMPLATES),
    default="generic",
    help="Which template to write. 'generic' is a Hello World policy with comments.",
)
@click.option(
    "--out",
    "-o",
    type=click.Path(),
    default="controlzero.yaml",
    help="Output file path. Defaults to ./controlzero.yaml",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite the output file if it exists.",
)
def init(template: str, out: str, force: bool):
    """Write a sample policy file with examples and comments."""
    out_path = Path(out)
    if out_path.exists() and not force:
        click.echo(
            f"error: {out_path} already exists. Use --force to overwrite.",
            err=True,
        )
        sys.exit(1)

    src = TEMPLATE_DIR / f"{template}.yaml"
    if not src.exists():
        click.echo(f"error: template not found: {template}", err=True)
        sys.exit(1)

    out_path.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    click.echo(f"Wrote {out_path} ({template} template)")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  1. Open {out_path} and edit the rules to fit your app")
    click.echo(f"  2. Run: controlzero validate {out_path}")
    click.echo(f"  3. Test: controlzero test delete_file --policy {out_path}")
    click.echo(f"  4. Use it in code: Client(policy_file='{out_path}')")


@cli.command()
@click.argument("policy_file", type=click.Path(exists=True), default="controlzero.yaml")
def validate(policy_file: str):
    """Validate a policy file. Exits non-zero on errors."""
    try:
        rules = load_policy(policy_file)
    except (PolicyLoadError, PolicyValidationError) as e:
        click.echo(f"INVALID: {e}", err=True)
        sys.exit(1)
    click.echo(f"OK: {policy_file} parsed cleanly ({len(rules)} rules)")
    for r in rules:
        click.echo(f"  - {r.effect:5s} {r.actions} {'(' + r.id + ')' if r.id else ''}")


@cli.command()
@click.argument("tool")
@click.option("--method", "-m", default="*", help="Method name. Defaults to '*'.")
@click.option(
    "--policy",
    "-p",
    type=click.Path(exists=True),
    default="controlzero.yaml",
    help="Policy file to test against.",
)
@click.option("--args", "-a", default="{}", help="Tool args as a JSON string.")
def test(tool: str, method: str, policy: str, args: str):
    """Dry-run a single tool call against a policy file."""
    try:
        args_dict = json.loads(args)
    except json.JSONDecodeError as e:
        click.echo(f"error: --args is not valid JSON: {e}", err=True)
        sys.exit(2)

    try:
        cz = Client(policy_file=policy)
    except (PolicyLoadError, PolicyValidationError) as e:
        click.echo(f"error: {e}", err=True)
        sys.exit(1)

    decision = cz.guard(tool, args_dict, method=method)
    cz.close()

    color = "green" if decision.allowed else "red"
    click.echo(f"tool:    {tool}")
    click.echo(f"method:  {method}")
    click.echo(f"args:    {args_dict}")
    click.echo("")
    click.secho(f"DECISION: {decision.effect.upper()}", fg=color, bold=True)
    if decision.policy_id:
        click.echo(f"matched: {decision.policy_id}")
    if decision.reason:
        click.echo(f"reason:  {decision.reason}")
    sys.exit(0 if decision.allowed else 3)


@cli.command()
@click.option(
    "--log",
    "-l",
    type=click.Path(),
    default="./controlzero.log",
    help="Log file path.",
)
@click.option("--lines", "-n", default=10, help="Show the last N lines first.")
def tail(log: str, lines: int):
    """Follow the local audit log."""
    log_path = Path(log)
    if not log_path.exists():
        click.echo(f"error: log file not found: {log_path}", err=True)
        click.echo(
            "hint: run a Client.guard() call first, or pass --log to a different path.",
            err=True,
        )
        sys.exit(1)

    # Print last N lines
    text = log_path.read_text(encoding="utf-8")
    last_lines = text.splitlines()[-lines:]
    for line in last_lines:
        click.echo(line)

    # Then follow
    import time
    with log_path.open("r", encoding="utf-8") as f:
        f.seek(0, 2)  # seek to end
        try:
            while True:
                chunk = f.readline()
                if not chunk:
                    time.sleep(0.5)
                    continue
                click.echo(chunk.rstrip("\n"))
        except KeyboardInterrupt:
            click.echo("")  # newline after ^C


@cli.command("enroll")
@click.option("--token", required=True, help="Single-use enrollment token from the dashboard.")
@click.option(
    "--api-url",
    default="https://api.controlzero.ai",
    show_default=True,
    help="ControlZero API base URL.",
)
@click.option(
    "--user-email",
    default=None,
    help="Optional: associate the enrolled machine with a user email.",
)
def enroll_cmd(token: str, api_url: str, user_email):
    """Enroll this machine with a ControlZero org.

    Generates a fresh signing keypair, exchanges the enrollment token
    for a server-assigned machine_id, and persists the result to
    ~/.controlzero/. Subsequent calls (heartbeat, policy pull, audit)
    sign requests with the private key automatically.

    Re-running with the same machine fingerprint converges on the
    same machine_id (the backend dedups via UNIQUE(org, fingerprint)).

    Example:

      controlzero enroll --token cz_enroll_xxxxxxxx
      controlzero enroll --token cz_enroll_xxxxxxxx --api-url https://api.controlzero.ai
    """
    from controlzero.enrollment import EnrollmentError, TokenError, enroll

    try:
        state = enroll(api_url=api_url, token=token, user_email=user_email)
    except TokenError as e:
        click.echo(f"enrollment failed: token rejected: {e}", err=True)
        sys.exit(2)
    except EnrollmentError as e:
        click.echo(f"enrollment failed: {e}", err=True)
        sys.exit(1)

    click.echo("Enrolled successfully.")
    click.echo(f"  machine_id     : {state.machine_id}")
    click.echo(f"  org_id         : {state.org_id}")
    click.echo(f"  hostname       : {state.hostname}")
    click.echo(f"  fingerprint    : {state.fingerprint_hint}")
    click.echo(f"  policy_version : {state.policy_version}")
    click.echo("")
    click.echo("State persisted to ~/.controlzero/enrollment.json")
    click.echo("Private key persisted to ~/.controlzero/machine.key (mode 0600)")


@cli.command("heartbeat")
def heartbeat_cmd():
    """Send a single signed heartbeat to the backend.

    Useful for verifying enrollment end-to-end. In normal operation
    a long-running daemon sends heartbeats every 5 minutes.
    """
    from controlzero.enrollment import (
        EnrollmentError,
        NotEnrolledError,
        heartbeat,
        load_state,
    )

    state = load_state()
    if state is None:
        click.echo("not enrolled. Run `controlzero enroll --token <TOKEN>` first.", err=True)
        sys.exit(1)

    try:
        resp = heartbeat(state)
    except NotEnrolledError as e:
        click.echo(f"heartbeat failed: {e}", err=True)
        sys.exit(1)
    except EnrollmentError as e:
        click.echo(f"heartbeat failed: {e}", err=True)
        sys.exit(2)

    click.echo("Heartbeat OK.")
    click.echo(f"  server_time    : {resp.get('server_time', 'unknown')}")
    click.echo(f"  policy_version : {resp.get('policy_version', 0)}")


@cli.command("policy-pull")
def policy_pull_cmd():
    """Pull the latest policy bundle from the backend.

    Uses If-None-Match with the locally cached policy_version. If the
    server returns 304 Not Modified, the local cache is already
    current and nothing is downloaded.
    """
    from controlzero.enrollment import (
        EnrollmentError,
        NotEnrolledError,
        load_state,
        pull_policy,
    )

    state = load_state()
    if state is None:
        click.echo("not enrolled. Run `controlzero enroll --token <TOKEN>` first.", err=True)
        sys.exit(1)

    try:
        bundle = pull_policy(state)
    except NotEnrolledError as e:
        click.echo(f"pull failed: {e}", err=True)
        sys.exit(1)
    except EnrollmentError as e:
        click.echo(f"pull failed: {e}", err=True)
        sys.exit(2)

    if bundle is None:
        click.echo(f"Policy is up to date (version {state.policy_version}).")
        return

    click.echo(f"Pulled policy version {bundle.get('policy_version', 0)}.")
    rules = bundle.get("rules", [])
    click.echo(f"  rules: {len(rules)}")
    for rule in rules[:10]:
        click.echo(f"    - {rule.get('name')} ({rule.get('action')}, scopes={rule.get('scopes')})")
    if len(rules) > 10:
        click.echo(f"    ... and {len(rules) - 10} more")


@cli.command("hook-check")
@click.option(
    "--policy",
    "-p",
    type=click.Path(),
    default=None,
    help="Policy file. Defaults to ./controlzero.yaml then ~/.controlzero/policy.yaml",
)
def hook_check(policy: Optional[str]):
    """Read a tool call from stdin (Claude Code hook protocol) and decide.

    Reads JSON from stdin with at minimum {"tool_name": "...", "tool_input": {...}}.
    Evaluates against the resolved policy. On allow exits 0. On deny exits 2 with
    a JSON block decision on stdout.

    Designed for Claude Code's PreToolUse hook system. Other agents that send a
    similar JSON-on-stdin protocol can reuse this command.
    """
    # Read stdin -- Claude Code passes the tool payload here
    try:
        raw = sys.stdin.read()
    except (KeyboardInterrupt, EOFError):
        # No payload: pass through (do not break the agent)
        sys.exit(0)

    if not raw.strip():
        # Empty stdin: pass through
        sys.exit(0)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        # Malformed payload: log to stderr and pass through. Never brick the agent.
        click.echo(f"controlzero: hook payload is not JSON ({e}); allowing", err=True)
        sys.exit(0)

    tool_name = payload.get("tool_name") or payload.get("toolName") or ""
    tool_args = payload.get("tool_input") or payload.get("toolInput") or {}
    if not tool_name:
        click.echo("controlzero: hook payload missing tool_name; allowing", err=True)
        sys.exit(0)

    # Resolve policy file
    policy_path = _resolve_hook_policy(policy)

    # Freshness check: if this machine is enrolled and the policy file is
    # stale, attempt a quick background sync from the backend. This is a
    # no-op for local-only (unenrolled) machines.
    if policy_path is not None:
        _maybe_refresh_policy(policy_path)
    elif policy is None:
        # Policy not found yet -- maybe a sync will create it.
        _maybe_refresh_policy(GLOBAL_POLICY_PATH)
        # Re-resolve after potential sync.
        policy_path = _resolve_hook_policy(policy)

    if policy_path is None:
        # No policy installed: warn once, allow. Never brick the agent.
        click.echo(
            "controlzero: no policy file found at ./controlzero.yaml or "
            f"{GLOBAL_POLICY_PATH}; allowing. Run `controlzero install claude-code` to set one up.",
            err=True,
        )
        sys.exit(0)

    # --- Load API key from config.yaml if not in environment ---
    if not os.environ.get("CONTROLZERO_API_KEY"):
        config_path = GLOBAL_POLICY_DIR / "config.yaml"
        if config_path.exists():
            try:
                config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                if config and config.get("api_key"):
                    os.environ["CONTROLZERO_API_KEY"] = config["api_key"]
            except Exception:
                pass

    # --- Tamper detection: policy file HMAC check ---
    tamper_detected = False
    tamper_detected = _check_policy_tamper(policy_path)

    # --- Tamper detection: audit log hash chain check ---
    audit_chain_broken = _check_audit_chain()

    try:
        cz = Client(
            policy_file=str(policy_path),
            log_path=str(GLOBAL_AUDIT_PATH),
        )
    except (PolicyLoadError, PolicyValidationError) as e:
        # Bad policy file: log + allow (do not silently break the agent)
        click.echo(f"controlzero: policy file invalid ({e}); allowing", err=True)
        sys.exit(0)

    decision = cz.guard(
        tool_name,
        args=tool_args if isinstance(tool_args, dict) else {},
        context={
            "tamper_detected": tamper_detected,
            "audit_chain_broken": audit_chain_broken,
        },
    )
    cz.close()

    if decision.denied:
        # Claude Code reads stdout for the model-facing reason
        click.echo(
            json.dumps(
                {
                    "decision": "block",
                    "reason": decision.reason or "Blocked by Control Zero policy",
                    "tamper_detected": tamper_detected,
                    "audit_chain_broken": audit_chain_broken,
                }
            )
        )
        sys.exit(2)

    sys.exit(0)


def _check_policy_tamper(policy_path: Path) -> bool:
    """Check policy file integrity against its HMAC signature file.

    Returns True if tamper is detected. Returns False if the signature
    file does not exist (backwards compatible) or if verification passes.
    Never raises; logs warnings to stderr on tamper detection.
    """
    # Determine sig path: sibling of the policy file with .sig appended
    sig_path = policy_path.with_suffix(policy_path.suffix + ".sig")
    if not sig_path.exists():
        # No signature file: skip check (backwards compatible)
        return False

    try:
        key_path = policy_path.parent / "tamper.key"
        if not key_path.exists():
            # No tamper key but sig file exists: suspicious but not conclusive
            click.echo(
                "controlzero: policy signature file exists but tamper key is missing; "
                "skipping tamper check",
                err=True,
            )
            return False
        secret = load_or_create_secret(key_path)
        policy_content = policy_path.read_bytes()
        signature = sig_path.read_text(encoding="utf-8").strip()
        if not verify_bundle(policy_content, signature, secret):
            click.echo(
                "controlzero: policy file tamper detected (HMAC mismatch); "
                "allowing but flagging",
                err=True,
            )
            return True
    except Exception as e:
        # Any error in tamper checking: log and continue (fail-open for CLI)
        click.echo(
            f"controlzero: tamper check error ({e}); skipping",
            err=True,
        )
    return False


def _check_audit_chain() -> bool:
    """Verify the audit log hash chain integrity.

    Returns True if the chain is broken. Returns False if the audit log
    does not exist, has no entries, or the chain is intact.
    Never raises; logs warnings to stderr on chain breakage.
    """
    if not GLOBAL_AUDIT_PATH.exists():
        return False

    try:
        text = GLOBAL_AUDIT_PATH.read_text(encoding="utf-8").strip()
        if not text:
            return False

        entries = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                # Only check entries that have hash chain fields
                if "entry_hash" in entry and "prev_hash" in entry:
                    entries.append(entry)
            except json.JSONDecodeError:
                continue

        if not entries:
            return False

        chain = HashChain(GLOBAL_AUDIT_PATH)
        ok, bad_idx = chain.verify(entries)
        if not ok:
            click.echo(
                f"controlzero: audit log hash chain broken at entry {bad_idx}; "
                "allowing but flagging",
                err=True,
            )
            return True
    except Exception as e:
        click.echo(
            f"controlzero: audit chain check error ({e}); skipping",
            err=True,
        )
    return False


# -- Policy freshness check for enrolled machines -------------------------
# Staleness threshold in seconds. If the global policy file is older than
# this, hook-check will attempt a background pull_policy() call.
POLICY_STALENESS_THRESHOLD_S = 300  # 5 minutes
# Maximum time to wait for the network sync before falling back to the
# cached policy. Keeps the agent snappy.
POLICY_SYNC_TIMEOUT_S = 2.0


def _is_policy_stale(policy_path: Path, threshold_s: float = POLICY_STALENESS_THRESHOLD_S) -> bool:
    """Return True if *policy_path* mtime is older than *threshold_s* seconds."""
    try:
        mtime = os.path.getmtime(policy_path)
        return (time.time() - mtime) > threshold_s
    except OSError:
        # File missing or inaccessible: treat as stale so we try to pull.
        return True


def _load_enrollment_state(state_dir: Path = GLOBAL_POLICY_DIR) -> Optional[object]:
    """Load the enrollment state from disk, returning None on any error.

    This is a fail-open helper: if enrollment.json is missing, malformed,
    or missing required fields, we return None so the caller skips the
    sync and proceeds with local-only mode.
    """
    try:
        from controlzero.enrollment import load_state
        state = load_state(state_dir)
        if state is None:
            return None
        # Validate that the required fields are present and non-empty.
        if not state.org_id or not state.api_url:
            return None
        return state
    except Exception:
        return None


def _do_pull_and_write(state: object, policy_path: Path, state_dir: Path, result: dict) -> None:
    """Worker target: pull policy from backend and write to disk.

    Writes results into *result* dict so the caller can inspect what
    happened. Keys: 'refreshed' (bool), 'error' (str or None).
    """
    try:
        from controlzero.enrollment import pull_policy
        bundle = pull_policy(state, state_dir=state_dir, timeout_s=POLICY_SYNC_TIMEOUT_S)
        if bundle is None:
            # 304 Not Modified: touch the file so mtime is refreshed.
            try:
                policy_path.touch()
            except OSError:
                pass
            result["refreshed"] = True
            result["error"] = None
            return
        # Write the bundle rules as YAML to the policy file.
        yaml_content = yaml.safe_dump(
            {
                "version": str(bundle.get("version", "1")),
                "rules": bundle.get("rules", []),
            },
            default_flow_style=False,
            allow_unicode=True,
        )
        # Atomic write: tmp + rename
        tmp = policy_path.with_suffix(".yaml.tmp")
        tmp.write_text(yaml_content, encoding="utf-8")
        tmp.replace(policy_path)
        result["refreshed"] = True
        result["error"] = None
    except Exception as exc:
        result["refreshed"] = False
        result["error"] = str(exc)


def _maybe_refresh_policy(
    policy_path: Path,
    state_dir: Path = GLOBAL_POLICY_DIR,
    threshold_s: float = POLICY_STALENESS_THRESHOLD_S,
    timeout_s: float = POLICY_SYNC_TIMEOUT_S,
) -> None:
    """If the machine is enrolled and the policy is stale, attempt a sync.

    Uses a background thread with a join timeout so the hook never stalls
    for longer than *timeout_s* seconds. On timeout or network failure,
    falls back to the cached policy and logs a warning to stderr.

    No-op when:
    - enrollment.json does not exist (local-only mode)
    - enrollment.json is malformed or missing required fields
    - The policy file is fresh (mtime within threshold)
    """
    state = _load_enrollment_state(state_dir)
    if state is None:
        return

    if not _is_policy_stale(policy_path, threshold_s):
        return

    # Compute staleness for the warning message.
    try:
        age_min = int((time.time() - os.path.getmtime(policy_path)) / 60)
    except OSError:
        age_min = -1

    result: dict = {"refreshed": False, "error": None}
    worker = threading.Thread(
        target=_do_pull_and_write,
        args=(state, policy_path, state_dir, result),
        daemon=True,
    )
    worker.start()
    worker.join(timeout=timeout_s)

    if worker.is_alive():
        # Thread is still running (network slow). Warn and proceed.
        msg = "controlzero: policy sync timed out"
        if age_min >= 0:
            msg += f" (last sync {age_min} min ago)"
        msg += "; using cached version."
        click.echo(msg, err=True)
        return

    if not result["refreshed"] and result["error"]:
        msg = "controlzero: policy stale"
        if age_min >= 0:
            msg += f" (last sync {age_min} min ago)"
        msg += "; using cached version."
        click.echo(msg, err=True)


def _resolve_hook_policy(explicit: Optional[str]) -> Optional[Path]:
    """Find a policy file using the hook-time resolution order:

    1. Explicit --policy argument
    2. ./controlzero.yaml (per-project)
    3. ~/.controlzero/policy.yaml (global)
    """
    if explicit:
        p = Path(explicit)
        return p if p.exists() else None
    cwd = Path.cwd() / "controlzero.yaml"
    if cwd.exists():
        return cwd
    if GLOBAL_POLICY_PATH.exists():
        return GLOBAL_POLICY_PATH
    return None


def _policy_has_deny_rules(policy_path: Path) -> bool:
    """Check whether an existing policy file contains any active deny rules.

    Returns True if at least one uncommented deny rule exists. Returns False
    if the policy only has allow rules (or is empty/unparseable).
    """
    try:
        text = policy_path.read_text(encoding="utf-8")
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            return False
        rules = data.get("rules", [])
        if not isinstance(rules, list):
            return False
        for rule in rules:
            if isinstance(rule, dict) and "deny" in rule:
                return True
        return False
    except Exception:
        return False


def _extract_template_deny_comments(template_path: Path) -> list[str]:
    """Extract commented-out deny rule blocks from a template file.

    Returns a list of comment lines (including the '#') that contain deny
    examples. These are the lines the user WOULD get if they used --force.
    """
    lines = template_path.read_text(encoding="utf-8").splitlines()
    deny_lines: list[str] = []
    in_deny_block = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") and "deny:" in stripped:
            in_deny_block = True
            deny_lines.append(line)
        elif in_deny_block and stripped.startswith("#") and stripped != "#":
            deny_lines.append(line)
        else:
            in_deny_block = False
    return deny_lines


def _merge_template_deny_rules(existing_path: Path, template_path: Path) -> str:
    """Merge deny rule examples from a template into an existing policy file.

    Inserts the template's commented-out deny rules just BEFORE the final
    allow-everything rule. Returns the merged text. Does not write to disk.
    """
    existing_text = existing_path.read_text(encoding="utf-8")
    template_text = template_path.read_text(encoding="utf-8")

    # Extract commented deny blocks from the template
    template_lines = template_text.splitlines()
    deny_sections: list[str] = []
    i = 0
    while i < len(template_lines):
        line = template_lines[i]
        stripped = line.strip()
        # Look for comment blocks that contain deny examples
        if stripped.startswith("#") and "DENY:" in stripped:
            section_lines = [line]
            i += 1
            while i < len(template_lines):
                next_line = template_lines[i]
                next_stripped = next_line.strip()
                # Section ends at the next section header or a non-comment active rule
                if next_stripped.startswith("# ==") and "ALLOW:" in next_stripped:
                    break
                if next_stripped and not next_stripped.startswith("#") and not next_stripped.startswith("-"):
                    break
                section_lines.append(next_line)
                i += 1
            section_text = "\n".join(section_lines)
            if "deny:" in section_text.lower():
                deny_sections.append(section_text)
            continue
        i += 1

    if not deny_sections:
        return existing_text

    # Find the allow-everything rule and insert before it
    existing_lines = existing_text.splitlines()
    insert_idx = None
    for idx, line in enumerate(existing_lines):
        stripped = line.strip()
        if "allow-everything" in stripped or (
            stripped.startswith("- id:") and "allow" in stripped.lower()
        ):
            insert_idx = idx
            break
        # Also catch bare allow rules that are the last rule
        if stripped == "- allow: '*'" or stripped == '- allow: "*"':
            insert_idx = idx
            break

    if insert_idx is None:
        # No allow-everything found; append at end
        insert_idx = len(existing_lines)

    merged_block = "\n".join(deny_sections)
    merged_lines = (
        existing_lines[:insert_idx]
        + ["", merged_block, ""]
        + existing_lines[insert_idx:]
    )
    return "\n".join(merged_lines) + "\n"


def _warn_no_deny_rules(agent_name: str, template_path: Path) -> None:
    """Emit a loud warning that the existing policy has no deny rules.

    Also shows what deny rules the template WOULD have added.
    """
    click.secho(
        f"WARNING: Your existing policy at {GLOBAL_POLICY_PATH} has NO deny rules.",
        fg="yellow",
        bold=True,
        err=True,
    )
    click.secho(
        f"The {agent_name} hook will ALLOW ALL tool calls. "
        "This may not be what you want.",
        fg="yellow",
        err=True,
    )
    click.echo("", err=True)
    click.echo(
        f"Options:",
        err=True,
    )
    click.echo(
        f"  --force    Overwrite with the {agent_name} template",
        err=True,
    )
    click.echo(
        f"  --merge    Add the {agent_name} template's deny rules to your existing policy",
        err=True,
    )
    click.echo(
        f"  manual     Edit {GLOBAL_POLICY_PATH} and add deny rules yourself",
        err=True,
    )

    # Show what deny rules the template has (commented out)
    deny_comments = _extract_template_deny_comments(template_path)
    if deny_comments:
        click.echo("", err=True)
        click.echo(
            f"The {agent_name} template includes these deny examples:",
            err=True,
        )
        for line in deny_comments[:10]:
            click.echo(f"  {line}", err=True)


GLOBAL_CONFIG_PATH = GLOBAL_POLICY_DIR / "config.yaml"


def _validate_api_key(api_key: str) -> bool:
    """Return True if the API key has a valid cz_live_ or cz_test_ prefix."""
    return api_key.startswith("cz_live_") or api_key.startswith("cz_test_")


def _write_api_key_config(api_key: str) -> None:
    """Write the API key to ~/.controlzero/config.yaml."""
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    config_data: dict = {}
    if GLOBAL_CONFIG_PATH.exists():
        try:
            existing = yaml.safe_load(GLOBAL_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(existing, dict):
                config_data = existing
        except Exception:
            pass
    config_data["api_key"] = api_key
    GLOBAL_CONFIG_PATH.write_text(
        yaml.safe_dump(config_data, default_flow_style=False),
        encoding="utf-8",
    )


def _print_api_key_status(api_key: Optional[str]) -> None:
    """Print API key configuration status after install."""
    if api_key:
        click.echo("")
        click.echo("API key configured. Audit logs will sync to the Control Zero dashboard.")
        click.echo("View them at: https://app.controlzero.ai/audit")
    else:
        click.echo("")
        click.echo("Tip: Pass --api-key cz_live_xxx to sync audit logs to the dashboard.")


@cli.group()
def install():
    """Install controlzero into a coding agent (Claude Code, Cursor, etc)."""


@install.command("claude-code")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file if present.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Claude Code settings.json. Defaults to ~/.claude/settings.json",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_claude_code(force: bool, merge: bool, settings: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Claude Code PreToolUse hook.

    Writes ~/.controlzero/policy.yaml from the claude-code template (idempotent
    unless --force is set) and merges a hook block into ~/.claude/settings.json.
    Existing hooks are preserved.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)

    template_path = TEMPLATE_DIR / "claude-code.yaml"
    if not template_path.exists():
        click.echo(f"error: claude-code template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            # Merge template deny rules into existing policy
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from claude-code template into {GLOBAL_POLICY_PATH}"
            )
        else:
            # Check if existing policy has deny rules; warn loudly if not
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("claude-code", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (claude-code template)")

    # Step 2: merge into Claude Code settings.json
    settings_path = Path(settings) if settings else Path.home() / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            click.echo(
                f"error: {settings_path} is not valid JSON ({e}). "
                "Fix it manually or move it aside, then re-run.",
                err=True,
            )
            sys.exit(1)

    hooks = existing.setdefault("hooks", {})
    pre_tool = hooks.setdefault("PreToolUse", [])

    # Idempotency: replace any existing controlzero hook block, preserve others
    hook_command = "controlzero hook-check"
    if api_key:
        hook_command = f"CONTROLZERO_API_KEY={api_key} controlzero hook-check"
    new_block = {
        "matcher": "*",
        "hooks": [
            {
                "type": "command",
                "command": hook_command,
                "timeout": 5000,
            }
        ],
    }
    pre_tool[:] = [
        b for b in pre_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict)
                and isinstance(h.get("command"), str)
                and "controlzero hook-check" in h.get("command", "")
                for h in b.get("hooks", [])
            )
        )
    ]
    pre_tool.append(new_block)

    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(f"Updated {settings_path} (added PreToolUse hook)")
    click.echo("")
    click.echo("Done. Test it:")
    click.echo("  1. Open Claude Code in any project")
    click.echo("  2. Ask Claude to run: rm -rf /tmp/test")
    click.echo("  3. Watch the request get blocked by your policy")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# install gemini-cli
# =============================================================================
#
# Gemini CLI stores user-level config under ~/.gemini/settings.json. The
# pre-tool-call hook contract is modeled on Claude Code's: a command
# that receives the tool call on stdin and returns 0 to allow or
# non-zero to deny. We merge a `BeforeTool.hooks` entry so existing
# hooks are preserved.
#
# Ref: Gemini CLI settings.json schema (as of gemini-cli 0.5.x).

@install.command("gemini-cli")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file if present.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Gemini CLI settings.json. Defaults to ~/.gemini/settings.json",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_gemini_cli(force: bool, merge: bool, settings: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Gemini CLI pre-tool-call hook.

    Writes ~/.controlzero/policy.yaml from the gemini-cli template
    (idempotent unless --force is set) and merges a hook block into
    ~/.gemini/settings.json. Existing hooks are preserved.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)

    template_path = TEMPLATE_DIR / "gemini-cli.yaml"
    if not template_path.exists():
        click.echo(f"error: gemini-cli template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from gemini-cli template into {GLOBAL_POLICY_PATH}"
            )
        else:
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("gemini-cli", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (gemini-cli template)")

    # Step 2: merge into Gemini CLI settings.json
    settings_path = Path(settings) if settings else Path.home() / ".gemini" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            click.echo(
                f"error: {settings_path} is not valid JSON ({e}). "
                "Fix it manually or move it aside, then re-run.",
                err=True,
            )
            sys.exit(1)

    hooks_root = existing.setdefault("hooks", {})
    pre_call = hooks_root.setdefault("BeforeTool", [])

    hook_command = "controlzero hook-check"
    if api_key:
        hook_command = f"CONTROLZERO_API_KEY={api_key} controlzero hook-check"
    new_block = {
        "matcher": "*",
        "command": hook_command,
        "timeout_ms": 5000,
    }
    # Idempotency: replace any existing controlzero hook block.
    pre_call[:] = [
        b
        for b in pre_call
        if not (
            isinstance(b, dict)
            and isinstance(b.get("command"), str)
            and "controlzero hook-check" in b.get("command", "")
        )
    ]
    pre_call.append(new_block)

    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(f"Updated {settings_path} (added BeforeTool hook)")
    click.echo("")
    click.echo("Done. Test it:")
    click.echo("  1. Open Gemini CLI in any project: gemini")
    click.echo("  2. Ask Gemini to run a shell command you have denied")
    click.echo("  3. Watch the request get blocked by your policy")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# install codex-cli
# =============================================================================
#
# Codex CLI (OpenAI) stores config under ~/.codex/config.toml. Codex
# does not expose a first-class hook API (as of 0.3.x), so we ship a
# small wrapper script that intercepts tool calls via the
# `tool_approval_policy` extension point: Codex calls out to an
# external reviewer command, gets JSON back, decides.
#
# Install writes:
#   ~/.controlzero/policy.yaml
#   ~/.codex/hooks/controlzero.sh     (wrapper that invokes hook-check)
#   appends a tool_approval_policy block to ~/.codex/config.toml
#
# If the user's config.toml already has a controlzero approval policy,
# it's left untouched (idempotent). The wrapper script is always
# rewritten so upgrades flow automatically.

@install.command("codex-cli")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file and config.toml block.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--config",
    type=click.Path(),
    default=None,
    help="Path to Codex CLI config.toml. Defaults to ~/.codex/config.toml",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_codex_cli(force: bool, merge: bool, config: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Codex CLI tool approval hook.

    Writes ~/.controlzero/policy.yaml from the codex-cli template
    (idempotent unless --force is set), drops a wrapper script at
    ~/.codex/hooks/controlzero.sh, and appends a
    `[tool_approval_policy]` block to ~/.codex/config.toml pointing at
    the wrapper.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)

    template_path = TEMPLATE_DIR / "codex-cli.yaml"
    if not template_path.exists():
        click.echo(f"error: codex-cli template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from codex-cli template into {GLOBAL_POLICY_PATH}"
            )
        else:
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("codex-cli", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (codex-cli template)")

    # Step 2: drop the wrapper shim. Always rewrites so upgrades flow.
    codex_dir = Path.home() / ".codex"
    hooks_dir = codex_dir / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    wrapper = hooks_dir / "controlzero.sh"
    exec_line = "exec controlzero hook-check\n"
    if api_key:
        exec_line = f"exec env CONTROLZERO_API_KEY={api_key} controlzero hook-check\n"
    wrapper.write_text(
        "#!/usr/bin/env bash\n"
        "# Auto-generated by `controlzero install codex-cli`. Do not edit.\n"
        "# Codex CLI calls this wrapper with the tool call JSON on stdin;\n"
        "# we forward it to `controlzero hook-check` and propagate the\n"
        "# exit code. Exit 0 = allow, non-zero = deny.\n"
        + exec_line,
        encoding="utf-8",
    )
    wrapper.chmod(0o755)
    click.echo(f"Wrote {wrapper} (codex approval hook wrapper)")

    # Step 3: merge a tool_approval_policy block into config.toml. We
    # do a string-level append rather than parse+rewrite because the
    # stdlib has no TOML writer (only a reader in Python 3.11+) and
    # introducing tomlkit as a new runtime dep for a shim is overkill.
    cfg_path = Path(config) if config else codex_dir / "config.toml"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    existing_text = cfg_path.read_text(encoding="utf-8") if cfg_path.exists() else ""
    marker = "# controlzero:tool_approval_policy"
    block = (
        f"\n{marker}\n"
        "[tool_approval_policy]\n"
        f'command = "{wrapper}"\n'
        'mode = "stdin_json"\n'
        "timeout_ms = 5000\n"
    )
    if marker in existing_text:
        if force:
            # Strip the old block (between marker and the next blank line).
            lines = existing_text.splitlines(keepends=True)
            out: list = []
            skip = False
            for line in lines:
                if line.strip() == marker:
                    skip = True
                    continue
                if skip and line.strip() == "":
                    skip = False
                    continue
                if not skip:
                    out.append(line)
            existing_text = "".join(out)
            click.echo("Removed existing controlzero block from config.toml (--force)")
        else:
            click.echo(
                f"Skipping config.toml merge: controlzero block already present "
                "(use --force to rewrite)."
            )
            click.echo("")
            click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
            click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
            return
    cfg_path.write_text(existing_text + block, encoding="utf-8")
    click.echo(f"Updated {cfg_path} (added [tool_approval_policy] block)")
    click.echo("")
    click.echo("Done. Test it:")
    click.echo("  1. Open Codex CLI in any project: codex")
    click.echo("  2. Ask Codex to run a shell command you have denied")
    click.echo("  3. Watch the request get blocked by your policy")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# uninstall command group
# =============================================================================


@cli.group()
def uninstall():
    """Remove controlzero hooks from a coding agent."""


@uninstall.command("claude-code")
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Claude Code settings.json. Defaults to ~/.claude/settings.json",
)
def uninstall_claude_code(settings: Optional[str]):
    """Remove the controlzero PreToolUse hook from Claude Code.

    Reads ~/.claude/settings.json (or --settings), removes any PreToolUse
    hook block where the command is 'controlzero hook-check', and writes
    the cleaned JSON back. Policy and audit log files are preserved.
    """
    settings_path = Path(settings) if settings else Path.home() / ".claude" / "settings.json"

    if not settings_path.exists():
        click.echo("No controlzero hook found in Claude Code.")
        sys.exit(0)

    try:
        existing = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        click.echo(
            f"error: {settings_path} is not valid JSON ({e}). "
            "Fix it manually or move it aside, then re-run.",
            err=True,
        )
        sys.exit(1)

    hooks = existing.get("hooks", {})
    pre_tool = hooks.get("PreToolUse", [])

    original_count = len(pre_tool)
    cleaned = [
        b for b in pre_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict)
                and isinstance(h.get("command"), str)
                and "controlzero hook-check" in h.get("command", "")
                for h in b.get("hooks", [])
            )
        )
    ]

    if len(cleaned) == original_count:
        click.echo("No controlzero hook found in Claude Code.")
        sys.exit(0)

    hooks["PreToolUse"] = cleaned
    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(
        "Removed controlzero hook from Claude Code. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


@uninstall.command("gemini-cli")
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Gemini CLI settings.json. Defaults to ~/.gemini/settings.json",
)
def uninstall_gemini_cli(settings: Optional[str]):
    """Remove the controlzero BeforeTool hook from Gemini CLI.

    Reads ~/.gemini/settings.json (or --settings), removes any BeforeTool
    entry where the command is 'controlzero hook-check', and writes the
    cleaned JSON back. Policy and audit log files are preserved.
    """
    settings_path = Path(settings) if settings else Path.home() / ".gemini" / "settings.json"

    if not settings_path.exists():
        click.echo("No controlzero hook found in Gemini CLI.")
        sys.exit(0)

    try:
        existing = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        click.echo(
            f"error: {settings_path} is not valid JSON ({e}). "
            "Fix it manually or move it aside, then re-run.",
            err=True,
        )
        sys.exit(1)

    hooks_root = existing.get("hooks", {})
    pre_call = hooks_root.get("BeforeTool", [])

    original_count = len(pre_call)
    cleaned = [
        b for b in pre_call
        if not (
            isinstance(b, dict)
            and isinstance(b.get("command"), str)
            and "controlzero hook-check" in b.get("command", "")
        )
    ]

    if len(cleaned) == original_count:
        click.echo("No controlzero hook found in Gemini CLI.")
        sys.exit(0)

    hooks_root["BeforeTool"] = cleaned
    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(
        "Removed controlzero hook from Gemini CLI. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


@uninstall.command("codex-cli")
@click.option(
    "--config",
    type=click.Path(),
    default=None,
    help="Path to Codex CLI config.toml. Defaults to ~/.codex/config.toml",
)
def uninstall_codex_cli(config: Optional[str]):
    """Remove the controlzero tool_approval_policy from Codex CLI.

    Reads ~/.codex/config.toml (or --config), removes the
    '# controlzero:tool_approval_policy' marker block, deletes the
    wrapper script at ~/.codex/hooks/controlzero.sh, and writes the
    cleaned TOML back. Policy and audit log files are preserved.
    """
    codex_dir = Path.home() / ".codex"
    cfg_path = Path(config) if config else codex_dir / "config.toml"
    wrapper = codex_dir / "hooks" / "controlzero.sh"
    marker = "# controlzero:tool_approval_policy"

    found_anything = False

    # Remove wrapper script if it exists
    if wrapper.exists():
        wrapper.unlink()
        found_anything = True

    # Remove marker block from config.toml
    if cfg_path.exists():
        existing_text = cfg_path.read_text(encoding="utf-8")
        if marker in existing_text:
            lines = existing_text.splitlines(keepends=True)
            out: list = []
            skip = False
            for line in lines:
                if line.strip() == marker:
                    skip = True
                    continue
                if skip and line.strip() == "":
                    skip = False
                    continue
                if not skip:
                    out.append(line)
            cfg_path.write_text("".join(out), encoding="utf-8")
            found_anything = True

    if not found_anything:
        click.echo("No controlzero hook found in Codex CLI.")
        sys.exit(0)

    click.echo(
        "Removed controlzero hook from Codex CLI. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


if __name__ == "__main__":
    cli()
