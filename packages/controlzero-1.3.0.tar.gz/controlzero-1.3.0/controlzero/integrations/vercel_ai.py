"""Vercel AI SDK integration for ControlZero.

Provides ``ControlZeroVercelAIMiddleware`` which adds governance to
Vercel AI SDK function calls (generateText, streamText) by intercepting
the model invocation layer.

Usage::

    from controlzero import Client
    from controlzero.integrations.vercel_ai import ControlZeroVercelAIMiddleware

    cz = Client(policy={"rules": [{"allow": "*"}]})

    middleware = ControlZeroVercelAIMiddleware(cz)
    # Use middleware.before_call() and middleware.after_call() hooks
    # in your Vercel AI SDK pipeline
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


class ControlZeroVercelAIMiddleware:
    """Middleware that integrates ControlZero governance with Vercel AI SDK.

    Provides before/after hooks for AI SDK function calls (generateText,
    streamText, generateObject) to enforce policies and log actions.
    """

    def __init__(
        self,
        client: Client,
        agent_id: str = "vercel-ai",
    ) -> None:
        self._client = client
        self._agent_id = agent_id

    def before_call(
        self,
        model: str,
        action: str = "chat",
        context: Optional[dict] = None,
    ) -> dict:
        """Run policy check before an AI SDK call.

        Args:
            model: The model identifier (e.g., "anthropic/claude-sonnet-4.6")
            action: The action type (e.g., "chat", "generate", "stream")
            context: Optional context for policy evaluation

        Returns:
            A dict with the policy decision metadata

        Raises:
            PolicyDeniedError: If the policy denies the action
        """
        start = time.monotonic()
        merged_context = context or {}
        merged_context["resource"] = f"model/{model}"
        merged_context["agent_id"] = self._agent_id

        decision = self._client.guard(
            tool="llm:vercel-ai",
            method=action,
            raise_on_deny=True,
            context=merged_context,
        )
        latency_ms = (time.monotonic() - start) * 1000

        return {
            "allowed": True,
            "model": model,
            "latency_ms": round(latency_ms, 2),
            "decision": decision,
        }

    def after_call(
        self,
        model: str,
        action: str = "chat",
        input_tokens: int = 0,
        output_tokens: int = 0,
        duration_ms: float = 0,
    ) -> None:
        """Log metrics after a successful AI SDK call.

        Args:
            model: The model identifier
            action: The action type
            input_tokens: Token count from the response
            output_tokens: Token count from the response
            duration_ms: Total call duration in milliseconds
        """
        try:
            decision = PolicyDecision(effect="allow", reason="post-call audit")
            self._client._audit_decision(
                tool="llm:vercel-ai",
                method=action,
                args={
                    "model": model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "duration_ms": round(duration_ms, 2),
                    "agent_id": self._agent_id,
                },
                decision=decision,
            )
        except Exception:
            pass

    def wrap_generate(self, generate_fn: Callable) -> Callable:
        """Wrap a Vercel AI SDK generate function with governance.

        Args:
            generate_fn: The AI SDK function (e.g., generateText)

        Returns:
            A wrapped function that enforces policies
        """
        middleware = self

        async def governed_generate(*args: Any, **kwargs: Any) -> Any:
            model = kwargs.get("model", str(args[0]) if args else "unknown")
            middleware.before_call(model=str(model), action="generate")
            start = time.monotonic()
            result = await generate_fn(*args, **kwargs)
            duration_ms = (time.monotonic() - start) * 1000
            middleware.after_call(
                model=str(model),
                action="generate",
                duration_ms=duration_ms,
            )
            return result

        return governed_generate
