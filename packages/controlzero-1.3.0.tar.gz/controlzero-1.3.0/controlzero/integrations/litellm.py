"""LiteLLM integration for ControlZero.

Provides ``ControlZeroLiteLLMCallback`` which extends LiteLLM's
``CustomLogger`` to enforce policies before every LLM API call.

Usage::

    from controlzero import Client
    from controlzero.integrations.litellm import ControlZeroLiteLLMCallback
    import litellm

    cz = Client(policy={"rules": [{"allow": "*"}]})
    litellm.callbacks = [ControlZeroLiteLLMCallback(cz)]

    # Policy enforcement happens automatically
    response = litellm.completion(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from litellm.integrations.custom_logger import CustomLogger
except ImportError:
    raise ImportError(
        "The 'litellm' package is required for this integration. "
        "Install it with: pip install litellm"
    )

from controlzero.client import Client


class ControlZeroLiteLLMCallback(CustomLogger):
    """LiteLLM callback that enforces ControlZero policies.

    Intercepts LLM calls at the ``log_pre_api_call`` hook, which
    fires before the request is sent to the provider. If the policy
    denies the action, a ``PolicyDeniedError`` is raised, preventing
    the API call.

    Args:
        cz: A ``controlzero.Client`` instance with a policy loaded.
        agent_id: Optional identifier for the agent. Included in the
            enforcement context for audit logging.
    """

    def __init__(
        self,
        cz: Client,
        agent_id: str = "",
    ) -> None:
        super().__init__()
        self._cz = cz
        self._agent_id = agent_id

    def log_pre_api_call(
        self,
        model: str,
        messages: Any,
        kwargs: dict[str, Any],
    ) -> None:
        """Enforce policy before each LiteLLM API call.

        Called by LiteLLM just before the request is sent to the
        provider. Extracts the model name and enforces the
        ``llm.generate`` action.

        Args:
            model: The model identifier (e.g. "gpt-4", "claude-sonnet-4-20250514").
            messages: The message payload.
            kwargs: Additional keyword arguments from the LiteLLM call.
        """
        # Determine the action based on call type
        call_type = kwargs.get("call_type", "completion")
        if call_type == "embedding":
            tool_name = "llm:litellm:embedding"
        else:
            tool_name = "llm:litellm"

        # Extract provider from the model string if present
        # LiteLLM uses format "provider/model" (e.g. "openai/gpt-4")
        provider = "litellm"
        if "/" in model:
            parts = model.split("/", 1)
            provider = parts[0]

        self._cz.guard(
            tool=tool_name,
            method=call_type,
            raise_on_deny=True,
            context={
                "agent_id": self._agent_id,
                "provider": provider,
                "resource": f"model/{model}",
                "litellm_call_type": call_type,
            },
        )

    def log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """No-op. Required by CustomLogger interface."""

    def log_failure_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """No-op. Required by CustomLogger interface."""

    async def async_log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """No-op. Required by CustomLogger interface."""

    async def async_log_failure_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """No-op. Required by CustomLogger interface."""
