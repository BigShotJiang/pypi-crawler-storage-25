"""
Governed LangChain Tool wrappers.

Provides governance enforcement for LangChain tools including:
- Policy checks before execution
- Audit logging
- Error tracking
"""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional, Type, Union
from functools import wraps

try:
    from langchain_core.tools import BaseTool, Tool, StructuredTool
    from langchain_core.pydantic_v1 import BaseModel, Field
    from langchain_core.callbacks import CallbackManagerForToolRun
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    class BaseTool:
        pass
    class Tool:
        pass
    class StructuredTool:
        pass
    class BaseModel:
        pass
    class CallbackManagerForToolRun:
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision


class GovernanceTool(BaseTool):
    """
    Wraps a LangChain Tool to enforce ControlZero governance policies.

    Usage:
        client = Client(policy={"rules": [{"allow": "*"}]})

        base_tool = MyCustomTool()
        gov_tool = GovernanceTool(
            base_tool=base_tool,
            client=client,
            tool_name="my_custom_tool"
        )

        agent = initialize_agent([gov_tool], ...)
    """

    base_tool: BaseTool
    client: Client
    tool_name: str

    name: str = ""
    description: str = ""
    args_schema: Optional[Type[BaseModel]] = None

    class Config:
        arbitrary_types_allowed = True

    def __init__(
        self,
        base_tool: BaseTool,
        client: Client,
        tool_name: Optional[str] = None,
        **kwargs
    ):
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "langchain is required for LangChain integration. "
                "Install with: pip install langchain-core"
            )

        name = base_tool.name
        description = base_tool.description
        args_schema = getattr(base_tool, 'args_schema', None)
        tool_name = tool_name or name

        super().__init__(
            base_tool=base_tool,
            client=client,
            tool_name=tool_name,
            name=name,
            description=description,
            args_schema=args_schema,
            **kwargs
        )

    def _run(
        self,
        *args: Any,
        run_manager: Optional[CallbackManagerForToolRun] = None,
        **kwargs: Any,
    ) -> Any:
        """Execute the tool with governance checks."""
        decision = self.client.guard(
            tool=self.tool_name,
            method="run",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        try:
            result = self.base_tool._run(*args, run_manager=run_manager, **kwargs)

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("success", "run", latency_ms, decision)

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("error", "run", latency_ms, decision, error=e)
            raise

    async def _arun(
        self,
        *args: Any,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> Any:
        """Async execution with governance."""
        decision = self.client.guard(
            tool=self.tool_name,
            method="run",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        try:
            result = await self.base_tool._arun(*args, run_manager=run_manager, **kwargs)

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("success", "run", latency_ms, decision)

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("error", "run", latency_ms, decision, error=e)
            raise

    def _audit(
        self,
        status: str,
        method: str,
        latency_ms: int,
        decision: PolicyDecision,
        error: Optional[Exception] = None,
    ) -> None:
        """Write audit entry."""
        try:
            self.client._audit_decision(
                tool=self.tool_name,
                method=method,
                args={"status": status, "latency_ms": latency_ms},
                decision=decision,
            )
        except Exception:
            pass


# Alias for consistency
GovernedTool = GovernanceTool


def governed_tool(
    client: Client,
    tool_name: Optional[str] = None,
) -> Callable:
    """
    Decorator to create a governed tool from a function.

    Usage:
        @governed_tool(client, tool_name="my_tool")
        def my_function(query: str) -> str:
            '''Search for information.'''
            return search(query)
    """
    def decorator(func: Callable) -> StructuredTool:
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("langchain is required")

        base_tool = StructuredTool.from_function(
            func=func,
            name=tool_name or func.__name__,
            description=func.__doc__ or "",
        )

        return GovernanceTool(
            base_tool=base_tool,
            client=client,
            tool_name=tool_name or func.__name__,
        )

    return decorator


def wrap_tools(
    tools: List[BaseTool],
    client: Client,
) -> List[GovernanceTool]:
    """
    Wrap multiple tools with governance.

    Usage:
        tools = [tool1, tool2, tool3]
        governed_tools = wrap_tools(tools, client)
    """
    return [
        GovernanceTool(base_tool=tool, client=client)
        for tool in tools
    ]
