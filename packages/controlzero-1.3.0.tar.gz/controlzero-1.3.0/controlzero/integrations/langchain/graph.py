"""
ControlZero LangGraph Integration.

Provides governance for LangGraph state machines including:
- Node-level policy enforcement
- State transition logging
- Graph execution governance
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union

try:
    from langgraph.graph import StateGraph, END
    from langgraph.graph.state import CompiledStateGraph
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    class StateGraph:
        pass
    class CompiledStateGraph:
        pass
    END = "__end__"

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision

StateType = TypeVar("StateType", bound=Dict[str, Any])


class GovernedNode:
    """
    Decorator for governing LangGraph node functions.

    Wraps a node function to add:
    - Policy checks before execution
    - State transition logging
    - Error handling

    Usage:
        @GovernedNode(client, node_name="process_query")
        def process_query(state: State) -> State:
            # Node logic
            return {"result": "processed"}
    """

    def __init__(
        self,
        client: Client,
        node_name: Optional[str] = None,
        log_state: bool = False,
    ):
        """
        Initialize governed node decorator.

        Args:
            client: ControlZero client
            node_name: Name for the node (defaults to function name)
            log_state: Whether to log state content
        """
        self._client = client
        self._node_name = node_name
        self._log_state = log_state

    def __call__(self, func: Callable) -> Callable:
        """Wrap the node function."""
        node_name = self._node_name or func.__name__

        @wraps(func)
        def governed_node(state: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
            return self._execute_governed(func, node_name, state, *args, **kwargs)

        @wraps(func)
        async def governed_node_async(state: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
            return await self._execute_governed_async(func, node_name, state, *args, **kwargs)

        import asyncio
        if asyncio.iscoroutinefunction(func):
            return governed_node_async
        return governed_node

    def _execute_governed(
        self,
        func: Callable,
        node_name: str,
        state: Dict[str, Any],
        *args,
        **kwargs,
    ) -> Dict[str, Any]:
        """Execute node with governance (sync)."""
        tool_name = f"langgraph:{node_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="execute",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = func(state, *args, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log(node_name, latency_ms, "success", decision, state, result)
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log(node_name, latency_ms, "error", decision, state, error=e)
            raise

    async def _execute_governed_async(
        self,
        func: Callable,
        node_name: str,
        state: Dict[str, Any],
        *args,
        **kwargs,
    ) -> Dict[str, Any]:
        """Execute node with governance (async)."""
        tool_name = f"langgraph:{node_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="execute",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = await func(state, *args, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log(node_name, latency_ms, "success", decision, state, result)
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log(node_name, latency_ms, "error", decision, state, error=e)
            raise

    def _log(
        self,
        node_name: str,
        latency_ms: int,
        status: str,
        decision: PolicyDecision,
        input_state: Optional[Dict] = None,
        output_state: Optional[Dict] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """Log node execution."""
        log_data: dict = {"status": status, "latency_ms": latency_ms}

        if self._log_state:
            if input_state:
                log_data["input_state"] = {k: str(v)[:100] for k, v in input_state.items()}
            if output_state:
                log_data["output_state"] = {k: str(v)[:100] for k, v in output_state.items()}
        if error:
            log_data["error_type"] = type(error).__name__
            log_data["error_message"] = str(error)

        try:
            self._client._audit_decision(
                tool=f"langgraph:{node_name}",
                method="execute",
                args=log_data,
                decision=decision,
            )
        except Exception:
            pass


def governed_graph(
    client: Client,
    graph_name: str = "langgraph",
) -> Callable:
    """
    Decorator to wrap an entire LangGraph with governance.

    Usage:
        @governed_graph(client, graph_name="my_workflow")
        def create_graph():
            graph = StateGraph(State)
            graph.add_node("process", process_node)
            graph.add_edge("process", END)
            return graph.compile()
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            compiled_graph = func(*args, **kwargs)

            return GovernedStateGraph(
                graph=compiled_graph,
                client=client,
                graph_name=graph_name,
            )
        return wrapper
    return decorator


class GovernedStateGraph:
    """
    Governance wrapper for compiled LangGraph.

    Provides:
    - Graph-level policy enforcement
    - Execution logging
    - State tracking

    Usage:
        graph = StateGraph(State)
        # ... add nodes and edges
        compiled = graph.compile()

        governed = GovernedStateGraph(
            graph=compiled,
            client=client,
            graph_name="my_workflow"
        )

        result = governed.invoke({"input": "data"})
    """

    def __init__(
        self,
        graph: Any,  # CompiledStateGraph
        client: Client,
        graph_name: str = "langgraph",
        log_states: bool = False,
    ):
        """
        Initialize governed graph.

        Args:
            graph: Compiled LangGraph
            client: ControlZero client
            graph_name: Name for logging
            log_states: Whether to log state content
        """
        if not LANGGRAPH_AVAILABLE:
            raise ImportError(
                "langgraph is required. Install with: pip install langgraph"
            )

        self._graph = graph
        self._client = client
        self._graph_name = graph_name
        self._log_states = log_states

    def invoke(
        self,
        input: Dict[str, Any],
        config: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Invoke the graph with governance.

        Args:
            input: Initial state
            config: Run configuration
            **kwargs: Additional arguments

        Returns:
            Final state
        """
        tool_name = f"langgraph:{self._graph_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="invoke",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = self._graph.invoke(input, config=config, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("invoke", latency_ms, "success", decision, input, result)
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("invoke", latency_ms, "error", decision, input, error=e)
            raise

    async def ainvoke(
        self,
        input: Dict[str, Any],
        config: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Async invoke with governance."""
        tool_name = f"langgraph:{self._graph_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="invoke",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = await self._graph.ainvoke(input, config=config, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("invoke", latency_ms, "success", decision, input, result)
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("invoke", latency_ms, "error", decision, input, error=e)
            raise

    def stream(
        self,
        input: Dict[str, Any],
        config: Optional[Dict] = None,
        **kwargs,
    ):
        """
        Stream graph execution with governance.

        Args:
            input: Initial state
            config: Run configuration
            **kwargs: Additional arguments

        Yields:
            State updates
        """
        tool_name = f"langgraph:{self._graph_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="stream",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        states = []

        try:
            for state in self._graph.stream(input, config=config, **kwargs):
                states.append(state)
                yield state

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("stream", latency_ms, "success", decision, input, metadata={"num_states": len(states)})

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("stream", latency_ms, "error", decision, input, error=e)
            raise

    async def astream(
        self,
        input: Dict[str, Any],
        config: Optional[Dict] = None,
        **kwargs,
    ):
        """Async stream with governance."""
        tool_name = f"langgraph:{self._graph_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="stream",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        states = []

        try:
            async for state in self._graph.astream(input, config=config, **kwargs):
                states.append(state)
                yield state

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("stream", latency_ms, "success", decision, input, metadata={"num_states": len(states)})

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._log("stream", latency_ms, "error", decision, input, error=e)
            raise

    def _log(
        self,
        method: str,
        latency_ms: int,
        status: str,
        decision: PolicyDecision,
        input_state: Optional[Dict] = None,
        output_state: Optional[Dict] = None,
        error: Optional[Exception] = None,
        metadata: Optional[Dict] = None,
    ) -> None:
        """Log graph execution."""
        log_data: dict = metadata or {}
        log_data["status"] = status
        log_data["latency_ms"] = latency_ms

        if self._log_states:
            if input_state:
                log_data["input_state"] = {k: str(v)[:100] for k, v in input_state.items()}
            if output_state:
                log_data["output_state"] = {k: str(v)[:100] for k, v in output_state.items()}
        if error:
            log_data["error_type"] = type(error).__name__
            log_data["error_message"] = str(error)

        try:
            self._client._audit_decision(
                tool=f"langgraph:{self._graph_name}",
                method=method,
                args=log_data,
                decision=decision,
            )
        except Exception:
            pass

    @property
    def graph(self) -> Any:
        """Get underlying graph."""
        return self._graph

    def get_graph(self, **kwargs):
        """Get graph visualization."""
        return self._graph.get_graph(**kwargs)
