"""
Governed CrewAI Crew wrapper.

Provides governance enforcement for CrewAI crews including:
- Crew-level policy enforcement
- Agent role-based access control
- Task execution governance
- Inter-agent communication logging
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

try:
    from crewai import Crew, Agent, Task, Process
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    class Crew:
        pass
    class Agent:
        pass
    class Task:
        pass
    class Process:
        sequential = "sequential"
        hierarchical = "hierarchical"

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision
from controlzero.integrations.crewai.agent import GovernedCrewAgent
from controlzero.integrations.crewai.task import GovernedTask


class GovernedCrew:
    """
    Governance wrapper for CrewAI Crew.

    Wraps a CrewAI Crew to provide:
    - Crew-level policy enforcement
    - Automatic agent and task governance wrapping
    - Execution audit logging
    - Resource tracking

    Usage:
        from crewai import Crew, Agent, Task

        researcher = Agent(role="Researcher", ...)
        writer = Agent(role="Writer", ...)

        research_task = Task(description="...", agent=researcher)
        writing_task = Task(description="...", agent=writer)

        crew = Crew(
            agents=[researcher, writer],
            tasks=[research_task, writing_task],
        )

        governed_crew = GovernedCrew(
            crew=crew,
            client=client,
            crew_name="content_creation",
        )

        result = governed_crew.kickoff()
    """

    def __init__(
        self,
        crew: Crew,
        client: Client,
        crew_name: str = "crewai_crew",
        wrap_agents: bool = True,
        wrap_tasks: bool = True,
        max_rpm: Optional[int] = None,
        max_iterations: Optional[int] = None,
        log_outputs: bool = False,
    ):
        """
        Initialize governed crew.

        Args:
            crew: The CrewAI Crew to wrap
            client: ControlZero client
            crew_name: Name for logging purposes
            wrap_agents: Whether to wrap agents with governance
            wrap_tasks: Whether to wrap tasks with governance
            max_rpm: Maximum requests per minute (rate limit)
            max_iterations: Maximum iterations for the crew
            log_outputs: Whether to log output content
        """
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "crewai is required. Install with: pip install crewai"
            )

        self._crew = crew
        self._client = client
        self._crew_name = crew_name
        self._log_outputs = log_outputs

        # Apply limits
        if max_rpm:
            self._crew.max_rpm = max_rpm
        if max_iterations:
            self._crew.max_iterations = max_iterations

        # Wrap agents and tasks with governance
        if wrap_agents:
            self._governed_agents = self._wrap_agents()
        else:
            self._governed_agents = []

        if wrap_tasks:
            self._governed_tasks = self._wrap_tasks()
        else:
            self._governed_tasks = []

        # Tracking
        self._kickoff_count = 0
        self._total_tokens = 0
        self._session_start = time.time()

    def _wrap_agents(self) -> List[GovernedCrewAgent]:
        """Wrap crew agents with governance."""
        governed = []
        for agent in self._crew.agents:
            if isinstance(agent, GovernedCrewAgent):
                governed.append(agent)
            else:
                governed.append(
                    GovernedCrewAgent(
                        agent=agent,
                        client=self._client,
                        wrap_tools=True,
                    )
                )
        return governed

    def _wrap_tasks(self) -> List[GovernedTask]:
        """Wrap crew tasks with governance."""
        governed = []
        for task in self._crew.tasks:
            if isinstance(task, GovernedTask):
                governed.append(task)
            else:
                governed.append(
                    GovernedTask(
                        task=task,
                        client=self._client,
                        log_outputs=self._log_outputs,
                    )
                )
        return governed

    def kickoff(
        self,
        inputs: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Execute the crew with governance.

        Args:
            inputs: Input variables for the crew

        Returns:
            Crew execution result
        """
        tool_name = f"crewai:crew:{self._crew_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="kickoff",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        self._kickoff_count += 1

        try:
            result = self._crew.kickoff(inputs=inputs)

            latency_ms = int((time.perf_counter() - start) * 1000)

            metadata = {
                "kickoff_count": self._kickoff_count,
                "num_agents": len(self._crew.agents),
                "num_tasks": len(self._crew.tasks),
                "process_type": str(getattr(self._crew, 'process', 'sequential')),
                "status": "success",
                "latency_ms": latency_ms,
            }

            if self._log_outputs and result:
                metadata["result_preview"] = str(result)[:500]

            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff",
                    args=metadata,
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(e).__name__}: {e}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff",
                    args={"status": "error", "latency_ms": latency_ms},
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    async def akickoff(
        self,
        inputs: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Async execute the crew with governance.

        Args:
            inputs: Input variables for the crew

        Returns:
            Crew execution result
        """
        tool_name = f"crewai:crew:{self._crew_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="kickoff",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        self._kickoff_count += 1

        try:
            if hasattr(self._crew, 'akickoff'):
                result = await self._crew.akickoff(inputs=inputs)
            else:
                result = self._crew.kickoff(inputs=inputs)

            latency_ms = int((time.perf_counter() - start) * 1000)

            metadata = {
                "kickoff_count": self._kickoff_count,
                "num_agents": len(self._crew.agents),
                "num_tasks": len(self._crew.tasks),
                "async": True,
                "status": "success",
                "latency_ms": latency_ms,
            }

            if self._log_outputs and result:
                metadata["result_preview"] = str(result)[:500]

            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff",
                    args=metadata,
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(e).__name__}: {e}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff",
                    args={"status": "error", "latency_ms": latency_ms},
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    def kickoff_for_each(
        self,
        inputs: List[Dict[str, Any]],
    ) -> List[Any]:
        """
        Execute crew for each input set with governance.

        Args:
            inputs: List of input dictionaries

        Returns:
            List of results
        """
        tool_name = f"crewai:crew:{self._crew_name}"
        decision = self._client.guard(
            tool=tool_name,
            method="kickoff_for_each",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        results = []

        try:
            for input_set in inputs:
                result = self._crew.kickoff(inputs=input_set)
                results.append(result)
                self._kickoff_count += 1

            latency_ms = int((time.perf_counter() - start) * 1000)

            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff_for_each",
                    args={
                        "batch_size": len(inputs),
                        "successful": len(results),
                        "status": "success",
                        "latency_ms": latency_ms,
                    },
                    decision=decision,
                )
            except Exception:
                pass

            return results

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(e).__name__}: {e}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method="kickoff_for_each",
                    args={
                        "completed": len(results),
                        "status": "error",
                        "latency_ms": latency_ms,
                    },
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    @property
    def crew(self) -> Crew:
        """Get underlying CrewAI crew."""
        return self._crew

    @property
    def agents(self) -> List:
        """Get crew agents."""
        return self._crew.agents

    @property
    def tasks(self) -> List:
        """Get crew tasks."""
        return self._crew.tasks

    @property
    def governed_agents(self) -> List[GovernedCrewAgent]:
        """Get governed agent wrappers."""
        return self._governed_agents

    @property
    def governed_tasks(self) -> List[GovernedTask]:
        """Get governed task wrappers."""
        return self._governed_tasks

    @property
    def kickoff_count(self) -> int:
        """Get total kickoff count."""
        return self._kickoff_count

    @property
    def usage_metrics(self) -> Dict[str, Any]:
        """Get usage metrics for the crew."""
        session_duration = time.time() - self._session_start
        return {
            "crew_name": self._crew_name,
            "kickoff_count": self._kickoff_count,
            "num_agents": len(self._crew.agents),
            "num_tasks": len(self._crew.tasks),
            "session_duration_seconds": round(session_duration, 2),
            "total_tokens": self._total_tokens,
        }
