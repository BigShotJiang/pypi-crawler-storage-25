"""
ControlZero CrewAI Integration.

Provides governance enforcement for CrewAI including:
- Crew-level policy enforcement
- Agent role-based access control
- Task execution governance
- Tool-level policy checks

Usage:
    from controlzero import Client
    from controlzero.integrations.crewai import (
        GovernedCrew,
        GovernedCrewAgent,
        GovernedTask,
        GovernedCrewTool,
    )

    client = Client(policy={"rules": [{"allow": "*"}]})

    # Wrap a crew with governance
    governed_crew = GovernedCrew(
        crew=my_crew,
        client=client,
    )

    result = governed_crew.kickoff()
"""

from controlzero.integrations.crewai.crew import GovernedCrew
from controlzero.integrations.crewai.agent import GovernedCrewAgent, governed_agent
from controlzero.integrations.crewai.task import GovernedTask, governed_task
from controlzero.integrations.crewai.tool import (
    GovernedCrewTool,
    governed_crew_tool,
    wrap_crew_tools,
)

__all__ = [
    # Crew
    "GovernedCrew",
    # Agent
    "GovernedCrewAgent",
    "governed_agent",
    # Task
    "GovernedTask",
    "governed_task",
    # Tool
    "GovernedCrewTool",
    "governed_crew_tool",
    "wrap_crew_tools",
]
