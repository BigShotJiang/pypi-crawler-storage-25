"""
Governed CrewAI Tool wrappers.

Provides governance enforcement for CrewAI tools including:
- Policy checks before execution
- Audit logging
- Error tracking
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Type

try:
    from crewai.tools import BaseTool as CrewAIBaseTool
    from pydantic import BaseModel, Field
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    class CrewAIBaseTool:
        pass
    class BaseModel:
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision


class GovernedCrewTool(CrewAIBaseTool):
    """
    Wraps a CrewAI Tool to enforce ControlZero governance policies.

    Usage:
        from crewai.tools import BaseTool

        class MyTool(BaseTool):
            name: str = "my_tool"
            description: str = "Does something"

            def _run(self, query: str) -> str:
                return "result"

        governed_tool = GovernedCrewTool(
            base_tool=MyTool(),
            client=client,
        )
    """

    name: str = ""
    description: str = ""
    base_tool: Any = None
    client: Any = None
    tool_name: str = ""

    class Config:
        arbitrary_types_allowed = True

    def __init__(
        self,
        base_tool: CrewAIBaseTool,
        client: Client,
        tool_name: Optional[str] = None,
        **kwargs
    ):
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "crewai is required for CrewAI integration. "
                "Install with: pip install crewai"
            )

        name = base_tool.name
        description = base_tool.description
        tool_name = tool_name or name

        super().__init__(
            name=name,
            description=description,
            base_tool=base_tool,
            client=client,
            tool_name=tool_name,
            **kwargs
        )

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        """Execute the tool with governance checks."""
        method = "run"

        # Check policy via guard()
        decision = self.client.guard(
            tool=self.tool_name,
            method=method,
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        try:
            result = self.base_tool._run(*args, **kwargs)

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("success", method, latency_ms, decision)

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("error", method, latency_ms, decision, error=e)
            raise

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        """Async execution with governance."""
        method = "run"

        decision = self.client.guard(
            tool=self.tool_name,
            method=method,
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        try:
            if hasattr(self.base_tool, '_arun'):
                result = await self.base_tool._arun(*args, **kwargs)
            else:
                result = self.base_tool._run(*args, **kwargs)

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("success", method, latency_ms, decision)

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("error", method, latency_ms, decision, error=e)
            raise

    def _audit(
        self,
        status: str,
        method: str,
        latency_ms: int,
        decision: PolicyDecision,
        error: Optional[Exception] = None,
    ) -> None:
        """Write audit entry."""
        try:
            self.client._audit_decision(
                tool=self.tool_name,
                method=method,
                args={"status": status, "latency_ms": latency_ms},
                decision=decision,
            )
        except Exception:
            pass


def governed_crew_tool(
    client: Client,
    tool_name: Optional[str] = None,
) -> Callable:
    """
    Decorator to create a governed CrewAI tool from a function.

    Usage:
        @governed_crew_tool(client, tool_name="search")
        def search_web(query: str) -> str:
            '''Search the web for information.'''
            return search(query)
    """
    def decorator(func: Callable) -> Callable:
        if not CREWAI_AVAILABLE:
            raise ImportError("crewai is required")

        name = tool_name or func.__name__
        description = func.__doc__ or ""

        @wraps(func)
        def governed_func(*args, **kwargs):
            decision = client.guard(tool=name, method="run")

            if decision.denied:
                raise PolicyDeniedError(decision)

            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)

                latency_ms = int((time.perf_counter() - start) * 1000)
                try:
                    client._audit_decision(
                        tool=name,
                        method="run",
                        args={"status": "success", "latency_ms": latency_ms},
                        decision=decision,
                    )
                except Exception:
                    pass

                return result

            except PolicyDeniedError:
                raise
            except Exception as e:
                latency_ms = int((time.perf_counter() - start) * 1000)
                try:
                    err_decision = PolicyDecision(
                        effect="allow",
                        reason=f"error: {type(e).__name__}: {e}",
                    )
                    client._audit_decision(
                        tool=name,
                        method="run",
                        args={"status": "error", "latency_ms": latency_ms},
                        decision=err_decision,
                    )
                except Exception:
                    pass
                raise

        governed_func.name = name
        governed_func.description = description
        governed_func.is_governed = True

        return governed_func

    return decorator


def wrap_crew_tools(
    tools: List[CrewAIBaseTool],
    client: Client,
) -> List[GovernedCrewTool]:
    """
    Wrap multiple CrewAI tools with governance.

    Usage:
        tools = [tool1, tool2, tool3]
        governed_tools = wrap_crew_tools(tools, client)
    """
    return [
        GovernedCrewTool(base_tool=tool, client=client)
        for tool in tools
    ]
