"""Google Generative AI SDK integration for ControlZero.

Provides ``wrap_google()`` which transparently intercepts
``model.generate_content()`` and ``model.generate_content_async()``
to enforce governance policies before the request reaches Google.

All other model methods and properties pass through unchanged.

This is a lightweight alternative to the full ``google_adk``
integration (GovernedAgent / GovernedTool). Use ``wrap_google()``
when you only need policy enforcement on a GenerativeModel instance.

Usage::

    from controlzero import Client
    from controlzero.integrations.google import wrap_google
    import google.generativeai as genai

    cz = Client(policy={"rules": [{"allow": "*"}]})
    model = genai.GenerativeModel("gemini-1.5-pro")
    model = wrap_google(model, cz)

    # Policy enforcement happens automatically
    response = model.generate_content("Hello")
"""

from __future__ import annotations

import time
from typing import Any

try:
    import google.generativeai as _genai  # noqa: F401
except ImportError:
    raise ImportError(
        "The 'google-generativeai' package is required for this integration. "
        "Install it with: pip install google-generativeai"
    )

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Rough cost estimate fallback (USD per token)."""
    return (input_tokens + output_tokens) / 1_000_000 * 1.0


class _WrappedGenerativeModel:
    """Proxy for ``genai.GenerativeModel`` that enforces policy on generate_content()."""

    __slots__ = ("_inner", "_cz", "_agent_id")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._cz = cz
        self._agent_id = agent_id

    def _enforce_model(self, method: str) -> None:
        """Enforce policy for a generate_content call."""
        model_name = getattr(self._inner, "model_name", "unknown")
        context: dict[str, Any] = {
            "agent_id": self._agent_id,
            "provider": "google",
            "method": method,
            "resource": f"model/{model_name}",
        }
        self._cz.guard(
            tool="llm:google",
            method=method,
            raise_on_deny=True,
            context=context,
        )

    def _extract_usage(self, response: Any) -> tuple[int, int]:
        """Extract token counts from a Google AI response."""
        usage = getattr(response, "usage_metadata", None)
        if usage is None:
            return 0, 0
        input_tokens = getattr(usage, "prompt_token_count", 0) or 0
        output_tokens = getattr(usage, "candidates_token_count", 0) or 0
        return input_tokens, output_tokens

    def generate_content(self, *args: Any, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original generate_content()."""
        self._enforce_model("generate_content")
        model_name = getattr(self._inner, "model_name", "unknown")
        start = time.perf_counter()
        response = self._inner.generate_content(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        input_tokens, output_tokens = self._extract_usage(response)

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm:google",
                method="generate_content",
                args={
                    "model": model_name,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
            )
        except Exception:
            pass

        return response

    async def generate_content_async(self, *args: Any, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original generate_content_async()."""
        self._enforce_model("generate_content_async")
        model_name = getattr(self._inner, "model_name", "unknown")
        start = time.perf_counter()
        response = await self._inner.generate_content_async(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        input_tokens, output_tokens = self._extract_usage(response)

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm:google",
                method="generate_content_async",
                args={
                    "model": model_name,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
            )
        except Exception:
            pass

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def wrap_google(
    model: Any,
    cz: Client,
    agent_id: str = "",
) -> Any:
    """Wrap a Google GenerativeModel with ControlZero policy enforcement.

    Returns a proxy object that intercepts ``generate_content()`` and
    ``generate_content_async()`` to enforce governance policies. All other
    model methods and properties pass through unchanged.

    This is a lightweight alternative to the full ``google_adk`` integration.
    Use this when you only need policy enforcement on a single model instance,
    not the full ADK agent governance.

    Args:
        model: A ``genai.GenerativeModel()`` instance.
        cz: A ``controlzero.Client`` instance with a policy loaded.
        agent_id: Optional identifier for the agent making requests.
            Included in the enforcement context for audit logging.

    Returns:
        A wrapped model with transparent policy enforcement.

    Example::

        from controlzero import Client
        from controlzero.integrations.google import wrap_google
        import google.generativeai as genai

        cz = Client(policy={"rules": [{"allow": "*"}]})
        model = wrap_google(genai.GenerativeModel("gemini-1.5-pro"), cz)

        response = model.generate_content("Hello, Gemini!")
    """
    return _WrappedGenerativeModel(model, cz, agent_id)
