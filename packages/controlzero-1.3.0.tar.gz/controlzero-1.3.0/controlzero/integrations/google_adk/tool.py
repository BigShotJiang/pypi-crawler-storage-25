"""
Governed Google ADK Tool wrapper.

Provides governance enforcement for Google ADK tools including:
- Policy checks before execution
- Audit logging
- Error tracking
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

try:
    from google.adk.tools import BaseTool
    from google.adk.tools.tool_context import ToolContext
    GOOGLE_ADK_AVAILABLE = True
except ImportError:
    GOOGLE_ADK_AVAILABLE = False
    class BaseTool:  # type: ignore[no-redef]
        pass
    class ToolContext:  # type: ignore[no-redef]
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision


class GovernedTool:
    """
    Wraps a Google ADK BaseTool to enforce ControlZero governance policies.

    Intercepts tool execution to apply policy checks and write entries
    to the audit trail before delegating to the underlying tool.

    Usage::

        from google.adk.tools import BaseTool
        from controlzero import Client
        from controlzero.integrations.google_adk import GovernedTool

        class MyTool(BaseTool):
            def __init__(self):
                super().__init__(name="my_tool", description="Does something useful")

            async def run_async(self, *, args, tool_context):
                return {"result": "done"}

        client = Client(policy={"rules": [{"allow": "*"}]})
        governed = GovernedTool(base_tool=MyTool(), client=client)
    """

    def __init__(
        self,
        base_tool: Any,
        client: Client,
        tool_name: Optional[str] = None,
    ) -> None:
        """
        Initialize governed tool.

        Args:
            base_tool: The Google ADK BaseTool instance to wrap.
            client: ControlZero client.
            tool_name: Override name used for policy lookups and logging.
                       Defaults to base_tool.name.
        """
        if not GOOGLE_ADK_AVAILABLE:
            raise ImportError(
                "The 'google-adk' package is required for this integration. "
                "Install it with: pip install google-adk"
            )

        self._base_tool = base_tool
        self._client = client
        self._tool_name = tool_name or getattr(base_tool, "name", type(base_tool).__name__)

    @property
    def name(self) -> str:
        return getattr(self._base_tool, "name", self._tool_name)

    @property
    def description(self) -> str:
        return getattr(self._base_tool, "description", "")

    @property
    def base_tool(self) -> Any:
        return self._base_tool

    async def run_async(
        self,
        *,
        args: Dict[str, Any],
        tool_context: Any,
    ) -> Any:
        """
        Execute the tool asynchronously with governance checks.

        Args:
            args: Tool arguments forwarded from the ADK runner.
            tool_context: Google ADK ToolContext instance.

        Returns:
            Tool result from the underlying BaseTool.

        Raises:
            PolicyDeniedError: If the governing policy denies execution.
        """
        decision = self._client.guard(
            tool=self._tool_name,
            method="run_async",
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        try:
            result = await self._base_tool.run_async(
                args=args,
                tool_context=tool_context,
            )

            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                self._client._audit_decision(
                    tool=self._tool_name,
                    method="run_async",
                    args={"status": "success", "latency_ms": latency_ms},
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as exc:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(exc).__name__}: {exc}",
                )
                self._client._audit_decision(
                    tool=self._tool_name,
                    method="run_async",
                    args={"status": "error", "latency_ms": latency_ms},
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    def __getattr__(self, name: str) -> Any:
        """Delegate any attribute not found on GovernedTool to the base tool."""
        return getattr(self._base_tool, name)


def governed_adk_tool(
    client: Client,
    tool_name: Optional[str] = None,
) -> Callable:
    """
    Decorator to create a governed Google ADK tool from a plain async function.

    The decorated function must accept ``args`` and ``tool_context`` keyword
    arguments, matching the ADK ``run_async`` signature.

    Usage::

        @governed_adk_tool(client, tool_name="web_search")
        async def web_search(*, args, tool_context):
            '''Search the web for information.'''
            query = args.get("query", "")
            return {"results": search(query)}
    """
    def decorator(func: Callable) -> Callable:
        if not GOOGLE_ADK_AVAILABLE:
            raise ImportError(
                "The 'google-adk' package is required for this integration. "
                "Install it with: pip install google-adk"
            )

        name = tool_name or func.__name__
        description = func.__doc__ or ""

        @wraps(func)
        async def governed_func(*args: Any, **kwargs: Any) -> Any:
            decision = client.guard(
                tool=name,
                method="run_async",
            )

            if decision.denied:
                raise PolicyDeniedError(decision)

            start = time.perf_counter()
            try:
                result = await func(*args, **kwargs)

                latency_ms = int((time.perf_counter() - start) * 1000)
                try:
                    client._audit_decision(
                        tool=name,
                        method="run_async",
                        args={"status": "success", "latency_ms": latency_ms},
                        decision=decision,
                    )
                except Exception:
                    pass

                return result

            except PolicyDeniedError:
                raise
            except Exception as exc:
                latency_ms = int((time.perf_counter() - start) * 1000)
                try:
                    err_decision = PolicyDecision(
                        effect="allow",
                        reason=f"error: {type(exc).__name__}: {exc}",
                    )
                    client._audit_decision(
                        tool=name,
                        method="run_async",
                        args={"status": "error", "latency_ms": latency_ms},
                        decision=err_decision,
                    )
                except Exception:
                    pass
                raise

        governed_func.name = name  # type: ignore[attr-defined]
        governed_func.description = description  # type: ignore[attr-defined]
        governed_func.is_governed = True  # type: ignore[attr-defined]

        return governed_func

    return decorator


def wrap_adk_tools(
    tools: List[Any],
    client: Client,
) -> List[GovernedTool]:
    """
    Wrap a list of Google ADK tools with ControlZero governance.

    Usage::

        from controlzero.integrations.google_adk import wrap_adk_tools

        governed_tools = wrap_adk_tools([tool1, tool2], client)
    """
    return [GovernedTool(base_tool=tool, client=client) for tool in tools]
