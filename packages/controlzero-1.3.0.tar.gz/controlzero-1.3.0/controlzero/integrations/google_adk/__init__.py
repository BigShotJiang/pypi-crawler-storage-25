"""
ControlZero Google ADK Integration.

Provides governance enforcement for Google ADK agents and tools including:
- Agent-level policy enforcement before each run
- Tool-level policy checks with audit logging
- Session-level usage tracking

Usage::

    from controlzero import Client
    from controlzero.integrations.google_adk import (
        GovernedAgent,
        GovernedTool,
        governed_adk_tool,
        wrap_adk_tools,
    )

    client = Client(policy={"rules": [{"allow": "*"}]})

    # Wrap an existing ADK tool with governance
    governed_tool = GovernedTool(base_tool=my_tool, client=client)

    # Wrap an entire ADK agent (tools are wrapped automatically)
    governed_agent = GovernedAgent(
        agent=my_agent,
        client=client,
        wrap_tools=True,
    )

    # Decorate an async function as a governed tool
    @governed_adk_tool(client, tool_name="web_search")
    async def web_search(*, args, tool_context):
        '''Search the web for information.'''
        ...

    # Bulk-wrap a list of tools
    governed_tools = wrap_adk_tools([tool1, tool2], client)

google-adk is an optional dependency. Install it separately::

    pip install google-adk
"""

from controlzero.integrations.google_adk.agent import GovernedAgent
from controlzero.integrations.google_adk.tool import (
    GovernedTool,
    governed_adk_tool,
    wrap_adk_tools,
)

__all__ = [
    # Agent
    "GovernedAgent",
    # Tool
    "GovernedTool",
    "governed_adk_tool",
    "wrap_adk_tools",
]
