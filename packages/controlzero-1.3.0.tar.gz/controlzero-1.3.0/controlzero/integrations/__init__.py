"""ControlZero framework integrations.

Each submodule provides a thin wrapper or callback handler for a
specific AI framework. Import directly from the submodule you need:

    from controlzero.integrations.openai import wrap_openai
    from controlzero.integrations.anthropic import wrap_anthropic
    from controlzero.integrations.google import wrap_google
    from controlzero.integrations.langchain import ControlZeroCallbackHandler
    from controlzero.integrations.crewai import create_step_callback
    from controlzero.integrations.litellm import ControlZeroLiteLLMCallback
    from controlzero.integrations.google_adk import GovernedAgent, GovernedTool
    from controlzero.integrations.vercel_ai import ControlZeroVercelAIMiddleware
    from controlzero.integrations.braintrust import BraintrustGovernanceLogger
    from controlzero.integrations.langfuse import LangfuseGovernanceHandler

No framework dependencies are installed by default. Install the
framework you need separately (e.g. ``pip install openai``,
``pip install google-adk``, ``pip install langfuse``).
"""
