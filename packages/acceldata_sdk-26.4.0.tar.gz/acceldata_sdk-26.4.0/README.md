# acceldata SDK

Acceldata SDK for instrumenting support in [ADOC](https://docs.acceldata.io/documentation/adoc-architecture-an-overview).

Refer to the [documentation](https://docs.acceldata.io/documentation/python) for details.
---

## Changelog

<!-- BEGIN CHANGELOG -->

Version Log
========================

26.4.0 (11/04/2026)
------------------
- Released **acceldata_sdk** version 26.4.0.
- Includes improvements and fixes for core SDK functionality.

<!-- END CHANGELOG -->

