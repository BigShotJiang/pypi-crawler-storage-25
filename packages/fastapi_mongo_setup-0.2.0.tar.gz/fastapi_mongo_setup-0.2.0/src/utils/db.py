import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv()

class Database:
    client: AsyncIOMotorClient = None
    db = None

db = Database()

async def connect_to_mongodb():
    mongodb_url = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
    database_name = os.getenv("DATABASE_NAME", "fastapi_db")
    
    db.client = AsyncIOMotorClient(mongodb_url)
    db.db = db.client[database_name]
    
    # Ping the database to ensure a successful connection
    await db.client.admin.command('ping')
    print("Connected to MongoDB!")

async def close_mongodb_connection():
    if db.client:
        db.client.close()
        print("Closed MongoDB connection.")
