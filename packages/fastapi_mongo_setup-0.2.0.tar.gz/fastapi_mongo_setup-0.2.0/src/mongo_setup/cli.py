import os
import pathlib

def init():
    print("Initializing MongoDB setup for FastAPI...")
    
    # Check if src/utils exists (create if not)
    utils_dir = pathlib.Path("src/utils")
    utils_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Create src/utils/db.py
    db_file = utils_dir / "db.py"
    if not db_file.exists():
        with open(db_file, "w", encoding="utf-8") as f:
            f.write("""import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv()

class Database:
    client: AsyncIOMotorClient = None
    db = None

db = Database()

async def connect_to_mongodb():
    mongodb_url = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
    database_name = os.getenv("DATABASE_NAME", "fastapi_db")
    
    db.client = AsyncIOMotorClient(mongodb_url)
    db.db = db.client[database_name]
    
    # Ping the database to ensure a successful connection
    await db.client.admin.command('ping')
    print("Connected to MongoDB!")

async def close_mongodb_connection():
    if db.client:
        db.client.close()
        print("Closed MongoDB connection.")
""")
        print(f"Created {db_file}")
    else:
        print(f"{db_file} already exists, skipping.")

    # 2. Create src/utils/helpers.py
    helpers_file = utils_dir / "helpers.py"
    if not helpers_file.exists():
        with open(helpers_file, "w", encoding="utf-8") as f:
            f.write("""def serialize_doc(doc):
    \"\"\"Convert MongoDB ObjectId to string\"\"\"
    if doc and "_id" in doc:
        doc["id"] = str(doc["_id"])
        del doc["_id"]
    return doc
""")
        print(f"Created {helpers_file}")
    else:
        print(f"{helpers_file} already exists, skipping.")

    # 3. Append to .env
    env_file = pathlib.Path(".env")
    env_content = ""
    
    if env_file.exists():
        with open(env_file, "r", encoding="utf-8") as f:
            env_content = f.read()

    with open(env_file, "a", encoding="utf-8") as f:
        # Add a newline if the file does not end with one
        if env_content and not env_content.endswith("\\n"):
            f.write("\\n")
            
        if "MONGODB_URL" not in env_content:
            f.write("MONGODB_URL=mongodb://localhost:27017\\n")
        if "DATABASE_NAME" not in env_content:
            f.write("DATABASE_NAME=fastapi_db\\n")
            
    print("Appended MONGODB_URL and DATABASE_NAME placeholders to .env")

    # 4. Create main.py
    main_file = pathlib.Path("main.py")
    if not main_file.exists():
        with open(main_file, "w", encoding="utf-8") as f:
            f.write("""from fastapi import FastAPI
from contextlib import asynccontextmanager
from src.utils.db import connect_to_mongodb, close_mongodb_connection, db
from src.utils.helpers import serialize_doc

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup actions
    await connect_to_mongodb()
    yield
    # Shutdown actions
    await close_mongodb_connection()

app = FastAPI(lifespan=lifespan)

@app.get("/")
async def root():
    return {"message": "Welcome to FastAPI with MongoDB!"}

@app.get("/test-db")
async def test_db():
    if db.client is None:
        return {"error": "Database not connected"}
    
    try:
        # Insert demo data to confirm it works
        demo_collection = db.db["demo_collection"]
        result = await demo_collection.insert_one({"message": "Hello from fastapi-mongo-setup!", "status": "success"})
        
        # Retrieve the inserted demo data
        demo_data = await demo_collection.find_one({"_id": result.inserted_id})
        
        return {
            "status": "success",
            "message": "Database is connected and demo data was successfully inserted!",
            "inserted_data": serialize_doc(demo_data)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": "Error connecting to the database or inserting data. Make sure your MongoDB server is running in the URL specified in .env",
            "details": str(e)
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
""")
        print(f"Created {main_file}")
    else:
        print(f"{main_file} already exists, skipping.")

    # 5. Create requirements.txt
    req_file = pathlib.Path("requirements.txt")
    if not req_file.exists():
        with open(req_file, "w", encoding="utf-8") as f:
            f.write("""fastapi
uvicorn
motor
python-dotenv
""")
        print(f"Created {req_file}")
    else:
        print(f"{req_file} already exists, skipping.")
        
    print("MongoDB setup complete! Run your server with: python main.py")

if __name__ == "__main__":
    init()
