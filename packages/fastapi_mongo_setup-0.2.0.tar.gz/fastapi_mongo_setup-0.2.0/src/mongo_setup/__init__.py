"""fastapi-mongo-setup package"""
