#!/usr/bin/env python3
"""
AWS Extended Support Cost Calculator - MCP Server

Calculates extended support costs for RDS/Aurora, ElastiCache, EKS, and OpenSearch.
Auto-fetches and caches pricing data, vCPU mappings, and version info.
No manual data setup required — just install and use.
"""

from mcp.server.fastmcp import FastMCP
import json
import os
import time
import csv
from typing import Optional, Dict, List, Any
from datetime import datetime

mcp = FastMCP("aws-extended-support-calculator")

CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache')
CACHE_TTL_HOURS = 24

ENGINE_MAPPING = {
    'mysql': 'MySQL', 'postgres': 'PostgreSQL', 'postgresql': 'PostgreSQL',
    'aurora-mysql': 'Aurora-MySQL', 'aurora-postgresql': 'Aurora-PostgreSQL',
    'aurora': 'Aurora-MySQL',
}

# ---------------------------------------------------------------------------
# ElastiCache Extended Support - Static Data
# ---------------------------------------------------------------------------

# Source: https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/extended-support-versions.html
ELASTICACHE_EXTENDED_SUPPORT = {
    "4": {"std_end": "2026-01-31", "ext_start": "2026-02-01", "ext_end": "2029-01-31",
          "y1_start": "2026-02-01", "y2_start": "2027-02-01", "y3_start": "2028-02-01"},
    "5": {"std_end": "2026-01-31", "ext_start": "2026-02-01", "ext_end": "2029-01-31",
          "y1_start": "2026-02-01", "y2_start": "2027-02-01", "y3_start": "2028-02-01"},
    "6": {"std_end": "2027-01-31", "ext_start": "2027-02-01", "ext_end": "2030-01-31",
          "y1_start": "2027-02-01", "y2_start": "2028-02-01", "y3_start": "2029-02-01"},
}

# ---------------------------------------------------------------------------
# OpenSearch Extended Support - Static Data
# ---------------------------------------------------------------------------

# Instance size normalization factors for NIH calculation
OPENSEARCH_NIH_NORMALIZATION = {
    "nano": 0.25, "micro": 0.5, "small": 1, "medium": 2, "large": 4,
    "xlarge": 8, "2xlarge": 16, "4xlarge": 32, "8xlarge": 64,
    "9xlarge": 72, "10xlarge": 80, "12xlarge": 96, "16xlarge": 128, "18xlarge": 144,
}

# OpenSearch/Elasticsearch extended support version dates
# Source: https://docs.aws.amazon.com/opensearch-service/latest/developerguide/what-is.html#choosing-version
OPENSEARCH_EXTENDED_SUPPORT_VERSIONS = {
    "Elasticsearch 1.5": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 2.3": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 5.1": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 5.3": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 5.5": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 5.6": {"std_end": "2025-11-07", "ext_end": "2028-11-07"},
    "Elasticsearch 6.0": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 6.2": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 6.3": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 6.4": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 6.5": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 6.7": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 7.1": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 7.4": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 7.7": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "Elasticsearch 7.8": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 1.0": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 1.1": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 1.2": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 2.3": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 2.5": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 2.7": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
    "OpenSearch 2.9": {"std_end": "2025-11-07", "ext_end": "2026-11-07"},
}

# ---------------------------------------------------------------------------
# DocumentDB Extended Support - Static Data
# Source: https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html
# Source: https://docs.aws.amazon.com/documentdb/latest/developerguide/docdb-engine-version-supportability.html
# ---------------------------------------------------------------------------

DOCUMENTDB_EXTENDED_SUPPORT = {
    "3.6": {
        "std_end": "2026-03-30",
        "ext_start": "2026-03-31",         # Extended support enrollment starts
        "ext_billing_start": "2026-07-01",  # Billing starts (3-month grace period)
        "ext_y2_start": "2027-02-01",       # Year 2 premium starts (based on pricing example)
        "ext_y3_start": "2028-03-31",       # Year 3 premium starts
        "ext_end": "2029-03-30",
    },
}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _cache_path(name):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, name)

def _cache_is_fresh(path):
    if not os.path.exists(path):
        return False
    return (time.time() - os.path.getmtime(path)) / 3600 < CACHE_TTL_HOURS

def _read_cache(path):
    with open(path, 'r') as f:
        return json.load(f)

def _write_cache(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def _cache_age_str(path):
    if not os.path.exists(path):
        return "not cached"
    age_hours = (time.time() - os.path.getmtime(path)) / 3600
    if age_hours < 1: return f"{int(age_hours * 60)} minutes ago"
    if age_hours < 24: return f"{age_hours:.1f} hours ago"
    return f"{age_hours / 24:.1f} days ago"


# ---------------------------------------------------------------------------
# Data fetchers (auto-download + cache)
# ---------------------------------------------------------------------------

def fetch_rds_pricing():
    cache = _cache_path('rds_extended_support_pricing.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import requests
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonRDS/current/index.json"
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    pricing_data = resp.json()
    products = pricing_data.get('products', {})
    terms = pricing_data.get('terms', {}).get('OnDemand', {})
    records = []
    for sku, product_info in products.items():
        attrs = product_info.get('attributes', {})
        usage_type = attrs.get('usagetype', '')
        if 'ExtendedSupport' not in usage_type:
            continue
        sku_terms = terms.get(sku, {})
        for term_data in sku_terms.values():
            for dim_data in term_data.get('priceDimensions', {}).values():
                records.append({
                    'usage_type': usage_type, 'sku': sku,
                    'region_code': attrs.get('regionCode', 'N/A'),
                    'database_engine': attrs.get('databaseEngine', 'N/A'),
                    'engine_major_version': attrs.get('engineMajorVersion', 'N/A'),
                    'extended_support_year': attrs.get('extendedSupportPricingYear', 'N/A'),
                    'price_per_unit_usd': dim_data.get('pricePerUnit', {}).get('USD', '0'),
                    'unit': dim_data.get('unit', 'N/A'),
                    'description': dim_data.get('description', 'N/A'),
                })
    _write_cache(cache, records)
    return records

def fetch_elasticache_pricing():
    cache = _cache_path('elasticache_pricing.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import requests
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonElastiCache/current/index.json"
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    pricing_data = resp.json()
    products = pricing_data.get('products', {})
    terms = pricing_data.get('terms', {}).get('OnDemand', {})
    price_map = {}
    for sku, product_info in products.items():
        attrs = product_info.get('attributes', {})
        if attrs.get('cacheEngine', '').lower() != 'redis':
            continue
        usage_type = attrs.get('usagetype', '')
        if 'NodeUsage' not in usage_type and 'Cache' not in usage_type:
            continue
        region = attrs.get('regionCode', '')
        instance_type = attrs.get('instanceType', '')
        if not region or not instance_type:
            continue
        sku_terms = terms.get(sku, {})
        for term_data in sku_terms.values():
            for dim_data in term_data.get('priceDimensions', {}).values():
                price = float(dim_data.get('pricePerUnit', {}).get('USD', '0'))
                if price > 0:
                    key = f"{region}|{instance_type}"
                    if key not in price_map or price < price_map[key]:
                        price_map[key] = price
    _write_cache(cache, price_map)
    return price_map


def fetch_documentdb_pricing():
    """Fetch DocumentDB extended support pricing from the AWS pricing API.

    Source: https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDocDB/current/index.json
    Pricing is per-vCPU-hour, same model as RDS.
    """
    cache = _cache_path('documentdb_extended_support_pricing.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import requests
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDocDB/current/index.json"
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    pricing_data = resp.json()
    products = pricing_data.get('products', {})
    terms = pricing_data.get('terms', {}).get('OnDemand', {})
    records = []
    for sku, product_info in products.items():
        attrs = product_info.get('attributes', {})
        usage_type = attrs.get('usagetype', '')
        if 'ExtendedSupport' not in usage_type:
            continue
        # Extract extended support year from usagetype (e.g. "EU-ExtendedSupport-Y3-db.r4.2xlarge-3.6")
        extended_support_year = ''
        for part in usage_type.split('-'):
            if part in ('Y1', 'Y2', 'Y3'):
                extended_support_year = part
                break
        # Extract instance type from usagetype
        instance_type = ''
        if 'db.' in usage_type:
            # Find the db.xxx.yyy portion
            parts = usage_type.split('-')
            for i, p in enumerate(parts):
                if p.startswith('db.'):
                    instance_type = p
                    break
                elif i > 0 and parts[i-1].startswith('db'):
                    instance_type = f"{parts[i-1]}.{p}"
                    break
            if not instance_type:
                # Try joining db parts
                for i, p in enumerate(parts):
                    if 'db.' in p:
                        instance_type = p
                        break
        sku_terms = terms.get(sku, {})
        for term_data in sku_terms.values():
            for dim_data in term_data.get('priceDimensions', {}).values():
                records.append({
                    'usage_type': usage_type,
                    'sku': sku,
                    'region_code': attrs.get('regionCode', 'N/A'),
                    'extended_support_year': extended_support_year,
                    'price_per_unit_usd': dim_data.get('pricePerUnit', {}).get('USD', '0'),
                    'unit': dim_data.get('unit', 'N/A'),
                    'instance_type': instance_type or attrs.get('instanceType', ''),
                    'description': dim_data.get('description', 'N/A'),
                })
    _write_cache(cache, records)
    return records


def fetch_vcpu_data():
    cache = _cache_path('ec2_vcpu_data.json')
    if _cache_is_fresh(cache):
        return _build_vcpu_map(_read_cache(cache))
    import boto3
    ec2 = boto3.client('ec2', region_name='us-east-1')
    paginator = ec2.get_paginator('describe_instance_types')
    items = []
    for page in paginator.paginate():
        for it in page['InstanceTypes']:
            items.append({'InstanceType': it['InstanceType'], 'VcpuCount': it['VCpuInfo']['DefaultVCpus']})
    _write_cache(cache, items)
    return _build_vcpu_map(items)


def _build_vcpu_map(data):
    vcpu_map = {}
    for item in data:
        t, v = item['InstanceType'], item['VcpuCount']
        vcpu_map[t] = v
        vcpu_map[f"db.{t}"] = v
    return vcpu_map


def fetch_extended_support_versions():
    cache = _cache_path('extended_support_versions.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache).get('versions', {})
    import boto3
    rds = boto3.client('rds')
    engines = {'postgres': 'PostgreSQL', 'mysql': 'MySQL',
               'aurora-postgresql': 'Aurora PostgreSQL', 'aurora-mysql': 'Aurora MySQL'}
    config = {"last_updated": datetime.now().strftime("%Y-%m-%d"), "versions": {}}
    for engine_id, engine_name in engines.items():
        config["versions"][engine_name] = {}
        try:
            resp = rds.describe_db_major_engine_versions(Engine=engine_id)
            for vi in resp.get('DBMajorEngineVersions', []):
                mv = vi.get('MajorEngineVersion', '')
                lifecycles = vi.get('SupportedEngineLifecycles', [])
                if not mv or not lifecycles:
                    continue
                std_end = ext_start = ext_end = None
                for lc in lifecycles:
                    name = lc.get('LifecycleSupportName', '')
                    if 'standard-support' in name:
                        d = lc.get('LifecycleSupportEndDate')
                        if d: std_end = d.strftime('%Y-%m-%d')
                    elif 'extended-support' in name:
                        d = lc.get('LifecycleSupportStartDate')
                        if d: ext_start = d.strftime('%Y-%m-%d')
                        d = lc.get('LifecycleSupportEndDate')
                        if d: ext_end = d.strftime('%Y-%m-%d')
                if ext_end and std_end:
                    std_dt = datetime.strptime(std_end, '%Y-%m-%d')
                    ext_dt = datetime.strptime(ext_end, '%Y-%m-%d')
                    years_diff = ext_dt.year - std_dt.year
                    if ext_dt.month < std_dt.month: years_diff -= 1
                    years = list(range(1, min(years_diff + 1, 4)))
                    status = "In Extended Support" if std_dt < datetime.now() else "Future Extended Support"
                    config["versions"][engine_name][mv] = {
                        "end_of_standard_support": std_end, "extended_support_start": ext_start,
                        "extended_support_end": ext_end, "extended_support_years": years, "status": status}
        except Exception as e:
            import sys
            print(f"⚠ Failed to fetch versions for {engine_id}: {e}", file=sys.stderr)
    _write_cache(cache, config)
    return config.get('versions', {})


def fetch_eks_versions():
    """Fetch EKS cluster version lifecycle data from the EKS API."""
    cache = _cache_path('eks_versions.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import boto3
    eks = boto3.client('eks', region_name='us-east-1')
    try:
        resp = eks.describe_cluster_versions()
    except Exception:
        # Fallback: return empty if API not available
        if os.path.exists(cache):
            return _read_cache(cache)
        return {}
    versions = {}
    for cv in resp.get('clusterVersions', []):
        ver = cv.get('clusterVersion', '')
        if not ver:
            continue
        eos = cv.get('endOfStandardSupportDate')
        eoes = cv.get('endOfExtendedSupportDate')
        status = cv.get('status', '')
        eos_str = eos.strftime('%Y-%m-%d') if eos else ''
        eoes_str = eoes.strftime('%Y-%m-%d') if eoes else ''
        # extended_support_start is the day after end_of_standard_support
        ext_start_str = eos_str  # use same date for simplicity as specified
        versions[ver] = {
            "end_of_standard_support": eos_str,
            "extended_support_start": ext_start_str,
            "extended_support_end": eoes_str,
            "status": status,
        }
    _write_cache(cache, versions)
    return versions


def fetch_opensearch_nih_rates():
    """Fetch OpenSearch extended support NIH rates per region from the public pricing API."""
    cache = _cache_path('opensearch_nih_rates.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import requests
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonES/current/index.json"
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    data = resp.json()
    products = data.get('products', {})
    terms = data.get('terms', {}).get('OnDemand', {})
    rates = {}
    for sku, prod in products.items():
        attrs = prod.get('attributes', {})
        if 'extended' not in attrs.get('usagetype', '').lower():
            continue
        region = attrs.get('regionCode', '')
        if not region:
            continue
        sku_terms = terms.get(sku, {})
        for td in sku_terms.values():
            for dd in td.get('priceDimensions', {}).values():
                price = float(dd.get('pricePerUnit', {}).get('USD', '0'))
                if price > 0:
                    rates[region] = price
    _write_cache(cache, rates)
    return rates


def fetch_eks_extended_support_rate():
    """Fetch EKS extended support additional hourly rate from the public pricing API."""
    cache = _cache_path('eks_extended_support_rate.json')
    if _cache_is_fresh(cache):
        return _read_cache(cache)
    import requests
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEKS/current/index.json"
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    data = resp.json()
    products = data.get('products', {})
    terms = data.get('terms', {}).get('OnDemand', {})
    rates = {}
    for sku, prod in products.items():
        attrs = prod.get('attributes', {})
        if 'extended' not in attrs.get('usagetype', '').lower():
            continue
        region = attrs.get('regionCode', '')
        if not region:
            continue
        sku_terms = terms.get(sku, {})
        for td in sku_terms.values():
            for dd in td.get('priceDimensions', {}).values():
                price = float(dd.get('pricePerUnit', {}).get('USD', '0'))
                if price > 0:
                    rates[region] = price
    _write_cache(cache, rates)
    return rates


# ---------------------------------------------------------------------------
# Shared calculation helpers
# ---------------------------------------------------------------------------

def _get_vcpu_count(instance_type, vcpu_map):
    if instance_type.lower() == 'db.serverless':
        return 1
    for c in [instance_type, instance_type.lower(), f"db.{instance_type}",
              instance_type[3:] if instance_type.startswith('db.') else None]:
        if c and c in vcpu_map:
            return vcpu_map[c]
    return None

def _normalize_engine(engine):
    return ENGINE_MAPPING.get(engine.lower())

def _find_rds_rate(pricing_data, engine, region, year):
    for rec in pricing_data:
        usage_type = rec.get('usage_type', '')
        rec_region = rec.get('region_code', '')
        db_engine = rec.get('database_engine', '')
        ext_year = rec.get('extended_support_year', '')
        year_match = (f'Year{year}' in usage_type or f'Yr{year}' in usage_type or ext_year == f'Year {year}')
        if not year_match: continue
        eng_norm = engine.replace('-', '').lower()
        usage_norm = usage_type.replace('-', '').replace('_', '').lower()
        db_eng_norm = db_engine.replace(' ', '').replace('-', '').lower()
        if eng_norm not in usage_norm and eng_norm not in db_eng_norm: continue
        if rec_region.lower() != region.lower(): continue
        return float(rec.get('price_per_unit_usd', 0))
    return None

def _rds_cost_breakdown(vcpus, rate, multi_az_multiplier=1):
    hourly = vcpus * rate * multi_az_multiplier
    return {'hourly': round(hourly, 6), 'monthly': round(hourly * 730, 2), 'yearly': round(hourly * 8760, 2)}

def _parse_engine_from_csv(db_engine):
    el = db_engine.lower()
    if 'aurora mysql' in el or 'aurora-mysql' in el: return 'aurora-mysql'
    if 'aurora postgresql' in el or 'aurora-postgresql' in el or 'aurora postgres' in el: return 'aurora-postgresql'
    if 'mysql' in el: return 'mysql'
    if 'postgres' in el: return 'postgres'
    return None

def _extract_major_version(version_string):
    if not version_string: return None
    version = version_string.split('.mysql_aurora')[0]
    parts = version.split('.')
    if len(parts) >= 2:
        if parts[0] in ['5', '8']: return f"{parts[0]}.{parts[1]}"
        return parts[0]
    return parts[0] if parts else None

def _is_on_extended_support(engine, version_string, ext_versions):
    if not version_string or not ext_versions: return False, None, []
    engine_key_map = {'mysql': 'MySQL', 'postgres': 'PostgreSQL', 'postgresql': 'PostgreSQL',
                      'aurora-mysql': 'Aurora MySQL', 'aurora-postgresql': 'Aurora PostgreSQL'}
    engine_key = engine_key_map.get(engine.lower())
    if not engine_key: return False, None, []
    major = _extract_major_version(version_string)
    if not major: return False, None, []
    info = ext_versions.get(engine_key, {}).get(major)
    if info: return True, major, info.get('extended_support_years', [])
    return False, major, []

def _detect_csv_columns(header):
    mapping = {}
    hl_map = {h: h.lower().strip() for h in header}
    checks = {
        'instance_name': ['instance name', 'dbinstanceid', 'instance_name', 'db instance', 'identifier', 'label'],
        'instance_type': ['instance type', 'instancetype', 'instance_type', 'dbinstanceclass', 'class', 'node type', 'cachenodetype'],
        'engine': ['db engine', 'engine', 'database_engine', 'databaseengine'],
        'version': ['engine version', 'engineversion', 'engine full version', 'engine_full_version', 'enginefullversion'],
        'region': ['instance region', 'region', 'regioncode', 'region_code'],
        'multi_az': ['multi-az', 'multi_az', 'multiaz', 'maz flag'],
    }
    for field, keywords in checks.items():
        for h, hl in hl_map.items():
            if any(k == hl for k in keywords):
                mapping[field] = h
                break
        if field not in mapping:
            # Fallback: substring match but exclude false positives
            for h, hl in hl_map.items():
                if field == 'region' and ('az' in hl or 'maz' in hl) and 'region' not in hl:
                    continue  # skip MAZ Flag, availability zone columns for region
                if any(k in hl for k in keywords):
                    mapping[field] = h
                    break
    return mapping

def _get_opensearch_nih_factor(instance_type):
    """Extract normalization factor from instance type like m7g.medium.search."""
    parts = instance_type.replace('.search', '').split('.')
    if len(parts) >= 2:
        size = parts[-1]
        return OPENSEARCH_NIH_NORMALIZATION.get(size)
    return None

def _get_opensearch_version_key(engine_version):
    """Map a version string to the OPENSEARCH_EXTENDED_SUPPORT_VERSIONS key."""
    if not engine_version:
        return None
    v = str(engine_version).strip()
    for key in OPENSEARCH_EXTENDED_SUPPORT_VERSIONS:
        prefix, ver = key.split(' ', 1)
        if prefix.lower() == 'elasticsearch' and v == ver:
            return key
        if prefix.lower() == 'opensearch' and v == ver:
            return key
    parts = v.split('.')
    if len(parts) >= 2:
        short = f"{parts[0]}.{parts[1]}"
        for key in OPENSEARCH_EXTENDED_SUPPORT_VERSIONS:
            if key.endswith(f" {short}"):
                return key
    if len(parts) >= 1:
        for key in OPENSEARCH_EXTENDED_SUPPORT_VERSIONS:
            if key.endswith(f" {parts[0]}"):
                return key
    return None


def _parse_date_field(value):
    """Parse a date from a CSV field that may contain a raw date string or embedded badge JSON.

    Handles:
      - Plain date strings like "March 23, 2026" or "2026-03-23"
      - Badge JSON like "{'__type': 'badge', 'value': 'March 23, 2026', 'options': {'color': 'red'}}"
    Returns a datetime or None.
    """
    if not value or not str(value).strip():
        return None
    val = str(value).strip()
    # Try to extract from badge-like dict string
    if '{' in val and 'value' in val:
        try:
            import ast
            parsed = ast.literal_eval(val)
            if isinstance(parsed, dict) and 'value' in parsed:
                val = str(parsed['value']).strip()
        except (ValueError, SyntaxError):
            # Try regex fallback for 'value': '...'
            import re
            m = re.search(r"'value'\s*:\s*'([^']+)'", val)
            if m:
                val = m.group(1).strip()
    # Try common date formats
    for fmt in ('%B %d, %Y', '%b %d, %Y', '%Y-%m-%d', '%m/%d/%Y', '%d-%b-%Y'):
        try:
            return datetime.strptime(val, fmt)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# Helper: _compute_rds_year_cost
# ---------------------------------------------------------------------------

def _compute_rds_year_cost(pricing, normalized, region, vcpus, maz_mult, ext_start, avail_years, target_year):
    """Compute RDS extended support cost for a specific calendar year, month by month."""
    total = 0
    if not ext_start:
        return 0
    try:
        es = datetime.strptime(ext_start, '%Y-%m-%d')
        for m in range(1, 13):
            ms = datetime(target_year, m, 1)
            months_since = (ms.year - es.year) * 12 + (ms.month - es.month)
            if months_since < 0:
                continue
            if months_since < 12: yr_num = 1
            elif months_since < 24: yr_num = 2
            else: yr_num = 3
            if avail_years and yr_num not in avail_years:
                if any(y <= yr_num for y in avail_years):
                    yr_num = max(y for y in avail_years if y <= yr_num)
                else:
                    continue
            rate = _find_rds_rate(pricing, normalized, region, yr_num)
            if rate:
                total += round(vcpus * rate * maz_mult * 730, 2)
    except ValueError:
        pass
    return total


# ---------------------------------------------------------------------------
# Helper: DocumentDB cost calculation
# ---------------------------------------------------------------------------

def _find_documentdb_rate(pricing_data, region, year):
    """Find the per-vCPU-hour rate for DocumentDB extended support in a given region and year.

    The usagetype format is like: EU-ExtendedSupport-Y3-db.r4.2xlarge-3.6
    We extract the year from Y1/Y2/Y3 in the usagetype.
    """
    year_key = f"Y{year}"
    for rec in pricing_data:
        usage_type = rec.get('usage_type', '')
        rec_region = rec.get('region_code', '')
        rec_year = rec.get('extended_support_year', '')
        if rec_region.lower() != region.lower():
            continue
        if rec_year != year_key and year_key not in usage_type:
            continue
        price = float(rec.get('price_per_unit_usd', '0'))
        if price > 0:
            return price
    return None


def _compute_documentdb_year_cost(pricing, region, vcpus, maz_mult, target_year):
    """Compute DocumentDB extended support cost for a specific calendar year, month by month.

    Uses DOCUMENTDB_EXTENDED_SUPPORT dates for version 3.6:
    - Before ext_billing_start: $0 (grace period)
    - ext_billing_start to ext_y2_start: Year 1 rate (80% premium)
    - ext_y2_start to ext_y3_start: Year 2 rate (80% premium)
    - ext_y3_start to ext_end: Year 3 rate (160% premium)

    Year determination uses months_since ext_billing_start:
    - 0-11 months = Y1, 12-23 = Y2, 24+ = Y3
    """
    ver_info = DOCUMENTDB_EXTENDED_SUPPORT.get("3.6")
    if not ver_info:
        return 0
    total = 0.0
    try:
        billing_start = datetime.strptime(ver_info["ext_billing_start"], '%Y-%m-%d')
        ext_end = datetime.strptime(ver_info["ext_end"], '%Y-%m-%d')
        for m in range(1, 13):
            ms = datetime(target_year, m, 1)
            # Before billing starts or after ext support ends: $0
            if ms < billing_start or ms > ext_end:
                continue
            # Determine year based on months since billing start
            months_since = (ms.year - billing_start.year) * 12 + (ms.month - billing_start.month)
            if months_since < 12:
                yr_num = 1
            elif months_since < 24:
                yr_num = 2
            else:
                yr_num = 3
            rate = _find_documentdb_rate(pricing, region, yr_num)
            if rate:
                total += round(vcpus * rate * maz_mult * 730, 2)
    except ValueError:
        pass
    return total


# ---------------------------------------------------------------------------
# MCP Tools - Single instance calculations
# ---------------------------------------------------------------------------

@mcp.tool()
def rds_cost(instance_type: str, engine: str, region: str, multi_az: bool = False) -> str:
    """Calculate RDS/Aurora extended support cost for a single instance.

    Args:
        instance_type: e.g. "db.r5.xlarge" or "db.serverless"
        engine: "mysql", "postgres", "aurora-mysql", or "aurora-postgresql"
        region: AWS region code, e.g. "us-east-1"
        multi_az: True if Multi-AZ deployment (doubles cost)
    """
    normalized = _normalize_engine(engine)
    if not normalized:
        return json.dumps({"error": f"Unsupported engine '{engine}'. Use: mysql, postgres, aurora-mysql, aurora-postgresql"})
    vcpu_map = fetch_vcpu_data()
    vcpus = _get_vcpu_count(instance_type, vcpu_map)
    if vcpus is None:
        return json.dumps({"error": f"Unknown instance type '{instance_type}'. Could not determine vCPU count."})
    pricing = fetch_rds_pricing()
    maz_mult = 2 if multi_az else 1
    years = {}
    total_3year = 0
    for yr in [1, 2, 3]:
        rate = _find_rds_rate(pricing, normalized, region, yr)
        if rate is None:
            years[f"year{yr}"] = {"note": f"No pricing found for {normalized} Year {yr} in {region}"}
            continue
        costs = _rds_cost_breakdown(vcpus, rate, maz_mult)
        years[f"year{yr}"] = {"per_vcpu_hourly_rate": rate, **costs}
        total_3year += costs['yearly']
    is_serverless = instance_type.lower() == 'db.serverless'
    return json.dumps({"instance_type": instance_type, "engine": normalized, "region": region,
        "vcpus": vcpus, "unit": "ACU" if is_serverless else "vCPU", "multi_az": multi_az,
        "effective_vcpus": vcpus * maz_mult, **years, "total_3_year_cost": round(total_3year, 2)}, indent=2)


@mcp.tool()
def elasticache_cost(instance_type: str, region: str, num_nodes: int = 1) -> str:
    """Calculate ElastiCache Redis extended support cost.

    Only Redis OSS 4.x and 5.x are eligible. Premium is 80% of on-demand price for Years 1-2, 160% for Year 3.

    Args:
        instance_type: e.g. "cache.r5.large"
        region: AWS region code
        num_nodes: Number of cache nodes
    """
    price_map = fetch_elasticache_pricing()
    key = f"{region}|{instance_type}"
    base_price = price_map.get(key)
    if base_price is None and not instance_type.startswith('cache.'):
        base_price = price_map.get(f"{region}|cache.{instance_type}")
    if base_price is None:
        return json.dumps({"error": f"No on-demand pricing found for {instance_type} in {region}."})
    premiums = {1: 0.80, 2: 0.80, 3: 1.60}
    years = {}
    total_3year = 0
    for yr, pct in premiums.items():
        premium_hourly = base_price * pct * num_nodes
        monthly = round(premium_hourly * 730, 2)
        yearly = round(premium_hourly * 8760, 2)
        years[f"year{yr}"] = {"on_demand_hourly_per_node": round(base_price, 6),
            "premium_pct": f"{int(pct * 100)}%", "extended_support_hourly_total": round(premium_hourly, 6),
            "monthly": monthly, "yearly": yearly}
        total_3year += yearly
    return json.dumps({"instance_type": instance_type, "region": region, "num_nodes": num_nodes,
        "eligible_versions": "Redis OSS 4.x, 5.x", **years, "total_3_year_cost": round(total_3year, 2)}, indent=2)


@mcp.tool()
def eks_cost(num_clusters: int = 1, months_in_extended_support: int = 12) -> str:
    """Calculate EKS extended support cost. Standard=$0.10/cluster/hour, Extended=$0.60/cluster/hour.

    Args:
        num_clusters: Number of EKS clusters
        months_in_extended_support: Months in extended support (1-12)
    """
    months = min(max(months_in_extended_support, 1), 12)
    std_hourly, ext_hourly = 0.10, 0.60
    hours = months * 730
    std_cost = round(std_hourly * hours * num_clusters, 2)
    ext_cost = round(ext_hourly * hours * num_clusters, 2)
    return json.dumps({"num_clusters": num_clusters, "months": months,
        "standard_hourly_per_cluster": std_hourly, "extended_hourly_per_cluster": ext_hourly,
        "standard_monthly_per_cluster": round(std_hourly * 730, 2),
        "extended_monthly_per_cluster": round(ext_hourly * 730, 2),
        "total_standard_cost": std_cost, "total_extended_cost": ext_cost,
        "additional_cost_over_standard": round(ext_cost - std_cost, 2)}, indent=2)


@mcp.tool()
def opensearch_cost(instance_type: str, region: str, num_nodes: int = 1, engine_version: str = "") -> str:
    """Calculate OpenSearch/Elasticsearch extended support cost.

    Pricing is a flat fee per Normalized Instance Hour (NIH). NIH = normalization_factor x instance_hours.
    Normalization factor is based on instance size (e.g. medium=2, large=4, xlarge=8).

    Args:
        instance_type: e.g. "m7g.medium.search", "r6g.xlarge.search"
        region: AWS region code, e.g. "us-east-1"
        num_nodes: Number of data nodes
        engine_version: e.g. "7.10", "2.9", "6.8" (optional, for version eligibility check)
    """
    nih_rates = fetch_opensearch_nih_rates()
    nih_rate = nih_rates.get(region)
    if nih_rate is None:
        return json.dumps({"error": f"No OpenSearch extended support pricing for region {region}"})
    norm_factor = _get_opensearch_nih_factor(instance_type)
    if norm_factor is None:
        return json.dumps({"error": f"Cannot determine normalization factor for {instance_type}. Expected format: <family>.<size>.search"})
    version_info = None
    if engine_version:
        version_key = _get_opensearch_version_key(engine_version)
        if version_key:
            version_info = OPENSEARCH_EXTENDED_SUPPORT_VERSIONS[version_key]
        else:
            return json.dumps({"warning": f"Version {engine_version} not found in extended support schedule. It may still be in standard support or not yet announced."})
    hourly_per_node = nih_rate * norm_factor
    hourly_total = hourly_per_node * num_nodes
    monthly = round(hourly_total * 730, 2)
    yearly = round(hourly_total * 8760, 2)
    result = {
        "instance_type": instance_type, "region": region, "num_nodes": num_nodes,
        "nih_rate": nih_rate, "normalization_factor": norm_factor,
        "extended_support_hourly_per_node": round(hourly_per_node, 6),
        "extended_support_hourly_total": round(hourly_total, 6),
        "monthly": monthly, "yearly": yearly,
        "formula": f"${nih_rate}/NIH x {norm_factor} (norm factor) x hours x {num_nodes} nodes",
    }
    if version_info:
        result["standard_support_end"] = version_info["std_end"]
        result["extended_support_end"] = version_info["ext_end"]
    if engine_version:
        result["engine_version"] = engine_version
    return json.dumps(result, indent=2)


@mcp.tool()
def documentdb_cost(instance_type: str, region: str, multi_az: bool = False) -> str:
    """Calculate DocumentDB extended support cost for a single instance.

    Only DocumentDB 3.6 is eligible. Pricing is per-vCPU-hour (same model as RDS).
    Year 1-2: 80% premium. Year 3: 160% premium.
    Note: 3-month grace period — std support ends Mar 30, 2026, billing starts Jul 1, 2026.

    Source: https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html

    Args:
        instance_type: e.g. "db.r5.xlarge", "db.r6g.large"
        region: AWS region code, e.g. "us-east-1"
        multi_az: True if Multi-AZ deployment (doubles cost)
    """
    vcpu_map = fetch_vcpu_data()
    vcpus = _get_vcpu_count(instance_type, vcpu_map)
    if vcpus is None:
        return json.dumps({"error": f"Unknown instance type '{instance_type}'. Could not determine vCPU count."})
    pricing = fetch_documentdb_pricing()
    maz_mult = 2 if multi_az else 1
    years = {}
    total = 0
    for yr in [1, 2, 3]:
        rate = _find_documentdb_rate(pricing, region, yr)
        if rate is None:
            years[f"year{yr}"] = {"note": f"No pricing found for DocumentDB Year {yr} in {region}"}
            continue
        hourly = vcpus * rate * maz_mult
        monthly = round(hourly * 730, 2)
        yearly = round(hourly * 8760, 2)
        years[f"year{yr}"] = {"per_vcpu_hourly_rate": rate, "hourly": round(hourly, 6), "monthly": monthly, "yearly": yearly}
        total += yearly
    ver_info = DOCUMENTDB_EXTENDED_SUPPORT["3.6"]
    return json.dumps({"instance_type": instance_type, "engine": "DocumentDB 3.6", "region": region,
        "vcpus": vcpus, "multi_az": multi_az, "effective_vcpus": vcpus * maz_mult,
        "std_end": ver_info["std_end"], "ext_start": ver_info["ext_start"],
        "ext_billing_start": ver_info["ext_billing_start"], "ext_end": ver_info["ext_end"],
        **years, "total_3_year_cost": round(total, 2),
        "note": "3-month grace period: billing starts Jul 1, 2026 (not Mar 31, 2026)"}, indent=2)


# ---------------------------------------------------------------------------
# MCP Tools - Batch CSV calculations
# ---------------------------------------------------------------------------

@mcp.tool()
def rds_report(csv_path: str, output_dir: str = "") -> str:
    """Process a CSV inventory of RDS/Aurora instances and calculate extended support costs.

    Auto-detects columns (case-insensitive). Skips instances not eligible for extended support.
    If output_dir is provided, saves a CSV and HTML report with engine/version breakdown.

    Args:
        csv_path: Absolute path to the CSV file
        output_dir: Directory to save report files (optional — if empty, returns JSON only)
    """
    if not os.path.exists(csv_path):
        return json.dumps({"error": f"File not found: {csv_path}"})
    pricing = fetch_rds_pricing()
    vcpu_map = fetch_vcpu_data()
    ext_versions = fetch_extended_support_versions()
    current_year = datetime.now().year
    next_year = current_year + 1

    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        col_map = _detect_csv_columns(reader.fieldnames or [])
        results, skipped, errors = [], [], []
        for idx, row in enumerate(reader, start=2):
            name = row.get(col_map.get('instance_name', ''), f'row-{idx}').strip()
            inst_type = row.get(col_map.get('instance_type', ''), '').strip()
            raw_engine = row.get(col_map.get('engine', ''), '').strip()
            version = row.get(col_map.get('version', ''), '').strip()
            region = row.get(col_map.get('region', ''), '').strip()
            maz_raw = row.get(col_map.get('multi_az', ''), '').strip()
            if not inst_type or not raw_engine or not region:
                errors.append({"row": idx, "name": name, "error": "Missing instance type, engine, or region"})
                continue
            engine = _parse_engine_from_csv(raw_engine)
            if not engine:
                skipped.append({"row": idx, "name": name, "engine": raw_engine, "reason": "Unsupported engine"})
                continue
            eligible, major, avail_years = _is_on_extended_support(engine, version, ext_versions)
            if not eligible:
                skipped.append({"row": idx, "name": name, "engine": raw_engine, "version": version, "major_version": major, "reason": "Not on extended support"})
                continue
            normalized = _normalize_engine(engine)
            if not normalized:
                errors.append({"row": idx, "name": name, "error": f"Cannot normalize engine: {engine}"})
                continue
            is_serverless = inst_type.lower() == 'db.serverless'
            vcpus = 1 if is_serverless else _get_vcpu_count(inst_type, vcpu_map)
            if vcpus is None:
                errors.append({"row": idx, "name": name, "error": f"Unknown instance type: {inst_type}"})
                continue
            is_maz = str(maz_raw).upper().strip() in ['MAZ', 'MULTI-AZ', 'YES', 'TRUE']
            maz_mult = 2 if is_maz else 1

            # Get version lifecycle info
            engine_key_map = {'mysql': 'MySQL', 'postgres': 'PostgreSQL', 'postgresql': 'PostgreSQL',
                              'aurora-mysql': 'Aurora MySQL', 'aurora-postgresql': 'Aurora PostgreSQL'}
            ek = engine_key_map.get(engine.lower(), '')
            info = ext_versions.get(ek, {}).get(major, {})
            ext_start = info.get('extended_support_start', '')

            # Compute costs using shared helper
            cy_cost = _compute_rds_year_cost(pricing, normalized, region, vcpus, maz_mult, ext_start, avail_years, current_year)
            ny_cost = _compute_rds_year_cost(pricing, normalized, region, vcpus, maz_mult, ext_start, avail_years, next_year)

            # Year 1 annual (full year at year 1 rate)
            rate_y1 = _find_rds_rate(pricing, normalized, region, 1)
            y1_annual = round(vcpus * rate_y1 * maz_mult * 8760, 2) if rate_y1 else 0

            results.append({"name": name, "instance_type": inst_type, "vcpus": vcpus,
                "engine": raw_engine, "version": version, "major_version": major,
                "region": region, "multi_az": is_maz,
                "current_year_cost": round(cy_cost, 2), "next_year_cost": round(ny_cost, 2),
                "y1_annual": y1_annual, "ext_start": ext_start,
                "ext_end": info.get("extended_support_end", ""),
                "status": info.get("status", "")})

    # Aggregations
    total_current = sum(r['current_year_cost'] for r in results)
    total_next = sum(r['next_year_cost'] for r in results)

    by_region = {}
    for r in results:
        by_region.setdefault(r['region'], {"count": 0, "current_year_cost": 0, "next_year_cost": 0})
        by_region[r['region']]["count"] += 1
        by_region[r['region']]["current_year_cost"] += r['current_year_cost']
        by_region[r['region']]["next_year_cost"] += r['next_year_cost']

    # Build engine+version summary
    by_engine_version = {}
    for r in results:
        key = f"{r['engine']} {r['major_version']}"
        if key not in by_engine_version:
            by_engine_version[key] = {"count": 0, "current_year_cost": 0, "next_year_cost": 0,
                "y1_cost": 0, "status": r["status"], "ext_start": r["ext_start"], "ext_end": r["ext_end"]}
        by_engine_version[key]["count"] += 1
        by_engine_version[key]["current_year_cost"] += r["current_year_cost"]
        by_engine_version[key]["next_year_cost"] += r["next_year_cost"]
        by_engine_version[key]["y1_cost"] += r["y1_annual"]

    # Categorize versions into 4 buckets based on ext_start vs today
    today = datetime.now()
    already_in_ext = {}
    entering_this_year = {}
    entering_next_year = {}
    future_beyond = {}
    for k, v in by_engine_version.items():
        ext_start_str = v.get("ext_start", "")
        if ext_start_str:
            try:
                es = datetime.strptime(ext_start_str, '%Y-%m-%d')
                if es <= today:
                    already_in_ext[k] = v
                elif es.year == current_year:
                    entering_this_year[k] = v
                elif es.year == next_year:
                    entering_next_year[k] = v
                else:
                    future_beyond[k] = v
            except ValueError:
                future_beyond[k] = v
        else:
            future_beyond[k] = v

    # Write reports if output_dir provided
    report_files = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(csv_path))[0]

        # CSV report
        csv_out = os.path.join(output_dir, f"{base_name}_extended_support_{timestamp}.csv")
        with open(csv_out, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["RDS/Aurora Extended Support Cost Report"])
            writer.writerow(["Source", csv_path])
            writer.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            writer.writerow([])
            writer.writerow(["Summary"])
            writer.writerow(["Instances Processed", len(results)])
            writer.writerow(["Instances Skipped", len(skipped)])
            writer.writerow([f"{current_year} Extended Support Cost", f"${total_current:,.2f}"])
            writer.writerow([f"{next_year} Projected Cost", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cost by Engine + Version"])
            writer.writerow(["Engine Version", "Instances", "Ext Support Start", "Ext Support End",
                f"{current_year} Cost", f"{next_year} Projected", "Year 1 Annual"])
            for k, v in sorted(by_engine_version.items()):
                writer.writerow([k, v["count"], v["ext_start"], v["ext_end"],
                    f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}", f"${v['y1_cost']:,.2f}"])
            writer.writerow(["Total", len(results), "", "",
                f"${total_current:,.2f}", f"${total_next:,.2f}", ""])
            writer.writerow([])
            writer.writerow(["Cost by Region"])
            writer.writerow(["Region", "Instances", f"{current_year} Cost", f"{next_year} Projected"])
            for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True):
                writer.writerow([k, v["count"], f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}"])
            writer.writerow([])
            writer.writerow(["Instance Detail"])
            writer.writerow(["Name", "Instance Type", "vCPUs", "Engine", "Version", "Region", "Multi-AZ",
                f"{current_year} Cost", f"{next_year} Projected", "Year 1 Annual"])
            for r in results:
                writer.writerow([r["name"], r["instance_type"], r["vcpus"], r["engine"], r["version"],
                    r["region"], r["multi_az"], f"${r['current_year_cost']:,.2f}",
                    f"${r['next_year_cost']:,.2f}", f"${r['y1_annual']:,.2f}"])
        report_files["csv"] = csv_out

        # HTML report
        def fmt(val): return f"${val:,.2f}"
        now = datetime.now().strftime("%B %d, %Y")
        html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>RDS/Aurora Extended Support Cost Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; color: #1a1a1a; background: #f8f9fa; }}
h1 {{ color: #232f3e; border-bottom: 3px solid #ff9900; padding-bottom: 12px; }}
h2 {{ color: #232f3e; margin-top: 36px; }}
h3 {{ color: #545b64; margin-top: 28px; }}
.summary-cards {{ display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0; }}
.card {{ background: white; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); min-width: 180px; flex: 1; }}
.card .label {{ font-size: 13px; color: #687078; text-transform: uppercase; letter-spacing: 0.5px; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #232f3e; margin-top: 4px; }}
.card .sub {{ font-size: 13px; color: #687078; margin-top: 4px; }}
.card.highlight {{ border-left: 4px solid #ff9900; }}
.card.green {{ border-left: 4px solid #1d8102; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }}
th {{ background: #232f3e; color: white; padding: 12px 16px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }}
td {{ padding: 10px 16px; border-bottom: 1px solid #eaeded; font-size: 14px; }}
tr:hover {{ background: #f5f7f7; }}
.right {{ text-align: right; }}
.total-row {{ font-weight: 700; background: #f0f2f3; }}
.footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid #eaeded; color: #687078; font-size: 12px; }}
</style></head><body>
<h1>RDS/Aurora Extended Support Cost Report</h1>
<p style="color:#687078;">Generated {now} &bull; Source: {os.path.basename(csv_path)}</p>
"""
        # Summary cards
        html += '<div class="summary-cards">'
        html += f'<div class="card highlight"><div class="label">{current_year} Ext Support Cost</div><div class="value">{fmt(total_current)}</div><div class="sub">{len(results)} instances</div></div>'
        html += f'<div class="card highlight"><div class="label">{next_year} Projected Cost</div><div class="value">{fmt(total_next)}</div><div class="sub">Next year</div></div>'
        html += f'<div class="card green"><div class="label">Versions</div><div class="value">{len(by_engine_version)}</div><div class="sub">engine+version combos</div></div>'
        html += '</div>'

        # Summary table: category rows
        html += '<h2>Summary by Category</h2>'
        html += f'<table><tr><th>Category</th><th class="right">Versions</th><th class="right">Instances</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        cats = [
            ("Already in Extended Support", already_in_ext),
            (f"Entering in {current_year}", entering_this_year),
            (f"Entering in {next_year}", entering_next_year),
            ("Future (beyond next year)", future_beyond),
        ]
        cat_total_inst = 0
        cat_total_cy = 0
        cat_total_ny = 0
        for cat_name, cat_dict in cats:
            cat_count = sum(v["count"] for v in cat_dict.values())
            cat_cy = sum(v["current_year_cost"] for v in cat_dict.values())
            cat_ny = sum(v["next_year_cost"] for v in cat_dict.values())
            cat_total_inst += cat_count
            cat_total_cy += cat_cy
            cat_total_ny += cat_ny
            html += f'<tr><td>{cat_name}</td><td class="right">{len(cat_dict)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(by_engine_version)}</td><td class="right">{cat_total_inst}</td><td class="right">{fmt(cat_total_cy)}</td><td class="right">{fmt(cat_total_ny)}</td></tr>'
        html += '</table>'

        # Version detail tables per category
        def _version_table(title, ver_dict):
            if not ver_dict:
                return ""
            t = f'<h3>{title}</h3>'
            t += f'<table><tr><th>Engine Version</th><th class="right">Instances</th><th>Ext Support Start</th><th>Ext Support End</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th><th class="right">Year 1 Annual</th></tr>'
            tot_count = 0
            tot_cy = 0
            tot_ny = 0
            tot_y1 = 0
            for k, v in sorted(ver_dict.items()):
                t += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td>{v["ext_start"]}</td><td>{v["ext_end"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td><td class="right">{fmt(v["y1_cost"])}</td></tr>'
                tot_count += v["count"]
                tot_cy += v["current_year_cost"]
                tot_ny += v["next_year_cost"]
                tot_y1 += v["y1_cost"]
            t += f'<tr class="total-row"><td>Total</td><td class="right">{tot_count}</td><td></td><td></td><td class="right">{fmt(tot_cy)}</td><td class="right">{fmt(tot_ny)}</td><td class="right">{fmt(tot_y1)}</td></tr>'
            t += '</table>'
            return t

        html += _version_table("Currently in Extended Support", already_in_ext)
        html += _version_table(f"Entering in {current_year}", entering_this_year)
        html += _version_table(f"Entering in {next_year}", entering_next_year)
        html += _version_table("Future", future_beyond)

        # Region table
        html += '<h2>Cost by Region</h2>'
        html += f'<table><tr><th>Region</th><th class="right">Instances</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True):
            html += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(results)}</td><td class="right">{fmt(total_current)}</td><td class="right">{fmt(total_next)}</td></tr>'
        html += '</table>'

        html += f'<div class="footer">Report generated by AWS Extended Support Cost Calculator &bull; {now}</div></body></html>'

        html_out = os.path.join(output_dir, f"{base_name}_extended_support_{timestamp}.html")
        with open(html_out, 'w') as f:
            f.write(html)
        report_files["html"] = html_out

    response = {
        "summary": {"instances_processed": len(results), "instances_skipped": len(skipped), "errors": len(errors),
            "current_year": current_year, "current_year_total": round(total_current, 2),
            "next_year": next_year, "next_year_total": round(total_next, 2)},
        "by_engine_version": {k: {"count": v["count"], "status": v["status"],
            "ext_start": v["ext_start"], "ext_end": v["ext_end"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2),
            "y1_cost": round(v["y1_cost"], 2)}
            for k, v in sorted(by_engine_version.items())},
        "by_region": {k: {"count": v["count"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2)}
            for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True)},
        "skipped_sample": skipped[:20], "errors_sample": errors[:20]}
    if report_files:
        response["report_files"] = report_files
    return json.dumps(response, indent=2)


@mcp.tool()
def elasticache_report(csv_path: str, output_dir: str = "") -> str:
    """Process a CSV inventory of ElastiCache Redis clusters. Only Redis OSS 4.x/5.x eligible.

    Calculates month-by-month costs using premium tiers based on months since ext_start.
    Year 1 (0-11 months): 80%, Year 2 (12-23 months): 80%, Year 3 (24+ months): 160%.

    Args:
        csv_path: Absolute path to the CSV file
        output_dir: Directory to save report files (optional — if empty, returns JSON only)
    """
    if not os.path.exists(csv_path):
        return json.dumps({"error": f"File not found: {csv_path}"})
    price_map = fetch_elasticache_pricing()
    current_year = datetime.now().year
    next_year = current_year + 1
    today = datetime.now()

    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames or []
        hl_map = {h: h.lower().strip() for h in header}
        node_type_col = region_col = nodes_col = name_col = version_col = None
        for h, hl in hl_map.items():
            if any(k in hl for k in ['node type', 'nodetype', 'cachenodetype', 'instance type', 'instancetype']): node_type_col = h
            if any(k in hl for k in ['region', 'location']): region_col = h
            if any(k in hl for k in ['num_nodes', 'numnodes', 'node_count', 'nodecount', 'nodes', 'numcachenodes']): nodes_col = h
            if any(k in hl for k in ['cluster', 'name', 'id', 'cacheid', 'cacheclusterid']): name_col = h
            if any(k in hl for k in ['version', 'engineversion', 'engine_version']): version_col = h
        results, skipped = [], []
        for idx, row in enumerate(reader, start=2):
            name = row.get(name_col or '', f'row-{idx}').strip()
            node_type = row.get(node_type_col or '', '').strip()
            region = row.get(region_col or '', '').strip()
            num_nodes = 1
            if nodes_col:
                try: num_nodes = int(row.get(nodes_col, '1').strip() or '1')
                except ValueError: num_nodes = 1
            version = row.get(version_col or '', '').strip() if version_col else ''
            if not node_type or not region:
                skipped.append({"row": idx, "name": name, "reason": "Missing node type or region"})
                continue
            major = version.split('.')[0] if version else ''
            if major and major not in ['4', '5', '6']:
                skipped.append({"row": idx, "name": name, "version": version, "reason": "Not eligible (only Redis 4.x/5.x/6.x)"})
                continue
            # Default to "4" if no version specified (assume eligible)
            ver_key = major if major in ['4', '5', '6'] else '4'
            ext_info = ELASTICACHE_EXTENDED_SUPPORT[ver_key]
            ext_start = datetime.strptime(ext_info["ext_start"], '%Y-%m-%d')

            key = f"{region}|{node_type}"
            base_price = price_map.get(key)
            if not base_price and not node_type.startswith('cache.'):
                base_price = price_map.get(f"{region}|cache.{node_type}")
            if not base_price:
                skipped.append({"row": idx, "name": name, "reason": f"No pricing for {node_type} in {region}"})
                continue

            # Month-by-month cost calculation
            def _calc_year_cost(target_year):
                total = 0.0
                for m in range(1, 13):
                    ms = datetime(target_year, m, 1)
                    if ms < ext_start:
                        continue
                    months_since = (ms.year - ext_start.year) * 12 + (ms.month - ext_start.month)
                    if months_since < 12:
                        pct = 0.80
                    elif months_since < 24:
                        pct = 0.80
                    else:
                        pct = 1.60
                    total += base_price * pct * num_nodes * 730
                return round(total, 2)

            cy_cost = _calc_year_cost(current_year)
            ny_cost = _calc_year_cost(next_year)

            results.append({"name": name, "node_type": node_type, "region": region,
                "num_nodes": num_nodes, "version": version, "major_version": ver_key,
                "current_year_cost": cy_cost, "next_year_cost": ny_cost,
                "ext_start": ext_info["ext_start"], "ext_end": ext_info["ext_end"]})

    # Aggregate by version
    by_version = {}
    for r in results:
        ver = r["major_version"]
        if ver not in by_version:
            by_version[ver] = {"count": 0, "current_year_cost": 0, "next_year_cost": 0,
                               "ext_start": r["ext_start"], "ext_end": r["ext_end"]}
        by_version[ver]["count"] += 1
        by_version[ver]["current_year_cost"] += r["current_year_cost"]
        by_version[ver]["next_year_cost"] += r["next_year_cost"]

    total_current = sum(r['current_year_cost'] for r in results)
    total_next = sum(r['next_year_cost'] for r in results)

    # All Redis 4.x/5.x are already in extended support since 2024
    already_in_ext = dict(by_version)

    # Write reports if output_dir provided
    report_files = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(csv_path))[0]

        # CSV report
        csv_out = os.path.join(output_dir, f"{base_name}_elasticache_extended_support_{timestamp}.csv")
        with open(csv_out, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ElastiCache Extended Support Cost Report"])
            writer.writerow(["Source", csv_path])
            writer.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            writer.writerow([])
            writer.writerow(["Summary"])
            writer.writerow(["Clusters Processed", len(results)])
            writer.writerow(["Clusters Skipped", len(skipped)])
            writer.writerow([f"{current_year} Extended Support Cost", f"${total_current:,.2f}"])
            writer.writerow([f"{next_year} Projected Cost", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cost by Version"])
            writer.writerow(["Version", "Clusters", "Ext Support Start", "Ext Support End",
                f"{current_year} Cost", f"{next_year} Projected"])
            for k, v in sorted(by_version.items()):
                writer.writerow([f"Redis {k}.x", v["count"], v["ext_start"], v["ext_end"],
                    f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}"])
            writer.writerow(["Total", len(results), "", "",
                f"${total_current:,.2f}", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cluster Detail"])
            writer.writerow(["Name", "Node Type", "Region", "Nodes", "Version",
                f"{current_year} Cost", f"{next_year} Projected"])
            for r in results:
                writer.writerow([r["name"], r["node_type"], r["region"], r["num_nodes"],
                    r["version"], f"${r['current_year_cost']:,.2f}", f"${r['next_year_cost']:,.2f}"])
        report_files["csv"] = csv_out

        # HTML report
        def fmt(val): return f"${val:,.2f}"
        now = datetime.now().strftime("%B %d, %Y")
        html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>ElastiCache Extended Support Cost Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; color: #1a1a1a; background: #f8f9fa; }}
h1 {{ color: #232f3e; border-bottom: 3px solid #ff9900; padding-bottom: 12px; }}
h2 {{ color: #232f3e; margin-top: 36px; }}
h3 {{ color: #545b64; margin-top: 28px; }}
.summary-cards {{ display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0; }}
.card {{ background: white; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); min-width: 180px; flex: 1; }}
.card .label {{ font-size: 13px; color: #687078; text-transform: uppercase; letter-spacing: 0.5px; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #232f3e; margin-top: 4px; }}
.card .sub {{ font-size: 13px; color: #687078; margin-top: 4px; }}
.card.highlight {{ border-left: 4px solid #ff9900; }}
.card.green {{ border-left: 4px solid #1d8102; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }}
th {{ background: #232f3e; color: white; padding: 12px 16px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }}
td {{ padding: 10px 16px; border-bottom: 1px solid #eaeded; font-size: 14px; }}
tr:hover {{ background: #f5f7f7; }}
.right {{ text-align: right; }}
.total-row {{ font-weight: 700; background: #f0f2f3; }}
.footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid #eaeded; color: #687078; font-size: 12px; }}
</style></head><body>
<h1>ElastiCache Extended Support Cost Report</h1>
<p style="color:#687078;">Generated {now} &bull; Source: {os.path.basename(csv_path)}</p>
"""
        # Summary cards
        html += '<div class="summary-cards">'
        html += f'<div class="card highlight"><div class="label">{current_year} Ext Support Cost</div><div class="value">{fmt(total_current)}</div><div class="sub">{len(results)} clusters</div></div>'
        html += f'<div class="card highlight"><div class="label">{next_year} Projected Cost</div><div class="value">{fmt(total_next)}</div><div class="sub">Next year</div></div>'
        html += f'<div class="card green"><div class="label">Versions</div><div class="value">{len(by_version)}</div><div class="sub">Redis major versions</div></div>'
        html += '</div>'

        # Category summary table
        html += '<h2>Summary by Category</h2>'
        html += f'<table><tr><th>Category</th><th class="right">Versions</th><th class="right">Clusters</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        cat_count = sum(v["count"] for v in already_in_ext.values())
        cat_cy = sum(v["current_year_cost"] for v in already_in_ext.values())
        cat_ny = sum(v["next_year_cost"] for v in already_in_ext.values())
        html += f'<tr><td>Already in Extended Support</td><td class="right">{len(already_in_ext)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(by_version)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += '</table>'

        # Version detail table
        html += '<h3>Currently in Extended Support</h3>'
        html += f'<table><tr><th>Version</th><th class="right">Clusters</th><th>Ext Support Start</th><th>Ext Support End</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        tot_count = 0
        tot_cy = 0
        tot_ny = 0
        for k, v in sorted(by_version.items()):
            html += f'<tr><td>Redis {k}.x</td><td class="right">{v["count"]}</td><td>{v["ext_start"]}</td><td>{v["ext_end"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td></tr>'
            tot_count += v["count"]
            tot_cy += v["current_year_cost"]
            tot_ny += v["next_year_cost"]
        html += f'<tr class="total-row"><td>Total</td><td class="right">{tot_count}</td><td></td><td></td><td class="right">{fmt(tot_cy)}</td><td class="right">{fmt(tot_ny)}</td></tr>'
        html += '</table>'

        html += f'<div class="footer">Report generated by AWS Extended Support Cost Calculator &bull; {now}</div></body></html>'

        html_out = os.path.join(output_dir, f"{base_name}_elasticache_extended_support_{timestamp}.html")
        with open(html_out, 'w') as f:
            f.write(html)
        report_files["html"] = html_out

    response = {
        "summary": {"clusters_processed": len(results), "clusters_skipped": len(skipped),
            "current_year": current_year, "current_year_total": round(total_current, 2),
            "next_year": next_year, "next_year_total": round(total_next, 2)},
        "by_version": {f"Redis {k}.x": {"count": v["count"],
            "ext_start": v["ext_start"], "ext_end": v["ext_end"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2)}
            for k, v in sorted(by_version.items())},
        "skipped_sample": skipped[:20],
    }
    if report_files:
        response["report_files"] = report_files
    return json.dumps(response, indent=2)


@mcp.tool()
def eks_report(csv_path: str, output_dir: str = "") -> str:
    """Process a CSV inventory of EKS clusters and calculate extended support costs.

    Calculates month-by-month costs based on each cluster's endOfSupportDate.
    Additional cost over standard = $0.50/cluster/hour for months in extended support.

    Args:
        csv_path: Absolute path to the CSV file
        output_dir: Directory to save report files (optional — if empty, returns JSON only)
    """
    if not os.path.exists(csv_path):
        return json.dumps({"error": f"File not found: {csv_path}"})
    EKS_RATES = fetch_eks_extended_support_rate()
    current_year = datetime.now().year
    next_year = current_year + 1
    today = datetime.now()

    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames or []
        hl_map = {h: h.lower().strip() for h in header}
        name_col = version_col = eos_col = eoes_col = region_col = None
        for h, hl in hl_map.items():
            if any(k in hl for k in ['clustername', 'cluster_name']):
                name_col = h
            elif any(k in hl for k in ['clusterversion', 'kubernetesversion', 'k8sversion', 'cluster_version']):
                version_col = h
            elif any(k == hl for k in ['endofsupportdate', 'end_of_support']):
                eos_col = h
            elif any(k == hl for k in ['endofextendedsupportdate', 'end_of_extended_support']):
                eoes_col = h
            elif hl == 'region':
                region_col = h
        # Fallback: broader matching
        if not name_col:
            for h, hl in hl_map.items():
                if hl in ['cluster', 'name', 'clustername']:
                    name_col = h
                    break
        if not version_col:
            for h, hl in hl_map.items():
                if hl in ['version', 'k8s'] and 'supported' not in hl:
                    version_col = h
                    break
        if not eos_col:
            for h, hl in hl_map.items():
                if 'end' in hl and 'support' in hl and 'extended' not in hl:
                    eos_col = h
                    break
        if not eoes_col:
            for h, hl in hl_map.items():
                if 'end' in hl and 'extended' in hl:
                    eoes_col = h
                    break

        clusters = []
        for idx, row in enumerate(reader, start=2):
            name = row.get(name_col or '', f'cluster-{idx}').strip()
            version = row.get(version_col or '', '').strip() if version_col else ''
            region = row.get(region_col or '', '').strip() if region_col else ''
            eos_raw = row.get(eos_col or '', '').strip() if eos_col else ''
            eoes_raw = row.get(eoes_col or '', '').strip() if eoes_col else ''
            eos_date = _parse_date_field(eos_raw)
            eoes_date = _parse_date_field(eoes_raw)
            clusters.append({"name": name, "version": version, "region": region, "eos_date": eos_date, "eoes_date": eoes_date})

    # Compute month-by-month costs per cluster
    results = []
    for c in clusters:
        eos = c["eos_date"]
        region = c["region"]
        ext_rate = EKS_RATES.get(region, EKS_RATES.get('us-east-1', 0.50))
        cy_cost = 0.0
        ny_cost = 0.0
        if eos:
            for m in range(1, 13):
                month_start = datetime(current_year, m, 1)
                if eos < month_start:
                    cy_cost += ext_rate * 730
            for m in range(1, 13):
                month_start = datetime(next_year, m, 1)
                if eos < month_start:
                    ny_cost += ext_rate * 730
        results.append({**c, "current_year_cost": round(cy_cost, 2), "next_year_cost": round(ny_cost, 2)})

    # Categorize by version
    by_version = {}
    for r in results:
        ver = r["version"] or "unknown"
        if ver not in by_version:
            by_version[ver] = {"count": 0, "current_year_cost": 0, "next_year_cost": 0,
                               "end_of_support": None, "end_of_extended_support": None}
        by_version[ver]["count"] += 1
        by_version[ver]["current_year_cost"] += r["current_year_cost"]
        by_version[ver]["next_year_cost"] += r["next_year_cost"]
        if r["eos_date"] and not by_version[ver]["end_of_support"]:
            by_version[ver]["end_of_support"] = r["eos_date"].strftime('%Y-%m-%d')
        if r["eoes_date"] and not by_version[ver]["end_of_extended_support"]:
            by_version[ver]["end_of_extended_support"] = r["eoes_date"].strftime('%Y-%m-%d')

    # Categorize versions into buckets
    already_in_ext = {}
    entering_this_year = {}
    entering_next_year = {}
    still_in_standard = {}
    for ver, info in by_version.items():
        eos_str = info.get("end_of_support")
        if eos_str:
            try:
                eos_dt = datetime.strptime(eos_str, '%Y-%m-%d')
                if eos_dt < today:
                    already_in_ext[ver] = info
                elif eos_dt.year == current_year:
                    entering_this_year[ver] = info
                elif eos_dt.year == next_year:
                    entering_next_year[ver] = info
                else:
                    still_in_standard[ver] = info
            except ValueError:
                still_in_standard[ver] = info
        else:
            still_in_standard[ver] = info

    total_current = sum(r['current_year_cost'] for r in results)
    total_next = sum(r['next_year_cost'] for r in results)

    # Write reports if output_dir provided
    report_files = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(csv_path))[0]

        # CSV report
        csv_out = os.path.join(output_dir, f"{base_name}_eks_extended_support_{timestamp}.csv")
        with open(csv_out, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["EKS Extended Support Cost Report"])
            writer.writerow(["Source", csv_path])
            writer.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            writer.writerow([])
            writer.writerow(["Summary"])
            writer.writerow(["Clusters Processed", len(results)])
            writer.writerow([f"{current_year} Extended Support Cost", f"${total_current:,.2f}"])
            writer.writerow([f"{next_year} Projected Cost", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cost by Version"])
            writer.writerow(["Version", "Clusters", "End of Support", "End of Extended Support",
                f"{current_year} Cost", f"{next_year} Projected"])
            for k, v in sorted(by_version.items()):
                writer.writerow([k, v["count"], v.get("end_of_support", ""),
                    v.get("end_of_extended_support", ""),
                    f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}"])
            writer.writerow(["Total", len(results), "", "",
                f"${total_current:,.2f}", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cluster Detail"])
            writer.writerow(["Name", "Version", "End of Support", "End of Extended Support",
                f"{current_year} Cost", f"{next_year} Projected"])
            for r in results:
                writer.writerow([r["name"], r["version"],
                    r["eos_date"].strftime('%Y-%m-%d') if r["eos_date"] else "",
                    r["eoes_date"].strftime('%Y-%m-%d') if r["eoes_date"] else "",
                    f"${r['current_year_cost']:,.2f}", f"${r['next_year_cost']:,.2f}"])
        report_files["csv"] = csv_out

        # HTML report
        def fmt(val): return f"${val:,.2f}"
        now = datetime.now().strftime("%B %d, %Y")
        html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>EKS Extended Support Cost Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; color: #1a1a1a; background: #f8f9fa; }}
h1 {{ color: #232f3e; border-bottom: 3px solid #ff9900; padding-bottom: 12px; }}
h2 {{ color: #232f3e; margin-top: 36px; }}
h3 {{ color: #545b64; margin-top: 28px; }}
.summary-cards {{ display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0; }}
.card {{ background: white; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); min-width: 180px; flex: 1; }}
.card .label {{ font-size: 13px; color: #687078; text-transform: uppercase; letter-spacing: 0.5px; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #232f3e; margin-top: 4px; }}
.card .sub {{ font-size: 13px; color: #687078; margin-top: 4px; }}
.card.highlight {{ border-left: 4px solid #ff9900; }}
.card.green {{ border-left: 4px solid #1d8102; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }}
th {{ background: #232f3e; color: white; padding: 12px 16px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }}
td {{ padding: 10px 16px; border-bottom: 1px solid #eaeded; font-size: 14px; }}
tr:hover {{ background: #f5f7f7; }}
.right {{ text-align: right; }}
.total-row {{ font-weight: 700; background: #f0f2f3; }}
.footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid #eaeded; color: #687078; font-size: 12px; }}
</style></head><body>
<h1>EKS Extended Support Cost Report</h1>
<p style="color:#687078;">Generated {now} &bull; Source: {os.path.basename(csv_path)}</p>
"""
        # Summary cards
        html += '<div class="summary-cards">'
        html += f'<div class="card highlight"><div class="label">{current_year} Ext Support Cost</div><div class="value">{fmt(total_current)}</div><div class="sub">{len(results)} clusters</div></div>'
        html += f'<div class="card highlight"><div class="label">{next_year} Projected Cost</div><div class="value">{fmt(total_next)}</div><div class="sub">Next year</div></div>'
        html += f'<div class="card green"><div class="label">Versions</div><div class="value">{len(by_version)}</div><div class="sub">EKS versions</div></div>'
        html += '</div>'

        # Category summary table
        html += '<h2>Summary by Category</h2>'
        html += f'<table><tr><th>Category</th><th class="right">Versions</th><th class="right">Clusters</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        cats = [
            ("Already in Extended Support", already_in_ext),
            (f"Entering in {current_year}", entering_this_year),
            (f"Entering in {next_year}", entering_next_year),
            ("Still in Standard Support", still_in_standard),
        ]
        cat_total_inst = 0
        cat_total_cy = 0
        cat_total_ny = 0
        for cat_name, cat_dict in cats:
            cat_count = sum(v["count"] for v in cat_dict.values())
            cat_cy = sum(v["current_year_cost"] for v in cat_dict.values())
            cat_ny = sum(v["next_year_cost"] for v in cat_dict.values())
            cat_total_inst += cat_count
            cat_total_cy += cat_cy
            cat_total_ny += cat_ny
            html += f'<tr><td>{cat_name}</td><td class="right">{len(cat_dict)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(by_version)}</td><td class="right">{cat_total_inst}</td><td class="right">{fmt(cat_total_cy)}</td><td class="right">{fmt(cat_total_ny)}</td></tr>'
        html += '</table>'

        # Version detail tables per category
        def _version_table(title, ver_dict):
            if not ver_dict:
                return ""
            t = f'<h3>{title}</h3>'
            t += f'<table><tr><th>Version</th><th class="right">Clusters</th><th>End of Support</th><th>End of Extended Support</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
            tot_count = 0
            tot_cy = 0
            tot_ny = 0
            for k, v in sorted(ver_dict.items()):
                t += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td>{v.get("end_of_support", "")}</td><td>{v.get("end_of_extended_support", "")}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td></tr>'
                tot_count += v["count"]
                tot_cy += v["current_year_cost"]
                tot_ny += v["next_year_cost"]
            t += f'<tr class="total-row"><td>Total</td><td class="right">{tot_count}</td><td></td><td></td><td class="right">{fmt(tot_cy)}</td><td class="right">{fmt(tot_ny)}</td></tr>'
            t += '</table>'
            return t

        html += _version_table("Currently in Extended Support", already_in_ext)
        html += _version_table(f"Entering in {current_year}", entering_this_year)
        html += _version_table(f"Entering in {next_year}", entering_next_year)
        html += _version_table("Still in Standard Support", still_in_standard)

        html += f'<div class="footer">Report generated by AWS Extended Support Cost Calculator &bull; {now}</div></body></html>'

        html_out = os.path.join(output_dir, f"{base_name}_eks_extended_support_{timestamp}.html")
        with open(html_out, 'w') as f:
            f.write(html)
        report_files["html"] = html_out

    response = {
        "summary": {"clusters_processed": len(results),
            "current_year": current_year, "current_year_total": round(total_current, 2),
            "next_year": next_year, "next_year_total": round(total_next, 2)},
        "by_version": {k: {"count": v["count"],
            "end_of_support": v.get("end_of_support", ""),
            "end_of_extended_support": v.get("end_of_extended_support", ""),
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2)}
            for k, v in sorted(by_version.items())},
    }
    if report_files:
        response["report_files"] = report_files
    return json.dumps(response, indent=2)


@mcp.tool()
def opensearch_report(csv_path: str, output_dir: str = "") -> str:
    """Process a CSV inventory of OpenSearch/Elasticsearch domains and calculate extended support costs.

    Calculates month-by-month costs. For each month after std_end, cost = nih_rate * norm_factor * num_nodes * 730.

    Args:
        csv_path: Absolute path to the CSV file
        output_dir: Directory to save report files (optional — if empty, returns JSON only)
    """
    if not os.path.exists(csv_path):
        return json.dumps({"error": f"File not found: {csv_path}"})
    nih_rates = fetch_opensearch_nih_rates()
    current_year = datetime.now().year
    next_year = current_year + 1
    today = datetime.now()

    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames or []
        hl_map = {h: h.lower().strip() for h in header}
        inst_col = region_col = nodes_col = name_col = version_col = None
        for h, hl in hl_map.items():
            if any(k in hl for k in ['instance type', 'instancetype', 'instance_type', 'node type']): inst_col = h
            if any(k in hl for k in ['region', 'location']): region_col = h
            if any(k in hl for k in ['num_nodes', 'numnodes', 'node_count', 'nodes', 'data_nodes', 'datanodes']): nodes_col = h
            if any(k in hl for k in ['domain', 'name', 'domainname', 'cluster']): name_col = h
            if any(k in hl for k in ['version', 'engineversion', 'engine_version']): version_col = h
        results, skipped = [], []
        for idx, row in enumerate(reader, start=2):
            name = row.get(name_col or '', f'row-{idx}').strip()
            inst_type = row.get(inst_col or '', '').strip()
            region = row.get(region_col or '', '').strip()
            num_nodes = 1
            if nodes_col:
                try: num_nodes = int(row.get(nodes_col, '1').strip() or '1')
                except ValueError: num_nodes = 1
            version = row.get(version_col or '', '').strip() if version_col else ''
            if not inst_type or not region:
                skipped.append({"row": idx, "name": name, "reason": "Missing instance type or region"})
                continue
            nih_rate = nih_rates.get(region)
            if not nih_rate:
                skipped.append({"row": idx, "name": name, "reason": f"No pricing for region {region}"})
                continue
            norm_factor = _get_opensearch_nih_factor(inst_type)
            if not norm_factor:
                skipped.append({"row": idx, "name": name, "reason": f"Unknown instance size: {inst_type}"})
                continue
            version_key = None
            version_info = {}
            if version:
                version_key = _get_opensearch_version_key(version)
                if version_key:
                    version_info = OPENSEARCH_EXTENDED_SUPPORT_VERSIONS[version_key]
                else:
                    skipped.append({"row": idx, "name": name, "version": version, "reason": "Not in extended support schedule"})
                    continue

            std_end_str = version_info.get("std_end", "")
            ext_end_str = version_info.get("ext_end", "")

            # Month-by-month cost calculation
            cy_cost = 0.0
            ny_cost = 0.0
            if std_end_str:
                try:
                    std_end_dt = datetime.strptime(std_end_str, '%Y-%m-%d')
                    for m in range(1, 13):
                        ms = datetime(current_year, m, 1)
                        if ms > std_end_dt:
                            cy_cost += nih_rate * norm_factor * num_nodes * 730
                    for m in range(1, 13):
                        ms = datetime(next_year, m, 1)
                        if ms > std_end_dt:
                            ny_cost += nih_rate * norm_factor * num_nodes * 730
                except ValueError:
                    pass

            results.append({
                "name": name, "instance_type": inst_type, "region": region,
                "num_nodes": num_nodes, "version": version, "version_key": version_key or "",
                "normalization_factor": norm_factor,
                "std_end": std_end_str, "ext_end": ext_end_str,
                "current_year_cost": round(cy_cost, 2), "next_year_cost": round(ny_cost, 2),
            })

    # Aggregate by version
    by_version = {}
    for r in results:
        ver = r["version_key"] or r["version"] or "unknown"
        if ver not in by_version:
            by_version[ver] = {"count": 0, "current_year_cost": 0, "next_year_cost": 0,
                               "std_end": r["std_end"], "ext_end": r["ext_end"]}
        by_version[ver]["count"] += 1
        by_version[ver]["current_year_cost"] += r["current_year_cost"]
        by_version[ver]["next_year_cost"] += r["next_year_cost"]

    total_current = sum(r['current_year_cost'] for r in results)
    total_next = sum(r['next_year_cost'] for r in results)

    # Categorize versions into buckets based on std_end vs today
    already_in_ext = {}
    entering_this_year = {}
    entering_next_year = {}
    future_beyond = {}
    for ver, info in by_version.items():
        std_end_str = info.get("std_end", "")
        if std_end_str:
            try:
                std_dt = datetime.strptime(std_end_str, '%Y-%m-%d')
                if std_dt < today:
                    already_in_ext[ver] = info
                elif std_dt.year == current_year:
                    entering_this_year[ver] = info
                elif std_dt.year == next_year:
                    entering_next_year[ver] = info
                else:
                    future_beyond[ver] = info
            except ValueError:
                future_beyond[ver] = info
        else:
            future_beyond[ver] = info

    # Write reports if output_dir provided
    report_files = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(csv_path))[0]

        # CSV report
        csv_out = os.path.join(output_dir, f"{base_name}_opensearch_extended_support_{timestamp}.csv")
        with open(csv_out, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["OpenSearch Extended Support Cost Report"])
            writer.writerow(["Source", csv_path])
            writer.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            writer.writerow([])
            writer.writerow(["Summary"])
            writer.writerow(["Domains Processed", len(results)])
            writer.writerow(["Domains Skipped", len(skipped)])
            writer.writerow([f"{current_year} Extended Support Cost", f"${total_current:,.2f}"])
            writer.writerow([f"{next_year} Projected Cost", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cost by Version"])
            writer.writerow(["Version", "Domains", "Std Support End", "Ext Support End",
                f"{current_year} Cost", f"{next_year} Projected"])
            for k, v in sorted(by_version.items()):
                writer.writerow([k, v["count"], v["std_end"], v["ext_end"],
                    f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}"])
            writer.writerow(["Total", len(results), "", "",
                f"${total_current:,.2f}", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Domain Detail"])
            writer.writerow(["Name", "Instance Type", "Region", "Nodes", "Version",
                f"{current_year} Cost", f"{next_year} Projected"])
            for r in results:
                writer.writerow([r["name"], r["instance_type"], r["region"], r["num_nodes"],
                    r["version"], f"${r['current_year_cost']:,.2f}", f"${r['next_year_cost']:,.2f}"])
        report_files["csv"] = csv_out

        # HTML report
        def fmt(val): return f"${val:,.2f}"
        now = datetime.now().strftime("%B %d, %Y")
        html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>OpenSearch Extended Support Cost Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; color: #1a1a1a; background: #f8f9fa; }}
h1 {{ color: #232f3e; border-bottom: 3px solid #ff9900; padding-bottom: 12px; }}
h2 {{ color: #232f3e; margin-top: 36px; }}
h3 {{ color: #545b64; margin-top: 28px; }}
.summary-cards {{ display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0; }}
.card {{ background: white; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); min-width: 180px; flex: 1; }}
.card .label {{ font-size: 13px; color: #687078; text-transform: uppercase; letter-spacing: 0.5px; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #232f3e; margin-top: 4px; }}
.card .sub {{ font-size: 13px; color: #687078; margin-top: 4px; }}
.card.highlight {{ border-left: 4px solid #ff9900; }}
.card.green {{ border-left: 4px solid #1d8102; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }}
th {{ background: #232f3e; color: white; padding: 12px 16px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }}
td {{ padding: 10px 16px; border-bottom: 1px solid #eaeded; font-size: 14px; }}
tr:hover {{ background: #f5f7f7; }}
.right {{ text-align: right; }}
.total-row {{ font-weight: 700; background: #f0f2f3; }}
.footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid #eaeded; color: #687078; font-size: 12px; }}
</style></head><body>
<h1>OpenSearch Extended Support Cost Report</h1>
<p style="color:#687078;">Generated {now} &bull; Source: {os.path.basename(csv_path)}</p>
"""
        # Summary cards
        html += '<div class="summary-cards">'
        html += f'<div class="card highlight"><div class="label">{current_year} Ext Support Cost</div><div class="value">{fmt(total_current)}</div><div class="sub">{len(results)} domains</div></div>'
        html += f'<div class="card highlight"><div class="label">{next_year} Projected Cost</div><div class="value">{fmt(total_next)}</div><div class="sub">Next year</div></div>'
        html += f'<div class="card green"><div class="label">Versions</div><div class="value">{len(by_version)}</div><div class="sub">engine versions</div></div>'
        html += '</div>'

        # Category summary table
        html += '<h2>Summary by Category</h2>'
        html += f'<table><tr><th>Category</th><th class="right">Versions</th><th class="right">Domains</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        cats = [
            ("Already in Extended Support", already_in_ext),
            (f"Entering in {current_year}", entering_this_year),
            (f"Entering in {next_year}", entering_next_year),
            ("Future (beyond next year)", future_beyond),
        ]
        cat_total_inst = 0
        cat_total_cy = 0
        cat_total_ny = 0
        for cat_name, cat_dict in cats:
            cat_count = sum(v["count"] for v in cat_dict.values())
            cat_cy = sum(v["current_year_cost"] for v in cat_dict.values())
            cat_ny = sum(v["next_year_cost"] for v in cat_dict.values())
            cat_total_inst += cat_count
            cat_total_cy += cat_cy
            cat_total_ny += cat_ny
            html += f'<tr><td>{cat_name}</td><td class="right">{len(cat_dict)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(by_version)}</td><td class="right">{cat_total_inst}</td><td class="right">{fmt(cat_total_cy)}</td><td class="right">{fmt(cat_total_ny)}</td></tr>'
        html += '</table>'

        # Version detail tables per category
        def _version_table(title, ver_dict):
            if not ver_dict:
                return ""
            t = f'<h3>{title}</h3>'
            t += f'<table><tr><th>Version</th><th class="right">Domains</th><th>Std Support End</th><th>Ext Support End</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
            tot_count = 0
            tot_cy = 0
            tot_ny = 0
            for k, v in sorted(ver_dict.items()):
                t += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td>{v["std_end"]}</td><td>{v["ext_end"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td></tr>'
                tot_count += v["count"]
                tot_cy += v["current_year_cost"]
                tot_ny += v["next_year_cost"]
            t += f'<tr class="total-row"><td>Total</td><td class="right">{tot_count}</td><td></td><td></td><td class="right">{fmt(tot_cy)}</td><td class="right">{fmt(tot_ny)}</td></tr>'
            t += '</table>'
            return t

        html += _version_table("Currently in Extended Support", already_in_ext)
        html += _version_table(f"Entering in {current_year}", entering_this_year)
        html += _version_table(f"Entering in {next_year}", entering_next_year)
        html += _version_table("Future", future_beyond)

        html += f'<div class="footer">Report generated by AWS Extended Support Cost Calculator &bull; {now}</div></body></html>'

        html_out = os.path.join(output_dir, f"{base_name}_opensearch_extended_support_{timestamp}.html")
        with open(html_out, 'w') as f:
            f.write(html)
        report_files["html"] = html_out

    response = {
        "summary": {"domains_processed": len(results), "domains_skipped": len(skipped),
            "current_year": current_year, "current_year_total": round(total_current, 2),
            "next_year": next_year, "next_year_total": round(total_next, 2)},
        "by_version": {k: {"count": v["count"],
            "std_end": v["std_end"], "ext_end": v["ext_end"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2)}
            for k, v in sorted(by_version.items())},
        "skipped_sample": skipped[:20],
    }
    if report_files:
        response["report_files"] = report_files
    return json.dumps(response, indent=2)


@mcp.tool()
def documentdb_report(csv_path: str, output_dir: str = "") -> str:
    """Process a CSV inventory of DocumentDB instances and calculate extended support costs.

    Only DocumentDB 3.6 (or 3.x) is currently eligible for extended support.
    Pricing is per-vCPU-hour (same EC2 instance types as RDS). Multi-AZ doubles the cost.
    Note: 3-month grace period — std support ends Mar 30, 2026 but billing starts Jul 1, 2026.

    Source: https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html
    Source: https://docs.aws.amazon.com/documentdb/latest/developerguide/docdb-engine-version-supportability.html

    Args:
        csv_path: Absolute path to the CSV file
        output_dir: Directory to save report files (optional — if empty, returns JSON only)
    """
    if not os.path.exists(csv_path):
        return json.dumps({"error": f"File not found: {csv_path}"})
    pricing = fetch_documentdb_pricing()
    vcpu_map = fetch_vcpu_data()
    current_year = datetime.now().year
    next_year = current_year + 1
    today = datetime.now()

    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames or []
        hl_map = {h: h.lower().strip() for h in header}
        # Auto-detect columns
        name_col = inst_col = region_col = version_col = maz_col = None
        for h, hl in hl_map.items():
            if any(k in hl for k in ['instance name', 'dbinstanceid', 'instance_name', 'identifier', 'name', 'label', 'cluster']):
                if not name_col:
                    name_col = h
            if any(k in hl for k in ['instance type', 'instancetype', 'instance_type', 'dbinstanceclass', 'class']):
                inst_col = h
            if any(k in hl for k in ['region', 'regioncode', 'region_code']):
                if 'az' not in hl or 'region' in hl:
                    region_col = h
            if any(k in hl for k in ['version', 'engineversion', 'engine_version', 'engine version']):
                version_col = h
            if any(k in hl for k in ['multi-az', 'multi_az', 'multiaz', 'maz']):
                maz_col = h

        results, skipped, errors = [], [], []
        for idx, row in enumerate(reader, start=2):
            name = row.get(name_col or '', f'row-{idx}').strip()
            inst_type = row.get(inst_col or '', '').strip()
            region = row.get(region_col or '', '').strip()
            version = row.get(version_col or '', '').strip() if version_col else ''
            maz_raw = row.get(maz_col or '', '').strip() if maz_col else ''

            if not inst_type or not region:
                errors.append({"row": idx, "name": name, "error": "Missing instance type or region"})
                continue

            # Only process version 3.6 (or 3.x)
            major = ''
            if version:
                parts = version.split('.')
                if len(parts) >= 2:
                    major = f"{parts[0]}.{parts[1]}"
                elif len(parts) == 1:
                    major = parts[0]
            # Accept 3.6 or 3.x (treat any 3.x as 3.6 since that's the only eligible version)
            if major and not major.startswith('3'):
                skipped.append({"row": idx, "name": name, "version": version, "reason": "Not eligible (only DocumentDB 3.6)"})
                continue
            if major and major != '3.6' and not major.startswith('3.'):
                skipped.append({"row": idx, "name": name, "version": version, "reason": "Not eligible (only DocumentDB 3.6)"})
                continue
            # Default to 3.6 if version is 3.x or unspecified
            major = "3.6"

            vcpus = _get_vcpu_count(inst_type, vcpu_map)
            if vcpus is None:
                errors.append({"row": idx, "name": name, "error": f"Unknown instance type: {inst_type}"})
                continue

            is_maz = str(maz_raw).upper().strip() in ['MAZ', 'MULTI-AZ', 'YES', 'TRUE', '1']
            maz_mult = 2 if is_maz else 1

            ver_info = DOCUMENTDB_EXTENDED_SUPPORT.get(major, {})
            ext_start = ver_info.get("ext_start", "")
            ext_end = ver_info.get("ext_end", "")

            # Compute costs
            cy_cost = _compute_documentdb_year_cost(pricing, region, vcpus, maz_mult, current_year)
            ny_cost = _compute_documentdb_year_cost(pricing, region, vcpus, maz_mult, next_year)

            # Year 1 annual (full year at year 1 rate)
            rate_y1 = _find_documentdb_rate(pricing, region, 1)
            y1_annual = round(vcpus * rate_y1 * maz_mult * 8760, 2) if rate_y1 else 0

            results.append({
                "name": name, "instance_type": inst_type, "vcpus": vcpus,
                "version": version, "major_version": major,
                "region": region, "multi_az": is_maz,
                "current_year_cost": round(cy_cost, 2), "next_year_cost": round(ny_cost, 2),
                "y1_annual": y1_annual,
                "ext_start": ext_start, "ext_end": ext_end,
                "billing_start": ver_info.get("ext_billing_start", ""),
            })

    # Aggregations
    total_current = sum(r['current_year_cost'] for r in results)
    total_next = sum(r['next_year_cost'] for r in results)

    by_region = {}
    for r in results:
        by_region.setdefault(r['region'], {"count": 0, "current_year_cost": 0, "next_year_cost": 0})
        by_region[r['region']]["count"] += 1
        by_region[r['region']]["current_year_cost"] += r['current_year_cost']
        by_region[r['region']]["next_year_cost"] += r['next_year_cost']

    # Build version summary
    by_version = {}
    for r in results:
        key = f"DocumentDB {r['major_version']}"
        if key not in by_version:
            by_version[key] = {"count": 0, "current_year_cost": 0, "next_year_cost": 0,
                "y1_cost": 0, "ext_start": r["ext_start"], "ext_end": r["ext_end"],
                "billing_start": r["billing_start"]}
        by_version[key]["count"] += 1
        by_version[key]["current_year_cost"] += r["current_year_cost"]
        by_version[key]["next_year_cost"] += r["next_year_cost"]
        by_version[key]["y1_cost"] += r["y1_annual"]

    # Categorize versions into buckets based on ext_start vs today
    already_in_ext = {}
    entering_this_year = {}
    entering_next_year = {}
    future_beyond = {}
    for k, v in by_version.items():
        ext_start_str = v.get("ext_start", "")
        if ext_start_str:
            try:
                es = datetime.strptime(ext_start_str, '%Y-%m-%d')
                if es <= today:
                    already_in_ext[k] = v
                elif es.year == current_year:
                    entering_this_year[k] = v
                elif es.year == next_year:
                    entering_next_year[k] = v
                else:
                    future_beyond[k] = v
            except ValueError:
                future_beyond[k] = v
        else:
            future_beyond[k] = v

    # Write reports if output_dir provided
    report_files = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(csv_path))[0]

        # CSV report
        csv_out = os.path.join(output_dir, f"{base_name}_documentdb_extended_support_{timestamp}.csv")
        with open(csv_out, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["DocumentDB Extended Support Cost Report"])
            writer.writerow(["Source", csv_path])
            writer.writerow(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            writer.writerow(["Note", "3-month grace period: billing starts 2026-07-01 (std support ends 2026-03-30)"])
            writer.writerow([])
            writer.writerow(["Summary"])
            writer.writerow(["Instances Processed", len(results)])
            writer.writerow(["Instances Skipped", len(skipped)])
            writer.writerow([f"{current_year} Extended Support Cost", f"${total_current:,.2f}"])
            writer.writerow([f"{next_year} Projected Cost", f"${total_next:,.2f}"])
            writer.writerow([])
            writer.writerow(["Cost by Version"])
            writer.writerow(["Version", "Instances", "Ext Support Start", "Billing Start", "Ext Support End",
                f"{current_year} Cost", f"{next_year} Projected", "Year 1 Annual"])
            for k, v in sorted(by_version.items()):
                writer.writerow([k, v["count"], v["ext_start"], v["billing_start"], v["ext_end"],
                    f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}", f"${v['y1_cost']:,.2f}"])
            writer.writerow(["Total", len(results), "", "", "",
                f"${total_current:,.2f}", f"${total_next:,.2f}", ""])
            writer.writerow([])
            writer.writerow(["Cost by Region"])
            writer.writerow(["Region", "Instances", f"{current_year} Cost", f"{next_year} Projected"])
            for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True):
                writer.writerow([k, v["count"], f"${v['current_year_cost']:,.2f}", f"${v['next_year_cost']:,.2f}"])
            writer.writerow([])
            writer.writerow(["Instance Detail"])
            writer.writerow(["Name", "Instance Type", "vCPUs", "Version", "Region", "Multi-AZ",
                f"{current_year} Cost", f"{next_year} Projected", "Year 1 Annual"])
            for r in results:
                writer.writerow([r["name"], r["instance_type"], r["vcpus"], r["version"],
                    r["region"], r["multi_az"], f"${r['current_year_cost']:,.2f}",
                    f"${r['next_year_cost']:,.2f}", f"${r['y1_annual']:,.2f}"])
        report_files["csv"] = csv_out

        # HTML report
        def fmt(val): return f"${val:,.2f}"
        now = datetime.now().strftime("%B %d, %Y")
        html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>DocumentDB Extended Support Cost Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; color: #1a1a1a; background: #f8f9fa; }}
h1 {{ color: #232f3e; border-bottom: 3px solid #ff9900; padding-bottom: 12px; }}
h2 {{ color: #232f3e; margin-top: 36px; }}
h3 {{ color: #545b64; margin-top: 28px; }}
.summary-cards {{ display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0; }}
.card {{ background: white; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); min-width: 180px; flex: 1; }}
.card .label {{ font-size: 13px; color: #687078; text-transform: uppercase; letter-spacing: 0.5px; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #232f3e; margin-top: 4px; }}
.card .sub {{ font-size: 13px; color: #687078; margin-top: 4px; }}
.card.highlight {{ border-left: 4px solid #ff9900; }}
.card.green {{ border-left: 4px solid #1d8102; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }}
th {{ background: #232f3e; color: white; padding: 12px 16px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }}
td {{ padding: 10px 16px; border-bottom: 1px solid #eaeded; font-size: 14px; }}
tr:hover {{ background: #f5f7f7; }}
.right {{ text-align: right; }}
.total-row {{ font-weight: 700; background: #f0f2f3; }}
.note {{ background: #fffbea; border: 1px solid #f5c518; border-radius: 6px; padding: 12px 16px; margin: 16px 0; font-size: 13px; }}
.footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid #eaeded; color: #687078; font-size: 12px; }}
</style></head><body>
<h1>DocumentDB Extended Support Cost Report</h1>
<p style="color:#687078;">Generated {now} &bull; Source: {os.path.basename(csv_path)}</p>
<div class="note"><strong>Note:</strong> DocumentDB 3.6 has a 3-month grace period. Standard support ends March 30, 2026 but extended support billing starts July 1, 2026.</div>
"""
        # Summary cards
        html += '<div class="summary-cards">'
        html += f'<div class="card highlight"><div class="label">{current_year} Ext Support Cost</div><div class="value">{fmt(total_current)}</div><div class="sub">{len(results)} instances</div></div>'
        html += f'<div class="card highlight"><div class="label">{next_year} Projected Cost</div><div class="value">{fmt(total_next)}</div><div class="sub">Next year</div></div>'
        html += f'<div class="card green"><div class="label">Versions</div><div class="value">{len(by_version)}</div><div class="sub">engine versions</div></div>'
        html += '</div>'

        # Summary table: category rows
        html += '<h2>Summary by Category</h2>'
        html += f'<table><tr><th>Category</th><th class="right">Versions</th><th class="right">Instances</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        cats = [
            ("Already in Extended Support", already_in_ext),
            (f"Entering in {current_year}", entering_this_year),
            (f"Entering in {next_year}", entering_next_year),
            ("Future (beyond next year)", future_beyond),
        ]
        cat_total_inst = 0
        cat_total_cy = 0
        cat_total_ny = 0
        for cat_name, cat_dict in cats:
            cat_count = sum(v["count"] for v in cat_dict.values())
            cat_cy = sum(v["current_year_cost"] for v in cat_dict.values())
            cat_ny = sum(v["next_year_cost"] for v in cat_dict.values())
            cat_total_inst += cat_count
            cat_total_cy += cat_cy
            cat_total_ny += cat_ny
            html += f'<tr><td>{cat_name}</td><td class="right">{len(cat_dict)}</td><td class="right">{cat_count}</td><td class="right">{fmt(cat_cy)}</td><td class="right">{fmt(cat_ny)}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(by_version)}</td><td class="right">{cat_total_inst}</td><td class="right">{fmt(cat_total_cy)}</td><td class="right">{fmt(cat_total_ny)}</td></tr>'
        html += '</table>'

        # Version detail tables per category
        def _version_table(title, ver_dict):
            if not ver_dict:
                return ""
            t = f'<h3>{title}</h3>'
            t += f'<table><tr><th>Version</th><th class="right">Instances</th><th>Ext Support Start</th><th>Billing Start</th><th>Ext Support End</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th><th class="right">Year 1 Annual</th></tr>'
            tot_count = 0
            tot_cy = 0
            tot_ny = 0
            tot_y1 = 0
            for k, v in sorted(ver_dict.items()):
                t += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td>{v["ext_start"]}</td><td>{v["billing_start"]}</td><td>{v["ext_end"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td><td class="right">{fmt(v["y1_cost"])}</td></tr>'
                tot_count += v["count"]
                tot_cy += v["current_year_cost"]
                tot_ny += v["next_year_cost"]
                tot_y1 += v["y1_cost"]
            t += f'<tr class="total-row"><td>Total</td><td class="right">{tot_count}</td><td></td><td></td><td></td><td class="right">{fmt(tot_cy)}</td><td class="right">{fmt(tot_ny)}</td><td class="right">{fmt(tot_y1)}</td></tr>'
            t += '</table>'
            return t

        html += _version_table("Currently in Extended Support", already_in_ext)
        html += _version_table(f"Entering in {current_year}", entering_this_year)
        html += _version_table(f"Entering in {next_year}", entering_next_year)
        html += _version_table("Future", future_beyond)

        # Region table
        html += '<h2>Cost by Region</h2>'
        html += f'<table><tr><th>Region</th><th class="right">Instances</th><th class="right">{current_year} Cost</th><th class="right">{next_year} Projected</th></tr>'
        for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True):
            html += f'<tr><td>{k}</td><td class="right">{v["count"]}</td><td class="right">{fmt(v["current_year_cost"])}</td><td class="right">{fmt(v["next_year_cost"])}</td></tr>'
        html += f'<tr class="total-row"><td>Total</td><td class="right">{len(results)}</td><td class="right">{fmt(total_current)}</td><td class="right">{fmt(total_next)}</td></tr>'
        html += '</table>'

        html += f'<div class="footer">Report generated by AWS Extended Support Cost Calculator &bull; {now}<br>Sources: <a href="https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html">DocumentDB Extended Support</a></div></body></html>'

        html_out = os.path.join(output_dir, f"{base_name}_documentdb_extended_support_{timestamp}.html")
        with open(html_out, 'w') as f:
            f.write(html)
        report_files["html"] = html_out

    response = {
        "summary": {"instances_processed": len(results), "instances_skipped": len(skipped), "errors": len(errors),
            "current_year": current_year, "current_year_total": round(total_current, 2),
            "next_year": next_year, "next_year_total": round(total_next, 2),
            "note": "3-month grace period: billing starts 2026-07-01 (std support ends 2026-03-30)"},
        "by_version": {k: {"count": v["count"],
            "ext_start": v["ext_start"], "billing_start": v["billing_start"], "ext_end": v["ext_end"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2),
            "y1_cost": round(v["y1_cost"], 2)}
            for k, v in sorted(by_version.items())},
        "by_region": {k: {"count": v["count"],
            "current_year_cost": round(v["current_year_cost"], 2),
            "next_year_cost": round(v["next_year_cost"], 2)}
            for k, v in sorted(by_region.items(), key=lambda x: x[1]["current_year_cost"], reverse=True)},
        "skipped_sample": skipped[:20], "errors_sample": errors[:20]}
    if report_files:
        response["report_files"] = report_files
    return json.dumps(response, indent=2)


# ---------------------------------------------------------------------------
# MCP Tools - Utility
# ---------------------------------------------------------------------------

@mcp.tool()
def list_versions(service: str = "all") -> str:
    """List version lifecycle dates for AWS services with extended support.

    Shows which versions are in standard support, extended support, or future extended support,
    with exact dates for standard support end, extended support start, and extended support end.

    Args:
        service: "rds", "eks", "elasticache", "opensearch", "documentdb", or "all" (default)
    """
    today = datetime.now()
    result = {}
    svc = service.lower().strip()

    # RDS / Aurora
    if svc in ['all', 'rds', 'aurora', 'rds/aurora']:
        ext_versions = fetch_extended_support_versions()
        rds_data = {}
        for engine_name, versions in ext_versions.items():
            for ver, info in sorted(versions.items()):
                key = f"{engine_name} {ver}"
                std_end = info.get('end_of_standard_support', '')
                ext_start = info.get('extended_support_start', '')
                ext_end = info.get('extended_support_end', '')
                status = info.get('status', '')
                # Refine status based on today
                if ext_start:
                    try:
                        es = datetime.strptime(ext_start, '%Y-%m-%d')
                        if es <= today:
                            status = "In Extended Support"
                        else:
                            status = "Future Extended Support"
                    except ValueError:
                        pass
                rds_data[key] = {"standard_support_end": std_end, "extended_support_start": ext_start,
                    "extended_support_end": ext_end, "status": status,
                    "extended_support_years": info.get('extended_support_years', []),
                    "source": "Live API: rds.describe_db_major_engine_versions()"}
        result["RDS / Aurora"] = rds_data

    # EKS
    if svc in ['all', 'eks']:
        eks_versions = fetch_eks_versions()
        eks_data = {}
        for ver, info in sorted(eks_versions.items()):
            std_end = info.get('end_of_standard_support', '')
            ext_start = info.get('extended_support_start', '')
            ext_end = info.get('extended_support_end', '')
            status = info.get('status', '')
            if ext_start:
                try:
                    es = datetime.strptime(ext_start, '%Y-%m-%d')
                    if es <= today:
                        status = "In Extended Support"
                    elif std_end:
                        sd = datetime.strptime(std_end, '%Y-%m-%d')
                        status = "In Standard Support" if sd > today else "In Extended Support"
                except ValueError:
                    pass
            eks_data[f"EKS {ver}"] = {"standard_support_end": std_end, "extended_support_start": ext_start,
                "extended_support_end": ext_end, "status": status,
                "source": "Live API: eks.describe_cluster_versions()"}
        result["EKS"] = eks_data

    # ElastiCache
    if svc in ['all', 'elasticache', 'redis']:
        ec_data = {}
        for ver, info in sorted(ELASTICACHE_EXTENDED_SUPPORT.items()):
            ext_start = info.get('ext_start', '')
            ext_end = info.get('ext_end', '')
            std_end = info.get('std_end', '')
            status = "In Extended Support"
            if ext_start:
                try:
                    es = datetime.strptime(ext_start, '%Y-%m-%d')
                    status = "In Extended Support" if es <= today else "Future Extended Support"
                except ValueError:
                    pass
            ec_data[f"Redis OSS {ver}.x"] = {"standard_support_end": std_end, "extended_support_start": ext_start,
                "extended_support_end": ext_end, "status": status,
                "premium_tiers": {"year1": "80%", "year2": "80%", "year3": "160%"},
                "source": "Hardcoded from https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/extended-support-versions.html"}
        result["ElastiCache"] = ec_data

    # OpenSearch
    if svc in ['all', 'opensearch', 'elasticsearch']:
        os_data = {}
        for ver, info in sorted(OPENSEARCH_EXTENDED_SUPPORT_VERSIONS.items()):
            std_end = info.get('std_end', '')
            ext_end = info.get('ext_end', '')
            ext_start = std_end  # ext support starts day after std ends
            if std_end:
                try:
                    sd = datetime.strptime(std_end, '%Y-%m-%d')
                    ext_start_dt = sd.replace(day=sd.day + 1) if sd.day < 28 else sd
                    ext_start = ext_start_dt.strftime('%Y-%m-%d')
                    status = "In Extended Support" if sd < today else "Future Extended Support"
                except ValueError:
                    status = "Unknown"
            else:
                status = "Unknown"
            os_data[ver] = {"standard_support_end": std_end, "extended_support_start": ext_start,
                "extended_support_end": ext_end, "status": status,
                "source": "Hardcoded from https://aws.amazon.com/blogs/big-data/amazon-opensearch-service-announces-standard-and-extended-support-dates-for-elasticsearch-and-opensearch-versions/"}
        # Add not-yet-announced versions
        for ver in ["Elasticsearch 6.8", "Elasticsearch 7.9", "Elasticsearch 7.10", "OpenSearch 1.3", "OpenSearch 2.11+"]:
            os_data[ver] = {"standard_support_end": "Not announced", "extended_support_start": "Not announced",
                "extended_support_end": "Not announced", "status": "Not yet announced", "source": "AWS has not announced dates"}
        result["OpenSearch"] = os_data

    # DocumentDB
    if svc in ['all', 'documentdb', 'docdb']:
        doc_data = {}
        for ver, info in sorted(DOCUMENTDB_EXTENDED_SUPPORT.items()):
            ext_start = info.get('ext_start', '')
            ext_end = info.get('ext_end', '')
            std_end = info.get('std_end', '')
            billing_start = info.get('ext_billing_start', '')
            status = "In Extended Support"
            if ext_start:
                try:
                    es = datetime.strptime(ext_start, '%Y-%m-%d')
                    status = "In Extended Support" if es <= today else "Future Extended Support"
                except ValueError:
                    pass
            doc_data[f"DocumentDB {ver}"] = {"standard_support_end": std_end, "extended_support_start": ext_start,
                "extended_support_end": ext_end, "billing_start": billing_start, "status": status,
                "note": "3-month grace period between ext_start and billing_start",
                "source": "Hardcoded from https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html"}
        result["DocumentDB"] = doc_data

    return json.dumps(result, indent=2)


@mcp.tool()
def list_services() -> str:
    """List all services and engines supported by this calculator."""
    return json.dumps({"services": {
        "RDS / Aurora": {"engines": ["mysql", "postgres", "aurora-mysql", "aurora-postgresql"],
            "pricing_model": "vCPUs x per-vCPU-hourly-rate x hours x (2 if Multi-AZ)",
            "serverless": "ACU-based pricing (1 ACU default)"},
        "ElastiCache": {"engines": ["Redis OSS 4.x", "Redis OSS 5.x"],
            "pricing_model": "On-demand price + premium (80% Year 1-2, 160% Year 3)",
            "note": "Redis 6.x+ and Valkey are NOT eligible"},
        "EKS": {"versions": "Kubernetes versions past standard support (14 months from GA)",
            "pricing_model": "$0.60/cluster/hour (vs $0.10 standard)", "duration": "Up to 12 months"},
        "OpenSearch": {"engines": ["Elasticsearch 1.5-7.8", "OpenSearch 1.0-2.9"],
            "pricing_model": "Flat fee per NIH (Normalized Instance Hour) by region",
            "formula": "NIH_rate x normalization_factor x instance_hours x num_nodes",
            "note": "Elasticsearch 6.8, 7.9, 7.10 and OpenSearch 1.3, 2.11+ not yet announced"},
        "DocumentDB": {"engines": ["DocumentDB 3.6"],
            "pricing_model": "vCPUs x per-vCPU-hourly-rate x hours x (2 if Multi-AZ)",
            "note": "3-month grace period: std support ends 2026-03-30, billing starts 2026-07-01",
            "source": "https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html"}},
        "unsupported": ["Neptune", "MariaDB", "Oracle", "SQL Server"]}, indent=2)


@mcp.tool()
def check_data() -> str:
    """Check the freshness of cached pricing and version data."""
    files = {"rds_pricing": _cache_path('rds_extended_support_pricing.json'),
        "elasticache_pricing": _cache_path('elasticache_pricing.json'),
        "documentdb_pricing": _cache_path('documentdb_extended_support_pricing.json'),
        "ec2_vcpu_data": _cache_path('ec2_vcpu_data.json'),
        "extended_support_versions": _cache_path('extended_support_versions.json'),
        "eks_versions": _cache_path('eks_versions.json'),
        "opensearch_nih_rates": _cache_path('opensearch_nih_rates.json'),
        "eks_extended_support_rate": _cache_path('eks_extended_support_rate.json')}
    status = {}
    for name, path in files.items():
        exists = os.path.exists(path)
        status[name] = {"cached": exists, "age": _cache_age_str(path) if exists else "not downloaded",
            "fresh": _cache_is_fresh(path) if exists else False}
    return json.dumps({"cache_ttl_hours": CACHE_TTL_HOURS, "data": status}, indent=2)


@mcp.tool()
def refresh_data() -> str:
    """Force re-download all cached pricing and version data."""
    if os.path.exists(CACHE_DIR):
        for f in os.listdir(CACHE_DIR):
            fp = os.path.join(CACHE_DIR, f)
            if os.path.isfile(fp): os.remove(fp)
    errors = []
    for label, fn in [("RDS pricing", fetch_rds_pricing), ("ElastiCache pricing", fetch_elasticache_pricing),
                      ("DocumentDB pricing", fetch_documentdb_pricing),
                      ("EC2 vCPU data", fetch_vcpu_data), ("Extended support versions", fetch_extended_support_versions),
                      ("EKS versions", fetch_eks_versions),
                      ("OpenSearch NIH rates", fetch_opensearch_nih_rates),
                      ("EKS extended support rate", fetch_eks_extended_support_rate)]:
        try: fn()
        except Exception as e: errors.append(f"{label}: {e}")
    if errors:
        return json.dumps({"status": "partial", "errors": errors})
    return json.dumps({"status": "success", "message": "All data refreshed successfully"})


# ---------------------------------------------------------------------------
# First-run setup: auto-register with Kiro
# ---------------------------------------------------------------------------

MCP_SERVER_NAME = "aws-extended-support"
KIRO_MCP_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".kiro", "settings", "mcp.json")

def _ensure_kiro_mcp_config(aws_profile=None):
    """Add this server to ~/.kiro/settings/mcp.json if not already present."""
    config_dir = os.path.dirname(KIRO_MCP_CONFIG_PATH)
    os.makedirs(config_dir, exist_ok=True)

    if os.path.exists(KIRO_MCP_CONFIG_PATH):
        with open(KIRO_MCP_CONFIG_PATH, 'r') as f:
            try:
                config = json.load(f)
            except json.JSONDecodeError:
                config = {"mcpServers": {}}
    else:
        config = {"mcpServers": {}}

    EXPECTED_TOOLS = [
        "rds_cost", "elasticache_cost", "eks_cost", "opensearch_cost", "documentdb_cost",
        "rds_report", "elasticache_report", "eks_report", "opensearch_report", "documentdb_report",
        "list_services", "list_versions", "check_data", "refresh_data",
    ]

    if MCP_SERVER_NAME in config.get("mcpServers", {}):
        # Already registered — update autoApprove to include any new tools
        existing = config["mcpServers"][MCP_SERVER_NAME]
        current_approve = set(existing.get("autoApprove", []))
        expected = set(EXPECTED_TOOLS)
        missing = expected - current_approve
        if missing:
            existing["autoApprove"] = sorted(expected | current_approve)
            with open(KIRO_MCP_CONFIG_PATH, 'w') as f:
                json.dump(config, f, indent=2)
            return "updated"
        return False  # already up to date

    config.setdefault("mcpServers", {})[MCP_SERVER_NAME] = {
        "command": "aws-extended-support-calculator",
        "args": [],
        "env": {
            "AWS_PROFILE": aws_profile or "your-aws-profile"
        },
        "disabled": False,
        "autoApprove": EXPECTED_TOOLS,
    }

    with open(KIRO_MCP_CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=2)

    return True


# ---------------------------------------------------------------------------
# Server entrypoint
# ---------------------------------------------------------------------------

KIRO_STEERING_DIR = os.path.join(os.path.expanduser("~"), ".kiro", "steering")

def _install_steering_files():
    """Copy steering files to ~/.kiro/steering/ if not already present."""
    # Steering files are bundled next to this script in ../.kiro/steering/
    script_dir = os.path.dirname(os.path.abspath(__file__))
    source_dir = os.path.join(os.path.dirname(script_dir), ".kiro", "steering")
    if not os.path.isdir(source_dir):
        # Fallback: try package install location
        import importlib.resources
        try:
            pkg_dir = os.path.dirname(importlib.resources.files("aws_extended_support_calculator").__str__())
            source_dir = os.path.join(pkg_dir, ".kiro", "steering")
        except Exception:
            return []
    if not os.path.isdir(source_dir):
        return []
    os.makedirs(KIRO_STEERING_DIR, exist_ok=True)
    installed = []
    import shutil
    for fname in os.listdir(source_dir):
        if not fname.endswith('.md'):
            continue
        dest = os.path.join(KIRO_STEERING_DIR, fname)
        shutil.copy2(os.path.join(source_dir, fname), dest)
        installed.append(fname)
    return installed


def main():
    """Entry point for the MCP server. Handles setup and starts the server."""
    import sys

    if '--setup' in sys.argv:
        # Setup mode: register with Kiro, install steering files, and exit

        # Get AWS profile — from --profile flag or interactive prompt
        aws_profile = None
        for i, arg in enumerate(sys.argv):
            if arg == '--profile' and i + 1 < len(sys.argv):
                aws_profile = sys.argv[i + 1]
                break
            if arg.startswith('--profile='):
                aws_profile = arg.split('=', 1)[1]
                break

        if not aws_profile:
            try:
                print("AWS Extended Support Cost Calculator — Setup\n")
                aws_profile = input("Enter your AWS profile name (for vCPU and version lookups) [default]: ").strip()
            except (EOFError, KeyboardInterrupt):
                aws_profile = None

        if not aws_profile:
            aws_profile = "default"

        try:
            result = _ensure_kiro_mcp_config(aws_profile=aws_profile)
            if result == "updated":
                print(f"✓ Updated config for '{MCP_SERVER_NAME}' in {KIRO_MCP_CONFIG_PATH}")
            elif result:
                print(f"✓ Registered '{MCP_SERVER_NAME}' in {KIRO_MCP_CONFIG_PATH}")
            else:
                # Already registered — update the profile if user provided one
                if aws_profile != "default":
                    with open(KIRO_MCP_CONFIG_PATH, 'r') as f:
                        config = json.load(f)
                    entry = config.get("mcpServers", {}).get(MCP_SERVER_NAME, {})
                    entry.setdefault("env", {})["AWS_PROFILE"] = aws_profile
                    with open(KIRO_MCP_CONFIG_PATH, 'w') as f:
                        json.dump(config, f, indent=2)
                    print(f"✓ Updated AWS_PROFILE to '{aws_profile}' in {KIRO_MCP_CONFIG_PATH}")
                else:
                    print(f"✓ '{MCP_SERVER_NAME}' already up to date in {KIRO_MCP_CONFIG_PATH}")
        except Exception as e:
            print(f"✗ Could not update Kiro MCP config: {e}")
            sys.exit(1)

        # Install steering files
        try:
            installed = _install_steering_files()
            if installed:
                print(f"✓ Updated steering files in {KIRO_STEERING_DIR}:")
                for f in installed:
                    print(f"    {f}")
            else:
                print(f"✓ Steering files up to date in {KIRO_STEERING_DIR}")
        except Exception as e:
            print(f"⚠ Could not install steering files: {e}")

        print(f"\nRestart Kiro IDE or start a new Kiro CLI chat to use the tools.")
        return

    # Normal mode: register silently and start the MCP server
    try:
        _ensure_kiro_mcp_config()
    except Exception:
        pass

    try:
        _install_steering_files()
    except Exception:
        pass

    mcp.run()


if __name__ == "__main__":
    main()
