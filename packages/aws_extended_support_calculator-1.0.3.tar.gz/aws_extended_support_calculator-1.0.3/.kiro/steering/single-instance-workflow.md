---
inclusion: auto
description: "How to calculate extended support cost for a single AWS resource"
---

# Single Instance Cost Calculation

## RDS / Aurora

Use `calculate_rds_extended_support` with:
- `instance_type`: e.g. "db.r5.xlarge", "db.serverless"
- `engine`: "mysql", "postgres", "aurora-mysql", "aurora-postgresql"
- `region`: AWS region code
- `multi_az`: true/false (doubles the cost)

Returns Year 1, 2, 3 breakdown with per-vCPU hourly rates from the AWS Pricing API. vCPU count is looked up via `ec2.describe_instance_types()`.

## ElastiCache

Use `calculate_elasticache_extended_support` with:
- `instance_type`: e.g. "cache.r6g.large"
- `region`: AWS region code
- `num_nodes`: number of cache nodes

Returns Year 1-2 (80% premium) and Year 3 (160% premium) over the on-demand price fetched from the AWS Pricing API.

## EKS

Use `calculate_eks_extended_support` with:
- `num_clusters`: number of clusters
- `months_in_extended_support`: 1-12

Returns standard vs extended cost comparison. Fixed rate: $0.60/cluster/hour.

## OpenSearch

Use `calculate_opensearch_extended_support` with:
- `instance_type`: e.g. "m7g.medium.search"
- `region`: AWS region code
- `num_nodes`: number of data nodes
- `engine_version`: optional, for eligibility check (e.g. "7.8", "2.9")

Returns NIH-based cost. Formula: NIH_rate × normalization_factor × hours × nodes.
