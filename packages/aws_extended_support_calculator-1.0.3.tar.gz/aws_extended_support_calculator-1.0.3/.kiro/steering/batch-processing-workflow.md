---
inclusion: auto
description: "How to process CSV inventory files for extended support cost reports"
---

# Batch CSV Processing Workflow

When processing CSV inventory files for extended support cost calculation:

## Column Auto-Detection

The batch tools auto-detect columns by matching header names (case-insensitive). No strict format required.

Common column name patterns recognized:
- **Instance/Node type**: "Instance Type", "DBInstanceClass", "CacheNodeType", "Node Type"
- **Engine**: "DB Engine", "Engine", "DatabaseEngine"
- **Version**: "Engine Version", "EngineVersion", "Version"
- **Region**: "Region", "Instance Region", "Location"
- **Multi-AZ** (RDS only): "Multi-AZ", "MultiAZ", "MAZ"
- **Name**: "Instance Name", "DBInstanceId", "CacheClusterId", "Domain Name"
- **Node count**: "NumNodes", "NumCacheNodes", "DataNodes"

## Processing Rules

1. Always call `check_data_status` first to verify pricing data is fresh
2. If data is stale, call `refresh_data` before processing
3. For RDS: instances are checked against the version lifecycle API — only versions actually in extended support are costed
4. For ElastiCache: only Redis 4.x/5.x rows are processed; others are skipped
5. For OpenSearch: version is matched against the known extended support schedule
6. Results are capped at 50 instances in the response; summary totals cover all rows

## Output Structure

All batch tools return:
- `summary`: totals, counts of processed/skipped/errors
- `instances`/`clusters`/`domains`: per-row detail (first 50)
- `skipped_sample`: rows that were skipped and why
- Breakdowns by region and/or engine where applicable
