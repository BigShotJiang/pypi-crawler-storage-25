---
inclusion: auto
description: "Version eligibility dates and data sources for all AWS services with extended support"
---

# AWS Extended Support — Version Eligibility & Data Sources

Use the `list_versions` tool to get current version lifecycle dates for any service. It returns live data for RDS/EKS and hardcoded data for ElastiCache/OpenSearch/DocumentDB.

## Data Sources by Service

| Service | Version Dates Source | Pricing Source | Requires AWS Creds |
|---------|---------------------|---------------|-------------------|
| RDS/Aurora | Live API: `rds.describe_db_major_engine_versions()` — cached 24h | AWS RDS Pricing API (public) | Yes (for versions) |
| EKS | Live API: `eks.describe_cluster_versions()` — cached 24h | AWS EKS Pricing API (public) | Yes (for versions) |
| ElastiCache | Hardcoded in server code | AWS ElastiCache Pricing API (public) | No |
| OpenSearch | Hardcoded in server code | AWS OpenSearch Pricing API (public) | No |
| DocumentDB | Hardcoded in server code | AWS DocumentDB Pricing API (public) | No |

## Live API Data (auto-refreshes every 24 hours)

**RDS / Aurora**: Exact standard support end, extended support start/end dates for each engine+version. Pricing per-vCPU-hour by region, engine, and year tier. Year 3 is typically 2× Year 1-2 for PostgreSQL/MySQL.

**EKS**: `endOfStandardSupportDate`, `endOfExtendedSupportDate`, and `status` per K8s version. Pricing is an additional per-cluster-hour rate by region.

## Hardcoded Data (verify periodically)

The following services have no lifecycle API. Dates are hardcoded in the server and should be verified against the source URLs when AWS announces changes.

| Service | Source URL | Last Verified |
|---------|-----------|---------------|
| ElastiCache | https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/extended-support-versions.html | April 2026 |
| OpenSearch | https://aws.amazon.com/blogs/big-data/amazon-opensearch-service-announces-standard-and-extended-support-dates-for-elasticsearch-and-opensearch-versions/ | April 2026 |
| DocumentDB | https://docs.aws.amazon.com/documentdb/latest/developerguide/extended-support.html | April 2026 |

**ElastiCache**: Redis 4.x/5.x (ext start Feb 2026, ext end Jan 2029), Redis 6.x (ext start Feb 2027, ext end Jan 2030). Premium: 80% Y1-2, 160% Y3.

**OpenSearch**: All announced versions have std end Nov 7, 2025. Most have ext end Nov 7, 2026 (12 months). ES 5.6 has ext end Nov 7, 2028 (36 months). ES 6.8, 7.9, 7.10, OS 1.3, 2.11+ not yet announced.

**DocumentDB**: Only v3.6 eligible. Std end Mar 30, 2026. 3-month grace period — billing starts Jul 1, 2026. Ext end Mar 30, 2029. Premium: 80% Y1-2, 160% Y3.
