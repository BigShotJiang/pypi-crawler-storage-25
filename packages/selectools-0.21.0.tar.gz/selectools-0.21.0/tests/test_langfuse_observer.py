"""Tests for LangfuseObserver."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


class TestLangfuseObserver:
    def _make_observer(self):
        mock_langfuse_mod = MagicMock()
        mock_client = MagicMock()
        mock_langfuse_mod.Langfuse.return_value = mock_client
        with patch.dict("sys.modules", {"langfuse": mock_langfuse_mod}):
            from selectools.observe.langfuse import LangfuseObserver

            obs = LangfuseObserver.__new__(LangfuseObserver)
            obs._langfuse = mock_client
            obs._traces = {}
            obs._generations = {}
            obs._llm_counter = 0
        return obs, mock_client

    def test_import_error(self):
        with patch.dict("sys.modules", {"langfuse": None}):
            with pytest.raises(ImportError, match="langfuse"):
                import importlib

                import selectools.observe.langfuse as mod

                importlib.reload(mod)
                mod.LangfuseObserver()

    def test_run_start_creates_trace(self):
        """Langfuse 3.x: root span is created via client.start_span(...)."""
        obs, client = self._make_observer()
        mock_root = MagicMock()
        client.start_span.return_value = mock_root
        obs.on_run_start("run1", [], "system prompt")
        client.start_span.assert_called_once()
        assert "run1" in obs._traces

    def test_run_end_updates_and_flushes(self):
        obs, client = self._make_observer()
        mock_trace = MagicMock()
        obs._traces["run1"] = mock_trace
        result = MagicMock()
        result.content = "response"
        result.usage.total_tokens = 100
        result.usage.total_cost_usd = 0.003
        result.iterations = 2
        obs.on_run_end("run1", result)
        mock_trace.update.assert_called_once()
        client.flush.assert_called_once()
        assert "run1" not in obs._traces

    def test_run_end_missing_trace(self):
        obs, client = self._make_observer()
        obs.on_run_end("nonexistent", MagicMock())
        client.flush.assert_not_called()

    def test_run_end_flush_error_handled(self):
        obs, client = self._make_observer()
        mock_trace = MagicMock()
        obs._traces["run1"] = mock_trace
        client.flush.side_effect = Exception("network error")
        obs.on_run_end("run1", MagicMock())  # Should not raise

    def test_llm_start_creates_generation(self):
        """Langfuse 3.x: child generation via root.start_generation(...)."""
        obs, _ = self._make_observer()
        mock_root = MagicMock()
        mock_gen = MagicMock()
        mock_root.start_generation.return_value = mock_gen
        obs._traces["run1"] = mock_root
        obs.on_llm_start("run1", [{"role": "user", "content": "hi"}], "gpt-4o", "prompt")
        mock_root.start_generation.assert_called_once()
        assert "run1:llm:1" in obs._generations

    def test_llm_start_no_trace(self):
        obs, _ = self._make_observer()
        obs.on_llm_start("nonexistent", [], "gpt-4o", "prompt")  # Should not raise

    def test_llm_end_updates_generation(self):
        obs, _ = self._make_observer()
        mock_gen = MagicMock()
        obs._generations["run1:llm:1"] = mock_gen
        usage = MagicMock()
        usage.prompt_tokens = 50
        usage.completion_tokens = 30
        usage.total_tokens = 80
        obs.on_llm_end("run1", "response", usage)
        mock_gen.update.assert_called_once()

    def test_llm_end_no_usage(self):
        obs, _ = self._make_observer()
        mock_gen = MagicMock()
        obs._generations["run1:llm:1"] = mock_gen
        obs.on_llm_end("run1", "response", None)
        mock_gen.update.assert_called_once()

    def test_tool_start_creates_span(self):
        """Langfuse 3.x: child span via root.start_span(...)."""
        obs, _ = self._make_observer()
        mock_root = MagicMock()
        mock_span = MagicMock()
        mock_root.start_span.return_value = mock_span
        obs._traces["run1"] = mock_root
        obs.on_tool_start("run1", "call1", "search", {"q": "test"})
        assert "run1:tool:call1" in obs._generations

    def test_tool_end_updates_span(self):
        obs, _ = self._make_observer()
        mock_span = MagicMock()
        obs._generations["run1:tool:call1"] = mock_span
        obs.on_tool_end("run1", "call1", "search", "results", 42.0)
        mock_span.update.assert_called_once()

    def test_tool_error_records_error(self):
        obs, _ = self._make_observer()
        mock_span = MagicMock()
        obs._generations["run1:tool:call1"] = mock_span
        obs.on_tool_error("run1", "call1", "search", Exception("timeout"), {"q": "test"}, 100.0)
        mock_span.update.assert_called_once()
        call_kwargs = mock_span.update.call_args[1]
        assert "ERROR" in call_kwargs.get("output", "") or call_kwargs.get("level") == "ERROR"

    def test_shutdown_flushes(self):
        obs, client = self._make_observer()
        obs.shutdown()
        client.flush.assert_called_once()

    def test_shutdown_error_handled(self):
        obs, client = self._make_observer()
        client.flush.side_effect = Exception("fail")
        obs.shutdown()  # Should not raise

    def test_multi_iteration_llm_no_overwrite(self):
        """Regression: Bug 8 — multiple LLM calls must not overwrite generations."""
        obs, _ = self._make_observer()
        mock_root = MagicMock()
        gen1 = MagicMock()
        gen2 = MagicMock()
        mock_root.start_generation.side_effect = [gen1, gen2]
        obs._traces["run1"] = mock_root

        obs.on_llm_start("run1", [], "gpt-4o", "prompt")
        assert "run1:llm:1" in obs._generations
        assert obs._generations["run1:llm:1"] is gen1

        # End the first
        obs.on_llm_end("run1", "response 1", None)
        gen1.update.assert_called_once()

        # Start a second — must not overwrite the first key
        obs.on_llm_start("run1", [], "gpt-4o", "prompt")
        assert "run1:llm:2" in obs._generations
        assert obs._generations["run1:llm:2"] is gen2

        obs.on_llm_end("run1", "response 2", None)
        gen2.update.assert_called_once()

    def test_concurrent_llm_generations_resolved_correctly(self):
        """Regression: Bug 8 — on_llm_end picks the highest-numbered generation."""
        obs, _ = self._make_observer()
        mock_root = MagicMock()
        gen1 = MagicMock()
        gen2 = MagicMock()
        mock_root.start_generation.side_effect = [gen1, gen2]
        obs._traces["run1"] = mock_root

        obs.on_llm_start("run1", [], "gpt-4o", "prompt")
        obs.on_llm_start("run1", [], "gpt-4o", "prompt")

        # End should close the most recent (gen2)
        obs.on_llm_end("run1", "response", None)
        gen2.update.assert_called_once()
        gen1.update.assert_not_called()
        assert "run1:llm:1" in obs._generations  # gen1 still open

    def test_run_end_cleans_up_orphaned_generations(self):
        """Regression: Bug 18 — orphaned generations cleaned up on run end."""
        obs, client = self._make_observer()
        mock_trace = MagicMock()
        orphan_llm = MagicMock()
        orphan_tool = MagicMock()
        obs._traces["run1"] = mock_trace
        obs._generations["run1:llm:1"] = orphan_llm
        obs._generations["run1:tool:call99"] = orphan_tool

        result = MagicMock()
        result.content = "done"
        result.usage = None
        del result.iterations
        obs.on_run_end("run1", result)

        # Orphans should be updated with error
        orphan_llm.update.assert_called_once()
        orphan_tool.update.assert_called_once()
        # Trace updated and flushed
        mock_trace.update.assert_called_once()
        client.flush.assert_called_once()
        # All cleaned up
        assert not any(k.startswith("run1") for k in obs._generations)
        assert "run1" not in obs._traces

    def test_run_end_orphan_cleanup_does_not_affect_other_runs(self):
        """Orphan cleanup must only touch generations for the given run_id."""
        obs, client = self._make_observer()
        mock_trace = MagicMock()
        run2_gen = MagicMock()
        obs._traces["run1"] = mock_trace
        obs._generations["run2:llm:1"] = run2_gen

        result = MagicMock()
        result.content = "done"
        result.usage = None
        del result.iterations
        obs.on_run_end("run1", result)

        # run2's generation should be untouched
        run2_gen.update.assert_not_called()
        assert "run2:llm:1" in obs._generations

    def test_stability_marker(self):
        obs, _ = self._make_observer()
        assert getattr(type(obs), "__stability__", None) == "beta"
