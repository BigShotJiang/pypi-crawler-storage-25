"""Interactive AI assistant for robot training — agentic tool-using loop.

ORBIT Assist is a domain-expert agent that autonomously executes ORBIT
commands, reasons about results, and helps users go from raw robot data
to trained policies.

Backward-compatible: `from orbit.assist import run_assist` still works.
"""

from orbit.assist.agent import run_assist

__all__ = ["run_assist"]
