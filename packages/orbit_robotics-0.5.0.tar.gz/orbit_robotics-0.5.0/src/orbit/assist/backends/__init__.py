"""LLM backends for ORBIT Assist.

Gemini (default): Uses Gemini Flash with function calling via REST API.
Claude (optional): Uses Claude Agent SDK for power users.
"""

from orbit.assist.backends.gemini import GeminiBackend

__all__ = ["GeminiBackend"]
