"""Multi-framework training command generation.

Generates ready-to-run training commands for LeRobot, OpenVLA, OpenPI/pi0,
GR00T N1, NVIDIA OSMO, and custom training scripts.
"""

from __future__ import annotations

from orbit.training.base import FRAMEWORKS, TrainingConfig, get_framework_config

__all__ = ["FRAMEWORKS", "TrainingConfig", "get_framework_config"]
