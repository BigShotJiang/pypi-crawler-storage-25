"""LLM-driven demonstration generation in simulation.

Uses an LLM agent in a ReAct loop to generate robot demonstrations
in MuJoCo (or other simulators). Based on the FAEA research showing
LLM agents achieving 85-96% success in simulation tasks.

Optional dependencies: mujoco>=3.0 (install with pip install orbit-robotics[sim])
"""

from __future__ import annotations

from orbit.generator.generate import GenerationResult, generate_demonstrations

__all__ = ["GenerationResult", "generate_demonstrations"]
