"""Integration tests for ORBIT.

These tests hit the real HuggingFace Hub and require network access.
Mark with @pytest.mark.integration so they can be skipped in CI.
"""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from orbit.cli import main


@pytest.mark.integration
class TestAnalyzeIntegration:
    """Integration tests that analyze real datasets."""

    def test_analyze_pusht(self):
        runner = CliRunner()
        result = runner.invoke(
            main, ["analyze", "lerobot/pusht", "--skip-embeddings"]
        )
        assert result.exit_code == 0
        assert "ORBIT Analysis" in result.output or "YOUR DATA AT A GLANCE" in result.output

    def test_analyze_pusht_json(self):
        runner = CliRunner()
        result = runner.invoke(
            main, ["analyze", "lerobot/pusht", "--json", "--skip-embeddings"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["repo_id"] == "lerobot/pusht"
        assert data["num_episodes"] > 0
        assert 0 <= data["quality_score"] <= 1

    def test_analyze_with_episode_limit(self):
        runner = CliRunner()
        result = runner.invoke(
            main, ["analyze", "lerobot/pusht", "--episodes", "5", "--skip-embeddings"]
        )
        assert result.exit_code == 0


@pytest.mark.integration
class TestTrackIntegration:
    """Integration tests for the track command with real data."""

    def test_plan_and_track(self, tmp_path):
        runner = CliRunner()
        plan_path = str(tmp_path / "plan.json")

        # Generate a plan
        result = runner.invoke(
            main,
            ["plan", "push t-shape", "--robot", "so100", "--policy", "act", "--save", plan_path],
        )
        assert result.exit_code == 0

        # Track against real dataset
        result = runner.invoke(
            main, ["track", plan_path, "--dataset", "lerobot/pusht"]
        )
        assert result.exit_code == 0
        assert "Progress Tracker" in result.output
        assert "Episode Progress" in result.output
