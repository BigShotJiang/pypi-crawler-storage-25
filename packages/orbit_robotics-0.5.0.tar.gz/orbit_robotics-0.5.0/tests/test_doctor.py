"""Tests for orbit doctor."""

from orbit.doctor import run_doctor, print_doctor_report


def test_run_doctor_returns_checks():
    checks = run_doctor()
    assert isinstance(checks, list)
    assert len(checks) > 0
    # Each check is (category, status, message, fix)
    for cat, status, msg, fix in checks:
        assert isinstance(cat, str)
        assert status in ("ok", "warn", "bad")
        assert isinstance(msg, str)
        assert isinstance(fix, str)


def test_python_check_passes():
    checks = run_doctor()
    python_checks = [(c, s, m, f) for c, s, m, f in checks if "Python" in m]
    assert len(python_checks) >= 1
    assert python_checks[0][1] == "ok"


def test_core_deps_installed():
    checks = run_doctor()
    core_checks = [(c, s, m, f) for c, s, m, f in checks if c == "Core"]
    # numpy, pandas, scipy, rich, click should all be ok
    ok_count = sum(1 for _, s, _, _ in core_checks if s == "ok")
    assert ok_count >= 5
