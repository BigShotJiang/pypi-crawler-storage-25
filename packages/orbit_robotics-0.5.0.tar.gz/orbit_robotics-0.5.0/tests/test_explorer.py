"""Tests for orbit explore."""

from orbit.explorer import DatasetResult, print_explore_results


def test_dataset_result_creation():
    r = DatasetResult(
        repo_id="lerobot/test",
        robot_type="so100",
        num_episodes=50,
        task="pick and place",
        downloads=100,
        likes=5,
        grade="B",
    )
    assert r.repo_id == "lerobot/test"
    assert r.grade == "B"


def test_print_explore_results_empty(capsys):
    """Empty results should not crash."""
    print_explore_results([])
