"""Tests for orbit badge."""

from orbit.badge import generate_badge_markdown


def test_badge_markdown_basic():
    md = generate_badge_markdown("A")
    assert "ORBIT" in md
    assert "Grade%20A" in md
    assert "brightgreen" in md


def test_badge_markdown_with_score():
    md = generate_badge_markdown("B", score=72)
    assert "72/100" in md
    assert "green" in md


def test_badge_markdown_grade_f():
    md = generate_badge_markdown("F")
    assert "red" in md
