"""Tests for orbit config."""

from orbit.config import OrbitConfig


def test_default_config():
    cfg = OrbitConfig()
    assert cfg.default_policy == "auto"
    assert cfg.default_min_grade == "C"
    assert cfg.default_framework == "lerobot"
    assert cfg.coach == {"target_episodes": 50, "poll_interval": 2.0}


def test_from_dict():
    data = {
        "default_policy": "act",
        "gpu_memory": 24,
        "google_api_key": "test-key",
        "coach": {"target_episodes": 100},
    }
    cfg = OrbitConfig._from_dict(data)
    assert cfg.default_policy == "act"
    assert cfg.gpu_memory == 24
    assert cfg.google_api_key == "test-key"
    assert cfg.coach["target_episodes"] == 100
    assert cfg.coach["poll_interval"] == 2.0  # preserved default


def test_from_dict_env_var(monkeypatch):
    monkeypatch.setenv("MY_TEST_KEY", "secret123")
    data = {"google_api_key": "${MY_TEST_KEY}"}
    cfg = OrbitConfig._from_dict(data)
    assert cfg.google_api_key == "secret123"


def test_from_dict_missing_env_var(monkeypatch):
    monkeypatch.delenv("NONEXISTENT_KEY_12345", raising=False)
    data = {"google_api_key": "${NONEXISTENT_KEY_12345}"}
    cfg = OrbitConfig._from_dict(data)
    assert cfg.google_api_key is None
