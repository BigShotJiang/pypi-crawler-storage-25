"""Tests for enhanced display helpers."""

from orbit.utils.display import progress_bar, sparkline, radar_chart


def test_progress_bar():
    bar = progress_bar(0.75)
    assert "75%" in bar


def test_progress_bar_with_label():
    bar = progress_bar(0.5, label="coverage")
    assert "50%" in bar
    assert "coverage" in bar


def test_progress_bar_clamps():
    bar = progress_bar(1.5)
    assert "100%" in bar
    bar = progress_bar(-0.1)
    assert "0%" in bar


def test_sparkline():
    values = [1, 3, 5, 2, 4]
    result = sparkline(values)
    assert len(result) == 5


def test_sparkline_empty():
    assert sparkline([]) == ""


def test_sparkline_resampling():
    values = list(range(100))
    result = sparkline(values, width=10)
    assert len(result) == 10


def test_radar_chart():
    dims = {"coverage": 0.8, "actions": 0.5, "consistency": 0.3}
    result = radar_chart(dims)
    assert "coverage" in result
    assert "actions" in result
    assert "consistency" in result
    assert "80%" in result
    assert "50%" in result
