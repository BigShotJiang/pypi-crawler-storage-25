"""LLM 提供商模块：工厂函数用于根据配置创建提供商实例。"""

from __future__ import annotations

from acm.config import ACMConfig
from acm.llm.base import LLMBase
from acm.llm.openai_compat import OpenAICompatProvider
from acm.llm.qwen import QwenProvider


def create_llm(config: ACMConfig) -> LLMBase:
    """根据配置创建 LLM 提供商实例。"""
    provider = config.llm.provider.lower()
    api_key = config.llm.api_key
    model = config.llm.model
    base_url = config.llm.base_url

    if provider == "qwen":
        return QwenProvider(api_key=api_key, model=model, base_url=base_url)

    # 其他未知提供商均视为 OpenAI 兼容接口
    return OpenAICompatProvider(api_key=api_key, model=model, base_url=base_url)


__all__ = ["LLMBase", "OpenAICompatProvider", "QwenProvider", "create_llm"]
