"""通义千问（Qwen）适配，复用 OpenAI 兼容接口。"""

from __future__ import annotations

from acm.llm.openai_compat import OpenAICompatProvider

QWEN_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"


class QwenProvider(OpenAICompatProvider):
    """通义千问提供商，自动设置 base_url。"""

    def __init__(self, api_key: str, model: str, base_url: str = ""):
        super().__init__(
            api_key=api_key,
            model=model,
            base_url=base_url or QWEN_BASE_URL,
        )
