"""ACM-CLI: 基于 LLM 的 Git Commit Message 自动生成工具"""

__version__ = "0.2.0"
