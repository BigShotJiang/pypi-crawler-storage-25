from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional


@dataclass
class ActivityNote:
    note_id: str
    identity_id: str
    body_id: str
    session_id: str
    content: str
    created_at: str
    tags: List[str] = field(default_factory=list)


def _parse_note_dt(raw: str) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


class ActivityFeed:
    MAX_ENTRIES = 1000

    def __init__(self, workspace: str | Path):
        self._meta_dir = Path(workspace) / "_meta"
        self._meta_dir.mkdir(parents=True, exist_ok=True)
        self._path = self._meta_dir / "activity_feed.jsonl"
        self._archive = self._meta_dir / "activity_feed.jsonl.1"

    def publish(self, note: ActivityNote) -> ActivityNote:
        data = (json.dumps(asdict(note), ensure_ascii=False) + "\n").encode("utf-8")
        fd = os.open(self._path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o644)
        try:
            os.write(fd, data)
        finally:
            os.close(fd)
        self._maybe_rotate()
        return note

    def list_for_identity(
        self,
        identity_id: str,
        *,
        limit: int = 20,
        max_age_hours: float = 6.0,
        exclude_session: str = "",
    ) -> List[ActivityNote]:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        latest_by_session: dict[str, tuple[ActivityNote, datetime]] = {}

        sources = [self._archive, self._path]
        for source in sources:
            if not source.exists():
                continue
            with source.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        raw = json.loads(line)
                        note = ActivityNote(**raw)
                    except Exception:
                        continue

                    if note.identity_id != identity_id:
                        continue
                    if exclude_session and note.session_id == exclude_session:
                        continue

                    created = _parse_note_dt(note.created_at)
                    if created is None:
                        continue
                    if created < cutoff:
                        continue

                    prev = latest_by_session.get(note.session_id)
                    if prev is None or created > prev[1]:
                        latest_by_session[note.session_id] = (note, created)

        notes = sorted(
            latest_by_session.values(),
            key=lambda pair: pair[1],
            reverse=True,
        )
        return [note for note, _ in notes[:limit]]

    def _maybe_rotate(self) -> None:
        try:
            with self._path.open("r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) <= self.MAX_ENTRIES:
                return
            rotated = lines[:-self.MAX_ENTRIES]
            keep = lines[-self.MAX_ENTRIES:]
            tmp = self._meta_dir / f"activity_feed.jsonl.1.tmp.{os.getpid()}"
            try:
                existing: list[str] = []
                if self._archive.exists():
                    with self._archive.open("r", encoding="utf-8") as f:
                        existing = f.readlines()
                with tmp.open("w", encoding="utf-8") as f:
                    f.writelines(existing + rotated)
                os.replace(tmp, self._archive)
            except Exception:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
                raise
            with self._path.open("w", encoding="utf-8") as f:
                f.writelines(keep)
        except Exception:
            pass
