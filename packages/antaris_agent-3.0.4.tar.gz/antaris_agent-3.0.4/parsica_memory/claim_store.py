"""
parsica_memory.claim_store — Sidecar claim family storage.

Claim families group records that make the same assertion.
When a claim is superseded, all linked records are downweighted in retrieval.

Storage: <workspace>/_meta/claims/families.jsonl (append-only with periodic compaction)
"""
import json
import os
import threading
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional, Dict, List


@dataclass
class ClaimFamily:
    family_id: str
    normalized_assertion: str
    state: str = "current"  # current | superseded | deprecated | do_not_use
    confidence: float = 1.0
    source_record_ids: List[str] = field(default_factory=list)
    supersedes: str = ""  # family_id this replaces
    corrected_by: str = ""  # family_id that corrected this
    created_at: str = ""
    updated_at: str = ""

    _VALID_STATES = frozenset({"current", "superseded", "deprecated", "do_not_use"})

    def __post_init__(self):
        if self.state not in self._VALID_STATES:
            raise ValueError(f"invalid claim state: {self.state!r} (valid: {self._VALID_STATES})")
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ClaimFamily":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class ClaimStore:
    """Thread-safe sidecar store for claim families."""

    CLAIM_STATE_WEIGHTS = {
        "current": 1.0,
        "superseded": 0.5,
        "deprecated": 0.25,
        "do_not_use": 0.0,
    }

    def __init__(self, workspace: str):
        self._workspace = workspace
        self._meta_dir = os.path.join(workspace, "_meta", "claims")
        self._families_path = os.path.join(self._meta_dir, "families.jsonl")
        self._lock = threading.Lock()
        self._families: Dict[str, ClaimFamily] = {}
        self._record_to_family: Dict[str, str] = {}  # record_id -> family_id
        self._load()

    def _load(self):
        """Load families from JSONL sidecar."""
        if not os.path.exists(self._families_path):
            return
        with self._lock:
            self._families.clear()
            self._record_to_family.clear()
            with open(self._families_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        cf = ClaimFamily.from_dict(d)
                        self._families[cf.family_id] = cf
                        for rid in cf.source_record_ids:
                            self._record_to_family[rid] = cf.family_id
                    except (json.JSONDecodeError, TypeError):
                        continue

    def _save(self):
        """Rewrite JSONL from in-memory state (atomic write)."""
        os.makedirs(self._meta_dir, exist_ok=True)
        tmp_path = self._families_path + ".tmp"
        with open(tmp_path, "w") as f:
            for cf in self._families.values():
                f.write(json.dumps(cf.to_dict()) + "\n")
        os.replace(tmp_path, self._families_path)

    def add_family(self, family: ClaimFamily) -> None:
        """Add or update a claim family."""
        with self._lock:
            self._families[family.family_id] = family
            for rid in family.source_record_ids:
                self._record_to_family[rid] = family.family_id
            self._save()

    def get_family(self, family_id: str) -> Optional[ClaimFamily]:
        """Get a claim family by ID."""
        return self._families.get(family_id)

    def get_family_for_record(self, record_id: str) -> Optional[ClaimFamily]:
        """Get the claim family a record belongs to."""
        fid = self._record_to_family.get(record_id)
        if fid:
            return self._families.get(fid)
        return None

    def get_claim_weight(self, record_id: str) -> float:
        """Get the claim-family weight modifier for a record (1.0 if no family)."""
        family = self.get_family_for_record(record_id)
        if family is None:
            return 1.0
        return self.CLAIM_STATE_WEIGHTS.get(family.state, 1.0)

    def supersede_claim(self, old_family_id: str, new_family_id: str) -> bool:
        """Mark old claim as superseded by new claim."""
        with self._lock:
            old = self._families.get(old_family_id)
            new = self._families.get(new_family_id)
            if old is None or new is None:
                return False
            old.state = "superseded"
            old.corrected_by = new_family_id
            old.updated_at = datetime.now(timezone.utc).isoformat()
            new.supersedes = old_family_id
            new.updated_at = datetime.now(timezone.utc).isoformat()
            self._save()
            return True

    def link_record(self, record_id: str, family_id: str) -> bool:
        """Link a record to a claim family."""
        with self._lock:
            family = self._families.get(family_id)
            if family is None:
                return False
            if record_id not in family.source_record_ids:
                family.source_record_ids.append(record_id)
            self._record_to_family[record_id] = family_id
            self._save()
            return True

    @property
    def families(self) -> Dict[str, ClaimFamily]:
        return dict(self._families)

    def __len__(self) -> int:
        return len(self._families)
