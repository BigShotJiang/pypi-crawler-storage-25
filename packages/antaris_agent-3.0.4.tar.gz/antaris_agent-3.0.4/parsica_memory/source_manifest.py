"""
parsica_memory.source_manifest — Provenance index for ingested records.

Maps ``(identity_id, body_id, source_type, source_id) -> [record_ids]``.
Built incrementally at ingest commit time.
Consumed by Knowledge Pack assembly and (planned) QTE source routing.

v3.0.4-r2 (Eye R1 architectural P0s resolved):

A-01 — Identity/body scoping:
    5-tuple key, nested-dict index so scope is structurally enforceable.
    ``add()`` and ``lookup()`` require keyword-only ``identity_id`` and
    ``body_id``. ``lookup_scoped(scope_policy)`` composes with the shipped
    ``ScopePolicy`` from retrieval.py. Legacy records are quarantined under
    the ``__legacy_unknown_identity__`` / ``__legacy_unknown_body__``
    sentinels — only reachable by callers that explicitly opt in.

A-02 — Tombstone protocol:
    Inline ``"op":"tombstone"`` records honor supersede, retract, purge,
    do_not_use, forgotten, deprecated state transitions. Lookup filters
    tombstoned record_ids automatically.

A-03 — Source allow-list:
    ``source_type`` must be in ``NATIVE_SOURCE_TYPES`` (contracts.py).
    ``add()`` fails closed on unknown types; load-time quarantines legacy
    records with unknown source_type to the ``__legacy_unknown_source__``
    bucket.

A-04 — HMAC integrity:
    Each JSONL line carries ``seq``, ``prev_seal``, ``seal`` (HMAC-SHA256
    chain). ``_ensure_loaded`` verifies the chain; tampered or injected
    lines are quarantined. Legacy unsealed prefix is anchored with a
    one-shot ``"op":"legacy_seal"`` record on first R2 boot.

Non-architectural hardening inherited from R1:
    - RLock-protected writes + ``threading.Event`` load-gate
    - Input sanitization (C0/DEL/C1/surrogates/line-separators)
    - Hash-suffixed clamping (no long-key aliasing)
    - Persist retry queue (drained on next add or explicit flush)
    - Read-only ``_ManifestView`` for public accessors

KNOWN LIMITATIONS (accepted as Eye R2/R3 tradeoffs):
    - F3 (hook placement vs segment flush): the per-entry hook fires
      after index insertion but may fire BEFORE the segment buffer
      holding the MemoryEntry has been flushed. If the process crashes
      in the gap, the manifest will claim provenance for a record that
      the segment never persisted. ``reconcile_with_store()`` surfaces
      these orphans at startup so operators can decide whether to
      prune or rematerialize; R4 will move the hook to fire atomically
      with segment flush.
    - F4 (no production readers yet): QTE and Pack do not yet consume
      ``get_by_source``. Until they do, the manifest is a write-only
      audit log. Tracked in post-R3 ADR.
    - F9 (per-add fsync): each ``add()`` opens/appends/closes the
      JSONL. Acceptable for single-process + local-disk workspaces.
      NFS / multi-writer scenarios are explicitly unsupported.
    - A-07/F-R2-08: hash/record_id identity conflation is resolved
      at the "re-ingest-after-tombstone" layer via op=untombstone,
      not by introducing a separate identifier tier. Acceptable for
      now; revisit if we introduce soft-merge or split semantics.
"""
from __future__ import annotations

import enum
import hashlib
import hmac
import json
import logging
import os
import secrets
import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

try:  # pragma: no cover - Windows fallback is exercised via the clear error path.
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# --- Public exceptions ------------------------------------------------------

class ManifestIntegrityError(RuntimeError):
    """Raised when the manifest integrity gate refuses an operation.

    Eye R2 Judge Opus "ship a consumer that exercises health()" was the
    first caller (``MemorySystemV4.get_by_source``).  Eye R4 P0-5 made
    this the single point of refusal for every gated public method on
    :class:`SourceManifest` — see :meth:`SourceManifest._require_usable`
    and the state matrix in
    ``specs/SOURCE_MANIFEST_R4_1_SCOPE_OPUS.md`` §4.2.
    """


class ManifestLockTimeoutError(ManifestIntegrityError):
    """Raised when the per-workspace manifest lock cannot be acquired in time."""


# --- R4.1 Cluster A: integrity-gate state matrix ---------------------------
# Fail-closed decision table. The gate helper ``_require_usable`` consults
# these three sets (not scattered string comparisons) so the allowed state
# surface is auditable in one place.  See
# ``specs/SOURCE_MANIFEST_R4_1_SCOPE_OPUS.md`` §4.2.
#
# ``_INTEGRITY_STATES_ALLOW_WRITE`` is the strictest ``allow`` set.  Any
# state NOT in this set refuses writes.  ``_INTEGRITY_STATES_ALLOW_READ``
# additionally permits ``degraded`` (persist-queue backlog) for reads.
# ``_INTEGRITY_STATES_HARD_REFUSE`` lists the tamper / corruption states
# where even reads are unsafe (an attacker-rewritten prefix could return
# adversary-chosen record_ids).

_INTEGRITY_STATES_ALLOW_WRITE = frozenset({
    "ok",
    "fresh",
    "anchor_missing",       # auto-heal-on-write path
    "legacy_pending_anchor",  # first-boot migration; first write anchors
    "unknown",              # pre-load transient state; _ensure_loaded will resolve
    # R4.1 Cluster J (P2-4): legacy anchor written but some quarantined lines
    # existed at load. The clean portion of the JSONL is anchored so future
    # writes are safe; the degraded signal is preserved for operator visibility
    # (health()["integrity"] != "ok") without blocking legitimate operations.
    "anchored_degraded",
})
_INTEGRITY_STATES_ALLOW_READ = _INTEGRITY_STATES_ALLOW_WRITE | frozenset({
    "degraded",             # persist backlog; reads safe, writes refused
    # R4.1 Cluster J (P2-4): legacy anchor written but quarantined lines
    # existed at load. Reads allowed; writes allowed (the anchored clean
    # lines can still grow); operators see the degraded signal explicitly.
    "anchored_degraded",
    # R4.1 Cluster D (P0-2): crash between JSONL append and anchor-
    # confirm was detected on load. Operator must inspect/reconcile
    # before further writes. Reads are permitted so the operator can
    # introspect; writes are refused until the anchor is reconciled.
    "chain_crash_recovery",
})
_INTEGRITY_STATES_HARD_REFUSE = frozenset({
    "chain_broken",
    "truncated",
    "tail_rewritten",
    "load_error",
    "secret_corrupt",           # new in R4.1 (Cluster B)
    "secret_rotation_required", # new in R4.1 (Cluster J / P1-3): secret absent on sealed workspace
})


class UnsealedWriteRefused(RuntimeError):
    """Raised when ``PARSICA_MANIFEST_DEV_NO_HMAC=1`` is active against a
    workspace that already carries a sealed HMAC chain. Never swallowed
    by the persist-retry path — this is a hard configuration error, not
    a transient IO failure.

    Eye R2 F-R2-05 (Attacker Opus): silent trust downgrade defense.
    """


# --- File layout ------------------------------------------------------------

MANIFEST_PATH = "_meta/source_manifest.jsonl"
SECRET_PATH = "_meta/.source_manifest_secret"
# Eye R2 F-R2-04: tail-tamper detection sidecar.
# Records (line_count, last_seal, seq) signed with the same HMAC secret,
# updated atomically after each successful append. On load we compare the
# on-disk JSONL state against the sidecar; a shrinking line_count means
# somebody truncated the tail (and with it, tombstones).
TAIL_ANCHOR_PATH = "_meta/.source_manifest_tail"
LOCKFILE_PATH = "_meta/.source_manifest.lock"

# R4.1 Cluster D (P1-5): monotonic update counter sidecar. Separate file
# from the main anchor so that an attacker who restores an older copy of
# the primary anchor file leaves a counter-regression fingerprint that
# the loader can detect. The counter lives in its own signed payload; any
# regression (``counter_sidecar.update_counter > anchor.update_counter``)
# is treated as ``chain_broken``.
COUNTER_PATH = "_meta/.source_manifest_counter"

# On-disk schema version. Bump when the record shape changes.
SCHEMA_VERSION = 2

# R4.1 Cluster D (P0-2, P1-5): anchor sidecar format version.
#   v1 = legacy single-phase ``{kind: tail_anchor, line_count, last_seal,
#        next_seq, updated_at, seal}`` (pre-R4.1).
#   v2 = 2-phase ``{schema_version: 2, planned: {...}, confirmed: {...},
#        update_counter, seal}`` where ``planned`` is populated before
#        the JSONL append and ``confirmed`` after. Loader detects crashes
#        in the append window by seeing ``planned.count > confirmed.count``
#        (or ``planned`` present without ``confirmed``).
# Backwards-compat: the v2 reader recognises v1 payloads and treats the
# record as ``confirmed`` with no ``planned`` (``update_counter`` defaults
# to 0). First v2 write migrates on-disk.
ANCHOR_SCHEMA_VERSION = 2
# R4.1 Cluster D: counter sidecar format version.
COUNTER_SCHEMA_VERSION = 1

# --- Sentinels --------------------------------------------------------------
# Mirror parsica_memory.scope_utils sentinels so identity/body scope semantics
# match across the retrieval filter and the manifest.

LEGACY_IDENTITY_SENTINEL = "__legacy_unknown_identity__"
LEGACY_BODY_SENTINEL = "__legacy_unknown_body__"
LEGACY_SOURCE_SENTINEL = "__legacy_unknown_source__"

# --- Allow-list -------------------------------------------------------------
# Native source types — the only values `add()` accepts. Attacker-controlled
# inputs (pack import) must be stamped with a type from this set BEFORE they
# reach `add()`. Lives here rather than contracts.py because source_manifest
# is the sole enforcement site; keeping the data close to the guard keeps
# drift low.

NATIVE_SOURCE_TYPES: frozenset = frozenset({
    # Primary ingest channels
    "discord",
    "telegram",
    "signal",
    "whatsapp",
    "slack",
    "imessage",
    "email",
    # File / web
    "file",
    "web",
    "url",
    "pdf",
    "memo",              # apple-notes memo CLI
    # Internal paths
    "inline",            # bare ingest(text) with no external id
    "api",               # programmatic API ingest
    "user_note",         # explicit user input
    "agent_turn",        # pipeline turn ingest
    "pipeline",          # enrichment pipeline generic
    "pipeline:enriched",
    "pipeline:discord",
    "pipeline:telegram",
    "pipeline:signal",
    # Typed helpers
    "fact",
    "preference",
    "procedure",
    "mistake",
    "lore_doc",
    "retrospective",
    "typed",
    "decomposed_fact",
    "enricher",
    # Pack import (hard-stamped — attacker's claim never lands here)
    "imported_pack",
    # Ambient / system
    "ambient_event",
    "system",
    # Fallbacks
    "unknown",                          # explicit opt-out when real source unknown
    LEGACY_SOURCE_SENTINEL,             # migration bucket only
})


# --- Validation constants ---------------------------------------------------

# Disallowed character ranges:
#   C0 (0x00-0x1F)    — \r \n \t and other control/break chars
#   DEL (0x7F)
#   C1 (0x80-0x9F)    — legacy controls
#   Surrogates (0xD800-0xDFFF) — lone surrogates crash UTF-8 writers
#   LS/PS (0x2028-0x2029) — non-Python JSONL parsers treat as line breaks
_DISALLOWED_CHAR_RANGES = (
    (0x0000, 0x001F),
    (0x007F, 0x007F),
    (0x0080, 0x009F),
    (0xD800, 0xDFFF),
    (0x2028, 0x2029),
)

_MAX_SOURCE_TYPE_LEN = 64
_MAX_SOURCE_ID_LEN = 512
_MAX_RECORD_ID_LEN = 128
_MAX_IDENTITY_ID_LEN = 128
_MAX_BODY_ID_LEN = 128
_MAX_REASON_LEN = 64

_HASH_SUFFIX_LEN = 10
_CLAMP_MARK = "#"


def _has_disallowed_char(s: str) -> bool:
    for ch in s:
        cp = ord(ch)
        for lo, hi in _DISALLOWED_CHAR_RANGES:
            if lo <= cp <= hi:
                return True
    return False


def _stable_hash_suffix(original: str) -> str:
    return hashlib.sha256(original.encode("utf-8", errors="replace")).hexdigest()[:_HASH_SUFFIX_LEN]


def _sanitize_field(name: str, value: str, max_len: int) -> str:
    """Validate and clamp a manifest field. Raises ValueError on bad input."""
    if not isinstance(value, str):
        raise ValueError(f"{name} must be str, got {type(value).__name__}")
    if _has_disallowed_char(value):
        raise ValueError(f"{name} contains disallowed codepoints")
    if len(value) > max_len:
        keep = max_len - _HASH_SUFFIX_LEN - len(_CLAMP_MARK)
        if keep < 1:
            keep = 0
        clamped = value[:keep] + _CLAMP_MARK + _stable_hash_suffix(value)
        logger.debug(
            "source_manifest: %s clamped from %d to %d chars (stable hash)",
            name, len(value), len(clamped),
        )
        return clamped
    return value


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


# --- Tombstone reasons ------------------------------------------------------

TOMBSTONE_REASONS = frozenset({
    "superseded",
    "retracted",
    "purged",
    "do_not_use",
    "forgotten",
    "deprecated",
    "state_sync",      # migration: record state excluded at boot
})

# Reasons that result in the record being fully hidden from lookup()
# (versus "deprecated" which is weighted-down but still visible).
TOMBSTONE_HIDE_REASONS = frozenset({
    "superseded",
    "retracted",
    "purged",
    "do_not_use",
    "forgotten",
    "state_sync",
})


# --- HMAC secret provider ---------------------------------------------------

# Env flag disables HMAC for tests/CI. Visible in health() output so production
# deployments with the flag on are obvious.
_HMAC_DISABLED_ENV = "PARSICA_MANIFEST_DEV_NO_HMAC"


# --- R4.1 Cluster B: typed HMAC status ------------------------------------
# Replaces the ``_hmac_disabled`` boolean that conflated four distinct
# runtime conditions into a single flag, swallowing corruption as
# "degraded no-HMAC mode" via a silent ``except Exception``. The enum
# values are string-valued so ``health()`` emits stable wire strings
# that log/alert consumers can pattern-match on.
#
# Transition rules (see specs/SOURCE_MANIFEST_R4_1_SCOPE_OPUS.md §4.5):
#   - PARSICA_MANIFEST_DEV_NO_HMAC=1 set, no secret file
#         -> DISABLED_BY_ENV (writes/reads allowed; explicit opt-out)
#   - secret file absent, env unset (first-boot case)
#         -> DISABLED_BY_MISSING_SECRET (writer provisions on first write)
#   - secret file present but contents not valid hex / wrong length
#         -> DISABLED_BY_SECRET_CORRUPT (tamper signal; hard-refuse)
#   - secret file present but unreadable (OSError on read)
#         -> DISABLED_BY_SECRET_CORRUPT (hard-refuse; operator investigation)
#   - sealed prefix exists but current secret cannot verify (reserved)
#         -> DISABLED_BY_ROTATION (future rotation detection)
#   - secret loads cleanly
#         -> ENABLED (nominal)
#
# ``_ensure_secret`` is non-throwing: it records status and leaves the
# Cluster A gate (``_require_usable``) to raise on use. This keeps
# eager construction safe for callers that build a SourceManifest then
# dispatch operations conditionally, while still failing hard on the
# first real operation against a corrupt workspace.

class _HmacStatus(str, enum.Enum):
    ENABLED = "enabled"
    DISABLED_BY_ENV = "disabled_by_env"
    DISABLED_BY_MISSING_SECRET = "disabled_by_missing_secret"
    DISABLED_BY_SECRET_CORRUPT = "disabled_by_secret_corrupt"
    DISABLED_BY_ROTATION = "disabled_by_rotation"

    def __str__(self) -> str:  # pragma: no cover - enum plumbing
        return self.value


# Log-line marker consumed by ops monitoring to alert on HMAC degradation.
# Keep the prefix stable — scraping tools pattern-match on it. Emitted by
# ``_emit_hmac_degraded_alert`` below.
_HMAC_DEGRADED_LOG_PREFIX = "PARSICA-MANIFEST-HMAC-DEGRADED:"


def _emit_hmac_degraded_alert(status: "_HmacStatus", secret_path: str,
                              detail: str) -> None:
    """Ops-alert hook for Cluster B degraded-HMAC transitions.

    Emits a WARNING log line with a distinctive prefix so ops dashboards
    / log scrapers can alert. Kept as a standalone function so tests
    and operators can patch a single target when wiring external
    notification channels (PagerDuty, Slack, Prometheus text exporter).
    Callers invoke this whenever ``_HmacStatus`` transitions to any
    non-ENABLED value that reflects a genuine degradation (corrupt,
    rotation) — DISABLED_BY_ENV is an operator opt-out and does NOT
    call this hook.
    """
    logger.warning(
        "%s status=%s secret_path=%s detail=%s",
        _HMAC_DEGRADED_LOG_PREFIX, status.value, secret_path, detail,
    )
# Eye R3.1 F-R3-04: opt-in to auto-anchor a pre-existing unsealed prefix
# on first boot. Without this flag, a freshly-created secret paired with
# unsealed lines on disk is refused — the legitimate sequence is:
# (1) operator runs without HMAC to accumulate legacy JSONL, (2) operator
# sets this env var once to explicitly bless that prefix, (3) the one-shot
# legacy_seal anchors it. Without the flag, a prior-boot attacker cannot
# plant unsealed lines into a fresh workspace and have first-boot silently
# anchor them as legitimate.
_ADOPT_LEGACY_ENV = "PARSICA_MANIFEST_ADOPT_LEGACY"
# R4.1 Cluster J (P1-3): explicit operator opt-in required when the HMAC
# secret is absent but the JSONL already contains sealed records. Without
# this gate, a deleted secret silently auto-creates a new one, invalidating
# the entire chain. Setting this env var signals intentional rotation and
# triggers a PARSICA-MANIFEST-HMAC-DEGRADED ops-alert so dashboards catch it.
_ROTATE_SECRET_ENV = "PARSICA_MANIFEST_ROTATE_SECRET"


def _jsonl_has_sealed_lines(jsonl_path: str) -> bool:
    """Quick probe: does the JSONL contain any line with a ``seal`` field?

    R4.1 Cluster J (P1-3): called by ``_ensure_secret`` before the JSONL
    is fully loaded, to determine whether auto-creating a new HMAC secret
    would invalidate pre-existing sealed records. We scan line-by-line and
    short-circuit on the first match so large manifests pay minimal cost.
    """
    try:
        with open(jsonl_path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except (json.JSONDecodeError, ValueError):
                    continue
                if rec.get("seal"):
                    return True
    except OSError:
        pass
    return False


def _load_or_create_secret(secret_path: str) -> bytes:
    """Read the per-workspace HMAC secret or create a new one at 0600.

    Returns the raw 32-byte secret. File is stored as hex for easy inspection.
    """
    parent = os.path.dirname(secret_path)
    if os.path.exists(secret_path):
        try:
            with open(secret_path, "rb") as f:
                hex_bytes = f.read().strip()
            secret = bytes.fromhex(hex_bytes.decode("ascii"))
            if len(secret) != 32:
                raise ValueError(f"secret length {len(secret)} != 32")
            return secret
        except (OSError, ValueError) as e:
            logger.error(
                "source_manifest: secret at %s is unreadable (%s); "
                "refusing to rotate without explicit operator action",
                secret_path, e,
            )
            raise
    # Create fresh. Parent dir 0700, file 0600.
    os.makedirs(parent, exist_ok=True)
    try:
        os.chmod(parent, 0o700)
    except OSError:
        pass  # Windows, or a filesystem that rejects mode bits.
    secret = secrets.token_bytes(32)
    # Write atomically so a crash doesn't leave a half-written secret.
    tmp = secret_path + ".tmp"
    with open(tmp, "w", encoding="ascii") as f:
        f.write(secret.hex())
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, secret_path)
    logger.info("source_manifest: created new HMAC secret at %s", secret_path)
    return secret


def _canonical_payload(rec: dict) -> bytes:
    """Stable JSON serialization for HMAC signing.

    Sorted keys, no whitespace, ensure_ascii=False. The ``seal`` field is
    explicitly excluded — it's what we're computing.
    """
    payload = {k: v for k, v in rec.items() if k != "seal"}
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def _compute_seal(secret: bytes, rec: dict) -> str:
    return hmac.new(secret, _canonical_payload(rec), hashlib.sha256).hexdigest()


# --- Read-only view ---------------------------------------------------------


class _ManifestView:
    """Read-only view over a SourceManifest.

    Returned by ``SourceManifest.view()`` so public accessors (QTE, pack
    assembly, debug UIs) physically cannot ``add()`` entries. Writes are
    reserved for the ingest path.
    """

    __slots__ = ("_backing",)

    def __init__(self, backing: "SourceManifest") -> None:
        self._backing = backing

    def lookup(self, source_type: str, source_id: str, *,
               identity_id: str, body_id: Optional[str] = None) -> List[str]:
        return self._backing.lookup(source_type, source_id,
                                    identity_id=identity_id, body_id=body_id)

    def lookup_scoped(self, source_type: str, source_id: str,
                      scope_policy) -> List[str]:
        return self._backing.lookup_scoped(source_type, source_id, scope_policy)

    def all_sources(self, *, identity_id: Optional[str] = None,
                    body_id: Optional[str] = None) -> List[Tuple[str, str, str, str]]:
        return self._backing.all_sources(identity_id=identity_id, body_id=body_id)

    def stats(self) -> dict:
        return self._backing.stats()

    def health(self) -> dict:
        return self._backing.health()

    def reconcile_with_store(self, known_hashes: Set[str]) -> dict:
        return self._backing.reconcile_with_store(known_hashes)


# --- Main class -------------------------------------------------------------


class SourceManifest:
    """Provenance index keyed by ``(identity_id, body_id, source_type, source_id)``.

    Persisted as JSONL at ``workspace/_meta/source_manifest.jsonl``.
    Append-only; thread-safe under an RLock.

    Call sites:
      - ``add(...)`` is invoked by the ingest commit path ONLY, via the
        ``_record_provenance()`` helper in MemorySystemV4.
      - ``tombstone(...)`` is invoked by lifecycle hooks (forget,
        delete_source, supersede, state transitions).
      - All read paths (``lookup``, ``lookup_scoped``, ``all_sources``,
        ``stats``, ``health``) are safe to expose via ``view()``.
    """

    def __init__(self, workspace: str, *, lock_timeout_seconds: float = 30.0) -> None:
        self._workspace = workspace
        self._path = str(Path(workspace) / MANIFEST_PATH)
        self._secret_path = str(Path(workspace) / SECRET_PATH)
        self._tail_anchor_path = str(Path(workspace) / TAIL_ANCHOR_PATH)
        # R4.1 Cluster D (P1-5): monotonic counter sidecar for anchor
        # rollback detection. See ``COUNTER_PATH``.
        self._counter_path = str(Path(workspace) / COUNTER_PATH)
        self._lockfile_path = str(Path(workspace) / LOCKFILE_PATH)
        self._lock_timeout_seconds = float(lock_timeout_seconds)

        # Nested index: identity -> body -> (source_type, source_id) -> [record_ids]
        # The structural nesting defends against code paths that accidentally
        # iterate the whole manifest without checking identity_id.
        self._index: Dict[str, Dict[str, Dict[Tuple[str, str], List[str]]]] = \
            defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        # Parallel O(1) dedup set, same nesting.
        self._index_sets: Dict[str, Dict[str, Dict[Tuple[str, str], Set[str]]]] = \
            defaultdict(lambda: defaultdict(lambda: defaultdict(set)))
        # identity_id -> set of tombstoned record_ids
        self._tombstones: Dict[str, Set[str]] = defaultdict(set)
        # identity_id -> record_id -> reason (for introspection / future purge)
        self._tombstone_reasons: Dict[str, Dict[str, str]] = defaultdict(dict)
        # Eye R2 F-R2-02: identity_id -> record_id -> retrieval_scope string.
        # Backs lookup_scoped() so allowed_scopes can be enforced on the
        # manifest side instead of silently passing through to the caller.
        self._scope_by_rid: Dict[str, Dict[str, str]] = defaultdict(dict)

        self._loaded = threading.Event()
        self._pending_persist: List[dict] = []
        self._dirty_count = 0
        self._persist_failures = 0
        self._persist_retries = 0
        self._legacy_lines_migrated = 0
        self._tombstoned_records = 0
        self._quarantined_lines = 0

        # HMAC chain state. Updated under the lock by `_append_line`.
        self._hmac_disabled = bool(os.environ.get(_HMAC_DISABLED_ENV))
        # R4.1 Cluster B: typed HMAC status replaces the conflated
        # ``_hmac_disabled`` boolean. The boolean is retained for
        # backwards compatibility with call sites that gate on
        # "should I stamp a seal?" (any non-ENABLED status implies
        # _hmac_disabled = True), but new code reads the enum for
        # distinguishing env-opt-out from tamper/missing/rotation.
        # Initialised from the env flag; _ensure_secret resolves it.
        self._hmac_status: _HmacStatus = (
            _HmacStatus.DISABLED_BY_ENV
            if self._hmac_disabled
            else _HmacStatus.ENABLED
        )
        self._secret: Optional[bytes] = None
        self._last_seal_hex: str = ""   # "" means chain starts fresh
        self._next_seq: int = 0
        # Eye R2 F-R2-05: set during load if we observed at least one
        # sealed line on disk. If true, future unsealed appends are
        # refused even under PARSICA_MANIFEST_DEV_NO_HMAC=1.
        self._has_sealed_prefix = False
        # Eye R2 F-R2-04: line count for tail-anchor truncation detection.
        self._line_count = 0
        # Eye R3.1 F-R3-04: set by _ensure_secret() to record whether
        # the HMAC secret file already existed on disk before this boot.
        # If it didn't exist, we refuse to auto-anchor pre-existing
        # unsealed lines (first-boot forge defense).
        self._secret_preexisted = False
        self._integrity_state: str = "unknown"
        # R4.1 Cluster D (P1-5): highest observed update_counter. Loaded
        # from the counter sidecar + anchor on _ensure_loaded, advanced
        # on every successful 2-phase anchor write. Used to detect
        # anchor-rollback on the next load.
        self._update_counter: int = 0

        self._lock = threading.RLock()

    @contextmanager
    def _with_workspace_lock(self):
        """Serialize manifest write transactions across processes.

        The lock wraps the full mutation transaction so Cluster D can drop
        its append + two-phase anchor protocol inside the same context without
        changing call sites. Reads intentionally do not acquire this lock.
        """
        if fcntl is None:
            raise ManifestIntegrityError(
                "SourceManifest workspace locking requires fcntl. Windows support "
                "is deferred for R4.1; refusing multi-process writes on this platform."
            )

        os.makedirs(os.path.dirname(self._lockfile_path), exist_ok=True)
        deadline = time.monotonic() + max(self._lock_timeout_seconds, 0.0)
        with open(self._lockfile_path, "a+", encoding="utf-8") as lock_file:
            while True:
                try:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise ManifestLockTimeoutError(
                            f"Timed out after {self._lock_timeout_seconds:.3f}s acquiring "
                            f"manifest workspace lock at {self._lockfile_path}"
                        )
                    time.sleep(0.05)
            try:
                yield
            finally:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    # ------------------------------------------------------------------ load

    def _ensure_secret(self) -> None:
        """Lazily load or create the HMAC secret (A-04).

        R4.1 Cluster B (P0-6, P2-6): NON-THROWING state machine.

        On entry this method can be in any of four legitimate starting
        conditions:
          (1) env var PARSICA_MANIFEST_DEV_NO_HMAC=1  -> DISABLED_BY_ENV
          (2) secret file already loaded               -> no-op
          (3) secret file absent, env unset            -> probe further
          (4) secret file present on disk              -> attempt load

        On corruption (ValueError: invalid hex or wrong length; OSError
        on read) the method does NOT raise. Instead it transitions
        ``_hmac_status`` to DISABLED_BY_SECRET_CORRUPT, flips the
        integrity state to ``secret_corrupt`` (which is in
        _INTEGRITY_STATES_HARD_REFUSE), emits an ops-alert log line,
        and returns. The Cluster A ``_require_usable`` gate raises
        ManifestIntegrityError on the first real operation so eager
        construction remains safe while use fails hard.

        Replaces the pre-R4.1 silent-downgrade:

            except Exception as e:
                ...
                self._hmac_disabled = True    # <- forgery primitive

        which conflated tamper with transient I/O and let any attacker
        who could corrupt the secret file turn HMAC verification off
        for subsequent writes. The new path hard-refuses every
        operation on corruption.

        Eye R3.1 F-R3-04: ``_secret_preexisted`` records whether the
        file existed BEFORE this call so the first-boot forge defense
        (``_load_from_disk``) can refuse to auto-anchor unsealed lines
        written before a fresh secret was provisioned.
        """
        if self._hmac_disabled or self._secret is not None:
            return
        self._secret_preexisted = os.path.exists(self._secret_path)

        if not self._secret_preexisted:
            # R4.1 Cluster J (P1-3): if the JSONL already contains sealed
            # records, auto-creating a new secret would silently invalidate
            # the entire HMAC chain. Gate rotation behind an explicit env flag.
            if os.path.exists(self._path) and _jsonl_has_sealed_lines(self._path):
                rotate = bool(os.environ.get(_ROTATE_SECRET_ENV))
                if not rotate:
                    logger.error(
                        "source_manifest: secret file absent at %s but the JSONL "
                        "contains sealed records — refusing to auto-create a new "
                        "secret (that would silently invalidate the HMAC chain). "
                        "Set %s=1 to authorise an explicit rotation (triggers an "
                        "ops-alert) or restore the original secret.",
                        self._secret_path, _ROTATE_SECRET_ENV,
                    )
                    self._hmac_status = _HmacStatus.DISABLED_BY_ROTATION
                    self._integrity_state = "secret_rotation_required"
                    _emit_hmac_degraded_alert(
                        _HmacStatus.DISABLED_BY_ROTATION,
                        self._secret_path,
                        "sealed records exist but secret absent; "
                        f"set {_ROTATE_SECRET_ENV}=1 to authorise rotation",
                    )
                    return
                # Operator explicitly authorised rotation — allow but alert.
                logger.warning(
                    "source_manifest: %s=1 set; proceeding with HMAC secret "
                    "rotation on workspace with pre-existing sealed records. "
                    "Historical HMAC chain will no longer be verifiable.",
                    _ROTATE_SECRET_ENV,
                )
                _emit_hmac_degraded_alert(
                    _HmacStatus.DISABLED_BY_ROTATION,
                    self._secret_path,
                    "explicit secret rotation authorised via env flag; "
                    "status=DISABLED_BY_ROTATION",
                )
            # First-boot case (no sealed records) or authorised rotation.
            # Leave _secret=None and record DISABLED_BY_MISSING_SECRET;
            # the first add() will go through _load_or_create_secret via
            # this method again once a write lands (the _hmac_disabled flag
            # stays False so _append_line's seal path is still reachable;
            # on that call we retry provisioning by falling through to the
            # file-missing branch below). This is NOT a tamper signal.
            self._hmac_status = _HmacStatus.DISABLED_BY_MISSING_SECRET
            # Create the secret lazily on the first write attempt.
            try:
                self._secret = _load_or_create_secret(self._secret_path)
            except OSError as e:
                # Parent dir unwritable / permissions error. We can't
                # provision; record missing and let the gate refuse on
                # subsequent use. Don't raise — construction stays safe.
                logger.warning(
                    "source_manifest: could not provision fresh HMAC secret at %s (%s); "
                    "remaining in DISABLED_BY_MISSING_SECRET until resolved",
                    self._secret_path, e,
                )
                _emit_hmac_degraded_alert(
                    _HmacStatus.DISABLED_BY_MISSING_SECRET,
                    self._secret_path,
                    f"fresh-secret provisioning failed: {type(e).__name__}: {e}",
                )
                return
            except ValueError as e:
                # Should not happen on the create path (token_bytes +
                # hex-encode is deterministic) but defend explicitly.
                logger.warning(
                    "source_manifest: fresh HMAC secret rejected by validator (%s); "
                    "recording secret_corrupt", e,
                )
                self._hmac_status = _HmacStatus.DISABLED_BY_SECRET_CORRUPT
                self._integrity_state = "secret_corrupt"
                self._secret = None
                _emit_hmac_degraded_alert(
                    _HmacStatus.DISABLED_BY_SECRET_CORRUPT,
                    self._secret_path,
                    f"{type(e).__name__}: {e}",
                )
                return
            self._hmac_status = _HmacStatus.ENABLED
            return

        # Secret file exists on disk. Any failure to load it is a
        # corruption / tamper signal — NOT a transient condition.
        try:
            self._secret = _load_or_create_secret(self._secret_path)
        except (OSError, ValueError) as e:
            # Narrow exception handling per Cluster B spec. Do NOT
            # ``except Exception:`` — that's the bug we're closing.
            # Distinguish ValueError (content is wrong; definitely not
            # transient) from OSError (could be permissions / hardware)
            # for the operator message but treat both as hard-refuse:
            # a present-but-unreadable secret in production is a
            # forensic event, not a silent downgrade.
            self._hmac_status = _HmacStatus.DISABLED_BY_SECRET_CORRUPT
            self._integrity_state = "secret_corrupt"
            self._secret = None
            detail = f"{type(e).__name__}: {e}"
            logger.error(
                "source_manifest: HMAC secret at %s is present but unusable (%s). "
                "This is a tamper signal; refusing all operations until "
                "operator intervention. See docs/RECOVERY.md for the "
                "quarantine-and-reseal procedure — do NOT simply delete "
                "the secret file (that would silently accept attacker-"
                "planted records).",
                self._secret_path, detail,
            )
            _emit_hmac_degraded_alert(
                _HmacStatus.DISABLED_BY_SECRET_CORRUPT,
                self._secret_path,
                detail,
            )
            return
        self._hmac_status = _HmacStatus.ENABLED

    def _ensure_loaded(self) -> None:
        """Load JSONL into the in-memory index on first use. Idempotent."""
        if self._loaded.is_set():
            return
        with self._lock:
            if self._loaded.is_set():
                return
            self._ensure_secret()
            # R4.1 Cluster B: if _ensure_secret flipped the integrity
            # state to ``secret_corrupt`` (a hard-refuse tamper signal),
            # do not let subsequent load logic overwrite it with
            # ``fresh`` / ``ok``. The gate must raise on every
            # operation until operator intervention.
            # R4.1 Cluster J (P1-3): same treatment for
            # ``secret_rotation_required`` — _load_from_disk must not
            # launder a detected rotation back to ``ok`` because HMAC
            # is disabled, the chain cannot be verified with the new
            # (as-yet nonexistent) secret, and the operator MUST intervene.
            _hard_refuse_from_secret = self._integrity_state in (
                "secret_corrupt",
                "secret_rotation_required",
            )
            if not os.path.exists(self._path):
                if not _hard_refuse_from_secret:
                    self._integrity_state = "fresh"
                self._loaded.set()
                return
            try:
                self._load_from_disk()
            except Exception as e:  # pragma: no cover
                logger.exception(
                    "source_manifest: load failed (%s); starting empty", e,
                )
                self._integrity_state = "load_error"
            # _load_from_disk can overwrite _integrity_state to "ok" etc.
            # Re-assert hard-refuse states so tamper is never laundered.
            if _hard_refuse_from_secret:
                self._integrity_state = (
                    "secret_corrupt"
                    if self._hmac_status == _HmacStatus.DISABLED_BY_SECRET_CORRUPT
                    else "secret_rotation_required"
                )
            self._loaded.set()

    # -------------------------------------------------------- integrity gate
    # R4.1 Cluster A (Eye R4 P0-5, dissolves P1-4):
    # Move the "safe-use gate" from a docstring promise into executable
    # code. Every gated public method (add, tombstone, lookup,
    # lookup_scoped, all_sources, stats, reconcile_with_store, flush)
    # calls ``_require_usable(op=...)`` at entry, after ``_ensure_loaded``
    # and inside the write-lock. Writes refuse in any state not in
    # ``_INTEGRITY_STATES_ALLOW_WRITE``; strict reads refuse in any state
    # not in ``_INTEGRITY_STATES_ALLOW_READ`` (which additionally permits
    # ``degraded`` for persist-backlog tolerance); tamper/corruption
    # states in ``_INTEGRITY_STATES_HARD_REFUSE`` refuse even
    # ``strict=False`` probes.
    #
    # ``strict=False`` is the escape hatch for health/probe reads that
    # tolerate ``degraded`` but still refuse hard-refuse states. It is
    # NOT a general best-effort override — tamper states always raise.
    #
    # See specs/SOURCE_MANIFEST_R4_1_SCOPE_OPUS.md §4.2 for the matrix.

    # Map gated operation name → True if the operation mutates state.
    # Used by _require_usable to pick the right allow-set. Kept as a
    # frozenset so lint tests can assert exhaustiveness against the
    # actual public API.
    _WRITE_OPS: frozenset = frozenset({
        "add", "tombstone", "flush",
    })
    _READ_OPS: frozenset = frozenset({
        "lookup", "lookup_scoped", "all_sources", "stats",
        "reconcile_with_store",
    })

    def _require_usable(self, op: str, strict: bool = True) -> None:
        """Gate-check the integrity state for ``op``.

        MUST be called after ``_ensure_loaded()`` from every public
        method whose behaviour depends on the manifest being trustworthy
        (writes + strict reads). ``health()`` and ``view()`` are
        deliberately ungated — ``health`` is the diagnostic surface and
        ``view`` merely returns a wrapper.

        Args:
            op: name of the calling method, for error messages and
                routing into the write vs read allow-set.
            strict: True (default) for operations that must refuse on
                ``degraded`` or any non-ok state; False for health
                probes that tolerate ``degraded`` (persist-backlog).
                Hard-refuse tamper/corruption states raise under BOTH
                strict and non-strict — ``strict=False`` is not a
                tamper override.

        Raises:
            ManifestIntegrityError: if the current integrity state does
                not permit ``op``. The error message names the state,
                the op, and (when relevant) the HMAC-status hint so an
                operator can route to the correct recovery procedure.
        """
        state = self._integrity_state
        # Hard-refuse states always raise. ``strict=False`` does not
        # bypass tamper — a probe against a chain_broken workspace must
        # still fail closed.
        if state in _INTEGRITY_STATES_HARD_REFUSE:
            hmac_hint = getattr(self._hmac_status, "value", str(self._hmac_status))
            # R4.1 Cluster B: secret_corrupt gets an explicit
            # operator-facing message that names the secret file and
            # the recovery path. Other hard-refuse states share the
            # generic template.
            if state == "secret_corrupt":
                raise ManifestIntegrityError(
                    f"SourceManifest integrity={state!r}; operation={op!r} refused. "
                    f"HMAC secret at {self._secret_path} is present but unusable "
                    f"(hmac_status={hmac_hint}). This is a tamper signal. "
                    f"To resolve: (1) STOP the agent process, (2) inspect the "
                    f"secret file for external modification or backup/restore "
                    f"corruption, (3) see docs/RECOVERY.md for the "
                    f"quarantine-and-reseal procedure — do NOT simply delete "
                    f"the secret file."
                )
            raise ManifestIntegrityError(
                f"SourceManifest integrity={state!r} (hard-refuse); "
                f"operation={op!r} blocked. This state is a tamper or "
                f"corruption signal — see docs/RECOVERY.md for the "
                f"state-specific operator procedure. "
                f"hmac_status={hmac_hint}."
            )
        # Pick the allow-set. Unknown ops default to the strictest
        # (writes) so a future engineer adding a new method without
        # registering it in _WRITE_OPS / _READ_OPS fails closed rather
        # than silently taking the permissive read path.
        is_write = op in self._WRITE_OPS or op not in self._READ_OPS
        if is_write:
            if state not in _INTEGRITY_STATES_ALLOW_WRITE:
                raise ManifestIntegrityError(
                    f"SourceManifest integrity={state!r}; writes refused "
                    f"(operation={op!r}). Reads may still be permitted; "
                    f"drain the persist queue or complete the migration, "
                    f"then retry."
                )
            return
        # Read / probe path (op classified as read).
        if strict:
            if state not in _INTEGRITY_STATES_ALLOW_READ:
                # Defense-in-depth: the matrix should be consistent, so
                # this branch is only reachable when a future engineer
                # adds a new state without updating the allow-sets.
                raise ManifestIntegrityError(
                    f"SourceManifest integrity={state!r}; strict read "
                    f"refused (operation={op!r})."
                )
        # Non-strict (probe) reads tolerate anything outside the
        # hard-refuse set — ``degraded`` and transient states are safe
        # to observe for diagnostic purposes.

    def _load_from_disk(self) -> None:
        """Parse the JSONL, verify HMAC chain, build the index."""
        expected_prev_seal = ""
        expected_seq = 0
        bad_lines = 0
        chain_broken_at: Optional[int] = None
        legacy_prefix_anchored = False
        in_legacy_prefix = True  # remains True until we see a sealed line or legacy_seal op

        with open(self._path, encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                # Eye R2 F-R2-04: every non-empty line counts toward the
                # tail-anchor total, even quarantined ones. A stripped-tail
                # attack would reduce this number; a duplicated-tail would
                # increase it.
                self._line_count += 1
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning(
                        "source_manifest: line %d is not valid JSON, skipping",
                        line_no,
                    )
                    bad_lines += 1
                    self._quarantined_lines += 1
                    continue
                if not isinstance(rec, dict):
                    logger.warning(
                        "source_manifest: line %d is not a JSON object, skipping",
                        line_no,
                    )
                    bad_lines += 1
                    self._quarantined_lines += 1
                    continue

                schema = rec.get("schema", 1)
                if not isinstance(schema, int) or schema > SCHEMA_VERSION:
                    logger.warning(
                        "source_manifest: line %d has schema=%r, skipping",
                        line_no, schema,
                    )
                    self._quarantined_lines += 1
                    continue

                op = rec.get("op", "add")

                # HMAC chain verification (A-04) ---------------------------------
                seal = rec.get("seal")
                # Eye R2 F-R2-05 + Eye R3 Attacker GPT: mark that the
                # workspace carries sealed lines. The naive R3 version
                # trusted any `seal` field, which let an attacker poison
                # a fresh workspace with a bogus seal string and block
                # legitimate NO_HMAC dev work. The R3.1 check requires
                # the per-workspace secret file to actually exist on
                # disk — that file is the only proof the workspace was
                # ever genuinely under HMAC protection. A fabricated
                # seal without the secret file is ignored; a real seal
                # plus secret file locks the chain.
                if isinstance(seal, str) and seal:
                    if os.path.exists(self._secret_path):
                        self._has_sealed_prefix = True
                    # else: unverifiable seal claim; do not poison state.
                if op == "legacy_seal":
                    # Anchor record — verify its own HMAC but do NOT require
                    # it to chain from the prior seal (it closes a prefix).
                    if not self._hmac_disabled and self._secret is not None:
                        expected = _compute_seal(self._secret, rec)
                        if seal is None or not hmac.compare_digest(seal, expected):
                            logger.warning(
                                "source_manifest: legacy_seal anchor at line %d has bad HMAC; quarantining",
                                line_no,
                            )
                            self._quarantined_lines += 1
                            chain_broken_at = line_no
                            break
                        # Eye R2 F-R2-04: verify prefix_hash if present
                        # (new-format anchors) so legacy line contents
                        # cannot be rewritten without detection.
                        expected_prefix_hash = rec.get("prefix_hash")
                        if expected_prefix_hash:
                            count = int(rec.get("count", 0))
                            actual_prefix_hash = self._hash_legacy_prefix(count)
                            if not hmac.compare_digest(
                                expected_prefix_hash, actual_prefix_hash,
                            ):
                                logger.warning(
                                    "source_manifest: legacy_seal prefix_hash mismatch at line %d; "
                                    "unsealed prefix appears rewritten",
                                    line_no,
                                )
                                self._quarantined_lines += 1
                                chain_broken_at = line_no
                                break
                    # Anchor is good — adopt its chain state.
                    expected_prev_seal = rec.get("seal", "")
                    expected_seq = int(rec.get("next_seq", 0))
                    legacy_prefix_anchored = True
                    in_legacy_prefix = False
                    # Eye R2 F-R2-05: legacy_seal is a sealed line.
                    # Eye R3 Attacker GPT: same secret-file gate as
                    # above — don't let a fabricated legacy_seal poison.
                    if os.path.exists(self._secret_path):
                        self._has_sealed_prefix = True
                    continue
                elif seal is not None and not self._hmac_disabled and self._secret is not None:
                    # This line claims to be sealed. Verify.
                    expected = _compute_seal(self._secret, rec)
                    if not hmac.compare_digest(seal, expected):
                        logger.warning(
                            "source_manifest: HMAC verification failed at line %d (seq=%s); quarantining and hard-stopping load",
                            line_no, rec.get("seq"),
                        )
                        bad_lines += 1
                        self._quarantined_lines += 1
                        chain_broken_at = line_no
                        break
                    if rec.get("prev_seal", "") != expected_prev_seal:
                        logger.warning(
                            "source_manifest: chain break at line %d (prev_seal mismatch); quarantining remainder",
                            line_no,
                        )
                        self._quarantined_lines += 1
                        chain_broken_at = line_no
                        break
                    if rec.get("seq") != expected_seq:
                        logger.warning(
                            "source_manifest: seq mismatch at line %d (got %s, expected %d)",
                            line_no, rec.get("seq"), expected_seq,
                        )
                        self._quarantined_lines += 1
                        chain_broken_at = line_no
                        break
                    # Good sealed line — advance chain state.
                    expected_prev_seal = seal
                    expected_seq += 1
                    in_legacy_prefix = False
                    # Eye R2 F-R2-05: mark that this workspace has a
                    # sealed prefix so later unsealed appends get
                    # refused even under PARSICA_MANIFEST_DEV_NO_HMAC=1.
                    self._has_sealed_prefix = True
                elif seal is None:
                    # Unsealed line.
                    if legacy_prefix_anchored:
                        # Legacy prefix already closed; reject unsealed appends.
                        logger.warning(
                            "source_manifest: unsealed line %d after legacy prefix was closed; quarantining",
                            line_no,
                        )
                        self._quarantined_lines += 1
                        bad_lines += 1
                        continue
                    if not in_legacy_prefix:
                        # Sealed lines have already appeared; an unsealed line
                        # here is suspicious (injection attempt).
                        logger.warning(
                            "source_manifest: unsealed line %d after sealed content; quarantining",
                            line_no,
                        )
                        self._quarantined_lines += 1
                        bad_lines += 1
                        continue
                    # In the grandfathered prefix; accept but count.
                    self._legacy_lines_migrated += 1

                # Dispatch by op ------------------------------------------------
                if op == "add":
                    self._apply_add_record(rec, line_no)
                elif op == "tombstone":
                    self._apply_tombstone_record(rec, line_no)
                elif op == "untombstone":
                    # Eye R2 F-R2-08: re-enable a previously tombstoned
                    # record so downstream re-ingest can land.
                    #
                    # Eye R3.1 F-R3-08 (Attacker Opus): a legitimate
                    # untombstone is only ever written by add() under
                    # the HMAC chain — which means it MUST appear AFTER
                    # the sealed chain starts (or after the legacy_seal
                    # anchor). An untombstone in the unsealed legacy
                    # prefix is a forged record planted by an attacker
                    # to resurrect GDPR-forgotten content. Reject.
                    if in_legacy_prefix:
                        logger.warning(
                            "source_manifest: line %d has op=untombstone in legacy prefix; "
                            "rejecting (forged resurrection attempt)",
                            line_no,
                        )
                        self._quarantined_lines += 1
                        bad_lines += 1
                        continue
                    self._apply_untombstone_record(rec, line_no)
                else:
                    logger.warning(
                        "source_manifest: line %d has unknown op=%r, skipping",
                        line_no, op,
                    )
                    self._quarantined_lines += 1

        # Set chain state after load
        self._last_seal_hex = expected_prev_seal
        self._next_seq = expected_seq

        if chain_broken_at is not None:
            self._integrity_state = "chain_broken"
        elif bad_lines > 0:
            self._integrity_state = "degraded"
        elif self._legacy_lines_migrated > 0 and not legacy_prefix_anchored:
            self._integrity_state = "legacy_pending_anchor"
        else:
            self._integrity_state = "ok"

        # Eye R2 F-R2-04: tail anchor check. If a prior run wrote an
        # anchor, the JSONL must now contain at LEAST as many lines and
        # end with the same seal/seq. A reduction (including tombstone
        # tail truncation) is a tamper signal.
        #
        # Eye R3.1 F-R3-01 (Attacker Opus + Attacker Sonnet): if the
        # workspace has a sealed prefix but NO tail anchor, that's
        # either a pre-R2 workspace (legitimate: we'll refresh on next
        # append) OR an attacker deleted the anchor to re-open the
        # truncation attack. Since we can't distinguish, we fail closed
        # when the anchor is missing AND the chain reports any sealed
        # content. The operator can refresh the anchor by a single
        # successful append(), at which point integrity returns to ok.
        #
        # R4.1 Cluster D (P0-2): read the full v2 anchor payload once.
        # This surfaces the planned/confirmed sub-records so we can
        # detect crashes in the append window. ``_read_tail_anchor()``
        # still returns the legacy-shaped view for the existing
        # truncation/seal mismatch checks below.
        anchor_raw = self._read_anchor_raw()
        counter_sidecar = self._read_counter_sidecar()
        anchor = self._read_tail_anchor()

        # R4.1 Cluster D (P1-5) — anchor rollback detection.
        # If the counter sidecar survived but the anchor was restored
        # from an older snapshot, counter_sidecar.update_counter will be
        # GREATER than the counter baked into the anchor. Both are
        # HMAC-signed, so an attacker without the secret cannot forge
        # either; the only way to rewrite both consistently is with the
        # secret (which itself is tamper-detected via Cluster B).
        if anchor_raw is not None and counter_sidecar is not None:
            anchor_counter = int(anchor_raw.get("update_counter", 0))
            if counter_sidecar > anchor_counter:
                logger.warning(
                    "source_manifest: counter sidecar reports update_counter=%d but "
                    "anchor records %d; anchor rollback suspected",
                    counter_sidecar, anchor_counter,
                )
                self._integrity_state = "chain_broken"
            # Take the max as our new live counter for subsequent writes.
            self._update_counter = max(anchor_counter, counter_sidecar)
        elif anchor_raw is not None:
            self._update_counter = int(anchor_raw.get("update_counter", 0))
        elif counter_sidecar is not None:
            # Anchor absent but counter sidecar still present — the
            # normal anchor-missing path below will refuse writes; we
            # still seed _update_counter so future anchor writes stay
            # monotonic relative to prior sessions.
            self._update_counter = counter_sidecar

        # R4.1 Cluster D (P0-2) — crash-window detection.
        # A planned-only record (confirmed is None or missing) or a
        # planned.count that exceeds confirmed.count means the prior
        # process crashed between the JSONL append and the anchor
        # confirm. We transition to ``chain_crash_recovery`` — reads
        # allowed, writes refused — so the operator can reconcile.
        # A confirmed.count > planned.count (when both present) is
        # impossible in the 2-phase protocol; treat as chain_broken.
        if anchor_raw is not None and self._integrity_state == "ok":
            planned = anchor_raw.get("planned")
            confirmed = anchor_raw.get("confirmed")
            p_count = int(planned.get("count", 0)) if isinstance(planned, dict) else None
            c_count = int(confirmed.get("count", 0)) if isinstance(confirmed, dict) else None
            if isinstance(planned, dict) and confirmed is None:
                logger.warning(
                    "source_manifest: anchor has planned phase without confirmed "
                    "(count=%d); append-then-anchor crash window detected",
                    p_count,
                )
                self._integrity_state = "chain_crash_recovery"
            elif p_count is not None and c_count is not None and p_count > c_count:
                logger.warning(
                    "source_manifest: anchor planned.count=%d > confirmed.count=%d; "
                    "append-then-anchor crash window detected",
                    p_count, c_count,
                )
                self._integrity_state = "chain_crash_recovery"
            elif p_count is not None and c_count is not None and c_count > p_count:
                logger.warning(
                    "source_manifest: anchor confirmed.count=%d > planned.count=%d; "
                    "impossible in 2-phase protocol — treating as chain_broken",
                    c_count, p_count,
                )
                self._integrity_state = "chain_broken"

        if anchor is None and self._has_sealed_prefix and self._integrity_state == "ok":
            logger.warning(
                "source_manifest: sealed chain present but tail anchor is missing; "
                "refusing to treat chain as intact until a successful write refreshes the anchor",
            )
            self._integrity_state = "anchor_missing"
        if anchor is not None and self._integrity_state == "ok":
            observed = self._line_count
            expected_min = int(anchor.get("line_count", 0))
            if observed < expected_min:
                logger.warning(
                    "source_manifest: tail anchor reports %d lines but only %d remain; "
                    "refusing to treat chain as intact (tail truncation suspected)",
                    expected_min, observed,
                )
                self._integrity_state = "truncated"
            else:
                # Length is OK; check the final seal matches what the
                # anchor signed (catches the "truncate then append junk
                # back to the original length" attack).
                a_seal = anchor.get("last_seal", "")
                if a_seal and expected_prev_seal and a_seal != expected_prev_seal \
                        and observed == expected_min:
                    logger.warning(
                        "source_manifest: tail anchor seal mismatch at line %d; "
                        "chain suffix may have been rewritten",
                        observed,
                    )
                    self._integrity_state = "tail_rewritten"

        # One-shot anchor of the legacy prefix. If we loaded unsealed lines
        # without crossing a legacy_seal op, write one now so future tampering
        # is detectable.
        #
        # Eye R3.1 F-R3-04: the auto-anchor is GATED on either the HMAC
        # secret pre-existing OR the operator explicitly opting in via
        # PARSICA_MANIFEST_ADOPT_LEGACY=1. A first-boot path that creates
        # a fresh secret AND finds pre-existing unsealed lines is the
        # attacker-plant scenario; we refuse to auto-bless it and leave
        # integrity="legacy_pending_anchor" until the operator decides.
        adopt_legacy = bool(os.environ.get(_ADOPT_LEGACY_ENV))
        if (self._legacy_lines_migrated > 0 and not legacy_prefix_anchored
                and not self._hmac_disabled and self._secret is not None
                and chain_broken_at is None):
            if not (self._secret_preexisted or adopt_legacy):
                self._integrity_state = "legacy_pending_anchor"
                logger.warning(
                    "source_manifest: refusing to auto-anchor %d unsealed lines on a first-boot "
                    "fresh-secret workspace (first-boot forge defense). Set %s=1 to explicitly "
                    "adopt the pre-existing prefix as legitimate.",
                    self._legacy_lines_migrated, _ADOPT_LEGACY_ENV,
                )
            else:
                try:
                    self._write_legacy_seal(self._legacy_lines_migrated)
                    # R4.1 Cluster J (P2-4): only transition to "ok" if the
                    # pre-anchor state was clean. If we entered this block
                    # with integrity="degraded" (bad_lines > 0 before the
                    # anchor write), the anchor DOES get written but we must
                    # NOT launder the degraded signal away. Operators reading
                    # health() after this boot must see that garbage lines
                    # were quarantined even though the anchor write succeeded.
                    # "degraded" → "anchored_degraded" makes the combination
                    # explicit; downstream consumers can still read (degraded
                    # is in _INTEGRITY_STATES_ALLOW_READ) but operators see
                    # the true picture rather than a misleading "ok".
                    if self._integrity_state == "degraded":
                        self._integrity_state = "anchored_degraded"
                        logger.warning(
                            "source_manifest: legacy_seal anchor written but %d quarantined "
                            "lines remain; integrity stays 'anchored_degraded' — inspect the "
                            "JSONL for corrupted or forged entries before trusting it.",
                            self._quarantined_lines,
                        )
                    else:
                        self._integrity_state = "ok"
                except Exception as e:
                    logger.warning(
                        "source_manifest: failed to write legacy_seal anchor (%s); manifest remains in legacy_pending_anchor state",
                        e,
                    )

    def _apply_add_record(self, rec: dict, line_no: int) -> None:
        """Index a single 'op: add' record from the JSONL."""
        st = rec.get("source_type")
        sid = rec.get("source_id")
        rid = rec.get("record_id")
        ident = rec.get("identity_id")
        body = rec.get("body_id")

        if not (isinstance(st, str) and isinstance(sid, str)
                and isinstance(rid, str)):
            logger.warning(
                "source_manifest: line %d missing core fields, skipping",
                line_no,
            )
            self._quarantined_lines += 1
            return

        # Legacy migration: schema<2 records may lack identity/body. Stamp
        # sentinels so they're reachable only via explicit opt-in.
        if not isinstance(ident, str) or not ident:
            ident = LEGACY_IDENTITY_SENTINEL
            self._legacy_lines_migrated += 1
        if not isinstance(body, str) or not body:
            body = LEGACY_BODY_SENTINEL

        # Legacy migration: source_type not in allow-list → quarantine bucket.
        if st not in NATIVE_SOURCE_TYPES:
            logger.warning(
                "source_manifest: line %d has unknown source_type=%r; remapping to legacy sentinel",
                line_no, st,
            )
            # Keep the original source_id so operators can find these; just
            # rename the type so it can't claim native trust.
            st = LEGACY_SOURCE_SENTINEL

        # Defensive codepoint check for legacy lines.
        if (_has_disallowed_char(st) or _has_disallowed_char(sid)
                or _has_disallowed_char(rid)
                or _has_disallowed_char(ident) or _has_disallowed_char(body)):
            logger.warning(
                "source_manifest: line %d has disallowed codepoints, skipping",
                line_no,
            )
            self._quarantined_lines += 1
            return

        bucket = (st, sid)
        if rid not in self._index_sets[ident][body][bucket]:
            self._index[ident][body][bucket].append(rid)
            self._index_sets[ident][body][bucket].add(rid)
        # Eye R2 F-R2-02: record retrieval_scope so lookup_scoped can
        # actually enforce allowed_scopes. Blank scopes are stored as ""
        # to distinguish "scope known, unconstrained" from "scope unset".
        scope = rec.get("retrieval_scope", "") or ""
        # R4.1 Cluster J (P2-5): first-write-wins during replay. If the
        # JSONL contains duplicate add records for the same rid (e.g., from
        # re-ingest), preserve the scope that was recorded first.
        if isinstance(scope, str) and rid not in self._scope_by_rid[ident]:
            self._scope_by_rid[ident][rid] = scope

    def _apply_tombstone_record(self, rec: dict, line_no: int) -> None:
        """Apply a single 'op: tombstone' record from the JSONL."""
        rid = rec.get("record_id")
        ident = rec.get("identity_id") or LEGACY_IDENTITY_SENTINEL
        reason = rec.get("reason", "forgotten")
        if not isinstance(rid, str) or not rid:
            logger.warning(
                "source_manifest: line %d tombstone missing record_id, skipping",
                line_no,
            )
            self._quarantined_lines += 1
            return
        if reason not in TOMBSTONE_REASONS:
            logger.warning(
                "source_manifest: line %d tombstone has unknown reason=%r, coercing to 'forgotten'",
                line_no, reason,
            )
            reason = "forgotten"
        if rid not in self._tombstones[ident]:
            self._tombstones[ident].add(rid)
            self._tombstone_reasons[ident][rid] = reason
            self._tombstoned_records += 1

    def _apply_untombstone_record(self, rec: dict, line_no: int) -> None:
        """Apply a single 'op: untombstone' record from the JSONL.

        Eye R2 F-R2-08: re-ingest-after-forget. The untombstone record
        clears the in-memory tombstone state so later lookups see the
        resurrected record_id. If we see an untombstone for a record_id
        that was never tombstoned (corrupt or replay), log and ignore;
        idempotent.
        """
        rid = rec.get("record_id")
        ident = rec.get("identity_id") or LEGACY_IDENTITY_SENTINEL
        if not isinstance(rid, str) or not rid:
            logger.warning(
                "source_manifest: line %d untombstone missing record_id, skipping",
                line_no,
            )
            self._quarantined_lines += 1
            return
        tomb = self._tombstones.get(ident)
        if tomb and rid in tomb:
            tomb.discard(rid)
            self._tombstone_reasons.get(ident, {}).pop(rid, None)
            if self._tombstoned_records > 0:
                self._tombstoned_records -= 1

    # ---------------------------------------------------------------- persist

    def _serialize_add(self, *, source_type: str, source_id: str,
                       record_id: str, identity_id: str, body_id: str,
                       retrieval_scope: str) -> dict:
        return {
            "schema": SCHEMA_VERSION,
            "op": "add",
            "source_type": source_type,
            "source_id": source_id,
            "record_id": record_id,
            "identity_id": identity_id,
            "body_id": body_id,
            "retrieval_scope": retrieval_scope,
            "added_at": _now_utc_iso(),
        }

    def _serialize_tombstone(self, *, record_id: str, identity_id: str,
                             reason: str) -> dict:
        return {
            "schema": SCHEMA_VERSION,
            "op": "tombstone",
            "record_id": record_id,
            "identity_id": identity_id,
            "reason": reason,
            "tombstoned_at": _now_utc_iso(),
        }

    def _serialize_untombstone(self, *, record_id: str, identity_id: str) -> dict:
        """Eye R2 F-R2-08: inline op=untombstone record that restores a
        previously tombstoned record_id so re-ingest of identical content
        is visible again. Chained into the HMAC seal like every other op.
        """
        return {
            "schema": SCHEMA_VERSION,
            "op": "untombstone",
            "record_id": record_id,
            "identity_id": identity_id,
            "untombstoned_at": _now_utc_iso(),
        }

    def _append_untombstone(self, *, record_id: str, identity_id: str) -> None:
        """Write an op=untombstone record and clear the in-memory state.

        Called from inside ``add()`` under the lock when a re-ingest would
        otherwise be invisible because the record_id is tombstoned.

        Eye R3 Judge GPT: this method MUST NOT swallow UnsealedWriteRefused.
        Doing so caused add() to return True for a resurrection that never
        actually landed, leaving the record invisible forever on a sealed
        workspace reopened under NO_HMAC. Only transient IO/encoding
        failures are queued; hard config refusals and other unexpected
        errors propagate so the caller's add() path can roll back in one
        consistent place.
        """
        payload = self._serialize_untombstone(
            record_id=record_id, identity_id=identity_id,
        )
        try:
            sealed = self._append_line(payload)
            self._advance_chain(sealed)
            self._dirty_count += 1
        except UnsealedWriteRefused:
            # Hard config error — MUST escape. No queueing; add() rolls
            # back both the untombstone attempt and its own state.
            raise
        except (OSError, UnicodeEncodeError, ValueError) as e:
            # Transient / recoverable persist failure — queue for retry.
            self._persist_failures += 1
            self._pending_persist.append(payload)
            logger.warning(
                "source_manifest: untombstone persist failed for %s; queued (%s)",
                record_id, e,
            )
            return
        # In-memory state updates only after a successful seal.
        self._tombstones.get(identity_id, set()).discard(record_id)
        self._tombstone_reasons.get(identity_id, {}).pop(record_id, None)
        if self._tombstoned_records > 0:
            self._tombstoned_records -= 1

    def _seal_and_finalize(self, payload: dict) -> dict:
        """Stamp seq + prev_seal + seal on a payload. Caller holds the lock."""
        if self._hmac_disabled or self._secret is None:
            return payload
        payload = dict(payload)
        payload["seq"] = self._next_seq
        payload["prev_seal"] = self._last_seal_hex
        seal = _compute_seal(self._secret, payload)
        payload["seal"] = seal
        return payload

    def _append_line(self, payload: dict) -> dict:
        """Append a single JSONL line. Raises on any IO or encode failure.

        Returns the SEALED payload (which may differ from the input when
        HMAC is enabled). Caller is responsible for advancing chain state
        on success.

        Eye R2 F-R2-05: if this workspace has EVER carried sealed content,
        refuse unsealed writes even when PARSICA_MANIFEST_DEV_NO_HMAC=1.
        Eye R2 F-R2-04: after a successful append, atomically update the
        tail anchor sidecar so tail-deletion is detectable on next load.

        R4.1 Cluster D (P0-2): 2-phase anchor protocol closes the
        append-then-anchor crash window. We write an ``anchor_planned``
        sidecar record BEFORE the JSONL append, then the JSONL append +
        fsync, then ``anchor_confirmed`` + fsync. If the process crashes
        between planned and confirmed, the next load observes
        ``planned.count > confirmed.count`` and transitions to
        ``chain_crash_recovery`` (writes refused until reconciled).
        R4.1 Cluster D (P1-5): a separate monotonic counter sidecar
        fingerprints anchor rollback (attacker restoring an older full
        anchor file).
        """
        if self._hmac_disabled and self._has_sealed_prefix:
            raise UnsealedWriteRefused(
                "source_manifest: refusing unsealed write — workspace already "
                "carries a sealed HMAC chain and PARSICA_MANIFEST_DEV_NO_HMAC=1. "
                "Unset the env flag or move the sealed manifest aside if you "
                "really need a fresh chain."
            )
        sealed = self._seal_and_finalize(payload)
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        # R4.1 Cluster D: compute the exact serialized line (what will
        # land on disk) BEFORE the append, so both the planned anchor
        # and the confirmed anchor carry the same hash of the committed
        # bytes. The ``planned`` hash must match the ``confirmed`` hash
        # for the loader to accept the confirmation.
        serialized = json.dumps(sealed, ensure_ascii=False) + "\n"
        next_line_count = self._line_count + 1
        next_seq_after = int(sealed.get("seq", self._next_seq)) + 1
        last_seal_after = sealed.get("seal", self._last_seal_hex)
        line_hash = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
        # Phase 1: write anchor_planned BEFORE the JSONL append. If we
        # crash here, the JSONL is unchanged; next load will see
        # planned.count > confirmed.count but the JSONL will have
        # fewer lines than planned (or the planned line won't exist),
        # so the loader transitions to chain_crash_recovery without
        # data loss.
        if not self._hmac_disabled and self._secret is not None:
            self._write_tail_anchor_planned(
                line_count=next_line_count,
                last_seal=last_seal_after,
                next_seq=next_seq_after,
                line_hash=line_hash,
            )
        # Phase 2: append the JSONL line + fsync.
        with open(self._path, "a", encoding="utf-8", errors="strict") as f:
            f.write(serialized)
            f.flush()
            try:
                os.fsync(f.fileno())
            except (OSError, AttributeError):
                # fsync unsupported on some test filesystems; continue
                # best-effort — anchor state still detects the crash.
                pass
        self._line_count += 1
        # Phase 3: write anchor_confirmed (+ bump monotonic counter).
        # A crash here leaves planned.count == next_line_count and
        # confirmed.count == next_line_count - 1 (or absent); loader
        # detects the crash window on the next boot.
        if not self._hmac_disabled and self._secret is not None:
            self._write_tail_anchor_confirmed(
                line_count=next_line_count,
                last_seal=last_seal_after,
                next_seq=next_seq_after,
                line_hash=line_hash,
            )
        # R4.1 Cluster J (P2-1): self-heal _integrity_state after a
        # successful write. _load_from_disk sets anchor_missing / truncated /
        # tail_rewritten when the on-disk anchor was absent or stale, but it
        # never updates _integrity_state again after load. A successful write
        # just refreshed (or created) the tail anchor on disk, so the
        # triggering condition no longer exists. Transition to "ok" so the
        # consumer gate unblocks for the remainder of this session — operators
        # should not need to restart the process to clear a self-healing
        # anchor_missing after one legitimate write.
        _SELF_HEALING_STATES = frozenset({"anchor_missing", "truncated", "tail_rewritten"})
        if self._integrity_state in _SELF_HEALING_STATES:
            self._integrity_state = "ok"
        return sealed

    # ---- R4.1 Cluster D: anchor 2-phase protocol + rollback defense ----
    #
    # On-disk anchor format v2 (new):
    #     {
    #       "schema_version": 2,
    #       "planned":   {count, last_seal, next_seq, line_hash, ts} | null,
    #       "confirmed": {count, last_seal, next_seq, line_hash, ts} | null,
    #       "update_counter": N,
    #       "seal": "<HMAC over everything above>"
    #     }
    #
    # On-disk anchor format v1 (legacy pre-R4.1):
    #     {schema: 2, kind: "tail_anchor", line_count, last_seal, next_seq,
    #      updated_at, seal}
    # The reader recognises both and migrates v1 to v2 on the next write
    # (treats the v1 record as ``confirmed`` with no ``planned`` and
    # ``update_counter = 0``).
    #
    # Counter sidecar (separate file, R4.1 P1-5 rollback defense):
    #     {schema_version: 1, update_counter: N, updated_at, seal}
    # Any loader state where counter_sidecar.update_counter >
    # anchor.update_counter is a rollback fingerprint (attacker restored
    # an older copy of the anchor but couldn't also rewrite the counter).

    def _tail_anchor_payload(self, *, line_count: int, last_seal: str,
                              next_seq: int) -> dict:
        """Legacy v1 payload shape. Retained for ``_write_legacy_seal`` and
        for backwards-compat during first-boot migration from pre-R4.1
        workspaces. New 2-phase writes build their own payloads via
        ``_anchor_phase_dict``."""
        return {
            "schema": SCHEMA_VERSION,
            "kind": "tail_anchor",
            "line_count": int(line_count),
            "last_seal": last_seal or "",
            "next_seq": int(next_seq),
            "updated_at": _now_utc_iso(),
        }

    def _anchor_phase_dict(self, *, line_count: int, last_seal: str,
                            next_seq: int, line_hash: str) -> dict:
        """Build a ``planned`` or ``confirmed`` sub-record."""
        return {
            "count": int(line_count),
            "last_seal": last_seal or "",
            "next_seq": int(next_seq),
            "line_hash": line_hash or "",
            "ts": _now_utc_iso(),
        }

    def _write_anchor_sidecar(self, *, planned: Optional[dict],
                               confirmed: Optional[dict],
                               update_counter: int) -> None:
        """Serialize + sign + atomically replace the anchor sidecar.

        Caller is responsible for deciding what goes in ``planned`` /
        ``confirmed`` — this helper just writes. Fails silently on IO
        error (logged) so a stuck-sidecar write cannot block an
        otherwise-durable JSONL append. The loader's mismatch detection
        catches any drift on the next boot.
        """
        if self._hmac_disabled or self._secret is None:
            return
        payload: Dict[str, Any] = {
            "schema_version": ANCHOR_SCHEMA_VERSION,
            "planned": planned,
            "confirmed": confirmed,
            "update_counter": int(update_counter),
        }
        payload["seal"] = _compute_seal(self._secret, payload)
        try:
            os.makedirs(os.path.dirname(self._tail_anchor_path), exist_ok=True)
            tmp = f"{self._tail_anchor_path}.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False))
                f.flush()
                try:
                    os.fsync(f.fileno())
                except (OSError, AttributeError):
                    pass
            os.replace(tmp, self._tail_anchor_path)
        except Exception as e:
            logger.warning(
                "source_manifest: tail anchor write failed (%s); truncation detection may be stale",
                e,
            )

    def _write_counter_sidecar(self, update_counter: int) -> None:
        """R4.1 Cluster D (P1-5): persist the monotonic update_counter
        in its own signed sidecar. Any regression on the next load is a
        rollback fingerprint."""
        if self._hmac_disabled or self._secret is None:
            return
        payload: Dict[str, Any] = {
            "schema_version": COUNTER_SCHEMA_VERSION,
            "update_counter": int(update_counter),
            "updated_at": _now_utc_iso(),
        }
        payload["seal"] = _compute_seal(self._secret, payload)
        try:
            os.makedirs(os.path.dirname(self._counter_path), exist_ok=True)
            tmp = f"{self._counter_path}.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False))
                f.flush()
                try:
                    os.fsync(f.fileno())
                except (OSError, AttributeError):
                    pass
            os.replace(tmp, self._counter_path)
        except Exception as e:
            logger.warning(
                "source_manifest: counter sidecar write failed (%s); rollback detection may be stale",
                e,
            )

    def _write_tail_anchor_planned(self, *, line_count: int, last_seal: str,
                                    next_seq: int, line_hash: str) -> None:
        """Phase 1 of the 2-phase protocol. Writes a new ``planned``
        block while keeping the existing ``confirmed`` block (so a
        crash here leaves the loader able to see the mismatch).
        """
        existing = self._read_anchor_raw()
        confirmed = existing.get("confirmed") if existing else None
        current_counter = int(existing.get("update_counter", 0)) if existing else 0
        # The monotonic counter only advances on the CONFIRMED phase.
        planned = self._anchor_phase_dict(
            line_count=line_count, last_seal=last_seal,
            next_seq=next_seq, line_hash=line_hash,
        )
        self._write_anchor_sidecar(
            planned=planned, confirmed=confirmed,
            update_counter=current_counter,
        )

    def _write_tail_anchor_confirmed(self, *, line_count: int, last_seal: str,
                                      next_seq: int, line_hash: str) -> None:
        """Phase 3 of the 2-phase protocol. Replaces ``confirmed`` and
        bumps the monotonic update_counter. Also refreshes the counter
        sidecar. Called ONLY after a successful JSONL append + fsync.
        """
        existing = self._read_anchor_raw()
        planned = existing.get("planned") if existing else None
        current_counter = int(existing.get("update_counter", 0)) if existing else 0
        new_counter = max(current_counter, self._update_counter) + 1
        confirmed = self._anchor_phase_dict(
            line_count=line_count, last_seal=last_seal,
            next_seq=next_seq, line_hash=line_hash,
        )
        # Write the anchor first (planned still matches confirmed here,
        # since the append has already landed). Then the counter sidecar.
        self._write_anchor_sidecar(
            planned=planned, confirmed=confirmed,
            update_counter=new_counter,
        )
        self._write_counter_sidecar(new_counter)
        self._update_counter = new_counter

    def _write_tail_anchor(self, *, line_count: int, last_seal: str,
                            next_seq: int) -> None:
        """Backwards-compat shim. Pre-R4.1 callers wrote a single-phase
        anchor after a successful append. In R4.1 this is only used by
        ``_write_legacy_seal`` (legacy prefix auto-anchor); it writes
        the planned AND confirmed blocks in one step so the loader
        sees a fully-confirmed v2 record.

        Eye R2 F-R2-04: atomic write with HMAC.
        """
        if self._hmac_disabled or self._secret is None:
            return
        # Single-shot: both planned and confirmed match the committed
        # tuple; line_hash unknown (legacy seal anchors contents by
        # its own prefix_hash mechanism, not the sidecar line_hash).
        phase = self._anchor_phase_dict(
            line_count=line_count, last_seal=last_seal,
            next_seq=next_seq, line_hash="",
        )
        existing = self._read_anchor_raw()
        current_counter = int(existing.get("update_counter", 0)) if existing else 0
        new_counter = max(current_counter, self._update_counter) + 1
        self._write_anchor_sidecar(
            planned=phase, confirmed=phase, update_counter=new_counter,
        )
        self._write_counter_sidecar(new_counter)
        self._update_counter = new_counter

    def _read_anchor_raw(self) -> Optional[dict]:
        """Load and verify the anchor sidecar. Returns the raw, HMAC-
        verified payload dict (v2 shape, or an auto-upgraded v1 shape
        where legacy fields have been moved into ``confirmed``). Returns
        None if absent / unreadable / seal mismatch.
        """
        if self._hmac_disabled or self._secret is None:
            return None
        try:
            with open(self._tail_anchor_path, "r", encoding="utf-8") as f:
                raw = f.read()
        except FileNotFoundError:
            return None
        except OSError as e:
            logger.warning(
                "source_manifest: tail anchor read failed (%s); treating as absent", e,
            )
            return None
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            logger.warning("source_manifest: tail anchor is not valid JSON; ignoring")
            return None
        if not isinstance(data, dict):
            logger.warning("source_manifest: tail anchor is not an object; ignoring")
            return None
        seal = data.pop("seal", None)
        if not isinstance(seal, str):
            logger.warning("source_manifest: tail anchor missing seal; ignoring")
            return None
        expected = _compute_seal(self._secret, data)
        if not hmac.compare_digest(seal, expected):
            logger.warning("source_manifest: tail anchor HMAC mismatch; ignoring")
            return None
        # Detect schema: v2 has "schema_version", v1 has "kind":
        # "tail_anchor". Auto-lift v1 records into the v2 shape so the
        # rest of the loader has a single code path (R4.1 Sonnet risk
        # R-mitigation: backwards-compat migration via fallback reader).
        if data.get("schema_version") == ANCHOR_SCHEMA_VERSION:
            return data
        if data.get("kind") == "tail_anchor":
            # Legacy v1: treat as confirmed with no planned; counter = 0.
            confirmed = {
                "count": int(data.get("line_count", 0)),
                "last_seal": data.get("last_seal", ""),
                "next_seq": int(data.get("next_seq", 0)),
                "line_hash": "",
                "ts": data.get("updated_at", ""),
            }
            return {
                "schema_version": ANCHOR_SCHEMA_VERSION,
                "planned": None,
                "confirmed": confirmed,
                "update_counter": 0,
                "_legacy_v1": True,
            }
        logger.warning(
            "source_manifest: tail anchor has unknown schema_version=%r; ignoring",
            data.get("schema_version"),
        )
        return None

    def _read_counter_sidecar(self) -> Optional[int]:
        """Load + verify the counter sidecar. Returns the monotonic
        counter on success, None if absent / unreadable / seal mismatch.
        """
        if self._hmac_disabled or self._secret is None:
            return None
        try:
            with open(self._counter_path, "r", encoding="utf-8") as f:
                raw = f.read()
        except FileNotFoundError:
            return None
        except OSError as e:
            logger.warning(
                "source_manifest: counter sidecar read failed (%s); treating as absent", e,
            )
            return None
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            logger.warning("source_manifest: counter sidecar is not valid JSON; ignoring")
            return None
        if not isinstance(data, dict):
            return None
        seal = data.pop("seal", None)
        if not isinstance(seal, str):
            return None
        expected = _compute_seal(self._secret, data)
        if not hmac.compare_digest(seal, expected):
            logger.warning("source_manifest: counter sidecar HMAC mismatch; ignoring")
            return None
        try:
            return int(data.get("update_counter", 0))
        except (TypeError, ValueError):
            return None

    def _read_tail_anchor(self) -> Optional[dict]:
        """Public reader used by the loader. Returns a legacy-shaped
        payload (``{line_count, last_seal, next_seq, ...}``) derived
        from the ``confirmed`` block of the v2 record, or None. The
        v1 ``line_count`` alias is preserved for existing loader call
        sites (they don't need to know about the 2-phase details).

        The 2-phase crash-window detection and counter-regression
        detection are handled separately in ``_load_from_disk``.
        """
        raw = self._read_anchor_raw()
        if raw is None:
            return None
        confirmed = raw.get("confirmed")
        if not isinstance(confirmed, dict):
            # A freshly-written planned-only sidecar (crash between
            # phase 1 and phase 2) has confirmed=None. The loader's
            # explicit crash-window check (via ``_read_anchor_raw``)
            # handles this; here we just report "no usable anchor."
            return None
        return {
            "line_count": int(confirmed.get("count", 0)),
            "last_seal": confirmed.get("last_seal", ""),
            "next_seq": int(confirmed.get("next_seq", 0)),
            "line_hash": confirmed.get("line_hash", ""),
        }

    def _advance_chain(self, sealed: dict) -> None:
        """Advance _last_seal_hex and _next_seq after a successful append."""
        if self._hmac_disabled or self._secret is None:
            return
        seal = sealed.get("seal")
        seq = sealed.get("seq")
        if isinstance(seal, str):
            self._last_seal_hex = seal
        if isinstance(seq, int):
            self._next_seq = seq + 1

    def _hash_legacy_prefix(self, count: int) -> str:
        """Eye R2 F-R2-04: hash the actual bytes of the first ``count``
        lines of the manifest so the legacy_seal anchor binds contents,
        not just a line count. Without this, an attacker could rewrite
        any unsealed record in the legacy prefix without triggering the
        anchor check.
        """
        h = hashlib.sha256()
        try:
            with open(self._path, "rb") as f:
                seen = 0
                for raw in f:
                    if not raw.strip():
                        # Don't count blank lines toward the prefix
                        # boundary — stays consistent with loader.
                        continue
                    if seen >= count:
                        break
                    h.update(raw)
                    seen += 1
        except FileNotFoundError:
            return ""
        return h.hexdigest()

    def _write_legacy_seal(self, count: int) -> None:
        """Write a one-shot anchor closing the grandfathered unsealed prefix.

        The anchor's `prev_seal` is empty (chain starts here). `seal` is an
        HMAC over {schema, op, count, next_seq, prefix_hash} so tampering
        with either the anchor itself OR the unsealed prefix contents is
        detectable. Eye R2 F-R2-04: the original R2 design only hashed the
        count, which let an attacker rewrite legacy lines under the anchor.
        """
        if self._hmac_disabled or self._secret is None:
            return
        prefix_hash = self._hash_legacy_prefix(count)
        payload = {
            "schema": SCHEMA_VERSION,
            "op": "legacy_seal",
            "count": count,
            "prefix_hash": prefix_hash,
            "seq": 0,
            # Eye R2 P1-H1: the anchor consumes seq=0 itself, so the next
            # sealed record uses seq=1.
            "next_seq": 1,
            "prev_seal": "",
            "anchored_at": _now_utc_iso(),
        }
        seal = _compute_seal(self._secret, payload)
        payload["seal"] = seal
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        with open(self._path, "a", encoding="utf-8", errors="strict") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self._last_seal_hex = seal
        self._next_seq = 1
        self._line_count += 1
        # Anchor writing is itself a line; refresh the tail anchor.
        self._write_tail_anchor(
            line_count=self._line_count, last_seal=seal, next_seq=1,
        )
        logger.info(
            "source_manifest: anchored legacy prefix (%d unsealed lines, prefix_hash=%s…) with one-shot legacy_seal",
            count, prefix_hash[:12] if prefix_hash else "-",
        )

    def _drain_pending(self) -> int:
        """Attempt to persist queued records. Returns count written.

        Eye R3.1 F-R3-06 (Attacker Opus): if the workspace is now under
        the NO_HMAC-on-sealed-workspace block, ``_append_line`` raises
        ``UnsealedWriteRefused``. Previously the broad except Exception
        here caught that and silently re-queued, producing an endless
        retry loop with no surfaced error. R3.1 lets UnsealedWriteRefused
        escape so callers see the config error the first time a queued
        write is retried.
        """
        if not self._pending_persist:
            return 0
        still_pending: List[dict] = []
        written = 0
        for payload in self._pending_persist:
            try:
                sealed = self._append_line(payload)
                self._advance_chain(sealed)
                written += 1
            except UnsealedWriteRefused:
                # Preserve un-retried entries; escape.
                still_pending.append(payload)
                self._pending_persist = still_pending
                if written:
                    self._persist_retries += written
                raise
            except (OSError, UnicodeEncodeError, ValueError) as e:
                logger.warning(
                    "source_manifest: persist retry failed (%s); re-queueing", e,
                )
                still_pending.append(payload)
            except Exception:  # pragma: no cover
                logger.exception("source_manifest: unexpected retry failure; re-queueing")
                still_pending.append(payload)
        self._pending_persist = still_pending
        if written:
            self._persist_retries += written
        return written

    def flush(self) -> int:
        """Drain the persist retry queue. Thread-safe."""
        with self._lock:
            with self._with_workspace_lock():
                self._ensure_loaded()
                # R4.1 Cluster A (P0-5): gate before attempting persist.
                # ``flush`` writes so it classifies as a write op.
                self._require_usable(op="flush")
                return self._drain_pending()

    # ------------------------------------------------------------------- add

    def add(
        self,
        source_type: str,
        source_id: str,
        record_id: str,
        *,
        identity_id: str,
        body_id: str,
        retrieval_scope: str = "",
    ) -> bool:
        """Register ``record_id`` under the scoped key.

        Keyword-only identity_id and body_id are required — callers must
        resolve scope explicitly. Blank strings are rejected; pass the
        ``LEGACY_IDENTITY_SENTINEL`` / ``LEGACY_BODY_SENTINEL`` constants
        if you genuinely have no identity/body (typically only the
        migration path).

        ``source_type`` must be in ``NATIVE_SOURCE_TYPES`` (A-03 allow-list).
        Unknown types raise ValueError.

        Returns True if a new (scope, key, record_id) triple was added;
        False if it was already present.
        """
        source_type = _sanitize_field("source_type", source_type, _MAX_SOURCE_TYPE_LEN)
        source_id = _sanitize_field("source_id", source_id, _MAX_SOURCE_ID_LEN)
        record_id = _sanitize_field("record_id", record_id, _MAX_RECORD_ID_LEN)
        identity_id = _sanitize_field("identity_id", identity_id, _MAX_IDENTITY_ID_LEN)
        body_id = _sanitize_field("body_id", body_id, _MAX_BODY_ID_LEN)
        if retrieval_scope:
            retrieval_scope = _sanitize_field("retrieval_scope", retrieval_scope, 64)

        if not source_type:
            raise ValueError("source_type must not be empty")
        if not source_id:
            raise ValueError("source_id must not be empty")
        if not record_id:
            raise ValueError("record_id must not be empty")
        if not identity_id:
            raise ValueError("identity_id must not be empty (pass LEGACY_IDENTITY_SENTINEL if truly unknown)")
        if not body_id:
            raise ValueError("body_id must not be empty (pass LEGACY_BODY_SENTINEL if truly unknown)")

        # A-03: allow-list.
        if source_type not in NATIVE_SOURCE_TYPES:
            raise ValueError(
                f"source_type={source_type!r} is not in NATIVE_SOURCE_TYPES; "
                "callers with attacker-reachable sources must map to a native "
                "type (e.g. imported_pack) before calling add()"
            )

        payload = self._serialize_add(
            source_type=source_type,
            source_id=source_id,
            record_id=record_id,
            identity_id=identity_id,
            body_id=body_id,
            retrieval_scope=retrieval_scope,
        )

        with self._lock:
            with self._with_workspace_lock():
                self._ensure_loaded()
                # R4.1 Cluster A (P0-5): refuse writes on any state outside
                # _INTEGRITY_STATES_ALLOW_WRITE. Closes the "primitive raises,
                # caller swallows, gate is docstring" architecture.
                self._require_usable(op="add")
                if self._pending_persist:
                    self._drain_pending()
                bucket = (source_type, source_id)

            # Eye R2 F-R2-08 / Attacker Opus: tombstone + re-ingest-same-hash
            # previously left the record permanently hidden because the
            # tombstone filter fires on the identity-scoped record_id and
            # the hash is stable. R3 resurrects by appending an inline
            # op=untombstone record that chains into the HMAC seal and
            # clearing the in-memory tombstone set. The tombstone is part
            # of the audit trail; the untombstone is part of the audit
            # trail; together they describe forget → re-ingest correctly.
            #
            # Check MUST happen before the dedup short-circuit so a
            # repeat add of a tombstoned+already-indexed record_id still
            # resurrects it instead of returning False.
                was_tombstoned = record_id in self._tombstones.get(identity_id, set())
                if was_tombstoned:
                    self._append_untombstone(
                        record_id=record_id, identity_id=identity_id,
                    )

                already_indexed = record_id in self._index_sets[identity_id][body_id][bucket]
                if already_indexed and not was_tombstoned:
                    return False
                if not already_indexed:
                    self._index[identity_id][body_id][bucket].append(record_id)
                    self._index_sets[identity_id][body_id][bucket].add(record_id)
                # Eye R2 F-R2-02: record retrieval_scope for manifest-side
                # allowed_scopes enforcement in lookup_scoped.
                # R4.1 Cluster J (P2-5): first-write-wins. On re-ingest the
                # original scope should be preserved, not silently overwritten
                # by whatever scope the re-ingest call carries. Last-write-wins
                # was causing retrieval-scope drift across re-ingest cycles.
                if record_id not in self._scope_by_rid[identity_id]:
                    self._scope_by_rid[identity_id][record_id] = retrieval_scope or ""

                if already_indexed and was_tombstoned:
                    # Resurrection path — the untombstone op already chained
                    # a seal. Caller sees True (the record is now visible).
                    # Skip re-writing an identical add line.
                    return True
                try:
                    sealed = self._append_line(payload)
                    self._advance_chain(sealed)
                    self._dirty_count += 1
                except UnsealedWriteRefused:
                    # Eye R2 F-R2-05: hard config error — must escape, not
                    # get queued as a transient persist failure. Roll back the
                    # in-memory index mutation we just performed since the
                    # write was rejected.
                    self._index[identity_id][body_id][bucket].remove(record_id)
                    self._index_sets[identity_id][body_id][bucket].discard(record_id)
                    self._scope_by_rid[identity_id].pop(record_id, None)
                    raise
                except (OSError, UnicodeEncodeError, ValueError) as e:
                    self._persist_failures += 1
                    self._pending_persist.append(payload)
                    logger.warning(
                        "source_manifest: persist failed for (%s/%s/%s/%s); queued for retry (%s)",
                        identity_id, body_id, source_type, source_id, e,
                    )
                except Exception:  # pragma: no cover
                    self._persist_failures += 1
                    self._pending_persist.append(payload)
                    logger.exception(
                        "source_manifest: unexpected persist failure; queued",
                    )
                return True

    # ------------------------------------------------------------ tombstone

    def tombstone(
        self,
        record_id: str,
        reason: str,
        *,
        identity_id: str,
    ) -> int:
        """Mark ``record_id`` as tombstoned in ``identity_id``'s scope.

        Returns the count of newly-tombstoned records (0 if already
        tombstoned, 1 on first tombstone). The record_id need not currently
        be in the index — calling tombstone on an unknown record_id is a
        valid preventive operation.

        ``reason`` must be in ``TOMBSTONE_REASONS``.
        """
        record_id = _sanitize_field("record_id", record_id, _MAX_RECORD_ID_LEN)
        identity_id = _sanitize_field("identity_id", identity_id, _MAX_IDENTITY_ID_LEN)
        reason = _sanitize_field("reason", reason, _MAX_REASON_LEN)

        if not record_id:
            raise ValueError("record_id must not be empty")
        if not identity_id:
            raise ValueError("identity_id must not be empty")
        if reason not in TOMBSTONE_REASONS:
            raise ValueError(
                f"reason={reason!r} not in TOMBSTONE_REASONS {sorted(TOMBSTONE_REASONS)}"
            )

        payload = self._serialize_tombstone(
            record_id=record_id,
            identity_id=identity_id,
            reason=reason,
        )

        with self._lock:
            with self._with_workspace_lock():
                self._ensure_loaded()
                # R4.1 Cluster A (P0-5): forget/GDPR path must refuse on
                # tamper/corruption rather than returning a meaningless 1.
                self._require_usable(op="tombstone")
                if self._pending_persist:
                    self._drain_pending()
                if record_id in self._tombstones[identity_id]:
                    return 0
                self._tombstones[identity_id].add(record_id)
                self._tombstone_reasons[identity_id][record_id] = reason
                self._tombstoned_records += 1
                try:
                    sealed = self._append_line(payload)
                    self._advance_chain(sealed)
                    self._dirty_count += 1
                except UnsealedWriteRefused:
                    # Eye R3.1 F-R3-06 (Attacker Opus): tombstone() is the
                    # user-facing forget path. GDPR-relevant. The refusal MUST
                    # escape so the caller knows their forget didn't land,
                    # not silently queue into pending_persist (which will
                    # reject again on drain). Roll back the optimistic
                    # in-memory tombstone we just set.
                    self._tombstones[identity_id].discard(record_id)
                    self._tombstone_reasons[identity_id].pop(record_id, None)
                    if self._tombstoned_records > 0:
                        self._tombstoned_records -= 1
                    raise
                except (OSError, UnicodeEncodeError, ValueError) as e:
                    # P1-9: transient I/O failure — queue for retry but
                    # return 0 to signal "not durably confirmed". The
                    # caller (_tombstone_entries) must not count this as a
                    # successful tombstone; flush() will retry later.
                    self._persist_failures += 1
                    self._pending_persist.append(payload)
                    logger.warning(
                        "source_manifest: tombstone persist failed for %s (%s); queued",
                        record_id[:12], e,
                    )
                    return 0
                except Exception:  # pragma: no cover
                    self._persist_failures += 1
                    self._pending_persist.append(payload)
                    logger.exception("source_manifest: tombstone persist failed")
                    return 0
                return 1

    # ------------------------------------------------------------------ read

    def _sanitize_for_lookup(self, name: str, value: str, max_len: int) -> Optional[str]:
        try:
            return _sanitize_field(name, value, max_len)
        except ValueError:
            return None

    def _is_tombstoned(self, identity_id: str, record_id: str) -> bool:
        """Return True if the record is hard-hidden by tombstone."""
        reason = self._tombstone_reasons.get(identity_id, {}).get(record_id)
        if reason is None:
            return False
        # "deprecated" is a soft signal — consumers handle via record-state
        # weighting. Everything else hard-hides.
        return reason in TOMBSTONE_HIDE_REASONS

    def _is_hard_tombstoned(self, identity_id: str, record_id: str) -> bool:
        """True if the record is hard-hidden by tombstone (hide-reason).

        The `deprecated` reason is soft — lookup still returns the record
        and the caller applies weighting. All other reasons hard-hide.
        """
        reason = self._tombstone_reasons.get(identity_id, {}).get(record_id)
        if reason is None:
            return False
        return reason in TOMBSTONE_HIDE_REASONS

    def lookup(
        self,
        source_type: str,
        source_id: str,
        *,
        identity_id: str,
        body_id: Optional[str] = None,
    ) -> List[str]:
        """Return record_ids for ``(source_type, source_id)`` in scope.

        ``identity_id`` is required — fail-closed. If ``body_id`` is None,
        returns records across all bodies within the identity (filtered to
        identity-durable / handoff-visible scopes). If given, strictly
        matches.

        Tombstoned records are filtered out automatically.
        """
        st = self._sanitize_for_lookup("source_type", source_type, _MAX_SOURCE_TYPE_LEN)
        sid = self._sanitize_for_lookup("source_id", source_id, _MAX_SOURCE_ID_LEN)
        ident = self._sanitize_for_lookup("identity_id", identity_id, _MAX_IDENTITY_ID_LEN)
        if st is None or sid is None or ident is None:
            return []
        if not st or not sid or not ident:
            logger.warning(
                "source_manifest: lookup called with empty scope fields; returning empty",
            )
            return []
        sanitized_body = None
        if body_id is not None:
            sanitized_body = self._sanitize_for_lookup("body_id", body_id, _MAX_BODY_ID_LEN)
            if not sanitized_body:
                return []

        with self._lock:
            self._ensure_loaded()
            # R4.1 Cluster A (P0-5 + dissolves P1-4): gate reads so the
            # ``lookup`` path matches the ``get_by_source`` consumer path
            # structurally. The ``lookup_source`` shim on MemorySystemV4
            # delegates here, so gating once closes both surfaces.
            self._require_usable(op="lookup")
            bucket = (st, sid)
            results: List[str] = []
            identity_index = self._index.get(ident)
            if identity_index is None:
                return []
            if sanitized_body is not None:
                body_map = identity_index.get(sanitized_body)
                if body_map is None:
                    return []
                for rid in body_map.get(bucket, ()):
                    if not self._is_hard_tombstoned(ident, rid):
                        results.append(rid)
            else:
                # body_id=None: fold across bodies within identity.
                for body, body_map in identity_index.items():
                    for rid in body_map.get(bucket, ()):
                        if self._is_hard_tombstoned(ident, rid):
                            continue
                        # Scope-axis filter is applied at ingest-write time;
                        # consumers needing retrieval_scope filtering use
                        # lookup_scoped() or hydrate entries themselves.
                        results.append(rid)
            return results

    def lookup_scoped(
        self,
        source_type: str,
        source_id: str,
        scope_policy: Any,
    ) -> List[str]:
        """Scope-filtered lookup composing with retrieval.py's ScopePolicy.

        Reads ``scope_policy.identity_id``, ``scope_policy.body_id`` (optional),
        and ``scope_policy.allowed_scopes`` (optional) and enforces the
        manifest-side equivalent of retrieval.py:435-497.

        Blank identity_id → fail-closed empty list.
        """
        if scope_policy is None:
            return []
        ident = getattr(scope_policy, "identity_id", "") or ""
        body = getattr(scope_policy, "body_id", "") or None
        allowed_scopes = getattr(scope_policy, "allowed_scopes", None)
        if not ident:
            logger.warning(
                "source_manifest: lookup_scoped called with blank scope_policy.identity_id; returning empty",
            )
            return []
        # R4.1 Cluster A (P0-5): gate before delegating to ``lookup``.
        # ``lookup`` will also gate, but gating here produces a clean
        # stack trace that names the public method the caller invoked.
        with self._lock:
            self._ensure_loaded()
            self._require_usable(op="lookup_scoped")
        # body axis: blank → cross-body within identity
        hits = self.lookup(source_type, source_id,
                           identity_id=ident, body_id=body)
        if allowed_scopes is None:
            return hits
        # Eye R2 F-R2-02: actually enforce allowed_scopes using the
        # scope-by-rid reverse map populated at index/add time. Before R3
        # this method silently passed hits through unchanged, which made
        # its name a trap for callers who assumed enforcement. Now the
        # return set really is {rid ∈ hits | scope(rid) ∈ allowed_scopes}.
        try:
            allowed_set = set(allowed_scopes)
        except TypeError:
            # Unhashable / malformed allowed_scopes → fail closed.
            logger.warning(
                "source_manifest: lookup_scoped allowed_scopes=%r is not iterable-of-hashable; "
                "returning empty",
                allowed_scopes,
            )
            return []
        ident_scopes = self._scope_by_rid.get(ident, {})
        return [rid for rid in hits if ident_scopes.get(rid, "") in allowed_set]

    def all_sources(
        self,
        *,
        identity_id: Optional[str] = None,
        body_id: Optional[str] = None,
    ) -> List[Tuple[str, str, str, str]]:
        """Return all indexed ``(identity, body, source_type, source_id)`` tuples.

        Tombstoned buckets are still returned — the tuple identifies a
        source, not a record. Callers that want "only live sources" should
        intersect with live-record lookups.
        """
        with self._lock:
            self._ensure_loaded()
            # R4.1 Cluster A (P0-5): gate the source enumeration path.
            self._require_usable(op="all_sources")
            out: List[Tuple[str, str, str, str]] = []
            identities = [identity_id] if identity_id else list(self._index.keys())
            for ident in identities:
                body_map = self._index.get(ident, {})
                bodies = [body_id] if body_id else list(body_map.keys())
                for body in bodies:
                    buckets = body_map.get(body, {})
                    for (st, sid) in buckets.keys():
                        out.append((ident, body, st, sid))
            return out

    # ---------------------------------------------------------------- stats

    def stats(self) -> dict:
        with self._lock:
            self._ensure_loaded()
            # R4.1 Cluster A (P0-5): ``stats`` exposes counts over the
            # loaded index; on a corrupt chain those counts would be
            # adversary-controllable. Gate as a strict read.
            self._require_usable(op="stats")
            source_count = 0
            total_records = 0
            for body_map in self._index.values():
                for buckets in body_map.values():
                    source_count += len(buckets)
                    for recs in buckets.values():
                        total_records += len(recs)
            return {
                "source_count": source_count,
                "total_records": total_records,
                "tombstoned_records": self._tombstoned_records,
                "dirty_count": self._dirty_count,
                "persist_failures": self._persist_failures,
                "persist_retries": self._persist_retries,
                "pending_persist": len(self._pending_persist),
                "legacy_lines_migrated": self._legacy_lines_migrated,
                "quarantined_lines": self._quarantined_lines,
                "identities": len(self._index),
            }

    def health(self) -> dict:
        """Return integrity/operational health for downstream consumers.

        Consumers (QTE router, pack assembler) MUST check ``integrity`` and
        refuse to use the manifest when not ``ok``. This is the safe-use
        gate required by the A-04 threat model.

        R4.1 Cluster B (P2-6): the ``hmac`` field now reports the typed
        ``_HmacStatus`` string instead of a coarse ``"enabled" /
        "disabled"`` pair. Log scrapers pattern-matching on the old
        strings keep working for the common cases (``"enabled"``); the
        new values (``"disabled_by_env"``, ``"disabled_by_missing_secret"``,
        ``"disabled_by_secret_corrupt"``, ``"disabled_by_rotation"``)
        unlock precise alerting on tamper vs opt-out.
        """
        with self._lock:
            self._ensure_loaded()
            return {
                "integrity": self._integrity_state,
                "hmac": self._hmac_status.value,
                "quarantined_lines": self._quarantined_lines,
                "legacy_lines_migrated": self._legacy_lines_migrated,
                "persist_failures": self._persist_failures,
                "pending_persist": len(self._pending_persist),
                "tombstoned_records": self._tombstoned_records,
            }

    def reconcile_with_store(self, known_hashes: Set[str]) -> dict:
        """Eye R2 F3 partial-mitigation: find manifest records whose hash
        is not present in the caller-supplied set of currently-known
        store hashes. These are likely crash orphans where the manifest
        was sealed before the segment buffer flushed.

        This method REPORTS; it does not mutate. Callers decide whether
        to prune (via tombstone + reason="state_sync") or rematerialize.

        Returns a dict::

            {
              "total_records": int,
              "orphan_record_ids": [rid, ...],
              "orphan_by_source": {(st, sid): count, ...},
            }

        Intended to be called at agent startup after the store has
        loaded. In a clean shutdown the orphan list is empty; after a
        crash it pinpoints exactly what the segment buffer lost.
        """
        with self._lock:
            self._ensure_loaded()
            # R4.1 Cluster A (P0-5): reconcile is a read-path; gate so a
            # tampered chain cannot convince the operator that orphans
            # are clean.
            self._require_usable(op="reconcile_with_store")
            total = 0
            orphans: List[str] = []
            orphan_by_source: Dict[Tuple[str, str], int] = defaultdict(int)
            for identity, body_map in self._index.items():
                for body, buckets in body_map.items():
                    for (st, sid), rids in buckets.items():
                        for rid in rids:
                            total += 1
                            if rid in known_hashes:
                                continue
                            # Tombstoned records aren't orphans in the
                            # problem sense — they're intentionally not
                            # in the store.
                            if rid in self._tombstones.get(identity, set()):
                                continue
                            orphans.append(rid)
                            orphan_by_source[(st, sid)] += 1
            return {
                "total_records": total,
                "orphan_record_ids": orphans,
                "orphan_by_source": dict(orphan_by_source),
            }

    # ------------------------------------------------------------------ view

    def view(self) -> _ManifestView:
        return _ManifestView(self)
