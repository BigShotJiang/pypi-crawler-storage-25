"""
parsica_memory.ambient_events — Cross-body ambient event storage and routing.

Separate from activity_feed.py — ambient events are ephemeral, cross-body,
dedup-sensitive, and cursor-driven. activity_feed is continuity-oriented.

Storage:
  workspace/_meta/ambient_events/<identity_id>.jsonl  — event log
  workspace/_meta/ambient_events/<identity_id>.cursor.<safe_body_id>.json — per-body cursor

Peek/ack split:
  peek_ambient_events() — pure-read, returns (events, cursor_token)
  ack_ambient_events()  — persists cursor after successful turn

v2.9.4
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple


AMBIENT_DIR = "_meta/ambient_events"
EVENT_TTL_HOURS = 24   # events expire after 24 hours


def _safe_body_id(body_id: str) -> str:
    """Sanitize body_id for use in filename."""
    return hashlib.md5(body_id.encode()).hexdigest()[:16]


def _event_id(identity_id: str, record_id: str, truth_state: str, enricher_version: str) -> str:
    """Deterministic event_id — same record+version = same id = idempotent publish."""
    key = f"{identity_id}|{record_id}|{truth_state}|{enricher_version}"
    return hashlib.sha256(key.encode()).hexdigest()[:32]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _is_expired(published_at: str, ttl_hours: float = EVENT_TTL_HOURS) -> bool:
    try:
        dt = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
        age_hours = (datetime.now(timezone.utc) - dt).total_seconds() / 3600
        return age_hours > ttl_hours
    except Exception:
        return True  # nit fix: malformed timestamps treated as expired (safer default)


@dataclass
class AmbientEvent:
    """A cross-body ambient event."""
    event_id: str
    identity_id: str
    source_body_id: str
    target_scope: str      # "identity_durable" or "handoff_visible" — NEVER "body_local"
    record_id: str
    summary: str
    published_at: str = field(default_factory=_now_iso)
    expires_at: str = ""
    event_type: str = "discovery"
    confidence: float = 0.5

    def to_dict(self) -> dict:
        return {
            "event_id": self.event_id,
            "identity_id": self.identity_id,
            "source_body_id": self.source_body_id,
            "target_scope": self.target_scope,
            "record_id": self.record_id,
            "summary": self.summary,
            "published_at": self.published_at,
            "expires_at": self.expires_at,
            "event_type": self.event_type,
            "confidence": round(float(self.confidence), 4),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "AmbientEvent":
        return cls(
            event_id=d["event_id"],
            identity_id=d.get("identity_id", ""),
            source_body_id=d.get("source_body_id", ""),
            target_scope=d.get("target_scope", "identity_durable"),
            record_id=d.get("record_id", ""),
            summary=d.get("summary", ""),
            published_at=d.get("published_at", _now_iso()),
            expires_at=d.get("expires_at", ""),
            event_type=d.get("event_type", "discovery"),
            confidence=float(d.get("confidence", 0.5) or 0.5),
        )


class AmbientEventStore:
    """Manages ambient event storage, peek, and ack for one workspace."""

    def __init__(self, workspace: str) -> None:
        self._workspace = workspace
        self._dir = Path(workspace) / AMBIENT_DIR

    def _events_path(self, identity_id: str) -> Path:
        return self._dir / f"{identity_id}.jsonl"

    def _cursor_path(self, identity_id: str, body_id: str) -> Path:
        return self._dir / f"{identity_id}.cursor.{_safe_body_id(body_id)}.json"

    def publish(
        self,
        identity_id: str,
        source_body_id: str,
        record_id: str,
        summary: str,
        scope: str = "identity_durable",
        event_type: str = "discovery",
        truth_state: str = "accepted",
        enricher_version: str = "",
        confidence: float = 0.5,
    ) -> Optional[AmbientEvent]:
        """Publish a cross-body ambient event. Idempotent by event_id.

        Enforces: scope must NOT be body_local. Returns None if rejected.
        """
        # Enforce: never publish body-local events across bodies
        if scope == "body_local":
            return None

        eid = _event_id(identity_id, record_id, truth_state, enricher_version)
        event = AmbientEvent(
            event_id=eid,
            identity_id=identity_id,
            source_body_id=source_body_id,
            target_scope=scope,
            record_id=record_id,
            summary=summary[:500],   # cap summary length
            event_type=event_type,
            confidence=max(0.0, min(1.0, confidence)),
        )

        self._dir.mkdir(parents=True, exist_ok=True)
        path = self._events_path(identity_id)

        # Check for existing event_id (idempotency) — scan last 200 lines
        if path.exists():
            try:
                with open(path, encoding="utf-8") as f:
                    lines = f.readlines()
                for line in lines[-200:]:
                    try:
                        d = json.loads(line.strip())
                        if d.get("event_id") == eid:
                            return event  # already published
                    except (json.JSONDecodeError, KeyError):
                        pass
            except OSError:
                pass

        # Append event
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event.to_dict(), ensure_ascii=False) + "\n")
        except OSError:
            return None

        return event

    def peek(
        self,
        identity_id: str,
        body_id: str,
        limit: int = 5,
        min_confidence: float = 0.0,
    ) -> Tuple[List[AmbientEvent], str]:
        """Pure-read: return (unseen events for this body, opaque cursor_token).

        Filters out:
        - Events from this body (source_body_id == body_id)
        - Expired events
        - Events already seen (before stored cursor position)
        - Events below min_confidence threshold

        Returns (events, cursor_token). No writes.
        """
        cursor_pos = self._load_cursor(identity_id, body_id)
        events_path = self._events_path(identity_id)

        if not events_path.exists():
            return [], str(cursor_pos)

        events: List[AmbientEvent] = []
        new_pos = cursor_pos

        try:
            with open(events_path, encoding="utf-8") as f:
                all_lines = f.readlines()
        except OSError:
            return [], str(cursor_pos)

        for i, line in enumerate(all_lines):
            if i < cursor_pos:
                continue   # already seen
            line = line.strip()
            if not line:
                new_pos = i + 1
                continue
            try:
                d = json.loads(line)
                ev = AmbientEvent.from_dict(d)
            except (json.JSONDecodeError, KeyError):
                new_pos = i + 1
                continue

            new_pos = i + 1

            # Skip events from this body
            if ev.source_body_id == body_id:
                continue
            # Skip expired events
            if _is_expired(ev.published_at):
                continue
            # Skip low-confidence events
            if min_confidence > 0.0 and ev.confidence < min_confidence:
                continue

            events.append(ev)
            if len(events) >= limit:
                break

        # Sort by published_at desc, then event_id (deterministic)
        from parsica_memory.scope_utils import stable_event_sort_key
        events.sort(key=stable_event_sort_key)

        return events, str(new_pos)

    def ack(self, identity_id: str, body_id: str, cursor_token: str) -> None:
        """Persist cursor after a successful turn. Advances the read position."""
        try:
            pos = int(cursor_token)
        except (ValueError, TypeError):
            return
        self._save_cursor(identity_id, body_id, pos)

    def _load_cursor(self, identity_id: str, body_id: str) -> int:
        path = self._cursor_path(identity_id, body_id)
        if not path.exists():
            return 0
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            return int(d.get("position", 0))
        except (OSError, json.JSONDecodeError, ValueError, KeyError):
            return 0

    def _save_cursor(self, identity_id: str, body_id: str, position: int) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        path = self._cursor_path(identity_id, body_id)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"position": position, "updated_at": _now_iso()}, f)
        except OSError:
            pass
