from __future__ import annotations

import json
import os
from collections import defaultdict
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .contracts import BackgroundTask
from .locking import FileLock
from .utils import atomic_write_json


_TASK_KINDS = ("hydrate_record", "flush_hot", "compact_store")
_ACTIVE_STATES = {"queued", "leased", "running"}
_TERMINAL_STATES = {"done", "failed", "dead_letter", "obsolete"}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_iso(value: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class TaskJournal:
    """Background task journal with snapshot + append-only event tail."""

    def __init__(self, workspace: Path):
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.snapshot_path = self.workspace / "background_tasks.snapshot.json"
        self.events_path = self.workspace / "background_tasks.events.jsonl"
        self.lock_path = str(self.workspace / "background_tasks.state")
        self.leader_lock_path = str(self.workspace / "background_runner.lock")
        self._rotation_bytes = 5 * 1024 * 1024
        self._rotation_events = 10_000
        if not self.snapshot_path.exists():
            atomic_write_json(str(self.snapshot_path), {"tasks": {}, "updated_at": now_iso()})
        if not self.events_path.exists():
            self.events_path.write_text("", encoding="utf-8")

    def append_new(self, task: BackgroundTask) -> str:
        task_id, _ = self.append_unique(task)
        return task_id

    def append_unique(self, task: BackgroundTask) -> Tuple[str, bool]:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            for existing in tasks.values():
                if (
                    existing.dedupe_key == task.dedupe_key
                    and existing.state in _ACTIVE_STATES
                ):
                    return existing.task_id, False
            self._upsert_task(tasks, task, "created")
            self._write_snapshot(tasks)
            self._maybe_rotate_unlocked()
            return task.task_id, True

    def claim_next(
        self,
        worker_id: str,
        now_iso: str,
        lease_duration_s: int = 30,
    ) -> Optional[BackgroundTask]:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            now_dt = _parse_iso(now_iso) or datetime.now(timezone.utc)
            candidates: List[BackgroundTask] = []
            for task in tasks.values():
                if task.state == "queued":
                    candidates.append(task)
                    continue
                if task.state in {"leased", "running"}:
                    lease_until = _parse_iso(task.lease_until)
                    if lease_until is None or lease_until <= now_dt:
                        candidates.append(task)
            if not candidates:
                return None
            candidates.sort(key=lambda t: (-int(t.priority or 0), t.created_at, t.task_id))
            task = candidates[0]
            task.state = "running"
            task.worker_id = worker_id
            task.attempt = int(task.attempt or 0) + 1
            task.updated_at = now_iso
            task.lease_until = (now_dt + timedelta(seconds=lease_duration_s)).isoformat()
            self._upsert_task(tasks, task, "claimed")
            self._write_snapshot(tasks)
            self._update_leader(worker_id)
            self._maybe_rotate_unlocked()
            return task

    def heartbeat(self, task_id: str, worker_id: str, lease_until: str) -> None:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            task = tasks.get(task_id)
            if task is None:
                return
            if task.worker_id and task.worker_id != worker_id:
                return
            task.worker_id = worker_id
            task.lease_until = lease_until
            task.state = "running"
            task.updated_at = now_iso()
            self._upsert_task(tasks, task, "heartbeat")
            self._write_snapshot(tasks)
            self._update_leader(worker_id)
            self._maybe_rotate_unlocked()

    def complete(self, task_id: str, worker_id: str, result: dict) -> None:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            task = tasks.get(task_id)
            if task is None:
                return
            if task.worker_id and task.worker_id != worker_id:
                return
            task.worker_id = worker_id
            task.state = "done"
            task.updated_at = now_iso()
            task.lease_until = ""
            task.result = dict(result or {})
            task.last_error = ""
            self._upsert_task(tasks, task, "completed")
            self._write_snapshot(tasks)
            self._update_leader(worker_id)
            self._maybe_rotate_unlocked()

    def fail(self, task_id: str, worker_id: str, error: str, retryable: bool = True) -> None:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            task = tasks.get(task_id)
            if task is None:
                return
            if task.worker_id and task.worker_id != worker_id:
                return
            task.worker_id = worker_id
            task.updated_at = now_iso()
            task.lease_until = ""
            task.last_error = error or ""
            attempts = int(task.attempt or 0)
            max_attempts = int(task.max_attempts or 0)
            if retryable and attempts < max_attempts:
                task.state = "queued"
            else:
                task.state = "dead_letter" if retryable else "failed"
            self._upsert_task(tasks, task, "failed")
            self._write_snapshot(tasks)
            self._update_leader(worker_id)
            self._maybe_rotate_unlocked()

    def mark_obsolete(self, task_id: str, worker_id: str) -> None:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            task = tasks.get(task_id)
            if task is None:
                return
            if task.worker_id and task.worker_id != worker_id:
                return
            task.worker_id = worker_id
            task.state = "obsolete"
            task.updated_at = now_iso()
            task.lease_until = ""
            self._upsert_task(tasks, task, "obsolete")
            self._write_snapshot(tasks)
            self._update_leader(worker_id)
            self._maybe_rotate_unlocked()

    def checkpoint(self) -> None:
        with FileLock(self.lock_path):
            tasks = self._load_snapshot()
            self._write_snapshot(tasks)

    def compact_history(self, keep_terminal_days: int = 7, max_events: int = 10_000) -> None:
        with FileLock(self.lock_path):
            self._compact_history_unlocked(keep_terminal_days=keep_terminal_days, max_events=max_events)

    def _compact_history_unlocked(self, keep_terminal_days: int = 7, max_events: int = 10_000) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=keep_terminal_days)
        tasks = self._load_snapshot()
        active_ids = {task_id for task_id, task in tasks.items() if task.state in _ACTIVE_STATES}
        retained: List[str] = []
        if self.events_path.exists():
            with self.events_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    task_id = event.get("task_id", "")
                    state = event.get("state", "")
                    ts = _parse_iso(event.get("ts", "")) or datetime.now(timezone.utc)
                    if task_id in active_ids:
                        retained.append(json.dumps(event, sort_keys=True))
                        continue
                    if state in _TERMINAL_STATES and ts >= cutoff:
                        retained.append(json.dumps(event, sort_keys=True))
        if len(retained) > max_events:
            retained = retained[-max_events:]
        content = ("\n".join(retained) + ("\n" if retained else ""))
        self.events_path.write_text(content, encoding="utf-8")
        self._write_snapshot(tasks)

    def stats(self) -> dict:
        tasks = self._load_snapshot()
        events = self._read_events()
        now_dt = datetime.now(timezone.utc)
        by_kind = {
            kind: {"queued": 0, "done": 0, "failed": 0}
            for kind in _TASK_KINDS
        }
        queue_depth = 0
        running_count = 0
        dead_letter_count = 0
        obsolete_count = 0
        oldest_queued_age_ms = 0
        active_workers = set()

        for task in tasks.values():
            kind_bucket = by_kind.setdefault(task.kind, {"queued": 0, "done": 0, "failed": 0})
            if task.state == "queued":
                queue_depth += 1
                kind_bucket["queued"] += 1
                created = _parse_iso(task.created_at)
                if created is not None:
                    age_ms = max(0, int((now_dt - created).total_seconds() * 1000))
                    oldest_queued_age_ms = max(oldest_queued_age_ms, age_ms)
            if task.state in {"leased", "running"}:
                running_count += 1
                if task.worker_id:
                    active_workers.add(task.worker_id)
            if task.state == "dead_letter":
                dead_letter_count += 1
                kind_bucket["failed"] += 1
            elif task.state == "obsolete":
                obsolete_count += 1
            elif task.state == "done":
                kind_bucket["done"] += 1
            elif task.state == "failed":
                kind_bucket["failed"] += 1

        completed_count = 0
        failed_count = 0
        latency_values: List[float] = []
        terminal_seen = set()
        for event in events:
            ev = event.get("event")
            state = event.get("state")
            task_id = event.get("task_id")
            if ev == "completed" or state == "done":
                completed_count += 1
                if task_id and task_id not in terminal_seen:
                    task = tasks.get(task_id)
                    if task is not None:
                        created = _parse_iso(task.created_at)
                        updated = _parse_iso(task.updated_at)
                        if created is not None and updated is not None:
                            latency_values.append(max(0.0, (updated - created).total_seconds() * 1000.0))
                    terminal_seen.add(task_id)
            elif ev == "failed" or state in {"failed", "dead_letter"}:
                failed_count += 1

        avg_latency_ms = round(sum(latency_values) / len(latency_values), 3) if latency_values else 0.0
        return {
            "queue_depth": queue_depth,
            "running_count": running_count,
            "dead_letter_count": dead_letter_count,
            "obsolete_count": obsolete_count,
            "total_completed": completed_count,
            "total_failed": failed_count,
            "avg_latency_ms": avg_latency_ms,
            "oldest_queued_age_ms": oldest_queued_age_ms,
            "active_worker_count": len(active_workers),
            "leader_worker_id": self._leader_worker_id(),
            "by_kind": by_kind,
        }

    def _load_snapshot(self) -> Dict[str, BackgroundTask]:
        try:
            data = json.loads(self.snapshot_path.read_text(encoding="utf-8"))
        except Exception:
            data = {"tasks": {}}
        raw_tasks = data.get("tasks", {}) if isinstance(data, dict) else {}
        tasks: Dict[str, BackgroundTask] = {}
        if isinstance(raw_tasks, list):
            for item in raw_tasks:
                task = self._task_from_dict(item)
                tasks[task.task_id] = task
        elif isinstance(raw_tasks, dict):
            for task_id, item in raw_tasks.items():
                payload = item if isinstance(item, dict) else {}
                payload.setdefault("task_id", task_id)
                task = self._task_from_dict(payload)
                tasks[task.task_id] = task
        return tasks

    def _write_snapshot(self, tasks: Dict[str, BackgroundTask]) -> None:
        data = {
            "updated_at": now_iso(),
            "tasks": {task_id: asdict(task) for task_id, task in tasks.items()},
        }
        atomic_write_json(str(self.snapshot_path), data)

    def _task_from_dict(self, data: dict) -> BackgroundTask:
        payload = dict(data or {})
        payload.setdefault("payload", {})
        payload.setdefault("result", {})
        return BackgroundTask(**payload)

    def _append_event(self, task: BackgroundTask, event: str) -> None:
        row = {
            "ts": now_iso(),
            "event": event,
            "task_id": task.task_id,
            "kind": task.kind,
            "state": task.state,
            "worker_id": task.worker_id,
            "attempt": task.attempt,
            "dedupe_key": task.dedupe_key,
        }
        with self.events_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, sort_keys=True) + "\n")

    def _upsert_task(self, tasks: Dict[str, BackgroundTask], task: BackgroundTask, event: str) -> None:
        tasks[task.task_id] = task
        self._append_event(task, event)

    def _read_events(self) -> List[dict]:
        rows: List[dict] = []
        if not self.events_path.exists():
            return rows
        with self.events_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return rows

    def _maybe_rotate_unlocked(self) -> None:
        size = self.events_path.stat().st_size if self.events_path.exists() else 0
        event_count = 0
        if self.events_path.exists():
            with self.events_path.open("r", encoding="utf-8") as handle:
                for event_count, _ in enumerate(handle, start=1):
                    if event_count > self._rotation_events:
                        break
        if size > self._rotation_bytes or event_count > self._rotation_events:
            self._compact_history_unlocked()  # already inside lock

    def _update_leader(self, worker_id: str) -> None:
        if not worker_id:
            return
        with FileLock(self.leader_lock_path):
            leader_dir = Path(self.leader_lock_path + ".lock")
            meta_path = leader_dir / "holder.json"
            payload = {}
            if meta_path.exists():
                try:
                    payload = json.loads(meta_path.read_text(encoding="utf-8"))
                except Exception:
                    payload = {}
            payload["worker_id"] = worker_id
            payload["updated_at"] = now_iso()
            meta_path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")

    def _leader_worker_id(self) -> str:
        meta_path = Path(self.leader_lock_path + ".lock") / "holder.json"
        if not meta_path.exists():
            return ""
        try:
            payload = json.loads(meta_path.read_text(encoding="utf-8"))
            return str(payload.get("worker_id", "") or "")
        except Exception:
            return ""

    def try_acquire_leader(self, worker_id: str, lease_s: int = 60) -> bool:
        """Try to become the leader runner for this workspace.

        Returns True if this worker_id is now the leader (either it was already
        the leader, or the previous lease expired).  Returns False if another
        worker holds a valid lease.

        v2.8 policy: only the leader may call claim_next() and execute tasks.
        """
        if not worker_id:
            return False
        with FileLock(self.leader_lock_path):
            leader_dir = Path(self.leader_lock_path + ".lock")
            meta_path = leader_dir / "holder.json"
            now_dt = datetime.now(timezone.utc)
            payload: dict = {}
            if meta_path.exists():
                try:
                    payload = json.loads(meta_path.read_text(encoding="utf-8"))
                except Exception:
                    payload = {}
            current_holder = str(payload.get("worker_id", "") or "")
            lease_until_str = str(payload.get("lease_until", "") or "")
            lease_until = _parse_iso(lease_until_str)
            # Allow acquisition if: no current holder, same worker, or lease expired
            if (
                not current_holder
                or current_holder == worker_id
                or lease_until is None
                or now_dt >= lease_until
            ):
                payload["worker_id"] = worker_id
                payload["updated_at"] = now_dt.isoformat()
                payload["lease_until"] = (now_dt + timedelta(seconds=lease_s)).isoformat()
                meta_path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
                return True
            return False

    def release_leader(self, worker_id: str) -> None:
        """Release leadership if this worker_id currently holds it."""
        with FileLock(self.leader_lock_path):
            leader_dir = Path(self.leader_lock_path + ".lock")
            meta_path = leader_dir / "holder.json"
            if not meta_path.exists():
                return
            try:
                payload = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                return
            if payload.get("worker_id") == worker_id:
                payload["worker_id"] = ""
                payload["lease_until"] = ""
                payload["updated_at"] = datetime.now(timezone.utc).isoformat()
                meta_path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
