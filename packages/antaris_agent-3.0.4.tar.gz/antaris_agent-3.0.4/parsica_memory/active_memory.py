"""
parsica_memory.active_memory — Pre-reply activation layer (v2.9.5).

ActivationPacket is assembled once per turn, before the LLM composes a reply.
It is the single context injection point — replaces all scattered pre-reply stuffing.

Invariants:
- Pure-read: zero writes, zero LLM calls, zero worker scheduling
- Synchronous: no async; pipeline wraps in executor if needed
- 250ms hard deadline: returns partial packet on timeout
- Only fires for USER_ANSWER purpose
- Shadow mode: build + log but do not inject (for rollout validation)

Stage budgets (250ms total):
  fingerprint/route:        15ms
  current session+handoffs: 60ms
  durable+pack retrieval:   90ms
  rerank/compose:           60ms
  reserve:                  25ms

Candidate caps:
  current_session_max = 8
  handoff_max = 5
  durable_hit_max = 20
  pack_entry_max = 30
  evidence_max = 10

v2.9.5
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Optional

from parsica_memory.contracts import surfaceable as _surfaceable_shared  # v2.9.9
from parsica_memory.contracts import RECORD_STATE_WEIGHTS as _RECORD_STATE_WEIGHTS  # v2.9.9 Phase B

if TYPE_CHECKING:
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem
    from parsica_memory.packs import KnowledgePack

logger = logging.getLogger("parsica_memory.active_memory")

# Hard candidate caps (per manifest spec)
ACTIVE_MEMORY_CAPS = {
    "current_session_max": 8,
    "handoff_max": 5,
    "durable_hit_max": 20,
    "pack_entry_max": 30,
    "evidence_max": 10,
}

# Stage time budgets in ms (must sum to <= 250)
STAGE_BUDGETS_MS = {
    "fingerprint": 15,
    "session_handoff": 60,
    "durable_packs": 90,
    "rerank_compose": 60,
    "reserve": 25,
}


@dataclass
class ActivationPacket:
    """Single context injection point for pre-reply activation."""
    mode: str = "full"              # "full" | "partial" | "minimal" | "timeout"
    latency_ms: int = 0
    current_state_block: str = ""
    handoff_block: str = ""
    durable_knowledge_block: str = ""
    pack_block: str = ""
    evidence_block: str = ""
    source_refs: List[str] = field(default_factory=list)
    diagnostics: dict = field(default_factory=dict)
    budget_exceeded: bool = False
    activation_hash: str = ""       # determinism proof

    def render(self) -> str:
        """Render non-empty blocks as a single context string."""
        parts = []
        if self.current_state_block:
            parts.append(f"[Current Session]\n{self.current_state_block}")
        if self.handoff_block:
            parts.append(f"[Handoffs]\n{self.handoff_block}")
        if self.durable_knowledge_block:
            parts.append(f"[Knowledge]\n{self.durable_knowledge_block}")
        if self.pack_block:
            parts.append(f"[Packs]\n{self.pack_block}")
        if self.evidence_block:
            parts.append(f"[Evidence]\n{self.evidence_block}")
        return "\n\n".join(parts)

    def is_empty(self) -> bool:
        return not any([
            self.current_state_block, self.handoff_block,
            self.durable_knowledge_block, self.pack_block, self.evidence_block,
        ])

    def to_dict(self) -> dict:
        return {
            "mode": self.mode,
            "latency_ms": self.latency_ms,
            "current_state_block": self.current_state_block,
            "handoff_block": self.handoff_block,
            "durable_knowledge_block": self.durable_knowledge_block,
            "pack_block": self.pack_block,
            "evidence_block": self.evidence_block,
            "source_refs": self.source_refs,
            "diagnostics": self.diagnostics,
            "budget_exceeded": self.budget_exceeded,
            "activation_hash": self.activation_hash,
        }


def _now_ms() -> float:
    return time.monotonic() * 1000


def _elapsed_ms(start: float) -> float:
    return _now_ms() - start


def _activation_hash(
    identity_id: str,
    body_id: str,
    session_id: str,
    user_message: str,
    token_budget: int,
) -> str:
    from parsica_memory.scope_utils import stable_hash
    return stable_hash({
        "identity_id": identity_id,
        "body_id": body_id,
        "session_id": session_id,
        "user_message_prefix": user_message[:100],
        "token_budget": token_budget,
    })


def _surfaceable(entry) -> bool:
    """Delegate to shared surfaceable() in contracts (v2.9.9 dedup)."""
    return _surfaceable_shared(entry)


class ActiveMemory:
    """Pre-reply activation layer. Synchronous. Pure-read. 250ms deadline."""

    def activate(
        self,
        identity_id: str,
        body_id: str,
        session_id: str,
        user_message: str,
        memory_system: "MemorySystem",
        *,
        packs: Optional[List["KnowledgePack"]] = None,
        handoff_data: Optional[dict] = None,
        token_budget: int = 1500,
        deadline_ms: int = 250,
        side_effect_mode: str = "pure_read",
    ) -> ActivationPacket:
        """Activate memory for the current turn. Pure-read. Synchronous.

        Returns ActivationPacket with mode="partial" and budget_exceeded=True
        if the deadline is hit before all stages complete.

        Must NOT:
        - Write to memory_system
        - Call an LLM
        - Schedule background workers
        - Persist traces

        Args:
            identity_id: Agent/user identity
            body_id: Current body (agent_name:channel)
            session_id: Current session
            user_message: The user's message (for fingerprinting)
            memory_system: The memory system to read from
            packs: Optional pre-selected packs to include
            handoff_data: Optional explicit handoff context dict
            token_budget: Max tokens to fill
            deadline_ms: Hard deadline in milliseconds (default 250)
            side_effect_mode: Must be "pure_read" — enforced internally
        """
        t_start = _now_ms()
        deadline_abs = t_start + deadline_ms
        packet = ActivationPacket()
        packet.activation_hash = _activation_hash(
            identity_id, body_id, session_id, user_message, token_budget
        )
        packet.diagnostics = {
            "identity_id": identity_id,
            "body_id": body_id,
            "session_id": session_id,
            "token_budget": token_budget,
            "deadline_ms": deadline_ms,
            "stages": {},
        }

        # Per-stage token budgets (proportional to time budgets)
        total_time = sum(STAGE_BUDGETS_MS.values()) - STAGE_BUDGETS_MS["reserve"]
        session_tokens = int(token_budget * STAGE_BUDGETS_MS["session_handoff"] / total_time)
        durable_tokens = int(token_budget * STAGE_BUDGETS_MS["durable_packs"] / total_time)
        compose_tokens = token_budget - session_tokens - durable_tokens
        overflow = 0

        try:
            # Stage 1: fingerprint/route (15ms budget)
            t_stage = _now_ms()
            query_mode = self._fingerprint(user_message)
            packet.diagnostics["stages"]["fingerprint_ms"] = round(_elapsed_ms(t_stage), 1)
            packet.diagnostics["query_mode"] = query_mode

            # Check deadline
            if _now_ms() > deadline_abs - STAGE_BUDGETS_MS["reserve"]:
                packet.mode = "minimal"
                packet.budget_exceeded = True
                packet.latency_ms = int(_elapsed_ms(t_start))
                return packet

            # Stage 2: current session + handoffs (60ms budget)
            t_stage = _now_ms()
            session_block, handoff_block, session_refs = self._fetch_session_handoff(
                memory_system, session_id, body_id, handoff_data,
                session_tokens + overflow,
            )
            overflow = max(0, session_tokens - len(session_block) // 4)
            packet.current_state_block = session_block
            packet.handoff_block = handoff_block
            packet.source_refs.extend(session_refs)
            packet.diagnostics["stages"]["session_handoff_ms"] = round(_elapsed_ms(t_stage), 1)

            if _now_ms() > deadline_abs - STAGE_BUDGETS_MS["reserve"]:
                packet.mode = "partial"
                packet.budget_exceeded = True
                packet.latency_ms = int(_elapsed_ms(t_start))
                return packet

            # Stage 3: durable + pack retrieval (90ms budget)
            t_stage = _now_ms()
            durable_block, pack_block, durable_refs = self._fetch_durable_packs(
                memory_system, identity_id, body_id, packs,
                durable_tokens + overflow,
            )
            overflow = max(0, durable_tokens - len(durable_block) // 4)
            packet.durable_knowledge_block = durable_block
            packet.pack_block = pack_block
            packet.source_refs.extend(durable_refs)
            packet.diagnostics["stages"]["durable_packs_ms"] = round(_elapsed_ms(t_stage), 1)

            if _now_ms() > deadline_abs - STAGE_BUDGETS_MS["reserve"]:
                packet.mode = "partial"
                packet.budget_exceeded = True
                packet.latency_ms = int(_elapsed_ms(t_start))
                return packet

            # Stage 4: rerank/compose (60ms budget)
            t_stage = _now_ms()
            evidence_block, evidence_refs = self._fetch_evidence(
                memory_system, session_id, compose_tokens + overflow,
            )
            packet.evidence_block = evidence_block
            packet.source_refs.extend(evidence_refs)
            packet.diagnostics["stages"]["rerank_compose_ms"] = round(_elapsed_ms(t_stage), 1)

        except Exception as exc:
            logger.warning("ActiveMemory.activate stage failed: %s", exc, exc_info=True)
            packet.mode = "partial"
            packet.diagnostics["error"] = str(exc)

        elapsed = _elapsed_ms(t_start)
        packet.latency_ms = int(elapsed)
        if elapsed > deadline_ms:
            packet.budget_exceeded = True
            if packet.mode == "full":
                packet.mode = "partial"
        elif not packet.budget_exceeded:
            packet.mode = "full"

        return packet

    def _fingerprint(self, user_message: str) -> str:
        """Classify query type for retrieval mode selection. 15ms budget."""
        msg_lower = user_message.lower()
        if any(w in msg_lower for w in ("remember", "recall", "what did", "last time")):
            return "recency"
        if any(w in msg_lower for w in ("prefer", "always", "never", "usually")):
            return "preference"
        if any(w in msg_lower for w in ("how to", "steps", "procedure", "process")):
            return "procedure"
        return "semantic"

    def _fetch_session_handoff(
        self,
        memory_system: "MemorySystem",
        session_id: str,
        body_id: str,
        handoff_data: Optional[dict],
        token_budget: int,
    ) -> tuple:
        """Fetch current session state + handoffs. Pure-read. Returns (session, handoff, refs)."""
        from parsica_memory.context_assembler import estimate_tokens

        memories = getattr(memory_system, "memories", [])
        session_lines = []
        session_refs = []
        used = 0
        cap = ACTIVE_MEMORY_CAPS["current_session_max"]

        # Session state — body-local entries from this session/body
        candidates = []
        for m in memories:
            scope = getattr(m, "retrieval_scope", "") or ""
            m_session = getattr(m, "session_id", "") or ""
            m_body = getattr(m, "body_id", "") or ""
            if scope == "body_local" and (m_session == session_id or m_body == body_id):
                # Phase 3: exclude stale/suppressed entries
                if not _surfaceable(m):
                    continue
                candidates.append(m)

        candidates.sort(
            key=lambda m: getattr(m, "created", None) or getattr(m, "created_at", None) or "",
            reverse=True,
        )

        session_token_budget = int(token_budget * 0.6)
        for m in candidates[:cap]:
            content = (getattr(m, "content", "") or "")[:200]
            t = estimate_tokens(content)
            if used + t > session_token_budget:
                break
            session_lines.append(f"- {content}")
            rid = getattr(m, "record_id", "")
            if rid:
                session_refs.append(rid)
            used += t

        # Handoffs
        handoff_lines = []
        if handoff_data and isinstance(handoff_data, dict):
            handoff_budget = token_budget - used
            handoff_cap = ACTIVE_MEMORY_CAPS["handoff_max"]
            for i, (k, v) in enumerate(handoff_data.items()):
                if i >= handoff_cap:
                    break
                line = f"{k}: {v}"
                t = estimate_tokens(line)
                if t > handoff_budget:
                    break
                handoff_lines.append(line)
                handoff_budget -= t

        return "\n".join(session_lines), "\n".join(handoff_lines), session_refs

    def _fetch_durable_packs(
        self,
        memory_system: "MemorySystem",
        identity_id: str,
        body_id: str,
        packs: Optional[list],
        token_budget: int,
    ) -> tuple:
        """Fetch identity-durable knowledge + pack content. Pure-read."""
        from parsica_memory.context_assembler import estimate_tokens

        DURABLE_KINDS = {"fact", "preference", "procedure", "mistake"}
        memories = getattr(memory_system, "memories", [])
        durable_lines = []
        durable_refs = []
        used = 0
        cap = ACTIVE_MEMORY_CAPS["durable_hit_max"]
        durable_budget = int(token_budget * 0.6)

        candidates = [
            m for m in memories
            if (getattr(m, "retrieval_scope", "") or "") == "identity_durable"
            and (getattr(m, "record_kind", "") or getattr(m, "memory_type", "") or "").lower() in DURABLE_KINDS
            and _surfaceable(m)  # Phase 3: exclude stale/suppressed entries
        ]
        # Phase B: lifecycle-aware ranking — apply RECORD_STATE_WEIGHTS to importance score
        candidates.sort(key=lambda m: -(
            float(getattr(m, "importance", 0.5) or 0.5)
            * _RECORD_STATE_WEIGHTS.get((getattr(m, "state", "active") or "active").lower(), 1.0)
        ))

        for m in candidates[:cap]:
            content = (getattr(m, "content", "") or "")[:300]
            t = estimate_tokens(content)
            if used + t > durable_budget:
                break
            kind = (getattr(m, "record_kind", "") or getattr(m, "memory_type", "") or "fact")
            durable_lines.append(f"[{kind}] {content}")
            rid = getattr(m, "record_id", "")
            if rid:
                durable_refs.append(rid)
            used += t

        # Packs
        pack_lines = []
        if packs:
            from parsica_memory.packs import PackAssembler
            assembler = PackAssembler()
            pack_budget = token_budget - used
            pack_used = 0
            total_pack_cap = ACTIVE_MEMORY_CAPS["pack_entry_max"]  # P2 fix: total cap across all packs
            total_pack_entries = 0
            for pack in packs[:3]:
                try:
                    entries = assembler.get_pack_entries(pack, memory_system)
                    for entry in entries:
                        if total_pack_entries >= total_pack_cap:
                            break
                        content = (getattr(entry, "content", "") or "")[:200]
                        t = estimate_tokens(content)
                        if pack_used + t > pack_budget:
                            break
                        pack_lines.append(f"[{pack.name}] {content}")
                        pack_used += t
                        total_pack_entries += 1
                except Exception:
                    pass

        return "\n".join(durable_lines), "\n".join(pack_lines), durable_refs

    def _fetch_evidence(
        self,
        memory_system: "MemorySystem",
        session_id: str,
        token_budget: int,
    ) -> tuple:
        """Fetch raw evidence anchors. Pure-read."""
        from parsica_memory.context_assembler import estimate_tokens

        memories = getattr(memory_system, "memories", [])
        cap = ACTIVE_MEMORY_CAPS["evidence_max"]
        episodic = [
            m for m in memories
            if (getattr(m, "memory_type", "") or "").lower() == "episodic"
            and _surfaceable(m)  # Phase 3: exclude stale/suppressed entries
        ]
        # Phase B: lifecycle-aware ranking — apply RECORD_STATE_WEIGHTS to importance score
        episodic.sort(key=lambda m: -(
            float(getattr(m, "importance", 0.5) or 0.5)
            * _RECORD_STATE_WEIGHTS.get((getattr(m, "state", "active") or "active").lower(), 1.0)
        ))

        lines = []
        refs = []
        used = 0
        for m in episodic[:cap]:
            content = (getattr(m, "content", "") or "")[:200]
            t = estimate_tokens(content)
            if used + t > token_budget:
                break
            lines.append(f"- {content}")
            rid = getattr(m, "record_id", "")
            if rid:
                refs.append(rid)
            used += t

        return "\n".join(lines), refs
