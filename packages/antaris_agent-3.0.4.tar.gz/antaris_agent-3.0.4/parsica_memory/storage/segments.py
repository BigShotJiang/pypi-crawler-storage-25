"""Segment I/O and hot buffer for Parsica Memory v3.2.0.

Segment format
--------------
A segment is a plain UTF-8 JSONL file: one serialised :class:`MemoryEntry`
per line, no header, no trailing metadata.  The filename encodes the sequence
number, flush timestamp, and entry count for human readability but carries no
semantic weight — the manifest is authoritative for all segment metadata.

Segment files are write-once.  After :meth:`SegmentWriter.write_segment`
returns, the file is never modified; it is only read or deleted (during
compaction).  A SHA-256 checksum of the raw bytes is computed during write
and stored in the manifest for integrity verification.

Hot buffer contract
-------------------
``hot.jsonl`` is the only mutable file in the storage layer.  Each write
appends a single JSON operation envelope and fsyncs before returning.  The
envelope schema is::

    {"op": "put",    "hash": "<sha256>", "entry": {...}, "ts": "<iso>"}
    {"op": "delete", "hash": "<sha256>", "reason": "<str>", "ts": "<iso>"}

The hot buffer uses a ``FileLock`` (directory-based, NFS-safe) around every
append to serialise concurrent writers.

Crash safety
------------
- Every ``append_put`` / ``append_delete`` fsyncs the file and the directory
  before returning.  No committed op can be silently lost.
- ``rotate()`` uses ``os.replace`` (atomic rename) to pivot ``hot.jsonl`` →
  ``hot.rotating.jsonl``, then creates a new empty ``hot.jsonl``.  If the
  process dies between the rename and the creation, ``hot.jsonl`` will be
  absent on restart; :meth:`rotate` detects this and heals it.
- ``hot.rotating.jsonl`` left on disk after a crash is detected and replayed
  by ``SegmentStore.load()`` before any new ops are processed.

Replay semantics
----------------
Two replay helpers are provided with deliberately different semantics:

:meth:`HotBuffer.replay`
    Returns ``(puts_list, deletes_set)`` — fast and simple, but **loses
    interleaving order** between puts and deletes.  Use only when the caller
    handles ordering externally (e.g. ``SegmentStore.load()`` already
    processes ops in arrival order before calling this).

:meth:`HotBuffer.replay_ordered`
    Returns the raw op list in log order with type tags intact, preserving
    the precise interleaving.  Use this whenever correct net-state requires
    respecting the sequence of puts and deletes (e.g. flush computation,
    external tools that reconstruct store state).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from typing import Any, Optional

from parsica_memory.entry import MemoryEntry
from parsica_memory.locking import FileLock

logger = logging.getLogger("parsica_memory")

# Type alias: a single ordered op dict from the hot log.
ReplayOp = dict[str, Any]


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _utc_now_iso() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _fsync_directory(path: str) -> None:
    """Fsync the directory containing *path* to make renames durable."""
    dir_path = os.path.dirname(path) or "."
    try:
        dir_fd = os.open(dir_path, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except (OSError, AttributeError):
        pass


def _atomic_write_bytes(path: str, data: bytes) -> None:
    """Write *data* to *path* atomically using a temp-file + rename pattern."""
    dir_path = os.path.dirname(path) or "."
    os.makedirs(dir_path, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=dir_path, suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, path)
        _fsync_directory(path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _safe_load_json_line(
    line: str,
    path: str,
    line_number: int,
) -> Optional[dict[str, Any]]:
    """Parse a single JSONL line, logging and returning ``None`` on any error."""
    try:
        value = json.loads(line)
    except json.JSONDecodeError as exc:
        logger.warning(
            "Skipping malformed JSON line in %s at line %s: %s",
            path,
            line_number,
            exc,
        )
        return None
    if not isinstance(value, dict):
        logger.warning(
            "Skipping non-object JSON line in %s at line %s",
            path,
            line_number,
        )
        return None
    return value


# ---------------------------------------------------------------------------
# SegmentWriter
# ---------------------------------------------------------------------------

class SegmentWriter:
    """Write immutable JSONL segment files.

    All methods are static — no instance state is maintained.  The caller
    is responsible for choosing a filename and registering the returned
    metadata in the manifest.
    """

    @staticmethod
    def write_segment(path: str, entries: list[MemoryEntry]) -> dict[str, Any]:
        """Write *entries* to an immutable JSONL segment file at *path*.

        The segment is written atomically (temp file → fsync → rename).
        A SHA-256 checksum of the raw bytes is computed and returned in the
        metadata dict so that the caller can store it in the manifest for
        later integrity verification.

        Parameters
        ----------
        path : str
            Destination filesystem path for the new segment file.  The parent
            directory is created if it does not exist.
        entries : list[MemoryEntry]
            Entries to write.  The order is preserved exactly.  The caller is
            responsible for deduplication before calling this method.

        Returns
        -------
        dict[str, Any]
            Segment metadata suitable for inclusion in ``manifest.json``::

                {
                    "entry_count": int,
                    "size_bytes": int,
                    "checksum_sha256": str,
                    "min_created": str | None,
                    "max_created": str | None,
                    "categories": dict[str, int],
                    "memory_types": dict[str, int],
                    "originals_count": int,
                    "derived_count": int,
                    "agent_ids": list[str],
                    "session_ids_sample": list[str],
                    "source_channels": list[str],
                    "has_lineage_fields": bool,
                }
        """
        lines: list[str] = []
        checksum = hashlib.sha256()
        categories: dict[str, int] = {}
        memory_types: dict[str, int] = {}
        agent_ids: set[str] = set()
        session_ids_sample: list[str] = []
        seen_sessions: set[str] = set()
        source_channels: set[str] = set()
        min_created: Optional[str] = None
        max_created: Optional[str] = None
        originals_count = 0
        derived_count = 0
        has_lineage_fields = False

        for entry in entries:
            entry_dict = entry.to_dict()
            line = json.dumps(entry_dict, ensure_ascii=False) + "\n"
            lines.append(line)
            checksum.update(line.encode("utf-8"))

            category = entry.category or "general"
            categories[category] = categories.get(category, 0) + 1

            memory_type = entry.memory_type or "episodic"
            memory_types[memory_type] = memory_types.get(memory_type, 0) + 1

            created = entry.created or ""
            if created:
                if min_created is None or created < min_created:
                    min_created = created
                if max_created is None or created > max_created:
                    max_created = created

            if getattr(entry, "provenance", "self") == "self":
                originals_count += 1
            else:
                derived_count += 1
                has_lineage_fields = True

            if getattr(entry, "parent_hash", ""):
                has_lineage_fields = True

            agent_id = getattr(entry, "agent_id", "")
            if agent_id:
                agent_ids.add(agent_id)

            session_id = getattr(entry, "session_id", "")
            if session_id and session_id not in seen_sessions and len(session_ids_sample) < 20:
                seen_sessions.add(session_id)
                session_ids_sample.append(session_id)

            source_channel = getattr(entry, "source_channel", "")
            if source_channel:
                source_channels.add(source_channel)

        payload = "".join(lines).encode("utf-8")
        _atomic_write_bytes(path, payload)
        size_bytes = os.path.getsize(path) if os.path.exists(path) else len(payload)

        return {
            "entry_count": len(entries),
            "size_bytes": size_bytes,
            "checksum_sha256": checksum.hexdigest(),
            "min_created": min_created,
            "max_created": max_created,
            "categories": categories,
            "memory_types": memory_types,
            "originals_count": originals_count,
            "derived_count": derived_count,
            "agent_ids": sorted(agent_ids),
            "session_ids_sample": session_ids_sample,
            "source_channels": sorted(source_channels),
            "has_lineage_fields": has_lineage_fields,
        }


# ---------------------------------------------------------------------------
# SegmentReader
# ---------------------------------------------------------------------------

class SegmentReader:
    """Read and verify immutable JSONL segment files.

    All methods are static — no instance state is maintained.
    """

    @staticmethod
    def read_segment(path: str) -> list[MemoryEntry]:
        """Read all :class:`MemoryEntry` objects from an immutable segment file.

        Parameters
        ----------
        path : str
            Filesystem path to the segment JSONL file.

        Returns
        -------
        list[MemoryEntry]
            Entries in file order.  Malformed lines are logged and skipped;
            they do not raise an exception.
        """
        entries: list[MemoryEntry] = []
        if not os.path.exists(path):
            return entries

        with open(path, "r", encoding="utf-8") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                data = _safe_load_json_line(line, path, line_number)
                if data is None:
                    continue
                try:
                    entries.append(MemoryEntry.from_dict(data))
                except Exception as exc:
                    logger.warning(
                        "Skipping invalid segment entry in %s at line %s: %s",
                        path,
                        line_number,
                        exc,
                    )
        return entries

    @staticmethod
    def read_segment_hashes(path: str) -> set[str]:
        """Read only the ``hash`` field from each line of a segment file.

        Faster than :meth:`read_segment` when only set membership is needed
        (e.g. tombstone resolution during compaction planning).

        Parameters
        ----------
        path : str
            Filesystem path to the segment JSONL file.

        Returns
        -------
        set[str]
            Set of hash strings found in the file.
        """
        hashes: set[str] = set()
        if not os.path.exists(path):
            return hashes

        with open(path, "r", encoding="utf-8") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                data = _safe_load_json_line(line, path, line_number)
                if data is None:
                    continue
                entry_hash = data.get("hash")
                if isinstance(entry_hash, str) and entry_hash:
                    hashes.add(entry_hash)
        return hashes

    @staticmethod
    def load_segment_entries(
        segment_meta: dict,
        *,
        apply_amendments: bool = True,
    ) -> list[MemoryEntry]:
        """Read entries from a cold segment and optionally apply an amendment sidecar.

        The amendment sidecar file is named ``<segment_id>.amendments.jsonl``
        and lives in the same directory as the segment file.  Each line in the
        sidecar is a JSON object with a ``hash`` key and any fields to overlay
        onto the matching entry.  Unknown fields in the sidecar are silently
        ignored.

        Parameters
        ----------
        segment_meta : dict
            A segment metadata dict as stored in ``manifest.json``.  Must
            contain a ``path`` key with the filesystem path to the segment
            file, and optionally a ``segment_id`` key.
        apply_amendments : bool
            When True (default), the amendment sidecar is loaded and applied.
            Pass False to read raw segment data without overlay.

        Returns
        -------
        list[MemoryEntry]
            Entries in file order, with amendment overlays applied when enabled.
        """
        path = segment_meta.get("path", "")
        entries = SegmentReader.read_segment(path)

        if not apply_amendments or not entries:
            return entries

        # Locate the sidecar: <segment_id>.amendments.jsonl next to the segment
        segment_id = segment_meta.get("segment_id", "")
        if not segment_id:
            # Derive segment_id from the filename (strip directory and extension)
            segment_id = os.path.splitext(os.path.basename(path))[0]

        sidecar_path = os.path.join(
            os.path.dirname(path),
            f"{segment_id}.amendments.jsonl",
        )
        if not os.path.exists(sidecar_path):
            return entries

        # Load amendments: hash → overlay dict
        amendments: dict[str, dict] = {}
        try:
            with open(sidecar_path, "r", encoding="utf-8") as fh:
                for line_num, raw in enumerate(fh, start=1):
                    line = raw.strip()
                    if not line:
                        continue
                    data = _safe_load_json_line(line, sidecar_path, line_num)
                    if data is None:
                        continue
                    entry_hash = data.get("hash")
                    if isinstance(entry_hash, str) and entry_hash:
                        amendments[entry_hash] = data
        except OSError as exc:
            logger.warning(
                "Could not read amendment sidecar %s: %s", sidecar_path, exc
            )
            return entries

        if not amendments:
            return entries

        # Apply overlays: only known MemoryEntry fields, never re-derive hash
        _SKIP_KEYS = {"hash", "content", "source", "line", "created"}
        for entry in entries:
            overlay = amendments.get(entry.hash)
            if overlay is None:
                continue
            for key, value in overlay.items():
                if key in _SKIP_KEYS:
                    continue
                if hasattr(entry, key):
                    try:
                        setattr(entry, key, value)
                    except (AttributeError, TypeError) as exc:
                        logger.debug(
                            "Amendment overlay skipped for field %r on %s: %s",
                            key, entry.hash, exc,
                        )

        return entries

    @staticmethod
    def append_amendment(segment_dir: "os.PathLike | str", segment_id: str, amendment: dict) -> None:
        """Append a truth-state amendment to ``<segment_id>.amendments.jsonl``.

        The sidecar file is created if it does not exist.  Each call appends
        exactly one JSON line and fsyncs before returning so the amendment is
        durable even if the process crashes immediately after.

        The amendment dict must contain at least a ``"hash"`` key identifying
        the entry to amend.  Typical keys include:

        - ``"hash"`` — entry hash (required; used as the lookup key)
        - ``"truth_state"`` — new truth state (e.g. "superseded", "retracted")
        - ``"superseded_by_id"`` — id of the replacement record (if applicable)
        - ``"updated_at"`` — ISO-8601 timestamp of the amendment

        Parameters
        ----------
        segment_dir : path-like
            Directory that contains the segment file (and the sidecar).
        segment_id : str
            Segment filename stem (e.g. ``"seg_0001_20260410T120000Z_500"``).
            The sidecar is written to ``<segment_dir>/<segment_id>.amendments.jsonl``.
        amendment : dict
            Amendment dict to append as a JSON line.
        """
        sidecar_path = os.path.join(str(segment_dir), f"{segment_id}.amendments.jsonl")
        line = json.dumps(amendment, ensure_ascii=False) + "\n"
        with open(sidecar_path, "a", encoding="utf-8") as fh:
            fh.write(line)
            fh.flush()
            os.fsync(fh.fileno())
        _fsync_directory(sidecar_path)

    @staticmethod
    def verify_checksum(path: str, expected_sha256: str) -> bool:
        """Verify the SHA-256 checksum of a segment file.

        Parameters
        ----------
        path : str
            Filesystem path to the segment file.
        expected_sha256 : str
            Hex digest string stored in the manifest at flush time.

        Returns
        -------
        bool
            ``True`` if the file exists and its checksum matches;
            ``False`` otherwise.
        """
        checksum = hashlib.sha256()
        if not os.path.exists(path):
            return False
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(65536), b""):
                checksum.update(chunk)
        return checksum.hexdigest() == expected_sha256


# ---------------------------------------------------------------------------
# HotBuffer
# ---------------------------------------------------------------------------

class HotBuffer:
    """Append-only hot log with fsync-per-write and crash-recovery semantics.

    Every :meth:`append_put` and :meth:`append_delete` acquires a
    ``FileLock``, appends one JSON envelope, fsyncs the file, and fsyncs
    the directory.  This guarantees that any op that returns successfully
    is durable even if the process crashes immediately after.

    Parameters
    ----------
    segments_dir : str
        Path to the ``segments/`` directory.  ``hot.jsonl`` and
        ``hot.rotating.jsonl`` are created here.
    """

    def __init__(self, segments_dir: str) -> None:
        self.segments_dir = segments_dir
        os.makedirs(self.segments_dir, exist_ok=True)
        self.hot_path = os.path.join(self.segments_dir, "hot.jsonl")
        self.rotating_path = os.path.join(self.segments_dir, "hot.rotating.jsonl")
        self.lock_path = self.hot_path
        if not os.path.exists(self.hot_path):
            self._create_empty_file(self.hot_path)

    def _create_empty_file(self, path: str) -> None:
        """Create an empty file at *path* with an fsync on the fd and directory."""
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        _fsync_directory(path)

    def _append_op(self, op: dict[str, Any]) -> None:
        """Append a single operation envelope to ``hot.jsonl``, fsyncing before return."""
        line = json.dumps(op, ensure_ascii=False) + "\n"
        with FileLock(self.lock_path, timeout=30.0):
            with open(self.hot_path, "a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())
            _fsync_directory(self.hot_path)

    def append_put(self, entry: MemoryEntry) -> None:
        """Append a *put* operation envelope for *entry* to the hot log.

        Parameters
        ----------
        entry : MemoryEntry
            The entry to record.  The full serialised entry is stored in the
            envelope so that crash-recovery replay can reconstruct it without
            consulting any other source.
        """
        self._append_op(
            {
                "op": "put",
                "hash": entry.hash,
                "entry": entry.to_dict(),
                "ts": _utc_now_iso(),
            }
        )

    def append_delete(self, hash: str, reason: str) -> None:
        """Append a *delete* operation envelope for *hash* to the hot log.

        Parameters
        ----------
        hash : str
            SHA-256 hash of the entry to delete.
        reason : str
            Human-readable reason for deletion (stored for audit purposes).
        """
        self._append_op(
            {
                "op": "delete",
                "hash": hash,
                "reason": reason,
                "ts": _utc_now_iso(),
            }
        )

    def read_ops(self) -> list[dict[str, Any]]:
        """Read all operation envelopes from ``hot.jsonl`` in append order.

        Returns
        -------
        list[dict[str, Any]]
            Raw op dicts in the order they were written.  Malformed lines are
            logged and skipped.  Returns an empty list if the file does not
            exist.
        """
        ops: list[dict[str, Any]] = []
        if not os.path.exists(self.hot_path):
            return ops
        with open(self.hot_path, "r", encoding="utf-8") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                data = _safe_load_json_line(line, self.hot_path, line_number)
                if data is None:
                    continue
                ops.append(data)
        return ops

    def rotate(self) -> str:
        """Rotate ``hot.jsonl`` → ``hot.rotating.jsonl`` and create a fresh empty log.

        This is the crash-safe pivot point for the flush operation.  After
        :meth:`rotate` returns, new writers append to the fresh ``hot.jsonl``
        while the flush continues to read from ``hot.rotating.jsonl``.

        Crash recovery semantics
        ~~~~~~~~~~~~~~~~~~~~~~~~
        If ``hot.rotating.jsonl`` already exists when this method is called, a
        previous rotation either completed successfully or crashed between the
        rename and the creation of the new empty ``hot.jsonl``.  Both sub-cases
        are handled:

        * ``hot.jsonl`` exists → previous rotation finished step (create new).
          Nothing to do; return the existing rotating path.
        * ``hot.jsonl`` missing → crash happened between rename and create.
          Create an empty ``hot.jsonl`` (with fsync) so writers can resume,
          then return the existing rotating path.

        Returns
        -------
        str
            Filesystem path to ``hot.rotating.jsonl``.
        """
        with FileLock(self.lock_path, timeout=30.0):
            if os.path.exists(self.rotating_path):
                # Previous rotation is in progress (or crashed mid-way).
                # Ensure hot.jsonl exists so that writers can always append.
                if not os.path.exists(self.hot_path):
                    # Crash happened between rename and create-new — heal it.
                    self._create_empty_file(self.hot_path)
                return self.rotating_path
            if not os.path.exists(self.hot_path):
                self._create_empty_file(self.hot_path)
            os.replace(self.hot_path, self.rotating_path)
            _fsync_directory(self.rotating_path)
            self._create_empty_file(self.hot_path)
        return self.rotating_path

    def replay(
        self,
        ops: list[dict[str, Any]],
    ) -> tuple[list[MemoryEntry], set[str]]:
        """Replay ops and return ``(put_entries, delete_hashes)`` as **separate collections**.

        .. warning:: **Order is not preserved between puts and deletes.**

            This method collects all puts into one list and all deletes into one
            set, discarding the interleaving order between them.  If an entry
            was put *after* a delete in the same hot window (e.g. delete → re-add
            → flush), naively applying ``delete_hashes`` first and then
            ``put_entries`` will produce the correct result.  But if the inverse
            happened (put → delete → flush, net state = deleted), applying puts
            first and then deletes will also be correct.  The problem arises only
            when a caller applies puts *after* deletes for an entry that was
            *re-added then deleted* — in that case ``replay()`` would show it as
            still present.

        **When to use ``replay()``**
            Use when you only need the net final *set of live entries* and the
            caller processes the op list separately in strict order (as
            ``SegmentStore.load()`` does) before calling this method — or when
            you can guarantee no entry was both put and deleted in the same hot
            window.

        **When NOT to use ``replay()``** — use :meth:`replay_ordered` instead
            Use :meth:`replay_ordered` whenever you need to reconstruct exact net
            state and cannot guarantee the above constraint.  For example:

            * Flush net-state computation (``SegmentStore.flush()``).
            * Any external tool that replays the hot log from scratch.
            * Tests that exercise put→delete→put or delete→put→delete cycles.

        See Also
        --------
        replay_ordered : Preserves strict log order; use for exact net-state.

        Parameters
        ----------
        ops : list[dict[str, Any]]
            Op envelopes as returned by :meth:`read_ops`.

        Returns
        -------
        tuple[list[MemoryEntry], set[str]]
            A 2-tuple of ``(put_entries, delete_hashes)``.  ``put_entries``
            contains one :class:`MemoryEntry` per valid put op; ``delete_hashes``
            contains the hash string from each valid delete op.  Invalid or
            unrecognised ops are silently skipped.
        """
        put_entries: list[MemoryEntry] = []
        delete_hashes: set[str] = set()
        for op in ops:
            op_type = op.get("op")
            if op_type == "put":
                entry_data = op.get("entry")
                if not isinstance(entry_data, dict):
                    continue
                try:
                    put_entries.append(MemoryEntry.from_dict(entry_data))
                except Exception as exc:
                    logger.warning(
                        "Skipping invalid hot put entry during replay: %s", exc
                    )
            elif op_type == "delete":
                entry_hash = op.get("hash")
                if isinstance(entry_hash, str) and entry_hash:
                    delete_hashes.add(entry_hash)
        return put_entries, delete_hashes

    def replay_ordered(self, ops: list[dict[str, Any]]) -> list[ReplayOp]:
        """Return ops in strict log order with type tags intact.

        Unlike :meth:`replay`, this method preserves the exact interleaving of
        puts and deletes so callers can reconstruct the precise net state of the
        hot window.  Each element is the raw op dict with its ``"op"`` key set
        to either ``"put"`` or ``"delete"``.

        **When to use ``replay_ordered()``**
            Use whenever strict op ordering matters:

            * Flush net-state computation — ``SegmentStore.flush()`` uses
              ``replay_ordered`` semantics via a manual iteration loop.
            * Any scenario where an entry could have been put *and* deleted (or
              vice versa) within the same hot window and the net result must be
              authoritative.
            * External tools that need to deterministically reconstruct store
              state from the hot log.

        **When ``replay()`` is sufficient**
            If you only need separate collections of puts and deletes and can
            guarantee that no hash appears in both (or the caller handles the
            ordering externally), :meth:`replay` is simpler and slightly faster.

        See Also
        --------
        replay : Returns separate (puts_list, deletes_set); loses interleaving order.

        Parameters
        ----------
        ops : list[dict[str, Any]]
            Op envelopes as returned by :meth:`read_ops`.

        Returns
        -------
        list[ReplayOp]
            Filtered list of valid op dicts in log order.  Invalid ops (missing
            ``"entry"`` on a put, non-string or empty ``"hash"`` on a delete)
            and unrecognised op types are silently skipped.

        Example
        -------
        ::

            entry_map: dict[str, MemoryEntry] = {}
            for op in hot_buffer.replay_ordered(hot_buffer.read_ops()):
                if op["op"] == "put":
                    try:
                        e = MemoryEntry.from_dict(op["entry"])
                        entry_map[e.hash] = e
                    except Exception:
                        pass
                elif op["op"] == "delete":
                    entry_map.pop(op.get("hash", ""), None)
        """
        result: list[ReplayOp] = []
        for op in ops:
            op_type = op.get("op")
            if op_type == "put":
                if not isinstance(op.get("entry"), dict):
                    continue
                result.append(op)
            elif op_type == "delete":
                if isinstance(op.get("hash"), str) and op["hash"]:
                    result.append(op)
        return result

    def get_stats(self) -> dict[str, int]:
        """Return advisory counts for the hot buffer.

        Returns
        -------
        dict[str, int]
            ``{"put_count": int, "delete_count": int, "size_bytes": int}``
        """
        put_count = 0
        delete_count = 0
        for op in self.read_ops():
            if op.get("op") == "put":
                put_count += 1
            elif op.get("op") == "delete":
                delete_count += 1
        size_bytes = (
            os.path.getsize(self.hot_path) if os.path.exists(self.hot_path) else 0
        )
        return {
            "put_count": put_count,
            "delete_count": delete_count,
            "size_bytes": size_bytes,
        }

    def cleanup_rotating(self) -> None:
        """Delete ``hot.rotating.jsonl`` if it exists, then fsync the directory."""
        if os.path.exists(self.rotating_path):
            os.unlink(self.rotating_path)
            _fsync_directory(self.rotating_path)

    def has_rotating(self) -> bool:
        """Return ``True`` if ``hot.rotating.jsonl`` exists (crash-recovery signal)."""
        return os.path.exists(self.rotating_path)
