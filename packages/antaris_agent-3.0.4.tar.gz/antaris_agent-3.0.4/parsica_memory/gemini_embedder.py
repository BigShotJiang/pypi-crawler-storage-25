"""
parsica_memory.gemini_embedder — Gemini embedding provider for v2.9.0

Provides a callable that embeds text via the Gemini Embeddings API
(gemini-embedding-001 by default, 3072 dimensions).

Zero-dependency: uses only stdlib urllib. No google-cloud packages required.

Usage::

    from parsica_memory.gemini_embedder import make_gemini_embedder
    embed = make_gemini_embedder(api_key="YOUR_KEY")
    mem.set_embedding_fn(embed)

The embedder is also wired automatically when GEMINI_EMBEDDING_API_KEY
is available via macOS Keychain (retrieved at startup by BotMemory).
"""
from __future__ import annotations

import json
import subprocess
import time
import urllib.error
import urllib.request
from typing import List, Optional


_CIRCUIT_BREAKER_FAILURES = 3
_CIRCUIT_BREAKER_DISABLE_S = 5 * 60

# Model priority: prefer 001 (best pure-text MTEB), fall back gracefully
_DEFAULT_MODEL = "gemini-embedding-001"
_FALLBACK_MODEL = "gemini-embedding-2-preview"
_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
_MAX_TEXT_CHARS = 2048
_RETRY_ATTEMPTS = 3
_RETRY_DELAY_S = 1.5


def _get_keychain_key(service: str = "GEMINI_EMBEDDING_API_KEY",
                      account: str = "antaris-analytics") -> Optional[str]:
    """Retrieve the Gemini embedding API key from macOS Keychain."""
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", account, "-s", service, "-w"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except Exception:
        pass
    return None


def make_gemini_embedder(
    api_key: Optional[str] = None,
    model: str = _DEFAULT_MODEL,
    use_keychain: bool = True,
) -> Optional[callable]:
    """Build a Gemini embedding callable, or return None if no key available.

    Parameters
    ----------
    api_key : str, optional
        Explicit API key. If not provided and use_keychain=True, attempts
        to read from macOS Keychain.
    model : str
        Embedding model name (default: gemini-embedding-001).
    use_keychain : bool
        If True and no api_key provided, try macOS Keychain.

    Returns
    -------
    callable or None
        A callable ``(text: str) -> list[float]``, or None if no key found.
    """
    key = api_key
    if not key and use_keychain:
        key = _get_keychain_key()
    if not key:
        return None

    _model = model
    _key = key
    _cache: dict = {}
    _consecutive_failures = 0
    _disabled_until = 0.0
    import threading as _threading
    _breaker_lock = _threading.Lock()

    def embed(text: str) -> Optional[List[float]]:
        nonlocal _consecutive_failures, _disabled_until
        now = time.time()
        with _breaker_lock:
            if _disabled_until > now:
                return None
            if _disabled_until > 0 and now >= _disabled_until:
                # Cooldown expired — reset breaker
                _consecutive_failures = 0
                _disabled_until = 0.0

        cache_key = text[:200]
        if cache_key in _cache:
            return _cache[cache_key]

        truncated = text[:_MAX_TEXT_CHARS]
        url = f"{_BASE_URL}/{_model}:embedContent?key={_key}"
        payload = json.dumps({
            "model": f"models/{_model}",
            "content": {"parts": [{"text": truncated}]},
        }).encode()
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/json"},
        )

        last_err: Optional[Exception] = None
        for attempt in range(_RETRY_ATTEMPTS):
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read())
                    vector = data["embedding"]["values"]
                    with _breaker_lock:
                        _consecutive_failures = 0
                    # Bound cache to 2000 entries
                    if len(_cache) >= 2000:
                        del _cache[next(iter(_cache))]
                    _cache[cache_key] = vector
                    return vector
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    raise
                last_err = e
                with _breaker_lock:
                    _consecutive_failures += 1
                    if _consecutive_failures >= _CIRCUIT_BREAKER_FAILURES:
                        _disabled_until = time.time() + _CIRCUIT_BREAKER_DISABLE_S
                        print("[embedder] circuit breaker tripped, disabling for 5m")
                        return None
                if attempt < _RETRY_ATTEMPTS - 1:
                    time.sleep(_RETRY_DELAY_S * (attempt + 1))
            except Exception as e:
                last_err = e
                with _breaker_lock:
                    _consecutive_failures += 1
                    if _consecutive_failures >= _CIRCUIT_BREAKER_FAILURES:
                        _disabled_until = time.time() + _CIRCUIT_BREAKER_DISABLE_S
                        print("[embedder] circuit breaker tripped, disabling for 5m")
                        return None
                if attempt < _RETRY_ATTEMPTS - 1:
                    time.sleep(_RETRY_DELAY_S)

        return None

    return embed
