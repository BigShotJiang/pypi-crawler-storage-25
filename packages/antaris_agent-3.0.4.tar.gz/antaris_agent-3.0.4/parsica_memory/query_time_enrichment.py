from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import asdict, dataclass, field, replace as dataclass_replace
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import List

from typing import Optional

from .contracts import RecordKind, RetrievalTrace, SideEffectMode

logger = logging.getLogger(__name__)

# v3.0.4 (P1-4 Eye fix): separate logger for machine-consumable metrics.
# Prod aggregators can subscribe to this logger at DEBUG level to capture
# pass-2 outcomes even when trace persistence is disabled (PURE_READ).
# To capture metrics in prod:
# logging.getLogger("parsica_memory.qte_metrics").addHandler(your_handler)
# logging.getLogger("parsica_memory.qte_metrics").setLevel(logging.DEBUG)
_QTE_METRICS_LOGGER = logging.getLogger("parsica_memory.qte_metrics")
_QTE_METRICS_LOGGER.propagate = False


class _Pass2Skipped(BaseException):
    """Internal BaseException sentinel for intentional pass-2 budget skips.

    This is not an operational failure. It is raised only to short-circuit the
    pass-2 try/except ladder without risking accidental capture by broad
    ``except Exception`` handlers elsewhere.
    """
    pass


class RetrievalMode(str, Enum):
    RECENT = "recent"
    SEMANTIC = "semantic"
    PRECISION = "precision"
    EVIDENCE = "evidence"
    DEEP = "deep"


# Public modes: auto | precision | evidence | deep
# Legacy mapping: recent → precision, semantic → evidence
_LEGACY_MODE_MAP: dict = {
    "recent": "precision",
    "semantic": "evidence",
}


def _map_legacy_mode(mode: str) -> str:
    """Map legacy mode names to their canonical equivalents."""
    return _LEGACY_MODE_MAP.get(mode.lower(), mode.lower())


@dataclass(init=False)
class QueryFingerprint:
    is_recentness_query: bool = False
    is_precision_query: bool = False
    is_evidence_query: bool = False
    is_preference_query: bool = False
    is_procedure_query: bool = False
    is_fact_lookup: bool = False
    mentions_time_window: bool = False
    mentions_correction_or_truth: bool = False
    needs_cross_session: bool = False
    query_length_tokens: int = 0

    def __init__(self, query_or_bool=None, **kwargs):
        """Support both positional string init (for tests) and keyword-only init.

        Usage:
          QueryFingerprint("What is Jake's name?")  — fingerprints the string
          QueryFingerprint(is_recentness_query=True) — keyword fields
          QueryFingerprint()                         — all defaults
        """
        # Set defaults for all declared fields
        self.is_recentness_query = False
        self.is_precision_query = False
        self.is_evidence_query = False
        self.is_preference_query = False
        self.is_procedure_query = False
        self.is_fact_lookup = False
        self.mentions_time_window = False
        self.mentions_correction_or_truth = False
        self.needs_cross_session = False
        self.query_length_tokens = 0

        if isinstance(query_or_bool, str):
            # Called as QueryFingerprint("some query text") — fingerprint the string inline
            query = query_or_bool.strip()
            q = query.lower()
            self.query_length_tokens = len(query.split())
            has_quotes = '"' in query or "'" in query
            has_filename = bool(re.search(r"\b[\w.-]+\.(py|md|json|yaml|yml|toml|ini|cfg|txt)\b", q))
            has_id = bool(re.search(r"\b[a-f0-9]{8,}\b", q)) or bool(re.search(r"\bid[:#-]?\s*[a-z0-9_-]+\b", q))
            has_exact = any(token in q for token in ("exact", "literal", "verbatim"))
            self.is_preference_query = any(token in q for token in _PREFERENCE_PATTERNS)
            self.is_procedure_query = any(token in q for token in _PROCEDURE_PATTERNS)
            self.mentions_correction_or_truth = any(token in q for token in _CORRECTION_PATTERNS)
            self.is_evidence_query = any(token in q for token in _EVIDENCE_PATTERNS)
            self.is_recentness_query = any(token in q for token in _RECENTNESS_PATTERNS)
            self.mentions_time_window = any(token in q for token in _TIME_WINDOW_PATTERNS)
            self.is_fact_lookup = bool(re.search(r"\bwhat is\b|\bwho is\b|\bwhere is\b|\bwhen did\b", q))
            self.needs_cross_session = any(token in q for token in ("last time", "previously", "across sessions", "before"))
            self.is_precision_query = has_quotes or has_filename or has_id or has_exact
        elif query_or_bool is not None:
            # Legacy positional bool (backward compat)
            self.is_recentness_query = bool(query_or_bool)

        # Apply any keyword overrides
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, k, v)


@dataclass
class RetrievalPlan:
    mode: RetrievalMode
    prefer_child_records: bool = False
    prefer_parent_records: bool = False
    prefer_record_kinds: list = field(default_factory=list)
    truth_state_filter: str = "accepted_only"
    allow_refinement: bool = True
    max_refinement_steps: int = 2
    refinement_budget_ms: int = 250
    persist_diagnostics: bool = False
    persist_trace: bool = False


class RetrievalTraceSink:
    """Handles optional trace persistence with rotation."""

    MAX_BYTES = 10 * 1024 * 1024
    RETENTION_DAYS = 7

    def __init__(self, traces_dir):
        self.traces_dir = Path(traces_dir)
        self.traces_dir.mkdir(parents=True, exist_ok=True)

    def _date_prefix(self) -> str:
        return datetime.now(timezone.utc).date().isoformat()

    def _current_path(self) -> Path:
        prefix = f"trace-{self._date_prefix()}"
        existing = sorted(self.traces_dir.glob(f"{prefix}.*.jsonl"))
        if existing:
            candidate = existing[-1]
            if candidate.stat().st_size < self.MAX_BYTES:
                return candidate
        next_index = len(existing) + 1
        return self.traces_dir / f"{prefix}.{next_index:04d}.jsonl"

    def write(self, trace) -> None:
        self.prune()
        path = self._current_path()
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace.to_dict(), ensure_ascii=False) + "\n")

    def prune(self) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=self.RETENTION_DAYS)
        for path in self.traces_dir.glob("trace-*.jsonl"):
            try:
                stamp = path.name.split(".")[0].replace("trace-", "")
                day = datetime.fromisoformat(stamp).replace(tzinfo=timezone.utc)
                if day < cutoff:
                    path.unlink(missing_ok=True)
            except Exception:
                continue


_RECENTNESS_PATTERNS = (
    "recent",
    "just",
    "earlier today",
    "what was i working on",
    "lately",
    "most recently",
    "last thing",
)
_EVIDENCE_PATTERNS = (
    "why",
    "evidence",
    "show me",
    "where did",
    "based on what",
    "proof",
)
_PROCEDURE_PATTERNS = ("how to", "steps to", "to deploy", "procedure")
_PREFERENCE_PATTERNS = ("prefer", "like", "dislike", "favorite", "want")
_CORRECTION_PATTERNS = ("mistake", "wrong", "fix", "correction", "not to do")
_TIME_WINDOW_PATTERNS = ("today", "yesterday", "this week", "last week", "recently", "lately")


def fingerprint_query(request) -> QueryFingerprint:
    query = (getattr(request, "query", "") or "").strip()
    q = query.lower()
    has_quotes = '"' in query or "'" in query
    has_filename = bool(re.search(r"\b[\w.-]+\.(py|md|json|yaml|yml|toml|ini|cfg|txt)\b", q))
    has_id = bool(re.search(r"\b[a-f0-9]{8,}\b", q)) or bool(re.search(r"\bid[:#-]?\s*[a-z0-9_-]+\b", q))
    has_exact = any(token in q for token in ("exact", "literal", "verbatim"))
    preference = any(token in q for token in _PREFERENCE_PATTERNS)
    procedure = any(token in q for token in _PROCEDURE_PATTERNS)
    correction = any(token in q for token in _CORRECTION_PATTERNS)
    evidence = any(token in q for token in _EVIDENCE_PATTERNS)
    recent = any(token in q for token in _RECENTNESS_PATTERNS)
    time_window = any(token in q for token in _TIME_WINDOW_PATTERNS)
    fact_lookup = bool(re.search(r"\bwhat is\b|\bwho is\b|\bwhere is\b|\bwhen did\b", q))
    cross_session = any(token in q for token in ("last time", "previously", "across sessions", "before"))
    return QueryFingerprint(
        is_recentness_query=recent,
        is_precision_query=has_quotes or has_filename or has_id or has_exact,
        is_evidence_query=evidence,
        is_preference_query=preference,
        is_procedure_query=procedure,
        is_fact_lookup=fact_lookup,
        mentions_time_window=time_window,
        mentions_correction_or_truth=correction,
        needs_cross_session=cross_session,
        query_length_tokens=len(query.split()),
    )


def choose_mode(request_or_fp, fp: QueryFingerprint = None) -> RetrievalMode:
    """Choose retrieval mode based on request and fingerprint.

    Supports two call signatures:
      choose_mode(request, fp)          — production path (request object + fingerprint)
      choose_mode(fp)                   — convenience path for tests (fingerprint only)

    Public modes: auto | precision | evidence | deep
    Legacy modes: recent → precision, semantic → evidence
    """
    # Handle single-argument form: choose_mode(fp)
    if fp is None:
        if isinstance(request_or_fp, QueryFingerprint):
            fp = request_or_fp
            request_or_fp = None
        else:
            raise TypeError("choose_mode requires a QueryFingerprint argument")

    request = request_or_fp

    # Explicit mode override (user-requested mode)
    if request is not None:
        requested = (getattr(request, "query_mode", "auto") or "auto").lower()
        if requested != "auto":
            # Apply legacy mapping before constructing enum
            canonical = _map_legacy_mode(requested)
            return RetrievalMode(canonical)

    # --- Heuristic mode routing ---
    # 1. Recentness signals stay as RECENT (legacy; routes to precision internally)
    if fp.is_recentness_query:
        return RetrievalMode.RECENT

    # 2. Short factual queries (who/what/when + entity, ≤6 tokens) → PRECISION
    if fp.query_length_tokens <= 6 and fp.is_fact_lookup:
        return RetrievalMode.PRECISION

    # 3. Complex / multi-faceted / ≥12 tokens → DEEP
    if fp.query_length_tokens >= 12:
        return RetrievalMode.DEEP

    # 4. Evidence signals → EVIDENCE
    if fp.is_evidence_query:
        return RetrievalMode.EVIDENCE

    # 5. Precision signals
    if fp.is_precision_query:
        return RetrievalMode.PRECISION
    if fp.is_procedure_query or fp.is_preference_query or fp.mentions_correction_or_truth:
        return RetrievalMode.PRECISION

    # 6. Default fallback → EVIDENCE
    return RetrievalMode.EVIDENCE


def build_plan(mode: RetrievalMode, request, fp: QueryFingerprint) -> RetrievalPlan:
    effective_mode = getattr(request, "side_effect_mode", None)
    is_pure = effective_mode == SideEffectMode.PURE_READ
    plan = RetrievalPlan(
        mode=mode,
        prefer_child_records=bool(getattr(request, "prefer_child_records", False)),
        prefer_parent_records=bool(getattr(request, "prefer_parent_records", False)),
        allow_refinement=bool(getattr(request, "allow_refinement", True)),
        max_refinement_steps=int(getattr(request, "max_refinement_steps", 2)),
        refinement_budget_ms=int(getattr(request, "max_qte_time_ms", 250)),
        persist_diagnostics=bool(getattr(request, "persist_diagnostics", False)),
        persist_trace=bool(getattr(request, "persist_trace", False)),
    )
    if mode == RetrievalMode.RECENT:
        plan.prefer_parent_records = True
    elif mode == RetrievalMode.EVIDENCE:
        plan.truth_state_filter = "include_superseded"
        plan.prefer_record_kinds = [RecordKind.FACT.value, RecordKind.MISTAKE.value, RecordKind.PROCEDURE.value]
    elif mode == RetrievalMode.PRECISION:
        plan.prefer_child_records = plan.prefer_child_records or fp.is_preference_query or fp.is_procedure_query
        if fp.is_preference_query:
            plan.prefer_record_kinds = [RecordKind.PREFERENCE.value, RecordKind.FACT.value]
        elif fp.is_procedure_query:
            plan.prefer_record_kinds = [RecordKind.PROCEDURE.value, RecordKind.FACT.value]
        elif fp.mentions_correction_or_truth:
            plan.prefer_record_kinds = [RecordKind.MISTAKE.value, RecordKind.FACT.value]
    elif mode == RetrievalMode.DEEP:
        plan.truth_state_filter = "include_all"
        plan.allow_refinement = True
    if is_pure:
        plan.persist_trace = False
        plan.persist_diagnostics = False
    return plan


def _score_item(item, plan: RetrievalPlan):
    score = float(getattr(item, "score", 0.0) or 0.0)
    kind = getattr(getattr(item, "record_kind", None), "value", getattr(item, "record_kind", ""))
    if plan.prefer_record_kinds and kind in plan.prefer_record_kinds:
        score += max(0.25, 0.3 - (0.02 * plan.prefer_record_kinds.index(kind)))
    if plan.prefer_child_records and kind in {
        RecordKind.FACT.value,
        RecordKind.MISTAKE.value,
        RecordKind.PREFERENCE.value,
        RecordKind.PROCEDURE.value,
    }:
        score += 0.2
    if plan.prefer_parent_records and kind == RecordKind.TURN.value:
        score += 0.15
    return score


def _extract_gap_terms(results, query_tokens: set, max_terms: int = 4) -> list:
    """Extract up to max_terms novel content terms from top results not in the original query."""
    stopwords = frozenset({
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "i", "you", "he", "she",
        "it", "we", "they", "what", "which", "who", "when", "where", "how",
        "in", "on", "at", "by", "for", "with", "about", "to", "of", "and",
        "or", "but", "not", "no", "so", "as", "if", "then", "than", "that",
    })
    term_counts: dict = {}
    for item in results:
        content = (getattr(item, "content", "") or "").lower()
        for word in re.findall(r"[a-z]{3,}", content):
            if word not in query_tokens and word not in stopwords:
                term_counts[word] = term_counts.get(word, 0) + 1
    # Sort by frequency, take top N
    sorted_terms = sorted(term_counts, key=lambda w: term_counts[w], reverse=True)
    return sorted_terms[:max_terms]


def _set_qte_path(trace: RetrievalTrace, path: str) -> None:
    trace.qte_features["qte_path"] = path
    try:
        trace.qte_path = path
    except Exception:
        pass


def run_qte(memory_system, request):
    from .retrieval import _execute_retrieval

    t0 = time.monotonic()
    fp = fingerprint_query(request)
    mode = choose_mode(request, fp)
    plan = build_plan(mode, request, fp)

    limit = max(0, getattr(request, "limit", 10))

    if mode == RetrievalMode.DEEP:
        # Bounded two-pass DEEP retrieval (no unbounded recursion)
        # Pass 1: normal search
        pass1_t0 = time.monotonic()
        items1, trace = _execute_retrieval(memory_system, request, persist_trace=False)
        pass1_time_ms = (time.monotonic() - pass1_t0) * 1000
        top8 = items1[:8]

        # Extract gap terms from top 8 results
        query_tokens = set((getattr(request, "query", "") or "").lower().split())
        gap_terms = _extract_gap_terms(top8, query_tokens, max_terms=4)

        items2 = []
        pass2_time_ms = 0.0
        pass2_budget_ms = None
        # v3.0.4 (F-DEEP-SWALLOW): track pass-2 error state across all branches
        # so the trace can always report whether pass-2 ran and how it ended.
        # v3.0.4 (P1-6): error is structured {exc_type: str, message: str}
        # for machine-consumable parsing, not a formatted string.
        _qte_pass2_error: Optional[dict] = None
        _qte_pass2_ran: bool = False
        # v3.0.4 (P1-7 Eye fix): count records surfaced by pass-2 that pass-1
        # missed. Proves F-QTE-AUTO's value.
        _qte_pass2_new_items: int = 0
        if gap_terms:
            _qte_pass2_ran = True
            # Pass 2: expanded query using a cloned request with the expanded query
            expanded_query = (getattr(request, "query", "") or "") + " " + " ".join(gap_terms)
            try:
                # v2.9.9: use dataclasses.replace() instead of dir()-based proxy
                req2 = dataclass_replace(
                    request,
                    query=expanded_query,
                    side_effect_mode=SideEffectMode.PURE_READ,
                )
                # v3.0.4 (P1-5 Eye fix): enforce max_qte_time_ms as a soft
                # wall-clock budget on pass-2. Before this, auto-routing into
                # DEEP could burn arbitrary time in a second retrieval pass;
                # the contract field existed but was ignored. We check at
                # entry and skip pass-2 if we've already exceeded budget.
                budget_ms = getattr(request, "max_qte_time_ms", 250) or 250
                elapsed_ms = (time.monotonic() - t0) * 1000
                if elapsed_ms >= budget_ms:
                    # Budget exceeded before pass-2 even starts; skip it but
                    # record the reason so it's observable.
                    _qte_pass2_error = {
                        "exc_type": "BudgetExceeded",
                        "message": f"pass-1 already consumed {elapsed_ms:.1f}ms of {budget_ms}ms budget",
                    }
                    items2 = []
                    raise _Pass2Skipped
                remaining_budget_ms = max(0.0, float(budget_ms) - elapsed_ms)
                pass2_budget_ms = remaining_budget_ms
                pass2_t0 = time.monotonic()
                items2_raw, _ = _execute_retrieval(
                    memory_system,
                    req2,
                    persist_trace=False,
                    budget_ms=remaining_budget_ms,
                )
                pass2_time_ms = (time.monotonic() - pass2_t0) * 1000
                items2 = list(items2_raw)
            except _Pass2Skipped:
                # Handled above — just proceed to merge with empty items2.
                pass
            except (SystemExit, KeyboardInterrupt, GeneratorExit, asyncio.CancelledError) as exc:
                # v3.0.4 (F-DEEP-SWALLOW, P0-3 Eye fix): SystemExit and
                # KeyboardInterrupt are BaseException subclasses that we MUST
                # NOT swallow — process termination and user-interrupt signals
                # have to propagate. But we log first so the incident is
                # observable, then re-raise.
                logger.warning(
                    "qte_deep_pass2_aborted: %s during pass-2 (query=%r, gap_terms=%r); re-raising",
                    type(exc).__name__, getattr(request, "query", ""), gap_terms,
                )
                raise
            except BaseException as exc:
                # v3.0.4 (F-DEEP-SWALLOW): Pass-2 is best-effort, but failures
                # must be OBSERVABLE. Pre-v3.0.4 this block silently produced
                # items2=[], hiding every pass-2 failure behind "graceful
                # degradation". We still fall back (don't fail the whole query)
                # but we log, attach the structured error to the trace, and
                # set a diagnostic flag so metrics can count pass-2 failures.
                #
                # v3.0.4 (P1-3 Eye fix): log at INFO (routine failures at
                # prod scale shouldn't drown WARN with stacktraces); a WARN
                # counter is emitted separately via qte_metrics below, which
                # is rate-limit-friendly and durable under PURE_READ paths.
                # (P1-6) error is structured {exc_type, message} for machine
                # parsing instead of a formatted string.
                logger.info(
                    "qte_deep_pass2_failed: %s: %s (query=%r, gap_terms=%r)",
                    type(exc).__name__, exc, getattr(request, "query", ""), gap_terms,
                    exc_info=logger.isEnabledFor(logging.DEBUG),
                )
                items2 = []
                _qte_pass2_error = {
                    "exc_type": type(exc).__name__,
                    "message": str(exc),
                }

        # Merge pass1 + pass2, dedupe by record_id.
        # v3.0.4 (P1-7): count pass-2 additions (records NOT already in pass-1).
        seen = set()
        merged = []
        for item in list(items1):
            rid = getattr(item, "record_id", id(item))
            if rid not in seen:
                seen.add(rid)
                merged.append(item)
        for item in list(items2):
            rid = getattr(item, "record_id", id(item))
            if rid not in seen:
                seen.add(rid)
                merged.append(item)
                _qte_pass2_new_items += 1

        items = merged
    else:
        pass1_t0 = time.monotonic()
        items, trace = _execute_retrieval(memory_system, request, persist_trace=False)
        pass1_time_ms = (time.monotonic() - pass1_t0) * 1000
        pass2_time_ms = 0.0
        pass2_budget_ms = None

    ranked = sorted(items, key=lambda item: _score_item(item, plan), reverse=True)
    limited = ranked[:limit]

    trace.qte_mode = mode.value
    trace.qte_fingerprint = asdict(fp)
    trace.qte_features = {
        "prefer_child_records": plan.prefer_child_records,
        "prefer_parent_records": plan.prefer_parent_records,
        "prefer_record_kinds": list(plan.prefer_record_kinds),
        "truth_state_filter": plan.truth_state_filter,
        "allow_refinement": plan.allow_refinement,
        "max_refinement_steps": plan.max_refinement_steps,
        "refinement_budget_ms": plan.refinement_budget_ms,
        "pass1_time_ms": round(pass1_time_ms, 2),
        "pass2_time_ms": round(pass2_time_ms, 2),
        "pass2_budget_ms": round(pass2_budget_ms, 2) if pass2_budget_ms is not None else None,
    }
    _set_qte_path(trace, "qte")
    trace.qte_refinement_steps = []
    trace.result_ids = [item.record_id for item in limited]
    trace.total_time_ms = (time.monotonic() - t0) * 1000
    # v3.0.4 (F-DEEP-SWALLOW): record pass-2 execution state on the trace so
    # failures are observable in retrieval_traces JSONL.  Only populated for
    # DEEP mode; other modes leave these unset.
    # (P1-7 Eye fix) pass2_new_items counts records that pass-2 surfaced and
    # pass-1 missed — this is the metric that proves F-QTE-AUTO's value.
    if mode == RetrievalMode.DEEP:
        trace.qte_features["pass2_ran"] = _qte_pass2_ran
        trace.qte_features["pass2_error"] = _qte_pass2_error
        trace.qte_features["pass2_new_items"] = _qte_pass2_new_items

    # v3.0.4 (P1-4 Eye fix): emit a metric counter regardless of PURE_READ
    # trace-persistence state so dominant caller modes (CONTEXT_PACK, HANDOFF,
    # ROUTING, AUDIT, BACKGROUND) still surface pass-2 failures durably.
    # Prints to stderr via the logger at DEBUG so prod aggregators can capture
    # it without spamming INFO; metric sinks can subscribe to this logger.
    if mode == RetrievalMode.DEEP and _qte_pass2_ran:
        _QTE_METRICS_LOGGER.debug(
            "qte.pass2 ran=1 ok=%d err=%d new=%d",
            1 if _qte_pass2_error is None else 0,
            0 if _qte_pass2_error is None else 1,
            _qte_pass2_new_items,
        )

    effective_mode = getattr(request, "side_effect_mode", None)
    if plan.persist_trace and effective_mode != SideEffectMode.PURE_READ:
        sink = RetrievalTraceSink(Path(memory_system.workspace) / "_meta" / "retrieval_traces")
        sink.write(trace)

    return limited
