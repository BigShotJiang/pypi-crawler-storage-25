from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
import uuid

from .entry import MemoryEntry

CURRENT_ENRICHER_VERSION = "det=v1"


def build_enricher_version(llm_enricher=None) -> str:
    base = "det=v1;class=v2"
    if llm_enricher is None:
        return base + ";llm=none;search_queries=none"
    return base + ";llm_prompt=v5;search_queries=v3"


@dataclass
class EnrichmentResult:
    parent_updated: bool
    children_created: int
    children_skipped: int
    children_superseded: int
    search_queries_added: int
    llm_used: bool
    mode: str
    enricher_version: str
    errors: list = field(default_factory=list)


class KnowledgeEnricher:
    def __init__(self, llm_enricher: Optional[Any] = None) -> None:
        self.llm_enricher = llm_enricher

    def _existing_child_keys(self, parent_id: str, enricher_version: str, memory_system) -> set[tuple[str, str]]:
        return {
            (getattr(m, "record_kind", "") or getattr(m, "memory_type", ""), getattr(m, "enricher_version", ""))
            for m in memory_system.memories
            if getattr(m, "parent_id", "") == parent_id and getattr(m, "enricher_version", "") == enricher_version
        }

    def _materialize_child(self, child: MemoryEntry, memory_system) -> None:
        memory_system.memories.append(child)
        memory_system._hashes.add(child.hash)
        memory_system._content_norms.add((child.content or "").strip().lower())
        if child.memory_type == "fact":
            memory_system._index_fact(child)
        if child.record_id:
            memory_system._record_by_id[child.record_id] = child
        memory_system.search_engine.mark_dirty()
        if memory_system.use_indexing and memory_system.index_manager:
            memory_system.index_manager.add_memory(child)
        if memory_system._using_segments:
            memory_system._debug_assert_no_dual_write(child.hash, "segment")
            memory_system._segment_store.append_put(child)
        else:
            memory_system._debug_assert_no_dual_write(child.hash, "wal")
            memory_system._wal.append(child.to_dict())
        if memory_system._read_cache is not None:
            memory_system._read_cache.invalidate()

    def enrich(self, record_id: str, target_version: str, memory_system) -> EnrichmentResult:
        parent = memory_system.get_record_by_id(record_id)
        mode = "llm_augmented" if self.llm_enricher is not None else "deterministic_only"
        result = EnrichmentResult(
            parent_updated=False,
            children_created=0,
            children_skipped=0,
            children_superseded=0,
            search_queries_added=0,
            llm_used=self.llm_enricher is not None,
            mode=mode,
            enricher_version=target_version,
            errors=[],
        )
        if parent is None:
            result.errors.append("record not found")
            return result

        enrichment_run_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        existing_keys = self._existing_child_keys(record_id, target_version, memory_system)

        # v2.8.1 fix: use persist=False to get candidate entries WITHOUT writing
        # to storage. The old approach wrote then manually undid WAL writes,
        # which caused duplicate WAL records and lost metadata on reload.
        candidate_entries = memory_system._decompose_turn(
            content=getattr(parent, "content", "") or "",
            turn_envelope_id=getattr(parent, "envelope_id", "") or "",
            session_id=getattr(parent, "session_id", "") or "",
            user_id="",
            agent_id=getattr(parent, "agent_id", "") or "",
            channel_id=getattr(parent, "source_channel", "") or "",
            inherited_tags=list(getattr(parent, "tags", []) or []),
            persist=False,
        )

        children_to_create: list[MemoryEntry] = []
        created_by_kind = {
            (getattr(m, "record_kind", "") or getattr(m, "memory_type", "")): m
            for m in candidate_entries
        }
        for kind in ("mistake", "preference", "fact", "procedure"):
            if (kind, target_version) in existing_keys:
                result.children_skipped += 1
                continue
            child = created_by_kind.get(kind)
            if child is None:
                result.children_skipped += 1
                continue
            child.record_id = child.record_id or str(uuid.uuid4())
            child.record_kind = kind
            child.memory_type = kind
            if kind == "fact" and getattr(child, "confidence", 0.0) < 0.8:
                child.confidence = 0.8
            memory_system._stamp_parent_links(child, parent)
            child.cross_session_eligible = memory_system._default_child_cross_session_eligibility(
                kind, getattr(child, "confidence", 0.0)
            )
            child.enricher_version = target_version
            child.enrichment_run_id = enrichment_run_id
            child.truth_state = "accepted"
            child.updated_at = now
            children_to_create.append(child)

        if self.llm_enricher is not None:
            try:
                enrichment = self.llm_enricher(getattr(parent, "content", "") or "")
                if enrichment and isinstance(enrichment, dict):
                    if enrichment.get("search_queries"):
                        existing_queries = list(getattr(parent, "search_queries", []) or [])
                        new_queries = [str(q) for q in enrichment.get("search_queries", []) if str(q) not in existing_queries]
                        if new_queries:
                            parent.search_queries = existing_queries + new_queries
                            result.search_queries_added = len(new_queries)
                    if enrichment.get("summary"):
                        parent.enriched_summary = str(enrichment.get("summary"))
                    if enrichment.get("keywords"):
                        parent.search_keywords = [str(k).lower() for k in enrichment.get("keywords", [])]
                    if enrichment.get("tags"):
                        parent.tags = sorted(set(list(getattr(parent, "tags", []) or [])) | {str(t).lower() for t in enrichment.get("tags", [])})
            except Exception as exc:
                result.errors.append(str(exc))

        for child in children_to_create:
            self._materialize_child(child, memory_system)
            result.children_created += 1

        prior_children = [
            m for m in memory_system.memories
            if getattr(m, "parent_id", "") == record_id
            and getattr(m, "enricher_version", "")
            and getattr(m, "enricher_version", "") != target_version
            and getattr(m, "truth_state", "accepted") == "accepted"
        ]
        for old_child in prior_children:
            old_child.truth_state = "superseded"
            old_child.updated_at = now
            result.children_superseded += 1
            # P0-2 fix: durable writeback for superseded old children
            # Use update_truth_state() which handles both hot and cold segment paths
            try:
                memory_system.update_truth_state(
                    old_child.record_id,
                    "superseded",
                )
            except Exception:
                pass  # in-memory mutation already done; persistence is best-effort

        parent.last_enricher_version = target_version
        parent.last_enrichment_run_id = enrichment_run_id
        parent.last_hydrated_at = now
        parent.last_hydration_mode = mode
        parent.updated_at = now
        result.parent_updated = True

        # v2.9.0: Generate and store embeddings via background worker
        # Uses the embedding_fn already set on memory_system (set_embedding_fn).
        # Pure best-effort — embedding failure never blocks hydration.
        _embed_fn = getattr(memory_system, "_embedding_fn", None)
        if _embed_fn is not None:
            # Embed the parent turn
            try:
                if not getattr(parent, "embedding", None):
                    parent.embedding = _embed_fn(parent.content[:2048])
                    parent.embedding_pending = False
            except Exception:
                parent.embedding_pending = True  # mark for backfill
            # Embed each new child record
            for child in children_to_create:
                try:
                    if not getattr(child, "embedding", None):
                        child.embedding = _embed_fn(child.content[:2048])
                        child.embedding_pending = False
                except Exception:
                    child.embedding_pending = True  # mark for backfill

        if memory_system._using_segments:
            memory_system._segment_store.append_put(parent)
        else:
            # v2.8.1 fix: WAL.append() deduplicates by hash so an updated
            # parent (same hash, new metadata) is silently dropped on replay.
            # flush() writes the full current memory state and survives reload.
            try:
                memory_system.flush()
            except Exception:
                memory_system._wal.append(parent.to_dict())  # fallback
        if memory_system._read_cache is not None:
            memory_system._read_cache.invalidate()

        return result
