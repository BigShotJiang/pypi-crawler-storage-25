"""
parsica_memory.context_assembler — Deterministic, token-budgeted context assembly.

Replaces scattered pre-reply stuffing with one deterministic assembly layer.
Same inputs + same budget = same AssembledContext (proven by assembly_hash).

Source priority order (strict):
  1. Current session state + active tasks (body-local, freshest)
  2. Explicit handoffs (handoff_visible scope)
  3. Identity-durable typed knowledge (facts, preferences, procedures, mistakes)
  4. Selected packs
  5. Evidence anchors / raw fallback

Token overflow: underflowing sources donate unused budget to next source.

v2.9.3
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, List, Optional

from parsica_memory.contracts import surfaceable as _surfaceable_shared  # v2.9.9
from parsica_memory.contracts import RECORD_STATE_WEIGHTS as _RECORD_STATE_WEIGHTS  # v2.9.9 Phase B

if TYPE_CHECKING:
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem
    from parsica_memory.packs import KnowledgePack


ASSEMBLY_PROFILES = {
    "default":    {"session": 0.30, "handoff": 0.20, "durable": 0.25, "packs": 0.15, "evidence": 0.10},
    "planner":    {"session": 0.15, "handoff": 0.25, "durable": 0.20, "packs": 0.25, "evidence": 0.15},
    "researcher": {"session": 0.10, "handoff": 0.10, "durable": 0.35, "packs": 0.30, "evidence": 0.15},
    "coder":      {"session": 0.40, "handoff": 0.10, "durable": 0.25, "packs": 0.15, "evidence": 0.10},
    "critic":     {"session": 0.10, "handoff": 0.15, "durable": 0.25, "packs": 0.10, "evidence": 0.40},
    "executive":  {"session": 0.10, "handoff": 0.30, "durable": 0.20, "packs": 0.25, "evidence": 0.15},
}


def estimate_tokens(text: str) -> int:
    """Substrate-level token estimate. len(text) // 4.
    Model adapters can override at the prompt boundary.
    """
    return max(0, len(text) // 4)


def _surfaceable(entry) -> bool:
    """Delegate to shared surfaceable() in contracts (v2.9.9 dedup)."""
    return _surfaceable_shared(entry)


@dataclass
class ContextAssemblyConfig:
    """Budget allocation config for context assembly."""
    token_budget: int = 2000
    current_session_pct: float = 0.30    # session state + active tasks
    handoff_pct: float = 0.20            # explicit handoffs
    durable_knowledge_pct: float = 0.25  # identity-durable typed knowledge
    pack_pct: float = 0.15               # selected packs
    evidence_pct: float = 0.10           # raw evidence anchors
    # Percentages should sum ≤ 1.0; remainder is overflow pool donated to next source
    profile: str = "default"             # role-specific assembly profile


@dataclass
class AssembledContext:
    """Deterministic context packet from one assembly run."""
    current_session_block: str = ""
    handoff_block: str = ""
    durable_knowledge_block: str = ""
    pack_block: str = ""
    evidence_block: str = ""
    tokens_used: int = 0
    token_budget: int = 0
    sources_used: List[str] = field(default_factory=list)
    assembly_hash: str = ""   # determinism proof: SHA256 of inputs + config

    def render(self) -> str:
        """Render all non-empty blocks into a single string."""
        parts = []
        if self.current_session_block:
            parts.append(f"## Current Session\n{self.current_session_block}")
        if self.handoff_block:
            parts.append(f"## Handoffs\n{self.handoff_block}")
        if self.durable_knowledge_block:
            parts.append(f"## Knowledge\n{self.durable_knowledge_block}")
        if self.pack_block:
            parts.append(f"## Packs\n{self.pack_block}")
        if self.evidence_block:
            parts.append(f"## Evidence\n{self.evidence_block}")
        return "\n\n".join(parts)

    def is_empty(self) -> bool:
        return not any([
            self.current_session_block,
            self.handoff_block,
            self.durable_knowledge_block,
            self.pack_block,
            self.evidence_block,
        ])


def _truncate_to_budget(text: str, token_budget: int) -> str:
    """Truncate text to fit within token budget. Hard cut at char boundary."""
    if token_budget <= 0:
        return ""
    max_chars = token_budget * 4
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0] + "…"


def _build_assembly_hash(
    identity_id: str,
    body_id: str,
    session_id: str,
    config: ContextAssemblyConfig,
    memory_system: "MemorySystem",
    active_packs: Optional[List["KnowledgePack"]],
) -> str:
    """Build a deterministic hash of the assembly inputs."""
    from parsica_memory.scope_utils import stable_hash
    payload = {
        "identity_id": identity_id,
        "body_id": body_id,
        "session_id": session_id,
        "token_budget": config.token_budget,
        "memory_count": len(getattr(memory_system, "memories", [])),
        "pack_ids": sorted([p.pack_id for p in (active_packs or [])]),
    }
    return stable_hash(payload)


class ContextAssembler:
    """Assemble a deterministic, token-budgeted context packet."""

    def assemble(
        self,
        identity_id: str,
        body_id: str,
        session_id: str,
        config: ContextAssemblyConfig,
        memory_system: "MemorySystem",
        *,
        active_packs: Optional[List["KnowledgePack"]] = None,
        handoff_data: Optional[dict] = None,
        side_effect_mode: str = "pure_read",
    ) -> AssembledContext:
        """Assemble context from all sources in strict priority order.

        Pure-read: no writes to memory_system during assembly.
        Token overflow: unused budget from one source donates to next.
        """
        ctx = AssembledContext(token_budget=config.token_budget)
        # assembly_hash computed POST-assembly to include rendered content digest (P1 fix)

        # Compute per-source token budgets (profile-aware)
        _profile_name = getattr(config, "profile", "default") or "default"
        _profile = ASSEMBLY_PROFILES.get(_profile_name, ASSEMBLY_PROFILES["default"])
        budgets = {
            "session": int(config.token_budget * _profile["session"]),
            "handoff": int(config.token_budget * _profile["handoff"]),
            "durable": int(config.token_budget * _profile["durable"]),
            "packs": int(config.token_budget * _profile["packs"]),
            "evidence": int(config.token_budget * _profile["evidence"]),
        }
        overflow = 0

        # Source 1: Current session state + active tasks
        session_budget = budgets["session"] + overflow
        session_block, session_used = self._assemble_session_block(
            memory_system, session_id, body_id, session_budget
        )
        overflow = max(0, session_budget - session_used)
        ctx.current_session_block = session_block
        if session_block:
            ctx.sources_used.append("session")

        # Source 2: Explicit handoffs
        handoff_budget = budgets["handoff"] + overflow
        handoff_block, handoff_used = self._assemble_handoff_block(
            handoff_data, handoff_budget
        )
        overflow = max(0, handoff_budget - handoff_used)
        ctx.handoff_block = handoff_block
        if handoff_block:
            ctx.sources_used.append("handoffs")

        # Source 3: Identity-durable typed knowledge
        durable_budget = budgets["durable"] + overflow
        durable_block, durable_used = self._assemble_durable_block(
            memory_system, identity_id, body_id, durable_budget
        )
        overflow = max(0, durable_budget - durable_used)
        ctx.durable_knowledge_block = durable_block
        if durable_block:
            ctx.sources_used.append("durable_knowledge")

        # Source 4: Selected packs
        packs_budget = budgets["packs"] + overflow
        packs_block, packs_used = self._assemble_packs_block(
            active_packs, memory_system, packs_budget
        )
        overflow = max(0, packs_budget - packs_used)
        ctx.pack_block = packs_block
        if packs_block:
            ctx.sources_used.append("packs")

        # Source 5: Evidence anchors (any remaining budget)
        evidence_budget = budgets["evidence"] + overflow
        evidence_block, evidence_used = self._assemble_evidence_block(
            memory_system, session_id, evidence_budget,
            identity_id=identity_id, body_id=body_id,
        )
        ctx.evidence_block = evidence_block
        if evidence_block:
            ctx.sources_used.append("evidence")

        ctx.tokens_used = (
            session_used + handoff_used + durable_used + packs_used + evidence_used
        )
        # P1 fix: recompute assembly_hash AFTER assembly — includes actual selected content
        # Pre-assembly hash (config fingerprint) replaced with post-assembly content digest
        from parsica_memory.scope_utils import stable_hash
        ctx.assembly_hash = stable_hash({
            "identity_id": identity_id,
            "body_id": body_id,
            "session_id": session_id,
            "token_budget": config.token_budget,
            "pack_ids": sorted([p.pack_id for p in (active_packs or [])]),
            "rendered_digest": hashlib.sha256(ctx.render().encode("utf-8")).hexdigest()[:32],
        })
        return ctx

    def _assemble_session_block(
        self,
        memory_system: "MemorySystem",
        session_id: str,
        body_id: str,
        budget: int,
    ) -> tuple:
        """Assemble current session state — body-local, most recent entries."""
        if budget <= 0:
            return "", 0
        memories = getattr(memory_system, "memories", [])
        # Filter to body-local entries from this session/body
        session_entries = []
        for m in memories:
            scope = getattr(m, "retrieval_scope", "") or ""
            m_session = getattr(m, "session_id", "") or ""
            m_body = getattr(m, "body_id", "") or ""
            if scope == "body_local" and (m_session == session_id or m_body == body_id):
                # Phase 3: exclude stale/suppressed entries
                if not _surfaceable(m):
                    continue
                session_entries.append(m)
        # Sort by created_at desc, take most recent
        session_entries.sort(
            key=lambda m: getattr(m, "created", None) or getattr(m, "created_at", None) or "",
            reverse=True,
        )
        lines = []
        used = 0
        for entry in session_entries[:8]:  # cap per manifest
            content = getattr(entry, "content", "") or ""
            t = estimate_tokens(content)
            if used + t > budget:
                break
            lines.append(f"- {content[:200]}")
            used += t
        text = "\n".join(lines)
        return text, estimate_tokens(text)

    def _assemble_handoff_block(
        self,
        handoff_data: Optional[dict],
        budget: int,
    ) -> tuple:
        """Assemble explicit handoff context."""
        if not handoff_data or budget <= 0:
            return "", 0
        text = ""
        if isinstance(handoff_data, dict):
            parts = []
            for k, v in handoff_data.items():
                parts.append(f"{k}: {v}")
            text = "\n".join(parts)
        text = _truncate_to_budget(text, budget)
        return text, estimate_tokens(text)

    def _assemble_durable_block(
        self,
        memory_system: "MemorySystem",
        identity_id: str,
        body_id: str,
        budget: int,
    ) -> tuple:
        """Assemble identity-durable typed knowledge (facts, preferences, procedures, mistakes)."""
        if budget <= 0:
            return "", 0
        DURABLE_KINDS = {"fact", "preference", "procedure", "mistake"}
        memories = getattr(memory_system, "memories", [])
        durable = []
        for m in memories:
            scope = getattr(m, "retrieval_scope", "") or "body_local"
            if scope != "identity_durable":
                continue
            rk = (getattr(m, "record_kind", "") or getattr(m, "memory_type", "") or "").lower()
            if rk not in DURABLE_KINDS:
                continue
            # Phase 3: exclude stale/suppressed entries
            if not _surfaceable(m):
                continue
            durable.append(m)
        # Phase B: lifecycle-aware ranking — apply RECORD_STATE_WEIGHTS to importance score
        # Deprecated entries that pass _surfaceable() get 0.25x weight; active entries get 1.0x
        durable.sort(
            key=lambda m: (
                -(
                    float(getattr(m, "importance", 0.5) or 0.5)
                    * _RECORD_STATE_WEIGHTS.get((getattr(m, "state", "active") or "active").lower(), 1.0)
                ),
                str(getattr(m, "created", None) or ""),
            ),
        )
        lines = []
        used = 0
        for entry in durable[:20]:  # cap at 20 per manifest
            content = getattr(entry, "content", "") or ""
            t = estimate_tokens(content)
            if used + t > budget:
                break
            kind = (getattr(entry, "record_kind", "") or getattr(entry, "memory_type", "") or "fact")
            lines.append(f"[{kind}] {content[:300]}")
            used += t
        text = "\n".join(lines)
        return text, estimate_tokens(text)

    def _assemble_packs_block(
        self,
        active_packs: Optional[List["KnowledgePack"]],
        memory_system: "MemorySystem",
        budget: int,
    ) -> tuple:
        """Assemble content from selected packs."""
        if not active_packs or budget <= 0:
            return "", 0
        from parsica_memory.packs import PackAssembler
        assembler = PackAssembler()
        lines = []
        used = 0
        per_pack_budget = budget // max(len(active_packs), 1)
        for pack in active_packs[:5]:  # cap at 5 packs
            entries = assembler.get_pack_entries(pack, memory_system)
            pack_lines = []
            pack_used = 0
            for entry in entries[:30]:  # cap per manifest
                content = getattr(entry, "content", "") or ""
                t = estimate_tokens(content)
                if pack_used + t > per_pack_budget:
                    break
                pack_lines.append(f"  - {content[:200]}")
                pack_used += t
            if pack_lines:
                lines.append(f"[Pack: {pack.name}]")
                lines.extend(pack_lines)
                used += pack_used
        text = "\n".join(lines)
        return text, estimate_tokens(text)

    def _assemble_evidence_block(
        self,
        memory_system: "MemorySystem",
        session_id: str,
        budget: int,
        *,
        identity_id: str = "",
        body_id: str = "",
    ) -> tuple:
        """Assemble raw evidence / fallback anchors."""
        if budget <= 0:
            return "", 0
        memories = getattr(memory_system, "memories", [])
        # Take highest-scoring episodic memories as evidence
        # Filter by agent/body scope to prevent cross-agent leakage
        episodic = []
        for m in memories:
            mtype = (getattr(m, "memory_type", "") or "").lower()
            if mtype != "episodic":
                continue
            # Phase 3: exclude stale/suppressed entries
            if not _surfaceable(m):
                continue
            # Agent-scoping: match body_id or session_id if provided
            m_body = getattr(m, "body_id", "") or ""
            m_session = getattr(m, "session_id", "") or ""
            m_scope = getattr(m, "retrieval_scope", "") or "body_local"
            # For body_local evidence, require matching body or session
            if m_scope == "body_local":
                if body_id and m_body and m_body != body_id and m_body != "__legacy_unknown_body__":
                    continue
                if session_id and m_session and m_session != session_id and not m_body:
                    continue
            episodic.append(m)
        episodic.sort(
            key=lambda m: -float(getattr(m, "importance", 0.5) or 0.5),
        )
        lines = []
        used = 0
        for entry in episodic[:10]:
            content = getattr(entry, "content", "") or ""
            t = estimate_tokens(content)
            if used + t > budget:
                break
            lines.append(f"- {content[:200]}")
            used += t
        text = "\n".join(lines)
        return text, estimate_tokens(text)
