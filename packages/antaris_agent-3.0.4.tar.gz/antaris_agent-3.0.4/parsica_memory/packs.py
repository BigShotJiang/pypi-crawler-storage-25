"""
parsica_memory.packs — Knowledge Pack assembly, export, and import.

A KnowledgePack is a named, versioned, portable collection of durable knowledge
records. Packs are assembled from identity-durable records only (body-local
excluded by default), export with full provenance, and resolve through live
truth-state on every read.

v2.9.2
"""
from __future__ import annotations

import hashlib
import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem

PACKS_DIR = "_meta/packs"
PACK_EXPORT_HEADER = "parsica_pack_v1"


@dataclass
class KnowledgePack:
    """Portable, versioned collection of durable knowledge records."""
    pack_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    version: str = "1.0"
    scope: str = "identity_durable"
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    truth_state_policy: str = "accepted_only"  # "accepted_only" | "include_superseded"
    source_tags: List[str] = field(default_factory=list)
    entry_ids: List[str] = field(default_factory=list)   # record_id references
    provenance: dict = field(default_factory=dict)
    embedding_centroid: List[float] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "pack_id": self.pack_id,
            "name": self.name,
            "version": self.version,
            "scope": self.scope,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "truth_state_policy": self.truth_state_policy,
            "source_tags": self.source_tags,
            "entry_ids": self.entry_ids,
            "provenance": self.provenance,
        }
        if self.embedding_centroid:
            d["embedding_centroid"] = self.embedding_centroid
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "KnowledgePack":
        return cls(
            pack_id=d.get("pack_id", str(uuid.uuid4())),
            name=d.get("name", ""),
            version=d.get("version", "1.0"),
            scope=d.get("scope", "identity_durable"),
            created_at=d.get("created_at", datetime.now(timezone.utc).isoformat()),
            updated_at=d.get("updated_at", datetime.now(timezone.utc).isoformat()),
            truth_state_policy=d.get("truth_state_policy", "accepted_only"),
            source_tags=d.get("source_tags", []),
            entry_ids=d.get("entry_ids", []),
            provenance=d.get("provenance", {}),
            embedding_centroid=d.get("embedding_centroid", []),
        )


class PackAssembler:
    """Assemble, export, and import KnowledgePacks."""

    def assemble(
        self,
        memory_system: "MemorySystem",
        name: str,
        *,
        record_kinds: tuple = ("fact", "preference", "procedure", "mistake"),
        tags: Optional[List[str]] = None,
        source_tags: Optional[List[str]] = None,
        truth_state_policy: str = "accepted_only",
        max_entries: int = 200,
        identity_id: str = "",
        body_id: str = "",
        include_handoff_visible: bool = False,
        unsafe_allow_body_local: bool = False,
    ) -> KnowledgePack:
        """Assemble a KnowledgePack from identity-durable records.

        Default scope: IDENTITY_DURABLE only.
        body-local entries excluded unless unsafe_allow_body_local=True.
        handoff_visible excluded unless include_handoff_visible=True.
        truth_state_policy="accepted_only" excludes superseded and retracted.

        H-2 (R4.1 P0-3): Manifest integrity is checked at assembly start via
        ``get_by_source(require_integrity=True)``.  Pack assembly is a declared
        consumer of the provenance substrate; this call exercises the integrity
        gate and raises ``ManifestIntegrityError`` if the manifest is degraded,
        making the product claim of "source-routed assembly" enforceable at
        runtime rather than decorative.
        """
        from parsica_memory.source_manifest import ManifestIntegrityError

        # H-2 (P0-3): Verify manifest integrity before assembling.
        # A degraded manifest means provenance records may be incomplete;
        # the assembly should not silently succeed against corrupted substrate.
        if hasattr(memory_system, "get_by_source"):
            try:
                memory_system.get_by_source(
                    "pack_assembly", "_assemble_integrity_check_",
                    identity_id=identity_id or "", require_integrity=True,
                )
            except ManifestIntegrityError:
                raise  # propagate — callers must not assemble from a degraded manifest

        allowed_scopes = {"identity_durable"}
        if include_handoff_visible:
            allowed_scopes.add("handoff_visible")
        if unsafe_allow_body_local:
            allowed_scopes.add("body_local")

        entry_ids = []
        seen_root_ids = set()

        for entry in memory_system.memories:
            # Scope filter
            entry_scope = getattr(entry, "retrieval_scope", "") or "body_local"
            if entry_scope not in allowed_scopes:
                continue

            # Record kind filter
            rk = (getattr(entry, "record_kind", "") or getattr(entry, "memory_type", "") or "").lower()
            if rk not in record_kinds:
                continue

            # Truth-state filter
            ts = (getattr(entry, "truth_state", "") or "accepted").lower()
            if ts == "retracted":
                continue
            if truth_state_policy == "accepted_only" and ts == "superseded":
                continue

            # Phase 3: state filter — exclude do_not_use, purged, deprecated from packs
            entry_state = (getattr(entry, "state", "active") or "active").lower()
            if entry_state in ("do_not_use", "purged", "deprecated"):
                continue

            # Tag filter
            if tags:
                entry_tags = getattr(entry, "tags", []) or []
                if not any(t in entry_tags for t in tags):
                    continue

            # Dedup by root record
            rid = getattr(entry, "record_id", "") or getattr(entry, "hash", "")
            superseded_by = getattr(entry, "superseded_by_id", "") or ""
            root_id = superseded_by or rid
            if root_id in seen_root_ids:
                continue
            seen_root_ids.add(root_id)

            if rid:
                entry_ids.append(rid)
            if len(entry_ids) >= max_entries:
                break

        pack = KnowledgePack(
            name=name,
            truth_state_policy=truth_state_policy,
            source_tags=source_tags or [],
            entry_ids=entry_ids,
            provenance={
                "assembled_at": datetime.now(timezone.utc).isoformat(),
                "identity_id": identity_id,
                "body_id": body_id,
                "record_count": len(entry_ids),
                "allowed_scopes": sorted(allowed_scopes),
            },
        )
        return pack

    def get_pack_entries(self, pack: KnowledgePack, memory_system: "MemorySystem") -> list:
        """Resolve pack entry_ids to live MemoryEntry objects.

        Resolves through truth-state on every call — NOT frozen record lists.
        Excludes retracted records. Deduplicates by root record_id.

        Falls back to hash-based lookup when record_id index is empty
        (entries ingested via typed helpers may not have record_ids indexed).
        """
        live = []
        seen_root_ids = set()

        # Build a hash→entry fallback index if needed
        _hash_index: Optional[dict] = None

        for record_id in pack.entry_ids:
            # Resolve through lineage to the live record
            entry = None
            if hasattr(memory_system, "resolve_live_record"):
                entry = memory_system.resolve_live_record(record_id)
            if entry is None and hasattr(memory_system, "get_record_by_id"):
                entry = memory_system.get_record_by_id(record_id)

            # Fallback: scan by hash (for typed-ingest entries without record_id index)
            if entry is None:
                if _hash_index is None:
                    _hash_index = {
                        m.hash: m
                        for m in getattr(memory_system, "memories", [])
                        if getattr(m, "hash", "")
                    }
                entry = _hash_index.get(record_id)

            if entry is None:
                continue

            # Phase 3: exclude retracted, do_not_use, purged, deprecated from packs
            ts = (getattr(entry, "truth_state", "") or "accepted").lower()
            state = (getattr(entry, "state", "active") or "active").lower()
            if ts == "retracted" or state in ("do_not_use", "purged", "deprecated"):
                continue

            # Dedup by root record
            root_id = (
                getattr(entry, "superseded_by_id", "")
                or getattr(entry, "record_id", "")
                or getattr(entry, "hash", "")
                or ""
            )
            if root_id in seen_root_ids:
                continue
            seen_root_ids.add(root_id)

            live.append(entry)

        return live

    def save_pack(self, pack: KnowledgePack, workspace: str) -> str:
        """Save pack metadata to workspace/_meta/packs/<pack_id>.json. Returns path."""
        packs_dir = Path(workspace) / PACKS_DIR
        packs_dir.mkdir(parents=True, exist_ok=True)
        path = packs_dir / f"{pack.pack_id}.json"
        from parsica_memory.utils import atomic_write_json
        atomic_write_json(str(path), pack.to_dict())
        return str(path)

    def load_pack(self, pack_id: str, workspace: str) -> Optional[KnowledgePack]:
        """Load pack metadata from workspace/_meta/packs/<pack_id>.json."""
        path = Path(workspace) / PACKS_DIR / f"{pack_id}.json"
        if not path.exists():
            return None
        try:
            with open(path, encoding="utf-8") as f:
                return KnowledgePack.from_dict(json.load(f))
        except Exception:
            return None

    def list_packs(self, workspace: str) -> List[KnowledgePack]:
        """List all saved packs in workspace."""
        packs_dir = Path(workspace) / PACKS_DIR
        if not packs_dir.exists():
            return []
        packs = []
        for p in packs_dir.glob("*.json"):
            try:
                with open(p, encoding="utf-8") as f:
                    packs.append(KnowledgePack.from_dict(json.load(f)))
            except Exception:
                pass
        return packs

    def export_pack(self, pack: KnowledgePack, memory_system: "MemorySystem", output_path: str) -> int:
        """Export pack as JSONL with full provenance chain.

        Line 0: header (pack metadata)
        Lines 1+: entry dicts with full provenance

        Returns number of entries written.
        """
        entries = self.get_pack_entries(pack, memory_system)
        written = 0
        with open(output_path, "w", encoding="utf-8") as f:
            # Header line
            header = {"_type": PACK_EXPORT_HEADER, **pack.to_dict()}
            f.write(json.dumps(header, ensure_ascii=False) + "\n")
            for entry in entries:
                d = entry.to_dict() if hasattr(entry, "to_dict") else {}
                d["_pack_id"] = pack.pack_id
                f.write(json.dumps(d, ensure_ascii=False) + "\n")
                written += 1
        return written

    def import_pack(self, input_path: str, memory_system: "MemorySystem") -> KnowledgePack:
        """Import pack from JSONL. Deduplicates by record_id. Preserves provenance.

        H-1 (R4.1 P0-3 + P1-7): Before ingesting any entries the manifest
        integrity gate is checked via ``get_by_source(require_integrity=True)``.
        If the manifest is degraded/chain_broken the import is aborted with an
        operator-visible ``ManifestIntegrityError``.  Additionally, if the pack
        ID already appears in the manifest under a different identity the import
        is refused to prevent cross-identity source-ID collision (P1-7).

        Returns the imported KnowledgePack.
        """
        from parsica_memory.entry import MemoryEntry
        from parsica_memory.source_manifest import ManifestIntegrityError

        # H-1a (P0-3): Manifest integrity preflight.
        # get_by_source() with require_integrity=True raises ManifestIntegrityError
        # if integrity != "ok" | "fresh".  Using a sentinel source_id that
        # won't match any real record; the health gate fires before any lookup.
        try:
            memory_system.get_by_source(
                "imported_pack", "_import_integrity_check_",
                identity_id="", require_integrity=True,
            )
        except ManifestIntegrityError as exc:
            raise ManifestIntegrityError(
                f"Pack import aborted: source manifest integrity check failed "
                f"(detail: {exc}). Resolve manifest corruption before importing."
            ) from exc

        pack = None
        imported_count = 0
        skipped_count = 0

        with open(input_path, encoding="utf-8") as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if i == 0:
                    # Header line — extract pack metadata
                    d.pop("_type", None)
                    pack = KnowledgePack.from_dict(d)
                    pack.provenance["imported_at"] = datetime.now(timezone.utc).isoformat()

                    # H-1b (P1-7): Cross-identity source ID collision check.
                    # If this pack's namespace already exists in the manifest
                    # under a non-blank identity, a different import session
                    # registered the same pack under an isolated identity scope.
                    # Re-importing under the global (blank) scope would create a
                    # collision that poisons cross-identity lookups.
                    pack_source_prefix = f"pack://{pack.pack_id}"
                    try:
                        existing_sources = memory_system.source_manifest.all_sources()
                        for (ident, _body, st, sid) in existing_sources:
                            if (
                                st == "imported_pack"
                                and sid.startswith(pack_source_prefix)
                                and ident != ""
                            ):
                                raise ValueError(
                                    f"Pack import refused: pack '{pack.pack_id}' already "
                                    f"exists in the manifest under identity '{ident}'. "
                                    f"Cross-identity source ID collision (P1-7). Use a "
                                    f"different pack ID or workspace."
                                )
                    except ManifestIntegrityError:
                        raise  # integrity errors already caught above; re-raise cleanly

                    continue

                # Entry line
                d.pop("_pack_id", None)
                try:
                    entry = MemoryEntry.from_dict(d)
                except Exception:
                    skipped_count += 1
                    continue

                # Dedup by record_id
                rid = getattr(entry, "record_id", "")
                if rid and memory_system.get_record_by_id(rid) is not None:
                    skipped_count += 1
                    continue

                # Re-ingest the entry. SourceManifest Eye R1 A-03:
                # attacker-controlled fields on the incoming pack are NEVER
                # used as the native source_type. We hard-stamp
                # source='imported_pack' and preserve the attacker's claim
                # in tags + source_channel for forensic visibility.
                if entry.content and entry.content.strip():
                    pack_id = pack.pack_id if pack is not None else "unknown"
                    original_source = str(getattr(entry, "source", "") or "")
                    original_source_url = str(getattr(entry, "source_url", "") or "")
                    pack_source_channel = (
                        f"imported_pack:{pack_id}:{original_source}"
                        if original_source else f"imported_pack:{pack_id}"
                    )
                    pack_source_url = (
                        f"pack://{pack_id}/{original_source_url}"
                        if original_source_url else f"pack://{pack_id}"
                    )
                    original_tags = list(getattr(entry, "tags", []) or [])
                    forensic_tags = original_tags + [
                        f"imported_pack:{pack_id}",
                        f"pack_claimed_source:{original_source}" if original_source else "pack_claimed_source:unknown",
                    ]
                    memory_system.ingest(
                        entry.content,
                        source="imported_pack",  # hard-stamped (A-03)
                        source_url=pack_source_url,
                        source_channel=pack_source_channel,
                        category=getattr(entry, "category", "general"),
                        memory_type=getattr(entry, "memory_type", "episodic"),
                        tags=forensic_tags,
                    )
                    imported_count += 1

        if pack is None:
            pack = KnowledgePack(name="imported", provenance={"import_path": input_path})

        pack.provenance["imported_count"] = imported_count
        pack.provenance["skipped_count"] = skipped_count
        return pack
