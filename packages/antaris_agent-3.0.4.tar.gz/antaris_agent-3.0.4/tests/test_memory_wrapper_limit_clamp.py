"""
test_memory_wrapper_limit_clamp.py

v3.0.4 (P0-2 Eye fix): Upstream wrapper must clamp user-supplied retrieval
limits to MAX_RETRIEVAL_LIMIT with a WARN log, so existing config surfaces
that still allow search_limit > 500 (recovery.py accepts up to 999,
setup/server.py accepts arbitrary from config) don't silently collapse
into empty recall/search post-merge.
"""

from __future__ import annotations

import logging

import pytest

from parsica_memory.contracts import MAX_RETRIEVAL_LIMIT


def test_clamp_helper_allows_in_range():
    from antaris_agent.core.memory import _clamp_retrieval_limit
    assert _clamp_retrieval_limit(10) == 10
    assert _clamp_retrieval_limit(MAX_RETRIEVAL_LIMIT) == MAX_RETRIEVAL_LIMIT
    assert _clamp_retrieval_limit(1) == 1


def test_clamp_helper_clamps_over_max(caplog):
    from antaris_agent.core.memory import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING, logger="antaris_agent.core.memory"):
        result = _clamp_retrieval_limit(999, caller="recall")
    assert result == MAX_RETRIEVAL_LIMIT
    warning_records = [r for r in caplog.records if r.levelname == "WARNING"]
    assert any("> MAX_RETRIEVAL_LIMIT" in r.message for r in warning_records), (
        "Clamp must log WARNING when downgrading a user-supplied limit"
    )


def test_clamp_helper_clamps_under_one(caplog):
    from antaris_agent.core.memory import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING, logger="antaris_agent.core.memory"):
        result = _clamp_retrieval_limit(0, caller="search")
    assert result == 1


def test_clamp_helper_handles_non_int(caplog):
    from antaris_agent.core.memory import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING, logger="antaris_agent.core.memory"):
        result = _clamp_retrieval_limit("not an int", caller="recall")
    assert result == 10  # default
    assert any("not int" in r.message for r in caplog.records if r.levelname == "WARNING")


def test_clamp_helper_handles_none():
    from antaris_agent.core.memory import _clamp_retrieval_limit
    # None is the sentinel for "use default"; callers pass `limit or default`
    # so the helper never actually sees raw None in production, but be safe.
    result = _clamp_retrieval_limit(None, caller="recall")
    assert result == 10  # default


def test_recovery_limit_999_no_longer_silently_empties():
    """Simulates the regression Attacker-GPT flagged: recovery.py clamps
    search_limit to [10, 999]; post-cap-fix, 999 would cause RetrievalRequest
    to raise, wrapper to swallow, empty list to return.

    With the clamp helper, 999 downgrades to MAX_RETRIEVAL_LIMIT with a
    WARN log AND the request succeeds.
    """
    from antaris_agent.core.memory import _clamp_retrieval_limit
    clamped = _clamp_retrieval_limit(999, caller="recovery")
    assert clamped == MAX_RETRIEVAL_LIMIT
    # Confirm the clamped value is legal for RetrievalRequest
    from parsica_memory.contracts import RetrievalRequest
    req = RetrievalRequest(query="x", limit=clamped)
    assert req.limit == MAX_RETRIEVAL_LIMIT


# ---------------------------------------------------------------------------
# R3B: tightened type-checking in _clamp_retrieval_limit (Attacker-GPT P2)
# ---------------------------------------------------------------------------

def test_clamp_rejects_bool_true(caplog):
    """bool True must be rejected (bool is int subclass — silent bug risk)."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING):
        result = _clamp_retrieval_limit(True, caller="test")
    assert result == 10


def test_clamp_rejects_bool_false(caplog):
    """bool False must be rejected."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING):
        result = _clamp_retrieval_limit(False, caller="test")
    assert result == 10


def test_clamp_rejects_float(caplog):
    """float 10.5 must be rejected (silent coercion to 10 is a type violation)."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING):
        result = _clamp_retrieval_limit(10.5, caller="test")
    assert result == 10


def test_clamp_rejects_str_digits(caplog):
    """str '10' must be rejected (silent coercion is a type violation)."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING):
        result = _clamp_retrieval_limit("10", caller="test")
    assert result == 10


def test_clamp_emits_clamp_metrics_logger(caplog):
    """When clamping, parsica_memory.clamp_metrics logger emits a WARNING."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING, logger="parsica_memory.clamp_metrics"):
        _clamp_retrieval_limit(999, caller="metrics_test")
    clamp_records = [r for r in caplog.records if r.name == "parsica_memory.clamp_metrics"]
    assert clamp_records, "parsica_memory.clamp_metrics must emit a log when clamping"
    assert any("clamp_event" in r.message for r in clamp_records)


def test_clamp_no_metrics_emit_for_valid_limit(caplog):
    """parsica_memory.clamp_metrics must NOT emit when limit is within bounds."""
    from parsica_memory.contracts import _clamp_retrieval_limit
    with caplog.at_level(logging.WARNING, logger="parsica_memory.clamp_metrics"):
        _clamp_retrieval_limit(10, caller="no_clamp_test")
    clamp_records = [r for r in caplog.records if r.name == "parsica_memory.clamp_metrics"]
    assert not clamp_records, "clamp_metrics must not emit for valid limits"


def test_clamp_shim_in_memory_py_delegates(caplog):
    """The shim in antaris_agent/core/memory.py must delegate to the canonical impl."""
    from antaris_agent.core.memory import _clamp_retrieval_limit as shim
    # bool rejection — canonical impl handles this, shim should pass it through
    with caplog.at_level(logging.WARNING):
        result = shim(True, caller="shim_test")
    assert result == 10


def test_context_packet_clamp_applied():
    """Regression: ContextAssembler with max_memories=200 must not raise ValueError.

    Before R3B, context_packet.py used `limit=max_memories * 3` raw (=600),
    which triggered RetrievalRequest.__post_init__ ValueError with no catch.
    """
    from parsica_memory.contracts import MAX_RETRIEVAL_LIMIT
    from parsica_memory.contracts import _clamp_retrieval_limit
    # Simulate what context_packet now does
    max_memories = 200
    clamped = _clamp_retrieval_limit(max_memories * 3, caller="context_packet")
    assert clamped == MAX_RETRIEVAL_LIMIT
    # Must be a legal RetrievalRequest limit
    from parsica_memory.contracts import RetrievalRequest
    req = RetrievalRequest(query="q", limit=clamped)
    assert req.limit == MAX_RETRIEVAL_LIMIT
