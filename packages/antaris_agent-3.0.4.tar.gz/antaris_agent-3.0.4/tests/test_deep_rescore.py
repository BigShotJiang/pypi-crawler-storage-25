"""
test_deep_rescore.py

v3.0.4 (F-DEEP-RESCORE, P0-5 Eye fix): rank_results_version_aware must not
double-apply lifecycle weights when the same hit is ranked twice. This is
now reachable on the default production path because F-QTE-AUTO routes all
default queries through QTE, and DEEP mode merges pass-1 + pass-2 via
record_id dedup — but a ranker can still see the same hit twice if the
dedup happens at a different layer.

Pre-v3.0.4: `hit.score = hit.score * weight` in-place mutation meant a
record with `truth_state="superseded"` (weight 0.5) got re-multiplied to
0.25 on the second pass.

Post-v3.0.4: the ranker stamps `_lifecycle_weighted=True` on first application
and becomes idempotent on subsequent calls.
"""

from __future__ import annotations

import pytest

from parsica_memory.contracts import ScopePolicy
from parsica_memory.entry import MemoryEntry
from parsica_memory.retrieval import rank_results_version_aware


class _Hit:
    def __init__(self, entry, score=1.0):
        self.entry = entry
        self.score = score


def _make_superseded_entry(identity_id="moro"):
    e = MemoryEntry(content="candidate record", source="test", category="general")
    e.retrieval_scope = "identity_durable"
    e.identity_id = identity_id
    e.truth_state = "superseded"  # triggers 0.5 weight
    e.state = "active"
    return e


def test_single_pass_applies_weight_once():
    """Baseline: one call applies weight exactly once."""
    entry = _make_superseded_entry()
    hit = _Hit(entry, score=1.0)
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    result = rank_results_version_aware([hit], policy)
    assert len(result) == 1
    # superseded => 0.5 weight, state=active => 1.0 weight, product = 0.5
    assert result[0].score == pytest.approx(0.5)


def test_same_list_ranked_twice_in_one_call_is_idempotent():
    """THE FIX (per-invocation dedup): when a single ranker call sees the
    same hit multiple times (e.g. DEEP's pass-1 + pass-2 merged list where
    the dedup happens *after* ranking), weights apply only once.

    Pre-Eye: 1.0 * 0.5 * 0.5 = 0.25 (bug)
    Post-Eye-R3: 1.0 * 0.5 = 0.5 (within one call)

    Note: across separate calls, double-application IS expected — the
    caller is asking to re-rank, and the per-invocation set resets. This
    is the contract change from R2's per-hit flag to R3's per-call set.
    See test_separate_calls_re_apply_weights_by_design below.
    """
    entry = _make_superseded_entry()
    hit = _Hit(entry, score=1.0)
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    # Same hit appears twice in the candidates list within ONE call.
    # Simulates DEEP pass-1+pass-2 merge where record_id dedup happens
    # at list-construction time but the ranker could still see duplicates
    # due to reference sharing.
    result = rank_results_version_aware([hit, hit], policy)
    # Weight should have been applied EXACTLY once
    assert hit.score == pytest.approx(0.5), (
        f"Double-application detected: score={hit.score}, expected 0.5"
    )
    # Both duplicate entries survive filtering; weight applied once.
    assert len(result) == 2


def test_separate_calls_re_apply_weights_by_design():
    """Contract: per-invocation dedup means across-call re-ranking DOES
    re-apply weights. This is by design (R3 refactor per Judge-Opus +
    Attacker-Sonnet) to avoid leaking internal state onto hit objects.

    A caller that wants cross-call idempotence should track it themselves
    or use immutable score fields. The ranker contract is:
      - idempotent within one invocation
      - NOT idempotent across invocations
    """
    entry = _make_superseded_entry()
    hit = _Hit(entry, score=1.0)
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    rank_results_version_aware([hit], policy)  # 1.0 * 0.5 = 0.5
    rank_results_version_aware([hit], policy)  # 0.5 * 0.5 = 0.25
    # By design: each call re-applies weights. Caller owns idempotence across calls.
    assert hit.score == pytest.approx(0.25), (
        f"Expected 0.25 after two calls (per-invocation dedup only), got {hit.score}"
    )


def test_no_hit_level_flag_pollution():
    """v3.0.4-r3 (Eye R2 Hazard A): dedup is per-invocation, not per-hit.

    Ranker must NOT mutate hit objects with lifecycle-weighting state, or
    future caching layers would leak it across requests and attackers
    could poison it to disable weighting. Contract: hit attributes
    unchanged except score.
    """
    entry = _make_superseded_entry()
    hit = _Hit(entry, score=1.0)
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    rank_results_version_aware([hit], policy)
    # Hit should NOT have _lifecycle_weighted or any other ranker-internal flag
    assert not hasattr(hit, "_lifecycle_weighted"), (
        "Ranker leaked internal state onto hit object — per-invocation set "
        "should keep state stack-local."
    )


def test_attacker_preset_flag_cannot_poison_weighting():
    """v3.0.4-r3 (Eye R2 Hazard A, Attacker-Sonnet N1): pre-setting
    _lifecycle_weighted on a hit must NOT bypass weighting.

    Pre-patch (R2): hit._lifecycle_weighted=True → ranker skipped weighting
    → superseded record returned at full weight (1.0 instead of 0.5).
    Post-patch (R3): per-invocation dedup ignores any hit attribute; the
    poison attempt has no effect.
    """
    entry = _make_superseded_entry()
    hit = _Hit(entry, score=1.0)
    # Attacker poisoning attempt
    hit._lifecycle_weighted = True
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    result = rank_results_version_aware([hit], policy)
    # superseded => 0.5. Poison attempt must be ignored.
    assert result[0].score == pytest.approx(0.5), (
        f"Attacker poisoning succeeded: score={result[0].score}, expected 0.5"
    )


def test_distinct_hits_each_get_weighted():
    """Regression: distinct hits in the same pass each get their weights applied."""
    e1 = _make_superseded_entry()
    e2 = MemoryEntry(content="accepted record", source="test", category="general")
    e2.retrieval_scope = "identity_durable"
    e2.identity_id = "moro"
    e2.truth_state = "accepted"
    e2.state = "active"

    h1 = _Hit(e1, score=1.0)
    h2 = _Hit(e2, score=1.0)
    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
    )
    rank_results_version_aware([h1, h2], policy)
    assert h1.score == pytest.approx(0.5)  # superseded
    assert h2.score == pytest.approx(1.0)  # accepted, no downweight
