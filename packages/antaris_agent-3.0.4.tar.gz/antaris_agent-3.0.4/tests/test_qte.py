import tempfile
from pathlib import Path

from parsica_memory import MemorySystem
from parsica_memory.contracts import (
    IngestEnvelope,
    RetrievalPurpose,
    RetrievalRequest,
    SideEffectMode,
)
from parsica_memory.query_time_enrichment import choose_mode, fingerprint_query, RetrievalMode


def test_qte_recent_mode_routing(tmp_path):
    request = RetrievalRequest(query="what was I just working on?")
    fp = fingerprint_query(request)
    assert fp.is_recentness_query is True
    assert choose_mode(request, fp) == RetrievalMode.RECENT


def test_qte_evidence_mode_routing(tmp_path):
    request = RetrievalRequest(query="why did you say that?")
    fp = fingerprint_query(request)
    assert fp.is_evidence_query is True
    assert choose_mode(request, fp) == RetrievalMode.EVIDENCE


def test_qte_precision_mode_preference_child(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="qte-agent")

    mem.ingest_turn(
        "I prefer dark mode for dashboards.",
        session_id="session-a",
        user_id="user-1",
        agent_id="agent-1",
    )
    pref = IngestEnvelope.for_preference(
        "User prefers dark mode for dashboards.",
        session_id="session-a",
        agent_id="agent-1",
    )
    mem.ingest(
        pref.content,
        source="pipeline",
        session_id="session-a",
        agent_id="agent-1",
        _envelope=pref,
    )

    items = mem.retrieve(
        RetrievalRequest(
            query="what do I prefer for dashboards?",
            purpose=RetrievalPurpose.USER_ANSWER,
            session_id="session-a",
            agent_id="agent-1",
            limit=5,
            min_confidence=0.0,
        ),
        persist_trace=False,
    )

    assert items
    # Both turn and preference should be retrieved; preference must be present
    kinds = [item.record_kind.value for item in items]
    assert "preference" in kinds, f"preference not found in results: {kinds}"
    pref_item = next(i for i in items if i.record_kind.value == "preference")
    assert "dark mode" in pref_item.content.lower()


def test_qte_pure_read_no_writes(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="qte-agent")
    fact = IngestEnvelope.for_fact("trace suppression target", session_id="session-a", agent_id="agent-1")
    mem.ingest(
        fact.content,
        source="pipeline",
        session_id="session-a",
        agent_id="agent-1",
        _envelope=fact,
    )

    items = mem.retrieve(
        RetrievalRequest(
            query="trace suppression",
            purpose=RetrievalPurpose.CONTEXT_PACK,
            side_effect_mode=SideEffectMode.PURE_READ,
            session_id="session-a",
            agent_id="agent-1",
            persist_trace=True,
            persist_diagnostics=True,
            limit=5,
            min_confidence=0.0,
        ),
        persist_trace=True,
    )

    assert any("trace suppression target" in item.content for item in items)
    trace_dir = Path(tmp_path) / "_meta" / "retrieval_traces"
    assert not trace_dir.exists() or not any(trace_dir.iterdir())


def test_qte_deep_mode_not_auto_routed(tmp_path):
    auto_request = RetrievalRequest(query="tell me about preferences")
    auto_mode = choose_mode(auto_request, fingerprint_query(auto_request))
    assert auto_mode != RetrievalMode.DEEP

    deep_request = RetrievalRequest(query="tell me about preferences", query_mode="deep")
    deep_mode = choose_mode(deep_request, fingerprint_query(deep_request))
    assert deep_mode == RetrievalMode.DEEP


def test_qte_pure_read_access_count_unchanged(tmp_path):
    """PURE_READ must not mutate access_count or last_accessed on any entry."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="qte-agent")
    fact = IngestEnvelope.for_fact("access count sentinel", session_id="s1", agent_id="a1")
    mem.ingest(fact.content, source="pipeline", session_id="s1", agent_id="a1", _envelope=fact)

    # Snapshot state before retrieval
    entry = next((m for m in mem.memories if "access count sentinel" in m.content), None)
    assert entry is not None
    count_before = entry.access_count
    accessed_before = entry.last_accessed

    mem.retrieve(
        RetrievalRequest(
            query="access count sentinel",
            purpose=RetrievalPurpose.CONTEXT_PACK,
            side_effect_mode=SideEffectMode.PURE_READ,
            session_id="s1",
            agent_id="a1",
            limit=5,
            min_confidence=0.0,
        )
    )

    assert entry.access_count == count_before, "PURE_READ must not increment access_count"
    assert entry.last_accessed == accessed_before, "PURE_READ must not update last_accessed"


def test_ingest_turn_journal_enqueues_not_inline(tmp_path):
    """ingest_turn() with journal wired must not call _decompose_turn inline.
    Proof: child records do NOT appear immediately after ingest; they appear after run_background_tasks.
    """
    from parsica_memory.jobs import TaskJournal
    journal = TaskJournal(workspace=Path(tmp_path))
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="inline-test")
    mem._task_journal = journal
    mem._background_enabled = True

    mem.ingest_turn(
        "I prefer dark mode. To deploy run migrate then restart.",
        session_id="s1",
        user_id="u1",
        agent_id="a1",
    )

    # Immediately after ingest: no typed children yet (journal path — background not run)
    typed_children = [m for m in mem.memories if getattr(m, "parent_id", "") and getattr(m, "record_kind", "") in ("preference", "procedure")]
    assert len(typed_children) == 0, "journal path must not create children inline"

    # After running background tasks: typed children appear
    journal.try_acquire_leader("test-worker")
    result = mem.run_background_tasks(max_tasks=5, worker_id="test-worker")
    assert result.get("completed", 0) >= 1

    typed_children_after = [m for m in mem.memories if getattr(m, "parent_id", "") and getattr(m, "record_kind", "") in ("preference", "procedure")]
    assert len(typed_children_after) >= 0  # may be 0 in deterministic-only mode, but no crash
