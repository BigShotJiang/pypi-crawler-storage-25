"""Tests for v2.9.5 Active Memory — Pro-mandated acceptance gates."""
import time
import tempfile
import pytest
from parsica_memory import MemorySystem
from parsica_memory.active_memory import ActiveMemory, ActivationPacket, ACTIVE_MEMORY_CAPS


def _make_store(tmp_path, agent_name="test-agent"):
    return MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name=agent_name)


# --- Pro-mandated tests ---

def test_active_memory_respects_250ms_cap_and_returns_partial_packet(tmp_path):
    """On artificial delay, must return partial packet with budget_exceeded=True."""
    mem = _make_store(tmp_path)
    for i in range(5):
        mem.ingest_fact(f"fact {i}: the quick brown fox jumps over the lazy dog here")

    am = ActiveMemory()
    # Use 1ms deadline — will always timeout
    packet = am.activate("user1", "body1", "sess1", "test query", mem, deadline_ms=1)
    assert packet.budget_exceeded or packet.mode in ("partial", "minimal", "timeout"), \
        f"Expected timeout behavior, got mode={packet.mode} budget_exceeded={packet.budget_exceeded}"


def test_active_memory_is_pure_read_zero_write(tmp_path):
    """activate() must not write any entries to memory_system."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("existing fact that should not be modified")
    count_before = len(mem.memories)

    am = ActiveMemory()
    am.activate("user1", "body1", "sess1", "what do you know?", mem)

    assert len(mem.memories) == count_before, \
        f"Memory count changed: {count_before} → {len(mem.memories)}"


def test_active_memory_prefers_current_session_and_handoff_before_pack_material(tmp_path):
    """current_state_block + handoff_block populated before pack_block attempted."""
    mem = _make_store(tmp_path)
    # Add a body-local session entry
    entry = mem.ingest_turn("working on this task right now in session", session_id="sess1")
    if entry:
        entry.retrieval_scope = "body_local"
        entry.body_id = "body1"

    am = ActiveMemory()
    packet = am.activate(
        "user1", "body1", "sess1", "what am I doing?", mem,
        handoff_data={"task": "fix the bug in PR 42"},
    )
    # If session or handoff data exists, those blocks should be populated before packs
    assert packet.handoff_block, "handoff_block must be populated when handoff_data provided"
    # Packs block should be empty (no packs passed)
    assert not packet.pack_block, "pack_block must be empty when no packs passed"


def test_active_memory_does_not_call_llm(tmp_path):
    """activate() must not import or call any LLM provider."""
    import sys
    mem = _make_store(tmp_path)
    mem.ingest_fact("some fact about llm calls")

    am = ActiveMemory()
    packet = am.activate("user1", "body1", "sess1", "test message", mem)
    # If we get here without error, no LLM was called (LLM calls would require API keys)
    assert isinstance(packet, ActivationPacket), "Must return ActivationPacket"
    assert packet.activation_hash, "Must have activation_hash"


def test_active_memory_respects_body_local_vs_identity_durable_vs_handoff_visible(tmp_path):
    """body_local entries only in session block; identity_durable in durable block."""
    mem = _make_store(tmp_path)

    # Add body-local entry
    entry = mem.ingest_turn("local working note for this session only", session_id="sess1")
    if entry:
        entry.retrieval_scope = "body_local"
        entry.body_id = "body1"
        entry.session_id = "sess1"

    # Add identity-durable fact
    mem.ingest_fact("global durable fact about preferences and systems")

    am = ActiveMemory()
    packet = am.activate("user1", "body1", "sess1", "what do you know?", mem)

    # body_local content must not appear in durable_knowledge_block
    if "local working note" in packet.current_state_block:
        assert "local working note" not in packet.durable_knowledge_block, \
            "body_local entry leaked into durable_knowledge_block"


def test_active_memory_agent_b_updates_within_one_turn_from_agent_a_discovery(tmp_path):
    """Ambient event from Agent A visible to Agent B via activation."""
    from parsica_memory.ambient_events import AmbientEventStore

    # Agent A publishes an ambient event
    ambient = AmbientEventStore(str(tmp_path))
    ambient.publish(
        identity_id="shared_identity",
        source_body_id="agent_a:discord:123",
        record_id="discovery_001",
        summary="Agent A discovered: the answer is 42",
        scope="identity_durable",
    )

    # Agent B peeks ambient events — must see Agent A's discovery
    events, token = ambient.peek("shared_identity", "agent_b:discord:456")
    assert len(events) >= 1, "Agent B must see Agent A's discovery"
    assert any("42" in e.summary for e in events), "Discovery content visible to Agent B"


def test_active_memory_does_not_leak_unrelated_body_local_activity(tmp_path):
    """body_local entries from Agent A must NOT appear in Agent B's activation."""
    mem_a = _make_store(tmp_path / "store_a", agent_name="agent_a")
    # Agent A ingests body-local turn
    entry = mem_a.ingest_turn("agent a secret working context only for agent a", session_id="sess_a")
    if entry:
        entry.retrieval_scope = "body_local"
        entry.body_id = "agent_a:discord:123"

    # Agent B uses a different store (different workspace = different body)
    mem_b = _make_store(tmp_path / "store_b", agent_name="agent_b")
    mem_b.ingest_fact("agent b's own fact here")

    am = ActiveMemory()
    packet_b = am.activate("user1", "agent_b:discord:456", "sess_b", "what do you know?", mem_b)
    rendered = packet_b.render()
    assert "secret working context" not in rendered, \
        "Agent A's body-local content must NOT appear in Agent B's activation"


# --- R2 additions ---

def test_legacy_store_load_does_not_leak_old_turns_across_bodies(tmp_path):
    """Legacy turns loaded from 2.8 store get body_local scope, not identity_durable."""
    from parsica_memory.entry import MemoryEntry
    from parsica_memory.scope_utils import normalize_loaded_entry

    # Simulate a legacy 2.8 entry with blank retrieval_scope
    entry = MemoryEntry("old turn from legacy store", "conversation", 0, "general")
    entry.record_kind = "turn"
    entry.retrieval_scope = ""   # blank = pre-2.9.1

    normalize_loaded_entry(entry)
    assert entry.retrieval_scope == "body_local", \
        f"Legacy turn must get body_local after normalize, got {entry.retrieval_scope!r}"


def test_shadow_mode_activation_hash_is_stable_before_cutover(tmp_path):
    """Same inputs produce identical activation_hash across two calls (shadow mode stability)."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("stable fact for hash consistency test here")

    am = ActiveMemory()
    p1 = am.activate("user1", "body1", "sess1", "test message identical", mem, token_budget=500)
    p2 = am.activate("user1", "body1", "sess1", "test message identical", mem, token_budget=500)

    assert p1.activation_hash == p2.activation_hash, \
        f"activation_hash must be stable: {p1.activation_hash} != {p2.activation_hash}"
