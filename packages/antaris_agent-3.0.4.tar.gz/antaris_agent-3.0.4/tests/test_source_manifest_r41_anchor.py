"""Tests for R4.1 Cluster D — anchor 2-phase protocol + rollback defense.

Closes:

* **P0-2** (append-then-anchor crash window, 6-reviewer converge): the
  prior single-shot anchor write left a window where a crash between
  the JSONL append and the sidecar refresh would leave the stale anchor
  matching count-1. An attacker could then delete the last JSONL line
  and pass the truncation check (line_count == expected). Cluster D
  introduces a 2-phase protocol (``planned`` BEFORE append,
  ``confirmed`` AFTER) so the loader can see the crash window on next
  boot.
* **P1-5** (anchor rollback): a separately signed monotonic
  ``update_counter`` sidecar fingerprints anchor rollback attacks.

Also verifies backwards compatibility with R3.1 (v1) anchor files.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from parsica_memory.source_manifest import (
    ANCHOR_SCHEMA_VERSION,
    COUNTER_PATH,
    TAIL_ANCHOR_PATH,
    MANIFEST_PATH,
    ManifestIntegrityError,
    SourceManifest,
    SCHEMA_VERSION,
    _INTEGRITY_STATES_ALLOW_READ,
    _INTEGRITY_STATES_ALLOW_WRITE,
)


I = "moro@antarisanalytics"
B = "moro:default"


def _anchor_path(tmp_path: Path) -> Path:
    return Path(tmp_path) / TAIL_ANCHOR_PATH


def _counter_path(tmp_path: Path) -> Path:
    return Path(tmp_path) / COUNTER_PATH


def _manifest_jsonl_path(tmp_path: Path) -> Path:
    return Path(tmp_path) / MANIFEST_PATH


# =============================================================================
# Cluster D.1 — Happy path: confirmed anchor is written
# =============================================================================


class TestHappyPath:
    def test_add_writes_v2_anchor_with_confirmed(self, tmp_path):
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        assert _anchor_path(tmp_path).exists(), "anchor sidecar should exist"
        raw = json.loads(_anchor_path(tmp_path).read_text())
        assert raw["schema_version"] == ANCHOR_SCHEMA_VERSION
        assert raw["confirmed"] is not None, "happy path must persist confirmed"
        assert raw["confirmed"]["count"] >= 1
        assert isinstance(raw["confirmed"].get("line_hash", ""), str)
        assert raw["update_counter"] >= 1

    def test_counter_sidecar_written_and_monotonic(self, tmp_path):
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        c1 = json.loads(_counter_path(tmp_path).read_text())
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)
        c2 = json.loads(_counter_path(tmp_path).read_text())
        assert c2["update_counter"] > c1["update_counter"], \
            "counter sidecar must advance monotonically"

    def test_load_then_add_happy_path(self, tmp_path):
        """Writing, closing, and re-opening a workspace must not trip
        any integrity state transitions in the ``ok`` happy path."""
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        # Fresh load: new SourceManifest against same workspace.
        m2 = SourceManifest(str(tmp_path))
        assert m2.health()["integrity"] == "ok"
        # Next write still lands cleanly.
        m2.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)
        assert m2.health()["integrity"] == "ok"


# =============================================================================
# Cluster D.2 — Crash window detection (P0-2)
# =============================================================================


class TestCrashWindowDetection:
    def test_crash_between_append_and_confirm_detected(self, tmp_path,
                                                       monkeypatch):
        """Simulate the append-then-anchor crash window: patch
        ``_write_tail_anchor_confirmed`` to raise AFTER the JSONL
        append has landed. The anchor sidecar is left with a
        ``planned`` block and a stale ``confirmed`` block (or no
        confirmed, on the first write). Next load should flip to
        ``chain_crash_recovery``.
        """
        m = SourceManifest(str(tmp_path))
        # First write completes normally (to establish a sealed prefix).
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)

        # Now sabotage the confirm phase of the SECOND write. ``add()``
        # catches unexpected exceptions from ``_append_line`` and queues
        # for retry (persist-backlog path), so we don't expect a raise
        # at the ``add()`` boundary — we only need to verify the JSONL
        # landed (because phase 2 runs before phase 3) while the anchor
        # is stuck with planned>confirmed.
        def boom(*a, **kw):
            raise RuntimeError("simulated crash between append and confirm")

        monkeypatch.setattr(m, "_write_tail_anchor_confirmed", boom)
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)

        # JSONL now has both lines; anchor has planned=next, confirmed=prev.
        # Fresh load should detect the crash window.
        jsonl = _manifest_jsonl_path(tmp_path)
        assert len(jsonl.read_text().splitlines()) == 2, (
            "phase 2 (JSONL append) must have landed before the sabotaged "
            "phase 3 (anchor confirm)"
        )
        m2 = SourceManifest(str(tmp_path))
        m2.stats()  # force _ensure_loaded
        assert m2._integrity_state == "chain_crash_recovery", \
            f"expected chain_crash_recovery, got {m2._integrity_state!r}"

    def test_chain_crash_recovery_refuses_writes(self, tmp_path, monkeypatch):
        """Cluster A interaction: ``chain_crash_recovery`` must be in
        ALLOW_READ but NOT in ALLOW_WRITE. ``_require_usable`` on any
        write op must raise ``ManifestIntegrityError``.
        """
        assert "chain_crash_recovery" in _INTEGRITY_STATES_ALLOW_READ
        assert "chain_crash_recovery" not in _INTEGRITY_STATES_ALLOW_WRITE

        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        monkeypatch.setattr(
            m, "_write_tail_anchor_confirmed",
            lambda *a, **kw: (_ for _ in ()).throw(
                RuntimeError("crash")),
        )
        # add() swallows unexpected exceptions into the persist-retry
        # queue; the JSONL append still lands before the sabotaged
        # confirm phase, so the anchor is left in a planned>confirmed
        # state.
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)

        # Next boot: writes refused.
        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        assert m2._integrity_state == "chain_crash_recovery"
        with pytest.raises(ManifestIntegrityError,
                           match=r"integrity='chain_crash_recovery'"):
            m2.add("discord", "ch1", "rec-3", identity_id=I, body_id=B)

    def test_truncation_after_crash_still_detected(self, tmp_path, monkeypatch):
        """Attacker scenario: crash leaves a planned-but-not-confirmed
        anchor pointing at count=N. Attacker deletes the last JSONL
        line so count=N-1 matches the stale confirmed anchor. BEFORE
        Cluster D, both checks (line_count==expected, seal matches)
        would pass. AFTER Cluster D, the planned block is still on
        disk and signals the crash-window even if the JSONL itself
        was rolled back to the old count.
        """
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)

        # Crash on add #2 confirm. add() queues the failure; JSONL
        # still landed (phase 2 ran before phase 3).
        monkeypatch.setattr(
            m, "_write_tail_anchor_confirmed",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("crash")),
        )
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)

        # Attacker trims the JSONL back to 1 line to match the stale
        # anchor's confirmed.count. (Implemented by reading all lines
        # and keeping only the first.)
        jsonl = _manifest_jsonl_path(tmp_path)
        lines = jsonl.read_text().splitlines(keepends=True)
        assert len(lines) >= 2, "test precondition: crash left >=2 JSONL lines"
        jsonl.write_text(lines[0])

        # Fresh load: the planned-only anchor should still trigger
        # chain_crash_recovery. If the code only compared
        # count(confirmed) vs count(JSONL), the attack would bypass.
        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        # Either chain_crash_recovery (planned detected) or truncated
        # (count mismatch) is an acceptable tamper signal; both refuse
        # writes. The key property is: NOT "ok".
        assert m2._integrity_state in {"chain_crash_recovery", "truncated",
                                        "chain_broken"}, (
            f"attacker should not be able to hide tail truncation after a "
            f"crash; got integrity_state={m2._integrity_state!r}"
        )


# =============================================================================
# Cluster D.3 — Rollback defense (P1-5)
# =============================================================================


class TestRollbackDefense:
    def test_counter_regression_detected(self, tmp_path):
        """Attacker restores an older copy of the anchor file (with
        lower update_counter) while leaving the counter sidecar
        untouched. Loader must detect counter_sidecar > anchor.counter
        and refuse.
        """
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        # Snapshot the early (low-counter) anchor.
        snapshot = _anchor_path(tmp_path).read_bytes()
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)
        m.add("discord", "ch1", "rec-3", identity_id=I, body_id=B)

        # Attacker restores old anchor (counter=1) while current counter
        # sidecar is 3.
        _anchor_path(tmp_path).write_bytes(snapshot)

        m2 = SourceManifest(str(tmp_path))
        # stats() is gated; load-and-check via the internal primitive.
        m2._ensure_loaded()
        assert m2._integrity_state == "chain_broken", (
            f"counter regression must land in chain_broken; "
            f"got {m2._integrity_state!r}"
        )
        with pytest.raises(ManifestIntegrityError):
            m2.add("discord", "ch1", "rec-4", identity_id=I, body_id=B)

    def test_counter_equality_is_not_regression(self, tmp_path):
        """Sanity: a legitimate re-open where anchor.counter ==
        counter_sidecar.counter must NOT trip chain_broken.
        """
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        assert m2._integrity_state == "ok"

    def test_counter_sidecar_hmac_forgery_rejected(self, tmp_path):
        """Rollback defense depends on the counter sidecar being
        signed. A forged counter file without a valid seal is simply
        ignored (treated as absent).
        """
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        # Forge: valid JSON, bogus seal.
        _counter_path(tmp_path).write_text(json.dumps({
            "schema_version": 1,
            "update_counter": 9999,
            "updated_at": "2099-01-01T00:00:00+00:00",
            "seal": "deadbeef" * 8,
        }))
        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        # Forged sidecar is ignored; anchor counter (1) wins; no
        # regression, integrity stays ok.
        assert m2._integrity_state == "ok", (
            f"forged counter sidecar should be ignored, not cause "
            f"a false-positive chain_broken; got {m2._integrity_state!r}"
        )


# =============================================================================
# Cluster D.4 — Backwards compat with R3.1 (v1) anchor format
# =============================================================================


class TestBackwardsCompat:
    def test_v1_anchor_file_loads_cleanly(self, tmp_path):
        """An R3.1-era anchor file (pre-Cluster D) must still be
        recognised and treated as a confirmed-only v2 record. The
        loader must NOT refuse on an unrecognised schema when the file
        is actually a legitimate legacy format.
        """
        # Bootstrap a sealed workspace using the new code path, then
        # REWRITE the anchor sidecar in legacy v1 format (reusing the
        # same HMAC secret so the seal validates).
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        # Read what the current anchor knows.
        confirmed = m._read_tail_anchor()
        assert confirmed is not None
        # Synthesize a v1 payload, sign it with the live secret, write
        # it back — simulating a workspace last written by R3.1.
        from parsica_memory.source_manifest import _compute_seal, _now_utc_iso
        legacy_payload = {
            "schema": SCHEMA_VERSION,
            "kind": "tail_anchor",
            "line_count": int(confirmed["line_count"]),
            "last_seal": confirmed["last_seal"],
            "next_seq": int(confirmed["next_seq"]),
            "updated_at": _now_utc_iso(),
        }
        legacy_payload["seal"] = _compute_seal(m._secret, legacy_payload)
        _anchor_path(tmp_path).write_text(json.dumps(legacy_payload))
        # Also reset the counter sidecar to 0 (R3.1 didn't write it).
        _counter_path(tmp_path).unlink()

        # Fresh load: legacy v1 anchor should be accepted; integrity=ok.
        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        assert m2._integrity_state == "ok", (
            f"legacy v1 anchor should load cleanly; "
            f"got {m2._integrity_state!r}"
        )

    def test_v1_anchor_file_migrates_on_next_write(self, tmp_path):
        """After a v1 anchor is read, the next write must produce a
        v2 anchor (with planned/confirmed sub-records + counter).
        """
        from parsica_memory.source_manifest import _compute_seal, _now_utc_iso

        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        confirmed = m._read_tail_anchor()
        # Overwrite with v1-shaped anchor.
        legacy_payload = {
            "schema": SCHEMA_VERSION,
            "kind": "tail_anchor",
            "line_count": int(confirmed["line_count"]),
            "last_seal": confirmed["last_seal"],
            "next_seq": int(confirmed["next_seq"]),
            "updated_at": _now_utc_iso(),
        }
        legacy_payload["seal"] = _compute_seal(m._secret, legacy_payload)
        _anchor_path(tmp_path).write_text(json.dumps(legacy_payload))
        _counter_path(tmp_path).unlink()

        m2 = SourceManifest(str(tmp_path))
        m2.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)
        # Should now be v2.
        raw = json.loads(_anchor_path(tmp_path).read_text())
        assert raw.get("schema_version") == ANCHOR_SCHEMA_VERSION
        assert raw["confirmed"] is not None
        assert raw["update_counter"] >= 1


# =============================================================================
# Cluster D.5 — State-matrix invariants
# =============================================================================


class TestStateMatrix:
    def test_chain_crash_recovery_is_read_allowed(self):
        """Per Scope Opus §4.2: chain_crash_recovery permits reads
        (operator needs to introspect) but refuses writes."""
        assert "chain_crash_recovery" in _INTEGRITY_STATES_ALLOW_READ
        assert "chain_crash_recovery" not in _INTEGRITY_STATES_ALLOW_WRITE

    def test_reads_work_in_chain_crash_recovery(self, tmp_path, monkeypatch):
        """A workspace stuck in chain_crash_recovery must still answer
        lookups so an operator can assess state."""
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "rec-1", identity_id=I, body_id=B)
        monkeypatch.setattr(
            m, "_write_tail_anchor_confirmed",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("crash")),
        )
        m.add("discord", "ch1", "rec-2", identity_id=I, body_id=B)

        m2 = SourceManifest(str(tmp_path))
        m2.stats()
        assert m2._integrity_state == "chain_crash_recovery"
        # Reads still work.
        records = m2.lookup("discord", "ch1", identity_id=I, body_id=B)
        assert "rec-1" in records
