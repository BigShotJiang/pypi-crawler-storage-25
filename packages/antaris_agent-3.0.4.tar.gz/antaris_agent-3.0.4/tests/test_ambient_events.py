"""Tests for v2.9.4 Multi-Agent Ambient Awareness."""
import tempfile
import time
import pytest
from parsica_memory.ambient_events import AmbientEventStore, AmbientEvent, _event_id


def test_publish_and_peek_basic(tmp_path):
    """Agent A publishes, Agent B sees it."""
    store = AmbientEventStore(str(tmp_path))
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="Agent A discovered something important",
        scope="identity_durable",
    )
    events, token = store.peek("user1", "moro:discord:B")
    assert len(events) == 1
    assert events[0].summary == "Agent A discovered something important"
    assert token != "0"


def test_peek_excludes_own_body_events(tmp_path):
    """peek() must filter out events from the querying body itself."""
    store = AmbientEventStore(str(tmp_path))
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="self-published event",
        scope="identity_durable",
    )
    # Body A should not see its own event
    events, _ = store.peek("user1", "moro:discord:A")
    assert len(events) == 0


def test_publish_body_local_is_rejected(tmp_path):
    """publish() must return None and not store body_local events."""
    store = AmbientEventStore(str(tmp_path))
    result = store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="local note",
        scope="body_local",   # must be rejected
    )
    assert result is None
    events, _ = store.peek("user1", "moro:discord:B")
    assert len(events) == 0


def test_publish_is_idempotent(tmp_path):
    """Same record + truth_state + enricher_version = same event_id = no duplicate."""
    store = AmbientEventStore(str(tmp_path))
    for _ in range(3):
        store.publish(
            identity_id="user1",
            source_body_id="moro:discord:A",
            record_id="record_001",
            summary="same event published 3 times",
            scope="identity_durable",
            truth_state="accepted",
            enricher_version="v1",
        )
    events, _ = store.peek("user1", "moro:discord:B")
    assert len(events) == 1, f"Expected 1 event, got {len(events)}"


def test_peek_is_pure_read(tmp_path):
    """peek() must not advance the cursor (cursor file unchanged)."""
    store = AmbientEventStore(str(tmp_path))
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="test event",
        scope="identity_durable",
    )
    cursor_path = store._cursor_path("user1", "moro:discord:B")
    exists_before = cursor_path.exists()
    events, token = store.peek("user1", "moro:discord:B")
    exists_after = cursor_path.exists()
    # peek must not create or modify the cursor file
    assert exists_before == exists_after, "peek() must not write cursor file"


def test_ack_advances_cursor(tmp_path):
    """After ack, same events are NOT returned on next peek."""
    store = AmbientEventStore(str(tmp_path))
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="event to acknowledge",
        scope="identity_durable",
    )
    events1, token1 = store.peek("user1", "moro:discord:B")
    assert len(events1) == 1

    store.ack("user1", "moro:discord:B", token1)
    events2, token2 = store.peek("user1", "moro:discord:B")
    assert len(events2) == 0, "After ack, same event must not appear again"


def test_event_id_is_deterministic():
    """Same inputs produce same event_id."""
    eid1 = _event_id("user1", "record_001", "accepted", "v1")
    eid2 = _event_id("user1", "record_001", "accepted", "v1")
    assert eid1 == eid2
    assert len(eid1) == 32


def test_multiple_bodies_get_independent_cursors(tmp_path):
    """Body B ack does not affect Body C's cursor."""
    store = AmbientEventStore(str(tmp_path))
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="record_001",
        summary="shared event",
        scope="identity_durable",
    )
    events_b, token_b = store.peek("user1", "moro:discord:B")
    store.ack("user1", "moro:discord:B", token_b)

    # Body C should still see the event
    events_c, _ = store.peek("user1", "moro:discord:C")
    assert len(events_c) == 1, "Body C cursor is independent of Body B ack"


def test_non_contamination_body_local_not_shared(tmp_path):
    """body_local events are never visible to other bodies."""
    store = AmbientEventStore(str(tmp_path))
    # Try to publish body_local — should be rejected
    store.publish(
        identity_id="user1",
        source_body_id="moro:discord:A",
        record_id="secret_local_001",
        summary="local working note not for sharing",
        scope="body_local",
    )
    events, _ = store.peek("user1", "moro:discord:B")
    summaries = [e.summary for e in events]
    assert not any("local working note" in s for s in summaries)
