"""Tests for R4.1 Cluster B \u2014 HMAC status enum + corrupt-secret hardening.

Cluster B (P0-6, P2-6): ``_ensure_secret`` is rewritten to be
non-throwing and to record a typed ``_HmacStatus`` instead of silently
flipping ``_hmac_disabled`` to True on any exception. Corrupt-secret
paths surface via the Cluster A gate (``secret_corrupt`` integrity
state) with operator-facing messages and a distinctive ops-alert log
line. Narrow exception hygiene: no ``except Exception`` inside
``_ensure_secret``.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from parsica_memory.source_manifest import (
    SECRET_PATH,
    ManifestIntegrityError,
    SourceManifest,
    _HMAC_DEGRADED_LOG_PREFIX,
    _HmacStatus,
    _INTEGRITY_STATES_HARD_REFUSE,
)


I = "moro@antarisanalytics"
B = "moro:default"


# =============================================================================
# _HmacStatus enum transitions
# =============================================================================


class TestHmacStatusTransitions:
    """Each scenario asserts the enum transition AND that the integrity
    gate refuses (or permits) appropriately.
    """

    def test_disabled_by_env_when_flag_set_and_no_secret(self, tmp_path, monkeypatch):
        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        m = SourceManifest(str(tmp_path))
        m.stats()  # Trigger _ensure_loaded.
        assert m._hmac_status == _HmacStatus.DISABLED_BY_ENV
        assert m.health()["hmac"] == "disabled_by_env"
        # Not a tamper signal \u2014 writes should still flow.
        m.add("discord", "ch1", "h1", identity_id=I, body_id=B)

    def test_enabled_on_clean_secret(self, tmp_path, monkeypatch):
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        m = SourceManifest(str(tmp_path))
        # First add provisions the secret and writes a sealed line.
        m.add("discord", "ch1", "h1", identity_id=I, body_id=B)
        assert m._hmac_status == _HmacStatus.ENABLED
        assert m.health()["hmac"] == "enabled"

    def test_disabled_by_missing_secret_on_first_boot(self, tmp_path, monkeypatch):
        """Env flag unset, no secret file \u2014 first-boot legitimate case.

        The status signals the writer path will provision on first
        touch; it is NOT a tamper signal. After _ensure_secret runs
        with no pre-existing file, the status is either ENABLED (if
        provisioning succeeded) or DISABLED_BY_MISSING_SECRET (if the
        workspace path was not writable).
        """
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        m = SourceManifest(str(tmp_path))
        m.stats()  # Triggers _ensure_loaded -> _ensure_secret.
        # Normal tmp_path: provisioning succeeds, status is ENABLED.
        assert m._hmac_status == _HmacStatus.ENABLED
        assert m._integrity_state not in _INTEGRITY_STATES_HARD_REFUSE

    def test_disabled_by_secret_corrupt_on_invalid_hex(self, tmp_path, monkeypatch, caplog):
        """Secret file exists but contents are not valid hex \u2014 tamper.

        _ensure_secret is non-throwing: it records
        ``DISABLED_BY_SECRET_CORRUPT`` and flips integrity to
        ``secret_corrupt``; the gate raises on first use with an
        operator-facing message.
        """
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        secret_path = Path(tmp_path) / SECRET_PATH
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text("this-is-not-hex!!!", encoding="ascii")

        m = SourceManifest(str(tmp_path))
        with caplog.at_level("WARNING"):
            with pytest.raises(ManifestIntegrityError) as ei:
                m.add("discord", "ch1", "h1", identity_id=I, body_id=B)

        msg = str(ei.value)
        assert "secret_corrupt" in msg
        # Operator-facing template fragments.
        assert "tamper signal" in msg
        assert str(secret_path) in msg
        assert "docs/RECOVERY.md" in msg
        assert m._hmac_status == _HmacStatus.DISABLED_BY_SECRET_CORRUPT
        assert m._integrity_state == "secret_corrupt"
        # Ops-alert log line fires with the distinctive prefix.
        assert any(
            _HMAC_DEGRADED_LOG_PREFIX in rec.getMessage()
            for rec in caplog.records
        ), f"expected {_HMAC_DEGRADED_LOG_PREFIX} in log output"
        # health() reports the typed status for alerting.
        assert m.health()["hmac"] == "disabled_by_secret_corrupt"
        assert m.health()["integrity"] == "secret_corrupt"

    def test_disabled_by_secret_corrupt_on_wrong_length(self, tmp_path, monkeypatch):
        """Valid hex but wrong byte length \u2014 still corrupt."""
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        secret_path = Path(tmp_path) / SECRET_PATH
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        # 16 bytes instead of 32.
        secret_path.write_text("00" * 16, encoding="ascii")

        m = SourceManifest(str(tmp_path))
        with pytest.raises(ManifestIntegrityError):
            m.stats()
        assert m._hmac_status == _HmacStatus.DISABLED_BY_SECRET_CORRUPT
        assert m._integrity_state == "secret_corrupt"

    def test_ensure_secret_is_non_throwing_on_corrupt(self, tmp_path, monkeypatch):
        """Contract: ``_ensure_secret`` must never raise on corruption.

        The gate raises on subsequent use. This keeps construction
        eager-safe for callers that build a SourceManifest then
        dispatch operations conditionally under try/except. Replaces
        the pre-R4.1 ``except Exception`` silent-downgrade.
        """
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        secret_path = Path(tmp_path) / SECRET_PATH
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text("garbage", encoding="ascii")

        m = SourceManifest(str(tmp_path))
        # Directly invoking the secret provisioning must not raise.
        m._ensure_secret()
        assert m._hmac_status == _HmacStatus.DISABLED_BY_SECRET_CORRUPT
        # And _secret stays None so no seal can be stamped.
        assert m._secret is None

    def test_ensure_secret_does_not_use_bare_except(self):
        """Cluster B contract: no ``except Exception`` inside
        ``_ensure_secret``.

        The rewrite narrowed exception hygiene so transient I/O
        (OSError) and validation errors (ValueError) are handled
        explicitly. A generic ``except Exception`` would re-introduce
        the silent-downgrade bug that R4.1 closes.
        """
        import ast
        import inspect
        import textwrap

        import parsica_memory.source_manifest as sm

        src = textwrap.dedent(inspect.getsource(sm.SourceManifest._ensure_secret))
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler):
                if node.type is None:
                    pytest.fail("_ensure_secret uses a bare `except:`")
                if isinstance(node.type, ast.Name) and node.type.id == "Exception":
                    pytest.fail(
                        "_ensure_secret catches generic Exception; R4.1 "
                        "Cluster B requires narrow (OSError, ValueError)."
                    )

    def test_secret_corrupt_state_in_hard_refuse_set(self):
        """The Cluster A gate's hard-refuse set must contain
        ``secret_corrupt`` so Cluster B's state transition actually
        blocks operations. Belt-and-braces structural assertion.
        """
        assert "secret_corrupt" in _INTEGRITY_STATES_HARD_REFUSE


class TestHealthReportsTypedHmacStatus:
    """``health()[\"hmac\"]`` emits the enum value, not the coarse boolean."""

    def test_enabled_value(self, tmp_path, monkeypatch):
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        m = SourceManifest(str(tmp_path))
        m.add("discord", "ch1", "h1", identity_id=I, body_id=B)
        assert m.health()["hmac"] == "enabled"

    def test_disabled_by_env_value(self, tmp_path, monkeypatch):
        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        m = SourceManifest(str(tmp_path))
        m.stats()
        assert m.health()["hmac"] == "disabled_by_env"

    def test_disabled_by_secret_corrupt_value(self, tmp_path, monkeypatch):
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        secret_path = Path(tmp_path) / SECRET_PATH
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text("nope", encoding="ascii")
        m = SourceManifest(str(tmp_path))
        # health() is ungated so it reports even on hard-refuse states.
        h = m.health()
        assert h["hmac"] == "disabled_by_secret_corrupt"
        assert h["integrity"] == "secret_corrupt"


class TestOpsAlertHook:
    """``_emit_hmac_degraded_alert`` emits a distinctive WARNING line."""

    def test_alert_fires_on_corrupt_secret(self, tmp_path, monkeypatch, caplog):
        monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
        secret_path = Path(tmp_path) / SECRET_PATH
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text("xyz", encoding="ascii")

        m = SourceManifest(str(tmp_path))
        with caplog.at_level("WARNING"):
            # ``health()`` is ungated and triggers _ensure_loaded which
            # invokes _ensure_secret — the alert fires there.
            m.health()
        lines = [r.getMessage() for r in caplog.records]
        matches = [l for l in lines if _HMAC_DEGRADED_LOG_PREFIX in l]
        assert matches, f"no alert line in {lines!r}"
        # Alert contains the status value and the secret path.
        assert "disabled_by_secret_corrupt" in matches[0]
        assert str(secret_path) in matches[0]

    def test_alert_does_not_fire_on_env_opt_out(self, tmp_path, monkeypatch, caplog):
        """DISABLED_BY_ENV is an operator choice, not a degradation.

        No alert should fire when the env flag is the reason.
        """
        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        m = SourceManifest(str(tmp_path))
        with caplog.at_level("WARNING"):
            m.stats()
        lines = [r.getMessage() for r in caplog.records]
        matches = [l for l in lines if _HMAC_DEGRADED_LOG_PREFIX in l]
        assert not matches, f"unexpected alert line(s): {matches!r}"
