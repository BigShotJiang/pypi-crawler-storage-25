"""Tests for the setup wizard server."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


def test_wizard_portable_cwd():
    """Verify wizard tests use repo-relative paths, not hardcoded."""

    assert REPO_ROOT.exists()
    assert (REPO_ROOT / "antaris_agent").exists()


class TestSetupServer:
    def test_wizard_html_contains_security_step(self):
        """Wizard HTML should still expose security configuration state."""
        from antaris_agent.setup.server import WIZARD_HTML
        assert 'securityMode' in WIZARD_HTML
        assert 'security_mode' in WIZARD_HTML
        assert 'standard' in WIZARD_HTML

    def test_handle_setup_saves_security_mode(self, tmp_path):
        """POST /api/setup should save security_mode to config."""
        from antaris_agent.setup.server import SetupServer, _WizardHandler
        from antaris_agent.core.config import Config

        payload = {
            "bot_name": "TestBot",
            "providers": [{"provider": "anthropic", "api_key": "sk-test-key"}],
            "selected_channels": [],
            "telegram_token": "",
            "discord_token": "",
            "slack_bot_token": "",
            "slack_app_token": "",
            "security_mode": "sandboxed",
        }

        with patch("antaris_agent.setup.server.DEFAULT_CONFIG_DIR", tmp_path):
            with patch("antaris_agent.setup.server.DEFAULT_CONFIG_PATH", tmp_path / "config.json"):
                with patch("antaris_agent.core.config.DEFAULT_CONFIG_DIR", tmp_path):
                    with patch("antaris_agent.core.config.DEFAULT_CONFIG_PATH", tmp_path / "config.json"):
                        with patch("antaris_agent.setup.server._test_channel_connection", return_value={"success": True, "channel": "terminal"}):
                            # Simulate the handler directly
                            handler = MagicMock()
                            handler.server_ref = None
                            handler.headers = {"Content-Length": str(len(json.dumps(payload)))}
                            handler.rfile = MagicMock()
                            handler.rfile.read.return_value = json.dumps(payload).encode()

                            sent = {}

                            def fake_send_json(data, status=200):
                                sent.update(data)

                            handler._send_json = fake_send_json
                            handler._read_json_body = lambda: payload

                            with patch("antaris_agent.setup.server.Config") as MockConfig:
                                mock_cfg = MagicMock()
                                MockConfig.load.return_value = mock_cfg
                                MockConfig.return_value = mock_cfg
                                _WizardHandler._handle_setup(handler)
                                # Check security_mode was set
                                assert mock_cfg.security_mode == "sandboxed"


class TestTestChannelConnection:
    def test_terminal_mode_always_succeeds(self):
        """Terminal mode should always report success."""
        from antaris_agent.setup.server import _test_channel_connection
        from antaris_agent.core.config import Config
        cfg = Config()
        cfg.telegram_enabled = False
        cfg.discord_enabled = False
        cfg.slack_enabled = False
        result = _test_channel_connection(cfg)
        assert result["success"] is True
        assert result["channel"] == "terminal"

    def test_returns_dict_with_expected_keys(self):
        """Result should always have channel, success, error keys."""
        from antaris_agent.setup.server import _test_channel_connection
        from antaris_agent.core.config import Config
        cfg = Config()
        result = _test_channel_connection(cfg)
        assert "channel" in result
        assert "success" in result
        assert "error" in result

    def test_telegram_mode_calls_api(self):
        """When telegram_enabled, _test_channel_connection should hit Telegram API."""
        from antaris_agent.setup.server import _test_channel_connection
        from antaris_agent.core.config import Config
        from unittest.mock import patch
        cfg = Config()
        cfg.telegram_enabled = True
        cfg.telegram_token = "fake-token"
        cfg.discord_enabled = False
        cfg.slack_enabled = False

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"ok": True, "result": {"username": "TestBot"}}).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("antaris_agent.setup.server.urlopen", return_value=mock_resp):
            result = _test_channel_connection(cfg)

        assert result["channel"] == "telegram"
        assert result["success"] is True


class TestValidateToken:
    def test_empty_token_returns_invalid(self):
        from antaris_agent.setup.server import _validate_token
        valid, error = _validate_token("anthropic", "")
        assert valid is False
        assert error is not None

    def test_unknown_provider_returns_invalid(self):
        from antaris_agent.setup.server import _validate_token
        valid, error = _validate_token("unknown_provider", "some-token")
        assert valid is False

    def test_empty_string_error_message(self):
        """Empty token should return a descriptive error."""
        from antaris_agent.setup.server import _validate_token
        valid, error = _validate_token("telegram", "")
        # Error should be non-empty string
        assert isinstance(error, str)
        assert len(error) > 0


class TestDoctorCommand:
    def test_doctor_runs_without_crash(self, tmp_path, capsys):
        """antaris doctor should run without raising exceptions."""
        from antaris_agent.cli import _cmd_doctor
        with patch("antaris_agent.core.config.Config.load", return_value=None):
            _cmd_doctor()  # Should not raise
        captured = capsys.readouterr()
        # Should print something doctor-related
        assert "Doctor" in captured.out or "doctor" in captured.out.lower()

    def test_doctor_shows_encryption_status(self, capsys):
        """antaris doctor should show honest encryption status."""
        from antaris_agent.cli import _cmd_doctor
        with patch("antaris_agent.core.config.Config.load", return_value=None):
            _cmd_doctor()
        captured = capsys.readouterr()
        assert "Encryption:" in captured.out
        assert "Data-at-rest:" in captured.out
        assert "not yet implemented" in captured.out

    def test_doctor_no_config_shows_warning(self, capsys):
        """antaris doctor with no config should mention 'antaris init'."""
        from antaris_agent.cli import _cmd_doctor
        with patch("antaris_agent.core.config.Config.load", return_value=None):
            _cmd_doctor()
        captured = capsys.readouterr()
        # Should mention initialization
        assert "init" in captured.out.lower() or "config" in captured.out.lower()

    def test_doctor_with_valid_config(self, capsys):
        """antaris doctor with valid config should show provider info."""
        from antaris_agent.cli import _cmd_doctor
        from antaris_agent.core.config import Config
        mock_cfg = MagicMock(spec=Config)
        mock_cfg.provider_name = "anthropic"
        mock_cfg.model = "claude-sonnet-4"
        mock_cfg.security_mode = "sandboxed"
        mock_cfg.discord_enabled = False
        mock_cfg.telegram_enabled = False
        mock_cfg.slack_enabled = False
        mock_cfg.memory_store = "/tmp/test-memories"
        with patch("antaris_agent.core.config.Config.load", return_value=mock_cfg):
            _cmd_doctor()
        captured = capsys.readouterr()
        # Should show some health info
        assert len(captured.out) > 0


class TestCLISecurityFlag:
    def test_init_parser_has_security_flag(self):
        """antaris init should accept --security flag."""
        import subprocess
        import sys
        result = subprocess.run(
            [sys.executable, "-m", "antaris_agent.cli", "init", "--help"],
            capture_output=True,
            text=True,
            cwd=str(REPO_ROOT),
        )
        # Should not crash with unrecognized argument
        assert result.returncode == 0 or "--security" in result.stdout or "--security" in result.stderr

    def test_start_parser_has_security_flag(self):
        """antaris start should accept --security flag."""
        import subprocess
        import sys
        result = subprocess.run(
            [sys.executable, "-m", "antaris_agent.cli", "start", "--help"],
            capture_output=True,
            text=True,
            cwd=str(REPO_ROOT),
        )
        assert "--security" in result.stdout or "--security" in result.stderr

    def test_doctor_subcommand_exists(self):
        """antaris doctor should be a registered subcommand."""
        import subprocess
        import sys
        result = subprocess.run(
            [sys.executable, "-m", "antaris_agent.cli", "--help"],
            capture_output=True,
            text=True,
            cwd=str(REPO_ROOT),
        )
        assert "doctor" in result.stdout or "doctor" in result.stderr
