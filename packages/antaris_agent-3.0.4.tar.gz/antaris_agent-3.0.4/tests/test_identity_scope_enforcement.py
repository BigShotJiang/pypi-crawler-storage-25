"""
test_identity_scope_enforcement.py

v3.0.4 P0 — Closes the Meyru-leaks-into-Moro cross-identity retrieval bug.

Before this patch:
    ScopePolicy.identity_id was a vestigial field. rank_results_version_aware()
    never filtered by identity_id. An identity_durable record created by
    identity "meyru" would surface in a query made with scope_policy.identity_id="moro".

After this patch:
    identity_durable records are filtered by identity_id match, symmetric with
    the existing body_local body_id enforcement. Legacy records with no
    identity_id get a sentinel and are excluded from identity-aware queries.

This test proves BOTH behaviors:
    - Pre-patch state: records from other identities appear in results
      (simulated by stripping the identity filter from a copy of the
      ranker, see `_pre_patch_rank`).
    - Post-patch state: records from other identities are excluded,
      own records survive, legacy records are excluded unless the caller
      explicitly opts in via the sentinel.
"""

from __future__ import annotations

import pytest

from parsica_memory.contracts import ScopePolicy
from parsica_memory.entry import MemoryEntry
from parsica_memory.retrieval import rank_results_version_aware
from parsica_memory.scope_utils import normalize_loaded_entry


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

def _make_durable(content: str, identity_id: str, *, retrieval_scope: str = "identity_durable") -> MemoryEntry:
    """Fresh identity_durable record stamped with a given identity."""
    e = MemoryEntry(content=content, source="test", category="general")
    e.retrieval_scope = retrieval_scope
    e.identity_id = identity_id
    e.truth_state = "accepted"
    e.state = "active"
    return e


def _make_hit(entry: MemoryEntry, score: float = 1.0):
    """Wrap entry in a hit-like object the ranker expects."""
    class _Hit:
        def __init__(self, entry, score):
            self.entry = entry
            self.score = score
    return _Hit(entry, score)


# ---------------------------------------------------------------------------
# The bug: demonstrate pre-patch leak by bypassing the new identity block.
# ---------------------------------------------------------------------------

def _pre_patch_rank(hits, scope_policy):
    """Simulates the pre-v3.0.4 ranker: scope classification filter only, no identity match.

    This is NOT the real ranker — it's a stripped copy that matches the pre-patch
    behavior (scope classification allowed, no identity filter). We keep it here so
    the test proves the patch actually changed something.
    """
    allowed = getattr(scope_policy, "allowed_scopes", None)
    out = []
    for hit in hits:
        entry = getattr(hit, "entry", hit)
        scope = getattr(entry, "retrieval_scope", "") or "identity_durable"
        if allowed is not None and scope not in allowed:
            continue
        out.append(hit)
    return out


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_pre_patch_ranker_would_have_leaked():
    """Sanity: the simulated pre-patch ranker DOES leak across identities.

    This proves the test itself is meaningful — if the simulated leak doesn't
    actually show up, the positive test below would be vacuous.
    """
    moro_fact = _make_durable("moro prefers sonnet 4.6", identity_id="moro")
    meyru_fact = _make_durable("meyru prefers opus 4.7", identity_id="meyru")
    hits = [_make_hit(moro_fact), _make_hit(meyru_fact)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    leaked = _pre_patch_rank(hits, policy)
    leaked_contents = {getattr(h.entry, "content", "") for h in leaked}
    assert "meyru prefers opus 4.7" in leaked_contents, (
        "Pre-patch behavior should leak meyru's fact into moro's query; "
        "if this assertion fails the simulated leak is wrong and the post-patch "
        "test is vacuous."
    )


def test_post_patch_no_cross_identity_leak():
    """THE FIX: identity_durable records from other identities must NOT surface."""
    moro_fact = _make_durable("moro prefers sonnet 4.6", identity_id="moro")
    meyru_fact = _make_durable("meyru prefers opus 4.7", identity_id="meyru")
    hits = [_make_hit(moro_fact), _make_hit(meyru_fact)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    contents = {getattr(h.entry, "content", "") for h in filtered}

    assert "moro prefers sonnet 4.6" in contents, "Moro's own fact must survive its own query"
    assert "meyru prefers opus 4.7" not in contents, (
        "CROSS-IDENTITY LEAK: meyru's identity_durable fact reached moro's query. "
        "identity_id enforcement is not working."
    )


def test_own_identity_records_survive():
    """Three Moro records, different body_ids and content — all should survive."""
    facts = [
        _make_durable("moro fact one", identity_id="moro"),
        _make_durable("moro fact two", identity_id="moro"),
        _make_durable("moro fact three", identity_id="moro"),
    ]
    hits = [_make_hit(f) for f in facts]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    assert len(filtered) == 3


def test_legacy_records_excluded_by_default():
    """Pre-v3.0.4 records with no identity_id must NOT appear in identity-aware queries."""
    legacy = _make_durable("ancient legacy fact", identity_id="")  # blank, pre-patch
    legacy = normalize_loaded_entry(legacy)  # simulates load-time backfill
    assert legacy.identity_id == "__legacy_unknown_identity__"

    hits = [_make_hit(legacy)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    assert len(filtered) == 0, (
        "Legacy records must be excluded from identity-aware queries. "
        "Conservative policy: caller must explicitly opt into legacy sweep."
    )


def test_legacy_sentinel_opt_in_works():
    """Operator explicitly running a legacy sweep can see legacy records."""
    legacy = _make_durable("ancient legacy fact", identity_id="")
    legacy = normalize_loaded_entry(legacy)

    hits = [_make_hit(legacy)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="__legacy_unknown_identity__",
        body_id="",
    )

    filtered = rank_results_version_aware(hits, policy)
    assert len(filtered) == 1
    assert "ancient legacy fact" in getattr(filtered[0].entry, "content", "")


def test_fail_closed_when_caller_has_identity_but_entry_does_not():
    """Entry with blank identity_id must not leak when caller declares a real identity.

    This is defensive: covers the case where an entry slipped through the
    normalize_loaded_entry backfill (e.g. a hit built in-memory, not loaded from disk).
    Fail-closed.
    """
    unstamped = _make_durable("unstamped fact", identity_id="")
    # NOTE: not calling normalize_loaded_entry — this simulates a pre-backfill bypass
    assert unstamped.identity_id == ""

    hits = [_make_hit(unstamped)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    assert len(filtered) == 0, "Entry with no identity_id must not leak when caller has one"


def test_body_local_still_works_post_patch():
    """Regression: existing body_local filtering behavior is unchanged."""
    moro_dm = MemoryEntry(content="moro in dm", source="test", category="general")
    moro_dm.retrieval_scope = "body_local"
    moro_dm.body_id = "moro:dm"
    moro_dm.identity_id = "moro"
    moro_dm.truth_state = "accepted"
    moro_dm.state = "active"

    moro_ventures = MemoryEntry(content="moro in ventures", source="test", category="general")
    moro_ventures.retrieval_scope = "body_local"
    moro_ventures.body_id = "moro:ventures"
    moro_ventures.identity_id = "moro"
    moro_ventures.truth_state = "accepted"
    moro_ventures.state = "active"

    hits = [_make_hit(moro_dm), _make_hit(moro_ventures)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    contents = {getattr(h.entry, "content", "") for h in filtered}
    assert "moro in dm" in contents
    assert "moro in ventures" not in contents, "body_local filter must still cross-exclude different bodies"


def test_roundtrip_serialization_preserves_identity_id():
    """to_dict / from_dict must persist identity_id."""
    original = _make_durable("persisted fact", identity_id="moro")
    d = original.to_dict()
    assert d.get("identity_id") == "moro", "to_dict must persist identity_id"

    restored = MemoryEntry.from_dict(d)
    assert restored.identity_id == "moro", "from_dict must restore identity_id"


def test_handoff_visible_records_not_blocked_by_identity():
    """handoff_visible records are cross-identity by design; identity filter must not touch them."""
    handoff = _make_durable("handoff from meyru to moro", identity_id="meyru",
                            retrieval_scope="handoff_visible")
    hits = [_make_hit(handoff)]

    policy = ScopePolicy(
        allowed_scopes=frozenset({"identity_durable", "handoff_visible", "body_local"}),
        identity_id="moro",
        body_id="moro:dm",
    )

    filtered = rank_results_version_aware(hits, policy)
    assert len(filtered) == 1, "handoff_visible records must survive cross-identity queries"
