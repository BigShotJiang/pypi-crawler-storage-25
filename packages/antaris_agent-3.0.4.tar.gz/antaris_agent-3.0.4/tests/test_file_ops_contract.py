import asyncio
from pathlib import Path

from antaris_agent.tools.native.file_ops import FileOpsTool


def run(coro):
    return asyncio.run(coro)


def test_missing_params_returns_error_metadata(tmp_path):
    tool = FileOpsTool(str(tmp_path))
    result = run(tool.execute({}))
    assert result.success is False
    assert result.is_error is True
    assert result.metadata.get('status') == 'error'


def test_read_missing_file_returns_error_metadata(tmp_path):
    tool = FileOpsTool(str(tmp_path))
    result = run(tool.execute({'operation': 'read', 'path': 'missing.txt'}))
    assert result.success is False
    assert result.metadata.get('status') == 'error'
    assert 'File not found' in result.error


def test_write_success_returns_success_metadata(tmp_path):
    tool = FileOpsTool(str(tmp_path))
    result = run(tool.execute({'operation': 'write', 'path': 'a.txt', 'content': 'hello'}))
    assert result.success is True
    assert result.metadata.get('status') == 'success'
    assert (tmp_path / 'a.txt').read_text() == 'hello'


def test_edit_missing_old_text_returns_error_metadata(tmp_path):
    p = tmp_path / 'a.txt'
    p.write_text('hello world')
    tool = FileOpsTool(str(tmp_path))
    result = run(tool.execute({'operation': 'edit', 'path': 'a.txt', 'old_text': 'zzz', 'new_text': 'x'}))
    assert result.success is False
    assert result.metadata.get('status') == 'error'
    assert 'not found' in result.error.lower()
