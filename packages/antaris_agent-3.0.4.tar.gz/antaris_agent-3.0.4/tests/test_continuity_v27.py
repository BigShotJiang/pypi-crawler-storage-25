"""
tests/test_continuity_v27.py

v2.7.0 battle-test suite — 21 tests covering:
  - Ambient ingest (session summary updates via ingest_turn)
  - Pure-read discipline (search, pitfalls, startup recall, subagent context)
  - Pipeline injection priority (typed brief > all old bailout paths)
  - Activity feed (publish, list, expiry, collapse)
  - BotMemory continuity API (brief, token budget, sparse store)
  - Cross-session isolation (no contamination between sessions)

THE PROOF TEST: test_continuity_source_prefers_typed_brief_over_all_fallbacks
  asserts typed brief beats legacy snapshot + startup recall + recency + ambient ALL AT ONCE.
"""
from __future__ import annotations

import asyncio
import tempfile
from dataclasses import dataclass, field as dc_field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from antaris_agent.channels.base import InboundMessage
from antaris_agent.core.memory import BotMemory
from antaris_agent.core.pipeline import Pipeline
from antaris_agent.core.subagents import SubagentRegistry
from antaris_agent.llm.base import LLMResponse
from parsica_memory import MemorySystem
from parsica_memory.activity_feed import ActivityFeed, ActivityNote
from parsica_memory.context_packet import ContextPacketBuilder


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def make_inbound(text="Hello", user_id="u1", channel_id="ch1", platform="terminal"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id=channel_id,
        platform=platform,
        text=text,
        timestamp_ms=0,
        images=[],
        documents=[],
    )


def make_pipeline():
    """Build a Pipeline with all dependencies mocked (mirrors test_ambient_awareness.py)."""
    config = MagicMock()
    config.model = "test-model"
    config.rate_limit_messages = 100
    config.rate_limit_window_seconds = 60
    config.memory_ambient_limit = 5
    config.per_turn_recall = True
    config.recency_enabled = False   # default off; individual tests opt in
    config.session_persistence_enabled = False
    config.config_path = "/tmp/fake_config.json"
    config.memory_continuity_enabled = True

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=[])
    memory.ingest = AsyncMock()
    memory.begin_turn = AsyncMock()
    memory.end_turn = AsyncMock()
    memory.get_ambient_context = AsyncMock(return_value=[])
    memory.get_continuity_brief = AsyncMock(return_value="")

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "Bot reply"))
    guard.scrub = MagicMock(side_effect=lambda text: text)

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="Base system prompt.")
    persona.config_dir = ""

    llm = MagicMock()
    llm.complete = AsyncMock(
        return_value=LLMResponse(
            content="Bot reply",
            model="test-model",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.0,
        )
    )

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    pipeline = Pipeline(config, memory, guard, persona, llm)
    pipeline._cooldown_seconds = 0
    return pipeline, adapter


def _capture_llm(pipeline):
    """Replace pipeline.llm.complete with a capture side-effect; return dict."""
    captured = {}

    async def _capture(messages, system, **kwargs):
        captured["prompt"] = system
        return LLMResponse(
            content="ok", model="test-model", input_tokens=1, output_tokens=1, cost_usd=0.0
        )

    pipeline.llm.complete = AsyncMock(side_effect=_capture)
    return captured


def make_activity_note(
    identity_id="agent1",
    session_id="sess1",
    content="did something",
    created_at=None,
    tags=None,
) -> ActivityNote:
    return ActivityNote(
        note_id="note-1",
        identity_id=identity_id,
        body_id=identity_id,
        session_id=session_id,
        content=content,
        created_at=created_at or datetime.now(timezone.utc).isoformat(),
        tags=tags or [],
    )


# ---------------------------------------------------------------------------
# Parsi's 8 core tests
# ---------------------------------------------------------------------------

def test_ingest_turn_updates_ambient_summary(tmp_path):
    """ingest_turn() must call update_memory_summary on _session_tracker."""
    store = MemorySystem(str(tmp_path))

    mock_tracker = MagicMock()
    mock_tracker.update_memory_summary = MagicMock()
    store._session_tracker = mock_tracker

    store.ingest_turn(content="User: hello\nAssistant: hi", session_id="sess1")

    mock_tracker.update_memory_summary.assert_called_once()
    call_args = mock_tracker.update_memory_summary.call_args[0]
    assert call_args[0] == "sess1", "first arg must be the session_id"
    # content passed must be the turn record's own content, not a child fragment
    assert len(call_args[1]) > 0, "update_memory_summary must receive non-empty content"


def test_search_memories_is_pure_read(tmp_path):
    """search_memories() must pass read_only=True to store.search."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    mock_store = MagicMock()
    mock_store.search = MagicMock(return_value=[])

    with patch.object(mem, "_get_store", return_value=mock_store):
        mem.search_memories("u1", "important query", limit=5)

    mock_store.search.assert_called_once()
    _, kwargs = mock_store.search.call_args
    assert kwargs.get("read_only") is True, "search_memories must pass read_only=True"


def test_collect_pitfalls_is_pure_read():
    """_collect_pitfalls() must pass read_only=True to mem.search."""
    mock_mem = MagicMock()
    mistake_entry = MagicMock()
    mistake_entry.memory_type = "mistake"
    mock_mem.memories = [mistake_entry]
    mock_mem.search = MagicMock(return_value=[])

    builder = ContextPacketBuilder(mock_mem)
    builder._collect_pitfalls("do the thing", max_pitfalls=3, min_relevance=0.0)

    mock_mem.search.assert_called_once()
    _, kwargs = mock_mem.search.call_args
    assert kwargs.get("read_only") is True, "_collect_pitfalls must pass read_only=True"


@pytest.mark.asyncio
async def test_startup_recall_is_pure_read():
    """Pipeline startup recall must pass read_only=True to memory.recall."""
    pipeline, adapter = make_pipeline()
    inbound = make_inbound(user_id="alice", channel_id="ch-startup")

    await pipeline.process(inbound, adapter)

    # Find the startup recall call (query = "recent events today")
    startup_calls = [
        c for c in pipeline.memory.recall.call_args_list
        if len(c.args) >= 2 and c.args[1] == "recent events today"
    ]
    assert len(startup_calls) == 1, "exactly one startup recall should fire for first message"
    assert startup_calls[0].kwargs.get("read_only") is True, (
        "startup recall must pass read_only=True"
    )


@pytest.mark.asyncio
async def test_subagent_auto_context_uses_parent_session():
    """_build_auto_context must pass parent_session_id as session_id to recall."""
    bot = MagicMock()
    bot.memory = MagicMock()
    bot.memory.recall = AsyncMock(return_value=[])
    registry = SubagentRegistry(bot)

    await registry._build_auto_context(
        "do a research task",
        parent_user_id="user1",
        parent_session_id="parent-sess-42",
    )

    bot.memory.recall.assert_awaited_once()
    call_kwargs = bot.memory.recall.call_args.kwargs
    assert call_kwargs.get("session_id") == "parent-sess-42", (
        "_build_auto_context must scope recall to parent_session_id"
    )


@pytest.mark.asyncio
async def test_subagent_auto_context_is_pure_read():
    """_build_auto_context must pass read_only=True to recall."""
    bot = MagicMock()
    bot.memory = MagicMock()
    bot.memory.recall = AsyncMock(return_value=[])
    registry = SubagentRegistry(bot)

    await registry._build_auto_context(
        "do a research task",
        parent_user_id="user1",
        parent_session_id="parent-sess-42",
    )

    call_kwargs = bot.memory.recall.call_args.kwargs
    assert call_kwargs.get("read_only") is True, (
        "_build_auto_context must pass read_only=True"
    )


@pytest.mark.asyncio
async def test_legacy_snapshot_does_not_cross_contaminate_other_session():
    """Legacy snapshot must NOT fire when continuity.latest.session_id != current session."""
    pipeline, adapter = make_pipeline()
    captured = _capture_llm(pipeline)

    mock_continuity = MagicMock()
    mock_continuity.latest = MagicMock()
    mock_continuity.latest.session_id = "OTHER_SESSION_999"  # different from current
    mock_continuity.get_context_block = MagicMock(return_value="LEGACY SNAPSHOT SENTINEL")
    pipeline.continuity = mock_continuity

    inbound = make_inbound(user_id="bob", channel_id="ch-main")
    await pipeline.process(inbound, adapter)

    prompt_text = captured.get("prompt", "")
    assert "LEGACY SNAPSHOT SENTINEL" not in prompt_text, (
        "legacy snapshot must not appear for a different session"
    )
    mock_continuity.get_context_block.assert_not_called()


@pytest.mark.asyncio
async def test_continuity_source_prefers_typed_brief_over_all_fallbacks():
    """
    THE PROOF TEST: typed brief beats legacy snapshot + startup recall + recency + ambient ALL AT ONCE.

    Setup:
    - mock memory.get_continuity_brief → "TYPED BRIEF SENTINEL"
    - continuity.latest.session_id MATCHES current session (legacy snapshot would fire)
    - get_ambient_context returns ambient items (ambient would fire)
    - memory.recall returns startup memories (startup recall would fire)
    - search_recent returns recency data (recency would fire)

    Assertions:
    - "TYPED BRIEF SENTINEL" IN prompt
    - "LEGACY SNAPSHOT SENTINEL" NOT in prompt
    - "## Recently (startup recall):" NOT in prompt
    - "RECENCY SENTINEL" NOT in prompt
    - "[Ambient cross-session context]" NOT in prompt
    """
    pipeline, adapter = make_pipeline()
    captured = _capture_llm(pipeline)

    # 1. Typed brief — the winner
    pipeline.memory.get_continuity_brief = AsyncMock(return_value="TYPED BRIEF SENTINEL")

    # 2. Legacy snapshot — same session, would normally fire
    inbound = make_inbound(user_id="proof_user", channel_id="ch-proof")
    session_key = pipeline._session_manager.session_id_for("proof_user", "ch-proof")
    mock_continuity = MagicMock()
    mock_continuity.latest = MagicMock()
    mock_continuity.latest.session_id = session_key   # matches — would fire without typed brief
    mock_continuity.get_context_block = MagicMock(return_value="LEGACY SNAPSHOT SENTINEL")
    pipeline.continuity = mock_continuity

    # 3. Ambient — would fire without typed brief
    pipeline.memory.get_ambient_context = AsyncMock(
        return_value=["AMBIENT DETAIL ITEM"]
    )

    # 4. Startup recall — first message for this session, would fire
    pipeline.memory.recall = AsyncMock(return_value=["STARTUP RECALL DETAIL"])

    # 5. Recency — enabled with sentinel content
    pipeline.config.recency_enabled = True
    recency_entry = MagicMock()
    recency_entry.content = "RECENCY SENTINEL"
    recency_entry.source = "ch-other"
    recency_entry.session_id = "other-sess"
    pipeline.memory.search_recent = MagicMock(return_value=[recency_entry])

    await pipeline.process(inbound, adapter)

    prompt_text = captured.get("prompt", "")

    # Typed brief must be present
    assert "TYPED BRIEF SENTINEL" in prompt_text, \
        "typed brief must appear in the system prompt"

    # Every old bailout path must be absent
    assert "LEGACY SNAPSHOT SENTINEL" not in prompt_text, \
        "legacy snapshot must be suppressed by typed brief"
    assert "## Recently (startup recall):" not in prompt_text, \
        "startup recall section must be suppressed by typed brief"
    assert "RECENCY SENTINEL" not in prompt_text, \
        "recency context must be suppressed by typed brief"
    assert "[Ambient cross-session context]" not in prompt_text, \
        "ambient fallback must be suppressed by typed brief"


# ---------------------------------------------------------------------------
# R3 additional tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_startup_recall_context_is_local_not_pipeline_global():
    """After v2.7 Step 6, pipeline must NOT store startup context as self._startup_context."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(return_value=["some memory"])

    inbound = make_inbound(user_id="u-local", channel_id="ch-local")
    await pipeline.process(inbound, adapter)

    assert not hasattr(pipeline, "_startup_context"), (
        "startup_context must be a local variable — never persisted on self"
    )


@pytest.mark.asyncio
async def test_typed_brief_suppresses_recency_injection():
    """When typed brief is present, recency context must NOT be injected."""
    pipeline, adapter = make_pipeline()
    captured = _capture_llm(pipeline)

    pipeline.memory.get_continuity_brief = AsyncMock(return_value="SOME TYPED BRIEF")
    pipeline.config.recency_enabled = True
    recency_entry = MagicMock()
    recency_entry.content = "RECENCY_DETAIL_TEXT"
    recency_entry.source = "ch-other"
    recency_entry.session_id = "other-sess"
    pipeline.memory.search_recent = MagicMock(return_value=[recency_entry])

    inbound = make_inbound(user_id="u-recency", channel_id="ch-recency")
    await pipeline.process(inbound, adapter)

    prompt_text = captured.get("prompt", "")
    assert "SOME TYPED BRIEF" in prompt_text, "typed brief must appear"
    assert "RECENCY_DETAIL_TEXT" not in prompt_text, (
        "recency detail must be suppressed when typed brief is present"
    )


def test_activity_feed_publish_and_list_for_identity(tmp_path):
    """Basic ActivityFeed round-trip: publish → list_for_identity returns the note."""
    feed = ActivityFeed(tmp_path)
    note = make_activity_note(identity_id="agent1", session_id="sess-x", content="did some work")
    feed.publish(note)

    results = feed.list_for_identity("agent1")
    assert len(results) == 1, "exactly one note should be returned"
    assert results[0].content == "did some work"
    assert results[0].session_id == "sess-x"


def test_ingest_turn_uses_turn_content_not_child_content(tmp_path):
    """
    update_memory_summary must receive the TURN entry's own content, not a
    decomposed child record. Child decomposition happens AFTER the ambient update.
    """
    store = MemorySystem(str(tmp_path))

    call_log: list[tuple[str, str]] = []
    mock_tracker = MagicMock()
    mock_tracker.update_memory_summary = MagicMock(
        side_effect=lambda sid, txt: call_log.append((sid, txt))
    )
    store._session_tracker = mock_tracker

    turn_content = "User: what is the capital of France?\nAssistant: Paris."
    store.ingest_turn(content=turn_content, session_id="sess-turn")

    assert len(call_log) == 1, "update_memory_summary must be called exactly once per turn"
    _, summary_text = call_log[0]

    # Must contain turn-level content (multi-line or at least meaningful)
    assert any(kw in summary_text for kw in ("France", "Paris", "what is", "capital")), (
        "ambient summary must reflect the turn's content"
    )
    # Must NOT be empty or a single-word child fragment
    assert len(summary_text) > 3, "ambient summary must not be a trivially short child snippet"


# ---------------------------------------------------------------------------
# R4 seam tests — exact shapes from PARSI doc
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ingest_does_not_publish_activity_when_turn_is_skipped(tmp_path):
    """When ingest_turn() returns None (deduped/filtered), must NOT save or publish."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    mock_store = MagicMock()
    mock_store.ingest_turn = MagicMock(return_value=None)
    mock_store.save = MagicMock()

    mem.publish_activity = AsyncMock()
    # Bypass the pre-filter so ingest_turn is actually reached
    mem._should_skip_ingest = MagicMock(return_value=False)

    with patch.object(mem, "_get_store", return_value=mock_store):
        await mem.ingest(
            "u1",
            "This is a normal user message that will pass the filter",
            "This is a normal response that will pass the filter",
            session_id="sess-skip",
        )

    mem.publish_activity.assert_not_awaited()
    mock_store.save.assert_not_called()


@pytest.mark.asyncio
async def test_ingest_publishes_activity_from_stored_turn_content(tmp_path):
    """ingest() must publish using created_entry.content, not the raw pre-store text."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    created_entry = MagicMock()
    created_entry.content = "User: hello\nAssistant: hi"

    mock_store = MagicMock()
    mock_store.ingest_turn = MagicMock(return_value=created_entry)
    mock_store.save = MagicMock()

    mem.publish_activity = AsyncMock()

    with patch.object(mem, "_get_store", return_value=mock_store):
        # Use sufficiently long strings to pass the _should_skip_ingest length guard (> 4 chars)
        await mem.ingest("u1", "hello there", "greetings back", session_id="sess-pub")

    mem.publish_activity.assert_awaited_once()
    call_kwargs = mem.publish_activity.call_args.kwargs
    assert call_kwargs.get("content") == "User: hello\nAssistant: hi", (
        "publish_activity must receive created_entry.content, not raw pre-store text"
    )
    assert call_kwargs.get("session_id") == "sess-pub"


@pytest.mark.asyncio
async def test_continuity_brief_reads_pending_tasks_from_session_tracker(tmp_path):
    """get_continuity_brief() must surface live pending_tasks from SessionTracker."""

    @dataclass
    class DummyState:
        status: str = "active"
        pending_tasks: dict = dc_field(
            default_factory=lambda: {"subagent:research": 123.0}
        )

    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    mock_tracker = MagicMock()
    mock_tracker.get_session_state = MagicMock(return_value=DummyState())

    mock_store = MagicMock()
    mock_store._session_tracker = mock_tracker
    mock_store.memories = []
    mock_store.read_activity = MagicMock(return_value=[])

    mem.get_session = AsyncMock(return_value={})

    with patch.object(mem, "_get_store", return_value=mock_store):
        brief = await mem.get_continuity_brief("u1", "sess-task")

    assert "Session status: active" in brief, \
        "brief must include session status from live SessionTracker"
    assert "Open tasks: subagent:research" in brief, \
        "brief must include pending_tasks keys from live SessionTracker"


# ---------------------------------------------------------------------------
# Integration tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_publish_activity_skips_blank_session(tmp_path):
    """publish_activity with session_id='' must skip without calling store."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    mock_store = MagicMock()
    mock_store.publish_activity = MagicMock()

    with patch.object(mem, "_get_store", return_value=mock_store):
        await mem.publish_activity("u1", session_id="", content="some content")

    mock_store.publish_activity.assert_not_called()


@pytest.mark.asyncio
async def test_two_sessions_startup_recall_does_not_contaminate():
    """
    Session B's prompt must NOT contain Session A's startup recall content.
    Proves startup_context is a local variable — not shared state across calls.
    """
    pipeline, adapter = make_pipeline()
    # Disable per_turn_recall so only startup recall calls fire
    pipeline.config.per_turn_recall = False

    # Each call returns session-specific content
    pipeline.memory.recall = AsyncMock(
        side_effect=[
            ["SESSION_A_ONLY_CONTENT"],   # startup recall for session A
            ["SESSION_B_CONTENT"],         # startup recall for session B
        ]
    )

    prompts: list[str] = []

    async def capture(messages, system, **kwargs):
        prompts.append(system)
        return LLMResponse(
            content="ok", model="test-model", input_tokens=1, output_tokens=1, cost_usd=0.0
        )

    pipeline.llm.complete = AsyncMock(side_effect=capture)

    # Session A — different channel creates a distinct session key
    await pipeline.process(make_inbound(user_id="user1", channel_id="ch-sessA"), adapter)
    # Session B — different channel, different session key, new startup recall
    await pipeline.process(make_inbound(user_id="user1", channel_id="ch-sessB"), adapter)

    assert len(prompts) == 2, "expected exactly two processed messages"
    prompt_b = prompts[1]

    assert "SESSION_A_ONLY_CONTENT" not in prompt_b, (
        "Session B must not contain Session A's startup recall content — "
        "startup_context must be a pure local variable with no cross-session bleed"
    )
    # Positive assertion: Session B's prompt must be non-empty and contain its own recall
    assert prompt_b, "Session B prompt must be non-empty"
    assert "SESSION_B_CONTENT" in prompt_b, (
        "Session B prompt must include Session B's own startup recall content"
    )


@pytest.mark.asyncio
async def test_get_continuity_brief_returns_empty_for_sparse_store(tmp_path):
    """When no typed records exist, get_continuity_brief must return ''."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    mock_store = MagicMock()
    mock_store.memories = []
    mock_store.read_activity = MagicMock(return_value=[])
    mock_store._session_tracker = None

    mem.get_session = AsyncMock(return_value={})

    with patch.object(mem, "_get_store", return_value=mock_store):
        brief = await mem.get_continuity_brief("u1", "sess-sparse")

    assert brief == "", f"expected empty brief for sparse store, got: {brief!r}"


@pytest.mark.asyncio
async def test_get_continuity_brief_token_budget_enforced(tmp_path):
    """get_continuity_brief must truncate output to ≤ 2000 characters."""
    mem = BotMemory(store_path=str(tmp_path), agent_name="bot")

    # 20 activity notes × 300 chars each = 6000 chars of activity alone
    long_notes = []
    for i in range(20):
        note = MagicMock()
        note.content = f"activity-item-{i}: " + ("x" * 280)
        long_notes.append(note)

    mock_store = MagicMock()
    mock_store.memories = []
    mock_store.read_activity = MagicMock(return_value=long_notes)
    mock_store._session_tracker = None

    mem.get_session = AsyncMock(return_value={})

    with patch.object(mem, "_get_store", return_value=mock_store):
        brief = await mem.get_continuity_brief("u1", "sess-budget")

    assert len(brief) <= 2000, (
        f"brief must be ≤ 2000 chars (token budget); got {len(brief)}"
    )


def test_activity_feed_skips_expired_notes(tmp_path):
    """Notes older than max_age_hours must not be returned by list_for_identity."""
    feed = ActivityFeed(tmp_path)

    old_ts = (datetime.now(timezone.utc) - timedelta(hours=10)).isoformat()
    old_note = ActivityNote(
        note_id="old-1",
        identity_id="agent1",
        body_id="agent1",
        session_id="sess-old",
        content="this is stale content",
        created_at=old_ts,
        tags=[],
    )
    feed.publish(old_note)

    results = feed.list_for_identity("agent1", max_age_hours=1.0)
    assert results == [], "expired notes must be excluded by max_age_hours filter"


def test_activity_feed_collapses_to_latest_per_session(tmp_path):
    """Two notes for the same session_id → only the latest note is returned."""
    feed = ActivityFeed(tmp_path)

    now = datetime.now(timezone.utc)
    earlier_ts = (now - timedelta(minutes=30)).isoformat()
    later_ts = now.isoformat()

    note_early = ActivityNote(
        note_id="n1",
        identity_id="agent1",
        body_id="agent1",
        session_id="same-sess",
        content="early content",
        created_at=earlier_ts,
        tags=[],
    )
    note_late = ActivityNote(
        note_id="n2",
        identity_id="agent1",
        body_id="agent1",
        session_id="same-sess",
        content="late content",
        created_at=later_ts,
        tags=[],
    )
    feed.publish(note_early)
    feed.publish(note_late)

    results = feed.list_for_identity("agent1")
    assert len(results) == 1, "feed must collapse multiple notes from same session to one"
    assert results[0].content == "late content", (
        "the collapsed result must be the LATEST note for that session"
    )


def test_ambient_awareness_live_with_session_awareness_on(tmp_path):
    """
    With a real MemorySystem and a mocked session_tracker,
    ingest_turn() followed by get_ambient_context() must return non-empty results.
    """
    store = MemorySystem(str(tmp_path))

    # Mock session_tracker so update_memory_summary stores something retrievable
    summaries: dict[str, str] = {}

    mock_tracker = MagicMock()
    mock_tracker.update_memory_summary = MagicMock(
        side_effect=lambda sid, txt: summaries.update({sid: txt})
    )
    # get_other_sessions returns a session other than the current one
    mock_tracker.get_other_sessions = MagicMock(return_value=["sess-other"])
    mock_tracker.get_memory_summary = MagicMock(
        side_effect=lambda sid: summaries.get(sid, "")
    )
    store._session_tracker = mock_tracker

    # Ingest a turn into "sess-other" so there's ambient content
    store.ingest_turn(
        content="User: what is the weather?\nAssistant: It is sunny today.",
        session_id="sess-other",
    )

    # get_ambient_context for a *different* session should surface sess-other's summary
    if hasattr(store, "get_ambient_context"):
        result = store.get_ambient_context("sess-current", limit=5)
        # The ambient context must be non-empty since sess-other has content
        assert result, (
            "get_ambient_context must return non-empty results when another session has ingested turns"
        )
    else:
        # If get_ambient_context is not on the store directly, verify via BotMemory
        mem = BotMemory(store_path=str(tmp_path), agent_name="bot")
        with patch.object(mem, "_get_store", return_value=store):
            import asyncio
            result = asyncio.get_event_loop().run_until_complete(
                mem.get_ambient_context("u1", "sess-current")
            )
        assert result, (
            "get_ambient_context must return non-empty results when another session has ingested turns"
        )


# ---------------------------------------------------------------------------
# v2.7.1 fixes — 3 new tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_continuity_brief_does_not_mix_typed_records_from_other_agent_shared_store(tmp_path):
    shared_root = str(tmp_path)
    agent_a = BotMemory(store_path=shared_root, agent_name="AgentA")
    agent_b = BotMemory(store_path=shared_root, agent_name="AgentB")
    await agent_a.ingest(
        "user1",
        "I prefer dark mode for dashboards",
        "Okay, I will remember that",
        session_id="sess-a",
    )
    brief_b = await agent_b.get_continuity_brief("user1", "sess-b")
    assert "dark mode" not in brief_b, (
        "AgentB continuity brief must not surface AgentA's typed preferences "
        "when both agents share the same user store"
    )


def test_recent_memory_type_respects_created_timestamp_and_age(tmp_path):
    from parsica_memory.core_v4 import MemoryEntry
    from datetime import datetime, timedelta, timezone
    mem = BotMemory(store_path=str(tmp_path), agent_name="AgentB")

    old_entry = MemoryEntry("old pref", "", 0, "general")
    old_entry.memory_type = "preference"
    old_entry.agent_id = "AgentB"
    old_entry.session_id = "s1"
    old_entry.created = (datetime.now(timezone.utc) - timedelta(days=400)).isoformat()
    old_entry.tags = ["identity:AgentB:user1"]

    new_entry = MemoryEntry("new pref", "", 0, "general")
    new_entry.memory_type = "preference"
    new_entry.agent_id = "AgentB"
    new_entry.session_id = "s2"
    new_entry.created = datetime.now(timezone.utc).isoformat()
    new_entry.tags = ["identity:AgentB:user1"]

    fake_store = MagicMock()
    fake_store.memories = [old_entry, new_entry]
    fake_store.agent_name = "AgentB"

    with patch.object(mem, "_get_store", return_value=fake_store):
        vals = mem._recent_memory_type("user1", "preference", limit=5)

    assert vals == ["new pref"]


@pytest.mark.asyncio
async def test_pipeline_prefers_real_assembled_continuity_brief_over_fallbacks(tmp_path):
    pipeline, adapter = make_pipeline()
    real_memory = BotMemory(store_path=str(tmp_path), agent_name="AgentX")
    pipeline.memory = real_memory
    captured = {}

    async def capture_complete(messages, system, **kw):
        from antaris_agent.llm.base import LLMResponse
        captured["prompt"] = system or ""
        return LLMResponse(content="ok", model="test-model", input_tokens=5, output_tokens=5, cost_usd=0.0)

    pipeline.llm.complete = AsyncMock(side_effect=capture_complete)

    session_key = None
    for k in list(pipeline._startup_recalled_sessions.keys())[:0]:
        session_key = k
    if not session_key:
        try:
            from antaris_agent.core.pipeline import _session_key_for
            session_key = _session_key_for("u1", "ch-real", pipeline.config)
        except Exception:
            session_key = "u1:ch-real"

    await real_memory.ingest(
        "u1",
        "I prefer dark mode for dashboards",
        "Got it, I will remember that",
        session_id=session_key or "sess-real",
    )
    # v2.8.2: run background tasks so enriched content is available for brief assembly
    real_memory.run_background_tasks(max_tasks_per_store=5, worker_id="test-w-brief")

    mock_continuity = MagicMock()
    mock_continuity.latest = MagicMock()
    mock_continuity.latest.session_id = session_key or "sess-real"
    mock_continuity.get_context_block = MagicMock(return_value="LEGACY SNAPSHOT SENTINEL")
    pipeline.continuity = mock_continuity

    await pipeline.process(make_inbound(user_id="u1", channel_id="ch-real", text="what do you know about me?"), adapter)

    prompt = captured.get("prompt", "")
    assert "LEGACY SNAPSHOT SENTINEL" not in prompt
    assert "RECENCY SENTINEL" not in prompt
    assert "AMBIENT SENTINEL" not in prompt


def test_activity_feed_accepts_naive_iso_timestamp(tmp_path):
    """ActivityFeed must not crash when note has naive (no-tz) ISO timestamp."""
    import json
    from datetime import datetime
    from pathlib import Path
    from parsica_memory.activity_feed import ActivityFeed

    feed = ActivityFeed(tmp_path)
    path = Path(tmp_path) / "_meta" / "activity_feed.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    # Use current time as naive ISO string (no tzinfo suffix) — must not raise
    naive_ts = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    path.write_text(
        json.dumps({
            "note_id": "n1",
            "identity_id": "id1",
            "body_id": "body1",
            "session_id": "sess1",
            "content": "hello",
            "created_at": naive_ts,  # naive — no timezone
            "tags": [],
        }) + "\n",
        encoding="utf-8",
    )

    # Use max_age_hours=24 to avoid tz-offset edge where naive local time
    # parsed as UTC might appear older than the 6h default window
    notes = feed.list_for_identity("id1", max_age_hours=24)
    assert len(notes) == 1
    assert notes[0].content == "hello"


def test_legacy_record_kind_knowledge_only_filter_does_not_raise(tmp_path):
    """_is_cross_session_knowledge_entry must not raise NameError for legacy records."""
    from parsica_memory.core_v4 import MemorySystem

    mem = MemorySystem(str(tmp_path), agent_name="agent-x", use_sharding=False, use_indexing=False)

    from parsica_memory.entry import MemoryEntry
    entry = MemoryEntry("legacy fact", source="test", line=1, category="general")
    entry.record_kind = "fact"
    entry.cross_session_eligible = None
    entry.session_id = "s1"
    entry.agent_id = "agent-x"
    mem.memories.append(entry)

    results = mem.search(
        "legacy",
        session_id="s2",
        cross_session_recall="knowledge_only",
        read_only=True,
    )

    assert any(getattr(r, "content", "") == "legacy fact" for r in results)
