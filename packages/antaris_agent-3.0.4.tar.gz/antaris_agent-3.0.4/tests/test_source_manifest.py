"""Tests for parsica_memory.source_manifest - v3.0.4-r2 (Eye R1 architectural fixes).

Covers all 4 architectural P0s plus R1 hardening:
  - A-01 identity/body scoping
  - A-02 tombstone protocol
  - A-03 source allow-list
  - A-04 HMAC integrity
  - R1: tuple keys, surrogates, hash-suffixed clamps, retry queue, read-only view
"""
from __future__ import annotations

import concurrent.futures
import hashlib
import hmac
import json
import multiprocessing
import os
import threading
import time
from pathlib import Path

import pytest

from parsica_memory.source_manifest import (
    LEGACY_BODY_SENTINEL,
    LEGACY_IDENTITY_SENTINEL,
    LEGACY_SOURCE_SENTINEL,
    MANIFEST_PATH,
    ManifestIntegrityError,
    ManifestLockTimeoutError,
    NATIVE_SOURCE_TYPES,
    SCHEMA_VERSION,
    SECRET_PATH,
    SourceManifest,
    TAIL_ANCHOR_PATH,
    TOMBSTONE_REASONS,
    _MAX_SOURCE_ID_LEN,
    _MAX_SOURCE_TYPE_LEN,
    _has_disallowed_char,
    _canonical_payload,
)


# Use "moro" identity + "default" body in most tests - they're short, legible,
# and pass the NATIVE_SOURCE_TYPES allow-list for the source field.
I = "moro@antarisanalytics"
B = "moro:default"


def _lock_holder_process(workspace: str, hold_seconds: float, queue) -> None:
    manifest = SourceManifest(workspace, lock_timeout_seconds=2.0)
    try:
        with manifest._with_workspace_lock():
            queue.put("locked")
            time.sleep(hold_seconds)
    except Exception as exc:  # pragma: no cover
        queue.put({"error": repr(exc)})


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    # Disable HMAC for most tests so we aren't provisioning a secret every run.
    # The dedicated HMAC suite flips this off.
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    return str(tmp_path)


@pytest.fixture
def manifest(workspace):
    return SourceManifest(workspace)


def add(m, st, sid, rid, *, ident=I, body=B, scope=""):
    """Compact add() helper that plumbs identity/body scope."""
    return m.add(st, sid, rid, identity_id=ident, body_id=body, retrieval_scope=scope)


def lookup(m, st, sid, *, ident=I, body=None):
    return m.lookup(st, sid, identity_id=ident, body_id=body)


# ── Basic API contract ──────────────────────────────────────────────────────

def test_empty_manifest_returns_empty(manifest):
    assert lookup(manifest, "discord", "1234") == []
    assert manifest.all_sources() == []
    stats = manifest.stats()
    assert stats["source_count"] == 0
    assert stats["total_records"] == 0
    assert stats["tombstoned_records"] == 0


def test_add_basic(manifest):
    assert add(manifest, "discord", "channel:1234", "hash_abc") is True
    assert lookup(manifest, "discord", "channel:1234", body=B) == ["hash_abc"]


def test_add_idempotent(manifest):
    assert add(manifest, "discord", "ch", "h1") is True
    assert add(manifest, "discord", "ch", "h1") is False
    assert lookup(manifest, "discord", "ch", body=B) == ["h1"]


def test_multiple_records_per_source(manifest):
    add(manifest, "discord", "ch1", "h1")
    add(manifest, "discord", "ch1", "h2")
    add(manifest, "discord", "ch1", "h3")
    assert lookup(manifest, "discord", "ch1", body=B) == ["h1", "h2", "h3"]


def test_lookup_returns_copy_not_reference(manifest):
    add(manifest, "discord", "ch", "h1")
    r = lookup(manifest, "discord", "ch", body=B)
    r.append("POISON")
    assert lookup(manifest, "discord", "ch", body=B) == ["h1"]


# ── A-01 Identity/body scoping ──────────────────────────────────────────────

def test_scope_required_on_add(manifest):
    with pytest.raises(TypeError):
        manifest.add("discord", "ch", "h1")  # missing identity_id, body_id


def test_blank_identity_id_rejected(manifest):
    with pytest.raises(ValueError, match="identity_id must not be empty"):
        manifest.add("discord", "ch", "h1", identity_id="", body_id=B)


def test_blank_body_id_rejected(manifest):
    with pytest.raises(ValueError, match="body_id must not be empty"):
        manifest.add("discord", "ch", "h1", identity_id=I, body_id="")


def test_cross_identity_lookup_returns_empty(manifest):
    add(manifest, "discord", "ch", "h1", ident="alice", body=B)
    # Lookup in Bob's identity must never see Alice's record.
    assert lookup(manifest, "discord", "ch", ident="bob", body=B) == []
    # Unqualified (no body) also fails-closed on identity.
    assert lookup(manifest, "discord", "ch", ident="bob") == []


def test_cross_body_lookup_within_same_identity(manifest):
    add(manifest, "discord", "ch", "h1", ident="alice", body="body_a")
    add(manifest, "discord", "ch", "h2", ident="alice", body="body_b")
    # Explicit body - strict match
    assert lookup(manifest, "discord", "ch", ident="alice", body="body_a") == ["h1"]
    assert lookup(manifest, "discord", "ch", ident="alice", body="body_b") == ["h2"]
    # body=None - folds across bodies within the identity
    assert sorted(lookup(manifest, "discord", "ch", ident="alice")) == ["h1", "h2"]


def test_lookup_rejects_blank_identity(manifest):
    add(manifest, "discord", "ch", "h1")
    # Blank identity_id fails closed
    assert manifest.lookup("discord", "ch", identity_id="") == []


def test_legacy_records_only_via_explicit_sentinel(manifest):
    # Write under legacy sentinel (the only way "unknown" records should land)
    manifest.add("discord", "ch", "h_legacy",
                 identity_id=LEGACY_IDENTITY_SENTINEL,
                 body_id=LEGACY_BODY_SENTINEL)
    # Normal caller scope gets nothing
    assert lookup(manifest, "discord", "ch", ident="real_user", body="real_body") == []
    # Opt-in to legacy sweep via sentinel - gets the record
    assert lookup(manifest, "discord", "ch",
                  ident=LEGACY_IDENTITY_SENTINEL, body=LEGACY_BODY_SENTINEL) == ["h_legacy"]


def test_lookup_scoped_composes_with_ScopePolicy(manifest):
    # Build a minimal ScopePolicy-like object
    class SP:
        identity_id = "alice"
        body_id = "body_a"
        allowed_scopes = None
    add(manifest, "discord", "ch", "h1", ident="alice", body="body_a", scope="identity_durable")
    add(manifest, "discord", "ch", "h2", ident="alice", body="body_b", scope="identity_durable")
    # Scoped by body_a - only h1
    assert manifest.lookup_scoped("discord", "ch", SP()) == ["h1"]


def test_lookup_scoped_blank_identity_fails_closed(manifest):
    class SP:
        identity_id = ""
        body_id = ""
        allowed_scopes = None
    add(manifest, "discord", "ch", "h1")
    assert manifest.lookup_scoped("discord", "ch", SP()) == []


def test_lookup_scoped_with_none_policy(manifest):
    add(manifest, "discord", "ch", "h1")
    assert manifest.lookup_scoped("discord", "ch", None) == []


# ── A-02 Tombstone protocol ─────────────────────────────────────────────────

def test_tombstone_hides_record(manifest):
    add(manifest, "discord", "ch", "h1")
    assert lookup(manifest, "discord", "ch", body=B) == ["h1"]
    manifest.tombstone("h1", "forgotten", identity_id=I)
    assert lookup(manifest, "discord", "ch", body=B) == []


def test_tombstone_unknown_record_no_op(manifest):
    # Tombstoning an unknown record is valid and returns 1 (it's tombstoned now)
    count = manifest.tombstone("never_seen", "forgotten", identity_id=I)
    assert count == 1
    # Re-tombstone returns 0
    assert manifest.tombstone("never_seen", "forgotten", identity_id=I) == 0


def test_tombstone_idempotent(manifest):
    add(manifest, "discord", "ch", "h1")
    assert manifest.tombstone("h1", "forgotten", identity_id=I) == 1
    assert manifest.tombstone("h1", "forgotten", identity_id=I) == 0


def test_tombstone_scoped_by_identity(manifest):
    # Same hash in two identities - tombstoning in one doesn't affect the other
    add(manifest, "discord", "ch", "h1", ident="alice", body="b")
    add(manifest, "discord", "ch", "h1", ident="bob", body="b")
    manifest.tombstone("h1", "forgotten", identity_id="alice")
    assert lookup(manifest, "discord", "ch", ident="alice", body="b") == []
    assert lookup(manifest, "discord", "ch", ident="bob", body="b") == ["h1"]


def test_tombstone_rejects_unknown_reason(manifest):
    with pytest.raises(ValueError, match="reason="):
        manifest.tombstone("h1", "arbitrary", identity_id=I)


def test_deprecated_reason_is_soft(manifest):
    """'deprecated' is a soft signal - record is NOT hidden from lookup."""
    add(manifest, "discord", "ch", "h1")
    manifest.tombstone("h1", "deprecated", identity_id=I)
    # Still findable - downstream consumers handle weighting.
    assert lookup(manifest, "discord", "ch", body=B) == ["h1"]


def test_tombstones_persist_across_reload(workspace):
    m1 = SourceManifest(workspace)
    add(m1, "discord", "ch", "h1")
    m1.tombstone("h1", "forgotten", identity_id=I)
    m2 = SourceManifest(workspace)
    assert lookup(m2, "discord", "ch", body=B) == []


def test_stats_reports_tombstoned_count(manifest):
    add(manifest, "discord", "ch", "h1")
    add(manifest, "discord", "ch", "h2")
    manifest.tombstone("h1", "forgotten", identity_id=I)
    assert manifest.stats()["tombstoned_records"] == 1


# ── A-03 Source allow-list ──────────────────────────────────────────────────

def test_unknown_source_type_rejected(manifest):
    with pytest.raises(ValueError, match="NATIVE_SOURCE_TYPES"):
        manifest.add("malicious_type", "ch", "h1", identity_id=I, body_id=B)


def test_all_native_types_accepted(manifest):
    # Spot-check some expected native types
    for st in ["discord", "file", "web", "imported_pack", "pipeline:enriched"]:
        assert st in NATIVE_SOURCE_TYPES
        add(manifest, st, f"id-{st}", f"h-{st}")


def test_imported_pack_is_native(manifest):
    """Pack import path must be able to stamp source='imported_pack'."""
    assert "imported_pack" in NATIVE_SOURCE_TYPES
    add(manifest, "imported_pack", "pack://xyz", "h_imported")
    assert lookup(manifest, "imported_pack", "pack://xyz", body=B) == ["h_imported"]


def test_legacy_sentinels_in_allow_list(manifest):
    assert LEGACY_SOURCE_SENTINEL in NATIVE_SOURCE_TYPES
    # Can be used for migration path
    add(manifest, LEGACY_SOURCE_SENTINEL, "weird_old_src", "h1")


# ── R1 hardening: tuple keys, surrogates, clamps ────────────────────────────

def test_colon_separator_no_collision(manifest):
    # pipeline::enriched and pipeline/enriched::ch must not collide
    add(manifest, "pipeline:enriched", "msg_1", "h1")
    add(manifest, "pipeline", "enriched:msg_1", "h2")
    assert lookup(manifest, "pipeline:enriched", "msg_1", body=B) == ["h1"]
    assert lookup(manifest, "pipeline", "enriched:msg_1", body=B) == ["h2"]


def test_rejects_newline_injection(manifest):
    with pytest.raises(ValueError, match="disallowed codepoints"):
        add(manifest, "discord", "ch\n{\"evil\":1}", "h1")


def test_rejects_lone_surrogates(manifest):
    with pytest.raises(ValueError, match="disallowed codepoints"):
        add(manifest, "discord", "ch" + "\ud800", "h1")


def test_rejects_line_separators(manifest):
    with pytest.raises(ValueError, match="disallowed codepoints"):
        add(manifest, "discord", "line_a\u2028line_b", "h1")


def test_accepts_unicode_emoji_and_cjk(manifest):
    add(manifest, "discord", "general-チャンネル-🎯", "h1")
    assert lookup(manifest, "discord", "general-チャンネル-🎯", body=B) == ["h1"]


def test_clamp_avoids_aliasing_distinct_long_sources(manifest):
    a = "A" * _MAX_SOURCE_ID_LEN + "_alpha"
    b = "A" * _MAX_SOURCE_ID_LEN + "_beta"
    add(manifest, "web", a, "h_a")
    add(manifest, "web", b, "h_b")
    assert lookup(manifest, "web", a, body=B) == ["h_a"]
    assert lookup(manifest, "web", b, body=B) == ["h_b"]


def test_add_rejects_empty_fields(manifest):
    with pytest.raises(ValueError, match="source_type must not be empty"):
        manifest.add("", "ch", "h1", identity_id=I, body_id=B)
    with pytest.raises(ValueError, match="source_id must not be empty"):
        manifest.add("discord", "", "h1", identity_id=I, body_id=B)
    with pytest.raises(ValueError, match="record_id must not be empty"):
        manifest.add("discord", "ch", "", identity_id=I, body_id=B)


# ── Persistence + reload ────────────────────────────────────────────────────

def test_persist_to_jsonl(workspace, manifest):
    add(manifest, "discord", "ch", "h1")
    path = Path(workspace) / MANIFEST_PATH
    assert path.exists()
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    rec = json.loads(lines[0])
    assert rec["schema"] == SCHEMA_VERSION
    assert rec["op"] == "add"
    assert rec["identity_id"] == I
    assert rec["body_id"] == B


def test_reload_preserves_index(workspace):
    m1 = SourceManifest(workspace)
    add(m1, "discord", "ch", "h1")
    m2 = SourceManifest(workspace)
    assert lookup(m2, "discord", "ch", body=B) == ["h1"]


def test_legacy_schema_1_record_gets_sentinels(workspace):
    """A schema=1 record (R1 format) has no identity/body - must land under sentinels."""
    path = Path(workspace) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": 1,
            "source_type": "discord",
            "source_id": "ch",
            "record_id": "h_old",
        }) + "\n")
    m = SourceManifest(str(workspace))
    # Not findable under real scope
    assert lookup(m, "discord", "ch", ident="real", body="real") == []
    # Findable under sentinels
    assert lookup(m, "discord", "ch",
                  ident=LEGACY_IDENTITY_SENTINEL,
                  body=LEGACY_BODY_SENTINEL) == ["h_old"]
    assert m.stats()["legacy_lines_migrated"] >= 1


def test_legacy_unknown_source_type_quarantined(workspace):
    """R2: legacy line with unallowed source_type maps to LEGACY_SOURCE_SENTINEL."""
    path = Path(workspace) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": 1,
            "source_type": "malicious_type",
            "source_id": "ch",
            "record_id": "h_bad",
            "identity_id": I,
            "body_id": B,
        }) + "\n")
    m = SourceManifest(str(workspace))
    # Not findable under the attacker's claim
    assert lookup(m, "malicious_type", "ch", body=B) == []
    # Findable in the quarantine bucket
    assert lookup(m, LEGACY_SOURCE_SENTINEL, "ch", body=B) == ["h_bad"]


def test_reload_skips_future_schema(workspace):
    path = Path(workspace) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": 999, "source_type": "discord",
            "source_id": "future", "record_id": "h_f",
        }) + "\n")
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "source_type": "discord",
            "source_id": "now", "record_id": "h_n",
            "identity_id": I, "body_id": B,
        }) + "\n")
    m = SourceManifest(str(workspace))
    assert lookup(m, "discord", "future", body=B) == []
    assert lookup(m, "discord", "now", body=B) == ["h_n"]


# ── A-04 HMAC integrity (run with HMAC enabled) ─────────────────────────────


@pytest.fixture
def workspace_hmac(tmp_path, monkeypatch):
    """Same as workspace fixture but with HMAC ENABLED."""
    monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
    return str(tmp_path)


@pytest.fixture
def workspace_hmac_adopt_legacy(tmp_path, monkeypatch):
    """Eye R3.1 F-R3-04: tests that simulate a pre-existing legacy
    unsealed workspace must opt into auto-anchor via the
    PARSICA_MANIFEST_ADOPT_LEGACY env var (the sanctioned operator
    path). Fresh-secret + pre-existing unsealed lines without this
    flag is the attacker-plant scenario and is correctly refused.
    """
    monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
    monkeypatch.setenv("PARSICA_MANIFEST_ADOPT_LEGACY", "1")
    return str(tmp_path)


def test_hmac_secret_auto_provisioned(workspace_hmac):
    m = SourceManifest(workspace_hmac)
    add(m, "discord", "ch", "h1")
    secret_path = Path(workspace_hmac) / SECRET_PATH
    assert secret_path.exists()
    # 0600 permissions (best-effort on platforms that honor it)
    if os.name == "posix":
        mode = os.stat(secret_path).st_mode & 0o777
        assert mode == 0o600


def test_hmac_sealed_lines_verify_on_reload(workspace_hmac):
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "ch", "h1")
    add(m1, "discord", "ch", "h2")
    # Fresh instance loads and verifies the chain
    m2 = SourceManifest(workspace_hmac)
    assert sorted(lookup(m2, "discord", "ch", body=B)) == ["h1", "h2"]
    h = m2.health()
    assert h["integrity"] == "ok"
    assert h["hmac"] == "enabled"


def test_hmac_tamper_detected(workspace_hmac):
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "ch", "h_good")
    # Tamper: inject a line that claims to be sealed but isn't
    path = Path(workspace_hmac) / MANIFEST_PATH
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "evil",
            "record_id": "h_evil",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
            "seq": 42, "prev_seal": "deadbeef" * 8,
            "seal": "00" * 32,  # bogus seal
        }) + "\n")
    m2 = SourceManifest(workspace_hmac)
    # Eye R4.1 Cluster A (P0-5): the integrity gate refuses reads on
    # ``chain_broken`` to prevent returning adversary-controlled record
    # ids through a poisoned chain. On ``degraded`` (soft state) reads
    # are still permitted. Probe health() first (always ungated) to
    # route the assertion.
    h = m2.health()
    assert h["integrity"] in ("chain_broken", "degraded")
    assert h["quarantined_lines"] >= 1
    if h["integrity"] == "chain_broken":
        with pytest.raises(ManifestIntegrityError):
            lookup(m2, "discord", "ch", body=B)
    else:
        # ``degraded`` still permits reads. Good line survives;
        # tampered line rejected by the line-level chain verifier.
        assert lookup(m2, "discord", "ch", body=B) == ["h_good"]
        assert lookup(m2, "discord", "evil", body=B) == []


def test_hmac_legacy_unsealed_prefix_anchored_on_first_load(workspace_hmac_adopt_legacy):
    """Legacy unsealed lines should load, and a one-shot legacy_seal should
    be written so subsequent loads don't re-migrate. Eye R3.1 F-R3-04
    requires explicit ADOPT_LEGACY opt-in for first-boot auto-anchor."""
    workspace_hmac = workspace_hmac_adopt_legacy
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        # Two legacy unsealed lines (no seal field)
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy1",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy2",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    m1 = SourceManifest(workspace_hmac)
    assert sorted(lookup(m1, "discord", "ch", body=B)) == ["h_legacy1", "h_legacy2"]
    h = m1.health()
    assert h["integrity"] == "ok"
    assert h["legacy_lines_migrated"] == 2
    # Second load should see the legacy_seal anchor and not re-migrate
    m2 = SourceManifest(workspace_hmac)
    h2 = m2.health()
    assert h2["integrity"] == "ok"


def test_hmac_disabled_flag_visible_in_health(workspace):
    # workspace fixture sets PARSICA_MANIFEST_DEV_NO_HMAC=1
    # R4.1 Cluster B (P2-6): ``health()["hmac"]`` now emits the typed
    # ``_HmacStatus`` value. The env-var opt-out reports
    # ``disabled_by_env`` (distinguishable from tamper/corruption
    # conditions which report ``disabled_by_secret_corrupt`` etc.).
    m = SourceManifest(workspace)
    assert m.health()["hmac"] == "disabled_by_env"


def test_hmac_legacy_migration_then_write_then_reload_stays_ok(workspace_hmac_adopt_legacy):
    """Eye R2 P1-H1 regression: a workspace that migrates legacy lines,
    then accepts a new sealed add, must still report integrity=ok on
    reload. Previously the anchor wrote next_seq=0 but the in-memory
    _next_seq advanced to 1, so reload saw a seq mismatch on the first
    post-migration record and went into chain_broken permanently.

    Eye R3.1 F-R3-04: legitimate legacy migration requires ADOPT_LEGACY."""
    workspace_hmac = workspace_hmac_adopt_legacy
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    # First boot: migrate + anchor legacy prefix.
    m1 = SourceManifest(workspace_hmac)
    assert m1.health()["integrity"] == "ok"
    # Write a new sealed record.
    add(m1, "discord", "ch", "h_new")
    # Reload and confirm chain survived.
    m2 = SourceManifest(workspace_hmac)
    h2 = m2.health()
    assert h2["integrity"] == "ok", (
        f"R2 legacy-anchor chain must survive reload after post-migration write; got {h2}"
    )
    assert sorted(lookup(m2, "discord", "ch", body=B)) == ["h_legacy", "h_new"]


# ── Public view is read-only ────────────────────────────────────────────────

def test_public_view_has_no_add_or_tombstone(manifest):
    view = manifest.view()
    assert hasattr(view, "lookup")
    assert hasattr(view, "lookup_scoped")
    assert hasattr(view, "all_sources")
    assert hasattr(view, "stats")
    assert hasattr(view, "health")
    assert not hasattr(view, "add"), "view must not expose write methods"
    assert not hasattr(view, "tombstone"), "view must not expose write methods"


def test_ms_source_manifest_returns_view(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    from parsica_memory.core_v4 import MemorySystemV4
    ms = MemorySystemV4(workspace=str(tmp_path), agent_name="t",
                       storage_backend="segments")
    view = ms.source_manifest
    assert not hasattr(view, "add")


def test_ms_manifest_private_attribute_is_not_traversable(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    from parsica_memory.core_v4 import MemorySystemV4
    ms = MemorySystemV4(workspace=str(tmp_path), agent_name="t",
                       storage_backend="segments")
    with pytest.raises(AttributeError):
        getattr(ms, "_source_manifest")


def test_ms_manifest_capability_grants_access(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    from parsica_memory.core_v4 import MemorySystemV4
    ms = MemorySystemV4(workspace=str(tmp_path), agent_name="t",
                       storage_backend="segments")
    cap = ms.internal_manifest_capability()
    manifest = ms.manifest(cap)
    assert manifest is not None
    assert manifest.health()["integrity"] in {"fresh", "ok"}


def test_ms_manifest_rejects_wrong_capability(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    from parsica_memory.core_v4 import MemorySystemV4, ManifestCapability
    ms = MemorySystemV4(workspace=str(tmp_path), agent_name="t",
                       storage_backend="segments")
    with pytest.raises(PermissionError):
        ms.manifest(ManifestCapability("wrong"))


# ── End-to-end: MemorySystemV4 ingest paths ─────────────────────────────────


@pytest.fixture
def ms(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    from parsica_memory.core_v4 import MemorySystemV4
    return MemorySystemV4(workspace=str(tmp_path), agent_name="t",
                         storage_backend="segments")


def test_ingest_registers_provenance(ms):
    ms.ingest(
        "This is a qualifying long-enough content line for the ingest path.",
        source="discord", source_channel="channel:123",
    )
    # Legacy identity/body fall back to sentinels because entry has none
    records = ms.source_manifest.lookup(
        "discord", "channel:123",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert len(records) >= 1


def test_ingest_without_external_id_skips_manifest(ms):
    ms.ingest(
        "This is a qualifying long-enough content line for the ingest path.",
        source="inline",  # no source_url/source_channel
    )
    assert ms.source_stats()["source_count"] == 0


def test_ingest_with_unknown_source_is_fail_closed(ms):
    """Eye R2 F-R2-03: an unmapped source kwarg (e.g. 'custom_thing')
    must NOT silently land in the manifest as the 'unknown' bucket.

    Before R3 the _normalize_source_type helper laundered every
    unrecognized source into the 'unknown' bucket which is part of the
    allow-list, so ``add()``'s fail-closed behavior was moot at the
    caller boundary. R3 makes the helper return None for unrecognized
    sources and the ingest path skips provenance registration rather
    than forging one."""
    ms.ingest(
        "This is a qualifying long-enough content line for the ingest path.",
        source="custom_thing", source_channel="ch_x",
    )
    # Skipped entirely - no 'unknown' bucket entry.
    records = ms.source_manifest.lookup(
        "unknown", "ch_x",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert records == [], (
        "unknown sources must not be laundered into the 'unknown' bucket"
    )


def test_multi_source_same_content_registers_under_both(ms):
    content = "This is the shared content that appears in two locations."
    ms.ingest(content, source="discord", source_channel="ch_a")
    ms.ingest(content, source="email", source_url="https://mail/x")
    a = ms.source_manifest.lookup(
        "discord", "ch_a",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    b = ms.source_manifest.lookup(
        "email", "https://mail/x",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert len(a) >= 1 and len(b) >= 1
    assert set(a) == set(b)


# ── Persist retry queue ─────────────────────────────────────────────────────

def test_persist_retry_queue(workspace, monkeypatch):
    m = SourceManifest(workspace)
    failing = {"flag": True}
    real_append = m._append_line
    def flaky_append(payload):
        if failing["flag"]:
            raise OSError("simulated disk full")
        return real_append(payload)
    monkeypatch.setattr(m, "_append_line", flaky_append)
    add(m, "discord", "ch", "h1")
    add(m, "discord", "ch", "h2")
    assert lookup(m, "discord", "ch", body=B) == ["h1", "h2"]
    assert m.stats()["pending_persist"] == 2
    failing["flag"] = False
    assert m.flush() == 2
    assert m.stats()["pending_persist"] == 0
    # Reload verifies both persisted
    m2 = SourceManifest(workspace)
    assert sorted(lookup(m2, "discord", "ch", body=B)) == ["h1", "h2"]


# ── Thread safety ───────────────────────────────────────────────────────────

def test_concurrent_adds(workspace):
    m = SourceManifest(workspace)
    n_threads = 8
    per_thread = 50
    def writer(tid):
        for i in range(per_thread):
            add(m, "discord", f"ch-{tid}", f"h-{tid}-{i}", ident=f"id-{tid}", body=B)
    with concurrent.futures.ThreadPoolExecutor(max_workers=n_threads) as ex:
        list(ex.map(writer, range(n_threads)))
    for t in range(n_threads):
        records = lookup(m, "discord", f"ch-{t}", ident=f"id-{t}", body=B)
        assert len(records) == per_thread


# ── Helpers ────────────────────────────────────────────────────────────────

def test_has_disallowed_char():
    assert _has_disallowed_char("\n")
    assert _has_disallowed_char("\r")
    assert _has_disallowed_char("\x00")
    assert _has_disallowed_char("\x7f")
    assert _has_disallowed_char("\u2028")
    assert _has_disallowed_char("\ud800")
    assert not _has_disallowed_char("hello")
    assert not _has_disallowed_char("チャンネル")
    assert not _has_disallowed_char("🎯")


def test_canonical_payload_excludes_seal():
    p1 = {"a": 1, "seal": "abc"}
    p2 = {"a": 1, "seal": "xyz"}
    assert _canonical_payload(p1) == _canonical_payload(p2)


# ── Eye R2 → R3 regression ────────────────────────────────────────────────

def test_r3_lookup_scoped_enforces_allowed_scopes(manifest):
    """Eye R2 F-R2-02: lookup_scoped must filter out record_ids whose
    retrieval_scope is not in allowed_scopes. Before R3 this silently
    passed hits through, making the method name a trap.
    """
    add(manifest, "discord", "c1", "h_user", scope="user")
    add(manifest, "discord", "c1", "h_system", scope="system")
    add(manifest, "discord", "c1", "h_none", scope="")

    class P:
        identity_id = I
        body_id = None
        allowed_scopes = {"user"}

    hits = manifest.lookup_scoped("discord", "c1", P())
    assert hits == ["h_user"], (
        "lookup_scoped must actually enforce allowed_scopes now"
    )


def test_r3_lookup_scoped_allowed_scopes_none_returns_all(manifest):
    add(manifest, "discord", "c1", "h1", scope="user")
    add(manifest, "discord", "c1", "h2", scope="system")

    class P:
        identity_id = I
        body_id = None
        allowed_scopes = None

    assert sorted(manifest.lookup_scoped("discord", "c1", P())) == ["h1", "h2"]


def test_r3_tombstone_then_re_add_resurrects(manifest):
    """Eye R2 F-R2-08: re-ingest after tombstone of identical content
    must be visible again - the manifest writes an op=untombstone record
    that chains into the HMAC seal and lookups return the record.
    """
    add(manifest, "discord", "c1", "h1", scope="user")
    manifest.tombstone("h1", "forgotten", identity_id=I)
    assert lookup(manifest, "discord", "c1", body=B) == []
    # Re-ingest same (source, rid) after tombstone - must re-appear.
    result = add(manifest, "discord", "c1", "h1", scope="user")
    assert result is True
    assert lookup(manifest, "discord", "c1", body=B) == ["h1"]


def test_r3_tombstone_then_re_add_survives_reload(workspace_hmac):
    """Untombstone records are part of the audit trail and must replay
    correctly on reload."""
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1", scope="user")
    m1.tombstone("h1", "forgotten", identity_id=I)
    add(m1, "discord", "c1", "h1", scope="user")
    assert lookup(m1, "discord", "c1", body=B) == ["h1"]
    m2 = SourceManifest(workspace_hmac)
    assert lookup(m2, "discord", "c1", body=B) == ["h1"]
    assert m2.health()["integrity"] == "ok"


def test_r3_no_hmac_env_refused_on_sealed_workspace(workspace_hmac, monkeypatch):
    """Eye R2 F-R2-05: PARSICA_MANIFEST_DEV_NO_HMAC cannot silently
    downgrade a workspace that already has a sealed chain.
    """
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1")
    # Now simulate "dev session attaches NO_HMAC to a prod workspace".
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    m2 = SourceManifest(workspace_hmac)
    # Load must still work (we read the sealed chain).
    assert lookup(m2, "discord", "c1", body=B) == ["h1"]
    # But an unsealed append against this sealed workspace is refused
    # with a specific exception that is NOT swallowed by the persist
    # retry queue (Eye R2 F-R2-05).
    import pytest
    from parsica_memory.source_manifest import UnsealedWriteRefused
    with pytest.raises(UnsealedWriteRefused, match="refusing unsealed write"):
        add(m2, "discord", "c1", "h2")


def test_r3_tail_truncation_detected(workspace_hmac):
    """Eye R2 F-R2-04: trimming trailing JSONL lines (which might contain
    tombstones) must surface as integrity='truncated' on reload, even
    though each remaining line's HMAC still individually verifies.
    """
    m = SourceManifest(workspace_hmac)
    add(m, "discord", "c1", "h1")
    m.tombstone("h1", "purged", identity_id=I)
    add(m, "discord", "c1", "h2")

    path = Path(workspace_hmac) / MANIFEST_PATH
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    # Simulate attacker deleting the last 2 lines (tombstone + final add).
    # Note: the manifest also has a legacy_seal anchor from migration; we
    # need to leave enough behind to keep the chain itself internally OK.
    assert len(lines) >= 2
    kept = lines[:-2]
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(kept)

    m2 = SourceManifest(workspace_hmac)
    # The chain should still verify (remaining lines are individually
    # sealed) but the tail anchor catches the truncation.
    assert m2.health()["integrity"] == "truncated", (
        f"expected truncated, got {m2.health()}"
    )


def test_r3_legacy_prefix_rewrite_detected(workspace_hmac_adopt_legacy):
    """Eye R2 F-R2-04 (near-P0): rewriting the unsealed legacy prefix
    contents must be detected by the anchor's prefix_hash.

    Eye R3.1 F-R3-04: first boot needs ADOPT_LEGACY to actually
    anchor; attacker without the flag would be refused instead of
    anchored-at-their-bytes.
    """
    workspace_hmac = workspace_hmac_adopt_legacy
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    # Seed a legacy (unsealed) line.
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    # First boot: anchor the legacy prefix (prefix_hash written).
    m1 = SourceManifest(workspace_hmac)
    assert m1.health()["integrity"] == "ok"
    del m1

    # Attacker rewrites the legacy line's record_id before next load.
    with open(path, encoding="utf-8") as f:
        all_lines = f.readlines()
    legacy = json.loads(all_lines[0])
    legacy["record_id"] = "h_attacker"
    all_lines[0] = json.dumps(legacy) + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(all_lines)

    m2 = SourceManifest(workspace_hmac)
    # Chain should be marked broken because the anchor's prefix_hash
    # no longer matches the current prefix bytes.
    assert m2.health()["integrity"] in ("chain_broken", "degraded"), (
        f"expected chain_broken/degraded, got {m2.health()}"
    )


def test_r3_unknown_source_skips_provenance_not_unknown_bucket(tmp_path, monkeypatch):
    """Eye R2 F-R2-03: an unmapped `source` kwarg (e.g. 'custom_thing')
    must NOT silently land in the manifest's allow-listed 'unknown'
    bucket. The ingest path now skips provenance registration.
    """
    from parsica_memory.core_v4 import MemorySystemV4
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))
    ms.ingest(
        "This is long enough content for the normal ingest path to accept.",
        source="custom_thing", source_channel="ch_x",
    )
    records = ms.source_manifest.lookup(
        "unknown", "ch_x",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert records == []


def test_r3_lookup_source_shim_works_with_identity_id(tmp_path, monkeypatch):
    """Eye R2 F-R2-01 / N-01: the public MemorySystemV4.lookup_source
    shim must plumb identity_id through to the new scoped API instead
    of raising TypeError.
    """
    from parsica_memory.core_v4 import MemorySystemV4
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))
    ms.ingest(
        "This is long enough content for the normal ingest path to accept.",
        source="discord", source_channel="ch_probe",
    )
    # Must not raise.
    rids = ms.lookup_source(
        "discord", "ch_probe",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert len(rids) == 1


def test_r3_get_by_source_consumer_exercises_health(tmp_path, monkeypatch):
    """Eye R2 Judge Opus: 'ship a public consumer that exercises
    health()'. get_by_source must resolve record_ids to MemoryEntry
    objects AND raise ManifestIntegrityError when health != 'ok' and
    require_integrity=True.
    """
    from parsica_memory.core_v4 import MemorySystemV4
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))
    ms.ingest(
        "This is long enough content for the normal ingest path to accept.",
        source="discord", source_channel="ch_probe",
    )
    entries = ms.get_by_source(
        "discord", "ch_probe",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert len(entries) == 1
    assert entries[0].content.startswith("This is long enough content")

    # Force unhealthy state and assert the consumer fails closed.
    ms.manifest(ms.internal_manifest_capability())._integrity_state = "chain_broken"
    import pytest
    with pytest.raises(ManifestIntegrityError):
        ms.get_by_source(
            "discord", "ch_probe",
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
        )
    # R4.1 Cluster A (P0-5): the integrity gate now refuses at the
    # primitive, so ``require_integrity=False`` no longer provides a
    # best-effort escape for hard-refuse states (chain_broken,
    # truncated, tail_rewritten, load_error, secret_corrupt). This is
    # the correct behaviour - a tampered chain cannot be coerced into
    # returning adversary-controlled record_ids by flipping a caller
    # kwarg. The opt-out that still works is to reset the integrity
    # state out-of-band after operator forensics.
    with pytest.raises(ManifestIntegrityError):
        ms.get_by_source(
            "discord", "ch_probe",
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
            require_integrity=False,
        )


def test_r3_reconcile_with_store_reports_orphans(manifest):
    """Eye R2 F3 partial-mitigation: reconcile_with_store surfaces
    records the manifest knows about that the caller's store does not.
    This is the tool operators use at startup to detect crash orphans
    when the manifest was sealed before the segment buffer flushed.
    """
    add(manifest, "discord", "c1", "h_live")
    add(manifest, "discord", "c1", "h_orphan")
    add(manifest, "email", "m1", "h_also_orphan")
    manifest.tombstone("h_tombstoned_never_in_store", "forgotten", identity_id=I)

    report = manifest.reconcile_with_store({"h_live"})
    assert report["total_records"] == 3
    assert sorted(report["orphan_record_ids"]) == ["h_also_orphan", "h_orphan"]
    # Orphans grouped by source.
    assert report["orphan_by_source"] == {
        ("discord", "c1"): 1,
        ("email", "m1"): 1,
    }


def test_r3_reconcile_with_store_clean_run_reports_no_orphans(manifest):
    add(manifest, "discord", "c1", "h1")
    add(manifest, "discord", "c1", "h2")
    report = manifest.reconcile_with_store({"h1", "h2"})
    assert report["orphan_record_ids"] == []
    assert report["total_records"] == 2


def test_r3_2_untombstone_refusal_does_not_swallow_or_lie(workspace_hmac, monkeypatch):
    """Eye R3 Judge GPT: when a sealed workspace is reopened under
    PARSICA_MANIFEST_DEV_NO_HMAC=1 and the caller re-adds a tombstoned
    record, the underlying untombstone write must raise
    UnsealedWriteRefused all the way out of add(), not silently queue.
    Previously the broad except Exception in _append_untombstone
    swallowed the refusal and add() returned True for a resurrection
    that never landed - the record stayed invisible forever.
    """
    from parsica_memory.source_manifest import UnsealedWriteRefused
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1")
    m1.tombstone("h1", "forgotten", identity_id=I)
    del m1

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    m2 = SourceManifest(workspace_hmac)
    # Lookup correctly returns [] because the record is tombstoned.
    assert lookup(m2, "discord", "c1", body=B) == []
    # Re-adding the same record must RAISE UnsealedWriteRefused, not
    # silently return True with the record still invisible.
    import pytest
    with pytest.raises(UnsealedWriteRefused):
        add(m2, "discord", "c1", "h1")
    # State is consistent: still tombstoned.
    assert lookup(m2, "discord", "c1", body=B) == []


def test_r3_2_fabricated_seal_without_secret_file_does_not_poison(tmp_path, monkeypatch):
    """Eye R3 Attacker GPT P2: under NO_HMAC, a fabricated line with a
    non-empty `seal` string must NOT set _has_sealed_prefix and block
    legitimate dev writes. The authoritative signal is the presence of
    the per-workspace secret file on disk; without it, a seal claim is
    unverifiable and ignored for downgrade-refusal purposes.
    """
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    path = Path(tmp_path) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    # Attacker writes a line that *claims* to be sealed, but the
    # workspace has no secret file - so the claim is unverifiable.
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_attack",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
            "seal": "deadbeef" * 8,  # fake seal
            "seq": 0,
            "prev_seal": "",
        }) + "\n")
    # Ensure no secret file exists.
    secret_path = Path(tmp_path) / SECRET_PATH
    assert not secret_path.exists()
    m = SourceManifest(str(tmp_path))
    # Legitimate dev NO_HMAC append must not be refused.
    add(m, "discord", "ch", "h_legit")
    assert "h_legit" in lookup(m, "discord", "ch", body=B)


def test_r3_2_real_sealed_workspace_still_refuses_no_hmac_write(workspace_hmac, monkeypatch):
    """Eye R3 Attacker GPT: the real F-R2-05 scenario must still be
    refused - a workspace that legitimately has both sealed lines AND
    the secret file cannot be silently downgraded via NO_HMAC.
    """
    from parsica_memory.source_manifest import UnsealedWriteRefused
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1")
    # Secret file was auto-provisioned on first add.
    assert (Path(workspace_hmac) / SECRET_PATH).exists()
    del m1

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    m2 = SourceManifest(workspace_hmac)
    import pytest
    with pytest.raises(UnsealedWriteRefused):
        add(m2, "discord", "c1", "h2")


def test_r3_2_main_ingest_fuzzy_dedup_retains_source_graph(tmp_path, monkeypatch):
    """Eye R2 Judge Opus N-02 / Eye R3: when two fuzzy-similar facts
    arrive via different source channels through the main ingest()
    path (NOT _decompose_facts), BOTH sources must end up registered
    against the canonical entry's hash. Before R3.1 the fuzzy-dedup
    branch at core_v4.py:2498-2503 silently dropped the second source.
    """
    from parsica_memory.core_v4 import MemorySystemV4
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))

    # Two fuzzy-similar fact statements (>0.85 cosine) from different
    # channels. Force fact classification via memory_type="fact" so the
    # fuzzy branch is exercised.
    ms.ingest(
        "Parsica source manifest enforces identity scoping at add time",
        memory_type="fact",
        source="discord", source_channel="ch_alpha",
    )
    # Near-identical wording so Jaccard clears 0.85 threshold.
    ms.ingest(
        "Parsica source manifest enforces identity scoping at add time always",
        memory_type="fact",
        source="discord", source_channel="ch_beta",
    )

    # Only one canonical entry (fuzzy deduped).
    facts = [m for m in ms.memories if m.memory_type == "fact"]
    assert len(facts) == 1, f"expected single canonical, got {len(facts)}"
    canonical_hash = facts[0].hash

    # BOTH source channels must resolve to the same canonical hash.
    alpha = ms.source_manifest.lookup(
        "discord", "ch_alpha",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    beta = ms.source_manifest.lookup(
        "discord", "ch_beta",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert canonical_hash in alpha, (
        f"ch_alpha provenance missing - fuzzy-dedup branch dropped source. "
        f"alpha={alpha} canonical={canonical_hash}"
    )
    assert canonical_hash in beta, (
        f"ch_beta provenance missing - fuzzy-dedup branch dropped source. "
        f"beta={beta} canonical={canonical_hash}"
    )


def _seed_fact(ms, content: str, *, source_channel: str, identity_id: str, body_id: str, scope: str):
    from parsica_memory.entry import MemoryEntry

    entry = MemoryEntry(content, "discord", 1, "general", memory_type="fact")
    entry.identity_id = identity_id
    entry.body_id = body_id
    entry.retrieval_scope = scope
    ms.memories.append(entry)
    ms._hashes.add(entry.hash)
    ms._content_norms.add(content.lower().strip())
    ms._index_fact(entry)
    ms._record_provenance(
        entry.hash,
        "discord",
        None,
        source_channel,
        identity_id=identity_id,
        body_id=body_id,
        retrieval_scope=scope,
    )
    return entry


def test_r4_1_fuzzy_dedup_cross_identity_isolation(tmp_path, monkeypatch):
    from parsica_memory.core_v4 import MemorySystemV4
    from parsica_memory.entry import MemoryEntry

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))

    alice = _seed_fact(
        ms,
        "Parsica keeps provenance scoped to each identity boundary",
        source_channel="alice_ch",
        identity_id="alice",
        body_id="alice:dm",
        scope="private",
    )

    bob_content = "Parsica keeps provenance scoped to identity boundaries"
    assert ms._find_similar_fact(bob_content, threshold=0.85, identity_id="bob") is None

    bob = MemoryEntry(bob_content, "discord", 2, "general", memory_type="fact")
    bob.identity_id = "bob"
    bob.body_id = "bob:dm"
    bob.retrieval_scope = "private"
    ms.memories.append(bob)
    ms._hashes.add(bob.hash)
    ms._content_norms.add(bob_content.lower().strip())
    ms._index_fact(bob)
    ms._record_provenance(
        bob.hash,
        "discord",
        None,
        "bob_ch",
        identity_id="bob",
        body_id="bob:dm",
        retrieval_scope="private",
    )

    assert ms.source_manifest.lookup("discord", "alice_ch", identity_id="alice", body_id="alice:dm") == [alice.hash]
    assert ms.source_manifest.lookup("discord", "bob_ch", identity_id="bob", body_id="bob:dm") == [bob.hash]
    assert ms.source_manifest.lookup("discord", "bob_ch", identity_id="alice", body_id="alice:dm") == []
    assert ms.source_manifest.lookup("discord", "alice_ch", identity_id="bob", body_id="bob:dm") == []


def test_r4_1_exact_dedup_cross_identity_isolation(tmp_path, monkeypatch):
    from parsica_memory.core_v4 import MemorySystemV4
    from parsica_memory.dedup import DedupEngine

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))

    alice = _seed_fact(
        ms,
        "Exact duplicate content must not leak provenance across identities",
        source_channel="alice_exact",
        identity_id="alice",
        body_id="alice:dm",
        scope="private",
    )

    dup_hash = DedupEngine().is_duplicate(
        alice.content,
        ms.memories,
        candidate_filter=lambda m: getattr(m, "identity_id", None) == "bob",
    )
    assert dup_hash is None

    bob = _seed_fact(
        ms,
        alice.content,
        source_channel="bob_exact",
        identity_id="bob",
        body_id="bob:dm",
        scope="private",
    )

    assert ms.source_manifest.lookup("discord", "alice_exact", identity_id="alice", body_id="alice:dm") == [alice.hash]
    assert ms.source_manifest.lookup("discord", "bob_exact", identity_id="bob", body_id="bob:dm") == [bob.hash]
    assert ms.source_manifest.lookup("discord", "bob_exact", identity_id="alice", body_id="alice:dm") == []
    assert ms.source_manifest.lookup("discord", "alice_exact", identity_id="bob", body_id="bob:dm") == []


def test_r4_1_same_identity_fuzzy_dedup_still_merges_provenance(tmp_path, monkeypatch):
    from parsica_memory.core_v4 import MemorySystemV4

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))

    alice = _seed_fact(
        ms,
        "Parsica keeps the same identity provenance graph intact",
        source_channel="alice_a",
        identity_id="alice",
        body_id="alice:dm",
        scope="private",
    )

    existing = ms._find_similar_fact(
        "Parsica keeps the same identity provenance graph fully intact",
        threshold=0.85,
        identity_id="alice",
    )
    assert existing is not None
    assert existing.hash == alice.hash

    ms._record_provenance(
        existing.hash,
        "discord",
        None,
        "alice_b",
        identity_id="alice",
        body_id="alice:dm",
        retrieval_scope="private",
    )

    assert ms.source_manifest.lookup("discord", "alice_a", identity_id="alice", body_id="alice:dm") == [alice.hash]
    assert ms.source_manifest.lookup("discord", "alice_b", identity_id="alice", body_id="alice:dm") == [alice.hash]


# ── Eye R3 → R3.1 regression (Attacker Opus minimum-bar) ─────────────────

def test_r3_1_first_boot_forge_refused(workspace_hmac):
    """Eye R3.1 F-R3-04 🔥 (Attacker Opus): fresh workspace + no prior
    secret + pre-existing unsealed lines on disk MUST NOT auto-anchor
    on first boot. Without this refusal, an attacker who plants lines
    into a fresh workspace has them auto-blessed by first R3 boot's
    new secret + prefix_hash (self-referential witness).
    """
    # Attacker plants unsealed lines.
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch_attacker",
            "record_id": "h_planted",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    # No secret file exists (first-boot-on-fresh-workspace).
    assert not (Path(workspace_hmac) / SECRET_PATH).exists()
    # R4.1 Cluster J (P2-2): verify the consumer gate refuses access.
    # We construct MemorySystemV4 FIRST (before any SourceManifest
    # instance can lazily create the secret file) so that its internal
    # manifest observes the genuine first-boot scenario:
    # _secret_preexisted=False + unsealed lines → legacy_pending_anchor.
    # This is the precondition the forge defense relies on.
    from parsica_memory.core_v4 import MemorySystemV4
    ms = MemorySystemV4(workspace_hmac)
    # Integrity state must be legacy_pending_anchor (not ok).
    assert ms.source_manifest.health()["integrity"] == "legacy_pending_anchor"
    # get_by_source must refuse — planted provenance is invisible to
    # well-behaved consumers that check health() before trusting the index.
    with pytest.raises(ManifestIntegrityError):
        ms.get_by_source("discord", "ch_attacker", identity_id=I, body_id=B)
    # Also verify via SourceManifest directly that the same file-state
    # produces legacy_pending_anchor on a second separate instance
    # (the secret is now on disk from the MemorySystemV4 boot above,
    # so _secret_preexisted=True — this is the legitimate re-open path
    # after first boot, not the forge scenario; first-boot forge is
    # already proven by the ms assertions above).
    m = SourceManifest(workspace_hmac)
    # After the ms instance created + anchored the prefix, m sees ok.
    assert m.health()["integrity"] == "ok"


def test_r3_1_adopt_legacy_opt_in_anchors_prefix(workspace_hmac_adopt_legacy):
    """Eye R3.1 F-R3-04: when the operator explicitly sets
    PARSICA_MANIFEST_ADOPT_LEGACY=1, the pre-existing unsealed prefix
    is blessed and anchored. This is the legitimate migration path.
    """
    path = Path(workspace_hmac_adopt_legacy) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    m = SourceManifest(workspace_hmac_adopt_legacy)
    assert m.health()["integrity"] == "ok"


def test_r3_1_secret_preexists_unsealed_prefix_allowed(workspace_hmac):
    """Eye R3.1 F-R3-04: if the secret file was already on disk (i.e.,
    this is a bona-fide pre-R2 workspace that was running under HMAC
    before but has unsealed lines from a yet-earlier era), allow the
    auto-anchor. The attack we're defending against is FRESH secret +
    pre-existing unsealed lines.
    """
    # Pre-create the secret file so it looks like a bona-fide legacy
    # HMAC workspace. Secret is stored as ASCII hex of 32 random bytes.
    (Path(workspace_hmac) / SECRET_PATH).parent.mkdir(parents=True, exist_ok=True)
    (Path(workspace_hmac) / SECRET_PATH).write_text(
        os.urandom(32).hex(), encoding="ascii",
    )
    os.chmod(Path(workspace_hmac) / SECRET_PATH, 0o600)
    # Now plant unsealed lines.
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_legacy",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
    m = SourceManifest(workspace_hmac)
    assert m.health()["integrity"] == "ok"


def test_r3_1_tombstone_refused_on_sealed_workspace_under_no_hmac(workspace_hmac, monkeypatch):
    """Eye R3.1 F-R3-06 (Attacker Opus GDPR P1): tombstone() is the
    user-facing forget path. A sealed workspace reopened under NO_HMAC
    must refuse the tombstone write loudly (UnsealedWriteRefused), not
    silently queue and lie to the caller that the forget happened.
    """
    from parsica_memory.source_manifest import UnsealedWriteRefused
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1")
    del m1
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    m2 = SourceManifest(workspace_hmac)
    import pytest
    with pytest.raises(UnsealedWriteRefused):
        m2.tombstone("h1", "forgotten", identity_id=I)
    # Roll-back: the in-memory tombstone state is NOT set.
    # The record should still be visible (tombstone didn't actually land).
    assert lookup(m2, "discord", "c1", body=B) == ["h1"]


def test_r3_1_drain_pending_refused_on_sealed_workspace_under_no_hmac(tmp_path, monkeypatch):
    """Eye R3.1 F-R3-06: _drain_pending must also let UnsealedWriteRefused
    escape rather than silently re-queueing forever. We simulate the
    scenario directly: load a sealed workspace under NO_HMAC, inject a
    queued payload into the in-memory pending list, then call flush().
    """
    from parsica_memory.source_manifest import UnsealedWriteRefused
    monkeypatch.delenv("PARSICA_MANIFEST_DEV_NO_HMAC", raising=False)
    m1 = SourceManifest(str(tmp_path))
    add(m1, "discord", "c1", "h1")
    del m1
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    m2 = SourceManifest(str(tmp_path))
    # Simulate an earlier-failed persist queued in memory. Under
    # NO_HMAC on a sealed workspace the retry must escape loudly.
    m2._ensure_loaded()
    m2._pending_persist.append(m2._serialize_add(
        source_type="discord", source_id="c1", record_id="h_queued",
        identity_id=I, body_id=B, retrieval_scope="",
    ))
    import pytest
    with pytest.raises(UnsealedWriteRefused):
        m2.flush()


def test_r3_1_anchor_deletion_surfaces_as_anchor_missing(workspace_hmac):
    """Eye R3.1 F-R3-01 (Attacker Opus + Attacker Sonnet): deleting the
    tail anchor sidecar on a workspace with a sealed chain must NOT
    allow the loader to report integrity=ok. That would re-open the
    truncation attack F-R2-04 was designed to close.
    """
    m1 = SourceManifest(workspace_hmac)
    add(m1, "discord", "c1", "h1")
    add(m1, "discord", "c1", "h2")
    del m1
    # Attacker deletes the anchor sidecar.
    anchor_path = Path(workspace_hmac) / TAIL_ANCHOR_PATH
    assert anchor_path.exists()
    anchor_path.unlink()
    m2 = SourceManifest(workspace_hmac)
    assert m2.health()["integrity"] == "anchor_missing"


def test_r3_1_forged_untombstone_in_legacy_prefix_rejected(workspace_hmac_adopt_legacy):
    """Eye R3.1 F-R3-08 (Attacker Opus): a forged op=untombstone
    record in the unsealed legacy prefix must be rejected on load,
    not replayed. Otherwise the attacker can plant
    tombstone(h) + untombstone(h) pairs to resurrect GDPR-forgotten
    content and have first-boot auto-anchor bless the sequence.
    """
    path = Path(workspace_hmac_adopt_legacy) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        # Legit-looking add
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch",
            "record_id": "h_victim",
            "identity_id": I, "body_id": B,
            "retrieval_scope": "",
            "added_at": "2026-04-17T00:00:00Z",
        }) + "\n")
        # Legit-looking tombstone
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "tombstone",
            "record_id": "h_victim",
            "identity_id": I,
            "reason": "forgotten",
            "tombstoned_at": "2026-04-17T00:00:01Z",
        }) + "\n")
        # FORGED untombstone in the unsealed prefix (attacker planted)
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "untombstone",
            "record_id": "h_victim",
            "identity_id": I,
            "untombstoned_at": "2026-04-17T00:00:02Z",
        }) + "\n")
    m = SourceManifest(workspace_hmac_adopt_legacy)
    # The forged untombstone MUST be rejected - the tombstone still
    # holds and the record is not retrievable. That is the core invariant.
    assert lookup(m, "discord", "ch", body=B) == [], (
        "forged untombstone in legacy prefix must not resurrect the record"
    )
    # And the loader must have logged a quarantine so operators can audit.
    health = m.health()
    assert health["quarantined_lines"] >= 1, (
        f"forged untombstone should have been quarantined; health={health}"
    )


# ── R4.1 Cluster G: multi-process lockfile ────────────────────────────────

def test_r4_1_workspace_lock_single_process_write_succeeds(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    workspace = str(tmp_path)
    manifest = SourceManifest(workspace, lock_timeout_seconds=0.5)

    assert add(manifest, "discord", "lock-single", "h1") is True

    lock_path = Path(workspace) / "_meta/.source_manifest.lock"
    assert lock_path.exists()
    assert lookup(manifest, "discord", "lock-single", body=B) == ["h1"]


def test_r4_1_workspace_lock_blocks_then_succeeds_across_processes(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    workspace = str(tmp_path)
    queue = multiprocessing.Queue()
    holder = multiprocessing.Process(
        target=_lock_holder_process,
        args=(workspace, 0.35, queue),
    )
    holder.start()
    msg = queue.get(timeout=2)
    assert msg == "locked"

    contender = SourceManifest(workspace, lock_timeout_seconds=1.0)
    start = time.monotonic()
    assert add(contender, "discord", "lock-contended", "h1") is True
    elapsed = time.monotonic() - start

    holder.join(timeout=2)
    assert holder.exitcode == 0
    assert elapsed >= 0.25
    assert lookup(contender, "discord", "lock-contended", body=B) == ["h1"]


def test_r4_1_workspace_lock_timeout_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    workspace = str(tmp_path)
    queue = multiprocessing.Queue()
    holder = multiprocessing.Process(
        target=_lock_holder_process,
        args=(workspace, 0.6, queue),
    )
    holder.start()
    msg = queue.get(timeout=2)
    assert msg == "locked"

    contender = SourceManifest(workspace, lock_timeout_seconds=0.1)
    with pytest.raises(ManifestLockTimeoutError):
        add(contender, "discord", "lock-timeout", "h1")

    holder.join(timeout=2)
    assert holder.exitcode == 0


def test_r4_1_workspace_lock_released_after_exception(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    workspace = str(tmp_path)
    manifest = SourceManifest(workspace, lock_timeout_seconds=0.2)

    with pytest.raises(RuntimeError, match="boom"):
        with manifest._with_workspace_lock():
            raise RuntimeError("boom")

    assert add(manifest, "discord", "lock-released", "h1") is True
    assert lookup(manifest, "discord", "lock-released", body=B) == ["h1"]


# ---------------------------------------------------------------------------
# R4.1 Cluster J — P2 hygiene sweep + P1-3 secret rotation defense
# ---------------------------------------------------------------------------

def test_r41_j_p1_3_secret_rotation_blocked_when_sealed_records_exist(workspace_hmac):
    """R4.1 Cluster J (P1-3): deleting the HMAC secret on a workspace that
    already contains sealed records must NOT silently auto-create a new
    secret. The manifest must transition to secret_rotation_required and
    refuse all operations until the operator sets PARSICA_MANIFEST_ROTATE_SECRET=1.
    """
    # Write a sealed record so the chain has sealed content.
    m = SourceManifest(workspace_hmac)
    assert add(m, "discord", "ch_sealed", "h_sealed_001") is True
    h = m.health()
    assert h["integrity"] in ("ok", "fresh"), f"expected ok/fresh after sealed add, got {h}"
    assert h["hmac"] == "enabled"
    # Confirm the JSONL has a seal field.
    path = Path(workspace_hmac) / MANIFEST_PATH
    with open(path, encoding="utf-8") as f:
        lines = [json.loads(l) for l in f if l.strip()]
    assert any("seal" in rec for rec in lines), "no sealed line in JSONL after add"

    # Now delete the secret to simulate attacker or accidental deletion.
    secret = Path(workspace_hmac) / SECRET_PATH
    assert secret.exists()
    secret.unlink()

    # A fresh instance (no rotation env var) must refuse operations.
    m2 = SourceManifest(workspace_hmac)
    h2 = m2.health()
    assert h2["integrity"] == "secret_rotation_required", (
        f"expected secret_rotation_required after secret deletion on sealed workspace, got {h2}"
    )
    assert h2["hmac"] == "disabled_by_rotation"
    with pytest.raises(ManifestIntegrityError):
        m2.lookup("discord", "ch_sealed", identity_id=I, body_id=B)


def test_r41_j_p1_3_secret_rotation_allowed_with_env_flag(workspace_hmac, monkeypatch):
    """R4.1 Cluster J (P1-3): when PARSICA_MANIFEST_ROTATE_SECRET=1, the
    operator explicitly authorises rotation. A new secret is created and an
    ops-alert is emitted, but operations proceed.
    """
    # Seed sealed workspace.
    m = SourceManifest(workspace_hmac)
    assert add(m, "discord", "ch_pre_rotation", "h_pre_001") is True
    secret = Path(workspace_hmac) / SECRET_PATH
    secret.unlink()

    monkeypatch.setenv("PARSICA_MANIFEST_ROTATE_SECRET", "1")
    m2 = SourceManifest(workspace_hmac)
    h2 = m2.health()
    # A new secret was created; the old chain can't be verified so the
    # workspace loads as chain_broken or legacy_pending_anchor (depends on
    # what the loader finds after the secret changed). Either is acceptable —
    # the key invariant is that secret_rotation_required is NOT the outcome
    # (that state only fires when the env flag is absent).
    assert h2["integrity"] != "secret_rotation_required", (
        f"ROTATE_SECRET=1 should allow rotation; integrity should not be "
        f"secret_rotation_required but got {h2}"
    )


def test_r41_j_p1_3_no_sealed_records_no_block(workspace_hmac):
    """R4.1 Cluster J (P1-3): if the JSONL has no sealed records, deleting
    the secret should NOT trigger secret_rotation_required. Fresh workspace
    with only unsealed lines → normal first-boot scenario.
    """
    # Write an unsealed line directly (no HMAC boot yet).
    path = Path(workspace_hmac) / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch_plain",
            "record_id": "h_plain", "identity_id": I, "body_id": B,
            "retrieval_scope": "", "added_at": "2026-01-01T00:00:00Z",
        }) + "\n")
    # No secret file.
    assert not (Path(workspace_hmac) / SECRET_PATH).exists()
    m = SourceManifest(workspace_hmac)
    # Should be legacy_pending_anchor (normal forge-refused path), NOT
    # secret_rotation_required.
    h = m.health()
    assert h["integrity"] in ("legacy_pending_anchor", "ok"), (
        f"unsupported state for unsealed-only JSONL without secret: {h}"
    )
    assert h["integrity"] != "secret_rotation_required"


def test_r41_j_p2_1_integrity_state_self_heals_after_write(workspace_hmac):
    """R4.1 Cluster J (P2-1): after anchor_missing load, a successful write
    must update _integrity_state to 'ok' in the CURRENT session (not just
    on the next restart).
    """
    workspace = workspace_hmac
    # Seed: write a sealed record so the workspace has sealed content.
    m_seed = SourceManifest(workspace)
    assert add(m_seed, "discord", "ch_seed", "h_seed") is True
    # Verify sealed content exists.
    anchor = Path(workspace) / TAIL_ANCHOR_PATH
    assert anchor.exists(), "tail anchor should exist after sealed add"

    # Delete the tail anchor to simulate anchor_missing on next load.
    anchor.unlink()

    # New instance: must load as anchor_missing.
    m2 = SourceManifest(workspace)
    h2 = m2.health()
    assert h2["integrity"] == "anchor_missing", (
        f"expected anchor_missing after anchor deletion, got {h2}"
    )

    # A successful write must self-heal _integrity_state to 'ok' in THIS
    # session without requiring a restart.
    assert add(m2, "discord", "ch_heal", "h_heal") is True
    h2_after = m2.health()
    assert h2_after["integrity"] == "ok", (
        f"_integrity_state should self-heal to 'ok' after successful write; "
        f"got {h2_after['integrity']!r}"
    )


def test_r41_j_p2_4_degraded_not_laundered_to_ok(tmp_path, monkeypatch):
    """R4.1 Cluster J (P2-4): when a workspace has quarantined (bad) lines
    AND a legacy prefix is auto-anchored, integrity must NOT be laundered
    from 'degraded' to 'ok'. It should remain 'anchored_degraded'.
    """
    monkeypatch.setenv("PARSICA_MANIFEST_ADOPT_LEGACY", "1")
    path = tmp_path / MANIFEST_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    # Plant: one valid line and one corrupted line.
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps({
            "schema": SCHEMA_VERSION, "op": "add",
            "source_type": "discord", "source_id": "ch_ok",
            "record_id": "h_ok", "identity_id": I, "body_id": B,
            "retrieval_scope": "", "added_at": "2026-01-01T00:00:00Z",
        }) + "\n")
        # Malformed JSON → will be quarantined.
        f.write("{not valid json\n")
    # Pre-create secret so _secret_preexisted=True → ADOPT_LEGACY anchors.
    secret = tmp_path / SECRET_PATH
    secret.parent.mkdir(parents=True, exist_ok=True)
    secret.write_text(os.urandom(32).hex(), encoding="ascii")
    os.chmod(secret, 0o600)

    m = SourceManifest(str(tmp_path))
    h = m.health()
    # Bad lines should produce anchored_degraded, NOT ok.
    assert h["integrity"] == "anchored_degraded", (
        f"expected anchored_degraded when bad lines present + legacy anchor written, "
        f"got {h['integrity']!r}"
    )
    assert h.get("quarantined_lines", 0) >= 1


def test_r41_j_p2_5_scope_by_rid_first_write_wins(tmp_path, monkeypatch):
    """R4.1 Cluster J (P2-5): re-ingesting a record_id with a different
    retrieval_scope must NOT overwrite the original scope (first-write-wins).
    """
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    workspace = str(tmp_path)
    m = SourceManifest(workspace)
    # First write: scope = "personal"
    payload_first = {
        "op": "add",
        "schema": SCHEMA_VERSION,
        "source_type": "discord",
        "source_id": "ch_scope",
        "record_id": "h_scope_test",
        "identity_id": I,
        "body_id": B,
        "retrieval_scope": "personal",
        "added_at": "2026-01-01T00:00:00Z",
    }
    m.add("discord", "ch_scope", "h_scope_test",
          identity_id=I, body_id=B, retrieval_scope="personal")
    # Verify original scope stored.
    assert m._scope_by_rid[I]["h_scope_test"] == "personal"

    # Second call with different scope — should NOT overwrite.
    # We call add() again; since already_indexed=True and no tombstone,
    # it returns False and scope update must not happen.
    m.add("discord", "ch_scope", "h_scope_test",
          identity_id=I, body_id=B, retrieval_scope="shared")
    assert m._scope_by_rid[I]["h_scope_test"] == "personal", (
        "_scope_by_rid must be first-write-wins; re-ingest must not drift scope"
    )
