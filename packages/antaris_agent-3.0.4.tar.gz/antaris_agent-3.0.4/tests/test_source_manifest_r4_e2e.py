"""
SourceManifest R4.1 — Cluster I: E2E test suite.

Provides R5 reviewability proof for every cluster A-H.
Closes P2-3 (zero forget/delete E2E tests — root cause of R3.1 P0 undetected).

Every test goes through ``MemorySystemV4`` public API (or the SourceManifest
accessed via the capability token), not the primitive directly.

R3.1 passed 78 manifest unit tests while shipping a P0 silent-forget because no
integration test exercised the user-facing path. These 9 tests close that gap.

9 mandatory tests (one per cluster A-H + integration happy-path):
  1. test_e2e_cluster_a_integrity_gate         — degraded state → forget() raises ManifestIntegrityError
  2. test_e2e_cluster_b_hmac_corrupt_secret    — corrupt secret → next op raises with operator message
  3. test_e2e_cluster_c_cross_identity_dedup   — identity isolation: A's record_ids ≠ B's record_ids
  4. test_e2e_cluster_d_anchor_crash_window    — crash mid-anchor → chain_crash_recovery → add() refuses
  5. test_e2e_cluster_e_capability_token       — no direct attribute access; cap-token guards manifest
  6. test_e2e_cluster_f_exception_hygiene      — UnsealedWriteRefused propagates through forget()
  7. test_e2e_cluster_g_multiprocess           — concurrent add() leaves chain intact
  8. test_e2e_cluster_h_pack_consumer          — get_by_source() raises ManifestIntegrityError on bad manifest
  9. test_e2e_integration_happy_path           — ingest→lookup→forget→tombstoned→re-ingest→fresh
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import textwrap
import warnings
from pathlib import Path
from typing import Optional

import pytest


# ---------------------------------------------------------------------------
# Module-level constants (lazy imports inside tests for isolation)
# ---------------------------------------------------------------------------

def _legacy_sentinels():
    from parsica_memory.source_manifest import LEGACY_IDENTITY_SENTINEL, LEGACY_BODY_SENTINEL
    return LEGACY_IDENTITY_SENTINEL, LEGACY_BODY_SENTINEL


def _make_ms(tmp_path, *, segments: bool = False, no_hmac: bool = False,
             monkeypatch=None, agent_name: str = "test-agent"):
    """Construct a MemorySystemV4 with sensible test defaults.

    Parameters
    ----------
    segments:
        Use the segmented storage backend so ``_using_segments`` is True.
        Required for ``forget()`` to hit the manifest tombstone path.
    no_hmac:
        Set ``PARSICA_MANIFEST_DEV_NO_HMAC=1`` before construction.
    monkeypatch:
        pytest monkeypatch fixture — used for environment variable injection.
    """
    if no_hmac:
        if monkeypatch is not None:
            monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        else:
            os.environ["PARSICA_MANIFEST_DEV_NO_HMAC"] = "1"

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        from parsica_memory.core_v4 import MemorySystemV4
        backend = "segments" if segments else "legacy"
        ms = MemorySystemV4(
            workspace=str(tmp_path),
            use_sharding=False,
            storage_backend=backend,
            agent_name=agent_name,
        )
    return ms


def _manifest_of(ms):
    """Return the raw SourceManifest via the capability-token (internal test helper)."""
    cap = ms.internal_manifest_capability()
    return ms.manifest(cap)


# ---------------------------------------------------------------------------
# 1. Cluster A — Integrity gate E2E
# ---------------------------------------------------------------------------

class TestE2EClusterAIntegrityGate:
    """
    Corrupt the workspace to force a degraded integrity state.
    Then call ``memory_system.forget(topic=...)`` — must raise ManifestIntegrityError
    visibly, not silently succeed.

    Uses ``storage_backend='segments'`` so ``forget()`` reaches the manifest
    tombstone path (the legacy WAL path skips the manifest entirely).
    """

    def test_e2e_cluster_a_integrity_gate(self, tmp_path, monkeypatch):
        from parsica_memory.source_manifest import ManifestIntegrityError

        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")

        ms = _make_ms(tmp_path, segments=True, monkeypatch=monkeypatch)

        # Ingest a memory so forget() has something to match.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            ms.ingest(
                "alpha integrity gate test memory content",
                source="inline",
                source_url="https://test.example/integrity-gate",
            )

        # Force the underlying manifest into a degraded integrity state.
        # Simulates what happens when the JSONL has bad lines on disk.
        sm = _manifest_of(ms)
        sm._integrity_state = "degraded"

        # forget() must raise — degraded refuses writes.
        with pytest.raises(ManifestIntegrityError) as exc_info:
            ms.forget(topic="integrity")

        msg = str(exc_info.value)
        assert "degraded" in msg, f"Expected 'degraded' in error: {msg}"


# ---------------------------------------------------------------------------
# 2. Cluster B — HMAC corrupt-secret E2E
# ---------------------------------------------------------------------------

class TestE2EClusterBHmacCorruptSecret:
    """
    Create workspace (HMAC-enabled), write data (clean chain), corrupt the
    secret file, then open a fresh instance and attempt any operation.

    Must raise ManifestIntegrityError with operator-visible message that
    includes the secret path and a recovery hint.
    """

    def test_e2e_cluster_b_hmac_corrupt_secret(self, tmp_path):
        from parsica_memory.source_manifest import (
            ManifestIntegrityError,
            SECRET_PATH,
            LEGACY_BODY_SENTINEL,
            LEGACY_IDENTITY_SENTINEL,
        )

        # Phase 1: write data to establish a clean HMAC chain.
        ms = _make_ms(tmp_path)
        sm = _manifest_of(ms)
        sm.add(
            "discord", "channel-b-test", "a" * 64,
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
        )
        sm.flush()
        del ms, sm

        # Phase 2: corrupt the secret file with garbage bytes.
        secret_path = tmp_path / SECRET_PATH
        assert secret_path.exists(), "Secret must exist after first add()"
        secret_path.write_bytes(b"\x00\x01\x02garbage\xff\xfe")

        # Phase 3: open fresh MemorySystemV4 on the same workspace.
        ms2 = _make_ms(tmp_path)
        sm2 = _manifest_of(ms2)

        # Phase 4: any operation must raise ManifestIntegrityError.
        # stats() is the lightest op; the gate runs on every public method.
        with pytest.raises(ManifestIntegrityError) as exc_info:
            sm2.stats()

        msg = str(exc_info.value)
        # Operator-visible: must mention the secret path and a recovery hint.
        assert any(
            kw in msg.lower()
            for kw in ("secret", "_meta", ".source_manifest_secret", "hmac")
        ), f"Error must mention secret/HMAC path. Got: {msg}"
        assert any(
            hint in msg.lower()
            for hint in ("recovery", "operator", "tamper", "corrupt", "rotate",
                         "remove", "check", "docs/", "procedure", "unusable")
        ), f"Error must contain recovery hint. Got: {msg}"


# ---------------------------------------------------------------------------
# 3. Cluster C — Cross-identity dedup E2E
# ---------------------------------------------------------------------------

class TestE2EClusterCCrossIdentityDedup:
    """
    Identity A ingests a source record; identity B ingests a different source
    record (same content URL pattern, but different identity scopes).

    Assert:
    - ``lookup(identity_id=A)`` returns record_ids under A's scope.
    - ``lookup(identity_id=B)`` returns record_ids under B's scope.
    - A's lookup for B's source URL returns empty (or only A-scoped records).
    - Neither identity sees the other's provenance.
    """

    def test_e2e_cluster_c_cross_identity_dedup(self, tmp_path, monkeypatch):
        from parsica_memory.source_manifest import LEGACY_BODY_SENTINEL

        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")

        ms = _make_ms(tmp_path, monkeypatch=monkeypatch)
        sm = _manifest_of(ms)

        identity_a = "identity-a@test"
        identity_b = "identity-b@test"
        hash_a = "a" * 64
        hash_b = "b" * 64

        # Identity A owns its source URL.
        sm.add(
            "web", "https://source-a.example/fact",
            hash_a,
            identity_id=identity_a,
            body_id=LEGACY_BODY_SENTINEL,
        )

        # Identity B owns a different source URL.
        sm.add(
            "web", "https://source-b.example/fact",
            hash_b,
            identity_id=identity_b,
            body_id=LEGACY_BODY_SENTINEL,
        )

        sm.flush()

        # Reload to confirm state is from disk.
        ms2 = _make_ms(tmp_path, monkeypatch=monkeypatch)
        sm2 = _manifest_of(ms2)

        # A can see their own records under their source URL.
        records_a_own = sm2.lookup(
            "web", "https://source-a.example/fact",
            identity_id=identity_a,
        )
        assert len(records_a_own) >= 1, "Identity A must see records under their source URL"
        assert hash_a in records_a_own, f"A's hash must be in A's records: {records_a_own}"

        # A does NOT see B's records under B's source URL.
        records_a_sees_b_url = sm2.lookup(
            "web", "https://source-b.example/fact",
            identity_id=identity_a,
        )
        assert hash_b not in records_a_sees_b_url, (
            f"Identity A must not see B's record_id under B's source URL: {records_a_sees_b_url}"
        )

        # B can see their own records.
        records_b_own = sm2.lookup(
            "web", "https://source-b.example/fact",
            identity_id=identity_b,
        )
        assert len(records_b_own) >= 1, "Identity B must see records under their source URL"
        assert hash_b in records_b_own, f"B's hash must be in B's records: {records_b_own}"

        # B does NOT see A's records under A's source URL.
        records_b_sees_a_url = sm2.lookup(
            "web", "https://source-a.example/fact",
            identity_id=identity_b,
        )
        assert hash_a not in records_b_sees_a_url, (
            f"Identity B must not see A's record_id under A's source URL: {records_b_sees_a_url}"
        )


# ---------------------------------------------------------------------------
# 4. Cluster D — Anchor crash-window E2E
# ---------------------------------------------------------------------------

class TestE2EClusterDAnchorCrashWindow:
    """
    Simulate a crash between anchor_planned and anchor_confirmed.

    Uses a REAL HMAC workspace (no NO_HMAC) and monkeypatches
    ``_write_tail_anchor_confirmed`` to be a no-op for one write.
    After that write, ``planned.count`` exceeds ``confirmed.count``
    → loader detects crash window → sets ``chain_crash_recovery``
    → writes refused via Cluster A gate.
    """

    def test_e2e_cluster_d_anchor_crash_window(self, tmp_path):
        from parsica_memory.source_manifest import (
            ManifestIntegrityError,
            LEGACY_BODY_SENTINEL,
            LEGACY_IDENTITY_SENTINEL,
        )

        # Phase 1: create workspace with HMAC (no NO_HMAC env).
        ms = _make_ms(tmp_path)
        sm = _manifest_of(ms)

        # Write record #1 to establish a baseline confirmed anchor.
        sm.add(
            "discord", "ch-crash-baseline", "c0" * 32,
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
        )
        sm.flush()

        # Phase 2: monkey-patch _write_tail_anchor_confirmed to no-op.
        # This simulates a crash AFTER the JSONL append (Phase 2) but
        # BEFORE the anchor_confirmed write (Phase 3). The anchor on disk
        # will have planned.count = 2 but confirmed.count = 1.
        original_confirmed = sm._write_tail_anchor_confirmed
        sm._write_tail_anchor_confirmed = lambda **kw: None  # no-op

        try:
            sm.add(
                "discord", "ch-crash-new", "c1" * 32,
                identity_id=LEGACY_IDENTITY_SENTINEL,
                body_id=LEGACY_BODY_SENTINEL,
            )
        finally:
            sm._write_tail_anchor_confirmed = original_confirmed

        # Phase 3: re-open workspace. Loader should detect planned > confirmed.
        ms2 = _make_ms(tmp_path)
        sm2 = _manifest_of(ms2)

        # Trigger load by calling health().
        health = sm2.health()
        integrity_state = sm2._integrity_state

        assert integrity_state in (
            "chain_crash_recovery", "chain_broken", "degraded"
        ), (
            f"Expected crash/broken/degraded state after anchor mismatch. "
            f"Got: {integrity_state!r}  health={health}"
        )

        # Phase 4: verify writes are refused.
        with pytest.raises(ManifestIntegrityError) as exc_info:
            sm2.add(
                "discord", "ch-crash-post", "c2" * 32,
                identity_id=LEGACY_IDENTITY_SENTINEL,
                body_id=LEGACY_BODY_SENTINEL,
            )

        msg = str(exc_info.value)
        assert any(
            kw in msg for kw in (
                "chain_crash_recovery", "chain_broken", "degraded",
                "hard-refuse", "writes refused",
            )
        ), f"Error must describe refused state. Got: {msg}"


# ---------------------------------------------------------------------------
# 5. Cluster E — Capability-token E2E
# ---------------------------------------------------------------------------

class TestE2EClusterECapabilityToken:
    """
    Verify the capability-token shield is real, not paper.

    - ``ms._source_manifest`` → AttributeError (name-mangled, not accessible).
    - ``ms.manifest(ms.internal_manifest_capability())`` → succeeds.
    - ``ms.manifest(WrongCapabilityToken())`` → PermissionError.
    """

    def test_e2e_cluster_e_capability_token(self, tmp_path, monkeypatch):
        import uuid
        from parsica_memory.core_v4 import ManifestCapability

        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        ms = _make_ms(tmp_path, monkeypatch=monkeypatch)

        # 1. Direct attribute access must fail with AttributeError.
        with pytest.raises(AttributeError):
            _ = ms._source_manifest

        # 2. Correct capability token must grant access.
        cap = ms.internal_manifest_capability()
        sm = ms.manifest(cap)
        assert sm is not None, "Valid capability must grant manifest access"

        # Confirm it is live by calling stats().
        stats = sm.stats()
        assert isinstance(stats, dict), "manifest.stats() must return a dict"

        # 3. Wrong capability tokens must raise PermissionError.
        wrong_cap = ManifestCapability("wrong-token-000")
        with pytest.raises(PermissionError):
            ms.manifest(wrong_cap)

        another_wrong = ManifestCapability(uuid.uuid4().hex)
        with pytest.raises(PermissionError):
            ms.manifest(another_wrong)


# ---------------------------------------------------------------------------
# 6. Cluster F — Exception hygiene E2E (R3.1 P0 regression test)
# ---------------------------------------------------------------------------

class TestE2EClusterFExceptionHygiene:
    """
    R3.1 P0 regression test.

    In a sealed workspace under PARSICA_MANIFEST_DEV_NO_HMAC=1,
    calling ``memory_system.forget(topic=...)`` must raise
    ``UnsealedWriteRefused``, NOT silently return success.

    This is the exact scenario that shipped as a P0 in R3.1:
    - forget() tombstoned the in-memory list but the manifest write raised.
    - The exception was swallowed by a bare ``except Exception:``.
    - The caller received ``{'removed': [...]}`` (success!) while the
      manifest was never written.

    After R4.1 Cluster F, UnsealedWriteRefused must propagate.
    """

    def test_e2e_cluster_f_exception_hygiene_forget_raises(self, tmp_path):
        from parsica_memory.source_manifest import UnsealedWriteRefused

        # Phase 1: create workspace with REAL HMAC chain (no NO_HMAC).
        ms1 = _make_ms(tmp_path)
        sm1 = _manifest_of(ms1)
        from parsica_memory.source_manifest import LEGACY_IDENTITY_SENTINEL, LEGACY_BODY_SENTINEL
        sm1.add(
            "discord", "ch-f-test", "e" * 64,
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
        )
        sm1.flush()
        del ms1, sm1

        # Phase 2: re-open the sealed workspace with PARSICA_MANIFEST_DEV_NO_HMAC=1.
        os.environ["PARSICA_MANIFEST_DEV_NO_HMAC"] = "1"
        try:
            ms2 = _make_ms(tmp_path, no_hmac=True, segments=True)

            # Add an entry directly to ms2.memories so forget_topic() returns
            # a non-empty set (otherwise forget() returns early before touching
            # the manifest at all).
            from parsica_memory.entry import MemoryEntry
            entry = MemoryEntry(
                content="cluster-f-exception-hygiene test content",
                category="general",
                source="internal",
            )
            ms2.memories.append(entry)
            ms2._hashes.add(entry.hash)

            # forget() must propagate UnsealedWriteRefused, NOT return success.
            with pytest.raises(UnsealedWriteRefused):
                ms2.forget(topic="cluster-f-exception-hygiene")

        finally:
            os.environ.pop("PARSICA_MANIFEST_DEV_NO_HMAC", None)


# ---------------------------------------------------------------------------
# 7. Cluster G — Multi-process E2E
# ---------------------------------------------------------------------------

class TestE2EClusterGMultiProcess:
    """
    Two subprocesses concurrently call ``SourceManifest.add()`` on the same
    workspace. After both finish:

    - Both records must be present (no data loss).
    - The manifest integrity state must be ``ok`` or ``legacy_pending_anchor``.
    - No lock timeout or chain corruption.
    """

    def test_e2e_cluster_g_multiprocess(self, tmp_path):
        _writer_script = textwrap.dedent("""
            import sys, os, warnings
            warnings.filterwarnings('ignore')

            workspace = sys.argv[1]
            record_hash = sys.argv[2]
            identity = sys.argv[3]

            os.environ['PARSICA_MANIFEST_DEV_NO_HMAC'] = '1'
            from parsica_memory.source_manifest import (
                SourceManifest, LEGACY_BODY_SENTINEL, LEGACY_IDENTITY_SENTINEL
            )

            sm = SourceManifest(workspace)
            sm.add(
                'discord', f'ch-multiproc-{identity}', record_hash,
                identity_id=identity,
                body_id=LEGACY_BODY_SENTINEL,
            )
            sm.flush()
            print(f'OK:{identity}')
        """)

        writer_path = tmp_path / "_writer.py"
        writer_path.write_text(_writer_script, encoding="utf-8")

        hash_a = "a0" * 32
        hash_b = "b0" * 32

        # Launch both processes simultaneously.
        proc_a = subprocess.Popen(
            [sys.executable, str(writer_path), str(tmp_path), hash_a, "proc-A"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        proc_b = subprocess.Popen(
            [sys.executable, str(writer_path), str(tmp_path), hash_b, "proc-B"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )

        out_a, err_a = proc_a.communicate(timeout=30)
        out_b, err_b = proc_b.communicate(timeout=30)

        assert proc_a.returncode == 0, (
            f"Process A failed (rc={proc_a.returncode}):\n{err_a.decode()}"
        )
        assert proc_b.returncode == 0, (
            f"Process B failed (rc={proc_b.returncode}):\n{err_b.decode()}"
        )
        assert b"OK:proc-A" in out_a, f"Process A bad output: {out_a.decode()}"
        assert b"OK:proc-B" in out_b, f"Process B bad output: {out_b.decode()}"

        # Reload the manifest and verify integrity + both records present.
        os.environ["PARSICA_MANIFEST_DEV_NO_HMAC"] = "1"
        try:
            from parsica_memory.source_manifest import SourceManifest, LEGACY_BODY_SENTINEL
            sm = SourceManifest(str(tmp_path))
            sm.stats()  # trigger full load

            assert sm._integrity_state in ("ok", "legacy_pending_anchor"), (
                f"Chain must be intact after concurrent writes. Got: {sm._integrity_state!r}"
            )

            recs_a = sm.lookup("discord", "ch-multiproc-proc-A", identity_id="proc-A")
            recs_b = sm.lookup("discord", "ch-multiproc-proc-B", identity_id="proc-B")
            assert len(recs_a) >= 1, "Record from process A must be present"
            assert len(recs_b) >= 1, "Record from process B must be present"
        finally:
            os.environ.pop("PARSICA_MANIFEST_DEV_NO_HMAC", None)


# ---------------------------------------------------------------------------
# 8. Cluster H — Pack consumer E2E
# ---------------------------------------------------------------------------

class TestE2EClusterHPackConsumer:
    """
    Cluster H wires pack-consumer code through ``get_by_source()``, which
    exercises the manifest health gate. On a tampered / corrupted manifest,
    ``get_by_source()`` must raise ``ManifestIntegrityError`` — the consumer
    must abort, not silently import records whose provenance is unverifiable.

    This test exercises the gated ``get_by_source()`` path directly, which
    is the intended pack-consumer entry point per the Cluster H spec.
    """

    def test_e2e_cluster_h_pack_consumer(
        self, tmp_path, monkeypatch
    ):
        """
        Direct regression: ``get_by_source(require_integrity=True)`` raises
        ManifestIntegrityError when the manifest is in a non-ok state.
        This is the exact guard the pack consumer uses.
        """
        from parsica_memory.source_manifest import ManifestIntegrityError

        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
        ms = _make_ms(tmp_path, monkeypatch=monkeypatch)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            ms.ingest(
                "pack consumer gating test",
                source="web",
                source_url="https://pack-h-gate.example/source",
            )

        # Force degraded state on the manifest.
        sm = _manifest_of(ms)
        sm._integrity_state = "degraded"

        with pytest.raises(ManifestIntegrityError) as exc_info:
            ms.get_by_source(
                "web",
                "https://pack-h-gate.example/source",
                identity_id="test-identity",
                require_integrity=True,
            )

        msg = str(exc_info.value)
        assert "degraded" in msg, f"Error must mention 'degraded'. Got: {msg}"


# ---------------------------------------------------------------------------
# 9. Integration happy-path
# ---------------------------------------------------------------------------

class TestE2EIntegrationHappyPath:
    """
    Full end-to-end integration test through MemorySystemV4 public API.

    Flow:
      ingest → manifest lookup (source recorded) → forget →
      memories cleared → re-ingest (untombstone) → memories present again.

    This is the "does the product work end-to-end" test. If this fails,
    nothing else matters.
    """

    def test_e2e_integration_happy_path(self, tmp_path, monkeypatch):
        from parsica_memory.source_manifest import (
            LEGACY_IDENTITY_SENTINEL,
            LEGACY_BODY_SENTINEL,
        )

        monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")

        ms = _make_ms(tmp_path, segments=True, monkeypatch=monkeypatch)
        content = "integration happy path: the wolf remembers and forgets with precision"
        src_url = "https://integration.example/happy-path"

        # ── Step 1: Ingest ─────────────────────────────────────────────────
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            added = ms.ingest(
                content,
                source="web",
                source_url=src_url,
            )
        assert added >= 1, f"ingest() must add at least 1 entry, got {added}"

        # ── Step 2: Manifest records the source provenance ─────────────────
        sm = _manifest_of(ms)
        manifest_records = sm.lookup("web", src_url, identity_id=LEGACY_IDENTITY_SENTINEL)
        assert len(manifest_records) >= 1, (
            f"After ingest, manifest must have source record. Got {manifest_records}"
        )

        # ── Step 3: Forget ─────────────────────────────────────────────────
        forget_result = ms.forget(topic="integration happy path")
        removed = forget_result.get("removed", [])
        assert len(removed) >= 1, f"forget() must remove at least 1 entry. Got {removed}"

        # ── Step 4: Memory must no longer be in active list ────────────────
        still_present = any(
            content[:30] in getattr(m, "content", "")
            for m in ms.memories
        )
        assert not still_present, "Forgotten content must not remain in memories"

        # ── Step 5: Re-ingest (untombstone path) ───────────────────────────
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            re_added = ms.ingest(
                content,
                source="web",
                source_url=src_url,
            )
        assert re_added >= 1, f"Re-ingest after forget() must succeed. Got {re_added}"

        # ── Step 6: Memory is present again ───────────────────────────────
        fresh_present = any(
            content[:30] in getattr(m, "content", "")
            for m in ms.memories
        )
        assert fresh_present, "Re-ingested content must be present in memories"
