"""R4.1 Cluster H — Pack/QTE functional manifest consumer wiring.

Unit tests for:
  - H-1 (P0-3 + P1-7): pack import manifest integrity gate + cross-identity
    source ID collision check.
  - H-2 (P0-3): pack assembly manifest health check.
  - H-3 (P1-8): forget() tombstones manifest on ALL backends, not just segmented.

Findings closed: P0-3, P1-7, P1-8.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock
from parsica_memory.core_v4 import MemorySystemV4
import pytest

from parsica_memory import MemorySystem
from parsica_memory.packs import KnowledgePack, PackAssembler
from parsica_memory.source_manifest import ManifestIntegrityError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store(tmp_path, use_segments=False):
    return MemorySystem(
        str(tmp_path),
        use_sharding=False,
        use_indexing=False,
        agent_name="test-agent",
    )


def _make_pack_jsonl(path: Path, pack_id: str, entries: list[dict]) -> str:
    """Write a minimal pack JSONL file. Returns the file path as str."""
    file_path = path / "test_pack.jsonl"
    with open(file_path, "w", encoding="utf-8") as f:
        header = {
            "_type": "parsica_pack_v1",
            "pack_id": pack_id,
            "name": "test-pack",
            "version": "1.0",
            "scope": "identity_durable",
            "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-01T00:00:00+00:00",
            "truth_state_policy": "accepted_only",
            "source_tags": [],
            "entry_ids": [],
            "provenance": {},
        }
        f.write(json.dumps(header) + "\n")
        for entry in entries:
            f.write(json.dumps(entry) + "\n")
    return str(file_path)


# ---------------------------------------------------------------------------
# H-1a: Pack import raises ManifestIntegrityError on degraded manifest
# ---------------------------------------------------------------------------

class TestPackImportIntegrityGate:
    """H-1a (P0-3): import_pack aborts cleanly when manifest is degraded."""

    def test_import_aborts_on_degraded_manifest(self, tmp_path):
        """ManifestIntegrityError propagates when get_by_source signals degraded."""
        mem = _make_store(tmp_path)
        pack_file = _make_pack_jsonl(
            tmp_path, "pack-abc",
            [{"content": "hello world", "memory_type": "episodic"}],
        )
        assembler = PackAssembler()

        # Patch get_by_source to simulate a degraded manifest
        with patch.object(
            mem, "get_by_source",
            side_effect=ManifestIntegrityError("chain_broken"),
        ):
            with pytest.raises(ManifestIntegrityError, match="import aborted"):
                assembler.import_pack(pack_file, mem)

    def test_import_succeeds_on_healthy_manifest(self, tmp_path):
        """Import completes normally when manifest integrity is ok."""
        mem = _make_store(tmp_path)
        pack_file = _make_pack_jsonl(
            tmp_path, "pack-xyz",
            [{"content": "the sky is blue", "memory_type": "episodic"}],
        )
        assembler = PackAssembler()
        pack = assembler.import_pack(pack_file, mem)
        assert pack.provenance.get("imported_count", 0) == 1

    def test_import_empty_pack_on_healthy_manifest(self, tmp_path):
        """Empty pack (header only) succeeds."""
        mem = _make_store(tmp_path)
        pack_file = _make_pack_jsonl(tmp_path, "pack-empty", [])
        assembler = PackAssembler()
        pack = assembler.import_pack(pack_file, mem)
        assert pack.provenance.get("imported_count", 0) == 0


# ---------------------------------------------------------------------------
# H-1b: Cross-identity source ID collision check (P1-7)
# ---------------------------------------------------------------------------

class TestPackImportCollisionCheck:
    """H-1b (P1-7): import_pack refuses when pack already exists under another identity."""

    def test_collision_refused_when_pack_imported_under_different_identity(self, tmp_path):
        """If manifest has 'imported_pack' + pack://PACKID under non-blank identity,
        re-import under blank identity must be refused."""
        mem = _make_store(tmp_path)
        pack_id = "pack-collision-test"
        pack_file = _make_pack_jsonl(
            tmp_path, pack_id,
            [{"content": "collision content", "memory_type": "episodic"}],
        )
        assembler = PackAssembler()

        # Simulate existing manifest entry under a different identity
        mock_view = MagicMock()
        mock_view.all_sources.return_value = [
            ("identity-A", "", "imported_pack", f"pack://{pack_id}/some_url"),
        ]

        with patch.object(MemorySystemV4, "source_manifest", new_callable=PropertyMock, return_value=mock_view):
            with pytest.raises(ValueError, match="Cross-identity source ID collision"):
                assembler.import_pack(pack_file, mem)

    def test_no_collision_when_same_blank_identity(self, tmp_path):
        """Existing entries under blank identity don't trigger collision refusal."""
        mem = _make_store(tmp_path)
        pack_id = "pack-no-collision"
        pack_file = _make_pack_jsonl(
            tmp_path, pack_id,
            [{"content": "no collision content", "memory_type": "episodic"}],
        )
        assembler = PackAssembler()

        # Existing entry under BLANK identity — should NOT trigger collision
        mock_view = MagicMock()
        mock_view.all_sources.return_value = [
            ("", "", "imported_pack", f"pack://{pack_id}/some_url"),
        ]

        with patch.object(MemorySystemV4, "source_manifest", new_callable=PropertyMock, return_value=mock_view):
            # Should not raise; import proceeds normally
            pack = assembler.import_pack(pack_file, mem)
            assert pack is not None

    def test_no_collision_when_different_pack_id(self, tmp_path):
        """Existing entries with a different pack ID don't trigger collision."""
        mem = _make_store(tmp_path)
        pack_id = "pack-different"
        pack_file = _make_pack_jsonl(
            tmp_path, pack_id,
            [{"content": "different pack content", "memory_type": "episodic"}],
        )
        assembler = PackAssembler()

        # Existing entry under non-blank identity but for a DIFFERENT pack_id
        mock_view = MagicMock()
        mock_view.all_sources.return_value = [
            ("identity-A", "", "imported_pack", "pack://other-pack/some_url"),
        ]

        with patch.object(MemorySystemV4, "source_manifest", new_callable=PropertyMock, return_value=mock_view):
            pack = assembler.import_pack(pack_file, mem)
            assert pack is not None


# ---------------------------------------------------------------------------
# H-2: Pack assembly manifest health check (P0-3)
# ---------------------------------------------------------------------------

class TestPackAssemblyManifestCheck:
    """H-2 (P0-3): assemble() raises ManifestIntegrityError on degraded manifest."""

    def test_assemble_raises_on_degraded_manifest(self, tmp_path):
        """assemble() propagates ManifestIntegrityError from get_by_source."""
        mem = _make_store(tmp_path)
        mem.ingest_fact("the sky is blue")
        assembler = PackAssembler()

        with patch.object(
            mem, "get_by_source",
            side_effect=ManifestIntegrityError("degraded"),
        ):
            with pytest.raises(ManifestIntegrityError):
                assembler.assemble(mem, "test-pack")

    def test_assemble_succeeds_on_healthy_manifest(self, tmp_path):
        """assemble() completes normally when manifest is healthy."""
        mem = _make_store(tmp_path)
        # Use unsafe_allow_body_local so entries are included regardless of scope
        mem.ingest_fact("the earth is round")
        assembler = PackAssembler()
        pack = assembler.assemble(mem, "test-pack", unsafe_allow_body_local=True)
        assert pack.name == "test-pack"
        assert len(pack.entry_ids) >= 1


# ---------------------------------------------------------------------------
# H-3: forget() tombstones on non-segmented backends (P1-8)
# ---------------------------------------------------------------------------

class TestForgetTombstoneBackendIndependence:
    """H-3 (P1-8): forget() must tombstone manifest on ALL backends."""

    def test_forget_tombstones_on_non_segmented_backend(self, tmp_path):
        """On WAL/legacy backend, _tombstone_entries is called after forget()."""
        mem = _make_store(tmp_path)  # non-segmented by default
        mem.ingest_fact("this fact should be forgotten and tombstoned")

        assert not mem._using_segments, "Test requires non-segmented backend"
        assert len(mem.memories) == 1

        tombstone_calls = []
        original_tombstone = mem._tombstone_entries

        def tracking_tombstone(entries, *, reason):
            tombstone_calls.append((list(entries), reason))
            return original_tombstone(entries, reason=reason)

        with patch.object(mem, "_tombstone_entries", side_effect=tracking_tombstone):
            result = mem.forget(topic="forgotten")

        assert len(result["removed"]) == 1, "Entry should have been forgotten"
        assert len(tombstone_calls) == 1, "_tombstone_entries must be called on non-segmented backend"
        assert tombstone_calls[0][1] == "forgotten"

    def test_forget_tombstones_on_segmented_backend(self, tmp_path):
        """On segmented backend, _tombstone_entries still runs (regression guard)."""
        mem = MemorySystem(
            str(tmp_path),
            use_sharding=True,
            use_indexing=False,
            agent_name="test-agent",
        )
        mem.ingest_fact("segmented backend forgotten fact")

        tombstone_calls = []
        original_tombstone = mem._tombstone_entries

        def tracking_tombstone(entries, *, reason):
            tombstone_calls.append((list(entries), reason))
            return original_tombstone(entries, reason=reason)

        with patch.object(mem, "_tombstone_entries", side_effect=tracking_tombstone):
            result = mem.forget(topic="forgotten")

        assert len(result["removed"]) == 1
        assert len(tombstone_calls) == 1
        assert tombstone_calls[0][1] == "forgotten"

    def test_forget_no_tombstone_when_nothing_forgotten(self, tmp_path):
        """_tombstone_entries is NOT called when forget() removes nothing."""
        mem = _make_store(tmp_path)
        mem.ingest_fact("this fact has nothing to do with the query")

        tombstone_calls = []
        original_tombstone = mem._tombstone_entries

        def tracking_tombstone(entries, *, reason):
            tombstone_calls.append((list(entries), reason))
            return original_tombstone(entries, reason=reason)

        with patch.object(mem, "_tombstone_entries", side_effect=tracking_tombstone):
            result = mem.forget(topic="completely unrelated topic xyz")

        assert len(result["removed"]) == 0
        assert len(tombstone_calls) == 0, "_tombstone_entries should not run when nothing removed"

    def test_forget_manifest_tombstone_visible_after_non_segmented(self, tmp_path):
        """After forget() on non-segmented backend, manifest reflects tombstone."""
        mem = _make_store(tmp_path)
        mem.ingest_fact("provenance-tracked fact to be forgotten")

        assert not mem._using_segments

        # Check initial manifest state
        stats_before = mem.source_stats()
        total_before = stats_before.get("total_records", 0)

        result = mem.forget(topic="provenance-tracked")
        assert len(result["removed"]) == 1

        # After forget, tombstoned count should have increased
        stats_after = mem.source_stats()
        tombstoned_after = stats_after.get("tombstoned_records", 0)
        assert tombstoned_after >= 1, (
            "Manifest tombstone_count must increase after forget() on non-segmented backend"
        )
