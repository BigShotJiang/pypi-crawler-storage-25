from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from antaris_agent.daemon_cli import (
    AgentTarget,
    _cmd_start,
    _cmd_status,
    render_launchd_plist,
    render_systemd_unit,
    resolve_agent_target,
)


def test_resolve_agent_target_default_uses_default_config_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTARIS_CONFIG_DIR", str(tmp_path / "default-body"))
    target = resolve_agent_target()
    assert target.agent == "default"
    assert target.config_dir == (tmp_path / "default-body").resolve()
    assert target.pid_file == target.config_dir / "bot.pid"


def test_resolve_agent_target_named_uses_registry(monkeypatch, tmp_path):
    config_dir = tmp_path / "bodies" / "alpha"
    monkeypatch.setattr(
        "antaris_agent.daemon_cli._load_registry",
        lambda: {"alpha": str(config_dir)},
    )
    target = resolve_agent_target("alpha")
    assert target.agent == "alpha"
    assert target.config_dir == config_dir.resolve()


def test_render_systemd_unit_uses_antarisd_run_and_isolated_config(tmp_path):
    target = AgentTarget(
        agent="alpha",
        config_dir=tmp_path / "alpha",
        pid_file=tmp_path / "alpha" / "bot.pid",
        log_file=tmp_path / "alpha" / "logs" / "antarisd.log",
        socket_file=tmp_path / "alpha" / "antarisd.sock",
    )
    unit = render_systemd_unit(target, "/usr/local/bin/antarisd")
    assert "ExecStart=/usr/local/bin/antarisd run alpha" in unit
    assert f"Environment=ANTARIS_CONFIG_DIR={target.config_dir}" in unit
    assert str(target.log_file) in unit


def test_render_launchd_plist_uses_antarisd_run_and_isolated_config(tmp_path):
    target = AgentTarget(
        agent="beta",
        config_dir=tmp_path / "beta",
        pid_file=tmp_path / "beta" / "bot.pid",
        log_file=tmp_path / "beta" / "logs" / "antarisd.log",
        socket_file=tmp_path / "beta" / "antarisd.sock",
    )
    plist = render_launchd_plist(target, "/opt/homebrew/bin/antarisd", "ai.antarisanalytics.antarisd.beta")
    assert "<string>/opt/homebrew/bin/antarisd</string>" in plist
    assert "<string>run</string>" in plist
    assert "<string>beta</string>" in plist
    assert f"<string>{target.config_dir}</string>" in plist


def test_cmd_status_reports_running(monkeypatch, tmp_path, capsys):
    target = AgentTarget(
        agent="alpha",
        config_dir=tmp_path / "alpha",
        pid_file=tmp_path / "alpha" / "bot.pid",
        log_file=tmp_path / "alpha" / "logs" / "antarisd.log",
        socket_file=tmp_path / "alpha" / "antarisd.sock",
    )
    target.pid_file.parent.mkdir(parents=True, exist_ok=True)
    target.pid_file.write_text("4242")
    monkeypatch.setattr("antaris_agent.daemon_cli._is_pid_alive", lambda pid: True)

    rc = _cmd_status(target)
    out = capsys.readouterr().out

    assert rc == 0
    assert "Status:  running" in out
    assert "PID:     4242" in out


def test_cmd_start_spawns_background_run_for_target(monkeypatch, tmp_path, capsys):
    target = AgentTarget(
        agent="alpha",
        config_dir=tmp_path / "alpha",
        pid_file=tmp_path / "alpha" / "bot.pid",
        log_file=tmp_path / "alpha" / "logs" / "antarisd.log",
        socket_file=tmp_path / "alpha" / "antarisd.sock",
    )
    monkeypatch.setattr("antaris_agent.daemon_cli._status_for_target", lambda _t: ("stopped", None))
    monkeypatch.setattr("antaris_agent.daemon_cli.shutil.which", lambda name: "/usr/local/bin/antarisd" if name == "antarisd" else "/usr/local/bin/antaris")
    monkeypatch.setattr("antaris_agent.daemon_cli.time.sleep", lambda _: None)

    popen_calls = {}

    def fake_popen(cmd, **kwargs):
        popen_calls["cmd"] = cmd
        popen_calls["kwargs"] = kwargs
        proc = MagicMock()
        proc.pid = 99999
        return proc

    monkeypatch.setattr("antaris_agent.daemon_cli.subprocess.Popen", fake_popen)

    rc = _cmd_start(target)
    out = capsys.readouterr().out

    assert rc == 0
    assert popen_calls["cmd"] == ["/usr/local/bin/antarisd", "run", "alpha"]
    assert popen_calls["kwargs"]["env"]["ANTARIS_CONFIG_DIR"] == str(target.config_dir)
    assert popen_calls["kwargs"]["start_new_session"] is True
    assert "Starting agent 'alpha'" in out
