"""Tests for the identity stack — AGENTS.md, MEMORY.md, HEARTBEAT.md, and context cadence."""

import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from antaris_agent.persona.context_cadence import ContextCadence
from antaris_agent.persona.loader import PersonaLoader

from antaris_agent.core.config import DEFAULT_CONFIG_DIR

# ── Helpers ─────────────────────────────────────────────────────────────────

ANTARISBOT_DIR = DEFAULT_CONFIG_DIR

# Smoke-test marker: these tests require a fully deployed config directory
# with identity files and will be skipped in CI or on machines without them.
_has_identity_files = (
    (ANTARISBOT_DIR / "SOUL.md").exists()
    and (ANTARISBOT_DIR / "context.json").exists()
)
requires_config_dir = pytest.mark.skipif(
    not _has_identity_files,
    reason=f"Deployed identity files not present in {ANTARISBOT_DIR} (CI / fresh machine)",
)


# ── File existence tests (smoke-tests: require deployed config dir) ──────────

@requires_config_dir
def test_agents_md_exists():
    path = ANTARISBOT_DIR / "AGENTS.md"
    assert path.exists(), f"AGENTS.md not found at {path}"


@requires_config_dir
def test_agents_md_has_content():
    path = ANTARISBOT_DIR / "AGENTS.md"
    content = path.read_text().strip()
    assert len(content) > 0, "AGENTS.md is empty"


@requires_config_dir
def test_agents_md_contains_identity_section():
    path = ANTARISBOT_DIR / "AGENTS.md"
    content = path.read_text()
    # These checks are deployment-specific; skip assertions about agent name
    assert "Antaris" in content, "AGENTS.md must mention Antaris"


@requires_config_dir
def test_memory_md_exists():
    path = ANTARISBOT_DIR / "MEMORY.md"
    assert path.exists(), f"MEMORY.md not found at {path}"


@requires_config_dir
def test_memory_md_has_content():
    path = ANTARISBOT_DIR / "MEMORY.md"
    content = path.read_text().strip()
    assert len(content) > 0, "MEMORY.md is empty"


@requires_config_dir
def test_memory_md_contains_team_section():
    path = ANTARISBOT_DIR / "MEMORY.md"
    content = path.read_text()
    assert "Antaris" in content, "MEMORY.md must mention Antaris"


@requires_config_dir
def test_heartbeat_md_exists():
    path = ANTARISBOT_DIR / "HEARTBEAT.md"
    assert path.exists(), f"HEARTBEAT.md not found at {path}"


@requires_config_dir
def test_heartbeat_md_has_content():
    path = ANTARISBOT_DIR / "HEARTBEAT.md"
    content = path.read_text().strip()
    assert len(content) > 0, "HEARTBEAT.md is empty"


# ── context.json tests (smoke-tests: require deployed config dir) ────────────

@requires_config_dir
def test_context_json_exists():
    path = ANTARISBOT_DIR / "context.json"
    assert path.exists(), f"context.json not found at {path}"


@requires_config_dir
def test_context_json_includes_agents_md_every():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "AGENTS.md" in data, "context.json must include AGENTS.md"
    assert data["AGENTS.md"] == "every", f"AGENTS.md cadence must be 'every', got: {data['AGENTS.md']}"


@requires_config_dir
def test_context_json_includes_memory_md_startup():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "MEMORY.md" in data, "context.json must include MEMORY.md"
    assert data["MEMORY.md"] == "startup", f"MEMORY.md cadence must be 'startup', got: {data['MEMORY.md']}"


@requires_config_dir
def test_context_json_preserves_soul_md():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "SOUL.md" in data, "context.json must still include SOUL.md"
    assert data["SOUL.md"] == "every", "SOUL.md cadence must remain 'every'"


@requires_config_dir
def test_context_json_preserves_tools_md():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "TOOLS.md" in data, "context.json must still include TOOLS.md"
    assert data["TOOLS.md"] == "startup", "TOOLS.md cadence must remain 'startup'"


# ── ContextCadence integration tests ────────────────────────────────────────

def _make_cadence_dir(files: dict[str, str], context_cfg: dict[str, str]) -> Path:
    """Create a temp dir with the given .md files and context.json, return the path."""
    tmp = Path(tempfile.mkdtemp())
    for name, content in files.items():
        (tmp / name).write_text(content)
    (tmp / "context.json").write_text(json.dumps(context_cfg))
    return tmp


def test_cadence_loads_agents_md_on_every_turn():
    """AGENTS.md with cadence 'every' must appear on every call to get_files_for_turn()."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "AGENTS.md": "# Agents\nNoFace rules.",
        },
        context_cfg={
            "SOUL.md": "every",
            "AGENTS.md": "every",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1
    turn1 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn1, "AGENTS.md must appear on turn 1"

    # Turn 2 — every cadence must repeat
    turn2 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn2, "AGENTS.md must appear on turn 2 (cadence=every)"


def test_cadence_loads_memory_md_on_startup_only():
    """MEMORY.md with cadence 'startup' must appear on first turn only."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "MEMORY.md": "# Memory\nLong-term memory.",
        },
        context_cfg={
            "SOUL.md": "every",
            "MEMORY.md": "startup",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1 — startup fires
    turn1 = dict(cadence.get_files_for_turn())
    assert "MEMORY.md" in turn1, "MEMORY.md must appear on startup turn"

    # Turn 2 — startup must NOT repeat
    turn2 = dict(cadence.get_files_for_turn())
    assert "MEMORY.md" not in turn2, "MEMORY.md must NOT appear after startup"


def test_cadence_manual_files_never_auto_inject():
    """FILES with cadence 'manual' must never appear in get_files_for_turn()."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul",
            "USER.md": "# User\nSome user data.",
        },
        context_cfg={
            "SOUL.md": "every",
            "USER.md": "manual",
        },
    )
    cadence = ContextCadence(config_dir)

    for _ in range(3):
        files = dict(cadence.get_files_for_turn())
        assert "USER.md" not in files, "USER.md (manual) must never auto-inject"


def test_persona_loader_includes_relay_framing_rule(tmp_path):
    (tmp_path / "SOUL.md").write_text("# Soul\nBe helpful.")
    (tmp_path / "context.json").write_text(json.dumps({"SOUL.md": "every"}))

    loader = PersonaLoader(str(tmp_path))
    prompt = loader.build_system_prompt([])

    assert "Address the current speaker" in prompt
    assert "draft/compose/write" in prompt


def test_cadence_agents_and_memory_together():
    """Combined test: AGENTS.md every + MEMORY.md startup."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "AGENTS.md": "# Agents\nRules here.",
            "MEMORY.md": "# Memory\nLong-term context.",
        },
        context_cfg={
            "SOUL.md": "every",
            "AGENTS.md": "every",
            "MEMORY.md": "startup",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1: all three should appear
    turn1 = dict(cadence.get_files_for_turn())
    assert "SOUL.md" in turn1
    assert "AGENTS.md" in turn1
    assert "MEMORY.md" in turn1

    # Turn 2: MEMORY.md must drop off
    turn2 = dict(cadence.get_files_for_turn())
    assert "SOUL.md" in turn2
    assert "AGENTS.md" in turn2
    assert "MEMORY.md" not in turn2

    # Turn 3: same as turn 2
    turn3 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn3
    assert "MEMORY.md" not in turn3


# ── Bot._message_count / compaction tracking tests ──────────────────────────

def test_bot_has_message_count_attribute():
    """Bot must expose _message_count initialised to 0."""
    from antaris_agent.core.bot import Bot
    with MagicMock() as mock_config:
        # Patch Config.load and _init_components to avoid real filesystem ops
        import unittest.mock as mock
        with mock.patch("antaris_agent.core.bot.Config.load") as mock_load, \
             mock.patch.object(Bot, "_init_components"):
            mock_load.return_value = MagicMock(
                config_path="/tmp/fake/config.json",
                validate=MagicMock(return_value=[]),
                auto_update=False,
                notify_updates=False,
            )
            bot = Bot.__new__(Bot)
            bot._message_count = 0
            bot._compaction_notified = False
            assert bot._message_count == 0
            assert bot._compaction_notified is False


def test_bot_message_count_increments():
    """Handler should increment the session count and sync the back-compat mirror."""
    import inspect
    from antaris_agent.core.bot import Bot
    source = inspect.getsource(Bot._make_handler)
    assert "increment_count" in source, "_make_handler must increment session message count"
    assert "_message_count" in source, "_make_handler must keep the back-compat mirror in sync"
    assert "compaction_notified" in source, "_make_handler must still wire compaction state"


def test_bot_compaction_log_at_100_messages():
    """Compaction ping must trigger when threshold is reached."""
    import inspect
    from antaris_agent.core.bot import Bot
    source = inspect.getsource(Bot._make_handler)
    assert "compaction_threshold" in source or "_threshold" in source, \
        "_make_handler must check configurable compaction threshold"
    assert "compaction" in source.lower(), \
        "_make_handler must trigger compaction-related logic"
