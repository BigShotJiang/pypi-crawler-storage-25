"""Tests for v2.9.3 ContextAssembler."""
import tempfile
import pytest
from parsica_memory import MemorySystem
from parsica_memory.context_assembler import (
    ContextAssembler, ContextAssemblyConfig, AssembledContext, estimate_tokens
)


def _make_store(tmp_path):
    return MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="test-agent")


def test_estimate_tokens_basic():
    assert estimate_tokens("") == 0
    assert estimate_tokens("hello world") == 2   # 11 chars // 4 = 2
    assert estimate_tokens("a" * 400) == 100


def test_assembly_produces_hash(tmp_path):
    """assembly_hash must be set and non-empty."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("test fact for hash verification")
    config = ContextAssemblyConfig(token_budget=500)
    ctx = ContextAssembler().assemble("user1", "agent:chan1", "sess1", config, mem)
    assert ctx.assembly_hash
    assert len(ctx.assembly_hash) == 64  # SHA256 hex


def test_assembly_hash_is_deterministic(tmp_path):
    """Same inputs must produce same assembly_hash."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("determinism test fact content here")
    config = ContextAssemblyConfig(token_budget=500)
    assembler = ContextAssembler()
    ctx1 = assembler.assemble("user1", "agent:chan1", "sess1", config, mem)
    ctx2 = assembler.assemble("user1", "agent:chan1", "sess1", config, mem)
    assert ctx1.assembly_hash == ctx2.assembly_hash


def test_token_budget_not_exceeded(tmp_path):
    """tokens_used must not exceed token_budget."""
    mem = _make_store(tmp_path)
    for i in range(20):
        mem.ingest_fact(f"fact number {i}: the quick brown fox jumps over the lazy dog repeatedly")
    config = ContextAssemblyConfig(token_budget=200)
    ctx = ContextAssembler().assemble("user1", "body1", "sess1", config, mem)
    assert ctx.tokens_used <= ctx.token_budget + 10  # small fudge for estimate_tokens rounding


def test_source_priority_session_before_durable(tmp_path):
    """Session entries appear before durable knowledge in render output."""
    mem = _make_store(tmp_path)
    # Add a durable fact
    mem.ingest_fact("durable fact about preferences and systems")
    # Add a body-local session entry
    entry = mem.ingest_turn("current session working note here", session_id="sess1")
    if entry:
        entry.retrieval_scope = "body_local"
        entry.body_id = "agent:chan1"

    config = ContextAssemblyConfig(token_budget=1000)
    ctx = ContextAssembler().assemble("user1", "agent:chan1", "sess1", config, mem)
    rendered = ctx.render()
    if ctx.current_session_block and ctx.durable_knowledge_block:
        session_pos = rendered.find(ctx.current_session_block[:20])
        durable_pos = rendered.find(ctx.durable_knowledge_block[:20])
        assert session_pos < durable_pos, "Session block must come before durable knowledge"


def test_retracted_excluded_from_assembly(tmp_path):
    """Retracted records must not appear in assembled context."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("this fact is retracted and must not appear in context")
    mem.ingest_fact("this fact is alive and should appear")
    for m in mem.memories:
        if "retracted" in m.content:
            m.truth_state = "retracted"

    config = ContextAssemblyConfig(token_budget=1000)
    ctx = ContextAssembler().assemble("user1", "body1", "sess1", config, mem)
    rendered = ctx.render()
    assert "retracted and must not appear" not in rendered


def test_assembled_context_render_non_empty(tmp_path):
    """render() must return non-empty string when context has content."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("important fact about the system architecture here")
    config = ContextAssemblyConfig(token_budget=500)
    ctx = ContextAssembler().assemble("user1", "body1", "sess1", config, mem)
    if not ctx.is_empty():
        assert ctx.render().strip()


def test_assembled_context_is_empty_on_empty_store(tmp_path):
    """Empty store produces empty context."""
    mem = _make_store(tmp_path)
    config = ContextAssemblyConfig(token_budget=500)
    ctx = ContextAssembler().assemble("user1", "body1", "sess1", config, mem)
    # May or may not be empty depending on what's in store — just check no exception
    assert isinstance(ctx, AssembledContext)


def test_handoff_block_populated_from_handoff_data(tmp_path):
    """handoff_data dict must appear in handoff_block."""
    mem = _make_store(tmp_path)
    config = ContextAssemblyConfig(token_budget=1000)
    ctx = ContextAssembler().assemble(
        "user1", "body1", "sess1", config, mem,
        handoff_data={"task": "fix the parsing bug", "context": "PR #42"},
    )
    assert "fix the parsing bug" in ctx.handoff_block


def test_zero_budget_returns_empty(tmp_path):
    """Zero token budget returns empty context without error."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("this fact should not appear with zero budget")
    config = ContextAssemblyConfig(token_budget=0)
    ctx = ContextAssembler().assemble("user1", "body1", "sess1", config, mem)
    assert ctx.tokens_used == 0
    assert ctx.is_empty()
