import tempfile
from antaris_agent.core.memory import BotMemory
from parsica_memory import MemorySystem
from parsica_memory.context_packet import ContextPacketBuilder
from parsica_memory.contracts import (
    IngestEnvelope,
    RetrievalPurpose,
    SideEffectMode,
    RetrievalRequest,
)


class _RecentItem:
    def __init__(self, content, timestamp, session_id=""):
        self.content = content
        self.timestamp = timestamp
        self.session_id = session_id


class _RecentStore:
    def __init__(self, items):
        self.items = items
        self.calls = 0

    def recall_recent(self, hours=6.0, limit=5):
        self.calls += 1
        return self.items[:limit]


def test_context_packet_build_is_pure_read():
    captured = {}

    class FakeMem:
        memories = []

        def retrieve(self, request):
            captured["request"] = request
            return []

    builder = ContextPacketBuilder(FakeMem())
    packet = builder.build("debug the install", max_memories=3)

    assert packet.metadata["results_found"] == 0
    assert captured["request"].purpose == RetrievalPurpose.CONTEXT_PACK
    assert captured["request"].side_effect_mode == SideEffectMode.PURE_READ


def test_cross_session_knowledge_only_allows_fact_not_turn():
    with tempfile.TemporaryDirectory() as td:
        # Use no agent_name so all records are in the same unscoped store
        mem = MemorySystem(workspace=td, use_sharding=False, use_indexing=False)

        mem.ingest_turn(
            "python turn only",
            session_id="session-other",
            user_id="user-1",
        )

        fact_envelope = IngestEnvelope.for_fact(
            "python durable fact",
            session_id="session-other",
        )
        mem.ingest(
            "python durable fact",
            source="pipeline",
            session_id="session-other",
            _envelope=fact_envelope,
        )

        results = mem.search(
            "python",
            limit=10,
            session_id="session-current",
            cross_session_recall="knowledge_only",
            read_only=True,
        )

        contents = [r.content for r in results]
        assert "python durable fact" in contents
        assert "python turn only" not in contents


def test_search_recent_excludes_session_without_empty_result_bug():
    bot_memory = BotMemory(store_path=tempfile.mkdtemp())
    store = _RecentStore(
        [
            _RecentItem("excluded", "2026-04-10T00:00:00Z", session_id="sess-a"),
            _RecentItem("kept", "2026-04-10T00:01:00Z", session_id="sess-b"),
        ]
    )
    bot_memory._get_store = lambda user_id: store

    results = bot_memory.search_recent(
        user_id="alice",
        hours=6.0,
        limit=5,
        exclude_session="sess-a",
    )

    assert [r.content for r in results] == ["kept"]
    assert store.calls == 1


def test_pure_read_does_not_mutate_access_counts():
    with tempfile.TemporaryDirectory() as td:
        mem = MemorySystem(workspace=td, use_sharding=False, use_indexing=False, agent_name="test-agent")
        fact_envelope = IngestEnvelope.for_fact(
            "pure read target",
            session_id="session-a",
            agent_id="agent-1",
        )
        mem.ingest(
            "pure read target",
            source="pipeline",
            session_id="session-a",
            agent_id="agent-1",
            _envelope=fact_envelope,
        )

        target = next(entry for entry in mem.memories if entry.content == "pure read target")
        before_count = target.access_count
        before_accessed = target.last_accessed

        items = mem.retrieve(
            RetrievalRequest(
                query="pure read",
                purpose=RetrievalPurpose.CONTEXT_PACK,
                side_effect_mode=SideEffectMode.PURE_READ,
                limit=5,
                min_confidence=0.0,
                cross_session_policy=fact_envelope.cross_session_policy,
                session_id="session-a",
                agent_id="agent-1",
                filters={},
            ),
            persist_trace=False,
        )

        assert any(item.content == "pure read target" for item in items)
        assert target.access_count == before_count
        assert target.last_accessed == before_accessed
