"""Tests for v2.9.1 scope policy and version-aware ranking."""
import pytest
import tempfile
from parsica_memory import MemorySystem
from parsica_memory.scope_utils import compute_body_id, normalize_loaded_entry, stable_hash
from parsica_memory.contracts import make_default_scope_policy, TRUTH_STATE_WEIGHTS
from parsica_memory.entry import MemoryEntry


def test_legacy_turn_records_do_not_become_identity_durable_on_load():
    e = MemoryEntry("test turn", "conversation", 0, "general", memory_type="episodic")
    e.record_kind = "turn"
    e.retrieval_scope = ""
    normalize_loaded_entry(e)
    assert e.retrieval_scope == "body_local", f"Expected body_local, got {e.retrieval_scope}"


def test_legacy_fact_gets_identity_durable():
    e = MemoryEntry("I prefer dark mode", "fact", 0, "general", memory_type="fact")
    e.record_kind = "fact"
    e.retrieval_scope = ""
    normalize_loaded_entry(e)
    assert e.retrieval_scope == "identity_durable"


def test_legacy_body_local_without_body_id_gets_sentinel():
    e = MemoryEntry("session note", "turn", 0, "general", memory_type="episodic")
    e.record_kind = "turn"
    e.retrieval_scope = ""
    e.body_id = ""
    normalize_loaded_entry(e)
    assert e.retrieval_scope == "body_local"
    assert e.body_id == "__legacy_unknown_body__"


def test_make_default_scope_policy_includes_all_three_by_default():
    p = make_default_scope_policy("agent1", "agent1:discord:123")
    assert "identity_durable" in p.allowed_scopes
    assert "handoff_visible" in p.allowed_scopes
    assert "body_local" in p.allowed_scopes


def test_make_default_scope_policy_excludes_body_local_when_requested():
    p = make_default_scope_policy("agent1", "agent1:discord:123", include_body_local=False)
    assert "body_local" not in p.allowed_scopes
    assert "identity_durable" in p.allowed_scopes


def test_truth_state_weights_values():
    assert TRUTH_STATE_WEIGHTS["accepted"] == 1.0
    assert TRUTH_STATE_WEIGHTS["superseded"] == 0.5
    assert TRUTH_STATE_WEIGHTS["retracted"] == 0.0


def test_compute_body_id_uses_source_channel_first():
    assert compute_body_id("moro", "discord:123", "456", "sess789") == "moro:discord:123"


def test_compute_body_id_falls_back_to_channel_id():
    assert compute_body_id("moro", "", "456", "sess789") == "moro:456"


def test_compute_body_id_falls_back_to_session_id():
    assert compute_body_id("moro", "", "", "sess789") == "moro:sess789"


def test_stable_hash_is_deterministic():
    obj = {"b": 2, "a": 1, "c": [3, 1, 2]}
    assert stable_hash(obj) == stable_hash(obj)
    assert len(stable_hash(obj)) == 64


def test_ingest_turn_gets_body_local_scope():
    with tempfile.TemporaryDirectory() as td:
        mem = MemorySystem(td, use_sharding=False, use_indexing=False, agent_name="test")
        entry = mem.ingest_turn("hello world long enough turn text here", session_id="s1")
        if entry is not None:
            assert entry.retrieval_scope == "body_local", f"Got {entry.retrieval_scope!r}"


def test_ingest_fact_gets_identity_durable_scope():
    with tempfile.TemporaryDirectory() as td:
        mem = MemorySystem(td, use_sharding=False, use_indexing=False, agent_name="test")
        mem.ingest_fact("the sky is blue and the grass is green")
        facts = [m for m in mem.memories if m.memory_type == "fact"]
        if facts:
            assert facts[0].retrieval_scope == "identity_durable", f"Got {facts[0].retrieval_scope!r}"


def test_retrieval_scope_round_trips_through_dict():
    e = MemoryEntry("test memory entry content here", "inline", 0, "general")
    e.retrieval_scope = "identity_durable"
    d = e.to_dict()
    e2 = MemoryEntry.from_dict(d)
    assert e2.retrieval_scope == "identity_durable"


# --- R2: P0 fix tests ---

def test_rank_results_body_local_excludes_wrong_body():
    """Body-local entry from body A must not appear in results for body B."""
    from parsica_memory.retrieval import rank_results_version_aware
    from parsica_memory.contracts import make_default_scope_policy
    from parsica_memory.entry import MemoryEntry

    class FakeHit:
        def __init__(self, content, scope, body, identity="moro"):
            self.entry = MemoryEntry(content, "test", 0, "general")
            self.entry.retrieval_scope = scope
            self.entry.body_id = body
            self.entry.identity_id = identity  # v3.0.4: stamp identity so durable records survive identity filter
            self.entry.truth_state = "accepted"
            self.entry.record_id = content[:8]
            self.entry.created = ""
            self.score = 1.0
            self.relevance = 1.0

    # Two body-local entries from different bodies, one identity-durable
    hits = [
        FakeHit("body A fact", "body_local", "moro:discord:A"),
        FakeHit("body B fact", "body_local", "moro:discord:B"),
        FakeHit("durable fact", "identity_durable", ""),
    ]
    policy = make_default_scope_policy("moro", "moro:discord:A")
    results = rank_results_version_aware(hits, policy)
    contents = [h.entry.content for h in results]
    assert "body A fact" in contents, "body A's own entry should be visible"
    assert "body B fact" not in contents, "body B's entry must NOT cross to body A"
    assert "durable fact" in contents, "identity_durable must always be visible"


def test_rank_results_excludes_retracted():
    """Retracted entries must be excluded from ranked results."""
    from parsica_memory.retrieval import rank_results_version_aware
    from parsica_memory.contracts import make_default_scope_policy
    from parsica_memory.entry import MemoryEntry

    class FakeHit:
        def __init__(self, content, ts):
            self.entry = MemoryEntry(content, "test", 0, "general")
            self.entry.retrieval_scope = "identity_durable"
            self.entry.body_id = ""
            self.entry.identity_id = "moro"  # v3.0.4: stamp identity to survive identity_id filter
            self.entry.truth_state = ts
            self.entry.record_id = content[:8]
            self.entry.created = ""
            self.score = 1.0
            self.relevance = 1.0

    hits = [
        FakeHit("accepted fact", "accepted"),
        FakeHit("retracted fact", "retracted"),
        FakeHit("superseded fact", "superseded"),
    ]
    policy = make_default_scope_policy("moro", "moro:discord:A")
    results = rank_results_version_aware(hits, policy)
    contents = [h.entry.content for h in results]
    assert "accepted fact" in contents
    assert "retracted fact" not in contents, "Retracted must be excluded"
    assert "superseded fact" in contents, "Superseded kept but downweighted"


def test_rank_results_legacy_sentinel_excluded_cross_body():
    """__legacy_unknown_body__ entries must be excluded from cross-body results."""
    from parsica_memory.retrieval import rank_results_version_aware
    from parsica_memory.contracts import make_default_scope_policy
    from parsica_memory.entry import MemoryEntry

    class FakeHit:
        def __init__(self, content, body):
            self.entry = MemoryEntry(content, "test", 0, "general")
            self.entry.retrieval_scope = "body_local"
            self.entry.body_id = body
            self.entry.truth_state = "accepted"
            self.entry.record_id = content[:8]
            self.entry.created = ""
            self.score = 1.0
            self.relevance = 1.0

    hits = [
        FakeHit("legacy entry", "__legacy_unknown_body__"),
        FakeHit("known body entry", "moro:discord:A"),
    ]
    policy = make_default_scope_policy("moro", "moro:discord:B")
    results = rank_results_version_aware(hits, policy)
    contents = [h.entry.content for h in results]
    assert "legacy entry" not in contents, "__legacy_unknown_body__ must be excluded"


def test_stable_hash_key_order_invariant():
    """stable_hash must produce same result regardless of dict key insertion order."""
    h1 = stable_hash({"a": 1, "b": 2, "c": 3})
    h2 = stable_hash({"c": 3, "a": 1, "b": 2})
    h3 = stable_hash({"b": 2, "c": 3, "a": 1})
    assert h1 == h2 == h3, "stable_hash must be key-order invariant"


def test_infer_scope_document_and_unknown_are_body_local():
    """document and unknown record kinds must map to body_local (not identity_durable)."""
    from parsica_memory.scope_utils import infer_retrieval_scope
    from parsica_memory.entry import MemoryEntry

    for kind in ("document", "unknown", ""):
        e = MemoryEntry("test content here", "test", 0, "general")
        e.record_kind = kind
        e.memory_type = kind
        result = infer_retrieval_scope(e)
        assert result == "body_local", f"Expected body_local for kind={kind!r}, got {result!r}"
