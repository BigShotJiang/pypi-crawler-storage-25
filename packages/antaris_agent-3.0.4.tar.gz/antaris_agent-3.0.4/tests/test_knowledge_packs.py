"""Tests for v2.9.2 Knowledge Packs."""
import json
import os
import tempfile
import pytest
from parsica_memory import MemorySystem
from parsica_memory.packs import KnowledgePack, PackAssembler


def _make_store(tmp_path):
    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="test-agent")
    return mem


def test_pack_assembly_basic(tmp_path):
    """Pack assembles fact + preference entries, excludes turns."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("the sky is blue and always has been")
    mem.ingest_preference("I prefer concise answers over verbose ones")
    mem.ingest_turn("hello how are you doing today", session_id="s1")

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "test-pack")

    assert pack.name == "test-pack"
    assert len(pack.entry_ids) == 2   # fact + preference, not turn
    entries = assembler.get_pack_entries(pack, mem)
    contents = [e.content for e in entries]
    assert any("sky" in c for c in contents)
    assert any("prefer" in c.lower() for c in contents)


def test_pack_assembly_excludes_body_local_by_default(tmp_path):
    """Pack assembly must exclude body_local records by default (R3 Patch 3)."""
    mem = _make_store(tmp_path)
    # Force a body_local fact
    mem.ingest_fact("local session note only")
    for e in mem.memories:
        if "local session note" in e.content:
            e.retrieval_scope = "body_local"

    mem.ingest_fact("global durable fact about the universe")

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "clean-pack")
    entries = assembler.get_pack_entries(pack, mem)
    contents = [e.content for e in entries]
    assert not any("local session note" in c for c in contents), "body_local must be excluded"
    assert any("global durable fact" in c for c in contents)


def test_pack_assembly_excludes_retracted(tmp_path):
    """Pack must not include retracted records."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("this fact will be retracted from the record")
    mem.ingest_fact("this fact is alive and well")

    # Retract the first fact
    for e in mem.memories:
        if "retracted" in e.content:
            e.truth_state = "retracted"

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "live-only-pack")
    entries = assembler.get_pack_entries(pack, mem)
    contents = [e.content for e in entries]
    assert not any("retracted" in c for c in contents)
    assert any("alive and well" in c for c in contents)


def test_pack_export_import_round_trip(tmp_path):
    """Export pack → import on fresh store → same content recoverable."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("exportable durable knowledge about parsica")
    mem.ingest_preference("I always prefer dark mode interfaces")

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "export-test")
    export_path = str(tmp_path / "test_pack.jsonl")
    written = assembler.export_pack(pack, mem, export_path)
    assert written == 2

    # Import into fresh store
    mem2 = _make_store(tmp_path / "store2")
    imported_pack = assembler.import_pack(export_path, mem2)
    assert imported_pack.provenance.get("imported_count", 0) > 0
    assert any("parsica" in m.content for m in mem2.memories)


def test_pack_get_entries_resolves_live_record(tmp_path):
    """get_pack_entries must resolve superseded records to live versions."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("original fact content version one")

    # Get the original entry
    facts = [m for m in mem.memories if m.memory_type == "fact"]
    assert facts, "Should have at least one fact"
    original = facts[0]
    original_id = original.record_id

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "resolve-test")
    assert original_id in pack.entry_ids

    # Now mark original as superseded
    original.truth_state = "superseded"
    original.superseded_by_id = "new_record_123"

    # Pack should see original as superseded — accepted_only pack excludes it
    entries = assembler.get_pack_entries(pack, mem)
    # In accepted_only mode + no replacement record: superseded entry filtered out is OK
    # Just verify no exception thrown and pack resolution runs
    assert isinstance(entries, list)


def test_pack_save_and_load(tmp_path):
    """Pack saves to and loads from _meta/packs/<pack_id>.json."""
    mem = _make_store(tmp_path)
    mem.ingest_fact("persistent fact for pack storage test")

    assembler = PackAssembler()
    pack = assembler.assemble(mem, "saved-pack")
    path = assembler.save_pack(pack, str(tmp_path))
    assert os.path.exists(path)

    loaded = assembler.load_pack(pack.pack_id, str(tmp_path))
    assert loaded is not None
    assert loaded.name == "saved-pack"
    assert loaded.pack_id == pack.pack_id


def test_source_manifest_add_and_lookup(tmp_path):
    """SourceManifest add + lookup round-trips correctly."""
    from parsica_memory.source_manifest import SourceManifest
    manifest = SourceManifest(str(tmp_path))
    manifest.add("fact", "source_file.md", "record_001")
    manifest.add("fact", "source_file.md", "record_002")
    manifest.add("document", "web_page.html", "record_003")

    assert "record_001" in manifest.lookup("fact", "source_file.md")
    assert "record_002" in manifest.lookup("fact", "source_file.md")
    assert manifest.lookup("document", "web_page.html") == ["record_003"]
    assert manifest.lookup("fact", "nonexistent.md") == []


def test_source_manifest_persists_across_instances(tmp_path):
    """SourceManifest data survives reload from disk."""
    from parsica_memory.source_manifest import SourceManifest
    m1 = SourceManifest(str(tmp_path))
    m1.add("fact", "test.md", "abc123")

    m2 = SourceManifest(str(tmp_path))
    assert "abc123" in m2.lookup("fact", "test.md")


def test_knowledge_pack_to_from_dict_round_trip():
    """KnowledgePack serialization round-trips without data loss."""
    pack = KnowledgePack(
        name="test",
        entry_ids=["r1", "r2"],
        source_tags=["parsica", "memory"],
        truth_state_policy="accepted_only",
    )
    d = pack.to_dict()
    pack2 = KnowledgePack.from_dict(d)
    assert pack2.name == pack.name
    assert pack2.entry_ids == pack.entry_ids
    assert pack2.source_tags == pack.source_tags
    assert pack2.pack_id == pack.pack_id
