"""
test_retrieval_limit_cap.py

v3.0.4 (F-LIMIT-CAP): RetrievalRequest.limit is now bounded above by
MAX_RETRIEVAL_LIMIT (=500). Pre-v3.0.4 any positive integer was accepted,
including absurd values like 100_000 which could exhaust process memory.
"""

from __future__ import annotations

import pytest

from parsica_memory.contracts import MAX_RETRIEVAL_LIMIT, RetrievalRequest


def test_max_retrieval_limit_is_reasonable():
    """Sanity: the cap should be a positive integer in a sensible range."""
    assert isinstance(MAX_RETRIEVAL_LIMIT, int)
    assert 50 <= MAX_RETRIEVAL_LIMIT <= 10_000, (
        "MAX_RETRIEVAL_LIMIT should be realistic for production workloads"
    )


def test_limit_at_cap_is_accepted():
    """Exact cap must be accepted — it's an inclusive bound."""
    request = RetrievalRequest(query="x", limit=MAX_RETRIEVAL_LIMIT)
    assert request.limit == MAX_RETRIEVAL_LIMIT


def test_limit_one_over_cap_rejected():
    """One above the cap must raise ValueError."""
    with pytest.raises(ValueError, match="must be <="):
        RetrievalRequest(query="x", limit=MAX_RETRIEVAL_LIMIT + 1)


def test_limit_massive_rejected():
    """The specific attack vector: limit=100_000 must be rejected."""
    with pytest.raises(ValueError, match="must be <="):
        RetrievalRequest(query="x", limit=100_000)


def test_limit_below_one_still_rejected():
    """Regression: lower bound still enforced."""
    with pytest.raises(ValueError, match="must be >= 1"):
        RetrievalRequest(query="x", limit=0)

    with pytest.raises(ValueError, match="must be >= 1"):
        RetrievalRequest(query="x", limit=-5)


def test_default_limit_is_safe():
    """Default limit must be well below the cap."""
    request = RetrievalRequest(query="x")
    assert 1 <= request.limit <= MAX_RETRIEVAL_LIMIT


def test_limit_cap_error_message_suggests_batched_path():
    """Error message must point callers at the batched export path."""
    with pytest.raises(ValueError) as exc_info:
        RetrievalRequest(query="x", limit=100_000)
    msg = str(exc_info.value)
    assert "batched" in msg.lower(), (
        f"Error should point caller to batched path, got: {msg!r}"
    )
