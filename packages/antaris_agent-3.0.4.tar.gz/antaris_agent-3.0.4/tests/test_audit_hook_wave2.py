"""
Wave 2 Audit Hook Hardening — Regression Tests

Covers:
  1. fdopen / integer FD handling (false positive fix)
  2. stdlib MIME-type file reads (false positive fix)
  3. bundled Parsica package-data access (false positive fix)
  4. broader system read-only paths (/dev/null, /etc/ssl, etc.)
  5. security posture preserved (truly dangerous paths still blocked)
"""

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# We test the module's internal functions directly (without installing the
# irremovable sys.addaudithook) by importing the helpers and manipulating
# module-level state.
from antaris_agent.security import audit_hook
from antaris_agent.security.levels import (
    LEVEL_OPEN,
    LEVEL_STANDARD,
    LEVEL_SANDBOXED,
    LEVEL_SECURED,
    LEVEL_ENCRYPTED,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_audit_state(tmp_path):
    """Reset audit_hook module state before each test to avoid cross-contamination."""
    orig_level = audit_hook._LEVEL.value
    orig_workspace = audit_hook._WORKSPACE
    orig_allowed = audit_hook._ALLOWED_PATHS.copy()

    # Set up a known workspace for testing
    workspace = str(tmp_path / "workspace")
    os.makedirs(workspace, exist_ok=True)
    audit_hook._WORKSPACE = str(Path(workspace).resolve())
    audit_hook._ALLOWED_PATHS = audit_hook._build_allowed_paths()
    audit_hook._LEVEL._set(LEVEL_STANDARD)

    yield workspace

    # Restore
    audit_hook._LEVEL._set(orig_level)
    audit_hook._WORKSPACE = orig_workspace
    audit_hook._ALLOWED_PATHS = orig_allowed


# ---------------------------------------------------------------------------
# 1. fdopen / integer FD handling
# ---------------------------------------------------------------------------

class TestIntegerFDHandling:
    """Integer file descriptors must be allowed through the audit hook."""

    def test_integer_fd_not_blocked(self, _reset_audit_state):
        """The audit hook must not raise on integer FDs (os.fdopen scenario)."""
        audit_hook._LEVEL._set(LEVEL_SANDBOXED)  # Strictest file-access level
        # Simulate what Python fires for os.fdopen(fd):
        # sys.audit("open", fd, mode, flags) where fd is an int
        # The hook should return without raising.
        try:
            audit_hook._antaris_hook("open", (42, "r", 0))
        except PermissionError:
            pytest.fail("Integer FD should NOT trigger PermissionError")

    def test_integer_fd_zero(self, _reset_audit_state):
        """FD 0 (stdin) must be allowed."""
        audit_hook._LEVEL._set(LEVEL_ENCRYPTED)
        try:
            audit_hook._antaris_hook("open", (0, "r", 0))
        except PermissionError:
            pytest.fail("FD 0 (stdin) should NOT be blocked")

    def test_integer_fd_negative(self, _reset_audit_state):
        """Negative FDs (invalid but still int) should not crash."""
        audit_hook._LEVEL._set(LEVEL_SECURED)
        try:
            audit_hook._antaris_hook("open", (-1, "r", 0))
        except PermissionError:
            pytest.fail("Negative FD should not raise PermissionError")

    def test_string_path_still_checked(self, _reset_audit_state):
        """String paths are still validated (integer bypass is type-specific)."""
        audit_hook._LEVEL._set(LEVEL_STANDARD)
        # A path outside workspace should still be blocked
        with pytest.raises(PermissionError):
            audit_hook._antaris_hook("open", ("/root/.secret", "r", 0))


# ---------------------------------------------------------------------------
# 2. stdlib MIME-type reads
# ---------------------------------------------------------------------------

class TestMIMETypeReads:
    """MIME type files that Python's mimetypes module reads must be allowed."""

    @pytest.mark.parametrize(
        "mime_path",
        [
            "/etc/mime.types",
            "/etc/httpd/mime.types",
            "/etc/httpd/conf/mime.types",
            "/etc/apache/mime.types",
            "/etc/apache2/mime.types",
            "/usr/local/etc/mime.types",
            "/usr/local/etc/httpd/conf/mime.types",
            "/usr/share/mime/globs2",
            "/usr/share/mime/mime.cache",
            "/usr/share/mime/types",
        ],
    )
    def test_mime_path_allowed(self, _reset_audit_state, mime_path):
        """Known MIME file paths must pass _check_file_access."""
        assert audit_hook._check_file_access(mime_path), f"MIME path should be allowed: {mime_path}"

    def test_mime_path_not_exploitable(self, _reset_audit_state):
        """Paths that share a prefix with MIME paths but are not MIME files must still be blocked."""
        # /etc/mime.types_EVIL should not match /etc/mime.types
        assert not audit_hook._check_file_access("/etc/mime.types_evil")


# ---------------------------------------------------------------------------
# 3. Bundled Parsica package-data access
# ---------------------------------------------------------------------------

class TestParsicaPackageData:
    """Parsica memory's bundled data files (word_expansion.json etc.) must be accessible."""

    def test_parsica_data_dir_in_allowed_paths_after_install(self, _reset_audit_state):
        """install() should add the parsica_memory package dir to allowed paths."""
        # Re-run install logic (without actually calling sys.addaudithook)
        # by calling the internal setup
        try:
            import parsica_memory

            pm_dir = str(Path(parsica_memory.__file__).resolve().parent)
            # Simulate what install() does
            audit_hook._ALLOWED_PATHS.add(pm_dir)

            data_file = os.path.join(pm_dir, "data", "word_expansion.json")
            assert audit_hook._check_file_access(data_file), f"Parsica data file should be allowed: {data_file}"
        except ImportError:
            pytest.skip("parsica_memory not installed")

    def test_parsica_data_dir_allowed_in_repo_checkout(self, _reset_audit_state):
        """When running from repo checkout (workspace = repo root), parsica data is accessible."""
        # The repo root contains parsica_memory/data/
        repo_root = str(Path(__file__).resolve().parent.parent)
        audit_hook._WORKSPACE = repo_root

        data_file = os.path.join(repo_root, "parsica_memory", "data", "word_expansion.json")
        resolved = str(Path(data_file).resolve())
        assert audit_hook._check_file_access(resolved), f"Parsica data file inside workspace should be allowed: {resolved}"


# ---------------------------------------------------------------------------
# 4. System read-only paths (broader false-positive reduction)
# ---------------------------------------------------------------------------

class TestSystemReadPaths:
    """OS-provided read-only resources that stdlib needs must be allowed."""

    @pytest.mark.parametrize(
        "sys_path",
        [
            "/dev/null",
            "/dev/urandom",
            "/dev/random",
            "/dev/zero",
        ],
    )
    def test_dev_paths_allowed(self, _reset_audit_state, sys_path):
        """Device files like /dev/null and /dev/urandom must be allowed."""
        assert audit_hook._check_file_access(sys_path)

    @pytest.mark.parametrize(
        "sys_path",
        [
            "/etc/ssl/certs/ca-certificates.crt",
            "/etc/ssl/openssl.cnf",
            "/etc/pki/tls/certs/ca-bundle.crt",
        ],
    )
    def test_ssl_cert_paths_allowed(self, _reset_audit_state, sys_path):
        """SSL certificate store paths must be allowed for HTTPS to work."""
        assert audit_hook._check_file_access(sys_path)

    @pytest.mark.parametrize(
        "sys_path",
        [
            "/etc/localtime",
            "/usr/share/zoneinfo/UTC",
            "/usr/share/zoneinfo/America/Los_Angeles",
        ],
    )
    def test_timezone_paths_allowed(self, _reset_audit_state, sys_path):
        """Timezone data must be accessible."""
        assert audit_hook._check_file_access(sys_path)

    @pytest.mark.parametrize(
        "sys_path",
        [
            "/etc/hosts",
            "/etc/resolv.conf",
            "/etc/nsswitch.conf",
            "/etc/passwd",
            "/etc/group",
        ],
    )
    def test_network_system_paths_allowed(self, _reset_audit_state, sys_path):
        """System network config files must be readable (stdlib uses them)."""
        assert audit_hook._check_file_access(sys_path)

    def test_macos_private_etc_allowed(self, _reset_audit_state):
        """macOS /private/etc/ paths must be allowed (symlink target of /etc)."""
        assert audit_hook._check_file_access("/private/etc/hosts")
        assert audit_hook._check_file_access("/private/etc/ssl/openssl.cnf")

    @pytest.mark.parametrize(
        "sys_path",
        [
            "/usr/share/locale/en_US/LC_MESSAGES",
            "/usr/share/locale/C/LC_MESSAGES/libc.mo",
        ],
    )
    def test_locale_paths_allowed(self, _reset_audit_state, sys_path):
        """Locale data must be accessible."""
        assert audit_hook._check_file_access(sys_path)


# ---------------------------------------------------------------------------
# 5. Security posture preserved — dangerous paths still blocked
# ---------------------------------------------------------------------------

class TestSecurityPosturePreserved:
    """Confirm that the false-positive fixes did NOT weaken security for actually dangerous paths."""

    @pytest.mark.parametrize(
        "dangerous_path",
        [
            "/root/.ssh/id_rsa",
            "/root/.bash_history",
            "/home/otheruser/.ssh/authorized_keys",
            "/var/lib/postgresql/data/pg_hba.conf",
            "/opt/secrets/api_key.txt",
            "/usr/bin/malicious_script",
            "/etc/shadow",  # Sensitive — NOT in our allow list
        ],
    )
    def test_dangerous_paths_blocked(self, _reset_audit_state, dangerous_path):
        """Paths outside the workspace/allowed set must still be blocked."""
        assert not audit_hook._check_file_access(dangerous_path), f"Dangerous path should be BLOCKED: {dangerous_path}"

    def test_etc_shadow_blocked(self, _reset_audit_state):
        """/etc/shadow must be blocked — it's not in the system read-only list."""
        assert not audit_hook._check_file_access("/etc/shadow")

    def test_home_dir_root_blocked(self, _reset_audit_state):
        """The home directory itself (not subdirectories) must not be blanket-allowed."""
        home = str(Path.home().resolve())
        # Home dir itself is not in allowed subdirs (only specific subdirs are)
        some_file = os.path.join(home, "random_file.txt")
        assert not audit_hook._check_file_access(some_file), f"Arbitrary home file should be blocked: {some_file}"

    def test_audit_hook_blocks_file_at_sandboxed(self, _reset_audit_state):
        """Full audit hook path: _antaris_hook raises PermissionError for blocked paths."""
        audit_hook._LEVEL._set(LEVEL_SANDBOXED)
        with pytest.raises(PermissionError, match="File access blocked"):
            audit_hook._antaris_hook("open", ("/root/.ssh/id_rsa", "r", 0))

    def test_subprocess_still_blocked_at_sandboxed(self, _reset_audit_state):
        """Subprocess blocking is unchanged by Wave 2 fixes."""
        audit_hook._LEVEL._set(LEVEL_SANDBOXED)
        with pytest.raises(PermissionError, match="Subprocess execution blocked"):
            audit_hook._antaris_hook("subprocess.Popen", ())

    def test_network_still_blocked_at_secured(self, _reset_audit_state):
        """Network allowlist is unchanged by Wave 2 fixes."""
        audit_hook._LEVEL._set(LEVEL_SECURED)
        with pytest.raises(PermissionError, match="Network access blocked"):
            audit_hook._antaris_hook("socket.connect", (None, ("evil.com", 443)))

    def test_exec_still_blocked_at_encrypted(self, _reset_audit_state):
        """exec() blocking is unchanged by Wave 2 fixes."""
        audit_hook._LEVEL._set(LEVEL_ENCRYPTED)
        with pytest.raises(PermissionError, match="Code execution blocked"):
            audit_hook._antaris_hook("exec", ())


# ---------------------------------------------------------------------------
# 6. Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    """Edge cases that shouldn't crash or produce unexpected behavior."""

    def test_none_path_allowed(self, _reset_audit_state):
        """None as path should not raise (early return)."""
        audit_hook._LEVEL._set(LEVEL_SANDBOXED)
        try:
            audit_hook._antaris_hook("open", (None, "r", 0))
        except PermissionError:
            pytest.fail("None path should not raise")

    def test_empty_args_allowed(self, _reset_audit_state):
        """Empty args tuple should not raise."""
        audit_hook._LEVEL._set(LEVEL_SANDBOXED)
        try:
            audit_hook._antaris_hook("open", ())
        except PermissionError:
            pytest.fail("Empty args should not raise")

    def test_bytes_path_handled(self, _reset_audit_state):
        """bytes path (some C extensions pass bytes) should be handled."""
        audit_hook._LEVEL._set(LEVEL_STANDARD)
        workspace = _reset_audit_state
        # A bytes path inside workspace should be allowed
        ws_file = os.path.join(workspace, "test.txt").encode()
        try:
            audit_hook._antaris_hook("open", (ws_file, "r", 0))
        except PermissionError:
            pytest.fail("bytes path inside workspace should not raise")

    def test_open_level_skips_checks(self, _reset_audit_state):
        """Level 0 (OPEN) should not block any file access."""
        audit_hook._LEVEL._set(LEVEL_OPEN)
        try:
            audit_hook._antaris_hook("open", ("/root/.ssh/id_rsa", "r", 0))
        except PermissionError:
            pytest.fail("OPEN level should never block file access")

    def test_system_read_prefix_not_dir_traversal(self, _reset_audit_state):
        """System read prefixes should not allow directory-traversal tricks."""
        # /dev/null/../etc/shadow should resolve to /etc/shadow, which is blocked
        resolved = str(Path("/dev/null/../etc/shadow").resolve())
        # The resolved path would be /etc/shadow (or /private/etc/shadow on macOS)
        # /etc/shadow is NOT in the system read prefixes, so it should be blocked
        # (unless it resolves to /private/etc/shadow which IS under /private/etc/)
        # This is a known policy decision: /private/etc/ is broadly allowed on macOS
        # because macOS /etc is a symlink to /private/etc
        if sys.platform == "darwin":
            # On macOS, /etc/shadow → /private/etc/shadow → allowed by /private/etc/ prefix
            # This is acceptable because macOS doesn't have /etc/shadow (it uses DirectoryService)
            pass
        else:
            assert not audit_hook._check_file_access(resolved), f"Traversal-resolved path should be blocked: {resolved}"

    def test_workspace_file_allowed(self, _reset_audit_state):
        """Files inside the workspace are still allowed (basic sanity)."""
        workspace = _reset_audit_state
        ws_file = os.path.join(workspace, "config.json")
        assert audit_hook._check_file_access(str(Path(ws_file).resolve()))

    def test_tmp_file_still_allowed(self, _reset_audit_state):
        """/tmp paths are still allowed (pre-existing behavior)."""
        assert audit_hook._check_file_access("/tmp/test.txt")
        assert audit_hook._check_file_access("/private/tmp/test.txt")

    def test_system_read_prefixes_tuple_is_immutable(self):
        """_SYSTEM_READ_PREFIXES is a tuple (immutable) — cannot be modified at runtime."""
        assert isinstance(audit_hook._SYSTEM_READ_PREFIXES, tuple)


# ---------------------------------------------------------------------------
# 7. install() coverage for parsica_memory
# ---------------------------------------------------------------------------

class TestInstallParsicaAllowance:
    """Verify install() adds parsica_memory to allowed paths."""

    def test_install_adds_parsica_memory(self, tmp_path):
        """install() should add parsica_memory's directory when importable."""
        workspace = str(tmp_path / "ws")
        os.makedirs(workspace, exist_ok=True)

        # Save original state
        orig_installed = audit_hook._INSTALLED
        orig_allowed = audit_hook._ALLOWED_PATHS.copy()
        orig_level = audit_hook._LEVEL.value
        orig_workspace = audit_hook._WORKSPACE

        try:
            # Force _INSTALLED=True to skip sys.addaudithook
            audit_hook._INSTALLED = True
            audit_hook.install(LEVEL_STANDARD, workspace)

            try:
                import parsica_memory

                pm_dir = str(Path(parsica_memory.__file__).resolve().parent)
                assert pm_dir in audit_hook._ALLOWED_PATHS, f"parsica_memory dir should be in allowed paths: {pm_dir}"
            except ImportError:
                pytest.skip("parsica_memory not installed")
        finally:
            audit_hook._INSTALLED = orig_installed
            audit_hook._ALLOWED_PATHS = orig_allowed
            audit_hook._LEVEL._set(orig_level)
            audit_hook._WORKSPACE = orig_workspace


# ---------------------------------------------------------------------------
# 8. Wave 1 P0 regression additions
# ---------------------------------------------------------------------------


def test_python_root_does_not_allow_sibling_system_binaries(_reset_audit_state):
    audit_hook._ALLOWED_PATHS.add("/usr/lib/python3.13")
    assert not audit_hook._check_file_access("/usr/bin/malicious_script")


def test_bytes_path_inside_workspace_allowed(_reset_audit_state):
    audit_hook._LEVEL._set(LEVEL_STANDARD)
    ws_file = os.path.join(_reset_audit_state, "test.txt").encode()
    audit_hook._antaris_hook("open", (ws_file, "r", 0))


@pytest.mark.parametrize("path", [b"/etc/mime.types", b"/dev/null"])
def test_bytes_system_paths_handled(_reset_audit_state, path):
    resolved = audit_hook._coerce_path(path)
    assert resolved is not None


def test_symlink_to_allowlisted_tmp_allowed_at_standard(tmp_path):
    """At STANDARD level, symlink to /tmp is allowed (broad /tmp allowlist)."""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    outside = tmp_path / "outside"
    outside.mkdir()
    secret = outside / "secret.txt"
    secret.write_text("nope")
    link = workspace / "link.txt"
    link.symlink_to(secret)
    audit_hook._WORKSPACE = str(workspace.resolve())
    audit_hook._LEVEL._set(LEVEL_STANDARD)

    # At STANDARD, /tmp is broadly allowed and symlinks are followed.
    audit_hook._antaris_hook("open", (str(link), "r", 0))


def test_symlink_blocked_at_secured_level(tmp_path):
    """At SECURED level, ANY symlink in the path is blocked (TOCTOU mitigation)."""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    target = workspace / "real.txt"
    target.write_text("safe content")
    link = workspace / "link.txt"
    link.symlink_to(target)
    audit_hook._WORKSPACE = str(workspace.resolve())
    audit_hook._LEVEL._set(LEVEL_SECURED)

    # Even though the target is inside workspace, the symlink itself is blocked
    # at SECURED+ to prevent TOCTOU attacks.
    with pytest.raises(PermissionError, match="Symlink in path blocked"):
        audit_hook._antaris_hook("open", (str(link), "r", 0))


def test_non_symlink_allowed_at_secured_level(tmp_path):
    """At SECURED level, direct (non-symlink) workspace paths still work."""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    real_file = workspace / "config.json"
    real_file.write_text("{}")
    audit_hook._WORKSPACE = str(workspace.resolve())
    audit_hook._LEVEL._set(LEVEL_SECURED)

    # Direct path, no symlink — should be allowed.
    audit_hook._antaris_hook("open", (str(real_file), "r", 0))


def test_tmp_blocked_at_secured_level(_reset_audit_state):
    """/tmp is NOT allowed at SECURED level (graduated temp restriction)."""
    audit_hook._LEVEL._set(LEVEL_SECURED)
    assert not audit_hook._check_file_access("/tmp/some_file.txt")


def test_tmp_blocked_at_encrypted_level(_reset_audit_state):
    """/tmp is NOT allowed at ENCRYPTED level."""
    audit_hook._LEVEL._set(LEVEL_ENCRYPTED)
    assert not audit_hook._check_file_access("/tmp/some_file.txt")


def test_tmp_allowed_at_standard_level(_reset_audit_state):
    """/tmp IS allowed at STANDARD level."""
    audit_hook._LEVEL._set(LEVEL_STANDARD)
    assert audit_hook._check_file_access("/tmp/some_file.txt")


def test_tmp_allowed_at_sandboxed_level(_reset_audit_state):
    """/tmp IS allowed at SANDBOXED level."""
    audit_hook._LEVEL._set(LEVEL_SANDBOXED)
    assert audit_hook._check_file_access("/tmp/some_file.txt")
