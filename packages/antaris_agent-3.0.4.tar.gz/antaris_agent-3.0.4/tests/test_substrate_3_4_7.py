import asyncio
import tempfile
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from antaris_agent.core.subagents import SubagentRegistry
from parsica_memory import MemorySystem


@pytest.fixture
def mem():
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, use_sharding=False, use_indexing=False, agent_name="test-agent")
        store.load()
        yield store


def test_register_session_creates_record(mem):
    record = mem.register_session("session-a", agent_id="agent-1", metadata={"task": "demo"})

    assert record["session_id"] == "session-a"
    assert record["agent_id"] == "agent-1"
    assert record["status"] == "running"
    assert record["metadata"]["task"] == "demo"
    assert record["created_at"]


def test_child_session_linked_to_parent(mem):
    mem.register_session("parent", agent_id="agent-parent")
    mem.register_session("child", parent_session_id="parent", agent_id="agent-child")

    parent = mem.get_session("parent")
    assert parent is not None
    assert len(parent["children"]) == 1
    assert parent["children"][0]["session_id"] == "child"
    assert parent["children"][0]["parent_session_id"] == "parent"


def test_list_child_sessions_returns_children(mem):
    mem.register_session("parent")
    mem.register_session("child-1", parent_session_id="parent")
    mem.register_session("child-2", parent_session_id="parent")
    mem.register_session("other", parent_session_id="someone-else")

    children = mem.list_child_sessions("parent")
    assert {child["session_id"] for child in children} == {"child-1", "child-2"}


def _make_bot_with_session_memory():
    bot = MagicMock()
    bot._active_discord_channel = None
    bot._active_session_id = "parent-session"
    bot._active_agent_id = "agent-main"
    bot.config = SimpleNamespace(provider_name="openai", model="gpt-5.4")
    bot.tool_registry = None

    response = SimpleNamespace(content="done", input_tokens=10, output_tokens=5)
    bot.dispatcher.complete = AsyncMock(return_value=response)

    mem = MagicMock()
    mem.recall = AsyncMock(return_value=[])
    mem.register_session = AsyncMock(return_value={"session_id": "subagent-child", "status": "running"})
    mem.add_task = AsyncMock(return_value="subagent:child")
    mem.complete_task = AsyncMock(return_value=None)
    mem.update_session_status = AsyncMock(return_value={"session_id": "subagent-child", "status": "done"})
    mem.ingest = AsyncMock(return_value=None)
    bot.memory = mem
    return bot, mem


@pytest.mark.asyncio
async def test_subagent_spawn_registers_child_session():
    bot, mem = _make_bot_with_session_memory()
    registry = SubagentRegistry(bot=bot, max_agents=2)

    ok, _ = await registry.spawn(
        task="Investigate child registration",
        name="child",
        parent_user_id="user-1",
    )
    assert ok is True

    agent = registry.get("child")
    assert agent is not None and agent.task_handle is not None
    await asyncio.wait_for(agent.task_handle, timeout=5.0)

    mem.register_session.assert_awaited_once_with(
        "user-1",
        "subagent-child",
        parent_session_id="parent-session",
        agent_id="agent-main",
        metadata={"task": "Investigate child registration", "subagent_name": "child"},
    )


@pytest.mark.asyncio
async def test_session_status_updates_on_complete():
    bot, mem = _make_bot_with_session_memory()
    registry = SubagentRegistry(bot=bot, max_agents=2)

    ok, _ = await registry.spawn(
        task="Finish work",
        name="child",
        parent_user_id="user-1",
    )
    assert ok is True

    agent = registry.get("child")
    assert agent is not None and agent.task_handle is not None
    await asyncio.wait_for(agent.task_handle, timeout=5.0)

    mem.update_session_status.assert_awaited_once_with("user-1", "subagent-child", "done")
    # Parsi fix: complete_task now uses parent_session_id (not child session_id)
    # so task lifecycle matches: add_task(parent) → complete_task(parent)
    mem.complete_task.assert_awaited_once_with("user-1", "parent-session", "subagent:child")
