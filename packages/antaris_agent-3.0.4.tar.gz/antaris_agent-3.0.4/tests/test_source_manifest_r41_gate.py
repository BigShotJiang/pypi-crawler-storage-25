"""Tests for R4.1 Cluster A \u2014 integrity gate (P0-5, dissolves P1-4).

Every gated public method on SourceManifest must refuse on
tamper/corruption states via ``_require_usable``. Previously the
primitive raised cleanly but callers could swallow; now the primitive
is the single point of enforcement and the gate is executable code,
not a docstring promise.
"""
from __future__ import annotations

import pytest

from parsica_memory.source_manifest import (
    LEGACY_BODY_SENTINEL,
    LEGACY_IDENTITY_SENTINEL,
    ManifestIntegrityError,
    SourceManifest,
    _INTEGRITY_STATES_ALLOW_READ,
    _INTEGRITY_STATES_ALLOW_WRITE,
    _INTEGRITY_STATES_HARD_REFUSE,
)


I = "moro@antarisanalytics"
B = "moro:default"


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    return str(tmp_path)


@pytest.fixture
def manifest(workspace):
    m = SourceManifest(workspace)
    # Touch the manifest so _ensure_loaded runs and state is resolved.
    m.stats()
    return m


# =============================================================================
# _require_usable state matrix
# =============================================================================


class TestRequireUsableStateMatrix:
    """Exhaustively exercise the allow / hard-refuse decision table."""

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_ALLOW_WRITE))
    def test_allow_write_states_permit_add_and_tombstone(self, manifest, state):
        manifest._integrity_state = state
        # Write-op gate should not raise.
        manifest._require_usable(op="add")
        manifest._require_usable(op="tombstone")
        manifest._require_usable(op="flush")

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_ALLOW_READ))
    def test_allow_read_states_permit_lookup(self, manifest, state):
        manifest._integrity_state = state
        manifest._require_usable(op="lookup")
        manifest._require_usable(op="lookup_scoped")
        manifest._require_usable(op="all_sources")
        manifest._require_usable(op="stats")
        manifest._require_usable(op="reconcile_with_store")

    def test_degraded_refuses_writes_but_permits_reads(self, manifest):
        manifest._integrity_state = "degraded"
        # Reads allowed (persist backlog is safe to read).
        manifest._require_usable(op="lookup")
        manifest._require_usable(op="stats")
        # Writes refused.
        with pytest.raises(ManifestIntegrityError) as ei:
            manifest._require_usable(op="add")
        assert "degraded" in str(ei.value)
        assert "writes refused" in str(ei.value)
        with pytest.raises(ManifestIntegrityError):
            manifest._require_usable(op="tombstone")

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_hard_refuse_states_block_every_op(self, manifest, state):
        manifest._integrity_state = state
        for op in ("add", "tombstone", "flush", "lookup", "lookup_scoped",
                   "all_sources", "stats", "reconcile_with_store"):
            with pytest.raises(ManifestIntegrityError) as ei:
                manifest._require_usable(op=op)
            msg = str(ei.value)
            assert state in msg
            assert op in msg
            # secret_corrupt gets an operator-specific message (Cluster B);
            # every other hard-refuse state uses the generic template that
            # includes the ``hard-refuse`` marker.
            if state != "secret_corrupt":
                assert "hard-refuse" in msg
            else:
                assert "tamper signal" in msg

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_hard_refuse_ignores_strict_false(self, manifest, state):
        """``strict=False`` is NOT a tamper override.

        A probe against a chain_broken workspace must still fail closed
        \u2014 otherwise an attacker who triggered chain corruption could
        coerce the caller into "best-effort" mode and read records under
        a poisoned chain.
        """
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest._require_usable(op="lookup", strict=False)
        with pytest.raises(ManifestIntegrityError):
            manifest._require_usable(op="stats", strict=False)

    def test_strict_false_tolerates_degraded_for_reads(self, manifest):
        """Probe reads bypass the strict-read check on ``degraded``.

        Writes on ``degraded`` still refuse even under ``strict=False``
        because ``degraded`` is not in the write allow-set.
        """
        manifest._integrity_state = "degraded"
        # Non-strict reads succeed.
        manifest._require_usable(op="lookup", strict=False)
        # Writes still refuse (strict doesn't apply to writes).
        with pytest.raises(ManifestIntegrityError):
            manifest._require_usable(op="add", strict=False)

    def test_unknown_op_classifies_as_write(self, manifest):
        """Defense-in-depth: a future engineer adding a method without
        registering it in ``_WRITE_OPS``/``_READ_OPS`` gets the
        strictest (write) allow-set rather than permissive fall-through.
        """
        manifest._integrity_state = "degraded"  # read-only state
        with pytest.raises(ManifestIntegrityError) as ei:
            manifest._require_usable(op="some_new_method")
        assert "writes refused" in str(ei.value)


class TestPublicMethodGating:
    """Integration: each gated public method refuses on hard-refuse states."""

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_add_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.add(
                "discord", "ch1", "h1",
                identity_id=I, body_id=B,
            )

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_tombstone_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.tombstone("h1", "forgotten", identity_id=I)

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_lookup_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.lookup("discord", "ch1", identity_id=I, body_id=B)

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_all_sources_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.all_sources()

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_stats_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.stats()

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_reconcile_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.reconcile_with_store(set())

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_flush_refuses(self, manifest, state):
        manifest._integrity_state = state
        with pytest.raises(ManifestIntegrityError):
            manifest.flush()

    @pytest.mark.parametrize("state", sorted(_INTEGRITY_STATES_HARD_REFUSE))
    def test_lookup_scoped_refuses(self, manifest, state):
        manifest._integrity_state = state

        class _P:
            identity_id = I
            body_id = B
            allowed_scopes = None

        with pytest.raises(ManifestIntegrityError):
            manifest.lookup_scoped("discord", "ch1", _P())

    def test_health_is_ungated(self, manifest):
        """``health()`` is the diagnostic surface. It must always work,
        even in hard-refuse states, so operators can read the state
        that caused the refusal.
        """
        for state in _INTEGRITY_STATES_HARD_REFUSE:
            manifest._integrity_state = state
            h = manifest.health()
            assert h["integrity"] == state

    def test_view_is_ungated_but_methods_forward(self, manifest):
        """``view()`` returns a wrapper without touching the gate; the
        wrapper's methods delegate to the gated primitive, so the gate
        still fires on reads through the view.
        """
        view = manifest.view()  # No gate call.
        manifest._integrity_state = "chain_broken"
        with pytest.raises(ManifestIntegrityError):
            view.lookup("discord", "ch1", identity_id=I, body_id=B)

    def test_degraded_write_refuses_but_read_succeeds(self, manifest):
        """Combined state/op matrix check at the public-method level."""
        # Seed some data while healthy.
        manifest.add("discord", "ch1", "h1", identity_id=I, body_id=B)
        manifest._integrity_state = "degraded"
        # Read succeeds.
        assert manifest.lookup("discord", "ch1", identity_id=I, body_id=B) == ["h1"]
        # Write refuses.
        with pytest.raises(ManifestIntegrityError):
            manifest.add("discord", "ch2", "h2", identity_id=I, body_id=B)


# =============================================================================
# P1-4 dissolved: MemorySystemV4.lookup_source shim flows through the gate
# =============================================================================


def test_p14_lookup_source_path_now_gated(tmp_path, monkeypatch):
    """P1-4 was: ``MemorySystemV4.lookup_source`` was the ungated cousin
    of ``get_by_source``. Under R4.1 Cluster A both paths flow through
    the same gated primitive ``SourceManifest.lookup``, so a caller who
    reaches for ``lookup_source`` on a chain_broken workspace also hits
    the gate \u2014 P1-4 dissolves structurally.
    """
    from parsica_memory.core_v4 import MemorySystemV4

    monkeypatch.setenv("PARSICA_MANIFEST_DEV_NO_HMAC", "1")
    ms = MemorySystemV4(str(tmp_path))
    ms.ingest(
        "This is long enough content for the normal ingest path to accept.",
        source="discord", source_channel="ch_probe",
    )
    # Healthy: both paths return results.
    rids_via_shim = ms.lookup_source(
        "discord", "ch_probe",
        identity_id=LEGACY_IDENTITY_SENTINEL,
        body_id=LEGACY_BODY_SENTINEL,
    )
    assert len(rids_via_shim) == 1

    # Corrupt the state. ``lookup_source`` now refuses just like
    # ``get_by_source`` does.
    ms.manifest(ms.internal_manifest_capability())._integrity_state = "chain_broken"
    with pytest.raises(ManifestIntegrityError):
        ms.lookup_source(
            "discord", "ch_probe",
            identity_id=LEGACY_IDENTITY_SENTINEL,
            body_id=LEGACY_BODY_SENTINEL,
        )


# =============================================================================
# Lint: every gated public method actually calls _require_usable
# =============================================================================


def test_every_gated_public_method_calls_require_usable():
    """Permanent guard against regression.

    Any future engineer adding a public read/write method on
    SourceManifest without calling ``_require_usable`` trips this.
    """
    import ast
    import inspect

    import parsica_memory.source_manifest as sm

    expected = (
        sm.SourceManifest._WRITE_OPS | sm.SourceManifest._READ_OPS
    )
    source = inspect.getsource(sm.SourceManifest)
    tree = ast.parse(source)
    cls = next(
        n for n in ast.walk(tree)
        if isinstance(n, ast.ClassDef) and n.name == "SourceManifest"
    )
    missing = []
    for node in cls.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        if node.name not in expected:
            continue
        body_src = ast.unparse(node)
        if "_require_usable" not in body_src:
            missing.append(node.name)
    assert not missing, (
        f"Methods missing _require_usable call: {missing}. "
        f"R4.1 Cluster A (P0-5) mandates the gate on every public method."
    )
