"""
test_qte_deep_observability.py

v3.0.4 (F-DEEP-SWALLOW): DEEP mode's pass-2 expanded retrieval used to
swallow ALL exceptions silently, producing empty results with no log,
no trace annotation, no counter. Pass-2 failures were invisible.

Post-v3.0.4:
  - Pass-2 failures are logged at WARNING
  - Trace records pass2_ran: bool and pass2_error: Optional[str]
  - Pass-1 results still returned (graceful degradation preserved)
  - Whole query does NOT fail when pass-2 fails

Note: `run_qte` returns only `limited` (the ranked item list). The trace is
persisted to a JSONL sink when `persist_trace` is enabled. We capture it here
by persisting through a writable request and inspecting the mutated trace.
Since the trace object is mutated before return, we capture it via a
side-effect hook on `RetrievalTraceSink.write`.
"""

from __future__ import annotations

import asyncio
import logging
from unittest.mock import patch

import pytest


class _FakeMem:
    """Minimal stand-in for MemorySystemV4 — only needs .workspace for trace sink path."""
    def __init__(self, tmp_path):
        self.workspace = str(tmp_path)


def _make_request(query: str, mode: str = "deep", *, write: bool = False):
    """Request fixture. When write=True, side_effect_mode is WRITE_ENABLED so
    the trace sink actually runs (letting us capture the mutated trace)."""
    from parsica_memory.contracts import RetrievalRequest, SideEffectMode
    return RetrievalRequest(
        query=query,
        query_mode=mode,
        side_effect_mode=(
            SideEffectMode.REINFORCE if write else SideEffectMode.PURE_READ
        ),
        persist_trace=write,
    )


def _capture_trace(run_callable):
    """Run a run_qte invocation and return (items, captured_trace).

    Captures the trace object by hooking RetrievalTraceSink.write.
    """
    import parsica_memory.query_time_enrichment as qte_mod
    captured = {"trace": None}

    class _Hook:
        def __init__(self, *a, **kw): pass
        def write(self, trace): captured["trace"] = trace

    with patch.object(qte_mod, "RetrievalTraceSink", _Hook):
        items = run_callable()
    return items, captured["trace"]


def test_deep_mode_pass2_failure_is_logged(tmp_path, caplog):
    """Pass-2 failure must emit a WARNING-level log, not silently disappear."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            from parsica_memory.contracts import RetrievalTrace
            return [], RetrievalTrace(request_id=req.request_id)
        raise RuntimeError("deliberate pass-2 failure for test")

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["alpha", "beta"]):
            # v3.0.4 (P1-3): pass-2 routine failures log at INFO, not WARNING.
            # Capture INFO level so the test observes the demoted log.
            with caplog.at_level(logging.INFO, logger="parsica_memory.query_time_enrichment"):
                items = run_qte(mem, request)

    # Pass-1 results still returned (graceful degradation)
    assert isinstance(items, list)

    # INFO log emitted — the observability we added, demoted from WARN
    # for prod-scale traffic (P1-3).
    info_records = [r for r in caplog.records if r.levelname == "INFO"]
    assert any("qte_deep_pass2_failed" in r.message for r in info_records), (
        "Pass-2 failure must emit an INFO log containing 'qte_deep_pass2_failed'; "
        f"got levels={[r.levelname for r in caplog.records]}"
    )


def test_deep_mode_pass2_failure_annotates_trace(tmp_path):
    """Pass-2 failure must set trace.qte_features['pass2_error'] and pass2_ran=True."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            from parsica_memory.contracts import RetrievalTrace
            return [], RetrievalTrace(request_id=req.request_id)
        raise RuntimeError("deliberate pass-2 failure for trace annotation test")

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["alpha", "beta"]):
            items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None, "Trace sink should have been called with a trace object"
    assert trace.qte_features.get("pass2_ran") is True, (
        "Pass-2 attempted → pass2_ran must be True"
    )
    err = trace.qte_features.get("pass2_error")
    assert err is not None, "pass2_error must be set when pass-2 fails"
    # v3.0.4 (P1-6): pass2_error is structured {exc_type, message} for machine parsing.
    assert isinstance(err, dict), f"pass2_error must be dict, got {type(err).__name__}: {err!r}"
    assert err.get("exc_type") == "RuntimeError", f"pass2_error.exc_type mismatch: {err!r}"
    assert "deliberate" in err.get("message", ""), f"pass2_error.message missing expected text: {err!r}"


def test_deep_mode_pass2_success_leaves_trace_clean(tmp_path):
    """Regression: pass-2 success must leave pass2_error=None."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        return [], RetrievalTrace(request_id=req.request_id)

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["alpha"]):
            items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None
    assert trace.qte_features.get("pass2_ran") is True
    assert trace.qte_features.get("pass2_error") is None, (
        "Successful pass-2 must leave pass2_error=None"
    )


def test_deep_mode_no_gap_terms_records_pass2_did_not_run(tmp_path):
    """When gap_terms is empty, pass-2 never runs: pass2_ran=False, pass2_error=None."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        return [], RetrievalTrace(request_id=req.request_id)

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=[]):
            items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None
    assert trace.qte_features.get("pass2_ran") is False, (
        "No gap terms → pass-2 should not run"
    )
    assert trace.qte_features.get("pass2_error") is None


def test_deep_mode_pass2_failure_does_not_raise(tmp_path):
    """Whole query must succeed even if pass-2 raises — graceful degradation."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            from parsica_memory.contracts import RetrievalTrace
            return [], RetrievalTrace(request_id=req.request_id)
        raise ValueError("pass-2 explosion")

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x"]):
            # Must not raise — graceful degradation preserved
            items = run_qte(mem, request)

    assert items == []  # pass-1 returned no items; pass-2 failed; merged list is empty


# ---------------------------------------------------------------------------
# v3.0.4 Eye verdict fixes
# ---------------------------------------------------------------------------

def test_deep_mode_pass2_systemexit_propagates(tmp_path):
    """P0-3: SystemExit during pass-2 must propagate, not be swallowed.

    Pre-Eye, the `except Exception` handler did not catch BaseException
    subclasses but could have been "accidentally fixed" to catch
    BaseException blindly. This test locks in the contract: process-
    termination signals propagate; only log+re-raise.
    """
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            from parsica_memory.contracts import RetrievalTrace
            return [], RetrievalTrace(request_id=req.request_id)
        raise SystemExit(42)

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x"]):
            with pytest.raises(SystemExit) as exc_info:
                run_qte(mem, request)
    assert exc_info.value.code == 42


def test_deep_mode_pass2_keyboard_interrupt_propagates(tmp_path):
    """P0-3: KeyboardInterrupt during pass-2 must propagate."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            from parsica_memory.contracts import RetrievalTrace
            return [], RetrievalTrace(request_id=req.request_id)
        raise KeyboardInterrupt()

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x"]):
            with pytest.raises(KeyboardInterrupt):
                run_qte(mem, request)


def test_deep_mode_pass2_budget_exceeded_skips_pass2(tmp_path):
    """P1-5: When pass-1 already consumed max_qte_time_ms, pass-2 is skipped
    with a structured BudgetExceeded annotation on the trace.
    """
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )
    # Tiny budget, pass-1 "already exceeded" it via simulated wall-clock delay
    request.max_qte_time_ms = 1

    import time as _time

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        # Force wall-clock to exceed the 1ms budget on pass-1
        _time.sleep(0.01)  # 10ms
        return [], RetrievalTrace(request_id=req.request_id)

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x", "y"]):
            items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None
    assert trace.qte_features.get("pass2_ran") is True, "Pass-2 attempted (budget check runs inside try)"
    err = trace.qte_features.get("pass2_error")
    assert isinstance(err, dict)
    assert err.get("exc_type") == "BudgetExceeded", (
        f"Budget-exceeded skip should produce exc_type=BudgetExceeded, got {err!r}"
    )
    assert "budget" in err.get("message", "").lower()


def test_deep_mode_pass2_new_items_counter(tmp_path):
    """P1-7: pass2_new_items must count records unique to pass-2."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    class _FakeItem:
        def __init__(self, rid):
            self.record_id = rid
            self.score = 1.0

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        call_count["n"] += 1
        if call_count["n"] == 1:
            return [_FakeItem("a"), _FakeItem("b")], RetrievalTrace(request_id=req.request_id)
        # pass-2 surfaces one overlap ('b') and two new records ('c', 'd')
        return [_FakeItem("b"), _FakeItem("c"), _FakeItem("d")], RetrievalTrace(request_id=req.request_id)

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x"]):
            with patch.object(qte_mod, "_score_item", return_value=1.0):
                items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None
    assert trace.qte_features.get("pass2_new_items") == 2, (
        f"Expected 2 new items from pass-2, got {trace.qte_features.get('pass2_new_items')!r}"
    )


def test_cancellederror_propagates(tmp_path):
    """CancelledError must propagate from DEEP pass-2."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
    )

    call_count = {"n": 0}

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        call_count["n"] += 1
        if call_count["n"] == 1:
            return [], RetrievalTrace(request_id=req.request_id)
        raise asyncio.CancelledError()

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["x"]):
            with pytest.raises(asyncio.CancelledError):
                run_qte(mem, request)


def test_deep_trace_records_pass_timings_and_budget_hint(tmp_path):
    """Trace should expose pass timing split and pass-2 budget hint."""
    from parsica_memory.query_time_enrichment import run_qte
    import parsica_memory.query_time_enrichment as qte_mod
    import parsica_memory.retrieval as retrieval_mod

    mem = _FakeMem(tmp_path)
    request = _make_request(
        "this is a long query with many tokens to ensure deep mode routing path is taken",
        mode="deep",
        write=True,
    )
    request.max_qte_time_ms = 250

    def _mock_execute(memory_system, req, persist_trace=False, budget_ms=None):
        from parsica_memory.contracts import RetrievalTrace
        trace = RetrievalTrace(request_id=req.request_id)
        if budget_ms is not None:
            trace.qte_features["budget_ms_hint"] = budget_ms
        return [], trace

    with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_execute):
        with patch.object(qte_mod, "_extract_gap_terms", return_value=["alpha"]):
            items, trace = _capture_trace(lambda: run_qte(mem, request))

    assert trace is not None
    assert trace.qte_features.get("pass1_time_ms", -1) >= 0
    assert trace.qte_features.get("pass2_time_ms", -1) >= 0
    assert trace.qte_features.get("pass2_budget_ms") is not None
    assert trace.qte_features.get("qte_path") == "qte"
