import os
import tempfile
from pathlib import Path

import pytest

from antaris_agent.core.memory import BotMemory
from parsica_memory import MemorySystem
from parsica_memory.context_packet import ContextPacketBuilder
from parsica_memory.contracts import IngestEnvelope, RetrievalPurpose, RetrievalRequest
from parsica_memory.retrieval import TRACE_DIR, load_traces


@pytest.fixture
def mem():
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, use_sharding=False, use_indexing=False)
        store.load()
        yield store


class _RecentItem:
    def __init__(self, content, timestamp, session_id=""):
        self.content = content
        self.timestamp = timestamp
        self.session_id = session_id


class _RecentStore:
    def __init__(self, items):
        self.items = items

    def recall_recent(self, hours=6.0, limit=5):
        return self.items[:limit]


# Gate 1: Every ingest path emits an IngestEnvelope

def test_gate1_ingest_emits_envelope(mem):
    count = mem.ingest("This inline memory is long enough to survive ingest gating.")
    assert count == 1
    entry = mem.memories[-1]
    assert entry.envelope_id
    assert entry.record_id


def test_gate1_ingest_turn_emits_envelope(mem):
    entry = mem.ingest_turn("Whole-turn ingest should always stamp an envelope.", session_id="sess-turn")
    assert entry is not None
    assert entry.envelope_id
    assert entry.record_kind == "turn"


def test_gate1_ingest_file_emits_envelope(mem):
    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".md") as handle:
        handle.write("Document ingest should also flow through an envelope contract.\n")
        path = handle.name
    try:
        count = mem.ingest_file(path)
        assert count == 1
        entry = mem.memories[-1]
        assert entry.envelope_id
        assert entry.record_kind == "document"
        assert entry.source_url == path
    finally:
        os.unlink(path)


def test_gate1_typed_ingest_emits_envelope(mem):
    count = mem.ingest_fact("The cache key prefix must stay stable across deployments.")
    assert count == 1
    entry = mem.memories[-1]
    assert entry.envelope_id
    assert entry.record_kind == "fact"
    assert entry.cross_session_eligible is True


# Gate 2: Every stored record has a stable record_id

def test_gate2_record_id_on_ingest(mem):
    count = mem.ingest("This stored ingest path should always get a stable record id.")
    assert count == 1
    entry = mem.memories[-1]
    assert entry.record_id


def test_gate2_record_id_on_turn(mem):
    entry = mem.ingest_turn("Conversation turns need stable record ids too.", session_id="sess-rid")
    assert entry is not None
    assert entry.record_id


def test_gate2_record_id_on_child(mem):
    parent = mem.ingest_turn(
        "Actually, I prefer pytest and the steps are: run tests, then merge.",
        session_id="sess-child",
    )
    assert parent is not None
    # v2.8.2: children form via background hydration, not inline
    if mem._task_journal is not None:
        mem._task_journal.try_acquire_leader("gate2-worker")
    mem.run_background_tasks(max_tasks=10, worker_id="gate2-worker")
    children = [m for m in mem.memories if m.record_kind in {"fact", "preference", "procedure"}]
    assert children
    assert all(child.record_id for child in children)


# Gate 3: Prompt building is pure read

def test_gate3_pure_read_does_not_mutate(mem):
    mem.ingest_fact("Pure read retrieval target for context packet verification.", session_id="sess-pure")
    target = next(entry for entry in mem.memories if "Pure read retrieval target" in entry.content)
    before_count = target.access_count
    before_accessed = target.last_accessed

    builder = ContextPacketBuilder(mem)
    packet = builder.build("Pure read retrieval target", max_memories=3)

    assert packet.metadata["results_found"] >= 1
    assert target.access_count == before_count
    assert target.last_accessed == before_accessed


# Gate 4: No semantic pseudo-type

def test_gate4_knowledge_only_replaces_semantic(mem):
    turn = mem.ingest_turn("python turn only", session_id="session-other", user_id="user-1", agent_id="agent-1")
    assert turn is not None

    fact_envelope = IngestEnvelope.for_fact(
        "python durable fact",
        session_id="session-other",
        agent_id="agent-1",
    )
    mem.ingest(
        "python durable fact",
        source="pipeline",
        session_id="session-other",
        agent_id="agent-1",
        _envelope=fact_envelope,
    )

    results = mem.search(
        "python",
        limit=10,
        session_id="session-current",
        cross_session_recall="knowledge_only",
        read_only=True,
    )
    contents = [r.content for r in results]
    assert "python durable fact" in contents
    assert "python turn only" not in contents


def test_gate4_turns_are_not_cross_session(mem):
    mem.ingest_turn("cross-session turn should stay local", session_id="session-a")
    results = mem.search(
        "cross-session turn",
        limit=10,
        session_id="session-b",
        cross_session_recall="knowledge_only",
        read_only=True,
    )
    assert all(r.content != "cross-session turn should stay local" for r in results)


def test_gate4_facts_are_cross_session(mem):
    mem.ingest_fact("The release branch is feature/3.4.5-3.4.8-substrate-contracts", session_id="session-a")
    results = mem.search(
        "release branch",
        limit=10,
        session_id="session-b",
        cross_session_recall="knowledge_only",
        read_only=True,
    )
    assert any("feature/3.4.5-3.4.8-substrate-contracts" in r.content for r in results)


# Gate 5: search_recent exclude works

def test_gate5_search_recent_excludes_session():
    bot_memory = BotMemory(store_path=tempfile.mkdtemp())
    store = _RecentStore(
        [
            _RecentItem("excluded", "2026-04-10T00:00:00Z", session_id="sess-a"),
            _RecentItem("kept", "2026-04-10T00:01:00Z", session_id="sess-b"),
        ]
    )
    bot_memory._get_store = lambda user_id: store

    results = bot_memory.search_recent(
        user_id="alice",
        hours=6.0,
        limit=5,
        exclude_session="sess-a",
    )
    assert [r.content for r in results] == ["kept"]


# Gate 6: Channel provenance canonical

def test_gate6_channel_canonical(mem):
    mem.ingest(
        "Channel provenance should persist on the canonical field.",
        source="test",
        channel_id="discord:gate-6",
        source_channel="discord:legacy",
    )
    entry = mem.memories[-1]
    assert entry.source_channel == "discord:gate-6"


# Gate 7: Session tree

def test_gate7_parent_child_linkage(mem):
    mem.register_session("parent", agent_id="agent-parent")
    mem.register_session("child", parent_session_id="parent", agent_id="agent-child")

    parent = mem.get_session("parent")
    assert parent is not None
    assert len(parent["children"]) == 1
    assert parent["children"][0]["session_id"] == "child"
    assert parent["children"][0]["parent_session_id"] == "parent"


def test_gate7_child_session_list(mem):
    mem.register_session("parent")
    mem.register_session("child-1", parent_session_id="parent")
    mem.register_session("child-2", parent_session_id="parent")
    mem.register_session("other", parent_session_id="someone-else")

    children = mem.list_child_sessions("parent")
    assert {child["session_id"] for child in children} == {"child-1", "child-2"}


# Gate 8: Retrieval traces

def test_gate8_trace_persisted(mem):
    mem.ingest_fact("Retrieval trace persisted target", session_id="trace-session")

    items = mem.retrieve(
        RetrievalRequest(
            query="persisted target",
            purpose=RetrievalPurpose.USER_ANSWER,
            session_id="trace-session",
            limit=5,
        ),
        persist_trace=True,
    )
    assert any("Retrieval trace persisted target" in item.content for item in items)

    trace_dir = Path(mem.workspace) / TRACE_DIR
    assert trace_dir.exists()
    assert list(trace_dir.glob("*.jsonl"))


def test_gate8_trace_loadable(mem):
    mem.ingest_fact("Retrieval trace loadable target", session_id="trace-session")

    mem.retrieve(
        RetrievalRequest(
            query="loadable target",
            purpose=RetrievalPurpose.USER_ANSWER,
            session_id="trace-session",
            limit=5,
        ),
        persist_trace=True,
    )

    traces = load_traces(mem.workspace, limit=10)
    assert traces
    assert any(trace.query == "loadable target" for trace in traces)
    assert all(trace.result_ids is not None for trace in traces)


# Gate 9: This test suite exists and passes

def test_gate9_all_gates_pass():
    required = {
        "test_gate1_ingest_emits_envelope",
        "test_gate1_ingest_turn_emits_envelope",
        "test_gate1_ingest_file_emits_envelope",
        "test_gate1_typed_ingest_emits_envelope",
        "test_gate2_record_id_on_ingest",
        "test_gate2_record_id_on_turn",
        "test_gate2_record_id_on_child",
        "test_gate3_pure_read_does_not_mutate",
        "test_gate4_knowledge_only_replaces_semantic",
        "test_gate4_turns_are_not_cross_session",
        "test_gate4_facts_are_cross_session",
        "test_gate5_search_recent_excludes_session",
        "test_gate6_channel_canonical",
        "test_gate7_parent_child_linkage",
        "test_gate7_child_session_list",
        "test_gate8_trace_persisted",
        "test_gate8_trace_loadable",
        "test_gate9_all_gates_pass",
    }
    present = {name for name in globals() if name.startswith("test_gate")}
    assert required.issubset(present)
    assert len(present & required) == len(required)
