import json
import tempfile
from pathlib import Path
from unittest.mock import patch

from antaris_agent.core.bot import Bot
from antaris_agent.core.config import Config
from antaris_agent.tools.native.google_workspace import GogRunner, GmailSearchGogTool


def test_gog_runner_availability_check():
    runner = GogRunner(account="test@example.com")
    with patch("shutil.which", return_value="/opt/homebrew/bin/gog"):
        assert runner.is_available() is True


def test_google_workspace_tool_properties():
    tool = GmailSearchGogTool(GogRunner(account="test@example.com"))
    assert tool.name == "gmail_search"
    assert "Gmail" in tool.description
    assert tool.input_schema["required"] == ["query"]


def test_google_workspace_tools_register_from_config():
    with tempfile.TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir)
        config_path = config_dir / "config.json"
        config_data = {
            "bot": {"name": "TestBot"},
            "provider": {"name": "anthropic", "apiKey": "test-key", "model": "claude-sonnet-4-6"},
            "channels": {"discord": {"enabled": False}},
            "memory": {"store": str(config_dir / "memory")},
            "guard": {"mode": "monitor"},
            "security": {"mode": "sandboxed"},
            "tools": {
                "google_workspace": {
                    "enabled": True,
                    "account": "test@example.com"
                }
            }
        }
        config_path.write_text(json.dumps(config_data))

        with patch("antaris_agent.core.bot.setup_logging"), \
             patch.object(Config, 'memory_storage_backend', 'filesystem', create=True), \
             patch.object(Config, 'memory_session_awareness', True, create=True), \
             patch.object(Config, 'memory_tiered_storage', False, create=True), \
             patch("shutil.which", return_value="/opt/homebrew/bin/gog"):
            bot = Bot(str(config_path))
            assert bot.tool_registry is not None
            tools = bot.tool_registry.list_tools()
            assert "gmail_search" in tools
            assert "gmail_read" in tools
            assert "gmail_send" in tools
            assert "calendar_list_events" in tools
            assert "calendar_create_event" in tools
            assert "drive_search" in tools
            assert "drive_read" in tools
            assert "docs_create" in tools
            assert "sheets_read" in tools
            assert "sheets_append" in tools
