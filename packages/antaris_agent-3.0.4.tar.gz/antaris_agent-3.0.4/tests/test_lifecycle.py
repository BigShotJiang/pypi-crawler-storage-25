"""Tests for v3.0 lifecycle: entry schema + state management."""
import pytest
from parsica_memory.entry import MemoryEntry


def test_memory_entry_state_roundtrip():
    """state field persists through to_dict/from_dict."""
    e = MemoryEntry("test content", "test", 0, "general")
    e.state = "deprecated"
    e.state_reason = "outdated info"
    d = e.to_dict()
    assert d["state"] == "deprecated"
    assert d["state_reason"] == "outdated info"
    e2 = MemoryEntry.from_dict(d)
    assert e2.state == "deprecated"
    assert e2.state_reason == "outdated info"


def test_memory_entry_family_id_roundtrip():
    """family_id persists through to_dict/from_dict."""
    e = MemoryEntry("test content", "test", 0, "general")
    e.family_id = "claim_family_001"
    d = e.to_dict()
    assert d["family_id"] == "claim_family_001"
    e2 = MemoryEntry.from_dict(d)
    assert e2.family_id == "claim_family_001"


def test_memory_entry_state_defaults():
    """New entries default to state='active' with empty family_id."""
    e = MemoryEntry("test", "test", 0, "general")
    assert e.state == "active"
    assert e.state_reason == ""
    assert e.family_id == ""
    assert e.updated_at == ""


def test_memory_entry_active_state_not_serialized():
    """Default 'active' state should not appear in to_dict (space optimization)."""
    e = MemoryEntry("test", "test", 0, "general")
    d = e.to_dict()
    assert "state" not in d  # active is default, no need to persist


def test_update_record_state_validates():
    """Invalid state raises ValueError."""
    import tempfile, os
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("test content for state validation", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        with pytest.raises(ValueError, match="invalid state"):
            store.update_record_state(rid, "nonexistent_state")


def test_deprecate_sets_state():
    """deprecate() sets state to deprecated and persists."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("test content for deprecation", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        result = store.deprecate(rid, reason="test reason")
        assert result is True
        assert entry.state == "deprecated"
        assert entry.state_reason == "test reason"
        assert entry.updated_at != ""


def test_mark_do_not_use_sets_state():
    """mark_do_not_use() sets state correctly."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("test content for dnu", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        result = store.mark_do_not_use(rid, reason="bad data")
        assert result is True
        assert entry.state == "do_not_use"


def test_record_state_constants():
    """Contracts define expected state constants."""
    from parsica_memory.contracts import RECORD_STATE_WEIGHTS, EXCLUDED_RECORD_STATES, VALID_RECORD_STATES
    assert RECORD_STATE_WEIGHTS["active"] == 1.0
    assert RECORD_STATE_WEIGHTS["deprecated"] == 0.25
    assert RECORD_STATE_WEIGHTS["do_not_use"] == 0.0
    assert "do_not_use" in EXCLUDED_RECORD_STATES
    assert "purged" in EXCLUDED_RECORD_STATES
    assert VALID_RECORD_STATES == frozenset({"active", "deprecated", "do_not_use", "purged"})


# ── Phase 1: forget → deprecate semantics ─────────────────────────────────────

def test_forget_deprecates_not_deletes():
    """forget() should deprecate entries, not delete them."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("the sky is blue and beautiful today", "test")
        assert len(store.memories) == 1
        result = store.forget(topic="sky")
        # Entry should still exist but be deprecated
        assert len(store.memories) == 1
        assert store.memories[0].state == "deprecated"
        assert result["forgotten"] >= 1


def test_forget_hard_delete_removes():
    """forget(hard_delete=True) should actually remove entries."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("the sky is blue and beautiful today", "test")
        assert len(store.memories) == 1
        result = store.forget(topic="sky", hard_delete=True)
        assert len(store.memories) == 0
        assert result["forgotten"] >= 1


def test_purge_record_removes():
    """purge_record() should permanently delete."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("secret data that must be purged completely", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        result = store.purge_record(rid, reason="GDPR request")
        assert result is True
        assert len(store.memories) == 0


def test_deprecated_survives_reload():
    """Deprecated entries should survive save/reload cycle."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("important historical record about the company founding", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="outdated")
        store.save()

        # Reload
        store2 = MemorySystem(td, agent_name="test")
        assert len(store2.memories) >= 1
        reloaded = [m for m in store2.memories if (m.record_id or m.hash) == rid]
        assert len(reloaded) == 1
        assert reloaded[0].state == "deprecated"


# ── Phase 2: Retrieval Plumbing Fix tests ────────────────────────────────────

def test_deprecated_downweighted_in_search():
    """Deprecated entries should get lower scores in search results."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("the quick brown fox jumps over the lazy dog near the river", "test")
        store.ingest("the quick brown fox runs through the forest near the river", "test")

        # Deprecate one
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="outdated")

        # Use explain=True to get SearchResult objects with .score
        results = store.search("quick brown fox", limit=10, explain=True)
        if len(results) >= 2:
            # The active result should rank higher than deprecated
            active_results = [r for r in results if getattr(r.entry, 'state', 'active') == 'active']
            deprecated_results = [r for r in results if getattr(r.entry, 'state', 'active') == 'deprecated']
            if active_results and deprecated_results:
                assert active_results[0].score >= deprecated_results[0].score


def test_do_not_use_excluded_from_search():
    """do_not_use entries should not appear in search results."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("unique alpaca farming techniques for mountain regions", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="bad data")

        results = store.search("alpaca farming", limit=10)
        # The do_not_use entry should not appear
        for r in results:
            e = getattr(r, 'entry', r)
            assert getattr(e, 'state', 'active') != 'do_not_use'


def test_lifecycle_weight_applied_once():
    """Superseded entries should get exactly 0.5x weight, not 0.25x (no double-penalization)."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("the capital of france is paris and it is beautiful", "test")
        store.ingest("the capital of france is paris a major european city", "test")

        # Mark first as superseded
        entry = store.memories[0]
        entry.truth_state = "superseded"
        store.save()

        # Use explain=True to get SearchResult objects with .score
        results = store.search("capital of france paris", limit=10, explain=True)
        scores = [r.score for r in results if r.score > 0]
        # If we have both, the superseded one should be roughly 0.5x of the active one
        # (not 0.25x which would indicate double-penalization)
        # This is a sanity check — exact values depend on BM25 scoring
        assert len(results) >= 1  # At minimum, active result should appear


# ── Phase 3: Stale-Context Leak Fix tests ────────────────────────────────────

def test_active_memory_excludes_do_not_use():
    """ActiveMemory should not surface do_not_use entries."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("important fact about quantum computing breakthroughs in 2026", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="retracted paper")

        # If ActiveMemory is available, test it
        try:
            from parsica_memory.active_memory import _surfaceable
            assert _surfaceable(entry) == False
        except ImportError:
            # If _surfaceable is not importable, check the entry state directly
            assert entry.state == "do_not_use"


def test_assembler_excludes_deprecated():
    """Context assembler should not include deprecated entries."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("old deprecated information about the company structure", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="restructured")

        # Test the surfaceable check
        ts = (getattr(entry, "truth_state", "accepted") or "accepted").lower()
        state = (getattr(entry, "state", "active") or "active").lower()
        # Deprecated should NOT be surfaceable in assembler/active memory
        assert state == "deprecated"
        # Verify the _surfaceable helper agrees
        from parsica_memory.context_assembler import _surfaceable
        assert _surfaceable(entry) == False


def test_surfaceable_helper():
    """_surfaceable correctly filters by truth_state and state."""
    from parsica_memory.entry import MemoryEntry

    # Active + accepted = surfaceable
    e1 = MemoryEntry("test", "test", 0, "general")
    e1.state = "active"
    e1.truth_state = "accepted"

    # do_not_use = not surfaceable
    e2 = MemoryEntry("test", "test", 0, "general")
    e2.state = "do_not_use"
    e2.truth_state = "accepted"

    # deprecated = not surfaceable (in assembler/active memory context)
    e3 = MemoryEntry("test", "test", 0, "general")
    e3.state = "deprecated"
    e3.truth_state = "accepted"

    # retracted = not surfaceable
    e4 = MemoryEntry("test", "test", 0, "general")
    e4.state = "active"
    e4.truth_state = "retracted"

    # Helper function logic
    def surfaceable(entry):
        ts = (getattr(entry, "truth_state", "accepted") or "accepted").lower()
        state = (getattr(entry, "state", "active") or "active").lower()
        return ts != "retracted" and state not in ("do_not_use", "purged", "deprecated")

    assert surfaceable(e1) == True
    assert surfaceable(e2) == False
    assert surfaceable(e3) == False
    assert surfaceable(e4) == False


def test_claim_family_roundtrip():
    """ClaimFamily persists through ClaimStore save/load."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        cf = ClaimFamily(
            family_id="cf_001",
            normalized_assertion="the capital of france is paris",
            source_record_ids=["rec_001", "rec_002"],
        )
        store.add_family(cf)
        assert len(store) == 1

        # Reload
        store2 = ClaimStore(td)
        assert len(store2) == 1
        loaded = store2.get_family("cf_001")
        assert loaded.normalized_assertion == "the capital of france is paris"
        assert loaded.source_record_ids == ["rec_001", "rec_002"]


def test_claim_supersession():
    """Superseding a claim marks old as superseded and links new."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        old = ClaimFamily(family_id="cf_old", normalized_assertion="pluto is a planet")
        new = ClaimFamily(family_id="cf_new", normalized_assertion="pluto is a dwarf planet")
        store.add_family(old)
        store.add_family(new)

        result = store.supersede_claim("cf_old", "cf_new")
        assert result is True
        assert store.get_family("cf_old").state == "superseded"
        assert store.get_family("cf_old").corrected_by == "cf_new"
        assert store.get_family("cf_new").supersedes == "cf_old"


def test_claim_weight_affects_retrieval():
    """Records in superseded claim families should get 0.5x weight."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        cf = ClaimFamily(
            family_id="cf_001",
            normalized_assertion="old fact",
            state="superseded",
            source_record_ids=["rec_001"],
        )
        store.add_family(cf)

        assert store.get_claim_weight("rec_001") == 0.5
        assert store.get_claim_weight("rec_unknown") == 1.0  # no family = no penalty


def test_do_not_use_claim_excludes():
    """Records in do_not_use claim families should get 0.0 weight."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        cf = ClaimFamily(
            family_id="cf_001",
            normalized_assertion="retracted claim",
            state="do_not_use",
            source_record_ids=["rec_001"],
        )
        store.add_family(cf)
        assert store.get_claim_weight("rec_001") == 0.0


def test_mode_router_factual_query():
    """Short factual queries should route to precision mode."""
    # Test the mode selection logic
    try:
        from parsica_memory.query_time_enrichment import choose_mode, QueryFingerprint
        # If these exist, test them
        fp = QueryFingerprint("What is Jake's name?")
        mode = choose_mode(fp)
        # Should be precision for short factual queries
        assert mode.value in ("precision", "recent")  # recent maps to precision
    except (ImportError, AttributeError):
        # If the QTE system has different API, just verify modes exist
        from parsica_memory.contracts import RetrievalMode
        assert hasattr(RetrievalMode, "PRECISION") or hasattr(RetrievalMode, "precision")


def test_mode_router_broad_query():
    """Broad queries should route to evidence mode."""
    try:
        from parsica_memory.query_time_enrichment import choose_mode, QueryFingerprint
        fp = QueryFingerprint("Tell me about what happened on February 24th")
        mode = choose_mode(fp)
        assert mode.value in ("evidence", "semantic", "deep")
    except (ImportError, AttributeError):
        from parsica_memory.contracts import RetrievalMode
        assert hasattr(RetrievalMode, "EVIDENCE") or hasattr(RetrievalMode, "evidence")


def test_legacy_mode_mapping():
    """Legacy modes 'recent' and 'semantic' should map to precision and evidence."""
    try:
        from parsica_memory.query_time_enrichment import _map_legacy_mode
        assert _map_legacy_mode("recent") in ("precision", "PRECISION")
        assert _map_legacy_mode("semantic") in ("evidence", "EVIDENCE")
    except (ImportError, AttributeError):
        # If no explicit mapping function, verify the modes exist
        pass


def test_deep_mode_bounded():
    """DEEP mode should do bounded two-pass, not unbounded recursion."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        # Add some content
        store.ingest("quantum computing uses qubits for parallel computation", "test")
        store.ingest("classical computing uses bits for sequential operations", "test")
        store.ingest("machine learning requires large datasets for training", "test")

        # Search should complete without timeout (bounded)
        results = store.search("quantum computing versus classical approaches", limit=10)
        assert isinstance(results, list)
        # Should get results back (proves search works)
        assert len(results) >= 1


# Phase 6: Role-Specific Assembly Profiles

def test_assembly_profile_default_unchanged():
    """Default profile should match current behavior."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    default = ASSEMBLY_PROFILES["default"]
    assert abs(sum(default.values()) - 1.0) < 0.01  # percentages sum to ~1.0
    assert default["session"] == 0.30


def test_assembly_profile_critic_weights_evidence():
    """Critic profile should heavily weight evidence."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    critic = ASSEMBLY_PROFILES["critic"]
    assert critic["evidence"] == 0.40
    assert critic["evidence"] > critic["session"]


def test_assembly_profile_coder_weights_session():
    """Coder profile should heavily weight session context."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    coder = ASSEMBLY_PROFILES["coder"]
    assert coder["session"] == 0.40
    assert coder["session"] > coder["evidence"]


def test_assembly_profiles_all_sum_to_one():
    """All profiles should have percentages that sum to 1.0."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    for name, profile in ASSEMBLY_PROFILES.items():
        total = sum(profile.values())
        assert abs(total - 1.0) < 0.01, f"Profile '{name}' sums to {total}"


def test_ambient_event_confidence_roundtrip():
    """AmbientEvent confidence persists through to_dict/from_dict."""
    from parsica_memory.ambient_events import AmbientEvent
    ev = AmbientEvent(
        event_id="evt_test_001",
        identity_id="agent_a",
        source_body_id="body_1",
        target_scope="identity_durable",
        record_id="rec_001",
        summary="test fact",
        confidence=0.85,
    )
    d = ev.to_dict()
    assert d["confidence"] == 0.85

    ev2 = AmbientEvent.from_dict(d)
    assert ev2.confidence == 0.85


def test_ambient_event_confidence_default():
    """AmbientEvent defaults to 0.5 confidence."""
    from parsica_memory.ambient_events import AmbientEvent
    ev = AmbientEvent(
        event_id="evt_test_002",
        identity_id="agent_a",
        source_body_id="body_1",
        target_scope="identity_durable",
        record_id="rec_002",
        summary="test",
    )
    assert ev.confidence == 0.5


def test_peek_filters_low_confidence():
    """peek() with min_confidence should filter low-confidence events."""
    import tempfile
    from parsica_memory.ambient_events import AmbientEventStore
    with tempfile.TemporaryDirectory() as td:
        store = AmbientEventStore(td)

        # Publish high and low confidence events from body_a
        store.publish(
            identity_id="agent_a",
            source_body_id="body_a",
            record_id="rec_high",
            summary="high confidence fact",
            confidence=0.9,
        )
        store.publish(
            identity_id="agent_a",
            source_body_id="body_a",
            record_id="rec_low",
            summary="low confidence fact",
            confidence=0.2,
        )

        # Peek from body_b with min_confidence=0.5 — should only return the high one
        events, _cursor = store.peek("agent_a", "body_b", min_confidence=0.5)
        high_conf = [e for e in events if e.confidence >= 0.5]
        low_conf = [e for e in events if e.confidence < 0.5]
        assert len(low_conf) == 0
        if high_conf:
            assert high_conf[0].confidence >= 0.5


# ---------------------------------------------------------------------------
# v2.9.9 Eye P1 regression tests
# ---------------------------------------------------------------------------

def test_forget_returns_audit_key():
    """forget() should return backward-compatible dict with 'audit' key."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("something about the weather forecast for tomorrow", "test")
        result = store.forget(topic="weather")
        assert "audit" in result or "deprecated" in result


def test_surfaceable_importable_from_contracts():
    """surfaceable() should be importable from contracts."""
    from parsica_memory.contracts import surfaceable
    from parsica_memory.entry import MemoryEntry
    e = MemoryEntry("test", "test", 0, "general")
    assert surfaceable(e) == True
    e.state = "do_not_use"
    assert surfaceable(e) == False


# ---------------------------------------------------------------------------
# Phase B: Assembler→Search Plumbing tests (v2.9.9)
# ---------------------------------------------------------------------------

def test_active_memory_applies_lifecycle():
    """ActiveMemory should not surface do_not_use entries even through direct scan."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("important fact about machine learning algorithms and neural networks", "test")
        store.ingest("another fact about deep learning transformers and attention mechanisms", "test")

        # Mark one as do_not_use
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="retracted")

        # Verify the entry is marked
        assert entry.state == "do_not_use"

        # Search should not return it
        results = store.search("machine learning algorithms", limit=10)
        for r in results:
            e = getattr(r, 'entry', r)
            assert getattr(e, 'state', 'active') != 'do_not_use'


def test_assembler_lifecycle_weight_applied():
    """ContextAssembler should exclude deprecated/do_not_use from assembly."""
    from parsica_memory.contracts import surfaceable
    from parsica_memory.entry import MemoryEntry

    # Create entries with different states
    active = MemoryEntry("active content", "test", 0, "general")
    active.state = "active"

    deprecated = MemoryEntry("deprecated content", "test", 0, "general")
    deprecated.state = "deprecated"

    dnu = MemoryEntry("do not use content", "test", 0, "general")
    dnu.state = "do_not_use"

    entries = [active, deprecated, dnu]
    surfaced = [e for e in entries if surfaceable(e)]

    assert len(surfaced) == 1
    assert surfaced[0].state == "active"


# ---------------------------------------------------------------------------
# Phase C: Integration Tests — lifecycle pipeline end-to-end (v2.9.9)
# ---------------------------------------------------------------------------

def test_e2e_deprecate_then_search_excludes():
    """End-to-end: ingest → deprecate → search should not return deprecated entry."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")

        # Ingest two facts
        store.ingest("the earth revolves around the sun in approximately 365 days", "test")
        store.ingest("the moon orbits the earth every 27 days approximately", "test")

        # Deprecate the first
        earth_entry = [m for m in store.memories if "earth revolves" in m.content][0]
        rid = earth_entry.record_id or earth_entry.hash
        store.deprecate(rid, reason="outdated model")

        # Search should still find moon fact but earth should be filtered/downweighted
        results = store.search("earth moon orbit", limit=10)
        # Active results should rank above deprecated
        active_results = [r for r in results if getattr(getattr(r, 'entry', r), 'state', 'active') == 'active']
        assert len(active_results) >= 1


def test_e2e_do_not_use_invisible_everywhere():
    """End-to-end: do_not_use entry should be invisible in search, retrieve, and surfaceable."""
    import tempfile
    from parsica_memory import MemorySystem
    from parsica_memory.contracts import surfaceable
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("classified information about secret project alpha bravo", "test")

        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="classified")

        # surfaceable check
        assert surfaceable(entry) == False

        # Search should not return it
        results = store.search("secret project alpha", limit=10)
        for r in results:
            e = getattr(r, 'entry', r)
            assert getattr(e, 'state', 'active') != 'do_not_use'


def test_e2e_claim_supersession_affects_search():
    """End-to-end: superseding a claim should downweight linked records in search."""
    import tempfile
    from parsica_memory import MemorySystem
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")

        # Ingest old and new facts
        store.ingest("pluto is the ninth planet in our solar system orbiting the sun", "test")
        store.ingest("pluto is classified as a dwarf planet since 2006 by the IAU", "test")

        old_entry = [m for m in store.memories if "ninth planet" in m.content][0]
        new_entry = [m for m in store.memories if "dwarf planet" in m.content][0]

        old_rid = old_entry.record_id or old_entry.hash
        new_rid = new_entry.record_id or new_entry.hash

        # Create claim families and supersede
        cs = store.claim_store  # trigger lazy init
        old_claim = ClaimFamily(
            family_id="pluto_old",
            normalized_assertion="pluto is a planet",
            source_record_ids=[old_rid],
        )
        new_claim = ClaimFamily(
            family_id="pluto_new",
            normalized_assertion="pluto is a dwarf planet",
            source_record_ids=[new_rid],
        )
        cs.add_family(old_claim)
        cs.add_family(new_claim)
        cs.supersede_claim("pluto_old", "pluto_new")

        # Link records to families
        old_entry.family_id = "pluto_old"
        new_entry.family_id = "pluto_new"

        # Verify claim weights
        assert cs.get_claim_weight(old_rid) == 0.5  # superseded
        assert cs.get_claim_weight(new_rid) == 1.0  # current


def test_e2e_lifecycle_survives_reload():
    """End-to-end: deprecated state survives save→reload cycle."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("important historical record about company founding in 2020", "test")

        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="outdated")
        store.save()

        # Reload from disk
        store2 = MemorySystem(td, agent_name="test")
        reloaded = [m for m in store2.memories if (m.record_id or m.hash) == rid]
        assert len(reloaded) == 1
        assert reloaded[0].state == "deprecated"
        assert reloaded[0].state_reason == "outdated"


def test_e2e_cache_invalidation_on_state_change():
    """End-to-end: changing state should invalidate cache so next search reflects it."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("unique alpaca farming techniques for high altitude regions", "test")

        # First search — should find it
        results1 = store.search("alpaca farming", limit=10)
        assert len(results1) >= 1

        # Mark do_not_use
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="retracted")

        # Second search — should NOT find it (cache invalidated)
        results2 = store.search("alpaca farming", limit=10)
        for r in results2:
            e = getattr(r, 'entry', r)
            assert getattr(e, 'state', 'active') != 'do_not_use'


# ============================================================
# Section: Claim Store Integration (v3.0 test gate)
# ============================================================

def test_claim_store_persists_across_reload():
    """Claim families survive ClaimStore reload from disk."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        store.add_family(ClaimFamily(family_id="f1", normalized_assertion="test claim", source_record_ids=["r1"]))
        del store
        store2 = ClaimStore(td)
        assert len(store2) == 1
        fam = store2.get_family("f1")
        assert fam is not None
        assert fam.normalized_assertion == "test claim"


def test_claim_store_link_record():
    """link_record adds record to existing family."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore, ClaimFamily
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        store.add_family(ClaimFamily(family_id="f1", normalized_assertion="test", source_record_ids=["r1"]))
        result = store.link_record("r2", "f1")
        assert result is True
        assert "r2" in store.get_family("f1").source_record_ids


def test_claim_store_link_nonexistent_family():
    """link_record to nonexistent family returns False."""
    import tempfile
    from parsica_memory.claim_store import ClaimStore
    with tempfile.TemporaryDirectory() as td:
        store = ClaimStore(td)
        assert store.link_record("r1", "nonexistent") is False


def test_claim_state_validation_rejects_invalid():
    """ClaimFamily with invalid state raises ValueError."""
    import pytest
    from parsica_memory.claim_store import ClaimFamily
    with pytest.raises(ValueError, match="invalid claim state"):
        ClaimFamily(family_id="f1", normalized_assertion="test", state="bogus")


# ============================================================
# Section: Retrieval Score Verification (v3.0 test gate)
# ============================================================

def test_retrieve_score_differs_by_state():
    """Deprecating an entry should lower its retrieval score (0.25x penalty)."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("quantum physics explains wave particle duality in atoms", "test")

        # Score before deprecation
        results_before = store.search("quantum physics", limit=10, explain=True)
        assert len(results_before) >= 1, "Should find entry before deprecation"
        score_before = results_before[0].score

        # Deprecate and re-score
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="outdated")

        results_after = store.search("quantum physics", limit=10, explain=True)
        assert len(results_after) >= 1, "Deprecated entry should still appear in results"
        score_after = results_after[0].score

        assert score_after < score_before, \
            f"Deprecated entry score ({score_after:.4f}) should be lower than active score ({score_before:.4f})"


def test_retrieve_excludes_purged_state():
    """Purged entries should never appear in search results."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("extremely sensitive classified data about operation phoenix", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.update_record_state(rid, "purged", reason="GDPR")
        results = store.search("classified operation phoenix", limit=10)
        for r in results:
            e = getattr(r, 'entry', r)
            assert getattr(e, 'state', 'active') != 'purged', \
                "Purged entry must never appear in search results"


def test_search_apply_lifecycle_false_returns_all():
    """search(apply_lifecycle=False) should return entries regardless of state."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        # Ingest two entries that pass the quality gate (P2+ content)
        store.ingest(
            "The solar energy system produces 4.5 megawatts from photovoltaic panels installed recently",
            "test"
        )
        store.ingest(
            "Coal power plants emit carbon dioxide contributing to climate change and air pollution",
            "test"
        )
        assert len(store.memories) == 2, \
            f"Expected 2 memories after ingest, got {len(store.memories)}"
        entry = store.memories[1]
        rid = entry.record_id or entry.hash
        store.deprecate(rid, reason="outdated")

        results_with = store.search("energy climate solar coal", limit=10, apply_lifecycle=True)
        try:
            results_without = store.search("energy climate solar coal", limit=10, apply_lifecycle=False)
            assert len(results_without) >= len(results_with), \
                "apply_lifecycle=False should return at least as many results as True"
        except TypeError:
            pass  # apply_lifecycle param may not be exposed on all search paths


# ============================================================
# Section: Mode Router (v3.0 test gate)
# ============================================================

def test_mode_precision_for_short_entity_query():
    """Short entity queries should route to PRECISION."""
    from parsica_memory.query_time_enrichment import fingerprint_query, choose_mode, RetrievalMode
    from parsica_memory.contracts import RetrievalRequest
    req = RetrievalRequest(query="What is Jake's email?")
    fp = fingerprint_query(req)
    mode = choose_mode(req, fp)
    assert mode in (RetrievalMode.PRECISION, RetrievalMode.EVIDENCE), \
        f"Short entity query should route to PRECISION or EVIDENCE, got {mode}"


def test_mode_evidence_for_architecture_query():
    """Architecture/explain queries should route to EVIDENCE."""
    from parsica_memory.query_time_enrichment import fingerprint_query, choose_mode, RetrievalMode
    from parsica_memory.contracts import RetrievalRequest
    req = RetrievalRequest(query="explain the architecture of our memory retrieval system in detail")
    fp = fingerprint_query(req)
    mode = choose_mode(req, fp)
    assert mode in (RetrievalMode.EVIDENCE, RetrievalMode.DEEP), \
        f"Architecture query should route to EVIDENCE or DEEP, got {mode}"


def test_mode_deep_for_complex():
    """Complex multi-faceted queries should route to DEEP."""
    from parsica_memory.query_time_enrichment import fingerprint_query, choose_mode, RetrievalMode
    from parsica_memory.contracts import RetrievalRequest
    req = RetrievalRequest(
        query="Compare the tradeoffs between using embeddings versus BM25 for retrieval "
              "in our current architecture considering cost latency and accuracy"
    )
    fp = fingerprint_query(req)
    mode = choose_mode(req, fp)
    assert mode == RetrievalMode.DEEP, f"Complex query should route to DEEP, got {mode}"


def test_legacy_mode_maps_correctly():
    """Legacy mode names should map to current modes."""
    from parsica_memory.query_time_enrichment import _map_legacy_mode
    assert _map_legacy_mode("recent") == "precision"
    assert _map_legacy_mode("semantic") == "evidence"
    assert _map_legacy_mode("precision") == "precision"
    assert _map_legacy_mode("deep") == "deep"


# ============================================================
# Section: Assembly Profiles (v3.0 test gate)
# ============================================================

def test_all_profiles_exist():
    """All 6 profiles should be defined."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    expected = {"default", "planner", "researcher", "coder", "critic", "executive"}
    assert set(ASSEMBLY_PROFILES.keys()) == expected, \
        f"Expected profiles {expected}, got {set(ASSEMBLY_PROFILES.keys())}"


def test_profile_budgets_cover_all_categories():
    """Each profile should define all 5 budget categories."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    expected_keys = {"session", "handoff", "durable", "packs", "evidence"}
    for name, profile in ASSEMBLY_PROFILES.items():
        assert set(profile.keys()) == expected_keys, \
            f"Profile '{name}' has keys {set(profile.keys())}, expected {expected_keys}"


def test_profile_no_negative_budgets():
    """No profile should have negative budget percentages."""
    from parsica_memory.context_assembler import ASSEMBLY_PROFILES
    for name, profile in ASSEMBLY_PROFILES.items():
        for key, val in profile.items():
            assert val >= 0, f"Profile '{name}' has negative budget for '{key}': {val}"


# ============================================================
# Section: WAL / Persistence (v3.0 test gate)
# ============================================================

def test_state_change_persists_through_save_reload():
    """State changes should survive save() + fresh MemorySystem load."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("persistent state test content about database migrations", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        store.mark_do_not_use(rid, reason="retracted study")
        store.save()

        store2 = MemorySystem(td, agent_name="test")
        reloaded = [m for m in store2.memories if (m.record_id or m.hash) == rid]
        assert len(reloaded) == 1, "Entry should exist after reload"
        assert reloaded[0].state == "do_not_use", \
            f"State should be do_not_use after reload, got {reloaded[0].state}"
        assert reloaded[0].state_reason == "retracted study", \
            f"state_reason should be preserved, got {reloaded[0].state_reason!r}"


def test_family_id_round_trips_through_dict():
    """family_id should survive to_dict() + from_dict() serialization round-trip."""
    from parsica_memory.entry import MemoryEntry
    entry = MemoryEntry("family id persistence test about claim linkage", "test", 1, "general")
    entry.family_id = "test_family_001"
    d = entry.to_dict()
    assert d.get("family_id") == "test_family_001", \
        f"to_dict() should include family_id, got {d.get('family_id')!r}"
    reloaded = MemoryEntry.from_dict(d)
    assert reloaded.family_id == "test_family_001", \
        f"from_dict() should restore family_id, got {reloaded.family_id!r}"


def test_updated_at_set_on_state_change():
    """updated_at should be set when state changes."""
    import tempfile
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as td:
        store = MemorySystem(td, agent_name="test")
        store.ingest("updated at timestamp verification content here", "test")
        entry = store.memories[0]
        rid = entry.record_id or entry.hash
        assert entry.updated_at == "", f"updated_at should start empty, got {entry.updated_at!r}"
        store.deprecate(rid, reason="test")
        assert entry.updated_at != "", "updated_at should be set after state change"
        assert "T" in entry.updated_at, \
            f"updated_at should be ISO format (contain 'T'), got {entry.updated_at!r}"


# ============================================================
# Section: Ambient Confidence (v3.0 test gate)
# ============================================================

def test_ambient_confidence_stored_as_float():
    """AmbientEvent confidence should be stored as a float."""
    from parsica_memory.ambient_events import AmbientEvent
    ev = AmbientEvent(
        event_id="e1", identity_id="a", source_body_id="s",
        target_scope="global", record_id="r1", summary="test",
        confidence=1.5
    )
    assert isinstance(ev.confidence, float), \
        f"confidence should be float, got {type(ev.confidence)}"


def test_ambient_event_default_fields():
    """AmbientEvent should have sensible defaults."""
    from parsica_memory.ambient_events import AmbientEvent
    ev = AmbientEvent(
        event_id="e1", identity_id="agent1", source_body_id="sess1",
        target_scope="global", record_id="r1", summary="test content"
    )
    assert ev.confidence == 0.5, f"Default confidence should be 0.5, got {ev.confidence}"
    assert ev.event_type == "discovery", f"Default event_type should be 'discovery', got {ev.event_type!r}"


def test_surfaceable_with_all_states():
    """surfaceable() should correctly handle all valid states."""
    from parsica_memory.contracts import surfaceable
    from parsica_memory.entry import MemoryEntry

    state_expectations = [
        ("active", True),
        ("deprecated", False),
        ("do_not_use", False),
        ("purged", False),
    ]
    for state, expected in state_expectations:
        e = MemoryEntry("test", "test", 0, "general")
        e.state = state
        result = surfaceable(e)
        assert result == expected, \
            f"surfaceable() for state={state!r}: expected {expected}, got {result}"
