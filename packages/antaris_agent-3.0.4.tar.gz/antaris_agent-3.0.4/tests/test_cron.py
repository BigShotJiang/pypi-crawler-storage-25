"""Tests for antaris_agent.core.cron"""
import asyncio
import json
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch, AsyncMock

import pytest

from antaris_agent.core.cron import CronJob, CronScheduler, _match_cron_field, _match_cron_expr, _normalize_dow_field


# ── CronJob ───────────────────────────────────────────────────────────────────

class TestCronJob:
    def test_create_basic(self):
        job = CronJob(id="abc123", name="Test Job", schedule_kind="every", schedule_every_ms=60000)
        assert job.id == "abc123"
        assert job.name == "Test Job"
        assert job.schedule_kind == "every"
        assert job.schedule_every_ms == 60000
        assert job.enabled is True
        assert job.run_count == 0
        assert job.payload_kind == "systemEvent"

    def test_serialization_round_trip(self):
        job = CronJob(
            id=str(uuid.uuid4()),
            name="Round Trip",
            schedule_kind="every",
            schedule_every_ms=5000,
            payload_kind="agentTurn",
            payload_text="Hello, world!",
            channel_id="123456",
            enabled=True,
            last_run=None,
            run_count=3,
        )
        d = job.to_dict()
        restored = CronJob.from_dict(d)
        assert restored.id == job.id
        assert restored.name == job.name
        assert restored.schedule_every_ms == job.schedule_every_ms
        assert restored.payload_kind == job.payload_kind
        assert restored.payload_text == job.payload_text
        assert restored.run_count == job.run_count

    def test_from_dict_ignores_extra_keys(self):
        """from_dict should not blow up on extra unknown keys."""
        d = {
            "id": "x",
            "name": "Y",
            "schedule_kind": "every",
            "schedule_every_ms": 1000,
            "unknown_future_key": "ignored",
        }
        # Extra key should be silently dropped
        job = CronJob.from_dict(d)
        assert job.id == "x"

    def test_created_at_auto(self):
        before = time.time()
        job = CronJob(id="t", name="T", schedule_kind="every")
        after = time.time()
        assert before <= job.created_at <= after

    def test_repr(self):
        """P2-7: CronJob has a useful __repr__."""
        job = CronJob(id="r1", name="Repr Test", schedule_kind="cron", enabled=True)
        r = repr(job)
        assert "CronJob(" in r
        assert "r1" in r
        assert "Repr Test" in r
        assert "cron" in r
        assert "enabled=True" in r


# ── CronScheduler ─────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_jobs_path(tmp_path):
    return tmp_path / "cron" / "jobs.json"


async def _noop(job):
    pass


class TestCronSchedulerJobManagement:
    def test_add_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j1", name="Job One", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)
        assert scheduler.get_job("j1") is not None
        assert len(scheduler.list_jobs()) == 1

    def test_add_job_persists(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j2", name="Persist", schedule_kind="every", schedule_every_ms=2000)
        scheduler.add_job(job)
        # Reload from disk
        scheduler2 = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        loaded = scheduler2.get_job("j2")
        assert loaded is not None
        assert loaded.name == "Persist"

    def test_remove_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j3", name="Remove Me", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)
        result = scheduler.remove_job("j3")
        assert result is True
        assert scheduler.get_job("j3") is None

    def test_remove_nonexistent(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        result = scheduler.remove_job("nope")
        assert result is False

    def test_list_jobs(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        for i in range(3):
            scheduler.add_job(CronJob(id=f"j{i}", name=f"Job {i}", schedule_kind="every", schedule_every_ms=1000))
        jobs = scheduler.list_jobs()
        assert len(jobs) == 3

    def test_replace_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="dup", name="Original", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)
        job2 = CronJob(id="dup", name="Replaced", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job2)
        assert scheduler.get_job("dup").name == "Replaced"
        assert len(scheduler.list_jobs()) == 1


class TestCronSchedulerIsDue:
    def test_every_never_run_is_due_immediately(self, tmp_jobs_path):
        """A job with schedule_kind=every and last_run=None should be due right away."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e1", name="Every 1s",
            schedule_kind="every",
            schedule_every_ms=1000,
            last_run=None,
        )
        assert scheduler._is_due(job) is True

    def test_every_just_ran_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e2", name="Every 1h",
            schedule_kind="every",
            schedule_every_ms=3_600_000,  # 1 hour
            last_run=time.time(),  # just ran
        )
        assert scheduler._is_due(job) is False

    def test_every_overdue_is_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e3", name="Every 1s overdue",
            schedule_kind="every",
            schedule_every_ms=1000,
            last_run=time.time() - 5,  # 5 seconds ago, interval is 1s
        )
        assert scheduler._is_due(job) is True

    def test_disabled_never_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="d1", name="Disabled",
            schedule_kind="every",
            schedule_every_ms=1,
            enabled=False,
            last_run=None,
        )
        assert scheduler._is_due(job) is False

    def test_at_future_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at1", name="Future At",
            schedule_kind="at",
            schedule_at=future,
            run_count=0,
        )
        assert scheduler._is_due(job) is False

    def test_at_past_is_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at2", name="Past At",
            schedule_kind="at",
            schedule_at=past,
            run_count=0,
        )
        assert scheduler._is_due(job) is True

    def test_at_fires_once_then_not_again(self, tmp_jobs_path):
        """After run_count > 0, the 'at' job should never be due again."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at3", name="One-shot",
            schedule_kind="at",
            schedule_at=past,
            run_count=1,  # already fired once
        )
        assert scheduler._is_due(job) is False

    def test_cron_kind_without_expression_returns_false(self, tmp_jobs_path):
        """cron jobs without an expression should not be due."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="c1", name="Cron expr",
            schedule_kind="cron",
            schedule_cron=None,
        )
        assert scheduler._is_due(job) is False

    def test_unknown_schedule_kind_returns_false(self, tmp_jobs_path):
        """P2-9: Unknown schedule_kind should return False."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="unk1", name="Unknown Kind",
            schedule_kind="unknown_type",
        )
        assert scheduler._is_due(job) is False


class TestCronSchedulerRunNow:
    def test_run_now_resets_last_run(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="rn1", name="Run Now",
            schedule_kind="every",
            schedule_every_ms=3_600_000,
            last_run=time.time(),  # just ran — normally not due
        )
        scheduler.add_job(job)
        scheduler.run_now("rn1")
        updated = scheduler.get_job("rn1")
        assert updated.last_run is None

    def test_run_now_nonexistent_returns_false(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        result = scheduler.run_now("no-such-id")
        assert result is False

    def test_run_now_persists(self, tmp_jobs_path):
        """P1-1 / P2-9: run_now() calls _save(), so the reset survives reload."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="rn_persist", name="Persist Run Now",
            schedule_kind="every",
            schedule_every_ms=3_600_000,
            last_run=time.time(),
        )
        scheduler.add_job(job)
        scheduler.run_now("rn_persist")
        # Reload from disk
        scheduler2 = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        loaded = scheduler2.get_job("rn_persist")
        assert loaded is not None
        assert loaded.last_run is None

    def test_run_now_on_at_job(self, tmp_jobs_path):
        """P2-9: run_now on an 'at' job resets last_run."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        job = CronJob(
            id="rn_at", name="Run Now At",
            schedule_kind="at",
            schedule_at=past,
            last_run=time.time(),
        )
        scheduler.add_job(job)
        assert scheduler.run_now("rn_at") is True
        assert scheduler.get_job("rn_at").last_run is None

    def test_run_now_on_cron_job(self, tmp_jobs_path):
        """P2-9: run_now on a 'cron' job resets last_run."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="rn_cron", name="Run Now Cron",
            schedule_kind="cron",
            schedule_cron="* * * * *",
            last_run=time.time(),
        )
        scheduler.add_job(job)
        assert scheduler.run_now("rn_cron") is True
        assert scheduler.get_job("rn_cron").last_run is None


class TestCronSchedulerAsync:
    def test_start_stop(self, tmp_jobs_path):
        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
            await scheduler.start()
            assert scheduler._task is not None
            await scheduler.stop()
            assert scheduler._task.cancelled() or scheduler._task.done()

        asyncio.run(_run())

    def test_tick_fires_due_jobs(self, tmp_jobs_path):
        fired = []

        async def _on_fire(job):
            fired.append(job.id)

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="fire1", name="Should Fire",
                schedule_kind="every",
                schedule_every_ms=1,  # 1ms — definitely overdue
                last_run=time.time() - 10,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            assert "fire1" in fired

        asyncio.run(_run())


class TestCronDeltaFeatures:
    def test_anchor_ms_aligns_correctly(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        now = time.time()
        anchor_ms = int((now - 12) * 1000)
        job = CronJob(
            id="a1",
            name="Anchored",
            schedule_kind="every",
            schedule_every_ms=5000,
            schedule_anchor_ms=anchor_ms,
            last_run=now - 8,
        )
        assert scheduler._is_due(job) is True

        job.last_run = now - 1
        assert scheduler._is_due(job) is False

    def test_anchor_ms_no_drift(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        now = time.time()
        anchor_ms = int((now - 23) * 1000)
        job = CronJob(
            id="a2",
            name="No Drift",
            schedule_kind="every",
            schedule_every_ms=10000,
            schedule_anchor_ms=anchor_ms,
            last_run=now - 13,
        )
        assert scheduler._is_due(job) is True

        job.last_run = now - 2
        assert scheduler._is_due(job) is False

    def test_anchor_ms_future_anchor_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        anchor_ms = int((time.time() + 60) * 1000)
        job = CronJob(
            id="a3",
            name="Future Anchor",
            schedule_kind="every",
            schedule_every_ms=1000,
            schedule_anchor_ms=anchor_ms,
        )
        assert scheduler._is_due(job) is False

    def test_anchor_ms_none_uses_existing_behavior(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        due_job = CronJob(
            id="a4",
            name="Legacy Due",
            schedule_kind="every",
            schedule_every_ms=1000,
            last_run=time.time() - 5,
        )
        not_due_job = CronJob(
            id="a5",
            name="Legacy Not Due",
            schedule_kind="every",
            schedule_every_ms=3_600_000,
            last_run=time.time(),
        )
        assert scheduler._is_due(due_job) is True
        assert scheduler._is_due(not_due_job) is False

    def test_anchor_last_run_none_fires_at_aligned_time(self, tmp_jobs_path):
        """P1-3 / P2-9: Anchor + last_run=None fires at the current aligned period
        if it's within one interval of now."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        now = time.time()
        # Anchor 100 seconds ago, interval 10 seconds
        anchor_ms = int((now - 100) * 1000)
        job = CronJob(
            id="anchor_new",
            name="Anchor New",
            schedule_kind="every",
            schedule_every_ms=10000,
            schedule_anchor_ms=anchor_ms,
            last_run=None,
        )
        # current_period_fire = anchor_s + 10 * 10 = anchor_s + 100 = now
        # now - interval_s = now - 10 → current_period_fire (now) >= now - 10 → True
        assert scheduler._is_due(job) is True

    def test_delivery_fields_default(self):
        job = CronJob(id="d1", name="Delivery Defaults", schedule_kind="every")
        assert job.delivery_mode == "none"
        assert job.delivery_channel is None
        assert job.delivery_to is None
        assert job.delivery_best_effort is True

    def test_delivery_fields_serialize(self):
        job = CronJob(
            id="d2",
            name="Delivery Serialize",
            schedule_kind="every",
            delivery_mode="announce",
            delivery_channel="discord:123",
            delivery_to="user:456",
            delivery_best_effort=False,
        )
        restored = CronJob.from_dict(job.to_dict())
        assert restored.delivery_mode == "announce"
        assert restored.delivery_channel == "discord:123"
        assert restored.delivery_to == "user:456"
        assert restored.delivery_best_effort is False

    def test_state_tracking_success(self, tmp_jobs_path):
        async def _on_fire(job):
            await asyncio.sleep(0.001)

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="s1",
                name="State Success",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            updated = scheduler.get_job("s1")
            assert updated.status == "idle"
            assert updated.consecutive_errors == 0
            assert updated.last_error is None
            assert updated.last_success is not None
            assert updated.last_duration_ms is not None
            assert updated.last_duration_ms >= 0

        asyncio.run(_run())

    def test_state_tracking_error(self, tmp_jobs_path):
        async def _on_fire(job):
            raise RuntimeError("boom")

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="s2",
                name="State Error",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            updated = scheduler.get_job("s2")
            assert updated.status == "error"
            assert updated.consecutive_errors == 1
            assert updated.last_error == "boom"
            assert updated.last_duration_ms is not None
            assert updated.last_success is None

        asyncio.run(_run())

    def test_state_tracking_error_then_success_resets(self, tmp_jobs_path):
        state = {"fail": True}

        async def _on_fire(job):
            if state["fail"]:
                raise RuntimeError("first failure")

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="s3",
                name="State Reset",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            updated = scheduler.get_job("s3")
            assert updated.status == "error"
            assert updated.consecutive_errors == 1
            assert updated.last_error == "first failure"

            state["fail"] = False
            updated.last_run = time.time() - 10
            await scheduler._tick()
            updated = scheduler.get_job("s3")
            assert updated.status == "idle"
            assert updated.consecutive_errors == 0
            assert updated.last_error is None
            assert updated.last_success is not None

        asyncio.run(_run())

    def test_delete_after_run_removes_job(self, tmp_jobs_path):
        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
            job = CronJob(
                id="x1",
                name="Delete After",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
                delete_after_run=True,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            assert scheduler.get_job("x1") is None

        asyncio.run(_run())

    def test_delete_after_run_false_keeps_job(self, tmp_jobs_path):
        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
            job = CronJob(
                id="x2",
                name="Keep After",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
                delete_after_run=False,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            assert scheduler.get_job("x2") is not None

        asyncio.run(_run())

    def test_delete_after_run_on_error_keeps_job(self, tmp_jobs_path):
        async def _on_fire(job):
            raise RuntimeError("fail and keep")

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="x3",
                name="Keep On Error",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
                delete_after_run=True,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            updated = scheduler.get_job("x3")
            assert updated is not None
            assert updated.status == "error"

        asyncio.run(_run())

    def test_delete_after_run_direct_field_access(self):
        """P2-6 / P2-9: delete_after_run is a direct dataclass field, not via getattr."""
        job = CronJob(id="dfa1", name="Direct Access", schedule_kind="every", delete_after_run=True)
        assert job.delete_after_run is True
        job2 = CronJob(id="dfa2", name="Default", schedule_kind="every")
        assert job2.delete_after_run is False


# ── Cron Expression Parsing (Alpha Pair) ──────────────────────────────────────

class TestCronExpressions:
    """Tests for cron expression matching helpers and cron-kind scheduling."""

    # -- _match_cron_field tests --

    def test_cron_field_match_star(self):
        """``*`` matches anything within range."""
        for v in (0, 15, 30, 59):
            assert _match_cron_field("*", v, 0, 59) is True

    def test_cron_field_match_range(self):
        """``1-5`` matches 1 through 5 inclusive."""
        for v in (1, 2, 3, 4, 5):
            assert _match_cron_field("1-5", v, 0, 59) is True
        for v in (0, 6, 59):
            assert _match_cron_field("1-5", v, 0, 59) is False

    def test_cron_field_match_step(self):
        """``*/10`` matches 0,10,20,30,40,50."""
        expected = {0, 10, 20, 30, 40, 50}
        for v in range(60):
            assert _match_cron_field("*/10", v, 0, 59) is (v in expected), f"v={v}"

    def test_cron_field_match_list(self):
        """``1,3,5`` matches those exact values."""
        for v in (1, 3, 5):
            assert _match_cron_field("1,3,5", v, 0, 59) is True
        for v in (0, 2, 4, 6):
            assert _match_cron_field("1,3,5", v, 0, 59) is False

    def test_cron_field_match_range_step(self):
        """``10-30/5`` matches 10,15,20,25,30."""
        expected = {10, 15, 20, 25, 30}
        for v in range(60):
            assert _match_cron_field("10-30/5", v, 0, 59) is (v in expected), f"v={v}"

    # -- _match_cron_expr tests --

    def test_cron_every_minute(self):
        """``* * * * *`` matches any datetime."""
        dt = datetime(2026, 3, 26, 14, 30, 0)
        assert _match_cron_expr("* * * * *", dt) is True

    def test_cron_specific_time(self):
        """``30 14 * * *`` matches 14:30 only."""
        assert _match_cron_expr("30 14 * * *", datetime(2026, 3, 26, 14, 30)) is True
        assert _match_cron_expr("30 14 * * *", datetime(2026, 3, 26, 14, 31)) is False
        assert _match_cron_expr("30 14 * * *", datetime(2026, 3, 26, 15, 30)) is False

    def test_cron_ranges(self):
        """``0 9-17 * * 1-5`` matches weekday business hours."""
        # Wednesday 2026-03-25 at 10:00
        assert _match_cron_expr("0 9-17 * * 1-5", datetime(2026, 3, 25, 10, 0)) is True
        # Wednesday at 8:00 — outside hour range
        assert _match_cron_expr("0 9-17 * * 1-5", datetime(2026, 3, 25, 8, 0)) is False
        # Sunday 2026-03-29 at 10:00 — wrong day of week
        assert _match_cron_expr("0 9-17 * * 1-5", datetime(2026, 3, 29, 10, 0)) is False

    def test_cron_steps(self):
        """``*/15 * * * *`` matches 0,15,30,45."""
        for m in (0, 15, 30, 45):
            assert _match_cron_expr(f"*/15 * * * *", datetime(2026, 1, 1, 0, m)) is True
        for m in (1, 14, 16, 29, 31, 44, 46, 59):
            assert _match_cron_expr(f"*/15 * * * *", datetime(2026, 1, 1, 0, m)) is False

    def test_cron_lists(self):
        """``0 6,12,18 * * *`` matches those hours."""
        for h in (6, 12, 18):
            assert _match_cron_expr("0 6,12,18 * * *", datetime(2026, 1, 1, h, 0)) is True
        for h in (0, 5, 7, 11, 13, 17, 19, 23):
            assert _match_cron_expr("0 6,12,18 * * *", datetime(2026, 1, 1, h, 0)) is False

    def test_cron_day_of_week_sunday(self):
        """``0 6 * * 0`` matches Sundays at 6:00am."""
        # 2026-03-29 is a Sunday
        assert _match_cron_expr("0 6 * * 0", datetime(2026, 3, 29, 6, 0)) is True
        # Monday
        assert _match_cron_expr("0 6 * * 0", datetime(2026, 3, 30, 6, 0)) is False

    def test_cron_day_of_week_7_is_sunday(self):
        """``0 6 * * 7`` also matches Sunday (7 == Sunday alias)."""
        # 2026-03-29 is a Sunday
        assert _match_cron_expr("0 6 * * 7", datetime(2026, 3, 29, 6, 0)) is True
        # Monday
        assert _match_cron_expr("0 6 * * 7", datetime(2026, 3, 30, 6, 0)) is False

    def test_cron_with_timezone(self):
        """Timezone-aware matching with America/Los_Angeles."""
        from zoneinfo import ZoneInfo
        la = ZoneInfo("America/Los_Angeles")
        # 2026-03-26 14:30 PDT
        dt_la = datetime(2026, 3, 26, 14, 30, tzinfo=la)
        assert _match_cron_expr("30 14 * * *", dt_la) is True
        assert _match_cron_expr("30 15 * * *", dt_la) is False

    def test_cron_no_refire_same_minute(self, tmp_jobs_path):
        """P1-2 / P2-8: A cron job with last_run very recently should NOT be due again.
        Uses mocked time for determinism."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        fake_now = 1711500000.0  # a fixed epoch time
        fake_dt = datetime(2026, 3, 26, 14, 30, 0)  # matches "* * * * *"
        job = CronJob(
            id="refire1",
            name="No Refire",
            schedule_kind="cron",
            schedule_cron="* * * * *",  # every minute
            last_run=fake_now - 10,  # 10 seconds ago
        )
        with patch("antaris_agent.core.cron.time.time", return_value=fake_now), \
             patch("antaris_agent.core.cron._datetime") as mock_dt:
            mock_dt.now.return_value = fake_dt
            assert scheduler._is_due(job) is False

    def test_cron_invalid_expr_returns_false(self):
        """Bad expressions return False without raising."""
        dt = datetime(2026, 3, 26, 14, 30)
        assert _match_cron_expr("", dt) is False
        assert _match_cron_expr("not a cron", dt) is False
        assert _match_cron_expr("* * *", dt) is False  # too few fields
        assert _match_cron_expr("* * * * * *", dt) is False  # too many fields
        assert _match_cron_expr("abc def ghi jkl mno", dt) is False

    def test_schedule_tz_serialization(self):
        """schedule_tz survives round-trip serialization."""
        job = CronJob(
            id="tz1",
            name="TZ Job",
            schedule_kind="cron",
            schedule_cron="30 14 * * *",
            schedule_tz="America/Los_Angeles",
        )
        d = job.to_dict()
        assert d["schedule_tz"] == "America/Los_Angeles"
        restored = CronJob.from_dict(d)
        assert restored.schedule_tz == "America/Los_Angeles"
        assert restored.schedule_cron == "30 14 * * *"

    def test_cron_kind_is_now_functional(self, tmp_jobs_path):
        """Cron kind should now return True when expression matches (not just False)."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="cron_live",
            name="Live Cron",
            schedule_kind="cron",
            schedule_cron="* * * * *",  # matches every minute
        )
        # This should now be True (was False before implementation)
        assert scheduler._is_due(job) is True


# ── P0-1: Wraparound Range Tests ─────────────────────────────────────────────

class TestWraparoundRanges:
    """P0-1 / P2-9: Wraparound ranges like 23-3 (hours) or 5-1 (DOW)."""

    def test_wraparound_hours_23_to_3(self):
        """23-3 should match 23, 0, 1, 2, 3."""
        for v in (23, 0, 1, 2, 3):
            assert _match_cron_field("23-3", v, 0, 23) is True, f"v={v} should match 23-3"
        for v in (4, 12, 22):
            assert _match_cron_field("23-3", v, 0, 23) is False, f"v={v} should NOT match 23-3"

    def test_wraparound_dow_5_to_1(self):
        """5-1 (Fri-Mon) should match 5, 6, 0, 1."""
        for v in (5, 6, 0, 1):
            assert _match_cron_field("5-1", v, 0, 6) is True, f"v={v} should match 5-1"
        for v in (2, 3, 4):
            assert _match_cron_field("5-1", v, 0, 6) is False, f"v={v} should NOT match 5-1"

    def test_wraparound_months_11_to_2(self):
        """11-2 should match 11, 12, 1, 2."""
        for v in (11, 12, 1, 2):
            assert _match_cron_field("11-2", v, 1, 12) is True, f"v={v} should match 11-2"
        for v in (3, 5, 10):
            assert _match_cron_field("11-2", v, 1, 12) is False, f"v={v} should NOT match 11-2"

    def test_wraparound_with_step_23_to_3_step_2(self):
        """23-3/2 (hours): starting at 23, step 2 → 23, 1, 3."""
        # 23 → +2=25 wraps to 1 → +2=3
        assert _match_cron_field("23-3/2", 23, 0, 23) is True
        assert _match_cron_field("23-3/2", 1, 0, 23) is True
        assert _match_cron_field("23-3/2", 3, 0, 23) is True
        # 0 and 2 should NOT match (they're between steps)
        assert _match_cron_field("23-3/2", 0, 0, 23) is False
        assert _match_cron_field("23-3/2", 2, 0, 23) is False

    def test_wraparound_in_cron_expr_hours(self):
        """Full cron expr with wraparound hours: ``0 22-2 * * *``."""
        for h in (22, 23, 0, 1, 2):
            dt = datetime(2026, 3, 26, h, 0)
            assert _match_cron_expr(f"0 22-2 * * *", dt) is True, f"h={h}"
        for h in (3, 12, 21):
            dt = datetime(2026, 3, 26, h, 0)
            assert _match_cron_expr(f"0 22-2 * * *", dt) is False, f"h={h}"


# ── P0-2: DOM+DOW OR Semantics Tests ─────────────────────────────────────────

class TestDomDowOrSemantics:
    """P0-2 / P2-9: When both DOM and DOW are non-wildcard, use OR semantics."""

    def test_dom_and_dow_both_nonwild_or_semantics(self):
        """``0 9 15 * 5`` fires on 15th of month OR on Fridays."""
        # 2026-03-15 is a Sunday — not a Friday, but IS the 15th → should fire
        assert _match_cron_expr("0 9 15 * 5", datetime(2026, 3, 15, 9, 0)) is True
        # 2026-03-20 is a Friday — not the 15th, but IS Friday → should fire
        assert _match_cron_expr("0 9 15 * 5", datetime(2026, 3, 20, 9, 0)) is True
        # 2026-03-18 is a Wednesday, not the 15th → should NOT fire
        assert _match_cron_expr("0 9 15 * 5", datetime(2026, 3, 18, 9, 0)) is False

    def test_dom_wild_dow_restricted_and_semantics(self):
        """``0 9 * * 5`` — only DOW restricted, DOM is wild → AND (Fridays only)."""
        # 2026-03-20 is a Friday
        assert _match_cron_expr("0 9 * * 5", datetime(2026, 3, 20, 9, 0)) is True
        # 2026-03-18 is a Wednesday
        assert _match_cron_expr("0 9 * * 5", datetime(2026, 3, 18, 9, 0)) is False

    def test_dow_wild_dom_restricted_and_semantics(self):
        """``0 9 15 * *`` — only DOM restricted, DOW is wild → AND (15th only)."""
        assert _match_cron_expr("0 9 15 * *", datetime(2026, 3, 15, 9, 0)) is True
        assert _match_cron_expr("0 9 15 * *", datetime(2026, 3, 16, 9, 0)) is False

    def test_both_wild_matches_always(self):
        """``0 9 * * *`` — both DOM and DOW are wild → matches any day."""
        assert _match_cron_expr("0 9 * * *", datetime(2026, 3, 15, 9, 0)) is True
        assert _match_cron_expr("0 9 * * *", datetime(2026, 3, 20, 9, 0)) is True


# ── P2-2: Bad Timezone Tests ─────────────────────────────────────────────────

class TestBadTimezone:
    """P2-2 / P2-9: Invalid timezone disables the job with an error."""

    def test_bad_timezone_disables_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="badtz1",
            name="Bad TZ",
            schedule_kind="cron",
            schedule_cron="* * * * *",
            schedule_tz="Not/A/Real/Timezone",
        )
        scheduler.add_job(job)
        result = scheduler._is_due(job)
        assert result is False
        assert job.enabled is False
        assert job.status == "error"
        assert "Invalid timezone" in job.last_error


# ── P2-9: Out-of-Range and Malformed Syntax Tests ────────────────────────────

class TestOutOfRangeAndMalformed:
    """P2-9: Out-of-range values and malformed cron syntax."""

    def test_minute_60_never_matches(self):
        """Minute 60 is out of range for standard cron (0-59)."""
        # "60" as a literal field — should not match any valid minute
        for m in range(60):
            assert _match_cron_field("60", m, 0, 59) is False

    def test_hour_24_never_matches(self):
        """Hour 24 is out of range (0-23)."""
        for h in range(24):
            assert _match_cron_field("24", h, 0, 23) is False

    def test_month_13_never_matches(self):
        """Month 13 is out of range (1-12)."""
        for m in range(1, 13):
            assert _match_cron_field("13", m, 1, 12) is False

    def test_dow_8_never_matches(self):
        """DOW 8 is out of range (0-7)."""
        for d in range(8):
            assert _match_cron_field("8", d, 0, 7) is False

    def test_malformed_comma_list(self):
        """``1,,3`` — empty part between commas is skipped, 1 and 3 still match."""
        assert _match_cron_field("1,,3", 1, 0, 59) is True
        assert _match_cron_field("1,,3", 3, 0, 59) is True
        assert _match_cron_field("1,,3", 2, 0, 59) is False

    def test_step_zero_skipped(self):
        """``*/0`` — step of 0 is invalid, should return False."""
        assert _match_cron_field("*/0", 0, 0, 59) is False
        assert _match_cron_field("*/0", 30, 0, 59) is False

    def test_empty_string_field(self):
        """Empty string field should return False."""
        assert _match_cron_field("", 0, 0, 59) is False

    def test_triple_dash_malformed(self):
        """``1-5-7`` — split('-', 1) gives '1' and '5-7', int('5-7') fails → False."""
        assert _match_cron_field("1-5-7", 3, 0, 59) is False


# ── P2-4: Auto-Disable After MAX_CONSECUTIVE_ERRORS ──────────────────────────

class TestAutoDisableErrors:
    """P2-4 / P2-9: Jobs auto-disable after MAX_CONSECUTIVE_ERRORS."""

    def test_auto_disable_after_max_errors(self, tmp_jobs_path):
        call_count = 0

        async def _fail(job):
            nonlocal call_count
            call_count += 1
            raise RuntimeError("persistent failure")

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_fail)
            job = CronJob(
                id="err_accum",
                name="Error Accumulator",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 100,
            )
            scheduler.add_job(job)

            # Fire MAX_CONSECUTIVE_ERRORS times
            for _ in range(CronScheduler.MAX_CONSECUTIVE_ERRORS):
                j = scheduler.get_job("err_accum")
                j.last_run = time.time() - 100  # ensure it's due
                await scheduler._tick()

            updated = scheduler.get_job("err_accum")
            assert updated.enabled is False
            assert updated.consecutive_errors >= CronScheduler.MAX_CONSECUTIVE_ERRORS

        asyncio.run(_run())

    def test_max_consecutive_errors_is_class_constant(self):
        """MAX_CONSECUTIVE_ERRORS is a class constant on CronScheduler."""
        assert hasattr(CronScheduler, "MAX_CONSECUTIVE_ERRORS")
        assert CronScheduler.MAX_CONSECUTIVE_ERRORS == 5


# ── P2-5: Corrupt Job Isolation in _load() ───────────────────────────────────

class TestCorruptJobIsolation:
    """P2-5 / P2-9: One corrupt job entry doesn't kill loading of others."""

    def test_corrupt_entry_skipped(self, tmp_jobs_path):
        """Bad entries are skipped; good ones load fine."""
        tmp_jobs_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "jobs": [
                {"id": "good1", "name": "Good Job", "schedule_kind": "every", "schedule_every_ms": 1000},
                {"this_is": "totally_broken", "missing_required_fields": True},
                {"id": "good2", "name": "Also Good", "schedule_kind": "cron", "schedule_cron": "* * * * *"},
            ]
        }
        tmp_jobs_path.write_text(json.dumps(data))
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        assert scheduler.get_job("good1") is not None
        assert scheduler.get_job("good2") is not None
        # Only 2 jobs loaded (the corrupt one was skipped)
        assert len(scheduler.list_jobs()) == 2


# ── P2-3: Atomic Save ────────────────────────────────────────────────────────

class TestAtomicSave:
    """P2-3 / P2-9: _save() uses write-to-temp-then-rename."""

    def test_atomic_save_no_tmp_left(self, tmp_jobs_path):
        """After _save(), there should be no .tmp file remaining."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="atom1", name="Atomic", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)  # triggers _save()

        tmp_file = tmp_jobs_path.with_suffix('.tmp')
        assert not tmp_file.exists(), ".tmp file should not remain after atomic save"
        assert tmp_jobs_path.exists(), "jobs.json should exist after save"

        # Verify content is valid
        data = json.loads(tmp_jobs_path.read_text())
        assert len(data["jobs"]) == 1
        assert data["jobs"][0]["id"] == "atom1"


# ── P1-5: Batch _save() in _tick() ───────────────────────────────────────────

class TestBatchSave:
    """P1-5 / P2-9: Multiple jobs firing in same tick should only call _save() once."""

    def test_single_save_for_multiple_jobs(self, tmp_jobs_path):
        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
            for i in range(3):
                job = CronJob(
                    id=f"batch_{i}",
                    name=f"Batch {i}",
                    schedule_kind="every",
                    schedule_every_ms=1,
                    last_run=time.time() - 100,
                )
                scheduler.add_job(job)

            save_count = 0
            original_save = scheduler._save

            def counting_save():
                nonlocal save_count
                save_count += 1
                original_save()

            scheduler._save = counting_save
            # Reset save_count since add_job calls _save
            save_count = 0

            await scheduler._tick()
            # Should be exactly 1 save call for all 3 jobs
            assert save_count == 1, f"Expected 1 _save() call, got {save_count}"

        asyncio.run(_run())


# ── P1-2: DST Re-Fire Guard ──────────────────────────────────────────────────

class TestDSTReFireGuard:
    """P1-2 / P2-8: Use epoch comparison to prevent re-fire, handles DST correctly."""

    def test_epoch_based_refire_guard(self, tmp_jobs_path):
        """Even with DST, a job that ran <60s ago should not re-fire."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        fake_now = 1711500030.0  # 30s after a fixed point
        fake_dt = datetime(2026, 3, 26, 14, 30, 0)  # matches "* * * * *"
        job = CronJob(
            id="dst1",
            name="DST Guard",
            schedule_kind="cron",
            schedule_cron="* * * * *",
            last_run=fake_now - 30,  # 30 seconds ago
        )
        with patch("antaris_agent.core.cron.time.time", return_value=fake_now), \
             patch("antaris_agent.core.cron._datetime") as mock_dt:
            mock_dt.now.return_value = fake_dt
            assert scheduler._is_due(job) is False

    def test_epoch_based_refire_allows_after_60s(self, tmp_jobs_path):
        """A job that ran >60s ago should be allowed to re-fire."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        fake_now = 1711500090.0
        fake_dt = datetime(2026, 3, 26, 14, 31, 0)  # matches "* * * * *"
        job = CronJob(
            id="dst2",
            name="DST Allow",
            schedule_kind="cron",
            schedule_cron="* * * * *",
            last_run=fake_now - 65,  # 65 seconds ago
        )
        with patch("antaris_agent.core.cron.time.time", return_value=fake_now), \
             patch("antaris_agent.core.cron._datetime") as mock_dt:
            mock_dt.now.return_value = fake_dt
            assert scheduler._is_due(job) is True


# ── P1-6: Defensive Copy for on_fire ─────────────────────────────────────────

class TestDefensiveCopy:
    """P1-6: on_fire receives a copy, not the live job object."""

    def test_on_fire_receives_copy(self, tmp_jobs_path):
        received_jobs = []

        async def _capture(job):
            received_jobs.append(job)

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_capture)
            job = CronJob(
                id="copy1",
                name="Copy Test",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 100,
            )
            scheduler.add_job(job)
            await scheduler._tick()

            assert len(received_jobs) == 1
            fired_job = received_jobs[0]
            live_job = scheduler.get_job("copy1")
            # The fired job should NOT be the same object as the live job
            assert fired_job is not live_job
            # But should have same id
            assert fired_job.id == live_job.id

        asyncio.run(_run())


# ── Round 2 Fix Tests ─────────────────────────────────────────────────────────

class TestR2BoundsValidation:
    """R2-GPT: _match_cron_field rejects out-of-range values and endpoints."""

    def test_value_outside_domain_rejected(self):
        """Value 61 for a minute field (0-59) should never match."""
        assert _match_cron_field("*", 61, 0, 59) is False
        assert _match_cron_field("61", 61, 0, 59) is False
        assert _match_cron_field("*/2", 60, 0, 59) is False

    def test_range_endpoint_outside_domain_rejected(self):
        """Range 100-200 with domain 0-59 should never match."""
        assert _match_cron_field("100-200", 150, 0, 59) is False

    def test_exact_value_outside_domain_rejected(self):
        """Exact value 32 in day-of-month (1-31) should be rejected."""
        assert _match_cron_field("32", 32, 1, 31) is False

    def test_valid_values_still_work(self):
        """Bounds checking shouldn't break normal operation."""
        assert _match_cron_field("30", 30, 0, 59) is True
        assert _match_cron_field("1-5", 3, 0, 59) is True
        assert _match_cron_field("*/15", 0, 0, 59) is True


class TestR2AsyncSafeDelete:
    """R2-Sonnet: _tick uses pop() so concurrent job removal doesn't crash."""

    def test_delete_after_run_uses_pop(self, tmp_jobs_path):
        """If a job was already removed during on_fire, _tick shouldn't crash."""
        async def _remove_during_fire(job):
            pass

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_remove_during_fire)
            job = CronJob(
                id="poptest",
                name="Pop Test",
                schedule_kind="every",
                schedule_every_ms=1,
                last_run=time.time() - 10,
                delete_after_run=True,
            )
            scheduler.add_job(job)
            # tick should use pop() not del — no KeyError
            await scheduler._tick()
            assert scheduler.get_job("poptest") is None

        asyncio.run(_run())


class TestR2RunNowSpentAtJob:
    """R2-Opus/Sonnet: run_now returns False for spent at-jobs."""

    def test_run_now_on_spent_at_job_returns_false(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="spent_at",
            name="Spent At",
            schedule_kind="at",
            schedule_at="2020-01-01T00:00:00Z",
            run_count=1,
        )
        scheduler.add_job(job)
        assert scheduler.run_now("spent_at") is False

    def test_run_now_on_fresh_at_job_returns_true(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="fresh_at",
            name="Fresh At",
            schedule_kind="at",
            schedule_at="2099-01-01T00:00:00Z",
            run_count=0,
        )
        scheduler.add_job(job)
        assert scheduler.run_now("fresh_at") is True


class TestR2LoopBackoff:
    """R2-Opus: Scheduler has backoff constants defined."""

    def test_tick_interval_and_max_errors_defined(self):
        assert CronScheduler.TICK_INTERVAL == 10
        assert CronScheduler.MAX_CONSECUTIVE_ERRORS == 5


# ── Round 3 Fix Tests ─────────────────────────────────────────────────────────

class TestR3DowNormalization:
    """R3-GPT: DOW 7 is normalized to 0 before matching on clean 0-6 domain."""

    def test_normalize_dow_exact_7(self):
        assert _normalize_dow_field("7") == "0"

    def test_normalize_dow_in_range(self):
        """5-7 becomes 5-0 (wraparound Fri-Sun)."""
        assert _normalize_dow_field("5-7") == "5-0"

    def test_normalize_dow_in_list(self):
        assert _normalize_dow_field("0,7") == "0,0"
        assert _normalize_dow_field("1,3,7") == "1,3,0"

    def test_normalize_dow_preserves_non_7(self):
        assert _normalize_dow_field("1-5") == "1-5"
        assert _normalize_dow_field("*") == "*"
        assert _normalize_dow_field("*/2") == "*/2"

    def test_normalize_dow_does_not_touch_17(self):
        """17 should NOT be modified — only standalone 7."""
        # 17 isn't a valid DOW but normalization shouldn't mangle it
        assert _normalize_dow_field("17") == "17"

    def test_dow_7_exact_matches_sunday_via_expr(self):
        """Cron expr '0 6 * * 7' matches Sunday via normalization."""
        # 2026-03-29 is a Sunday
        assert _match_cron_expr("0 6 * * 7", datetime(2026, 3, 29, 6, 0)) is True
        assert _match_cron_expr("0 6 * * 7", datetime(2026, 3, 30, 6, 0)) is False

    def test_dow_5_to_7_range_matches_fri_sat_sun(self):
        """5-7 should match Friday(5), Saturday(6), Sunday(0)."""
        # 2026-03-27 = Friday, 2026-03-28 = Saturday, 2026-03-29 = Sunday
        assert _match_cron_expr("0 6 * * 5-7", datetime(2026, 3, 27, 6, 0)) is True  # Fri
        assert _match_cron_expr("0 6 * * 5-7", datetime(2026, 3, 28, 6, 0)) is True  # Sat
        assert _match_cron_expr("0 6 * * 5-7", datetime(2026, 3, 29, 6, 0)) is True  # Sun
        assert _match_cron_expr("0 6 * * 5-7", datetime(2026, 3, 30, 6, 0)) is False  # Mon

    def test_dow_7_to_2_range_matches_sun_mon_tue(self):
        """7-2 should match Sunday(0), Monday(1), Tuesday(2)."""
        # 2026-03-29 = Sun, 2026-03-30 = Mon, 2026-03-31 = Tue, 2026-04-01 = Wed
        assert _match_cron_expr("0 6 * * 7-2", datetime(2026, 3, 29, 6, 0)) is True  # Sun
        assert _match_cron_expr("0 6 * * 7-2", datetime(2026, 3, 30, 6, 0)) is True  # Mon
        assert _match_cron_expr("0 6 * * 7-2", datetime(2026, 3, 31, 6, 0)) is True  # Tue
        assert _match_cron_expr("0 6 * * 7-2", datetime(2026, 4, 1, 6, 0)) is False  # Wed


class TestR3NegativeInterval:
    """N2-Opus: Negative schedule_every_ms is rejected."""

    def test_negative_interval_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="neg1",
            name="Negative Interval",
            schedule_kind="every",
            schedule_every_ms=-5000,
            last_run=time.time() - 100,
        )
        assert scheduler._is_due(job) is False

    def test_zero_interval_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="zero1",
            name="Zero Interval",
            schedule_kind="every",
            schedule_every_ms=0,
        )
        assert scheduler._is_due(job) is False


class TestR3NaiveScheduleAt:
    """N3-Opus: Naive schedule_at treated as UTC instead of silently failing."""

    def test_naive_at_treated_as_utc(self, tmp_jobs_path):
        """A naive datetime (no timezone) in schedule_at should fire as UTC."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="naive_at",
            name="Naive At",
            schedule_kind="at",
            schedule_at="2020-01-01T00:00:00",  # naive, no Z, no offset — past
            run_count=0,
        )
        assert scheduler._is_due(job) is True  # should fire (treated as UTC, in the past)

    def test_naive_future_at_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="naive_future",
            name="Naive Future",
            schedule_kind="at",
            schedule_at="2099-01-01T00:00:00",  # naive but far future
            run_count=0,
        )
        assert scheduler._is_due(job) is False


class TestR3MalformedStepEdgeCases:
    """R3-GPT: Malformed step syntax edge cases."""

    def test_bare_number_with_step_ignores_step(self):
        """5/2 matches only 5 (Vixie cron behavior)."""
        assert _match_cron_field("5/2", 5, 0, 59) is True
        assert _match_cron_field("5/2", 7, 0, 59) is False

    def test_trailing_slash(self):
        """1-5/ is malformed — should return False."""
        assert _match_cron_field("1-5/", 3, 0, 59) is False

    def test_leading_slash(self):
        """/5 is malformed."""
        assert _match_cron_field("/5", 0, 0, 59) is False

    def test_star_slash_non_numeric(self):
        """*/x is malformed."""
        assert _match_cron_field("*/x", 0, 0, 59) is False
