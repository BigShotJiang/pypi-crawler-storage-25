"""
test_retrieval_request_immutability.py

v3.0.4 (P0-1 Eye fix): RetrievalRequest.__setattr__ re-validates bounded
fields (limit, query_mode) on mutation. Closes the post-construction
bypass that three independent Eye reviewers (Judge-GPT, Attacker-Sonnet,
Attacker-Opus) found.

Known attack vectors closed:
  - req.limit = 100_000
  - req.query_mode = None / ""
  - copy.copy(req); c.limit = 100_000
  - dataclasses.replace(req, limit=100_000)

Known bypass still possible (documented, covered by defense-in-depth):
  - object.__setattr__(req, "limit", 100_000)
    -> caught at _execute_retrieval boundary instead
  - subclass override of __setattr__
    -> attacker is already inside the trust boundary
"""

from __future__ import annotations

import copy
import dataclasses
import pytest

from parsica_memory.contracts import MAX_RETRIEVAL_LIMIT, RetrievalRequest


# ---------------------------------------------------------------------------
# __setattr__ guard (P0-1 primary)
# ---------------------------------------------------------------------------

def test_post_construction_limit_bypass_rejected():
    """req.limit = 100_000 must raise (was silently accepted pre-Eye)."""
    req = RetrievalRequest(query="x", limit=10)
    with pytest.raises(ValueError, match="must be <="):
        req.limit = MAX_RETRIEVAL_LIMIT + 1


def test_post_construction_limit_negative_rejected():
    """req.limit = -1 must raise."""
    req = RetrievalRequest(query="x", limit=10)
    with pytest.raises(ValueError, match="must be >= 1"):
        req.limit = 0


def test_post_construction_limit_non_int_rejected():
    """req.limit = 'ten' must raise (type check added to be strict)."""
    req = RetrievalRequest(query="x", limit=10)
    with pytest.raises(ValueError, match="must be an int"):
        req.limit = "ten"


def test_post_construction_limit_bool_rejected():
    """req.limit = True bypass (bool is int subclass) must be rejected explicitly."""
    req = RetrievalRequest(query="x", limit=10)
    with pytest.raises(ValueError, match="must be an int"):
        req.limit = True


def test_post_construction_query_mode_bypass_rejected():
    """req.query_mode = None bypass (would re-enable F-QTE-AUTO bypass) must raise."""
    req = RetrievalRequest(query="x", query_mode="auto")
    with pytest.raises(ValueError, match="must be one of"):
        req.query_mode = None


def test_post_construction_query_mode_empty_rejected():
    """req.query_mode = '' bypass must raise."""
    req = RetrievalRequest(query="x", query_mode="auto")
    with pytest.raises(ValueError, match="must be one of"):
        req.query_mode = ""


def test_post_construction_query_mode_invalid_rejected():
    """req.query_mode = 'turbo' bypass must raise."""
    req = RetrievalRequest(query="x", query_mode="auto")
    with pytest.raises(ValueError, match="must be one of"):
        req.query_mode = "turbo"


def test_valid_post_construction_mutation_allowed():
    """Bounded fields can still be mutated to VALID values — existing prod
    code does this legitimately for persist_trace/side_effect_mode etc."""
    req = RetrievalRequest(query="x", limit=10, query_mode="auto")
    req.limit = 20
    req.query_mode = "precision"
    assert req.limit == 20
    assert req.query_mode == "precision"


def test_unbounded_field_mutation_unaffected():
    """Non-bounded fields like persist_trace still mutate freely (needed by retrieve())."""
    req = RetrievalRequest(query="x")
    req.persist_trace = True
    req.persist_trace = False  # toggle back
    assert req.persist_trace is False


# ---------------------------------------------------------------------------
# copy.copy / dataclasses.replace (converges with Attacker-Sonnet)
# ---------------------------------------------------------------------------

def test_copy_then_mutate_limit_rejected():
    """copy.copy(req); c.limit = 100_000 must raise via inherited __setattr__."""
    req = RetrievalRequest(query="x", limit=10)
    c = copy.copy(req)
    with pytest.raises(ValueError, match="must be <="):
        c.limit = MAX_RETRIEVAL_LIMIT + 1


def test_dataclasses_replace_over_limit_rejected():
    """dataclasses.replace triggers __post_init__ which validates."""
    req = RetrievalRequest(query="x", limit=10)
    with pytest.raises(ValueError, match="must be <="):
        dataclasses.replace(req, limit=MAX_RETRIEVAL_LIMIT + 1)


# ---------------------------------------------------------------------------
# Defense-in-depth check at _execute_retrieval (known object.__setattr__ bypass)
# ---------------------------------------------------------------------------

def test_object_setattr_bypass_caught_at_execution():
    """object.__setattr__ bypasses the guard, but _execute_retrieval re-checks."""
    req = RetrievalRequest(query="x", limit=10)
    # Bypass the guard
    object.__setattr__(req, "limit", MAX_RETRIEVAL_LIMIT + 1)
    assert req.limit == MAX_RETRIEVAL_LIMIT + 1  # bypass succeeded at attribute level

    # But the consumption site MUST reject it.
    from unittest.mock import MagicMock
    from parsica_memory.retrieval import _execute_retrieval
    fake_mem = MagicMock()
    with pytest.raises(ValueError, match="out of bounds at execution"):
        _execute_retrieval(fake_mem, req)


# ---------------------------------------------------------------------------
# copy.deepcopy (R3B: Judge-Opus P2)
# ---------------------------------------------------------------------------

def test_deepcopy_preserves_validation():
    """deepcopy produces a valid copy; mutating the copy to invalid values raises."""
    req = RetrievalRequest(query="x", limit=10, query_mode="auto")
    deep = copy.deepcopy(req)
    # Fields are preserved
    assert deep.limit == req.limit
    assert deep.query == req.query
    assert deep.query_mode == req.query_mode
    # Mutation on the copy is still guarded
    with pytest.raises(ValueError, match="must be <="):
        deep.limit = MAX_RETRIEVAL_LIMIT + 1


def test_deepcopy_does_not_bypass_guard():
    """Even if deepcopy uses __dict__ internally, subsequent mutation via attribute
    assignment on the deep copy must still go through __setattr__."""
    req = RetrievalRequest(query="x", limit=10)
    deep = copy.deepcopy(req)
    # Valid mutation is fine
    deep.limit = 20
    assert deep.limit == 20
    # Invalid mutation is still rejected — __setattr__ is in effect
    with pytest.raises(ValueError, match="must be an int"):
        deep.limit = True
