"""
Tests for benchmarks/substrate_telemetry_harness.py
====================================================

Covers:
  - SubstrateEvent schema fields and serialisation (CSV row + JSONL line)
  - SubstrateHarness: record, finalize, context-manager, family_context,
    timed_event, buffer flush, real file output
  - CSV export: header present, all columns, boolean encoding, extra-as-JSON
  - JSONL export: valid JSON on every line, field completeness
  - SubstrateAdapter: converts a mock AntarisEvent → SubstrateEvent correctly
  - Demo runner: produces non-empty output files

Run with:
  pytest tests/test_substrate_harness.py -v
"""

import csv
import json
import os
import sys
import time
import uuid
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict

import pytest

# Ensure repo root is on sys.path (mirrors other benchmark test files)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from benchmarks.substrate_telemetry_harness import (
    CSV_COLUMNS,
    SubstrateAdapter,
    SubstrateEvent,
    SubstrateHarness,
    run_demo,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_event(**kwargs) -> SubstrateEvent:
    """Build a minimal valid SubstrateEvent."""
    defaults = dict(agent="agent-1", role="reasoner", event_type="query")
    defaults.update(kwargs)
    return SubstrateEvent(**defaults)


def _mock_antaris_event(payload: Dict[str, Any] = None, **attrs) -> SimpleNamespace:
    """Build a minimal mock AntarisEvent for adapter tests."""
    ev = SimpleNamespace(
        event_id=str(uuid.uuid4()),
        session_id="sess-test",
        event_type="pipeline.complete",
        confidence=0.88,
        performance=None,
        trace_id="trace-xyz",
        payload=payload or {},
    )
    for k, v in attrs.items():
        setattr(ev, k, v)
    return ev


# ---------------------------------------------------------------------------
# SubstrateEvent — schema & serialisation
# ---------------------------------------------------------------------------


class TestSubstrateEvent:

    def test_required_fields_only(self):
        ev = SubstrateEvent(agent="a", role="r")
        assert ev.agent == "a"
        assert ev.role == "r"
        assert ev.record_id  # auto-generated
        assert ev.run_id == ""
        assert ev.timestamp == ""

    def test_all_required_schema_fields_present(self):
        ev = _make_event()
        row = ev.as_csv_row()
        for col in CSV_COLUMNS:
            assert col in row, f"Missing column: {col}"

    def test_booleans_encoded_as_int_in_csv(self):
        ev = _make_event(instinct_hit=True, reuse=True)
        row = ev.as_csv_row()
        assert row["instinct_hit"] == 1
        assert row["reuse"] == 1

        ev2 = _make_event(instinct_hit=False, reuse=False)
        row2 = ev2.as_csv_row()
        assert row2["instinct_hit"] == 0
        assert row2["reuse"] == 0

    def test_extra_serialised_as_json_string(self):
        ev = _make_event(extra={"foo": 42, "bar": [1, 2]})
        row = ev.as_csv_row()
        decoded = json.loads(row["extra"])
        assert decoded["foo"] == 42
        assert decoded["bar"] == [1, 2]

    def test_empty_extra_is_empty_string(self):
        ev = _make_event(extra={})
        row = ev.as_csv_row()
        assert row["extra"] == ""

    def test_query_truncated_at_500_chars(self):
        long_q = "x" * 600
        ev = _make_event(query=long_q)
        row = ev.as_csv_row()
        assert len(row["query"]) == 500

    def test_jsonl_line_is_valid_json(self):
        ev = _make_event(latency_ms=42.5, confidence=0.9)
        line = ev.as_jsonl_line()
        parsed = json.loads(line)
        assert parsed["agent"] == "agent-1"
        assert parsed["latency_ms"] == 42.5
        assert parsed["confidence"] == 0.9

    def test_jsonl_line_contains_all_schema_keys(self):
        ev = _make_event()
        parsed = json.loads(ev.as_jsonl_line())
        for col in CSV_COLUMNS:
            assert col in parsed, f"Missing key in JSONL: {col}"

    def test_schema_fields_baseline_coverage(self):
        """All required schema fields from the spec are addressable."""
        required = [
            "timestamp", "agent", "role", "session", "event_type", "query",
            "latency_ms", "context_window_pct", "instinct_hit",
            "ambient_propagation_id", "pack_origin", "outcome",
            "record_id", "family_id", "derived_from", "source_event",
            "provenance", "confidence", "truth_state", "state",
            "retrieval_hit_count", "reuse",
        ]
        ev = _make_event()
        for f in required:
            assert hasattr(ev, f), f"SubstrateEvent missing field: {f}"


# ---------------------------------------------------------------------------
# SubstrateHarness — record / finalize
# ---------------------------------------------------------------------------


class TestSubstrateHarness:

    def test_context_manager_finalizes(self, tmp_path):
        with SubstrateHarness(run_id="test-cm", output_dir=tmp_path) as h:
            h.record(_make_event())
        assert h.jsonl_path.exists()
        assert h.csv_path.exists()

    def test_record_stamps_run_id_and_timestamp(self, tmp_path):
        h = SubstrateHarness(run_id="rid-001", output_dir=tmp_path)
        ev = h.record(_make_event())
        assert ev.run_id == "rid-001"
        assert ev.timestamp  # non-empty ISO timestamp
        h.finalize()

    def test_record_returns_event_with_record_id(self, tmp_path):
        h = SubstrateHarness(run_id="rid-002", output_dir=tmp_path)
        ev = h.record(SubstrateEvent(agent="a", role="r"))
        assert len(ev.record_id) > 0
        h.finalize()

    def test_multiple_records_counted(self, tmp_path):
        h = SubstrateHarness(run_id="cnt-001", output_dir=tmp_path)
        for i in range(10):
            h.record(_make_event(agent=f"agent-{i}"))
        summary = h.finalize()
        assert summary["total_events"] == 10

    def test_finalize_returns_summary(self, tmp_path):
        h = SubstrateHarness(run_id="sum-001", output_dir=tmp_path)
        h.record(_make_event())
        summary = h.finalize()
        assert summary["run_id"] == "sum-001"
        assert summary["total_events"] == 1
        assert "jsonl_path" in summary
        assert "csv_path" in summary

    def test_stats_mid_run(self, tmp_path):
        h = SubstrateHarness(run_id="stats-001", output_dir=tmp_path)
        h.record(_make_event())
        h.record(_make_event())
        st = h.stats()
        assert st["events_recorded"] == 2
        h.finalize()

    # ── JSONL file ────────────────────────────────────────────────────────

    def test_jsonl_file_has_one_line_per_event(self, tmp_path):
        with SubstrateHarness(run_id="jl-001", output_dir=tmp_path) as h:
            for _ in range(5):
                h.record(_make_event())
        lines = h.jsonl_path.read_text().splitlines()
        assert len(lines) == 5

    def test_jsonl_lines_are_valid_json(self, tmp_path):
        with SubstrateHarness(run_id="jl-002", output_dir=tmp_path) as h:
            h.record(_make_event(agent="parser-test", latency_ms=77.7))
        for line in h.jsonl_path.read_text().splitlines():
            parsed = json.loads(line)  # raises if invalid
            assert parsed["agent"] == "parser-test"
            assert parsed["latency_ms"] == 77.7

    def test_jsonl_appended_across_instances(self, tmp_path):
        """Two harness instances with the same run_id accumulate lines."""
        for run in range(2):
            with SubstrateHarness(run_id="append-test", output_dir=tmp_path) as h:
                h.record(_make_event())
        lines = (tmp_path / "substrate_append-test_events.jsonl").read_text().splitlines()
        assert len(lines) == 2

    # ── CSV file ──────────────────────────────────────────────────────────

    def test_csv_header_contains_all_columns(self, tmp_path):
        with SubstrateHarness(run_id="csv-hdr", output_dir=tmp_path) as h:
            h.record(_make_event())
        with open(h.csv_path, newline="") as f:
            reader = csv.DictReader(f)
            assert set(CSV_COLUMNS).issubset(set(reader.fieldnames))

    def test_csv_rows_match_event_count(self, tmp_path):
        n = 7
        with SubstrateHarness(run_id="csv-rows", output_dir=tmp_path) as h:
            for i in range(n):
                h.record(_make_event(agent=f"ag-{i}"))
        with open(h.csv_path, newline="") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == n

    def test_csv_row_values_correct(self, tmp_path):
        with SubstrateHarness(run_id="csv-val", output_dir=tmp_path) as h:
            h.record(_make_event(
                agent="agent-X",
                role="validator",
                latency_ms=123.4,
                instinct_hit=True,
                outcome="success",
                confidence=0.95,
            ))
        with open(h.csv_path, newline="") as f:
            row = list(csv.DictReader(f))[0]
        assert row["agent"] == "agent-X"
        assert row["role"] == "validator"
        assert float(row["latency_ms"]) == 123.4
        assert row["instinct_hit"] == "1"
        assert row["outcome"] == "success"
        assert float(row["confidence"]) == 0.95

    def test_csv_header_written_once_on_append(self, tmp_path):
        """When appending to existing CSV the header must not be duplicated."""
        for _ in range(3):
            with SubstrateHarness(run_id="hdr-once", output_dir=tmp_path) as h:
                h.record(_make_event())
        with open(tmp_path / "substrate_hdr-once_events.csv", newline="") as f:
            lines = f.readlines()
        header_count = sum(1 for ln in lines if "agent" in ln and "role" in ln and "latency_ms" in ln)
        assert header_count == 1

    # ── Buffer flush ──────────────────────────────────────────────────────

    def test_buffer_auto_flushes_when_full(self, tmp_path):
        """A tiny buffer_size forces mid-run CSV flushes."""
        with SubstrateHarness(run_id="buf-flush", output_dir=tmp_path, buffer_size=3) as h:
            for i in range(10):
                h.record(_make_event(agent=f"ag-{i}"))
        with open(h.csv_path, newline="") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 10

    # ── timed_event ───────────────────────────────────────────────────────

    def test_timed_event_measures_latency(self, tmp_path):
        with SubstrateHarness(run_id="timed-001", output_dir=tmp_path) as h:
            with h.timed_event("agent-1", "reasoner", event_type="query",
                               query="test") as ev:
                time.sleep(0.01)  # 10 ms sleep
                ev.outcome = "success"
        assert ev.latency_ms >= 10.0

    def test_timed_event_records_event(self, tmp_path):
        with SubstrateHarness(run_id="timed-002", output_dir=tmp_path) as h:
            with h.timed_event("agent-2", "retriever", outcome="success"):
                pass
        assert h._event_count == 1

    # ── family_context ────────────────────────────────────────────────────

    def test_family_context_stamps_family_id(self, tmp_path):
        with SubstrateHarness(run_id="fam-001", output_dir=tmp_path) as h:
            with h.family_context("fam-xyz") as fam:
                ev = fam.record(_make_event())
                ev2 = fam.record(_make_event())
        assert ev.family_id == "fam-xyz"
        assert ev2.family_id == "fam-xyz"

    def test_family_context_does_not_override_explicit_family_id(self, tmp_path):
        with SubstrateHarness(run_id="fam-002", output_dir=tmp_path) as h:
            with h.family_context("fam-default") as fam:
                ev = fam.record(_make_event(family_id="fam-explicit"))
        assert ev.family_id == "fam-explicit"

    def test_family_context_auto_generates_id_if_empty(self, tmp_path):
        with SubstrateHarness(run_id="fam-003", output_dir=tmp_path) as h:
            with h.family_context() as fam:
                assert fam.family_id  # auto-generated
                ev = fam.record(_make_event())
        assert ev.family_id == fam.family_id


# ---------------------------------------------------------------------------
# SubstrateAdapter
# ---------------------------------------------------------------------------


class TestSubstrateAdapter:

    def test_adapter_records_event(self, tmp_path):
        h = SubstrateHarness(run_id="adp-001", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-A", role="pipeline")
        mock_ev = _mock_antaris_event(payload={"outcome": "success", "query": "hello"})
        recorded = adapter.handle(mock_ev)
        assert recorded is not None
        assert recorded.agent == "agent-A"
        assert recorded.role == "pipeline"
        assert recorded.query == "hello"
        assert recorded.outcome == "success"
        h.finalize()

    def test_adapter_extracts_performance_latency(self, tmp_path):
        h = SubstrateHarness(run_id="adp-002", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-B")
        perf = SimpleNamespace(latency_ms=55.5)
        mock_ev = _mock_antaris_event(performance=perf, payload={})
        recorded = adapter.handle(mock_ev)
        assert recorded.latency_ms == 55.5
        h.finalize()

    def test_adapter_extracts_propagation_fields(self, tmp_path):
        h = SubstrateHarness(run_id="adp-003", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-C")
        payload = {
            "ambient_propagation_id": "prop-abc",
            "pack_origin": "pack:security-v2",
            "instinct_hit": True,
        }
        mock_ev = _mock_antaris_event(payload=payload)
        recorded = adapter.handle(mock_ev)
        assert recorded.ambient_propagation_id == "prop-abc"
        assert recorded.pack_origin == "pack:security-v2"
        assert recorded.instinct_hit is True
        h.finalize()

    def test_adapter_tolerates_bad_event(self, tmp_path):
        """A bad event should not raise — graceful degradation."""
        h = SubstrateHarness(run_id="adp-err", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-Z")
        result = adapter.handle(None)  # None is not a valid event
        assert result is None  # returns None, does not raise
        h.finalize()

    def test_adapter_maps_confidence(self, tmp_path):
        h = SubstrateHarness(run_id="adp-conf", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-D")
        mock_ev = _mock_antaris_event(confidence=0.77, payload={})
        recorded = adapter.handle(mock_ev)
        assert recorded.confidence == 0.77
        h.finalize()

    def test_adapter_captures_extra_payload_fields(self, tmp_path):
        h = SubstrateHarness(run_id="adp-extra", output_dir=tmp_path)
        adapter = SubstrateAdapter(h, agent_id="agent-E")
        payload = {"custom_field": "hello", "score": 99}
        mock_ev = _mock_antaris_event(payload=payload)
        recorded = adapter.handle(mock_ev)
        assert recorded.extra.get("custom_field") == "hello"
        assert recorded.extra.get("score") == 99
        h.finalize()


# ---------------------------------------------------------------------------
# Demo runner
# ---------------------------------------------------------------------------


class TestRunDemo:

    def test_demo_produces_files(self, tmp_path):
        summary = run_demo(output_dir=str(tmp_path), n_rounds=2)
        assert Path(summary["jsonl_path"]).exists()
        assert Path(summary["csv_path"]).exists()

    def test_demo_event_count(self, tmp_path):
        """2 rounds × 6 agents = 12 events."""
        summary = run_demo(output_dir=str(tmp_path), n_rounds=2)
        assert summary["total_events"] == 12

    def test_demo_csv_readable(self, tmp_path):
        summary = run_demo(output_dir=str(tmp_path), n_rounds=1)
        with open(summary["csv_path"], newline="") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 6  # 1 round × 6 agents
        assert all(set(CSV_COLUMNS).issubset(set(r.keys())) for r in rows)

    def test_demo_jsonl_valid(self, tmp_path):
        summary = run_demo(output_dir=str(tmp_path), n_rounds=1)
        lines = Path(summary["jsonl_path"]).read_text().splitlines()
        assert len(lines) == 6
        for line in lines:
            obj = json.loads(line)
            assert obj["agent"]
            assert obj["role"]

    def test_demo_ambient_propagation_id_present(self, tmp_path):
        """Propagation id should appear in some rows (round > 2 or propagator role)."""
        summary = run_demo(output_dir=str(tmp_path), n_rounds=4)
        with open(summary["csv_path"], newline="") as f:
            rows = list(csv.DictReader(f))
        propagated = [r for r in rows if r["ambient_propagation_id"]]
        assert len(propagated) > 0

    def test_demo_all_six_agents_represented(self, tmp_path):
        summary = run_demo(output_dir=str(tmp_path), n_rounds=1)
        with open(summary["csv_path"], newline="") as f:
            rows = list(csv.DictReader(f))
        agents = {r["agent"] for r in rows}
        assert len(agents) == 6
