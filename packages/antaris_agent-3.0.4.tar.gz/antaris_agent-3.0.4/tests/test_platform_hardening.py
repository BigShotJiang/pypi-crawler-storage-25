"""
Tests for platform hardening sprint:
  - Thinking-level propagation through providers and pipeline
  - Auth-profile auto-rotation via dispatcher
  - Browser tool security (URL blocklist, new actions)
  - Extension security policy system
"""

import asyncio
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.llm.base import ThinkingConfig, LLMResponse, Message


# ── ThinkingConfig Tests ──────────────────────────────────────────────────

class TestThinkingConfig:

    def test_from_level_off(self):
        tc = ThinkingConfig.from_level("off")
        assert tc.enabled is False
        assert tc.budget_tokens == 0
        assert tc.level == "off"

    def test_from_level_high(self):
        tc = ThinkingConfig.from_level("high", 16384)
        assert tc.enabled is True
        assert tc.budget_tokens == 16384
        assert tc.level == "high"

    def test_from_level_max(self):
        tc = ThinkingConfig.from_level("max", 32768)
        assert tc.enabled is True
        assert tc.budget_tokens == 32768

    def test_from_level_empty_string(self):
        tc = ThinkingConfig.from_level("")
        assert tc.enabled is False

    def test_from_level_none(self):
        tc = ThinkingConfig.from_level(None)
        assert tc.enabled is False


# ── Anthropic Provider Thinking Tests ─────────────────────────────────────

class TestAnthropicThinking:

    @pytest.mark.asyncio
    async def test_thinking_adds_to_payload(self):
        """Thinking config adds thinking block to API payload."""
        from antaris_agent.llm.anthropic import AnthropicProvider
        
        provider = AnthropicProvider(api_key="sk-ant-test", model="claude-sonnet-4-6")
        
        # Mock the HTTP client
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "content": [{"type": "text", "text": "Hello"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=thinking,
        )
        
        # Verify the payload
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        assert "thinking" in payload
        assert payload["thinking"]["type"] == "enabled"
        assert payload["thinking"]["budget_tokens"] == 16384
        assert payload["temperature"] == 1  # Required for thinking

    @pytest.mark.asyncio
    async def test_no_thinking_when_off(self):
        """No thinking block when thinking is off."""
        from antaris_agent.llm.anthropic import AnthropicProvider
        
        provider = AnthropicProvider(api_key="sk-ant-test", model="claude-sonnet-4-6")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "content": [{"type": "text", "text": "Hello"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=None,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        assert "thinking" not in payload

    @pytest.mark.asyncio
    async def test_thinking_not_applied_to_haiku(self):
        """Thinking is not applied to non-thinking-capable models."""
        from antaris_agent.llm.anthropic import AnthropicProvider
        
        provider = AnthropicProvider(api_key="sk-ant-test", model="claude-haiku-4-5-20251001")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "content": [{"type": "text", "text": "Hello"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=thinking,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        # Haiku is NOT in THINKING_CAPABLE_MODELS so thinking should NOT be added
        assert "thinking" not in payload

    @pytest.mark.asyncio
    async def test_thinking_content_parsed(self):
        """Thinking blocks in response are parsed into thinking_content."""
        from antaris_agent.llm.anthropic import AnthropicProvider
        
        provider = AnthropicProvider(api_key="sk-ant-test", model="claude-sonnet-4-6")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "content": [
                {"type": "thinking", "thinking": "Let me think about this..."},
                {"type": "text", "text": "Here's my answer."},
            ],
            "usage": {"input_tokens": 10, "output_tokens": 25},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        response = await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=ThinkingConfig.from_level("high", 16384),
        )
        
        assert response.content == "Here's my answer."
        assert response.thinking_content == "Let me think about this..."


# ── OpenAI Provider Thinking Tests ────────────────────────────────────────

class TestOpenAIThinking:

    @pytest.mark.asyncio
    async def test_reasoning_effort_for_o3(self):
        """Reasoning effort is set for o-series models."""
        from antaris_agent.llm.openai import OpenAIProvider
        
        provider = OpenAIProvider(api_key="sk-test", model="o3-mini")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Hello", "tool_calls": None}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            model="o3-mini",
            thinking=thinking,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        assert payload.get("reasoning_effort") == "high"

    @pytest.mark.asyncio
    async def test_no_reasoning_effort_for_gpt(self):
        """Reasoning effort is NOT set for non-o-series models."""
        from antaris_agent.llm.openai import OpenAIProvider
        
        provider = OpenAIProvider(api_key="sk-test", model="gpt-5.4")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Hello", "tool_calls": None}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            model="gpt-5.4",
            thinking=thinking,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        assert "reasoning_effort" not in payload


# ── Dispatcher Auto-Rotation Tests ────────────────────────────────────────

class TestDispatcherAutoRotation:

    @pytest.mark.asyncio
    async def test_failover_on_rate_limit(self):
        """Dispatcher fails over to fallback provider on rate limit."""
        from antaris_agent.llm.dispatcher import LLMDispatcher
        from antaris_agent.extensions.auth_monitor import AuthMonitor
        
        dispatcher = LLMDispatcher()
        
        # Create two providers
        primary = MagicMock()
        primary.complete = AsyncMock(side_effect=RuntimeError("rate_limit:30"))
        
        fallback_response = LLMResponse(
            content="Fallback response",
            model="gpt-5.4",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
        )
        fallback = MagicMock()
        fallback.complete = AsyncMock(return_value=fallback_response)
        
        dispatcher.register("anthropic", primary)
        dispatcher.register("openai", fallback)
        
        # Wire auth monitor
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            monitor = AuthMonitor(config_dir=tmp)
            # Pre-register providers in monitor
            monitor.record_call("anthropic", success=True)
            monitor.record_call("openai", success=True)
            dispatcher.set_auth_monitor(monitor)
            
            response = await dispatcher.complete(
                provider="anthropic",
                model="claude-sonnet-4-6",
                messages=[Message(role="user", content="test")],
                system="system",
            )
        
        assert response.content == "Fallback response"
        fallback.complete.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_failover_when_no_monitor(self):
        """Without auth monitor, rate limits raise normally."""
        from antaris_agent.llm.dispatcher import LLMDispatcher
        
        dispatcher = LLMDispatcher()
        
        primary = MagicMock()
        primary.complete = AsyncMock(side_effect=RuntimeError("rate_limit:30"))
        dispatcher.register("anthropic", primary)
        
        with pytest.raises(RuntimeError, match="rate_limit"):
            await dispatcher.complete(
                provider="anthropic",
                model="claude-sonnet-4-6",
                messages=[Message(role="user", content="test")],
                system="system",
            )

    @pytest.mark.asyncio
    async def test_records_success_with_monitor(self):
        """Successful calls are recorded in the auth monitor."""
        from antaris_agent.llm.dispatcher import LLMDispatcher
        from antaris_agent.extensions.auth_monitor import AuthMonitor
        
        dispatcher = LLMDispatcher()
        
        response = LLMResponse(
            content="OK", model="test", input_tokens=5, output_tokens=3, cost_usd=0.0
        )
        primary = MagicMock()
        primary.complete = AsyncMock(return_value=response)
        dispatcher.register("anthropic", primary)
        
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            monitor = AuthMonitor(config_dir=tmp)
            dispatcher.set_auth_monitor(monitor)
            
            await dispatcher.complete(
                provider="anthropic",
                model="claude-sonnet-4-6",
                messages=[Message(role="user", content="test")],
                system="system",
            )
        
        status = monitor._health.providers.get("anthropic")
        assert status is not None
        assert status.total_calls == 1
        assert status.is_valid is True

    @pytest.mark.asyncio
    async def test_dispatcher_forwards_thinking_config(self):
        """Dispatcher forwards thinking config to provider."""
        from antaris_agent.llm.dispatcher import LLMDispatcher
        
        dispatcher = LLMDispatcher()
        
        response = LLMResponse(
            content="OK", model="test", input_tokens=5, output_tokens=3, cost_usd=0.0
        )
        provider = MagicMock()
        provider.complete = AsyncMock(return_value=response)
        dispatcher.register("anthropic", provider)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await dispatcher.complete(
            provider="anthropic",
            model="claude-sonnet-4-6",
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=thinking,
        )
        
        call_args = provider.complete.call_args
        assert call_args.kwargs.get("thinking") is thinking


# ── Browser Tool Security Tests ───────────────────────────────────────────

class TestBrowserSecurity:

    def test_blocks_localhost(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        error = tool._check_url_security("http://localhost:8080/admin")
        assert error is not None
        assert "blocked" in error.lower()

    def test_blocks_metadata_endpoint(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        error = tool._check_url_security("http://169.254.169.254/latest/meta-data/")
        assert error is not None
        assert "blocked" in error.lower()

    def test_blocks_loopback(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        error = tool._check_url_security("http://127.0.0.1:9200/_all")
        assert error is not None

    def test_allows_public_urls(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        error = tool._check_url_security("https://example.com")
        assert error is None

    def test_blocks_non_http_schemes(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        error = tool._check_url_security("file:///etc/passwd")
        assert error is not None
        assert "scheme" in error.lower()

    def test_allowed_domains_whitelist(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool(allowed_domains=["example.com", "api.example.com"])
        
        assert tool._check_url_security("https://example.com/page") is None
        assert tool._check_url_security("https://api.example.com/v1") is None
        
        error = tool._check_url_security("https://evil.com")
        assert error is not None
        assert "allowed domains" in error.lower()

    def test_allowed_domains_blocks_suffix_bypass(self):
        """Parsi fix: evil-example.com must NOT match allowed domain example.com."""
        from antaris_agent.tools.native.browser import BrowserTool

        tool = BrowserTool(allowed_domains=["example.com"])

        # Legitimate subdomains should pass
        assert tool._check_url_security("https://example.com") is None
        assert tool._check_url_security("https://sub.example.com") is None
        # Suffix bypass attempts must be blocked
        assert tool._check_url_security("https://evil-example.com") is not None
        assert tool._check_url_security("https://notexample.com") is not None

    def test_custom_blocklist(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool(blocked_patterns={"evil.com", "bad.org"})
        
        error = tool._check_url_security("https://evil.com/hack")
        assert error is not None
        
        # Should allow what's NOT in the custom blocklist
        assert tool._check_url_security("https://google.com") is None

    @pytest.mark.asyncio
    async def test_navigate_blocked_url(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        # Mock browser initialization
        tool.browser = MagicMock()
        tool.page = MagicMock()
        
        result = await tool.execute({"action": "navigate", "url": "http://localhost:8080"})
        assert result.is_error
        assert "blocked" in result.error.lower()

    def test_input_schema_has_new_actions(self):
        from antaris_agent.tools.native.browser import BrowserTool
        
        tool = BrowserTool()
        schema = tool.input_schema
        actions = schema["properties"]["action"]["enum"]
        
        assert "evaluate" in actions
        assert "wait_for" in actions
        assert "scroll" in actions
        assert "go_back" in actions
        assert "get_url" in actions


# ── Extension Security Policy Tests ───────────────────────────────────────

class TestExtensionSecurity:

    def test_open_mode_allows_everything(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="open")
        
        assert sec.is_allowed("test-ext", ExtensionCapability.SHELL_EXEC)
        assert sec.is_allowed("test-ext", ExtensionCapability.NETWORK_WRITE)
        assert sec.is_allowed("test-ext", ExtensionCapability.DESKTOP)

    def test_sandboxed_denies_shell(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        
        assert sec.is_denied("test-ext", ExtensionCapability.SHELL_EXEC)
        assert not sec.is_allowed("test-ext", ExtensionCapability.SHELL_EXEC)

    def test_sandboxed_requires_approval_for_browser(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        
        assert sec.needs_approval("test-ext", ExtensionCapability.BROWSER)
        assert not sec.is_allowed("test-ext", ExtensionCapability.BROWSER)
        assert not sec.is_denied("test-ext", ExtensionCapability.BROWSER)

    def test_standard_allows_network_read(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="standard")
        
        assert sec.is_allowed("test-ext", ExtensionCapability.NETWORK_READ)
        assert sec.is_allowed("test-ext", ExtensionCapability.MEMORY_READ)

    def test_grant_capability(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        
        # Shell is denied in sandboxed mode
        assert sec.is_denied("test-ext", ExtensionCapability.SHELL_EXEC)
        
        # Admin grants it
        sec.grant_capability("test-ext", ExtensionCapability.SHELL_EXEC)
        
        # Now it's allowed
        assert sec.is_allowed("test-ext", ExtensionCapability.SHELL_EXEC)
        assert not sec.is_denied("test-ext", ExtensionCapability.SHELL_EXEC)

    def test_deny_capability(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="open")
        
        # Everything allowed in open mode
        assert sec.is_allowed("test-ext", ExtensionCapability.BROWSER)
        
        # Admin denies browser
        sec.deny_capability("test-ext", ExtensionCapability.BROWSER)
        
        assert sec.is_denied("test-ext", ExtensionCapability.BROWSER)
        assert not sec.is_allowed("test-ext", ExtensionCapability.BROWSER)

    def test_encrypted_requires_approval_for_all(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="encrypted")
        
        # In encrypted mode, everything requires approval
        for cap in ExtensionCapability:
            assert not sec.is_allowed("test-ext", cap), f"{cap} should not be auto-allowed in encrypted mode"

    def test_status_text(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        sec.get_policy("test-ext")  # Create a policy
        
        text = sec.status_text()
        assert "sandboxed" in text
        assert "test-ext" in text

    def test_per_extension_isolation(self):
        from antaris_agent.extensions.security import (
            ExtensionSecurityManager, ExtensionCapability
        )
        
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        
        # Grant shell to ext-a
        sec.grant_capability("ext-a", ExtensionCapability.SHELL_EXEC)
        
        # ext-b should still have shell denied
        assert sec.is_allowed("ext-a", ExtensionCapability.SHELL_EXEC)
        assert sec.is_denied("ext-b", ExtensionCapability.SHELL_EXEC)


# ── Tool Loop Thinking Propagation Test ───────────────────────────────────

class TestToolLoopThinking:

    @pytest.mark.asyncio
    async def test_thinking_passed_to_llm_in_tool_loop(self):
        """run_tool_loop passes thinking config to the LLM."""
        from antaris_agent.tools.pipeline_integration import run_tool_loop
        
        response = LLMResponse(
            content="Done.", model="test", input_tokens=5, output_tokens=3, cost_usd=0.0
        )
        llm = MagicMock()
        llm.complete = AsyncMock(return_value=response)
        
        registry = MagicMock()
        thinking = ThinkingConfig.from_level("medium", 4096)
        
        await run_tool_loop(
            llm=llm,
            messages=[Message(role="user", content="test")],
            tools=[{"name": "test_tool", "description": "test", "input_schema": {}}],
            tool_registry=registry,
            system="system",
            thinking=thinking,
        )
        
        call_args = llm.complete.call_args
        assert call_args.kwargs.get("thinking") is thinking


# ── Google Provider Thinking Tests ────────────────────────────────────────

class TestGoogleThinking:

    @pytest.mark.asyncio
    async def test_thinking_budget_for_gemini_25(self):
        """Thinking budget is set for Gemini 2.5+ models."""
        from antaris_agent.llm.google import GoogleProvider
        
        provider = GoogleProvider(api_key="test-key", model="gemini-2.5-flash")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "Hello"}]}}],
            "usageMetadata": {"promptTokenCount": 10, "candidatesTokenCount": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            thinking=thinking,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        gen_config = payload.get("generationConfig", {})
        assert "thinkingConfig" in gen_config
        assert gen_config["thinkingConfig"]["thinkingBudget"] == 16384

    @pytest.mark.asyncio
    async def test_no_thinking_for_old_gemini(self):
        """No thinking config for Gemini 1.x models."""
        from antaris_agent.llm.google import GoogleProvider
        
        provider = GoogleProvider(api_key="test-key", model="gemini-1.5-flash")
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "Hello"}]}}],
            "usageMetadata": {"promptTokenCount": 10, "candidatesTokenCount": 5},
        }
        
        provider._client = MagicMock()
        provider._client.post = AsyncMock(return_value=mock_response)
        
        thinking = ThinkingConfig.from_level("high", 16384)
        
        await provider.complete(
            messages=[Message(role="user", content="test")],
            system="system",
            model="gemini-1.5-flash",
            thinking=thinking,
        )
        
        call_args = provider._client.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        
        gen_config = payload.get("generationConfig", {})
        assert "thinkingConfig" not in gen_config


# ── LLMResponse Tests ────────────────────────────────────────────────────

class TestLLMResponse:

    def test_thinking_content_field(self):
        response = LLMResponse(
            content="Hello",
            model="test",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
            thinking_content="I thought about it...",
        )
        assert response.thinking_content == "I thought about it..."

    def test_thinking_content_default_none(self):
        response = LLMResponse(
            content="Hello",
            model="test",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
        )
        assert response.thinking_content is None
