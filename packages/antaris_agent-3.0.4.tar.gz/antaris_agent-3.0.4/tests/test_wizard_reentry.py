import json
from unittest.mock import patch, MagicMock

from antaris_agent.core.config import Config
from antaris_agent.setup.server import SetupServer, _WizardHandler, WIZARD_HTML
from antaris_agent.setup.wizard import SetupWizard


def test_setup_wizard_accepts_specific_wizard():
    wizard = SetupWizard()
    with patch("antaris_agent.setup.wizard.SetupServer") as MockServer:
        server = MagicMock()
        server.setup_complete = True
        server.config = Config()
        MockServer.return_value = server
        wizard.run(open_browser=False, wizard="integrations")
        MockServer.assert_called_once_with(initial_wizard="integrations")


def test_setup_server_stores_initial_wizard():
    server = SetupServer(initial_wizard="power")
    assert server.initial_wizard == "power"


def test_status_includes_reentry_sections():
    cfg = Config()
    cfg.api_key = "sk-test"
    cfg.bot_name = "TestBot"
    cfg.provider_name = "anthropic"
    cfg.security_mode = "sandboxed"
    cfg._tools_config = {
        "google_workspace": {"enabled": True, "account": "moro@example.com"},
        "video": {"enabled": True},
        "webhooks": {"enabled": True},
        "auth_monitor": {"enabled": True},
        "skills": {"enabled": False},
        "model_control": {"enabled": True},
        "browser": {"enabled": True},
        "desktop_control": {"enabled": False},
        "terminal_control": {"enabled": True},
    }
    cfg.extensions_enabled = True
    cfg.webhooks_enabled = True

    handler = MagicMock()
    payload = {}
    handler._send_json = lambda data, status=200: payload.update(data)
    with patch("antaris_agent.setup.server.Config.load", return_value=cfg):
        _WizardHandler._handle_status(handler)

    assert payload["configured"] is True
    assert payload["google_workspace"]["enabled"] is True
    assert payload["automation"]["media_enabled"] is True
    assert payload["power"]["browser_enabled"] is True


def test_handle_setup_saves_google_workspace_and_power_flags():
    payload = {
        "bot_name": "TestBot",
        "provider": "anthropic",
        "api_key": "sk-test-key",
        "channel": "terminal",
        "security_mode": "sandboxed",
        "google_workspace_enabled": True,
        "google_workspace_account": "moro@example.com",
        "media_enabled": True,
        "webhooks_enabled": True,
        "auth_monitor_enabled": True,
        "extensions_enabled": False,
        "skills_enabled": False,
        "model_switching_enabled": True,
        "browser_enabled": True,
        "desktop_control_enabled": True,
        "terminal_control_enabled": False,
    }

    sent = {}
    handler = MagicMock()
    handler.server_ref = MagicMock()
    handler._send_json = lambda data, status=200: sent.update(data)
    handler._read_json_body = lambda: payload
    handler._status_from_config = lambda cfg: {"configured": True}

    cfg = Config()
    with patch("antaris_agent.setup.server.Config.load", return_value=cfg):
        with patch.object(Config, "save", return_value=None):
            with patch("antaris_agent.setup.server._test_channel_connection", return_value={"success": True, "channel": "terminal"}):
                _WizardHandler._handle_setup(handler)

    assert sent["ok"] is True
    assert cfg.extensions_enabled is False
    assert cfg._tools_config["google_workspace"]["enabled"] is True
    assert cfg._tools_config["video"]["enabled"] is True
    assert cfg._tools_config["browser"]["enabled"] is True
    assert cfg._tools_config["terminal_control"]["enabled"] is False


def test_wizard_html_mentions_all_wizard_categories():
    assert "General setup" in WIZARD_HTML
    assert "Integrations wizard" in WIZARD_HTML
    assert "Automation / platform wizard" in WIZARD_HTML
    assert "Power-user wizard" in WIZARD_HTML
