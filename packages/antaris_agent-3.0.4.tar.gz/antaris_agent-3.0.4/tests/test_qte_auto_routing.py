"""
test_qte_auto_routing.py

v3.0.4 (F-QTE-AUTO): The default `query_mode="auto"` path must route through
QTE, not bypass it. Pre-v3.0.4 `retrieval.py:238` had the condition
`if query_mode and query_mode != "auto"` which silently skipped `run_qte()`
on every production request that used the default mode.

Post-v3.0.4: any non-empty `query_mode` (including "auto") routes through
`run_qte()`, which calls `choose_mode()` — which correctly handles "auto"
via heuristic routing.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from parsica_memory.contracts import RetrievalRequest


def test_auto_mode_routes_through_run_qte():
    """Default query_mode='auto' must invoke run_qte, not bypass it."""
    from parsica_memory import retrieval as retrieval_mod

    request = RetrievalRequest(query="who is antaris", query_mode="auto")

    # Stub mem that never has search called directly (would mean bypass).
    class _StubMem:
        workspace = "/tmp"

    mem = _StubMem()

    with patch("parsica_memory.query_time_enrichment.run_qte", return_value=[]) as mocked_qte:
        retrieval_mod.retrieve(mem, request)
    assert mocked_qte.called, (
        "query_mode='auto' should route through run_qte (F-QTE-AUTO). "
        "Pre-v3.0.4 this was silently bypassed."
    )


def test_explicit_mode_still_routes_through_run_qte():
    """Regression: explicit query_mode='precision' still goes through run_qte."""
    from parsica_memory import retrieval as retrieval_mod

    request = RetrievalRequest(query="who is antaris", query_mode="precision")

    class _StubMem:
        workspace = "/tmp"

    with patch("parsica_memory.query_time_enrichment.run_qte", return_value=[]) as mocked_qte:
        retrieval_mod.retrieve(_StubMem(), request)
    assert mocked_qte.called


def test_choose_mode_handles_auto_via_heuristic():
    """choose_mode with query_mode='auto' must fall through to heuristic routing."""
    from parsica_memory.query_time_enrichment import (
        choose_mode, fingerprint_query, RetrievalMode,
    )

    # A short factual query should map to PRECISION via heuristic path.
    request = RetrievalRequest(query="what is parsica", query_mode="auto")
    fp = fingerprint_query(request)
    mode = choose_mode(request, fp)
    assert isinstance(mode, RetrievalMode), "choose_mode must return a RetrievalMode even for auto"
    assert mode != RetrievalMode.SEMANTIC, (
        "auto mode must be resolved by heuristic, not defaulted"
    )


def test_auto_routes_long_queries_to_deep():
    """A 12+ token query under query_mode='auto' should resolve to DEEP."""
    from parsica_memory.query_time_enrichment import (
        choose_mode, fingerprint_query, RetrievalMode,
    )

    long_query = (
        "tell me everything you know about antaris analytics and the parsica "
        "memory system including the roadmap and the open issues"
    )
    request = RetrievalRequest(query=long_query, query_mode="auto")
    fp = fingerprint_query(request)
    mode = choose_mode(request, fp)
    assert mode == RetrievalMode.DEEP, (
        f"12+ token auto query must map to DEEP, got {mode}"
    )


def test_fallback_path_emits_metric_and_trace_path_for_retryable_qte_error():
    """Retryable run_qte failures must be observable via metric + qte_path."""
    from parsica_memory import retrieval as retrieval_mod
    from parsica_memory.contracts import RetrievalTrace

    class _StubMem:
        workspace = "/tmp"

    request = RetrievalRequest(query="who is antaris", query_mode="auto")
    observed = {}

    def _mock_direct(mem, req, persist_trace=False, budget_ms=None):
        trace = RetrievalTrace(request_id=req.request_id)
        observed["trace"] = trace
        return [], trace

    with patch("parsica_memory.query_time_enrichment.run_qte", side_effect=TimeoutError("temporary qte outage")):
        with patch.object(retrieval_mod, "_execute_retrieval", side_effect=_mock_direct):
            with patch.object(retrieval_mod._QTE_METRICS_LOGGER, "debug") as mocked_metric:
                items = retrieval_mod.retrieve(_StubMem(), request)

    assert items == []
    assert observed["trace"].qte_features.get("qte_path") == "fallback_exception"
    assert getattr(observed["trace"], "qte_path", None) == "fallback_exception"
    assert mocked_metric.called
    assert "qte.fallback path=fallback_exception" in mocked_metric.call_args.args[0]


def test_non_retryable_qte_exception_does_not_fallback():
    """Contract violations like ValueError must surface, not silently downgrade."""
    from parsica_memory import retrieval as retrieval_mod

    class _StubMem:
        workspace = "/tmp"

    request = RetrievalRequest(query="who is antaris", query_mode="auto")

    with patch("parsica_memory.query_time_enrichment.run_qte", side_effect=ValueError("bad contract")):
        with pytest.raises(ValueError, match="bad contract"):
            retrieval_mod.retrieve(_StubMem(), request)
