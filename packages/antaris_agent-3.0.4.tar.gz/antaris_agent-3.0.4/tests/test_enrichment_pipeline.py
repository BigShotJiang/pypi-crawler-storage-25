from __future__ import annotations

import pytest
from parsica_memory import MemorySystem
from parsica_memory.jobs import TaskJournal


def _make_mem(tmp_path):
    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="test-agent")
    mem.load()
    mem._task_journal = TaskJournal(tmp_path)
    mem._background_enabled = True
    return mem


def test_no_enricher_configured_deterministic_only_success(tmp_path):
    """No LLM configured → task completes successfully, mode=deterministic_only, no dead-letter"""
    mem = _make_mem(tmp_path)

    parent = mem.ingest_turn(
        "I prefer pytest for tests. It turns out fixtures make setup easier.",
        session_id="s1",
    )
    assert parent is not None

    stats_before = mem.get_background_stats()
    assert stats_before["queue_depth"] >= 1

    run = mem.run_background_tasks(max_tasks=5, worker_id="worker-test")
    assert run["completed"] == 1
    assert run["failed"] == 0

    stats_after = mem.get_background_stats()
    assert stats_after["dead_letter_count"] == 0

    done_task = next(
        task for task in mem._task_journal._load_snapshot().values() if task.kind == "hydrate_record"
    )
    assert done_task.state == "done"
    assert done_task.result["mode"] == "deterministic_only"

    parent_after = mem.get_record_by_id(parent.record_id)
    assert parent_after is not None
    assert parent_after.last_hydration_mode == "deterministic_only"
    assert parent_after.last_enricher_version.startswith("det=v1;class=v2;")



def test_hydrate_record_idempotent(tmp_path):
    """Running enrichment twice on same record+version doesn't duplicate children.

    v2.8.1: ingest_turn() runs deterministic decompose inline (sync), so
    children may already exist. Idempotency guarantee: no new duplicates on second call.
    """
    mem = _make_mem(tmp_path)

    parent = mem.ingest_turn(
        "I prefer pytest for tests. It turns out fixtures make setup easier.",
        session_id="s1",
    )
    assert parent is not None

    count_before = len([m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id])

    first = mem.run_enrichment_for_record(parent.record_id)
    after_first = len([m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id])
    assert after_first >= count_before

    second = mem.run_enrichment_for_record(parent.record_id, target_version=first.enricher_version)
    assert second.children_created == 0, "Second run must not create new children"

    children = [m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id]
    child_keys = [(m.record_kind, m.enricher_version) for m in children]
    assert len(child_keys) == len(set(child_keys)), "No duplicate (kind, version) pairs"



def test_hydrate_record_uses_record_id_not_stale_payload(tmp_path):
    """Worker fetches record fresh by record_id — doesn't rely on payload content"""
    mem = _make_mem(tmp_path)

    parent = mem.ingest_turn(
        "Let's discuss something generic with no durable pattern yet.",
        session_id="s1",
    )
    assert parent is not None

    queued = next(
        task for task in mem._task_journal._load_snapshot().values() if task.kind == "hydrate_record"
    )
    queued.payload["content"] = "I prefer stale payload content"

    parent.content = "I prefer fresh record content from the store."

    run = mem.run_background_tasks(max_tasks=5, worker_id="worker-test")
    assert run["completed"] == 1

    children = [m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id]
    assert any(child.record_kind == "preference" for child in children)
    assert all("stale payload" not in child.content.lower() for child in children)
    assert any("fresh record content" in child.content.lower() for child in children)


def test_memory_system_initializes_task_journal_by_default(tmp_path):
    """MemorySystem() must auto-initialize _task_journal on startup."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="init-test")
    assert mem._task_journal is not None, "_task_journal must be set after init"
    stats = mem.get_background_stats()
    assert "queue_depth" in stats


def test_wal_hydration_survives_reload_with_parent_links_and_version(tmp_path):
    """After WAL-mode hydration, parent links and version metadata survive reload."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="wal-reload-test")
    # Ensure WAL mode (not segments)
    assert not mem._using_segments or True  # WAL or segments — both must survive

    parent = mem.ingest_turn("I prefer dark mode for all dashboards.", session_id="s1")
    assert parent is not None

    result = mem.run_enrichment_for_record(parent.record_id)
    children_before = [m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id]

    # Save and reload
    mem.save()
    mem2 = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="wal-reload-test")

    # Parent should still have hydration metadata
    reloaded_parent = mem2.get_record_by_id(parent.record_id)
    assert reloaded_parent is not None
    assert reloaded_parent.last_enricher_version != "" or result.mode == "deterministic_only"

    # Children should still have parent_id set
    reloaded_children = [m for m in mem2.memories if getattr(m, "parent_id", "") == parent.record_id]
    assert len(reloaded_children) >= len(children_before), "Children must survive reload"
    for child in reloaded_children:
        assert child.parent_id == parent.record_id, "parent_id must survive reload"


def test_stale_hydrate_task_marked_obsolete_and_requeued(tmp_path):
    """Stale-version hydrate tasks are marked obsolete and a current-version task is enqueued."""
    from parsica_memory.jobs import BackgroundTask, TaskJournal, now_iso
    import uuid
    from pathlib import Path

    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, use_indexing=False, agent_name="stale-test")
    parent = mem.ingest_turn("lesson learned: always test with real data.", session_id="s1")
    assert parent is not None

    # Drain the auto-queued current-version task first
    mem._task_journal.try_acquire_leader("test-worker")
    mem.run_background_tasks(max_tasks=5, worker_id="test-worker")

    # Manually queue a stale-version task
    stale_task = BackgroundTask(
        task_id=str(uuid.uuid4()),
        kind="hydrate_record",
        dedupe_key=f"hydrate:{parent.record_id}:oldv",
        payload={"record_id": parent.record_id, "target_enricher_version": "oldv"},
        created_at=now_iso(),
        updated_at=now_iso(),
    )
    mem._task_journal.append_new(stale_task)

    result = mem.run_background_tasks(max_tasks=5, worker_id="test-worker")

    stats = mem.get_background_stats()
    assert stats.get("obsolete_count", 0) >= 1, "Stale task must be marked obsolete"


def test_ingest_turn_persists_only_parent_before_worker(tmp_path):
    """v2.8.2: ingest_turn() must persist only the parent turn before background worker runs.
    No typed children inline — hydrate_record is the sole owner."""
    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="sole-owner-test")
    parent = mem.ingest_turn("I prefer dark mode.", session_id="s1")
    assert parent is not None

    rows = [(m.record_kind, getattr(m, "parent_id", ""), getattr(m, "enricher_version", ""))
            for m in mem.memories]
    # Only the parent turn should exist before background worker runs
    assert rows == [("turn", "", "")], f"Expected only turn, got: {rows}"


def test_background_hydration_creates_parent_linked_versioned_children(tmp_path):
    """v2.8.2: After run_background_tasks(), children have parent_id and enricher_version set."""
    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="linked-children-test")
    parent = mem.ingest_turn("I prefer dark mode for all dashboards.", session_id="s1")
    assert parent is not None

    if mem._task_journal is not None:
        mem._task_journal.try_acquire_leader("test-worker-v")
    mem.run_background_tasks(max_tasks=5, worker_id="test-worker-v")

    children = [m for m in mem.memories if getattr(m, "parent_id", "") == parent.record_id]
    assert len(children) >= 1, "At least one versioned child must exist after hydration"
    for child in children:
        assert child.parent_id == parent.record_id, "parent_id must match parent record_id"
        assert getattr(child, "enricher_version", "") != "", "enricher_version must be set on children"


def test_run_background_tasks_reuses_existing_store_not_alias(tmp_path):
    """v2.8.2: BotMemory.run_background_tasks() must not create alias stores by dirname."""
    from antaris_agent.core.memory import BotMemory
    import asyncio
    mem = BotMemory(store_path=str(tmp_path), agent_name="Moro")
    asyncio.run(mem.ingest("u1", "I prefer dark mode", "Okay, noted", session_id="s1"))
    before = set(mem._stores.keys())
    mem.run_background_tasks(max_tasks_per_store=5, worker_id="wid")
    after = set(mem._stores.keys())
    assert after == before, f"Store keys must not change: before={before}, after={after}"


@pytest.mark.asyncio
async def test_run_background_tasks_processes_persisted_queue_after_restart(tmp_path):
    """v2.8.3: persisted queue must drain after restart without pre-loading the store."""
    from antaris_agent.core.memory import BotMemory

    def enricher(text: str):
        return {"summary": "SUM", "search_queries": ["q1"]}

    # First instance — ingest creates a queued task
    mem1 = BotMemory(store_path=str(tmp_path), agent_name="Moro", enricher=enricher)
    await mem1.ingest(
        "u1",
        "I prefer dark mode for dashboards",
        "I will remember that preference for future work.",
        session_id="s1",
    )
    # Confirm task is queued
    store1 = mem1._get_store("u1")
    stats_before = store1.get_background_stats() if hasattr(store1, "get_background_stats") else {}
    # Don't run background tasks — simulate restart

    # Second instance — fresh BotMemory, _stores starts empty
    mem2 = BotMemory(store_path=str(tmp_path), agent_name="Moro", enricher=enricher)
    result = mem2.run_background_tasks(max_tasks_per_store=5, worker_id="wid2")

    # Must have processed at least 1 task from the persisted queue
    assert result["processed"] >= 1, f"Expected >=1 processed after restart, got: {result}"

    # Load the store and check parent was hydrated
    store2 = mem2._get_store("u1")
    turn = next((m for m in store2.memories if getattr(m, "record_kind", "") == "turn"), None)
    assert turn is not None
    assert getattr(turn, "last_enricher_version", "") != "", "Parent must be hydrated after background task"


def test_gemini_embedder_dimensions(tmp_path):
    """gemini-embedding-001 must return exactly 3072 unit-normalized floats."""
    from parsica_memory.gemini_embedder import make_gemini_embedder
    embed = make_gemini_embedder()
    if embed is None:
        import pytest
        pytest.skip("No GEMINI_EMBEDDING_API_KEY in Keychain — skipping live embedding test")
    vec = embed("cognitive substrate memory test")
    assert len(vec) == 3072, f"Expected 3072 dims, got {len(vec)}"
    norm = sum(x**2 for x in vec) ** 0.5
    assert abs(norm - 1.0) < 0.01, f"Expected unit-normalized vector, got norm={norm:.4f}"


def test_embedding_stored_on_entry_after_hydration(tmp_path):
    """After run_background_tasks(), parent entry must have embedding set when fn is wired."""
    from parsica_memory.gemini_embedder import make_gemini_embedder
    embed = make_gemini_embedder()
    if embed is None:
        import pytest
        pytest.skip("No GEMINI_EMBEDDING_API_KEY — skipping embedding storage test")

    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="embed-test")
    mem.set_embedding_fn(embed)
    parent = mem.ingest_turn("I prefer dark mode for all interfaces.", session_id="s1")
    assert parent is not None

    if mem._task_journal is not None:
        mem._task_journal.try_acquire_leader("embed-test-worker")
    mem.run_background_tasks(max_tasks=5, worker_id="embed-test-worker")

    reloaded = mem.get_record_by_id(parent.record_id)
    assert reloaded is not None
    assert len(getattr(reloaded, "embedding", [])) == 3072, \
        f"Expected 3072-dim embedding after hydration, got {len(getattr(reloaded, 'embedding', []))}"


def test_embedding_graceful_fallback_no_key(tmp_path):
    """When no embedding fn is set, hydration completes without error and embedding stays empty."""
    mem = MemorySystem(str(tmp_path), use_sharding=False, use_indexing=False, agent_name="no-embed-test")
    # Deliberately NO embedding fn set
    parent = mem.ingest_turn("lesson learned: always run tests before pushing.", session_id="s1")
    assert parent is not None

    if mem._task_journal is not None:
        mem._task_journal.try_acquire_leader("no-embed-worker")
    result = mem.run_background_tasks(max_tasks=5, worker_id="no-embed-worker")

    reloaded = mem.get_record_by_id(parent.record_id)
    assert reloaded is not None
    assert getattr(reloaded, "embedding", []) == [], "embedding must be empty when no fn is set"
