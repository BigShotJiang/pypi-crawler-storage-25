"""Tests for the Pipeline and Bot classes."""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.core.pipeline import Pipeline, PipelineResult, RELAY_FRAME_GUARD
from antaris_agent.channels.base import InboundMessage, OutboundMessage
from antaris_agent.llm.base import Message, LLMResponse
from antaris_agent.core.media import build_media_context, build_provider_text_fallback


def make_inbound(text="Hello bot", user_id="user-123", channel_id="ch-1", platform="terminal", images=None, documents=None):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id=channel_id,
        platform=platform,
        text=text,
        timestamp_ms=0,
        images=images or [],
        documents=documents or [],
    )


def make_pipeline():
    """Build a Pipeline with mocked dependencies."""
    config = MagicMock()
    config.model = "claude-sonnet-4-20250514"
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=["User likes cats"])
    memory.ingest = AsyncMock()
    memory.get_continuity_brief = AsyncMock(return_value="")

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "Response text"))

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="You are Antaris.")
    persona.config_dir = ""  # empty → no UserTracker created

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=LLMResponse(
        content="Response text",
        model="claude-sonnet-4-20250514",
        input_tokens=100,
        output_tokens=50,
        cost_usd=0.001,
    ))

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    return Pipeline(config, memory, guard, persona, llm), adapter


# ── Pipeline tests ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_success():
    pipeline, adapter = make_pipeline()
    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True
    assert result.response_text == "Response text"
    assert result.blocked is False
    assert result.tokens_used == 150
    assert result.cost_usd == pytest.approx(0.001)


@pytest.mark.asyncio
async def test_pipeline_calls_all_stages():
    pipeline, adapter = make_pipeline()
    inbound = make_inbound(text="I like dogs")
    await pipeline.process(inbound, adapter)

    pipeline.guard.check_input.assert_awaited_once()
    # memory.recall is called twice: once for user, once for startup recall
    assert pipeline.memory.recall.call_count == 2
    pipeline.persona.build_system_prompt.assert_called_once()
    pipeline.llm.complete.assert_awaited_once()
    pipeline.guard.check_output.assert_awaited_once()
    pipeline.memory.ingest.assert_awaited_once()
    adapter.format_for_surface.assert_called_once()


@pytest.mark.asyncio
async def test_pipeline_blocked_by_guard():
    pipeline, adapter = make_pipeline()
    pipeline.guard.check_input = AsyncMock(return_value=(False, "policy violation"))

    result = await pipeline.process(make_inbound(text="bad input"), adapter)

    assert result.blocked is True
    assert result.block_reason == "policy violation"
    assert "can't respond" in result.response_text.lower()
    # LLM should NOT have been called
    pipeline.llm.complete.assert_not_awaited()


@pytest.mark.asyncio
async def test_pipeline_memory_recall_failure_is_graceful():
    """Memory failure should not crash the pipeline."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(side_effect=Exception("disk error"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True  # still responds
    assert result.response_text == "Response text"


@pytest.mark.asyncio
async def test_pipeline_memory_ingest_failure_is_graceful():
    """Ingest failure should not crash the pipeline."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.ingest = AsyncMock(side_effect=Exception("write error"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True


@pytest.mark.asyncio
async def test_pipeline_llm_failure_returns_error_result():
    pipeline, adapter = make_pipeline()
    pipeline.llm.complete = AsyncMock(side_effect=RuntimeError("API down"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is False
    assert result.error == "API down"
    assert "trouble" in result.response_text.lower() or "something went wrong" in result.response_text.lower()


@pytest.mark.asyncio
async def test_pipeline_injects_recalled_memories_into_prompt():
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(return_value=["user likes cats", "user is from NYC"])

    await pipeline.process(make_inbound(), adapter)

    call_args = pipeline.persona.build_system_prompt.call_args
    memories = call_args[0][0]  # positional arg
    # Memories are framed with [RECALLED MEMORY] prefix — check content is present
    assert any("user likes cats" in m for m in memories)
    assert any("user is from NYC" in m for m in memories)


@pytest.mark.asyncio
async def test_pipeline_passes_previous_history_to_llm():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0  # disable rate limiting for this test
    inbound1 = make_inbound(text="My name is Alice")
    inbound2 = make_inbound(text="What is my name?")

    await pipeline.process(inbound1, adapter)
    await pipeline.process(inbound2, adapter)

    # Second call should include history
    second_call_messages = pipeline.llm.complete.call_args_list[1][1]["messages"]
    texts = [m.content for m in second_call_messages]
    assert "My name is Alice" in texts


@pytest.mark.asyncio
async def test_pipeline_formats_for_surface():
    pipeline, adapter = make_pipeline()
    adapter.format_for_surface = MagicMock(return_value="formatted!")

    result = await pipeline.process(make_inbound(), adapter)
    assert result.response_text == "formatted!"


# ── History management tests ────────────────────────────────────────────────

def test_history_starts_empty():
    pipeline, _ = make_pipeline()
    assert pipeline.history_length("user-x", "ch-1") == 0


@pytest.mark.asyncio
async def test_history_grows_per_turn():
    pipeline, adapter = make_pipeline()
    await pipeline.process(make_inbound(user_id="u1"), adapter)
    assert pipeline.history_length("u1", "ch-1") == 2  # user + assistant


@pytest.mark.asyncio
async def test_history_grows_without_cap():
    """History should grow beyond the old 20-message cap (no artificial trim)."""
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0  # disable cooldown
    for _ in range(30):
        await pipeline.process(make_inbound(user_id="u1"), adapter)
    # Must exceed the old MAX_HISTORY=20 cap — proves no trimming
    assert pipeline.history_length("u1", "ch-1") > 25


@pytest.mark.asyncio
async def test_history_isolated_per_user():
    pipeline, adapter = make_pipeline()
    await pipeline.process(make_inbound(user_id="alice"), adapter)
    await pipeline.process(make_inbound(user_id="bob"), adapter)
    assert pipeline.history_length("alice", "ch-1") == 2
    assert pipeline.history_length("bob", "ch-1") == 2


def test_clear_history():
    pipeline, _ = make_pipeline()
    # v6.1: history is keyed by session_key (user_id:channel_id), not raw user_id
    pipeline._history["u1:ch-1"] = [Message(role="user", content="hi")]
    pipeline.clear_history("u1", "ch-1")
    assert pipeline.history_length("u1", "ch-1") == 0


def test_clear_history_nonexistent_user():
    pipeline, _ = make_pipeline()
    pipeline.clear_history("nobody")  # should not raise


# ── Rate limiting tests ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rate_limiting_blocks_rapid_messages():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 60  # very long cooldown for testing

    # First message goes through
    result1 = await pipeline.process(make_inbound(user_id="rapid-user"), adapter)
    assert result1.response_text != "" or result1.blocked

    # Second message within cooldown returns empty response
    result2 = await pipeline.process(make_inbound(user_id="rapid-user"), adapter)
    assert result2.response_text == ""


@pytest.mark.asyncio
async def test_rate_limiting_different_users_independent():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 60

    result1 = await pipeline.process(make_inbound(user_id="user-a"), adapter)
    result2 = await pipeline.process(make_inbound(user_id="user-b"), adapter)

    # Different users don't interfere
    assert result2.response_text != ""


# ── Bot tests ───────────────────────────────────────────────────────────────

def test_bot_imports():
    from antaris_agent.core.bot import Bot
    assert Bot is not None


def test_pipeline_result_defaults():
    r = PipelineResult(success=True, response_text="hi")
    assert r.blocked is False
    assert r.block_reason == ""
    assert r.tokens_used == 0
    assert r.cost_usd == 0.0
    assert r.error is None


# ── Startup recall tests ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_startup_recall_fires_on_first_message():
    """Startup recall should fire exactly once on first message."""
    pipeline, adapter = make_pipeline()
    # Track recall calls by user_id
    recall_calls = []
    original_recall = pipeline.memory.recall

    async def tracking_recall(user_id, query, **kwargs):
        recall_calls.append((user_id, query))
        return ["recent event: bot started"]

    pipeline.memory.recall = tracking_recall

    await pipeline.process(make_inbound(text="hello"), adapter)

    # Startup recall now runs per session and uses the real user_id.
    recall_system_calls = [(uid, q) for uid, q in recall_calls if q == "recent events today"]
    assert recall_system_calls == [("user-123", "recent events today")]
    assert "user-123:ch-1" in pipeline._startup_recalled_sessions


@pytest.mark.asyncio
async def test_startup_recall_fires_only_once():
    """Startup recall fires on first message, not on subsequent messages."""
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0  # disable cooldown so both messages go through

    recall_system_calls = []

    async def tracking_recall(user_id, query, **kwargs):
        if query == "recent events today":
            recall_system_calls.append((user_id, kwargs.get("session_id")))
        return []

    pipeline.memory.recall = tracking_recall

    # First message
    await pipeline.process(make_inbound(text="first message", user_id="u1"), adapter)
    # Second message
    await pipeline.process(make_inbound(text="second message", user_id="u1"), adapter)

    # Startup recall only fires once per session
    assert recall_system_calls == [("u1", None)]
    assert "u1:ch-1" in pipeline._startup_recalled_sessions


@pytest.mark.asyncio
async def test_startup_recall_flag_set_after_first_message():
    """_startup_recalled flag should be True after first message."""
    pipeline, adapter = make_pipeline()
    assert len(pipeline._startup_recalled_sessions) == 0

    await pipeline.process(make_inbound(), adapter)

    assert len(pipeline._startup_recalled_sessions) > 0


@pytest.mark.asyncio
async def test_startup_recall_injects_into_system_prompt():
    """Startup memories should appear in the system prompt on first message."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(return_value=["startup: bot was last active yesterday"])

    await pipeline.process(make_inbound(text="hi"), adapter)

    # Verify persona.build_system_prompt was called, and result had startup block appended
    pipeline.persona.build_system_prompt.assert_called_once()


@pytest.mark.asyncio
async def test_startup_recall_exception_is_graceful():
    """Startup recall exception should not crash the pipeline."""
    pipeline, adapter = make_pipeline()

    async def failing_recall(user_id, query):
        if user_id == "system":
            raise RuntimeError("store unavailable")
        return []

    pipeline.memory.recall = failing_recall

    result = await pipeline.process(make_inbound(text="hello"), adapter)
    assert result.success is True  # pipeline continues despite startup recall failure


@pytest.mark.asyncio
async def test_startup_context_not_persisted_on_second_message():
    """Startup recall is local — session B must not see session A's startup content."""
    captured_systems: list[str] = []

    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0
    pipeline.memory.recall = AsyncMock(return_value=["event: SESSION_A_STARTUP_CONTENT"])

    async def capture_complete(messages, system, **kw):
        from antaris_agent.llm.base import LLMResponse
        captured_systems.append(system or "")
        return LLMResponse(content="ok", model="test-model", input_tokens=5, output_tokens=5, cost_usd=0.0)

    pipeline.llm.complete = AsyncMock(side_effect=capture_complete)

    # Session A — first message triggers startup recall
    await pipeline.process(make_inbound(text="first", user_id="u1", channel_id="ch-a"), adapter)

    # Session B (different channel_id = different session key) — must NOT get session A's startup recall
    pipeline.memory.recall = AsyncMock(return_value=[])
    await pipeline.process(make_inbound(text="hello", user_id="u1", channel_id="ch-b"), adapter)

    assert len(captured_systems) >= 2
    session_b_prompt = captured_systems[-1]
    assert "SESSION_A_STARTUP_CONTENT" not in session_b_prompt, (
        "Session B must not inherit session A's startup recall content"
    )
    # Also verify _startup_context never exists as an instance attribute
    assert not hasattr(pipeline, '_startup_context')


def test_media_context_marks_screenshot_inputs():
    block, summary = build_media_context("what error is in this screenshot?", [{"media_type": "image/png", "data": "abc"}])
    assert "Visual input attached" in block
    assert summary["image_kind"] == "screenshot"
    assert summary["image_count"] == 1


def test_provider_text_fallback_includes_visual_context():
    text = build_provider_text_fallback("what am I looking at?", [{"media_type": "image/png", "data": "abc"}])
    assert "what am I looking at?" in text
    assert "Visual input attached" in text


@pytest.mark.asyncio
async def test_pipeline_injects_screenshot_context_and_metadata():
    pipeline, adapter = make_pipeline()
    inbound = make_inbound(
        text="what error is in this screenshot?",
        images=[{"media_type": "image/png", "data": "abc123"}],
    )

    result = await pipeline.process(inbound, adapter)

    call_kwargs = pipeline.llm.complete.call_args.kwargs
    sent_messages = call_kwargs["messages"]
    assert isinstance(sent_messages[-1].content, list)
    assert sent_messages[-1].content[0]["type"] == "text"
    assert "Visual input attached" in sent_messages[-1].content[0]["text"]
    assert "screenshot" in call_kwargs["system"].lower()
    assert result.metadata["visual_input"]["image_kind"] == "screenshot"


@pytest.mark.asyncio
async def test_pipeline_marks_general_image_when_no_screenshot_hints():
    pipeline, adapter = make_pipeline()
    inbound = make_inbound(
        text="describe this image",
        images=[{"media_type": "image/jpeg", "data": "xyz"}],
    )

    result = await pipeline.process(inbound, adapter)

    assert result.metadata["visual_input"]["image_kind"] == "image"


@pytest.mark.asyncio
async def test_pipeline_injects_relay_frame_guard_into_system_prompt():
    pipeline, adapter = make_pipeline()

    # Text with no relay intent → static RELAY_FRAME_GUARD injected
    await pipeline.process(make_inbound(text="What time is it?"), adapter)

    system_prompt = pipeline.llm.complete.call_args.kwargs["system"]
    assert RELAY_FRAME_GUARD in system_prompt
    assert "draft, compose, or write" in system_prompt


@pytest.mark.asyncio
async def test_pipeline_injects_dynamic_relay_block_on_acknowledge_intent():
    pipeline, adapter = make_pipeline()

    # Text with Mode A relay intent → dynamic block injected instead of static guard
    await pipeline.process(make_inbound(text="tell Jake the build is done"), adapter)

    system_prompt = pipeline.llm.complete.call_args.kwargs["system"]
    assert "Mode A" in system_prompt
    assert "Jake" in system_prompt
    assert "current speaker" in system_prompt.lower() or "addressed" in system_prompt.lower()


@pytest.mark.asyncio
async def test_pipeline_relay_guard_coexists_with_persona_prompt():
    pipeline, adapter = make_pipeline()
    pipeline.persona.build_system_prompt = MagicMock(return_value="You are Antaris.")

    await pipeline.process(make_inbound(text="let Sam know we're shipping tomorrow"), adapter)

    system_prompt = pipeline.llm.complete.call_args.kwargs["system"]
    assert "You are Antaris." in system_prompt
    assert "stay addressed to the current speaker" in system_prompt.lower()
