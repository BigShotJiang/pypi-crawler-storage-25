"""
Tests for 3.4.5rc — Ingest contract + scope hygiene

Covers:
  - IngestEnvelope construction and policy derivation
  - RecordKind / CrossSessionPolicy defaults
  - is_durable_knowledge() vs broken semantic gate
  - ingest_turn() — atomic whole-turn, not line-split
  - channel_id canonicalization at ingest_turn boundary
  - cross_session_eligible stamped on entries
  - entry.py new fields round-trip
  - RecordMeta serialization
"""
import os
import tempfile
import pytest

# ---------------------------------------------------------------------------
# contracts.py tests
# ---------------------------------------------------------------------------

from parsica_memory.contracts import (
    IngestEnvelope,
    RecordKind,
    CrossSessionPolicy,
    SourceKind,
    is_durable_knowledge,
    RECORD_KIND_DEFAULTS,
    RetrievalRequest,
    RetrievalPurpose,
    SideEffectMode,
    RetrievedItem,
    RetrievalTrace,
    RecordMeta,
    PURPOSE_SIDE_EFFECT_DEFAULTS,
    default_policy,
)


class TestRecordKindDefaults:
    """Policy table is encoded in code, not comments."""

    def test_turn_is_local_only(self):
        p = default_policy(RecordKind.TURN)
        assert p.cross_session_eligible is False
        assert p.default_cross_session_policy == CrossSessionPolicy.LOCAL_ONLY

    def test_fact_is_cross_session_eligible(self):
        p = default_policy(RecordKind.FACT)
        assert p.cross_session_eligible is True

    def test_mistake_is_cross_session_eligible(self):
        assert default_policy(RecordKind.MISTAKE).cross_session_eligible is True

    def test_preference_is_cross_session_eligible(self):
        assert default_policy(RecordKind.PREFERENCE).cross_session_eligible is True

    def test_procedure_is_cross_session_eligible(self):
        assert default_policy(RecordKind.PROCEDURE).cross_session_eligible is True

    def test_document_is_local_only(self):
        assert default_policy(RecordKind.DOCUMENT).cross_session_eligible is False

    def test_system_is_local_only(self):
        assert default_policy(RecordKind.SYSTEM).cross_session_eligible is False

    def test_unknown_falls_back_safely(self):
        p = default_policy(RecordKind.UNKNOWN)
        assert p.cross_session_eligible is False


class TestIsDurableKnowledge:
    """Replaces broken ``cross_session_recall == 'semantic'`` gate."""

    def test_durable_kinds(self):
        for kind in [RecordKind.FACT, RecordKind.MISTAKE,
                     RecordKind.PREFERENCE, RecordKind.PROCEDURE]:
            assert is_durable_knowledge(kind), f"{kind} should be durable"

    def test_non_durable_kinds(self):
        for kind in [RecordKind.TURN, RecordKind.DOCUMENT,
                     RecordKind.SYSTEM, RecordKind.UNKNOWN]:
            assert not is_durable_knowledge(kind), f"{kind} should NOT be durable"

    def test_summary_is_durable(self):
        # Summary is selectively cross-session — default policy says True
        assert is_durable_knowledge(RecordKind.SUMMARY)


class TestIngestEnvelopeForTurn:
    """Turns must be local-only and not fragmented."""

    def test_for_turn_record_kind(self):
        e = IngestEnvelope.for_turn("hello world", session_id="s1")
        assert e.record_kind == RecordKind.TURN

    def test_for_turn_cross_session_eligible_false(self):
        e = IngestEnvelope.for_turn("hello world", session_id="s1")
        assert e.cross_session_eligible is False

    def test_for_turn_policy_local_only(self):
        e = IngestEnvelope.for_turn("hello world", session_id="s1")
        assert e.cross_session_policy == CrossSessionPolicy.LOCAL_ONLY

    def test_for_turn_source_kind(self):
        e = IngestEnvelope.for_turn("hello world")
        assert e.source_kind == SourceKind.CONVERSATION

    def test_for_turn_channel_id_preserved(self):
        e = IngestEnvelope.for_turn("msg", channel_id="discord:1234")
        assert e.channel_id == "discord:1234"

    def test_for_turn_envelope_has_id(self):
        e = IngestEnvelope.for_turn("msg")
        assert len(e.envelope_id) > 0

    def test_for_turn_multiline_content_preserved(self):
        """Whole turn — NOT split into fragments."""
        content = "line one\nline two\nline three"
        e = IngestEnvelope.for_turn(content, session_id="s1")
        assert e.content == content  # must preserve as-is


class TestIngestEnvelopeForFact:
    def test_for_fact_is_cross_session_eligible(self):
        e = IngestEnvelope.for_fact("Python GIL prevents true threading")
        assert e.cross_session_eligible is True
        assert e.record_kind == RecordKind.FACT

    def test_for_fact_policy_knowledge_only(self):
        e = IngestEnvelope.for_fact("important fact")
        assert e.cross_session_policy == CrossSessionPolicy.KNOWLEDGE_ONLY

    def test_for_fact_parent_envelope_id(self):
        parent = IngestEnvelope.for_turn("parent turn", session_id="s1")
        child = IngestEnvelope.for_fact(
            "extracted fact", parent_envelope_id=parent.envelope_id
        )
        assert child.envelope_parent_id == parent.envelope_id


class TestIngestEnvelopeRoundTrip:
    def test_turn_round_trip(self):
        e = IngestEnvelope.for_turn("test content", session_id="s1",
                                     channel_id="discord:999")
        d = e.to_dict()
        e2 = IngestEnvelope.from_dict(d)
        assert e2.record_kind == RecordKind.TURN
        assert e2.cross_session_eligible is False
        assert e2.channel_id == "discord:999"
        assert e2.session_id == "s1"

    def test_fact_round_trip(self):
        e = IngestEnvelope.for_fact("durable fact", tags=["ai", "memory"])
        d = e.to_dict()
        e2 = IngestEnvelope.from_dict(d)
        assert e2.record_kind == RecordKind.FACT
        assert e2.cross_session_eligible is True
        assert "ai" in e2.tags

    def test_envelope_with_children(self):
        parent = IngestEnvelope.for_turn("parent turn")
        child = IngestEnvelope.for_fact("child fact",
                                         parent_envelope_id=parent.envelope_id)
        parent.children.append(child)
        d = parent.to_dict()
        restored = IngestEnvelope.from_dict(d)
        assert len(restored.children) == 1
        assert restored.children[0].record_kind == RecordKind.FACT


class TestIngestEnvelopeInheritPolicy:
    """INHERIT policy derives from record kind."""

    def test_inherit_turn_resolves_false(self):
        e = IngestEnvelope(
            content="test",
            record_kind=RecordKind.TURN,
            cross_session_policy=CrossSessionPolicy.INHERIT,
        )
        assert e.cross_session_eligible is False

    def test_inherit_fact_resolves_true(self):
        e = IngestEnvelope(
            content="test",
            record_kind=RecordKind.FACT,
            cross_session_policy=CrossSessionPolicy.INHERIT,
        )
        assert e.cross_session_eligible is True


class TestRetrievalRequestDefaults:
    """Pure-read is the safe default for everything except user_answer."""

    def test_context_pack_is_pure_read(self):
        r = RetrievalRequest(query="context", purpose=RetrievalPurpose.CONTEXT_PACK)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_handoff_is_pure_read(self):
        r = RetrievalRequest(query="handoff", purpose=RetrievalPurpose.HANDOFF)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_routing_is_pure_read(self):
        r = RetrievalRequest(query="route", purpose=RetrievalPurpose.ROUTING)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_audit_is_pure_read(self):
        r = RetrievalRequest(query="audit", purpose=RetrievalPurpose.AUDIT)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_background_is_pure_read(self):
        r = RetrievalRequest(query="bg", purpose=RetrievalPurpose.BACKGROUND)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_user_answer_is_retrieved_only(self):
        r = RetrievalRequest(query="answer me", purpose=RetrievalPurpose.USER_ANSWER)
        assert r.side_effect_mode == SideEffectMode.RETRIEVED_ONLY

    def test_unknown_purpose_defaults_to_pure_read(self):
        r = RetrievalRequest(query="q", purpose=RetrievalPurpose.UNKNOWN)
        assert r.side_effect_mode == SideEffectMode.PURE_READ

    def test_explicit_override_respected(self):
        r = RetrievalRequest(
            query="q",
            purpose=RetrievalPurpose.USER_ANSWER,
            side_effect_mode=SideEffectMode.PURE_READ,
        )
        assert r.side_effect_mode == SideEffectMode.PURE_READ


class TestRecordMeta:
    def test_basic_construction(self):
        m = RecordMeta(
            record_kind=RecordKind.FACT,
            session_id="s1",
            cross_session_eligible=True,
        )
        assert m.state == "active"
        assert m.record_kind == RecordKind.FACT

    def test_round_trip(self):
        m = RecordMeta(
            record_kind=RecordKind.MISTAKE,
            session_id="s1",
            agent_id="agent1",
            cross_session_eligible=True,
            state="active",
        )
        d = m.to_dict()
        m2 = RecordMeta.from_dict(d)
        assert m2.record_kind == RecordKind.MISTAKE
        assert m2.cross_session_eligible is True
        assert m2.state == "active"


# ---------------------------------------------------------------------------
# MemoryEntry new fields tests
# ---------------------------------------------------------------------------

from parsica_memory.entry import MemoryEntry


class TestMemoryEntryNewFields:
    def test_new_fields_default_empty(self):
        m = MemoryEntry("content")
        assert m.record_id == ""
        assert m.record_kind == ""
        assert m.cross_session_eligible is None
        assert m.envelope_id == ""

    def test_new_fields_not_written_when_default(self):
        m = MemoryEntry("content")
        d = m.to_dict()
        assert "record_id" not in d
        assert "record_kind" not in d
        assert "cross_session_eligible" not in d
        assert "envelope_id" not in d

    def test_new_fields_written_when_set(self):
        m = MemoryEntry("content")
        m.record_id = "r123"
        m.record_kind = "turn"
        m.cross_session_eligible = False
        m.envelope_id = "env-abc"
        d = m.to_dict()
        assert d["record_id"] == "r123"
        assert d["record_kind"] == "turn"
        assert d["cross_session_eligible"] is False
        assert d["envelope_id"] == "env-abc"

    def test_cross_session_eligible_false_is_written(self):
        """False is not default (None is) — must be written."""
        m = MemoryEntry("content")
        m.cross_session_eligible = False
        d = m.to_dict()
        assert "cross_session_eligible" in d
        assert d["cross_session_eligible"] is False

    def test_from_dict_backward_compat(self):
        """Old dicts without new fields load fine."""
        old = {
            "content": "old content",
            "source": "test",
            "hash": "abc123456789",
        }
        m = MemoryEntry.from_dict(old)
        assert m.record_id == ""
        assert m.cross_session_eligible is None

    def test_full_round_trip_with_new_fields(self):
        m = MemoryEntry("full content", source="test", session_id="s1")
        m.record_id = "rid-1"
        m.record_kind = "fact"
        m.cross_session_eligible = True
        m.envelope_id = "env-001"
        d = m.to_dict()
        m2 = MemoryEntry.from_dict(d)
        assert m2.record_id == "rid-1"
        assert m2.record_kind == "fact"
        assert m2.cross_session_eligible is True
        assert m2.envelope_id == "env-001"


# ---------------------------------------------------------------------------
# ingest_turn() integration tests
# ---------------------------------------------------------------------------

from parsica_memory import MemorySystem


@pytest.fixture
def mem():
    with tempfile.TemporaryDirectory() as d:
        m = MemorySystem(d, agent_name="test-agent")
        m.load()
        yield m


def _hydrate(mem, worker_id="test-w"):
    """Run background tasks so typed children materialize (v2.8 background path)."""
    if mem._task_journal is not None:
        mem._task_journal.try_acquire_leader(worker_id)
    mem.run_background_tasks(max_tasks=10, worker_id=worker_id)


class TestIngestTurn:
    def test_turn_ingest_preserves_single_turn_record(self, mem):
        """The whole turn is ONE record — not newline fragments."""
        content = "First line of turn\nSecond line of turn\nThird line"
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        assert entry.content == content.strip()
        # Only ONE entry added for the whole turn
        turn_entries = [m for m in mem.memories if m.record_kind == "turn"]
        assert len(turn_entries) == 1

    def test_turn_ingest_stamps_record_kind(self, mem):
        entry = mem.ingest_turn("hello world for testing", session_id="s1")
        assert entry is not None
        assert entry.record_kind == "turn"

    def test_turn_ingest_stamps_cross_session_false(self, mem):
        entry = mem.ingest_turn("hello world for testing", session_id="s1")
        assert entry is not None
        assert entry.cross_session_eligible is False

    def test_channel_id_persists_to_canonical_channel_field(self, mem):
        """channel_id passed to ingest_turn becomes source_channel on the entry."""
        entry = mem.ingest_turn(
            "message content here",
            session_id="s1",
            channel_id="discord:9876",
        )
        assert entry is not None
        assert entry.source_channel == "discord:9876"

    def test_turn_ingest_dedup(self, mem):
        content = "this is a unique conversation turn"
        e1 = mem.ingest_turn(content, session_id="s1")
        e2 = mem.ingest_turn(content, session_id="s1")
        assert e1 is not None
        assert e2 is None  # duplicate rejected

    def test_turn_ingest_empty_returns_none(self, mem):
        assert mem.ingest_turn("", session_id="s1") is None
        assert mem.ingest_turn("   ", session_id="s1") is None

    def test_turn_ingest_stamps_envelope_id(self, mem):
        entry = mem.ingest_turn("content for envelope test", session_id="s1")
        assert entry is not None
        assert entry.envelope_id != ""

    def test_cross_session_knowledge_only_allows_fact_not_turn(self, mem):
        """
        Under knowledge_only cross-session policy:
          - facts (durable) are eligible
          - turns (episodic) are NOT eligible
        This replaces the broken 'semantic' gate.
        """
        from parsica_memory.contracts import RecordKind, is_durable_knowledge
        assert is_durable_knowledge(RecordKind.FACT) is True
        assert is_durable_knowledge(RecordKind.TURN) is False
        # Verify the entry we create has the right eligibility
        turn_entry = mem.ingest_turn("some turn content here", session_id="s1")
        assert turn_entry is not None
        assert turn_entry.cross_session_eligible is False


# ---------------------------------------------------------------------------
# 3.4.5 Gate 1B — Derived fact decomposition + channel canonicalization
# ---------------------------------------------------------------------------

class TestDerivedFactDecomposition:
    """ingest_turn() decomposes turns into child records for durable knowledge."""

    def test_turn_ingest_creates_derived_fact_children(self, mem):
        """A turn with a fact pattern spawns a FACT child record."""
        content = "Actually, the fact is that Python dicts are ordered since 3.7."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        # There should be at least one child record with record_kind == "fact"
        fact_entries = [m for m in mem.memories if m.record_kind == "fact"]
        assert len(fact_entries) >= 1

    def test_turn_with_mistake_creates_mistake_child(self, mem):
        """A turn with a mistake phrase spawns a MISTAKE child record."""
        content = "I was wrong about that approach, lesson learned: always check the docs first."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        mistake_entries = [m for m in mem.memories if m.record_kind == "mistake"]
        assert len(mistake_entries) >= 1

    def test_turn_with_preference_creates_preference_child(self, mem):
        """A turn with a preference phrase spawns a PREFERENCE child record."""
        content = "I prefer using pytest over unittest for all my projects."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        pref_entries = [m for m in mem.memories if m.record_kind == "preference"]
        assert len(pref_entries) >= 1

    def test_turn_with_procedure_creates_procedure_child(self, mem):
        """A turn with a procedure phrase spawns a PROCEDURE child record."""
        content = "The steps are: first run tests, then commit, then push to the branch."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        proc_entries = [m for m in mem.memories if m.record_kind == "procedure"]
        assert len(proc_entries) >= 1

    def test_turn_without_patterns_creates_no_children(self, mem):
        """A plain turn with no recognized patterns creates only the parent turn record."""
        content = "Let's discuss the weather today and plan our schedule."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        # Only the turn record, no durable children
        child_kinds = {m.record_kind for m in mem.memories if m.record_kind != "turn" and m.record_kind != ""}
        assert len(child_kinds) == 0

    def test_derived_children_have_parent_ids(self, mem):
        """Child records carry the parent turn's envelope_id in their type_metadata."""
        content = "It turns out the answer is 42, remember that for next time."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        parent_envelope_id = entry.envelope_id
        assert parent_envelope_id != ""
        # Child records should have parent_envelope_id in their type_metadata
        children = [m for m in mem.memories if m.record_kind == "fact"]
        assert len(children) >= 1
        for child in children:
            assert child.type_metadata.get("parent_envelope_id") == parent_envelope_id

    def test_derived_facts_are_cross_session_eligible(self, mem):
        """Derived FACT/MISTAKE/PREFERENCE/PROCEDURE children must be cross_session_eligible=True."""
        content = "I learned that Redis is much faster than Memcached for our use case."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        fact_entries = [m for m in mem.memories if m.record_kind == "fact"]
        assert len(fact_entries) >= 1
        for child in fact_entries:
            assert child.cross_session_eligible is True, (
                f"Expected cross_session_eligible=True on derived fact, got {child.cross_session_eligible}"
            )

    def test_derived_mistakes_are_cross_session_eligible(self, mem):
        """Derived MISTAKE children must be cross_session_eligible=True."""
        content = "I made a mistake in the deployment, correction: always run migrations first."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        mistake_entries = [m for m in mem.memories if m.record_kind == "mistake"]
        assert len(mistake_entries) >= 1
        for child in mistake_entries:
            assert child.cross_session_eligible is True

    def test_turn_record_itself_stays_local_only(self, mem):
        """The parent TURN record must NOT be made cross_session_eligible even when children are."""
        content = "Actually I prefer to keep my config in environment variables."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        assert entry.record_kind == "turn"
        assert entry.cross_session_eligible is False

    def test_multiple_patterns_in_one_turn(self, mem):
        """A turn with both fact and preference patterns creates both child types."""
        content = "I prefer TypeScript for large projects. It turns out it catches so many errors."
        entry = mem.ingest_turn(content, session_id="s1")
        assert entry is not None
        _hydrate(mem)
        kinds = {m.record_kind for m in mem.memories if m.record_kind not in ("turn", "")}
        assert "preference" in kinds
        assert "fact" in kinds


class TestChannelCanonicalization:
    """channel_id is canonical; source_channel is a legacy alias."""

    def test_channel_id_persists_to_canonical_field(self, mem):
        """channel_id passed to ingest_turn() is stored as source_channel on the entry."""
        entry = mem.ingest_turn(
            "channel canonicalization test content",
            session_id="s1",
            channel_id="discord:1122334455",
        )
        assert entry is not None
        assert entry.source_channel == "discord:1122334455"

    def test_ingest_channel_id_maps_to_source_channel(self, mem):
        """channel_id passed to ingest() is stored as source_channel on entries."""
        count = mem.ingest(
            "This is a long enough line for the ingest path to accept it as valid content.",
            source="test",
            channel_id="telegram:9988776655",
        )
        assert count >= 1
        entries_with_channel = [
            m for m in mem.memories if getattr(m, "source_channel", "") == "telegram:9988776655"
        ]
        assert len(entries_with_channel) >= 1

    def test_channel_id_takes_precedence_over_source_channel(self, mem):
        """When both channel_id and source_channel are given, channel_id wins."""
        count = mem.ingest(
            "Testing channel precedence in a sufficiently long ingest line for the content filter.",
            source="test",
            channel_id="discord:primary",
            source_channel="discord:legacy",
        )
        assert count >= 1
        entries = [
            m for m in mem.memories if getattr(m, "source_channel", "") == "discord:primary"
        ]
        assert len(entries) >= 1
        # legacy value should not have been stored
        legacy_entries = [
            m for m in mem.memories if getattr(m, "source_channel", "") == "discord:legacy"
        ]
        assert len(legacy_entries) == 0

    def test_derived_children_inherit_channel_id(self, mem):
        """Derived child records inherit channel_id from the parent turn."""
        content = "I prefer to run tests locally before pushing, it turns out CI is slow."
        entry = mem.ingest_turn(
            content,
            session_id="s1",
            channel_id="discord:5544332211",
        )
        assert entry is not None
        _hydrate(mem)
        children = [m for m in mem.memories if m.record_kind in ("fact", "preference")]
        assert len(children) >= 1
        for child in children:
            assert child.source_channel == "discord:5544332211", (
                f"Child {child.record_kind} missing channel_id, got {child.source_channel!r}"
            )


class TestLegacyIngestPaths:
    def test_ingest_stamps_envelope_id(self, mem):
        count = mem.ingest("This is a durable-enough inline memory entry.")
        assert count == 1
        entry = mem.memories[-1]
        assert entry.envelope_id != ""

    def test_ingest_stamps_record_id(self, mem):
        count = mem.ingest("This memory should receive a generated record id.")
        assert count == 1
        entry = mem.memories[-1]
        assert entry.record_id != ""

    def test_ingest_file_uses_document_source_kind(self, mem):
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".md") as f:
            f.write("This is a document line long enough to ingest.")
            file_path = f.name
        try:
            count = mem.ingest_file(file_path)
            assert count == 1
            entry = mem.memories[-1]
            assert entry.record_kind == RecordKind.DOCUMENT.value
            assert entry.cross_session_eligible is False
            assert entry.source_url == file_path
        finally:
            os.unlink(file_path)

    def test_ingest_bulk_stamps_envelopes(self, mem):
        count = mem.ingest_bulk([
            "First bulk memory line that is definitely long enough.",
            "Second bulk memory line that is also definitely long enough.",
        ])
        assert count == 2
        recent = mem.memories[-2:]
        assert all(entry.envelope_id != "" for entry in recent)
        assert len({entry.envelope_id for entry in recent}) == 2

    def test_ingest_mistake_uses_correct_record_kind(self, mem):
        entry = mem.ingest_mistake(
            what_happened="The deploy used the wrong environment.",
            correction="Use the production env file before deploy.",
        )
        assert entry is not None
        assert entry.record_kind == RecordKind.MISTAKE.value

    def test_ingest_fact_is_cross_session_eligible(self, mem):
        count = mem.ingest_fact("The cache invalidation flag lives in config state.")
        assert count == 1
        entry = mem.memories[-1]
        assert entry.record_kind == RecordKind.FACT.value
        assert entry.cross_session_eligible is True
