"""
Cluster F — Permanent regression guard: AST lint for bare `except Exception:`
in parsica_memory/core_v4.py.

Any new `except Exception:` clause must either:
  - Not call a SourceManifest primitive (in which case a reviewer should add
    `# pragma: allow-bare-except: <reason>` on the same line), OR
  - Be narrowed to a specific exception tuple before merging.

The lint parses the AST and fails if it finds `except Exception:` or
`except Exception as <name>:` without the pragma marker. A small allowlist
is maintained for sites that are genuinely generic (e.g. top-level method
wrappers that must return error dicts rather than raise).

Additionally, unit tests verify the Cluster F findings are actually closed:
- P0-1 + P1-1: UnsealedWriteRefused propagates through _tombstone_entries
  and _record_provenance instead of being swallowed.
- P1-9: tombstone() returns 0 when the write is queued (OSError path).
- P1-10: forget() calls manifest.flush() after _tombstone_entries so queued
  tombstones are drained before returning success.
- Regression: forget() on a NO_HMAC=1 sealed workspace raises rather than
  returning a populated 'removed' list with no manifest write.
"""

import ast
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch, call

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).parent.parent
CORE_PATH = REPO_ROOT / "parsica_memory" / "core_v4.py"
MANIFEST_PATH = REPO_ROOT / "parsica_memory" / "source_manifest.py"


def _iter_except_exception_nodes(tree: ast.AST):
    """Yield (lineno, handler) for every `except Exception` handler in tree."""
    for node in ast.walk(tree):
        if not isinstance(node, ast.ExceptHandler):
            continue
        if node.type is None:
            # bare `except:` — not our target but arguably worse
            continue
        t = node.type
        if isinstance(t, ast.Name) and t.id == "Exception":
            yield node.lineno, node
        elif isinstance(t, ast.Attribute) and t.attr == "Exception":
            yield node.lineno, node


# ---------------------------------------------------------------------------
# AST lint test
# ---------------------------------------------------------------------------

# Sites that are allowed to keep `except Exception:` — top-level wrappers
# that must catch-all to return structured error dicts, and health check
# probes that must never raise. Each entry is an approximate line number
# (within ±5) so the test is robust to minor line shifts.
#
# To add a new allowlist entry, add the `# pragma: allow-bare-except: <reason>`
# comment on the same line as the `except Exception` in the source. This list
# is the fallback for sites that predate the pragma convention.
_ALLOWLIST_FUNCTIONS = {
    # top-level wrappers returning error dicts
    "ingest_url",
    "ingest_data_file",
    "delete_source",
    # health-check probes — must never raise
    "get_health",
    # optional-feature init — feature disables itself gracefully
    "__init__",
    "_initialize",
    # stats() collection helpers — safe to swallow metric failures
    "stats",
    # search-tier helpers — fallback on failure, must not raise
    "_warm_search_fallback",
    "_cold_search",
    "search",
    # ingest helpers — graph/WAL/enrichment failures are non-fatal
    "ingest",
    "ingest_bulk",
    "_setup_v46_index",
    "_feed_cooccurrence_from_enrichment",
    # enrichment passes — non-fatal per-entry
    "re_enrich",
    "re_decompose",
    # misc non-fatal helpers
    "save",
    "mark_used",
    "import_from",
    "_replay_wal",
    "_get_embedding",
    "forget",  # WAL-purge path only — manifest path now narrowed (P0-1 closed)
    # graph API wrappers — must never raise
    "graph_search",
    "entity_path",
    "get_entity",
    "get_graph_stats",
    "check_bootstrap_files",
    "rebuild_graph",
    "rebuild_clusters",
}

# Pragma marker for inline opt-out
_PRAGMA = "pragma: allow-bare-except"


class TestNoBareExceptInCoreV4(unittest.TestCase):
    """AST-based lint: no new bare `except Exception:` in core_v4.py
    that calls a SourceManifest primitive."""

    def setUp(self):
        self.source = CORE_PATH.read_text(encoding="utf-8")
        self.lines = self.source.splitlines()
        self.tree = ast.parse(self.source, filename=str(CORE_PATH))

    def _containing_function(self, lineno: int) -> str:
        """Return the name of the innermost function/method containing lineno."""
        best = None
        best_start = -1
        for node in ast.walk(self.tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            end = getattr(node, "end_lineno", node.lineno + 200)
            if node.lineno <= lineno <= end and node.lineno > best_start:
                best = node.name
                best_start = node.lineno
        return best or "<module>"

    def test_no_bare_except_exception_outside_allowlist(self):
        """Every `except Exception:` must be in an allowed function or carry
        the allow pragma on the same line."""
        violations = []
        for lineno, handler in _iter_except_exception_nodes(self.tree):
            line_text = self.lines[lineno - 1] if lineno <= len(self.lines) else ""
            if _PRAGMA in line_text:
                continue
            fn = self._containing_function(lineno)
            if fn in _ALLOWLIST_FUNCTIONS:
                continue
            violations.append((lineno, fn, line_text.strip()))

        if violations:
            msg = (
                f"core_v4.py has {len(violations)} bare `except Exception:` handler(s) "
                "outside the Cluster-F allowlist.\n"
                "Fix: narrow to a specific exception tuple, or add "
                f"`# {_PRAGMA}: <reason>` on the same line.\n\n"
            )
            for lineno, fn, text in violations:
                msg += f"  line {lineno} in {fn!r}: {text}\n"
            self.fail(msg)


# ---------------------------------------------------------------------------
# Sibling lint for source_manifest.py (Cluster I extension per Master Manifest)
# ---------------------------------------------------------------------------
#
# The primitive also participates in the no-bare-except discipline. Unlike
# core_v4.py where most bare-except sites are top-level API wrappers returning
# error dicts, source_manifest.py's bare-except sites are internal fallback
# paths that must fail closed (not silent-downgrade). Post-R4.1 all remaining
# bare-except sites in source_manifest.py carry `# pragma: no cover` because
# they sit on hard-unreachable defensive branches; we allow-list those
# function names here as the durable policy.
#
# The critical R3.1 regression was specifically `_ensure_secret` with a bare
# except Exception — after Cluster B that now has narrow `except (OSError,
# ValueError)` with a permanent test in test_source_manifest_r41_hmac.py.
# This lint ensures no NEW bare-except sneaks into the primitive.

_MANIFEST_ALLOWLIST_FUNCTIONS = {
    # Internal defensive fallbacks — each covered by `# pragma: no cover`
    # because the exception path is genuinely unreachable under contract.
    "_ensure_loaded",        # last-resort guard around lazy load
    "_load_from_disk",       # defensive wrapper around per-line JSONL parse
    "_write_anchor_sidecar", # defensive sidecar write (returns to caller; caller handles)
    "_write_counter_sidecar",# defensive counter sidecar write
    "_drain_pending",        # opportunistic drain — non-fatal per-record
    # Cluster A-gated public API — bare except on internal stats fallbacks
    # after the gate already rejected bad states.
    "add",       # primitive-internal best-effort cleanup AFTER gate passed
    "tombstone", # primitive-internal best-effort cleanup AFTER gate passed
}


class TestNoBareExceptInSourceManifest(unittest.TestCase):
    """AST-based lint: no new bare `except Exception:` in source_manifest.py
    outside the R4.1 allowlist. Guards against the R3.1 silent-downgrade
    pattern re-emerging in the primitive."""

    def setUp(self):
        self.source = MANIFEST_PATH.read_text(encoding="utf-8")
        self.lines = self.source.splitlines()
        self.tree = ast.parse(self.source, filename=str(MANIFEST_PATH))

    def _containing_function(self, lineno: int) -> str:
        best = None
        best_start = -1
        for node in ast.walk(self.tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            end = getattr(node, "end_lineno", node.lineno + 200)
            if node.lineno <= lineno <= end and node.lineno > best_start:
                best = node.name
                best_start = node.lineno
        return best or "<module>"

    def test_no_bare_except_exception_outside_allowlist(self):
        """Every `except Exception:` in source_manifest.py must be in an
        allowed function or carry the allow pragma on the same line.

        R4.1 Cluster B closed the `_ensure_secret` silent-downgrade bug that
        Attacker Opus flagged as P0 (F-R4-ATK-OPUS-05). This lint ensures no
        new bare except sneaks into the primitive.
        """
        violations = []
        for lineno, handler in _iter_except_exception_nodes(self.tree):
            line_text = self.lines[lineno - 1] if lineno <= len(self.lines) else ""
            if _PRAGMA in line_text:
                continue
            fn = self._containing_function(lineno)
            if fn in _MANIFEST_ALLOWLIST_FUNCTIONS:
                continue
            violations.append((lineno, fn, line_text.strip()))

        if violations:
            msg = (
                f"source_manifest.py has {len(violations)} bare `except Exception:` "
                "handler(s) outside the Cluster-B/F allowlist.\n"
                "Fix: narrow to a specific exception tuple, or add "
                f"`# {_PRAGMA}: <reason>` on the same line. The primitive MUST NOT\n"
                "silently swallow ManifestIntegrityError, UnsealedWriteRefused, "
                "HMACMismatch, or ManifestLockTimeoutError.\n\n"
            )
            for lineno, fn, text in violations:
                msg += f"  line {lineno} in {fn!r}: {text}\n"
            self.fail(msg)

    def test_ensure_secret_has_no_bare_except(self):
        """Explicit regression guard for R3.1's specific P0: `_ensure_secret`
        had a bare `except Exception` that silent-downgraded HMAC on corrupt
        secret files. Closed in Cluster B. This test pins that closure."""
        for lineno, handler in _iter_except_exception_nodes(self.tree):
            fn = self._containing_function(lineno)
            if fn == "_ensure_secret":
                self.fail(
                    f"_ensure_secret has bare `except Exception` at line {lineno}. "
                    "Cluster B closed the R3.1 P0 corrupt-secret silent-downgrade "
                    "bug by narrowing to `except (OSError, ValueError)`. Do not "
                    "re-introduce the bare except."
                )


# ---------------------------------------------------------------------------
# Unit tests for specific findings
# ---------------------------------------------------------------------------

def _make_ms(tmp_path):
    """Create a MemorySystemV4 with the test workspace."""
    from parsica_memory.core_v4 import MemorySystemV4
    return MemorySystemV4(workspace=str(tmp_path), use_sharding=False)


class TestP01TombstoneEntriesPropagates(unittest.TestCase):
    """P0-1: _tombstone_entries must let UnsealedWriteRefused propagate."""

    def test_unsealed_write_refused_propagates(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        from parsica_memory.source_manifest import UnsealedWriteRefused
        ms = _make_ms(tmp_path)

        # Patch the internal manifest's tombstone() to raise UnsealedWriteRefused
        manifest_mock = MagicMock()
        manifest_mock.tombstone.side_effect = UnsealedWriteRefused("sealed")

        with patch.object(type(ms), "_manifest_internal", return_value=manifest_mock):
            entry = MagicMock()
            entry.hash = "abc123" * 10
            entry.identity_id = "test-identity"

            with self.assertRaises(UnsealedWriteRefused):
                ms._tombstone_entries([entry], reason="forgotten")


class TestP01TombstoneEntriesSwallowsTransient(unittest.TestCase):
    """P0-1: _tombstone_entries must swallow transient OSError (still counts 0)."""

    def test_oserror_swallowed_returns_zero(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        ms = _make_ms(tmp_path)

        manifest_mock = MagicMock()
        manifest_mock.tombstone.side_effect = OSError("disk full")

        with patch.object(type(ms), "_manifest_internal", return_value=manifest_mock):
            entry = MagicMock()
            entry.hash = "abc123" * 10
            entry.identity_id = "test-identity"

            # Should not raise; returns 0 (tombstone() returns 0 on queue)
            count = ms._tombstone_entries([entry], reason="forgotten")
            self.assertEqual(count, 0)


class TestP11RecordProvenancePropagates(unittest.TestCase):
    """P1-1: _record_provenance must let UnsealedWriteRefused propagate."""

    def test_unsealed_write_refused_propagates(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        from parsica_memory.source_manifest import UnsealedWriteRefused, NATIVE_SOURCE_TYPES
        ms = _make_ms(tmp_path)

        manifest_mock = MagicMock()
        manifest_mock.add.side_effect = UnsealedWriteRefused("sealed")

        # _record_provenance only hits add() when a valid src_type + src_id exist
        src_type = next(iter(NATIVE_SOURCE_TYPES - {"unknown"}))

        with patch.object(type(ms), "_manifest_internal", return_value=manifest_mock):
            with self.assertRaises(UnsealedWriteRefused):
                ms._record_provenance(
                    "abc123" * 10,
                    src_type,
                    source_url="https://example.com/test",
                    source_channel=None,
                )


class TestP19TombstoneReturnsZeroOnQueue(unittest.TestCase):
    """P1-9: SourceManifest.tombstone() must return 0 when write is queued."""

    def test_oserror_queued_returns_zero(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        from parsica_memory.source_manifest import SourceManifest, TOMBSTONE_REASONS
        sm = SourceManifest(workspace=str(tmp_path))

        reason = next(iter(TOMBSTONE_REASONS))

        # Patch _append_line to raise OSError (simulating disk full)
        with patch.object(sm, "_append_line", side_effect=OSError("disk full")):
            result = sm.tombstone(
                "abc123" * 10, reason, identity_id="test-identity"
            )
        self.assertEqual(result, 0, "tombstone() must return 0 when write is queued")


class TestP10ForgetFlushAfterTombstone(unittest.TestCase):
    """P1-10: forget() must call manifest.flush() after _tombstone_entries."""

    def test_flush_called_after_tombstone(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        from parsica_memory.entry import MemoryEntry
        ms = _make_ms(tmp_path)

        flush_called = []
        manifest_mock = MagicMock()
        manifest_mock.tombstone.return_value = 1
        manifest_mock.flush.side_effect = lambda: flush_called.append(True) or 1

        # Seed a memory directly so we bypass the ingest pipeline
        entry = MemoryEntry(content="hello topic test memory", category="general", source="internal")
        ms.memories = [entry]
        ms._hashes = {entry.hash}

        with patch.object(type(ms), "_manifest_internal", return_value=manifest_mock):
            with patch.object(type(ms), "_using_segments", new_callable=lambda: property(lambda self: True)):
                # Patch segment_store.forget_hashes to no-op
                ms._segment_store = MagicMock()
                ms.forget(topic="hello")

        self.assertTrue(flush_called, "manifest.flush() must be called after _tombstone_entries in forget()")


class TestRegressionForgetSealedWorkspace(unittest.TestCase):
    """Regression for P0-1: forget() on a NO_HMAC=1 sealed workspace must raise
    (or return a non-success result) rather than returning populated 'removed'."""

    def test_forget_on_sealed_workspace_raises(self, tmp_path=None):
        if tmp_path is None:
            import tempfile
            tmp_path = Path(tempfile.mkdtemp())
        from parsica_memory.source_manifest import UnsealedWriteRefused
        from parsica_memory.entry import MemoryEntry
        ms = _make_ms(tmp_path)

        # Seed a memory directly
        entry = MemoryEntry(content="hello world sealed test", category="general", source="internal")
        ms.memories = [entry]
        ms._hashes = {entry.hash}

        manifest_mock = MagicMock()
        manifest_mock.tombstone.side_effect = UnsealedWriteRefused("sealed")

        with patch.object(type(ms), "_manifest_internal", return_value=manifest_mock):
            with patch.object(type(ms), "_using_segments", new_callable=lambda: property(lambda self: True)):
                ms._segment_store = MagicMock()
                with self.assertRaises(UnsealedWriteRefused):
                    ms.forget(topic="hello")


if __name__ == "__main__":
    unittest.main()
