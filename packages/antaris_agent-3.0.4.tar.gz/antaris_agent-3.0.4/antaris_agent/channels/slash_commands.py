"""Discord slash command registration for Antaris Agent.

Mirrors the !command system as /commands for Discord's native slash UI.
Commands that take arguments use a single 'args' string parameter.
Commands that need no args are simple slash commands.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import discord
    from discord import app_commands

logger = logging.getLogger(__name__)


# Commands that take no arguments
_SIMPLE_COMMANDS = {
    "status": "Show bot status, provider, memory, and security info",
    "ping": "Quick alive check",
    "help": "Show all available commands",
    "models": "List available LLM models",
    "stop": "Gracefully shut down the bot (authorized users only)",
    "compact": "Manually trigger memory compaction for this session",
    "approve": "Approve a pending venture action",
    "deny": "Deny a pending venture action",
}

# Commands that take a single string argument
_ARG_COMMANDS = {
    "model": ("Switch LLM model", "model_name", "Model name or alias"),
    "gather": ("Catch up on recent Discord history", "hours", "Hours to look back (3/6/12/18/24/48)"),
    "memory": ("Memory operations", "subcommand", "search/recent/stats/forget/clear + query"),
    "teach": ("Teach the bot a fact or preference", "text", "What to teach (or list/remove/clear)"),
    "focus": ("Focus on a specific topic", "topic", "Topic and optional duration"),
    "unfocus": ("Remove current focus", None, None),
    "cron": ("Manage scheduled tasks", "subcommand", "add/list/remove/run + args"),
    "spawn": ("Spawn a subagent", "task", "Task description for the subagent"),
    "agent": ("Agent mode operations", "subcommand", "Subcommand and args"),
    "agents": ("List running subagents", "subcommand", "Optional: kill <name>"),
    "sync": ("Sync memory operations", "subcommand", "Subcommand and args"),
    "cost": ("Show API cost tracking", "period", "Optional: today/week/month/reset"),
    "export": ("Export data", "format", "Export format and options"),
    "feedback": ("Submit feedback", "text", "Your feedback"),
    "profile": ("Manage user profiles", "subcommand", "Subcommand and args"),
    "shortcuts": ("Manage command shortcuts", "subcommand", "Subcommand and args"),
    "recap": ("Get a recap of recent context", "scope", "Optional scope"),
    "thinking": ("Toggle extended thinking mode", "mode", "on/off"),
    "extensions": ("Manage extensions", "subcommand", "Subcommand and args"),
    "auth": ("Auth management", "subcommand", "Subcommand and args"),
    "skills": ("List available skills", "subcommand", "Optional subcommand"),
    "webhooks": ("Manage webhooks", "subcommand", "Subcommand and args"),
    "discover": ("Discovery and audit", "subcommand", "audit or other subcommand"),
    "gmail": ("Gmail operations", "subcommand", "Gmail subcommand and args"),
    "calendar": ("Google Calendar operations", "subcommand", "Calendar subcommand and args"),
    "drive": ("Google Drive operations", "subcommand", "Drive subcommand and args"),
    "thread": ("Thread operations", "subcommand", "Thread subcommand and args"),
    "threads": ("List active threads", None, None),
}


async def register_slash_commands(
    client: discord.Client,
    command_dispatcher,
    guild_ids: list[int] | None = None,
) -> None:
    """Register slash commands on the Discord client.

    Args:
        client: The discord.py Client instance
        command_dispatcher: The CommandDispatcher instance (calls dispatch() directly)
        guild_ids: Optional list of guild IDs for instant sync (vs global which takes ~1hr)
    """
    try:
        from discord import app_commands
        import discord
    except ImportError:
        logger.warning("discord.py app_commands not available — slash commands disabled")
        return

    tree = app_commands.CommandTree(client)

    def _make_inbound(interaction: discord.Interaction, command_text: str):
        from antaris_agent.channels.base import InboundMessage
        return InboundMessage(
            text=command_text,
            user_id=str(interaction.user.id),
            channel_id=str(interaction.channel_id),
            platform="discord",
            username=interaction.user.display_name,
            raw=None,
        )

    async def _run_command(interaction: discord.Interaction, cmd_text: str):
        """Dispatch a !command via the CommandDispatcher and send the result."""
        await interaction.response.defer(thinking=True)
        inbound = _make_inbound(interaction, cmd_text)
        try:
            result = await command_dispatcher.dispatch(inbound)
            if result.handled and result.response:
                text = str(result.response)[:2000]
                await interaction.followup.send(text)
            elif result.handled:
                await interaction.followup.send("✅ Done.")
            else:
                await interaction.followup.send("⚠️ Command not recognized.")
        except Exception as e:
            logger.exception("Slash command failed: %s", cmd_text)
            await interaction.followup.send("❌ An error occurred. Check server logs for details.")

    # Register simple commands (no args)
    for cmd_name, description in _SIMPLE_COMMANDS.items():
        @tree.command(name=cmd_name, description=description)
        async def _handler(interaction: discord.Interaction, _cmd=cmd_name):
            await _run_command(interaction, f"!{_cmd}")

    # Register arg commands
    for cmd_name, (description, arg_name, arg_desc) in _ARG_COMMANDS.items():
        if arg_name is None:
            @tree.command(name=cmd_name, description=description)
            async def _handler_noarg(interaction: discord.Interaction, _cmd=cmd_name):
                await _run_command(interaction, f"!{_cmd}")
        else:
            @tree.command(name=cmd_name, description=description)
            @app_commands.describe(**{arg_name: arg_desc})
            async def _handler_arg(
                interaction: discord.Interaction,
                args: str = "",
                _cmd=cmd_name,
            ):
                await _run_command(interaction, f"!{_cmd} {args}".strip())

    # Sync commands
    try:
        if guild_ids:
            for gid in guild_ids:
                guild = discord.Object(id=gid)
                tree.copy_global_to(guild=guild)
                synced = await tree.sync(guild=guild)
                logger.info("Synced %d slash commands to guild %s", len(synced), gid)
        else:
            synced = await tree.sync()
            logger.info("Synced %d slash commands globally (may take up to 1 hour to appear)", len(synced))
    except Exception as e:
        logger.error("Failed to sync slash commands: %s", e)

    # Store tree on client for potential later use
    client._command_tree = tree
    logger.info("Slash command registration complete: %d simple + %d with args",
                len(_SIMPLE_COMMANDS), len(_ARG_COMMANDS))
