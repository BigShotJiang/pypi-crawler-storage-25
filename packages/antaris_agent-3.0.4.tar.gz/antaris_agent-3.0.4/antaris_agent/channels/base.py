from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Callable, Awaitable


@dataclass
class InboundMessage:
    id: str                       # platform message ID
    user_id: str                  # sender identifier (platform-scoped)
    user_name: str                # display name
    channel_id: str               # channel/chat identifier
    platform: str                 # "discord" | "telegram" | "terminal"
    text: str                     # message text
    reply_to: Optional[str] = None
    timestamp_ms: int = 0
    metadata: dict = field(default_factory=dict)
    images: list = field(default_factory=list)       # v1.7.0: base64 image data [{"media_type": "image/png", "data": "..."}]
    documents: list = field(default_factory=list)     # v1.7.0: extracted doc text [{"filename": "...", "text": "..."}]
    channel_context: list = field(default_factory=list)  # v2.9.8: recent channel messages for lookback [{"author": str, "text": str, "timestamp_ms": int}]


@dataclass
class OutboundMessage:
    channel_id: str
    text: str
    reply_to: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    files: Optional[list] = None  # list of dicts: {"path": str, "filename": str (optional)}


# Type alias for message handler
MessageHandler = Callable[[InboundMessage], Awaitable[None]]


class ChannelAdapter(ABC):
    def __init__(self):
        self._handler: Optional[MessageHandler] = None

    def on_message(self, handler: MessageHandler):
        """Register the message handler."""
        self._handler = handler

    @abstractmethod
    async def connect(self):
        """Connect to the platform."""
        pass

    @abstractmethod
    async def disconnect(self):
        """Disconnect cleanly."""
        pass

    @abstractmethod
    async def send(self, message: OutboundMessage):
        """Send a message."""
        pass

    def format_for_surface(self, text: str) -> str:
        """Format text for this surface. Override in subclasses."""
        return text
