"""
Notification Tool — Push macOS notifications and alerts.

Operations:
  notify  — Send a macOS notification center alert
  say     — Speak text aloud via macOS TTS (for urgent alerts)

Uses osascript (macOS native). The notification appears in
Notification Center regardless of what app is focused.

Drop into: antaris_agent/tools/native/notification.py
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class NotificationTool(NativeTool):
    """Push macOS notifications and alerts."""

    def __init__(self, app_name: str = "Antaris Agent"):
        self._app_name = app_name

    @property
    def name(self) -> str:
        return "notification"

    @property
    def description(self) -> str:
        return (
            "Send a macOS notification or speak an alert aloud. "
            "Use 'notify' for visual notifications in Notification Center. "
            "Use 'say' for spoken alerts (urgent situations)."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Notification type",
                    "enum": ["notify", "say"],
                },
                "title": {
                    "type": "string",
                    "description": "Notification title (for 'notify')",
                },
                "message": {
                    "type": "string",
                    "description": "Notification body text or text to speak",
                },
                "subtitle": {
                    "type": "string",
                    "description": "Optional subtitle (for 'notify')",
                },
                "sound": {
                    "type": "boolean",
                    "description": "Play notification sound (default true)",
                    "default": True,
                },
                "voice": {
                    "type": "string",
                    "description": "macOS voice name for 'say' (default: system default)",
                },
            },
            "required": ["operation", "message"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")
        message = arguments.get("message", "")

        if not message:
            return ToolResult(
                success=False, content="",
                error="'message' is required",
                is_error=True,
            )

        try:
            if operation == "notify":
                return await self._notify(arguments)
            elif operation == "say":
                return await self._say(arguments)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}. Use 'notify' or 'say'.",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Notification tool error")
            return ToolResult(
                success=False, content="",
                error=f"Notification error: {e}",
                is_error=True,
            )

    async def _notify(self, args: dict) -> ToolResult:
        """Send a macOS notification."""
        title = args.get("title", self._app_name)
        message = args.get("message", "")
        subtitle = args.get("subtitle", "")
        sound = args.get("sound", True)

        # Escape for AppleScript
        title_esc = title.replace('"', '\\"')
        message_esc = message.replace('"', '\\"')
        subtitle_esc = subtitle.replace('"', '\\"')

        script_parts = [f'display notification "{message_esc}" with title "{title_esc}"']
        if subtitle:
            script_parts[0] += f' subtitle "{subtitle_esc}"'
        if sound:
            script_parts[0] += ' sound name "default"'

        script = script_parts[0]

        proc = await asyncio.create_subprocess_exec(
            "osascript", "-e", script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)

        if proc.returncode != 0:
            error = stderr.decode("utf-8", errors="replace")
            return ToolResult(
                success=False, content="",
                error=f"Notification failed: {error}",
                is_error=True,
            )

        return ToolResult(
            success=True,
            content=f"Notification sent: {title} — {message[:80]}",
        )

    async def _say(self, args: dict) -> ToolResult:
        """Speak text aloud using macOS TTS."""
        message = args.get("message", "")
        voice = args.get("voice", "")

        # Truncate to avoid very long speech
        if len(message) > 500:
            message = message[:500]

        cmd = ["say"]
        if voice:
            cmd.extend(["-v", voice])
        cmd.append(message)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)

        if proc.returncode != 0:
            error = stderr.decode("utf-8", errors="replace")
            return ToolResult(
                success=False, content="",
                error=f"TTS failed: {error}",
                is_error=True,
            )

        return ToolResult(
            success=True,
            content=f"Spoke aloud: {message[:80]}",
        )
