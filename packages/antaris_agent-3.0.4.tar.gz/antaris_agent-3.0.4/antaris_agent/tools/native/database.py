"""
Database/SQL Tool — Query Postgres directly via asyncpg.

Operations:
  query     — Execute a read-only SQL query (SELECT)
  execute   — Execute a write SQL statement (INSERT/UPDATE/DELETE)
  tables    — List all tables in a schema
  describe  — Describe a table's columns and types
  count     — Count rows in a table (with optional WHERE)

Security:
  - Read-only mode available (blocks writes)
  - DROP and TRUNCATE always blocked
  - Query timeout enforcement
  - Result row limit to prevent RAM issues
  - Connection pooling for performance

Dependencies: asyncpg (pip install asyncpg)

Drop into: antaris_agent/tools/native/database.py

Config (tools_config):
    "database": {
        "enabled": true,
        "postgres_url": "postgresql://user:pass@host:port/dbname",
        "read_only": false,
        "max_rows": 500,
        "timeout": 30
    }

For Supabase, use the direct Postgres connection string from your
dashboard: Settings → Database → Connection string (URI).
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class DatabaseTool(NativeTool):
    """Query Postgres databases directly via asyncpg."""

    def __init__(
        self,
        postgres_url: str = "",
        read_only: bool = False,
        max_rows: int = 500,
        timeout: float = 30.0,
    ):
        self._postgres_url = postgres_url
        self._read_only = read_only
        self._max_rows = max_rows
        self._timeout = timeout
        self._pool = None  # lazy-init connection pool

    @property
    def name(self) -> str:
        return "database"

    @property
    def description(self) -> str:
        ro = " Read-only mode." if self._read_only else ""
        return (
            f"Query and manage Postgres database tables.{ro} "
            "Operations: query (SELECT), execute (INSERT/UPDATE/DELETE), "
            "tables (list), describe (columns), count (row count)."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Database operation",
                    "enum": ["query", "execute", "tables", "describe", "count"],
                },
                "sql": {
                    "type": "string",
                    "description": "SQL query or statement (for 'query' and 'execute')",
                },
                "schema": {
                    "type": "string",
                    "description": "Schema name (default: public)",
                    "default": "public",
                },
                "table": {
                    "type": "string",
                    "description": "Table name (for 'describe' and 'count')",
                },
                "where": {
                    "type": "string",
                    "description": "WHERE clause for 'count' (without the WHERE keyword)",
                },
                "max_rows": {
                    "type": "integer",
                    "description": "Max rows to return (default from config)",
                },
            },
            "required": ["operation"],
        }

    async def _get_pool(self):
        """Lazy-init a connection pool."""
        if self._pool is None:
            try:
                import asyncpg
            except ImportError:
                return None
            self._pool = await asyncpg.create_pool(
                self._postgres_url,
                min_size=1,
                max_size=5,
                command_timeout=self._timeout,
            )
        return self._pool

    async def _run_sql(self, sql: str, max_rows: int = None) -> ToolResult:
        """Execute SQL and return formatted results."""
        try:
            import asyncpg
        except ImportError:
            return ToolResult(
                success=False, content="",
                error="asyncpg not installed. Run: pip install asyncpg",
                is_error=True,
            )

        if not self._postgres_url:
            return ToolResult(
                success=False, content="",
                error="postgres_url not configured",
                is_error=True,
            )

        max_rows = max_rows or self._max_rows

        pool = await self._get_pool()
        if pool is None:
            return ToolResult(
                success=False, content="",
                error="Failed to create database connection pool",
                is_error=True,
            )

        try:
            async with pool.acquire() as conn:
                # Check if it's a SELECT-like query (returns rows)
                sql_upper = sql.strip().upper()
                is_select = sql_upper.startswith(("SELECT", "WITH", "SHOW", "EXPLAIN"))

                if is_select:
                    rows = await conn.fetch(sql)
                    if not rows:
                        return ToolResult(success=True, content="Query returned 0 rows.")
                    data = [dict(r) for r in rows[:max_rows]]
                    total = len(rows)
                    return self._format_results(data, max_rows, total)
                else:
                    # Execute (INSERT/UPDATE/DELETE) — returns status string
                    result = await conn.execute(sql)
                    return ToolResult(success=True, content=f"Executed: {result}")

        except asyncpg.PostgresError as e:
            return ToolResult(
                success=False, content="",
                error=f"SQL error: {e}",
                is_error=True,
            )
        except Exception as e:
            return ToolResult(
                success=False, content="",
                error=f"Database error: {e}",
                is_error=True,
            )

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")

        try:
            if operation == "query":
                return await self._query(arguments)
            elif operation == "execute":
                return await self._execute_sql(arguments)
            elif operation == "tables":
                return await self._tables(arguments)
            elif operation == "describe":
                return await self._describe(arguments)
            elif operation == "count":
                return await self._count(arguments)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Database tool error: operation=%s", operation)
            return ToolResult(
                success=False, content="",
                error=f"Database error: {e}",
                is_error=True,
            )

    async def _query(self, args: dict) -> ToolResult:
        """Execute a read-only SQL query."""
        sql = args.get("sql", "").strip()
        if not sql:
            return ToolResult(
                success=False, content="",
                error="'sql' is required for query",
                is_error=True,
            )

        # Reject obvious writes in query mode
        first_word = sql.split()[0].upper() if sql.split() else ""
        if first_word in ("INSERT", "UPDATE", "DELETE", "DROP", "ALTER",
                          "CREATE", "TRUNCATE", "GRANT", "REVOKE"):
            return ToolResult(
                success=False, content="",
                error=f"Use 'execute' operation for {first_word} statements, not 'query'",
                is_error=True,
            )

        max_rows = args.get("max_rows", self._max_rows)
        return await self._run_sql(sql, max_rows)

    async def _execute_sql(self, args: dict) -> ToolResult:
        """Execute a write SQL statement."""
        if self._read_only:
            return ToolResult(
                success=False, content="",
                error="Database is in read-only mode. Write operations are blocked.",
                is_error=True,
            )

        sql = args.get("sql", "").strip()
        if not sql:
            return ToolResult(
                success=False, content="",
                error="'sql' is required for execute",
                is_error=True,
            )

        # Block dangerous operations
        first_word = sql.split()[0].upper() if sql.split() else ""
        if first_word in ("DROP", "TRUNCATE"):
            return ToolResult(
                success=False, content="",
                error=f"{first_word} operations are blocked for safety. Use psql directly.",
                is_error=True,
            )

        return await self._run_sql(sql)

    async def _tables(self, args: dict) -> ToolResult:
        """List all tables in a schema."""
        schema = args.get("schema", "public")
        sql = (
            f"SELECT table_name, table_type "
            f"FROM information_schema.tables "
            f"WHERE table_schema = '{schema}' "
            f"ORDER BY table_name"
        )
        return await self._run_sql(sql, 200)

    async def _describe(self, args: dict) -> ToolResult:
        """Describe a table's columns."""
        table = args.get("table", "")
        schema = args.get("schema", "public")

        if not table:
            return ToolResult(
                success=False, content="",
                error="'table' is required for describe",
                is_error=True,
            )

        sql = (
            f"SELECT column_name, data_type, is_nullable, column_default "
            f"FROM information_schema.columns "
            f"WHERE table_schema = '{schema}' AND table_name = '{table}' "
            f"ORDER BY ordinal_position"
        )
        return await self._run_sql(sql, 200)

    async def _count(self, args: dict) -> ToolResult:
        """Count rows in a table."""
        table = args.get("table", "")
        schema = args.get("schema", "public")
        where = args.get("where", "")

        if not table:
            return ToolResult(
                success=False, content="",
                error="'table' is required for count",
                is_error=True,
            )

        sql = f'SELECT COUNT(*) as count FROM "{schema}"."{table}"'
        if where:
            sql += f" WHERE {where}"

        return await self._run_sql(sql)

    def _format_results(self, data: list[dict], max_rows: int,
                        total: int) -> ToolResult:
        """Format query results as a readable table."""
        if not data:
            return ToolResult(success=True, content="Query returned 0 rows.")

        # Get all columns
        columns = list(data[0].keys())

        # Calculate column widths (capped at 40 chars)
        widths = {}
        for col in columns:
            max_val_len = max(len(str(row.get(col, ""))[:40]) for row in data)
            widths[col] = min(40, max(len(col), max_val_len))

        # Build table
        header = " | ".join(col.ljust(widths[col]) for col in columns)
        separator = "-+-".join("-" * widths[col] for col in columns)

        lines = [header, separator]
        for row in data:
            vals = []
            for col in columns:
                val = str(row.get(col, ""))[:40]
                vals.append(val.ljust(widths[col]))
            lines.append(" | ".join(vals))

        if total > max_rows:
            lines.append(f"\n[Showing {max_rows} of {total} rows]")
        else:
            lines.append(f"\n{total} row{'s' if total != 1 else ''}")

        result = "\n".join(lines)
        if len(result) > 50_000:
            result = result[:50_000] + "\n[Truncated]"

        return ToolResult(success=True, content=result)

    async def shutdown(self):
        """Close the connection pool."""
        if self._pool:
            await self._pool.close()
            self._pool = None
