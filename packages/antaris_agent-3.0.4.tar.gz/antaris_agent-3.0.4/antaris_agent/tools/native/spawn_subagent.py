"""
SpawnSubagentTool — lets the LLM autonomously spawn a named subagent
to handle a parallel or background task.
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from .base import NativeTool, ToolResult

if TYPE_CHECKING:
    from antaris_agent.core.subagents import SubagentRegistry

logger = logging.getLogger(__name__)


class SpawnSubagentTool(NativeTool):
    """
    Tool that allows the LLM to spawn a named subagent for parallel/background work.
    The subagent runs an LLM call with the given task and posts results back to Discord.
    """

    def __init__(self, registry: "SubagentRegistry", origin_channel=None):
        self.registry = registry
        self.origin_channel = origin_channel  # updated per-message via set_active_channel()

    def set_active_channel(self, channel) -> None:
        """Update origin channel per inbound message — mirrors DiscordFileTool pattern."""
        self.origin_channel = channel

    @property
    def name(self) -> str:
        return "spawn_subagent"

    @property
    def description(self) -> str:
        return (
            "Spawn a background subagent to handle a task in parallel. "
            "The subagent runs independently and posts its result to Discord when done. "
            "Use this when a task would take a long time, needs to run in parallel with other work, "
            "or should be delegated to a focused worker. "
            "Returns immediately with the subagent name — results arrive later."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task for the subagent to complete. Be specific and detailed."
                },
                "name": {
                    "type": "string",
                    "description": "Optional name for the subagent (a-z). Auto-assigned if omitted."
                },
                "context": {
                    "type": "string",
                    "description": "Optional context to pass to the subagent (relevant background info)."
                }
            },
            "required": ["task"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        task = arguments.get("task", "").strip()
        name = arguments.get("name")
        context = arguments.get("context")

        if not task:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: task",
                is_error=True
            )

        if not self.registry:
            return ToolResult(
                success=False,
                content="",
                error="Subagent registry not available",
                is_error=True
            )

        # Commit 6: Extract parent session provenance from bot
        bot = getattr(self.registry, "bot", None)
        parent_user_id = getattr(bot, "_active_user_id", "") or ""
        parent_session_id = ""
        parent_agent_id = ""
        parent_body_id = ""
        if bot:
            cfg = getattr(bot, "config", None)
            if cfg:
                parent_agent_id = getattr(cfg, "identityId", "") or getattr(cfg, "agent_name", "") or ""
                parent_body_id = getattr(cfg, "bodyId", "") or ""
            # Session ID from the current active session
            parent_session_id = getattr(bot, "_active_session_id", "") or getattr(bot, "_current_session_id", "") or ""

        ok, msg = await self.registry.spawn(
            task=task,
            name=name,
            context=context,
            origin_channel=self.origin_channel,
            parent_user_id=parent_user_id,
            parent_session_id=parent_session_id,
            parent_agent_id=parent_agent_id,
            parent_body_id=parent_body_id,
        )

        return ToolResult(
            success=ok,
            content=msg,
            error="" if ok else msg,
            is_error=not ok
        )
