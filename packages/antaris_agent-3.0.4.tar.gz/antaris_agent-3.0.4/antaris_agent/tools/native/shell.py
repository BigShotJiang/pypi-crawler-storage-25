from __future__ import annotations

import asyncio
import logging
import os
import re
import shlex
from pathlib import Path

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

# ─── Security Mode Hierarchy ──────────────────────────────────────────────
#   open(0)      → blocklist only (defense-in-depth), full shell via exec()
#   standard(1)  → allowlist + interpreter block + path validation + exec()
#   sandboxed(2) → allowlist + interpreter block + path validation + exec()
#   secured(3)   → ALL commands require interactive approval (not yet wired)
#   encrypted(4) → ALL commands require interactive approval (not yet wired)
#
# The primary defense for standard+ is the ALLOWLIST.  The blocklist is kept
# as a secondary defense-in-depth layer for all modes.
# ──────────────────────────────────────────────────────────────────────────

# ─── Allowlist: commands permitted in standard+ modes ─────────────────────
# Only the base command name matters (argv[0] after PATH resolution).
# Extend this set as legitimate use-cases are identified.
ALLOWED_COMMANDS: set[str] = {
    # Navigation / inspection
    "ls", "dir", "find", "tree", "du", "df", "stat", "file", "wc",
    "head", "tail", "cat", "less", "more", "bat",
    # Text processing
    "grep", "rg", "awk", "sed", "sort", "uniq", "cut", "tr", "tee",
    "diff", "patch", "jq", "yq", "xargs", "column",
    # File management (safe subset)
    "cp", "mv", "mkdir", "touch", "ln", "realpath", "dirname", "basename",
    "tar", "zip", "unzip", "gzip", "gunzip", "bzip2", "xz",
    # Versioning
    "git",
    # Build / dev tooling
    "make", "cmake", "cargo", "go", "npm", "npx", "yarn", "pnpm",
    "pip", "pip3", "uv", "poetry", "pdm",
    "pytest", "deno", "bun",
    # Networking (read-only / fetch)
    "curl", "wget", "ping", "dig", "nslookup", "host", "traceroute",
    "ssh", "scp", "rsync",
    # System info
    "uname", "whoami", "id", "hostname", "date", "uptime", "env", "printenv",
    "which", "where", "type", "command",
    "ps", "top", "htop", "free", "lsof", "netstat", "ss",
    # Editors / pagers (non-interactive usage)
    "echo", "printf", "yes", "true", "false", "test", "[",
    # macOS specifics
    "open", "pbcopy", "pbpaste", "sw_vers", "defaults", "security",
    "diskutil", "mdls", "mdfind", "xattr", "ditto",
    # Antaris-specific
    "antaris",
    # Docker (read-only operations are common)
    "docker", "docker-compose",
    # Misc utilities
    "chmod", "chown", "trash", "rm",  # rm is allowed but path-validated
    "tput", "clear", "reset",
    "sleep", "timeout",
    "sha256sum", "sha1sum", "md5sum", "md5", "shasum",
    "base64", "xxd", "od", "hexdump",
}

# ─── Interpreter binaries that must NOT appear as arguments ───────────────
# In standard+ modes, shell interpreters are never allowed as argv[0] unless
# the overall shell security mode is OPEN. They are also blocked when they
# appear as arguments to another command, which is a classic injection vector.
# e.g. "find / -exec bash -c '...'" or "xargs python3 -c '...'"
INTERPRETER_NAMES: set[str] = {
    "python", "python2", "python3",
    "perl", "perl5",
    "ruby", "irb",
    "node", "deno", "bun",
    "sh", "bash", "zsh", "dash", "ksh", "csh", "tcsh", "fish",
    "lua", "luajit",
    "php",
    "pwsh", "powershell",
}

# ─── Defense-in-depth: blocklist patterns (substring match on lowercased cmd)
# Kept as a secondary layer.  NOT the primary guard.
BLOCKED_PATTERNS: list[str] = [
    "rm -rf /",
    "rm -rf ~",
    "rm -rf .",
    "mkfs",
    "dd if=",
    "> /dev/sd",
    "chmod -R 777",
    # Pipe-to-shell: catch any pipe into an interpreter
    # (covers curl/wget/cat/etc piped to bash/sh/python/etc)
    "|bash", "| bash",
    "|sh",   "| sh",
    "|python", "| python",
    "|perl",   "| perl",
    "|ruby",   "| ruby",
    "|node",   "| node",
    # Reverse shell patterns
    "/dev/tcp/",
    "/dev/udp/",
    "nc -e",
    "nc -c",
    "ncat -e",
    "ncat -c",
    # Filesystem destruction
    "find / -delete",
    "find / -exec rm",
    ":(){",              # fork bomb
    # Interpreter-wrapped destruction (defense in depth)
    "shutil.rmtree",
    "os.system",
    "os.popen",
    "subprocess.call",
    "subprocess.run",
    "subprocess.Popen",
    "__import__",
    "eval(",
    "exec(",
]

# ─── Commands that are logged with a warning ──────────────────────────────
SENSITIVE_PATTERNS: list[str] = [
    "scp ",
    "rsync ",
    "ssh ",
    "pip install",
    "pip uninstall",
    "npm install -g",
    "npm publish",
    "twine upload",
    "docker ",
    "launchctl ",
    "systemctl ",
    "crontab ",
    "chmod ",
    "chown ",
    "rm ",
    "git push",
    "git force",
]

# ─── Regex for dangerous shell metacharacters ─────────────────────────────
# In standard+ modes we use create_subprocess_exec, so shell interpretation
# is already eliminated.  This regex is an additional safety net that would
# catch attempts to sneak shell syntax into the raw command string.
_SHELL_METACHAR_RE = re.compile(
    r"[`$]"            # backtick or dollar (command/variable substitution)
    r"|>\s*/dev/"      # redirect to device files
    r"|\beval\b"       # eval keyword
    r"|\bsource\b"     # source keyword
)


def _resolve_base_command(argv0: str) -> str:
    """Extract the bare command name from a potentially path-qualified argv[0]."""
    return Path(argv0).name


def _is_path_within(target: Path, root: Path) -> bool:
    """Check if *target* is inside *root* using Path.relative_to."""
    try:
        target.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


class ShellTool(NativeTool):
    """Execute shell commands with layered security controls.

    Security layers (applied in order):
    1. Defense-in-depth blocklist (all modes)
    2. Allowlist gate (standard+ modes)
    3. Interpreter-as-argument block (standard+ modes)
    4. Path validation (standard+ modes)
    5. create_subprocess_exec instead of shell (standard+ modes)
    6. Interactive approval gate (secured+ modes — placeholder)
    """

    def __init__(
        self,
        workspace_path: str,
        timeout: int = 30,
        security_mode: str = "open",
    ):
        self.workspace_path = Path(workspace_path).resolve()
        self.default_timeout = timeout
        self.security_mode = security_mode

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute shell commands"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute",
                },
                "workdir": {
                    "type": "string",
                    "description": "Working directory (optional, defaults to workspace)",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (optional, defaults to 30)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 300,
                },
            },
            "required": ["command"],
        }

    # ── helpers ─────────────────────────────────────────────────────────

    def _is_restricted_mode(self) -> bool:
        """Return True when security mode is standard or above."""
        return self.security_mode in ("standard", "sandboxed", "secured", "encrypted")

    def _is_approval_required(self) -> bool:
        """Return True when interactive approval is required (secured+)."""
        return self.security_mode in ("secured", "encrypted")

    def _validate_workdir(self, workdir_str: str) -> tuple[bool, str, Path]:
        """Validate that working directory is within workspace."""
        try:
            workdir = (self.workspace_path / workdir_str).resolve()
            workspace_resolved = self.workspace_path.resolve()

            try:
                workdir.relative_to(workspace_resolved)
            except ValueError:
                return False, "Working directory outside workspace not allowed", workdir

            if not workdir.exists():
                return False, f"Working directory does not exist: {workdir}", workdir

            if not workdir.is_dir():
                return False, f"Working directory is not a directory: {workdir}", workdir

            return True, "", workdir
        except Exception as e:
            return False, f"Invalid working directory: {e}", Path()

    def _check_blocklist(self, command: str) -> str | None:
        """Check command against defense-in-depth blocklist.

        Returns the matched pattern string, or None if clean.
        """
        cmd_lower = command.lower().strip()
        # Also check with whitespace collapsed for pipe-to-shell evasion
        cmd_collapsed = re.sub(r"\s+", " ", cmd_lower)
        for pattern in BLOCKED_PATTERNS:
            if pattern in cmd_lower or pattern in cmd_collapsed:
                return pattern
        return None

    def _check_allowlist(self, argv: list[str]) -> str | None:
        """Validate the base command is in the allowlist.

        Returns an error message, or None if allowed.
        """
        if not argv:
            return "Empty command"

        base_cmd = _resolve_base_command(argv[0])

        if base_cmd not in ALLOWED_COMMANDS:
            return (
                f"Command '{base_cmd}' is not in the shell allowlist. "
                f"Security mode '{self.security_mode}' only permits pre-approved commands. "
                f"Contact the operator to add it to ALLOWED_COMMANDS if needed."
            )
        return None

    def _check_interpreter_injection(self, argv: list[str]) -> str | None:
        """Block interpreter binaries appearing as arguments to other commands.

        e.g. ``find / -exec bash -c 'evil'`` or ``xargs python3 -c 'payload'``

        Returns an error message, or None if clean.
        """
        if len(argv) < 2:
            return None

        base_cmd = _resolve_base_command(argv[0])

        # If the top-level command IS an interpreter, that's fine — the user
        # is explicitly running python3/node/etc.  We only block interpreters
        # appearing as *arguments* to non-interpreter commands.
        if base_cmd in INTERPRETER_NAMES:
            return None

        for arg in argv[1:]:
            arg_name = _resolve_base_command(arg)
            if arg_name in INTERPRETER_NAMES:
                return (
                    f"Interpreter '{arg_name}' detected as argument to '{base_cmd}'. "
                    f"This pattern (e.g. `find -exec bash`, `xargs python3`) is blocked "
                    f"in security mode '{self.security_mode}' to prevent injection."
                )
        return None

    def _check_path_args(self, argv: list[str]) -> str | None:
        """Validate that path-like arguments don't escape the workspace.

        Only enforced for commands that modify files (rm, mv, cp, chmod, chown).
        Read-only commands (cat, ls, head, etc.) are not path-restricted
        so the agent can inspect system files for debugging.

        Returns an error message, or None if all paths are acceptable.
        """
        # Commands whose path arguments are checked for workspace containment
        _path_restricted_commands = {"rm", "mv", "chmod", "chown"}

        if not argv:
            return None

        base_cmd = _resolve_base_command(argv[0])
        if base_cmd not in _path_restricted_commands:
            return None

        workspace = self.workspace_path
        home = Path.home().resolve()

        for arg in argv[1:]:
            # Skip flags
            if arg.startswith("-"):
                continue
            # Only check things that look like paths
            if "/" in arg or arg.startswith("~") or arg.startswith("."):
                try:
                    target = Path(arg).expanduser().resolve()
                except (ValueError, OSError):
                    continue

                # Allow paths within workspace or home
                if _is_path_within(target, workspace) or _is_path_within(target, home):
                    continue

                return (
                    f"Path '{arg}' resolves outside the workspace and home directory. "
                    f"Destructive commands are restricted to workspace and home in "
                    f"security mode '{self.security_mode}'."
                )
        return None

    def _safe_split(self, command: str) -> list[str] | None:
        """Split a command string into argv using shlex.

        Returns None if the command contains unterminated quotes or
        is otherwise unparseable.
        """
        try:
            return shlex.split(command)
        except ValueError:
            return None

    # ── main execute ────────────────────────────────────────────────────

    async def execute(self, arguments: dict) -> ToolResult:
        command = arguments.get("command")
        workdir_str = arguments.get("workdir", ".")
        timeout = arguments.get("timeout", self.default_timeout)

        if not command:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: command",
                is_error=True,
            )

        # ── Layer 1: Defense-in-depth blocklist (ALL modes) ─────────
        blocked_pattern = self._check_blocklist(command)
        if blocked_pattern:
            logger.warning("Shell tool BLOCKED dangerous command: %r (matched: %r)", command, blocked_pattern)
            return ToolResult(
                success=False,
                content="",
                error=f"Command blocked by security policy: matched blocked pattern '{blocked_pattern}'",
                is_error=True,
            )

        # ── Layer 2+: Restricted mode checks (standard and above) ──
        restricted = self._is_restricted_mode()

        if restricted:
            # Parse command into argv
            argv = self._safe_split(command)
            if argv is None:
                return ToolResult(
                    success=False,
                    content="",
                    error="Command contains unparseable syntax (unterminated quotes or invalid escapes).",
                    is_error=True,
                )
            if not argv:
                return ToolResult(
                    success=False,
                    content="",
                    error="Empty command after parsing.",
                    is_error=True,
                )

            # Layer 2a: Allowlist gate
            allowlist_err = self._check_allowlist(argv)
            if allowlist_err:
                logger.warning("Shell tool BLOCKED non-allowlisted command: %r", command)
                return ToolResult(
                    success=False,
                    content="",
                    error=allowlist_err,
                    is_error=True,
                )

            # Layer 2b: Interpreter injection check
            interp_err = self._check_interpreter_injection(argv)
            if interp_err:
                logger.warning("Shell tool BLOCKED interpreter injection: %r", command)
                return ToolResult(
                    success=False,
                    content="",
                    error=interp_err,
                    is_error=True,
                )

            # Layer 2c: Path validation for destructive commands
            path_err = self._check_path_args(argv)
            if path_err:
                logger.warning("Shell tool BLOCKED path escape: %r", command)
                return ToolResult(
                    success=False,
                    content="",
                    error=path_err,
                    is_error=True,
                )

        # ── Layer 3: Approval gate (secured+ modes) ────────────────
        if self._is_approval_required():
            # TODO: Wire into the interactive approval system when available.
            # For now, block with an informative message.
            logger.warning(
                "Shell tool requires approval in '%s' mode: %r",
                self.security_mode, command,
            )
            return ToolResult(
                success=False,
                content="",
                error=(
                    f"Security mode '{self.security_mode}' requires interactive approval "
                    f"for all shell commands. Approval system not yet wired — command blocked. "
                    f"Lower security mode to 'sandboxed' or 'standard' to allow execution."
                ),
                is_error=True,
            )

        # Log sensitive commands with warning (all modes)
        cmd_lower = command.lower().strip()
        for pattern in SENSITIVE_PATTERNS:
            if pattern in cmd_lower:
                logger.warning("Shell tool executing SENSITIVE command: %r", command)
                break

        # ── Validate working directory ──────────────────────────────
        is_valid, error_msg, workdir = self._validate_workdir(workdir_str)
        if not is_valid:
            return ToolResult(
                success=False,
                content="",
                error=error_msg,
                is_error=True,
            )

        # ── Defensive timeout validation ────────────────────────────
        try:
            timeout = int(timeout)
        except (TypeError, ValueError):
            timeout = self.default_timeout
        timeout = max(1, min(300, timeout))

        logger.info(
            "Shell tool executing: command=%r workdir=%s timeout=%d mode=%s",
            command, workdir, timeout, self.security_mode,
        )

        try:
            # ── Subprocess creation ─────────────────────────────────
            if restricted:
                # standard+ modes: use create_subprocess_exec (no shell interpretation)
                # argv was already parsed above
                process = await asyncio.create_subprocess_exec(
                    *argv,
                    cwd=workdir,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                    limit=1024 * 1024,  # 1MB buffer limit
                )
            else:
                # open mode: preserve full shell for backwards compatibility
                process = await asyncio.create_subprocess_shell(
                    command,
                    cwd=workdir,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                    limit=1024 * 1024,
                )

            # Wait for completion with timeout
            try:
                stdout, _ = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout,
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                process.kill()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    logger.error("Timed out waiting for killed process to exit: %r", command)
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Command timed out after {timeout} seconds",
                    is_error=True,
                )

            # Decode output
            output = stdout.decode("utf-8", errors="replace") if stdout else ""

            # Truncate if too long (100KB limit)
            if len(output) > 102400:
                output = output[:102400] + "\n\n[Output truncated at 100KB...]"

            # Prepare result content
            result_content = f"Command: {command}\n"
            result_content += f"Working directory: {workdir}\n"
            result_content += f"Exit code: {exit_code}\n\n"
            result_content += "Output:\n" + output

            success = exit_code == 0

            logger.info(
                "Shell tool completed: command=%r exit_code=%d output_bytes=%d",
                command, exit_code, len(output),
            )

            return ToolResult(
                success=success,
                content=result_content,
                error=None if success else f"Command failed with exit code {exit_code}",
                is_error=not success,
            )

        except FileNotFoundError:
            return ToolResult(
                success=False,
                content="",
                error="Shell command not found or not executable",
                is_error=True,
            )
        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied executing command",
                is_error=True,
            )
        except Exception as e:
            logger.exception("Unexpected error in shell execution")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True,
            )
