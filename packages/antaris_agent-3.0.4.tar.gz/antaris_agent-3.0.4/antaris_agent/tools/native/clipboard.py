"""
Clipboard Tool — Read and write the macOS system clipboard.

Operations:
  read   — Get current clipboard contents
  write  — Set clipboard contents

Uses pbcopy/pbpaste (macOS native). Falls back to xclip on Linux.

Drop into: antaris_agent/tools/native/clipboard.py
"""

from __future__ import annotations

import asyncio
import logging
import platform
import sys
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class ClipboardTool(NativeTool):
    """Read and write the system clipboard."""

    @property
    def name(self) -> str:
        return "clipboard"

    @property
    def description(self) -> str:
        return (
            "Read or write the system clipboard. "
            "Use 'read' to get what was just copied, "
            "'write' to put text on the clipboard for pasting."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Clipboard operation",
                    "enum": ["read", "write"],
                },
                "text": {
                    "type": "string",
                    "description": "Text to write to clipboard (required for 'write')",
                },
            },
            "required": ["operation"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")

        try:
            if operation == "read":
                return await self._read()
            elif operation == "write":
                text = arguments.get("text", "")
                if not text:
                    return ToolResult(
                        success=False, content="",
                        error="'text' is required for write operation",
                        is_error=True,
                    )
                return await self._write(text)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}. Use 'read' or 'write'.",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Clipboard tool error")
            return ToolResult(
                success=False, content="",
                error=f"Clipboard error: {e}",
                is_error=True,
            )

    async def _read(self) -> ToolResult:
        """Read current clipboard contents."""
        cmd = self._paste_cmd()
        if not cmd:
            return ToolResult(
                success=False, content="",
                error="Clipboard not supported on this platform",
                is_error=True,
            )

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=5)

        if proc.returncode != 0:
            return ToolResult(
                success=False, content="",
                error=f"Failed to read clipboard: {stderr.decode('utf-8', errors='replace')}",
                is_error=True,
            )

        content = stdout.decode("utf-8", errors="replace")

        if not content:
            return ToolResult(success=True, content="(clipboard is empty)")

        # Truncate very large clipboard contents
        if len(content) > 50000:
            content = content[:50000] + "\n\n[Truncated at 50KB]"

        return ToolResult(success=True, content=content)

    async def _write(self, text: str) -> ToolResult:
        """Write text to the clipboard."""
        cmd = self._copy_cmd()
        if not cmd:
            return ToolResult(
                success=False, content="",
                error="Clipboard not supported on this platform",
                is_error=True,
            )

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(
            proc.communicate(input=text.encode("utf-8")),
            timeout=5,
        )

        if proc.returncode != 0:
            return ToolResult(
                success=False, content="",
                error=f"Failed to write clipboard: {stderr.decode('utf-8', errors='replace')}",
                is_error=True,
            )

        return ToolResult(
            success=True,
            content=f"Copied {len(text)} characters to clipboard.",
        )

    @staticmethod
    def _paste_cmd() -> list[str] | None:
        system = platform.system()
        if system == "Darwin":
            return ["pbpaste"]
        elif system == "Linux":
            return ["xclip", "-selection", "clipboard", "-o"]
        return None

    @staticmethod
    def _copy_cmd() -> list[str] | None:
        system = platform.system()
        if system == "Darwin":
            return ["pbcopy"]
        elif system == "Linux":
            return ["xclip", "-selection", "clipboard", "-i"]
        return None
