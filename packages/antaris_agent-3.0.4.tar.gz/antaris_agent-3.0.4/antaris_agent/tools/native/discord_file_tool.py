"""Discord file attachment tool.

Sends a file attachment to a Discord channel.  The bot must be connected to
Discord for this tool to work.  If no channel_id is given, the tool sends to
the channel the most-recent inbound message came from.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    import discord

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class DiscordFileTool(NativeTool):
    """Native tool: send a file attachment to Discord."""

    def __init__(self, discord_client: Optional["discord.Client"] = None):
        self.discord_client = discord_client
        self._active_channel_id: Optional[str] = None  # set by the bot on each inbound message

    def set_discord_client(self, client: "discord.Client") -> None:
        """Inject the live Discord client (called after on_ready)."""
        self.discord_client = client

    def set_active_channel(self, channel_id: str) -> None:
        """Track the channel the most-recent inbound message came from."""
        self._active_channel_id = channel_id

    # ── NativeTool interface ──────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "discord_send_file"

    @property
    def description(self) -> str:
        return (
            "Send a file attachment to Discord. "
            "Use for sharing images, documents, CSVs, PDFs, and any other files. "
            "If channel_id is omitted the file is sent to the current conversation channel."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Absolute or workspace-relative path to the file to send.",
                },
                "channel_id": {
                    "type": "string",
                    "description": (
                        "Discord channel ID to send the file to. "
                        "Omit to use the current conversation channel."
                    ),
                },
                "caption": {
                    "type": "string",
                    "description": "Optional text caption to accompany the file.",
                },
            },
            "required": ["file_path"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        import discord  # deferred — only needed at runtime

        file_path_str: str = arguments.get("file_path", "").strip()
        channel_id: Optional[str] = arguments.get("channel_id") or self._active_channel_id
        caption: Optional[str] = arguments.get("caption")

        # ── Validation ────────────────────────────────────────────────────
        if not file_path_str:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: file_path",
                is_error=True,
            )

        file_path = Path(file_path_str).expanduser().resolve()
        if not file_path.exists():
            return ToolResult(
                success=False,
                content="",
                error=f"File not found: {file_path}",
                is_error=True,
            )
        if not file_path.is_file():
            return ToolResult(
                success=False,
                content="",
                error=f"Path is not a file: {file_path}",
                is_error=True,
            )

        if not channel_id:
            return ToolResult(
                success=False,
                content="",
                error=(
                    "No channel_id provided and no active Discord channel available. "
                    "Please pass channel_id explicitly."
                ),
                is_error=True,
            )

        if not self.discord_client:
            return ToolResult(
                success=False,
                content="",
                error="Discord client not available — is the Discord channel connected?",
                is_error=True,
            )

        # ── Resolve channel ───────────────────────────────────────────────
        try:
            channel = self.discord_client.get_channel(int(channel_id))
            if channel is None:
                channel = await self.discord_client.fetch_channel(int(channel_id))
        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Could not resolve Discord channel {channel_id}: {e}",
                is_error=True,
            )

        if not isinstance(
            channel,
            (discord.TextChannel, discord.DMChannel, discord.Thread),
        ):
            return ToolResult(
                success=False,
                content="",
                error=f"Channel {channel_id} is not a text channel (type: {type(channel).__name__})",
                is_error=True,
            )

        # ── Send ──────────────────────────────────────────────────────────
        try:
            with open(file_path, "rb") as fp:
                discord_file = discord.File(fp, filename=file_path.name)
                sent = await channel.send(
                    content=caption if caption else None,
                    file=discord_file,
                )
        except discord.Forbidden:
            return ToolResult(
                success=False,
                content="",
                error=f"No permission to send files in channel {channel_id}",
                is_error=True,
            )
        except discord.HTTPException as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Discord API error while sending file: {e}",
                is_error=True,
            )
        except Exception as e:
            logger.exception("Unexpected error in DiscordFileTool.execute")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True,
            )

        channel_name = getattr(channel, "name", "DM")
        summary = (
            f"✅ File sent to Discord\n"
            f"Channel: #{channel_name} ({channel_id})\n"
            f"File: {file_path.name} ({file_path.stat().st_size:,} bytes)\n"
            f"Message ID: {sent.id}"
        )
        if caption:
            summary += f"\nCaption: {caption[:120]}{'…' if len(caption) > 120 else ''}"

        logger.info(
            "Discord file sent: channel=%s file=%s message_id=%s",
            channel_id,
            file_path.name,
            sent.id,
        )
        return ToolResult(success=True, content=summary)
