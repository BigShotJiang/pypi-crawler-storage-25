"""
Cron Scheduler Tool — First-class scheduling for the agent.

Lets the LLM create, list, delete, enable/disable, and trigger
scheduled tasks during conversation. Wraps the CronScheduler from
core/cron.py.

Operations:
  create   — Create a new scheduled job (every/at/cron)
  list     — List all jobs with status
  delete   — Remove a job by ID
  enable   — Enable a disabled job
  disable  — Disable a job without deleting it
  trigger  — Fire a job immediately (next tick)
  status   — Get detailed status of a specific job

Drop into: antaris_agent/tools/native/cron_tool.py

Wire in bot.py:
    from antaris_agent.tools.native.cron_tool import CronTool
    cron_tool = CronTool(bot.cron_scheduler)
    await tool_registry.register_native("cron", cron_tool)
"""

from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from antaris_agent.core.cron import DEFAULT_AGENT_TURN_RESTRICTED_TOOLS
from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class CronTool(NativeTool):
    REQUIRE_OWNER_APPROVAL_MSG = (
        "Creating cron jobs with payload_kind='agentTurn' requires explicit owner approval. "
        "Use a human-owned command path, or re-create this as payload_kind='systemEvent'."
    )
    """Scheduling tool that wraps CronScheduler for LLM access.

    Args:
        scheduler: The CronScheduler instance from the bot.
        default_tz: Default timezone for new jobs (e.g. "America/Los_Angeles").
        default_channel_id: Default channel for delivery.
    """

    def __init__(self, scheduler, default_tz: str = "America/Los_Angeles",
                 default_channel_id: str = ""):
        self._scheduler = scheduler
        self._default_tz = default_tz
        self._default_channel_id = default_channel_id

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Create, list, delete, and manage scheduled tasks. "
            "Use this for reminders, periodic checks, recurring reports, "
            "or any task that should run on a schedule. "
            "Supports one-time (at), recurring interval (every), and "
            "cron expression scheduling."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Scheduling operation to perform",
                    "enum": ["create", "list", "delete", "enable", "disable", "trigger", "status"],
                },
                "job_name": {
                    "type": "string",
                    "description": (
                        "Human-readable name for the job (required for 'create'). "
                        "Example: 'morning standup reminder'"
                    ),
                },
                "schedule_kind": {
                    "type": "string",
                    "description": (
                        "Schedule type (required for 'create'): "
                        "'every' for interval, 'at' for one-time, 'cron' for cron expression"
                    ),
                    "enum": ["every", "at", "cron"],
                },
                "interval_minutes": {
                    "type": "number",
                    "description": (
                        "Interval in minutes (for 'every' schedule). "
                        "Example: 60 for hourly, 1440 for daily"
                    ),
                },
                "at_time": {
                    "type": "string",
                    "description": (
                        "ISO datetime for one-time job (for 'at' schedule). "
                        "Example: '2026-04-06T15:00:00'"
                    ),
                },
                "cron_expression": {
                    "type": "string",
                    "description": (
                        "5-field cron expression (for 'cron' schedule). "
                        "Fields: minute hour day_of_month month day_of_week. "
                        "Examples: '0 9 * * 1-5' (weekdays 9am), '*/30 * * * *' (every 30min)"
                    ),
                },
                "timezone": {
                    "type": "string",
                    "description": (
                        "IANA timezone for the schedule. "
                        "Default: America/Los_Angeles"
                    ),
                },
                "payload": {
                    "type": "string",
                    "description": (
                        "The text/prompt to execute when the job fires. "
                        "For 'agentTurn': sent as if the user typed it. "
                        "For 'systemEvent': injected as system context."
                    ),
                },
                "payload_kind": {
                    "type": "string",
                    "description": (
                        "How the payload is delivered: "
                        "'agentTurn' (fires through full pipeline as user message) or "
                        "'systemEvent' (injected as system prompt context). "
                        "Default: agentTurn"
                    ),
                    "enum": ["agentTurn", "systemEvent"],
                },
                "delete_after_run": {
                    "type": "boolean",
                    "description": "Auto-delete after successful execution (default: false for recurring, true for one-time)",
                },
                "job_id": {
                    "type": "string",
                    "description": "Job ID (required for delete, enable, disable, trigger, status)",
                },
                "channel_id": {
                    "type": "string",
                    "description": "Channel to deliver the job output to",
                },
                "restricted_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Tool denylist enforced when an 'agentTurn' cron fires. "
                        "If omitted for agentTurn, safe defaults are applied."
                    ),
                },
                "owner_approved": {
                    "type": "boolean",
                    "description": "Human approval flag required for creating 'agentTurn' cron jobs.",
                },
            },
            "required": ["operation"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")

        try:
            if operation == "create":
                return self._create(arguments)
            elif operation == "list":
                return self._list()
            elif operation == "delete":
                return self._delete(arguments)
            elif operation == "enable":
                return self._set_enabled(arguments, True)
            elif operation == "disable":
                return self._set_enabled(arguments, False)
            elif operation == "trigger":
                return self._trigger(arguments)
            elif operation == "status":
                return self._status(arguments)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Cron tool error: operation=%s", operation)
            return ToolResult(
                success=False, content="",
                error=f"Cron operation failed: {e}",
                is_error=True,
            )

    def _create(self, args: dict) -> ToolResult:
        """Create a new scheduled job."""
        from antaris_agent.core.cron import CronJob

        job_name = args.get("job_name", "")
        if not job_name:
            return ToolResult(
                success=False, content="",
                error="'job_name' is required for create",
                is_error=True,
            )

        schedule_kind = args.get("schedule_kind", "")
        if schedule_kind not in ("every", "at", "cron"):
            return ToolResult(
                success=False, content="",
                error="'schedule_kind' must be 'every', 'at', or 'cron'",
                is_error=True,
            )

        payload = args.get("payload", "")
        if not payload:
            return ToolResult(
                success=False, content="",
                error="'payload' is required — the text/prompt to execute",
                is_error=True,
            )

        job_id = str(uuid.uuid4())[:8]
        tz = args.get("timezone", self._default_tz)
        payload_kind = args.get("payload_kind", "agentTurn")
        channel_id = args.get("channel_id", self._default_channel_id)
        restricted_tools = args.get("restricted_tools")

        if payload_kind == "agentTurn":
            if args.get("owner_approved") is not True:
                return ToolResult(
                    success=False, content="",
                    error=self.REQUIRE_OWNER_APPROVAL_MSG,
                    is_error=True,
                )
            if not restricted_tools:
                restricted_tools = list(DEFAULT_AGENT_TURN_RESTRICTED_TOOLS)
        else:
            restricted_tools = [] if restricted_tools is None else restricted_tools

        if not isinstance(restricted_tools, list) or any(not isinstance(t, str) or not t.strip() for t in restricted_tools):
            return ToolResult(
                success=False, content="",
                error="'restricted_tools' must be an array of non-empty tool names",
                is_error=True,
            )

        kwargs = {
            "id": job_id,
            "name": job_name,
            "schedule_kind": schedule_kind,
            "schedule_tz": tz,
            "payload_kind": payload_kind,
            "payload_text": payload,
            "restricted_tools": restricted_tools,
            "channel_id": channel_id,
            "enabled": True,
        }

        if schedule_kind == "every":
            minutes = args.get("interval_minutes")
            if not minutes or float(minutes) <= 0:
                return ToolResult(
                    success=False, content="",
                    error="'interval_minutes' is required for 'every' schedule",
                    is_error=True,
                )
            kwargs["schedule_every_ms"] = int(float(minutes) * 60 * 1000)
            kwargs["delete_after_run"] = args.get("delete_after_run", False)
            schedule_desc = f"every {minutes} minutes"

        elif schedule_kind == "at":
            at_time = args.get("at_time", "")
            if not at_time:
                return ToolResult(
                    success=False, content="",
                    error="'at_time' is required for 'at' schedule (ISO datetime)",
                    is_error=True,
                )
            kwargs["schedule_at"] = at_time
            kwargs["delete_after_run"] = args.get("delete_after_run", True)
            schedule_desc = f"once at {at_time}"

        elif schedule_kind == "cron":
            cron_expr = args.get("cron_expression", "")
            if not cron_expr:
                return ToolResult(
                    success=False, content="",
                    error="'cron_expression' is required for 'cron' schedule",
                    is_error=True,
                )
            # Basic validation
            if len(cron_expr.split()) != 5:
                return ToolResult(
                    success=False, content="",
                    error=f"Cron expression must have 5 fields (got {len(cron_expr.split())}): minute hour day month weekday",
                    is_error=True,
                )
            kwargs["schedule_cron"] = cron_expr
            kwargs["delete_after_run"] = args.get("delete_after_run", False)
            schedule_desc = f"cron: {cron_expr} ({tz})"

        job = CronJob(**kwargs)
        self._scheduler.add_job(job)

        return ToolResult(
            success=True,
            content=(
                f"Created job '{job_name}'\n"
                f"  ID: {job_id}\n"
                f"  Schedule: {schedule_desc}\n"
                f"  Payload: {payload_kind} — {payload[:100]}\n"
                f"  Restricted tools: {', '.join(restricted_tools) if restricted_tools else '(none)'}\n"
                f"  Channel: {channel_id or '(default)'}"
            ),
        )

    def _list(self) -> ToolResult:
        """List all scheduled jobs."""
        jobs = self._scheduler.list_jobs()

        if not jobs:
            return ToolResult(success=True, content="No scheduled jobs.")

        lines = [f"{len(jobs)} scheduled jobs:\n"]
        for j in jobs:
            status_icon = "on" if j.enabled else "off"
            schedule = ""
            if j.schedule_kind == "every" and j.schedule_every_ms:
                mins = j.schedule_every_ms / 60000
                schedule = f"every {mins:.0f}m"
            elif j.schedule_kind == "at":
                schedule = f"at {j.schedule_at or '?'}"
            elif j.schedule_kind == "cron":
                schedule = f"cron: {j.schedule_cron or '?'}"

            last = ""
            if j.last_run:
                ago = int(time.time() - j.last_run)
                if ago < 60:
                    last = f"{ago}s ago"
                elif ago < 3600:
                    last = f"{ago // 60}m ago"
                else:
                    last = f"{ago // 3600}h ago"

            error = ""
            if j.last_error:
                error = f" [ERROR: {j.last_error[:60]}]"

            lines.append(
                f"  [{status_icon}] {j.id} — {j.name}\n"
                f"      {schedule} | runs: {j.run_count} | last: {last or 'never'}{error}"
            )

        return ToolResult(success=True, content="\n".join(lines))

    def _delete(self, args: dict) -> ToolResult:
        """Delete a job by ID."""
        job_id = args.get("job_id", "")
        if not job_id:
            return ToolResult(
                success=False, content="",
                error="'job_id' is required for delete",
                is_error=True,
            )

        job = self._scheduler.get_job(job_id)
        if not job:
            return ToolResult(
                success=False, content="",
                error=f"No job found with ID '{job_id}'",
                is_error=True,
            )

        name = job.name
        self._scheduler.remove_job(job_id)
        return ToolResult(success=True, content=f"Deleted job '{name}' ({job_id})")

    def _set_enabled(self, args: dict, enabled: bool) -> ToolResult:
        """Enable or disable a job."""
        job_id = args.get("job_id", "")
        if not job_id:
            return ToolResult(
                success=False, content="",
                error="'job_id' is required",
                is_error=True,
            )

        job = self._scheduler.get_job(job_id)
        if not job:
            return ToolResult(
                success=False, content="",
                error=f"No job found with ID '{job_id}'",
                is_error=True,
            )

        job.enabled = enabled
        self._scheduler._save()

        action = "Enabled" if enabled else "Disabled"
        return ToolResult(success=True, content=f"{action} job '{job.name}' ({job_id})")

    def _trigger(self, args: dict) -> ToolResult:
        """Trigger a job to run on the next tick."""
        job_id = args.get("job_id", "")
        if not job_id:
            return ToolResult(
                success=False, content="",
                error="'job_id' is required for trigger",
                is_error=True,
            )

        if self._scheduler.run_now(job_id):
            job = self._scheduler.get_job(job_id)
            name = job.name if job else job_id
            return ToolResult(success=True, content=f"Triggered job '{name}' — will fire on next tick (~10s)")
        else:
            return ToolResult(
                success=False, content="",
                error=f"Could not trigger job '{job_id}' — not found or is a spent one-shot job",
                is_error=True,
            )

    def _status(self, args: dict) -> ToolResult:
        """Get detailed status of a specific job."""
        job_id = args.get("job_id", "")
        if not job_id:
            return ToolResult(
                success=False, content="",
                error="'job_id' is required for status",
                is_error=True,
            )

        job = self._scheduler.get_job(job_id)
        if not job:
            return ToolResult(
                success=False, content="",
                error=f"No job found with ID '{job_id}'",
                is_error=True,
            )

        lines = [
            f"Job: {job.name} ({job.id})",
            f"  Enabled: {job.enabled}",
            f"  Status: {job.status}",
            f"  Schedule: {job.schedule_kind}",
        ]

        if job.schedule_kind == "every" and job.schedule_every_ms:
            lines.append(f"    Interval: {job.schedule_every_ms / 60000:.1f} minutes")
        elif job.schedule_kind == "at":
            lines.append(f"    At: {job.schedule_at}")
        elif job.schedule_kind == "cron":
            lines.append(f"    Expression: {job.schedule_cron}")
            lines.append(f"    Timezone: {job.schedule_tz or '(default)'}")

        lines.append(f"  Payload: {job.payload_kind}")
        lines.append(f"    Text: {job.payload_text[:200]}")
        lines.append(f"    Restricted tools: {', '.join(job.restricted_tools) if job.restricted_tools else '(none)'}")
        lines.append(f"  Run count: {job.run_count}")
        lines.append(f"  Consecutive errors: {job.consecutive_errors}")

        if job.last_run:
            from datetime import datetime as dt
            last_dt = dt.fromtimestamp(job.last_run).isoformat()
            lines.append(f"  Last run: {last_dt}")
        if job.last_success:
            from datetime import datetime as dt
            succ_dt = dt.fromtimestamp(job.last_success).isoformat()
            lines.append(f"  Last success: {succ_dt}")
        if job.last_error:
            lines.append(f"  Last error: {job.last_error}")
        if job.last_duration_ms is not None:
            lines.append(f"  Last duration: {job.last_duration_ms}ms")

        lines.append(f"  Delete after run: {job.delete_after_run}")
        lines.append(f"  Channel: {job.channel_id or '(default)'}")

        return ToolResult(success=True, content="\n".join(lines))
