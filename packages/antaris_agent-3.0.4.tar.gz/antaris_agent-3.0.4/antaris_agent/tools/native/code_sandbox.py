"""
Code Execution Sandbox — Run code snippets in isolation.

Runs Python or JavaScript code in a subprocess with:
  - Separate working directory (temp dir, cleaned up after)
  - Timeout enforcement
  - Output capture (stdout + stderr)
  - No access to the bot's workspace or config

This is distinct from the shell tool: shell is for system commands
within the workspace, sandbox is for throwaway code execution.

Drop into: antaris_agent/tools/native/code_sandbox.py
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class CodeSandboxTool(NativeTool):
    """Execute code snippets in an isolated environment."""

    def __init__(self, timeout: int = 30, max_output: int = 100_000):
        self._timeout = timeout
        self._max_output = max_output

    @property
    def name(self) -> str:
        return "code_sandbox"

    @property
    def description(self) -> str:
        return (
            "Execute Python or JavaScript code snippets in an isolated sandbox. "
            "Use this for calculations, data processing, testing logic, "
            "or any throwaway code that doesn't need workspace access. "
            "Output (stdout + stderr) is captured and returned."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "language": {
                    "type": "string",
                    "description": "Programming language",
                    "enum": ["python", "javascript"],
                },
                "code": {
                    "type": "string",
                    "description": "Code to execute",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Execution timeout in seconds (default: 30, max: 120)",
                    "default": 30,
                },
            },
            "required": ["language", "code"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        language = arguments.get("language", "")
        code = arguments.get("code", "")
        timeout = min(arguments.get("timeout", self._timeout), 120)

        if not code.strip():
            return ToolResult(
                success=False, content="",
                error="No code provided",
                is_error=True,
            )

        if language == "python":
            return await self._run_python(code, timeout)
        elif language == "javascript":
            return await self._run_javascript(code, timeout)
        else:
            return ToolResult(
                success=False, content="",
                error=f"Unsupported language: {language}. Use 'python' or 'javascript'.",
                is_error=True,
            )

    async def _run_python(self, code: str, timeout: int) -> ToolResult:
        """Execute Python code in a subprocess."""
        with tempfile.TemporaryDirectory(prefix="antaris_sandbox_") as tmpdir:
            script_path = Path(tmpdir) / "script.py"
            script_path.write_text(code, encoding="utf-8")

            proc = await asyncio.create_subprocess_exec(
                "python3", str(script_path),
                cwd=tmpdir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self._sandbox_env(tmpdir),
                limit=1024 * 1024,
            )

            return await self._collect_output(proc, timeout, "Python")

    async def _run_javascript(self, code: str, timeout: int) -> ToolResult:
        """Execute JavaScript code via Node.js."""
        with tempfile.TemporaryDirectory(prefix="antaris_sandbox_") as tmpdir:
            script_path = Path(tmpdir) / "script.js"
            script_path.write_text(code, encoding="utf-8")

            # Try node first, fall back to bun
            runtime = "node"
            try:
                proc_check = await asyncio.create_subprocess_exec(
                    "node", "--version",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc_check.communicate()
                if proc_check.returncode != 0:
                    runtime = "bun"
            except FileNotFoundError:
                runtime = "bun"

            proc = await asyncio.create_subprocess_exec(
                runtime, str(script_path),
                cwd=tmpdir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self._sandbox_env(tmpdir),
                limit=1024 * 1024,
            )

            return await self._collect_output(proc, timeout, f"JavaScript ({runtime})")

    async def _collect_output(self, proc, timeout: int, lang_label: str) -> ToolResult:
        """Collect subprocess output with timeout."""
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                pass
            return ToolResult(
                success=False, content="",
                error=f"{lang_label} execution timed out after {timeout}s",
                is_error=True,
            )

        out = stdout.decode("utf-8", errors="replace") if stdout else ""
        err = stderr.decode("utf-8", errors="replace") if stderr else ""
        exit_code = proc.returncode

        # Truncate large output
        if len(out) > self._max_output:
            out = out[:self._max_output] + "\n[Output truncated]"
        if len(err) > self._max_output:
            err = err[:self._max_output] + "\n[Stderr truncated]"

        parts = [f"Exit code: {exit_code}"]
        if out.strip():
            parts.append(f"\nOutput:\n{out}")
        if err.strip():
            parts.append(f"\nStderr:\n{err}")

        content = "\n".join(parts)

        return ToolResult(
            success=(exit_code == 0),
            content=content,
            error=f"{lang_label} exited with code {exit_code}" if exit_code != 0 else None,
            is_error=(exit_code != 0),
        )

    @staticmethod
    def _sandbox_env(tmpdir: str) -> dict:
        """Build a restricted environment for the sandbox subprocess."""
        env = dict(os.environ)
        # Override HOME and TMPDIR to isolate from user config
        env["HOME"] = tmpdir
        env["TMPDIR"] = tmpdir
        # Remove sensitive vars
        for key in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "ANTARIS_LLM_API_KEY",
                     "AWS_SECRET_ACCESS_KEY", "GITHUB_TOKEN", "SUPABASE_KEY"):
            env.pop(key, None)
        return env
