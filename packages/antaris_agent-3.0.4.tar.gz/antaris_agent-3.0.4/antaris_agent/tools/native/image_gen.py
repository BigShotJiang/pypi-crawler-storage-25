"""
Image Generation Tool — Imagen 3 via Google Vertex AI.

Operations:
  generate  — Generate an image from a text prompt

Authentication:
  Uses Google Cloud Application Default Credentials (ADC).
  Either:
    1. Set GOOGLE_APPLICATION_CREDENTIALS env var to a service account JSON
    2. Run `gcloud auth application-default login`
    3. Pass credentials_path in config

Dependencies: google-cloud-aiplatform (pip install google-cloud-aiplatform)

Drop into: antaris_agent/tools/native/image_gen.py

Config (tools_config):
    "image_gen": {
        "enabled": true,
        "project_id": "your-gcp-project-id",
        "location": "us-central1",
        "model": "imagen-3.0-generate-002",
        "default_size": "1024x1024",
        "credentials_path": ""
    }
"""

from __future__ import annotations

import base64
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class ImageGenTool(NativeTool):
    """Generate images via Google Imagen 3 (Vertex AI)."""

    def __init__(
        self,
        project_id: str = "",
        location: str = "us-central1",
        model: str = "imagen-3.0-generate-002",
        default_size: str = "1024x1024",
        credentials_path: str = "",
        output_dir: str = "",
    ):
        self._project_id = project_id or os.environ.get("GOOGLE_CLOUD_PROJECT", "")
        self._location = location
        self._model = model
        self._default_size = default_size
        self._output_dir = Path(output_dir) if output_dir else Path.cwd()

        # Set credentials if provided
        if credentials_path and os.path.exists(credentials_path):
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path

    @property
    def name(self) -> str:
        return "image_gen"

    @property
    def description(self) -> str:
        return (
            f"Generate images from text prompts using Google Imagen 3. "
            "Provide a detailed description and get back a generated image. "
            "Supports different sizes and aspect ratios."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": (
                        "Detailed description of the image to generate. "
                        "Be specific about style, composition, colors, lighting, "
                        "and subject matter."
                    ),
                },
                "negative_prompt": {
                    "type": "string",
                    "description": (
                        "What to avoid in the image. "
                        "Example: 'blurry, low quality, text, watermark'"
                    ),
                },
                "size": {
                    "type": "string",
                    "description": "Image size/aspect ratio",
                    "enum": [
                        "1024x1024",   # 1:1
                        "1024x768",    # 4:3 landscape
                        "768x1024",    # 3:4 portrait
                        "1280x768",    # 5:3 wide landscape
                        "768x1280",    # 3:5 tall portrait
                        "1536x640",    # ultra-wide
                        "640x1536",    # ultra-tall
                    ],
                    "default": "1024x1024",
                },
                "count": {
                    "type": "integer",
                    "description": "Number of images to generate (1-4, default: 1)",
                    "default": 1,
                    "minimum": 1,
                    "maximum": 4,
                },
                "output_filename": {
                    "type": "string",
                    "description": "Filename to save the image as (default: auto-generated)",
                },
                "seed": {
                    "type": "integer",
                    "description": "Random seed for reproducibility (optional)",
                },
                "guidance_scale": {
                    "type": "number",
                    "description": "How closely to follow the prompt (1-30, default: model default)",
                },
            },
            "required": ["prompt"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        prompt = arguments.get("prompt", "")
        if not prompt:
            return ToolResult(
                success=False, content="",
                error="'prompt' is required",
                is_error=True,
            )

        if not self._project_id:
            return ToolResult(
                success=False, content="",
                error=(
                    "Google Cloud project_id not configured. "
                    "Set 'project_id' in tools config or GOOGLE_CLOUD_PROJECT env var."
                ),
                is_error=True,
            )

        return await self._generate(arguments)

    async def _generate(self, args: dict) -> ToolResult:
        """Generate images via Vertex AI Imagen 3."""
        try:
            from google.cloud import aiplatform
            from vertexai.preview.vision_models import ImageGenerationModel
        except ImportError:
            return ToolResult(
                success=False, content="",
                error=(
                    "google-cloud-aiplatform not installed. "
                    "Run: pip install google-cloud-aiplatform"
                ),
                is_error=True,
            )

        prompt = args.get("prompt", "")
        negative_prompt = args.get("negative_prompt", "")
        size = args.get("size", self._default_size)
        count = min(max(args.get("count", 1), 1), 4)
        seed = args.get("seed")
        guidance_scale = args.get("guidance_scale")
        output_filename = args.get("output_filename", "")

        # Parse size
        try:
            width, height = [int(x) for x in size.split("x")]
        except (ValueError, AttributeError):
            width, height = 1024, 1024

        # Determine aspect ratio string for the API
        aspect_ratio = self._get_aspect_ratio(width, height)

        try:
            # Initialize Vertex AI
            aiplatform.init(
                project=self._project_id,
                location=self._location,
            )

            # Load the model
            model = ImageGenerationModel.from_pretrained(self._model)

            # Build generation parameters
            gen_kwargs = {
                "prompt": prompt,
                "number_of_images": count,
                "aspect_ratio": aspect_ratio,
            }

            if negative_prompt:
                gen_kwargs["negative_prompt"] = negative_prompt
            if seed is not None:
                gen_kwargs["seed"] = seed
            if guidance_scale is not None:
                gen_kwargs["guidance_scale"] = float(guidance_scale)

            # Generate
            response = model.generate_images(**gen_kwargs)

            if not response.images:
                return ToolResult(
                    success=False, content="",
                    error="No images were generated. The prompt may have been filtered.",
                    is_error=True,
                )

            # Save images
            saved_paths = []
            self._output_dir.mkdir(parents=True, exist_ok=True)

            for i, image in enumerate(response.images):
                if output_filename and count == 1:
                    fname = output_filename
                elif output_filename:
                    stem = Path(output_filename).stem
                    suffix = Path(output_filename).suffix or ".png"
                    fname = f"{stem}_{i+1}{suffix}"
                else:
                    ts = int(time.time())
                    fname = f"imagen_{ts}_{i+1}.png"

                out_path = self._output_dir / fname

                # Save the image
                image.save(str(out_path))
                saved_paths.append(str(out_path))

                logger.info("Imagen 3: saved %s", out_path)

            # Build result
            lines = [f"Generated {len(saved_paths)} image(s):"]
            for p in saved_paths:
                file_size = Path(p).stat().st_size
                size_str = f"{file_size / 1024:.1f} KB"
                lines.append(f"  {p} ({size_str})")

            lines.append(f"\nSize: {size} (aspect ratio: {aspect_ratio})")
            lines.append(f"Model: {self._model}")

            return ToolResult(success=True, content="\n".join(lines))

        except Exception as e:
            error_str = str(e)
            # Check for common Vertex AI errors
            if "permission" in error_str.lower() or "403" in error_str:
                return ToolResult(
                    success=False, content="",
                    error=(
                        f"Permission denied. Ensure your service account has "
                        f"'Vertex AI User' role in project {self._project_id}. "
                        f"Error: {error_str[:200]}"
                    ),
                    is_error=True,
                )
            if "quota" in error_str.lower() or "429" in error_str:
                return ToolResult(
                    success=False, content="",
                    error=f"Quota exceeded. Try again later. Error: {error_str[:200]}",
                    is_error=True,
                )
            if "safety" in error_str.lower() or "blocked" in error_str.lower():
                return ToolResult(
                    success=False, content="",
                    error=f"Image generation blocked by safety filters. Try a different prompt.",
                    is_error=True,
                )

            logger.exception("Imagen 3 generation error")
            return ToolResult(
                success=False, content="",
                error=f"Image generation failed: {error_str[:300]}",
                is_error=True,
            )

    @staticmethod
    def _get_aspect_ratio(width: int, height: int) -> str:
        """Convert pixel dimensions to Imagen 3 aspect ratio string."""
        ratio = width / height
        # Map to closest supported aspect ratio
        ratios = {
            "1:1": 1.0,
            "4:3": 4/3,
            "3:4": 3/4,
            "16:9": 16/9,
            "9:16": 9/16,
            "3:2": 3/2,
            "2:3": 2/3,
        }
        closest = min(ratios.items(), key=lambda x: abs(x[1] - ratio))
        return closest[0]
