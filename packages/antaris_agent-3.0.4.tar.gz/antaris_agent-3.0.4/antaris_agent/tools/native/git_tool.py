"""
Git Tool — Structured git operations with guardrails.

Operations:
  status    — Show working tree status
  diff      — Show changes (staged, unstaged, or specific file)
  log       — Recent commit history
  commit    — Stage and commit (with --no-verify flag support)
  push      — Push to remote
  pull      — Pull from remote
  branch    — List, create, or switch branches
  stash     — Stash/pop/list changes

The --no-verify flag is exposed for commit/push to bypass git hooks,
which is needed when global hooks are installed for security.

Drop into: antaris_agent/tools/native/git_tool.py
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class GitTool(NativeTool):
    """Structured git operations with guardrails."""

    def __init__(self, workspace_path: str, timeout: int = 30,
                 allow_no_verify: bool = True):
        self.workspace_path = Path(workspace_path).resolve()
        self.default_timeout = timeout
        self.allow_no_verify = allow_no_verify

    @property
    def name(self) -> str:
        return "git"

    @property
    def description(self) -> str:
        return (
            "Perform git operations: status, diff, log, commit, push, pull, "
            "branch management, and stash. Supports --no-verify for bypassing "
            "git hooks when needed."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Git operation to perform",
                    "enum": [
                        "status", "diff", "log", "commit", "push", "pull",
                        "branch", "stash", "add", "checkout",
                    ],
                },
                "path": {
                    "type": "string",
                    "description": "Repository path (defaults to workspace)",
                },
                "message": {
                    "type": "string",
                    "description": "Commit message (for 'commit')",
                },
                "files": {
                    "type": "string",
                    "description": "Files to stage (for 'add'). Use '.' for all. Space-separated.",
                },
                "branch_name": {
                    "type": "string",
                    "description": "Branch name (for 'branch' create/switch, 'checkout')",
                },
                "branch_action": {
                    "type": "string",
                    "description": "Branch action: 'list', 'create', 'switch', 'delete'",
                    "enum": ["list", "create", "switch", "delete"],
                },
                "stash_action": {
                    "type": "string",
                    "description": "Stash action: 'save', 'pop', 'list', 'drop'",
                    "enum": ["save", "pop", "list", "drop"],
                },
                "no_verify": {
                    "type": "boolean",
                    "description": "Skip git hooks (--no-verify). Needed when global hooks block commits.",
                    "default": False,
                },
                "remote": {
                    "type": "string",
                    "description": "Remote name (default: origin)",
                    "default": "origin",
                },
                "count": {
                    "type": "integer",
                    "description": "Number of log entries to show (default: 10)",
                    "default": 10,
                },
                "diff_target": {
                    "type": "string",
                    "description": "Diff target: 'staged', 'unstaged' (default), or a file path",
                },
            },
            "required": ["operation"],
        }

    async def _run(self, args: list[str], cwd: Path = None,
                   timeout: int = None) -> tuple[int, str, str]:
        """Run a git command and return (exit_code, stdout, stderr)."""
        cwd = cwd or self.workspace_path
        timeout = timeout or self.default_timeout

        proc = await asyncio.create_subprocess_exec(
            "git", *args,
            cwd=str(cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return -1, "", f"Git command timed out after {timeout}s"

        return (
            proc.returncode,
            stdout.decode("utf-8", errors="replace"),
            stderr.decode("utf-8", errors="replace"),
        )

    def _resolve_path(self, args: dict) -> Path:
        """Resolve repo path from arguments."""
        path_str = args.get("path", "")
        if path_str:
            p = Path(path_str)
            if p.is_absolute():
                return p
            return self.workspace_path / p
        return self.workspace_path

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")
        repo = self._resolve_path(arguments)

        try:
            if operation == "status":
                return await self._status(repo)
            elif operation == "diff":
                return await self._diff(repo, arguments)
            elif operation == "log":
                return await self._log(repo, arguments)
            elif operation == "add":
                return await self._add(repo, arguments)
            elif operation == "commit":
                return await self._commit(repo, arguments)
            elif operation == "push":
                return await self._push(repo, arguments)
            elif operation == "pull":
                return await self._pull(repo, arguments)
            elif operation == "branch":
                return await self._branch(repo, arguments)
            elif operation == "stash":
                return await self._stash(repo, arguments)
            elif operation == "checkout":
                return await self._checkout(repo, arguments)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Git tool error: operation=%s", operation)
            return ToolResult(
                success=False, content="",
                error=f"Git error: {e}",
                is_error=True,
            )

    async def _status(self, repo: Path) -> ToolResult:
        code, out, err = await self._run(["status", "--short", "--branch"], repo)
        if code != 0:
            return ToolResult(success=False, content="", error=err, is_error=True)
        return ToolResult(success=True, content=out or "(clean working tree)")

    async def _diff(self, repo: Path, args: dict) -> ToolResult:
        target = args.get("diff_target", "unstaged")
        cmd = ["diff"]
        if target == "staged":
            cmd.append("--cached")
        elif target not in ("unstaged", ""):
            cmd.append(target)
        cmd.extend(["--stat", "--patch"])

        code, out, err = await self._run(cmd, repo, timeout=60)
        if code != 0:
            return ToolResult(success=False, content="", error=err, is_error=True)

        if not out.strip():
            return ToolResult(success=True, content="No changes.")

        # Truncate large diffs
        if len(out) > 50000:
            out = out[:50000] + "\n\n[Diff truncated at 50KB]"

        return ToolResult(success=True, content=out)

    async def _log(self, repo: Path, args: dict) -> ToolResult:
        count = min(args.get("count", 10), 50)
        code, out, err = await self._run(
            ["log", f"--oneline", f"-{count}", "--no-decorate"],
            repo,
        )
        if code != 0:
            return ToolResult(success=False, content="", error=err, is_error=True)
        return ToolResult(success=True, content=out or "(no commits)")

    async def _add(self, repo: Path, args: dict) -> ToolResult:
        files = args.get("files", ".")
        file_list = files.split() if files else ["."]
        code, out, err = await self._run(["add"] + file_list, repo)
        if code != 0:
            return ToolResult(success=False, content="", error=err, is_error=True)
        return ToolResult(success=True, content=f"Staged: {files}")

    async def _commit(self, repo: Path, args: dict) -> ToolResult:
        message = args.get("message", "")
        if not message:
            return ToolResult(
                success=False, content="",
                error="Commit requires a 'message'",
                is_error=True,
            )

        # Pre-commit: capture what's being committed
        stat_code, stat_out, _ = await self._run(["diff", "--cached", "--stat"], repo)
        staged_summary = stat_out.strip() if stat_code == 0 else "(could not read staged changes)"

        cmd = ["commit", "-m", message]
        if args.get("no_verify") and self.allow_no_verify:
            cmd.append("--no-verify")

        code, out, err = await self._run(cmd, repo)
        if code != 0:
            combined = (out + "\n" + err).strip()
            return ToolResult(success=False, content="", error=combined, is_error=True)

        # Post-commit: capture the commit hash
        hash_code, hash_out, _ = await self._run(["rev-parse", "--short", "HEAD"], repo)
        commit_hash = hash_out.strip() if hash_code == 0 else "unknown"

        result_text = (
            f"Committed: {commit_hash} — {message}\n"
            f"Files changed:\n{staged_summary}\n\n"
            f"{out}"
        )
        logger.info("GIT COMMIT: hash=%s message=%s repo=%s", commit_hash, message[:80], repo)
        return ToolResult(success=True, content=result_text)

    async def _push(self, repo: Path, args: dict) -> ToolResult:
        remote = args.get("remote", "origin")

        # Pre-push verification: log where we're pushing to
        verify_code, verify_out, _ = await self._run(["remote", "get-url", remote], repo)
        remote_url = verify_out.strip() if verify_code == 0 else "unknown"
        branch_code, branch_out, _ = await self._run(["branch", "--show-current"], repo)
        current_branch = branch_out.strip() if branch_code == 0 else "unknown"

        logger.warning(
            "GIT PUSH: remote=%s url=%s branch=%s repo=%s",
            remote, remote_url, current_branch, repo,
        )

        cmd = ["push", remote]
        if args.get("no_verify") and self.allow_no_verify:
            cmd.append("--no-verify")

        code, out, err = await self._run(cmd, repo, timeout=60)
        combined = (out + "\n" + err).strip()
        if code != 0:
            return ToolResult(success=False, content="", error=combined, is_error=True)

        # Post-push verification: confirm remote HEAD
        head_code, head_out, _ = await self._run(["rev-parse", "HEAD"], repo)
        local_head = head_out.strip() if head_code == 0 else "unknown"

        result_text = (
            f"Pushed to {remote} ({remote_url})\n"
            f"Branch: {current_branch}\n"
            f"Local HEAD: {local_head}\n"
            f"{combined}"
        )
        return ToolResult(success=True, content=result_text)

    async def _pull(self, repo: Path, args: dict) -> ToolResult:
        remote = args.get("remote", "origin")
        code, out, err = await self._run(["pull", remote], repo, timeout=60)
        combined = (out + "\n" + err).strip()
        if code != 0:
            return ToolResult(success=False, content="", error=combined, is_error=True)
        return ToolResult(success=True, content=combined or "Already up to date.")

    async def _branch(self, repo: Path, args: dict) -> ToolResult:
        action = args.get("branch_action", "list")
        branch_name = args.get("branch_name", "")

        if action == "list":
            code, out, err = await self._run(["branch", "-a"], repo)
            if code != 0:
                return ToolResult(success=False, content="", error=err, is_error=True)
            return ToolResult(success=True, content=out)

        if not branch_name:
            return ToolResult(
                success=False, content="",
                error=f"'branch_name' required for {action}",
                is_error=True,
            )

        if action == "create":
            code, out, err = await self._run(["branch", branch_name], repo)
        elif action == "switch":
            code, out, err = await self._run(["checkout", branch_name], repo)
        elif action == "delete":
            code, out, err = await self._run(["branch", "-d", branch_name], repo)
        else:
            return ToolResult(
                success=False, content="",
                error=f"Unknown branch action: {action}",
                is_error=True,
            )

        combined = (out + "\n" + err).strip()
        if code != 0:
            return ToolResult(success=False, content="", error=combined, is_error=True)
        return ToolResult(success=True, content=combined or f"Branch {action}: {branch_name}")

    async def _stash(self, repo: Path, args: dict) -> ToolResult:
        action = args.get("stash_action", "save")

        if action == "save":
            code, out, err = await self._run(["stash", "push"], repo)
        elif action == "pop":
            code, out, err = await self._run(["stash", "pop"], repo)
        elif action == "list":
            code, out, err = await self._run(["stash", "list"], repo)
        elif action == "drop":
            code, out, err = await self._run(["stash", "drop"], repo)
        else:
            return ToolResult(
                success=False, content="",
                error=f"Unknown stash action: {action}",
                is_error=True,
            )

        combined = (out + "\n" + err).strip()
        if code != 0:
            return ToolResult(success=False, content="", error=combined, is_error=True)
        return ToolResult(success=True, content=combined or f"Stash {action} complete.")

    async def _checkout(self, repo: Path, args: dict) -> ToolResult:
        branch_name = args.get("branch_name", "")
        if not branch_name:
            return ToolResult(
                success=False, content="",
                error="'branch_name' required for checkout",
                is_error=True,
            )
        code, out, err = await self._run(["checkout", branch_name], repo)
        combined = (out + "\n" + err).strip()
        if code != 0:
            return ToolResult(success=False, content="", error=combined, is_error=True)
        return ToolResult(success=True, content=combined or f"Switched to {branch_name}")
