"""
HTTP/API Tool — General-purpose HTTP requests.

Makes structured HTTP requests with proper JSON handling,
headers, auth, and response parsing. Replaces the need
for shell + curl for API work.

Operations:
  get      — HTTP GET
  post     — HTTP POST (JSON body)
  put      — HTTP PUT (JSON body)
  patch    — HTTP PATCH (JSON body)
  delete   — HTTP DELETE
  head     — HTTP HEAD (headers only)

Drop into: antaris_agent/tools/native/http_tool.py
"""

from __future__ import annotations

import ipaddress
import json
import logging
import socket
from typing import Any, Dict, Optional
from urllib.parse import urlparse

import httpx

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

# Block requests to private/local networks by default
_BLOCKED_HOSTS = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1",
    "metadata.google.internal",  # GCP metadata
    "169.254.169.254",           # AWS/GCP/Azure metadata
}

# Additional hostname patterns to block (substring match)
_BLOCKED_HOST_PATTERNS = {
    "metadata.google",  # GCP metadata variations
}


def _is_ssrf_target(hostname: str) -> Optional[str]:
    """Resolve hostname and check if the resolved IP is private/loopback/link-local.

    Returns an error message if blocked, None if safe.
    This catches encoding tricks (decimal IP, hex, IPv6 mapped, DNS rebinding)
    because the OS resolver normalizes them all to standard IP addresses.
    """
    # Check static blocklist first (catches well-known names)
    hostname_lower = hostname.lower()
    if hostname_lower in _BLOCKED_HOSTS:
        return f"Requests to {hostname} are blocked (local/metadata endpoint)"
    for pattern in _BLOCKED_HOST_PATTERNS:
        if pattern in hostname_lower:
            return f"Requests to {hostname} are blocked (metadata endpoint)"

    # Resolve hostname to IP(s) and check each one
    try:
        infos = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror:
        # Can't resolve — not necessarily an error, let httpx handle it
        return None

    for family, _type, _proto, _canonname, sockaddr in infos:
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            continue

        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return (
                f"Requests to {hostname} blocked: resolves to {ip_str} "
                f"(private/loopback/link-local/reserved)"
            )

    return None


def _resolve_and_pin(hostname: str) -> tuple[Optional[str], Optional[str]]:
    """Resolve hostname to a safe IP and pin it for use in the request.

    Returns (pinned_ip, error_message).  If error_message is set the
    request must be aborted.  pinned_ip is the first resolved address
    that passed the SSRF check (or None if hostname couldn't be resolved
    at all — callers should let httpx handle that natively).

    Pinning eliminates the DNS-rebinding TOCTOU window: we resolve once,
    validate the result, and then force the HTTP client to connect to
    that specific IP rather than re-resolving at connect time.
    """
    hostname_lower = hostname.lower()

    # Static blocklist fast path
    if hostname_lower in _BLOCKED_HOSTS:
        return None, f"Requests to {hostname} are blocked (local/metadata endpoint)"
    for pattern in _BLOCKED_HOST_PATTERNS:
        if pattern in hostname_lower:
            return None, f"Requests to {hostname} are blocked (metadata endpoint)"

    try:
        infos = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror:
        # No resolution — let httpx fail naturally (no pinning possible)
        return None, None

    for family, _type, _proto, _canonname, sockaddr in infos:
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            continue

        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return None, (
                f"Requests to {hostname} blocked: resolves to {ip_str} "
                f"(private/loopback/link-local/reserved)"
            )

        # First safe address wins — pin it
        return ip_str, None

    # All resolved addresses were unparseable (shouldn't happen)
    return None, None


class HTTPTool(NativeTool):
    """General-purpose HTTP request tool."""

    def __init__(self, timeout: float = 30.0, max_response_bytes: int = 500_000,
                 allow_local: bool = False):
        self._timeout = timeout
        self._max_response = max_response_bytes
        self._allow_local = allow_local

    @property
    def name(self) -> str:
        return "http"

    @property
    def description(self) -> str:
        return (
            "Make HTTP requests to APIs. Supports GET, POST, PUT, PATCH, DELETE, HEAD. "
            "Handles JSON bodies, custom headers, and auth headers. "
            "Use this instead of shell+curl for structured API work."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "method": {
                    "type": "string",
                    "description": "HTTP method",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"],
                },
                "url": {
                    "type": "string",
                    "description": "Request URL (must include https:// or http://)",
                },
                "headers": {
                    "type": "object",
                    "description": "Request headers as key-value pairs",
                },
                "body": {
                    "type": "object",
                    "description": "JSON request body (for POST/PUT/PATCH)",
                },
                "body_raw": {
                    "type": "string",
                    "description": "Raw string body (alternative to JSON body)",
                },
                "auth_bearer": {
                    "type": "string",
                    "description": "Bearer token (adds Authorization: Bearer <token> header)",
                },
                "auth_api_key": {
                    "type": "string",
                    "description": "API key value (pair with auth_api_key_header)",
                },
                "auth_api_key_header": {
                    "type": "string",
                    "description": "Header name for API key (default: X-API-Key)",
                    "default": "X-API-Key",
                },
                "timeout": {
                    "type": "number",
                    "description": "Request timeout in seconds (default: 30)",
                },
                "follow_redirects": {
                    "type": "boolean",
                    "description": "Follow HTTP redirects (default: true)",
                    "default": True,
                },
            },
            "required": ["method", "url"],
        }

    def _check_url(self, url: str) -> tuple[Optional[str], Optional[str]]:
        """Validate URL against SSRF. Returns (error_message, pinned_ip).

        M6: Uses DNS resolution + ipaddress module to catch all encoding tricks
        (decimal IP, hex, IPv6 mapped, DNS rebinding).

        M7 (TOCTOU fix): Returns the pinned IP so callers can connect directly to
        that specific address, eliminating the window between resolve-time check
        and connect-time re-resolution (DNS rebinding attack vector).
        """
        if not url:
            return "URL is required", None
        if not url.startswith(("http://", "https://")):
            return "URL must start with http:// or https://", None

        if not self._allow_local:
            try:
                parsed = urlparse(url)
                hostname = (parsed.hostname or "").lower()
                if not hostname:
                    return "URL has no hostname", None
                pinned_ip, ssrf_error = _resolve_and_pin(hostname)
                if ssrf_error:
                    return ssrf_error, None
                return None, pinned_ip
            except Exception as e:
                return f"URL validation failed: {e}", None

        return None, None

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        method = arguments.get("method", "GET").upper()
        url = arguments.get("url", "")

        # Validate URL — also returns the pinned IP to prevent DNS rebinding TOCTOU
        url_error, pinned_ip = self._check_url(url)
        if url_error:
            return ToolResult(
                success=False, content="",
                error=url_error, is_error=True,
            )

        # Build headers
        headers = dict(arguments.get("headers", {}) or {})
        if arguments.get("auth_bearer"):
            headers["Authorization"] = f"Bearer {arguments['auth_bearer']}"
        if arguments.get("auth_api_key"):
            key_header = arguments.get("auth_api_key_header", "X-API-Key")
            headers[key_header] = arguments["auth_api_key"]

        # Build body
        body_json = arguments.get("body")
        body_raw = arguments.get("body_raw")
        content = None
        json_body = None

        if body_json is not None:
            json_body = body_json
            if "Content-Type" not in headers:
                headers["Content-Type"] = "application/json"
        elif body_raw is not None:
            content = body_raw

        timeout = min(arguments.get("timeout", self._timeout), 120)
        follow = arguments.get("follow_redirects", True)

        # M7 (DNS rebinding TOCTOU fix): If we pinned an IP at validation time,
        # rewrite the URL to connect directly to that IP and set the Host header
        # so the server still sees the original hostname.  This eliminates the
        # window between our pre-flight DNS check and httpx's own resolution at
        # connect time — a classic DNS rebinding attack vector.
        actual_url = url
        if pinned_ip and not self._allow_local:
            try:
                parsed = urlparse(url)
                original_host = parsed.netloc  # includes port if present
                original_hostname = parsed.hostname or ""
                port = parsed.port

                # Build replacement netloc using the pinned IP.
                # IPv6 addresses must be bracketed in the URL.
                ip_obj = ipaddress.ip_address(pinned_ip)
                if ip_obj.version == 6:
                    ip_netloc = f"[{pinned_ip}]"
                else:
                    ip_netloc = pinned_ip
                if port:
                    ip_netloc = f"{ip_netloc}:{port}"

                # Replace netloc in the URL so httpx connects to the pinned IP
                actual_url = parsed._replace(netloc=ip_netloc).geturl()

                # Preserve the original Host header so SNI / virtual hosting works
                if "Host" not in headers and "host" not in headers:
                    headers["Host"] = original_host
            except Exception:
                # If URL surgery fails, fall back to the original URL.
                # The pre-flight check already validated it; risk is low.
                actual_url = url

        try:
            async with httpx.AsyncClient(
                timeout=timeout,
                follow_redirects=follow,
                max_redirects=5,
            ) as client:
                response = await client.request(
                    method=method,
                    url=actual_url,
                    headers=headers,
                    json=json_body,
                    content=content,
                )

            if not self._allow_local:
                final_url_error = self._check_url(str(response.url))
                if final_url_error:
                    return ToolResult(
                        success=False,
                        content="",
                        error=(
                            "Final response URL blocked after redirect validation: "
                            f"{final_url_error}"
                        ),
                        is_error=True,
                    )

            # Build result
            status = response.status_code
            resp_headers = dict(response.headers)

            # HEAD requests: return headers only
            if method == "HEAD":
                header_lines = [f"{k}: {v}" for k, v in resp_headers.items()]
                return ToolResult(
                    success=True,
                    content=(
                        f"HTTP {status}\n"
                        + "\n".join(header_lines)
                    ),
                )

            # Read body
            resp_text = response.text
            if len(resp_text) > self._max_response:
                resp_text = resp_text[:self._max_response] + "\n\n[Truncated at 500KB]"

            # Try to pretty-print JSON
            content_type = resp_headers.get("content-type", "")
            if "json" in content_type:
                try:
                    parsed = response.json()
                    resp_text = json.dumps(parsed, indent=2, ensure_ascii=False)
                    if len(resp_text) > self._max_response:
                        resp_text = resp_text[:self._max_response] + "\n\n[Truncated]"
                except Exception:
                    pass  # fall back to raw text

            result_content = f"HTTP {status}\n\n{resp_text}"

            return ToolResult(
                success=(200 <= status < 400),
                content=result_content,
                error=f"HTTP {status}" if status >= 400 else None,
                is_error=(status >= 400),
            )

        except httpx.TimeoutException:
            return ToolResult(
                success=False, content="",
                error=f"Request timed out after {timeout}s",
                is_error=True,
            )
        except httpx.ConnectError as e:
            return ToolResult(
                success=False, content="",
                error=f"Connection failed: {e}",
                is_error=True,
            )
        except Exception as e:
            logger.exception("HTTP tool error")
            return ToolResult(
                success=False, content="",
                error=f"HTTP request failed: {e}",
                is_error=True,
            )
