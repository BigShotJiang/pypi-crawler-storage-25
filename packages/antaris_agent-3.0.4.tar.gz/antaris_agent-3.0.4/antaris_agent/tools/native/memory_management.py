"""
Memory Management Tool — Self-service memory operations for the agent.

Lets the LLM search, inspect, forget, and get stats on its own memories
during conversation. Without this, the agent can recall memories but has
no ability to question, correct, or clean up what it recalls.

Operations:
  search    — Search memories by query, return scored results with metadata
  inspect   — Get full details of a memory by its content hash
  forget    — Remove memories by topic, entity, or date
  stats     — Get memory store statistics (total, enriched, by type, by source)
  recent    — Get the N most recent memories

Drop into: antaris_agent/tools/native/memory_management.py

Wire in bot.py where other native tools are registered:
    from antaris_agent.tools.native.memory_management import MemoryManagementTool
    memory_tool = MemoryManagementTool(bot.memory)
    await tool_registry.register_native("memory_management", memory_tool)
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class MemoryManagementTool(NativeTool):
    """Self-service memory operations for the agent.

    Wraps BotMemory methods so the LLM can directly search, inspect,
    forget, and introspect its own memory store during conversation.

    Args:
        bot_memory: The BotMemory instance from the bot.
        default_user_id: Fallback user ID when not provided in arguments.
            In single-user setups (like Moro), this avoids requiring
            user_id on every call.
    """

    def __init__(self, bot_memory, default_user_id: str = ""):
        self._memory = bot_memory
        self._default_user_id = default_user_id

    @property
    def name(self) -> str:
        return "memory_management"

    @property
    def description(self) -> str:
        return (
            "Search, inspect, forget, and get stats on your own memories. "
            "Use this to find what you remember about a topic, check if a "
            "memory is accurate, remove incorrect or stale memories, or "
            "understand how many memories you have and what they cover."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Memory operation to perform",
                    "enum": ["search", "inspect", "forget", "stats", "recent"],
                },
                "query": {
                    "type": "string",
                    "description": (
                        "Search query (required for 'search'). "
                        "Use natural language — BM25 matches on keywords."
                    ),
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return (default 5, max 20)",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 20,
                },
                "topic": {
                    "type": "string",
                    "description": (
                        "Topic string to forget (for 'forget' operation). "
                        "Removes all memories containing this topic."
                    ),
                },
                "entity": {
                    "type": "string",
                    "description": (
                        "Entity name to forget (for 'forget' operation). "
                        "Removes all memories mentioning this entity."
                    ),
                },
                "before_date": {
                    "type": "string",
                    "description": (
                        "Date cutoff for forget (YYYY-MM-DD). "
                        "Removes memories created before this date."
                    ),
                },
                "content_hash": {
                    "type": "string",
                    "description": (
                        "Content hash of a specific memory (for 'inspect'). "
                        "Get this from search results."
                    ),
                },
                "user_id": {
                    "type": "string",
                    "description": (
                        "User ID to scope the operation to. "
                        "Usually not needed in single-user setups."
                    ),
                },
            },
            "required": ["operation"],
        }

    def _resolve_user_id(self, arguments: dict) -> str:
        """Resolve user_id from arguments or default."""
        uid = arguments.get("user_id", "") or self._default_user_id
        if not uid:
            uid = "default"
        return str(uid)

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")
        user_id = self._resolve_user_id(arguments)

        try:
            if operation == "search":
                return await self._search(user_id, arguments)
            elif operation == "inspect":
                return await self._inspect(user_id, arguments)
            elif operation == "forget":
                return await self._forget(user_id, arguments)
            elif operation == "stats":
                return await self._stats(user_id)
            elif operation == "recent":
                return await self._recent(user_id, arguments)
            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Unknown operation: {operation}. Use: search, inspect, forget, stats, recent",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("Memory management tool error: operation=%s", operation)
            return ToolResult(
                success=False,
                content="",
                error=f"Memory operation failed: {e}",
                is_error=True,
            )

    async def _search(self, user_id: str, arguments: dict) -> ToolResult:
        """Search memories by query."""
        query = arguments.get("query", "")
        limit = min(arguments.get("limit", 5), 20)

        if not query.strip():
            return ToolResult(
                success=False,
                content="",
                error="Search requires a 'query' parameter",
                is_error=True,
            )

        results = self._memory.search_memories(user_id, query, limit=limit)

        if not results:
            return ToolResult(
                success=True,
                content=f"No memories found matching '{query}'.",
            )

        lines = [f"Found {len(results)} memories for '{query}':\n"]
        for i, r in enumerate(results, 1):
            content = (r.get("content") or "")[:300]
            score = r.get("score", 0.0)
            source = r.get("source", "unknown")
            timestamp = r.get("timestamp", "unknown")
            # Include hash if available for inspect/forget follow-up
            content_hash = r.get("hash", "")

            lines.append(f"{i}. [score={score:.3f}] {content}")
            meta_parts = [f"   source={source}", f"ts={timestamp}"]
            if content_hash:
                meta_parts.append(f"hash={content_hash}")
            lines.append("   " + " | ".join(meta_parts))
            lines.append("")

        return ToolResult(success=True, content="\n".join(lines))

    async def _inspect(self, user_id: str, arguments: dict) -> ToolResult:
        """Inspect a specific memory by hash or by searching for it."""
        content_hash = arguments.get("content_hash", "")
        query = arguments.get("query", "")

        if not content_hash and not query:
            return ToolResult(
                success=False,
                content="",
                error="Inspect requires either 'content_hash' or 'query'",
                is_error=True,
            )

        store = self._memory._get_store(user_id)
        if store is None:
            return ToolResult(
                success=False,
                content="",
                error=f"No memory store found for user {user_id}",
                is_error=True,
            )

        # Find by hash
        if content_hash:
            all_memories = getattr(store, "memories", [])
            target = None
            for m in all_memories:
                if getattr(m, "hash", "") == content_hash:
                    target = m
                    break
            if target is None:
                return ToolResult(
                    success=True,
                    content=f"No memory found with hash '{content_hash}'.",
                )
        else:
            # Search and return the top result with full detail
            results = store.search(query, limit=1, read_only=True)
            if not results:
                return ToolResult(
                    success=True,
                    content=f"No memories found matching '{query}'.",
                )
            target = results[0]
            # Handle SearchResult wrapper
            if hasattr(target, "entry"):
                target = target.entry

        # Build full detail view
        fields = {
            "content": getattr(target, "content", ""),
            "hash": getattr(target, "hash", ""),
            "source": getattr(target, "source", ""),
            "memory_type": getattr(target, "memory_type", ""),
            "category": getattr(target, "category", ""),
            "tags": getattr(target, "tags", []),
            "importance": getattr(target, "importance", ""),
            "access_count": getattr(target, "access_count", 0),
            "created": getattr(target, "created", ""),
            "last_accessed": getattr(target, "last_accessed", ""),
            "session_id": getattr(target, "session_id", ""),
            "channel_id": getattr(target, "channel_id", ""),
            "enriched_summary": getattr(target, "enriched_summary", ""),
            "enriched_keywords": getattr(target, "enriched_keywords", []),
            "enriched_tags": getattr(target, "enriched_tags", []),
        }

        lines = ["Memory Detail:"]
        for k, v in fields.items():
            if v or v == 0:  # include zero but skip empty strings/lists
                if isinstance(v, list):
                    v = ", ".join(str(x) for x in v) if v else "(none)"
                lines.append(f"  {k}: {v}")

        return ToolResult(success=True, content="\n".join(lines))

    async def _forget(self, user_id: str, arguments: dict) -> ToolResult:
        """Forget memories by topic, entity, or date."""
        topic = arguments.get("topic")
        entity = arguments.get("entity")
        before_date = arguments.get("before_date")

        if not topic and not entity and not before_date:
            return ToolResult(
                success=False,
                content="",
                error=(
                    "Forget requires at least one of: 'topic', 'entity', or 'before_date'. "
                    "This is a safety guard to prevent accidental bulk deletion."
                ),
                is_error=True,
            )

        store = self._memory._get_store(user_id)
        if store is None:
            return ToolResult(
                success=False,
                content="",
                error=f"No memory store found for user {user_id}",
                is_error=True,
            )

        # Check if the store has the forget method
        forget_fn = getattr(store, "forget", None)
        if not callable(forget_fn):
            return ToolResult(
                success=False,
                content="",
                error="Memory store does not support the forget operation",
                is_error=True,
            )

        result = forget_fn(topic=topic, entity=entity, before_date=before_date)

        removed = result.get("removed", [])
        count = len(removed)

        if count == 0:
            criteria = []
            if topic:
                criteria.append(f"topic='{topic}'")
            if entity:
                criteria.append(f"entity='{entity}'")
            if before_date:
                criteria.append(f"before={before_date}")
            return ToolResult(
                success=True,
                content=f"No memories matched the criteria: {', '.join(criteria)}",
            )

        # Summarize what was removed
        lines = [f"Forgot {count} memories:"]
        for i, m in enumerate(removed[:10], 1):
            content = (getattr(m, "content", "") or "")[:120]
            lines.append(f"  {i}. {content}")
        if count > 10:
            lines.append(f"  ... and {count - 10} more")

        logger.info(
            "Memory forget: user=%s topic=%s entity=%s before=%s removed=%d",
            user_id, topic, entity, before_date, count,
        )

        return ToolResult(success=True, content="\n".join(lines))

    async def _stats(self, user_id: str) -> ToolResult:
        """Get memory store statistics."""
        store = self._memory._get_store(user_id)
        if store is None:
            return ToolResult(
                success=True,
                content="No memory store initialized for this user.",
            )

        all_memories = getattr(store, "memories", [])
        total = len(all_memories)

        if total == 0:
            return ToolResult(
                success=True,
                content="Memory store is empty (0 memories).",
            )

        # Count by type
        type_counts: dict = {}
        source_counts: dict = {}
        category_counts: dict = {}
        enriched_count = 0
        total_access = 0

        for m in all_memories:
            mt = getattr(m, "memory_type", "unknown") or "unknown"
            type_counts[mt] = type_counts.get(mt, 0) + 1

            src = getattr(m, "source", "unknown") or "unknown"
            # Normalize long source strings
            if ":" in src:
                src = src.split(":")[0]
            source_counts[src] = source_counts.get(src, 0) + 1

            cat = getattr(m, "category", "unknown") or "unknown"
            category_counts[cat] = category_counts.get(cat, 0) + 1

            if getattr(m, "enriched_summary", ""):
                enriched_count += 1

            total_access += getattr(m, "access_count", 0) or 0

        lines = [
            f"Memory Store Stats:",
            f"  Total memories: {total}",
            f"  Enriched: {enriched_count} ({enriched_count/total*100:.1f}%)",
            f"  Total recall hits: {total_access}",
            f"",
            f"  By type:",
        ]
        for t, c in sorted(type_counts.items(), key=lambda x: -x[1]):
            lines.append(f"    {t}: {c}")

        lines.append(f"")
        lines.append(f"  By source (top 10):")
        for s, c in sorted(source_counts.items(), key=lambda x: -x[1])[:10]:
            lines.append(f"    {s}: {c}")

        lines.append(f"")
        lines.append(f"  By category (top 10):")
        for cat, c in sorted(category_counts.items(), key=lambda x: -x[1])[:10]:
            lines.append(f"    {cat}: {c}")

        return ToolResult(success=True, content="\n".join(lines))

    async def _recent(self, user_id: str, arguments: dict) -> ToolResult:
        """Get the N most recent memories."""
        limit = min(arguments.get("limit", 10), 20)

        store = self._memory._get_store(user_id)
        if store is None:
            return ToolResult(
                success=True,
                content="No memory store initialized for this user.",
            )

        all_memories = getattr(store, "memories", [])
        if not all_memories:
            return ToolResult(
                success=True,
                content="Memory store is empty.",
            )

        # Sort by timestamp/created descending
        def get_ts(m):
            ts = getattr(m, "timestamp", None)
            if ts:
                return float(ts)
            created = getattr(m, "created", "")
            if created:
                try:
                    from datetime import datetime
                    return datetime.fromisoformat(
                        str(created).replace("Z", "+00:00")
                    ).timestamp()
                except (ValueError, TypeError):
                    pass
            return 0.0

        sorted_memories = sorted(all_memories, key=get_ts, reverse=True)[:limit]

        lines = [f"Most recent {len(sorted_memories)} memories:\n"]
        for i, m in enumerate(sorted_memories, 1):
            content = (getattr(m, "content", "") or "")[:200]
            source = getattr(m, "source", "unknown") or "unknown"
            created = getattr(m, "created", "unknown")
            mem_type = getattr(m, "memory_type", "") or ""
            mem_hash = getattr(m, "hash", "")

            type_label = f" [{mem_type}]" if mem_type else ""
            lines.append(f"{i}.{type_label} {content}")
            meta = f"   source={source} | created={created}"
            if mem_hash:
                meta += f" | hash={mem_hash}"
            lines.append(meta)
            lines.append("")

        return ToolResult(success=True, content="\n".join(lines))
