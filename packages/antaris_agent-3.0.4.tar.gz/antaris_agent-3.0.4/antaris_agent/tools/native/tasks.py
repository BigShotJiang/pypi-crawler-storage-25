"""
Task Manager Tool — Local task board for the agent.

A lightweight task management system that persists to JSON.
No external service dependency — lives alongside the bot's config.

Operations:
  add        — Create a new task
  list       — List tasks (with filters)
  update     — Update task status, priority, or details
  done       — Mark a task as done
  delete     — Remove a task
  archive    — Move completed tasks to archive
  search     — Search tasks by text

Task states: todo, in_progress, blocked, done, archived
Priorities: low, medium, high, urgent

Drop into: antaris_agent/tools/native/tasks.py

Persists to: {config_dir}/tasks.json
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class TaskManagerTool(NativeTool):
    """Local task management with JSON persistence."""

    VALID_STATUSES = {"todo", "in_progress", "blocked", "done", "archived"}
    VALID_PRIORITIES = {"low", "medium", "high", "urgent"}

    def __init__(self, tasks_path: str = ""):
        self._tasks_path = Path(tasks_path) if tasks_path else Path.cwd() / "tasks.json"
        self._tasks: dict[str, dict] = {}
        self._load()

    @property
    def name(self) -> str:
        return "tasks"

    @property
    def description(self) -> str:
        return (
            "Manage a personal task board. Create, list, update, complete, "
            "and search tasks. Supports priorities (low/medium/high/urgent), "
            "statuses (todo/in_progress/blocked/done), tags, and due dates. "
            "Tasks persist across sessions."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Task operation",
                    "enum": ["add", "list", "update", "done", "delete", "archive", "search"],
                },
                "title": {
                    "type": "string",
                    "description": "Task title (required for 'add')",
                },
                "description": {
                    "type": "string",
                    "description": "Task description/details",
                },
                "priority": {
                    "type": "string",
                    "description": "Task priority",
                    "enum": ["low", "medium", "high", "urgent"],
                },
                "status": {
                    "type": "string",
                    "description": "Task status (for 'update')",
                    "enum": ["todo", "in_progress", "blocked", "done"],
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tags for categorization (e.g. ['parsica', 'bug'])",
                },
                "due_date": {
                    "type": "string",
                    "description": "Due date (YYYY-MM-DD format)",
                },
                "task_id": {
                    "type": "string",
                    "description": "Task ID (for update/done/delete)",
                },
                "filter_status": {
                    "type": "string",
                    "description": "Filter by status (for 'list')",
                    "enum": ["todo", "in_progress", "blocked", "done", "all"],
                },
                "filter_priority": {
                    "type": "string",
                    "description": "Filter by priority (for 'list')",
                },
                "filter_tag": {
                    "type": "string",
                    "description": "Filter by tag (for 'list')",
                },
                "query": {
                    "type": "string",
                    "description": "Search query (for 'search')",
                },
                "note": {
                    "type": "string",
                    "description": "Add a note/comment to the task (for 'update')",
                },
            },
            "required": ["operation"],
        }

    def _load(self):
        """Load tasks from disk."""
        if self._tasks_path.exists():
            try:
                data = json.loads(self._tasks_path.read_text(encoding="utf-8"))
                self._tasks = data.get("tasks", {})
                logger.debug("TaskManager: loaded %d tasks", len(self._tasks))
            except Exception as e:
                logger.warning("TaskManager: failed to load tasks: %s", e)
                self._tasks = {}
        else:
            self._tasks = {}

    def _save(self):
        """Persist tasks to disk (atomic write)."""
        self._tasks_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"tasks": self._tasks, "updated": datetime.now().isoformat()}
        tmp = self._tasks_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        tmp.rename(self._tasks_path)

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        operation = arguments.get("operation", "")

        try:
            if operation == "add":
                return self._add(arguments)
            elif operation == "list":
                return self._list(arguments)
            elif operation == "update":
                return self._update(arguments)
            elif operation == "done":
                return self._done(arguments)
            elif operation == "delete":
                return self._delete(arguments)
            elif operation == "archive":
                return self._archive()
            elif operation == "search":
                return self._search(arguments)
            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True,
                )
        except Exception as e:
            logger.exception("TaskManager error: operation=%s", operation)
            return ToolResult(
                success=False, content="",
                error=f"Task operation failed: {e}",
                is_error=True,
            )

    def _add(self, args: dict) -> ToolResult:
        """Add a new task."""
        title = args.get("title", "").strip()
        if not title:
            return ToolResult(
                success=False, content="",
                error="'title' is required for add",
                is_error=True,
            )

        task_id = str(uuid.uuid4())[:8]
        now = datetime.now().isoformat()

        task = {
            "id": task_id,
            "title": title,
            "description": args.get("description", ""),
            "status": "todo",
            "priority": args.get("priority", "medium"),
            "tags": args.get("tags", []),
            "due_date": args.get("due_date", ""),
            "created": now,
            "updated": now,
            "notes": [],
        }

        # Validate priority
        if task["priority"] not in self.VALID_PRIORITIES:
            task["priority"] = "medium"

        self._tasks[task_id] = task
        self._save()

        lines = [
            f"Created task: {title}",
            f"  ID: {task_id}",
            f"  Priority: {task['priority']}",
        ]
        if task["due_date"]:
            lines.append(f"  Due: {task['due_date']}")
        if task["tags"]:
            lines.append(f"  Tags: {', '.join(task['tags'])}")

        return ToolResult(success=True, content="\n".join(lines))

    def _list(self, args: dict) -> ToolResult:
        """List tasks with optional filters."""
        filter_status = args.get("filter_status", "all")
        filter_priority = args.get("filter_priority", "")
        filter_tag = args.get("filter_tag", "")

        tasks = list(self._tasks.values())

        # Apply filters
        if filter_status and filter_status != "all":
            tasks = [t for t in tasks if t.get("status") == filter_status]
        else:
            # Default: exclude archived
            tasks = [t for t in tasks if t.get("status") != "archived"]

        if filter_priority:
            tasks = [t for t in tasks if t.get("priority") == filter_priority]

        if filter_tag:
            tasks = [t for t in tasks if filter_tag in (t.get("tags") or [])]

        if not tasks:
            filters = []
            if filter_status != "all":
                filters.append(f"status={filter_status}")
            if filter_priority:
                filters.append(f"priority={filter_priority}")
            if filter_tag:
                filters.append(f"tag={filter_tag}")
            filter_desc = f" ({', '.join(filters)})" if filters else ""
            return ToolResult(success=True, content=f"No tasks found{filter_desc}.")

        # Sort: urgent first, then by due date, then by created
        priority_order = {"urgent": 0, "high": 1, "medium": 2, "low": 3}
        tasks.sort(key=lambda t: (
            priority_order.get(t.get("priority", "medium"), 2),
            t.get("due_date") or "9999",
            t.get("created", ""),
        ))

        lines = [f"{len(tasks)} tasks:\n"]
        for t in tasks:
            status_icons = {
                "todo": "[ ]", "in_progress": "[~]",
                "blocked": "[!]", "done": "[x]", "archived": "[-]",
            }
            icon = status_icons.get(t.get("status", "todo"), "[ ]")
            priority = t.get("priority", "medium")
            priority_marker = {"urgent": "!!!", "high": "!!", "medium": "!", "low": ""}.get(priority, "")

            title_line = f"  {icon} {t['id']} — {t['title']}"
            if priority_marker:
                title_line += f" [{priority_marker}]"

            meta_parts = []
            if t.get("due_date"):
                meta_parts.append(f"due: {t['due_date']}")
            if t.get("tags"):
                meta_parts.append(f"tags: {', '.join(t['tags'])}")
            if t.get("status") == "blocked":
                meta_parts.append("BLOCKED")

            lines.append(title_line)
            if meta_parts:
                lines.append(f"      {' | '.join(meta_parts)}")

        return ToolResult(success=True, content="\n".join(lines))

    def _update(self, args: dict) -> ToolResult:
        """Update a task's fields."""
        task_id = args.get("task_id", "")
        if not task_id:
            return ToolResult(
                success=False, content="",
                error="'task_id' is required for update",
                is_error=True,
            )

        task = self._tasks.get(task_id)
        if not task:
            return ToolResult(
                success=False, content="",
                error=f"No task found with ID '{task_id}'",
                is_error=True,
            )

        changes = []

        if "title" in args and args["title"]:
            task["title"] = args["title"]
            changes.append(f"title → {args['title']}")

        if "description" in args:
            task["description"] = args["description"]
            changes.append("description updated")

        if "status" in args and args["status"] in self.VALID_STATUSES:
            old = task.get("status")
            task["status"] = args["status"]
            changes.append(f"status: {old} → {args['status']}")

        if "priority" in args and args["priority"] in self.VALID_PRIORITIES:
            old = task.get("priority")
            task["priority"] = args["priority"]
            changes.append(f"priority: {old} → {args['priority']}")

        if "tags" in args:
            task["tags"] = args["tags"]
            changes.append(f"tags → {', '.join(args['tags'])}")

        if "due_date" in args:
            task["due_date"] = args["due_date"]
            changes.append(f"due → {args['due_date']}")

        if "note" in args and args["note"]:
            task.setdefault("notes", []).append({
                "text": args["note"],
                "added": datetime.now().isoformat(),
            })
            changes.append(f"note added")

        if not changes:
            return ToolResult(
                success=True,
                content=f"No changes specified for task '{task['title']}'",
            )

        task["updated"] = datetime.now().isoformat()
        self._save()

        return ToolResult(
            success=True,
            content=f"Updated '{task['title']}': {', '.join(changes)}",
        )

    def _done(self, args: dict) -> ToolResult:
        """Mark a task as done."""
        task_id = args.get("task_id", "")
        if not task_id:
            return ToolResult(
                success=False, content="",
                error="'task_id' is required for done",
                is_error=True,
            )

        task = self._tasks.get(task_id)
        if not task:
            return ToolResult(
                success=False, content="",
                error=f"No task found with ID '{task_id}'",
                is_error=True,
            )

        task["status"] = "done"
        task["completed"] = datetime.now().isoformat()
        task["updated"] = datetime.now().isoformat()
        self._save()

        return ToolResult(
            success=True,
            content=f"Completed: {task['title']}",
        )

    def _delete(self, args: dict) -> ToolResult:
        """Delete a task."""
        task_id = args.get("task_id", "")
        if not task_id:
            return ToolResult(
                success=False, content="",
                error="'task_id' is required for delete",
                is_error=True,
            )

        task = self._tasks.pop(task_id, None)
        if not task:
            return ToolResult(
                success=False, content="",
                error=f"No task found with ID '{task_id}'",
                is_error=True,
            )

        self._save()
        return ToolResult(
            success=True,
            content=f"Deleted task: {task['title']} ({task_id})",
        )

    def _archive(self) -> ToolResult:
        """Move all completed tasks to archived status."""
        archived = 0
        for task in self._tasks.values():
            if task.get("status") == "done":
                task["status"] = "archived"
                task["archived_at"] = datetime.now().isoformat()
                archived += 1

        if archived == 0:
            return ToolResult(
                success=True,
                content="No completed tasks to archive.",
            )

        self._save()
        return ToolResult(
            success=True,
            content=f"Archived {archived} completed task(s).",
        )

    def _search(self, args: dict) -> ToolResult:
        """Search tasks by text."""
        query = args.get("query", "").lower()
        if not query:
            return ToolResult(
                success=False, content="",
                error="'query' is required for search",
                is_error=True,
            )

        matches = []
        for task in self._tasks.values():
            searchable = " ".join([
                task.get("title", ""),
                task.get("description", ""),
                " ".join(task.get("tags", [])),
                " ".join(n.get("text", "") for n in task.get("notes", [])),
            ]).lower()

            if query in searchable:
                matches.append(task)

        if not matches:
            return ToolResult(
                success=True,
                content=f"No tasks matching '{query}'.",
            )

        lines = [f"Found {len(matches)} task(s) matching '{query}':\n"]
        for t in matches:
            status = t.get("status", "todo")
            lines.append(f"  [{status}] {t['id']} — {t['title']}")
            if t.get("description"):
                lines.append(f"      {t['description'][:100]}")

        return ToolResult(success=True, content="\n".join(lines))
