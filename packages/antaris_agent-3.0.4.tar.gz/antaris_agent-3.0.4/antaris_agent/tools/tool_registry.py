"""Tool Registry for managing native and MCP tools."""

from __future__ import annotations

import asyncio
import logging
from typing import Dict, List, Any, Optional

from antaris_agent.core.cron import get_active_cron_job_context
from . import ToolDef, ToolResult, NativeTool
from .mcp_client import MCPClient

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Central registry for native and MCP tools."""
    
    def __init__(self):
        """Initialize the tool registry."""
        self._native_tools: Dict[str, NativeTool] = {}
        self._mcp_clients: Dict[str, MCPClient] = {}
        self._tool_definitions: Dict[str, ToolDef] = {}
        self._lock = asyncio.Lock()
        self._initialized = False

    async def initialize(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize the registry with configuration.
        
        Args:
            config: Configuration dict containing native tools and MCP servers
        """
        async with self._lock:
            if self._initialized:
                logger.warning("Tool registry already initialized")
                return
            
            # Load native tools from config
            if config and "native_tools" in config:
                for tool_config in config["native_tools"]:
                    logger.info("Would load native tool: %s", tool_config)
            
            # Connect to MCP servers from config
            if config and "mcp_servers" in config:
                for server_config in config["mcp_servers"]:
                    await self.add_mcp_server(
                        name=server_config["name"],
                        transport=server_config.get("transport", "stdio"),
                        command=server_config.get("command"),
                        env=server_config.get("env"),
                        url=server_config.get("url")
                    )
            
            self._initialized = True
            logger.info("Tool registry initialized")

    async def register_native(self, name: str, tool: NativeTool) -> None:
        """Register a native Python tool.
        
        Args:
            name: Name to register the tool under
            tool: NativeTool instance
        """
        async with self._lock:
            self._native_tools[name] = tool
            self._tool_definitions[name] = ToolDef(
                name=name,
                description=tool.description,
                input_schema=tool.input_schema,
                source="native"
            )
            logger.debug("Registered native tool: %s", name)



    async def add_mcp_server(
        self,
        name: str,
        transport: str = "stdio",
        command: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        url: Optional[str] = None
    ) -> None:
        """Add and connect to an MCP server.
        
        Args:
            name: Server name
            transport: Transport type ("stdio" or "sse")
            command: Command to spawn MCP server (for stdio)
            env: Environment variables for the command
            url: HTTP URL for SSE transport
        """
        if name in self._mcp_clients:
            logger.warning("MCP server %s already registered, skipping", name)
            return

        client = MCPClient(
            name=name,
            transport=transport,
            command=command or [],
            env=env or {},
            url=url
        )
        
        try:
            await client.connect()
            tools = await client.list_tools()
            
            self._mcp_clients[name] = client
            
            for tool_def in tools:
                tool_name = tool_def.name if isinstance(tool_def, ToolDef) else tool_def["name"]
                tool_desc = tool_def.description if isinstance(tool_def, ToolDef) else tool_def.get("description", "")
                tool_schema = tool_def.input_schema if isinstance(tool_def, ToolDef) else tool_def.get("inputSchema", {})
                
                # Handle name conflicts with existing tools
                if tool_name in self._tool_definitions:
                    existing = self._tool_definitions[tool_name]
                    if existing.source == "native":
                        # Native tools take priority, prefix the MCP tool
                        prefixed_name = f"{name}.{tool_name}"
                        self._tool_definitions[prefixed_name] = ToolDef(
                            name=prefixed_name,
                            description=tool_desc,
                            input_schema=tool_schema,
                            source=f"mcp:{name}"
                        )
                        logger.debug("MCP tool %s prefixed as %s due to native conflict", tool_name, prefixed_name)
                        continue
                
                self._tool_definitions[tool_name] = ToolDef(
                    name=tool_name,
                    description=tool_desc,
                    input_schema=tool_schema,
                    source=f"mcp:{name}"
                )
                logger.debug("Loaded MCP tool: %s from %s", tool_name, name)
            
        except Exception as e:
            # Cleanup on failure
            try:
                await client.disconnect()
            except Exception:
                pass
            raise

    async def remove_mcp_server(self, name: str) -> None:
        """Remove an MCP server and its tools.
        
        Args:
            name: Server name to remove
        """
        if name not in self._mcp_clients:
            logger.debug("MCP server %s not found, nothing to remove", name)
            return
        
        client = self._mcp_clients.pop(name)
        
        # Remove all tool definitions from this server
        to_remove = [
            tool_name for tool_name, tool_def in self._tool_definitions.items()
            if tool_def.source == f"mcp:{name}"
        ]
        for tool_name in to_remove:
            del self._tool_definitions[tool_name]
        
        try:
            await client.disconnect()
        except Exception as e:
            logger.warning("Error disconnecting MCP server %s: %s", name, e)

    def get_tool_definition(self, name: str):
        """Return the ToolDef for a single tool by name, or None if not found."""
        return self._tool_definitions.get(name)

    async def get_tool_definitions(self) -> List[Dict[str, Any]]:
        """Get all tool definitions in Anthropic tool_use format."""
        definitions = []
        for tool_def in self._tool_definitions.values():
            definitions.append({
                "name": tool_def.name,
                "description": tool_def.description,
                "input_schema": tool_def.input_schema
            })
        return definitions

    def get_tool_definitions_sync(self) -> List[Dict[str, Any]]:
        """Get tool definitions synchronously (for pipeline integration).
        
        This avoids needing to await in synchronous contexts like
        the pipeline's tool loop setup.
        """
        definitions = []
        for tool_def in self._tool_definitions.values():
            definitions.append({
                "name": tool_def.name,
                "description": tool_def.description,
                "input_schema": tool_def.input_schema
            })
        return definitions

    async def execute_tool(self, name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Execute a tool by name.
        
        Args:
            name: Tool name
            arguments: Tool arguments
            
        Returns:
            Tool execution result
        """
        cron_ctx = get_active_cron_job_context()
        if cron_ctx:
            logger.info("[CRON] Tool call requested: job=%s tool=%s args=%s",
                        cron_ctx.get("id"), name, arguments)
            restricted = set(cron_ctx.get("restricted_tools") or [])
            if name in restricted:
                logger.warning("[CRON] Tool call blocked: job=%s tool=%s restricted_tools=%s",
                               cron_ctx.get("id"), name, sorted(restricted))
                return ToolResult(
                    success=False,
                    content=f"Tool '{name}' is blocked for cron job '{cron_ctx.get('name') or cron_ctx.get('id')}'.",
                    error=f"Restricted for cron job: {name}",
                    is_error=True,
                    metadata={"cron_job_id": cron_ctx.get("id"), "restricted": True},
                )
        if name not in self._tool_definitions:
            return ToolResult(
                success=False,
                content=f"Tool '{name}' not found",
                error=f"Unknown tool: {name}",
                is_error=True
            )
        
        tool_def = self._tool_definitions[name]
        
        try:
            if tool_def.source == "native":
                return await self._execute_native_tool(name, arguments)
            elif tool_def.source.startswith("mcp:"):
                server_name = tool_def.source[4:]  # Remove "mcp:" prefix
                return await self._execute_mcp_tool(server_name, name, arguments)
            else:
                return ToolResult(
                    success=False,
                    content=f"Unknown tool source: {tool_def.source}",
                    error=f"Unknown tool source: {tool_def.source}",
                    is_error=True
                )
        except Exception as e:
            logger.error("Tool %s execution failed: %s", name, e, exc_info=True)
            return ToolResult(
                success=False,
                content=f"Tool execution failed: {str(e)}",
                error=str(e),
                is_error=True
            )

    async def _execute_native_tool(self, name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Execute a native Python tool."""
        if name not in self._native_tools:
            return ToolResult(
                success=False,
                content=f"Native tool '{name}' not found",
                error=f"Native tool not registered: {name}",
                is_error=True
            )
        
        tool = self._native_tools[name]
        return await tool.execute(arguments)

    async def _execute_mcp_tool(self, server_name: str, tool_name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Execute an MCP tool via its server."""
        if server_name not in self._mcp_clients:
            return ToolResult(
                success=False,
                content=f"MCP server '{server_name}' not found",
                error=f"MCP server '{server_name}' not found",
                is_error=True
            )
        
        client = self._mcp_clients[server_name]
        
        # Strip server prefix from tool name if present
        actual_tool_name = tool_name
        prefix = f"{server_name}."
        if tool_name.startswith(prefix):
            actual_tool_name = tool_name[len(prefix):]
        
        return await client.call_tool(actual_tool_name, arguments)

    async def get_server_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all MCP servers.
        
        Returns:
            Dict mapping server names to their status info
        """
        status = {}
        for name, client in self._mcp_clients.items():
            tool_count = sum(
                1 for td in self._tool_definitions.values()
                if td.source == f"mcp:{name}"
            )
            
            healthy = False
            try:
                healthy = await client.healthcheck()
            except Exception:
                pass
            
            status[name] = {
                "connected": getattr(client, "_connected", False),
                "healthy": healthy,
                "transport": getattr(client, "transport", "unknown"),
                "tools": tool_count
            }
        
        return status

    async def shutdown(self) -> None:
        """Shutdown the registry and disconnect all servers."""
        for client in self._mcp_clients.values():
            try:
                await client.disconnect()
            except Exception as e:
                logger.warning("Error disconnecting MCP server: %s", e)
        
        self._native_tools.clear()
        self._mcp_clients.clear()
        self._tool_definitions.clear()
        self._initialized = False
        
        logger.info("Tool registry shut down")

    def list_tools(self) -> List[str]:
        """Get list of all registered tool names."""
        return list(self._tool_definitions.keys())
    
    def has_tool(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tool_definitions

    def __repr__(self) -> str:
        native_count = sum(1 for td in self._tool_definitions.values() if td.source == "native")
        mcp_count = sum(1 for td in self._tool_definitions.values() if td.source.startswith("mcp:"))
        server_count = len(self._mcp_clients)
        return f"ToolRegistry(native_tools={native_count}, mcp_tools={mcp_count}, servers={server_count})"