"""Data models for the tools module."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass
class ToolDef:
    """Definition of a tool (native or MCP)."""
    name: str
    description: str
    input_schema: Dict[str, Any]  # JSON Schema
    source: str  # "native" | "mcp:{server_name}"


@dataclass
class ToolResult:
    """Result from executing a tool."""
    success: bool
    content: str  # text result
    error: Optional[str] = None
    is_error: bool = False
    metadata: Optional[Dict[str, Any]] = None


class NativeTool(ABC):
    """Abstract base class for native Python tools."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Tool name."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description."""
        pass
    
    @property
    @abstractmethod
    def input_schema(self) -> Dict[str, Any]:
        """Tool input schema (JSON Schema)."""
        pass
    
    @abstractmethod
    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        """Execute the tool with given arguments."""
        pass