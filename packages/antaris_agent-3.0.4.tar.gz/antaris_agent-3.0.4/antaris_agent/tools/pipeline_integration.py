"""Pipeline integration for tool usage - handles LLM tool loops."""

from __future__ import annotations

import logging
from typing import List, Dict, Any, Tuple, Optional

from antaris_agent.llm.base import LLMProvider, Message, LLMResponse, ThinkingConfig
from antaris_agent.tools.tool_registry import ToolRegistry
from antaris_agent.tools.models import ToolResult

logger = logging.getLogger(__name__)


async def run_tool_loop(
    llm: LLMProvider,
    messages: List[Message],
    tools: List[Dict[str, Any]],
    tool_registry: ToolRegistry,
    max_iterations: int = 100,
    system: str = "",
    model: Optional[str] = None,
    max_tokens: int = 16384,
    temperature: Optional[float] = None,
    tool_middleware=None,
    thinking: Optional[ThinkingConfig] = None,
) -> Tuple[str, List[Message], Dict[str, Any]]:
    """
    Run LLM with tools until text response is received.
    
    Handles tool use loops where LLM calls tools, receives results,
    and continues until it returns a text response instead of tool calls.
    
    Args:
        llm: LLM provider instance
        messages: Initial message history  
        tools: List of tool definitions for the LLM
        tool_registry: Registry for executing tools
        max_iterations: Maximum tool call iterations (default 100; safety net against runaway loops)
        system: System prompt
        model: Model to use (optional)
        max_tokens: Max tokens for LLM response
        temperature: LLM temperature
        tool_middleware: Optional middleware for tool security/validation
    
    Returns:
        Tuple of (final_text_response, updated_messages, metadata)
        
        metadata includes:
        - tool_calls_made: List of {name, args, result} for each tool call
        - iterations: Number of iterations performed
        - stopped_by_max_iterations: Whether loop was stopped by hitting max
    """
    working_messages = list(messages)  # Copy to avoid modifying original
    tool_calls_made = []
    # v1.7.0: Accumulate token counts across tool-loop iterations
    _total_input_tokens = 0
    _total_output_tokens = 0
    _total_cost_usd = 0.0
    iteration = 0
    
    # Checkpoint interval: after this many iterations, pause and warn
    _checkpoint_interval = 5

    while iteration < max_iterations:
        iteration += 1
        logger.debug("Tool loop iteration %d/%d", iteration, max_iterations)

        # Checkpoint: warn operator about extended tool loop
        if iteration > 1 and iteration % _checkpoint_interval == 0:
            _checkpoint_summary = ", ".join(
                f"{tc['name']}({'ok' if tc['success'] else 'FAIL'})"
                for tc in tool_calls_made[-_checkpoint_interval:]
            )
            logger.warning(
                "Tool loop checkpoint at iteration %d — last %d calls: [%s] "
                "— accumulated ~%d input + %d output tokens (~$%.2f)",
                iteration, _checkpoint_interval, _checkpoint_summary,
                _total_input_tokens, _total_output_tokens, _total_cost_usd,
            )
        
        try:
            # Call LLM with current message history and tools
            llm_response: LLMResponse = await llm.complete(
                messages=working_messages,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                tools=tools,
                thinking=thinking,
            )
            
            # v1.7.0: Accumulate tokens from this iteration
            _total_input_tokens += getattr(llm_response, 'input_tokens', 0)
            _total_output_tokens += getattr(llm_response, 'output_tokens', 0)
            _total_cost_usd += getattr(llm_response, 'cost_usd', 0.0)

            # If LLM returned text content and no tool use, we're done
            if llm_response.content and not llm_response.tool_use:
                logger.debug("Tool loop completed with text response after %d iterations", iteration)
                metadata: dict = {
                    "tool_calls_made": tool_calls_made,
                    "iterations": iteration,
                    "stopped_by_max_iterations": False,
                    "input_tokens": _total_input_tokens,
                    "output_tokens": _total_output_tokens,
                    "cost_usd": _total_cost_usd,
                }
                # Part B: Detect "says it but doesn't do it" — LLM expressed intent
                # but no tools were actually fired.
                # Only check the first 200 chars — action intent is expressed early,
                # not buried in closing remarks. Phrases like "let me know" and
                # "working on understanding" were false-positives in the original list.
                if not tool_calls_made:
                    _ACTION_PHRASES = (
                        "i'll ",
                        "i will ",
                        "i'm going to ",
                        "i'll go ahead",
                        "i've started",
                        "i'm starting",
                        "i'm now",
                    )
                    _text_check = llm_response.content.lower()[:200]
                    if any(phrase in _text_check for phrase in _ACTION_PHRASES):
                        metadata["intent_without_action"] = True
                        logger.warning(
                            "Tool loop: LLM expressed action intent but no tools were executed "
                            "(tool_calls_made=0). Response preview: %s",
                            llm_response.content[:120],
                        )
                return llm_response.content, working_messages, metadata
            
            # If LLM returned tool use, execute the tools
            if llm_response.tool_use:
                # Add assistant message with tool calls
                assistant_content = []
                
                # Add text content if present
                if llm_response.content:
                    assistant_content.append({
                        "type": "text", 
                        "text": llm_response.content
                    })
                
                # Add tool use blocks
                for tool_call in llm_response.tool_use:
                    assistant_content.append({
                        "type": "tool_use",
                        "id": tool_call["id"],
                        "name": tool_call["name"],
                        "input": tool_call["input"]
                    })
                
                # Add assistant message to conversation
                working_messages.append(Message(
                    role="assistant",
                    content=assistant_content
                ))
                
                # Execute each tool and collect results
                tool_results = []
                for tool_call in llm_response.tool_use:
                    tool_name = tool_call["name"]
                    tool_args = tool_call["input"]
                    tool_id = tool_call["id"]
                    
                    logger.debug("Executing tool: %s with args: %s", tool_name, tool_args)
                    
                    # Execute the tool
                    try:
                        if tool_middleware:
                            result = await tool_middleware.approve_and_run(
                                tool_name, tool_args,
                                tool_registry.execute_tool, tool_name, tool_args,
                            )
                            if result is None:
                                # Tool was rejected by middleware
                                result = ToolResult(
                                    success=False, content="Tool call rejected by security policy",
                                    error="Rejected", is_error=True
                                )
                        else:
                            result = await tool_registry.execute_tool(tool_name, tool_args)
                        
                        # Record the tool call
                        tool_calls_made.append({
                            "name": tool_name,
                            "args": tool_args,
                            "result": result.content,
                            "success": result.success,
                            "error": result.error
                        })
                        
                        # Prepare tool result for LLM
                        # Anthropic requires non-empty content when is_error=True
                        tool_content = result.content
                        if result.is_error and not tool_content:
                            tool_content = result.error or "Tool execution failed"
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": tool_content,
                            "is_error": result.is_error
                        })
                        
                    except Exception as e:
                        logger.error("Tool %s execution failed: %s", tool_name, e, exc_info=True)
                        _safe_error_msg = "Tool execution failed. The error has been logged."
                        
                        tool_calls_made.append({
                            "name": tool_name,
                            "args": tool_args,
                            "result": _safe_error_msg,
                            "success": False,
                            "error": str(e)
                        })
                        
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": _safe_error_msg,
                            "is_error": True
                        })
                
                # Add user message with tool results
                working_messages.append(Message(
                    role="user",
                    content=tool_results
                ))
                
                # Continue the loop to get LLM response to tool results
                continue
            
            # If we reach here, LLM didn't return content or tool use (shouldn't happen)
            logger.warning("LLM returned neither content nor tool use - treating as empty response")
            return "", working_messages, {
                "tool_calls_made": tool_calls_made,
                "iterations": iteration,
                "stopped_by_max_iterations": False,
                "input_tokens": _total_input_tokens,
                "output_tokens": _total_output_tokens,
                "cost_usd": _total_cost_usd,
            }
            
        except Exception as e:
            logger.error("Error in tool loop iteration %d: %s", iteration, e, exc_info=True)
            return "Something went wrong. The error has been logged.", working_messages, {
                "tool_calls_made": tool_calls_made,
                "iterations": iteration,
                "stopped_by_max_iterations": False,
                "error": str(e),
                "input_tokens": _total_input_tokens,
                "output_tokens": _total_output_tokens,
                "cost_usd": _total_cost_usd,
            }
    
    # Hit max iterations
    logger.warning("Tool loop stopped after %d iterations - max reached", max_iterations)
    return "I've reached the maximum number of tool calls for this conversation. Please try a simpler request.", working_messages, {
        "tool_calls_made": tool_calls_made,
        "iterations": max_iterations,
        "stopped_by_max_iterations": True,
        "input_tokens": _total_input_tokens,
        "output_tokens": _total_output_tokens,
        "cost_usd": _total_cost_usd,
    }