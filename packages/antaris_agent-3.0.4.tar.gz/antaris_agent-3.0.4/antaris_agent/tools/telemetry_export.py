"""
Telemetry export tool — summarize and export substrate telemetry data.

Usage:
    antaris telemetry export [--format csv|json|summary] [--agent <name>]
"""
from __future__ import annotations

import csv
import io
import json
import logging
from collections import Counter, defaultdict
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def find_telemetry_files(config_dir: Optional[str] = None) -> list[Path]:
    """Find all telemetry JSONL files for agents."""
    import os
    base = Path(config_dir) if config_dir else Path.home()
    files = []
    
    # Check named instances
    # Always search from home dir for named instances
    home = Path.home()
    for d in sorted(home.glob(".antarisagent-*")):
        tel_dir = d / "telemetrics"
        if tel_dir.exists():
            files.extend(sorted(tel_dir.glob("*.jsonl")))
    
    # Also check default config dir
    default_tel = Path.home() / ".antaris" / "telemetrics"
    if default_tel.exists():
        files.extend(sorted(default_tel.glob("*.jsonl")))
    
    return files


MAX_EVENTS = 100_000  # Memory safety cap


def load_events(files: list[Path], agent_filter: Optional[str] = None, max_events: int = MAX_EVENTS) -> list[dict]:
    """Load telemetry events from JSONL files (capped at max_events for memory safety)."""
    events = []
    for f in files:
        try:
            with open(f) as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                        if agent_filter and event.get("agent", "").lower() != agent_filter.lower():
                            continue
                        events.append(event)
                        if len(events) >= max_events:
                            logger.warning("Telemetry load capped at %d events", max_events)
                            return events
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.warning("Failed to read %s: %s", f, e)
    return events


def generate_summary(events: list[dict]) -> str:
    """Generate a human-readable summary of telemetry data."""
    if not events:
        return "No telemetry data found."
    
    lines = []
    lines.append(f"=== Substrate Telemetry Summary ===")
    lines.append(f"Total events: {len(events)}")
    
    # Per-agent breakdown
    by_agent = defaultdict(list)
    for e in events:
        by_agent[e.get("agent", "unknown")].append(e)
    
    lines.append(f"Agents: {len(by_agent)}")
    lines.append("")
    
    for agent, agent_events in sorted(by_agent.items()):
        lines.append(f"--- {agent} ({len(agent_events)} events) ---")
        
        # Event type distribution
        type_counts = Counter(e.get("event_type", "unknown") for e in agent_events)
        lines.append(f"  Event types: {dict(type_counts)}")
        
        # Role
        roles = set(e.get("role", "") for e in agent_events if e.get("role"))
        if roles:
            lines.append(f"  Role: {', '.join(roles)}")
        
        # Latency stats
        latencies = [e.get("latency_ms", 0) for e in agent_events if e.get("latency_ms")]
        if latencies:
            avg_lat = sum(latencies) / len(latencies)
            max_lat = max(latencies)
            lines.append(f"  Avg latency: {avg_lat:.0f}ms | Max: {max_lat:.0f}ms")
        
        # Context usage
        ctx_pcts = [e.get("context_window_pct", 0) for e in agent_events if e.get("context_window_pct")]
        if ctx_pcts:
            avg_ctx = sum(ctx_pcts) / len(ctx_pcts)
            max_ctx = max(ctx_pcts)
            lines.append(f"  Avg context: {avg_ctx:.1f}% | Max: {max_ctx:.1f}%")
        
        # Retrieval stats
        hits = [e.get("retrieval_hit_count", 0) for e in agent_events if e.get("retrieval_hit_count") is not None]
        if hits:
            avg_hits = sum(hits) / len(hits)
            lines.append(f"  Avg retrieval hits: {avg_hits:.1f}")
        
        # Instinct fires
        instinct_fires = sum(1 for e in agent_events if e.get("instinct_hit"))
        if instinct_fires:
            lines.append(f"  Instinct fires: {instinct_fires}")
        
        lines.append("")
    
    # Time range
    timestamps = sorted(e.get("timestamp", "") for e in events if e.get("timestamp"))
    if timestamps:
        lines.append(f"Time range: {timestamps[0]} → {timestamps[-1]}")
    
    return "\n".join(lines)


def export_csv(events: list[dict]) -> str:
    """Export events as CSV string."""
    if not events:
        return ""
    
    # Collect all unique keys
    all_keys = set()
    for e in events:
        all_keys.update(e.keys())
    
    fieldnames = sorted(all_keys)
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
    writer.writeheader()
    for e in events:
        writer.writerow(e)
    
    return output.getvalue()


def export_json(events: list[dict]) -> str:
    """Export events as JSON array."""
    return json.dumps(events, indent=2, default=str)


def run_export(
    format: str = "summary",
    agent: Optional[str] = None,
    output_path: Optional[str] = None,
    config_dir: Optional[str] = None,
) -> str:
    """Main export entry point."""
    files = find_telemetry_files(config_dir)
    if not files:
        return "No telemetry files found. Run agents with telemetry harness enabled first."
    
    events = load_events(files, agent_filter=agent)
    
    if format == "summary":
        result = generate_summary(events)
    elif format == "csv":
        result = export_csv(events)
    elif format == "json":
        result = export_json(events)
    else:
        result = generate_summary(events)
    
    if output_path:
        Path(output_path).write_text(result)
        return f"Exported {len(events)} events to {output_path}"
    
    return result
