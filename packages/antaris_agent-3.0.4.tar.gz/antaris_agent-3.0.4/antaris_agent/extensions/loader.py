"""
Extension Loader — discovers and loads extensions from disk and config.

Supports:
  - Python module extensions (import path)
  - Directory-based extensions (with extension.py or __init__.py)
  - Config-declared extensions
  - Auto-discovery from extensions/ directory
"""

from __future__ import annotations

import importlib
import importlib.util
import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .base import Extension
from .security import ExtensionAllowlist, ExtensionSource

if TYPE_CHECKING:
    from .manager import ExtensionManager

logger = logging.getLogger(__name__)


class ExtensionLoader:
    """Discovers and instantiates extensions from various sources.
    
    Usage:
        loader = ExtensionLoader(config_dir="/path/to/.antaris")
        extensions = loader.discover_all()
        
        for ext in extensions:
            manager.register(ext)
    """

    def __init__(self, config_dir: str):
        self.config_dir = Path(config_dir)
        self.extensions_dir = self.config_dir / "extensions"

    def discover_all(self, config: Optional[Dict[str, Any]] = None) -> List[Extension]:
        """Discover all extensions from config and filesystem.
        
        Each returned Extension has a ``_source`` attribute attached indicating
        its provenance (ExtensionSource.CONFIG or ExtensionSource.FILESYSTEM).
        
        Args:
            config: The full config dict (config.json contents).
                    Extensions are declared under "extensions" key.
        
        Returns:
            List of Extension instances ready to register.
        """
        extensions = []
        ext_configs = config.get("extensions", {}) if config else {}
        security_cfg = config.get("security", {}) if config else {}
        security_mode = str(
            security_cfg.get("mode") or (config or {}).get("security_mode") or "open"
        ).lower()
        allowlist = ExtensionAllowlist(config_dir=str(self.config_dir))
        declared_extensions = {
            name
            for name, ext_conf in ext_configs.items()
            if isinstance(ext_conf, dict) and ext_conf.get("enabled", True)
        }
        
        # 1. Config-declared extensions (explicit import paths — trusted)
        for name, ext_conf in ext_configs.items():
            if isinstance(ext_conf, dict) and ext_conf.get("enabled", True):
                module_path = ext_conf.get("module")
                if module_path:
                    ext = self._load_from_module(module_path, name)
                    if ext:
                        ext._source = ExtensionSource.CONFIG  # type: ignore[attr-defined]
                        extensions.append(ext)
        
        # 2. Auto-discover from extensions/ directory (third-party — needs allowlist)
        if self.extensions_dir.exists():
            for item in sorted(self.extensions_dir.iterdir()):
                # Skip hidden files/dirs and __pycache__
                if item.name.startswith(('.', '_')):
                    continue

                candidate_name = self._get_filesystem_extension_name(item)
                if not candidate_name:
                    continue

                # In non-open modes, filesystem extensions must be explicitly declared.
                if security_mode != "open" and candidate_name not in declared_extensions:
                    logger.debug(
                        "Skipping filesystem extension '%s' in %s mode: not declared in config",
                        candidate_name,
                        security_mode,
                    )
                    continue

                # In non-open modes, require allowlist approval before import/exec.
                if security_mode != "open" and not allowlist.is_approved(candidate_name):
                    logger.warning(
                        "Skipping extension '%s': not on allowlist for %s mode",
                        candidate_name,
                        security_mode,
                    )
                    continue
                
                # Directory-based extension
                if item.is_dir():
                    ext = self._load_from_directory(item)
                    if ext:
                        # Skip if already loaded from config
                        if not any(e.name == ext.name for e in extensions):
                            ext._source = ExtensionSource.FILESYSTEM  # type: ignore[attr-defined]
                            extensions.append(ext)
                
                # Single-file extension
                elif item.suffix == '.py':
                    ext = self._load_from_file(item)
                    if ext:
                        if not any(e.name == ext.name for e in extensions):
                            ext._source = ExtensionSource.FILESYSTEM  # type: ignore[attr-defined]
                            extensions.append(ext)
        
        logger.info("Discovered %d extension(s)", len(extensions))
        return extensions

    def _get_filesystem_extension_name(self, path: Path) -> str:
        """Infer a filesystem extension's name without executing Python code."""
        if path.is_file():
            return path.stem if path.suffix == '.py' else ""

        manifest_file = path / "extension.json"
        if manifest_file.exists():
            try:
                with open(manifest_file) as f:
                    manifest = json.load(f)
                manifest_name = manifest.get("name")
                if isinstance(manifest_name, str) and manifest_name.strip():
                    return manifest_name.strip()
            except Exception as e:
                logger.warning("Error reading manifest %s: %s", manifest_file, e)

        ext_file = path / "extension.py"
        init_file = path / "__init__.py"
        if ext_file.exists() or init_file.exists() or manifest_file.exists():
            return path.name

        return ""

    def _load_from_module(self, module_path: str, name: str) -> Optional[Extension]:
        """Load an extension from a Python module path.
        
        Looks for a class named 'extension' or the first Extension subclass.
        """
        try:
            module = importlib.import_module(module_path)
            return self._find_extension_class(module, name)
        except ImportError as e:
            logger.warning("Could not import extension module '%s': %s", module_path, e)
            return None
        except Exception as e:
            logger.error("Error loading extension from '%s': %s", module_path, e)
            return None

    def _load_from_directory(self, dir_path: Path) -> Optional[Extension]:
        """Load an extension from a directory.
        
        Looks for:
          1. extension.py with an Extension subclass
          2. __init__.py with an Extension subclass
          3. extension.json manifest + any .py file
        """
        # Try extension.py first
        ext_file = dir_path / "extension.py"
        if ext_file.exists():
            return self._load_from_file(ext_file, dir_path.name)
        
        # Try __init__.py
        init_file = dir_path / "__init__.py"
        if init_file.exists():
            return self._load_from_file(init_file, dir_path.name)
        
        # Try manifest-based loading
        manifest_file = dir_path / "extension.json"
        if manifest_file.exists():
            return self._load_from_manifest(manifest_file)
        
        logger.debug("No extension entry point found in %s", dir_path)
        return None

    def _load_from_file(self, file_path: Path, fallback_name: str = "") -> Optional[Extension]:
        """Load an extension from a single .py file."""
        try:
            name = fallback_name or file_path.stem
            spec = importlib.util.spec_from_file_location(
                f"antaris_ext_{name}", str(file_path)
            )
            if spec is None or spec.loader is None:
                logger.warning("Could not create module spec for %s", file_path)
                return None
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
            
            return self._find_extension_class(module, name)
            
        except Exception as e:
            logger.error("Error loading extension from %s: %s", file_path, e)
            return None

    def _load_from_manifest(self, manifest_path: Path) -> Optional[Extension]:
        """Load an extension from a JSON manifest file.
        
        The manifest specifies metadata and the entry point module.
        """
        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
            
            entry_point = manifest.get("entry_point", "extension.py")
            entry_file = manifest_path.parent / entry_point
            
            if not entry_file.exists():
                logger.warning("Extension entry point not found: %s", entry_file)
                return None
            
            ext = self._load_from_file(entry_file, manifest.get("name", ""))
            if ext:
                # Override metadata from manifest
                if manifest.get("name"):
                    ext.name = manifest["name"]
                if manifest.get("version"):
                    ext.version = manifest["version"]
                if manifest.get("description"):
                    ext.description = manifest["description"]
                if manifest.get("author"):
                    ext.author = manifest["author"]
            
            return ext
            
        except Exception as e:
            logger.error("Error loading manifest %s: %s", manifest_path, e)
            return None

    def _find_extension_class(self, module, fallback_name: str = "") -> Optional[Extension]:
        """Find and instantiate the Extension subclass in a module.
        
        Looks for:
          1. Module-level 'extension' variable
          2. Module-level 'Extension' class  
          3. First subclass of Extension found
        """
        # Check for pre-instantiated extension
        if hasattr(module, 'extension') and isinstance(module.extension, Extension):
            return module.extension
        
        # Check for Extension subclass
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type) 
                and issubclass(attr, Extension) 
                and attr is not Extension
                and not attr.__name__.startswith('_')
            ):
                try:
                    instance = attr()
                    if not instance.name and fallback_name:
                        instance.name = fallback_name
                    return instance
                except Exception as e:
                    logger.warning("Could not instantiate %s: %s", attr_name, e)
        
        logger.debug("No Extension subclass found in %s", getattr(module, '__name__', 'unknown'))
        return None
