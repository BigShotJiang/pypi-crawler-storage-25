"""Security level constants and utilities."""
from __future__ import annotations

LEVEL_OPEN = 0
LEVEL_STANDARD = 1
LEVEL_SANDBOXED = 2
LEVEL_SECURED = 3
LEVEL_ENCRYPTED = 4

LEVEL_NAMES = {
    0: "Open",
    1: "Standard",
    2: "Sandboxed",
    3: "Secured",
    4: "Encrypted",
}

LEVEL_DESCRIPTIONS = {
    0: "No restrictions. Full access. Developer mode.",
    1: "Light safety net. File ops scoped to workspace + home. Subprocesses logged.",
    2: "Filesystem restricted. Subprocesses blocked. Guard: monitor.",
    3: "Network allowlisted. Tool calls logged. Destructive ops need approval. Guard: warn.",
    4: "All tools need approval. Owner-only memory directory. Mandatory audit. Guard: block.",
}

DEFAULT_LEVEL = LEVEL_STANDARD

DESTRUCTIVE_TOOL_KEYWORDS = {"write", "delete", "shell", "exec", "remove", "kill"}

# Tools that are always destructive regardless of name keywords
DESTRUCTIVE_TOOLS = {"git", "spawn_subagent", "file_ops"}

# Specific operations within tools that are destructive
DESTRUCTIVE_OPERATIONS = {
    "git": {"commit", "push", "branch", "stash", "checkout", "add"},
    "file_ops": {"write", "edit"},
}


def is_destructive_tool(tool_name: str, operation: str = "") -> bool:
    """Check if a tool or operation is destructive."""
    name_lower = tool_name.lower()

    # Exact match on known destructive tools
    if name_lower in DESTRUCTIVE_TOOLS:
        return True

    # Keyword match for other tools
    if any(kw in name_lower for kw in DESTRUCTIVE_TOOL_KEYWORDS):
        return True

    return False


def can_escalate(current: int, target: int) -> bool:
    """Check if escalation is allowed (up only, no downgrade)."""
    return target > current


def level_name(level: int) -> str:
    """Get the human-readable name for a security level."""
    return LEVEL_NAMES.get(level, f"Unknown({level})")