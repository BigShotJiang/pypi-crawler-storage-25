"""Antaris Agent audit hook — filesystem, subprocess, network enforcement via sys.addaudithook().

Security notes
--------------
- **TOCTOU mitigation:** At SECURED/ENCRYPTED levels, symlinks are blocked
  entirely — if the raw path differs from the resolved path (indicating a
  symlink is in the chain), access is denied.  This eliminates the race
  window where an attacker swaps a symlink component between resolve and
  open.  At STANDARD/SANDBOXED, symlinks are followed normally (the resolved
  target is checked against the allowlist).

- **``/tmp`` graduation:** At STANDARD/SANDBOXED levels, system temp
  directories (``/tmp``, ``/private/tmp``, ``/var/folders``) are broadly
  allowed.  At SECURED/ENCRYPTED levels, only the workspace itself (which
  may contain a scoped temp dir) and Python/system paths are allowed — broad
  ``/tmp`` is NOT permitted, reducing the attack surface from shared temp
  directories.
"""
from __future__ import annotations

import os
import site
import sys
from pathlib import Path
from typing import Union

from .levels import LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED, LEVEL_SECURED, LEVEL_ENCRYPTED

# ---------------------------------------------------------------------------
# Module-level state (mutated once by install())
# ---------------------------------------------------------------------------


class _SecurityLevel:
    """Immutable-from-outside security level container.

    Prevents direct attribute assignment so that external code cannot lower
    the security level by doing ``audit_hook._LEVEL = 0``.  The level can
    only be *raised* via the ``_escalate()`` method (called by the module-
    level ``escalate()`` function).

    Uses ``__slots__`` to prevent dynamic attribute creation, and overrides
    ``__setattr__`` to block all direct writes.  Internal mutation goes
    through ``object.__setattr__`` inside ``_escalate()`` and ``_set()``.
    """

    __slots__ = ("_value",)

    def __init__(self, initial: int) -> None:
        object.__setattr__(self, "_value", initial)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError(
            "Security level cannot be modified directly. Use escalate()."
        )

    def __delattr__(self, name: str) -> None:
        raise AttributeError(
            "Security level attributes cannot be deleted."
        )

    @property
    def value(self) -> int:
        """Current security level (read-only)."""
        return self._value

    def _escalate(self, new_level: int) -> bool:
        """Raise the level — only upward transitions allowed.

        Returns True if the level was raised, False if *new_level* is not
        strictly greater than the current value.
        """
        if new_level <= self._value:
            return False
        object.__setattr__(self, "_value", new_level)
        return True

    def _set(self, level: int) -> None:
        """Unconditionally set the level (used only during ``install()``)."""
        object.__setattr__(self, "_value", level)

    def __repr__(self) -> str:
        return f"_SecurityLevel({self._value})"

    def __str__(self) -> str:
        return str(self._value)

    def __int__(self) -> int:
        return self._value

    def __eq__(self, other: object) -> bool:
        if isinstance(other, int):
            return self._value == other
        if isinstance(other, _SecurityLevel):
            return self._value == other._value
        return NotImplemented

    def __lt__(self, other: object) -> bool:
        if isinstance(other, int):
            return self._value < other
        if isinstance(other, _SecurityLevel):
            return self._value < other._value
        return NotImplemented

    def __le__(self, other: object) -> bool:
        if isinstance(other, int):
            return self._value <= other
        if isinstance(other, _SecurityLevel):
            return self._value <= other._value
        return NotImplemented

    def __gt__(self, other: object) -> bool:
        if isinstance(other, int):
            return self._value > other
        if isinstance(other, _SecurityLevel):
            return self._value > other._value
        return NotImplemented

    def __ge__(self, other: object) -> bool:
        if isinstance(other, int):
            return self._value >= other
        if isinstance(other, _SecurityLevel):
            return self._value >= other._value
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._value)


_LEVEL = _SecurityLevel(LEVEL_STANDARD)
_WORKSPACE: str = ""


def _coerce_path(raw_path) -> Path | None:
    """Best-effort conversion of audit hook path args into a resolved Path.

    Rules:
    - None -> None
    - int (file descriptor) -> None
    - bytes -> decoded with os.fsdecode
    - str/PathLike -> Path(...).resolve()

    Returns None if coercion fails.
    """
    if raw_path is None:
        return None
    if isinstance(raw_path, int):
        return None
    try:
        if isinstance(raw_path, (bytes, bytearray)):
            raw_path = os.fsdecode(raw_path)
        p = Path(raw_path)
        # Resolve without requiring the path to exist; follow symlinks if present.
        return p.resolve(strict=False)
    except Exception:
        return None


def _is_within(path: Path, root: str | Path) -> bool:
    """Return True if *path* is equal to or contained within *root* (resolved)."""
    try:
        root_p = root if isinstance(root, Path) else Path(root)
        root_r = root_p.resolve()
        path_r = path.resolve()
        if path_r == root_r:
            return True
        path_r.relative_to(root_r)
        return True
    except Exception:
        return False


def _has_symlink_component(raw_path: str | Path) -> bool:
    """Return True if *raw_path* contains any symlink component.

    Walks each component of the path from root to leaf, checking whether
    any intermediate or final component is a symlink.  Used at SECURED+
    levels to block symlink-based TOCTOU attacks.
    """
    try:
        p = Path(raw_path)
        # Check each parent component and the leaf
        for part in list(p.parents)[:-1]:  # parents excludes '/' itself at the end
            if part.is_symlink():
                return True
        if p.is_symlink():
            return True
        return False
    except Exception:
        return True  # If we can't check, assume symlink (fail-closed)


def _matches_system_read_prefix(path: Path) -> bool:
    """Return True if *path* matches one of the safe system read prefixes."""
    try:
        path_r = path.resolve()
    except Exception:
        return False

    for prefix in _SYSTEM_READ_PREFIXES:
        # Treat file prefixes (those with a suffix) as exact-only, unless the
        # original prefix is an existing directory.
        try:
            prefix_p = Path(prefix)
            prefix_r = prefix_p.resolve()
        except Exception:
            continue

        if path_r == prefix_r:
            return True

        # Only treat prefixes that explicitly end with a separator as directory
        # prefixes. Otherwise, require exact match.
        if str(prefix).endswith(os.sep):
            try:
                path_r.relative_to(prefix_r)
                return True
            except Exception:
                pass

    return False


_ALLOWED_PATHS: set[str] = set()
_INSTALLED: bool = False  # Guard against double audit hook installation

# ---------------------------------------------------------------------------
# Read-only system paths that stdlib modules legitimately access.
# These are inherently safe — they are OS-provided, read-only resources
# that Python's own standard library (mimetypes, ssl, locale, timezone,
# etc.) needs to function correctly.
# ---------------------------------------------------------------------------
# Entries ending in "/" are directory prefixes (match anything beneath).
# Entries without "/" are exact file matches OR prefix matches with "/".
_SYSTEM_READ_PREFIXES: tuple[str, ...] = (
    # MIME databases (Python mimetypes module)
    "/etc/mime.types",
    "/etc/httpd/",         # /etc/httpd/mime.types, /etc/httpd/conf/mime.types
    "/etc/apache/",        # /etc/apache/mime.types
    "/etc/apache2/",       # /etc/apache2/mime.types
    # SSL / TLS certificates & config
    "/etc/ssl/",           # /etc/ssl/certs/*, /etc/ssl/openssl.cnf
    "/etc/pki/",           # /etc/pki/tls/certs/ca-bundle.crt
    # System config reads (stdlib: socket, pwd, grp, etc.)
    "/etc/localtime",
    "/etc/resolv.conf",
    "/etc/hosts",
    "/etc/passwd",         # getpwnam / getpwuid (stdlib pwd module)
    "/etc/group",          # grp module
    "/etc/nsswitch.conf",
    # /usr/share resources (timezone, locale, MIME)
    "/usr/share/zoneinfo/",
    "/usr/share/locale/",
    "/usr/share/mime/",
    # Homebrew / /usr/local resources
    "/usr/local/etc/mime.types",
    "/usr/local/etc/httpd/",
    "/usr/local/etc/openssl/",
    "/usr/local/share/mime/",
    # macOS: /etc → /private/etc (symlink target). Keep this scoped to subpaths
    # that stdlib legitimately reads (ssl, hosts, resolv.conf, localtime, etc.).
    # Do NOT blanket-allow /private/etc/.
    "/private/etc/hosts",
    "/private/etc/resolv.conf",
    "/private/etc/localtime",
    "/private/etc/ssl/",
    # Device files
    "/dev/null",
    "/dev/urandom",
    "/dev/random",
    "/dev/zero",
)

# Hosts always permitted in secured/encrypted modes
ALLOWED_HOSTS: set[str] = {
    "api.anthropic.com",
    "api.openai.com",
    "generativelanguage.googleapis.com",
    "localhost",
    "127.0.0.1",
}


def _build_allowed_paths() -> set[str]:
    """Collect Python stdlib and site-packages roots that are always safe.

    IMPORTANT: We do NOT add sys.prefix/sys.base_prefix directly, because on
    many systems these resolve to coarse roots like /usr or /usr/local, which
    would allow access to /usr/bin/* and other dangerous paths.

    Instead, we add only the specific stdlib/site-packages directories.
    """
    candidates: list[str] = []

    # Specific stdlib and platform stdlib directories (NOT parent prefixes)
    try:
        import sysconfig

        for path_name in ("stdlib", "platstdlib", "purelib", "platlib"):
            p = sysconfig.get_path(path_name)
            if p:
                candidates.append(p)
    except Exception:
        pass

    # site-packages directories
    try:
        candidates.extend(site.getsitepackages())
    except AttributeError:
        pass
    try:
        candidates.append(site.getusersitepackages())
    except AttributeError:
        pass

    allowed: set[str] = set()
    for p in candidates:
        if p:
            try:
                resolved = str(Path(p).resolve())
                # Safety: reject paths that resolve to overly broad roots
                if resolved in ("/", "/usr", "/usr/local", "/opt", "/opt/homebrew"):
                    continue
                allowed.add(resolved)
            except Exception:
                pass
    return allowed


def install(level_or_mode: Union[int, str], workspace_path: str) -> None:
    """Register the Antaris Agent audit hook for the given security level.

    This calls ``sys.addaudithook`` which is **irremovable** for the lifetime
    of the interpreter — call it exactly once, at bot startup.

    Args:
        level_or_mode: Security level (0-4) or legacy mode string for backward compat.
        workspace_path: Absolute path to the bot's workspace root.
    """
    global _WORKSPACE, _ALLOWED_PATHS, _INSTALLED

    # Accept both int level and string mode for backward compat
    if isinstance(level_or_mode, str):
        mode_map = {
            "open": LEVEL_OPEN,
            "standard": LEVEL_STANDARD,
            "sandboxed": LEVEL_SANDBOXED,
            "secured": LEVEL_SECURED,
            "encrypted": LEVEL_ENCRYPTED,
            "locked": LEVEL_ENCRYPTED,  # legacy alias
        }
        level = mode_map.get(level_or_mode, LEVEL_STANDARD)
    else:
        level = level_or_mode

    _LEVEL._set(level)
    _WORKSPACE = str(Path(workspace_path).resolve())
    _ALLOWED_PATHS = _build_allowed_paths()

    # Always allow the bot's own package directory (needed to import its own modules)
    _bot_pkg_dir = str(Path(__file__).resolve().parent.parent)
    _ALLOWED_PATHS.add(_bot_pkg_dir)

    # Allow bundled suite module directories
    for _mod_name in ("parsica_memory", "antaris_agent.suite.guard", "antaris_agent.suite.context", "antaris_agent.suite.router", "antaris_agent.suite.pipeline"):
        try:
            _mod = __import__(_mod_name, fromlist=[_mod_name.split(".")[-1]])
            _mod_dir = str(Path(_mod.__file__).resolve().parent)
            _ALLOWED_PATHS.add(_mod_dir)
        except Exception:
            pass

    # Allow bundled parsica_memory package (top-level, not under antaris_agent)
    # Needed for package-data reads (word_expansion.json, etc.)
    try:
        import parsica_memory as _pm
        _pm_dir = str(Path(_pm.__file__).resolve().parent)
        _ALLOWED_PATHS.add(_pm_dir)
    except Exception:
        pass

    # Also allow the workspace path itself
    _ALLOWED_PATHS.add(_WORKSPACE)

    # Level 0 (OPEN) skips audit hook entirely
    # Guard: sys.addaudithook is irremovable — only install once per process
    if level > LEVEL_OPEN and not _INSTALLED:
        sys.addaudithook(_antaris_hook)
        _INSTALLED = True


def escalate(new_level: int) -> bool:
    """Escalate to a higher security level.

    Returns:
        False if new_level <= current (can't downgrade), True otherwise.
    """
    return _LEVEL._escalate(new_level)


def current_level() -> int:
    """Get the current security level."""
    return _LEVEL.value


def get_level() -> int:
    """Get the current security level (alias for current_level())."""
    return _LEVEL.value


def add_allowed_host(host: str) -> None:
    """Add a host to the network allowlist for SECURED/ENCRYPTED levels."""
    ALLOWED_HOSTS.add(host)


# ---------------------------------------------------------------------------
# File access helper (shared by STANDARD and SANDBOXED+ branches)
# ---------------------------------------------------------------------------

def _check_file_access(resolved: Path | str, level: _SecurityLevel | None = None) -> bool:
    """Return True if file access to *resolved* should be permitted.

    Accepts a Path or string for backward compatibility, but performs all
    comparisons with resolved Path objects to avoid prefix-matching bugs.

    Args:
        resolved: The resolved path to check.
        level: Security level to check against.  When called from the audit
            hook this is the closure-captured singleton; defaults to the
            module-level ``_LEVEL`` for backward compat.
    """
    lvl = level if level is not None else _LEVEL

    p = resolved if isinstance(resolved, Path) else _coerce_path(resolved)
    if p is None:
        # Fail-closed: if we can't coerce the path, deny access.
        # Integer FDs are already handled (returned None by _coerce_path,
        # but filtered out in _antaris_hook before reaching here).
        return False

    # 1. Workspace
    if _WORKSPACE and _is_within(p, _WORKSPACE):
        return True

    # 2. Approved home subdirectories
    try:
        home_dir = Path.home().resolve()
        allowed_home_subdirs = (
            home_dir / ".antaris",
            home_dir / ".antarisagent",
            home_dir / ".openclaw",
            home_dir / ".config",
        )
        for subdir in allowed_home_subdirs:
            if _is_within(p, subdir):
                return True
    except Exception:
        pass

    # 3. /tmp and system temp directories
    # At STANDARD/SANDBOXED: broad /tmp allowed (stdlib, pytest, runtime needs)
    # At SECURED/ENCRYPTED: /tmp NOT allowed (reduces shared-temp attack surface)
    if lvl < LEVEL_SECURED:
        for tmp_root in ("/tmp", "/private/tmp", "/var/folders", "/private/var/folders"):
            if _is_within(p, tmp_root):
                return True

    # 4. Python stdlib / site-packages / venv (all resolved roots)
    for allowed in _ALLOWED_PATHS:
        if _is_within(p, allowed):
            return True

    # 5. Read-only system paths
    if _matches_system_read_prefix(p):
        return True

    return False


# ---------------------------------------------------------------------------
# The audit hook
# ---------------------------------------------------------------------------

def _antaris_hook(event: str, args: tuple, _lvl: _SecurityLevel = _LEVEL) -> None:  # noqa: C901
    """sys.audit hook — enforces level-based restrictions.

    The *_lvl* default captures the ``_SecurityLevel`` singleton at function-
    definition time so that even if external code replaces the module-level
    ``_LEVEL`` name, the hook still reads from the original (immutable)
    object.
    """
    try:
        # ------------------------------------------------------------------ #
        # File access
        # ------------------------------------------------------------------ #
        if event == "open":
            # args: (path, mode, flags)
            raw_path = args[0] if args else None
            if raw_path is None:
                return

            resolved = _coerce_path(raw_path)
            if resolved is None:
                return

            # TOCTOU mitigation: at SECURED/ENCRYPTED, block symlinks entirely.
            # This prevents an attacker from swapping a symlink component
            # between our resolve() and the kernel's actual open().
            if _lvl >= LEVEL_SECURED and not isinstance(raw_path, int):
                try:
                    raw_str = os.fsdecode(raw_path) if isinstance(raw_path, (bytes, bytearray)) else str(raw_path)
                    if _has_symlink_component(raw_str):
                        raise PermissionError(
                            f"[Antaris Agent/level-{_lvl}] Symlink in path blocked "
                            f"(TOCTOU mitigation): {raw_str}"
                        )
                except PermissionError:
                    raise
                except Exception:
                    pass  # If symlink check itself fails, fall through to normal check

            if _lvl >= LEVEL_STANDARD:
                if not _check_file_access(resolved, level=_lvl):
                    raise PermissionError(
                        f"[Antaris Agent/level-{_lvl}] File access blocked: {resolved}"
                    )

        # ------------------------------------------------------------------ #
        # Subprocess
        # ------------------------------------------------------------------ #
        elif event == "subprocess.Popen":
            if _lvl == LEVEL_STANDARD:
                # Level 1: Allow but could log (logging not implemented in audit hook)
                return
            elif _lvl >= LEVEL_SANDBOXED:
                # Level 2+: Block subprocess execution
                raise PermissionError(
                    f"[Antaris Agent/level-{_lvl}] Subprocess execution blocked"
                )

        # ------------------------------------------------------------------ #
        # exec() — ENCRYPTED only
        # ------------------------------------------------------------------ #
        elif event == "exec":
            if _lvl >= LEVEL_ENCRYPTED:
                raise PermissionError(
                    f"[Antaris Agent/level-{_lvl}] Code execution blocked"
                )

        # ------------------------------------------------------------------ #
        # Network — SECURED and ENCRYPTED
        # ------------------------------------------------------------------ #
        elif event == "socket.connect":
            if _lvl >= LEVEL_SECURED:
                # args varies by address family; try to extract host
                addr = args[1] if len(args) > 1 else None
                if addr is None:
                    return
                if isinstance(addr, (list, tuple)) and len(addr) >= 1:
                    host = str(addr[0])
                elif isinstance(addr, str):
                    # Unix socket path — allow
                    return
                else:
                    return

                if host not in ALLOWED_HOSTS:
                    raise PermissionError(
                        f"[Antaris Agent/level-{_lvl}] Network access blocked: {host}"
                    )

    except PermissionError:
        # Always propagate PermissionError — that's how we block things
        raise
    except Exception:
        # Swallow everything else; we must never crash the bot
        pass
