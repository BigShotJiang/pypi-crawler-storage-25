"""
antaris_agent/core/subagents.py

Subagent system for Antaris Agent.

Allows the bot (or user) to spawn named subagents — isolated async workers
that each receive a scoped context packet, run their own LLM call chain,
and report results back to Discord and/or the parent memory store.

Key design decisions:
- Isolation via asyncio tasks (same process, separate context/state)
  matches OpenClaw's isolated session model — lightweight, no IPC overhead
- Each subagent shares the parent's LLM dispatcher + API key (same provider)
- Max concurrent agents is configurable (default 4, tunable per machine)
- Auto-naming: if no name given, assigns a, b, c, d ... or a1, b1 on overflow
- Results are posted to Discord if a channel is available, and saved to memory
"""
from __future__ import annotations

import asyncio
import logging
import string
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

if TYPE_CHECKING:
    from antaris_agent.core.bot import Bot

from antaris_agent.core.subagent_tools import (
    SubagentRole,
    get_tools_for_role,
    get_role_constraints,
    FORBIDDEN_TOOLS,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Auto-name generator  (a, b, c … z, a1, b1 …)
# ---------------------------------------------------------------------------
_ALPHA = list(string.ascii_lowercase)


def _auto_name(existing: set[str]) -> str:
    for ch in _ALPHA:
        if ch not in existing:
            return ch
    suffix = 1
    while True:
        for ch in _ALPHA:
            candidate = f"{ch}{suffix}"
            if candidate not in existing:
                return candidate
        suffix += 1


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

class SubagentStatus(str, Enum):
    RUNNING = "running"
    DONE    = "done"
    FAILED  = "failed"
    KILLED  = "killed"


@dataclass
class SubagentResult:
    text: str
    elapsed: float   # seconds
    tokens_used: int = 0


@dataclass
class Subagent:
    name: str
    task: str
    context: str                    # pre-built context string passed at spawn
    parent_user_id: str = ""       # user who spawned this subagent
    parent_session_id: str = ""    # Commit 6: parent session for provenance tracking
    parent_agent_id: str = ""      # Commit 6: parent agent identity
    parent_body_id: str = ""       # Commit 6: parent body identity
    role: Optional[SubagentRole] = None  # M1: mechanical tool restriction via role
    channel_id: str = ""           # durable Discord delivery target
    thread_id: str = ""            # durable Discord thread target when available
    platform: str = ""             # source platform for completion routing
    status: SubagentStatus = SubagentStatus.RUNNING
    result: Optional[SubagentResult] = None
    started_at: float = field(default_factory=time.monotonic)
    task_handle: Optional[asyncio.Task] = None
    origin_channel: object = None   # Discord channel captured at spawn time (fix: avoids race condition)

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self.started_at

    def summary(self) -> str:
        icon = {
            SubagentStatus.RUNNING: "⏳",
            SubagentStatus.DONE:    "✅",
            SubagentStatus.FAILED:  "❌",
            SubagentStatus.KILLED:  "🛑",
        }[self.status]
        elapsed = f"{self.elapsed:.1f}s"
        if self.result:
            preview = self.result.text[:80].replace("\n", " ")
            return f"{icon} **{self.name}** ({elapsed}) — {preview}…"
        return f"{icon} **{self.name}** ({elapsed}) — {self.task[:60]}"


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class SubagentRegistry:
    """
    In-process registry of all spawned subagents for a bot session.

    Thread-safe via asyncio — all access should happen on the event loop.
    """

    def __init__(self, bot: "Bot", max_agents: int = 4):
        self.bot = bot
        self.max_agents = max_agents
        self._agents: dict[str, Subagent] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def active_count(self) -> int:
        return sum(
            1 for a in self._agents.values()
            if a.status == SubagentStatus.RUNNING
        )

    def get(self, name: str) -> Optional[Subagent]:
        return self._agents.get(name)

    def list_all(self) -> list[Subagent]:
        return list(self._agents.values())

    async def spawn(
        self,
        task: str,
        name: Optional[str] = None,
        context: Optional[str] = None,
        on_done: Optional[Callable] = None,
        origin_channel: object = None,
        parent_user_id: str = "",
        parent_session_id: str = "",
        parent_agent_id: str = "",
        parent_body_id: str = "",
        role: Optional[SubagentRole] = None,
    ) -> tuple[bool, str]:
        """
        Spawn a new subagent.

        Returns (success, message).
        origin_channel: Discord channel object captured at call time — stored on
        the agent so concurrent spawns from different channels don't race.
        role: SubagentRole for mechanical tool restriction. If None, subagent
        gets NO tools (LLM-only) — defense in depth.
        """
        if self.active_count >= self.max_agents:
            return False, (
                f"⚠️ Max concurrent subagents reached ({self.max_agents}). "
                f"Kill one with `!agents kill <name>` or wait for one to finish."
            )

        # Auto-name from RUNNING agents only (completed agents free their names)
        running_names = {
            n for n, a in self._agents.items()
            if a.status == SubagentStatus.RUNNING
        }
        resolved_name = name or _auto_name(running_names)

        if resolved_name in self._agents and self._agents[resolved_name].status == SubagentStatus.RUNNING:
            return False, f"⚠️ Subagent **{resolved_name}** is already running."

        if not parent_session_id:
            parent_session_id = getattr(self.bot, "_active_session_id", "") or ""

        # Build context: use provided, or auto-scope from memory
        ctx = context or await self._build_auto_context(
            task,
            parent_user_id=parent_user_id,
            parent_session_id=parent_session_id,
        )

        # Capture origin channel at spawn time to avoid race conditions
        channel = origin_channel or getattr(self.bot, "_active_discord_channel", None)
        channel_id = str(getattr(channel, "id", "") or "")
        thread_id = ""
        if channel is not None:
            try:
                import discord  # type: ignore
                if isinstance(channel, discord.Thread):
                    thread_id = channel_id
                    channel_id = str(getattr(channel, "parent_id", "") or channel_id)
            except Exception:
                pass

        agent = Subagent(
            name=resolved_name, task=task, context=ctx,
            parent_user_id=parent_user_id or "",
            parent_session_id=parent_session_id,
            parent_agent_id=parent_agent_id,
            parent_body_id=parent_body_id,
            role=role,
            channel_id=channel_id,
            thread_id=thread_id,
            platform="discord" if channel_id else "",
            origin_channel=channel,
        )
        self._agents[resolved_name] = agent

        # Launch async task
        agent.task_handle = asyncio.create_task(
            self._run(agent, on_done),
            name=f"subagent-{resolved_name}",
        )

        logger.info("Spawned subagent '%s' — task: %s", resolved_name, task[:80])
        return True, f"🚀 Spawned subagent **{resolved_name}** — `{task[:80]}`"

    async def spawn_many(
        self,
        tasks: list[str],
        names: Optional[list[str]] = None,
        on_done: Optional[Callable] = None,
        origin_channel: object = None,
        parent_user_id: str = "",
        parent_session_id: str = "",
        parent_agent_id: str = "",
        parent_body_id: str = "",
        role: Optional[SubagentRole] = None,
    ) -> list[tuple[bool, str]]:
        """Spawn multiple subagents at once. Pre-validates count against available slots."""
        available = self.max_agents - self.active_count
        if available <= 0:
            return [(False, f"⚠️ Max concurrent subagents reached ({self.max_agents}).")]

        # Cap tasks to available slots upfront — clean UX, no partial noisy failures
        tasks = tasks[:available]
        if names:
            names = names[:available]

        results = []
        for i, task in enumerate(tasks):
            name = names[i] if names and i < len(names) else None
            ok, msg = await self.spawn(task, name=name, on_done=on_done, origin_channel=origin_channel, parent_user_id=parent_user_id, parent_session_id=parent_session_id, parent_agent_id=parent_agent_id, parent_body_id=parent_body_id, role=role)
            results.append((ok, msg))
        return results

    async def kill(self, name: str) -> tuple[bool, str]:
        agent = self._agents.get(name)
        if not agent:
            return False, f"No subagent named **{name}**."
        if agent.status != SubagentStatus.RUNNING:
            return False, f"Subagent **{name}** is already {agent.status.value}."
        if agent.task_handle:
            agent.task_handle.cancel()
        agent.status = SubagentStatus.KILLED
        logger.info("Killed subagent '%s'", name)
        return True, f"🛑 Killed subagent **{name}**."

    def get_subagent_results(self, parent_session_id: str = "") -> list[dict]:
        """Commit 6: Get all subagent results, optionally filtered by parent session."""
        results = []
        for name, agent in self._agents.items():
            if agent.status != SubagentStatus.DONE or not agent.result:
                continue
            if parent_session_id and agent.parent_session_id != parent_session_id:
                continue
            results.append({
                "name": name,
                "task": agent.task,
                "result": agent.result.text,
                "elapsed": agent.result.elapsed,
                "parent_session_id": agent.parent_session_id,
                "parent_agent_id": agent.parent_agent_id,
                "parent_body_id": agent.parent_body_id,
            })
        return results

    def result_text(self, name: str) -> Optional[str]:
        agent = self._agents.get(name)
        if not agent or not agent.result:
            return None
        return agent.result.text

    def status_board(self) -> str:
        if not self._agents:
            return "No subagents spawned this session."
        lines = [f"**Subagents** ({self.active_count}/{self.max_agents} running)"]
        for agent in self._agents.values():
            lines.append(agent.summary())
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_memory_store(self, user_id: str = ""):
        """Deprecated no-op retained for backward compatibility.

        FIX-8 removed direct MemorySystem access for subagent task tracking.
        Callers must use BotMemory.add_task()/complete_task() with the parent
        user_id instead of reaching into a store directly.
        """
        logger.debug("_get_memory_store is deprecated; use BotMemory wrappers instead")
        return None

    async def _build_auto_context(
        self,
        task: str,
        parent_user_id: str = "",
        parent_session_id: str = "",
    ) -> str:
        """Build a scoped context packet from memory relevant to the task."""
        try:
            if hasattr(self.bot, "memory") and self.bot.memory:
                if not parent_user_id:
                    return ""
                memories = await self.bot.memory.recall(
                    user_id=parent_user_id,
                    query=task,
                    session_id=parent_session_id or "",
                    read_only=True,
                )
                if memories:
                    block = "\n".join(f"- {m}" for m in memories[:8])
                    return f"[Relevant context]\n{block}"
        except Exception as e:
            logger.debug("Auto-context build failed: %s", e)
        return ""

    # Discord mention pattern — strip @everyone, @here, and <@id> from LLM output
    _MENTION_RE = None

    @classmethod
    def _strip_mentions(cls, text: str) -> str:
        import re
        if cls._MENTION_RE is None:
            cls._MENTION_RE = re.compile(r"@(everyone|here)|<@[!&]?\d+>")
        return cls._MENTION_RE.sub("[mention removed]", text)

    # Default LLM call timeout in seconds — prevents runaway subagents
    LLM_TIMEOUT = 300

    async def _run(
        self,
        agent: Subagent,
        on_done,
    ) -> None:
        """Core execution loop for a single subagent."""
        t0 = time.monotonic()
        task_name = f"subagent:{agent.name}"
        session_id = f"subagent-{agent.name}"

        # Register task in Parsica Memory so ambient awareness sees it (Bug #3)
        parent_user_id = agent.parent_user_id or ""
        if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
            try:
                register_session = getattr(self.bot.memory, "register_session", None)
                if callable(register_session):
                    result = register_session(
                        parent_user_id,
                        session_id,
                        parent_session_id=agent.parent_session_id,
                        agent_id=agent.parent_agent_id or getattr(self.bot, "_active_agent_id", "") or "",
                        metadata={"task": agent.task, "subagent_name": agent.name},
                    )
                    if asyncio.iscoroutine(result):
                        await result
            except Exception as e:
                logger.debug("Session registration failed for '%s': %s", agent.name, e)
            try:
                # Register task on PARENT session so parent knows about delegated work
                _parent_sid = agent.parent_session_id or session_id
                await self.bot.memory.add_task(parent_user_id, _parent_sid, task_name)
                logger.debug("Registered task '%s' on parent session '%s' for subagent '%s'", task_name, _parent_sid, agent.name)
            except Exception as e:
                logger.debug("Task registration failed for '%s': %s", agent.name, e)

        try:
            # Build system prompt with inherited persona constraints
            _base_rules = (
                f"You are a focused subagent named '{agent.name}'. "
                f"Complete the assigned task thoroughly and concisely. "
                f"Report results directly — no filler, no preamble."
            )

            # Inherit parent's SOUL.md and RULES.md for behavioral constraints
            _persona_block = ""
            try:
                _config_dir = Path(getattr(self.bot.config, "config_path", "")).parent
                _soul_path = _config_dir / "SOUL.md"
                _rules_path = _config_dir / "RULES.md"
                _parts = []
                if _soul_path.exists():
                    _soul = _soul_path.read_text().strip()
                    if _soul:
                        _parts.append(f"## Identity & Values\n{_soul[:2000]}")
                if _rules_path.exists():
                    _rules = _rules_path.read_text().strip()
                    if _rules:
                        _parts.append(f"## Rules\n{_rules[:2000]}")
                if _parts:
                    _persona_block = "\n\n---\n".join(_parts)
            except Exception as _pe:
                logger.debug("Subagent persona load failed: %s", _pe)

            # Subagent constraints — role-based if available, generic fallback
            # M1: get_role_constraints() provides role-specific text as defense-in-depth
            # The real enforcement is mechanical: filtered tool definitions below
            if agent.role:
                _constraints = get_role_constraints(agent.role)
            else:
                _constraints = (
                    "\n\n---\n## Subagent constraints\n"
                    "You are a subagent, not the primary agent. You MUST NOT:\n"
                    "- Commit, push, or tag any git repository\n"
                    "- Publish to PyPI or any package registry\n"
                    "- Create, rename, or delete directories outside the immediate task scope\n"
                    "- Modify config files (.env, config.json, auth-profiles.json)\n"
                    "- Spawn additional subagents\n"
                    "- Copy files to remote hosts\n"
                    "- Restructure project layout\n"
                    "If your task requires any of these, report back to the parent agent "
                    "with your recommendation instead of executing directly."
                )

            system = _base_rules
            if _persona_block:
                system += f"\n\n{_persona_block}"
            system += _constraints

            # Build messages: context + task
            if agent.context:
                content = f"Context provided:\n{agent.context}\n\nTask: {agent.task}"
            else:
                content = agent.task

            from antaris_agent.llm.base import Message
            messages = [Message(role="user", content=content)]

            # Resolve provider + model from bot config
            provider = self.bot.config.provider_name
            model = self.bot.config.model

            # M1: Mechanical tool restriction — build filtered tool list from role
            # If no role assigned, subagent gets NO tools (LLM-only, safest default)
            _tools = None
            if agent.role and hasattr(self.bot, "tool_registry") and self.bot.tool_registry:
                _tools = get_tools_for_role(agent.role, self.bot.tool_registry)
                logger.info(
                    "Subagent '%s' (role=%s): %d tools available",
                    agent.name, agent.role.value, len(_tools) if _tools else 0,
                )
            else:
                logger.info(
                    "Subagent '%s': no role assigned — LLM-only (no tools)",
                    agent.name,
                )

            # Timeout guard — prevents runaway subagents from holding slots forever
            response = await asyncio.wait_for(
                self.bot.dispatcher.complete(
                    provider=provider,
                    model=model,
                    messages=messages,
                    system=system,
                    tools=_tools or None,
                ),
                timeout=self.LLM_TIMEOUT,
            )

            elapsed = time.monotonic() - t0
            agent.result = SubagentResult(
                text=response.content,
                elapsed=elapsed,
                tokens_used=response.input_tokens + response.output_tokens,
            )
            agent.status = SubagentStatus.DONE
            logger.info("Subagent '%s' done in %.1fs", agent.name, elapsed)
            if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
                try:
                    update_status = getattr(self.bot.memory, "update_session_status", None)
                    if callable(update_status):
                        result = update_status(parent_user_id, session_id, SubagentStatus.DONE.value)
                        if asyncio.iscoroutine(result):
                            await result
                except Exception as e:
                    logger.debug("Session status update failed for '%s': %s", agent.name, e)

            await self._save_to_memory(agent)
            await self._report_to_discord(agent)

        except asyncio.TimeoutError:
            agent.status = SubagentStatus.FAILED
            agent.result = SubagentResult(
                text=f"Timed out after {self.LLM_TIMEOUT}s.",
                elapsed=time.monotonic() - t0,
            )
            logger.warning("Subagent '%s' timed out", agent.name)
            if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
                try:
                    update_status = getattr(self.bot.memory, "update_session_status", None)
                    if callable(update_status):
                        result = update_status(parent_user_id, session_id, SubagentStatus.FAILED.value)
                        if asyncio.iscoroutine(result):
                            await result
                except Exception as e:
                    logger.debug("Session status update failed for '%s': %s", agent.name, e)
            await self._report_to_discord(agent)
        except asyncio.CancelledError:
            agent.status = SubagentStatus.KILLED
            logger.info("Subagent '%s' cancelled", agent.name)
            if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
                try:
                    update_status = getattr(self.bot.memory, "update_session_status", None)
                    if callable(update_status):
                        result = update_status(parent_user_id, session_id, SubagentStatus.KILLED.value)
                        if asyncio.iscoroutine(result):
                            await result
                except Exception as e:
                    logger.debug("Session status update failed for '%s': %s", agent.name, e)
        except Exception as e:
            agent.status = SubagentStatus.FAILED
            agent.result = SubagentResult(
                text=f"Error: {e}",
                elapsed=time.monotonic() - t0,
            )
            logger.exception("Subagent '%s' failed: %s", agent.name, e)
            if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
                try:
                    update_status = getattr(self.bot.memory, "update_session_status", None)
                    if callable(update_status):
                        result = update_status(parent_user_id, session_id, SubagentStatus.FAILED.value)
                        if asyncio.iscoroutine(result):
                            await result
                except Exception as e:
                    logger.debug("Session status update failed for '%s': %s", agent.name, e)
            await self._report_to_discord(agent)
        finally:
            # Complete task in Parsica Memory so ambient awareness clears it (Bug #3)
            if parent_user_id and hasattr(self.bot, "memory") and self.bot.memory:
                try:
                    # Complete on PARENT session (matches add_task which uses _parent_sid)
                    _parent_sid_for_complete = agent.parent_session_id or session_id
                    await self.bot.memory.complete_task(parent_user_id, _parent_sid_for_complete, task_name)
                    logger.debug("Completed task '%s' on parent session '%s' for subagent '%s'", task_name, _parent_sid_for_complete, agent.name)
                except Exception as e:
                    logger.debug("Task completion failed for '%s': %s", agent.name, e)

            if on_done:
                try:
                    if asyncio.iscoroutinefunction(on_done):
                        await on_done(agent)
                    else:
                        on_done(agent)
                except Exception:
                    pass

    async def _save_to_memory(self, agent: Subagent) -> None:
        """Save subagent result to the memory store."""
        try:
            if not (hasattr(self.bot, "memory") and self.bot.memory and agent.result):
                return
            user_message = f"Subagent '{agent.name}' task: {agent.task}"
            bot_response = agent.result.text
            # BotMemory.ingest() is async with signature:
            #   (user_id, user_message, bot_response, session_id="", channel_id="")
            # Previous code used text= kwarg which doesn't exist (Bug #2),
            # and wrapped in run_in_executor despite ingest being async.
            if not agent.parent_user_id:
                return
            # Commit 6: Build provenance tags from parent session
            extra_tags = [f"subagent:{agent.name}"]
            if agent.parent_session_id:
                extra_tags.append(f"parent_session:{agent.parent_session_id}")
            if agent.parent_agent_id:
                extra_tags.append(f"parent_agent:{agent.parent_agent_id}")
            if agent.parent_body_id:
                extra_tags.append(f"parent_body:{agent.parent_body_id}")

            await self.bot.memory.ingest(
                user_id=agent.parent_user_id,
                user_message=user_message,
                bot_response=bot_response,
                session_id=f"subagent-{agent.name}",
                extra_tags=extra_tags,
            )
        except Exception as e:
            logger.debug("Subagent memory save failed: %s", e)

    async def _report_to_discord(self, agent: Subagent) -> None:
        """Post subagent result through the bot's outbound adapter using durable delivery metadata."""
        try:
            target_channel_id = agent.thread_id or agent.channel_id
            if agent.platform != "discord" or not target_channel_id:
                return

            from antaris_agent.channels.base import OutboundMessage
            adapter = None
            for ch in getattr(self.bot, "_channels", []):
                if ch.__class__.__name__ == "DiscordAdapter":
                    adapter = ch
                    break
            if not adapter:
                raise RuntimeError("Discord adapter unavailable")

            if agent.status == SubagentStatus.DONE and agent.result:
                header = f"✅ **Subagent {agent.name}** finished in {agent.result.elapsed:.1f}s"
                body = self._strip_mentions(agent.result.text)
                full = f"{header}\n{body}"
                await adapter.send(OutboundMessage(channel_id=target_channel_id, text=full))

            elif agent.status in (SubagentStatus.FAILED, SubagentStatus.KILLED) and agent.result:
                icon = "❌" if agent.status == SubagentStatus.FAILED else "🛑"
                await adapter.send(
                    OutboundMessage(
                        channel_id=target_channel_id,
                        text=f"{icon} **Subagent {agent.name}**: {agent.result.text[:200]}",
                    )
                )
        except Exception as e:
            logger.error("Subagent Discord report failed for %s (platform=%s channel_id=%s thread_id=%s): %s", agent.name, agent.platform, agent.channel_id, agent.thread_id, e)
            if agent.parent_session_id and hasattr(self.bot, "sessions") and self.bot.sessions:
                try:
                    from antaris_agent.llm.base import Message
                    session = await self.bot.sessions.get_session(agent.parent_session_id)
                    if session:
                        session.add_to_history(
                            Message(
                                role="assistant",
                                content=f"[Subagent delivery failure] {agent.name} could not post completion to Discord: {e}",
                            )
                        )
                except Exception as session_err:
                    logger.error("Failed to write subagent delivery failure event for %s: %s", agent.name, session_err)
