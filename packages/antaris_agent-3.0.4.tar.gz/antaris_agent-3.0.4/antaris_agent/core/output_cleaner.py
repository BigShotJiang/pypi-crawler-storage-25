"""
Output Cleaner — Strip AI slop from LLM responses.

Runs as a lightweight regex pass between the LLM call (Stage 6) and the
output guard (Stage 7). No LLM call, no network, just string ops.

Usage in pipeline.py:
    from antaris_agent.core.output_cleaner import clean_output

    # After Stage 6, before Stage 7:
    raw_text = clean_output(raw_text)

The cleaner:
  1. Strips common filler openers ("Great question!", "I'd be happy to help!")
  2. Strips hedging preambles ("Sure, I can help with that. ")
  3. Strips performative closers ("Let me know if you need anything else!")
  4. Collapses resulting double-newlines
  5. Never touches content inside code blocks (``` ... ```)

All patterns are case-insensitive. The list is intentionally conservative
to avoid false positives on legitimate content.
"""

import re
from typing import Optional

# ── Filler openers ────────────────────────────────────────────────────────
# These appear at the start of a response and add zero information.
# Matched case-insensitively, stripped along with trailing whitespace.
_FILLER_OPENERS = [
    r"great question[.!]*\s*",
    r"that'?s a great question[.!]*\s*",
    r"that'?s a fantastic question[.!]*\s*",
    r"that'?s an? (?:excellent|interesting|wonderful|good) question[.!]*\s*",
    r"good question[.!]*\s*",
    r"excellent question[.!]*\s*",
    r"wonderful question[.!]*\s*",
    r"i'?d be happy to help(?:\s+(?:you\s+)?with that)?[.!]*\s*",
    r"i'?d love to help(?:\s+(?:you\s+)?with that)?[.!]*\s*",
    r"i'?m happy to help(?:\s+(?:you\s+)?with that)?[.!]*\s*",
    r"happy to help[.!]*\s*",
    r"absolutely[.!]+\s*",
    r"of course[.!]+\s*",
    r"sure thing[.!]+\s*",
    r"certainly[.!]+\s*",
    r"definitely[.!]+\s*",
    r"no problem[.!]+\s*",
    r"sure,?\s+i\s+can\s+(?:help\s+(?:you\s+)?with\s+that|do\s+that|handle\s+that)[.!]*\s*",
    r"let me help (?:you )?with that[.!]*\s*",
    r"thanks for (?:asking|sharing|bringing this up)[.!]*\s*",
    r"thank you for (?:asking|sharing|bringing this up)[.!]*\s*",
    r"that'?s a (?:really )?(?:great|fantastic|excellent|wonderful) (?:idea|thought|point)[.!]*\s*",
    r"what a (?:great|fantastic|excellent|wonderful) (?:idea|thought|point)[.!]*\s*",
]

# ── Hedging preambles ─────────────────────────────────────────────────────
# Mid-sentence filler that precedes actual content.
_HEDGING_PREAMBLES = [
    r"so,?\s+",
    r"well,?\s+",
    r"now,?\s+",
    r"alright,?\s+so\s+",
    r"okay,?\s+so\s+",
]

# ── Performative closers ──────────────────────────────────────────────────
# These appear at the end and add nothing. Matched at end of string.
_FILLER_CLOSERS = [
    r"\s*let me know if you (?:need|have|want) (?:anything|any(?:thing)?) else[.!]*",
    r"\s*let me know if (?:there'?s anything else|you'?d like (?:me to|anything else))[.!]*",
    r"\s*(?:hope|i hope) (?:this|that) helps[.!]*",
    r"\s*feel free to (?:ask|reach out|let me know) if you (?:need|have) (?:any(?:thing)?|more) (?:questions|help)[.!]*",
    r"\s*don'?t hesitate to (?:ask|reach out|let me know)[.!]*",
    r"\s*i'?m here (?:to help|if you need (?:anything|me))[.!]*",
    r"\s*happy to (?:help|assist) (?:further|anytime)[.!]*",
    r"\s*is there anything else (?:you'?d like|i can help with|you need)[.!?]*",
]

# Compile once at import time
_OPENER_PATTERNS = [re.compile(p, re.IGNORECASE) for p in _FILLER_OPENERS]
_HEDGING_PATTERNS = [re.compile(r"^" + p, re.IGNORECASE) for p in _HEDGING_PREAMBLES]
_CLOSER_PATTERNS = [re.compile(p + r"\s*$", re.IGNORECASE) for p in _FILLER_CLOSERS]

# Code block fence pattern
_CODE_FENCE = re.compile(r"```")


def _split_code_blocks(text: str) -> list[tuple[str, bool]]:
    """Split text into segments, tagging each as code or prose.

    Returns list of (segment_text, is_code) tuples.
    Code blocks (``` ... ```) are returned verbatim and never cleaned.
    """
    parts = _CODE_FENCE.split(text)
    result = []
    in_code = False
    for part in parts:
        result.append((part, in_code))
        in_code = not in_code
    return result


def _clean_prose(text: str, strip_openers: bool = True,
                 strip_closers: bool = True) -> str:
    """Clean a single prose segment (not inside a code block)."""
    s = text

    if strip_openers:
        # Strip filler openers (only at the very start)
        for pattern in _OPENER_PATTERNS:
            m = pattern.match(s)
            if m:
                s = s[m.end():]
                break  # only strip one opener

        # Strip hedging preamble (only if it's now at the start after opener removal)
        for pattern in _HEDGING_PATTERNS:
            m = pattern.match(s)
            if m:
                # Capitalize the next character after removing the hedge
                rest = s[m.end():]
                if rest and rest[0].islower():
                    rest = rest[0].upper() + rest[1:]
                s = rest
                break

    if strip_closers:
        # Strip performative closers (only at the very end)
        for pattern in _CLOSER_PATTERNS:
            s = pattern.sub("", s)

    return s


def clean_output(text: str) -> str:
    """Clean AI slop from an LLM response.

    Safe to call on any text. Preserves code blocks verbatim.
    Returns cleaned text, or original text if cleaning would
    produce an empty string.
    """
    if not text or not text.strip():
        return text

    segments = _split_code_blocks(text)

    # Only apply opener stripping to the first prose segment,
    # and closer stripping to the last prose segment.
    cleaned_parts = []
    first_prose_idx = None
    last_prose_idx = None

    for i, (seg, is_code) in enumerate(segments):
        if not is_code and seg.strip():
            if first_prose_idx is None:
                first_prose_idx = i
            last_prose_idx = i

    for i, (seg, is_code) in enumerate(segments):
        if is_code:
            # Re-add the code fences
            cleaned_parts.append("```" + seg + "```")
        else:
            is_first = (i == first_prose_idx)
            is_last = (i == last_prose_idx)
            cleaned = _clean_prose(
                seg,
                strip_openers=is_first,
                strip_closers=is_last,
            )
            cleaned_parts.append(cleaned)

    result = "".join(cleaned_parts)

    # Collapse triple+ newlines to double
    result = re.sub(r"\n{3,}", "\n\n", result)

    # If cleaning nuked everything, return original
    if not result.strip():
        return text

    return result.strip()
