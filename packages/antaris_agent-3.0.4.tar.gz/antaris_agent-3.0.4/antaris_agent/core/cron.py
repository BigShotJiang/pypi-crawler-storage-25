"""
Antaris Agent Cron System — scheduled jobs for periodic tasks.

Job types:
    systemEvent — injects text as a system prompt into the pipeline
    agentTurn   — fires a prompt through the full pipeline as if a user sent it

Persistence: ~/.antaris/cron/jobs.json
"""
import asyncio
import json
import logging
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime as _datetime, timezone
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Callable, Awaitable
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)


DEFAULT_AGENT_TURN_RESTRICTED_TOOLS = [
    "shell",
    "file_ops",
    "spawn_subagent",
    "git",
    "cron",
    "discord_proactive",
    "discord_send_file",
    "notification",
]

_CRON_JOB_CTX: ContextVar[Optional[dict]] = ContextVar("cron_job_context", default=None)


@contextmanager
def cron_job_context(job: "CronJob"):
    """Mark the current async context as executing on behalf of a cron job."""
    token = _CRON_JOB_CTX.set({
        "id": job.id,
        "name": job.name,
        "payload_kind": job.payload_kind,
        "restricted_tools": list(job.restricted_tools or []),
    })
    try:
        yield
    finally:
        _CRON_JOB_CTX.reset(token)


def get_active_cron_job_context() -> Optional[dict]:
    """Return the active cron execution context, if any."""
    return _CRON_JOB_CTX.get()


# ── Cron expression helpers ───────────────────────────────────────────────────

def _match_cron_field(field_expr: str, value: int, min_val: int, max_val: int) -> bool:
    """Check if *value* matches a single cron field expression.

    Supports: ``*``, specific values (``30``), ranges (``1-5``),
    steps (``*/15``, ``1-30/5``), comma-separated lists (``1,3,5``),
    and wraparound ranges (``23-3`` for hours, ``5-1`` for DOW).
    Returns False (never raises) on malformed input.

    Values and range endpoints outside ``[min_val, max_val]`` are rejected.

    Note: ``N/step`` (bare number with step, e.g. ``5/2``) is not supported —
    the step is silently ignored and only the exact value matches.  This is
    consistent with Vixie cron.  Use ``N-max/step`` or ``*/step`` instead.
    """
    try:
        # R2-GPT: Reject value itself if outside the valid domain
        if value < min_val or value > max_val:
            return False

        for part in field_expr.split(","):
            part = part.strip()
            if not part:
                continue

            # Split off an optional step suffix
            step = None
            if "/" in part:
                base, step_str = part.split("/", 1)
                step = int(step_str)
                if step <= 0:
                    continue
            else:
                base = part

            if base == "*":
                # Whole range with optional step
                if step is None:
                    return True  # "*" matches everything
                if (value - min_val) % step == 0:
                    return True
            elif "-" in base:
                lo_s, hi_s = base.split("-", 1)
                lo, hi = int(lo_s), int(hi_s)
                # R2-GPT: Reject out-of-range endpoints
                if lo < min_val or lo > max_val or hi < min_val or hi > max_val:
                    continue
                if lo <= hi:
                    # Normal range
                    if step is None:
                        if lo <= value <= hi:
                            return True
                    else:
                        v = lo
                        while v <= hi:
                            if v == value:
                                return True
                            v += step
                else:
                    # P0-1: Wraparound range (e.g., 23-3 for hours, 5-1 for DOW)
                    if step is None:
                        if value >= lo or value <= hi:
                            return True
                    else:
                        # Step iteration on wraparound: lo..max_val, then min_val..hi
                        v = lo
                        while v <= max_val:
                            if v == value:
                                return True
                            v += step
                        # Continue from min_val side
                        # Calculate the next step value after wrapping
                        overshoot = v - max_val - 1 + min_val
                        v = overshoot
                        while v <= hi:
                            if v == value:
                                return True
                            v += step
            else:
                # Exact value — reject if outside valid domain
                exact = int(base)
                if exact < min_val or exact > max_val:
                    continue
                if exact == value:
                    return True
        return False
    except (ValueError, TypeError):
        return False


def _normalize_dow_field(dow: str) -> str:
    """Rewrite ``7`` to ``0`` in a day-of-week cron field.

    Standard cron allows both 0 and 7 for Sunday.  To avoid ambiguity in
    ranges and steps (e.g. ``5-7`` meaning Fri-Sun vs a synthetic 0-7 domain),
    we normalize all ``7`` references to ``0`` before matching against the
    canonical 0-6 domain.
    """
    import re as _re
    # Replace standalone "7" (not part of larger numbers like "17" or "71")
    # in the DOW expression with "0".
    return _re.sub(r'\b7\b', '0', dow)


def _match_cron_expr(expr: str, dt: _datetime) -> bool:
    """Return True if *dt* matches the 5-field cron expression *expr*.

    Fields: ``minute hour day_of_month month day_of_week``
    Day-of-week: 0 = Sunday … 6 = Saturday (7 is also Sunday).

    P0-2: When BOTH dom and dow are non-wildcard (not ``*``), uses OR
    semantics (standard Vixie cron). When only one is non-wildcard,
    uses AND semantics.
    """
    try:
        fields = expr.split()
        if len(fields) != 5:
            return False

        minute, hour, dom, month, dow = fields

        # Python isoweekday: Mon=1 … Sun=7  →  cron: Sun=0, Mon=1 … Sat=6
        cron_dow = dt.isoweekday() % 7  # Sun(7)→0, Mon(1)→1, … Sat(6)→6

        # Minute and hour and month must always match
        if not _match_cron_field(minute, dt.minute, 0, 59):
            return False
        if not _match_cron_field(hour, dt.hour, 0, 23):
            return False
        if not _match_cron_field(month, dt.month, 1, 12):
            return False

        # P0-2: DOM+DOW OR semantics (Vixie cron)
        dom_is_wild = dom.strip() == "*"
        dow_is_wild = dow.strip() == "*"

        dom_match = _match_cron_field(dom, dt.day, 1, 31)

        # R3-GPT: Normalize DOW field — rewrite all occurrences of "7" to "0"
        # BEFORE matching so ranges like "5-7" become "5-0" (wraparound) and
        # the domain is a clean 0-6.  This avoids the dual-Sunday ambiguity
        # where both 0 and 7 represent Sunday in a 0-7 domain.
        dow_normalized = _normalize_dow_field(dow)
        dow_match = _match_cron_field(dow_normalized, cron_dow, 0, 6)

        if dom_is_wild and dow_is_wild:
            # Both wildcards — always matches (dom and dow don't restrict)
            return True
        elif not dom_is_wild and not dow_is_wild:
            # Both are restricted — OR semantics (fire if EITHER matches)
            return dom_match or dow_match
        else:
            # Only one is restricted — AND semantics (both must match)
            return dom_match and dow_match
    except Exception:
        return False


@dataclass
class CronJob:
    id: str
    name: str
    schedule_kind: str          # "every" | "at" | "cron"
    schedule_every_ms: Optional[int] = None   # for kind=every
    schedule_at: Optional[str] = None         # for kind=at (ISO timestamp)
    schedule_cron: Optional[str] = None       # for kind=cron (cron expression)
    schedule_tz: Optional[str] = None         # IANA tz name for cron evaluation
    schedule_anchor_ms: Optional[int] = None
    payload_kind: str = "systemEvent"         # "systemEvent" | "agentTurn"
    payload_text: str = ""
    restricted_tools: list[str] = field(default_factory=list)  # denylist enforced for cron-fired agentTurn jobs
    channel_id: Optional[str] = None         # which channel to deliver to
    delivery_mode: str = "none"
    delivery_channel: Optional[str] = None
    delivery_to: Optional[str] = None
    delivery_best_effort: bool = True
    enabled: bool = True
    last_run: Optional[float] = None         # epoch seconds
    run_count: int = 0
    status: str = "idle"
    consecutive_errors: int = 0
    last_error: Optional[str] = None
    last_duration_ms: Optional[int] = None
    last_success: Optional[float] = None
    delete_after_run: bool = False
    created_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        # All agentTurn cron jobs start with the standard denylist unless
        # a non-empty explicit list was supplied — fixes live !cron add gap.
        if self.payload_kind == "agentTurn" and not self.restricted_tools:
            self.restricted_tools = list(DEFAULT_AGENT_TURN_RESTRICTED_TOOLS)
        # Back-compat: legacy/systemEvent jobs created before payload_text was
        # mandatory get their name as a fallback payload.
        if (
            self.payload_kind == "systemEvent"
            and isinstance(self.payload_text, str)
            and not self.payload_text.strip()
        ):
            self.payload_text = (self.name or "").strip()

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CronJob":
        data = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        if data.get("payload_kind") == "agentTurn" and "restricted_tools" not in data:
            data["restricted_tools"] = list(DEFAULT_AGENT_TURN_RESTRICTED_TOOLS)
        return cls(**data)

    def validate(self) -> tuple[bool, Optional[str]]:
        """Validate persisted or newly-created job data."""
        if not self.id or not isinstance(self.id, str):
            return False, "missing/invalid id"
        if not self.name or not isinstance(self.name, str):
            return False, "missing/invalid name"
        if self.schedule_kind not in {"every", "at", "cron"}:
            return False, f"invalid schedule_kind: {self.schedule_kind!r}"
        if self.payload_kind not in {"systemEvent", "agentTurn"}:
            return False, f"invalid payload_kind: {self.payload_kind!r}"
        if not isinstance(self.payload_text, str) or not self.payload_text.strip():
            return False, "missing/invalid payload_text"
        if not isinstance(self.restricted_tools, list) or any(not isinstance(t, str) or not t.strip() for t in self.restricted_tools):
            return False, "invalid restricted_tools"

        if self.schedule_kind == "every":
            if not isinstance(self.schedule_every_ms, int) or self.schedule_every_ms <= 0:
                return False, "invalid schedule_every_ms"
        elif self.schedule_kind == "at":
            if not isinstance(self.schedule_at, str) or not self.schedule_at.strip():
                return False, "missing/invalid schedule_at"
        elif self.schedule_kind == "cron":
            if not isinstance(self.schedule_cron, str) or len(self.schedule_cron.split()) != 5:
                return False, "missing/invalid schedule_cron"

        return True, None

    # P2-7: Human-readable repr
    def __repr__(self) -> str:
        return f"CronJob(id={self.id!r}, name={self.name!r}, kind={self.schedule_kind!r}, enabled={self.enabled})"


class CronScheduler:
    """
    Simple async cron scheduler for Antaris Agent.

    Usage:
        scheduler = CronScheduler(jobs_path, on_fire_callback)
        await scheduler.start()          # runs in background
        scheduler.add_job(job)
        scheduler.remove_job(job_id)
        await scheduler.stop()
    """

    TICK_INTERVAL = 10  # check every 10 seconds
    MAX_CONSECUTIVE_ERRORS = 5  # P2-4: auto-disable threshold

    def __init__(
        self,
        jobs_path: str | Path,
        on_fire: Callable[[CronJob], Awaitable[None]],
        default_tz: str | None = None,
    ):
        self.jobs_path = Path(jobs_path)
        self.on_fire = on_fire
        self.default_tz = default_tz  # v2.3.2: fallback timezone for jobs without schedule_tz
        self._jobs: dict[str, CronJob] = {}
        self._task: Optional[asyncio.Task] = None
        self._load()

    def _load(self):
        """Load jobs from disk.  P2-5: isolate per-job errors."""
        if self.jobs_path.exists():
            try:
                data = json.loads(self.jobs_path.read_text())
                for job_dict in data.get("jobs", []):
                    try:
                        job = CronJob.from_dict(job_dict)
                        ok, err = job.validate()
                        if not ok:
                            raise ValueError(err)
                        self._jobs[job.id] = job
                    except Exception as e:
                        logger.warning("CronScheduler: skipping corrupt job entry: %s", e)
                logger.info("CronScheduler: loaded %d jobs", len(self._jobs))
            except Exception as e:
                logger.warning("CronScheduler: failed to load jobs: %s", e)

    def _save(self):
        """Persist jobs to disk.  P2-3: atomic write-to-temp-then-rename."""
        self.jobs_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"jobs": [j.to_dict() for j in self._jobs.values()]}
        tmp = self.jobs_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, indent=2))
        tmp.rename(self.jobs_path)

    def add_job(self, job: CronJob) -> CronJob:
        """Add or replace a job."""
        ok, err = job.validate()
        if not ok:
            raise ValueError(f"Invalid cron job: {err}")
        self._jobs[job.id] = job
        self._save()
        logger.info("CronScheduler: added job %s (%s)", job.id, job.name)
        return job

    def remove_job(self, job_id: str) -> bool:
        """Remove a job by id."""
        if job_id in self._jobs:
            del self._jobs[job_id]
            self._save()
            logger.info("CronScheduler: removed job %s", job_id)
            return True
        return False

    def list_jobs(self) -> list[CronJob]:
        return list(self._jobs.values())

    def get_job(self, job_id: str) -> Optional[CronJob]:
        return self._jobs.get(job_id)

    def _is_due(self, job: CronJob) -> bool:
        """Check if a job is due to run."""
        if not job.enabled:
            return False
        now = time.time()
        if job.schedule_kind == "every":
            if not job.schedule_every_ms or job.schedule_every_ms <= 0:
                return False
            interval_s = job.schedule_every_ms / 1000
            if job.schedule_anchor_ms is not None:
                anchor_s = job.schedule_anchor_ms / 1000
                elapsed = now - anchor_s
                if elapsed < 0:
                    return False
                periods_passed = int(elapsed / interval_s)
                current_period_fire = anchor_s + periods_passed * interval_s
                # P1-3: Anchor + last_run=None — fire at current_period_fire if
                # it's within one interval of now (i.e., recent enough). This means
                # a brand-new anchored job fires at the most recent aligned time.
                if job.last_run is None:
                    return current_period_fire >= (now - interval_s)
                return job.last_run < current_period_fire
            last = job.last_run or (now - interval_s)  # fire immediately if never run
            return (now - last) >= interval_s
        elif job.schedule_kind == "at":
            if not job.schedule_at or job.run_count > 0:
                return False  # one-shot, already fired
            try:
                target = _datetime.fromisoformat(job.schedule_at.replace("Z", "+00:00"))
                if target.tzinfo is None:
                    # N3-Opus: Naive datetime can't compare with aware UTC.
                    # Treat as UTC to avoid silent never-fire.
                    logger.warning(
                        "CronScheduler: job %s has naive schedule_at %r — treating as UTC",
                        job.id, job.schedule_at)
                    target = target.replace(tzinfo=timezone.utc)
                return _datetime.now(timezone.utc) >= target
            except Exception:
                return False
        elif job.schedule_kind == "cron":
            if not job.schedule_cron:
                return False
            # P2-2: Bad timezone validation
            try:
                _tz_name = job.schedule_tz or self.default_tz
                tz = ZoneInfo(_tz_name) if _tz_name else None
            except KeyError:
                job.status = "error"
                job.last_error = f"Invalid timezone: {job.schedule_tz}"
                job.enabled = False
                logger.warning("CronScheduler: invalid timezone %r for job %s, disabling",
                               job.schedule_tz, job.id)
                return False
            now_dt = _datetime.now(tz) if tz else _datetime.now()
            if not _match_cron_expr(job.schedule_cron, now_dt):
                return False
            # P1-2: DST re-fire guard — use epoch comparison instead of wall-clock
            if job.last_run and (now - job.last_run) < 60:
                return False
            return True
        return False

    async def _tick(self):
        """Check all jobs and fire due ones.  P1-5: batch _save() at end."""
        modified = False
        for job in list(self._jobs.values()):
            if self._is_due(job):
                modified = True
                job.status = "running"
                job.last_run = time.time()
                job.run_count += 1
                start = time.monotonic()
                try:
                    # P1-6: Defensive copy for on_fire callback
                    await self.on_fire(CronJob.from_dict(job.to_dict()))
                    job.status = "idle"
                    job.consecutive_errors = 0
                    job.last_error = None
                    job.last_success = time.time()
                    job.last_duration_ms = int((time.monotonic() - start) * 1000)
                    logger.info("CronScheduler: fired job %s (%s)", job.id, job.name)
                except Exception as e:
                    job.status = "error"
                    job.consecutive_errors += 1
                    job.last_error = str(e)[:500]
                    job.last_duration_ms = int((time.monotonic() - start) * 1000)
                    logger.error("CronScheduler: job %s failed: %s", job.id, e)

                # P2-4: Auto-disable after N consecutive errors
                if job.consecutive_errors >= self.MAX_CONSECUTIVE_ERRORS:
                    job.enabled = False
                    logger.warning("CronScheduler: auto-disabled job %s after %d consecutive errors",
                                   job.id, job.consecutive_errors)

                # P2-6: Direct field access (not getattr)
                # R2-Sonnet: Use pop() — job may have been removed by another
                # async task (e.g., user command) during the await on_fire().
                if job.delete_after_run and job.status != "error":
                    self._jobs.pop(job.id, None)
                    logger.info("CronScheduler: auto-deleted job %s (deleteAfterRun)", job.id)

        if modified:
            self._save()

    async def _loop(self):
        """Main scheduler loop.  R2-Opus: backoff on persistent tick failures."""
        logger.info("CronScheduler: started")
        _consecutive_tick_errors = 0
        while True:
            try:
                await self._tick()
                _consecutive_tick_errors = 0
            except Exception as e:
                _consecutive_tick_errors += 1
                logger.error("CronScheduler tick error (#%d): %s",
                             _consecutive_tick_errors, e)
            # Backoff: normal interval + 2s per consecutive error (capped at 60s)
            backoff = min(_consecutive_tick_errors * 2, 50)
            await asyncio.sleep(self.TICK_INTERVAL + backoff)

    async def start(self):
        """Start the scheduler in background."""
        self._task = asyncio.create_task(self._loop())

    async def stop(self):
        """Stop the scheduler."""
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("CronScheduler: stopped")

    def run_now(self, job_id: str) -> bool:
        """Trigger a job immediately (resets last_run).

        Returns False if the job doesn't exist or is a spent one-shot ``at``
        job (``run_count > 0``), since resetting ``last_run`` alone cannot
        make an ``at`` job re-fire.
        """
        job = self._jobs.get(job_id)
        if not job:
            return False
        # R2-Opus/Sonnet: Spent at-jobs can never fire again — don't mislead.
        if job.schedule_kind == "at" and job.run_count > 0:
            return False
        job.last_run = None  # force due
        # P1-1: Persist the reset so it survives restarts
        self._save()
        return True
