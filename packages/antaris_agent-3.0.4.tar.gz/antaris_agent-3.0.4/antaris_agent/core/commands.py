"""
Antaris Agent Command Dispatcher — handles ! prefixed commands.

Commands are resolved before rate-limiting and the normal pipeline so
they are always available regardless of LLM state.
"""
import json
import logging
import os
import re
import shlex
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from antaris_agent.channels.base import InboundMessage
from antaris_agent.core.google_workspace_commands import GoogleWorkspaceCommandMixin

logger = logging.getLogger(__name__)

MAX_CRON_JOBS = 50
_MIN_EVERY_INTERVAL_MS = 300_000  # 5 minutes


def _cron_usage() -> str:
    return (
        "Usage: `!cron add every 30m remind me to stretch`\n"
        "Also: `!cron add daily 6am post daily brief`\n"
        "`!cron add weekdays 6am post market brief`\n"
        "`!cron add tomorrow 9am remind me to call mom`\n"
        "`!cron add at 2026-03-27T09:00:00Z send follow-up`\n"
        "`!cron add cron \"0 6 * * 1-5\" weekday brief`\n"
        "Other commands: `!cron list` | `!cron remove <id>` | `!cron run <id>`"
    )


def _parse_time_token(token: str) -> Optional[tuple[int, int]]:
    """Parse a time token into (hour, minute).

    Supported formats:
        - 12-hour: ``6am``, ``6:30pm``, ``12am`` (midnight), ``12pm`` (noon)
        - 24-hour: ``18:00``, ``06:30``
        - Keywords: ``noon`` (12:00), ``midnight`` (0:00)

    Returns None for unrecognized input.
    """
    token = token.strip().lower()
    # Keywords
    if token == "noon":
        return (12, 0)
    if token == "midnight":
        return (0, 0)
    # 12-hour formats
    for fmt in ("%I%p", "%I:%M%p"):
        try:
            dt = datetime.strptime(token, fmt)
            return dt.hour, dt.minute
        except ValueError:
            continue
    # 24-hour format: HH:MM
    try:
        dt = datetime.strptime(token, "%H:%M")
        return dt.hour, dt.minute
    except ValueError:
        pass
    return None


def _parse_every_interval(token: str) -> Optional[int]:
    token = token.strip().lower()
    if len(token) < 2:
        return None
    unit = token[-1]
    num = token[:-1]
    if not num.isdigit():
        return None
    value = int(num)
    if value <= 0:
        return None
    multipliers = {"m": 60_000, "h": 3_600_000, "d": 86_400_000}
    mult = multipliers.get(unit)
    if mult is None:
        return None
    return value * mult


def _summarize_every(ms: int) -> str:
    minute = 60_000
    hour = 3_600_000
    day = 86_400_000
    if ms % day == 0:
        return f"every {ms // day}d"
    if ms % hour == 0:
        return f"every {ms // hour}h"
    if ms % minute == 0:
        return f"every {ms // minute}m"
    return f"every {ms}ms"


def _summarize_time(hour: int, minute: int) -> str:
    return datetime(2000, 1, 1, hour, minute).strftime("%-I:%M %p")


def _derive_job_name(payload_text: str) -> str:
    text = (payload_text or "").strip()
    if not text:
        return "Cron Job"
    if len(text) > 40:
        return text[:37] + "..."
    return text


def _validate_cron_expr(expr: str) -> Optional[str]:
    """Validate a 5-field cron expression.

    Returns None if valid, or an error message string if invalid.
    """
    fields = expr.split()
    if len(fields) != 5:
        return "Cron expression must have exactly 5 fields (minute hour dom month dow)."
    field_pattern = re.compile(r'^[\d,\-\*/]+$')
    # R2-Opus/GPT: Add per-field range validation
    field_ranges = [
        (0, 59, "minute"),   # field 0
        (0, 23, "hour"),     # field 1
        (1, 31, "day"),      # field 2
        (1, 12, "month"),    # field 3
        (0, 7, "day-of-week"),  # field 4
    ]
    for i, f in enumerate(fields):
        if not field_pattern.match(f):
            return f"Invalid character in cron field {i + 1}: `{f}`. Only digits, commas, dashes, slashes, and * are allowed."
        # R3: Validate numeric values within range, but only base values —
        # NOT step values after "/".  Also reject step=0.
        if f != "*":
            lo, hi, name = field_ranges[i]
            for part in f.split(","):
                part = part.strip()
                if not part:
                    continue
                # Split off step
                base_part = part
                step_part = None
                if "/" in part:
                    base_part, step_str = part.split("/", 1)
                    if not step_str:
                        # R4-Opus: `*/` with empty step is invalid
                        return f"Empty step value in {name} field (`{part}`). Use e.g. `*/15`."
                    if step_str.isdigit():
                        step_part = int(step_str)
                        if step_part == 0:
                            return f"Step value `0` in {name} field is invalid (must be > 0)."
                    else:
                        return f"Invalid step `{step_str}` in {name} field."
                # Validate base values (not the step)
                if base_part == "*":
                    continue
                # R4-Opus: Reject malformed base like `-1`, `5-`, `-`
                if base_part.startswith("-") or base_part.endswith("-"):
                    return f"Malformed range `{base_part}` in {name} field."
                for num_str in re.findall(r'\d+', base_part):
                    n = int(num_str)
                    if n < lo or n > hi:
                        return f"Value `{n}` in {name} field is out of range ({lo}-{hi})."
    # Test-fire against current time to catch obviously broken expressions
    from antaris_agent.core.cron import _match_cron_expr
    try:
        _match_cron_expr(expr, datetime.now())
    except Exception:
        return f"Cron expression `{expr}` is malformed."
    return None


def _parse_cron_add_spec(spec: str) -> Optional[dict]:
    """Parse a ``!cron add`` specification into a job config dict.

    Supported forms:
        - ``every <interval> <payload>``  — e.g. ``every 30m remind me``
        - ``daily <time> <payload>``      — e.g. ``daily 6am post brief``
        - ``weekdays <time> <payload>``   — e.g. ``weekdays 9am standup``
        - ``tomorrow <time> <payload>``   — e.g. ``tomorrow 9am call mom``
        - ``at <datetime> <payload>``     — e.g. ``at 2026-03-27T09:00:00Z send msg``
        - ``at <date> <time> <payload>``  — e.g. ``at 2026-03-27 09:00 send msg``
        - ``cron "<expr>" <payload>``     — e.g. ``cron "0 6 * * 1-5" brief``

    Returns a dict with keys: schedule_kind, payload_text, summary, and
    schedule-specific keys (schedule_every_ms, schedule_at, schedule_cron,
    schedule_tz, delete_after_run). Also includes ``_warning`` if applicable.

    Returns None for unrecognized input. Returns a dict with ``_error`` key
    for recognized-but-invalid input (specific error message).
    """
    spec = spec.strip()
    if not spec:
        return None

    try:
        tokens = shlex.split(spec)
    except ValueError:
        # R2-Opus: Specific error for unmatched quotes instead of silent None
        return {"_error": "❌ Unmatched quote in input. Check your quoting — cron expressions need matching quotes: `cron \"0 6 * * 1-5\" task`"}

    if not tokens:
        return None

    head = tokens[0].lower()
    # R2-GPT: Use IANA timezone name (e.g. "America/Los_Angeles") not abbreviation
    # ("PDT").  ZoneInfo requires IANA names.  We get it from the system's
    # /etc/localtime symlink or fall back to the abbreviation for display only.
    _local_now = datetime.now().astimezone()
    local_tz_name = _local_now.tzname() or "local"  # display name (PDT, etc.)
    local_tz_iana: Optional[str] = None
    try:
        import time as _time_mod
        local_tz_iana = _time_mod.tzname[0]  # e.g. "PST" — not ideal
        # Better: try to resolve from /etc/localtime or TZ env
        import os
        _tz_env = os.environ.get("TZ")
        if _tz_env:
            local_tz_iana = _tz_env
        else:
            # On Linux/macOS, /etc/localtime is often a symlink to zoneinfo
            # R3-Sonnet/Opus: macOS uses /zoneinfo.default/ not /zoneinfo/
            _tz_link = "/etc/localtime"
            if os.path.islink(_tz_link):
                _target = os.path.realpath(_tz_link)
                # Extract IANA name — handles both /zoneinfo/ and /zoneinfo.default/
                _zi_match = re.search(r'zoneinfo[^/]*/(.+)$', _target)
                if _zi_match:
                    local_tz_iana = _zi_match.group(1)
    except Exception:
        pass
    # Validate the IANA name works with ZoneInfo
    if local_tz_iana:
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(local_tz_iana)  # will raise if invalid
        except Exception:
            local_tz_iana = None  # fall back to no tz

    if head == "every":
        if len(tokens) < 3:
            return {"_error": "❌ Missing interval or payload. Example: `!cron add every 30m remind me to stretch`"}
        interval_ms = _parse_every_interval(tokens[1])
        if not interval_ms:
            return {"_error": f"❌ Invalid interval `{tokens[1]}`. Use `<number><m|h|d>` — e.g. `30m`, `2h`, `1d`."}
        if interval_ms < _MIN_EVERY_INTERVAL_MS:
            return {"_error": f"❌ Minimum interval is 5 minutes. `{tokens[1]}` is too frequent."}
        payload_text = " ".join(tokens[2:]).strip()
        if not payload_text:
            return {"_error": "❌ Missing payload text after interval. What should the job do?"}
        return {
            "schedule_kind": "every",
            "schedule_every_ms": interval_ms,
            "payload_text": payload_text,
            "summary": _summarize_every(interval_ms),
        }

    if head in {"daily", "weekdays", "tomorrow"}:
        if len(tokens) < 3:
            return {"_error": f"❌ Missing time or payload. Example: `!cron add {head} 6am do something`"}
        parsed_time = _parse_time_token(tokens[1])
        if not parsed_time:
            return {"_error": f"❌ Invalid time format `{tokens[1]}`. Use `6am`, `6:30am`, `18:00`, `noon`, or `midnight`."}
        payload_text = " ".join(tokens[2:]).strip()
        if not payload_text:
            return {"_error": f"❌ Missing payload text. What should the {head} job do?"}
        hour, minute = parsed_time
        if head == "daily":
            result = {
                "schedule_kind": "cron",
                "schedule_cron": f"{minute} {hour} * * *",
                "payload_text": payload_text,
                "summary": f"daily at {_summarize_time(hour, minute)} ({local_tz_name})",
            }
            if local_tz_iana:
                result["schedule_tz"] = local_tz_iana
            return result
        if head == "weekdays":
            result = {
                "schedule_kind": "cron",
                "schedule_cron": f"{minute} {hour} * * 1-5",
                "payload_text": payload_text,
                "summary": f"weekdays at {_summarize_time(hour, minute)} ({local_tz_name})",
            }
            if local_tz_iana:
                result["schedule_tz"] = local_tz_iana
            return result
        # tomorrow
        target = datetime.now().astimezone().replace(second=0, microsecond=0) + timedelta(days=1)
        target = target.replace(hour=hour, minute=minute)
        return {
            "schedule_kind": "at",
            "schedule_at": target.isoformat(),
            "delete_after_run": True,
            "payload_text": payload_text,
            "summary": f"tomorrow at {_summarize_time(hour, minute)} ({local_tz_name})",
        }

    if head == "at":
        if len(tokens) < 3:
            return {"_error": "❌ Missing datetime or payload. Example: `!cron add at 2026-03-27T09:00:00Z send msg`"}
        # Greedy parse: try tokens[1] + "T" + tokens[2] as datetime first
        # R2-Opus: Changed from >= 4 to >= 3 so "at 2026-03-27 09:00" (no payload)
        # correctly attempts greedy parse before falling back.
        when = None
        payload_start = 2
        if len(tokens) >= 3:
            # First try ISO combination: "2026-03-27" + "09:00" → "2026-03-27T09:00"
            combined = tokens[1] + "T" + tokens[2]
            try:
                _parsed_combined = datetime.fromisoformat(combined.replace("Z", "+00:00"))
                # R3: If naive (no tz info), make it tz-aware using local time
                if _parsed_combined.tzinfo is None:
                    _parsed_combined = _parsed_combined.astimezone()
                    when = _parsed_combined.isoformat()
                else:
                    when = combined
                payload_start = 3
            except ValueError:
                pass
            # R2-GPT: Also try human time tokens: "2026-03-27" + "9am" → date + parsed time
            if when is None:
                human_time = _parse_time_token(tokens[2])
                if human_time is not None:
                    try:
                        base_date = datetime.fromisoformat(tokens[1])
                        h, m = human_time
                        combined_dt = base_date.replace(hour=h, minute=m, second=0, microsecond=0)
                        # Use local timezone if base_date is naive
                        if combined_dt.tzinfo is None:
                            combined_dt = combined_dt.astimezone()
                        when = combined_dt.isoformat()
                        payload_start = 3
                    except (ValueError, TypeError):
                        pass
        if when is None:
            try:
                datetime.fromisoformat(tokens[1].replace("Z", "+00:00"))
                when = tokens[1]
                payload_start = 2
            except ValueError:
                return {"_error": f"❌ Invalid datetime `{tokens[1]}`. Use ISO format: `2026-03-27T09:00:00Z` or `2026-03-27 09:00`."}
        payload_text = " ".join(tokens[payload_start:]).strip()
        if not payload_text:
            return {"_error": "❌ Missing payload text after datetime. What should the job do?"}
        # Normalize Z to +00:00 and date-only to full datetime
        normalized_when = when.replace("Z", "+00:00")
        # R2-Opus: If date-only (no T), normalize to midnight UTC
        if "T" not in normalized_when and "t" not in normalized_when:
            normalized_when = normalized_when + "T00:00:00+00:00"
        # Check for past datetime
        warning = None
        try:
            parsed_dt = datetime.fromisoformat(normalized_when)
            if parsed_dt.tzinfo is None:
                parsed_dt = parsed_dt.replace(tzinfo=timezone.utc)
            if parsed_dt < datetime.now(timezone.utc):
                warning = "⚠️ Note: scheduled time is in the past — job will fire immediately."
        except ValueError:
            pass
        result = {
            "schedule_kind": "at",
            "schedule_at": normalized_when,
            "delete_after_run": True,
            "payload_text": payload_text,
            "summary": f"at {when}",
        }
        if warning:
            result["_warning"] = warning
        return result

    if head == "cron":
        if len(tokens) < 3:
            return {"_error": "❌ Missing expression or payload. Example: `!cron add cron \"0 6 * * 1-5\" weekday brief`"}
        expr = tokens[1].strip()
        payload_text = " ".join(tokens[2:]).strip()
        if not payload_text:
            return {"_error": "❌ Missing payload text after cron expression."}
        validation_error = _validate_cron_expr(expr)
        if validation_error:
            # R2-Opus: Hint about quoting if expression looks like it was meant to be multi-token
            hint = ""
            if len(expr.split()) == 1 and any(t in ("*", "*/") or t.isdigit() for t in tokens[2:5]):
                hint = " Did you forget to quote the expression? Use: `cron \"0 6 * * 1-5\" task`"
            return {"_error": f"❌ {validation_error}{hint}"}
        return {
            "schedule_kind": "cron",
            "schedule_cron": expr,
            "payload_text": payload_text,
            "summary": f"cron {expr}",
        }

    return None


@dataclass
class CommandResult:
    handled: bool
    response: Optional[str] = None


class CommandDispatcher(GoogleWorkspaceCommandMixin):
    """
    Dispatch ! commands from inbound messages.

    Usage:
        dispatcher = CommandDispatcher(bot=bot_instance)
        result = await dispatcher.dispatch(inbound)
        if result.handled:
            return result.response
    """

    def __init__(self, bot=None):
        self.bot = bot
        self._model_overrides: dict[str, str] = {}  # user_id → model override
        # Command registry: cmd string → async callable(inbound, args) → str
        self._commands: dict = {
            "!status":     lambda inbound, args: self._cmd_status(),
            "!model":      lambda inbound, args: self._cmd_model(inbound.user_id, args),
            "!gather":     lambda inbound, args: self._cmd_gather(inbound, args),
            "!recap":      lambda inbound, args: self._cmd_recap(inbound, args),
            "!focus":      lambda inbound, args: self._cmd_focus(inbound.user_id, args),
            "!unfocus":    lambda inbound, args: self._cmd_unfocus(inbound.user_id),
            "!help":       lambda inbound, args: self._cmd_help(),
            "!gmail":      lambda inbound, args: self._cmd_gmail(inbound, args),
            "!calendar":   lambda inbound, args: self._cmd_calendar(inbound, args),
            "!drive":      lambda inbound, args: self._cmd_drive(inbound, args),
            "!ping":       lambda inbound, args: self._cmd_ping(),
            "!memory":     lambda inbound, args: self._cmd_memory(inbound, args),
            "!cron":       lambda inbound, args: self._cmd_cron(inbound, args),
            "!profile":    lambda inbound, args: self._cmd_profile(inbound.user_id, args),
            "!teach":      lambda inbound, args: self._cmd_teach(inbound.user_id, args),
            "!threads":    lambda inbound, args: self._cmd_threads(inbound.user_id),
            "!thread":     lambda inbound, args: self._cmd_thread(inbound.user_id, args),
            "!shortcuts":  lambda inbound, args: self._cmd_shortcuts(inbound.user_id, args),
            "!export":     lambda inbound, args: self._cmd_export(inbound.user_id, args),
            "!feedback":   lambda inbound, args: self._cmd_feedback(inbound.user_id, args),
            "!spawn":      lambda inbound, args: self._cmd_spawn(inbound, args),
            "!agent":      lambda inbound, args: self._cmd_agent(inbound, args),
            "!sync":       lambda inbound, args: self._cmd_sync(inbound, args),
            "!agents":     lambda inbound, args: self._cmd_agents(inbound, args),
            "!cost":       lambda inbound, args: self._cmd_cost(inbound.user_id, args),
            "!extensions": lambda inbound, args: self._cmd_extensions(inbound.user_id, args),
            "!auth":       lambda inbound, args: self._cmd_auth(inbound.user_id, args),
            "!skills":     lambda inbound, args: self._cmd_skills(inbound.user_id, args),
            "!thinking":   lambda inbound, args: self._cmd_thinking(inbound.user_id, args),
            "!reasoning":  lambda inbound, args: self._cmd_thinking(inbound.user_id, args),
            "!models":     lambda inbound, args: self._cmd_models(inbound.user_id),
            "!webhooks":   lambda inbound, args: self._cmd_webhooks(inbound.user_id, args),
            "!discover":   lambda inbound, args: self._cmd_discover(inbound.user_id, args),
            "!compact":    lambda inbound, args: self._cmd_compact(inbound),
            "!stop":       lambda inbound, args: self._cmd_stop(inbound),
            "!shutdown":   lambda inbound, args: self._cmd_stop(inbound),
            "!approve":    lambda inbound, args: self._cmd_venture_approve(inbound, True, args),
            "!deny":       lambda inbound, args: self._cmd_venture_approve(inbound, False, args),
        }

    def get_model_override(self, user_id: str) -> Optional[str]:
        """Get model override for user, if set."""
        return self._model_overrides.get(user_id)

    async def dispatch(self, inbound: InboundMessage) -> CommandResult:
        """Check if message is a command and handle it."""
        text = (inbound.text or "").strip()
        if not text.startswith("!"):
            return CommandResult(handled=False)

        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        logger.info("Command received: cmd=%s user=%s channel=%s platform=%s", cmd, inbound.user_id, inbound.channel_id, inbound.platform)

        handler = self._commands.get(cmd)
        if handler:
            try:
                response = await handler(inbound, args)
                logger.info("Command handled: cmd=%s user=%s", cmd, inbound.user_id)
                return CommandResult(handled=True, response=response)
            except Exception as e:
                logger.exception("Command failed: cmd=%s user=%s", cmd, inbound.user_id)
                return CommandResult(handled=True, response=f"❌ Command `{cmd}` failed. Check server logs for details.")

        # Try extension-registered commands
        from antaris_agent.extensions.manager import ExtensionManager
        _ext_mgr = getattr(self.bot, '_extension_manager', None)
        if isinstance(_ext_mgr, ExtensionManager):
            ext_result = _ext_mgr.dispatch_command(
                cmd[1:], inbound.user_id, args
            )
            if ext_result is not None:
                return CommandResult(handled=True, response=ext_result)

        logger.warning("Unknown command: cmd=%s user=%s channel=%s", cmd, inbound.user_id, inbound.channel_id)
        # Unknown command -- don't handle, let it fall through to the LLM
        return CommandResult(handled=False)

    def _authorized_command_users(self) -> set[str]:
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if getattr(self.bot, 'config', None) else []
        return set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

    def _is_authorized_command_user(self, user_id: str) -> bool:
        allowed = self._authorized_command_users()
        return bool(allowed) and str(user_id) in allowed

    # ── Commands ──────────────────────────────────────────────────────────

    async def _cmd_stop(self, inbound: InboundMessage) -> str:
        """Gracefully shut down the bot. Flushes memory, saves sessions, then exits.

        Authorization: deny-by-default. If no authorized_users or owner_ids are
        configured, NO ONE can stop the bot via chat command (use CLI instead).
        """
        import asyncio
        import os
        import signal

        # Build allowlist — deny-by-default
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

        if not allowed:
            return "❌ No authorized users configured. Use CLI `antaris stop` or `antarisd stop` instead."

        if str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can stop the bot."

        logger.info("!stop command received from user=%s channel=%s — initiating graceful shutdown",
                     inbound.user_id, inbound.channel_id)

        response = "🛑 Initiating graceful shutdown..."

        # Schedule the actual shutdown after the response is delivered
        async def _delayed_shutdown():
            await asyncio.sleep(3)  # Give Discord API time to deliver the response
            logger.info("Executing graceful shutdown via !stop command")
            os.kill(os.getpid(), signal.SIGTERM)

        asyncio.create_task(_delayed_shutdown())
        return response

    async def _cmd_venture_approve(self, inbound: InboundMessage, approved: bool, args: str = "") -> str:
        """Write a per-venture approval/denial record to a private directory.

        Security hardening (C4):
        - Deny-by-default: if no authorized users configured, DENY regardless of caller
        - Per-venture files bound to a venture_id (from args, or falls back to "default")
        - Random nonce to prevent forging by name
        - Private directory (~/.antaris/approvals/) instead of /tmp/
        - 5-minute TTL embedded in the record
        - Consume-once: the consumer is expected to delete the file after reading
        """
        import json as _json
        import secrets as _secrets
        import time as _time
        from pathlib import Path as _Path

        # Authorization: deny-by-default — mirrors !stop exactly.
        # If no authorized users are configured at all, DENY.
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

        if not allowed:
            logger.warning(
                "Venture %s denied — no authorized users configured: user=%s channel=%s",
                "approve" if approved else "deny", inbound.user_id, inbound.channel_id,
            )
            return "❌ No authorized users configured. Venture approval is disabled until an owner is set."

        if str(inbound.user_id) not in allowed:
            logger.warning(
                "Venture %s denied — unauthorized user=%s channel=%s",
                "approve" if approved else "deny", inbound.user_id, inbound.channel_id,
            )
            return "❌ Only authorized users can approve/deny ventures."

        # Resolve venture_id from args (e.g. `!approve abc123`) or use "default"
        venture_id = args.strip().split()[0] if args.strip() else "default"

        # Private approvals directory — not world-writable /tmp/
        approvals_dir = _Path.home() / ".antaris" / "approvals"
        approvals_dir.mkdir(parents=True, exist_ok=True)
        approvals_dir.chmod(0o700)  # owner-only

        now = _time.time()
        record = {
            "venture_id": venture_id,
            "nonce": _secrets.token_hex(16),
            "approved": approved,
            "user_id": str(inbound.user_id),
            "channel_id": str(inbound.channel_id),
            "timestamp": now,
            "expires": now + 300,  # 5-minute TTL
        }

        # Write atomically: write to .tmp then rename so readers never see partial data
        approval_file = approvals_dir / f"venture_{venture_id}.json"
        tmp_file = approvals_dir / f"venture_{venture_id}.tmp"
        tmp_file.write_text(_json.dumps(record))
        tmp_file.chmod(0o600)  # owner-read/write only
        tmp_file.rename(approval_file)

        action = "✅ **Approved**" if approved else "❌ **Denied**"
        logger.info(
            "Venture %s: venture_id=%s user=%s channel=%s nonce=%s expires=+300s",
            "approved" if approved else "denied",
            venture_id, inbound.user_id, inbound.channel_id, record["nonce"],
        )
        return f"{action} — venture `{venture_id}` decision recorded (expires in 5 min)."

    async def _cmd_compact(self, inbound: InboundMessage) -> str:
        """Manually trigger the existing pre-compaction flush for the current session.

        Authorization: deny if an allowlist is configured and the caller is not on it.
        If no owners/authorized_users are configured, anyone can trigger compaction
        (open/personal bot deployment). Matches the !venture_approve pattern.
        """
        # Auth gate — same pattern as !approve / !deny
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

        if allowed and str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can trigger session compaction."

        if not getattr(self.bot, 'sessions', None):
            return "❌ Session manager not available."
        try:
            session = await self.bot.sessions.get_or_create(inbound.user_id, inbound.channel_id, inbound.platform)
            logger.info("Manual compact requested: user=%s channel=%s session=%s", inbound.user_id, inbound.channel_id, session.session_id)
            await self.bot._pre_compaction_flush(session)
            return "🧹 Manual compaction flush completed for this session."
        except Exception as e:
            logger.exception("Manual compact failed: user=%s channel=%s", inbound.user_id, inbound.channel_id)
            return f"❌ Manual compaction failed: {e}"

    async def _cmd_status(self) -> str:
        lines = ["**📊 Antaris Status**"]
        try:
            stats = self.bot.memory.stats()
            lines.append(f"🧠 Memory: {stats.get('total', 0):,} entries")
        except Exception:
            lines.append("🧠 Memory: unavailable")
        if self.bot and hasattr(self.bot, 'dispatcher') and self.bot.dispatcher:
            providers = list(self.bot.dispatcher.providers.keys())
            lines.append(f"🔌 Providers: {', '.join(providers)}")
        if self.bot and hasattr(self.bot, 'config'):
            lines.append(f"🤖 Model: {self.bot.config.model} via {self.bot.config.provider_name}")
            lines.append(f"🛡️ Guard: {self.bot.config.guard_mode}")
            lines.append(f"🔒 Security: {getattr(self.bot.config, 'security_mode', 'sandboxed')}")
        if self.bot and getattr(self.bot, 'router', None):
            lines.append("🧭 Router: active")
        else:
            lines.append("🧭 Router: off")
        return "\n".join(lines)

    async def _cmd_model(self, user_id: str, args: str) -> str:
        # Use ModelController if available, otherwise fall back to legacy aliases
        from antaris_agent.extensions.model_control import ModelController
        controller = getattr(self.bot, 'model_controller', None)
        if controller and isinstance(controller, ModelController):
            if not args or args.lower() == "auto":
                self._model_overrides.pop(user_id, None)
                controller.set_model(user_id, "auto")
                return "🔄 Model routing reset to auto."
            
            # Check for duration suffix: "opus 30m" or "gpt 1h"
            parts = args.strip().split()
            model_spec = parts[0]
            duration = 0
            if len(parts) > 1:
                dur_str = parts[-1].lower()
                from antaris_agent.core.focus import parse_duration_minutes
                parsed = parse_duration_minutes(dur_str)
                if parsed is not None:
                    duration = parsed
                    # model_spec is everything except the duration
                    model_spec = " ".join(parts[:-1])
            
            model, provider, msg = controller.set_model(user_id, model_spec, duration)
            if model:
                self._model_overrides[user_id] = model
            return msg
        
        # Legacy fallback
        if not args or args.lower() == "auto":
            self._model_overrides.pop(user_id, None)
            return "🔄 Model routing reset to auto."
        aliases = {
            "opus": "claude-opus-4-6",
            "opus-4.6": "claude-opus-4-6",
            "opus-4-6": "claude-opus-4-6",
            "opus4.6": "claude-opus-4-6",
            "sonnet": "claude-sonnet-4-6",
            "sonnet-4.6": "claude-sonnet-4-6",
            "sonnet-4-6": "claude-sonnet-4-6",
            "sonnet4.6": "claude-sonnet-4-6",
            "haiku": "claude-haiku-4-5-20251001",
            "haiku-4.5": "claude-haiku-4-5-20251001",
            "gpt": "gpt-5.4",
            "gpt5": "gpt-5.4",
            "gpt-5.4": "gpt-5.4",
            "gpt4": "gpt-4o",
            "gemini": "gemini-3.1-pro",
            "flash": "gemini-2.5-flash",
            "qwen": "qwen3.5:4b",
            "qwen9b": "qwen3.5:9b",
            "qwen8b": "qwen3:8b",
        }
        model = aliases.get(args.lower(), args)
        self._model_overrides[user_id] = model
        return f"✅ Model set to `{model}`. Use `!model auto` to reset."

    async def _cmd_gather(self, inbound: InboundMessage, args: str) -> str:
        """Gather and ingest recent Discord channel history.

        Modifies the shared memory store — restricted to authorized users.
        """
        # Auth gate — ingesting channel history writes to the memory store
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

        if allowed and str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can gather channel history."

        from antaris_agent.core import gather as _gather

        # Parse hours argument
        hours = 12
        if args.strip():
            try:
                hours = int(args.strip())
            except ValueError:
                return f"Invalid hours value. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        if hours not in _gather.VALID_HOURS:
            return f"Invalid hours: {hours}. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        # Get the Discord client from the DiscordAdapter if available
        discord_client = None
        for ch in getattr(self.bot, '_channels', []):
            from antaris_agent.channels.discord import DiscordAdapter
            if isinstance(ch, DiscordAdapter):
                discord_client = ch._client
                break

        if not discord_client:
            return "Gather requires a connected Discord client. Bot may not be running on Discord."

        channel_ids = list(getattr(self.bot.config, 'discord_open_channels', []))
        if not channel_ids:
            return "No open channels configured. Add channels to discord_open_channels in config."

        try:
            result = await _gather.gather_and_ingest(
                client=discord_client,
                memory=self.bot.memory,
                llm=self.bot.llm,
                channel_ids=channel_ids,
                hours=hours,
                user_id=inbound.user_id,
            )
            synced = result["channels_synced"]
            total = result["total_messages"]
            errors = result.get("errors", [])
            channel_summaries = result.get("channel_summaries", [])

            if not channel_summaries:
                msg = f"No new messages found in the last {hours}h."
                if errors:
                    msg += f" Errors: {'; '.join(errors[:3])}"
                return msg

            lines = [f"**Gathered {synced} channel(s) over the last {hours}h ({total} messages):**\n"]
            for cs in channel_summaries:
                lines.append(f"**#{cs['channel_name']}** ({cs['count']} msgs)")
                lines.append(cs["summary"])
                lines.append("")

            if errors:
                lines.append(f"Errors: {'; '.join(errors[:3])}")

            return "\n".join(lines).strip()
        except Exception as e:
            logger.error("gather failed: %s", e, exc_info=True)
            return "❌ Gather failed. The error has been logged."

    async def _cmd_recap(self, inbound: InboundMessage, args: str) -> str:
        try:
            n = int(args) if args else 10
            n = min(max(n, 1), 50)
        except ValueError:
            n = 10
        return f"📝 Recap of last {n} messages: *coming soon.*"

    async def _cmd_ping(self) -> str:
        """Quick alive check."""
        return "🏓 Pong!"

    async def _cmd_help(self) -> str:
        return (
            "**📖 Parsica Agent — Command Guide**\n"
            "Use `!help` anytime. Unknown `!` commands fall through to the LLM.\n"
            "\n"
            "**Core**\n"
            "`!status` — agent / provider / security / router status\n"
            "`!ping` — quick alive check\n"
            "`!help` — show this guide\n"
            "`!stop` — gracefully shut down (authorized users only)\n"
            "`!compact` — manually trigger session compaction\n"
            "\n"
            "**Memory + recall**\n"
            "`!memory help` — memory subcommand help\n"
            "`!memory search <query>` — search your memories\n"
            "`!memory recent` — show recent memories\n"
            "`!memory stats` — show memory health + size\n"
            "`!memory forget <query>` — deprecate memories matching a query (reversible)\n"
            "`!memory purge <query>` — permanently delete memories matching a query\n"
            "`!memory clear` — clear conversation history\n"
            "`!teach <text>` — explicitly teach a fact or preference\n"
            "`!teach list|remove <n>|clear` — manage teachings\n"
            "`!sync memory <hours>` — sync memories from peer stores (1-24h)\n"
            "\n"
            "**Models + reasoning**\n"
            "`!model <name>` — switch model (opus / sonnet / gpt / gemini / qwen / auto)\n"
            "`!model <name> 30m` — switch model temporarily\n"
            "`!models` — list available model aliases, costs, and thinking support\n"
            "`!thinking <off|low|medium|high|max>` — set reasoning depth\n"
            "`!reasoning <level>` — alias for `!thinking`\n"
            "\n"
            "**Focus + threads**\n"
            "`!focus <topic> [duration]` — focus on a project or topic\n"
            "`!focus` — show current focus\n"
            "`!unfocus` — exit focus mode\n"
            "`!threads` — list detected conversation threads\n"
            "`!thread <topic>` — reopen a specific thread\n"
            "`!shortcuts` — list learned implicit shortcuts\n"
            "`!shortcuts remove <phrase>` — remove a shortcut\n"
            "\n"
            "**History + context**\n"
            "`!gather [3|6|12|18|24|48]` — catch up on recent Discord history\n"
            "`!recap [hours]` — summarize recent conversation\n"
            "`!export today|week|project <name>|all` — export conversations to markdown\n"
            "`!profile` — show your user profile\n"
            "`!feedback` — show reaction feedback stats\n"
            "`!feedback clear` — clear feedback\n"
            "\n"
            "**Scheduling**\n"
            "`!cron list` — list scheduled jobs\n"
            "`!cron add every 30m remind me to stretch` — interval job\n"
            "`!cron add daily 6am post daily brief` — daily job\n"
            "`!cron add weekdays 6am post market brief` — weekday job\n"
            "`!cron add tomorrow 9am remind me to call mom` — one-shot job\n"
            "`!cron remove <id>` — remove a job\n"
            "`!cron run <id>` — run a job now\n"
            "\n"
            "**Agents + orchestration**\n"
            "`!spawn <task>` — spawn an auto-named subagent\n"
            "`!spawn <name> <task>` — spawn a named subagent\n"
            "`!spawn 3 <task>` — spawn multiple subagents\n"
            "`!agent mode single|multi|status` — session routing mode\n"
            "`!agents` — list subagents and status\n"
            "`!agents kill <name>` — stop a subagent\n"
            "`!agents result <name>` — show a subagent result\n"
            "`!approve` / `!deny` — approve/deny a pending venture action\n"
            "`!cost` — show token usage / estimated cost\n"
            "`!cost all` — global cost summary (admin only)\n"
            "\n"
            "**Google Workspace**\n"
            "`!gmail ...` — search / draft / send mail\n"
            "`!calendar ...` — list / create calendar events\n"
            "`!drive ...` — search and read Drive / Docs content\n"
            "\n"
            "**Platform / power-user**\n"
            "`!extensions` — list loaded extensions and status\n"
            "`!extensions reload <name>` — hot-reload an extension\n"
            "`!auth` — show API key health and auth status\n"
            "`!auth rotate [provider]` — rotate auth profile\n"
            "`!skills` — list custom skills\n"
            "`!webhooks` — show webhook delivery status\n"
            "`!discover audit` — audit unconfigured features\n"
            "`!discover off` / `!discover on` — toggle setup reminders\n"
        )

    async def _cmd_focus(self, user_id: str, args: str) -> str:
        """Start, show, or check focus mode."""
        from antaris_agent.core.focus import FocusManager, parse_duration_minutes

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."

        # No args: show current status
        if not args.strip():
            session = focus.get(user_id)
            if not session:
                return "No active focus session. Use `!focus <topic> [duration]` to start one."
            remaining = session.remaining_minutes
            if remaining < 0:
                time_str = "no time limit"
            else:
                time_str = f"{remaining}m remaining"
            return f"Focused on: **{session.topic}** ({time_str})"

        # Parse "<topic> [duration]"
        parts = args.strip().split()
        topic_parts = []
        duration_minutes = 0

        for part in parts:
            parsed = parse_duration_minutes(part)
            if parsed is not None:
                duration_minutes = parsed
                break
            topic_parts.append(part)

        if not topic_parts:
            return "Usage: `!focus <topic> [duration]` — e.g. !focus 'antaris agent' 1h"

        topic = " ".join(topic_parts)
        focus.start(user_id, topic, duration_minutes)

        if duration_minutes > 0:
            time_str = f"{duration_minutes}m"
        else:
            time_str = "no time limit"
        return f"Focus set: **{topic}** ({time_str}). Memory recall and context will prioritize this topic."

    async def _cmd_unfocus(self, user_id: str) -> str:
        """End focus mode."""
        from antaris_agent.core.focus import FocusManager

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."
        was_active = focus.stop(user_id)
        if was_active:
            return "Focus mode ended. Returning to general mode."
        return "No active focus session."

    async def _cmd_memory(self, inbound, args: str) -> str:
        """Memory subcommands: search, recent, stats, forget, help, clear."""
        user_id = str(inbound.user_id)
        text = args.strip()
        parts = text.split(maxsplit=1) if text else []
        subcmd = parts[0].lower() if parts else ""
        subargs = parts[1].strip() if len(parts) > 1 else ""

        # ── !memory (no args) or !memory help ────────────────────────────
        if not subcmd or subcmd == "help":
            return (
                "**🧠 Memory Commands:**\n"
                "`!memory search <query>` — search your memories\n"
                "`!memory recent` — show 5 most recent memories\n"
                "`!memory stats` — show memory statistics\n"
                "`!memory forget <query>` — deprecate memories matching a query (reversible)\n"
                "`!memory purge <query>` — permanently delete memories matching a query\n"
                "`!memory clear` — clear conversation history\n"
                "`!memory help` — show this message"
            )

        # ── !memory clear (legacy: clear conversation history) ───────────
        if subcmd == "clear":
            allowed = set(getattr(self.bot, "_owner_ids", [])) | set(getattr(self.bot.config, 'authorized_users', []))
            if not allowed or str(inbound.user_id) not in allowed:
                return "❌ Only authorized users can clear memory."
            pipeline = getattr(self.bot, 'pipeline', None)
            if not pipeline:
                return "❌ Pipeline not available."
            channel_id = getattr(inbound, 'channel_id', None) or ''
            pipeline.clear_history(user_id, channel_id)
            return "🧹 Conversation history cleared."

        # ── Remaining subcommands need bot.memory ────────────────────────
        bot_memory = getattr(self.bot, 'memory', None)
        if not bot_memory:
            return "❌ Memory system not available."

        # ── !memory search <query> ────────────────────────────────────────
        if subcmd == "search":
            if not subargs:
                return "Usage: `!memory search <query>`"
            try:
                results = bot_memory.search_memories(user_id, subargs, limit=5)
                if not results:
                    return f"🔍 No memories found matching **{subargs}**."
                lines = [f"**🔍 Memory search: \"{subargs}\"**\n"]
                for i, r in enumerate(results, 1):
                    content = r.get("content", "")
                    if len(content) > 200:
                        content = content[:200] + "..."
                    score = r.get("score", r.get("relevance", 0.0))
                    ts = r.get("timestamp") or r.get("created")
                    ts_str = ""
                    if ts:
                        try:
                            from datetime import datetime, timezone
                            if isinstance(ts, (int, float)):
                                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                            else:
                                dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                            ts_str = f" _{dt.strftime('%b %d %H:%M UTC')}_"
                        except Exception:
                            pass
                    lines.append(f"**{i}.** {content}{ts_str}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory search error: %s", e, exc_info=True)
                return "❌ Search failed. The error has been logged."

        # ── !memory recent ────────────────────────────────────────────────
        if subcmd == "recent":
            try:
                store = bot_memory._get_store(user_id)
                # Use recall_recent (by time window) — 72h to ensure we get results
                entries = store.recall_recent(hours=72.0, limit=5)
                if not entries:
                    # Fallback: use .recent() by access order
                    entries = store.recent(limit=5)
                if not entries:
                    return "🕐 No recent memories found."
                lines = ["**🕐 Recent Memories:**\n"]
                for i, entry in enumerate(entries, 1):
                    content = getattr(entry, "content", str(entry))
                    if len(content) > 200:
                        content = content[:200] + "..."
                    # Timestamp from created field
                    created = getattr(entry, "created", None)
                    ts_str = ""
                    if created:
                        try:
                            from datetime import datetime, timezone
                            if isinstance(created, (int, float)):
                                dt = datetime.fromtimestamp(created, tz=timezone.utc)
                            else:
                                dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
                            ts_str = f" _{dt.strftime('%b %d %H:%M UTC')}_"
                        except Exception:
                            pass
                    lines.append(f"**{i}.** {content}{ts_str}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory recent error: %s", e, exc_info=True)
                return "❌ Could not retrieve recent memories. The error has been logged."

        # ── !memory stats ─────────────────────────────────────────────────
        if subcmd == "stats":
            try:
                user_stats = bot_memory.stats(user_id)
                entry_count = user_stats.get("entry_count", 0)
                size_bytes = user_stats.get("store_size_bytes", 0)
                newest = user_stats.get("newest_entry")
                error = user_stats.get("error")

                # Health from the underlying MemorySystem
                health_str = "unknown"
                try:
                    store = bot_memory._get_store(user_id)
                    health = store.get_health()
                    all_ok = all(health.get("checks", {}).values())
                    health_str = "✅ healthy" if all_ok else "⚠️ degraded"
                except Exception:
                    pass

                # Format size
                if size_bytes >= 1_048_576:
                    size_str = f"{size_bytes / 1_048_576:.1f} MB"
                elif size_bytes >= 1024:
                    size_str = f"{size_bytes / 1024:.1f} KB"
                else:
                    size_str = f"{size_bytes} B"

                lines = ["**🧠 Memory Stats**"]
                lines.append(f"Total memories: **{entry_count:,}**")
                lines.append(f"Store size: **{size_str}**")
                lines.append(f"Health: {health_str}")
                if newest:
                    try:
                        from datetime import datetime, timezone
                        dt = datetime.fromisoformat(newest.replace("Z", "+00:00"))
                        lines.append(f"Last ingestion: **{dt.strftime('%b %d %H:%M UTC')}**")
                    except Exception:
                        lines.append(f"Last ingestion: {newest}")
                if error:
                    lines.append(f"⚠️ Error: {error}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory stats error: %s", e, exc_info=True)
                return "❌ Could not retrieve memory stats. The error has been logged."

        # ── !memory forget <query> ────────────────────────────────────────
        if subcmd == "forget":
            allowed = set(getattr(self.bot, "_owner_ids", [])) | set(getattr(self.bot.config, 'authorized_users', []))
            if not allowed or str(inbound.user_id) not in allowed:
                return "❌ Only authorized users can forget memories."
            if not subargs:
                return "Usage: `!memory forget <query>` — deprecates memories matching the query (reversible)."
            try:
                store = bot_memory._get_store(user_id)
                # Preview: search for matching memories first
                preview_results = bot_memory.search_memories(user_id, subargs, limit=5)
                # Call forget on the underlying store — deprecates by default
                result = store.forget(topic=subargs)
                forgotten = 0
                if isinstance(result, dict):
                    forgotten = result.get("forgotten", result.get("deleted", result.get("count", 0)))
                elif isinstance(result, int):
                    forgotten = result

                if forgotten == 0 and not preview_results:
                    return f"🔍 No memories found matching **\"{subargs}\"**. Nothing deprecated."

                lines = [f"🗂️ Deprecated **{forgotten}** memor{'y' if forgotten == 1 else 'ies'} matching **\"{subargs}\"** (hidden from retrieval)."]
                if preview_results:
                    lines.append("_(Matched entries included:)_")
                    for r in preview_results[:3]:
                        snippet = r.get("content", "")[:100]
                        if len(r.get("content", "")) > 100:
                            snippet += "..."
                        lines.append(f"• {snippet}")
                try:
                    store.save()
                except Exception as _save_err:
                    logger.warning("Memory save after forget failed: %s", _save_err)
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory forget error: %s", e, exc_info=True)
                return "❌ Forget failed. The error has been logged."

        # ── !memory purge <query> ─────────────────────────────────────────
        if subcmd == "purge":
            allowed = set(getattr(self.bot, "_owner_ids", [])) | set(getattr(self.bot.config, 'authorized_users', []))
            if not allowed or str(inbound.user_id) not in allowed:
                return "❌ Only authorized users can purge memories."
            if not subargs:
                return "Usage: `!memory purge <query>` — permanently deletes memories matching the query."
            try:
                store = bot_memory._get_store(user_id)
                # Preview: search for matching memories first
                preview_results = bot_memory.search_memories(user_id, subargs, limit=5)
                # Hard-delete permanently
                result = store.forget(topic=subargs, hard_delete=True)
                forgotten = 0
                if isinstance(result, dict):
                    forgotten = result.get("forgotten", result.get("deleted", result.get("count", 0)))
                elif isinstance(result, int):
                    forgotten = result

                if forgotten == 0 and not preview_results:
                    return f"🔍 No memories found matching **\"{subargs}\"**. Nothing purged."

                lines = [f"🗑️ Permanently deleted **{forgotten}** memor{'y' if forgotten == 1 else 'ies'} matching **\"{subargs}\"**."]
                if preview_results:
                    lines.append("_(Matched entries included:)_")
                    for r in preview_results[:3]:
                        snippet = r.get("content", "")[:100]
                        if len(r.get("content", "")) > 100:
                            snippet += "..."
                        lines.append(f"• {snippet}")
                try:
                    store.save()
                except Exception as _save_err:
                    logger.warning("Memory save after purge failed: %s", _save_err)
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory purge error: %s", e, exc_info=True)
                return "❌ Purge failed. The error has been logged."

        # ── Unknown subcommand ────────────────────────────────────────────
        return (
            f"Unknown memory subcommand: `{subcmd}`\n"
            "Try: `!memory help` to see available options."
        )

    async def _cmd_cron(self, inbound: InboundMessage, args: str) -> str:
        """Manage cron jobs.

        !cron list is open to all users so they can see what's scheduled.
        add/remove/run modify persistent state and can trigger API calls —
        those sub-commands require authorization when an allowlist is configured.
        """
        cron = getattr(self.bot, 'cron', None)
        if not cron:
            return "❌ Cron scheduler not available."

        parts = args.split(maxsplit=1) if args else []
        subcmd = parts[0].lower() if parts else "list"

        # Gate mutating sub-commands (add/remove/run) behind auth
        if subcmd in ("add", "remove", "run"):
            owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
            authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
            allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)
            if allowed and str(inbound.user_id) not in allowed:
                return "❌ Only authorized users can add, remove, or run cron jobs."

        if subcmd == "list":
            jobs = cron.list_jobs()
            if not jobs:
                return "📋 No cron jobs scheduled."
            lines = ["**📋 Cron Jobs:**"]
            for job in jobs:
                status = "✅" if job.enabled else "⏸️"
                lines.append(f"{status} `{job.id[:8]}` **{job.name}** — {job.schedule_kind}")
            return "\n".join(lines)

        elif subcmd == "add" and len(parts) > 1:
            from antaris_agent.core.cron import CronJob

            parsed = _parse_cron_add_spec(parts[1])
            if not parsed:
                return _cron_usage()
            if "_error" in parsed:
                return parsed["_error"]

            # Job count limit
            if len(cron.list_jobs()) >= MAX_CRON_JOBS:
                return f"❌ Job limit reached ({MAX_CRON_JOBS}). Remove some jobs with `!cron remove <id>` first."

            job = CronJob(
                id=uuid.uuid4().hex,
                name=_derive_job_name(parsed["payload_text"]),
                schedule_kind=parsed["schedule_kind"],
                schedule_every_ms=parsed.get("schedule_every_ms"),
                schedule_at=parsed.get("schedule_at"),
                schedule_cron=parsed.get("schedule_cron"),
                schedule_tz=parsed.get("schedule_tz"),
                payload_kind="agentTurn",
                payload_text=parsed["payload_text"],
                channel_id=inbound.channel_id,
                enabled=True,
                delete_after_run=parsed.get("delete_after_run", False),
            )
            cron.add_job(job)
            response = f"✅ Added job `{job.id[:8]}` — {parsed['summary']} — \"{job.payload_text}\""
            if parsed.get("_warning"):
                response += f"\n{parsed['_warning']}"
            return response

        elif subcmd == "remove" and len(parts) > 1:
            job_id = parts[1].strip()
            # Try partial match
            for jid in [j.id for j in cron.list_jobs()]:
                if jid.startswith(job_id):
                    cron.remove_job(jid)
                    return f"✅ Removed job `{jid[:8]}`."
            return f"❌ No job found matching `{job_id}`."

        elif subcmd == "run" and len(parts) > 1:
            job_id = parts[1].strip()
            for job in cron.list_jobs():
                if job.id.startswith(job_id):
                    cron.run_now(job.id)
                    return f"▶️ Job `{job.id[:8]}` queued to run next tick."
            return f"❌ No job found matching `{job_id}`."

        elif subcmd == "help":
            return _cron_usage()

        return _cron_usage()

    async def _cmd_profile(self, user_id: str, args: str) -> str:
        """Show user profile."""
        profiles = getattr(self.bot, 'profiles', None)
        if not profiles:
            return "❌ Profile manager not available."
        profile = profiles.get(user_id)
        lines = [f"**👤 Profile: `{user_id}`**"]
        if profile.display_name:
            lines.append(f"Name: {profile.display_name}")
        lines.append(f"Messages: {profile.message_count}")
        lines.append(f"Style: {profile.conversation_style}")
        if profile.last_seen:
            lines.append(f"Last seen: {profile.last_seen[:19].replace('T', ' ')} UTC")
        if profile.notes:
            lines.append(f"Notes: {len(profile.notes)} stored")
        return "\n".join(lines)

    async def _cmd_teach(self, user_id: str, args: str) -> str:
        """Manage user teachings."""
        teachings = getattr(self.bot, 'teachings', None)
        if not teachings:
            return "❌ Teaching store not available."

        text = args.strip()

        if not text or text.lower() == "list":
            items = teachings.list(user_id)
            if not items:
                return "📚 No teachings stored. Use `!teach <text>` to add one."
            lines = ["**📚 Your Teachings:**"]
            for i, t in enumerate(items, 1):
                lines.append(f"{i}. {t['text']}")
            return "\n".join(lines)

        if text.lower() == "clear":
            count = teachings.clear(user_id)
            if count == 0:
                return "📚 No teachings to clear."
            return f"🧹 Cleared {count} teaching(s)."

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!teach remove <n>`"
            try:
                index = int(parts[1].strip())
            except ValueError:
                return "Usage: `!teach remove <n>` — n must be a number."
            success = teachings.remove(user_id, index)
            if success:
                return f"✅ Teaching #{index} removed."
            return f"❌ No teaching #{index}. Use `!teach list` to see your teachings."

        # Store the teaching
        count = teachings.add(user_id, text)
        return f"✅ Got it! Teaching stored. You now have {count} teaching(s). Use `!teach list` to review."

    async def _cmd_threads(self, user_id: str) -> str:
        """List all active conversation threads for the user."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        summaries = threads.list_threads(user_id)
        if not summaries:
            return "No conversation threads yet. Chat a bit and they will appear here."
        lines = ["**🧵 Conversation Threads:**"]
        for s in summaries:
            last_ts = s["last_active"]
            import time as _time
            age_s = _time.time() - last_ts
            if age_s < 3600:
                age = f"{int(age_s // 60)}m ago"
            elif age_s < 86400:
                age = f"{int(age_s // 3600)}h ago"
            else:
                age = f"{int(age_s // 86400)}d ago"
            lines.append(
                f"**{s['name']}** -- {s['turn_count']} turns, last active {age}"
            )
        return "\n".join(lines)

    async def _cmd_thread(self, user_id: str, args: str) -> str:
        """Show the conversation thread matching a topic query."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        query = args.strip()
        if not query:
            return "Usage: `!thread <topic>` -- e.g. `!thread website` or `!thread deployment`"
        turns = threads.get_thread(user_id, query)
        if not turns:
            return f"No thread found matching '{query}'. Use `!threads` to see available topics."
        lines = [f"**🧵 Thread: {turns[0]['topic']}** ({len(turns)} turns)\n"]
        for t in turns[-20:]:  # show up to 20 most recent turns
            prefix = "You" if t["role"] == "user" else "Antaris"
            snippet = t["content"][:200].replace("\n", " ")
            if len(t["content"]) > 200:
                snippet += "..."
            lines.append(f"**{prefix}:** {snippet}")
        return "\n".join(lines)

    async def _cmd_export(self, user_id: str, args: str) -> str:
        """Export conversation history to a markdown file."""
        exporter = getattr(self.bot, 'exporter', None)
        if not exporter:
            return "Export is not available."

        text = args.strip().lower()

        if not text:
            return (
                "**Export usage:**\n"
                "`!export today` — export today's conversation\n"
                "`!export week` — export last 7 days\n"
                "`!export project <name>` — export conversations about a topic\n"
                "`!export all` — export everything"
            )

        if text == "today":
            filepath, summary = exporter.export_recent(user_id, days=1)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "week":
            filepath, summary = exporter.export_recent(user_id, days=7)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "all":
            filepath, summary = exporter.export_all(user_id)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        # project <name>
        parts = args.strip().split(maxsplit=1)
        if parts[0].lower() == "project":
            if len(parts) < 2 or not parts[1].strip():
                return "Usage: `!export project <name>`"
            topic = parts[1].strip()
            filepath, summary = exporter.export_by_topic(user_id, topic)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        return (
            "Unknown export option. Try:\n"
            "`!export today` | `!export week` | `!export project <name>` | `!export all`"
        )

    async def _cmd_shortcuts(self, user_id: str, args: str) -> str:
        """List or remove learned implicit shortcuts."""
        shortcuts = getattr(self.bot, 'shortcuts', None)
        if not shortcuts:
            return "Shortcut learning is not available."

        text = args.strip()

        if not text:
            items = shortcuts.list_shortcuts(user_id)
            if not items:
                return (
                    "No shortcuts learned yet. "
                    "Use short phrases repeatedly for the same action and I will learn them automatically."
                )
            lines = ["**Learned Shortcuts:**"]
            for item in items:
                lines.append(f'`{item["phrase"]}` -> {item["expansion"]} (seen {item["count"]}x)')
            return "\n".join(lines)

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!shortcuts remove <phrase>`"
            phrase = parts[1].strip()
            removed = shortcuts.remove(user_id, phrase)
            if removed:
                return f'Shortcut `{phrase}` removed.'
            return f'No shortcut found for `{phrase}`. Use `!shortcuts` to see your shortcuts.'

        return "Usage: `!shortcuts` or `!shortcuts remove <phrase>`"

    async def _cmd_feedback(self, user_id: str, args: str) -> str:
        """Show or clear reaction-based feedback."""
        feedback = getattr(self.bot, 'feedback', None)
        if not feedback:
            return "Feedback tracking is not available."

        text = args.strip().lower()

        if text == "clear":
            feedback.clear(user_id)
            return "Feedback cleared."

        stats = feedback.get_stats(user_id)
        if stats["total"] == 0:
            return (
                "No feedback recorded yet.\n"
                "React to my messages with 👍 or 👎 to train my responses."
            )

        pos = stats["positive"]
        neg = stats["negative"]
        total = stats["total"]
        lines = [
            f"**Reaction Feedback ({total} total)**",
            f"Positive: {pos} (👍 ❤️ ✅ 🔥 💯 👏)",
            f"Negative: {neg} (👎 ❌ 😕 🚫)",
            "",
            "Use `!feedback clear` to reset.",
        ]
        return "\n".join(lines)

    # ── Subagent commands ─────────────────────────────────────────────────

    async def _cmd_spawn(self, inbound: "InboundMessage", args: str) -> str:
        """
        !spawn [name] <task>
        !spawn <task>            — auto-named (a, b, c …)
        !spawn 3 <task>          — spawn 3 auto-named agents with the same task
        !spawn a,b,c <task>      — spawn named agents a, b, c with same task
        """
        if not hasattr(self.bot, "subagents"):
            return "⚠️ Subagent system not initialised."

        # Auth gate — spawning subagents costs API budget; restrict to owners/authorized users.
        # Deny-by-default when an allowlist is configured.
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)

        if allowed and str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can spawn subagents."

        args = args.strip()
        if not args:
            return "Usage: `!spawn [name] <task>` — e.g. `!spawn scout Research antaris-suite competitors`"

        registry = self.bot.subagents
        channel = getattr(self.bot, "_active_discord_channel", None)

        # Parse: "3 <task>" → spawn 3 auto-named agents
        parts = args.split(maxsplit=1)
        if parts[0].isdigit():
            count = int(parts[0])
            task = parts[1] if len(parts) > 1 else "No task specified."
            results = await registry.spawn_many([task] * count, origin_channel=channel, parent_user_id=inbound.user_id)
            lines = [msg for _, msg in results]
            return "\n".join(lines)

        # Parse: "a,b,c <task>" → spawn named agents
        if "," in parts[0] and len(parts) > 1:
            names = [n.strip() for n in parts[0].split(",")]
            task = parts[1]
            results = await registry.spawn_many([task] * len(names), names=names, origin_channel=channel, parent_user_id=inbound.user_id)
            lines = [msg for _, msg in results]
            return "\n".join(lines)

        # Parse: "name task…" — first word is name if it looks like a label
        # (single word, no spaces, short) — otherwise whole thing is the task
        first = parts[0]
        rest = parts[1] if len(parts) > 1 else ""

        if rest and len(first) <= 20 and first.replace("-", "").replace("_", "").isalnum():
            # "scout research competitors" → name=scout, task=research competitors
            name = first
            task = rest
        else:
            # whole args is the task, auto-name
            name = None
            task = args

        channel = getattr(self.bot, "_active_discord_channel", None)
        ok, msg = await registry.spawn(task=task, name=name, origin_channel=channel, parent_user_id=inbound.user_id)
        return msg

    async def _cmd_agent(self, inbound: "InboundMessage", args: str) -> str:
        """Handle !agent — mode subcommand or fall through to !spawn."""
        if args.lower().startswith("mode"):
            return await self._cmd_agent_mode(inbound, args)
        return await self._cmd_spawn(inbound, args)

    # ── Session mode helpers ────────────────────────────────────────────────

    def _get_config_dir(self) -> str:
        """Return the bot config directory."""
        return getattr(self.bot, 'config_dir', None) or os.path.expanduser('~/.antaris')

    def _get_session_mode(self) -> str:
        """Read current session mode — delegates to SessionManager (single source of truth)."""
        pipeline = getattr(self.bot, 'pipeline', None)
        if pipeline and hasattr(pipeline, '_session_manager'):
            return pipeline._session_manager._get_session_mode()
        # Fallback: read file directly (shouldn't happen in normal operation)
        config_dir = self._get_config_dir()
        mode_file = os.path.join(config_dir, 'session_mode.json')
        if os.path.exists(mode_file):
            try:
                with open(mode_file) as f:
                    return json.load(f).get('mode', 'multi')
            except (json.JSONDecodeError, OSError):
                pass
        return 'multi'

    def _set_session_mode(self, mode: str, user_id: str) -> None:
        """Write session mode to config file (atomic write)."""
        config_dir = self._get_config_dir()
        os.makedirs(config_dir, exist_ok=True)
        mode_file = os.path.join(config_dir, 'session_mode.json')
        tmp_file = mode_file + '.tmp'
        data = {
            "mode": mode,
            "changed_at": datetime.now(timezone.utc).isoformat(),
            "changed_by": user_id,
        }
        with open(tmp_file, 'w') as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_file, mode_file)

    async def _cmd_agent_mode(self, inbound: "InboundMessage", args: str) -> str:
        """Handle !agent mode single|multi|status commands.

        Status is readable by all. Switching modes writes persistent config —
        restricted to authorized users.
        """
        # args is "mode ..." — strip the "mode" prefix
        mode_args = args.strip()
        if mode_args.lower().startswith("mode"):
            mode_args = mode_args[4:].strip()

        current_mode = self._get_session_mode()

        # Parse: "", "status", "single", "multi", "single confirm", "multi confirm"
        parts = mode_args.lower().split()

        if not parts or parts[0] == "status":
            if current_mode == "single":
                return "📡 Current mode: **single** (all channels share one session)"
            return "📡 Current mode: **multi** (separate session per channel)"

        requested = parts[0]
        if requested not in ("single", "multi"):
            return "Usage: `!agent mode single|multi|status`"

        # Auth gate — switching mode writes persistent config; restrict to authorized users
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)
        if allowed and str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can change the session routing mode."

        confirm = len(parts) > 1 and parts[1] == "confirm"

        # Already in requested mode
        if current_mode == requested:
            return f"Already in **{requested}** mode."

        if not confirm:
            if requested == "single":
                return "⚠️ Switch to single-session mode? All channels will share one context window. Reply `!agent mode single confirm` to proceed."
            else:
                return "⚠️ Switch to multi-session mode? Each channel will get its own session. Reply `!agent mode multi confirm` to proceed."

        # Confirmed — write the config
        self._set_session_mode(requested, inbound.user_id)

        if requested == "single":
            return "✅ Single mode active. All channels now share one session.\n⚠️ Note: existing per-channel histories are preserved but won't be visible until you switch back to multi mode."
        return "✅ Multi mode active. Each channel now has its own session.\n⚠️ Note: the unified session history is preserved but won't be visible until you switch back to single mode."

    async def _cmd_sync(self, inbound: "InboundMessage", args: str) -> str:
        """Handle !sync memory <hours> command.

        Writes peer memories into the local store — restricted to authorized users.
        """
        # Auth gate — memory sync writes data from external peers into the store
        owner_ids = getattr(self.bot, '_owner_ids', set()) or set()
        authorized = getattr(self.bot.config, 'authorized_users', []) if self.bot.config else []
        allowed = set(str(uid) for uid in owner_ids) | set(str(uid) for uid in authorized)
        if allowed and str(inbound.user_id) not in allowed:
            return "❌ Only authorized users can sync memory from peers."

        text = args.strip()
        parts = text.split() if text else []

        if not parts or parts[0].lower() != "memory":
            return "Usage: `!sync memory <hours>` (1-24)"

        # Parse hours
        hours = 6  # default
        if len(parts) > 1:
            try:
                hours = int(parts[1])
            except ValueError:
                return "Usage: `!sync memory <hours>` (1-24, default 6)"

        if hours < 1 or hours > 24:
            return "❌ Hours must be between 1 and 24."

        try:
            from parsica_memory.sync import PeerSync
            workspace = getattr(self.bot, 'memory_workspace', None) or os.path.expanduser('~/.antaris/memory')
            syncer = PeerSync(workspace)

            if not syncer.default_peers:
                return "⚠️ No `sync_peers` configured in parsica_config.json. Add peer store paths to sync from."

            result = syncer.sync(hours=hours)

            def _coerce_int(value, default=0):
                try:
                    return int(value)
                except (TypeError, ValueError):
                    return default

            synced = _coerce_int(getattr(result, "synced", 0))
            skipped = _coerce_int(getattr(result, "skipped", 0))

            log_lines_merged = getattr(result, "log_lines_merged", None)
            if not isinstance(log_lines_merged, int):
                fallback = getattr(syncer, "sync_daily_logs", None)
                if callable(fallback):
                    try:
                        log_lines_merged = fallback(hours=hours)
                    except TypeError:
                        log_lines_merged = fallback()
                else:
                    log_lines_merged = 0
            log_lines_merged = _coerce_int(log_lines_merged)

            errors = getattr(result, "errors", [])
            if not isinstance(errors, list):
                errors = []

            msg = (
                f"🔄 Synced last {hours}h: **{synced}** new memories, "
                f"{skipped} duplicates skipped, {log_lines_merged} daily log lines merged."
            )
            if errors:
                msg += f"\n⚠️ Errors: {'; '.join(str(e) for e in errors if str(e).strip())}"
            return msg
        except ImportError:
            return "❌ parsica_memory not available. Install with `pip install parsica-memory>=3.1.8`"
        except Exception as e:
            logger.error("!memory sync failed: %s", e, exc_info=True)
            return "❌ Sync failed. The error has been logged."

    async def _cmd_agents(self, inbound: "InboundMessage", args: str) -> str:
        """
        !agents             — list all subagents
        !agents kill <name> — terminate a subagent
        !agents result <name> — get full result text
        """
        if not hasattr(self.bot, "subagents"):
            return "⚠️ Subagent system not initialised."

        registry = self.bot.subagents
        args = args.strip()

        if not args:
            return registry.status_board()

        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower()
        name = parts[1].strip() if len(parts) > 1 else ""

        if subcmd == "kill":
            if not name:
                return "Usage: `!agents kill <name>`"
            if not self._is_authorized_command_user(inbound.user_id):
                return "❌ Only authorized users can kill subagents."
            ok, msg = await registry.kill(name)
            return msg

        if subcmd == "result":
            if not name:
                return "Usage: `!agents result <name>`"
            text = registry.result_text(name)
            if text is None:
                return f"No result for **{name}** yet."
            return f"**Result from {name}:**\n{text}"

        return f"Unknown subcommand `{subcmd}`. Try: `!agents`, `!agents kill <name>`, `!agents result <name>`"

    # ── Cost command ──────────────────────────────────────────────────────

    async def _cmd_cost(self, user_id: str, args: str) -> str:
        """
        !cost       — show the requesting user's token usage and cost
        !cost all   — show global summary (admin only)
        """
        try:
            pipeline = getattr(self.bot, "pipeline", None)
            if not pipeline:
                return "❌ Pipeline not available."

            cost_tracker = getattr(pipeline, "cost_tracker", None)
            if not cost_tracker:
                return "❌ Cost tracker not available."

            if not cost_tracker.enabled:
                return "ℹ️ Cost tracking is disabled."

            sub = args.strip().lower()

            if sub == "all":
                # Admin-only: check owner_user_id or admin_users
                config = getattr(self.bot, "config", None)
                is_admin = False
                if config:
                    owner = getattr(config, "owner_user_id", "")
                    if owner and str(user_id) == str(owner):
                        is_admin = True
                    # Also check admin_users list if present
                    admin_users = getattr(config, "admin_users", [])
                    if str(user_id) in [str(u) for u in admin_users]:
                        is_admin = True

                if not is_admin:
                    return "⛔ `!cost all` is restricted to bot admins."

                return cost_tracker.format_global_summary()

            # Default: show requesting user's stats
            return cost_tracker.format_user_stats(user_id)

        except Exception as e:
            logger.warning("_cmd_cost failed: %s", e)
            return "❌ Could not retrieve cost stats."

    # ── Extension commands ────────────────────────────────────────────────

    async def _cmd_extensions(self, user_id: str, args: str) -> str:
        """
        !extensions          — list all extensions and their status
        !extensions reload <name> — hot-reload an extension
        !extensions disable <name> — disable an extension
        """
        manager = getattr(self.bot, '_extension_manager', None)
        if not manager:
            return "Extension system not available."

        text = args.strip()
        if not text:
            return manager.status_board()

        parts = text.split(maxsplit=1)
        subcmd = parts[0].lower()
        name = parts[1].strip() if len(parts) > 1 else ""

        if subcmd == "reload" and name:
            if not self._is_authorized_command_user(user_id):
                return "❌ Only authorized users can reload extensions."
            success = await manager.reload(name)
            if success:
                return f"✅ Extension **{name}** reloaded."
            return f"❌ Failed to reload **{name}**."

        if subcmd == "disable" and name:
            if not self._is_authorized_command_user(user_id):
                return "❌ Only authorized users can disable extensions."
            success = await manager.unload(name)
            if success:
                return f"⏸️ Extension **{name}** disabled."
            return f"❌ Could not disable **{name}**."

        return "Usage: `!extensions`, `!extensions reload <name>`, `!extensions disable <name>`"

    async def _cmd_auth(self, user_id: str, args: str) -> str:
        """Show auth/API key status or manage profiles.
        
        Usage:
            !auth          — show auth status
            !auth rotate   — manually trigger profile rotation for primary provider
            !auth rotate <provider> — rotate a specific provider
        """
        auth_monitor = getattr(self.bot, 'auth_monitor', None)
        if not auth_monitor:
            return "Auth monitoring not available."

        subcmd = args.strip().split()[0].lower() if args.strip() else ""

        if subcmd == "rotate":
            if not self._is_authorized_command_user(user_id):
                return "❌ Only authorized users can rotate auth profiles."
            # Manual rotation
            parts = args.strip().split()
            provider = parts[1] if len(parts) > 1 else self.bot.config.provider_name
            current_profile = auth_monitor.get_active_profile(provider)
            result = auth_monitor.try_rotate_profile(
                provider,
                current_profile=current_profile,
                reason="manual",
            )
            if result:
                new_pid, new_cred = result
                # Update the live provider's key
                dispatcher = getattr(self.bot, 'dispatcher', None)
                if dispatcher:
                    p = dispatcher.get(provider)
                    if p:
                        p.api_key = new_cred
                    dispatcher.set_active_profile(provider, new_pid)
                return f"🔄 Rotated **{provider}** to profile `{new_pid}`"
            return f"❌ No alternative profile available for **{provider}**"

        return auth_monitor.get_status_text()

    async def _cmd_skills(self, user_id: str, args: str) -> str:
        """Show custom skills status."""
        skill_reg = getattr(self.bot, 'skill_registry', None)
        if not skill_reg:
            return "Custom skills not available."
        return skill_reg.status_text()

    async def _cmd_thinking(self, user_id: str, args: str) -> str:
        """Set thinking/reasoning level."""
        controller = getattr(self.bot, 'model_controller', None)
        if not controller:
            return "Model control not available."

        if not args.strip():
            level, budget = controller.get_thinking_for_user(user_id)
            if level == "off":
                return "🧠 Thinking: off\nSet with: `!thinking low|medium|high|max` or `!reasoning low|medium|high|max`"
            support = controller.get_thinking_support(user_id)
            if support.supported:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"✅ Active on `{support.model}` via {support.provider}" +
                    (f" ({support.mechanism})" if support.mechanism else "")
                )
            if support.model and support.provider:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"⚠️ Current model `{support.model}` via {support.provider} does not support provider-side thinking."
                )
            return f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)"

        return controller.set_thinking(user_id, args.strip())

    async def _cmd_models(self, user_id: str) -> str:
        """List available model aliases and costs."""
        from antaris_agent.extensions.model_control import MODEL_ALIASES, MODEL_COSTS
        lines = ["**Available Models:**\n"]

        providers: dict = {}
        seen = set()
        for alias, (model, provider) in sorted(MODEL_ALIASES.items()):
            if provider not in providers:
                providers[provider] = []
            cost_info = ""
            if model in MODEL_COSTS:
                in_c, out_c = MODEL_COSTS[model]
                cost_info = f" (${in_c}/{out_c})"
            entry = f"`{alias}` → {model}{cost_info}"
            if entry not in seen:
                providers[provider].append(entry)
                seen.add(entry)

        for provider, entries in providers.items():
            lines.append(f"**{provider.title()}:**")
            for entry in entries:
                lines.append(f"  {entry}")
            lines.append("")

        lines.append("Use `!model <alias>` to switch, `!thinking <level>` (or `!reasoning <level>`) for reasoning depth")
        return "\n".join(lines)

    async def _cmd_discover(self, user_id: str, args: str) -> str:
        """
        !discover           — show the next capability hint
        !discover status    — show all category statuses
        !discover audit     — show all unconfigured capabilities (full audit)
        !discover dismiss   — dismiss the current hint category
        !discover snooze [hours] — snooze the current hint category
        !discover disable [category] — permanently disable a category
        !discover enable [category]  — re-enable a category
        !discover off       — disable all discovery reminders
        !discover on        — re-enable discovery reminders
        !discover reset     — reset all discovery state
        """
        from antaris_agent.core.discovery import (
            DiscoveryManager, ALL_CATEGORIES, CATEGORY_LABELS,
            format_hint_markdown, format_status_markdown,
        )
        from pathlib import Path

        config_dir = str(Path(self.bot.config.config_path).parent)
        dm = DiscoveryManager(config_dir)

        text = args.strip().lower()
        parts = text.split() if text else []
        subcmd = parts[0] if parts else ""

        if not subcmd:
            # Show the next hint (ignore timing constraints for manual invocation)
            hints = dm.get_all_hints(self.bot.config)
            # Filter out disabled/snoozed categories
            import time as _time
            now = _time.time()
            eligible = [
                h for h in hints
                if not dm.state.categories.get(h.category, type('', (), {'permanently_disabled': False, 'snoozed_until': 0})()).permanently_disabled
                and dm.state.categories.get(h.category, type('', (), {'snoozed_until': 0})()).snoozed_until <= now
            ]
            if not eligible:
                return "✅ All capabilities configured! Nothing to discover right now."
            hint = eligible[0]
            dm.mark_shown(hint.category, message_count=getattr(self.bot, '_message_count', 0))
            return format_hint_markdown(hint)

        if subcmd == "status":
            status = dm.get_category_status()
            return format_status_markdown(status)

        if subcmd == "audit":
            hints = dm.get_all_hints(self.bot.config)
            if not hints:
                return "✅ **Full capability audit complete** — everything is configured!"
            lines = ["**🔍 Capability Audit — Unconfigured Features:**\n"]
            current_cat = None
            for hint in hints:
                if hint.category != current_cat:
                    current_cat = hint.category
                    label = CATEGORY_LABELS.get(hint.category, hint.category)
                    lines.append(f"\n**{label}**")
                lines.append(f"  • **{hint.title}** — {hint.message[:100]}...")
                lines.append(f"    → {hint.action_hint}")
            return "\n".join(lines)

        if subcmd == "dismiss":
            # Dismiss the most recently relevant category
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.dismiss(hints[0].category)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"👋 Dismissed {label} hint. It will come back next check cycle."
            return "Nothing to dismiss."

        if subcmd == "snooze":
            hours = 24.0
            if len(parts) > 1:
                try:
                    hours = float(parts[1])
                except ValueError:
                    return "Usage: `!discover snooze [hours]` — e.g. `!discover snooze 48`"
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.snooze(hints[0].category, hours=hours)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"😴 Snoozed {label} for {hours:.0f} hours."
            return "Nothing to snooze."

        if subcmd == "disable":
            if len(parts) > 1:
                cat = parts[1]
                # Try to match by name or partial
                matched = None
                for c in ALL_CATEGORIES:
                    if c == cat or c.startswith(cat) or cat in c:
                        matched = c
                        break
                if not matched:
                    cats = ", ".join(f"`{c}`" for c in ALL_CATEGORIES)
                    return f"Unknown category `{cat}`. Available: {cats}"
                dm.disable(matched)
                label = CATEGORY_LABELS.get(matched, matched)
                return f"🔴 Permanently disabled {label} reminders. Use `!discover enable {matched}` to re-enable."
            # No category specified: disable the top hint category
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.disable(hints[0].category)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"🔴 Permanently disabled {label} reminders."
            return "Nothing to disable."

        if subcmd == "enable":
            if len(parts) > 1:
                cat = parts[1]
                matched = None
                for c in ALL_CATEGORIES:
                    if c == cat or c.startswith(cat) or cat in c:
                        matched = c
                        break
                if not matched:
                    cats = ", ".join(f"`{c}`" for c in ALL_CATEGORIES)
                    return f"Unknown category `{cat}`. Available: {cats}"
                dm.enable(matched)
                label = CATEGORY_LABELS.get(matched, matched)
                return f"🟢 Re-enabled {label} reminders."
            return "Usage: `!discover enable <category>` — e.g. `!discover enable automation`"

        if subcmd == "off":
            dm.disable_all()
            return "🔴 All discovery reminders disabled. Use `!discover on` to re-enable."

        if subcmd == "on":
            dm.enable_all()
            return "🟢 Discovery reminders re-enabled."

        if subcmd == "reset":
            dm.reset()
            return "🔄 Discovery state reset to defaults."

        return (
            "**🔍 Discover Commands:**\n"
            "`!discover` — show the next capability hint\n"
            "`!discover status` — show all category statuses\n"
            "`!discover audit` — full audit of unconfigured features\n"
            "`!discover dismiss` — dismiss the current hint\n"
            "`!discover snooze [hours]` — snooze current category (default: 24h)\n"
            "`!discover disable [category]` — permanently disable a category\n"
            "`!discover enable <category>` — re-enable a disabled category\n"
            "`!discover off` — disable all reminders\n"
            "`!discover on` — re-enable all reminders\n"
            "`!discover reset` — reset all discovery state\n"
            f"\nCategories: {', '.join(f'`{c}`' for c in ALL_CATEGORIES)}"
        )

    async def _cmd_webhooks(self, user_id: str, args: str) -> str:
        """Show webhook status."""
        webhooks = getattr(self.bot, 'webhooks', None)
        if not webhooks:
            return "Webhook system not available."

        status = webhooks.status()
        lines = ["**🔗 Webhooks:**"]
        lines.append(f"Running: {'✅' if status['running'] else '❌'}")
        lines.append(f"Queue size: {status['queue_size']}")
        lines.append(f"Sent: {status['stats']['total_sent']}")
        lines.append(f"Failed: {status['stats']['total_failed']}")

        for ep in status['endpoints']:
            icon = "✅" if ep['enabled'] else "⏸️"
            circuit = " ⚡OPEN" if ep.get('circuit_open') else ""
            events = ep['events'] if ep['events'] != "all" else "all events"
            lines.append(f"\n{icon} `{ep['url']}`{circuit}")
            lines.append(f"  Events: {events}")
            if ep.get('failure_count', 0) > 0:
                lines.append(f"  Failures: {ep['failure_count']}")

        return "\n".join(lines)
