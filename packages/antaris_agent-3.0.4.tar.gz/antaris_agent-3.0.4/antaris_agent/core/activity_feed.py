"""
Persisted Activity Feed - Commit 3
Lightweight append-only activity log for agent actions.
Persisted to disk alongside memory store.
"""

import json
import os
import time
import threading
from pathlib import Path
from typing import Optional, List, Dict, Any


class ActivityFeed:
    """Append-only activity feed persisted to JSONL."""

    MAX_ENTRIES = 500
    ARCHIVE_KEEP = 100

    ACTION_TYPES = {
        "memory_write",
        "memory_read", 
        "tool_use",
        "response",
        "subagent_spawn",
        "subagent_result",
        "system",
    }

    def __init__(self, store_path: str):
        self._store_path = Path(store_path)
        self._feed_path = self._store_path / "activity_feed.jsonl"
        self._archive_path = self._store_path / "activity_feed_archive.jsonl"
        self._lock = threading.Lock()
        self._store_path.mkdir(parents=True, exist_ok=True)
        self._entries: List[Dict[str, Any]] = []
        self._load()

    def _load(self):
        """Load existing feed from disk."""
        if self._feed_path.exists():
            try:
                with open(self._feed_path, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                self._entries.append(json.loads(line))
                            except json.JSONDecodeError:
                                continue
            except OSError:
                self._entries = []

    def append(
        self,
        action_type: str,
        summary: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Append an entry to the feed."""
        if action_type not in self.ACTION_TYPES:
            action_type = "system"

        entry = {
            "timestamp": time.time(),
            "iso_time": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "action_type": action_type,
            "summary": summary,
            "metadata": metadata or {},
        }

        with self._lock:
            self._entries.append(entry)
            self._persist_entry(entry)
            self._maybe_rotate()

        return entry

    def _persist_entry(self, entry: Dict[str, Any]):
        """Append a single entry to the JSONL file."""
        try:
            with open(self._feed_path, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except OSError:
            pass

    def _maybe_rotate(self):
        """Rotate feed if it exceeds MAX_ENTRIES."""
        if len(self._entries) > self.MAX_ENTRIES:
            archive_entries = self._entries[: -self.ARCHIVE_KEEP]
            self._entries = self._entries[-self.ARCHIVE_KEEP :]

            # Append old entries to archive
            try:
                with open(self._archive_path, "a") as f:
                    for entry in archive_entries:
                        f.write(json.dumps(entry) + "\n")
            except OSError:
                pass

            # Rewrite active feed
            try:
                with open(self._feed_path, "w") as f:
                    for entry in self._entries:
                        f.write(json.dumps(entry) + "\n")
            except OSError:
                pass

    def recent(self, n: int = 20) -> List[Dict[str, Any]]:
        """Get the N most recent entries."""
        with self._lock:
            return list(self._entries[-n:])

    def search(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Simple keyword search across summaries."""
        query_lower = query.lower()
        results = []
        with self._lock:
            for entry in reversed(self._entries):
                if query_lower in entry.get("summary", "").lower():
                    results.append(entry)
                    if len(results) >= limit:
                        break
        return results

    def by_type(self, action_type: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Get entries filtered by action type."""
        results = []
        with self._lock:
            for entry in reversed(self._entries):
                if entry.get("action_type") == action_type:
                    results.append(entry)
                    if len(results) >= limit:
                        break
        return results

    def stats(self) -> Dict[str, Any]:
        """Get feed statistics."""
        with self._lock:
            type_counts = {}
            for entry in self._entries:
                t = entry.get("action_type", "unknown")
                type_counts[t] = type_counts.get(t, 0) + 1
            return {
                "total_entries": len(self._entries),
                "action_types": type_counts,
                "oldest": self._entries[0]["iso_time"] if self._entries else None,
                "newest": self._entries[-1]["iso_time"] if self._entries else None,
            }
