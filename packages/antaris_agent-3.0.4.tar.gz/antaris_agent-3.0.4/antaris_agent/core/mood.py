"""Mood detection from message patterns - adapts response style."""
import logging
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class MoodSignal:
    """A single mood data point."""
    timestamp: float
    msg_length: int
    has_caps: bool          # significant CAPS usage
    has_punctuation: bool   # !! or ?? or ...
    is_question: bool
    word_count: int
    sentiment_hint: str     # "positive", "negative", "neutral"


class MoodDetector:
    """Detects user mood from recent message patterns and generates style guidance."""

    def __init__(self, window_size: int = 10):
        self._signals: dict[str, deque] = {}  # user_id -> recent signals
        self.window_size = window_size

    def observe(self, user_id: str, text: str) -> None:
        """Record a mood signal from a user message."""
        if user_id not in self._signals:
            self._signals[user_id] = deque(maxlen=self.window_size)

        signal = self._analyze(text)
        self._signals[user_id].append(signal)

    def get_mood(self, user_id: str) -> str:
        """Get the current detected mood. Returns one of:
        'frustrated', 'focused', 'relaxed', 'excited', 'neutral'
        """
        signals = self._signals.get(user_id)
        if not signals or len(signals) < 2:
            return "neutral"

        recent = list(signals)[-5:]  # last 5 messages

        avg_words = sum(s.word_count for s in recent) / len(recent)
        caps_ratio = sum(1 for s in recent if s.has_caps) / len(recent)
        punct_ratio = sum(1 for s in recent if s.has_punctuation) / len(recent)
        negative_ratio = sum(1 for s in recent if s.sentiment_hint == "negative") / len(recent)
        positive_ratio = sum(1 for s in recent if s.sentiment_hint == "positive") / len(recent)
        question_ratio = sum(1 for s in recent if s.is_question) / len(recent)

        # Frustrated: short messages + caps + negative sentiment + punctuation
        if avg_words < 6 and (caps_ratio > 0.3 or negative_ratio > 0.4) and punct_ratio > 0.3:
            return "frustrated"

        # Focused: moderate length, lots of questions, neutral tone
        if question_ratio > 0.4 and negative_ratio < 0.2:
            return "focused"

        # Excited: caps + positive + longer messages + punctuation
        if positive_ratio > 0.4 and (caps_ratio > 0.2 or punct_ratio > 0.3):
            return "excited"

        # Relaxed: longer messages, positive or neutral, low caps/punct
        if avg_words > 10 and caps_ratio < 0.2 and negative_ratio < 0.2:
            return "relaxed"

        return "neutral"

    def get_context(self, user_id: str) -> str:
        """Build style guidance for the system prompt."""
        mood = self.get_mood(user_id)

        guidance = {
            "frustrated": (
                "## Response Style Guidance\n"
                "The user seems frustrated. Keep responses short and direct. "
                "No filler, no pleasantries. Acknowledge the problem immediately "
                "and focus on the fix."
            ),
            "focused": (
                "## Response Style Guidance\n"
                "The user is in a focused, task-oriented mode. "
                "Be precise and efficient. Provide structured answers. Skip small talk."
            ),
            "excited": (
                "## Response Style Guidance\n"
                "The user is in good spirits. Stay direct but don't be dry. "
                "Keep the same no-filler approach but allow a bit more personality. "
                "Do NOT use filler affirmations like 'That's fantastic!' or 'Great idea!' "
                "Just engage with the substance of what they're saying."
            ),
            "relaxed": (
                "## Response Style Guidance\n"
                "The user is relaxed and conversational. "
                "You can be more detailed and add context. "
                "A bit of personality is welcome but skip performative enthusiasm."
            ),
        }

        return guidance.get(mood, "")

    def _analyze(self, text: str) -> MoodSignal:
        """Analyze a single message for mood signals."""
        # Caps detection (more than 30% uppercase letters, excluding short messages)
        alpha_chars = [c for c in text if c.isalpha()]
        has_caps = (
            len(alpha_chars) > 5
            and sum(1 for c in alpha_chars if c.isupper()) / len(alpha_chars) > 0.3
        )

        # Punctuation patterns
        has_punctuation = bool(re.search(r'[!?]{2,}|\.{3,}', text))

        # Question detection
        is_question = text.strip().endswith('?')

        # Simple sentiment hints
        negative_words = {
            "broken", "wrong", "error", "fail", "bug", "fix", "crash", "stuck",
            "annoying", "frustrated", "ugh", "damn", "wtf", "smh", "hate",
            "terrible", "awful", "useless", "sucks",
        }
        positive_words = {
            "great", "awesome", "perfect", "nice", "love", "excellent", "amazing",
            "good", "thanks", "cool", "sweet", "brilliant", "wow", "incredible",
            "beautiful", "fantastic",
        }

        words = set(re.findall(r'\b\w+\b', text.lower()))
        neg_count = len(words & negative_words)
        pos_count = len(words & positive_words)

        if neg_count > pos_count:
            sentiment = "negative"
        elif pos_count > neg_count:
            sentiment = "positive"
        else:
            sentiment = "neutral"

        return MoodSignal(
            timestamp=time.time(),
            msg_length=len(text),
            has_caps=has_caps,
            has_punctuation=has_punctuation,
            is_question=is_question,
            word_count=len(text.split()),
            sentiment_hint=sentiment,
        )

    def reset(self, user_id: Optional[str] = None) -> None:
        """Reset mood signals for a user, or all users if user_id is None."""
        if user_id:
            self._signals.pop(user_id, None)
        else:
            self._signals.clear()
