"""
antaris_agent/core/guard.py

Thin wrapper around antaris-guard (v4.0.x) for Antaris Agent.
Handles input + output filtering with configurable modes.

Real API discovered via inspection:
    PromptGuard(sensitivity=...) — prompt injection / threat detector
        .analyze(text, source_id) → GuardResult
            .is_blocked    bool
            .is_suspicious bool
            .is_safe       bool
            .score         float  (0.0 safe → 1.0 malicious)
            .message       str

    ContentFilter() — PII / sensitive-data filter for output
        .filter_content(text, sanitize=True) → FilterResult
            .filtered_text  str   (redacted version)
            .pii_found      bool
            .redaction_count int

Guard modes:
    "monitor" — always passes, logs violations to stdout
    "warn"    — always passes, prints a warning for suspicious/blocked
    "block"   — blocks input when PromptGuard marks it blocked/suspicious
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Real imports — fail loud so operators know what's missing.
# ---------------------------------------------------------------------------
try:
    from antaris_agent.suite.guard import PromptGuard, SensitivityLevel
    _GUARD_AVAILABLE = True
except ImportError:
    _GUARD_AVAILABLE = False
    PromptGuard = None           # type: ignore[assignment, misc]
    SensitivityLevel = None      # type: ignore[assignment, misc]

try:
    from antaris_agent.suite.guard import ContentFilter
    _FILTER_AVAILABLE = True
except ImportError:
    _FILTER_AVAILABLE = False
    ContentFilter = None         # type: ignore[assignment, misc]

_VALID_MODES = {"disabled", "monitor", "warn", "block"}


class BotGuard:
    """
    Wrapper around antaris-guard for Antaris Agent.
    Handles input + output filtering with configurable modes.

    Args:
        mode: One of "monitor" | "warn" | "block"
            monitor — always allow, log violations
            warn    — always allow, print warning for suspicious/blocked
            block   — deny if PromptGuard marks input as blocked or suspicious
    """

    def __init__(self, mode: str = "monitor"):
        if mode not in _VALID_MODES:
            raise ValueError(f"Invalid guard mode '{mode}'. Must be one of: {_VALID_MODES}")
        self.mode = mode
        self._guard = None        # PromptGuard instance
        self._filter = None       # ContentFilter instance
        self._init_guard()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _init_guard(self):
        """
        Initialize antaris-guard components for the current mode.

        PromptGuard sensitivity is tuned to mode:
            monitor → permissive (fewest false positives, observe only)
            warn    → balanced   (default)
            block   → strict     (maximum protection)
        """
        if self.mode == "disabled":
            self._guard = None
            self._filter = None
            return

        if _GUARD_AVAILABLE and PromptGuard is not None:
            sensitivity_map = {
                "monitor": SensitivityLevel.PERMISSIVE,
                "warn": SensitivityLevel.BALANCED,
                "block": SensitivityLevel.STRICT,
            }
            sensitivity = sensitivity_map.get(self.mode, SensitivityLevel.BALANCED)
            try:
                self._guard = PromptGuard(sensitivity=sensitivity)
            except Exception as e:
                logger.warning("Failed to init PromptGuard: %s", e)
                self._guard = None
        else:
            logger.warning(
                "antaris-guard not available — BotGuard running in passthrough mode"
            )
            self._guard = None

        if _FILTER_AVAILABLE and ContentFilter is not None:
            try:
                self._filter = ContentFilter()
            except Exception as e:
                logger.warning("Failed to init ContentFilter: %s", e)
                self._filter = None
        else:
            self._filter = None

    # ------------------------------------------------------------------
    # Public async interface
    # ------------------------------------------------------------------

    async def check_input(self, text: str, user_id: str = "") -> tuple[bool, str]:
        """
        Check an inbound message for prompt injection / threats.

        Returns:
            (allowed: bool, reason: str)

        Modes:
            monitor — always True, logs violations
            warn    — always True, prints a warning for blocked/suspicious
            block   — False when PromptGuard marks as blocked or suspicious
        """
        if self.mode == "disabled":
            return True, "guard_disabled"

        if self._guard is None:
            # Guard unavailable — passthrough with a note
            return True, "guard_unavailable"

        try:
            result = self._guard.analyze(text, source_id=user_id or None)
        except Exception as e:
            logger.error("PromptGuard.analyze failed: %s", e)
            return True, f"guard_error: {e}"

        if result.is_safe:
            return True, "safe"

        # Build a human-readable reason
        threat = "blocked" if result.is_blocked else "suspicious"
        reason = (
            f"{threat} (score={result.score:.2f}): {result.message}"
        )

        if self.mode == "monitor":
            logger.info("🔍 [guard/monitor] %s user=%s", reason, user_id)
            return True, reason

        if self.mode == "warn":
            print(f"   ⚠️  [guard/warn] {reason} user={user_id}")
            logger.warning("[guard/warn] %s user=%s", reason, user_id)
            return True, reason

        # block mode — actually deny
        if result.is_blocked or result.is_suspicious:
            logger.warning("[guard/block] DENIED %s user=%s", reason, user_id)
            return False, reason

        return True, "safe"

    async def check_output(self, text: str) -> tuple[bool, str]:
        """
        Check and filter an outbound response.

        Uses ContentFilter to detect and redact PII before it reaches users.

        Returns:
            (allowed: bool, filtered_text: str)
            filtered_text is the (possibly redacted) text to actually send.
        """
        if self.mode == "disabled":
            return True, text

        if self._filter is None:
            return True, text

        try:
            result = self._filter.filter_content(text, sanitize=True)
            if result.pii_found:
                logger.info(
                    "🔒 [guard/output] PII redacted — %d item(s) removed",
                    result.redaction_count,
                )
                if self.mode != "monitor":
                    print(
                        f"   🔒 [guard] Output filtered: "
                        f"{result.redaction_count} PII item(s) redacted"
                    )
            return True, result.filtered_text
        except Exception as e:
            logger.error("ContentFilter.filter_content failed: %s", e)
            return True, text  # passthrough on error

    # ------------------------------------------------------------------
    # Control methods
    # ------------------------------------------------------------------

    def set_mode(self, mode: str):
        """Switch guard mode at runtime and reinitialize internals."""
        if mode not in _VALID_MODES:
            raise ValueError(f"Invalid guard mode '{mode}'. Must be one of: {_VALID_MODES}")
        self.mode = mode
        self._init_guard()

    def status(self) -> dict:
        """Return current guard status and configuration."""
        return {
            "mode": self.mode,
            "active": self._guard is not None,
            "filter_active": self._filter is not None,
            "guard_available": _GUARD_AVAILABLE,
            "filter_available": _FILTER_AVAILABLE,
        }

    def scrub(self, text: str) -> str:
        """Scrub prompt-injection patterns from text before memory ingestion."""
        if self.mode == "disabled" or not text:
            return text

        guard = self._guard
        if guard is None:
            return text

        detector = getattr(guard, "injection_detector", None)
        if detector is None or not hasattr(detector, "scrub"):
            return text

        try:
            scrubbed, _modified = detector.scrub(text)
            return scrubbed
        except Exception as e:
            logger.warning("Prompt injection scrub failed: %s", e)
            return text


def register_audit_hook(security_mode: str, workspace_path: str) -> None:
    """Register the sys.addaudithook for the given security mode."""
    try:
        from antaris_agent.security.audit_hook import install as install_audit_hook
        install_audit_hook(security_mode, workspace_path)
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(
            "Could not register audit hook: %s", e
        )
