"""
antaris_agent/core/health.py

Simple asyncio HTTP health/readiness server (stdlib only — no aiohttp required).

Endpoints:
    GET /health  → JSON: {"status":"ok","uptime_seconds":N,"version":"X.Y.Z",
                          "memory_count":N,"channels":[...],"model":"..."}
    GET /ready   → 200 OK if bot is accepting messages, 503 if still starting up

Binds to 127.0.0.1 (localhost only) on a configurable port (default 8484).

Usage:
    server = HealthServer(bot, port=8484)
    await server.start()       # returns immediately, runs as background task
    ...
    await server.stop()        # clean shutdown
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from antaris_agent.core.bot import Bot

logger = logging.getLogger(__name__)

_STATUS_REASONS: dict[int, str] = {
    200: "OK",
    404: "Not Found",
    405: "Method Not Allowed",
    503: "Service Unavailable",
}


class HealthServer:
    """Minimal asyncio TCP server that speaks just enough HTTP/1.1."""

    def __init__(
        self,
        bot: "Bot",
        port: int = 8484,
        host: str = "127.0.0.1",
    ) -> None:
        self._bot = bot
        self._port = port
        self._host = host
        self._start_time: float = time.monotonic()
        self._server: Optional[asyncio.AbstractServer] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the server and log the listen address."""
        self._server = await asyncio.start_server(
            self._handle_connection,
            self._host,
            self._port,
        )
        logger.info(
            "Health server listening on http://%s:%d  (endpoints: /health /ready)",
            self._host,
            self._port,
        )

    async def stop(self) -> None:
        """Gracefully stop the server."""
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            logger.info("Health server stopped")
            self._server = None

    # ── Connection handler ────────────────────────────────────────────────

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Parse one HTTP request and write the response."""
        try:
            try:
                raw = await asyncio.wait_for(reader.read(4096), timeout=5.0)
            except asyncio.TimeoutError:
                return

            method, path = self._parse_request_line(raw)

            if method != "GET":
                self._write_response(writer, 405, b'{"error":"Method Not Allowed"}')
            elif path == "/health":
                payload = json.dumps(self._build_health_payload()).encode("utf-8")
                self._write_response(writer, 200, payload)
            elif path == "/ready":
                accepting = getattr(self._bot, "_accepting_messages", False)
                if accepting:
                    self._write_response(writer, 200, b'{"status":"ready"}')
                else:
                    self._write_response(writer, 503, b'{"status":"starting"}')
            else:
                self._write_response(writer, 404, b'{"error":"Not Found"}')

            await writer.drain()
        except Exception as exc:  # pragma: no cover
            logger.debug("Health server handler error: %s", exc)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _parse_request_line(raw: bytes) -> tuple[str, str]:
        """Extract HTTP method and path from raw bytes. Returns ("", "/") on failure."""
        try:
            first_line = raw.split(b"\r\n", 1)[0].decode("ascii", errors="replace")
            parts = first_line.split()
            method = parts[0] if parts else ""
            path = parts[1] if len(parts) > 1 else "/"
            # Strip query string
            path = path.split("?", 1)[0]
            return method, path
        except Exception:
            return "", "/"

    @staticmethod
    def _write_response(
        writer: asyncio.StreamWriter,
        status: int,
        body: bytes,
    ) -> None:
        reason = _STATUS_REASONS.get(status, "Unknown")
        header = (
            f"HTTP/1.1 {status} {reason}\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Connection: close\r\n"
            f"\r\n"
        ).encode("ascii")
        writer.write(header + body)

    def _build_health_payload(self) -> dict:
        """Gather live data from the bot instance."""
        from antaris_agent._version import __version__

        uptime_seconds = int(time.monotonic() - self._start_time)

        memory_count: int = 0
        try:
            if self._bot.memory is not None:
                memory_count = int(self._bot.memory.stats().get("total", 0))
        except Exception:
            pass

        channels: list[str] = []
        try:
            channels = [
                type(ch).__name__.replace("Adapter", "")
                for ch in getattr(self._bot, "_channels", [])
            ]
        except Exception:
            pass

        model: str = ""
        try:
            model = self._bot.config.model or ""
        except Exception:
            pass

        return {
            "status": "ok",
            "uptime_seconds": uptime_seconds,
            "version": __version__,
            "memory_count": memory_count,
            "channels": channels,
            "model": model,
        }
