"""
Continuity API - Commit 4
Auto-publishes continuity snapshots from memory ingest events.
Provides cross-session context preservation and pipeline injection.

A continuity snapshot captures:
  - Recent activity summary
  - Active working context (what the agent is doing)
  - Key facts/decisions from current session
  - Handoff notes for session transitions

Snapshots are persisted to disk and injected into the pipeline
context on each turn, giving the agent awareness of its own
recent state even after compaction or restart.
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


class ContinuitySnapshot:
    """A single point-in-time continuity snapshot."""

    def __init__(
        self,
        summary: str,
        active_tasks: List[str],
        key_decisions: List[str],
        session_id: str = "",
        timestamp: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.summary = summary
        self.active_tasks = active_tasks
        self.key_decisions = key_decisions
        self.session_id = session_id
        self.timestamp = timestamp or time.time()
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "summary": self.summary,
            "active_tasks": self.active_tasks,
            "key_decisions": self.key_decisions,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "iso_time": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(self.timestamp)),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ContinuitySnapshot":
        return cls(
            summary=d.get("summary", ""),
            active_tasks=d.get("active_tasks", []),
            key_decisions=d.get("key_decisions", []),
            session_id=d.get("session_id", ""),
            timestamp=d.get("timestamp", 0.0),
            metadata=d.get("metadata", {}),
        )

    def to_context_block(self) -> str:
        """Format snapshot as a context block for pipeline injection."""
        lines = []
        lines.append("[Continuity Context]")
        if self.summary:
            lines.append(f"Recent state: {self.summary}")
        if self.active_tasks:
            lines.append("Active tasks:")
            for task in self.active_tasks[:5]:
                lines.append(f"  - {task}")
        if self.key_decisions:
            lines.append("Key decisions this session:")
            for dec in self.key_decisions[:5]:
                lines.append(f"  - {dec}")
        age_min = (time.time() - self.timestamp) / 60
        if age_min < 60:
            lines.append(f"Snapshot age: {age_min:.0f} minutes ago")
        else:
            lines.append(f"Snapshot age: {age_min / 60:.1f} hours ago")
        return "\n".join(lines)


class ContinuityManager:
    """
    Manages continuity snapshots for cross-session context preservation.
    
    Snapshots are auto-published at key events:
      - After N messages (periodic refresh)
      - Before compaction (preserve context about to be lost)
      - On explicit save (user or system triggered)
    
    The latest snapshot is always available for pipeline injection.
    """

    MAX_SNAPSHOTS = 10  # Keep last N snapshots on disk
    AUTO_SNAPSHOT_INTERVAL = 15  # Messages between auto-snapshots

    def __init__(self, store_path: str, enabled: bool = True):
        self._store_path = Path(store_path)
        self._snapshot_dir = self._store_path / "continuity"
        self._snapshot_dir.mkdir(parents=True, exist_ok=True)
        self._latest_path = self._snapshot_dir / "latest.json"
        self._history_path = self._snapshot_dir / "history.jsonl"
        self._enabled = enabled
        self._latest: Optional[ContinuitySnapshot] = None
        self._message_count_at_last_snapshot = 0
        self._load_latest()

    def _load_latest(self):
        """Load the most recent snapshot from disk."""
        if self._latest_path.exists():
            try:
                with open(self._latest_path, "r") as f:
                    data = json.load(f)
                self._latest = ContinuitySnapshot.from_dict(data)
                logger.debug("Loaded continuity snapshot from %s", self._latest_path)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("Failed to load continuity snapshot: %s", e)
                self._latest = None

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def latest(self) -> Optional[ContinuitySnapshot]:
        return self._latest

    def get_context_block(self) -> str:
        """Get the latest snapshot formatted for pipeline injection.
        Returns empty string if no snapshot or disabled."""
        if not self._enabled or not self._latest:
            return ""
        # Don't inject stale snapshots (older than 6 hours)
        age_hours = (time.time() - self._latest.timestamp) / 3600
        if age_hours > 6:
            return ""
        return self._latest.to_context_block()

    def should_auto_snapshot(self, message_count: int) -> bool:
        """Check if it's time for an auto-snapshot based on message count."""
        if not self._enabled:
            return False
        return (message_count - self._message_count_at_last_snapshot) >= self.AUTO_SNAPSHOT_INTERVAL

    def publish(
        self,
        summary: str,
        active_tasks: Optional[List[str]] = None,
        key_decisions: Optional[List[str]] = None,
        session_id: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ContinuitySnapshot:
        """Publish a new continuity snapshot."""
        snapshot = ContinuitySnapshot(
            summary=summary,
            active_tasks=active_tasks or [],
            key_decisions=key_decisions or [],
            session_id=session_id,
            metadata=metadata,
        )
        self._latest = snapshot
        self._persist(snapshot)
        logger.info("Published continuity snapshot: %s", summary[:80])
        return snapshot

    def publish_from_buffer(
        self,
        conversation_buffer: List[tuple],
        session_id: str = "",
        message_count: int = 0,
    ) -> Optional[ContinuitySnapshot]:
        """Auto-publish a snapshot derived from the conversation buffer.
        
        Extracts a lightweight summary without LLM calls — just captures
        the recent conversation flow and any detected task/decision patterns.
        """
        if not self._enabled or not conversation_buffer:
            return None

        self._message_count_at_last_snapshot = message_count

        # Extract recent topics from the last 10 turns
        recent = conversation_buffer[-10:]
        topics = []
        decisions = []
        tasks = []

        for user_id, user_msg, bot_response in recent:
            # Simple heuristic: lines with action words are tasks
            msg_lower = user_msg.lower()
            if any(w in msg_lower for w in ["fix", "build", "create", "implement", "add", "wire", "deploy", "push", "commit"]):
                tasks.append(user_msg[:100])
            # Lines with decision words
            if any(w in msg_lower for w in ["let's", "we should", "go with", "decided", "approved", "confirmed"]):
                decisions.append(user_msg[:100])
            # Everything is a topic
            topics.append(user_msg[:60])

        summary_parts = []
        if topics:
            summary_parts.append(f"Recent conversation ({len(recent)} turns): {'; '.join(t[:40] for t in topics[-5:])}")
        
        summary = " | ".join(summary_parts) if summary_parts else "Active session"

        return self.publish(
            summary=summary,
            active_tasks=tasks[-5:],
            key_decisions=decisions[-5:],
            session_id=session_id,
            metadata={"auto": True, "message_count": message_count},
        )

    def _persist(self, snapshot: ContinuitySnapshot):
        """Write snapshot to disk."""
        data = snapshot.to_dict()
        
        # Write latest
        try:
            with open(self._latest_path, "w") as f:
                json.dump(data, f, indent=2)
        except OSError as e:
            logger.warning("Failed to write continuity snapshot: %s", e)

        # Append to history
        try:
            with open(self._history_path, "a") as f:
                f.write(json.dumps(data) + "\n")
        except OSError:
            pass

        # Rotate history
        self._rotate_history()

    def _rotate_history(self):
        """Keep only the last MAX_SNAPSHOTS in history."""
        if not self._history_path.exists():
            return
        try:
            with open(self._history_path, "r") as f:
                lines = f.readlines()
            if len(lines) > self.MAX_SNAPSHOTS:
                with open(self._history_path, "w") as f:
                    f.writelines(lines[-self.MAX_SNAPSHOTS:])
        except OSError:
            pass

    def stats(self) -> Dict[str, Any]:
        """Return continuity stats."""
        history_count = 0
        if self._history_path.exists():
            try:
                with open(self._history_path, "r") as f:
                    history_count = sum(1 for _ in f)
            except OSError:
                pass

        return {
            "enabled": self._enabled,
            "has_latest": self._latest is not None,
            "latest_age_min": round((time.time() - self._latest.timestamp) / 60, 1) if self._latest else None,
            "latest_session": self._latest.session_id if self._latest else None,
            "history_count": history_count,
        }
