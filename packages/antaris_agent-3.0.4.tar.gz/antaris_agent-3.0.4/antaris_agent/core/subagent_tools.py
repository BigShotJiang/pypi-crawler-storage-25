"""
Subagent tool permissions — defines scoped tool access per role.

Subagents are workers, not orchestrators. They receive a scoped set of
tools based on their assigned role. Only the parent agent can
spawn subagents and push to git.

Roles:
    reviewer — read-only access for code review (Scales / Crucible)
    builder  — read + write access for implementation, no push, no spawn

Usage:
    from antaris_agent.core.subagent_tools import get_tools_for_role, SubagentRole

    role = SubagentRole.REVIEWER
    tools = get_tools_for_role(role, bot.tool_registry)
"""
from __future__ import annotations

import logging
from enum import Enum
from typing import TYPE_CHECKING, Dict, List, Any

if TYPE_CHECKING:
    from antaris_agent.tools.tool_registry import ToolRegistry

logger = logging.getLogger(__name__)


class SubagentRole(str, Enum):
    """Roles determine which tools a subagent can access."""
    REVIEWER = "reviewer"
    BUILDER = "builder"


# Tools allowed per role.
# Format: tool_name -> list of allowed operations (empty list = all operations allowed)
REVIEWER_TOOLS: Dict[str, List[str]] = {
    "file_ops": ["read", "list"],
    "git": ["status", "diff", "log"],
    "shell": [],  # allowed but command blocklist still applies
    "web_search": [],
    "web_fetch": [],
    "memory_management": ["search", "recall"],
}

BUILDER_TOOLS: Dict[str, List[str]] = {
    "file_ops": ["read", "write", "edit", "list"],
    "git": ["status", "diff", "log", "add", "commit"],  # no push, no branch delete
    "shell": [],  # allowed but command blocklist still applies
    "web_search": [],
    "web_fetch": [],
    "memory_management": ["search", "recall"],
}

# Tools that subagents can NEVER access regardless of role
FORBIDDEN_TOOLS = {
    "spawn_subagent",       # only parent can orchestrate
    "discord_proactive",    # only parent communicates externally
    "discord_send_file",    # only parent communicates externally
    "notification",         # only parent notifies
}

ROLE_TOOL_MAP: Dict[SubagentRole, Dict[str, List[str]]] = {
    SubagentRole.REVIEWER: REVIEWER_TOOLS,
    SubagentRole.BUILDER: BUILDER_TOOLS,
}


def get_tools_for_role(
    role: SubagentRole,
    registry: "ToolRegistry",
) -> List[Dict[str, Any]]:
    """Build a filtered tool definition list for a subagent role.

    Returns tool definitions in Anthropic tool_use format, filtered to
    only include tools and operations allowed for the given role.

    Args:
        role: The subagent's assigned role
        registry: The parent bot's tool registry

    Returns:
        List of tool definition dicts suitable for passing to the LLM
    """
    allowed = ROLE_TOOL_MAP.get(role, {})
    if not allowed:
        logger.warning("No tool map for role '%s', subagent will be LLM-only", role)
        return []

    all_tools = registry.get_tool_definitions_sync()
    filtered = []

    for tool_def in all_tools:
        tool_name = tool_def["name"]

        # Never allow forbidden tools
        if tool_name in FORBIDDEN_TOOLS:
            continue

        # Only include tools in the role's allowlist
        if tool_name not in allowed:
            continue

        allowed_ops = allowed[tool_name]

        # If no operation restrictions, include the tool as-is
        if not allowed_ops:
            filtered.append(tool_def)
            continue

        # If the tool has an operation enum in its schema, modify the
        # schema to only expose allowed operations
        schema = tool_def.get("input_schema", {})
        props = schema.get("properties", {})
        op_prop = props.get("operation", {})

        if "enum" in op_prop:
            # Filter the enum to only allowed operations
            original_enum = op_prop["enum"]
            restricted_enum = [op for op in original_enum if op in allowed_ops]

            if not restricted_enum:
                # No allowed operations remain, skip this tool entirely
                logger.debug(
                    "Skipping tool '%s' for role '%s': no allowed operations",
                    tool_name, role,
                )
                continue

            # Deep copy the schema to avoid mutating the registry's version
            import copy
            modified_def = copy.deepcopy(tool_def)
            modified_def["input_schema"]["properties"]["operation"]["enum"] = restricted_enum

            # Update description to clarify restrictions
            op_list = ", ".join(restricted_enum)
            modified_def["description"] = (
                f"{tool_def['description']} "
                f"[Subagent: restricted to {op_list}]"
            )
            filtered.append(modified_def)
        else:
            # No operation enum to filter, include as-is
            filtered.append(tool_def)

    logger.info(
        "Subagent role '%s': %d tools available (from %d total)",
        role, len(filtered), len(all_tools),
    )
    return filtered


def get_role_constraints(role: SubagentRole) -> str:
    """Return the behavioral constraints block for a subagent role.

    Injected into the subagent's system prompt alongside SOUL.md.
    """
    if role == SubagentRole.REVIEWER:
        return (
            "\n\n---\n## Subagent constraints (role: reviewer)\n"
            "You are a code reviewer. You have READ-ONLY access.\n"
            "You MUST NOT:\n"
            "- Write, edit, or create any files\n"
            "- Commit, push, or modify any git state\n"
            "- Spawn additional subagents\n"
            "- Send messages to Discord or external services\n\n"
            "You MUST:\n"
            "- Read the code thoroughly using file_ops and git tools\n"
            "- Report findings clearly: bugs, style issues, logic errors, security concerns\n"
            "- Classify each finding as BLOCKER (must fix) or NIT (should fix)\n"
            "- Be specific: cite file names, line numbers, and exact problems\n"
            "- State APPROVED or BLOCKED as your final verdict\n"
        )

    if role == SubagentRole.BUILDER:
        return (
            "\n\n---\n## Subagent constraints (role: builder)\n"
            "You are a builder. You can read and write code.\n"
            "You MUST NOT:\n"
            "- Push to any remote (git push is not available to you)\n"
            "- Delete branches or force-push\n"
            "- Spawn additional subagents\n"
            "- Send messages to Discord or external services\n"
            "- Create new top-level directories or restructure project layout\n"
            "- Modify config files, boot files, or auth credentials\n\n"
            "You MUST:\n"
            "- Write code to the files specified in your task\n"
            "- Run tests after making changes when possible\n"
            "- Commit your work with clear, descriptive messages\n"
            "- Report what you built and any issues encountered\n"
            "- Stay within the scope of your assigned task\n"
        )

    return (
        "\n\n---\n## Subagent constraints\n"
        "You are a subagent. Report findings to the parent agent.\n"
        "Do not take destructive actions.\n"
    )
