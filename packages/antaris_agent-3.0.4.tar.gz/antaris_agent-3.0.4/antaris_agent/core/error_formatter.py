"""
Antaris Agent unified error formatting — user-facing friendly messages with full
traceback preservation in logs.

Classes:
    ToolExecutionError — wraps tool failures with a friendly message while
    preserving the original exception type via __cause__.

Usage:
    from antaris_agent.core.error_formatter import format_user_error, format_tool_error

    # In pipeline stages:
    except Exception as e:
        return PipelineResult(
            success=False,
            response_text=format_user_error(e, stage="llm_call"),
            error=str(e),
        )

    # In tool middleware:
    except Exception as e:
        return format_tool_error("search_web", e)
"""
from __future__ import annotations

import logging
import traceback
from typing import Optional


class ToolExecutionError(Exception):
    """Wrapper for tool failures that preserves the friendly message.

    Use instead of RuntimeError so upstream callers can still isinstance-check
    for ToolExecutionError without losing the original exception chain (via __cause__).
    """
    pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exception-type → friendly message map.
# Checked in order; first match wins.
# ---------------------------------------------------------------------------

_TYPE_MAP: list[tuple[tuple[type, ...], str]] = [
    (
        (TimeoutError,),
        "This is taking longer than expected. Please try again.",
    ),
    (
        (ConnectionError,),
        "Couldn't reach the external service. It may be temporarily down.",
    ),
    (
        (PermissionError,),
        "I don't have permission to do that.",
    ),
    (
        (FileNotFoundError,),
        "Couldn't find the requested file.",
    ),
    (
        (ImportError,),
        "A required package isn't installed for this feature.",
    ),
]

# String fragments checked against the lowercased exception message.
# Evaluated only when no type match was found.
_MSG_MAP: list[tuple[tuple[str, ...], str]] = [
    (
        ("timeout", "timed out", "read timeout", "connect timeout"),
        "This is taking longer than expected. Please try again.",
    ),
    (
        ("connection", "connect error", "network", "unreachable", "refused", "ssl"),
        "Couldn't reach the external service. It may be temporarily down.",
    ),
    (
        ("rate limit", "429", "too many requests"),
        "I'm being asked to do too much at once. Please try again in a moment.",
    ),
    (
        ("overloaded", "503", "502", "500"),
        "The service is temporarily unavailable. Please try again shortly.",
    ),
    (
        ("permission denied", "access denied", "forbidden", "401", "403"),
        "I don't have permission to do that.",
    ),
    (
        ("not found", "404", "no such file", "no such"),
        "Couldn't find the requested resource.",
    ),
    (
        ("json", "decode", "parse", "invalid response"),
        "Received an unexpected response format.",
    ),
    (
        ("import", "module", "no module named"),
        "A required package isn't installed for this feature.",
    ),
]

# Patterns that indicate the error string may contain sensitive internal info
# (file paths, keys, variable names). When found we suppress the raw message.
_SENSITIVE_PATTERNS: tuple[str, ...] = (
    "/home/",
    "/usr/",
    "/var/",
    "/tmp/antaris-agent",
    "sk-ant-",      # Anthropic API keys
    "sk-proj-",     # OpenAI API keys
    "token=",
    "key=",
    "password",
    "secret",
    "traceback (most recent",  # Python traceback header
    'file "/',      # file path in traceback
    ", line ",      # line reference in traceback (more precise than bare "line ")
)


def _is_sensitive(msg: str) -> bool:
    """Return True if the raw error message looks like it has internal details."""
    lowered = msg.lower()
    return any(p in lowered for p in _SENSITIVE_PATTERNS)


def _classify(error: Exception) -> str:
    """Return a friendly one-liner for *error*. Never raises."""
    try:
        # 1. Type-based lookup (most precise)
        for exc_types, friendly in _TYPE_MAP:
            if isinstance(error, exc_types):
                return friendly

        # 2. Late-import optional types (avoid hard dependency at module level)
        try:
            import json
            if isinstance(error, json.JSONDecodeError):
                return "Received an unexpected response format."
        except Exception:
            pass

        try:
            import httpx  # type: ignore[import]
            if isinstance(error, (httpx.ConnectError, httpx.TimeoutException)):
                return "Couldn't reach the external service. It may be temporarily down."
            if isinstance(error, httpx.HTTPStatusError):
                code = getattr(getattr(error, "response", None), "status_code", 0)
                if code == 429:
                    return "I'm being asked to do too much at once. Please try again in a moment."
                if code in (500, 502, 503):
                    return "The service is temporarily unavailable. Please try again shortly."
                if code in (401, 403):
                    return "I don't have permission to do that."
                if code == 404:
                    return "Couldn't find the requested resource."
        except Exception:
            pass

        # 3. Message-content heuristics
        raw = str(error).lower()
        for keywords, friendly in _MSG_MAP:
            if any(kw in raw for kw in keywords):
                return friendly

    except Exception:
        # Formatter must never raise
        pass

    # Fallback: include the error type so operators can at least diagnose
    error_type = type(error).__name__
    brief = str(error)[:120]
    if _is_sensitive(brief):
        return f"Something went wrong ({error_type}). The error has been logged."
    return f"Something went wrong ({error_type}: {brief}). Check logs for details."


def format_user_error(
    error: Exception,
    stage: str = "",
    *,
    log_level: int = logging.ERROR,
) -> str:
    """Return a friendly one-liner for the user.

    Always logs the full traceback at *log_level*. Never exposes file paths,
    API keys, or internal variable names to the caller.

    Args:
        error:     The exception that was caught.
        stage:     Optional pipeline stage name — included in the log context.
        log_level: Logging level for the internal traceback (default ERROR).

    Returns:
        A single-sentence string safe to send to users.
    """
    try:
        # Use format_exception on the actual error object to get the correct
        # traceback, not format_exc() which only works inside an active except block.
        tb = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        stage_tag = f" [stage={stage}]" if stage else ""
        logger.log(
            log_level,
            "Error%s: %s\n%s",
            stage_tag,
            repr(error),
            tb,
        )
    except Exception:
        pass

    friendly = _classify(error)
    # Extra safety: if the classified message somehow contains sensitive info, suppress it
    if _is_sensitive(friendly):
        return "Something went wrong. The error has been logged."
    return friendly


def format_tool_error(
    tool_name: str,
    error: Exception,
    *,
    log_level: int = logging.WARNING,
) -> str:
    """Return a friendly message for a tool failure.

    Format: ``"Tool <name> encountered an issue: <brief description>"``

    Always logs the full traceback internally.

    Args:
        tool_name: The tool that failed (e.g. ``"search_web"``).
        error:     The exception that was caught.
        log_level: Logging level for the internal traceback (default WARNING).

    Returns:
        A single-sentence string safe to send to users.
    """
    try:
        tb = traceback.format_exc()
        logger.log(
            log_level,
            "Tool %r failed: %s\n%s",
            tool_name,
            repr(error),
            tb,
        )
    except Exception:
        pass

    brief = _classify(error)
    # Strip the trailing period so "Tool X encountered an issue: ..." reads naturally
    brief_clean = brief.rstrip(".")
    result = f"Tool {tool_name} encountered an issue: {brief_clean}."
    if _is_sensitive(result):
        return f"Tool {tool_name} encountered an issue. The error has been logged."
    return result
