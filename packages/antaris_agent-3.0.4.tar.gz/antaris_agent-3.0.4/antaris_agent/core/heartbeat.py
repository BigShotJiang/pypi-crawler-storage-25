"""
Antaris Agent Heartbeat Manager — periodic health checks and proactive notifications.

The HeartbeatManager runs periodic checks on email, calendar, memory health,
and session state. It can notify the user via Discord if anything urgent is found.
"""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, TYPE_CHECKING, Dict, List, Any

if TYPE_CHECKING:
    from antaris_agent.core.bot import Bot
    from antaris_agent.core.cron import CronScheduler
    from antaris_agent.core.memory import BotMemory

logger = logging.getLogger(__name__)


class HeartbeatManager:
    """
    Manages periodic heartbeat checks for the bot.
    
    Features:
    - Email check (placeholder)
    - Calendar check (placeholder)
    - Memory health monitoring
    - Session state persistence
    - Discord notifications for urgent items
    """

    def __init__(self, bot: "Bot"):
        """
        Initialize heartbeat manager.
        
        Args:
            bot: The main Bot instance to access config, memory, etc.
            
        Note:
            Safely handles missing attributes (memory, cron, daily_log, _channels)
            by checking for their existence before use.
        """
        self.bot = bot
        self.config = bot.config
        self.memory: Optional["BotMemory"] = getattr(bot, "memory", None)
        self.cron: Optional["CronScheduler"] = getattr(bot, "cron", None)
        self._job_id: Optional[str] = None
        self._enabled = getattr(self.config, "heartbeat_enabled", False)
        self._interval_minutes = getattr(self.config, "heartbeat_interval_minutes", 30)

    def is_enabled(self) -> bool:
        """Check if heartbeat is enabled."""
        return self._enabled

    # Stable heartbeat job ID — prevents duplicate jobs on restart
    HEARTBEAT_JOB_ID = "heartbeat_default"

    def start(self) -> None:
        """Start the heartbeat system by scheduling a recurring cron job."""
        if not self._enabled:
            logger.info("Heartbeat system disabled in config")
            return

        if not self.cron:
            logger.warning("Heartbeat system requires CronScheduler but it's not available")
            return

        if not hasattr(self.cron, "add_job") or not callable(self.cron.add_job):
            logger.error("CronScheduler missing add_job method")
            return

        # Check if a heartbeat job already exists — skip if so (prevents duplicates)
        existing = self.cron.get_job(self.HEARTBEAT_JOB_ID)
        if existing:
            self._job_id = self.HEARTBEAT_JOB_ID
            logger.info(
                "Heartbeat job already exists (job_id=%s), skipping creation",
                self._job_id,
            )
            return

        # Also clean up any stale heartbeat jobs from old random-UUID scheme
        stale = [j for j in self.cron.list_jobs()
                 if j.name == "Heartbeat Check" and j.id != self.HEARTBEAT_JOB_ID]
        for j in stale:
            self.cron.remove_job(j.id)
            logger.info("Removed stale heartbeat job %s", j.id)

        # Create a recurring cron job with a stable ID
        from antaris_agent.core.cron import CronJob

        self._job_id = self.HEARTBEAT_JOB_ID
        interval_ms = self._interval_minutes * 60 * 1000  # convert to milliseconds

        if interval_ms <= 0:
            logger.error("Invalid heartbeat interval: %d minutes", self._interval_minutes)
            return

        heartbeat_job = CronJob(
            id=self._job_id,
            name="Heartbeat Check",
            schedule_kind="every",
            schedule_every_ms=interval_ms,
            payload_kind="systemEvent",
            payload_text="heartbeat_tick",
            enabled=True
        )

        try:
            self.cron.add_job(heartbeat_job)
            logger.info(
                "Heartbeat system started: %d minute intervals (job_id=%s)",
                self._interval_minutes, self._job_id
            )
        except Exception as e:
            logger.error("Failed to add heartbeat cron job: %s", e)
            self._job_id = None

    def stop(self) -> None:
        """Stop the heartbeat system by removing the cron job."""
        if self._job_id and self.cron:
            if hasattr(self.cron, "remove_job"):
                try:
                    if self.cron.remove_job(self._job_id):
                        logger.info("Heartbeat system stopped (job_id=%s)", self._job_id)
                    else:
                        logger.warning("Failed to remove heartbeat job %s (may not exist)", self._job_id)
                except Exception as e:
                    logger.error("Error removing heartbeat job %s: %s", self._job_id, e)
            else:
                logger.warning("CronScheduler missing remove_job method, cannot remove heartbeat job")
            self._job_id = None

    async def tick(self) -> Dict[str, Any]:
        """
        Execute a heartbeat check cycle.
        
        Returns:
            dict: Summary of check results
        """
        if not self._enabled:
            return {"error": "heartbeat_disabled"}

        start_time = time.time()
        results = {
            "timestamp": datetime.now().isoformat(),
            "checks": {},
            "urgent_items": [],
            "session_state": {}
        }

        logger.info("Heartbeat tick starting...")

        # Check email (placeholder)
        try:
            results["checks"]["email"] = await self._check_email()
        except Exception as e:
            logger.warning("Email check failed: %s", e)
            results["checks"]["email"] = {"error": str(e)}

        # Check calendar (placeholder)
        try:
            results["checks"]["calendar"] = await self._check_calendar()
        except Exception as e:
            logger.warning("Calendar check failed: %s", e)
            results["checks"]["calendar"] = {"error": str(e)}

        # Check memory health
        try:
            results["checks"]["memory"] = self._check_memory_health()
        except Exception as e:
            logger.warning("Memory health check failed: %s", e)
            results["checks"]["memory"] = {"error": str(e)}

        # Save session state
        try:
            results["session_state"] = await self._save_session_state()
        except Exception as e:
            logger.warning("Session state save failed: %s", e)
            results["session_state"] = {"error": str(e)}

        # Collect urgent items
        for check_name, check_result in results["checks"].items():
            if isinstance(check_result, dict) and check_result.get("urgent"):
                results["urgent_items"].append({
                    "source": check_name,
                    "message": check_result.get("message", "Unknown urgent item")
                })

        # Send notifications for urgent items
        if results["urgent_items"]:
            try:
                await self._notify_urgent_items(results["urgent_items"])
            except Exception as e:
                logger.warning("Urgent notification failed: %s", e)

        elapsed = time.time() - start_time
        results["duration_seconds"] = elapsed
        
        logger.info(
            "Heartbeat tick completed in %.2fs: %d checks, %d urgent items",
            elapsed, len(results["checks"]), len(results["urgent_items"])
        )

        return results

    async def _check_email(self) -> Dict[str, Any]:
        """
        Check email for new messages.
        
        Currently a placeholder - just logs that it would check email.
        """
        logger.debug("Heartbeat: would check email")
        return {
            "status": "placeholder",
            "message": "Email check not implemented yet",
            "urgent": False
        }

    async def _check_calendar(self) -> Dict[str, Any]:
        """
        Check calendar for upcoming events.
        
        Currently a placeholder - just logs that it would check calendar.
        """
        logger.debug("Heartbeat: would check calendar")
        return {
            "status": "placeholder", 
            "message": "Calendar check not implemented yet",
            "urgent": False
        }

    def _check_memory_health(self) -> Dict[str, Any]:
        """
        Check memory system health using memory.stats().
        """
        if not self.memory:
            return {
                "status": "error",
                "message": "Memory system not available",
                "urgent": False
            }

        try:
            stats = self.memory.stats()
            total_memories = stats.get("total", 0)
            
            # Check for potential issues
            urgent = False
            warnings = []
            
            if total_memories == 0:
                warnings.append("No memories stored")
            elif total_memories > 50000:
                warnings.append(f"High memory count: {total_memories}")
                urgent = True

            return {
                "status": "ok",
                "stats": stats,
                "total_memories": total_memories,
                "warnings": warnings,
                "urgent": urgent,
                "message": f"Memory system healthy: {total_memories} memories"
            }

        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to get memory stats: {e}",
                "urgent": True
            }

    async def _save_session_state(self) -> Dict[str, Any]:
        """Write daily log entry to memory/YYYY-MM-DD.md via Parsica memory system.

        Previously hollowed out to a stub in v1.0.x. Restored in v2.6.1 —
        Parsica handles syncing but cannot create the files if nothing writes them.
        """
        try:
            from datetime import date
            import os

            if not self.memory:
                return {"status": "skip", "reason": "no memory system"}

            # Get today's date for the log file
            today = date.today().isoformat()

            # Find the memory workspace path
            store_path = getattr(self.memory, "store_path", None)
            if not store_path:
                return {"status": "skip", "reason": "no store_path"}

            # Write to memory/YYYY-MM-DD.md
            log_dir = os.path.join(store_path, "memory")
            os.makedirs(log_dir, exist_ok=True)
            log_path = os.path.join(log_dir, f"{today}.md")

            # Build a brief session state entry
            entry_lines = []
            if not os.path.exists(log_path):
                entry_lines.append(f"# Daily Log — {today}\n")

            # Append a heartbeat checkpoint
            from datetime import datetime
            now_str = datetime.now().strftime("%H:%M")
            memory_count = 0
            try:
                if hasattr(self.memory, "_stores"):
                    for store in self.memory._stores.values():
                        memory_count += len(getattr(store, "memories", []))
            except Exception:
                pass

            entry_lines.append(f"\n## Heartbeat {now_str}\n")
            entry_lines.append(f"- Memory: {memory_count} records\n")
            entry_lines.append(f"- Status: running\n")

            with open(log_path, "a", encoding="utf-8") as f:
                f.writelines(entry_lines)

            return {"status": "ok", "path": log_path}
        except Exception as e:
            logger.warning("_save_session_state failed: %s", e)
            return {"status": "error", "error": str(e)}

    async def _notify_urgent_items(self, urgent_items: List[Dict[str, str]]) -> None:
        """
        Send Discord notification to the owner about urgent items.
        
        Args:
            urgent_items: List of urgent items with 'source' and 'message' keys
            
        Raises:
            Logs errors but does not raise exceptions to avoid breaking the heartbeat cycle.
            Handles invalid owner_user_id gracefully by validating it's numeric.
        """
        owner_id = getattr(self.config, "owner_user_id", "")
        if not owner_id:
            logger.debug("No owner_user_id configured, skipping urgent notifications")
            return

        if not urgent_items:
            return

        # Validate owner_id is numeric
        try:
            owner_id_int = int(owner_id)
        except (ValueError, TypeError) as e:
            logger.error("Invalid owner_user_id '%s': must be numeric Discord user ID", owner_id)
            return

        # Build notification message
        lines = ["🚨 **Heartbeat Alert**"]
        for item in urgent_items:
            lines.append(f"• **{item['source']}**: {item['message']}")

        message_text = "\n".join(lines)

        # Try to send via Discord adapter if available
        try:
            channels = getattr(self.bot, "_channels", [])
            discord_adapter = None
            
            for adapter in channels:
                if hasattr(adapter, "_client") and adapter.__class__.__name__ == "DiscordAdapter":
                    discord_adapter = adapter
                    break

            if discord_adapter and hasattr(discord_adapter, "_client") and discord_adapter._client:
                user = await discord_adapter._client.fetch_user(owner_id_int)
                if user:
                    await user.send(message_text)
                    logger.info("Sent heartbeat urgent notification to owner %s", owner_id)
                else:
                    logger.warning("Could not find Discord user with ID %s", owner_id)
            else:
                logger.warning("Discord adapter not available for urgent notifications")

        except Exception as e:
            logger.error("Failed to send urgent notification: %s", e)