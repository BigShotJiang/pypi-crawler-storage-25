"""Per-agent daemon lock and token collision prevention.

Provides:
- Token-hash lock files that prevent same-token double-launch (local or cross-host)
- PID file discipline per config-dir
- Fleet status scanning

Lock layout (H7 — per-agent isolation):
  <config_dir>/.locks/token-<hash>.lock   — full lock data (per-agent, mode 0700)
  ~/.antaris/.locks/registry-<hash>.lock  — global token-hash registry (hash + hostname
                                            + timestamp ONLY — no config_dir or secrets)

This separation means a compromised agent can only see its own lock directory.
The global registry is used solely for cross-agent collision detection and contains
no sensitive metadata.

Lock acquisition uses O_CREAT|O_EXCL for atomic creation, and atomic rename
(os.replace) for updates. Cross-host detection uses timestamp staleness since
remote PID checks are impossible.
"""
from __future__ import annotations

import errno
import hashlib
import json
import os
import socket
import time
from pathlib import Path


# Global registry dir — token hashes only, no config paths
GLOBAL_REGISTRY_DIR = Path.home() / ".antaris" / ".locks"
STALENESS_SECONDS = 300  # 5 minutes — cross-host lock considered stale after this


def _token_hash(token: str) -> str:
    """SHA-256 hash of Discord token — never store the token itself."""
    return hashlib.sha256(token.encode()).hexdigest()[:16]


def _ensure_lock_dir(lock_dir: Path) -> None:
    """Create lock directory with restricted permissions (0o700)."""
    lock_dir.mkdir(parents=True, exist_ok=True)
    try:
        lock_dir.chmod(0o700)
    except OSError:
        pass


def _agent_lock_dir(config_dir: str | Path) -> Path:
    """Return the per-agent lock directory inside config_dir."""
    return Path(config_dir).resolve() / ".locks"


def _agent_lock_path(config_dir: str | Path, token_hash: str) -> Path:
    return _agent_lock_dir(config_dir) / f"token-{token_hash}.lock"


def _registry_lock_path(token_hash: str) -> Path:
    return GLOBAL_REGISTRY_DIR / f"registry-{token_hash}.lock"


def _read_lock(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else None
    except Exception:
        # Corrupt lock file — treat as stale, clean up
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return None


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pid_is_antaris(pid: int) -> bool:
    """Check if PID belongs to an antaris process (not a recycled PID)."""
    import subprocess

    if not _pid_alive(pid):
        return False
    try:
        # Linux: read /proc/PID/cmdline
        cmdline_path = Path(f"/proc/{pid}/cmdline")
        if cmdline_path.exists():
            cmdline = cmdline_path.read_bytes().decode(errors="replace").replace("\x00", " ")
            return "antaris" in cmdline.lower()
        # macOS/other: use ps
        result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode == 0:
            return "antaris" in result.stdout.lower()
    except Exception:
        pass
    # Fallback: PID is alive but we can't verify identity — assume it's ours (safe side)
    return True


def _write_lock_atomic(lock_file: Path, lock_data: dict) -> None:
    """Write lock file atomically via temp file + os.replace."""
    tmp = lock_file.with_suffix(".tmp")
    tmp.write_text(json.dumps(lock_data, indent=2))
    os.replace(str(tmp), str(lock_file))


def _write_registry_entry(token_hash: str, my_pid: int, my_host: str) -> None:
    """Write a minimal entry to the global registry (no sensitive metadata)."""
    _ensure_lock_dir(GLOBAL_REGISTRY_DIR)
    reg_file = _registry_lock_path(token_hash)
    reg_data = {
        "token_hash": token_hash,
        "pid": my_pid,
        "hostname": my_host,
        "timestamp": time.time(),
    }
    _write_lock_atomic(reg_file, reg_data)


def _remove_registry_entry(token_hash: str) -> None:
    """Remove the global registry entry for this token hash."""
    reg_file = _registry_lock_path(token_hash)
    reg_file.unlink(missing_ok=True)


def acquire_token_lock(
    token: str,
    config_dir: str | Path,
    agent_name: str = "default",
) -> tuple[bool, str]:
    """Attempt to acquire a token lock.

    Returns (success, message).
    If another live process holds this token, returns (False, explanation).
    If lock is stale (dead PID or corrupt), reclaims it.

    Lock files are stored in <config_dir>/.locks/ (per-agent isolation, H7).
    A minimal entry is also written to the global registry at ~/.antaris/.locks/
    for fleet-wide collision detection, containing only the token hash and
    hostname (no config_dir or other sensitive metadata).

    Uses O_CREAT|O_EXCL for race-free initial creation. For reclaim after
    staleness check, uses atomic rename.
    """
    agent_lock_dir = _agent_lock_dir(config_dir)
    _ensure_lock_dir(agent_lock_dir)

    # N1: Clean up any stale .tmp files left by prior interrupted atomic writes.
    # These are created by _write_lock_atomic() and can persist forever if the
    # process dies between the write and os.replace().
    for _tmp_path in agent_lock_dir.glob("*.tmp"):
        try:
            _tmp_path.unlink(missing_ok=True)
        except OSError:
            pass

    th = _token_hash(token)
    lock_file = _agent_lock_path(config_dir, th)
    my_pid = os.getpid()
    my_host = socket.gethostname()
    config_str = str(Path(config_dir).resolve())

    lock_data = {
        "pid": my_pid,
        "agent": agent_name,
        "config_dir": config_str,
        "hostname": my_host,
        "timestamp": time.time(),
    }

    # Fast path: try atomic exclusive creation first
    try:
        fd = os.open(str(lock_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            os.write(fd, json.dumps(lock_data, indent=2).encode())
        finally:
            os.close(fd)
        _write_registry_entry(th, my_pid, my_host)
        return True, f"Token lock acquired for agent '{agent_name}'"
    except OSError as e:
        if e.errno != errno.EEXIST:
            return False, f"Failed to create lock file: {e}"
        # Lock file exists — fall through to check if it's stale

    # Lock exists — read and evaluate
    existing = _read_lock(lock_file)
    if not existing:
        # Was corrupt, _read_lock cleaned it up. Retry once.
        try:
            fd = os.open(str(lock_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            try:
                os.write(fd, json.dumps(lock_data, indent=2).encode())
            finally:
                os.close(fd)
            _write_registry_entry(th, my_pid, my_host)
            return True, f"Token lock acquired for agent '{agent_name}' (reclaimed corrupt lock)"
        except OSError:
            return False, "Lock file in contested state — try again in a moment."

    other_pid = existing.get("pid", 0)
    other_agent = existing.get("agent", "unknown")
    other_config = existing.get("config_dir", "unknown")
    other_host = existing.get("hostname", "unknown")
    lock_age = time.time() - existing.get("timestamp", 0)

    # Same PID as us — we already hold it (e.g. restart within same process)
    if other_pid == my_pid and other_host == my_host:
        _write_lock_atomic(lock_file, lock_data)
        _write_registry_entry(th, my_pid, my_host)
        return True, f"Token lock refreshed for agent '{agent_name}'"

    # Same host — we can reliably check PID
    if other_host == my_host:
        if _pid_is_antaris(other_pid):
            return False, (
                f"Token collision: agent '{other_agent}' is already running "
                f"with this Discord token (PID {other_pid}, config: {other_config}). "
                f"Stop it first."
            )
        # PID is dead or recycled to non-antaris — reclaim
        lock_file.unlink(missing_ok=True)
        _write_lock_atomic(lock_file, lock_data)
        _write_registry_entry(th, my_pid, my_host)
        return True, f"Token lock acquired for agent '{agent_name}' (reclaimed stale local lock)"

    # Different host — cannot check PID, use timestamp staleness
    if lock_age < STALENESS_SECONDS:
        return False, (
            f"Token collision: agent '{other_agent}' appears to be running "
            f"on host '{other_host}' with this Discord token "
            f"(lock age: {int(lock_age)}s, config: {other_config}). "
            f"If that instance is dead, delete {lock_file} manually "
            f"or wait {int(STALENESS_SECONDS - lock_age)}s for staleness."
        )

    # Cross-host lock is stale — reclaim
    lock_file.unlink(missing_ok=True)
    _write_lock_atomic(lock_file, lock_data)
    _write_registry_entry(th, my_pid, my_host)
    return True, f"Token lock acquired for agent '{agent_name}' (reclaimed stale cross-host lock)"


def release_token_lock(token: str, config_dir: str | Path | None = None) -> None:
    """Release the token lock (call on shutdown).

    config_dir is required for per-agent lock removal. If omitted, only
    the global registry entry is cleaned up (backward-compat shim).
    """
    th = _token_hash(token)
    my_pid = os.getpid()

    if config_dir is not None:
        lock_file = _agent_lock_path(config_dir, th)
        existing = _read_lock(lock_file)
        if existing and existing.get("pid") == my_pid:
            lock_file.unlink(missing_ok=True)

    # Always clean up the global registry entry if we own it
    reg_file = _registry_lock_path(th)
    reg_data = _read_lock(reg_file)
    if reg_data and reg_data.get("pid") == my_pid:
        reg_file.unlink(missing_ok=True)


def refresh_token_lock(token: str, config_dir: str | Path | None = None) -> None:
    """Update the timestamp on an existing lock (heartbeat keepalive).

    config_dir is required for per-agent lock refresh. If omitted, only
    the global registry entry is refreshed (backward-compat shim).
    """
    th = _token_hash(token)
    my_pid = os.getpid()
    my_host = socket.gethostname()

    if config_dir is not None:
        lock_file = _agent_lock_path(config_dir, th)
        existing = _read_lock(lock_file)
        if existing and existing.get("pid") == my_pid:
            existing["timestamp"] = time.time()
            _write_lock_atomic(lock_file, existing)

    # Refresh registry entry
    reg_file = _registry_lock_path(th)
    reg_data = _read_lock(reg_file)
    if reg_data and reg_data.get("pid") == my_pid:
        reg_data["timestamp"] = time.time()
        _write_lock_atomic(reg_file, reg_data)
    else:
        # Registry entry missing — recreate it
        _write_registry_entry(th, my_pid, my_host)


def write_pid_file(config_dir: str | Path) -> None:
    """Write PID file into config dir."""
    pid_file = Path(config_dir) / "bot.pid"
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(os.getpid()))


def clear_pid_file(config_dir: str | Path) -> None:
    """Remove PID file from config dir."""
    pid_file = Path(config_dir) / "bot.pid"
    pid_file.unlink(missing_ok=True)


def read_pid_file(config_dir: str | Path) -> int | None:
    """Read PID from config dir's bot.pid."""
    pid_file = Path(config_dir) / "bot.pid"
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text().strip())
    except (ValueError, OSError):
        return None


def fleet_status(config_dirs: list[str | Path] | None = None) -> list[dict]:
    """Scan all token locks and return fleet status.

    Scans the global registry (token hashes only) to enumerate running agents,
    then cross-references per-agent lock dirs from the provided config_dirs for
    enriched metadata (agent name, config path).

    If config_dirs is None or empty, falls back to registry-only data (hostname,
    pid, alive status) without per-agent details — this is the safe default since
    enumerating all config dirs is not generally possible.

    Note: For cross-host locks, 'alive' is based on timestamp freshness,
    not PID checks (which are local-only). This shows local locks accurately
    and remote locks as best-effort.
    """
    my_host = socket.gethostname()
    results = []

    if not GLOBAL_REGISTRY_DIR.exists():
        return results

    # Build a lookup of per-agent lock data from provided config_dirs
    agent_lock_data: dict[str, dict] = {}  # token_hash -> full lock data
    if config_dirs:
        for cfg_dir in config_dirs:
            agent_dir = _agent_lock_dir(cfg_dir)
            if not agent_dir.exists():
                continue
            for lock_file in agent_dir.glob("token-*.lock"):
                # Extract token_hash from filename: token-<hash>.lock
                stem = lock_file.stem  # "token-<hash>"
                if stem.startswith("token-"):
                    th = stem[len("token-"):]
                    data = _read_lock(lock_file)
                    if data:
                        agent_lock_data[th] = data

    for reg_file in GLOBAL_REGISTRY_DIR.glob("registry-*.lock"):
        reg_data = _read_lock(reg_file)
        if not reg_data:
            continue

        token_hash = reg_data.get("token_hash", "")
        pid = reg_data.get("pid", 0)
        host = reg_data.get("hostname", "unknown")
        age = time.time() - reg_data.get("timestamp", 0)

        if host == my_host:
            alive = _pid_is_antaris(pid)
        else:
            # Cross-host: can't check PID, use timestamp freshness
            alive = age < STALENESS_SECONDS

        # Enrich with per-agent data if available
        agent_data = agent_lock_data.get(token_hash, {})

        results.append({
            "agent": agent_data.get("agent", "unknown"),
            "config_dir": agent_data.get("config_dir", "unknown"),
            "hostname": host,
            "pid": pid,
            "alive": alive,
            "lock_age_seconds": int(age),
            "lock_file": str(reg_file),
            "token_hash": token_hash,
        })

    return results
