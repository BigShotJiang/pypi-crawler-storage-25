"""
Bridge Logging Setup — Drop-in for pipeline_bridge.py

Adds structured rotating file logging to the bridge process.
Call setup_bridge_logging() at the top of run_persistent_mode()
BEFORE the stdin redirect.

Writes to: ~/.openclaw/logs/bridge.log
  - Rotating: 5MB max, 3 backups
  - Format matches the agent's logger: "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
  - DEBUG and above to file
  - WARNING and above to stderr (doesn't contaminate NDJSON stdout)

Usage in pipeline_bridge.py:

    def run_persistent_mode():
        from bridge_logging import setup_bridge_logging
        setup_bridge_logging()

        # ... rest of persistent mode ...
"""

import logging
import logging.handlers
import os
import sys
from pathlib import Path

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_INITIALIZED = False


def setup_bridge_logging(
    log_dir: str = None,
    log_name: str = "bridge.log",
    max_bytes: int = 5 * 1024 * 1024,
    backup_count: int = 3,
    console_level: str = "WARNING",
    file_level: str = "DEBUG",
) -> None:
    """Configure root logger for the bridge process.

    Safe to call multiple times — skips if already initialized.

    Args:
        log_dir: Directory for the log file. Defaults to ~/.openclaw/logs/
        log_name: Log filename. Defaults to "bridge.log"
        max_bytes: Max size per log file before rotation. Default 5MB.
        backup_count: Number of rotated backups to keep.
        console_level: Minimum level for stderr output.
        file_level: Minimum level for file output.
    """
    global _INITIALIZED
    if _INITIALIZED:
        return
    _INITIALIZED = True

    if log_dir is None:
        log_dir = os.path.join(os.path.expanduser("~"), ".openclaw", "logs")

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    log_file = log_path / log_name

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    fmt = logging.Formatter(_LOG_FORMAT)

    # ── Stderr handler: WARNING+ (avoids contaminating NDJSON on stdout) ──
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(getattr(logging, console_level.upper(), logging.WARNING))
    stderr_handler.setFormatter(fmt)

    # ── Rotating file handler: DEBUG+ ─────────────────────────────────────
    file_handler = logging.handlers.RotatingFileHandler(
        str(log_file),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setLevel(getattr(logging, file_level.upper(), logging.DEBUG))
    file_handler.setFormatter(fmt)

    # Replace any existing handlers (avoid duplicates on repeated calls)
    for h in root.handlers[:]:
        try:
            h.close()
        except Exception:
            pass
    root.handlers.clear()

    root.addHandler(stderr_handler)
    root.addHandler(file_handler)

    logging.getLogger("antaris").info(
        "Bridge logging initialized: file=%s (max=%dMB x%d)",
        log_file, max_bytes // (1024 * 1024), backup_count,
    )
