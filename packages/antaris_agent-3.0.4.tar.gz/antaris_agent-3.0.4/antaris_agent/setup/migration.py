"""Config discovery and migration helpers for the setup wizard."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

CONFIG_CANDIDATES = (
    Path(".antaris") / "config.json",
    Path(".antarisbot") / "config.json",
    Path(".openclaw") / "openclaw.json",
    Path(".openclaw") / "config.json",
)


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"Expected object in {path}")
    return data


def _as_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _extract_channels(data: dict[str, Any]) -> list[str]:
    channels: list[str] = []

    for key in ("selected_channels", "channels"):
        value = data.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str) and item and item not in channels:
                    channels.append(item)

    nested_channels = data.get("channels")
    if isinstance(nested_channels, dict):
        for name in ("discord", "telegram", "slack"):
            channel_cfg = nested_channels.get(name)
            if isinstance(channel_cfg, dict) and channel_cfg.get("enabled") and name not in channels:
                channels.append(name)

    channel = data.get("channel")
    if isinstance(channel, str):
        if channel == "both":
            for item in ("telegram", "discord"):
                if item not in channels:
                    channels.append(item)
        elif channel and channel != "terminal" and channel not in channels:
            channels.append(channel)

    flags = {
        "discord": bool(data.get("discord_enabled") or data.get("discord_token")),
        "telegram": bool(data.get("telegram_enabled") or data.get("telegram_token")),
        "slack": bool(data.get("slack_enabled") or data.get("slack_bot_token")),
    }
    for name, enabled in flags.items():
        if enabled and name not in channels:
            channels.append(name)

    return channels


def _extract_provider(data: dict[str, Any]) -> str:
    providers = data.get("providers")
    if isinstance(providers, list) and providers:
        first = providers[0]
        if isinstance(first, dict):
            provider = first.get("provider") or first.get("name")
            if isinstance(provider, str) and provider:
                return provider

    provider = data.get("provider")
    if isinstance(provider, dict):
        provider_name = provider.get("name")
        if isinstance(provider_name, str) and provider_name:
            return provider_name
    elif isinstance(provider, str) and provider:
        return provider

    provider_name = data.get("provider_name")
    if isinstance(provider_name, str) and provider_name:
        return provider_name
    return "unknown"


def _extract_bot_name(data: dict[str, Any], path: Path) -> str:
    bot = data.get("bot")
    if isinstance(bot, dict):
        value = bot.get("name")
        if isinstance(value, str) and value.strip():
            return value.strip()
    for key in ("bot_name", "name"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return path.parent.name or path.stem


def _extract_tools(data: dict[str, Any]) -> list[str]:
    tools = data.get("tools") or data.get("_tools_config")
    if isinstance(tools, dict):
        names: list[str] = []
        for name, payload in tools.items():
            if isinstance(name, str) and name:
                if isinstance(payload, dict):
                    if payload.get("enabled", True):
                        names.append(name)
                else:
                    names.append(name)
        return sorted(set(names))
    if isinstance(tools, list):
        return sorted({str(item) for item in tools if str(item)})
    return []


def _extract_skills(data: dict[str, Any]) -> list[str]:
    for key in ("skills", "enabled_skills", "skill_names"):
        value = data.get(key)
        if isinstance(value, list):
            return sorted({str(item) for item in value if str(item)})
    return []


def discover_configs() -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    home = Path.home()

    for relative_path in CONFIG_CANDIDATES:
        config_path = home / relative_path
        if not config_path.is_file():
            continue
        try:
            data = _read_json(config_path)
        except Exception:
            continue

        tools = _extract_tools(data)
        skills = _extract_skills(data)
        channels = _extract_channels(data)
        provider = _extract_provider(data)
        bot_name = _extract_bot_name(data, config_path)
        source_type = config_path.parent.name

        results.append(
            {
                "path": str(config_path),
                "name": bot_name,
                "bot_name": bot_name,
                "provider": provider,
                "channels": channels,
                "has_tools": bool(tools),
                "has_skills": bool(skills),
                "source_type": source_type,
            }
        )

    return results


def load_migration(config_path: str | Path) -> dict[str, Any]:
    path = Path(config_path).expanduser()
    data = _read_json(path)
    tools = _extract_tools(data)
    skills = _extract_skills(data)

    payload: dict[str, Any] = {
        "path": str(path),
        "bot_name": _extract_bot_name(data, path),
        "provider": _extract_provider(data),
        "channels": _extract_channels(data),
        "tools": tools,
        "skills": skills,
        "has_tools": bool(tools),
        "has_skills": bool(skills),
    }

    for key in (
        "api_key",
        "security_mode",
        "owner_user_id",
        "memory_store",
        "channel",
        "telegram_token",
        "discord_token",
        "slack_bot_token",
        "slack_app_token",
        "google_workspace_enabled",
        "google_workspace_account",
        "google_workspace_services",
    ):
        if key in data:
            payload[key] = data[key]

    bot = data.get("bot") if isinstance(data.get("bot"), dict) else {}
    provider = data.get("provider") if isinstance(data.get("provider"), dict) else {}
    channels = data.get("channels") if isinstance(data.get("channels"), dict) else {}
    discord = channels.get("discord") if isinstance(channels.get("discord"), dict) else {}
    telegram = channels.get("telegram") if isinstance(channels.get("telegram"), dict) else {}
    slack = channels.get("slack") if isinstance(channels.get("slack"), dict) else {}
    memory = data.get("memory") if isinstance(data.get("memory"), dict) else {}
    security = data.get("security") if isinstance(data.get("security"), dict) else {}

    if provider.get("apiKey"):
        payload.setdefault("api_key", provider.get("apiKey"))
    if security.get("mode"):
        payload.setdefault("security_mode", security.get("mode"))
    if bot.get("ownerUserId"):
        payload.setdefault("owner_user_id", bot.get("ownerUserId"))
    if memory.get("store"):
        payload.setdefault("memory_store", memory.get("store"))
    if telegram.get("token"):
        payload.setdefault("telegram_token", telegram.get("token"))
    if discord.get("token"):
        payload.setdefault("discord_token", discord.get("token"))
    if slack.get("botToken"):
        payload.setdefault("slack_bot_token", slack.get("botToken"))
    if slack.get("appToken"):
        payload.setdefault("slack_app_token", slack.get("appToken"))

    tools_cfg = data.get("tools") or data.get("_tools_config")
    if isinstance(tools_cfg, dict):
        payload["tools_config"] = tools_cfg
        google_workspace = tools_cfg.get("google_workspace")
        if isinstance(google_workspace, dict):
            payload.setdefault("google_workspace_enabled", bool(google_workspace.get("enabled")))
            if google_workspace.get("account"):
                payload.setdefault("google_workspace_account", google_workspace.get("account"))
            services = google_workspace.get("services")
            if isinstance(services, list):
                payload.setdefault("google_workspace_services", services)

    return payload


def _copy_json_value(value: Any) -> Any:
    return json.loads(json.dumps(value))


def migrate_tools(source_config: str | Path | dict[str, Any], target_dir: str | Path, selected_tools: list[str]) -> list[Path]:
    if isinstance(source_config, dict):
        data = source_config
    else:
        data = _read_json(Path(source_config).expanduser())

    tools_cfg = data.get("tools") or data.get("_tools_config") or {}
    if not isinstance(tools_cfg, dict):
        return []

    target_path = Path(target_dir).expanduser()
    target_path.mkdir(parents=True, exist_ok=True)

    selected = set(selected_tools or [])
    migrated: dict[str, Any] = {}
    for name, payload in tools_cfg.items():
        if name in selected:
            migrated[name] = _copy_json_value(payload)

    if not migrated:
        return []

    destination = target_path / "tools.json"
    with destination.open("w", encoding="utf-8") as fh:
        json.dump(migrated, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    return [destination]


def migrate_skills(source_dir: str | Path, target_dir: str | Path, selected_skills: list[str]) -> list[Path]:
    source_root = Path(source_dir).expanduser()
    target_root = Path(target_dir).expanduser()
    target_root.mkdir(parents=True, exist_ok=True)

    copied: list[Path] = []
    for skill_name in selected_skills or []:
        source_skill = source_root / skill_name
        if not source_skill.exists() or not source_skill.is_dir():
            continue
        destination_skill = target_root / skill_name
        if destination_skill.exists():
            shutil.rmtree(destination_skill)
        shutil.copytree(source_skill, destination_skill)
        copied.append(destination_skill)
    return copied


# Compatibility aliases for the existing server implementation.
load_migration_payload = load_migration


def migrate_selected_tools(target_config: Any, source_config: str | Path | dict[str, Any], selected_tools: list[str]) -> list[Path]:
    if hasattr(target_config, "_tools_config"):
        payload = load_migration(source_config) if not isinstance(source_config, dict) else {"tools_config": source_config.get("tools") or source_config.get("_tools_config") or {}}
        tools_cfg = payload.get("tools_config", {})
        existing = dict(getattr(target_config, "_tools_config", {}) or {})
        for name in selected_tools or []:
            if name in tools_cfg:
                existing[name] = _copy_json_value(tools_cfg[name])
        target_config._tools_config = existing
        return []
    return migrate_tools(source_config, Path(target_config), selected_tools)


def migrate_selected_skills(target_dir: str | Path, source_dir: str | Path, selected_skills: list[str]) -> list[Path]:
    source_root = Path(source_dir).expanduser()
    if source_root.is_file():
        source_root = source_root.parent / "skills"
    return migrate_skills(source_root, target_dir, selected_skills)
