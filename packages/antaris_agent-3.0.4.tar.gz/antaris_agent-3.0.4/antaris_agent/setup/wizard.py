"""High-level setup wizard wrapper."""

from __future__ import annotations

import time
import webbrowser
from typing import Any

from antaris_agent.core.config import Config
from antaris_agent.setup.server import SetupServer


class SetupWizard:
    """Thin orchestration layer around :class:`SetupServer`."""

    def __init__(self, poll_interval: float = 0.25):
        self.poll_interval = poll_interval

    def is_needed(self) -> bool:
        config = Config.load()
        if config is None:
            return True
        return not bool(getattr(config, "api_key", None))

    def run(self, wizard: str = "all", open_browser: bool = True) -> Any:
        server = SetupServer(initial_wizard=wizard)
        server.start(open_browser=False)
        try:
            url = f"http://{server.HOST}:{server.PORT}"
            if wizard and wizard != "all":
                url += f"/?wizard={wizard}"
            if open_browser:
                webbrowser.open(url)
            else:
                print(f"\n   Open in browser: {url}")

            while not server.setup_complete:
                time.sleep(self.poll_interval)

            return server.config
        finally:
            server.stop()
