"""
Antaris Agent Setup Server.

Browser-based setup wizard using only stdlib — zero external dependencies.
Runs on localhost:7474 and serves a single-page HTML wizard.

v2 — Multi-provider, model selection, multi-channel, migration, discovery,
     review screen, Google Workspace services, security default to Standard.
"""

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH, DEFAULT_CONFIG_DIR

from antaris_agent.setup.migration import (
    discover_configs,
    load_migration_payload,
    migrate_selected_tools,
    migrate_selected_skills,
)
from antaris_agent.setup.discovery import build_discovery_payload

WIZARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Antaris Agent Setup</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#1a1a1a;color:#e5e7eb;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:0 16px 48px}
#progress-wrap{width:100%;max-width:720px;padding:28px 0 20px}
#progress-track{background:#2a2a2a;border-radius:99px;height:6px;overflow:hidden}
#progress-fill{background:linear-gradient(90deg,#dc2626,#ef4444);height:6px;border-radius:99px;transition:width 0.4s ease}
.card{width:100%;max-width:720px;padding:36px 40px;animation:fadeIn 0.25s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
h1{font-size:1.9rem;font-weight:700;margin-bottom:10px;line-height:1.2;color:#f9fafb}
h2{font-size:1.35rem;font-weight:700;margin-bottom:8px;color:#f3f4f6}
h3{font-size:1rem;font-weight:700;margin-bottom:8px;color:#e5e7eb}
.subtitle{color:#9ca3af;font-size:0.95rem;line-height:1.6;margin-bottom:22px}
.muted{color:#9ca3af}
.radio-group{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}
.radio-card,.tile-card{display:flex;align-items:flex-start;gap:14px;border:1px solid #2a2d3a;border-radius:12px;padding:16px 18px;cursor:pointer;transition:border-color 0.15s,background 0.15s;text-decoration:none;color:inherit;background:linear-gradient(135deg,#181a24 0%,#1e2030 100%)}
.tile-card{display:block}
.radio-card:hover,.tile-card:hover{border-color:#6366f1;background:linear-gradient(135deg,#1e2030 0%,#252840 100%)}
.radio-card.selected,.tile-card.selected{border-color:#818cf8;background:linear-gradient(135deg,#1e1b4b 0%,#252840 100%)}
.radio-card input[type=radio],.radio-card input[type=checkbox]{margin-top:3px;accent-color:#818cf8;flex-shrink:0}
.radio-label{font-weight:600;font-size:0.95rem;color:#f3f4f6}
.radio-desc{font-size:0.82rem;color:#9ca3af;margin-top:2px}
.badge{display:inline-block;background:#422006;color:#fbbf24;font-size:0.7rem;font-weight:700;padding:1px 6px;border-radius:99px;margin-left:6px;vertical-align:middle}
.badge-rec{background:#2e1065;color:#c4b5fd}
.badge-soft{background:#1e1b4b;color:#a5b4fc}
.badge-green{background:#052e16;color:#6ee7b7}
.field{margin-bottom:20px}
.field label{display:block;font-weight:600;font-size:0.9rem;margin-bottom:7px;color:#cbd5e1}
.field input[type=text],.field input[type=password]{width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;outline:none;transition:border-color 0.15s,background 0.15s;background:#121521;color:#f3f4f6}
.field input:focus{border-color:#818cf8;background:#171a28}
.verify-row{display:flex;gap:10px;align-items:center;margin-top:8px}
.verify-row input{flex:1}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 26px;border-radius:9px;font-size:0.95rem;font-weight:600;cursor:pointer;border:none;transition:background 0.15s,opacity 0.15s;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;box-shadow:0 10px 24px rgba(99,102,241,0.25)}
.btn-primary:hover{background:linear-gradient(135deg,#5b5ff0,#6d28d9)}
.btn-primary:disabled{opacity:0.55;cursor:not-allowed}
.btn-secondary{background:#1a1e2d;color:#d1d5db;border:1px solid #31364a}
.btn-secondary:hover{background:#22273a}
.btn-success{background:linear-gradient(135deg,#059669,#10b981);color:#fff}
.btn-success:hover{background:linear-gradient(135deg,#047857,#059669)}
.btn-danger{background:#dc2626;color:#fff}
.btn-danger:hover{background:#b91c1c}
.btn-sm{padding:8px 16px;font-size:0.85rem}
.btn-row{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}
.token-status{font-size:0.85rem;min-width:60px;font-weight:500}
.token-status.ok{color:#059669}
.token-status.err{color:#dc2626}
.token-status.checking{color:#9ca3af}
.instr{background:linear-gradient(135deg,#141827 0%,#1c2240 100%);border:1px solid #3b3f62;border-left:3px solid #818cf8;border-radius:0 8px 8px 0;padding:14px 18px;margin-bottom:20px;font-size:0.88rem;line-height:1.65;color:#cbd5e1}
.instr strong{color:#f3f4f6}
.success-wrap{text-align:center;padding:20px 0}
.success-icon{font-size:3.5rem;margin-bottom:18px}
.divider{height:1px;background:#2a2d3a;margin:20px 0}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:24px}
.list{display:flex;flex-direction:column;gap:10px;margin:16px 0 24px}
.list li{margin-left:18px;color:#d1d5db;line-height:1.55}
.section-box{border:1px solid #31364a;border-radius:12px;padding:16px 18px;margin-bottom:16px;background:linear-gradient(135deg,#161a27 0%,#1b2133 100%)}
.pill-row{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.pill{display:inline-block;background:#1f2435;color:#cbd5e1;padding:6px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;border:1px solid #31364a}
.summary{background:linear-gradient(135deg,#141827 0%,#1b2133 100%);border:1px solid #31364a;border-radius:12px;padding:16px 18px;margin:14px 0 22px}
.summary .row{display:flex;gap:8px;padding:5px 0;font-size:0.92rem}
.summary .row strong{min-width:150px;color:#cbd5e1;flex-shrink:0}
.summary .row span{color:#f3f4f6}
code{background:#1f2435;padding:2px 6px;border-radius:6px;color:#c4b5fd}
.provider-tag{display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,#171b29 0%,#20263a 100%);border:1px solid #3b3f62;border-radius:8px;padding:8px 12px;margin:4px;font-size:0.85rem}
.provider-tag .remove{cursor:pointer;color:#f87171;font-weight:700;margin-left:4px;font-size:1rem;line-height:1}
.provider-tag .remove:hover{color:#fca5a5}
.model-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;margin:12px 0}
.model-card{border:1px solid #31364a;border-radius:10px;padding:12px 14px;cursor:pointer;transition:border-color 0.15s,background 0.15s;background:linear-gradient(135deg,#161a27 0%,#1b2133 100%)}
.model-card:hover{border-color:#818cf8}
.model-card.selected{border-color:#818cf8;background:linear-gradient(135deg,#1f2340 0%,#2a2352 100%)}
.model-card.primary{border-color:#34d399;background:linear-gradient(135deg,#052e16 0%,#064e3b 100%)}
.model-name{font-weight:600;font-size:0.88rem;color:#f3f4f6}
.model-tier{font-size:0.72rem;color:#9ca3af;margin-top:2px}
.collapse-hdr{cursor:pointer;display:flex;align-items:center;gap:8px;padding:10px 0;font-weight:600;font-size:0.95rem;user-select:none;color:#e5e7eb}
.collapse-hdr:hover{color:#a5b4fc}
.collapse-body{display:none;padding:0 0 12px 6px}
.collapse-body.open{display:block}
.cmd-table{width:100%;border-collapse:collapse;font-size:0.84rem}
.cmd-table td{padding:5px 8px;border-bottom:1px solid #2a2d3a;vertical-align:top;color:#d1d5db}
.cmd-table td:first-child{font-family:monospace;white-space:nowrap;color:#a5b4fc;font-weight:600}
.check-list{list-style:none;padding:0;margin:8px 0}
.check-list li{padding:4px 0;font-size:0.9rem;color:#d1d5db}
.check-list li input{margin-right:8px;accent-color:#6366f1}
@media(max-width:640px){.grid{grid-template-columns:1fr}.card{padding:24px 18px}.btn{width:100%}.btn-row{flex-direction:column}.model-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="progress-wrap">
  <div id="progress-track"><div id="progress-fill" style="width:8%"></div></div>
</div>
<div id="app" class="card"></div>
<script>
/* ============ CONSTANTS ============ */
const PROVIDERS=[
  {id:'anthropic',name:'Anthropic',desc:'Claude family — best for assistant personality',badge:'Recommended',hint:'sk-ant-... or OAuth token'},
  {id:'openai',name:'OpenAI',desc:'GPT-5.x family — strong general purpose',hint:'sk-proj-...'},
  {id:'google',name:'Google',desc:'Gemini family — fast multimodal',hint:'AIza...'},
  {id:'deepseek',name:'DeepSeek',desc:'Strong reasoning models',hint:'sk-...'},
  {id:'mistral',name:'Mistral',desc:'European AI — fast and capable',hint:''},
  {id:'groq',name:'Groq',desc:'Ultra-fast inference — free tier',hint:'gsk_...'},
  {id:'ollama',name:'Ollama',desc:'Local models — no API key needed',hint:'http://localhost:11434',local:true},
  {id:'together',name:'Together',desc:'Open-source model hosting',hint:''},
  {id:'kimi',name:'Kimi',desc:'Moonshot AI — long context',hint:''},
  {id:'minimax',name:'Minimax',desc:'MiniMax — multimodal generation',hint:''}
];
const KNOWN_MODELS={
  anthropic:[
    {id:'claude-opus-4-6',name:'Claude Opus 4.6',tier:'flagship'},
    {id:'claude-sonnet-4-6',name:'Claude Sonnet 4.6',tier:'balanced'},
    {id:'claude-sonnet-4-20250514',name:'Claude Sonnet 4',tier:'balanced'},
    {id:'claude-haiku-4-5-20251001',name:'Claude Haiku 4.5',tier:'fast'}
  ],
  openai:[
    {id:'gpt-5.4',name:'GPT-5.4',tier:'flagship'},
    {id:'gpt-5.2',name:'GPT-5.2',tier:'balanced'},
    {id:'gpt-4o',name:'GPT-4o',tier:'balanced'},
    {id:'gpt-4o-mini',name:'GPT-4o Mini',tier:'fast'}
  ],
  google:[
    {id:'gemini-3.1-pro-preview',name:'Gemini 3.1 Pro',tier:'flagship'},
    {id:'gemini-2.5-flash',name:'Gemini 2.5 Flash',tier:'balanced'},
    {id:'gemini-2.5-flash-lite',name:'Gemini 2.5 Flash Lite',tier:'fast'}
  ],
  deepseek:[
    {id:'deepseek-chat',name:'DeepSeek Chat',tier:'balanced'},
    {id:'deepseek-reasoner',name:'DeepSeek Reasoner',tier:'flagship'}
  ],
  mistral:[
    {id:'mistral-large-latest',name:'Mistral Large',tier:'flagship'},
    {id:'mistral-small-latest',name:'Mistral Small',tier:'fast'}
  ],
  groq:[
    {id:'llama-3.3-70b',name:'Llama 3.3 70B',tier:'balanced'},
    {id:'mixtral-8x7b-32768',name:'Mixtral 8x7B',tier:'fast'}
  ]
};
const CHANNELS=[
  {id:'discord',name:'Discord',desc:'Best for server-based collaboration'},
  {id:'telegram',name:'Telegram',desc:'Fastest path to a live bot',badge:'Easiest'},
  {id:'slack',name:'Slack',desc:'Workspace-native team use'}
];
const FLOW_STEPS={general:5,integrations:5,automation:3,power:3,all:10};
const START_STEP={general:10,integrations:20,automation:30,power:40,all:1};
const NEXT_MAP={1:2,2:3,3:4,4:5,5:6,6:7,7:8,8:9,9:50,10:11,11:12,12:13,13:14,20:21,21:22,22:23,23:24,30:31,31:32,40:41,41:42};
const PREV_MAP={2:1,3:2,4:3,5:4,6:5,7:6,8:7,9:8,50:9,11:10,12:11,13:12,14:13,21:20,22:21,23:22,24:23,31:30,32:31,41:40,42:41};

/* ============ STATE ============ */
const SEARCH=new URLSearchParams(window.location.search);
let state={
  flow:SEARCH.get('wizard')||'all',step:1,
  providers:[],addingProvider:true,curProvider:'anthropic',curApiKey:'',curApiKeyValid:null,
  selectedModels:[],primaryModel:'',
  selectedChannels:[],
  telegramToken:'',telegramValid:null,
  discordToken:'',discordValid:null,discordOpenChannels:[],discordRequireMention:true,discordChannelOptions:null,
  slackBotToken:'',slackAppToken:'',slackValid:null,
  botName:'Altaris',securityMode:'standard',
  ownerUserId:'',memoryStore:'',timezone:'UTC',
  googleEnabled:false,googleAccount:'',
  googleServices:{gmail:false,calendar:false,drive:false,docs:false,sheets:false},
  migrationChoice:null,migrationConfigs:[],migrationSelected:null,migrationPayload:null,
  migrateTools:[],migrateSkills:[],
  discoveryData:null,
  mediaEnabled:false,webhooksEnabled:false,authMonitorEnabled:false,
  extensionsEnabled:true,skillsEnabled:true,modelSwitchingEnabled:true,
  browserEnabled:false,desktopControlEnabled:false,terminalControlEnabled:false,
  heartbeatEnabled:false,heartbeatIntervalMinutes:30,
  compactionThreshold:80,
  memorySearchLimit:10,memoryMinRelevance:0.3,perTurnRecall:true,
  startupRestoreDays:2,
  keepRecentTokens:40000,
  rateLimitMessages:20,rateLimitWindowSeconds:60,
  tokenRateLimitEnabled:false,tokenRateLimitPerHour:100000,
  launched:false,testResult:null,status:null
};

/* ============ HELPERS ============ */
function esc(v){return String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function maskKey(k){if(!k)return'(not set)';if(k.length<=8)return'****';return k.substring(0,4)+'****'+k.substring(k.length-4);}
function statusClass(v){if(v===true)return'ok';if(v===false)return'err';if(v==='checking')return'checking';return'';}
function tokenStatusHtml(v){if(v===true)return'Verified';if(v===false)return'Invalid';if(v==='checking')return'Checking\u2026';return'';}
function providerInfo(id){return PROVIDERS.find(function(p){return p.id===id})||{id:id,name:id,desc:'',hint:''};}
function initFlow(){
  const f=(state.flow||'all').toLowerCase();
  state.flow=['general','integrations','automation','power','all'].includes(f)?f:'all';
  state.step=START_STEP[state.flow]||1;
}
initFlow();
function totalSteps(){return FLOW_STEPS[state.flow]||10;}
function currentStepIndex(){
  const s=state.step;
  if(state.flow==='all'){if(s>=1&&s<=9)return s;if(s===50)return 10;return 1;}
  if(state.flow==='general')return({10:1,11:2,12:3,13:4,14:5})[s]||1;
  if(state.flow==='integrations')return({20:1,21:2,22:3,23:4,24:5})[s]||1;
  if(state.flow==='automation')return({30:1,31:2,32:3})[s]||1;
  if(state.flow==='power')return({40:1,41:2,42:3})[s]||1;
  return s;
}
function setProgress(){
  const pct=Math.max(8,Math.round((currentStepIndex()/totalSteps())*100));
  document.getElementById('progress-fill').style.width=pct+'%';
}
function nextFlow(s){return NEXT_MAP[s]||s;}
function prevFlow(s){return PREV_MAP[s]||s;}
function gotoFlow(flow){state.flow=flow;state.step=START_STEP[flow]||1;const url=flow==='all'?'/':'/?wizard='+encodeURIComponent(flow);history.replaceState({},'',url);render();}
function gotoStep(s){state.step=s;render();}

/* ============ API ============ */
async function loadStatus(){try{const r=await fetch('/api/status');const d=await r.json();state.status=d;hydrateFromStatus(d);render();}catch(_){}}
function hydrateFromStatus(d){
  if(!d)return;
  if(d.bot_name)state.botName=d.bot_name;
  if(d.security_mode)state.securityMode=d.security_mode;
  if(d.owner_user_id)state.ownerUserId=d.owner_user_id;
  if(d.memory_store)state.memoryStore=d.memory_store;
  if(d.timezone)state.timezone=d.timezone;
  if(d.providers&&d.providers.length>0){state.providers=d.providers.map(function(p){return{provider:p.provider,apiKey:'',validated:p.has_key};});state.addingProvider=false;}
  else if(d.provider&&d.configured){state.providers=[{provider:d.provider,apiKey:'',validated:true}];state.addingProvider=false;}
  if(d.primary_model){state.primaryModel=d.primary_model;if(d.selected_models&&d.selected_models.length>0){state.selectedModels=d.selected_models;}else{state.selectedModels=[d.primary_model];if(d.fallback_model)state.selectedModels.push(d.fallback_model);}}
  if(d.channels&&d.channels.length>0)state.selectedChannels=d.channels.slice();
  if(d.google_workspace){state.googleEnabled=!!d.google_workspace.enabled;state.googleAccount=d.google_workspace.account||'';}
  if(d.automation){state.mediaEnabled=!!d.automation.media_enabled;state.webhooksEnabled=!!d.automation.webhooks_enabled;state.authMonitorEnabled=!!d.automation.auth_monitor_enabled;}
  if(d.power){state.extensionsEnabled=d.power.extensions_enabled!==false;state.skillsEnabled=d.power.skills_enabled!==false;state.modelSwitchingEnabled=d.power.model_switching_enabled!==false;state.browserEnabled=!!d.power.browser_enabled;state.desktopControlEnabled=!!d.power.desktop_control_enabled;state.terminalControlEnabled=!!d.power.terminal_control_enabled;}
  if(d.discord_require_mention!==undefined)state.discordRequireMention=!!d.discord_require_mention;
  if(d.discord_open_channels&&d.discord_open_channels.length>0)state.discordOpenChannels=d.discord_open_channels.slice();
  if(d.heartbeat){state.heartbeatEnabled=!!d.heartbeat.enabled;state.heartbeatIntervalMinutes=d.heartbeat.interval_minutes||30;}
  if(d.memory_settings){state.memorySearchLimit=d.memory_settings.search_limit||10;state.memoryMinRelevance=d.memory_settings.min_relevance||0.3;state.perTurnRecall=d.memory_settings.per_turn_recall!==false;}
  if(d.bot_settings){state.compactionThreshold=d.bot_settings.compaction_threshold||80;state.startupRestoreDays=d.bot_settings.startup_restore_days||2;state.timezone=d.bot_settings.timezone||'UTC';}
  if(d.rate_limit){state.rateLimitMessages=d.rate_limit.max_messages||20;state.rateLimitWindowSeconds=d.rate_limit.window_seconds||60;}
  if(d.token_rate_limit){state.tokenRateLimitEnabled=!!d.token_rate_limit.enabled;state.tokenRateLimitPerHour=d.token_rate_limit.per_hour||100000;}
}
async function verifyToken(kind,token){const r=await fetch('/api/validate-token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:kind,token:token})});return await r.json();}
async function fetchMigrationDiscover(){const r=await fetch('/api/migration/discover');return await r.json();}
async function fetchMigrationLoad(path){const r=await fetch('/api/migration/load',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:path})});return await r.json();}
async function fetchDiscovery(){const r=await fetch('/api/discovery');return await r.json();}
async function saveConfig(extra){
  const payload={
    wizard:state.flow,bot_name:state.botName,
    providers:state.providers.map(function(p){return{provider:p.provider,api_key:p.apiKey};}),
    primary_model:state.primaryModel,
    fallback_models:state.selectedModels.filter(function(m){return m!==state.primaryModel;}),
    selected_models:state.selectedModels,
    selected_channels:state.selectedChannels,
    telegram_token:state.telegramToken,discord_token:state.discordToken,discord_open_channels:state.discordOpenChannels||[],discord_require_mention:state.discordRequireMention!==false,
    slack_bot_token:state.slackBotToken,slack_app_token:state.slackAppToken,
    security_mode:state.securityMode,
    owner_user_id:state.ownerUserId,memory_store:state.memoryStore,timezone:state.timezone,
    google_workspace_enabled:state.googleEnabled,google_workspace_account:state.googleAccount,
    google_workspace_services:Object.keys(state.googleServices).filter(function(k){return state.googleServices[k];}),
    media_enabled:state.mediaEnabled,webhooks_enabled:state.webhooksEnabled,auth_monitor_enabled:state.authMonitorEnabled,
    extensions_enabled:state.extensionsEnabled,skills_enabled:state.skillsEnabled,
    model_switching_enabled:state.modelSwitchingEnabled,browser_enabled:state.browserEnabled,
    desktop_control_enabled:state.desktopControlEnabled,terminal_control_enabled:state.terminalControlEnabled,
    heartbeat_enabled:state.heartbeatEnabled,
    heartbeat_interval_minutes:state.heartbeatIntervalMinutes,
    compaction_threshold:state.compactionThreshold,
    memory_search_limit:state.memorySearchLimit,
    memory_min_relevance:state.memoryMinRelevance,
    per_turn_recall:state.perTurnRecall,
    startup_restore_days:state.startupRestoreDays,
    rate_limit_messages:state.rateLimitMessages,
    rate_limit_window_seconds:state.rateLimitWindowSeconds,
    token_rate_limit_enabled:state.tokenRateLimitEnabled,
    token_rate_limit_per_hour:state.tokenRateLimitPerHour
  };
  if(state.migrationSelected){payload.migration_source=state.migrationSelected;payload.migrate_tools=state.migrateTools;payload.migrate_skills=state.migrateSkills;}
  Object.assign(payload,extra||{});
  const r=await fetch('/api/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  return await r.json();
}

/* ============ UI HELPERS ============ */
function wizardTile(flow,title,desc,badge){return '<div class="tile-card" data-flow="'+flow+'"><div class="radio-label">'+title+' <span class="badge badge-soft">'+badge+'</span></div><div class="radio-desc" style="margin-top:8px">'+desc+'</div></div>';}
function toggleCard(id,title,desc,enabled){return '<label class="radio-card '+(enabled?'selected':'')+'" data-toggle-for="'+id+'"><input type="checkbox" id="'+id+'" '+(enabled?'checked':'')+'/><div><div class="radio-label">'+title+'</div><div class="radio-desc">'+desc+'</div></div></label>';}
function backBtn(){return '<button class="btn btn-secondary" id="btn-back">\u2190 Back</button>';}

/* ============ STEP RENDERERS ============ */

function stepWizardHub(){
  const cfg=state.status&&state.status.configured;
  return '<h1>Choose a setup path</h1><p class="subtitle">Antaris uses focused wizards instead of one giant onboarding flow. Start simple, come back later for more.</p>'+
    (cfg?'<div class="instr"><strong>Re-entry built in.</strong><br>Your current config was detected. Open any wizard to add channels, integrations, or advanced controls without starting over.</div>':'')+
    '<div class="grid">'+wizardTile('general','General setup','Core identity, providers, models, owner ID','Recommended first run')+wizardTile('integrations','Integrations wizard','Discord, Telegram, Slack, Google Workspace','Channels + workspace')+wizardTile('automation','Automation wizard','Media/docs, webhooks, auth monitoring','Hooks + automation')+wizardTile('power','Power-user wizard','Extensions, skills, model controls, browser/desktop/terminal','Advanced / local')+'</div>'+
    '<div class="divider"></div><h3>Prefer the classic guided flow?</h3><p class="subtitle">Run the original all-in-one setup with migration, providers, models, channels, discovery, and review.</p><div class="btn-row"><button class="btn btn-secondary" id="btn-classic-flow">Run full setup \u2192</button></div>';
}

/* Step 1: Migration */
function stepMigration(){
  let h='<h2>Migrate from existing agent?</h2><p class="subtitle">Import settings, tools, and skills from an existing Antaris or OpenClaw config.</p>';
  if(state.migrationChoice===null){
    h+='<div class="btn-row"><button class="btn btn-primary" id="btn-migrate-yes">Yes, find my configs</button><button class="btn btn-secondary" id="btn-migrate-no">No, start fresh</button></div>';
    return h;
  }
  if(state.migrationChoice===false){state.step=nextFlow(state.step);return render(),'';}
  if(state.migrationConfigs.length===0){
    h+='<div class="instr">Searching for existing configurations\u2026</div>';
    return h;
  }
  if(!state.migrationSelected){
    h+='<p class="subtitle" style="margin-top:8px">Found '+state.migrationConfigs.length+' config(s):</p><div class="radio-group" id="migration-list">';
    state.migrationConfigs.forEach(function(c,i){
      h+='<label class="radio-card" data-mig-idx="'+i+'"><input type="radio" name="mig" value="'+i+'"/><div><div class="radio-label">'+esc(c.name)+' <span class="badge badge-soft">'+esc(c.source_type)+'</span></div><div class="radio-desc">'+esc(c.path)+'<br>Provider: '+esc(c.provider)+' | Channels: '+(c.channels.length?esc(c.channels.join(', ')):'none')+'</div></div></label>';
    });
    h+='</div><div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-mig-select" disabled>Load selected</button><button class="btn btn-secondary" id="btn-mig-skip">Skip migration</button></div>';
    return h;
  }
  /* Migration payload loaded — show tools/skills checkboxes */
  const p=state.migrationPayload||{};
  h+='<div class="section-box"><h3>Loaded: '+esc(p.bot_name||'Agent')+'</h3><p class="muted" style="font-size:0.85rem">Provider: '+esc(p.provider)+' | Security: '+esc(p.security_mode||'standard')+'</p></div>';
  if(p.tools&&p.tools.length>0){
    h+='<h3>Migrate tools</h3><ul class="check-list">';
    p.tools.forEach(function(t){
      const checked=state.migrateTools.indexOf(t)>=0;
      h+='<li><input type="checkbox" data-mig-tool="'+esc(t)+'" '+(checked?'checked':'')+'/> '+esc(t)+'</li>';
    });
    h+='</ul>';
  }
  if(p.skills&&p.skills.length>0){
    h+='<h3>Migrate skills</h3><ul class="check-list">';
    p.skills.forEach(function(s){
      const checked=state.migrateSkills.indexOf(s)>=0;
      h+='<li><input type="checkbox" data-mig-skill="'+esc(s)+'" '+(checked?'checked':'')+'/> '+esc(s)+'</li>';
    });
    h+='</ul>';
  }
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-mig-continue">Continue with setup \u2192</button></div>';
  return h;
}

/* Step 2: Multi-Provider */
function stepProviders(){
  let h='<h2>Configure AI provider(s)</h2><p class="subtitle">Add one or more providers. The first becomes your default.</p>';
  if(state.providers.length>0){
    h+='<div style="margin-bottom:16px">';
    state.providers.forEach(function(p,i){
      const info=providerInfo(p.provider);
      h+='<span class="provider-tag">'+esc(info.name)+(p.validated?' <span class="badge badge-green">verified</span>':'')+' <span class="remove" data-rm-provider="'+i+'">\u00d7</span></span>';
    });
    h+='</div>';
  }
  if(state.addingProvider){
    const availIds=state.providers.map(function(p){return p.provider;});
    const avail=PROVIDERS.filter(function(p){return availIds.indexOf(p.id)<0;});
    if(avail.length===0){
      h+='<p class="muted">All providers added.</p>';
    } else {
      h+='<div class="radio-group" id="provider-group">';
      avail.forEach(function(p){
        const sel=state.curProvider===p.id?'selected':'';
        h+='<label class="radio-card '+sel+'" data-val="'+p.id+'"><input type="radio" name="provider" value="'+p.id+'" '+(state.curProvider===p.id?'checked':'')+'><div><div class="radio-label">'+esc(p.name)+(p.badge?' <span class="badge badge-rec">'+esc(p.badge)+'</span>':'')+'</div><div class="radio-desc">'+esc(p.desc)+'</div></div></label>';
      });
      h+='</div>';
      const info=providerInfo(state.curProvider);
      if(info.local){
        h+='<div class="field"><label>Ollama URL (optional)</label><input type="text" id="api-key-input" value="'+esc(state.curApiKey)+'" placeholder="http://localhost:11434"/></div>';
        h+='<div class="btn-row"><button class="btn btn-primary btn-sm" id="btn-add-provider">Add Ollama</button></div>';
      } else {
        const st=tokenStatusHtml(state.curApiKeyValid);
        h+='<div class="field"><label>'+esc(info.name)+' API Key or Token</label><div class="verify-row"><input type="password" id="api-key-input" value="'+esc(state.curApiKey)+'" placeholder="'+esc(info.hint)+'" autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-api">Verify</button><span class="token-status '+statusClass(state.curApiKeyValid)+'" id="api-key-status">'+st+'</span></div></div>';
        h+='<div class="btn-row"><button class="btn btn-primary btn-sm" id="btn-add-provider" '+(state.curApiKeyValid!==true?'disabled':'')+'>Add '+esc(info.name)+'</button></div>';
      }
    }
  } else {
    h+='<div class="btn-row" style="margin-bottom:16px"><button class="btn btn-secondary btn-sm" id="btn-add-another-provider">+ Add another provider</button></div>';
  }
  const canNext=state.providers.length>0;
  h+='<div class="divider"></div><div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-providers" '+(canNext?'':'disabled')+'>Next \u2192</button></div>';
  return h;
}

/* Step 3: Model Selection */
function stepModelSelection(){
  let h='<h2>Select models</h2><p class="subtitle">Click models to build your fallback chain. First click = primary (#1), next clicks = fallback order (#2, #3, ...). Click a selected model to remove it.</p>';
  state.providers.forEach(function(p){
    const models=KNOWN_MODELS[p.provider];
    if(!models||models.length===0)return;
    const info=providerInfo(p.provider);
    h+='<h3>'+esc(info.name)+'</h3><div class="model-grid">';
    models.forEach(function(m){
      const pos=state.selectedModels.indexOf(m.id);
      const isSel=pos>=0;
      const isPrimary=pos===0;
      const cls='model-card'+(isPrimary?' primary':(isSel?' selected':''));
      const rank=isSel?(pos+1):0;
      const rankBadge=isPrimary?' <span class="badge badge-green">#1 Primary</span>':(isSel?' <span class="badge badge-soft">#'+(pos+1)+' Fallback</span>':'');
      h+='<div class="'+cls+'" data-model="'+esc(m.id)+'" data-provider="'+esc(p.provider)+'"><div class="model-name">'+esc(m.name)+rankBadge+'</div><div class="model-tier">'+esc(m.tier)+'</div></div>';
    });
    h+='</div>';
  });
  if(state.selectedModels.length>0){
    h+='<div style="margin:14px 0"><strong>Fallback chain:</strong> ';
    h+=state.selectedModels.map(function(m,i){
      const label=i===0?'#1 Primary':'#'+(i+1)+' Fallback';
      return '<span class="pill" style="margin:2px 4px">'+esc(m)+' <span style="opacity:0.7;font-size:0.75rem">('+label+')</span></span>';
    }).join(' \u2192 ');
    h+='</div>';
  }
  const canNext=state.selectedModels.length>0;
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-models" '+(canNext?'':'disabled')+'>Next \u2192</button></div>';
  return h;
}

/* Step 4: Channel Selection (multi-select) */
function stepChannelSelect(){
  let h='<h2>Select chat interface(s)</h2><p class="subtitle">Choose which platforms your assistant should connect to. Select none for terminal-only mode.</p>';
  h+='<div class="radio-group" id="channel-group">';
  CHANNELS.forEach(function(ch){
    const sel=state.selectedChannels.indexOf(ch.id)>=0;
    h+='<label class="radio-card '+(sel?'selected':'')+'" data-ch="'+ch.id+'"><input type="checkbox" data-ch-check="'+ch.id+'" '+(sel?'checked':'')+'><div><div class="radio-label">'+esc(ch.name)+(ch.badge?' <span class="badge">'+esc(ch.badge)+'</span>':'')+'</div><div class="radio-desc">'+esc(ch.desc)+'</div></div></label>';
  });
  h+='<label class="radio-card '+(state.selectedChannels.length===0?'selected':'')+'" data-ch="terminal"><input type="checkbox" data-ch-check="terminal" '+(state.selectedChannels.length===0?'checked':'')+'><div><div class="radio-label">Terminal only</div><div class="radio-desc">No tokens needed — local dev mode</div></div></label>';
  h+='</div><div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-channels">Next \u2192</button></div>';
  return h;
}

/* Step 5: Channel Setup (per-platform tokens) */
function stepChannelSetup(){
  if(state.selectedChannels.length===0){state.step=nextFlow(state.step);return render(),'';}
  let h='<h2>Set up your channels</h2><p class="subtitle">Paste the token(s) below — we\'ll verify them before continuing.</p>';
  if(state.selectedChannels.indexOf('telegram')>=0){
    const st=tokenStatusHtml(state.telegramValid);
    h+='<div class="instr"><strong>Telegram</strong><br>1. Open Telegram, search for <strong>@BotFather</strong><br>2. Send <code>/newbot</code> and follow prompts<br>3. Paste the token below</div>';
    h+='<div class="field"><label>Telegram Bot Token</label><div class="verify-row"><input type="password" id="tg-token-input" value="'+esc(state.telegramToken)+'" placeholder="123456789:ABCdef..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-tg">Verify</button><span class="token-status '+statusClass(state.telegramValid)+'" id="tg-status">'+st+'</span></div></div>';
  }
  if(state.selectedChannels.indexOf('discord')>=0){
    if(state.selectedChannels.indexOf('telegram')>=0)h+='<div class="divider"></div>';
    const st2=tokenStatusHtml(state.discordValid);
    h+='<div class="instr"><strong>Discord</strong><br>1. Go to <strong>discord.com/developers</strong> \u2192 New Application<br>2. Bot tab \u2192 Reset Token \u2192 Copy<br>3. Enable <strong>Message Content Intent</strong><br>4. Paste below</div>';
    h+='<div class="field"><label>Discord Bot Token</label><div class="verify-row"><input type="password" id="dc-token-input" value="'+esc(state.discordToken)+'" placeholder="MTI3..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-dc">Verify</button><span class="token-status '+statusClass(state.discordValid)+'" id="dc-status">'+st2+'</span></div></div>';
    if(state.discordToken){
      h+='<div class="field"><button class="btn btn-secondary btn-sm" id="btn-discover-channels">&#128268; Discover channels</button></div>';
      h+='<div id="channel-discovery-results">';
      if(state.discordChannelOptions&&state.discordChannelOptions.length>0){
        state.discordChannelOptions.forEach(function(guild){
          h+='<div class="instr"><strong>'+esc(guild.guild_name)+'</strong><br>';
          (guild.channels||[]).forEach(function(ch){
            var checked=state.discordOpenChannels.indexOf(ch.id)>=0?' checked':'';
            h+='<label style="display:block;margin:2px 0"><input type="checkbox" class="dc-ch-check" data-ch-id="'+esc(ch.id)+'"'+checked+'> #'+esc(ch.name)+'</label>';
          });
          h+='</div>';
        });
      }
      h+='</div>';
      h+='<div class="field"><label><input type="checkbox" id="dc-require-mention"'+(state.discordRequireMention?' checked':'')+'/> Require @mention to respond (recommended)</label></div>';
    }
  }
  if(state.selectedChannels.indexOf('slack')>=0){
    if(state.selectedChannels.length>1)h+='<div class="divider"></div>';
    const st3=tokenStatusHtml(state.slackValid);
    h+='<div class="instr"><strong>Slack (Socket Mode)</strong><br>1. <strong>api.slack.com/apps</strong> \u2192 Create App<br>2. Add bot scopes like <code>chat:write</code><br>3. Install to workspace, copy bot token (xoxb-...)<br>4. Enable Socket Mode, create app token (xapp-...)</div>';
    h+='<div class="field"><label>Slack Bot Token (xoxb-...)</label><div class="verify-row"><input type="password" id="slack-bot-input" value="'+esc(state.slackBotToken)+'" placeholder="xoxb-..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-slack">Verify</button><span class="token-status '+statusClass(state.slackValid)+'" id="slack-status">'+st3+'</span></div></div>';
    h+='<div class="field"><label>Slack App Token (xapp-...)</label><input type="password" id="slack-app-input" value="'+esc(state.slackAppToken)+'" placeholder="xapp-..." autocomplete="off"/></div>';
  }
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-ch-setup" '+(canProceedChannelSetup()?'':'disabled')+'>Next \u2192</button></div>';
  return h;
}
function canProceedChannelSetup(){
  if(state.selectedChannels.length===0)return true;
  let ok=true;
  if(state.selectedChannels.indexOf('telegram')>=0&&state.telegramValid!==true)ok=false;
  if(state.selectedChannels.indexOf('discord')>=0&&state.discordValid!==true)ok=false;
  if(state.selectedChannels.indexOf('slack')>=0&&state.slackValid!==true)ok=false;
  return ok;
}

/* Step 6: Bot Name */
function stepBotName(){
  return '<h2>Name your bot</h2><p class="subtitle">Give your assistant an identity.</p>'+
    '<div class="field"><label>Bot name</label><input type="text" id="bot-name-input" value="'+esc(state.botName)+'" placeholder="Altaris" maxlength="40"/></div>'+
    '<div class="field"><label>Owner user ID (optional)</label><input type="text" id="owner-user-id-input" value="'+esc(state.ownerUserId)+'" placeholder="Discord/Telegram user ID for alerts"/></div>'+
    '<div class="field"><label>Memory store path (optional)</label><input type="text" id="memory-store-input" value="'+esc(state.memoryStore)+'" placeholder="~/.antaris/memory"/></div>'+
    '<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-name">Next \u2192</button></div>';
}

/* Step 7: Google Workspace */
function stepGoogleWorkspace(){
  let h='<h2>Google Workspace</h2><p class="subtitle">Optionally enable Google Workspace tools. Select which services you need.</p>';
  h+=toggleCard('google-enabled-input','Enable Google Workspace integration','Uses the machine\'s authorized gog CLI when available',state.googleEnabled);
  if(state.googleEnabled){
    h+='<div style="margin-top:16px"><div class="field"><label>Google account (optional)</label><input type="text" id="google-account-input" value="'+esc(state.googleAccount)+'" placeholder="user@example.com"/></div>';
    h+='<h3>Services</h3><ul class="check-list">';
    const svcs=[{id:'gmail',name:'Gmail'},{id:'calendar',name:'Calendar'},{id:'drive',name:'Drive'},{id:'docs',name:'Docs'},{id:'sheets',name:'Sheets'}];
    svcs.forEach(function(s){
      h+='<li><input type="checkbox" data-gsvc="'+s.id+'" '+(state.googleServices[s.id]?'checked':'')+'> '+s.name+'</li>';
    });
    h+='</ul></div>';
  }
  if(state.flow==='integrations'){
    h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-save-integrations">Save &amp; Finish</button></div>';
  }else{
    h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-google">Next \u2192</button></div>';
  }
  return h;
}

/* Step 8: Discovery */
function stepDiscovery(){
  let h='<h2>Discover capabilities</h2><p class="subtitle">Here\'s what your agent can do. Explore the available tools, extensions, CLI commands, and chat commands.</p>';
  if(!state.discoveryData){
    h+='<p class="muted">Loading discovery data\u2026</p>';
    return h;
  }
  const d=state.discoveryData;
  /* Tools */
  if(d.tools&&d.tools.length>0){
    h+='<div class="section-box"><h3>Available Tools</h3>';
    d.tools.forEach(function(g){
      h+='<div style="margin-top:8px"><strong>'+esc(g.category)+'</strong><div class="pill-row">';
      g.items.forEach(function(t){h+='<span class="pill'+(t.enabled?' selected':'')+'">'+esc(t.name)+(t.enabled?' \u2713':'')+'</span>';});
      h+='</div></div>';
    });
    h+='</div>';
  }
  /* Extensions */
  if(d.extensions&&d.extensions.length>0){
    h+='<div class="section-box"><h3>Extensions</h3>';
    d.extensions.forEach(function(e){h+='<div style="padding:4px 0"><strong>'+esc(e.name)+'</strong> \u2014 <span class="muted">'+esc(e.description)+'</span></div>';});
    h+='</div>';
  }
  /* CLI Commands */
  if(d.cli_commands&&d.cli_commands.length>0){
    h+='<div class="section-box"><h3>CLI Commands</h3><table class="cmd-table">';
    d.cli_commands.forEach(function(c){h+='<tr><td>'+esc(c.command)+'</td><td>'+esc(c.description)+'</td></tr>';});
    h+='</table></div>';
  }
  /* Chat Commands */
  if(d.chat_commands&&d.chat_commands.length>0){
    h+='<div class="section-box"><h3>Chat Commands</h3><table class="cmd-table">';
    d.chat_commands.forEach(function(c){h+='<tr><td>'+esc(c.command)+'</td><td>'+esc(c.description)+'</td></tr>';});
    h+='</table></div>';
  }
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-next-discovery">Next \u2192</button></div>';
  return h;
}

/* Step 9: Review Screen */
function stepReview(){
  let h='<h2>Review configuration</h2><p class="subtitle">Review everything before saving. Credentials are masked for security.</p>';
  h+='<div class="summary">';
  h+='<div class="row"><strong>Bot name:</strong> <span>'+esc(state.botName)+'</span></div>';
  h+='<div class="row"><strong>Security mode:</strong> <span>'+esc(state.securityMode)+'</span></div>';
  /* Providers */
  h+='<div class="row"><strong>Providers:</strong> <span>';
  if(state.providers.length>0){h+=state.providers.map(function(p){return esc(providerInfo(p.provider).name)+(p.apiKey?' ('+esc(maskKey(p.apiKey))+')':'');}).join(', ');}
  else{h+='None configured';}
  h+='</span></div>';
  /* Models */
  h+='<div class="row"><strong>Model chain:</strong> <span>';
  if(state.selectedModels.length>0){
    h+=state.selectedModels.map(function(m,i){return esc(m)+(i===0?' (#1 Primary)':' (#'+(i+1)+')');}).join(' \u2192 ');
  }else{h+='(not set)';}
  h+='</span></div>';
  /* Channels */
  h+='<div class="row"><strong>Channels:</strong> <span>'+(state.selectedChannels.length>0?esc(state.selectedChannels.join(', ')):'Terminal only')+'</span></div>';
  if(state.selectedChannels.indexOf('telegram')>=0)h+='<div class="row"><strong>Telegram token:</strong> <span>'+esc(maskKey(state.telegramToken))+'</span></div>';
  if(state.selectedChannels.indexOf('discord')>=0){h+='<div class="row"><strong>Discord token:</strong> <span>'+esc(maskKey(state.discordToken))+'</span></div>';if(state.discordOpenChannels&&state.discordOpenChannels.length>0)h+='<div class="row"><strong>Open channels:</strong> <span>'+state.discordOpenChannels.length+' selected</span></div>';h+='<div class="row"><strong>Require mention:</strong> <span>'+(state.discordRequireMention?'Yes':'No (open chat)')+'</span></div>';}
  if(state.selectedChannels.indexOf('slack')>=0)h+='<div class="row"><strong>Slack bot token:</strong> <span>'+esc(maskKey(state.slackBotToken))+'</span></div>';
  /* Owner / Memory */
  if(state.ownerUserId)h+='<div class="row"><strong>Owner ID:</strong> <span>'+esc(state.ownerUserId)+'</span></div>';
  h+='<div class="row"><strong>Timezone:</strong> <span>'+esc(state.timezone||'UTC')+'</span></div>';
  if(state.memoryStore)h+='<div class="row"><strong>Memory store:</strong> <span>'+esc(state.memoryStore)+'</span></div>';
  /* Google */
  if(state.googleEnabled){
    const svcs=Object.keys(state.googleServices).filter(function(k){return state.googleServices[k];});
    h+='<div class="row"><strong>Google Workspace:</strong> <span>Enabled'+(svcs.length?' ('+esc(svcs.join(', '))+')':'')+''+(state.googleAccount?' \u2014 '+esc(state.googleAccount):'')+'</span></div>';
  }
  /* Migration */
  if(state.migrationSelected){
    h+='<div class="row"><strong>Migration from:</strong> <span>'+esc(state.migrationSelected)+'</span></div>';
    if(state.migrateTools.length)h+='<div class="row"><strong>Migrated tools:</strong> <span>'+esc(state.migrateTools.join(', '))+'</span></div>';
    if(state.migrateSkills.length)h+='<div class="row"><strong>Migrated skills:</strong> <span>'+esc(state.migrateSkills.join(', '))+'</span></div>';
  }
  h+='</div>';
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-success" id="btn-save-config">\ud83d\udcbe Save Configuration</button><button class="btn btn-danger btn-sm" id="btn-quit-wizard">Quit</button></div>';
  return h;
}

/* Step 50: Done */
function stepDone(){
  if(state.launched){
    const test=state.testResult||{};
    const testH=test.success?'<p style="color:#059669;font-weight:600;margin-top:12px">\u2705 Connection test passed'+(test.channel?' for '+esc(test.channel):'')+'</p>':'<p style="color:#92400e;font-weight:600;margin-top:12px">\u26a0\ufe0f Config saved'+(test.error?' \u2014 '+esc(test.error):'')+'</p>';
    return '<div class="success-wrap"><div class="success-icon">\u2705</div><h2>Antaris is configured!</h2><p class="subtitle">Your setup is saved. Run <code>antaris start</code> to bring your agent online.</p>'+testH+'<div class="btn-row" style="justify-content:center;margin-top:18px"><a class="btn btn-secondary" href="/">Open wizard hub</a></div></div>';
  }
  return '<div class="success-wrap"><div class="success-icon">\u2728</div><h2>Setup complete</h2><p class="subtitle">Return to the wizard hub anytime to unlock more features.</p><div class="btn-row" style="justify-content:center"><a class="btn btn-secondary" href="/">Back to wizard hub</a></div></div>';
}

/* Sub-wizard steps */
function stepGeneralWelcome(){
  return '<h1>General setup</h1><p class="subtitle">Start with essentials: providers, models, identity, and runtime defaults.</p><ul class="list"><li>AI providers + default models</li><li>Bot identity + owner</li><li>Memory store path</li><li>Return later for integrations and power features</li></ul><div class="btn-row"><button class="btn btn-secondary" id="btn-back-hub">\u2190 Wizard hub</button><button class="btn btn-primary" id="btn-next-gw">Get started \u2192</button></div>';
}
function stepIntegrationsWelcome(){
  return '<h1>Integrations wizard</h1><p class="subtitle">Connect chat surfaces and workspace tooling.</p><div class="pill-row"><span class="pill">Discord</span><span class="pill">Telegram</span><span class="pill">Slack</span><span class="pill">Google Workspace</span></div><div class="btn-row" style="margin-top:24px"><button class="btn btn-secondary" id="btn-back-hub">\u2190 Wizard hub</button><button class="btn btn-primary" id="btn-next-intro">Continue \u2192</button></div>';
}
function stepAutomationWelcome(){
  return '<h1>Automation / platform wizard</h1><p class="subtitle">Turn on feature clusters for documents, media, hooks, and auth observability.</p><div class="pill-row"><span class="pill">PDF / media</span><span class="pill">Webhooks</span><span class="pill">Auth monitoring</span></div><div class="btn-row" style="margin-top:24px"><button class="btn btn-secondary" id="btn-back-hub">\u2190 Wizard hub</button><button class="btn btn-primary" id="btn-next-auto">Continue \u2192</button></div>';
}
function stepPowerWelcome(){
  return '<h1>Power-user wizard</h1><p class="subtitle">Advanced local control stays opt-in: extensions, skills, model switching, and machine-control surfaces.</p><div class="pill-row"><span class="pill">Extensions</span><span class="pill">Skills</span><span class="pill">Model switching</span><span class="pill">Browser / desktop / terminal</span></div><div class="btn-row" style="margin-top:24px"><button class="btn btn-secondary" id="btn-back-hub">\u2190 Wizard hub</button><button class="btn btn-primary" id="btn-next-power">Continue \u2192</button></div>';
}
function stepGeneralProfile(){
  return '<h2>General runtime defaults</h2><p class="subtitle">Core details that make later re-entry smoother.</p>'+
    '<div class="field"><label>Bot name</label><input type="text" id="bot-name-input" value="'+esc(state.botName)+'" placeholder="Altaris" maxlength="40"/></div>'+
    '<div class="field"><label>Owner user ID (optional)</label><input type="text" id="owner-user-id-input" value="'+esc(state.ownerUserId)+'" placeholder="Discord owner ID for alerts"/></div>'+
    '<div class="field"><label>Timezone</label>'+
    '<input type="text" id="timezone-input" value="'+esc(state.timezone)+'" list="tz-list" placeholder="UTC"/>'+
    '<datalist id="tz-list"><option value="UTC"/><option value="America/Los_Angeles"/><option value="America/New_York"/><option value="America/Chicago"/><option value="America/Denver"/><option value="Europe/London"/><option value="Europe/Berlin"/><option value="Europe/Paris"/><option value="Asia/Tokyo"/><option value="Asia/Singapore"/><option value="Asia/Dubai"/><option value="Australia/Sydney"/></datalist>'+
    '<div class="radio-desc">Used for timestamps in memory and logs.</div></div>'+
    '<div class="field"><label>Memory store path (optional)</label><input type="text" id="memory-store-input" value="'+esc(state.memoryStore)+'" placeholder="~/.antaris/memory"/></div>'+
    '<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-save-general">Save general setup</button></div>';
}
function stepAutomationOptions(){
  return '<h2>Automation features</h2><p class="subtitle">Choose which product surfaces to unlock.</p>'+
    toggleCard('media-enabled-input','Enable PDF / media / document handling','Transcripts, video, PDF ingestion, document flows',state.mediaEnabled)+
    toggleCard('webhooks-enabled-input','Enable hooks / webhooks','Webhook and event-driven automation surfaces',state.webhooksEnabled)+
    toggleCard('auth-monitor-enabled-input','Enable auth monitoring','Auth and credential monitoring extension',state.authMonitorEnabled)+
    '<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-save-automation">Save automation settings</button></div>';
}
function stepPowerOptions(){
  var h='<h2>Power-user features</h2><p class="subtitle">Advanced features stay discoverable but optional.</p>'+
    toggleCard('extensions-enabled-input','Extensions / plugins enabled','Load extension and plugin surfaces',state.extensionsEnabled)+
    toggleCard('skills-enabled-input','Skills enabled','Skill-driven workflows and discoverability',state.skillsEnabled)+
    toggleCard('model-switch-enabled-input','Model switching / thinking controls','Model-switching and thinking-level controls',state.modelSwitchingEnabled)+
    toggleCard('browser-enabled-input','Browser control','Browser automation tools',state.browserEnabled)+
    toggleCard('desktop-enabled-input','Desktop control','Desktop control extension',state.desktopControlEnabled)+
    toggleCard('terminal-enabled-input','Terminal control','Terminal control/local shell extension',state.terminalControlEnabled);
  /* Memory tuning */
  h+='<div class="section-box"><h3>\ud83e\udde0 Memory Tuning</h3>'+
    '<div class="field"><label>Memory search limit (1\u201350)</label><input type="number" id="memory-search-limit-input" value="'+esc(state.memorySearchLimit)+'" min="1" max="50" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    '<div class="field"><label>Min relevance score (0.0\u20131.0)</label><input type="number" id="memory-min-relevance-input" value="'+esc(state.memoryMinRelevance)+'" min="0" max="1" step="0.05" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    toggleCard('per-turn-recall-input','Per-turn recall','Automatically recall relevant memories each turn',state.perTurnRecall)+
    '<div class="field"><label>Startup restore days (0\u201330)</label><input type="number" id="startup-restore-days-input" value="'+esc(state.startupRestoreDays)+'" min="0" max="30" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    '</div>';
  /* Heartbeat */
  h+='<div class="section-box"><h3>\ud83d\udc93 Heartbeat</h3>'+
    toggleCard('heartbeat-enabled-input','Enable heartbeat','Periodic check-in polling',state.heartbeatEnabled);
  if(state.heartbeatEnabled){
    h+='<div class="field" style="margin-top:12px"><label>Interval (minutes, 5\u20131440)</label><input type="number" id="heartbeat-interval-input" value="'+esc(state.heartbeatIntervalMinutes)+'" min="5" max="1440" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>';
  }
  h+='</div>';
  /* Context */
  h+='<div class="section-box"><h3>\ud83d\udcc4 Context</h3>'+
    '<div class="field"><label>Compaction threshold % (50\u201395)</label><input type="number" id="compaction-threshold-input" value="'+esc(state.compactionThreshold)+'" min="50" max="95" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    '</div>';
  /* Rate limits */
  h+='<div class="section-box"><h3>\u26a1 Rate Limits</h3>'+
    '<div class="field"><label>Max messages per window (1\u20131000)</label><input type="number" id="rate-limit-messages-input" value="'+esc(state.rateLimitMessages)+'" min="1" max="1000" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    '<div class="field"><label>Window seconds (10\u20133600)</label><input type="number" id="rate-limit-window-input" value="'+esc(state.rateLimitWindowSeconds)+'" min="10" max="3600" step="1" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>'+
    toggleCard('token-rate-limit-enabled-input','Token rate limit','Cap token usage per hour',state.tokenRateLimitEnabled);
  if(state.tokenRateLimitEnabled){
    h+='<div class="field" style="margin-top:12px"><label>Max tokens per hour</label><input type="number" id="token-rate-limit-per-hour-input" value="'+esc(state.tokenRateLimitPerHour)+'" min="1000" step="1000" style="width:100%;padding:10px 14px;border:1px solid #31364a;border-radius:8px;font-size:0.95rem;background:#121521;color:#f3f4f6;outline:none"/></div>';
  }
  h+='</div>';
  /* Bot settings — timezone */
  h+='<div class="section-box"><h3>\ud83c\udf10 Bot Settings</h3>'+
    '<div class="field"><label>Timezone</label>'+
    '<input type="text" id="power-timezone-input" value="'+esc(state.timezone)+'" list="power-tz-list" placeholder="UTC" style="width:100%"/>'+
    '<datalist id="power-tz-list"><option value="UTC"/><option value="America/Los_Angeles"/><option value="America/New_York"/><option value="America/Chicago"/><option value="Europe/London"/><option value="Europe/Berlin"/><option value="Asia/Tokyo"/><option value="Asia/Singapore"/></datalist>'+
    '</div></div>';
  h+='<div class="btn-row">'+backBtn()+'<button class="btn btn-primary" id="btn-save-power">Save power settings</button></div>';
  return h;
}
function stepFlowDone(flow){
  const labels={general:'General setup saved',integrations:'Integrations saved',automation:'Automation settings saved',power:'Power-user settings saved'};
  return '<div class="success-wrap"><div class="success-icon">\u2728</div><h2>'+(labels[flow]||'Saved')+'</h2><p class="subtitle">Return to the wizard hub anytime to unlock more features.</p><div class="btn-row" style="justify-content:center"><a class="btn btn-secondary" href="/">Back to wizard hub</a></div></div>';
}

/* ============ RENDER ============ */
function render(){
  setProgress();
  const app=document.getElementById('app');
  const s=state.step;
  switch(s){
    /* Full flow */
    case 1: app.innerHTML=stepMigration();break;
    case 2: app.innerHTML=stepProviders();break;
    case 3: app.innerHTML=stepModelSelection();break;
    case 4: app.innerHTML=stepChannelSelect();break;
    case 5: app.innerHTML=stepChannelSetup();break;
    case 6: app.innerHTML=stepBotName();break;
    case 7: app.innerHTML=stepGoogleWorkspace();break;
    case 8: app.innerHTML=stepDiscovery();break;
    case 9: app.innerHTML=stepReview();break;
    case 50: app.innerHTML=stepDone();break;
    /* Wizard hub */
    case 0: app.innerHTML=stepWizardHub();break;
    /* General */
    case 10: app.innerHTML=stepGeneralWelcome();break;
    case 11: app.innerHTML=stepProviders();break;
    case 12: app.innerHTML=stepModelSelection();break;
    case 13: app.innerHTML=stepGeneralProfile();break;
    case 14: app.innerHTML=stepFlowDone('general');break;
    /* Integrations */
    case 20: app.innerHTML=stepIntegrationsWelcome();break;
    case 21: app.innerHTML=stepChannelSelect();break;
    case 22: app.innerHTML=stepChannelSetup();break;
    case 23: app.innerHTML=stepGoogleWorkspace();break;
    case 24: app.innerHTML=stepFlowDone('integrations');break;
    /* Automation */
    case 30: app.innerHTML=stepAutomationWelcome();break;
    case 31: app.innerHTML=stepAutomationOptions();break;
    case 32: app.innerHTML=stepFlowDone('automation');break;
    /* Power */
    case 40: app.innerHTML=stepPowerWelcome();break;
    case 41: app.innerHTML=stepPowerOptions();break;
    case 42: app.innerHTML=stepFlowDone('power');break;
    default: state.step=0;app.innerHTML=stepWizardHub();break;
  }
  bindEvents();
}

/* ============ EVENT BINDING ============ */
function bindEvents(){
  /* Wizard hub tiles */
  document.querySelectorAll('[data-flow]').forEach(function(el){el.addEventListener('click',function(){gotoFlow(el.getAttribute('data-flow'));});});
  const classic=document.getElementById('btn-classic-flow');
  if(classic)classic.addEventListener('click',function(){gotoFlow('all');});
  const backHub=document.getElementById('btn-back-hub');
  if(backHub)backHub.addEventListener('click',function(){state.step=0;render();});
  const back=document.getElementById('btn-back');
  if(back)back.addEventListener('click',function(){state.step=prevFlow(state.step);render();});

  /* Toggle cards */
  document.querySelectorAll('[data-toggle-for]').forEach(function(card){card.addEventListener('click',function(e){if(e.target.tagName==='INPUT')return;const id=card.getAttribute('data-toggle-for');const inp=document.getElementById(id);if(inp){inp.checked=!inp.checked;inp.dispatchEvent(new Event('change'));}});});

  /* Timezone input */
  var tzInput=document.getElementById('timezone-input');
  if(tzInput)tzInput.addEventListener('input',function(){state.timezone=tzInput.value.trim();});

  /* Sub-wizard nav */
  const nextGW=document.getElementById('btn-next-gw');if(nextGW)nextGW.addEventListener('click',function(){state.step=11;render();});
  const nextIntro=document.getElementById('btn-next-intro');if(nextIntro)nextIntro.addEventListener('click',function(){state.step=21;render();});
  const nextAuto=document.getElementById('btn-next-auto');if(nextAuto)nextAuto.addEventListener('click',function(){state.step=31;render();});
  const nextPower=document.getElementById('btn-next-power');if(nextPower)nextPower.addEventListener('click',function(){state.step=41;render();});

  /* Migration */
  const migYes=document.getElementById('btn-migrate-yes');
  if(migYes)migYes.addEventListener('click',async function(){
    state.migrationChoice=true;render();
    const data=await fetchMigrationDiscover();
    state.migrationConfigs=data.configs||data||[];
    if(state.migrationConfigs.length===0){state.migrationChoice=false;state.step=nextFlow(state.step);}
    render();
  });
  const migNo=document.getElementById('btn-migrate-no');
  if(migNo)migNo.addEventListener('click',function(){state.migrationChoice=false;state.step=nextFlow(state.step);render();});
  const migSkip=document.getElementById('btn-mig-skip');
  if(migSkip)migSkip.addEventListener('click',function(){state.migrationChoice=false;state.migrationSelected=null;state.step=nextFlow(state.step);render();});
  /* Migration config selection */
  document.querySelectorAll('[data-mig-idx]').forEach(function(el){el.addEventListener('click',function(){
    const selBtn=document.getElementById('btn-mig-select');if(selBtn)selBtn.disabled=false;
  });});
  const migSelect=document.getElementById('btn-mig-select');
  if(migSelect)migSelect.addEventListener('click',async function(){
    const radios=document.querySelectorAll('input[name=mig]');let idx=-1;
    radios.forEach(function(r){if(r.checked)idx=parseInt(r.value);});
    if(idx<0)return;
    const cfg=state.migrationConfigs[idx];
    state.migrationSelected=cfg.path;
    migSelect.disabled=true;migSelect.textContent='Loading\u2026';
    const payload=await fetchMigrationLoad(cfg.path);
    state.migrationPayload=payload;
    state.migrateTools=(payload.tools||[]).slice();
    state.migrateSkills=(payload.skills||[]).slice();
    /* Pre-fill state from migration */
    if(payload.bot_name)state.botName=payload.bot_name;
    if(payload.provider&&payload.api_key){state.providers=[{provider:payload.provider,apiKey:payload.api_key,validated:true}];state.addingProvider=false;}
    if(payload.security_mode)state.securityMode=payload.security_mode;
    if(payload.owner_user_id)state.ownerUserId=payload.owner_user_id;
    if(payload.memory_store)state.memoryStore=payload.memory_store;
    if(payload.channel&&payload.channel!=='terminal'){
      if(payload.channel==='both')state.selectedChannels=['telegram','discord'];
      else state.selectedChannels=[payload.channel];
    }
    if(payload.telegram_token)state.telegramToken=payload.telegram_token;
    if(payload.discord_token)state.discordToken=payload.discord_token;
    if(payload.slack_bot_token)state.slackBotToken=payload.slack_bot_token;
    if(payload.slack_app_token)state.slackAppToken=payload.slack_app_token;
    if(payload.google_workspace_enabled)state.googleEnabled=true;
    if(payload.google_workspace_account)state.googleAccount=payload.google_workspace_account;
    if(payload.google_workspace_services){payload.google_workspace_services.forEach(function(s){if(state.googleServices.hasOwnProperty(s))state.googleServices[s]=true;});}
    render();
  });
  /* Migration tool/skill checkboxes */
  document.querySelectorAll('[data-mig-tool]').forEach(function(el){el.addEventListener('change',function(){
    const t=el.getAttribute('data-mig-tool');
    if(el.checked&&state.migrateTools.indexOf(t)<0)state.migrateTools.push(t);
    else state.migrateTools=state.migrateTools.filter(function(x){return x!==t;});
  });});
  document.querySelectorAll('[data-mig-skill]').forEach(function(el){el.addEventListener('change',function(){
    const s=el.getAttribute('data-mig-skill');
    if(el.checked&&state.migrateSkills.indexOf(s)<0)state.migrateSkills.push(s);
    else state.migrateSkills=state.migrateSkills.filter(function(x){return x!==s;});
  });});
  const migCont=document.getElementById('btn-mig-continue');
  if(migCont)migCont.addEventListener('click',function(){state.step=nextFlow(state.step);render();});

  /* Provider group radio */
  document.querySelectorAll('#provider-group .radio-card').forEach(function(card){card.addEventListener('click',function(){
    state.curProvider=card.getAttribute('data-val');state.curApiKeyValid=null;render();
  });});
  /* Verify API key */
  const verifyApi=document.getElementById('btn-verify-api');
  if(verifyApi)verifyApi.addEventListener('click',async function(){
    state.curApiKey=(document.getElementById('api-key-input').value||'').trim();
    state.curApiKeyValid='checking';render();
    const data=await verifyToken(state.curProvider,state.curApiKey);
    state.curApiKeyValid=!!data.valid;render();
  });
  /* Add provider */
  const addProv=document.getElementById('btn-add-provider');
  if(addProv)addProv.addEventListener('click',function(){
    const key=(document.getElementById('api-key-input').value||'').trim();
    const info=providerInfo(state.curProvider);
    state.providers.push({provider:state.curProvider,apiKey:key,validated:info.local||state.curApiKeyValid===true});
    state.curApiKey='';state.curApiKeyValid=null;state.addingProvider=false;
    /* Auto-pick first available provider for next add */
    const usedIds=state.providers.map(function(p){return p.provider;});
    const next=PROVIDERS.find(function(p){return usedIds.indexOf(p.id)<0;});
    state.curProvider=next?next.id:'anthropic';
    render();
  });
  const addAnother=document.getElementById('btn-add-another-provider');
  if(addAnother)addAnother.addEventListener('click',function(){state.addingProvider=true;render();});
  /* Remove provider */
  document.querySelectorAll('[data-rm-provider]').forEach(function(el){el.addEventListener('click',function(e){
    e.stopPropagation();const i=parseInt(el.getAttribute('data-rm-provider'));
    state.providers.splice(i,1);if(state.providers.length===0)state.addingProvider=true;render();
  });});
  /* Next from providers */
  const nextProv=document.getElementById('btn-next-providers');
  if(nextProv)nextProv.addEventListener('click',function(){state.addingProvider=false;state.step=nextFlow(state.step);render();});

  /* Model selection — ordered fallback chain */
  document.querySelectorAll('.model-card').forEach(function(card){card.addEventListener('click',function(){
    const mid=card.getAttribute('data-model');
    const idx=state.selectedModels.indexOf(mid);
    if(idx>=0){
      /* Already selected — remove from chain */
      state.selectedModels.splice(idx,1);
    }else{
      /* Add to end of chain */
      state.selectedModels.push(mid);
    }
    /* Primary is always first in chain */
    state.primaryModel=state.selectedModels.length>0?state.selectedModels[0]:'';
    render();
  });});
  const nextModels=document.getElementById('btn-next-models');
  if(nextModels)nextModels.addEventListener('click',function(){state.step=nextFlow(state.step);render();});

  /* Channel checkboxes */
  document.querySelectorAll('[data-ch]').forEach(function(card){card.addEventListener('click',function(e){
    if(e.target.tagName==='INPUT')return;
    const ch=card.getAttribute('data-ch');
    if(ch==='terminal'){state.selectedChannels=[];render();return;}
    const idx=state.selectedChannels.indexOf(ch);
    if(idx>=0)state.selectedChannels.splice(idx,1);else state.selectedChannels.push(ch);
    render();
  });});
  document.querySelectorAll('[data-ch-check]').forEach(function(inp){inp.addEventListener('change',function(){
    const ch=inp.getAttribute('data-ch-check');
    if(ch==='terminal'){state.selectedChannels=[];render();return;}
    if(inp.checked&&state.selectedChannels.indexOf(ch)<0)state.selectedChannels.push(ch);
    else if(!inp.checked)state.selectedChannels=state.selectedChannels.filter(function(c){return c!==ch;});
    render();
  });});
  const nextCh=document.getElementById('btn-next-channels');
  if(nextCh)nextCh.addEventListener('click',function(){state.step=nextFlow(state.step);render();});

  /* Channel setup verification */
  const verifyTg=document.getElementById('btn-verify-tg');
  if(verifyTg)verifyTg.addEventListener('click',async function(){state.telegramToken=(document.getElementById('tg-token-input').value||'').trim();state.telegramValid='checking';render();const d=await verifyToken('telegram',state.telegramToken);state.telegramValid=!!d.valid;render();});
  const verifyDc=document.getElementById('btn-verify-dc');
  if(verifyDc)verifyDc.addEventListener('click',async function(){state.discordToken=(document.getElementById('dc-token-input').value||'').trim();state.discordValid='checking';render();const d=await verifyToken('discord',state.discordToken);state.discordValid=!!d.valid;render();});
  var discoverBtn=document.getElementById('btn-discover-channels');
  if(discoverBtn)discoverBtn.addEventListener('click',async function(){var token=(document.getElementById('dc-token-input')&&document.getElementById('dc-token-input').value.trim())||state.discordToken;if(!token){alert('Enter your Discord token first.');return;}var r=await fetch('/api/discord/channels',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:token})});var d=await r.json();if(d.ok===false){alert('Discovery failed: '+(d.error||'Unknown'));return;}state.discordChannelOptions=d.guilds||[];render();});
  document.querySelectorAll('.dc-ch-check').forEach(function(inp){inp.addEventListener('change',function(){var id=inp.getAttribute('data-ch-id');if(inp.checked&&state.discordOpenChannels.indexOf(id)<0)state.discordOpenChannels.push(id);else if(!inp.checked)state.discordOpenChannels=state.discordOpenChannels.filter(function(x){return x!==id;});});});
  var dcMention=document.getElementById('dc-require-mention');
  if(dcMention)dcMention.addEventListener('change',function(){state.discordRequireMention=dcMention.checked;});
  const verifySlack=document.getElementById('btn-verify-slack');
  if(verifySlack)verifySlack.addEventListener('click',async function(){state.slackBotToken=(document.getElementById('slack-bot-input').value||'').trim();state.slackAppToken=(document.getElementById('slack-app-input').value||'').trim();state.slackValid='checking';render();const d=await verifyToken('slack',state.slackBotToken);state.slackValid=!!d.valid&&!!state.slackAppToken;render();});
  const nextChSetup=document.getElementById('btn-next-ch-setup');
  if(nextChSetup)nextChSetup.addEventListener('click',function(){
    if(document.getElementById('tg-token-input'))state.telegramToken=document.getElementById('tg-token-input').value.trim();
    if(document.getElementById('dc-token-input'))state.discordToken=document.getElementById('dc-token-input').value.trim();
    if(document.getElementById('slack-bot-input'))state.slackBotToken=document.getElementById('slack-bot-input').value.trim();
    if(document.getElementById('slack-app-input'))state.slackAppToken=document.getElementById('slack-app-input').value.trim();
    state.step=nextFlow(state.step);render();
  });

  /* Bot name */
  const nextName=document.getElementById('btn-next-name');
  if(nextName)nextName.addEventListener('click',function(){
    state.botName=(document.getElementById('bot-name-input').value||'Altaris').trim();
    state.ownerUserId=(document.getElementById('owner-user-id-input').value||'').trim();
    state.memoryStore=(document.getElementById('memory-store-input').value||'').trim();
    state.step=nextFlow(state.step);render();
  });

  /* Google Workspace */
  const gToggle=document.getElementById('google-enabled-input');
  if(gToggle)gToggle.addEventListener('change',function(){state.googleEnabled=gToggle.checked;render();});
  document.querySelectorAll('[data-gsvc]').forEach(function(el){el.addEventListener('change',function(){
    state.googleServices[el.getAttribute('data-gsvc')]=el.checked;
  });});
  const nextGoogle=document.getElementById('btn-next-google');
  if(nextGoogle)nextGoogle.addEventListener('click',function(){
    const accInp=document.getElementById('google-account-input');
    if(accInp)state.googleAccount=accInp.value.trim();
    state.step=nextFlow(state.step);render();
  });

  /* Discovery — auto-load */
  if((state.step===8)&&!state.discoveryData){
    fetchDiscovery().then(function(d){state.discoveryData=d;render();});
  }
  const nextDisc=document.getElementById('btn-next-discovery');
  if(nextDisc)nextDisc.addEventListener('click',function(){state.step=nextFlow(state.step);render();});

  /* Review — Save */
  const saveBtn=document.getElementById('btn-save-config');
  if(saveBtn)saveBtn.addEventListener('click',async function(){
    saveBtn.disabled=true;saveBtn.textContent='Saving\u2026';
    const data=await saveConfig({wizard:'all'});
    if(data.ok){if(data.warnings&&data.warnings.length>0)alert('Warning: '+data.warnings.join('; '));state.launched=true;state.testResult=data.test||{success:false};state.status=data.status||state.status;state.step=50;render();}
    else{saveBtn.disabled=false;saveBtn.textContent='\ud83d\udcbe Save Configuration';alert('Save failed: '+(data.error||'Unknown'));}
  });
  const quitBtn=document.getElementById('btn-quit-wizard');
  if(quitBtn)quitBtn.addEventListener('click',function(){if(confirm('Quit without saving?'))window.close();});

  /* General save */
  const saveGeneral=document.getElementById('btn-save-general');
  if(saveGeneral)saveGeneral.addEventListener('click',async function(){
    state.botName=(document.getElementById('bot-name-input').value||'Altaris').trim();
    state.ownerUserId=(document.getElementById('owner-user-id-input').value||'').trim();
    var tzInp=document.getElementById('timezone-input');
    if(tzInp)state.timezone=(tzInp.value||'').trim()||'UTC';
    state.memoryStore=(document.getElementById('memory-store-input').value||'').trim();
    const data=await saveConfig();
    if(data.ok){if(data.warnings&&data.warnings.length>0)alert('Warning: '+data.warnings.join('; '));state.step=14;state.status=data.status||state.status;render();}else alert('Save failed: '+(data.error||'Unknown'));
  });
  /* Integrations save (Google step) */
  const saveInteg=document.getElementById('btn-save-integrations');
  if(saveInteg)saveInteg.addEventListener('click',async function(){
    const accInp=document.getElementById('google-account-input');
    if(accInp)state.googleAccount=accInp.value.trim();
    const data=await saveConfig();
    if(data.ok){if(data.warnings&&data.warnings.length>0)alert('Warning: '+data.warnings.join('; '));state.step=24;state.status=data.status||state.status;render();}else alert('Save failed: '+(data.error||'Unknown'));
  });
  /* Automation save */
  const saveAuto=document.getElementById('btn-save-automation');
  if(saveAuto)saveAuto.addEventListener('click',async function(){
    state.mediaEnabled=!!document.getElementById('media-enabled-input').checked;
    state.webhooksEnabled=!!document.getElementById('webhooks-enabled-input').checked;
    state.authMonitorEnabled=!!document.getElementById('auth-monitor-enabled-input').checked;
    const data=await saveConfig();
    if(data.ok){if(data.warnings&&data.warnings.length>0)alert('Warning: '+data.warnings.join('; '));state.step=32;state.status=data.status||state.status;render();}else alert('Save failed: '+(data.error||'Unknown'));
  });
  /* Power — new field event bindings */
  var msli=document.getElementById('memory-search-limit-input');
  if(msli)msli.addEventListener('input',function(){state.memorySearchLimit=parseInt(msli.value)||10;});
  var mmri=document.getElementById('memory-min-relevance-input');
  if(mmri)mmri.addEventListener('input',function(){state.memoryMinRelevance=parseFloat(mmri.value)||0.3;});
  var ptri=document.getElementById('per-turn-recall-input');
  if(ptri)ptri.addEventListener('change',function(){state.perTurnRecall=ptri.checked;render();});
  var srdi=document.getElementById('startup-restore-days-input');
  if(srdi)srdi.addEventListener('input',function(){state.startupRestoreDays=parseInt(srdi.value)||2;});
  var hei=document.getElementById('heartbeat-enabled-input');
  if(hei)hei.addEventListener('change',function(){state.heartbeatEnabled=hei.checked;render();});
  var hii=document.getElementById('heartbeat-interval-input');
  if(hii)hii.addEventListener('input',function(){state.heartbeatIntervalMinutes=parseInt(hii.value)||30;});
  var cti=document.getElementById('compaction-threshold-input');
  if(cti)cti.addEventListener('input',function(){state.compactionThreshold=parseInt(cti.value)||80;});
  var rlmi=document.getElementById('rate-limit-messages-input');
  if(rlmi)rlmi.addEventListener('input',function(){state.rateLimitMessages=parseInt(rlmi.value)||20;});
  var rlwi=document.getElementById('rate-limit-window-input');
  if(rlwi)rlwi.addEventListener('input',function(){state.rateLimitWindowSeconds=parseInt(rlwi.value)||60;});
  var trlei=document.getElementById('token-rate-limit-enabled-input');
  if(trlei)trlei.addEventListener('change',function(){state.tokenRateLimitEnabled=trlei.checked;render();});
  var trlphi=document.getElementById('token-rate-limit-per-hour-input');
  if(trlphi)trlphi.addEventListener('input',function(){state.tokenRateLimitPerHour=parseInt(trlphi.value)||100000;});
  var ptzi=document.getElementById('power-timezone-input');
  if(ptzi)ptzi.addEventListener('input',function(){state.timezone=ptzi.value.trim()||'UTC';});
  /* Power save */
  const savePow=document.getElementById('btn-save-power');
  if(savePow)savePow.addEventListener('click',async function(){
    state.extensionsEnabled=!!document.getElementById('extensions-enabled-input').checked;
    state.skillsEnabled=!!document.getElementById('skills-enabled-input').checked;
    state.modelSwitchingEnabled=!!document.getElementById('model-switch-enabled-input').checked;
    state.browserEnabled=!!document.getElementById('browser-enabled-input').checked;
    state.desktopControlEnabled=!!document.getElementById('desktop-enabled-input').checked;
    state.terminalControlEnabled=!!document.getElementById('terminal-enabled-input').checked;
    const data=await saveConfig();
    if(data.ok){if(data.warnings&&data.warnings.length>0)alert('Warning: '+data.warnings.join('; '));state.step=42;state.status=data.status||state.status;render();}else alert('Save failed: '+(data.error||'Unknown'));
  });
}

/* ============ BOOT ============ */
loadStatus();
render();
</script>
</body>
</html>
"""


# --------------------------------------------------------------------------- #
# Validation helpers                                                           #
# --------------------------------------------------------------------------- #

def _validate_token(provider: str, token: str) -> tuple[bool, Optional[str]]:
    try:
        fn = {
            "telegram": _validate_telegram,
            "discord": _validate_discord,
            "anthropic": _validate_anthropic,
            "openai": _validate_openai,
            "google": _validate_google,
            "slack": _validate_slack,
            "deepseek": _validate_deepseek,
            "mistral": _validate_mistral,
            "groq": _validate_groq,
            "together": _validate_together,
            "kimi": _validate_kimi,
        }.get(provider)
        if fn:
            return fn(token)
        if provider == "ollama":
            return _validate_ollama(token)
        if provider in ("minimax",):
            # Accept optimistically for providers without easy validation
            return (True, None) if token else (False, "Token is required")
        return False, f"Unknown provider: {provider}"
    except Exception as exc:
        return False, str(exc)


def _validate_telegram(token: str) -> tuple[bool, Optional[str]]:
    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("description", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_discord(token: str) -> tuple[bool, Optional[str]]:
    url = "https://discord.com/api/v10/users/@me"
    req = Request(url, headers={"Authorization": f"Bot {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized — check your token"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_anthropic(token: str) -> tuple[bool, Optional[str]]:
    req = Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": "claude-sonnet-4-20250514", "max_tokens": 1, "messages": [{"role": "user", "content": "ping"}]}).encode("utf-8"),
        headers={
            "x-api-key": token,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 400:
            return True, None  # Bad request means auth succeeded
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_openai(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_google(token: str) -> tuple[bool, Optional[str]]:
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={token}"
    try:
        with urlopen(url, timeout=10):
            return True, None
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_slack(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://slack.com/api/auth.test", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("error", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_deepseek(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.deepseek.com/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_mistral(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.mistral.ai/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_groq(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.groq.com/openai/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_together(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.together.xyz/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_kimi(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.moonshot.cn/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_ollama(url_or_token: str) -> tuple[bool, Optional[str]]:
    base = url_or_token.rstrip("/") if url_or_token else "http://localhost:11434"
    if not base.startswith("http"):
        base = "http://localhost:11434"
    url = f"{base}/api/tags"
    try:
        with urlopen(url, timeout=5):
            return True, None
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, f"Cannot reach Ollama at {base}: {e.reason}"


def _test_channel_connection(cfg: Config) -> dict:
    result: dict = {"channel": None, "success": False, "error": None}
    try:
        if cfg.telegram_enabled and cfg.telegram_token:
            valid, error = _validate_telegram(cfg.telegram_token)
            result.update({"channel": "telegram", "success": valid, "error": error})
        elif cfg.discord_enabled and cfg.discord_token:
            valid, error = _validate_discord(cfg.discord_token)
            result.update({"channel": "discord", "success": valid, "error": error})
        elif getattr(cfg, "slack_enabled", False) and cfg.slack_bot_token:
            valid, error = _validate_slack(cfg.slack_bot_token)
            result.update({"channel": "slack", "success": valid, "error": error})
        else:
            result["channel"] = "terminal"
            result["success"] = True
    except Exception as exc:
        result["error"] = str(exc)
    return result


# --------------------------------------------------------------------------- #
# HTTP Handler                                                                 #
# --------------------------------------------------------------------------- #

class _WizardHandler(BaseHTTPRequestHandler):
    server_ref: "SetupServer" = None  # type: ignore[assignment]

    def log_message(self, fmt, *args):
        pass  # Suppress default request logging

    # ---- routing ----

    def do_GET(self):
        if self.path == "/" or self.path.startswith("/?") or self.path == "/index.html":
            self._send_html(WIZARD_HTML)
        elif self.path.startswith("/api/status"):
            self._handle_status()
        elif self.path.startswith("/api/migration/discover"):
            self._handle_migration_discover()
        elif self.path.startswith("/api/discovery"):
            self._handle_discovery()
        else:
            self._send_json({"error": "not found"}, status=404)

    def do_POST(self):
        if self.path == "/api/setup":
            self._handle_setup()
        elif self.path == "/api/validate-token":
            self._handle_validate_token()
        elif self.path == "/api/migration/load":
            self._handle_migration_load()
        elif self.path == "/api/discord/channels":
            self._handle_discord_channels()
        else:
            self._send_json({"error": "not found"}, status=404)

    # ---- status ----

    def _handle_status(self):
        cfg = Config.load()
        data: dict = {
            "configured": False,
            "channels": [],
            "providers": [],
            "bot_name": "Altaris",
            "provider": "anthropic",
            "primary_model": "",
            "security_mode": "standard",
            "owner_user_id": "",
            "memory_store": "",
            "google_workspace": {"enabled": False, "account": ""},
            "google_services": [],
            "automation": {
                "media_enabled": False,
                "webhooks_enabled": False,
                "auth_monitor_enabled": False,
            },
            "power": {
                "extensions_enabled": True,
                "skills_enabled": True,
                "model_switching_enabled": True,
                "browser_enabled": False,
                "desktop_control_enabled": False,
                "terminal_control_enabled": False,
            },
        }
        if cfg:
            data["configured"] = bool(cfg.api_key)
            data["bot_name"] = cfg.bot_name
            data["provider"] = cfg.provider_name
            data["primary_model"] = getattr(cfg, "model", "")
            data["fallback_model"] = getattr(cfg, "fallback_model", "")
            data["selected_models"] = getattr(cfg, "_selected_models", [])
            data["fallback_chain"] = getattr(cfg, "_fallback_chain", [])
            data["security_mode"] = getattr(cfg, "security_mode", "standard")
            data["owner_user_id"] = getattr(cfg, "owner_user_id", "")
            data["memory_store"] = getattr(cfg, "memory_store", "")
            data["timezone"] = getattr(cfg, "timezone", "UTC")
            data["discord_open_channels"] = getattr(cfg, "discord_open_channels", [])
            channels = []
            if cfg.discord_enabled:
                channels.append("discord")
            if cfg.telegram_enabled:
                channels.append("telegram")
            if getattr(cfg, "slack_enabled", False):
                channels.append("slack")
            data["channels"] = channels
            # Provider list
            providers_list = []
            if cfg.provider_name and cfg.api_key:
                providers_list.append({"provider": cfg.provider_name, "has_key": True})
            extra_providers = getattr(cfg, "_extra_providers", None)
            if isinstance(extra_providers, list):
                for ep in extra_providers:
                    if isinstance(ep, dict):
                        providers_list.append({
                            "provider": ep.get("provider", ""),
                            "has_key": bool(ep.get("api_key")),
                        })
            data["providers"] = providers_list
            # Tools config
            tools = getattr(cfg, "_tools_config", {}) or {}
            gw = tools.get("google_workspace", {}) if isinstance(tools, dict) else {}
            data["google_workspace"] = {
                "enabled": bool(gw.get("enabled", False)),
                "account": gw.get("account", ""),
            }
            data["google_services"] = gw.get("services", []) if isinstance(gw, dict) else []
            data["automation"] = {
                "media_enabled": bool(tools.get("video", {}).get("enabled", False)),
                "webhooks_enabled": bool(
                    getattr(cfg, "webhooks_enabled", False) or tools.get("webhooks", {}).get("enabled", False)
                ),
                "auth_monitor_enabled": bool(tools.get("auth_monitor", {}).get("enabled", False)),
            }
            data["power"] = {
                "extensions_enabled": bool(getattr(cfg, "extensions_enabled", True)),
                "skills_enabled": bool(tools.get("skills", {}).get("enabled", True)),
                "model_switching_enabled": bool(tools.get("model_control", {}).get("enabled", True)),
                "browser_enabled": bool(tools.get("browser", {}).get("enabled", False)),
                "desktop_control_enabled": bool(tools.get("desktop_control", {}).get("enabled", False)),
                "terminal_control_enabled": bool(tools.get("terminal_control", {}).get("enabled", False)),
            }
            data["heartbeat"] = {
                "enabled": bool(getattr(cfg, "heartbeat_enabled", False)),
                "interval_minutes": int(getattr(cfg, "heartbeat_interval_minutes", 30)),
            }
            data["memory_settings"] = {
                "search_limit": int(getattr(cfg, "memory_search_limit", 10)),
                "min_relevance": float(getattr(cfg, "memory_min_relevance", 0.3)),
                "per_turn_recall": bool(getattr(cfg, "per_turn_recall", True)),
            }
            data["bot_settings"] = {
                "compaction_threshold": int(getattr(cfg, "compaction_threshold", 80)),
                "startup_restore_days": int(getattr(cfg, "startup_restore_days", 2)),
                "timezone": str(getattr(cfg, "timezone", "UTC")),
            }
            data["rate_limit"] = {
                "max_messages": int(getattr(cfg, "rate_limit_messages", 20)),
                "window_seconds": int(getattr(cfg, "rate_limit_window_seconds", 60)),
            }
            data["token_rate_limit"] = {
                "enabled": bool(getattr(cfg, "token_rate_limit_enabled", False)),
                "per_hour": int(getattr(cfg, "token_rate_limit_per_hour", 100000)),
            }
            data["discord_require_mention"] = bool(getattr(cfg, "discord_require_mention", True))
        self._send_json(data)

    # ---- setup (save) ----

    def _handle_setup(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"ok": False, "error": "invalid JSON"}, status=400)
            return

        cfg = Config.load() or Config()
        cfg.bot_name = body.get("bot_name", cfg.bot_name) or cfg.bot_name or "Altaris"

        # Providers — first one becomes primary
        providers = body.get("providers", [])
        if providers and isinstance(providers, list) and len(providers) > 0:
            primary = providers[0]
            cfg.provider_name = primary.get("provider", cfg.provider_name)
            api_key = primary.get("api_key")
            # Ollama: URL goes to ollama_base_url, not api_key
            if cfg.provider_name == "ollama":
                if api_key:
                    cfg.ollama_base_url = api_key if api_key.startswith("http") else f"http://{api_key}"
                cfg.api_key = "ollama"  # sentinel so save() guard passes
            elif api_key:
                cfg.api_key = api_key
            elif cfg.provider_name == "anthropic" and getattr(cfg, "anthropic_api_key", ""):
                cfg.api_key = cfg.anthropic_api_key
            elif cfg.provider_name == "openai" and getattr(cfg, "openai_api_key", ""):
                cfg.api_key = cfg.openai_api_key
            elif cfg.provider_name == "google" and getattr(cfg, "google_api_key", ""):
                cfg.api_key = cfg.google_api_key
            elif cfg.provider_name == "qwen" and getattr(cfg, "qwen_api_key", ""):
                cfg.api_key = cfg.qwen_api_key

            # Track the selected extra providers exactly as the wizard sent them.
            cfg._extra_providers = providers[1:]
            selected_extra = {str(ep.get("provider", "")).strip() for ep in providers[1:] if isinstance(ep, dict)}

            # Clear removed extras so re-save reflects the UI accurately.
            if cfg.provider_name != "anthropic" and "anthropic" not in selected_extra:
                cfg.anthropic_api_key = ""
            if cfg.provider_name != "openai" and "openai" not in selected_extra:
                cfg.openai_api_key = ""
            if cfg.provider_name != "google" and "google" not in selected_extra:
                cfg.google_api_key = ""
            if cfg.provider_name != "qwen" and "qwen" not in selected_extra:
                cfg.qwen_api_key = ""

            # Map extra providers to per-provider key fields for persistence.
            for ep in providers[1:]:
                ep_name = str(ep.get("provider", "")).strip()
                ep_key = ep.get("api_key", "")
                if ep_name == "anthropic":
                    if ep_key:
                        cfg.anthropic_api_key = ep_key
                elif ep_name == "openai":
                    if ep_key:
                        cfg.openai_api_key = ep_key
                elif ep_name == "google":
                    if ep_key:
                        cfg.google_api_key = ep_key
                elif ep_name == "qwen":
                    if ep_key:
                        cfg.qwen_api_key = ep_key
                elif ep_name == "ollama":
                    cfg.ollama_base_url = (ep_key if ep_key.startswith("http") else f"http://{ep_key}") if ep_key else (cfg.ollama_base_url or "http://localhost:11434/v1")
                else:
                    # Generic provider (deepseek, mistral, groq, together, kimi, minimax, etc.)
                    if not hasattr(cfg, 'extra_api_keys') or cfg.extra_api_keys is None:
                        cfg.extra_api_keys = {}
                    if ep_key:
                        cfg.extra_api_keys[ep_name] = {'apiKey': ep_key}

            # Clear removed generic extras
            if hasattr(cfg, 'extra_api_keys') and cfg.extra_api_keys:
                cfg.extra_api_keys = {k: v for k, v in cfg.extra_api_keys.items() if k in selected_extra}
        else:
            provider = body.get("provider")
            if provider:
                cfg.provider_name = provider
            api_key = body.get("api_key")
            if api_key is not None:
                if provider == "ollama":
                    cfg.ollama_base_url = api_key if api_key.startswith("http") else f"http://{api_key}"
                    cfg.api_key = "ollama"
                else:
                    cfg.api_key = api_key

        # Models — primary + fallback
        primary_model = body.get("primary_model")
        if primary_model:
            cfg.model = primary_model
        fallback_models = body.get("fallback_models", [])
        if fallback_models and isinstance(fallback_models, list) and len(fallback_models) > 0:
            cfg.fallback_model = fallback_models[0]
            cfg._fallback_chain = fallback_models  # full ordered chain after primary
        selected_models = body.get("selected_models", [])
        if selected_models:
            cfg._selected_models = selected_models
        if not primary_model:
            # Keep defaults based on provider
            if cfg.provider_name == "openai":
                cfg.model = cfg.model or "gpt-5.2"
                cfg.fallback_model = cfg.fallback_model or "gpt-4o-mini"
            elif cfg.provider_name == "google":
                cfg.model = cfg.model or "gemini-3.1-pro-preview"
                cfg.fallback_model = cfg.fallback_model or "gemini-2.5-flash"
            elif cfg.provider_name == "anthropic":
                cfg.model = cfg.model or "claude-sonnet-4-6"
                cfg.fallback_model = cfg.fallback_model or "claude-haiku-4-5-20251001"

        # Channels — multi-select
        selected_channels = body.get("selected_channels", [])
        telegram_token = body.get("telegram_token", cfg.telegram_token or "")
        discord_token = body.get("discord_token", cfg.discord_token or "")
        slack_bot_token = body.get("slack_bot_token", cfg.slack_bot_token or "")
        slack_app_token = body.get("slack_app_token", cfg.slack_app_token or "")

        cfg.telegram_enabled = "telegram" in selected_channels and bool(telegram_token)
        cfg.telegram_token = telegram_token if cfg.telegram_enabled else (cfg.telegram_token or "")
        cfg.discord_enabled = "discord" in selected_channels and bool(discord_token)
        cfg.discord_token = discord_token if cfg.discord_enabled else (cfg.discord_token or "")
        cfg.discord_open_channels = body.get("discord_open_channels", cfg.discord_open_channels or [])
        cfg.discord_require_mention = body.get("discord_require_mention", getattr(cfg, "discord_require_mention", True))
        cfg.slack_enabled = "slack" in selected_channels and bool(slack_bot_token) and bool(slack_app_token)
        cfg.slack_bot_token = slack_bot_token if cfg.slack_enabled else (cfg.slack_bot_token or "")
        cfg.slack_app_token = slack_app_token if cfg.slack_enabled else (cfg.slack_app_token or "")

        # Security — default to standard
        security_mode = body.get("security_mode", cfg.security_mode or "standard")
        valid_modes = ("open", "standard", "sandboxed", "secured", "encrypted")
        if security_mode in valid_modes:
            cfg.security_mode = security_mode

        cfg.owner_user_id = body.get("owner_user_id", getattr(cfg, "owner_user_id", "")) or getattr(cfg, "owner_user_id", "")
        cfg.timezone = str(body.get("timezone", getattr(cfg, "timezone", "UTC") or "UTC"))
        memory_store = body.get("memory_store")
        if isinstance(memory_store, str) and memory_store.strip():
            cfg.memory_store = memory_store.strip()

        cfg.extensions_enabled = bool(body.get("extensions_enabled", getattr(cfg, "extensions_enabled", True)))
        cfg.webhooks_enabled = bool(body.get("webhooks_enabled", getattr(cfg, "webhooks_enabled", False)))

        # Power wizard — advanced settings
        cfg.heartbeat_enabled = bool(body.get("heartbeat_enabled", getattr(cfg, "heartbeat_enabled", False)))
        cfg.heartbeat_interval_minutes = int(body.get("heartbeat_interval_minutes", getattr(cfg, "heartbeat_interval_minutes", 30)))
        cfg.compaction_threshold = int(body.get("compaction_threshold", getattr(cfg, "compaction_threshold", 80)))
        cfg.memory_search_limit = int(body.get("memory_search_limit", getattr(cfg, "memory_search_limit", 10)))
        cfg.memory_min_relevance = float(body.get("memory_min_relevance", getattr(cfg, "memory_min_relevance", 0.3)))
        cfg.per_turn_recall = bool(body.get("per_turn_recall", getattr(cfg, "per_turn_recall", True)))
        cfg.startup_restore_days = int(body.get("startup_restore_days", getattr(cfg, "startup_restore_days", 2)))
        cfg.rate_limit_messages = int(body.get("rate_limit_messages", getattr(cfg, "rate_limit_messages", 20)))
        cfg.rate_limit_window_seconds = int(body.get("rate_limit_window_seconds", getattr(cfg, "rate_limit_window_seconds", 60)))
        cfg.token_rate_limit_enabled = bool(body.get("token_rate_limit_enabled", getattr(cfg, "token_rate_limit_enabled", False)))
        cfg.token_rate_limit_per_hour = int(body.get("token_rate_limit_per_hour", getattr(cfg, "token_rate_limit_per_hour", 100000)))

        # Tools config
        tools = dict(getattr(cfg, "_tools_config", {}) or {})

        def upsert_tool(name, enabled=None, **extra):
            current = dict(tools.get(name, {}) or {})
            if enabled is not None:
                current["enabled"] = bool(enabled)
            current.update({k: v for k, v in extra.items() if v is not None and v != ""})
            tools[name] = current

        # Google Workspace with services
        gw_enabled = body.get("google_workspace_enabled", tools.get("google_workspace", {}).get("enabled", False))
        gw_account = body.get("google_workspace_account", tools.get("google_workspace", {}).get("account", ""))
        gw_services = body.get("google_workspace_services", tools.get("google_workspace", {}).get("services", []))
        gw_current = dict(tools.get("google_workspace", {}) or {})
        gw_current["enabled"] = bool(gw_enabled)
        if gw_account:
            gw_current["account"] = gw_account
        if isinstance(gw_services, list):
            gw_current["services"] = gw_services
        tools["google_workspace"] = gw_current

        upsert_tool("video", body.get("media_enabled", tools.get("video", {}).get("enabled", False)))
        upsert_tool("webhooks", body.get("webhooks_enabled", tools.get("webhooks", {}).get("enabled", False)))
        upsert_tool("auth_monitor", body.get("auth_monitor_enabled", tools.get("auth_monitor", {}).get("enabled", False)))
        upsert_tool("skills", body.get("skills_enabled", tools.get("skills", {}).get("enabled", True)))
        upsert_tool("model_control", body.get("model_switching_enabled", tools.get("model_control", {}).get("enabled", True)))
        upsert_tool("browser", body.get("browser_enabled", tools.get("browser", {}).get("enabled", False)))
        upsert_tool("desktop_control", body.get("desktop_control_enabled", tools.get("desktop_control", {}).get("enabled", False)))
        upsert_tool("terminal_control", body.get("terminal_control_enabled", tools.get("terminal_control", {}).get("enabled", False)))
        cfg._tools_config = tools

        # Migration
        mig_source = body.get("migration_source")
        mig_tools = body.get("migrate_tools", [])
        mig_skills = body.get("migrate_skills", [])
        migration_errors = []
        if mig_source:
            if mig_tools:
                try:
                    migrate_selected_tools(cfg, mig_source, mig_tools)
                except Exception as exc:
                    migration_errors.append(f"tool migration failed: {exc}")
            if mig_skills:
                try:
                    migrate_selected_skills(str(DEFAULT_CONFIG_DIR), mig_source, mig_skills)
                except Exception as exc:
                    migration_errors.append(f"skill migration failed: {exc}")

        try:
            cfg.save()
            test_result = _test_channel_connection(cfg)
            if self.server_ref:
                self.server_ref._config = cfg
                self.server_ref._setup_complete = True
            status_payload = self._status_from_config(cfg)
            self._send_json({"ok": True, "test": test_result, "status": status_payload, "warnings": migration_errors})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=500)

    def _status_from_config(self, cfg: Config) -> dict:
        tools = getattr(cfg, "_tools_config", {}) or {}
        channels = []
        if cfg.discord_enabled:
            channels.append("discord")
        if cfg.telegram_enabled:
            channels.append("telegram")
        if getattr(cfg, "slack_enabled", False):
            channels.append("slack")
        gw = tools.get("google_workspace", {}) if isinstance(tools, dict) else {}
        return {
            "configured": bool(cfg.api_key),
            "channels": channels,
            "bot_name": cfg.bot_name,
            "provider": cfg.provider_name,
            "primary_model": getattr(cfg, "model", ""),
            "fallback_model": getattr(cfg, "fallback_model", ""),
            "selected_models": getattr(cfg, "_selected_models", []),
            "fallback_chain": getattr(cfg, "_fallback_chain", []),
            "security_mode": getattr(cfg, "security_mode", "standard"),
            "owner_user_id": getattr(cfg, "owner_user_id", ""),
            "memory_store": getattr(cfg, "memory_store", ""),
            "timezone": getattr(cfg, "timezone", "UTC"),
            "discord_open_channels": getattr(cfg, "discord_open_channels", []),
            "discord_require_mention": bool(getattr(cfg, "discord_require_mention", True)),
            "google_workspace": {
                "enabled": bool(gw.get("enabled", False)),
                "account": gw.get("account", ""),
            },
            "google_services": gw.get("services", []) if isinstance(gw, dict) else [],
            "automation": {
                "media_enabled": bool(tools.get("video", {}).get("enabled", False)),
                "webhooks_enabled": bool(tools.get("webhooks", {}).get("enabled", False)),
                "auth_monitor_enabled": bool(tools.get("auth_monitor", {}).get("enabled", False)),
            },
            "power": {
                "extensions_enabled": bool(getattr(cfg, "extensions_enabled", True)),
                "skills_enabled": bool(tools.get("skills", {}).get("enabled", True)),
                "model_switching_enabled": bool(tools.get("model_control", {}).get("enabled", True)),
                "browser_enabled": bool(tools.get("browser", {}).get("enabled", False)),
                "desktop_control_enabled": bool(tools.get("desktop_control", {}).get("enabled", False)),
                "terminal_control_enabled": bool(tools.get("terminal_control", {}).get("enabled", False)),
            },
            "heartbeat": {
                "enabled": bool(getattr(cfg, "heartbeat_enabled", False)),
                "interval_minutes": int(getattr(cfg, "heartbeat_interval_minutes", 30)),
            },
            "memory_settings": {
                "search_limit": int(getattr(cfg, "memory_search_limit", 10)),
                "min_relevance": float(getattr(cfg, "memory_min_relevance", 0.3)),
                "per_turn_recall": bool(getattr(cfg, "per_turn_recall", True)),
            },
            "bot_settings": {
                "compaction_threshold": int(getattr(cfg, "compaction_threshold", 80)),
                "startup_restore_days": int(getattr(cfg, "startup_restore_days", 2)),
                "timezone": str(getattr(cfg, "timezone", "UTC")),
            },
            "rate_limit": {
                "max_messages": int(getattr(cfg, "rate_limit_messages", 20)),
                "window_seconds": int(getattr(cfg, "rate_limit_window_seconds", 60)),
            },
            "token_rate_limit": {
                "enabled": bool(getattr(cfg, "token_rate_limit_enabled", False)),
                "per_hour": int(getattr(cfg, "token_rate_limit_per_hour", 100000)),
            },
        }

    # ---- discord channel discovery ----

    def _handle_discord_channels(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"ok": False, "error": "invalid JSON"}, status=400)
            return
        token = body.get("token", "")
        if not token:
            self._send_json({"ok": False, "error": "token required"}, status=400)
            return
        try:
            import json as _json
            from urllib.request import Request as _Req, urlopen as _urlopen
            headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}

            def _discord_get(url):
                req = _Req(url, headers=headers)
                with _urlopen(req, timeout=10) as resp:
                    return _json.loads(resp.read().decode())

            guilds_data = _discord_get("https://discord.com/api/v10/users/@me/guilds")
            guilds = []
            for guild in guilds_data[:5]:
                gid = guild.get("id")
                gname = guild.get("name", "Unknown")
                try:
                    channels_data = _discord_get(f"https://discord.com/api/v10/guilds/{gid}/channels")
                    text_channels = [
                        {"id": ch["id"], "name": ch["name"], "type": ch["type"]}
                        for ch in channels_data
                        if ch.get("type") in (0, 5)
                    ]
                    guilds.append({"guild_id": gid, "guild_name": gname, "channels": text_channels})
                except Exception:
                    guilds.append({"guild_id": gid, "guild_name": gname, "channels": []})
            self._send_json({"guilds": guilds})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)})

    # ---- validate token ----

    def _handle_validate_token(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"valid": False, "error": "invalid JSON"}, status=400)
            return
        provider = body.get("provider", "")
        token = body.get("token", "")
        if not token and provider != "ollama":
            self._send_json({"valid": False, "error": "Token is required"})
            return
        valid, error = _validate_token(provider, token)
        self._send_json({"valid": valid, "error": error})

    # ---- migration ----

    def _handle_migration_discover(self):
        try:
            configs = discover_configs()
            self._send_json({"configs": configs})
        except Exception as exc:
            self._send_json({"configs": [], "error": str(exc)})

    def _handle_migration_load(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"error": "invalid JSON"}, status=400)
            return
        path = body.get("path", "")
        if not path:
            self._send_json({"error": "path is required"}, status=400)
            return
        try:
            payload = load_migration_payload(path)
            self._send_json(payload)
        except Exception as exc:
            self._send_json({"error": str(exc)}, status=500)

    # ---- discovery ----

    def _handle_discovery(self):
        try:
            cfg = Config.load()
            payload = build_discovery_payload(cfg)
            self._send_json(payload)
        except Exception as exc:
            self._send_json({"error": str(exc)}, status=500)

    # ---- helpers ----

    def _read_json_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b"{}"
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return None

    def _send_html(self, html: str):
        encoded = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _send_json(self, data: dict, status: int = 200):
        encoded = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


# --------------------------------------------------------------------------- #
# Server                                                                       #
# --------------------------------------------------------------------------- #

class SetupServer:
    HOST = "localhost"
    PORT = 7474

    def __init__(self, initial_wizard: str = "all"):
        self._httpd: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._setup_complete: bool = False
        self._config: Optional[Config] = None
        self.initial_wizard = initial_wizard

    @property
    def setup_complete(self) -> bool:
        return self._setup_complete

    @property
    def config(self) -> Optional[Config]:
        return self._config

    def start(self, open_browser: bool = True) -> None:
        server_ref = self

        class BoundHandler(_WizardHandler):
            pass

        BoundHandler.server_ref = server_ref
        self._httpd = HTTPServer((self.HOST, self.PORT), BoundHandler)
        self._thread = threading.Thread(
            target=self._httpd.serve_forever, daemon=True, name="setup-wizard-server"
        )
        self._thread.start()
        if open_browser:
            url = f"http://{self.HOST}:{self.PORT}"
            if self.initial_wizard and self.initial_wizard != "all":
                url += f"/?wizard={self.initial_wizard}"
            webbrowser.open(url)

    def stop(self) -> None:
        if self._httpd:
            self._httpd.shutdown()
            try:
                self._httpd.server_close()
            except Exception:
                pass
            self._httpd = None
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
