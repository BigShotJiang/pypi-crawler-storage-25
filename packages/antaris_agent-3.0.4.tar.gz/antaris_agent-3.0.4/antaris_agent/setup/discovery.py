"""Discovery payloads for the Antaris setup wizard."""

from __future__ import annotations

from typing import Any


NATIVE_TOOL_CATEGORIES = {
    "Core": [
        ("memory", "Persistent context and recall"),
        ("search", "Web and knowledge retrieval"),
        ("agents", "Multi-agent orchestration"),
        ("models", "Model routing and switching"),
    ],
    "Communication": [
        ("discord", "Discord chat interface"),
        ("telegram", "Telegram chat interface"),
        ("slack", "Slack workspace interface"),
        ("webhooks", "Webhook automation endpoints"),
    ],
    "Workspace": [
        ("google_workspace", "Gmail, Calendar, Drive, Docs, Sheets"),
        ("browser", "Browser automation and capture"),
        ("terminal_control", "Local terminal execution"),
        ("desktop_control", "Desktop automation"),
    ],
    "Media": [
        ("video", "PDF, media, and transcription flows"),
        ("document_ingest", "Document parsing and extraction"),
        ("export", "Data export and handoff"),
    ],
}

EXTENSIONS = [
    {"name": "Skills", "description": "Reusable task playbooks and guided workflows"},
    {"name": "Extensions", "description": "Local plugin and extension surfaces"},
    {"name": "Auth Monitor", "description": "Credential and auth health monitoring"},
    {"name": "Model Control", "description": "Runtime model selection and thinking controls"},
]

MCP_SERVERS = [
    {"name": "filesystem", "description": "Workspace file access bridge"},
    {"name": "browser", "description": "Browser automation / inspection bridge"},
    {"name": "github", "description": "GitHub and repository operations"},
    {"name": "google_workspace", "description": "Workspace productivity bridge"},
]

CLI_COMMANDS = [
    ("antaris init", "Create or initialize an Antaris configuration"),
    ("antaris start", "Start the Antaris agent runtime"),
    ("antaris stop", "Stop the running Antaris agent"),
    ("antaris restart", "Restart the agent and reload config"),
    ("antaris status", "Show runtime and integration status"),
    ("antaris setup", "Open the setup wizard"),
    ("antaris doctor", "Run diagnostics and health checks"),
    ("antaris logs", "Tail or inspect agent logs"),
    ("antaris config", "Inspect or edit config state"),
    ("antaris version", "Show installed version information"),
]

CHAT_COMMANDS = [
    ("!help", "Show available commands and usage"),
    ("!memory", "Inspect or query memory state"),
    ("!search", "Search memory, web, or workspace"),
    ("!agent mode", "Change agent behavior or active mode"),
    ("!sync", "Sync models, extensions, or state"),
    ("!agents", "Inspect active agents and orchestration"),
    ("!models", "List or switch available models"),
    ("!discover", "Show discovered tools and capabilities"),
    ("!extensions", "List installed extensions"),
    ("!skills", "List available skills"),
    ("!gather", "Collect context across tools and sources"),
    ("!prune", "Prune stale or noisy state"),
    ("!enrichment", "Inspect or run memory enrichment"),
    ("!decompose", "Break work into subtasks or agents"),
    ("!export", "Export data, context, or reports"),
]


def _tool_enabled(name: str, config: Any) -> bool:
    if config is None:
        defaults = {
            "memory": True,
            "search": True,
            "agents": True,
            "models": True,
            "discord": False,
            "telegram": False,
            "slack": False,
            "webhooks": False,
            "google_workspace": False,
            "browser": False,
            "terminal_control": False,
            "desktop_control": False,
            "video": False,
            "document_ingest": True,
            "export": True,
        }
        return defaults.get(name, False)

    if name == "discord":
        return bool(getattr(config, "discord_enabled", False))
    if name == "telegram":
        return bool(getattr(config, "telegram_enabled", False))
    if name == "slack":
        return bool(getattr(config, "slack_enabled", False))
    if name == "webhooks":
        return bool(getattr(config, "webhooks_enabled", False))

    tools = getattr(config, "_tools_config", {}) or {}
    if isinstance(tools, dict) and name in tools and isinstance(tools[name], dict):
        return bool(tools[name].get("enabled", False))

    if name == "models":
        return bool(getattr(config, "api_key", None))
    if name == "agents":
        return True
    if name == "memory":
        return True
    if name == "search":
        return True
    if name == "document_ingest":
        return True
    if name == "export":
        return True
    return False


def get_discovery_payload(config: Any | None = None) -> dict[str, Any]:
    tools_payload = []
    for category, items in NATIVE_TOOL_CATEGORIES.items():
        tools_payload.append(
            {
                "category": category,
                "items": [
                    {
                        "name": name,
                        "description": description,
                        "enabled": _tool_enabled(name, config),
                    }
                    for name, description in items
                ],
            }
        )

    return {
        "tools": tools_payload,
        "extensions": list(EXTENSIONS),
        "mcp_servers": list(MCP_SERVERS),
        "cli_commands": [
            {"command": command, "description": description}
            for command, description in CLI_COMMANDS
        ],
        "chat_commands": [
            {"command": command, "description": description}
            for command, description in CHAT_COMMANDS
        ],
    }


# Compatibility alias for the existing server implementation.
build_discovery_payload = get_discovery_payload
