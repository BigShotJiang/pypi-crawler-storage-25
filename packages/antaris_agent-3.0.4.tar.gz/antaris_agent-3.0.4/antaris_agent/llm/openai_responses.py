"""OpenAI Responses API provider — for Codex/ChatGPT OAuth tokens."""

import asyncio
import httpx
import json as _json
import logging
import os
from typing import Optional
from .base import LLMProvider, Message, LLMResponse, ThinkingConfig

logger = logging.getLogger("antaris_agent.llm.openai_responses")


class OpenAIResponsesProvider(LLMProvider):
    """OpenAI provider using the Responses API via ChatGPT backend.
    
    Routes through chatgpt.com/backend-api/codex/responses which accepts
    Codex OAuth identity tokens (no api.responses.write scope needed).
    
    Reads token from (in priority order):
    1. OAUTH_ACCESS_TOKEN env var (set via .env in agent workspace)
    2. api_key passed from config/auth-profiles
    """

    BASE_URL = "https://chatgpt.com/backend-api/codex"

    def __init__(self, api_key: str, model: str):
        super().__init__(api_key, model)
        # Load .env from agent config dir if present
        config_dir = os.environ.get("ANTARIS_CONFIG_DIR", "")
        if config_dir:
            env_path = os.path.join(config_dir, ".env")
            if os.path.exists(env_path):
                try:
                    with open(env_path) as f:
                        for line in f:
                            line = line.strip()
                            if line and not line.startswith("#") and "=" in line:
                                k, v = line.split("=", 1)
                                os.environ.setdefault(k.strip(), v.strip())
                except Exception:
                    pass
        # Prefer OAUTH_ACCESS_TOKEN from .env over config api_key
        env_token = os.environ.get("OAUTH_ACCESS_TOKEN", "")
        if env_token:
            self.api_key = env_token
        # Store refresh token and config dir for auto-refresh
        self._refresh_token = os.environ.get("OAUTH_REFRESH_TOKEN", "")
        self._config_dir = config_dir
        self._client = httpx.AsyncClient(timeout=180.0)

    async def _refresh_access_token(self) -> bool:
        """Attempt to refresh the Codex OAuth access token.
        
        Uses the refresh_token from .env to mint a new access_token
        via https://auth.openai.com/oauth/token.
        Returns True if refresh succeeded, False otherwise.
        """
        if not self._refresh_token:
            logger.warning("No refresh token available — cannot auto-refresh")
            return False
        
        # File lock to prevent concurrent refresh race condition.
        # OAuth refresh tokens are single-use — if two agents race to refresh,
        # the loser's token is invalidated and ALL agents get locked out.
        import fcntl
        import aiohttp
        
        lock_path = os.path.join(self._config_dir, ".env.lock") if self._config_dir else None
        lock_fd = None
        
        try:
            # Acquire exclusive file lock (prevents concurrent refresh)
            if lock_path:
                lock_fd = open(lock_path, "w")
                fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (IOError, OSError):
            # Another process is already refreshing — wait for it and re-read .env
            logger.info("Another process is refreshing token — waiting...")
            if lock_path and lock_fd:
                try:
                    fcntl.flock(lock_fd, fcntl.LOCK_EX)  # Blocking wait
                    # Re-read .env after the other process finished refreshing
                    env_path = os.path.join(self._config_dir, ".env")
                    if os.path.exists(env_path):
                        with open(env_path) as f:
                            for line in f:
                                line = line.strip()
                                if line and not line.startswith("#") and "=" in line:
                                    k, v = line.split("=", 1)
                                    if k.strip() == "OAUTH_ACCESS_TOKEN":
                                        self.api_key = v.strip()
                                    elif k.strip() == "OAUTH_REFRESH_TOKEN":
                                        self._refresh_token = v.strip()
                    logger.info("Picked up refreshed token from another process")
                    return True
                except Exception:
                    pass
                finally:
                    lock_fd.close()
            return False
        
        try:
            form_data = {
                "grant_type": "refresh_token",
                "refresh_token": self._refresh_token,
                "client_id": "app_EMoamEEZ73f0CkXaXp7hrann",
            }
            
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
                async with session.post(
                    "https://auth.openai.com/oauth/token",
                    data=form_data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                ) as resp:
                    resp.raise_for_status()
                    data = await resp.json(content_type=None)
            
            new_access = data.get("access_token", "")
            new_refresh = data.get("refresh_token", self._refresh_token)
            
            if not new_access:
                logger.error("Token refresh returned empty access_token")
                return False
            
            # Update in-memory tokens
            self.api_key = new_access
            self._refresh_token = new_refresh
            
            # Persist to .env — atomic read-modify-write with file lock held
            if self._config_dir:
                env_path = os.path.join(self._config_dir, ".env")
                try:
                    existing = {}
                    if os.path.exists(env_path):
                        with open(env_path) as f:
                            for line in f:
                                line = line.strip()
                                if line and not line.startswith("#") and "=" in line:
                                    k, v = line.split("=", 1)
                                    existing[k.strip()] = v.strip()
                    existing["OAUTH_ACCESS_TOKEN"] = new_access
                    existing["OAUTH_REFRESH_TOKEN"] = new_refresh
                    tmp_path = env_path + ".tmp"
                    with open(tmp_path, "w") as f:
                        for k, v in existing.items():
                            f.write(f"{k}={v}\n")
                    os.chmod(tmp_path, 0o600)
                    os.replace(tmp_path, env_path)
                    logger.info("Codex OAuth token refreshed and saved to .env")
                except Exception as e:
                    logger.warning("Token refreshed but failed to save .env: %s", e)
            
            return True
            
        except Exception as e:
            logger.error("Codex OAuth token refresh failed: %s", e)
            return False
        finally:
            if lock_fd:
                try:
                    fcntl.flock(lock_fd, fcntl.LOCK_UN)
                    lock_fd.close()
                except Exception:
                    pass

    @staticmethod
    def _get_version() -> str:
        try:
            from antaris_agent import __version__
            return __version__
        except Exception:
            return "unknown"

    async def close(self) -> None:
        await self._client.aclose()

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 16384,
        temperature: Optional[float] = None,
        tools=None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        use_model = model or self.model

        # Build input items (exclude system — goes in "instructions")
        input_items = []
        for m in messages:
            if m.role == "system":
                continue
            content = m.content
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        text_parts.append(block)
                content = "\n".join(text_parts)
            input_items.append({"role": m.role, "content": content})

        payload = {
            "model": use_model,
            "input": input_items,
            "store": False,
            "stream": True,
        }

        # Codex backend requires "instructions" field for system prompt
        if system:
            payload["instructions"] = system

        # Reasoning/thinking support
        if thinking and isinstance(thinking, ThinkingConfig) and thinking.enabled:
            _effort_map = {"low": "low", "medium": "medium", "high": "high", "max": "high"}
            payload["reasoning"] = {"effort": _effort_map.get(thinking.level, "medium")}

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": f"antaris-agent/{self._get_version()}",
            "Origin": "https://chatgpt.com",
            "Referer": "https://chatgpt.com/",
        }

        content = ""
        input_tokens = 0
        output_tokens = 0
        response_model = use_model
        lines_processed = 0

        try:
            async with self._client.stream(
                "POST",
                f"{self.BASE_URL}/responses",
                json=payload,
                headers=headers,
                timeout=180.0,
            ) as response:
                if response.status_code == 401:
                    body = (await response.aread()).decode()
                    # Prevent infinite refresh loops with a per-call flag
                    if not getattr(self, '_refresh_in_progress', False):
                        self._refresh_in_progress = True
                        logger.warning("Codex 401 — attempting token refresh...")
                        try:
                            if await self._refresh_access_token():
                                logger.info("Token refreshed — retrying request")
                                self._refresh_in_progress = False
                                # Retry the entire request with new token
                                return await self.complete(
                                    messages, system, model, max_tokens,
                                    temperature, tools, thinking,
                                )
                        finally:
                            self._refresh_in_progress = False
                    logger.error("Codex 401 — refresh failed or already attempted: %s", body[:200])
                    raise ValueError("Codex 401 — token expired or invalid")
                if response.status_code == 400:
                    body = (await response.aread()).decode()
                    logger.error("Codex 400: %s", body[:200])
                    raise ValueError(f"Codex bad request: {body[:200]}")
                if response.status_code == 429:
                    await response.aread()
                    retry_after = response.headers.get("retry-after", "5")
                    try:
                        wait = int(float(retry_after))
                    except (ValueError, TypeError):
                        wait = 5
                    raise RuntimeError(f"rate_limit:{wait}")
                if response.status_code != 200:
                    body = (await response.aread()).decode()
                    logger.error("Codex %d: %s", response.status_code, body[:200])
                    raise ValueError(f"Codex error {response.status_code}: {body[:200]}")

                # Parse SSE stream with periodic yields to prevent event loop starvation.
                # Without yields, the Discord heartbeat can't fire during long responses,
                # causing connection resets.
                async for line in response.aiter_lines():
                    # Yield to event loop every 20 lines to keep Discord heartbeat alive
                    lines_processed += 1
                    if lines_processed % 20 == 0:
                        await asyncio.sleep(0)

                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        event = _json.loads(data_str)
                    except _json.JSONDecodeError:
                        continue

                    event_type = event.get("type", "")

                    if event_type == "response.output_text.delta":
                        content += event.get("delta", "")
                    elif event_type == "response.completed":
                        resp = event.get("response", {})
                        response_model = resp.get("model", use_model)
                        usage = resp.get("usage", {})
                        input_tokens = usage.get("input_tokens", 0)
                        output_tokens = usage.get("output_tokens", 0)
                    elif event_type == "error":
                        err = event.get("error", {})
                        logger.error("Codex stream error: %s", err)
                        raise ValueError(f"Codex stream error: {err.get('message', str(err))}")

        except httpx.ConnectError as e:
            raise RuntimeError(f"Cannot connect to Codex backend: {e}")
        except httpx.ReadTimeout:
            # Return whatever we collected if we have content, with truncation indicator
            if content.strip():
                logger.warning("Codex read timeout after collecting %d chars — returning partial", len(content))
                content = content.strip() + "\n\n[Response truncated — connection timed out]"
            else:
                raise RuntimeError("Codex response timed out with no content")

        return LLMResponse(
            content=content.strip(),
            model=response_model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=0.0,  # Codex/ChatGPT Pro — subscription, no per-token cost
        )

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
