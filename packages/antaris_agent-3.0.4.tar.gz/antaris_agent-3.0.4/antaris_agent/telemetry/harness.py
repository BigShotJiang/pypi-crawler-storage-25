"""
Substrate Growth / Multi-Agent Telemetry Harness
=================================================

Captures structured per-event telemetry rows across up to N concurrent agents
sharing a common substrate (memory/context/pack layer) and exports them as
flat CSV and JSONL files ready for Google Sheets or BigQuery analysis.

Schema covers the full Antaris multi-agent signal space:
  timestamp, agent, role, session, event_type, query,
  latency_ms, context_window_pct, instinct_hit, ambient_propagation_id,
  pack_origin, outcome, record_id, family_id, derived_from,
  source_event, provenance, confidence, truth_state, state,
  retrieval_hit_count, reuse

Design notes
------------
* Rows are written in real time (append mode) so a crash loses at most the
  in-flight row, not the whole run.
* All fields are scalar / flat — no nested blobs — so the CSV opens cleanly
  in Google Sheets without post-processing.
* The harness is intentionally thin: it is a *collector*, not a runtime.
  Real runtime hooks should call ``SubstrateHarness.record(...)`` directly
  or use the lightweight ``SubstrateAgent`` adapter further below.
* Integration points are marked with TODO comments so the harness can be
  wired into the live Antaris-Agent runtime without refactoring this file.

Usage
-----
  python3 benchmarks/substrate_telemetry_harness.py

  # From code (real runtime wiring):
  harness = SubstrateHarness(run_id="demo-run-001", output_dir="telemetrics")
  harness.record(SubstrateEvent(agent="agent-1", role="reasoner", ...))
  harness.finalize()   # flushes + writes CSV

Emitted files
-------------
  telemetrics/substrate_<run_id>_events.jsonl   — newline-delimited JSON, one row per event
  telemetrics/substrate_<run_id>_events.csv     — flat CSV, same rows, Google-Sheets-ready

Run tests
---------
  pytest tests/test_substrate_harness.py -v
"""

from __future__ import annotations

import csv
import json
import os
import sys
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

# Outcome vocabulary — extend as needed
OutcomeType = Literal[
    "success", "fail", "corrected", "superseded", "timeout", "partial", "skipped"
]

# Truth-state vocabulary
TruthState = Literal["verified", "unverified", "contested", "retracted", "unknown"]

# Agent state vocabulary
AgentState = Literal[
    "idle", "querying", "retrieving", "reasoning", "responding",
    "waiting", "instinct_firing", "pack_applying", "error",
]

# CSV columns in stable order (must match SubstrateEvent field order)
CSV_COLUMNS = [
    "record_id",
    "run_id",
    "timestamp",
    "agent",
    "role",
    "session",
    "event_type",
    "query",
    "latency_ms",
    "context_window_pct",
    "instinct_hit",
    "ambient_propagation_id",
    "pack_origin",
    "outcome",
    "family_id",
    "derived_from",
    "source_event",
    "provenance",
    "confidence",
    "truth_state",
    "state",
    "retrieval_hit_count",
    "reuse",
    "extra",  # safety valve for ad-hoc fields; stored as JSON string
]


@dataclass
class SubstrateEvent:
    """
    One telemetry row emitted by an agent during a substrate-growth run.

    All fields are flat scalars so the row serialises directly to CSV.
    Optional fields default to None / empty strings — leave them blank rather
    than guessing; downstream analysis treats NULL as *not captured*.
    """

    # ── Identity ──────────────────────────────────────────────────────────
    agent: str
    """Agent name or id (e.g. 'agent-1', 'san', 'moro')."""

    role: str
    """Logical role of the agent (e.g. 'reasoner', 'retriever', 'pack-curator')."""

    session: str = ""
    """Session or body id this event belongs to."""

    event_type: str = "unknown"
    """Event category (e.g. 'query', 'retrieval', 'instinct_fire', 'pack_apply',
    'response', 'propagation', 'compaction', 'error')."""

    # ── Query / latency ───────────────────────────────────────────────────
    query: str = ""
    """The query or prompt driving this event (truncated to 500 chars on write)."""

    latency_ms: Optional[float] = None
    """Wall-clock latency in milliseconds for this event. Critical metric."""

    context_window_pct: Optional[float] = None
    """Fraction of the model's context window consumed at event time (0.0–1.0).
    Behaviour degrades >0.8; flag events above that threshold."""

    # ── Instinct / pack ───────────────────────────────────────────────────
    instinct_hit: bool = False
    """True if a behavioural or pack instinct fired during this event."""

    ambient_propagation_id: str = ""
    """Propagation chain id proving cross-agent learning. Same id links the
    originating event to all agents that received the knowledge propagation."""

    pack_origin: str = ""
    """Name / version of the knowledge-behaviour pack that influenced this
    event (e.g. 'pack:security-v2', 'pack:reasoning-core')."""

    # ── Outcome ───────────────────────────────────────────────────────────
    outcome: str = "unknown"
    """Result of the event: success | fail | corrected | superseded | …"""

    # ── Record / family linkage ───────────────────────────────────────────
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    """Unique id for this telemetry row."""

    family_id: str = ""
    """Groups related events into a causal family (e.g. one user query →
    multiple retrieval + reasoning events share a family_id)."""

    # ── Provenance chain ──────────────────────────────────────────────────
    derived_from: str = ""
    """record_id of the parent event this one was derived from."""

    source_event: str = ""
    """External event id that triggered this event (e.g. inbound message id)."""

    provenance: str = ""
    """Free-text or structured provenance note
    (e.g. 'memory:recall', 'pack:inject', 'ambient:propagation')."""

    # ── Confidence / truth ────────────────────────────────────────────────
    confidence: Optional[float] = None
    """Model confidence for this event (0.0–1.0)."""

    truth_state: str = "unknown"
    """Epistemics of the output: verified | unverified | contested | retracted."""

    # ── Agent state ───────────────────────────────────────────────────────
    state: str = "unknown"
    """Agent state at event time."""

    # ── Retrieval / reuse ─────────────────────────────────────────────────
    retrieval_hit_count: int = 0
    """Number of memory / knowledge items retrieved during this event."""

    reuse: bool = False
    """True if this event reused a cached / pre-computed result."""

    # ── Extra ─────────────────────────────────────────────────────────────
    extra: Dict[str, Any] = field(default_factory=dict)
    """Ad-hoc fields. Stored as a JSON string in CSV to keep the row flat."""

    # ── Injected at write time ────────────────────────────────────────────
    run_id: str = ""
    timestamp: str = ""

    def as_csv_row(self) -> Dict[str, Any]:
        """Return a flat dict suitable for csv.DictWriter."""
        d = asdict(self)
        # Truncate long queries so CSV stays readable
        if d.get("query"):
            d["query"] = d["query"][:500]
        # Serialise extra dict as JSON string
        d["extra"] = json.dumps(d["extra"]) if d["extra"] else ""
        # Booleans → 1/0 for easy spreadsheet filtering
        d["instinct_hit"] = 1 if d["instinct_hit"] else 0
        d["reuse"] = 1 if d["reuse"] else 0
        return d

    def as_jsonl_line(self) -> str:
        """Return a JSON string (no newline) for JSONL append."""
        d = asdict(self)
        return json.dumps(d, default=str)


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


class SubstrateHarness:
    """
    Real-time multi-agent telemetry collector.

    Records are appended to JSONL immediately on ``record()`` and flushed
    to CSV on ``finalize()``.  Call ``finalize()`` once per run (or use the
    context-manager form).

    Example::

        with SubstrateHarness(run_id="demo-001") as harness:
            harness.record(SubstrateEvent(agent="a1", role="reasoner",
                                          event_type="query", latency_ms=42.0))
    """

    def __init__(
        self,
        run_id: str = "",
        output_dir: str | Path = "telemetrics",
        buffer_size: int = 10_000,
    ):
        self.run_id = run_id or str(uuid.uuid4())[:8]
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        stem = f"substrate_{self.run_id}_events"
        self.jsonl_path = self.output_dir / f"{stem}.jsonl"
        self.csv_path = self.output_dir / f"{stem}.csv"

        self._buffer: List[SubstrateEvent] = []
        self._buffer_size = buffer_size
        self._event_count = 0

        # Open JSONL file for append immediately (real-time writes)
        self._jsonl_fh = open(self.jsonl_path, "a", encoding="utf-8")
        self._finalized = False

        # Write CSV header only if the file is new / empty
        self._csv_fh = open(self.csv_path, "a", newline="", encoding="utf-8")
        self._csv_writer = csv.DictWriter(
            self._csv_fh, fieldnames=CSV_COLUMNS, extrasaction="ignore"
        )
        if self.csv_path.stat().st_size == 0:
            self._csv_writer.writeheader()
            self._csv_fh.flush()

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self) -> "SubstrateHarness":
        return self

    def __exit__(self, *_) -> None:
        self.finalize()

    # ── Core API ──────────────────────────────────────────────────────────

    def record(self, event: SubstrateEvent) -> SubstrateEvent:
        """
        Record a single telemetry event.

        Stamps ``run_id`` and ``timestamp`` if not already set, appends
        to the JSONL file in real time, and buffers for CSV write.

        Returns the event (with ids stamped) for caller convenience.
        """
        if not event.run_id:
            event.run_id = self.run_id
        if not event.timestamp:
            event.timestamp = datetime.now(timezone.utc).isoformat()
        if not event.record_id:
            event.record_id = str(uuid.uuid4())

        # JSONL — real-time append
        self._jsonl_fh.write(event.as_jsonl_line() + "\n")
        self._jsonl_fh.flush()

        # Buffer for CSV
        self._buffer.append(event)
        self._event_count += 1

        # Flush CSV buffer if it grows large
        if len(self._buffer) >= self._buffer_size:
            self._flush_csv()

        return event

    def finalize(self) -> Dict[str, Any]:
        """
        Flush all buffered events to CSV and close file handles.

        Idempotent — safe to call multiple times (subsequent calls are no-ops).
        Returns a summary dict with counts and output paths.
        """
        if self._finalized:
            return {
                "run_id": self.run_id,
                "total_events": self._event_count,
                "jsonl_path": str(self.jsonl_path),
                "csv_path": str(self.csv_path),
            }

        self._flush_csv()
        self._finalized = True

        try:
            self._jsonl_fh.close()
        except Exception:
            pass
        try:
            self._csv_fh.close()
        except Exception:
            pass

        return {
            "run_id": self.run_id,
            "total_events": self._event_count,
            "jsonl_path": str(self.jsonl_path),
            "csv_path": str(self.csv_path),
        }

    # ── Helpers ───────────────────────────────────────────────────────────

    def _flush_csv(self) -> None:
        """Write buffered rows to CSV and clear the buffer."""
        for event in self._buffer:
            self._csv_writer.writerow(event.as_csv_row())
        self._csv_fh.flush()
        self._buffer.clear()

    @contextmanager
    def timed_event(
        self,
        agent: str,
        role: str,
        event_type: str = "query",
        **kwargs,
    ):
        """
        Context manager that automatically measures latency_ms.

        Usage::

            with harness.timed_event("agent-1", "reasoner", event_type="query",
                                     query="what is 2+2?") as ev:
                result = run_inference(ev.query)
                ev.outcome = "success"
                ev.confidence = 0.99
        """
        ev = SubstrateEvent(agent=agent, role=role, event_type=event_type, **kwargs)
        t0 = time.perf_counter()
        try:
            yield ev
        finally:
            ev.latency_ms = round((time.perf_counter() - t0) * 1000, 3)
            self.record(ev)

    def family_context(self, family_id: str = "") -> "_FamilyContext":
        """
        Return a helper that pre-fills family_id on every recorded event.

        Usage::

            with harness.family_context("req-abc123") as fam:
                fam.record(SubstrateEvent(agent="a1", role="r", ...))
        """
        return _FamilyContext(self, family_id or str(uuid.uuid4())[:8])

    def stats(self) -> Dict[str, Any]:
        """Return lightweight in-session stats (no file I/O)."""
        return {
            "run_id": self.run_id,
            "events_recorded": self._event_count,
            "buffer_pending": len(self._buffer),
            "jsonl_path": str(self.jsonl_path),
            "csv_path": str(self.csv_path),
        }


class _FamilyContext:
    """Helper returned by SubstrateHarness.family_context()."""

    def __init__(self, harness: SubstrateHarness, family_id: str):
        self._harness = harness
        self.family_id = family_id

    def __enter__(self) -> "_FamilyContext":
        return self

    def __exit__(self, *_) -> None:
        pass  # harness owns finalisation

    def record(self, event: SubstrateEvent) -> SubstrateEvent:
        if not event.family_id:
            event.family_id = self.family_id
        return self._harness.record(event)


# ---------------------------------------------------------------------------
# Adapter — lightweight bridge to the live AntarisEvent / pipeline system
# TODO: wire these hooks into the actual runtime once the harness is in-repo
# ---------------------------------------------------------------------------


class SubstrateAdapter:
    """
    Thin adapter that converts an existing ``AntarisEvent`` (from
    ``antaris_agent.suite.pipeline.events``) into a ``SubstrateEvent`` row
    and records it via the harness.

    This is an *opt-in* integration layer — the main pipeline does not need
    to import this file; callers can attach it as a side-channel handler.

    TODO (runtime wiring):
        1. Import SubstrateAdapter in pipeline_bridge.py or daemon startup.
        2. Create a shared SubstrateHarness for the GCVM run.
        3. Register ``adapter.handle`` as a TelemetricsCollector handler:
               collector.add_handler(adapter.handle)   # if EventEmitter pattern
           or call adapter.handle(event) from the pipeline hook.
        4. Pass ambient_propagation_id / pack_origin through AntarisEvent.payload
           so the adapter can extract them automatically.
    """

    def __init__(self, harness: SubstrateHarness, agent_id: str, role: str = "pipeline"):
        self.harness = harness
        self.agent_id = agent_id
        self.role = role

    def handle(self, antaris_event: Any) -> Optional[SubstrateEvent]:
        """
        Convert one AntarisEvent → SubstrateEvent and record it.

        Falls back gracefully if the event lacks expected attributes
        (so a bad event never crashes the runtime).
        """
        if antaris_event is None:
            return None
        try:
            payload: Dict[str, Any] = getattr(antaris_event, "payload", {}) or {}
            perf = getattr(antaris_event, "performance", None)

            ev = SubstrateEvent(
                agent=self.agent_id,
                role=self.role,
                session=getattr(antaris_event, "session_id", ""),
                event_type=str(getattr(antaris_event, "event_type", "unknown")),
                query=str(payload.get("query", payload.get("input", ""))),
                latency_ms=getattr(perf, "latency_ms", None) if perf else None,
                context_window_pct=payload.get("context_window_pct"),
                instinct_hit=bool(payload.get("instinct_hit", False)),
                ambient_propagation_id=str(payload.get("ambient_propagation_id", "")),
                pack_origin=str(payload.get("pack_origin", "")),
                outcome=str(payload.get("outcome", "unknown")),
                family_id=str(getattr(antaris_event, "trace_id", "") or ""),
                derived_from=str(payload.get("derived_from", "")),
                source_event=str(getattr(antaris_event, "event_id", "")),
                provenance=str(payload.get("provenance", "")),
                confidence=getattr(antaris_event, "confidence", None),
                truth_state=str(payload.get("truth_state", "unknown")),
                state=str(payload.get("agent_state", "unknown")),
                retrieval_hit_count=int(payload.get("retrieval_hit_count", 0)),
                reuse=bool(payload.get("reuse", False)),
                extra={
                    k: v for k, v in payload.items()
                    if k not in {
                        "query", "input", "context_window_pct", "instinct_hit",
                        "ambient_propagation_id", "pack_origin", "outcome",
                        "derived_from", "provenance", "truth_state",
                        "agent_state", "retrieval_hit_count", "reuse",
                    }
                },
            )
            return self.harness.record(ev)
        except Exception as exc:
            # Never crash the runtime due to telemetry errors
            # TODO: route to a structured error log once integrated
            print(f"[SubstrateAdapter] warn: could not record event: {exc}")
            return None


# ---------------------------------------------------------------------------
# Demo / smoke-test runner
# ---------------------------------------------------------------------------

_AGENT_ROLES = [
    ("agent-1", "reasoner"),
    ("agent-2", "retriever"),
    ("agent-3", "pack-curator"),
    ("agent-4", "validator"),
    ("agent-5", "propagator"),
    ("agent-6", "observer"),
]

_SAMPLE_QUERIES = [
    "What is the pack status for security-v2?",
    "Recall last 3 relevant memories for this context",
    "Apply pack: reasoning-core to this session",
    "Validate output truth-state against substrate ground-truth",
    "Propagate ambient signal to sibling agents",
    "Log observation: context window at 82%",
]


def run_demo(output_dir: str = "telemetrics", n_rounds: int = 6) -> Dict[str, Any]:
    """
    Simulate a 6-agent substrate-growth run and write telemetry to disk.

    This is a pure *simulation* — no real agents or LLM calls.  It is useful
    as a smoke test and to produce sample data for schema validation.

    Args:
        output_dir: Directory to write output files.
        n_rounds:   Number of event rounds to simulate per agent.

    Returns:
        Harness summary dict with paths and event count.
    """
    import random

    run_id = f"demo-{int(time.time())}"
    prop_id = str(uuid.uuid4())[:8]  # shared ambient propagation id

    print(f"\n{'='*62}")
    print(f"  Substrate Growth Telemetry Harness — Demo Run [{run_id}]")
    print(f"{'='*62}")

    with SubstrateHarness(run_id=run_id, output_dir=output_dir) as harness:
        for round_idx in range(n_rounds):
            for agent_id, role in _AGENT_ROLES:
                query = _SAMPLE_QUERIES[round_idx % len(_SAMPLE_QUERIES)]
                latency = round(random.uniform(15, 350), 2)
                ctx_pct = round(random.uniform(0.3, 0.92), 3)
                instinct = random.random() > 0.7
                reuse = random.random() > 0.6
                outcome = random.choice(["success", "success", "success", "fail", "corrected"])
                retrieval_hits = random.randint(0, 8)
                confidence = round(random.uniform(0.55, 0.99), 3)
                truth_st = random.choice(["verified", "unverified", "unverified", "unknown"])
                state = "instinct_firing" if instinct else "reasoning"

                ev = SubstrateEvent(
                    agent=agent_id,
                    role=role,
                    session=f"session-{round_idx}",
                    event_type="query" if round_idx % 2 == 0 else "retrieval",
                    query=query,
                    latency_ms=latency,
                    context_window_pct=ctx_pct,
                    instinct_hit=instinct,
                    ambient_propagation_id=prop_id if role == "propagator" or round_idx > 2 else "",
                    pack_origin=f"pack:core-v{(round_idx % 3) + 1}" if instinct else "",
                    outcome=outcome,
                    family_id=f"fam-round-{round_idx}",
                    derived_from="",
                    source_event="",
                    provenance="demo:simulation",
                    confidence=confidence,
                    truth_state=truth_st,
                    state=state,
                    retrieval_hit_count=retrieval_hits,
                    reuse=reuse,
                    extra={"round": round_idx, "sim": True},
                )
                harness.record(ev)

        summary = harness.finalize()

    print(f"\n  ✓  {summary['total_events']} events recorded")
    print(f"  ✓  JSONL  → {summary['jsonl_path']}")
    print(f"  ✓  CSV    → {summary['csv_path']}")
    print(f"{'='*62}\n")
    return summary


if __name__ == "__main__":
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "telemetrics"
    run_demo(output_dir=out_dir)
