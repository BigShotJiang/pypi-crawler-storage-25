# ============================================================================
# PROPRIETARY AND CONFIDENTIAL
# Copyright (c) 2026 Antaris Analytics LLC. All Rights Reserved.
#
# THIS SOFTWARE IS PROPRIETARY TO ANTARIS ANALYTICS LLC AND IS PROVIDED
# UNDER A NON-DISCLOSURE AGREEMENT TO AUTHORIZED RECIPIENTS ONLY.
# UNAUTHORIZED DISTRIBUTION, MODIFICATION, OR USE IS STRICTLY PROHIBITED.
# For licensing inquiries: legal@antarisanalytics.ai
# ============================================================================

from ._version import __version__
