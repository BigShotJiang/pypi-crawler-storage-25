cwlVersion: v1.2
class: CommandLineTool
doc: Run TraP with the provided input data

baseCommand: trap-run

requirements:
  DockerRequirement:
    dockerPull: git.astron.nl:5000/rd/trap:1.3.0

inputs:
  fits_files:
    doc: A list of fits files that are to be fed into TraP
    type: File[]
    inputBinding:
      valueFrom: |
        ${
          return self.map(function(f) {
            return ["-i", f.path];
          }).flat();
        }
  output_sas_id:
    doc: The sas-id of the newly generated output product, used in the export medatadata and used here for the name of the database
    type: string
    inputBinding:
      prefix: --db_name
      valueFrom: ${return "trap_" + self + ".db"}
  nr_threads:
    doc: the maximum number of threads TraP may use in parallel
    type: int
    inputBinding:
      prefix: --nr_threads

outputs: {}
