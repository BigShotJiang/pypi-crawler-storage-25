cwlVersion: v1.2
class: ExpressionTool
doc: Turn a list of strings into file objects as expected by cwl. Files are not mounted by the cwl runners if this is not done.

requirements:
  InlineJavascriptRequirement: {}

inputs:
  input_files:
    doc: List of input fits files as string, that are to be converted to file objects
    type: string[]

outputs:
  files:
    doc: List of fits files as files, as converted from the strings supplied in `input_files`
    type: File[]

expression: |
  ${
    return {
      files: inputs.input_files.map(function(path) {
        return {
          class: "File",
          location: path
        };
      })
    };
  }
