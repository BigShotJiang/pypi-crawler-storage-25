cwlVersion: v1.2
class: ExpressionTool
doc: Format a json structure in the output format expected by the POPPY/ATDB system

requirements:
  InlineJavascriptRequirement: {}

inputs: {}

outputs:
  compressed:
    type: File[]
  control:
    type: File
  ingest:
    type: File[]
  inspect:
    type: File
  logfile:
    type: File[]
  quality:
    type: File

expression: |
  ${
    return {
      compressed: [],
      control: {
        keep_input: []
      },
      ingest: [],
      inspect: {},
      logfile: [],
      quality: {
        plots: [],
        summary: {}
      }
    };
  }
