Transients Pipeline
===================

[![Documentation](https://readthedocs.org/projects/transients-pipeline/badge/?version=latest)](https://transients-pipeline.readthedocs.io/en/latest/?badge=latest)
[![PyPI Downloads](https://static.pepy.tech/personalized-badge/trap?period=monthly&units=INTERNATIONAL_SYSTEM&left_color=GREY&right_color=GREEN&left_text=Monthly+downloads)](https://pepy.tech/projects/trap)
[![PyPI](https://badge.fury.io/py/trap.svg)](https://pypi.org/project/trap/)

The Transients Pipeline (or "TraP") is a system for detecting transient
and variable sources in a stream or batch of astronomical images.
It primarily targets LOFAR data, but is also applicable to a range of other instruments.

Documentation: https://transients-pipeline.readthedocs.io/en/latest/

This is a rework of the original package hosted here:
https://github.com/transientskp/tkp
An overview of the package and it's initial design can be found in the original [TraP paper](https://ui.adsabs.harvard.edu/abs/2015A%26C....11...25S/abstract).
If you make use of TraP in work leading to a publication, we ask that you cite this reference.

The rework is focussed on performance, ease of deployment and ease of use and code maintainability.
The approach of associating sources between images is still based on the paper linked above, as
this approach has shown itself to be suitable to finding a variety of transient and variable sources.

How TraP operates (high level overview)
=======================================

The way the package is meant to operate is that it will run on astronomical images (.FITS recommended)
and will use a source finder ([PySE](https://github.com/transientskp/pyse)) to find all the sources
in a given image. This is done for all images individually. The source finder returns information on each
source extracted from the image, such as it's position, the intensity (flux) and their related errors.
In order to construct light curves/time series of each source, the sources extracted from the first image
are matched to (associated with) the sources extracted from the second image. This creates a table of known
source locations. We track the locations of each of these as we go, but we export the information of every
source extracted from every image in the export database. For more information on the export database structure,
see the [Database Reference](https://transients-pipeline.readthedocs.io/en/latest/export_database/database_reference.html)
For every source we export to the database, we also save the index of the source it was associated with in the
previous image. This creates a daisy-chain of ids we can use to reconstruct a lightcurve.

Interpreting the results
========================
We want to support a broad range of transients and variability science. During the processing therefore,
we make few assumptions about what makes a good source. Any kind of filtering on the data can be 
done afterwards. The database can be queried to select the sources in a given position or with a certain
intensity, error margin, etc.. The user can then decide what qualities make for an interesting source.
The most common way to interact with the data is to use a Jupyter Notebook, read some results from
the database and plot the results. Some basic examples can be found in the [Example Gallery](https://transients-pipeline.readthedocs.io/en/latest/example_gallery/index.html)
