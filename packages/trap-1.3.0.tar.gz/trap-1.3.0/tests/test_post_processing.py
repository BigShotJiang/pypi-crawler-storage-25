import numpy as np
import pandas as pd

from trap.io import open_db
from trap.post_processing import construct_lightcurves, construct_varmetric


def test_construct_lightcurves():
    db_engine = open_db("sqlite", "tests/data/lofar1/default_export.db")
    reconstructed_lightcurves = construct_lightcurves(db_engine, attribute="peak_flux")

    # Only one frequency band in test dataset
    assert len(reconstructed_lightcurves) == 1
    reconstructed_lightcurves = reconstructed_lightcurves[0]

    expected_nr_lightcurves = 244
    assert len(reconstructed_lightcurves) == expected_nr_lightcurves
    assert np.all(reconstructed_lightcurves.columns == ["im_0", "im_1", "im_2"])
    expected_min = [0.024638861417770386, 0.009967652505394137, -0.0012932927393839717]
    np.testing.assert_allclose(reconstructed_lightcurves.min().values, expected_min)
    expected_max = [4.383113861083984, 4.367282390594482, 4.307971477508545]
    np.testing.assert_allclose(reconstructed_lightcurves.max().values, expected_max)
    expected_median = [0.08833817765116692, 0.0776652954518795, 0.07550453921254752]
    np.testing.assert_allclose(
        reconstructed_lightcurves.median().values, expected_median
    )


def test_construct_varmetric():
    db_engine = open_db("sqlite", "tests/data/lofar1/default_export.db")
    varmetric = construct_varmetric(db_engine)
    expected_median = {
        "newsource": 121.5,
        "v_int": 0.0947170244941074,
        "eta_int": 0.9254423948357626,
        "lightcurve_max": 0.11663857847452164,
        "lightcurve_avg": 0.10800672446688017,
        "lightcurve_median": 0.10791200026869774,
        "nr_datapoints": 3.0,
        "wm_ra": 61.76276700277948,
        "av_ra_err": 0.00081821182289706,
        "wm_dec": 65.0563075845374,
        "av_dec_err": 0.0003515416590786913,
        "freq_band": 0,
        "src_ids": 121.5,
    }
    # Columns for which we don't calculate mean but test in a different way leter in the function
    otherwise_expected_columns = ["first_detection_time", "first_image"]

    col_diff = set(expected_median.keys()).difference(varmetric.columns)
    assert not col_diff, f"Expected column not found in varmetric table: {col_diff}"
    col_diff_reverse = set(varmetric.columns).difference(expected_median.keys())
    for col in otherwise_expected_columns:
        col_diff_reverse.remove(col)
    assert (
        not col_diff_reverse
    ), f"Column found in varmetric table that is not in expected dict: {col_diff_reverse}"
    for key in varmetric.columns:
        if key in otherwise_expected_columns:
            continue
        np.testing.assert_allclose(varmetric[key].median(), expected_median[key])

    # Group by detection time and check that the detection times nicely align with the image id's when selecting the first_image of the groupby
    nr_images = 3
    np.testing.assert_allclose(
        varmetric.groupby("first_detection_time").mean()["first_image"].values,
        np.arange(nr_images),
    )
