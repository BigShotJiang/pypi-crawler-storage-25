cwlVersion: v1.2
class: Workflow
doc: Parse inputs, run TraP, parse outputs.

inputs:
  data:
    doc: Input fits file locations as strings
    type: string[]
  output_sas_id:
    doc: The sas-id of the newly generated output product, used in the export medatadata and for the name of the database
    type: string
  nr_threads:
    doc: the maximum number of threads TraP may use in parallel
    type: int
    default: 1

steps:
  make_files:
    run: cwl_steps/parse_input.cwl
    in:
      input_files: data
    out: [files]

  run_trap:
    run: cwl_steps/run_trap.cwl
    in:
      fits_files: make_files/files
      output_sas_id: output_sas_id
      nr_threads: nr_threads
    out: []

  create_poppy:
    run: cwl_steps/create_poppy_json.cwl
    in: {}
    out:
        - compressed
        - control
        - ingest
        - inspect
        - logfile
        - quality

outputs:
  compressed:
    type: File[]
    outputSource: create_poppy/compressed

  control:
    type: File
    outputSource: create_poppy/control

  ingest:
    type: File[]
    outputSource: create_poppy/ingest

  inspect:
    type: File
    outputSource: create_poppy/inspect

  logfile:
    type: File[]
    outputSource: create_poppy/logfile

  quality:
    type: File
    outputSource: create_poppy/quality

requirements:
  DockerRequirement:
    dockerPull: git.astron.nl:5000/rd/trap:1.3.0
  InlineJavascriptRequirement: {}
