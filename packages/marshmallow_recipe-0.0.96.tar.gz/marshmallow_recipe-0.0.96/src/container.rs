use std::collections::HashMap;

use pyo3::prelude::*;
use pyo3::types::PyString;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[pyclass(eq, eq_int, from_py_object)]
pub enum LoadStrategy {
    DirectSlots,
    DirectDict,
    Kwargs,
}

use crate::fields::collection::CollectionKind;
use crate::fields::datetime::DateTimeFormat;
use crate::fields::length::LengthBound;
use crate::fields::range::RangeBound;

pub struct FieldCommon {
    pub optional: bool,
    pub default_value: Option<Py<PyAny>>,
    pub default_factory: Option<Py<PyAny>>,
    pub required_error: Option<Py<PyString>>,
    pub none_error: Option<Py<PyString>>,
    pub invalid_error: Py<PyString>,
    pub validator: Option<Py<PyAny>>,
}

impl Clone for FieldCommon {
    fn clone(&self) -> Self {
        Python::attach(|py| Self {
            optional: self.optional,
            default_value: self.default_value.as_ref().map(|v| v.clone_ref(py)),
            default_factory: self.default_factory.as_ref().map(|f| f.clone_ref(py)),
            required_error: self.required_error.as_ref().map(|v| v.clone_ref(py)),
            none_error: self.none_error.as_ref().map(|v| v.clone_ref(py)),
            invalid_error: self.invalid_error.clone_ref(py),
            validator: self.validator.as_ref().map(|v| v.clone_ref(py)),
        })
    }
}

pub struct DataclassField {
    pub name: String,
    pub name_interned: Py<PyString>,
    pub data_key: String,
    pub data_key_interned: Py<PyString>,
    pub slot_offset: Option<isize>,
    pub field_init: bool,
    pub field: FieldContainer,
}

impl Clone for DataclassField {
    fn clone(&self) -> Self {
        Python::attach(|py| Self {
            name: self.name.clone(),
            name_interned: self.name_interned.clone_ref(py),
            data_key: self.data_key.clone(),
            data_key_interned: self.data_key_interned.clone_ref(py),
            slot_offset: self.slot_offset,
            field_init: self.field_init,
            field: self.field.clone(),
        })
    }
}

#[allow(clippy::use_self, clippy::large_enum_variant)]
pub enum FieldContainer {
    Str {
        common: FieldCommon,
        strip_whitespaces: bool,
        post_load: Option<Py<PyAny>>,
        min_length: Option<LengthBound>,
        max_length: Option<LengthBound>,
    },
    Int {
        common: FieldCommon,
        gt: Option<RangeBound>,
        gte: Option<RangeBound>,
        lt: Option<RangeBound>,
        lte: Option<RangeBound>,
    },
    Float {
        common: FieldCommon,
        gt: Option<RangeBound>,
        gte: Option<RangeBound>,
        lt: Option<RangeBound>,
        lte: Option<RangeBound>,
    },
    Bool {
        common: FieldCommon,
    },
    Decimal {
        common: FieldCommon,
        decimal_places: Option<i32>,
        rounding: Option<Py<PyAny>>,
        gt: Option<RangeBound>,
        gte: Option<RangeBound>,
        lt: Option<RangeBound>,
        lte: Option<RangeBound>,
    },
    Date {
        common: FieldCommon,
    },
    Time {
        common: FieldCommon,
    },
    DateTime {
        common: FieldCommon,
        format: DateTimeFormat,
    },
    Uuid {
        common: FieldCommon,
    },
    Bytes {
        common: FieldCommon,
    },
    StrEnum {
        common: FieldCommon,
        enum_values: Vec<(String, Py<PyAny>)>,
        enum_cls: Py<PyAny>,
    },
    IntEnum {
        common: FieldCommon,
        enum_values: Vec<(Py<PyAny>, Py<PyAny>)>,
        enum_cls: Py<PyAny>,
    },
    StrLiteral {
        common: FieldCommon,
        values: Vec<String>,
    },
    IntLiteral {
        common: FieldCommon,
        values: Vec<Py<PyAny>>,
    },
    BoolLiteral {
        common: FieldCommon,
        values: Vec<bool>,
    },
    Any {
        common: FieldCommon,
    },
    Collection {
        common: FieldCommon,
        kind: CollectionKind,
        item: Box<FieldContainer>,
        item_validator: Option<Py<PyAny>>,
        min_length: Option<LengthBound>,
        max_length: Option<LengthBound>,
    },
    Dict {
        common: FieldCommon,
        value: Box<FieldContainer>,
        value_validator: Option<Py<PyAny>>,
    },
    Nested {
        common: FieldCommon,
        dataclass_index: usize,
    },
    Union {
        common: FieldCommon,
        variants: Vec<FieldContainer>,
    },
}

impl Clone for FieldContainer {
    fn clone(&self) -> Self {
        Python::attach(|py| match self {
            Self::Str {
                common,
                strip_whitespaces,
                post_load,
                min_length,
                max_length,
            } => Self::Str {
                common: common.clone(),
                strip_whitespaces: *strip_whitespaces,
                post_load: post_load.as_ref().map(|v| v.clone_ref(py)),
                min_length: min_length.clone(),
                max_length: max_length.clone(),
            },
            Self::Int {
                common,
                gt,
                gte,
                lt,
                lte,
            } => Self::Int {
                common: common.clone(),
                gt: gt.clone(),
                gte: gte.clone(),
                lt: lt.clone(),
                lte: lte.clone(),
            },
            Self::Float {
                common,
                gt,
                gte,
                lt,
                lte,
            } => Self::Float {
                common: common.clone(),
                gt: gt.clone(),
                gte: gte.clone(),
                lt: lt.clone(),
                lte: lte.clone(),
            },
            Self::Bool { common } => Self::Bool {
                common: common.clone(),
            },
            Self::Decimal {
                common,
                decimal_places,
                rounding,
                gt,
                gte,
                lt,
                lte,
            } => Self::Decimal {
                common: common.clone(),
                decimal_places: *decimal_places,
                rounding: rounding.as_ref().map(|r| r.clone_ref(py)),
                gt: gt.clone(),
                gte: gte.clone(),
                lt: lt.clone(),
                lte: lte.clone(),
            },
            Self::Date { common } => Self::Date {
                common: common.clone(),
            },
            Self::Time { common } => Self::Time {
                common: common.clone(),
            },
            Self::DateTime { common, format } => Self::DateTime {
                common: common.clone(),
                format: format.clone(),
            },
            Self::Uuid { common } => Self::Uuid {
                common: common.clone(),
            },
            Self::Bytes { common } => Self::Bytes {
                common: common.clone(),
            },
            Self::StrEnum {
                common,
                enum_values,
                enum_cls,
            } => Self::StrEnum {
                common: common.clone(),
                enum_values: enum_values
                    .iter()
                    .map(|(k, v)| (k.clone(), v.clone_ref(py)))
                    .collect(),
                enum_cls: enum_cls.clone_ref(py),
            },
            Self::IntEnum {
                common,
                enum_values,
                enum_cls,
            } => Self::IntEnum {
                common: common.clone(),
                enum_values: enum_values
                    .iter()
                    .map(|(k, v)| (k.clone_ref(py), v.clone_ref(py)))
                    .collect(),
                enum_cls: enum_cls.clone_ref(py),
            },
            Self::StrLiteral { common, values } => Self::StrLiteral {
                common: common.clone(),
                values: values.clone(),
            },
            Self::IntLiteral { common, values } => Self::IntLiteral {
                common: common.clone(),
                values: values.iter().map(|v| v.clone_ref(py)).collect(),
            },
            Self::BoolLiteral { common, values } => Self::BoolLiteral {
                common: common.clone(),
                values: values.clone(),
            },
            Self::Any { common } => Self::Any {
                common: common.clone(),
            },
            Self::Collection {
                common,
                kind,
                item,
                item_validator,
                min_length,
                max_length,
            } => Self::Collection {
                common: common.clone(),
                kind: *kind,
                item: item.clone(),
                item_validator: item_validator.as_ref().map(|v| v.clone_ref(py)),
                min_length: min_length.clone(),
                max_length: max_length.clone(),
            },
            Self::Dict {
                common,
                value,
                value_validator,
            } => Self::Dict {
                common: common.clone(),
                value: value.clone(),
                value_validator: value_validator.as_ref().map(|v| v.clone_ref(py)),
            },
            Self::Nested {
                common,
                dataclass_index,
            } => Self::Nested {
                common: common.clone(),
                dataclass_index: *dataclass_index,
            },
            Self::Union { common, variants } => Self::Union {
                common: common.clone(),
                variants: variants.clone(),
            },
        })
    }
}

#[allow(clippy::missing_const_for_fn)]
impl FieldContainer {
    pub fn common(&self) -> &FieldCommon {
        match self {
            Self::Str { common, .. }
            | Self::Int { common, .. }
            | Self::Float { common, .. }
            | Self::Bool { common }
            | Self::Decimal { common, .. }
            | Self::Date { common }
            | Self::Time { common }
            | Self::DateTime { common, .. }
            | Self::Uuid { common }
            | Self::Bytes { common }
            | Self::StrEnum { common, .. }
            | Self::IntEnum { common, .. }
            | Self::StrLiteral { common, .. }
            | Self::IntLiteral { common, .. }
            | Self::BoolLiteral { common, .. }
            | Self::Any { common }
            | Self::Collection { common, .. }
            | Self::Dict { common, .. }
            | Self::Nested { common, .. }
            | Self::Union { common, .. } => common,
        }
    }
}

impl std::fmt::Debug for FieldContainer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Str {
                strip_whitespaces,
                post_load,
                ..
            } => f
                .debug_struct("Str")
                .field("strip_whitespaces", strip_whitespaces)
                .field("has_post_load", &post_load.is_some())
                .finish(),
            Self::Int { .. } => write!(f, "Int"),
            Self::Float { .. } => write!(f, "Float"),
            Self::Bool { .. } => write!(f, "Bool"),
            Self::Decimal { .. } => write!(f, "Decimal"),
            Self::Date { .. } => write!(f, "Date"),
            Self::Time { .. } => write!(f, "Time"),
            Self::DateTime { format, .. } => {
                f.debug_struct("DateTime").field("format", format).finish()
            }
            Self::Uuid { .. } => write!(f, "Uuid"),
            Self::Bytes { .. } => write!(f, "Bytes"),
            Self::StrEnum { .. } => write!(f, "StrEnum"),
            Self::IntEnum { .. } => write!(f, "IntEnum"),
            Self::StrLiteral { .. } => write!(f, "StrLiteral"),
            Self::IntLiteral { .. } => write!(f, "IntLiteral"),
            Self::BoolLiteral { .. } => write!(f, "BoolLiteral"),
            Self::Any { .. } => write!(f, "Any"),
            Self::Collection { kind, .. } => {
                f.debug_struct("Collection").field("kind", kind).finish()
            }
            Self::Dict { .. } => write!(f, "Dict"),
            Self::Nested { .. } => write!(f, "Nested"),
            Self::Union { .. } => write!(f, "Union"),
        }
    }
}

pub struct DataclassContainer {
    pub cls: Py<PyAny>,
    pub fields: Vec<DataclassField>,
    pub field_lookup: HashMap<String, usize>,
    pub load_strategy: LoadStrategy,
    pub ignore_none: bool,
    pub pre_loads: Vec<Py<PyAny>>,
}

impl Clone for DataclassContainer {
    fn clone(&self) -> Self {
        Python::attach(|py| Self {
            cls: self.cls.clone_ref(py),
            fields: self.fields.clone(),
            field_lookup: self.field_lookup.clone(),
            load_strategy: self.load_strategy,
            ignore_none: self.ignore_none,
            pre_loads: self.pre_loads.iter().map(|f| f.clone_ref(py)).collect(),
        })
    }
}

impl DataclassContainer {
    pub fn new(
        cls: Py<PyAny>,
        load_strategy: LoadStrategy,
        ignore_none: bool,
        pre_loads: Vec<Py<PyAny>>,
    ) -> Self {
        Self {
            cls,
            fields: Vec::new(),
            field_lookup: HashMap::new(),
            load_strategy,
            ignore_none,
            pre_loads,
        }
    }

    pub fn add_field(&mut self, field: DataclassField) {
        let idx = self.fields.len();
        self.field_lookup.insert(field.data_key.clone(), idx);
        self.fields.push(field);
    }
}

impl std::fmt::Debug for DataclassContainer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DataclassContainer")
            .field("fields", &self.fields.len())
            .field("load_strategy", &self.load_strategy)
            .finish_non_exhaustive()
    }
}

pub struct DataclassRegistry {
    containers: Vec<DataclassContainer>,
}

impl DataclassRegistry {
    pub const fn new(containers: Vec<DataclassContainer>) -> Self {
        Self { containers }
    }

    pub fn get(&self, index: usize) -> &DataclassContainer {
        &self.containers[index]
    }
}

pub struct PrimitiveContainer {
    pub field: FieldContainer,
}

impl Clone for PrimitiveContainer {
    fn clone(&self) -> Self {
        Self {
            field: self.field.clone(),
        }
    }
}

#[allow(clippy::use_self)]
pub enum TypeContainer {
    Dataclass(usize),
    Primitive(PrimitiveContainer),
    List { item: Box<Self> },
    Dict { value: Box<Self> },
    Optional { inner: Box<Self> },
    Set { item: Box<Self> },
    FrozenSet { item: Box<Self> },
    Tuple { item: Box<Self> },
    Union { variants: Vec<Self> },
}

impl Clone for TypeContainer {
    fn clone(&self) -> Self {
        match self {
            Self::Dataclass(idx) => Self::Dataclass(*idx),
            Self::Primitive(p) => Self::Primitive(p.clone()),
            Self::List { item } => Self::List { item: item.clone() },
            Self::Dict { value } => Self::Dict {
                value: value.clone(),
            },
            Self::Optional { inner } => Self::Optional {
                inner: inner.clone(),
            },
            Self::Set { item } => Self::Set { item: item.clone() },
            Self::FrozenSet { item } => Self::FrozenSet { item: item.clone() },
            Self::Tuple { item } => Self::Tuple { item: item.clone() },
            Self::Union { variants } => Self::Union {
                variants: variants.clone(),
            },
        }
    }
}

impl std::fmt::Debug for TypeContainer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Dataclass(idx) => f.debug_tuple("Dataclass").field(idx).finish(),
            Self::Primitive(_) => write!(f, "Primitive"),
            Self::List { .. } => write!(f, "List"),
            Self::Dict { .. } => write!(f, "Dict"),
            Self::Optional { .. } => write!(f, "Optional"),
            Self::Set { .. } => write!(f, "Set"),
            Self::FrozenSet { .. } => write!(f, "FrozenSet"),
            Self::Tuple { .. } => write!(f, "Tuple"),
            Self::Union { .. } => write!(f, "Union"),
        }
    }
}
