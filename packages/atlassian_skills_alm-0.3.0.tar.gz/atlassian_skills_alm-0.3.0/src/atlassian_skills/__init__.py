"""atlassian-skills-alm: Token-efficient CLI for the Atlassian Server/DC ALM stack (Jira, Confluence, Bitbucket, Bamboo, Codebeamer)."""

__version__ = "0.3.0"
