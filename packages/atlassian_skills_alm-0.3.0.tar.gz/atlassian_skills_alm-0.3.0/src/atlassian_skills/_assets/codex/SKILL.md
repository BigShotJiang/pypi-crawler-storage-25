---
name: atls
description: Use when the task involves Jira, Confluence, Bitbucket, or Codebeamer and the preferred path is the atls CLI rather than Atlassian MCP tools. Covers command selection, output formats, dry-run safety, and markdown push/pull workflows.
---

# atls — Atlassian CLI Dispatcher

<!-- installed-by: atls 0.1.0 -->

## When to use
Use `atls` instead of `mcp__mcp-atlassian__*` tools for ALL Atlassian-stack operations (Jira, Confluence, Bitbucket, Codebeamer).

## Upgrade
On missing command/flag or CHANGELOG-fixed behavior, run `atls version --check`; exit 1 → suggest `atls upgrade`.

## Command tree
```
atls
├── jira
│   ├── issue        get, search, create, update, delete, transition, transitions, dates, sla, images
│   ├── issue-batch  create
│   ├── epic         link
│   ├── comment      list, add, edit, delete
│   ├── sprint       list, issues, create, update, add-issues
│   ├── board        list, issues
│   ├── field        search, options
│   ├── link         list-types, create, remote-list, remote-create, delete
│   ├── worklog      list, add
│   ├── watcher      list, add, remove
│   ├── attachment   list, upload, download, delete
│   ├── dev-info     get, get-many
│   ├── service-desk list, queues, queue-issues
│   ├── project      list, issues, versions, components, versions-create
│   └── user         get, me
├── confluence
│   ├── page         get, search, children, history, diff, images, create, update, delete, move, push-md, pull-md, diff-local
│   ├── space        tree
│   ├── comment      list, add, reply
│   ├── label        list, add
│   ├── attachment   list, upload, upload-batch, download, download-all, delete
│   └── user         search, me
├── bitbucket
│   ├── project      list
│   ├── repo         list, get
│   ├── pr           list, get, diff, comments, commits, activity, create, update, merge, decline, approve, unapprove, needs-work, reopen, diffstat, statuses, pending-review
│   ├── branch       list
│   ├── file         get
│   ├── comment      add, reply, update, delete, resolve, reopen
│   └── task         list, get, create, update, delete
└── codebeamer
    ├── item         get, children, search, search-advanced, relations, update, delete, patch-children, bulk-update
    └── association  list-types, get, history, create, update, delete
```

When unsure, navigate with `<group> --help` (e.g. `atls jira issue --help`).

## Format
- Default `--format=compact` (fewest tokens). Use `json` to parse, `md` to read body, `raw` for byte-exact server response.
- **Never use `-f` as a short form for `--format`** — `-f` is a file-input flag in `page create/update`, `push-md`, `confluence comment add/reply`. Always write `--format=...`.

## page update vs push-md
- `page update`: Low-level. Replace page body directly (`--body-format=storage|md`). No attachment handling.
- `push-md`: High-level. Markdown-native with attachment syncing, passthrough comments, asset-dir, no-change detection. **Prefer this for markdown workflows.**

## Common patterns
```bash
# Jira
atls jira issue get KEY                    # compact view
atls jira issue search "project=PROJ"      # JQL search
atls jira issue create --project PROJ --type Story --summary "..." --body-file=-
atls jira issue update KEY --body-file=- --body-format=md --heading-promotion=jira
atls jira comment add KEY --body-file=- --body-format=md
atls jira issue get KEY --format=md --section "Acceptance Criteria"

# Jira transition (2-step: discover ID, then transition)
atls jira issue transitions KEY --format=json
atls jira issue transition KEY --transition-id 31
# Or by name (case-insensitive):
atls jira issue transition KEY --transition-name "In Progress"

# Confluence
atls confluence page get ID
atls confluence page search "CQL query"
atls confluence page push-md ID --md-file page.md --if-version 15 --asset-dir=assets/
atls confluence page pull-md ID --output page.md --resolve-assets=sidecar --asset-dir=assets/
atls confluence page diff-local ID page.md --passthrough-prefix workflow:
```

## Write safety
- Always use `--dry-run` before write operations
- Use `--if-version N` for Confluence updates & push-md (reject if stale → exit 5)
- Use `--if-updated ISO` for Jira updates (stale check → exit 5)
- Use `--attachment-if-exists skip|replace` to control duplicate attachments (push-md)

## Key flags
| Flag | Commands | Effect |
|---|---|---|
| `--if-version N` | push-md, page update | Optimistic lock (exit 5 if stale) |
| `--asset-dir DIR` | push-md, pull-md | Batch attach / download assets |
| `--output -o PATH` | pull-md | Write markdown to file instead of stdout |
| `--resolve-assets=sidecar` | pull-md | Download attachments, rewrite image links |
| `--passthrough-prefix P` | push-md, pull-md, diff-local, issue update | Preserve `<!-- P:... -->` comments |
| `--md-file -` | push-md | Read markdown from stdin |
| `--body-repr md\|raw\|wiki` | issue get | Body representation (separate from `--format`) |
| `--body-format md` / `--comment-format md` | jira/confluence writes | md → server format (Jira wiki / Confluence storage) |
| `--heading-promotion jira` | issue update/get/search | Heading level adjust for md↔wiki |
| `--section "H2 Title"` | issue get/search | Extract specific H2 section |

## Exit codes
0=OK, 2=not found, 3=permission, 4=conflict, 5=stale, 6=auth, 7=validation, 10=network, 11=rate-limited

## JSON output parsing
```bash
atls confluence page push-md ID --md-file p.md --format=json   # push-md uses -f for --md-file
atls confluence page pull-md ID --format=json                   # → {"markdown":"...","version":15,"title":"..."}
atls jira issue search "project=PROJ" --format=json | jq '.[].key'
```

## Custom fields
- Explicitly requested Jira `customfield_*` values are preserved in JSON issue output.
- `jira issue update --set-customfield customfield_XXXXX=value` performs a read-back check; silent server-side ignore → validation error.
- Use `--fields-json` instead of `--set-customfield` when the field expects a structured payload.

## Multi-profile
```bash
atls --profile corp jira issue get CORP-1
export ATLS_CORP_JIRA_TOKEN="..."   # also ATLS_CORP_CONFLUENCE_TOKEN, ATLS_CORP_BITBUCKET_TOKEN, ATLS_CORP_CODEBEAMER_USER/TOKEN
```

## Codebeamer notes
- Default auth is **Basic** (username + password), not PAT — Codebeamer Server doesn't issue PATs.
- Set `CODEBEAMER_USERNAME` + `CODEBEAMER_PASSWORD` (or `ATLS_<PROFILE>_CODEBEAMER_USER` + `ATLS_<PROFILE>_CODEBEAMER_TOKEN`).
- URL: `CODEBEAMER_BASE_URL` accepts `https://host`, `.../cb`, `.../cb/api`, `.../cb/api/v3` — auto-normalized to v3.
- Search uses **cbQL**: `atls codebeamer item search "tracker.id IN (1234)"`.
- Write commands all support `--dry-run`; pass JSON via `--body '{...}'` or `--body @file.json`.
