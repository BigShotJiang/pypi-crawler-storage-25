from __future__ import annotations

import json
import os
from typing import Any

import typer

from atlassian_skills.codebeamer.client import CodebeamerClient
from atlassian_skills.core.auth import resolve_credential
from atlassian_skills.core.config import get_profile, load_config
from atlassian_skills.core.dryrun import format_dry_run
from atlassian_skills.core.errors import AtlasError
from atlassian_skills.core.format import OutputFormat, format_output
from atlassian_skills.core.models import WriteResult

codebeamer_app = typer.Typer(help="Codebeamer commands", no_args_is_help=True)

item_app = typer.Typer(help="Codebeamer item commands", no_args_is_help=True)
association_app = typer.Typer(help="Codebeamer association commands", no_args_is_help=True)

codebeamer_app.add_typer(item_app, name="item")
codebeamer_app.add_typer(association_app, name="association")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(ctx_obj: dict[str, Any]) -> CodebeamerClient:
    profile_name: str = ctx_obj.get("profile", "default")
    timeout: float = ctx_obj.get("timeout", 30.0)
    config = load_config()
    profile = get_profile(config, profile_name)
    url = (
        profile.codebeamer_url
        or os.environ.get(f"ATLS_{profile_name.upper()}_CODEBEAMER_URL")
        or os.environ.get("CODEBEAMER_BASE_URL")
    )
    if not url:
        typer.echo(
            f"No Codebeamer URL for profile '{profile_name}'. "
            f"Set codebeamer_url in config, ATLS_{profile_name.upper()}_CODEBEAMER_URL, "
            f"or CODEBEAMER_BASE_URL env var.",
            err=True,
        )
        raise typer.Exit(1)
    credential = resolve_credential(profile_name, "codebeamer", profile)
    verify: str | bool = profile.ca_bundle if profile.ca_bundle else True
    return CodebeamerClient(url.rstrip("/"), credential, timeout=timeout, verify=verify)


def _resolve_fmt(ctx_obj: dict[str, Any], local_format: str | None) -> OutputFormat:
    if local_format:
        try:
            return OutputFormat(local_format)
        except ValueError:
            valid = ", ".join(f.value for f in OutputFormat)
            typer.echo(f"Error: Invalid format '{local_format}'. Valid: {valid}", err=True)
            raise typer.Exit(1)  # noqa: B904
    fmt = ctx_obj.get("format", OutputFormat.COMPACT)
    return OutputFormat(fmt) if not isinstance(fmt, OutputFormat) else fmt


def _handle_error(err: AtlasError, fmt: OutputFormat) -> None:
    if fmt == OutputFormat.JSON:
        typer.echo(json.dumps(err.to_dict()))
    else:
        typer.echo(f"Error: {err.message}", err=True)
        if err.hint:
            typer.echo(f"Hint:  {err.hint}", err=True)
    raise typer.Exit(err.exit_code)


def _parse_json_arg(name: str, value: str | None) -> dict[str, Any] | None:
    """Parse a JSON string CLI argument; supports '@file.json' to read from disk."""
    if value is None:
        return None
    if value.startswith("@"):
        path = value[1:]
        with open(path, encoding="utf-8") as f:
            value = f.read()
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as e:
        typer.echo(f"Error: --{name} is not valid JSON: {e}", err=True)
        raise typer.Exit(1) from e
    if not isinstance(parsed, dict):
        typer.echo(f"Error: --{name} must be a JSON object", err=True)
        raise typer.Exit(1)
    return parsed


# ---------------------------------------------------------------------------
# item get / children
# ---------------------------------------------------------------------------


@item_app.command("get")
def item_get(
    ctx: typer.Context,
    item_id: int = typer.Argument(..., help="Codebeamer item ID"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Get a Codebeamer item by ID."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        item = client.get_item(item_id)
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output(item.model_dump(), fmt))
        else:
            tracker = item.tracker.name if item.tracker else "?"
            status = item.status.name if item.status else "?"
            typer.echo(f"#{item.id} [{tracker} | {status}] {item.name or ''}")
            if item.description:
                typer.echo(item.description)
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("children")
def item_children(
    ctx: typer.Context,
    item_id: int = typer.Argument(..., help="Codebeamer item ID"),
    page: int | None = typer.Option(None, "--page", help="Page number (1-based)"),
    page_size: int | None = typer.Option(None, "--page-size", help="Items per page"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """List children of a Codebeamer item."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        page_result = client.get_item_children(item_id, page=page, page_size=page_size)
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output(page_result.model_dump(), fmt))
        else:
            for child in page_result.items:
                status = child.status.name if child.status else "?"
                typer.echo(f"#{child.id:<8} [{status}] {child.name or ''}")
    except AtlasError as e:
        _handle_error(e, fmt)


# ---------------------------------------------------------------------------
# item search (cbQL)
# ---------------------------------------------------------------------------


@item_app.command("search")
def item_search(
    ctx: typer.Context,
    query: str = typer.Argument(..., help="cbQL query string"),
    page: int | None = typer.Option(None, "--page", help="Page number (1-based)"),
    page_size: int | None = typer.Option(None, "--page-size", help="Items per page"),
    baseline_id: int | None = typer.Option(None, "--baseline-id", help="Baseline ID"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Search Codebeamer items via cbQL (GET /items/query)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        result = client.search_items_cbql(
            query, page=page, page_size=page_size, baseline_id=baseline_id
        )
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output(result.model_dump(), fmt))
        else:
            for it in result.items:
                tracker = it.tracker.name if it.tracker else "?"
                typer.echo(f"#{it.id:<8} [{tracker}] {it.name or ''}")
            typer.echo(f"-- {len(result.items)}/{result.total or '?'} items")
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("search-advanced")
def item_search_advanced(
    ctx: typer.Context,
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Search Codebeamer items via cbQL request body (POST /items/query)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        result = client.search_items_cbql_advanced(payload)
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output(result.model_dump(), fmt))
        else:
            for it in result.items:
                tracker = it.tracker.name if it.tracker else "?"
                typer.echo(f"#{it.id:<8} [{tracker}] {it.name or ''}")
            typer.echo(f"-- {len(result.items)}/{result.total or '?'} items")
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("relations")
def item_relations(
    ctx: typer.Context,
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    baseline_id: int | None = typer.Option(None, "--baseline-id", help="Baseline ID"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Get item relations (POST /items/relations)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        result = client.get_items_relations(payload, baseline_id=baseline_id)
        typer.echo(format_output(result, fmt))
    except AtlasError as e:
        _handle_error(e, fmt)


# ---------------------------------------------------------------------------
# item write
# ---------------------------------------------------------------------------


@item_app.command("create")
def item_create(
    ctx: typer.Context,
    tracker_id: int = typer.Argument(..., help="Tracker ID (e.g. 6289127)"),
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Create a new tracker item (POST /trackers/{trackerId}/items)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/trackers/{tracker_id}/items"
            typer.echo(format_dry_run("POST", url, body=payload, fmt=fmt.value))
            return
        result = client.create_item(tracker_id, payload)
        typer.echo(
            format_output(
                WriteResult(key=f"#{result.id}", action="created", summary=result.name), fmt
            )
        )
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("update")
def item_update(
    ctx: typer.Context,
    item_id: int = typer.Argument(..., help="Codebeamer item ID"),
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Update a Codebeamer item (PUT /items/{id})."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/items/{item_id}"
            typer.echo(format_dry_run("PUT", url, body=payload, fmt=fmt.value))
            return
        result = client.update_item(item_id, payload)
        typer.echo(
            format_output(
                WriteResult(key=f"#{result.id}", action="updated", summary=result.name), fmt
            )
        )
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("delete")
def item_delete(
    ctx: typer.Context,
    item_id: int = typer.Argument(..., help="Codebeamer item ID"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Move a Codebeamer item to trash (DELETE /items/{id})."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/items/{item_id}"
            typer.echo(format_dry_run("DELETE", url, fmt=fmt.value))
            return
        client.delete_item(item_id)
        typer.echo(format_output(WriteResult(key=f"#{item_id}", action="deleted"), fmt))
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("patch-children")
def item_patch_children(
    ctx: typer.Context,
    item_id: int = typer.Argument(..., help="Parent item ID"),
    mode: str = typer.Option(..., "--mode", help="Patch mode (e.g. ADD, REMOVE, MOVE)"),
    child_item_id: int = typer.Option(..., "--child-item-id", help="Child item ID"),
    index: int = typer.Option(..., "--index", help="Position index"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Patch the child list of an item (PATCH /items/{id}/children)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    body = {"childItemId": child_item_id, "index": index}
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/items/{item_id}/children?mode={mode}"
            typer.echo(format_dry_run("PATCH", url, body=body, fmt=fmt.value))
            return
        result = client.patch_item_children(
            item_id, mode=mode, child_item_id=child_item_id, index=index
        )
        typer.echo(format_output(result, fmt))
    except AtlasError as e:
        _handle_error(e, fmt)


@item_app.command("bulk-update")
def item_bulk_update(
    ctx: typer.Context,
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    atomic: bool | None = typer.Option(None, "--atomic/--non-atomic", help="Atomic update mode"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Bulk update item fields (PUT /items/fields)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            qs = ""
            if atomic is not None:
                qs = f"?atomic={'true' if atomic else 'false'}"
            url = f"{client.base_url}/items/fields{qs}"
            typer.echo(format_dry_run("PUT", url, body=payload, fmt=fmt.value))
            return
        result = client.bulk_update_item_fields(payload, atomic=atomic)
        typer.echo(format_output(result, fmt))
    except AtlasError as e:
        _handle_error(e, fmt)


# ---------------------------------------------------------------------------
# association read
# ---------------------------------------------------------------------------


@association_app.command("list-types")
def association_list_types(
    ctx: typer.Context,
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """List available association types."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        types = client.list_association_types()
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output([t.model_dump() for t in types], fmt))
        else:
            for t in types:
                typer.echo(f"#{t.id} {t.name or ''}")
    except AtlasError as e:
        _handle_error(e, fmt)


@association_app.command("get")
def association_get(
    ctx: typer.Context,
    association_id: int = typer.Argument(..., help="Association ID"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Get an association by ID."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        a = client.get_association(association_id)
        if fmt in (OutputFormat.JSON, OutputFormat.RAW):
            typer.echo(format_output(a.model_dump(), fmt))
        else:
            type_name = a.type.name if a.type else "?"
            typer.echo(f"#{a.id} [{type_name}] {a.description or ''}")
    except AtlasError as e:
        _handle_error(e, fmt)


@association_app.command("history")
def association_history(
    ctx: typer.Context,
    association_id: int = typer.Argument(..., help="Association ID"),
    page: int | None = typer.Option(None, "--page", help="Page number (1-based)"),
    page_size: int | None = typer.Option(None, "--page-size", help="Items per page"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Get association change history."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        history = client.get_association_history(
            association_id, page=page, page_size=page_size
        )
        typer.echo(format_output(history.model_dump(), fmt))
    except AtlasError as e:
        _handle_error(e, fmt)


# ---------------------------------------------------------------------------
# association write
# ---------------------------------------------------------------------------


@association_app.command("create")
def association_create(
    ctx: typer.Context,
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Create a new association (POST /associations)."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/associations"
            typer.echo(format_dry_run("POST", url, body=payload, fmt=fmt.value))
            return
        result = client.create_association(payload)
        typer.echo(
            format_output(
                WriteResult(key=f"assoc-{result.id}", action="created", summary=result.description),
                fmt,
            )
        )
    except AtlasError as e:
        _handle_error(e, fmt)


@association_app.command("update")
def association_update(
    ctx: typer.Context,
    association_id: int = typer.Argument(..., help="Association ID"),
    body: str = typer.Option(..., "--body", help="JSON body (or @file.json)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Update an association (PUT /associations/{id})."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    payload = _parse_json_arg("body", body)
    assert payload is not None
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/associations/{association_id}"
            typer.echo(format_dry_run("PUT", url, body=payload, fmt=fmt.value))
            return
        result = client.update_association(association_id, payload)
        typer.echo(
            format_output(
                WriteResult(key=f"assoc-{result.id}", action="updated", summary=result.description),
                fmt,
            )
        )
    except AtlasError as e:
        _handle_error(e, fmt)


@association_app.command("delete")
def association_delete(
    ctx: typer.Context,
    association_id: int = typer.Argument(..., help="Association ID"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    format: str | None = typer.Option(None, "--format", help="Override output format"),
) -> None:
    """Delete an association (DELETE /associations/{id})."""
    ctx.ensure_object(dict)
    fmt = _resolve_fmt(ctx.obj, format)
    try:
        client = _make_client(ctx.obj)
        if dry_run:
            url = f"{client.base_url}/associations/{association_id}"
            typer.echo(format_dry_run("DELETE", url, fmt=fmt.value))
            return
        client.delete_association(association_id)
        typer.echo(format_output(WriteResult(key=f"assoc-{association_id}", action="deleted"), fmt))
    except AtlasError as e:
        _handle_error(e, fmt)
