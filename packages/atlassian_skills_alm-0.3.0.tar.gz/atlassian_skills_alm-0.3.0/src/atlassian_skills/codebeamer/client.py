from __future__ import annotations

from typing import Any

from atlassian_skills.codebeamer.models import (
    CbAssociation,
    CbAssociationHistory,
    CbAssociationType,
    CbItem,
    CbItemPage,
)
from atlassian_skills.core.auth import Credential
from atlassian_skills.core.client import BaseClient


def _normalize_v3_base(base_url: str) -> str:
    """Resolve the v3 API root regardless of how the user wrote the base URL.

    Accepted inputs:
      https://cb.example.com               -> https://cb.example.com/cb/api/v3
      https://cb.example.com/cb            -> https://cb.example.com/cb/api/v3
      https://cb.example.com/cb/api        -> https://cb.example.com/cb/api/v3
      https://cb.example.com/cb/api/v3     -> https://cb.example.com/cb/api/v3
    """
    base = base_url.rstrip("/")
    if base.endswith("/cb/api/v3"):
        return base
    if base.endswith("/cb/api"):
        return f"{base}/v3"
    if base.endswith("/cb"):
        return f"{base}/api/v3"
    return f"{base}/cb/api/v3"


class CodebeamerClient(BaseClient):
    """Codebeamer Swarm REST v3 client.

    API base: <host>/cb/api/v3 (auto-normalized from any of the common prefixes).
    Auth: Basic by default (id+pw). PAT/Bearer also supported via Credential.
    Pagination: page / pageSize / total.
    """

    def __init__(
        self,
        base_url: str,
        credential: Credential,
        timeout: float = 30.0,
        verify: str | bool = True,
    ) -> None:
        super().__init__(_normalize_v3_base(base_url), credential, timeout, verify=verify)

    # ------------------------------------------------------------------
    # Items — read
    # ------------------------------------------------------------------

    def get_item(self, item_id: int | str) -> CbItem:
        """GET /items/{itemId}"""
        data = self.get(f"/items/{item_id}").json()
        return CbItem.model_validate(data)

    def get_item_children(
        self,
        item_id: int | str,
        *,
        page: int | None = None,
        page_size: int | None = None,
    ) -> CbItemPage:
        """GET /items/{itemId}/children"""
        params: dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["pageSize"] = page_size
        data = self.get(f"/items/{item_id}/children", params=params or None).json()
        return CbItemPage.model_validate(data)

    def search_items_cbql(
        self,
        query: str,
        *,
        page: int | None = None,
        page_size: int | None = None,
        baseline_id: int | None = None,
    ) -> CbItemPage:
        """GET /items/query — cbQL search via query string."""
        params: dict[str, Any] = {"queryString": query}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["pageSize"] = page_size
        if baseline_id is not None:
            params["baselineId"] = baseline_id
        data = self.get("/items/query", params=params).json()
        return CbItemPage.model_validate(data)

    def search_items_cbql_advanced(self, body: dict[str, Any]) -> CbItemPage:
        """POST /items/query — cbQL search via request body."""
        data = self.post("/items/query", json=body).json()
        return CbItemPage.model_validate(data)

    def get_items_relations(
        self,
        body: dict[str, Any],
        *,
        baseline_id: int | None = None,
    ) -> dict[str, Any]:
        """POST /items/relations — upstream/downstream/association lookup."""
        params: dict[str, Any] = {}
        if baseline_id is not None:
            params["baselineId"] = baseline_id
        result: dict[str, Any] = self.request(
            "POST",
            "/items/relations",
            params=params or None,
            json=body,
        ).json()
        return result

    # ------------------------------------------------------------------
    # Items — write
    # ------------------------------------------------------------------

    def create_item(self, tracker_id: int | str, body: dict[str, Any]) -> CbItem:
        """POST /trackers/{trackerId}/items — create a new tracker item.

        Required body keys (typical): {"name": str}. Optional: "description",
        "descriptionFormat" ("Wiki" | "PlainText" | "Html"), "parent": {"id":N,
        "type":"TrackerItemReference"}, "categories", "priority", "status", ...
        """
        data = self.post(f"/trackers/{tracker_id}/items", json=body).json()
        return CbItem.model_validate(data)

    def update_item(self, item_id: int | str, body: dict[str, Any]) -> CbItem:
        """PUT /items/{itemId}"""
        data = self.put(f"/items/{item_id}", json=body).json()
        return CbItem.model_validate(data)

    def patch_item_children(
        self,
        item_id: int | str,
        *,
        mode: str,
        child_item_id: int,
        index: int,
    ) -> dict[str, Any]:
        """PATCH /items/{itemId}/children — reorder/add/remove a child link.

        mode is one of ADD / REMOVE / MOVE etc., per Codebeamer v3 spec.
        """
        body = {"childItemId": child_item_id, "index": index}
        result: dict[str, Any] = self.request(
            "PATCH",
            f"/items/{item_id}/children",
            params={"mode": mode},
            json=body,
        ).json()
        return result

    def delete_item(self, item_id: int | str) -> None:
        """DELETE /items/{itemId} — moves to trash."""
        self.delete(f"/items/{item_id}")

    def bulk_update_item_fields(
        self,
        body: dict[str, Any],
        *,
        atomic: bool | None = None,
    ) -> dict[str, Any]:
        """PUT /items/fields — bulk field updates."""
        params: dict[str, Any] = {}
        if atomic is not None:
            params["atomic"] = "true" if atomic else "false"
        result: dict[str, Any] = self.request(
            "PUT",
            "/items/fields",
            params=params or None,
            json=body,
        ).json()
        return result

    # ------------------------------------------------------------------
    # Associations — read
    # ------------------------------------------------------------------

    def list_association_types(self) -> list[CbAssociationType]:
        """GET /associations/types"""
        data = self.get("/associations/types").json()
        items: list[Any] = data if isinstance(data, list) else data.get("items", [])
        return [CbAssociationType.model_validate(t) for t in items]

    def get_association(self, association_id: int | str) -> CbAssociation:
        """GET /associations/{associationId}"""
        data = self.get(f"/associations/{association_id}").json()
        return CbAssociation.model_validate(data)

    def get_association_history(
        self,
        association_id: int | str,
        *,
        page: int | None = None,
        page_size: int | None = None,
    ) -> CbAssociationHistory:
        """GET /associations/{associationId}/history"""
        params: dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["pageSize"] = page_size
        data = self.get(
            f"/associations/{association_id}/history",
            params=params or None,
        ).json()
        return CbAssociationHistory.model_validate(data)

    # ------------------------------------------------------------------
    # Associations — write
    # ------------------------------------------------------------------

    def create_association(self, body: dict[str, Any]) -> CbAssociation:
        """POST /associations"""
        data = self.post("/associations", json=body).json()
        return CbAssociation.model_validate(data)

    def update_association(
        self,
        association_id: int | str,
        body: dict[str, Any],
    ) -> CbAssociation:
        """PUT /associations/{associationId}"""
        data = self.put(f"/associations/{association_id}", json=body).json()
        return CbAssociation.model_validate(data)

    def delete_association(self, association_id: int | str) -> None:
        """DELETE /associations/{associationId}"""
        self.delete(f"/associations/{association_id}")
