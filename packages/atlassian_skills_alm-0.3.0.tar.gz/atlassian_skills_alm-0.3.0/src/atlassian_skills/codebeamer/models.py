from __future__ import annotations

from typing import Any

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class CbUser(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int | None = None
    name: str | None = None
    type: str | None = None


class CbReference(BaseModel):
    """Generic Codebeamer reference (tracker, status, project, ...)."""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int | None = None
    name: str | None = None
    type: str | None = None


class CbItem(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: int
    name: str | None = None
    description: str | None = None
    descriptionFormat: str | None = None
    tracker: CbReference | None = None
    status: CbReference | None = None
    priority: CbReference | None = None
    severity: CbReference | None = None
    parent: CbReference | None = None
    owners: list[CbUser] = []
    assignedTo: list[CbUser] = []
    submittedAt: str | None = None
    submittedBy: CbUser | None = None
    modifiedAt: str | None = None
    modifiedBy: CbUser | None = None
    version: int | None = None


class CbItemPage(BaseModel):
    """Codebeamer v3 paginated item response.

    /items/query returns the full items under `items`; /items/{id}/children
    returns lightweight references under `itemRefs`. Both shapes parse into
    `items` here.
    """

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    page: int | None = None
    pageSize: int | None = None
    total: int | None = None
    items: list[CbItem] = Field(default_factory=list, validation_alias=AliasChoices("items", "itemRefs"))


class CbAssociationType(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int | None = None
    name: str | None = None
    type: str | None = None


class CbAssociation(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: int
    type: CbAssociationType | None = None
    description: str | None = None
    descriptionFormat: str | None = None
    propagatingDependencies: bool | None = None
    propagatingSuspects: bool | None = None
    from_: dict[str, Any] | None = None
    to: dict[str, Any] | None = None


class CbAssociationHistoryEntry(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    version: int | None = None
    modifiedAt: str | None = None
    modifiedBy: CbUser | None = None


class CbAssociationHistory(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    page: int | None = None
    pageSize: int | None = None
    total: int | None = None
    items: list[CbAssociationHistoryEntry] = []
