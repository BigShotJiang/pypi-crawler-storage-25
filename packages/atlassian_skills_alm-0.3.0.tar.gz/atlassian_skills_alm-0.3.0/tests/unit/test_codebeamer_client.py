from __future__ import annotations

import httpx
import pytest
import respx

from atlassian_skills.codebeamer.client import CodebeamerClient, _normalize_v3_base
from atlassian_skills.codebeamer.models import (
    CbAssociation,
    CbAssociationHistory,
    CbAssociationType,
    CbItem,
    CbItemPage,
)
from atlassian_skills.core.auth import Credential

HOST = "https://cb.example.com"
V3 = f"{HOST}/cb/api/v3"

cred = Credential(method="basic", token="pw", username="user")
client = CodebeamerClient(HOST, cred)


# ---------------------------------------------------------------------------
# URL normalization
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw",
    [
        "https://cb.example.com",
        "https://cb.example.com/",
        "https://cb.example.com/cb",
        "https://cb.example.com/cb/api",
        "https://cb.example.com/cb/api/",
        "https://cb.example.com/cb/api/v3",
    ],
)
def test_normalize_v3_base(raw: str) -> None:
    assert _normalize_v3_base(raw) == V3


def test_basic_auth_header() -> None:
    assert client.credential.method == "basic"
    header = client.credential.to_header()["Authorization"]
    assert header.startswith("Basic ")


# ---------------------------------------------------------------------------
# items — read
# ---------------------------------------------------------------------------


@respx.mock
def test_get_item() -> None:
    respx.get(f"{V3}/items/123").mock(
        return_value=httpx.Response(200, json={"id": 123, "name": "Login bug"})
    )
    item = client.get_item(123)
    assert isinstance(item, CbItem)
    assert item.id == 123
    assert item.name == "Login bug"


@respx.mock
def test_get_item_children() -> None:
    payload = {
        "page": 1,
        "pageSize": 25,
        "total": 2,
        "items": [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}],
    }
    respx.get(f"{V3}/items/123/children").mock(return_value=httpx.Response(200, json=payload))
    page = client.get_item_children(123)
    assert isinstance(page, CbItemPage)
    assert page.total == 2
    assert [c.id for c in page.items] == [1, 2]


@respx.mock
def test_search_items_cbql_get() -> None:
    payload = {"page": 1, "pageSize": 1, "total": 1, "items": [{"id": 9, "name": "x"}]}
    route = respx.get(f"{V3}/items/query").mock(return_value=httpx.Response(200, json=payload))
    result = client.search_items_cbql("tracker.id = 1234", page=1, page_size=1, baseline_id=42)
    assert result.items[0].id == 9
    params = dict(route.calls[0].request.url.params)
    assert params["queryString"] == "tracker.id = 1234"
    assert params["page"] == "1"
    assert params["pageSize"] == "1"
    assert params["baselineId"] == "42"


@respx.mock
def test_search_items_cbql_advanced_post() -> None:
    payload = {"page": 1, "pageSize": 1, "total": 1, "items": [{"id": 7, "name": "y"}]}
    route = respx.post(f"{V3}/items/query").mock(
        return_value=httpx.Response(200, json=payload)
    )
    result = client.search_items_cbql_advanced({"queryString": "tracker.id = 9"})
    assert result.items[0].id == 7
    assert route.calls[0].request.method == "POST"


@respx.mock
def test_get_items_relations() -> None:
    route = respx.post(f"{V3}/items/relations").mock(
        return_value=httpx.Response(200, json={"relations": []})
    )
    result = client.get_items_relations({"itemIds": [1, 2]}, baseline_id=5)
    assert result == {"relations": []}
    params = dict(route.calls[0].request.url.params)
    assert params["baselineId"] == "5"


# ---------------------------------------------------------------------------
# items — write
# ---------------------------------------------------------------------------


@respx.mock
def test_create_item() -> None:
    route = respx.post(f"{V3}/trackers/6289127/items").mock(
        return_value=httpx.Response(200, json={"id": 1496747, "name": "[atls-test] sample"})
    )
    body = {
        "name": "[atls-test] sample",
        "description": "body",
        "descriptionFormat": "Wiki",
        "parent": {"id": 1332325, "type": "TrackerItemReference"},
    }
    item = client.create_item(6289127, body)
    assert item.id == 1496747
    assert item.name == "[atls-test] sample"
    assert route.calls[0].request.method == "POST"
    sent = httpx.Request("POST", "x", json=body).read()
    assert route.calls[0].request.read() == sent


@respx.mock
def test_update_item() -> None:
    route = respx.put(f"{V3}/items/55").mock(
        return_value=httpx.Response(200, json={"id": 55, "name": "renamed"})
    )
    item = client.update_item(55, {"name": "renamed"})
    assert item.name == "renamed"
    assert route.calls[0].request.method == "PUT"


@respx.mock
def test_children_response_with_itemRefs_alias() -> None:
    """v3 /items/{id}/children returns 'itemRefs' (not 'items'); alias must parse both."""
    payload = {
        "page": 1,
        "pageSize": 25,
        "total": 2,
        "itemRefs": [
            {"id": 11, "name": "ref-a", "type": "TrackerItemReference"},
            {"id": 12, "name": "ref-b", "type": "TrackerItemReference"},
        ],
    }
    respx.get(f"{V3}/items/100/children").mock(return_value=httpx.Response(200, json=payload))
    page = client.get_item_children(100)
    assert [c.id for c in page.items] == [11, 12]
    assert page.items[0].name == "ref-a"


@respx.mock
def test_patch_item_children() -> None:
    route = respx.patch(f"{V3}/items/55/children").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    result = client.patch_item_children(55, mode="ADD", child_item_id=99, index=0)
    assert result == {"ok": True}
    params = dict(route.calls[0].request.url.params)
    assert params["mode"] == "ADD"


@respx.mock
def test_delete_item() -> None:
    route = respx.delete(f"{V3}/items/55").mock(return_value=httpx.Response(204))
    client.delete_item(55)
    assert route.called


@respx.mock
def test_bulk_update_item_fields() -> None:
    route = respx.put(f"{V3}/items/fields").mock(
        return_value=httpx.Response(200, json={"updated": 3})
    )
    result = client.bulk_update_item_fields({"items": []}, atomic=True)
    assert result == {"updated": 3}
    params = dict(route.calls[0].request.url.params)
    assert params["atomic"] == "true"


# ---------------------------------------------------------------------------
# associations
# ---------------------------------------------------------------------------


@respx.mock
def test_list_association_types() -> None:
    respx.get(f"{V3}/associations/types").mock(
        return_value=httpx.Response(200, json=[{"id": 1, "name": "depends"}])
    )
    types = client.list_association_types()
    assert len(types) == 1
    assert isinstance(types[0], CbAssociationType)
    assert types[0].name == "depends"


@respx.mock
def test_get_association() -> None:
    respx.get(f"{V3}/associations/77").mock(
        return_value=httpx.Response(200, json={"id": 77, "description": "d"})
    )
    a = client.get_association(77)
    assert isinstance(a, CbAssociation)
    assert a.id == 77


@respx.mock
def test_get_association_history() -> None:
    payload = {"page": 1, "pageSize": 25, "total": 0, "items": []}
    respx.get(f"{V3}/associations/77/history").mock(
        return_value=httpx.Response(200, json=payload)
    )
    h = client.get_association_history(77, page=1, page_size=25)
    assert isinstance(h, CbAssociationHistory)
    assert h.total == 0


@respx.mock
def test_create_association() -> None:
    respx.post(f"{V3}/associations").mock(
        return_value=httpx.Response(200, json={"id": 888})
    )
    a = client.create_association({"type": {"id": 1}})
    assert a.id == 888


@respx.mock
def test_update_association() -> None:
    respx.put(f"{V3}/associations/888").mock(
        return_value=httpx.Response(200, json={"id": 888, "description": "u"})
    )
    a = client.update_association(888, {"description": "u"})
    assert a.description == "u"


@respx.mock
def test_delete_association() -> None:
    route = respx.delete(f"{V3}/associations/888").mock(return_value=httpx.Response(204))
    client.delete_association(888)
    assert route.called
