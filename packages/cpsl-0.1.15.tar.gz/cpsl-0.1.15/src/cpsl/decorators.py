"""Lifecycle and handler decorators for Capsule apps.

    @cpsl.boot()       — runs once when the runtime starts
    @cpsl.shutdown()    — runs on SIGTERM before going cold
    @cpsl.enter()       — runs when a new session is created
    @cpsl.exit()        — runs when a session is closed
    @cpsl.message()     — handles every inbound message
"""

from __future__ import annotations

from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable)

_BOOT_ATTR = "_cpsl_boot"
_SHUTDOWN_ATTR = "_cpsl_shutdown"
_ENTER_ATTR = "_cpsl_enter"
_EXIT_ATTR = "_cpsl_exit"
_MESSAGE_ATTR = "_cpsl_message"


def _hook(attr: str, doc: str) -> Callable[[F], F]:
    def decorator(fn: F) -> F:
        setattr(fn, attr, True)
        return fn
    decorator.__doc__ = doc
    return decorator


def boot() -> Callable[[F], F]:
    return _hook(_BOOT_ATTR, "Runs once when the runtime starts.")


def shutdown() -> Callable[[F], F]:
    return _hook(_SHUTDOWN_ATTR, "Runs on SIGTERM before the runtime goes cold.")


def enter() -> Callable[[F], F]:
    return _hook(_ENTER_ATTR, "Runs when a new session is created. Receives ``session``.")


def exit() -> Callable[[F], F]:
    return _hook(_EXIT_ATTR, "Runs when a session is closed.")


def message() -> Callable[[F], F]:
    return _hook(_MESSAGE_ATTR, "Handles every inbound message. Receives ``session, msg``.")
