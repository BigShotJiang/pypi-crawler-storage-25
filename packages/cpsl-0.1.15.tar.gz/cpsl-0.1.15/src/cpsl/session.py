from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from .channels import Channel
from .msg import Message


@dataclass
class UserInfo:
    """Identity of the user who owns this session.

    Attributes:
        id: Unique user identifier (workspace ID).
        email: User's email address, if available.
    """

    id: str
    email: str | None = None


class Session:
    """Per-user conversation context, persisted across messages.

    Attributes:
        id:      Unique session identifier.
        user:    Identity of the user — ``UserInfo(id, email)``.
        channel: Channel this session is on (chat, api, etc.).
        history: Recent messages, rehydrated from the backing store.
        data:    Persistent key-value dict, saved automatically after each message.
    """

    __slots__ = ("id", "user", "channel", "history", "data",
                 "_reply_callback", "_stream_callback")

    def __init__(
        self,
        id: str,
        user: UserInfo,
        channel: Channel,
        history: list[Message] | None = None,
        data: dict[str, Any] | None = None,
    ) -> None:
        self.id = id
        self.user = user
        self.channel = channel
        self.history: list[Message] = history or []
        self.data: dict[str, Any] = data or {}
        self._reply_callback: Any = None
        self._stream_callback: Any = None

    async def reply(self, text: str) -> None:
        """Send a complete message back to the user."""
        msg = Message(text=text, sender="app", channel_type=self.channel.type)
        self.history.append(msg)
        if self._reply_callback:
            await self._reply_callback(msg)

    async def stream(self, chunks: AsyncIterator[str]) -> None:
        """Stream response chunks to the user in real time."""
        if self._stream_callback:
            await self._stream_callback(chunks)
