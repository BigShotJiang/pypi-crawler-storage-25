from __future__ import annotations

from pathlib import Path

from brvm.scrapers import sika


FIXTURES_DIR = Path(__file__).parent / "fixtures"


class DummyResponse:
    def __init__(self, text: str) -> None:
        self.text = text


class DummySession:
    def __init__(self, by_url: dict[str, str]) -> None:
        self.by_url = by_url

    def get(self, url: str, params: dict | None = None) -> DummyResponse:
        _ = params
        return DummyResponse(self.by_url[url])


def test_fetch_symbol_slug_map_parses_sika_aaz(monkeypatch) -> None:
    aaz_html = (FIXTURES_DIR / "sika_aaz.html").read_text(encoding="utf-8")
    monkeypatch.setattr(sika, "get_brvm_session", lambda: DummySession({sika.SIKA_AAZ_URL: aaz_html}))

    mapping = sika.fetch_symbol_slug_map()

    assert mapping["BOABF"] == "BOABF.bf"
    assert mapping["ABJC"] == "ABJC.ci"


def test_fetch_fundamentals_history_parses_annual_metrics(monkeypatch) -> None:
    aaz_html = (FIXTURES_DIR / "sika_aaz.html").read_text(encoding="utf-8")
    societe_html = (FIXTURES_DIR / "sika_societe_boabf.html").read_text(encoding="utf-8")
    cotation_html = (FIXTURES_DIR / "sika_cotation_boabf.html").read_text(encoding="utf-8")
    monkeypatch.setattr(
        sika,
        "get_brvm_session",
        lambda: DummySession(
            {
                sika.SIKA_AAZ_URL: aaz_html,
                sika.SIKA_SOCIETE_URL.format(slug="BOABF.bf"): societe_html,
                sika.SIKA_COTATION_URL.format(slug="BOABF.bf"): cotation_html,
            }
        ),
    )

    result = sika.fetch_fundamentals_history("BOABF")

    assert list(result["fiscal_year"]) == [2021, 2022, 2023, 2024, 2025]
    assert float(result.loc[result["fiscal_year"] == 2025, "per"].iloc[0]) == 12.99
    assert float(result.loc[result["fiscal_year"] == 2025, "dividend_yield"].iloc[0]) == 13.08
    assert float(result.loc[result["fiscal_year"] == 2025, "eps"].iloc[0]) == 437.55
    assert float(result.loc[result["fiscal_year"] == 2025, "dividend_amount"].iloc[0]) == 397.0


def test_fetch_company_info_parses_snapshot_fields(monkeypatch) -> None:
    aaz_html = (FIXTURES_DIR / "sika_aaz.html").read_text(encoding="utf-8")
    societe_html = (FIXTURES_DIR / "sika_societe_boabf.html").read_text(encoding="utf-8")
    cotation_html = (FIXTURES_DIR / "sika_cotation_boabf.html").read_text(encoding="utf-8")
    monkeypatch.setattr(
        sika,
        "get_brvm_session",
        lambda: DummySession(
            {
                sika.SIKA_AAZ_URL: aaz_html,
                sika.SIKA_SOCIETE_URL.format(slug="BOABF.bf"): societe_html,
                sika.SIKA_COTATION_URL.format(slug="BOABF.bf"): cotation_html,
            }
        ),
    )

    result = sika.fetch_company_info("BOABF")

    assert result["name"] == "BANK OF AFRICA BURKINA FASO"
    assert result["shares_outstanding"] == 44000000.0
    assert result["free_float_percent"] == 29.10
    assert result["capitalization"] == 250140000000.0
    assert result["beta_1y"] == 0.55
    assert result["rsi"] == 79.88
    assert result["principal_shareholders"][0]["name"] == "BOA WEST AFRICA"
