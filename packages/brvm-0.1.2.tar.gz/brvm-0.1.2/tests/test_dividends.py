from __future__ import annotations

from datetime import date
from pathlib import Path

from brvm.scrapers import dividends


FIXTURES_DIR = Path(__file__).parent / "fixtures"


class DummyResponse:
    def __init__(self, text: str) -> None:
        self.text = text


class DummySession:
    def __init__(self, html: str) -> None:
        self.html = html

    def get(self, url: str, params: dict | None = None) -> DummyResponse:
        _ = (url, params)
        return DummyResponse(self.html)


def test_fetch_dividends_normalizes_dates_and_amounts(monkeypatch) -> None:
    html = (FIXTURES_DIR / "richbourse_dividends.html").read_text(encoding="utf-8")
    monkeypatch.setattr(dividends, "get_brvm_session", lambda: DummySession(html))

    result = dividends.fetch_dividends("BOABF")

    assert list(result.columns) == [
        "symbol",
        "company_name",
        "amount_net",
        "yield_percent",
        "ex_date",
        "payment_date",
    ]
    assert result.iloc[0]["symbol"] == "BOABF"
    assert float(result.iloc[0]["amount_net"]) == 397
    assert float(result.iloc[0]["yield_percent"]) == 6.98
    assert result.iloc[0]["ex_date"] == date(2026, 4, 22)
    assert result.iloc[0]["payment_date"] == date(2026, 4, 23)
