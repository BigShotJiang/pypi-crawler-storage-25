from __future__ import annotations

import pytest
import httpx
import pandas as pd
from brvm.scrapers.umoatitres import fetch_yield_curve, UMOA_TITRES_YIELD_CURVE_URL

def test_fetch_yield_curve(monkeypatch):
    """Test fetch_yield_curve mocks HTML page and Excel file parsing."""
    
    class MockResponseHTML:
        def __init__(self, *args, **kwargs):
            self.text = '''<html>
                <body>
                    <a href="https://example.com/courbe-des-taux-test.xlsx">COURBES DE TAUX</a>
                </body>
            </html>'''
        def raise_for_status(self): pass

    class MockResponseExcel:
        def __init__(self, *args, **kwargs):
            import io
            self.content = io.BytesIO()
            with pd.ExcelWriter(self.content, engine='openpyxl') as writer:
                df1 = pd.DataFrame([
                    [None, None, None, None],
                    ["Maturité", "Zero Coupon", "Taux Après Lissage", "Extra"],
                    ["1 an", 0.05, 0.06, "junk"],
                    ["Junk row", None, None, "junk2"]
                ])
                df1.to_excel(writer, sheet_name="Mali", index=False, header=False)
                
                df2 = pd.DataFrame([
                    ["Maturité", "Zero Coupon", "Taux Après Lissage"],
                    ["3 mois", 0.02, 0.03]
                ])
                df2.to_excel(writer, sheet_name="Sénégal", index=False, header=False)
                
                df3 = pd.DataFrame([["Nothing"]])
                df3.to_excel(writer, sheet_name="Feuil1", index=False, header=False)

            self.content = self.content.getvalue()
        def raise_for_status(self): pass

    def mock_get(url, *args, **kwargs):
        if url == UMOA_TITRES_YIELD_CURVE_URL:
            return MockResponseHTML()
        else:
            return MockResponseExcel()
            
    class MockClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def get(self, url, *args, **kwargs):
            return mock_get(url)

    monkeypatch.setattr(httpx, "Client", MockClient)

    curves = fetch_yield_curve()
    
    assert len(curves) == 2
    
    mali = next(c for c in curves if c["country"] == "Mali")
    assert len(mali["yield_curve"]) == 1
    assert mali["yield_curve"][0]["maturite"] == "1 an"
    assert mali["yield_curve"][0]["zero_coupon"] == 0.05
    assert mali["yield_curve"][0]["taux_lissage"] == 0.06

    senegal = next(c for c in curves if c["country"] == "Sénégal")
    assert len(senegal["yield_curve"]) == 1
    assert senegal["yield_curve"][0]["maturite"] == "3 mois"
    assert senegal["yield_curve"][0]["zero_coupon"] == 0.02
    assert senegal["yield_curve"][0]["taux_lissage"] == 0.03

def test_fetch_adjudications_history_and_calendar(monkeypatch):
    """Test fetch_adjudications_history and fetch_adjudications_calendar."""
    from brvm.scrapers.umoatitres import fetch_adjudications_history, fetch_adjudications_calendar
    
    html = '''<html>
        <body>
            <table>
                <tr>
                    <th>Émetteur</th><th>Instrument</th><th>Précisions</th><th>Date de l'opération</th>
                    <th>Date de valeur</th><th>Échéance</th><th>Maturité(mois)</th><th>Différé(année)</th>
                    <th>Plus d'infos</th><th>Etat</th><th>Extra</th>
                </tr>
                <tr>
                    <td>Mali</td><td>BAT</td><td>Echange</td><td>01/01/2026</td>
                    <td>01/01/2026</td><td>01/01/2027</td><td>12</td><td>--</td>
                    <td><a href="/test-history">Link</a></td><td>réalisée</td><td>Extra</td>
                </tr>
            </table>
            <table>
                <tr>
                    <th>Émetteur</th><th>Instrument</th><th>Précisions</th><th>Date de l'opération</th>
                    <th>Date de valeur</th><th>Échéance</th><th>Montant(millions de FCFA)</th>
                    <th>Plus d'infos</th><th>Etat</th>
                </tr>
                <tr>
                    <td>Sénégal</td><td>OAT</td><td>--</td><td>02/01/2026</td>
                    <td>02/01/2026</td><td>02/01/2029</td><td>25000</td>
                    <td><a href="//test-calendar">Link</a></td><td>A venir</td>
                </tr>
            </table>
        </body>
    </html>'''

    class MockResponse:
        def __init__(self, *args, **kwargs):
            self.text = html
        def raise_for_status(self): pass

    class MockClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def get(self, *args, **kwargs): return MockResponse()

    monkeypatch.setattr(httpx, "Client", MockClient)

    history = fetch_adjudications_history(limit=10)
    assert len(history) == 1
    assert history[0]["issuer"] == "Mali"
    assert history[0]["url"] == "https://www.umoatitres.org/test-history"
    assert history[0]["status"] == "réalisée"

    calendar = fetch_adjudications_calendar(limit=10)
    assert len(calendar) == 1
    assert calendar[0]["issuer"] == "Sénégal"
    assert calendar[0]["url"] == "https://test-calendar"
    assert calendar[0]["amount_millions_cfa"] == "25000"

    from brvm.core import get_adjudications_history, get_adjudications_calendar
    assert len(get_adjudications_history()) == 1
    assert len(get_adjudications_calendar()) == 1

def test_fetch_adjudications_empty(monkeypatch):
    """Test adjudications returns empty list if tables are missing."""
    from brvm.scrapers.umoatitres import fetch_adjudications_history, fetch_adjudications_calendar
    class MockResponse:
        def __init__(self, *args, **kwargs):
            self.text = "<html><body><table></table></body></html>"
        def raise_for_status(self): pass
    class MockClient:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def get(self, *args, **kwargs): return MockResponse()

    monkeypatch.setattr(httpx, "Client", MockClient)
    assert fetch_adjudications_history() == []
    assert fetch_adjudications_calendar() == []
