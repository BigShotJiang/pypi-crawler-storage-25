from __future__ import annotations

import pytest
import pandas as pd
from brvm.scrapers.news import fetch_company_news
import brvm.scrapers.news as news_module

def test_fetch_company_news(monkeypatch):
    class MockResponse:
        def __init__(self, text):
            self.text = text
        def raise_for_status(self): pass

    class MockSession:
        def get(self, url, **kwargs):
            html = """
            <html><body><div class="contentpad">
              <div>
                <span>26/03/26 16:38</span>
                <a href="/marches/article_test">Titre Test</a>
              </div>
            </div></body></html>
            """
            return MockResponse(html)

    monkeypatch.setattr(news_module, "get_brvm_session", lambda: MockSession())
    
    res = fetch_company_news("SNTS")
    assert len(res) == 1
    assert res[0]["title"] == "Titre Test"
    assert res[0]["date"] == "26/03/26 16:38"
    assert res[0]["link"] == "https://www.sikafinance.com/marches/article_test"

def test_fetch_company_news_failure(monkeypatch):
    class MockSession:
        def get(self, url, **kwargs):
            raise Exception("Failure")
            
    monkeypatch.setattr(news_module, "get_brvm_session", lambda: MockSession())
    
    res = fetch_company_news("SNTS")
    assert res == []

def test_fetch_company_news_empty(monkeypatch):
    class MockResponse:
        def __init__(self, text):
            self.text = text
        def raise_for_status(self): pass
        
    class MockSession:
        def get(self, url, **kwargs):
            return MockResponse("<html><body></body></html>")
            
    monkeypatch.setattr(news_module, "get_brvm_session", lambda: MockSession())
    res = fetch_company_news("SNTS")
    assert res == []
