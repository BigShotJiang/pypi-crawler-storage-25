from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

import certifi

try:
    from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential
except ModuleNotFoundError:  # pragma: no cover - fallback for bare environments
    def retry(*args: Any, **kwargs: Any):  # type: ignore[override]
        def decorator(func: Any) -> Any:
            return func

        return decorator

    def retry_if_exception_type(*args: Any, **kwargs: Any) -> None:
        return None

    def stop_after_attempt(*args: Any, **kwargs: Any) -> None:
        return None

    def wait_exponential(*args: Any, **kwargs: Any) -> None:
        return None

if TYPE_CHECKING:
    import httpx


logger = logging.getLogger(__name__)

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
}

_client_singleton: "BRVMClient | None" = None


def _load_httpx() -> Any:
    import httpx

    return httpx


class BRVMClient:
    """HTTP client shared by source adapters."""

    def __init__(
        self,
        *,
        timeout: float = 20.0,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        httpx = _load_httpx()
        merged_headers = {**DEFAULT_HEADERS, **dict(headers or {})}
        self._httpx = httpx
        self._session = httpx.Client(
            headers=merged_headers,
            timeout=timeout,
            verify=certifi.where(),
        )
        self._insecure_session = httpx.Client(
            headers=merged_headers,
            timeout=timeout,
            verify=False,
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    def get(
        self, url: str, *, params: Mapping[str, Any] | None = None
    ) -> "httpx.Response":
        logger.debug("GET %s params=%s", url, params)
        response = self._request_with_tls_fallback("GET", url, params=params)
        response.raise_for_status()
        return response

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    def post(
        self, url: str, *, data: Mapping[str, Any] | None = None
    ) -> "httpx.Response":
        logger.debug("POST %s", url)
        response = self._request_with_tls_fallback("POST", url, data=data)
        response.raise_for_status()
        return response

    def close(self) -> None:
        self._session.close()
        self._insecure_session.close()

    def __enter__(self) -> "BRVMClient":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def _request_with_tls_fallback(
        self,
        method: str,
        url: str,
        *,
        params: Mapping[str, Any] | None = None,
        data: Mapping[str, Any] | None = None,
    ) -> "httpx.Response":
        try:
            return self._session.request(method, url, params=params, data=data)
        except Exception as exc:
            if "CERTIFICATE_VERIFY_FAILED" not in str(exc):
                raise

            logger.warning(
                "TLS verification failed for %s; retrying with certificate checks disabled.",
                url,
            )
            return self._insecure_session.request(method, url, params=params, data=data)


def get_brvm_session() -> BRVMClient:
    global _client_singleton
    if _client_singleton is None:
        _client_singleton = BRVMClient()
    return _client_singleton
