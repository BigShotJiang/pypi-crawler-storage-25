from __future__ import annotations

import sqlite3
import logging
import os
import sqlite3
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

# Options par défaut
DEFAULT_CACHE_DIR = Path.home() / ".brvm_cache.db"
TTL_EOD = timedelta(hours=12)
TTL_STATIC = timedelta(days=7)

_USE_CACHE = True

def disable_cache():
    """Désactive le cache de manière globale."""
    global _USE_CACHE
    _USE_CACHE = False
    logger.info("BRVM cache disabled.")

def enable_cache():
    """Réactive le cache de manière globale."""
    global _USE_CACHE
    _USE_CACHE = True
    logger.info("BRVM cache enabled.")

def is_cache_enabled():
    """Vérifie si le cache est actif."""
    return _USE_CACHE

def get_db_path() -> Path:
    """Récupère le chemin du cache."""
    # Override via var env
    env_path = os.environ.get("BRVM_CACHE_DIR")
    if env_path:
        return Path(env_path)
    return DEFAULT_CACHE_DIR

def _get_connection() -> sqlite3.Connection:
    """Ouvre et gère la connexion locale."""
    path = get_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    # Active la vérification des foreign keys
    conn.execute("PRAGMA foreign_keys = 1")
    return conn

def init_db():
    conn = _get_connection()
    c = conn.cursor()
    # Métadonnées cache pour gérer le TTL
    c.execute('''
        CREATE TABLE IF NOT EXISTS cache_meta (
            key TEXT PRIMARY KEY,
            updated_at TIMESTAMP NOT NULL
        )
    ''')
    # Tickers
    c.execute('''
        CREATE TABLE IF NOT EXISTS tickers (
            id TEXT PRIMARY KEY,
            nom_entreprise TEXT,
            secteur_activite TEXT,
            type_instrument TEXT
        )
    ''')
    # Historique de cotations
    c.execute('''
        CREATE TABLE IF NOT EXISTS daily_quotes (
            date TIMESTAMP,
            ticker_id TEXT,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            adj_close REAL,
            volume INTEGER CHECK(volume >= 0),
            value REAL,
            trading_status TEXT,
            PRIMARY KEY (date, ticker_id),
            FOREIGN KEY (ticker_id) REFERENCES tickers(id) ON DELETE CASCADE
        )
    ''')
    # Fondamentaux
    c.execute('''
        CREATE TABLE IF NOT EXISTS fundamentals (
            ticker_id TEXT,
            annee_fiscale INTEGER,
            per REAL,
            rendement_dividende REAL,
            capitalisation REAL,
            roe REAL,
            PRIMARY KEY (ticker_id, annee_fiscale),
            FOREIGN KEY (ticker_id) REFERENCES tickers(id) ON DELETE CASCADE
        )
    ''')
    # Dividendes
    c.execute('''
        CREATE TABLE IF NOT EXISTS dividends (
            ticker_id TEXT,
            date_detachement TIMESTAMP,
            montant_net REAL,
            PRIMARY KEY (ticker_id, date_detachement),
            FOREIGN KEY (ticker_id) REFERENCES tickers(id) ON DELETE CASCADE
        )
    ''')
    conn.commit()
    conn.close()

def _set_updated(key: str):
    conn = _get_connection()
    c = conn.cursor()
    c.execute(
        "INSERT OR REPLACE INTO cache_meta (key, updated_at) VALUES (?, ?)", 
        (key, datetime.now())
    )
    conn.commit()
    conn.close()

def _check_valid(key: str, ttl: timedelta) -> bool:
    if not is_cache_enabled():
        return False
        
    conn = _get_connection()
    c = conn.cursor()
    c.execute("SELECT updated_at FROM cache_meta WHERE key = ?", (key,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        return False
        
    try:
        updated_at = datetime.fromisoformat(row[0] if isinstance(row[0], str) else str(row[0]))
        return datetime.now() - updated_at < ttl
    except Exception:
        return False

# ----- Operations sur le Tickers Cache -----
def cache_set_tickers(df: pd.DataFrame):
    if not is_cache_enabled(): return
    conn = _get_connection()
    lock_path = str(get_db_path()) + ".lock"
    # Simple to_sql save, ignoring FK constraints temporarily for initial load or just parsing properly
    # A plus sûr: utiliser to_sql avec if_exists="replace" si c'est pour l'API. Or, la table est définie custom.
    # Pour garder la structure du CC:
    try:
        df_copy = df.copy()
        if 'symbol' in df_copy.columns:
            df_copy = df_copy.rename(columns={'symbol': 'id'})
        
        # On ne stocke que les colonnes prévues (simplification).
        # Normalement on utilise REPLACE pour gérer les doublons SQLite
        # pandas to_sql doesn't support REPLACE directly on all sqlite versions natively without extra dialect args.
        # So we delete and insert.
        c = conn.cursor()
        c.execute("DELETE FROM tickers")
        df_copy.to_sql("tickers", conn, if_exists="append", index=False)
        _set_updated("tickers")
    except Exception as e:
        logger.warning(f"Failed to cache tickers: {e}")
    finally:
        conn.close()

def cache_get_tickers() -> pd.DataFrame:
    if not _check_valid("tickers", TTL_STATIC):
        return None
    try:
        conn = _get_connection()
        df = pd.read_sql("SELECT * FROM tickers", conn)
        conn.close()
        # Remapper id -> symbol si convention interne
        df = df.rename(columns={'id': 'symbol'})
        return df if not df.empty else None
    except Exception:
        return None

# ----- Operations sur le Quotes Cache -----
def cache_set_history(symbol: str, df: pd.DataFrame):
    if not is_cache_enabled() or df.empty: return
    conn = _get_connection()
    try:
        c = conn.cursor()
        c.execute("DELETE FROM daily_quotes WHERE ticker_id = ?", (symbol,))
        
        df_copy = df.copy()
        df_copy['ticker_id'] = symbol
        # Ensure date format as string or datetime
        df_copy['date'] = pd.to_datetime(df_copy['date'])
        
        # Safe insert
        df_copy.to_sql("daily_quotes", conn, if_exists="append", index=False)
        _set_updated(f"history_{symbol}")
    except Exception as e:
        logger.warning(f"Failed to cache history for {symbol}: {e}")
    finally:
        conn.close()

def cache_get_history(symbol: str) -> pd.DataFrame:
    if not _check_valid(f"history_{symbol}", TTL_EOD):
        return None
    try:
        conn = _get_connection()
        df = pd.read_sql("SELECT * FROM daily_quotes WHERE ticker_id = ? ORDER BY date ASC", conn, params=(symbol,))
        conn.close()
        
        if df.empty:
            return None
            
        df['date'] = pd.to_datetime(df['date']).dt.date
        df = df.drop(columns=['ticker_id'])
        return df
    except Exception:
        return None

# Initialisation 
try:
    init_db()
except Exception as e:
    logger.warning(f"Cache DB init failed: {e}")
