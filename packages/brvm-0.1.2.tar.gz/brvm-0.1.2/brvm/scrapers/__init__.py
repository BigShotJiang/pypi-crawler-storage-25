from __future__ import annotations

"""Source adapters for BRVM upstream websites."""
