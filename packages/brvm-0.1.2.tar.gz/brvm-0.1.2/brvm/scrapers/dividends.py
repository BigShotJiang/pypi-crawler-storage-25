from __future__ import annotations

from io import StringIO

import pandas as pd

from brvm.client import get_brvm_session

RICHBOURSE_DIVIDENDS_URL = "https://www.richbourse.com/common/dividende/index/{symbol}"


def _normalize_number(series: pd.Series) -> pd.Series:
    cleaned = (
        series.astype(str)
        .str.replace("\xa0", "", regex=False)
        .str.replace(" ", "", regex=False)
        .str.replace("%", "", regex=False)
        .str.replace(",", ".", regex=False)
    )
    return pd.to_numeric(cleaned, errors="coerce")


def fetch_dividends(symbol: str) -> pd.DataFrame:
    response = get_brvm_session().get(
        RICHBOURSE_DIVIDENDS_URL.format(symbol=symbol),
        params={"sort": "-montant_dividende"},
    )
    tables = pd.read_html(StringIO(response.text))
    table = _extract_dividend_table(tables)
    if table.empty:
        return pd.DataFrame(
            columns=["symbol", "company_name", "amount_net", "yield_percent", "ex_date", "payment_date"]
        )

    table = table.rename(
        columns={
            "Société": "company_name",
            "Dividende": "amount_net",
            "Rendement": "yield_percent",
            "Ex-dividende": "ex_date",
            "Date paiement": "payment_date",
        }
    )

    table = table.loc[:, ["company_name", "amount_net", "yield_percent", "ex_date", "payment_date"]].copy()
    table["symbol"] = symbol
    table["amount_net"] = _normalize_number(table["amount_net"])
    table["yield_percent"] = _normalize_number(table["yield_percent"])
    table["ex_date"] = pd.to_datetime(table["ex_date"], format="%d/%m/%Y", errors="coerce").dt.date
    table["payment_date"] = pd.to_datetime(
        table["payment_date"], format="%d/%m/%Y", errors="coerce"
    ).dt.date

    return table[
        ["symbol", "company_name", "amount_net", "yield_percent", "ex_date", "payment_date"]
    ].reset_index(drop=True)


def _extract_dividend_table(tables: list[pd.DataFrame]) -> pd.DataFrame:
    required = {"Société", "Dividende", "Rendement", "Ex-dividende", "Date paiement"}
    for table in tables:
        if required.issubset(set(table.columns)):
            first_value = str(table.iloc[0, 0]).strip() if not table.empty else ""
            if "Aucun résultat trouvé" in first_value:
                return pd.DataFrame()
            return table.copy()
    return pd.DataFrame()
