from __future__ import annotations

import re
from io import StringIO

import pandas as pd
from bs4 import BeautifulSoup

from brvm.client import get_brvm_session

SIKA_AAZ_URL = "https://www.sikafinance.com/marches/aaz"
SIKA_SOCIETE_URL = "https://www.sikafinance.com/marches/societe/{slug}"
SIKA_COTATION_URL = "https://www.sikafinance.com/marches/cotation_{slug}"


def _normalize_number(value: object) -> float | None:
    if value is None or pd.isna(value):
        return None
    cleaned = (
        str(value)
        .replace("\xa0", "")
        .replace(" ", "")
        .replace("%", "")
        .replace(",", ".")
    )
    cleaned = re.sub(r"[^0-9.\-]", "", cleaned)
    if cleaned == "" or cleaned.lower() == "nan":
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def fetch_symbol_slug_map() -> dict[str, str]:
    html = get_brvm_session().get(SIKA_AAZ_URL).text
    soup = BeautifulSoup(html, "lxml")
    mapping: dict[str, str] = {}
    for option in soup.find_all("option"):
        value = option.get("value")
        if not value or "." not in value:
            continue
        symbol = value.split(".", 1)[0].upper()
        mapping[symbol] = value
    return mapping


def fetch_company_info(symbol: str) -> dict[str, object]:
    slug_map = fetch_symbol_slug_map()
    slug = slug_map.get(symbol.upper())
    if not slug:
        return {}

    cotation_html = get_brvm_session().get(SIKA_COTATION_URL.format(slug=slug)).text
    societe_html = get_brvm_session().get(SIKA_SOCIETE_URL.format(slug=slug)).text

    quote_metrics = _extract_key_value_tables(cotation_html)
    profile = _extract_company_profile(societe_html)

    return {
        "symbol": symbol.upper(),
        "name": profile.get("company_name"),
        "sector": profile.get("sector"),
        "capitalization": _million_xof_to_xof(profile.get("capitalization_mfcfa")),
        "currency": "XOF",
        "shares_outstanding": _normalize_number(profile.get("shares_outstanding")),
        "free_float_percent": _normalize_number(profile.get("free_float_percent")),
        "chief_executive_officer": profile.get("chief_executive_officer"),
        "address": profile.get("address"),
        "market_cap_percent_traded": _normalize_number(quote_metrics.get("Capital échangé")),
        "valuation_mfcfa": _normalize_number(quote_metrics.get("Valorisation")),
        "open": _normalize_number(quote_metrics.get("Ouverture")),
        "high": _normalize_number(quote_metrics.get("Plus haut")),
        "low": _normalize_number(quote_metrics.get("Plus bas")),
        "previous_close": _normalize_number(quote_metrics.get("Clôture veille")),
        "volume": _normalize_number(quote_metrics.get("Volume (titres)")),
        "value": _normalize_number(quote_metrics.get("Volume ( )")),
        "beta_1y": _divide_by_100(_normalize_number(quote_metrics.get("Beta 1 an"))),
        "rsi": _divide_by_100(_normalize_number(quote_metrics.get("RSI"))),
        "principal_shareholders": profile.get("principal_shareholders"),
    }


def fetch_fundamentals_history(symbol: str) -> pd.DataFrame:
    slug_map = fetch_symbol_slug_map()
    slug = slug_map.get(symbol.upper())
    if not slug:
        return pd.DataFrame(
            columns=[
                "symbol",
                "fiscal_year",
                "per",
                "roe",
                "dividend_yield",
                "capitalization",
                "revenue",
                "net_income",
                "eps",
                "dividend_amount",
            ]
        )

    html = get_brvm_session().get(SIKA_SOCIETE_URL.format(slug=slug)).text
    table = _extract_financial_table(html)
    if table.empty:
        return pd.DataFrame(
            columns=[
                "symbol",
                "fiscal_year",
                "per",
                "roe",
                "dividend_yield",
                "capitalization",
                "revenue",
                "net_income",
                "eps",
                "dividend_amount",
            ]
        )

    metrics = {
        str(row.iloc[0]).strip(): row.iloc[1:].tolist()
        for _, row in table.iterrows()
    }
    years = [int(str(col)) for col in table.columns[1:]]
    yields_by_year = _extract_dividend_yields(html)
    if not yields_by_year:
        cotation_html = get_brvm_session().get(SIKA_COTATION_URL.format(slug=slug)).text
        yields_by_year = _extract_dividend_yields(cotation_html)

    rows: list[dict[str, object]] = []
    for idx, year in enumerate(years):
        rows.append(
            {
                "symbol": symbol.upper(),
                "fiscal_year": year,
                "per": _scaled_metric(metrics.get("PER", []), idx, scale=100),
                "roe": None,
                "dividend_yield": yields_by_year.get(year),
                "capitalization": None,
                "revenue": _normalize_metric(metrics.get("Chiffre d'affaires", []), idx),
                "net_income": _normalize_metric(metrics.get("Résultat net", []), idx),
                "eps": _scaled_metric(metrics.get("BNPA", []), idx, scale=100),
                "dividend_amount": _scaled_metric(metrics.get("Dividende", []), idx, scale=100),
            }
        )

    return pd.DataFrame(rows)


def _extract_financial_table(html: str) -> pd.DataFrame:
    tables = pd.read_html(StringIO(html))
    for table in tables:
        columns = {str(col) for col in table.columns}
        if "Unnamed: 0" in columns and any(str(col).isdigit() for col in table.columns[1:]):
            return table.copy()
    return pd.DataFrame()


def _extract_dividend_yields(html: str) -> dict[int, float]:
    match = re.search(
        r'var labels2 = \[(.*?)\];\s*var dividends2 = \[(.*?)\];\s*var yields2 = \[(.*?)\];',
        html,
        re.S,
    )
    if not match:
        return {}

    years = [int(part.strip().strip('"')) for part in match.group(1).split(",") if part.strip()]
    yields = [_normalize_number(part.strip()) for part in match.group(3).split(",")]
    return {
        year: value
        for year, value in zip(years, yields, strict=False)
        if value is not None
    }


def _extract_key_value_tables(html: str) -> dict[str, object]:
    metrics: dict[str, object] = {}
    tables = pd.read_html(StringIO(html))
    for table in tables:
        if table.shape[1] != 2:
            continue
        for _, row in table.iterrows():
            key = str(row.iloc[0]).strip()
            value = row.iloc[1]
            metrics[key] = value
    return metrics


def _extract_company_profile(html: str) -> dict[str, object]:
    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text("\n", strip=True)

    company_name = None
    title_match = re.search(r"([A-Z0-9' .-]+), fiche société", text)
    if title_match:
        company_name = title_match.group(1).strip()

    section_match = re.search(
        r"Adresse\s*:\s*(?P<address>.*?)\s*Dirigeants\s*:\s*Directeur Général\s*:\s*(?P<ceo>.*?)\s*Nombre de titres\s*:\s*(?P<shares>.*?)\s*Flottant\s*:\s*(?P<float>.*?)\s*Valorisation de la société\s*:\s*(?P<valuation>.*?)\s*Principaux actionnaires\s*(?P<holders>.*?)\s*Les chiffres sont en millions de FCFA",
        text,
        re.S,
    )
    if not section_match:
        return {
            "company_name": company_name,
            "sector": _extract_sector(text),
        }

    return {
        "company_name": company_name,
        "sector": _extract_sector(text),
        "address": " ".join(section_match.group("address").split()),
        "chief_executive_officer": " ".join(section_match.group("ceo").split()),
        "shares_outstanding": section_match.group("shares"),
        "free_float_percent": section_match.group("float"),
        "capitalization_mfcfa": section_match.group("valuation"),
        "principal_shareholders": _parse_shareholders(section_match.group("holders")),
    }


def _extract_sector(text: str) -> str | None:
    upper_text = text.upper()
    if "BANK OF AFRICA" in upper_text or "BANQUE" in upper_text:
        return "Finance"
    sector_match = re.search(r"Secteur\s*:\s*([A-ZÉÈÊÀÙÛÎÔÇ /-]+)", text)
    if sector_match:
        return sector_match.group(1).strip().title()
    return None


def _parse_shareholders(raw_value: str) -> list[dict[str, object]]:
    holders: list[dict[str, object]] = []
    for item in raw_value.split(";"):
        item = item.strip()
        if not item or "*" not in item:
            continue
        name, percent = item.rsplit("*", 1)
        holders.append(
            {
                "name": name.strip(),
                "percent": _normalize_number(percent),
            }
        )
    return holders


def _normalize_metric(values: list[object], idx: int) -> float | None:
    if idx >= len(values):
        return None
    return _normalize_number(values[idx])


def _scaled_metric(values: list[object], idx: int, *, scale: int) -> float | None:
    raw_value = _normalize_metric(values, idx)
    if raw_value is None:
        return None
    return raw_value / scale


def _million_xof_to_xof(value: object) -> float | None:
    normalized = _normalize_number(value)
    if normalized is None:
        return None
    return normalized * 1_000_000


def _divide_by_100(value: float | None) -> float | None:
    if value is None:
        return None
    return value / 100
