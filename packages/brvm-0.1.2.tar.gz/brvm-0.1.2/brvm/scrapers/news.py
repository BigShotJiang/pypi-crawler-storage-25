from __future__ import annotations

import re
from typing import List, Dict, Optional
from bs4 import BeautifulSoup
from brvm.client import get_brvm_session

def fetch_company_news(symbol: str) -> List[Dict[str, str]]:
    """
    Fetch the latest news for a specific symbol from SikaFinance.
    Args:
        symbol (str): The ticker symbol (e.g., 'SNTS').
    Returns:
        List[Dict[str, str]]: A list of dictionaries containing 'date', 'title', and 'link'.
    """
    url = f"https://www.sikafinance.com/marches/news_valeur?s={symbol}.sn"
    session = get_brvm_session()
    
    try:
        response = session.get(url)
        response.raise_for_status()
    except Exception as e:
        print(f"Error fetching news for {symbol}: {e}")
        return []

    soup = BeautifulSoup(response.text, 'lxml')
    content = soup.find('div', class_='contentpad')
    
    news_items = []
    
    if not content:
        return news_items

    # Depending on the layout Sika Finance is using, Sika outputs dates and links inside one common div.
    for tag in content.children:
        if tag.name == 'div':
            # SikaFinance lumps dates in spans right before the a tags inside the div
            for a_child in tag.find_all('a'):
                href = a_child.get('href', '')
                if ('/marches/' in href or '/premium/' in href) and not any(x in href for x in ['cotation', 'graph', 'news_valeur', 'historiques', 'secteur', 'events', 'societe', '?s=', 'brvm', 'palmares', 'convertisseur', 'communiques']):
                    title = a_child.text.strip()
                    if not title:
                        continue
                    
                    date_str = ""
                    prev_span = a_child.find_previous_sibling('span')
                    if prev_span:
                        date_str = prev_span.text.strip()
                        
                    news_items.append({
                        'date': date_str,
                        'title': title,
                        'link': f"https://www.sikafinance.com{href}"
                    })
    
    return news_items
