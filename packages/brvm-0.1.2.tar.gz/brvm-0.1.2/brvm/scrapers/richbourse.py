from __future__ import annotations

from io import StringIO

import pandas as pd

from brvm.client import get_brvm_session

RICHBOURSE_INDEX_HISTORY_URLS = [
    "https://www.richbourse.com/common/variation/historique-indice/{symbol}",
]
RICHBOURSE_EQUITY_HISTORY_URLS = [
    "https://www.richbourse.com/common/variation/historique/{symbol}",
    "https://www.richbourse.com/common/variation/historique-valeur/{symbol}",
    "https://www.richbourse.com/common/variation/historique-action/{symbol}",
]


def _normalize_number(series: pd.Series) -> pd.Series:
    cleaned = (
        series.astype(str)
        .str.replace("\xa0", "", regex=False)
        .str.replace(" ", "", regex=False)
        .str.replace("%", "", regex=False)
        .str.replace(",", ".", regex=False)
    )
    return pd.to_numeric(cleaned, errors="coerce")


def _read_history_table(html: str) -> pd.DataFrame:
    tables = pd.read_html(StringIO(html))
    if not tables:
        return pd.DataFrame()

    for table in tables:
        lowered = {str(column).lower() for column in table.columns}
        if "date" in lowered and ("cours" in lowered or "variation (%)" in lowered):
            first_value = str(table.iloc[0, 0]).strip() if not table.empty else ""
            if "Aucun résultat trouvé" in first_value:
                return pd.DataFrame()
            return table.copy()
    return pd.DataFrame()


def fetch_history(
    symbol: str,
    *,
    is_index: bool = False,
    max_pages: int = 40,
    start_date: object | None = None,
) -> pd.DataFrame:
    base_urls = (
        RICHBOURSE_INDEX_HISTORY_URLS if is_index else RICHBOURSE_EQUITY_HISTORY_URLS
    )

    frames: list[pd.DataFrame] = []
    for pattern in base_urls:
        frames = _fetch_from_base_url(
            pattern.format(symbol=symbol),
            max_pages=max_pages,
            start_date=start_date,
        )
        if frames:
            break

    if not frames:
        return pd.DataFrame(
            columns=["date", "open", "high", "low", "close", "adj_close", "volume", "value", "trading_status"]
        )

    history = pd.concat(frames, ignore_index=True).drop_duplicates(subset=["date"])

    rename_map = {
        "cours": "close",
        "variation (%)": "variation",
        "volume": "volume",
        "valeur": "value",
        "valeur (fcfa)": "value",
        "cours ajusté": "adj_close",
        "volume ajusté": "volume_adjusted",
        "cours normal": "close",
        "volume normal": "volume",
    }
    history = history.rename(columns=rename_map)
    history["date"] = pd.to_datetime(history["date"], format="%d/%m/%Y", errors="coerce").dt.date

    for column in ["close", "adj_close", "variation", "volume", "value", "volume_adjusted"]:
        if column in history.columns:
            history[column] = _normalize_number(history[column])

    if "volume" not in history.columns:
        history["volume"] = 0
    if "value" not in history.columns:
        history["value"] = 0
    if "adj_close" not in history.columns:
        history["adj_close"] = history.get("close")

    history["trading_status"] = "CO"
    history.loc[history["volume"].fillna(0) == 0, "trading_status"] = "NC"
    history["open"] = pd.NA
    history["high"] = pd.NA
    history["low"] = pd.NA

    history = history[
        ["date", "open", "high", "low", "close", "adj_close", "volume", "value", "trading_status"]
    ].sort_values("date")

    return history.reset_index(drop=True)


def _fetch_from_base_url(base_url: str, *, max_pages: int, start_date: object | None) -> list[pd.DataFrame]:
    frames: list[pd.DataFrame] = []
    seen_dates: set[str] = set()

    for page in range(1, max_pages + 1):
        try:
            response = get_brvm_session().get(base_url, params={"page": page, "sort": "-date"})
        except Exception:
            break

        table = _read_history_table(response.text)
        if table.empty:
            break

        table.columns = [str(column).strip().lower() for column in table.columns]
        if "date" not in table.columns:
            break

        parsed_dates = pd.to_datetime(table["date"], format="%d/%m/%Y", errors="coerce")
        oldest_date = parsed_dates.min()

        current_dates = set(table["date"].astype(str))
        if current_dates and current_dates.issubset(seen_dates):
            break

        seen_dates.update(current_dates)
        frames.append(table)
        if start_date is not None and pd.notna(oldest_date) and oldest_date.date() <= start_date:
            break

    return frames
