from __future__ import annotations

import io
import re

import pandas as pd
import pdfplumber
from bs4 import BeautifulSoup

from brvm.client import get_brvm_session

BOC_LIST_URL = "https://www.brvm.org/fr/bulletins-officiels-de-la-cote"


def _clean_number(val: str) -> float | None:
    v = val.replace(" ", "").replace("\xa0", "").replace(",", ".")
    try:
        return float(v)
    except ValueError:
        return None


def fetch_latest_boc_url() -> str:
    response = get_brvm_session().get(BOC_LIST_URL)
    soup = BeautifulSoup(response.text, "lxml")
    for a in soup.find_all("a", href=re.compile(r'\.pdf$', re.IGNORECASE)):
        href = str(a.get("href"))
        if href.startswith("/"):
            href = "https://www.brvm.org" + href
        return href
    raise RuntimeError("No BOC PDF found on BRVM website.")


def fetch_latest_boc() -> pd.DataFrame:
    url = fetch_latest_boc_url()
    response = get_brvm_session().get(url)
    pdf_bytes = response.content

    rows: list[dict[str, object]] = []
    
    # Regex to extract: Symbol, Name, Previous Close, Open, Close, Variation %
    pattern = re.compile(
        r'^([A-Z]{4})\s+(.+?)\s+(\d{1,3}(?: \d{3})*)\s+(\d{1,3}(?: \d{3})*)\s+(\d{1,3}(?: \d{3})*)\s+(-?\d+,\d{1,2})\s*%(.*)$'
    )

    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue
            for line in text.split('\n'):
                line = line.strip()
                match = pattern.match(line)
                if match:
                    res = match.groups()
                    sym = res[0].strip()
                    name = res[1].strip()
                    prev = res[2]
                    open_px = res[3]
                    close_px = res[4]
                    var = res[5]
                    rows.append({
                        "symbol": sym,
                        "name": name,
                        "previous_close": _clean_number(prev),
                        "open": _clean_number(open_px),
                        "close": _clean_number(close_px),
                        "variation_percent": _clean_number(var),
                    })

    df = pd.DataFrame(rows)
    return df.drop_duplicates(subset=["symbol"]).reset_index(drop=True)

def fetch_latest_boc_cached() -> pd.DataFrame:
    return fetch_latest_boc()
