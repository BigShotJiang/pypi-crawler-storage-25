from __future__ import annotations

from io import StringIO

import pandas as pd

from brvm.client import get_brvm_session

BRVM_ACTIONS_URL = "https://www.brvm.org/fr/cours-actions/investisseurs/portefeuille"
BRVM_BONDS_URL = "https://www.brvm.org/fr/cours-obligations/investisseurs/portefeuille"

INDEX_ALIASES = {
    "BRVM-COMP": "BRVM Composite",
    "BRVM10": "BRVM 10",
    "BRVM-PREST": "BRVM Prestige",
}

RICHBOURSE_INDEX_SLUGS = {
    "BRVM-COMP": "BRVM-COMPOSITE",
    "BRVM10": "BRVM-10",
    "BRVM-PREST": "BRVM-PRESTIGE",
}


def _normalize_number(series: pd.Series) -> pd.Series:
    cleaned = (
        series.astype(str)
        .str.replace("\xa0", "", regex=False)
        .str.replace(" ", "", regex=False)
        .str.replace("%", "", regex=False)
        .str.replace(",", ".", regex=False)
    )
    return pd.to_numeric(cleaned, errors="coerce")


def fetch_tickers() -> pd.DataFrame:
    response = get_brvm_session().get(BRVM_ACTIONS_URL)
    tables = pd.read_html(StringIO(response.text))
    table = _extract_quotes_table(tables)
    if table.empty:
        return pd.DataFrame(columns=["id", "name", "instrument_type", "sector"])
    column_map = {
        "Symbole": "id",
        "Nom": "name",
    }
    table = table.rename(columns=column_map)
    instruments = table.loc[:, ["id", "name"]].copy()
    instruments["id"] = instruments["id"].astype(str).str.strip().str.upper()
    instruments["name"] = instruments["name"].astype(str).str.strip()
    instruments["instrument_type"] = "EQUITY"
    instruments["sector"] = pd.NA

    # Fetch bonds
    bond_instruments = pd.DataFrame(columns=["id", "name", "instrument_type", "sector"])
    try:
        res_bonds = get_brvm_session().get(BRVM_BONDS_URL)
        bond_tables = pd.read_html(StringIO(res_bonds.text))
        for t in bond_tables:
            if "Code obligation" in t.columns:
                bonds_df = t.rename(columns={"Code obligation": "id", "Nom": "name"})
                bonds_df = bonds_df.loc[:, ["id", "name"]].copy()
                bonds_df["id"] = bonds_df["id"].astype(str).str.strip().str.upper()
                bonds_df["name"] = bonds_df["name"].astype(str).str.strip()
                bonds_df["instrument_type"] = "BOND"
                bonds_df["sector"] = pd.NA
                bond_instruments = bonds_df
                break
    except Exception:
        pass

    indices = pd.DataFrame(
        {
            "id": list(INDEX_ALIASES.keys()),
            "name": list(INDEX_ALIASES.values()),
            "instrument_type": "INDEX",
            "sector": pd.NA,
        }
    )
    combined = pd.concat([instruments, bond_instruments, indices], ignore_index=True)
    return combined.drop_duplicates(subset=["id"]).sort_values("id").reset_index(drop=True)


def fetch_latest_quotes() -> pd.DataFrame:
    response = get_brvm_session().get(BRVM_ACTIONS_URL)
    tables = pd.read_html(StringIO(response.text))
    table = _extract_quotes_table(tables)
    
    if table.empty:
        equities_df = pd.DataFrame(
            columns=["symbol", "name", "open", "close", "volume", "previous_close", "variation"]
        )
    else:
        equities_df = table.rename(
            columns={
                "Symbole": "symbol",
                "Nom": "name",
                "Volume": "volume",
                "Cours veille (FCFA)": "previous_close",
                "Cours Ouverture (FCFA)": "open",
                "Cours Clôture (FCFA)": "close",
                "Variation (%)": "variation",
            }
        ).loc[:, ["symbol", "name", "open", "close", "volume", "previous_close", "variation"]].copy()
        
    try:
        res_bonds = get_brvm_session().get(BRVM_BONDS_URL)
        bond_tables = pd.read_html(StringIO(res_bonds.text))
        bond_df = pd.DataFrame()
        for t in bond_tables:
            if "Code obligation" in t.columns:
                bond_df = t.rename(
                    columns={
                        "Code obligation": "symbol",
                        "Nom": "name",
                        "Cours du jour en valeur": "close",
                    }
                ).loc[:, ["symbol", "name", "close"]].copy()
                bond_df["open"] = pd.NA
                bond_df["volume"] = 0
                bond_df["previous_close"] = pd.NA
                bond_df["variation"] = pd.NA
                break
    except Exception:
        bond_df = pd.DataFrame()
        
    combined = pd.concat([equities_df, bond_df], ignore_index=True)
    if combined.empty:
        return combined
        
    combined["symbol"] = combined["symbol"].astype(str).str.strip().str.upper()
    for column in ["open", "close", "volume", "previous_close", "variation"]:
        combined[column] = _normalize_number(combined[column])
    return combined


def _extract_quotes_table(tables: list[pd.DataFrame]) -> pd.DataFrame:
    required = {"Symbole", "Nom", "Volume", "Cours Clôture (FCFA)"}
    for table in tables:
        if required.issubset(set(table.columns)):
            return table.copy()
    return pd.DataFrame()
