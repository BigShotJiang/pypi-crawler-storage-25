"""Public package exports for the BRVM Python library."""

from .core import (
    get_company_info,
    get_dividends,
    get_fundamentals_history,
    get_history,
    get_index_history,
    get_quote,
    get_tickers,
)
from .exceptions import (
    BRVMError,
    DataValidationError,
    InvalidSymbolError,
    SourceUnavailableError,
)

__all__ = [
    "BRVMError",
    "DataValidationError",
    "InvalidSymbolError",
    "SourceUnavailableError",
    "get_company_info",
    "get_dividends",
    "get_fundamentals_history",
    "get_history",
    "get_index_history",
    "get_quote",
    "get_tickers",
]
