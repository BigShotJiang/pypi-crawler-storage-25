from __future__ import annotations

class BRVMError(Exception):
    """Base exception for the brvm package."""


class InvalidSymbolError(BRVMError):
    """Raised when a requested symbol is not covered by the package."""


class SourceUnavailableError(BRVMError):
    """Raised when all configured upstream sources are unavailable."""


class DataValidationError(BRVMError):
    """Raised when scraped payloads cannot be normalized safely."""
