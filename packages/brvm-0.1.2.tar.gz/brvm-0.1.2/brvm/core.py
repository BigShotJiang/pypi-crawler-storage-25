from __future__ import annotations

from datetime import date, datetime
from typing import Any

import pandas as pd

from brvm.exceptions import InvalidSymbolError, SourceUnavailableError
from brvm.scrapers.brvm_official import (
    INDEX_ALIASES,
    RICHBOURSE_INDEX_SLUGS,
    fetch_latest_quotes,
    fetch_tickers,
)
from brvm.scrapers.dividends import fetch_dividends
from brvm.scrapers.boc import fetch_latest_boc
from brvm.scrapers.richbourse import fetch_history as fetch_richbourse_history
from brvm.scrapers.sika import (
    fetch_company_info as fetch_sika_company_info,
    fetch_fundamentals_history as fetch_sika_fundamentals_history,
)
from brvm.scrapers.news import fetch_company_news



from brvm.cache import (
    cache_get_tickers,
    cache_set_tickers,
    cache_get_history,
    cache_set_history,
    disable_cache,
    enable_cache,
)

def _coerce_date(value: str | date | datetime | None) -> date | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(value)


def _normalize_symbol(symbol: str) -> str:
    return symbol.strip().upper()


def _is_index(symbol: str) -> bool:
    normalized = _normalize_symbol(symbol)
    return normalized in INDEX_ALIASES


def get_tickers() -> pd.DataFrame:
    """Return the list of covered BRVM instruments as a normalized DataFrame."""
    cached = cache_get_tickers()
    if cached is not None:
        return cached

    df = fetch_tickers()
    if not df.empty:
        cache_set_tickers(df)
    return df


def get_history(
    symbol: str,
    start: str | date | datetime | None = None,
    end: str | date | datetime | None = None,
) -> pd.DataFrame:
    """Return normalized historical price data for an equity or index."""

    normalized_symbol = _normalize_symbol(symbol)
    start_date = _coerce_date(start)
    end_date = _coerce_date(end)
    if start_date and end_date and start_date > end_date:
        raise ValueError("start must be less than or equal to end")

    tickers = get_tickers()
    if normalized_symbol not in set(tickers["id"]):
        raise InvalidSymbolError(f"Unknown BRVM symbol: {normalized_symbol}")

    source_symbol = (
        RICHBOURSE_INDEX_SLUGS.get(normalized_symbol, normalized_symbol)
        if _is_index(normalized_symbol)
        else normalized_symbol
    )
    history = cache_get_history(normalized_symbol)
    if history is None:
        history = fetch_richbourse_history(
            source_symbol,
            is_index=_is_index(normalized_symbol),
            start_date=start_date,
            max_pages=500,  # Jusqu'à ~500 pages pour couvrir tout l'historique possible depuis le début de la cotation
        )
        if history.empty:
            raise SourceUnavailableError(f"No history could be retrieved for {normalized_symbol}")
        cache_set_history(normalized_symbol, history)

    filtered = history.copy()
    if start_date is not None:
        filtered = filtered[filtered["date"] >= start_date]
    if end_date is not None:
        filtered = filtered[filtered["date"] <= end_date]

    return filtered.reset_index(drop=True)


def get_quote(symbol: str) -> dict[str, Any]:
    """Return the latest official BRVM quote for the requested symbol."""

    normalized_symbol = _normalize_symbol(symbol)
    quotes = fetch_latest_quotes()
    matches = quotes.loc[quotes["symbol"] == normalized_symbol]
    if matches.empty:
        raise InvalidSymbolError(f"Unknown BRVM symbol: {normalized_symbol}")

    latest = matches.iloc[0]
    result = {
        "symbol": str(latest["symbol"]),
        "name": str(latest["name"]),
        "open": int(latest["open"]) if pd.notna(latest["open"]) else None,
        "close": int(latest["close"]) if pd.notna(latest["close"]) else None,
        "previous_close": int(latest["previous_close"]) if pd.notna(latest["previous_close"]) else None,
        "volume": int(latest["volume"]) if pd.notna(latest["volume"]) else 0,
        "variation": float(latest["variation"]) if pd.notna(latest["variation"]) else None,
        "currency": "XOF",
    }
    
    try:
        from brvm.scrapers.boc import fetch_latest_boc_cached
        boc_df = fetch_latest_boc_cached()
        boc_match = boc_df.loc[boc_df["symbol"] == normalized_symbol]
        if not boc_match.empty:
            boc_row = boc_match.iloc[0]
            if pd.notna(boc_row["open"]): result["open"] = int(boc_row["open"]) 
            if pd.notna(boc_row["close"]): result["close"] = int(boc_row["close"])
            if pd.notna(boc_row["previous_close"]): result["previous_close"] = int(boc_row["previous_close"])
            if pd.notna(boc_row["variation_percent"]): result["variation"] = float(boc_row["variation_percent"])
    except Exception:
        pass
        
    return result


def get_company_info(symbol: str) -> dict[str, Any]:
    """Return the latest company snapshot available from covered sources."""

    normalized_symbol = _normalize_symbol(symbol)
    tickers = get_tickers()
    matches = tickers.loc[
        (tickers["id"] == normalized_symbol) & (tickers["instrument_type"] == "EQUITY")
    ]
    if matches.empty:
        raise InvalidSymbolError(f"Unknown BRVM equity symbol: {normalized_symbol}")

    info = fetch_sika_company_info(normalized_symbol)
    if info:
        return info

    row = matches.iloc[0]
    return {
        "symbol": str(row["id"]),
        "name": str(row["name"]),
        "sector": row["sector"],
        "currency": "XOF",
    }


def get_fundamentals_history(symbol: str) -> pd.DataFrame:
    """Return yearly fundamentals history for the given company."""

    normalized_symbol = _normalize_symbol(symbol)
    tickers = get_tickers()
    matches = tickers.loc[
        (tickers["id"] == normalized_symbol) & (tickers["instrument_type"] == "EQUITY")
    ]
    if matches.empty:
        raise InvalidSymbolError(f"Unknown BRVM equity symbol: {normalized_symbol}")

    return fetch_sika_fundamentals_history(normalized_symbol)


def get_dividends(symbol: str) -> pd.DataFrame:
    """Return dividend history for the given company."""

    normalized_symbol = _normalize_symbol(symbol)
    tickers = get_tickers()
    matches = tickers.loc[
        (tickers["id"] == normalized_symbol) & (tickers["instrument_type"] == "EQUITY")
    ]
    if matches.empty:
        raise InvalidSymbolError(f"Unknown BRVM equity symbol: {normalized_symbol}")

    return fetch_dividends(normalized_symbol)


def get_index_history(index_name: str) -> pd.DataFrame:
    """Return historical normalized data for a BRVM index."""

    normalized = _normalize_symbol(index_name)
    alias_map = {
        "BRVM COMPOSITE": "BRVM-COMP",
        "BRVM-COMPOSITE": "BRVM-COMP",
        "BRVM 10": "BRVM10",
        "BRVM-10": "BRVM10",
        "BRVM PRESTIGE": "BRVM-PREST",
        "BRVM-PRESTIGE": "BRVM-PREST",
    }
    canonical = alias_map.get(normalized, normalized)
    return get_history(canonical)

def get_latest_boc() -> pd.DataFrame:
    """Return the daily official quotation bulletin (BOC) extracted from PDF."""
    return fetch_latest_boc()

def get_news(symbol: str) -> list[dict[str, str]]:
    """Return the latest news articles for a specific stock."""
    normalized_symbol = _normalize_symbol(symbol)
    tickers = get_tickers()
    if normalized_symbol not in set(tickers["id"]):
        raise InvalidSymbolError(f"Unknown BRVM symbol: {normalized_symbol}")
    return fetch_company_news(normalized_symbol)

def get_yield_curve() -> list[dict]:
    """
    Get the latest yield curve from UMOA-Titres (Courbes des Taux).
    """
    from brvm.scrapers.umoatitres import fetch_yield_curve
    return fetch_yield_curve()

def get_adjudications_history(limit: int = 50) -> list[dict]:
    """
    Get the latest primary market emissions results from UMOA-Titres.
    """
    from brvm.scrapers.umoatitres import fetch_adjudications_history
    return fetch_adjudications_history(limit)

def get_adjudications_calendar(limit: int = 50) -> list[dict]:
    """
    Get the upcoming primary market emissions from UMOA-Titres.
    """
    from brvm.scrapers.umoatitres import fetch_adjudications_calendar
    return fetch_adjudications_calendar(limit)
