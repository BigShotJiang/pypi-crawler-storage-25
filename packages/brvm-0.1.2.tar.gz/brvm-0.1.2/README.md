# 📈 BRVM Python - Financial Data Extractor

[![PyPI version](https://badge.fury.io/py/brvm.svg)](https://pypi.org/project/brvm/)
[![Python Versions](https://img.shields.io/badge/python-3.9%20%7C%203.10%20%7C%203.11-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

**La bibliothèque Python open-source de référence pour scraper, nettoyer et analyser les données de la Bourse Régionale des Valeurs Mobilières (BRVM).**

Inspirée par l'aisance d'utilisation de `yfinance`, cette API non officielle s'adresse aux data scientists, analystes financiers et développeurs souhaitant intégrer les données du marché financier de l'UEMOA (Actions, Obligations, Indices, Marché Primaire) directement sous forme de `pandas.DataFrame`.

Le système est **résilient** : il agrège, nettoie et croise en temps réel les données de plusieurs sources (Site Officiel BRVM, Sika Finance, RichBourse, UMOA-Titres) avec un système de **fallback automatique** en cas de panne de l'une d'entre elles.

---

## �� Table des matières
1. [Installation](#-installation)
2. [Démarrage Rapide](#-démarrage-rapide)
3. [Documentation de l'API](#-documentation-de-lapi-détaillée)
   - [Actions, Obligations et Indices](#1-actions-obligations-et-indices)
   - [Fondamentaux & Opérations sur titres](#2-fondamentaux--opérations-sur-titres)
   - [Marché Primaire (UMOA-Titres)](#3-marché-primaire-umoa-titres)
4. [Standardisation et Format des Données](#-standardisation-et-format-des-données)
5. [Système de Cache Local (SQLite)](#-système-de-cache-local-sqlite)
6. [Avertissement & Licence](#-avertissement--licence)

---

## 📦 Installation

L'installation recommandée se fait simplement via `pip` :

```bash
pip install brvm
```

Pour la version de développement depuis les sources (si vous souhaitez y contribuer) :
```bash
git clone https://github.com/Naofal03/brvm.git
cd brvm
pip install -e ".[dev]"
```

---

## 🚀 Démarrage Rapide

```python
import brvm

# Récupérer l'historique complet de la Sonatel (SNTS)
historique = brvm.get_history("SNTS", start="2023-01-01", end="2024-01-01")
print(historique.head())

# Obtenir les indicateurs clés de la société
profil = brvm.get_company_info("SNTS")
print(f"Secteur : {profil['sector']} - Capitalisation : {profil.get('market_cap', 'N/A')}")
```

---

## 📚 Documentation de l'API Détaillée

Toutes les méthodes renvoient des DataFrames standards prêts à être passés à `matplotlib`, `scikit-learn` ou exportés en `.csv`.

### 1. Actions, Obligations et Indices

#### `brvm.get_tickers()`
Renvoie la liste complète de tous les instruments financiers cotés.
*   **Retourne** : `pandas.DataFrame` (Colonnes: `id`, `name`, `instrument_type`, `sector`).
*   **Types d'instruments supportés** : `EQUITY` (Actions), `BOND` (Obligations), `INDEX` (Indices).

#### `brvm.get_history(symbol, start=None, end=None)`
Extrait la série temporelle historique (Bougies OHLCV).
*   **Arguments** : 
    *   `symbol` (str): Le Ticker canonique (ex: `"SNTS"`, `"BOABF"`).
    *   `start` / `end` (str ou datetime, optionnels) : Les bornes de date (ex: `"2022-01-01"`).
*   **Retourne** : `pandas.DataFrame`.

#### `brvm.get_quote(symbol)`
Récupère les cotations temps-réel (End-of-Day) et les volumes de la journée en cours.
*   **Retourne** : `dict` (ex: `{'symbol': 'SNTS', 'open': 18000, 'close': 18050, 'volume': 4500, 'variation': 0.27}`).

#### `brvm.get_index_history(index_name)`
Fonctionne comme `get_history` mais adaptée pour les indices boursiers (Alias supportés: `"BRVM-COMP"`, `"BRVM 10"`, `"BRVM PRESTIGE"`...).

### 2. Fondamentaux & Opérations sur titres

#### `brvm.get_company_info(symbol)`
Récupère le profil descriptif (Secteur, Dirigeants, Capitalisation) de l'entreprise.
*   **Retourne** : `dict`.

#### `brvm.get_fundamentals_history(symbol)`
Extrait l'historique des indicateurs financiers de Sika Finance.
*   **Retourne** : `pandas.DataFrame` annuel contenant le **PER**, **ROE**, **Rendement du Dividende**, et la **Capitalisation**.

#### `brvm.get_dividends(symbol)`
Récupère l'historique détaillé des versements de dividendes annuels.
*   **Retourne** : `pandas.DataFrame` (Colonnes : `date_detachement`, `date_paiement`, `montant_net`).

#### `brvm.get_latest_boc()`
Scrape et analyse le dernier Bulletin Officiel de la Cote (BOC) PDF publié par la BRVM.
*   **Retourne** : `pandas.DataFrame` formaté avec les variations officielles du marché.

#### `brvm.get_news(symbol)`
Renvoie les derniers titres et liens d'articles d'actualité financière associés à l'entreprise.
*   **Retourne** : `list[dict]` avec les clés `date`, `title`, `url`.

### 3. Marché Primaire (UMOA-Titres)
Pour les acteurs obligataires, intègre les données des titres d'États de la zone UEMOA.

#### `brvm.get_yield_curve()`
Télécharge les fichiers Excel des courbes de taux souverains et en extrait la matrice des taux Zéro-Coupon par pays.
*   **Retourne** : `list[dict]` groupé par pays souverains (`Senegal`, `Mali`, `Cote d'Ivoire`, etc.).

#### `brvm.get_adjudications_history(limit=50)`
Renvoie les dernières émissions obligataires (OAT, BAT) réalisées sur le marché de l'UEMOA.
*   **Retourne** : `list[dict]`.

#### `brvm.get_adjudications_calendar(limit=50)`
Affiche le calendrier des prochaines levées de fonds souveraines prévues.
*   **Retourne** : `list[dict]`.

---

## 🛠 Standardisation et Format des Données

Afin de garantir la propreté de la donnée pour la modélisation statistique :
1.  **Dates standards :** Toutes les dates sont formattées en objet Python natif `datetime.date`. Les jours sans activité boursière (week-ends, jours fériés) sont exclus des DataFrames.
2.  **Gestion des "NC" (Non Cotés) :** Si un actif n'enregistre aucune transaction (Volume = 0), la méthode `get_history` effectue un **Forward Fill** : le prix de `close` est maintenu à la valeur de la veille, le volume passe à zéro, les indices `open`/`high`/`low` deviennent `NaN`, et la colonne `trading_status` passe à `"NC"`.
3.  **Colonnes immuables :** L'historique d'action retourne invariablement : `[date, open, high, low, close, adj_close, volume, value, trading_status]`.

---

## ⚙️ Système de Cache Local (SQLite)

Pour accélérer de **100x** les requêtes massives de Data Science et économiser la bande passante des serveurs de la BRVM, un système de cache silencieux est embarqué. 

Il génère un fichier local dans votre profil utilisateur : `~/.brvm_cache.db`.
*   **Expiration des données liées au marché (Cours EOD)** : 12 heures.
*   **Expiration des données structurelles (Fondamentaux, Tickers)** : 7 jours.

**Contrôle du cache :**
Vous pouvez purger ou forcer le désamorçage du cache à tout moment dans votre script.
```python
import brvm

brvm.disable_cache()     # Désactive la lecture/écriture en base locale (Requêtes réseau forcées)
brvm.get_history("SNTS") # Scraping brut
brvm.enable_cache()      # Réactive le comportement par défaut
```

---

## 🧪 Contribuer au Projet

La bibliothèque est construite avec robustesse. Les Pull Requests sont les bienvenues ! 
Le dépôt oblige à maintenir une **couverture de tests supérieure à 80%**. C'est vérifié via un pipeline GitHub Actions embarqué (Python 3.9, 3.10, 3.11).

```bash
# Lancer la batterie de tests virtuelle en local
pytest --cov=brvm
```

---

## ⚖️ Avertissement & Licence

**Licence MIT**. Ce projet est open-source et gratuit.
*Avertissement : Cette bibliothèque n'est pas un produit officiel de la Bourse Régionale des Valeurs Mobilières (BRVM), ni de Sika Finance. Elle est fournie "en l'état" à des fins éducatives et de recherche. L'auteur et les contributeurs déclinent toute responsabilité quant à d'éventuelles décisions financières ou pertes résultant de l'utilisation de ces données.*
