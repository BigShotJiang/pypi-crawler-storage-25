"""Control flow helpers extracted from QBasicTerminal.

Requires: TerminalProtocol (see qubasic_core.protocol).
"""

from __future__ import annotations

import re
from typing import Any, Callable

from qubasic_core.engine import ExecResult, ExecOutcome
from qubasic_core.parser import parse_stmt
from qubasic_core.statements import (
    RawStmt, RemStmt, MeasureStmt, EndStmt, ReturnStmt, WendStmt,
    LetArrayStmt, LetStmt, PrintStmt, GotoStmt, GosubStmt,
    ForStmt, NextStmt, WhileStmt, IfThenStmt,
    DataStmt, ReadStmt, OnGotoStmt, OnGosubStmt,
    SelectCaseStmt, CaseStmt, EndSelectStmt,
    DoStmt, LoopStmt, ExitStmt,
    SwapStmt, DefFnStmt, OptionBaseStmt,
    SubStmt, EndSubStmt, FunctionStmt, EndFunctionStmt, CallStmt,
    LocalStmt, StaticStmt, SharedStmt,
    OnErrorStmt, ResumeStmt, ErrorStmt, AssertStmt, StopStmt,
    OnMeasureStmt, OnTimerStmt,
)


class ControlFlowMixin:
    """Mixin providing control flow helpers for QBasicTerminal.

    Requires: TerminalProtocol — uses self.program, self.variables,
    self.arrays, self.locc_mode, self.locc, self._gosub_stack,
    self._eval_with_vars(), self._eval_condition(), self._substitute_vars().
    """

    # ── Control flow helpers (decomposed from _exec_control_flow) ────
    #
    # Each _cf_* method accepts (self, stmt, parsed, ...) where parsed is
    # a required typed Stmt object.  The stmt parameter is retained in the
    # signature for compatibility with _exec_control_flow's argument
    # passing but is not used by the methods themselves.

    def _cf_let_array(self, stmt: str, run_vars: dict[str, Any],
                      parsed: LetArrayStmt) -> tuple[bool, ExecOutcome]:
        name, idx_expr, val_expr = parsed.name, parsed.index_expr, parsed.value_expr
        idx = int(self._eval_with_vars(idx_expr, run_vars))
        val = self._eval_with_vars(val_expr, run_vars)
        if name not in self.arrays:
            self.arrays[name] = [0.0] * (idx + 1)
        while idx >= len(self.arrays[name]):
            self.arrays[name].append(0.0)
        self.arrays[name][idx] = val
        return True, ExecResult.ADVANCE

    def _cf_let_var(self, stmt: str, run_vars: dict[str, Any],
                    parsed: LetStmt) -> tuple[bool, ExecOutcome]:
        name, expr = parsed.name, parsed.expr
        val = self._eval_with_vars(expr, run_vars)
        run_vars[name] = val
        self.variables[name] = val
        return True, ExecResult.ADVANCE

    def _cf_print(self, stmt: str, run_vars: dict[str, Any],
                  parsed: PrintStmt) -> tuple[bool, ExecOutcome]:
        raw_expr = parsed.expr
        text = self._substitute_vars(raw_expr.strip(), run_vars)
        # Determine trailing separator: ; suppresses newline, , advances to tab
        suppress_newline = raw_expr.rstrip().endswith(';')
        tab_advance = raw_expr.rstrip().endswith(',')
        if suppress_newline:
            text = text.rstrip().removesuffix(';').rstrip()
        elif tab_advance:
            text = text.rstrip().removesuffix(',').rstrip()
        # Evaluate SPC(n) and TAB(n) inline
        def _replace_spc(m_spc):
            n = int(self._eval_with_vars(m_spc.group(1), run_vars))
            return ' ' * max(0, n)
        def _replace_tab(m_tab):
            n = int(self._eval_with_vars(m_tab.group(1), run_vars))
            return ' ' * max(0, n)
        text = re.sub(r'\bSPC\s*\(([^)]+)\)', _replace_spc, text, flags=re.IGNORECASE)
        text = re.sub(r'\bTAB\s*\(([^)]+)\)', _replace_tab, text, flags=re.IGNORECASE)
        # Evaluate the expression
        if (text.startswith('"') and text.endswith('"')) or \
           (text.startswith("'") and text.endswith("'")):
            output = text[1:-1]
        else:
            try:
                ns = run_vars.as_dict() if hasattr(run_vars, 'as_dict') else dict(run_vars) if not isinstance(run_vars, dict) else run_vars
                result = self._safe_eval(text, extra_ns=ns)
                output = str(result)
            except Exception:
                output = text
        # Output with separator behavior
        if suppress_newline:
            self.io.write(output)
        elif tab_advance:
            col = len(output) % 14
            padding = 14 - col if col > 0 else 14
            self.io.write(output + ' ' * padding)
        else:
            self.io.writeln(output)
        return True, ExecResult.ADVANCE

    def _cf_goto(self, stmt: str, sorted_lines: list[int],
                 parsed: GotoStmt) -> tuple[bool, int]:
        target = parsed.target
        for idx, ln in enumerate(sorted_lines):
            if ln == target:
                return True, idx
        raise RuntimeError(f"GOTO {target}: LINE NOT FOUND")

    def _cf_gosub(self, stmt: str, sorted_lines: list[int], ip: int,
                  parsed: GosubStmt) -> tuple[bool, int]:
        target = parsed.target
        self._gosub_stack.append(ip + 1)
        for idx, ln in enumerate(sorted_lines):
            if ln == target:
                return True, idx
        raise RuntimeError(f"GOSUB {target}: LINE NOT FOUND")

    def _cf_for(self, stmt: str, run_vars: dict[str, Any], loop_stack: list[dict[str, Any]], ip: int,
                parsed: ForStmt) -> tuple[bool, ExecOutcome]:
        var = parsed.var
        start_expr, end_expr, step_expr = parsed.start_expr, parsed.end_expr, parsed.step_expr
        start = self._eval_with_vars(start_expr, run_vars)
        end = self._eval_with_vars(end_expr, run_vars)
        step = self._eval_with_vars(step_expr, run_vars) if step_expr else 1
        try:
            if start == int(start): start = int(start)
        except (OverflowError, ValueError):
            pass
        try:
            if end == int(end): end = int(end)
        except (OverflowError, ValueError):
            pass
        try:
            if isinstance(step, float) and step == int(step): step = int(step)
        except (OverflowError, ValueError):
            pass
        run_vars[var] = start
        self.variables[var] = start
        loop_stack.append({'var': var, 'current': start, 'end': end,
                           'step': step, 'return_ip': ip})
        return True, ExecResult.ADVANCE

    def _cf_next(self, stmt: str, run_vars: dict[str, Any], loop_stack: list[dict[str, Any]],
                 parsed: NextStmt) -> tuple[bool, ExecOutcome]:
        var = parsed.var
        if not loop_stack or loop_stack[-1].get('var') != var:
            if loop_stack:
                expected = loop_stack[-1].get('var', '?')
                raise RuntimeError(f"NEXT {var} does not match current FOR {expected}")
            raise RuntimeError(f"NEXT {var} without matching FOR")
        loop = loop_stack[-1]
        loop['current'] += loop['step']
        if (loop['step'] > 0 and loop['current'] <= loop['end']) or \
           (loop['step'] < 0 and loop['current'] >= loop['end']):
            run_vars[var] = loop['current']
            self.variables[var] = loop['current']
            return True, loop['return_ip'] + 1
        else:
            loop_stack.pop()
            return True, ExecResult.ADVANCE

    def _find_matching_wend(self, sorted_lines: list[int], ip: int) -> int:
        """Find the ip after the WEND matching the WHILE at ip.

        Scans forward with proper nesting depth tracking. Returns the ip
        index past the matching WEND. Raises with the WHILE line number
        for clear diagnostics.
        """
        depth = 1
        scan = ip + 1
        while scan < len(sorted_lines):
            s = self.program[sorted_lines[scan]].strip().upper()
            if s.startswith('WHILE '):
                depth += 1
            elif s == 'WEND':
                depth -= 1
                if depth == 0:
                    return scan + 1
            scan += 1
        line_num = sorted_lines[ip]
        raise RuntimeError(f"WHILE at line {line_num} has no matching WEND")

    def _cf_while(self, stmt: str, run_vars: dict[str, Any], loop_stack: list[dict[str, Any]],
                  sorted_lines: list[int], ip: int,
                  parsed: WhileStmt) -> tuple[bool, ExecOutcome]:
        cond = parsed.condition
        if self._eval_condition(cond, run_vars):
            loop_stack.append({'type': 'while', 'cond': cond, 'return_ip': ip})
            return True, ExecResult.ADVANCE
        else:
            return True, self._find_matching_wend(sorted_lines, ip)

    def _cf_wend(self, run_vars: dict[str, Any], loop_stack: list[dict[str, Any]],
                 sorted_lines: list[int] | None = None, ip: int | None = None) -> tuple[bool, ExecOutcome] | None:
        if not loop_stack or loop_stack[-1].get('type') != 'while':
            ctx = f" at line {sorted_lines[ip]}" if sorted_lines and ip is not None else ""
            raise RuntimeError(f"WEND{ctx} without matching WHILE")
        loop = loop_stack[-1]
        if self._eval_condition(loop['cond'], run_vars):
            return True, loop['return_ip']
        else:
            loop_stack.pop()
            return True, ExecResult.ADVANCE

    def _cf_if_then(self, stmt: str, run_vars: dict[str, Any], loop_stack: list[dict[str, Any]],
                    sorted_lines: list[int], ip: int,
                    exec_fn: Callable[..., Any],
                    parsed: IfThenStmt) -> tuple[bool, ExecOutcome]:
        cond_str = parsed.condition
        then_clause = parsed.then_clause
        else_clause = parsed.else_clause
        cond_vars = run_vars
        if self.locc_mode and self.locc:
            cond_vars = {**run_vars, **self.locc.classical}
        result = ExecResult.ADVANCE
        if self._eval_condition(cond_str, cond_vars):
            if then_clause:
                r = exec_fn(then_clause, loop_stack, sorted_lines, ip, run_vars)
                if r is not None and r is not ExecResult.ADVANCE:
                    result = r
        elif else_clause:
            r = exec_fn(else_clause, loop_stack, sorted_lines, ip, run_vars)
            if r is not None and r is not ExecResult.ADVANCE:
                result = r
        return True, result

    # ── Type-based dispatch table ────────────────────────────────────
    # Maps parsed Stmt types to handler lambdas.  Each lambda receives
    # (self, stmt, parsed, loop_stack, sorted_lines, ip, run_vars,
    # exec_fn) and returns (handled: bool, result).

    _CF_DISPATCH: dict[type, Callable] = {
        # Trivial handlers (no _cf_* method needed)
        RemStmt:         lambda s, st, p, ls, sl, ip, rv, ef: (True, ExecResult.ADVANCE),
        MeasureStmt:     lambda s, st, p, ls, sl, ip, rv, ef: (True, ExecResult.ADVANCE),
        EndStmt:         lambda s, st, p, ls, sl, ip, rv, ef: (True, ExecResult.END),
        ReturnStmt:      lambda s, st, p, ls, sl, ip, rv, ef: (_ for _ in ()).throw(RuntimeError("RETURN WITHOUT GOSUB")) if not s._gosub_stack else (True, s._gosub_stack.pop()),
        # Handlers defined in control_flow.py (parsed is positional)
        WendStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_wend(rv, ls, sl, ip),
        LetArrayStmt:    lambda s, st, p, ls, sl, ip, rv, ef: s._cf_let_array(st, rv, p),
        LetStmt:         lambda s, st, p, ls, sl, ip, rv, ef: s._cf_let_var(st, rv, p),
        PrintStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_print(st, rv, p),
        GotoStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_goto(st, sl, p),
        GosubStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_gosub(st, sl, ip, p),
        ForStmt:         lambda s, st, p, ls, sl, ip, rv, ef: s._cf_for(st, rv, ls, ip, p),
        NextStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_next(st, rv, ls, p),
        WhileStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_while(st, rv, ls, sl, ip, p),
        IfThenStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_if_then(st, rv, ls, sl, ip, ef, p),
        # Handlers defined in classic.py (parsed is keyword-only)
        DataStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_data(st, parsed=p),
        ReadStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_read(st, rv, parsed=p),
        OnGotoStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_on_goto(st, rv, sl, parsed=p),
        OnGosubStmt:     lambda s, st, p, ls, sl, ip, rv, ef: s._cf_on_gosub(st, rv, sl, ip, parsed=p),
        SelectCaseStmt:  lambda s, st, p, ls, sl, ip, rv, ef: s._cf_select_case(st, rv, sl, ip, parsed=p),
        CaseStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_case(st, sl, ip, parsed=p),
        EndSelectStmt:   lambda s, st, p, ls, sl, ip, rv, ef: s._cf_end_select(st, parsed=p),
        DoStmt:          lambda s, st, p, ls, sl, ip, rv, ef: s._cf_do(st, rv, ls, sl, ip, parsed=p),
        LoopStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_loop(st, rv, ls, sl, ip, parsed=p),
        ExitStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_exit(st, ls, sl, ip, parsed=p),
        SwapStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_swap(st, rv, parsed=p),
        DefFnStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_def_fn(st, rv, parsed=p),
        OptionBaseStmt:  lambda s, st, p, ls, sl, ip, rv, ef: s._cf_option_base(st, parsed=p),
        # Handlers defined in subs.py (parsed is keyword-only)
        SubStmt:         lambda s, st, p, ls, sl, ip, rv, ef: s._cf_sub(st, sl, ip, parsed=p),
        EndSubStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_end_sub(st, parsed=p),
        FunctionStmt:    lambda s, st, p, ls, sl, ip, rv, ef: s._cf_function(st, sl, ip, parsed=p),
        EndFunctionStmt: lambda s, st, p, ls, sl, ip, rv, ef: s._cf_end_function(st, parsed=p),
        CallStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_call(st, rv, sl, ip, parsed=p),
        LocalStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_local(st, rv, parsed=p),
        StaticStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_static(st, rv, parsed=p),
        SharedStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_shared(st, rv, parsed=p),
        # Handlers defined in debug.py (parsed is keyword-only)
        OnErrorStmt:     lambda s, st, p, ls, sl, ip, rv, ef: s._cf_on_error(st, parsed=p),
        ResumeStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_resume(st, sl, parsed=p),
        ErrorStmt:       lambda s, st, p, ls, sl, ip, rv, ef: s._cf_error(st, parsed=p),
        AssertStmt:      lambda s, st, p, ls, sl, ip, rv, ef: s._cf_assert(st, rv, parsed=p),
        StopStmt:        lambda s, st, p, ls, sl, ip, rv, ef: s._cf_stop(st, sl, ip, parsed=p),
        OnMeasureStmt:   lambda s, st, p, ls, sl, ip, rv, ef: s._cf_on_measure(st, parsed=p),
        OnTimerStmt:     lambda s, st, p, ls, sl, ip, rv, ef: s._cf_on_timer(st, parsed=p),
    }

    def _exec_control_flow(
        self, stmt: str, loop_stack: list[dict[str, Any]],
        sorted_lines: list[int], ip: int, run_vars: dict[str, Any],
        exec_fn: Callable[..., Any],
        *, parsed=None,
    ) -> tuple[bool, ExecOutcome | None]:
        """Shared control flow for both Qiskit and LOCC execution paths.
        Returns (handled, result) -- if handled is True, result is the
        return value.  exec_fn is the recursive line executor for
        IF/multi-statement dispatch.

        Dispatches via dict lookup on the parsed Stmt type (O(1)).

        If *parsed* is provided, the parse_stmt call is skipped (avoids
        redundant parsing when the caller has already parsed the statement).
        """
        if parsed is None:
            parsed = parse_stmt(stmt)
        handler = self._CF_DISPATCH.get(type(parsed))
        if handler is not None:
            return handler(self, stmt, parsed, loop_stack, sorted_lines, ip, run_vars, exec_fn)

        # RawStmt or unmapped type -- not handled by control flow
        return False, None
