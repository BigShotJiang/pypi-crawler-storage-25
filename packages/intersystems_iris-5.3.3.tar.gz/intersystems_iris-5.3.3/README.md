# intersystems-iris

Compatibility shim: `import intersystems_iris` resolves to the `iris` module from `intersystems-irispython`.

## The problem

The InterSystems IRIS Python client is distributed as `intersystems-irispython` but imported as `iris`. This mismatch between package name and import name has led the community to independently converge on `intersystems_iris` as a more intuitive import name — and several widely-used packages depend on it:

- **`sqlalchemy-iris`** (caretdev) — `import intersystems_iris.dbapi._DBAPI` in 4 files
- **`django-iris`** (caretdev) — `import intersystems_iris.dbapi._DBAPI as Database`
- **`iris-kafka-python`** (grongierisc / ISC) — `import intersystems_iris` + `intersystems_iris.IRIS(conn)`
- **`iris-vector-graph`** (intersystems-community) — `import intersystems_iris` in bulk_loader and engine

These packages were not wrong. `intersystems_iris` was the intended public import name of the legacy `intersystems-iris` distribution before ISC renamed the package to `intersystems-irispython` and shortened the import to `iris`. This shim restores that name so all of the above packages work without modification.

```python
import intersystems_iris          # same as: import iris
intersystems_iris.connect(...)    # works
intersystems_iris.createIRIS(...) # works
intersystems_iris.dbapi           # works
intersystems_iris.IRIS(conn)      # works
```

## Install

```bash
pip install intersystems-iris
```

Pulls in `intersystems-irispython` automatically.

## For new code

Use `import iris` directly. This package exists for ecosystem compatibility.

```python
import iris
conn = iris.connect("iris://_SYSTEM:SYS@localhost:1972/USER")
```

## Embedded Python (in-process)

When running inside IRIS via `irispython`, `import iris` is provided by the IRIS runtime — `intersystems-irispython` is not installed. The `intersystems_iris` shim still works because it imports from `iris`, which is always present.

```python
# Inside irispython — no pip install needed
import intersystems_iris  # resolves to the embedded iris module
intersystems_iris.sql.exec("SELECT 1")
```
