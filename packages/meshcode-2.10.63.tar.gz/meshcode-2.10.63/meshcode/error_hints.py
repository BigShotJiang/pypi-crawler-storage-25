"""Smart error messages — maps common error patterns to actionable fix commands.

Usage:
    from meshcode.error_hints import hint_for_error
    print(hint_for_error("agent not found"))
    # → "Run: meshcode register <project> <agent> <role>"
"""

_HINTS = [
    # Auth errors
    ("invalid api_key", "Run: meshcode login <api_key> to set your credentials"),
    ("api key", "Run: meshcode login <api_key> to refresh credentials"),
    ("auth_failed", "Run: meshcode login to re-authenticate"),
    ("forbidden", "You don't have permission. Check: meshcode doctor"),
    ("not authenticated", "Run: meshcode login <api_key>"),

    # Agent errors
    ("agent not found", "Run: meshcode register <project> <agent_name> <role>"),
    ("agent.*not registered", "Run: meshcode register <project> <agent_name> <role>"),

    # Project errors
    ("project.*not found", "Check project name with: meshcode projects"),
    ("no projects found", "Create one at meshcode.io/dashboard or: meshcode init <project_name>"),

    # Network errors
    ("circuit breaker open", "Supabase is temporarily unavailable. Wait 30s and retry. Details: meshcode doctor"),
    ("connection refused", "Check internet connection. If persists: meshcode doctor"),
    ("network error", "Check internet connection. If persists: meshcode doctor"),
    ("timeout", "Request timed out. Check connection: meshcode doctor"),

    # MCP errors
    ("MCP server crashed", "Restart: meshcode run <agent>"),
    ("stdin EOF", "MCP pipe closed. Restart the MCP server or Claude Code session"),
    ("mcp.*failed", "Check MCP config: meshcode doctor"),

    # Task errors
    ("task.*already claimed", "This task is being worked on. Try: meshcode tasks to see available tasks"),
    ("task not found", "Check task ID. List tasks: meshcode tasks"),

    # Config errors
    ("comms_v4.py not found", "Reinstall: pip install --upgrade meshcode"),
    ("\.mcp\.json", "Run: meshcode setup <project> <agent> to create config"),

    # Token errors
    ("token expired", "Generate a new token from the dashboard"),
    ("token already used", "Generate a new token from the dashboard"),
]


def hint_for_error(error_msg: str) -> str:
    """Return an actionable fix suggestion for a given error message.

    Returns empty string if no hint matches.
    """
    import re
    lower = error_msg.lower()
    for pattern, hint in _HINTS:
        if re.search(pattern, lower):
            return hint
    return ""


def format_error(error_msg: str, prefix: str = "[meshcode]") -> str:
    """Format an error with an actionable hint if available.

    Example output:
        [meshcode] ERROR: agent not found
        [meshcode] Fix: Run: meshcode register <project> <agent_name> <role>
    """
    lines = [f"{prefix} ERROR: {error_msg}"]
    hint = hint_for_error(error_msg)
    if hint:
        lines.append(f"{prefix} Fix: {hint}")
    return "\n".join(lines)
