"""MeshCode file upload — register metadata + upload to Supabase Storage."""
import os
import sys
import json
import mimetypes
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def upload_file(file_path: str, api_key: str, supabase_url: str, supabase_key: str) -> dict:
    """Upload a file to MeshCode via Supabase Storage.

    1. Register file metadata via mc_register_file RPC
    2. Upload binary to Supabase Storage bucket
    3. Return file_id for task attachment

    Returns: {"ok": True, "file_id": "...", "storage_path": "..."}
    """
    path = Path(file_path)
    if not path.exists():
        return {"error": f"file not found: {file_path}"}

    file_name = path.name
    mime_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
    size_bytes = path.stat().st_size

    if size_bytes > 52428800:
        return {"error": "file too large (max 50MB)"}

    # 1. Register metadata
    rpc_url = f"{supabase_url}/rest/v1/rpc/mc_register_file"
    payload = json.dumps({
        "p_api_key": api_key,
        "p_file_name": file_name,
        "p_mime_type": mime_type,
        "p_size_bytes": size_bytes,
    }).encode("utf-8")

    req = Request(rpc_url, data=payload, method="POST")
    req.add_header("apikey", supabase_key)
    req.add_header("Content-Type", "application/json")

    try:
        with urlopen(req) as resp:
            result = json.loads(resp.read())
    except HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return {"error": f"register failed: {body[:200]}"}

    if not result or result.get("error"):
        return {"error": f"register failed: {result}"}

    storage_path = result["storage_path"]
    bucket = result.get("bucket", "meshcode-files")
    file_id = result["file_id"]

    # 2. Upload to Supabase Storage
    storage_url = f"{supabase_url}/storage/v1/object/{bucket}/{storage_path}"
    with open(path, "rb") as f:
        file_data = f.read()

    upload_req = Request(storage_url, data=file_data, method="POST")
    upload_req.add_header("apikey", supabase_key)
    upload_req.add_header("Authorization", f"Bearer {supabase_key}")
    upload_req.add_header("Content-Type", mime_type)

    try:
        with urlopen(upload_req) as resp:
            upload_result = json.loads(resp.read())
    except HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return {"error": f"upload failed: {body[:200]}", "file_id": file_id, "note": "metadata registered but upload failed"}

    return {
        "ok": True,
        "file_id": file_id,
        "file_name": file_name,
        "size_bytes": size_bytes,
        "storage_path": storage_path,
        "mime_type": mime_type,
    }


def cmd_upload(file_path: str, project: str = None) -> int:
    """CLI entry point for meshcode upload <file>."""
    from meshcode.meshcode_mcp import backend as be

    api_key = None
    # Try to get API key from environment or config
    env_key = os.environ.get("MESHCODE_API_KEY")
    if env_key:
        api_key = env_key
    else:
        # Try keychain profile
        try:
            profile_path = Path.home() / ".meshcode" / "profile_meta.json"
            if profile_path.exists():
                meta = json.loads(profile_path.read_text())
                api_key = meta.get("api_key")
        except Exception:
            pass

    if not api_key:
        print("[meshcode upload] ERROR: No API key. Set MESHCODE_API_KEY or run meshcode login.")
        return 1

    print(f"[meshcode upload] Uploading {file_path}...")
    result = upload_file(
        file_path=file_path,
        api_key=api_key,
        supabase_url=be.SUPABASE_URL,
        supabase_key=be.SUPABASE_KEY,
    )

    if result.get("ok"):
        print(f"[meshcode upload] Success!")
        print(f"  file_id:   {result['file_id']}")
        print(f"  file_name: {result['file_name']}")
        print(f"  size:      {result['size_bytes']} bytes")
        print(f"  path:      {result['storage_path']}")
        return 0
    else:
        print(f"[meshcode upload] ERROR: {result.get('error', 'unknown error')}")
        return 1
