"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc)."""
__version__ = "1.0.0"

# Convenience re-exports so `from meshcode.meshcode_mcp import MeshCodeMCP`
# and `from meshcode.meshcode_mcp.backend import MeshCodeBackend` work.
# These are lazy to avoid import-time side effects (server.py reads env vars
# and exits if MESHCODE_PROJECT / MESHCODE_AGENT are unset).


def __getattr__(name):
    if name == "MeshCodeMCP":
        from .server import mcp as _mcp, run_server  # noqa: F811
        # Expose the FastMCP instance and run_server under the expected name
        class MeshCodeMCP:
            """Convenience wrapper around the FastMCP server instance."""
            server = _mcp
            run = staticmethod(run_server)
        return MeshCodeMCP
    if name == "run_server":
        from .server import run_server
        return run_server
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
