"""Run via: python -m meshcode_mcp serve"""
import os
import sys

# CRITICAL Windows fix: the MCP protocol uses stdio JSON-RPC. On Windows
# stdin/stdout default to cp1252 encoding and block-buffered when piped.
# - cp1252 → any non-ASCII char in a JSON message raises UnicodeEncodeError
#   and corrupts the byte stream → Claude Code times out the handshake.
# - Block-buffered → JSON-RPC bytes get stuck in the kernel buffer until
#   the buffer fills, so Claude Code never sees the handshake response.
# Both must be fixed BEFORE FastMCP touches stdio.
def _force_utf8_stdio():
    """Force UTF-8 + line-buffered stdout, UTF-8 stdin/stderr.

    reconfigure() can fail on some Windows Python builds (3.14+) when
    stdout is a pipe without a backing console. In that case, wrap the
    raw buffer in a fresh TextIOWrapper.
    """
    import io
    for stream_name in ("stdout", "stdin", "stderr"):
        stream = getattr(sys, stream_name)
        if stream is None:
            continue
        kw = {"encoding": "utf-8", "errors": "replace"}
        if stream_name != "stderr":
            kw["newline"] = "\n"
        if stream_name == "stdout":
            kw["line_buffering"] = True
        try:
            stream.reconfigure(**kw)
        except Exception:
            # reconfigure failed — wrap the raw buffer manually
            try:
                raw = stream.buffer
                wrapper = io.TextIOWrapper(raw, **kw)
                setattr(sys, stream_name, wrapper)
            except Exception:
                pass  # nothing more we can do

_force_utf8_stdio()
# Belt and suspenders: also export PYTHONIOENCODING in case any subprocess
# we spawn inherits this env.
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
# Tell self_update / other modules: we are the MCP serve subprocess; do
# NOT auto-update from inside this process.
os.environ.setdefault("MESHCODE_MCP_SERVE", "1")

from .server import run_server


def main():
    args = sys.argv[1:]
    if args and args[0] == "serve":
        run_server()
    else:
        print("Usage: python -m meshcode_mcp serve", file=sys.stderr)
        print("       (env vars: MESHCODE_PROJECT, MESHCODE_AGENT, SUPABASE_URL, SUPABASE_KEY)", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
