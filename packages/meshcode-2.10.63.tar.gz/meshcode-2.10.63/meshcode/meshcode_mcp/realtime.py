"""Supabase Realtime listener for the MeshCode MCP server.

Connects to Supabase Realtime via WebSocket (no supabase-py dep — uses
the `websockets` package directly to keep the install light).

When a new mc_message INSERT arrives for the current agent, it:
  1. Pushes the message into an in-memory deque (consumed by meshcode_check tool)
  2. Calls the registered notify_callback (FastMCP session.send_resource_updated)
"""
import asyncio
import json
import logging
import ssl
from collections import deque
from typing import Any, Awaitable, Callable, Deque, Dict, Optional
from urllib.parse import quote as url_quote

try:
    import certifi
    _SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except Exception:
    # Fallback to system trust store if certifi isn't available.
    try:
        _SSL_CTX = ssl.create_default_context()
    except Exception:
        _SSL_CTX = None

try:
    import websockets
    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False

log = logging.getLogger("meshcode-mcp.realtime")


class RealtimeListener:
    """Connects to Supabase Realtime and forwards mc_messages INSERTs to a callback."""

    def __init__(
        self,
        supabase_url: str,
        supabase_key: str,
        project_id: str,
        agent_name: str,
        notify_callback: Optional[Callable[[Dict], Awaitable[None]]] = None,
        service_role_key: Optional[str] = None,
    ):
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key
        self.project_id = project_id
        self.agent_name = agent_name
        self.notify_callback = notify_callback
        self.service_role_key = service_role_key

        # Message queue — drained by meshcode_check/meshcode_wait.
        # Cap at 2000 (was 500). When full, oldest messages are dropped
        # and _dropped_count is incremented so the agent knows.
        self.queue: Deque[Dict] = deque(maxlen=2000)
        self._overflow_warned = False
        self._dropped_count = 0
        self._task: Optional[asyncio.Task] = None
        # asyncio.Event() in Py3.10+ no longer requires a running loop, but
        # on older Python or certain Windows event-loop policies it can
        # raise. Defer creation to start() which is always called from
        # inside the running event loop.
        self._stop: Optional[asyncio.Event] = None
        self._connected = False
        # Event fired whenever a new message is appended to the queue.
        # meshcode_wait awaits this instead of polling -> zero-cost idle.
        self.message_event: Optional[asyncio.Event] = None

        # Deaf detection: track when we last received ANY event from Realtime
        # (message, task, or heartbeat reply). If this goes stale while the
        # agent is supposedly listening, Realtime is deaf and needs restart.
        import time as _time_mod
        self.last_event_at: float = _time_mod.time()
        self._deaf_restart_count: int = 0

    @property
    def ws_url(self) -> str:
        host = self.supabase_url.replace("https://", "").replace("http://", "").rstrip("/")
        # Use service_role_key for WebSocket auth if available — bypasses RLS
        # so Realtime can deliver INSERT events without needing auth.uid().
        # Falls back to publishable key (requires anon RLS policy).
        key = self.service_role_key or self.supabase_key
        return f"wss://{host}/realtime/v1/websocket?apikey={key}&vsn=1.0.0"

    async def start(self) -> None:
        if not WEBSOCKETS_AVAILABLE:
            log.warning("websockets package not installed — Realtime disabled")
            return
        # Cancel any existing task from a previous event loop.
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        # ALWAYS recreate Event objects. After mcp.run() restarts with a new
        # event loop, old Events are bound to the dead loop and can never
        # fire. This was the root cause of the "deaf after ESC" bug.
        self._stop = asyncio.Event()
        self.message_event = asyncio.Event()
        # Reset subscription state so is_subscribed doesn't return stale True
        self._connected = False
        self._subscription_ok = False
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="meshcode-realtime")

    async def stop(self) -> None:
        # Reset connection flags FIRST so is_subscribed/is_connected
        # return False immediately — prevents stale-flag deaf bug.
        self._connected = False
        self._subscription_ok = False
        if self._stop is not None:
            self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        # Reset state so is_connected/is_subscribed don't return stale values
        self._connected = False
        self._subscription_ok = False

    async def _run(self) -> None:
        """Outer loop: reconnect with exponential backoff on disconnect.

        NEVER gives up — keeps retrying with capped backoff (max 60s).
        The MCP server must stay alive regardless of Realtime health.
        """
        backoff = 1
        consecutive_failures = 0
        while not self._stop.is_set():
            try:
                await self._connect_and_listen()
                backoff = 1  # reset on clean disconnect
                consecutive_failures = 0
            except asyncio.CancelledError:
                return
            except Exception as e:
                consecutive_failures += 1
                if consecutive_failures % 10 == 0:
                    log.error(
                        f"Realtime: {consecutive_failures} consecutive failures — "
                        f"still retrying (backoff={backoff}s). Last error: {e}"
                    )
                else:
                    log.warning(
                        f"Realtime connection error ({consecutive_failures}): "
                        f"{e}; reconnecting in {backoff}s"
                    )
                self._connected = False
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=backoff)
                    return  # stop signaled
                except asyncio.TimeoutError:
                    pass
                backoff = min(backoff * 2, 60)

    async def _connect_and_listen(self) -> None:
        """Single connection lifecycle: connect, subscribe, listen."""
        # Cap the initial TLS handshake at 10s. Without this, websockets.connect
        # can hang indefinitely behind a corporate firewall / DNS stall, which
        # blocks the MCP lifespan startup -> Claude Code times out the spawn
        # -> "Failed to reconnect".
        connect_kwargs = {"ping_interval": 20, "ping_timeout": 15}
        if _SSL_CTX is not None and self.ws_url.startswith("wss://"):
            connect_kwargs["ssl"] = _SSL_CTX
        ws = await asyncio.wait_for(
            websockets.connect(self.ws_url, **connect_kwargs),
            timeout=10.0,
        )
        try:
            self._connected = True
            log.info(f"Realtime connected for agent={self.agent_name}")

            # Phoenix channel join: phoenix realtime topic
            topic = f"realtime:{self.project_id}-{self.agent_name}"
            join_msg = {
                "topic": topic,
                "event": "phx_join",
                "payload": {
                    "config": {
                        "postgres_changes": [
                            {
                                "event": "INSERT",
                                "schema": "meshcode",
                                "table": "mc_messages",
                                "filter": f"to_agent=eq.{url_quote(self.agent_name, safe='')}",
                            },
                            {
                                "event": "INSERT",
                                "schema": "meshcode",
                                "table": "mc_messages",
                                "filter": "to_agent=eq.*",
                            },
                            {
                                "event": "INSERT",
                                "schema": "meshcode",
                                "table": "mc_tasks",
                                "filter": f"assignee=eq.{url_quote(self.agent_name, safe='')}",
                            },
                            {
                                "event": "UPDATE",
                                "schema": "meshcode",
                                "table": "mc_tasks",
                                "filter": f"assignee=eq.{url_quote(self.agent_name, safe='')}",
                            }
                        ]
                    }
                },
                "ref": "1",
            }
            await ws.send(json.dumps(join_msg))

            # Wait for phx_reply to confirm subscription was accepted.
            # Retry up to 3 times with backoff — transient Supabase latency
            # can cause one agent to time out while siblings succeed.
            self._subscription_ok = False
            for _sub_attempt in range(3):
                try:
                    reply_raw = await asyncio.wait_for(ws.recv(), timeout=15.0)
                    reply = json.loads(reply_raw)
                    reply_status = (reply.get("payload") or {}).get("status")
                    if reply_status == "ok":
                        self._subscription_ok = True
                        log.info(f"Realtime subscription OK for {self.agent_name} on {topic}")
                        break
                    else:
                        log.warning(
                            f"Realtime subscription attempt {_sub_attempt+1} failed for {self.agent_name}: "
                            f"status={reply_status} payload={reply.get('payload')}"
                        )
                except asyncio.TimeoutError:
                    log.warning(f"Realtime subscription attempt {_sub_attempt+1} TIMEOUT for {self.agent_name}")
                except Exception as e:
                    log.warning(f"Realtime subscription attempt {_sub_attempt+1} error: {e}")
                # Retry: re-send join message after brief backoff
                if _sub_attempt < 2:
                    await asyncio.sleep(2 ** _sub_attempt)
                    await ws.send(json.dumps(join_msg))
            if not self._subscription_ok:
                log.error(f"Realtime subscription FAILED after 3 attempts for {self.agent_name}")
                # Close and let the outer _run() loop reconnect with backoff.
                # Staying connected but unsubscribed wastes the WebSocket
                # and forces the agent into slow DB polling forever.
                return

            # Heartbeat task to keep the connection alive
            heartbeat_task = asyncio.create_task(self._heartbeat(ws))
            try:
                async for raw in ws:
                    if self._stop.is_set():
                        break
                    try:
                        msg = json.loads(raw)
                    except Exception as e:
                        log.warning(f"Realtime JSON parse error: {e} (raw[:200]={str(raw)[:200]})")
                        continue
                    await self._handle_message(msg)
            finally:
                heartbeat_task.cancel()
                self._connected = False
        finally:
            try:
                await ws.close()
            except Exception:
                pass

    async def _heartbeat(self, ws) -> None:
        """Send phoenix heartbeats every 25s to keep the channel alive."""
        ref = 0
        while not self._stop.is_set():
            await asyncio.sleep(25)
            ref += 1
            try:
                await ws.send(json.dumps({
                    "topic": "phoenix",
                    "event": "heartbeat",
                    "payload": {},
                    "ref": str(ref),
                }))
            except Exception as e:
                log.warning(f"Realtime heartbeat send failed: {e} — closing WS to force reconnect")
                # Close WS to trigger recv loop exit → outer _run() reconnects.
                # Without this, half-dead WS stays open for 45-60s silent blackout.
                try:
                    await ws.close()
                except Exception:
                    pass
                return

    async def _handle_message(self, msg: Dict[str, Any]) -> None:
        import time as _time_mod
        self.last_event_at = _time_mod.time()
        event = msg.get("event")
        payload = msg.get("payload") or {}

        # postgres_changes payload structure:
        # {"event": "postgres_changes", "payload": {"data": {"record": {...}, "type": "INSERT", ...}}}
        if event == "postgres_changes":
            data = payload.get("data") or {}
            table = data.get("table", (data.get("record") or {}).get("_table", ""))
            change_type = data.get("type")

            # ── mc_tasks events: wake the agent when a task is assigned/updated ──
            if table == "mc_tasks" and change_type in ("INSERT", "UPDATE"):
                record = data.get("record") or {}
                assignee = record.get("assignee", "")
                if assignee == self.agent_name and record.get("status") in ("open", "in_progress"):
                    log.info(f"task event: {change_type} task '{record.get('title', '?')[:60]}' for {self.agent_name}")
                    try:
                        self.message_event.set()
                    except Exception:
                        pass
                return

            if change_type == "INSERT":
                record = data.get("record") or {}
                to = record.get("to_agent")
                from_agent = record.get("from_agent")
                # Accept direct messages AND broadcasts (to_agent='*'),
                # but filter out self-broadcasts to avoid echo.
                if (to in (self.agent_name, "*")) and record.get("project_id") == self.project_id and from_agent != self.agent_name:
                    enriched = {
                        "from": record.get("from_agent"),
                        "type": record.get("type", "msg"),
                        "ts": record.get("created_at"),
                        "payload": record.get("payload", {}),
                        "id": record.get("id"),
                        "parent_id": record.get("parent_msg_id"),
                    }
                    if len(self.queue) >= self.queue.maxlen:
                        # Queue is full — this append will drop the oldest message
                        self._dropped_count += 1
                        if not self._overflow_warned:
                            log.warning(f"Message queue FULL ({self.queue.maxlen}) — dropping oldest messages ({self._dropped_count} dropped so far)")
                            self._overflow_warned = True
                    elif len(self.queue) >= self.queue.maxlen * 0.8 and not self._overflow_warned:
                        log.warning(f"Message queue at {len(self.queue)}/{self.queue.maxlen} — approaching limit")
                    self.queue.append(enriched)
                    # Wake any meshcode_wait blocked on this event.
                    try:
                        self.message_event.set()
                    except Exception:
                        pass
                    log.info(f"new message from {enriched['from']}")
                    if self.notify_callback:
                        try:
                            await self.notify_callback(enriched)
                        except Exception as e:
                            log.warning(f"notify_callback failed: {e}")

    def peek(self) -> list:
        """Return queued messages without removing them."""
        return list(self.queue)

    def drain(self) -> list:
        """Pop and return all queued messages."""
        # Clear event FIRST, then drain queue. If a message arrives between
        # clear() and the drain, it re-sets the event and lands in queue —
        # the next wait_for_message returns immediately. This avoids the race
        # where clear() after drain() could eat a wake signal.
        try:
            self.message_event.clear()
        except Exception:
            pass
        out = list(self.queue)
        self.queue.clear()
        return out

    async def wait_for_message(self, timeout: Optional[float] = None) -> bool:
        """Block until a new message lands in the queue (or timeout).

        Returns True if woken by a message, False on timeout. This is the
        core of the zero-cost idle loop: while awaiting, the event loop
        does ZERO work — no polling, no Supabase calls, no token cost.
        """
        try:
            await asyncio.wait_for(self.message_event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    # Restart circuit breaker: prevent infinite restart cascades.
    # After 3 restarts in 120s, enter cooldown (no restarts for 60s).
    _restart_times: list = []
    _restart_cooldown_until: float = 0.0
    _RESTART_MAX = 3
    _RESTART_WINDOW = 120.0
    _RESTART_COOLDOWN = 60.0

    async def restart(self) -> None:
        """Stop and restart the Realtime connection.

        Called by the heartbeat thread when it detects the subscription
        dropped (is_subscribed=False). Has a circuit breaker: after 3
        restarts in 120s, enters 60s cooldown to prevent cascade.
        """
        import time as _t
        now = _t.time()
        # Cooldown check
        if now < self._restart_cooldown_until:
            log.warning(
                f"Realtime restart SUPPRESSED — in cooldown until "
                f"{self._restart_cooldown_until - now:.0f}s from now"
            )
            return
        # Prune old restart times
        self._restart_times = [t for t in self._restart_times if now - t < self._RESTART_WINDOW]
        if len(self._restart_times) >= self._RESTART_MAX:
            self._restart_cooldown_until = now + self._RESTART_COOLDOWN
            log.error(
                f"Realtime restart cascade detected ({self._RESTART_MAX} restarts in "
                f"{self._RESTART_WINDOW}s) — entering {self._RESTART_COOLDOWN}s cooldown"
            )
            return
        self._restart_times.append(now)
        log.info(f"Realtime restart requested for {self.agent_name} (#{len(self._restart_times)})")
        await self.stop()
        await self.start()

    @property
    def dropped_count(self) -> int:
        return self._dropped_count

    @property
    def is_connected(self) -> bool:
        # Check both the _connected flag AND that the background task is alive.
        # After ESC, _connected stays True but the task is dead/cancelled.
        return self._connected and self._task is not None and not self._task.done()

    @property
    def is_subscribed(self) -> bool:
        # Must verify the background task is still running — ESC cancels the
        # task but leaves _connected=True, causing stale "subscribed" state
        # that prevents DB fallback in meshcode_wait (the "deaf bug").
        return (self._connected
                and getattr(self, "_subscription_ok", False)
                and self._task is not None
                and not self._task.done())

    @property
    def seconds_since_last_event(self) -> float:
        import time as _time_mod
        return _time_mod.time() - self.last_event_at

    @property
    def is_deaf(self) -> bool:
        """True if Realtime claims to be subscribed but hasn't received
        any events for >120s. Raised from 60s to prevent restart cascades
        for agents in persistent wait (e.g. commander always in meshcode_wait)."""
        return self.is_subscribed and self.seconds_since_last_event > 120.0

    @property
    def deaf_restart_count(self) -> int:
        return self._deaf_restart_count
