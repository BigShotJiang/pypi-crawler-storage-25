"""Per-user CLI preferences for MeshCode.

Stores small non-secret settings (like permission_mode for `meshcode run`)
in ~/.meshcode/preferences.json with mode 600. Not the same as the API key
storage in secrets.py — that goes to the OS keychain. This file is for
opinion/UX preferences only, no credentials.

Currently tracked:
  permission_mode  one of "bypass" | "safe" | "ask" | None (unset)
                   - "bypass": meshcode run passes --dangerously-skip-permissions
                     to Claude Code so the autonomous loop runs without prompts.
                   - "safe":   meshcode run does NOT pass that flag, so Claude
                     prompts the user to approve every tool call. Kills the
                     autonomous loop in practice — exists for paranoid users.
                   - "ask":    prompt every launch.
                   - None:     never set; meshcode run prompts on first use,
                     saves the choice, and uses it from then on.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

PREFS_PATH = Path.home() / ".meshcode" / "preferences.json"

VALID_PERMISSION_MODES = {"bypass", "safe", "ask"}
DEFAULT_PERMISSION_MODE_FOR_NON_TTY = "bypass"

# auto_update: True | False | None (unset → prompt on first interactive run)
DEFAULT_AUTO_UPDATE_FOR_NON_TTY = False


def load_prefs() -> Dict[str, Any]:
    """Load the prefs file. Returns {} if missing or unparseable."""
    if not PREFS_PATH.exists():
        return {}
    try:
        return json.loads(PREFS_PATH.read_text())
    except Exception:
        return {}


def _restrict_file_permissions(path: "Path") -> None:
    """Restrict file to owner-only access on all platforms."""
    try:
        if sys.platform == "win32":
            import subprocess
            # icacls: remove inherited ACLs, grant only current user Full Control
            username = os.environ.get("USERNAME", os.environ.get("USER", ""))
            if username:
                subprocess.run(
                    ["icacls", str(path), "/inheritance:r",
                     "/grant:r", f"{username}:(F)"],
                    capture_output=True, timeout=5,
                )
        else:
            os.chmod(path, 0o600)
    except Exception:
        pass


def save_prefs(prefs: Dict[str, Any]) -> bool:
    """Atomic write of the prefs file with restricted permissions."""
    try:
        PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = PREFS_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(prefs, indent=2))
        _restrict_file_permissions(tmp)
        tmp.replace(PREFS_PATH)
        _restrict_file_permissions(PREFS_PATH)
        return True
    except Exception as e:
        print(f"[meshcode] WARNING: could not save prefs: {e}", file=sys.stderr)
        return False


def get_permission_mode() -> Optional[str]:
    """Returns 'bypass' / 'safe' / 'ask' / None."""
    val = load_prefs().get("permission_mode")
    if isinstance(val, str) and val in VALID_PERMISSION_MODES:
        return val
    return None


def set_permission_mode(mode: str) -> bool:
    """Persist a new permission mode. Returns True on success."""
    if mode not in VALID_PERMISSION_MODES:
        print(f"[meshcode] ERROR: invalid permission mode '{mode}'. Use: {', '.join(sorted(VALID_PERMISSION_MODES))}", file=sys.stderr)
        return False
    prefs = load_prefs()
    prefs["permission_mode"] = mode
    prefs["permission_mode_set_at"] = int(time.time())
    return save_prefs(prefs)


def reset_permission_mode() -> bool:
    """Forget the permission mode so the next launch prompts again."""
    prefs = load_prefs()
    prefs.pop("permission_mode", None)
    prefs.pop("permission_mode_set_at", None)
    return save_prefs(prefs)


def prompt_permission_mode() -> str:
    """Default to bypass mode without blocking. The user can change later.

    Previous behavior prompted interactively on first launch, which blocked
    `meshcode run` for 30-60s. Now we default to 'bypass' with a 1-line
    notice and save it. The user can change later with:
        meshcode prefs permission-mode <bypass|safe|ask>
    """
    chosen = "bypass"
    set_permission_mode(chosen)
    print("[meshcode] Permission mode: bypass (change with: meshcode prefs permission-mode <mode>)", file=sys.stderr)
    return chosen


def resolve_permission_mode(per_launch_override: Optional[str] = None) -> str:
    """Resolve the effective permission mode for a single launch.

    Order:
      1. per-launch override (--bypass / --safe flag) wins
      2. saved preference
      3. interactive prompt (saves choice if user is at a TTY)
      4. fallback to 'bypass' for non-TTY environments
    """
    if per_launch_override in VALID_PERMISSION_MODES:
        return per_launch_override

    saved = get_permission_mode()
    if saved == "ask":
        # The user opted into being prompted every launch
        return prompt_permission_mode_quick()
    if saved in ("bypass", "safe"):
        return saved

    # Unset → first-run prompt + save
    return prompt_permission_mode()


def prompt_permission_mode_quick() -> str:
    """One-line prompt for users who picked 'ask each launch'.

    Does NOT save — the saved preference stays as 'ask'.
    """
    if not sys.stdin.isatty():
        return DEFAULT_PERMISSION_MODE_FOR_NON_TTY
    try:
        ans = input("[meshcode] Permission mode for this launch [B/s] (default B): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = ""
    if ans in ("s", "safe"):
        return "safe"
    return "bypass"


# ============================================================
# Auto-update preferences
# ============================================================

def get_auto_update() -> Optional[bool]:
    """Returns True / False / None (unset)."""
    val = load_prefs().get("auto_update")
    if isinstance(val, bool):
        return val
    return None


def set_auto_update(enabled: bool) -> bool:
    prefs = load_prefs()
    prefs["auto_update"] = bool(enabled)
    prefs["auto_update_set_at"] = int(time.time())
    return save_prefs(prefs)


def reset_auto_update() -> bool:
    prefs = load_prefs()
    prefs.pop("auto_update", None)
    prefs.pop("auto_update_set_at", None)
    return save_prefs(prefs)


def prompt_auto_update() -> bool:
    """Interactive first-run prompt. Returns the chosen value and saves it.

    Non-TTY: silently picks DEFAULT_AUTO_UPDATE_FOR_NON_TTY (False) and saves.
    """
    if not sys.stdin.isatty():
        set_auto_update(DEFAULT_AUTO_UPDATE_FOR_NON_TTY)
        return DEFAULT_AUTO_UPDATE_FOR_NON_TTY

    print("", file=sys.stderr)
    print("[meshcode] AUTO-UPDATE — meshcode is iterating fast right now.", file=sys.stderr)
    print("[meshcode]", file=sys.stderr)
    print("[meshcode]   When a new version is published to PyPI, meshcode can", file=sys.stderr)
    print("[meshcode]   pull it in the background (no interruption to your", file=sys.stderr)
    print("[meshcode]   current launch — the next launch picks it up).", file=sys.stderr)
    print("[meshcode]", file=sys.stderr)
    print("[meshcode]   [Y] Yes (recommended) — silent background pip install -U", file=sys.stderr)
    print("[meshcode]   [n] No  — I'll run pip install -U meshcode myself", file=sys.stderr)
    print("[meshcode]", file=sys.stderr)
    try:
        ans = input("[meshcode]   Pick [Y/n] (default Y): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = ""

    chosen = False if ans in ("n", "no") else True
    set_auto_update(chosen)
    label = "ON" if chosen else "OFF"
    print(f"[meshcode]   ✓ Auto-update {label}. Change later with: meshcode prefs auto-update <on|off>", file=sys.stderr)
    print("", file=sys.stderr)
    return chosen


def resolve_auto_update() -> bool:
    """Returns True if auto-update should run for this launch.

    Order:
      1. saved preference
      2. interactive prompt + save (TTY only)
      3. fallback False for non-TTY
    """
    saved = get_auto_update()
    if saved is not None:
        return saved
    return prompt_auto_update()


# ============================================================
# Obsidian vault sync preferences
# ============================================================

def get_obsidian_config() -> Optional[Dict[str, str]]:
    """Returns {"vault_url": "...", "api_key": "..."} if configured, else None."""
    prefs = load_prefs()
    url = prefs.get("obsidian_vault_url")
    key = prefs.get("obsidian_api_key")
    if url and key:
        return {"vault_url": url.rstrip("/"), "api_key": key}
    return None


def set_obsidian_config(vault_url: str, api_key: str) -> bool:
    """Save Obsidian REST API connection settings."""
    prefs = load_prefs()
    prefs["obsidian_vault_url"] = vault_url.rstrip("/")
    prefs["obsidian_api_key"] = api_key
    return save_prefs(prefs)


def clear_obsidian_config() -> bool:
    """Remove Obsidian connection settings."""
    prefs = load_prefs()
    prefs.pop("obsidian_vault_url", None)
    prefs.pop("obsidian_api_key", None)
    return save_prefs(prefs)
