"""Claude Code version compatibility matrix.

Tracks known-good and known-bad Claude Code versions so the SDK can
adjust behavior at runtime and warn users about regressions.

HEARTBEAT THRESHOLD CONTRACT (reference):
  clear(60) < guard(90) < decay(180) < display(300) < client(600)
"""

from __future__ import annotations

import subprocess
import shutil
from typing import Optional, Dict, List, Tuple


# ============================================================
# COMPATIBILITY MATRIX
# ============================================================
# Each entry: version_prefix -> {status, issues[], mitigations[]}
# status: "safe", "degraded", "broken"
# Versions not listed are assumed "unknown" (treated as safe with warning).

MATRIX: Dict[str, Dict] = {
    # Known-good versions
    "2.1.104": {
        "status": "safe",
        "issues": [],
        "mitigations": [],
    },
    # ESC/MCP stdio regression range: 2.1.111 through 2.1.119
    "2.1.111": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe instead of sending cancel notification"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.112": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.113": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.114": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.115": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.116": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.117": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.118": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
    "2.1.119": {
        "status": "broken",
        "issues": ["ESC closes MCP stdio pipe (same as 2.1.111)"],
        "mitigations": ["Pin to 2.1.104: npm i -g @anthropic-ai/claude-code@2.1.104"],
    },
}

RECOMMENDED_VERSION = "2.1.104"


def detect_cc_version() -> Optional[str]:
    """Detect installed Claude Code version. Returns version string or None."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        return None
    try:
        out = subprocess.run(
            [claude_bin, "--version"],
            capture_output=True, text=True, timeout=5,
        )
        # Output like "2.1.104 (Claude Code)" or "Claude Code 2.1.104"
        text = out.stdout.strip()
        for part in text.split():
            # Find the version-like token
            if part[0].isdigit() and "." in part:
                return part.strip("()")
    except Exception:
        pass
    return None


def lookup(version: str) -> Dict:
    """Look up a version in the matrix. Returns entry or unknown default."""
    if version in MATRIX:
        return MATRIX[version]
    # Try prefix match (e.g., "2.1.104" matches "2.1.104-beta")
    for key in MATRIX:
        if version.startswith(key):
            return MATRIX[key]
    return {
        "status": "unknown",
        "issues": [],
        "mitigations": [],
    }


def check() -> Tuple[str, str, Dict]:
    """Check current CC version against matrix.

    Returns: (version_str, status, entry_dict)
    """
    version = detect_cc_version()
    if not version:
        return ("not found", "unknown", {
            "status": "unknown",
            "issues": ["Claude Code not found in PATH"],
            "mitigations": ["Install: npm i -g @anthropic-ai/claude-code"],
        })
    entry = lookup(version)
    return (version, entry["status"], entry)


def get_runtime_adjustments(version: str) -> Dict:
    """Return runtime parameter adjustments for a given CC version.

    These can be applied by the MCP server to mitigate known issues.
    """
    entry = lookup(version)
    adjustments = {}

    if entry["status"] == "broken":
        # ESC kills MCP: use shorter wait timeouts so if MCP dies,
        # it restarts faster and doesn't miss too many messages.
        adjustments["wait_timeout_cap"] = 10  # seconds (default 20)
        adjustments["heartbeat_interval"] = 15  # seconds (default 30)
        adjustments["warn_on_boot"] = True

    elif entry["status"] == "degraded":
        adjustments["heartbeat_interval"] = 20  # slightly more aggressive
        adjustments["warn_on_boot"] = True

    return adjustments


def format_report(version: str, entry: Dict) -> str:
    """Format a human-readable compatibility report."""
    lines = []
    lines.append(f"  Claude Code version: {version}")
    lines.append(f"  Status: {entry.get('status', 'unknown').upper()}")
    lines.append(f"  Recommended: {RECOMMENDED_VERSION}")
    if entry.get("issues"):
        lines.append("")
        lines.append("  Known issues:")
        for issue in entry["issues"]:
            lines.append(f"    - {issue}")
    if entry.get("mitigations"):
        lines.append("")
        lines.append("  Fixes:")
        for m in entry["mitigations"]:
            lines.append(f"    - {m}")
    if entry.get("status") == "safe":
        lines.append("  No known issues.")
    return "\n".join(lines)
