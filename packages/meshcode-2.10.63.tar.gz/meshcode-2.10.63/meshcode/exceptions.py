"""MeshCode exception hierarchy.

All SDK-specific errors inherit from :class:`MeshCodeError` so callers can
catch a single base class, or narrow down to the specific failure mode.

CLI entry points (cli.py, launcher.py, server.py boot) catch these and
convert to ``sys.exit(2)`` so end-user behaviour is unchanged.
"""


class MeshCodeError(Exception):
    """Base exception for all MeshCode SDK errors."""


class AuthError(MeshCodeError):
    """Authentication or API-key related failure.

    Raised when:
    - No API key is found in the keychain or environment
    - The secrets module cannot be loaded
    - An API key is rejected by the server
    """


class RPCError(MeshCodeError):
    """A Supabase RPC call returned an error payload.

    Attributes:
        rpc_name:  Name of the RPC function that failed (if known).
        detail:    Server-provided error message.
    """

    def __init__(self, message: str, *, rpc_name: str = "", detail: str = ""):
        super().__init__(message)
        self.rpc_name = rpc_name
        self.detail = detail


class MeshCodeTimeoutError(MeshCodeError):
    """A network or RPC call timed out.

    Named ``MeshCodeTimeoutError`` to avoid shadowing the builtin
    :class:`TimeoutError`.
    """


class MeshCodeConnectionError(MeshCodeError):
    """Could not reach the MeshCode / Supabase backend.

    Named ``MeshCodeConnectionError`` to avoid shadowing the builtin
    :class:`ConnectionError`.
    """
