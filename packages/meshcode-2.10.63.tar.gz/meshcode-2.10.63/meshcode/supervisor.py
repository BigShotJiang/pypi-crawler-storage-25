"""MeshCode Process Supervisor — auto-restart agents on crash.

Generates macOS launchd plists (or simple bash wrappers) that keep
agents running 24/7. When Claude crashes or MCP dies, the supervisor
restarts in 2-5 seconds automatically.

Usage:
    meshcode supervisor start <project> <agent>  — install + start launchd plist
    meshcode supervisor stop <project> <agent>   — stop + uninstall
    meshcode supervisor status                   — list supervised agents
    meshcode supervisor --simple <project> <agent> — bash while-loop fallback
"""
import os
import sys
import subprocess
import json
import platform
from pathlib import Path


_PLIST_DIR = Path.home() / "Library" / "LaunchAgents"
_PLIST_PREFIX = "io.meshcode.agent"


def _plist_path(project: str, agent: str) -> Path:
    safe_name = f"{project}-{agent}".replace("/", "-").replace(" ", "-")
    return _PLIST_DIR / f"{_PLIST_PREFIX}.{safe_name}.plist"


def _plist_label(project: str, agent: str) -> str:
    safe_name = f"{project}-{agent}".replace("/", "-").replace(" ", "-")
    return f"{_PLIST_PREFIX}.{safe_name}"


def _find_meshcode_bin() -> str:
    """Find the meshcode executable path."""
    import shutil
    path = shutil.which("meshcode")
    if path:
        return path
    # Fallback: python -m meshcode
    return f"{sys.executable} -m meshcode"


def _generate_plist(project: str, agent: str) -> str:
    """Generate a launchd plist XML for auto-restarting an agent."""
    label = _plist_label(project, agent)
    meshcode_bin = _find_meshcode_bin()
    log_dir = Path.home() / ".meshcode" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_log = log_dir / f"{project}-{agent}.stdout.log"
    stderr_log = log_dir / f"{project}-{agent}.stderr.log"

    # Build the command
    if " -m " in meshcode_bin:
        parts = meshcode_bin.split()
        program_args = parts + ["run", project, agent]
    else:
        program_args = [meshcode_bin, "run", project, agent]

    args_xml = "\n".join(f"        <string>{a}</string>" for a in program_args)

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
{args_xml}
    </array>
    <key>KeepAlive</key>
    <true/>
    <key>ThrottleInterval</key>
    <integer>5</integer>
    <key>StandardOutPath</key>
    <string>{stdout_log}</string>
    <key>StandardErrorPath</key>
    <string>{stderr_log}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:{os.path.dirname(sys.executable)}</string>
    </dict>
</dict>
</plist>
"""


def start(project: str, agent: str) -> None:
    """Install and start a launchd supervisor for an agent."""
    if platform.system() != "Darwin":
        print("[meshcode supervisor] launchd is macOS only. Use --simple for other platforms.")
        return

    plist = _plist_path(project, agent)
    _PLIST_DIR.mkdir(parents=True, exist_ok=True)

    # Write plist
    plist.write_text(_generate_plist(project, agent))
    print(f"[meshcode supervisor] Plist written: {plist}")

    # Load it
    result = subprocess.run(
        ["launchctl", "load", str(plist)],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"[meshcode supervisor] Agent {agent}@{project} supervised (KeepAlive=true)")
        print(f"[meshcode supervisor] Logs: ~/.meshcode/logs/{project}-{agent}.stderr.log")
    else:
        print(f"[meshcode supervisor] ERROR: launchctl load failed: {result.stderr.strip()}")


def stop(project: str, agent: str) -> None:
    """Stop and uninstall a supervised agent."""
    plist = _plist_path(project, agent)
    if not plist.exists():
        print(f"[meshcode supervisor] No plist found for {agent}@{project}")
        return

    result = subprocess.run(
        ["launchctl", "unload", str(plist)],
        capture_output=True, text=True
    )
    plist.unlink(missing_ok=True)
    print(f"[meshcode supervisor] Agent {agent}@{project} unsupervised")


def status() -> None:
    """List all supervised agents."""
    if not _PLIST_DIR.exists():
        print("[meshcode supervisor] No supervised agents")
        return

    plists = list(_PLIST_DIR.glob(f"{_PLIST_PREFIX}.*.plist"))
    if not plists:
        print("[meshcode supervisor] No supervised agents")
        return

    print(f"[meshcode supervisor] {len(plists)} supervised agent(s):")
    for p in sorted(plists):
        label = p.stem.replace(f"{_PLIST_PREFIX}.", "")
        # Check if running
        result = subprocess.run(
            ["launchctl", "list", f"{_PLIST_PREFIX}.{label}"],
            capture_output=True, text=True
        )
        running = result.returncode == 0
        state = "RUNNING" if running else "STOPPED"
        print(f"  {label}: {state}")


def simple(project: str, agent: str) -> None:
    """Simple bash while-loop supervisor (cross-platform fallback)."""
    meshcode_bin = _find_meshcode_bin()
    print(f"[meshcode supervisor] Starting simple supervisor for {agent}@{project}")
    print("[meshcode supervisor] Press Ctrl+C to stop")

    restart_count = 0
    while True:
        restart_count += 1
        print(f"\n[meshcode supervisor] Starting agent (attempt #{restart_count})...")
        try:
            if " -m " in meshcode_bin:
                parts = meshcode_bin.split()
                cmd = parts + ["run", project, agent]
            else:
                cmd = [meshcode_bin, "run", project, agent]
            result = subprocess.run(cmd)
            print(f"[meshcode supervisor] Agent exited with code {result.returncode}")
        except KeyboardInterrupt:
            print("\n[meshcode supervisor] Stopped by user")
            break
        except Exception as e:
            print(f"[meshcode supervisor] Error: {e}")

        import time
        backoff = min(2 + restart_count, 10)
        print(f"[meshcode supervisor] Restarting in {backoff}s...")
        try:
            time.sleep(backoff)
        except KeyboardInterrupt:
            print("\n[meshcode supervisor] Stopped by user")
            break
