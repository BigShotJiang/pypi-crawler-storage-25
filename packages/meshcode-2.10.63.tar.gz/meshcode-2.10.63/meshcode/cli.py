#!/usr/bin/env python3
"""MeshCode CLI entry point for pip install."""
import sys
import os

# Force UTF-8 on stdout/stderr for Windows terminals (cp1252 default crashes
# on emojis, em-dashes, and any non-ASCII output the CLI prints).
# Python 3.7+ supports reconfigure(); older versions get a no-op.
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main():
    """Entry point that delegates to comms_v4.py within the package."""
    # Find comms_v4.py — first in package dir, then in repo root
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    repo_root = os.path.dirname(pkg_dir)

    for candidate in [
        os.path.join(pkg_dir, "comms_v4.py"),
        os.path.join(repo_root, "comms_v4.py"),
    ]:
        if os.path.exists(candidate):
            sys.argv[0] = candidate
            # Set __name__ and __file__ for the script
            globs = {"__name__": "__main__", "__file__": candidate}
            # Force UTF-8 on Windows (cp1252 default crashes on non-ASCII)
            with open(candidate, encoding="utf-8") as f:
                exec(compile(f.read(), candidate, "exec"), globs)
            return

    print("[meshcode] ERROR: comms_v4.py not found. Reinstall: pip install meshcode")
    sys.exit(1)


if __name__ == "__main__":
    main()
