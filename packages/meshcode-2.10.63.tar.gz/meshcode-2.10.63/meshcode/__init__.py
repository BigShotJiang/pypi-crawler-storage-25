"""MeshCode — Real-time communication between AI agents."""
__version__ = "2.10.63"

# Exception hierarchy — eagerly imported (lightweight, no deps)
from meshcode.exceptions import (  # noqa: F401
    MeshCodeError,
    AuthError,
    RPCError,
    MeshCodeTimeoutError,
    MeshCodeConnectionError,
)

# Public API — lazy imports to avoid heavy deps at import time
def __getattr__(name):
    if name == "backend":
        from meshcode.meshcode_mcp import backend
        return backend
    if name in _BACKEND_EXPORTS:
        from meshcode.meshcode_mcp import backend
        return getattr(backend, name)
    if name in _SECRETS_EXPORTS:
        from meshcode import secrets
        return getattr(secrets, name)
    raise AttributeError(f"module 'meshcode' has no attribute {name!r}")


# Backend: core messaging & agent management
_BACKEND_EXPORTS = {
    "send_message",
    "read_inbox",
    "count_pending",
    "get_board",
    "heartbeat",
    "set_status",
    "register_agent",
    "get_project_id",
    "sb_rpc",
    "task_create",
    "task_list",
    "encrypt_payload",
    "decrypt_payload",
}

# Secrets: credential management
_SECRETS_EXPORTS = {
    "get_api_key",
    "set_api_key",
    "list_profiles",
}

__all__ = [
    "__version__",
    "backend",
    # Exceptions
    "MeshCodeError",
    "AuthError",
    "RPCError",
    "MeshCodeTimeoutError",
    "MeshCodeConnectionError",
    # Messaging
    "send_message",
    "read_inbox",
    "count_pending",
    # Agent management
    "register_agent",
    "get_project_id",
    "get_board",
    "heartbeat",
    "set_status",
    # Tasks
    "task_create",
    "task_list",
    # Low-level
    "sb_rpc",
    # Encryption
    "encrypt_payload",
    "decrypt_payload",
    # Credentials
    "get_api_key",
    "set_api_key",
    "list_profiles",
]
