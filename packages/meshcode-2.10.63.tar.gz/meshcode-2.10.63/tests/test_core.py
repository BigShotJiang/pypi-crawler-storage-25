"""Core unit tests for meshcode SDK.

Tests fundamental behaviors that must never break:
- Version compatibility matrix
- Message serialization roundtrip
- Auth guard logic
- Status normalization

Run: pytest tests/test_core.py -v
"""

import json
import sys
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

# Ensure the meshcode package is importable from repo root
sys.path.insert(0, str(Path(__file__).parent.parent))


# ============================================================
# 1. Compatibility matrix
# ============================================================

class TestCompatMatrix:
    """Verify the CC version compatibility matrix returns correct data."""

    def test_known_safe_version(self):
        from meshcode.compat import lookup
        entry = lookup("2.1.104")
        assert entry["status"] == "safe"
        assert entry["issues"] == []

    def test_known_broken_version(self):
        from meshcode.compat import lookup
        entry = lookup("2.1.119")
        assert entry["status"] == "broken"
        assert len(entry["issues"]) > 0
        assert "ESC" in entry["issues"][0] or "MCP" in entry["issues"][0]

    def test_all_broken_versions_in_range(self):
        from meshcode.compat import lookup
        for v in range(111, 120):
            entry = lookup(f"2.1.{v}")
            assert entry["status"] == "broken", f"2.1.{v} should be broken"

    def test_unknown_version_returns_unknown(self):
        from meshcode.compat import lookup
        entry = lookup("99.99.99")
        assert entry["status"] == "unknown"

    def test_runtime_adjustments_for_broken(self):
        from meshcode.compat import get_runtime_adjustments
        adj = get_runtime_adjustments("2.1.119")
        assert adj.get("warn_on_boot") is True
        assert adj.get("wait_timeout_cap", 20) < 20

    def test_runtime_adjustments_for_safe(self):
        from meshcode.compat import get_runtime_adjustments
        adj = get_runtime_adjustments("2.1.104")
        assert adj == {}  # no adjustments for safe versions

    def test_format_report_safe(self):
        from meshcode.compat import format_report
        report = format_report("2.1.104", {"status": "safe", "issues": [], "mitigations": []})
        assert "SAFE" in report
        assert "No known issues" in report

    def test_format_report_broken(self):
        from meshcode.compat import format_report
        report = format_report("2.1.119", {
            "status": "broken",
            "issues": ["ESC kills MCP"],
            "mitigations": ["Pin to 2.1.104"],
        })
        assert "BROKEN" in report
        assert "ESC kills MCP" in report
        assert "Pin to 2.1.104" in report

    def test_recommended_version_exists_in_matrix(self):
        from meshcode.compat import MATRIX, RECOMMENDED_VERSION
        assert RECOMMENDED_VERSION in MATRIX
        assert MATRIX[RECOMMENDED_VERSION]["status"] == "safe"


# ============================================================
# 2. Message serialization roundtrip
# ============================================================

class TestMessageSerialization:
    """Test that message payloads survive JSON roundtrip."""

    def test_simple_text_roundtrip(self):
        payload = {"type": "msg", "text": "hello world"}
        serialized = json.dumps(payload)
        deserialized = json.loads(serialized)
        assert deserialized == payload

    def test_nested_payload_roundtrip(self):
        payload = {
            "type": "task_report",
            "data": {
                "findings": [{"severity": "HIGH", "detail": "RLS gap"}],
                "count": 42,
                "nested": {"deep": True},
            },
        }
        serialized = json.dumps(payload)
        deserialized = json.loads(serialized)
        assert deserialized == payload

    def test_unicode_roundtrip(self):
        payload = {"text": "emoji test: \u2713 \u2718 \u26a0 \u2192"}
        serialized = json.dumps(payload, ensure_ascii=False)
        deserialized = json.loads(serialized)
        assert deserialized == payload

    def test_empty_payload(self):
        payload = {}
        serialized = json.dumps(payload)
        deserialized = json.loads(serialized)
        assert deserialized == payload

    def test_large_payload_roundtrip(self):
        """Payloads up to 2000 chars should survive (meshcode message limit)."""
        text = "x" * 1500
        payload = {"text": text}
        serialized = json.dumps(payload)
        deserialized = json.loads(serialized)
        assert len(deserialized["text"]) == 1500


# ============================================================
# 3. Auth guard logic
# ============================================================

class TestAuthGuard:
    """Test that the auth guard correctly blocks unauthenticated commands."""

    def _get_no_auth_cmds(self):
        """Extract the set of commands that don't need auth."""
        # Read the actual set from comms_v4.py to keep tests in sync
        return {"doctor", "compat", "upgrade", "help", "--help", "-h", "login",
                "init", "prefs", "launcher", "--version", "-V", "version",
                "whoami", "profiles", "scan"}

    def test_no_auth_cmds_include_essentials(self):
        cmds = self._get_no_auth_cmds()
        assert "login" in cmds, "login must not require auth"
        assert "init" in cmds, "init must not require auth"
        assert "doctor" in cmds, "doctor must not require auth"
        assert "help" in cmds, "help must not require auth"
        assert "--version" in cmds, "--version must not require auth"

    def test_auth_commands_not_in_no_auth(self):
        cmds = self._get_no_auth_cmds()
        # Commands that MUST require auth
        must_auth = {"send", "board", "status", "history", "register",
                     "go", "run", "invite", "join"}
        for cmd in must_auth:
            assert cmd not in cmds, f"'{cmd}' should require auth"

    def test_api_key_loading_from_env(self):
        """MESHCODE_API_KEY env var should be the first auth source."""
        with patch.dict(os.environ, {"MESHCODE_API_KEY": "test_key_123"}):
            # Import after patching env
            import importlib
            import meshcode.comms_v4 as cv4
            importlib.reload(cv4)
            result = cv4._load_api_key_for_cli()
            assert result == "test_key_123"


# ============================================================
# 4. Status normalization
# ============================================================

class TestStatusNormalization:
    """Test agent status values and transitions."""

    VALID_STATUSES = {
        "needs_setup", "online", "offline", "working", "waiting",
        "idle", "standby", "sleeping", "blocked", "done",
    }

    def test_all_valid_statuses_known(self):
        """Verify the canonical status set matches what we expect."""
        assert len(self.VALID_STATUSES) == 10

    def test_offline_is_terminal(self):
        """offline and needs_setup should not be decayed further."""
        non_decay = {"offline", "needs_setup"}
        assert non_decay.issubset(self.VALID_STATUSES)

    def test_sleeping_trigger_statuses(self):
        """protect_sleeping_trigger intercepts these specific statuses."""
        sleeping_trigger_inputs = {"idle", "online", "waiting"}
        assert sleeping_trigger_inputs.issubset(self.VALID_STATUSES)

    def test_active_statuses_for_display(self):
        """Dashboard should show these as 'active'."""
        active = {"online", "working", "waiting", "idle", "standby", "blocked"}
        assert active.issubset(self.VALID_STATUSES)

    def test_heartbeat_threshold_invariant(self):
        """Verify the threshold ordering invariant.

        clear(60) < guard(90) < decay(180) < display(300) < client(600)
        """
        clear = 60
        guard = 90
        decay = 180
        display = 300
        client = 600
        assert clear < guard < decay < display < client
