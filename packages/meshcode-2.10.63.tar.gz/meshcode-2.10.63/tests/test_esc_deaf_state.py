"""
ESC/MCP Deaf State Test
========================
Tests that the MCP server's send/read/check operations remain functional
after simulated ESC (CancelledError during meshcode_wait).

The "deaf bug": after ESC cancels meshcode_wait, the Realtime WebSocket
task may die but is_subscribed remains True. Subsequent operations should
fall back to DB polling gracefully.

This test does NOT require a running MCP server — it tests the backend
and realtime components directly to verify state recovery.

Usage:
    python tests/test_esc_deaf_state.py
"""

import asyncio
import os
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("SUPABASE_URL", "https://gjinagyyjttyxnaoavnz.supabase.co")


class TestRealtimeStateAfterCancel(unittest.TestCase):
    """Test that Realtime listener recovers from CancelledError."""

    def test_01_is_subscribed_after_task_cancel(self):
        """After task cancellation, is_subscribed should reflect actual state."""
        from meshcode.meshcode_mcp.realtime import RealtimeListener, WEBSOCKETS_AVAILABLE

        if not WEBSOCKETS_AVAILABLE:
            self.skipTest("websockets not installed")

        listener = RealtimeListener(
            supabase_url="https://example.supabase.co",
            supabase_key="fake-key",
            project_id="fake-project",
            agent_name="test-agent",
        )

        # Before start: not subscribed
        self.assertFalse(listener.is_subscribed)

        # Simulate a task that gets cancelled immediately
        async def _test():
            # Create the event objects that start() needs
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()

            # Create a task and cancel it immediately
            task = asyncio.create_task(asyncio.sleep(100))
            listener._task = task
            listener._connected = True  # Simulate was-connected state

            # Cancel (simulates ESC)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

            # After cancel: _connected should be stale (this is the bug)
            # The task is done but _connected wasn't reset
            stale_connected = listener._connected
            task_done = listener._task.done()

            return stale_connected, task_done

        stale_connected, task_done = asyncio.run(_test())

        # FINDING: _connected remains True after task cancel
        # is_subscribed checks _connected, so it returns stale True
        if stale_connected and task_done:
            print("  [CONFIRMED] _connected stays True after task cancel — "
                  "is_subscribed will return stale True. This is the deaf bug root cause.")

        # The task should be done
        self.assertTrue(task_done, "Task should be done after cancel")

    def test_02_is_subscribed_property_accuracy(self):
        """is_subscribed should check both _connected AND task alive."""
        from meshcode.meshcode_mcp.realtime import RealtimeListener

        listener = RealtimeListener(
            supabase_url="https://example.supabase.co",
            supabase_key="fake-key",
            project_id="fake-project",
            agent_name="test-agent",
        )

        # Check is_subscribed implementation
        import inspect
        source = inspect.getsource(type(listener).is_subscribed.fget)
        checks_task = "_task" in source and "done" in source
        only_checks_connected = "_connected" in source and not checks_task

        if only_checks_connected:
            print("  [FINDING] is_subscribed only checks _connected, not _task.done(). "
                  "After ESC cancels the task, is_subscribed returns stale True.")
        elif checks_task:
            print("  [OK] is_subscribed checks both _connected and _task state.")

    def test_03_queue_survives_cancel(self):
        """Message queue should retain messages after task cancellation."""
        from meshcode.meshcode_mcp.realtime import RealtimeListener

        listener = RealtimeListener(
            supabase_url="https://example.supabase.co",
            supabase_key="fake-key",
            project_id="fake-project",
            agent_name="test-agent",
        )

        # Pre-populate queue
        listener.queue.append({"from": "alice", "type": "msg", "payload": {"text": "hello"}})
        listener.queue.append({"from": "bob", "type": "msg", "payload": {"text": "world"}})

        self.assertEqual(len(listener.queue), 2)

        # Simulate cancel (task dies)
        async def _test():
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            task = asyncio.create_task(asyncio.sleep(100))
            listener._task = task
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        asyncio.run(_test())

        # Queue should survive
        self.assertEqual(len(listener.queue), 2, "Queue should survive task cancellation")
        msgs = listener.drain()
        self.assertEqual(len(msgs), 2)
        print("  [OK] Queue survives task cancellation — no message loss from ESC")


class TestCircuitBreakerAfterCancel(unittest.TestCase):
    """Test that circuit breaker state is healthy after simulated interrupts."""

    def test_04_circuit_breaker_not_tripped_by_cancel(self):
        """CancelledError should NOT count as a circuit breaker failure."""
        from meshcode.meshcode_mcp.backend import _CircuitBreaker

        cb = _CircuitBreaker(failure_threshold=3, recovery_timeout=5.0)
        self.assertEqual(cb.state, cb.CLOSED)

        # Simulate 2 real failures
        cb.record_failure()
        cb.record_failure()
        self.assertEqual(cb.state, cb.CLOSED, "Should still be closed after 2 failures")

        # 3 real failures would trip the breaker — this is expected
        cb.record_failure()
        self.assertEqual(cb.state, cb.OPEN, "3 real failures should trip CB")
        print("  [OK] Circuit breaker correctly opens after 3 real failures")

    def test_04b_sb_rpc_excludes_keyboard_interrupt_from_cb(self):
        """sb_rpc should re-raise KeyboardInterrupt without recording CB failure."""
        import inspect
        from meshcode.meshcode_mcp import backend as be

        source = inspect.getsource(be.sb_rpc)

        # Verify KeyboardInterrupt is caught and re-raised (not falling through to record_failure)
        has_keyboard_guard = "KeyboardInterrupt" in source
        has_system_exit_guard = "SystemExit" in source

        self.assertTrue(has_keyboard_guard,
                        "sb_rpc should catch KeyboardInterrupt before it counts as failure")
        self.assertTrue(has_system_exit_guard,
                        "sb_rpc should catch SystemExit before it counts as failure")
        print("  [OK] sb_rpc guards KeyboardInterrupt + SystemExit from circuit breaker")

    def test_05_connection_pool_has_flush(self):
        """Connection pool should have a flush method for recovery."""
        from meshcode.meshcode_mcp.backend import _ConnectionPool

        pool = _ConnectionPool("https://example.supabase.co", pool_size=3)
        has_flush = hasattr(pool, "flush")
        if has_flush:
            pool.flush()
            print("  [OK] Connection pool has flush() for recovery after interrupt")
        else:
            print("  [INFO] Connection pool has no flush() — connections may go stale after interrupt")
        # Not a hard failure — pool may recover via other means


class TestBackendOperationsAfterCancel(unittest.TestCase):
    """Test that backend send/read work after simulated interrupt state."""

    def test_06_send_message_after_cb_reset(self):
        """send_message should work even if circuit breaker was previously open."""
        from meshcode.meshcode_mcp import backend as be

        # Find the circuit breaker instance
        cb = getattr(be, '_cb', None) or getattr(be, '_circuit_breaker', None)
        if cb is None:
            # Search module for CircuitBreaker instances
            for name in dir(be):
                obj = getattr(be, name, None)
                if hasattr(obj, 'state') and hasattr(obj, 'record_failure'):
                    cb = obj
                    break

        if cb is None:
            print("  [INFO] Could not find circuit breaker instance — skipping live test")
            return

        original_state = cb.state
        original_failures = list(cb._failures)

        try:
            for _ in range(10):
                cb.record_failure()

            if cb.state == cb.OPEN:
                cb.state = cb.CLOSED
                cb._failures.clear()

                key = None
                try:
                    import keyring
                    key = keyring.get_password("meshcode", "default")
                except Exception:
                    pass

                if key:
                    result = be.count_pending(
                        "82e46cb2-3e5e-4043-947f-0e8f497f0515",
                        "qa",
                        api_key=key,
                    )
                    self.assertIsNotNone(result)
                    print(f"  [OK] Backend operation succeeds after CB reset (pending={result})")
                else:
                    print("  [SKIP] No API key for live test")
        finally:
            cb.state = original_state
            cb._failures = original_failures

    def test_07_stale_is_subscribed_triggers_db_fallback(self):
        """When is_subscribed is stale True, meshcode_wait's DB safety net should catch it."""
        # This is a structural verification using the local source file
        from pathlib import Path
        server_path = Path(__file__).parent.parent / "meshcode" / "meshcode_mcp" / "server.py"
        if not server_path.exists():
            self.skipTest("server.py not found in repo")

        source = server_path.read_text()

        # Verify DB safety net exists in meshcode_wait
        has_safety_net = "safety" in source.lower() and "count_pending" in source
        has_db_fallback = "read_inbox" in source

        self.assertTrue(has_safety_net,
                        "meshcode_wait should have a DB safety net for stale Realtime")
        self.assertTrue(has_db_fallback,
                        "meshcode_wait should fall back to DB read_inbox")

        has_mid_wait_check = "_rt_sub_timeout" in source

        if has_mid_wait_check and has_safety_net:
            print("  [OK] meshcode_wait has mid-wait DB safety net — "
                  "stale is_subscribed won't cause permanent deafness during wait")
        else:
            print("  [FINDING] DB safety net may only run after full timeout")


class TestDeafStateReproduction(unittest.TestCase):
    """Attempt to reproduce the exact deaf state sequence."""

    def test_08_full_deaf_sequence(self):
        """Simulate: connect → ESC → check if send/read still work.

        This is the core reproduction test. It verifies that after
        CancelledError kills the Realtime task but leaves _connected=True,
        the backend REST operations still function.
        """
        from meshcode.meshcode_mcp import backend as be
        from meshcode.meshcode_mcp.realtime import RealtimeListener

        # 1. Create listener in "was-connected" state
        listener = RealtimeListener(
            supabase_url="https://example.supabase.co",
            supabase_key="fake-key",
            project_id="fake-project",
            agent_name="test-agent",
        )

        # 2. Simulate ESC: task cancelled, _connected remains True
        async def _simulate_esc():
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            task = asyncio.create_task(asyncio.sleep(100))
            listener._task = task
            listener._connected = True
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        asyncio.run(_simulate_esc())

        # 3. Verify: is_subscribed is stale
        stale = listener.is_subscribed
        task_dead = listener._task.done()

        # 4. Verify: backend REST operations still work (independent of Realtime)
        try:
            key = None
            try:
                import keyring
                key = keyring.get_password("meshcode", "default")
            except Exception:
                pass

            if key:
                # send_message uses REST, not Realtime — should work
                result = be.count_pending(
                    "82e46cb2-3e5e-4043-947f-0e8f497f0515",
                    "qa",
                    api_key=key,
                )
                backend_works = result is not None

                print(f"\n  DEAF STATE REPRODUCTION:")
                print(f"    Realtime task alive: {not task_dead}")
                print(f"    is_subscribed (stale): {stale}")
                print(f"    Backend REST works: {backend_works}")
                print(f"    Diagnosis: {'DEAF (Realtime dead but claimed alive)' if stale and task_dead else 'HEALTHY'}")

                self.assertTrue(backend_works,
                                "Backend should work even when Realtime is dead")

                if stale and task_dead:
                    print("\n  [ROOT CAUSE] is_subscribed returns True when task is dead.")
                    print("  FIX: is_subscribed should check `self._task and not self._task.done()`")
            else:
                print("  [SKIP] No API key — structural check only")
                self.assertTrue(stale and task_dead,
                                "Stale state should be reproducible without API key")
                print(f"  [CONFIRMED] Deaf state reproduced: is_subscribed={stale}, task_dead={task_dead}")

        except Exception as e:
            self.fail(f"Backend failed in deaf state: {e}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
