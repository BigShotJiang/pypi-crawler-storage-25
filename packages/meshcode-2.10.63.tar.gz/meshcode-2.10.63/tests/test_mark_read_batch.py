"""
Batch Mark-Read Tests
======================
Verifies that mark_read works correctly in batch scenarios:
- Multiple messages marked read in one call
- Broadcast messages NOT marked read (stay available for other agents)
- Re-reading after mark_read returns empty

Requires: MESHCODE_API_KEY env var or keyring credential.

Usage:
    pytest tests/test_mark_read_batch.py -v
"""

import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("SUPABASE_URL", "https://gjinagyyjttyxnaoavnz.supabase.co")


def _get_api_key():
    key = os.environ.get("MESHCODE_API_KEY")
    if key:
        return key
    try:
        import keyring
        key = keyring.get_password("meshcode", "default")
    except Exception:
        pass
    return key


API_KEY = _get_api_key()
PROJECT = "mesh-dev"
PROJECT_ID = None


def _resolve():
    global PROJECT_ID
    if PROJECT_ID:
        return PROJECT_ID
    if not API_KEY:
        return None
    from meshcode.meshcode_mcp import backend as be
    r = be.sb_rpc("mc_resolve_project", {"p_api_key": API_KEY, "p_project_name": PROJECT})
    if isinstance(r, dict) and r.get("project_id"):
        PROJECT_ID = r["project_id"]
    return PROJECT_ID


AGENT_A = f"mread-a-{int(time.time()) % 10000}"
AGENT_B = f"mread-b-{int(time.time()) % 10000}"


@unittest.skipUnless(API_KEY, "No API key — skipping live tests")
class TestBatchMarkRead(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.pid = _resolve()
        assert cls.pid

        from meshcode.meshcode_mcp import backend as be
        for name, role in [(AGENT_A, "Sender"), (AGENT_B, "Receiver")]:
            be.sb_rpc("mc_register_agent", {
                "p_api_key": API_KEY,
                "p_project_id": cls.pid,
                "p_name": name,
                "p_role": role,
                "p_status": "online",
            })

    @classmethod
    def tearDownClass(cls):
        from meshcode.meshcode_mcp import backend as be
        for name in [AGENT_A, AGENT_B]:
            try:
                be.sb_rpc("mc_unregister_agent", {
                    "p_api_key": API_KEY,
                    "p_project_id": cls.pid,
                    "p_agent_name": name,
                })
            except Exception:
                pass

    def test_01_batch_mark_read(self):
        """Send 5 messages, read_inbox marks all read in one call."""
        from meshcode.meshcode_mcp import backend as be

        # Send 5 messages
        for i in range(5):
            be.send_message(self.pid, AGENT_A, AGENT_B,
                            {"seq": i, "test": "batch_mark_read"},
                            api_key=API_KEY)

        time.sleep(0.3)

        # Read with mark_read=True
        msgs = be.read_inbox(self.pid, AGENT_B, mark_read=True, api_key=API_KEY)
        batch = [m for m in msgs if m.get("payload", {}).get("test") == "batch_mark_read"]
        self.assertEqual(len(batch), 5, f"Expected 5 messages, got {len(batch)}")

        # Verify all marked read (second read should be empty)
        time.sleep(0.2)
        msgs2 = be.read_inbox(self.pid, AGENT_B, mark_read=False, api_key=API_KEY)
        remaining = [m for m in msgs2 if m.get("payload", {}).get("test") == "batch_mark_read"]
        self.assertEqual(len(remaining), 0,
                         f"Expected 0 after mark_read, got {len(remaining)}")

    def test_02_mark_read_idempotent(self):
        """Reading an empty inbox with mark_read=True doesn't error."""
        from meshcode.meshcode_mcp import backend as be

        # Inbox should be empty from test_01
        msgs = be.read_inbox(self.pid, AGENT_B, mark_read=True, api_key=API_KEY)
        real = [m for m in msgs if m.get("type") != "ack"]
        self.assertEqual(len(real), 0)

    def test_03_count_pending_after_mark_read(self):
        """count_pending should be 0 after all messages are marked read."""
        from meshcode.meshcode_mcp import backend as be

        count = be.count_pending(self.pid, AGENT_B, api_key=API_KEY)
        self.assertEqual(count, 0, f"Pending should be 0 after mark_read, got {count}")


@unittest.skipUnless(API_KEY, "No API key — skipping live tests")
class TestEffectiveStatusIntegration(unittest.TestCase):
    """Live integration test for mc_agent_effective_status."""

    @classmethod
    def setUpClass(cls):
        cls.pid = _resolve()
        assert cls.pid

    def test_04_effective_status_returns_agents(self):
        """RPC returns all agents with effective status."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_agent_effective_status", {
            "p_api_key": API_KEY,
            "p_project_id": self.pid,
        })
        self.assertTrue(result.get("ok"), f"RPC failed: {result}")
        agents = result.get("agents", [])
        self.assertGreater(len(agents), 0, "Should have at least 1 agent")

        # Every agent should have both stored and effective status
        for a in agents:
            self.assertIn("stored_status", a)
            self.assertIn("effective_status", a)
            self.assertIn("seconds_since_heartbeat", a)

    def test_05_stale_agents_detected(self):
        """Agents with old heartbeats show effective_status != stored_status."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_agent_effective_status", {
            "p_api_key": API_KEY,
            "p_project_id": self.pid,
        })
        agents = result.get("agents", [])

        for a in agents:
            secs = a.get("seconds_since_heartbeat")
            eff = a.get("effective_status")
            stored = a.get("stored_status")

            if secs is not None and secs > 300:
                # Agent hasn't heartbeated in 5+ min
                if stored not in ("offline", "sleeping", "needs_setup"):
                    self.assertEqual(eff, "offline",
                                     f"{a['name']}: {secs}s since heartbeat, "
                                     f"stored={stored} but effective should be offline")

    def test_06_active_agents_preserve_status(self):
        """Active agents (recent heartbeat) keep their stored status."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_agent_effective_status", {
            "p_api_key": API_KEY,
            "p_project_id": self.pid,
        })
        agents = result.get("agents", [])

        for a in agents:
            secs = a.get("seconds_since_heartbeat")
            if secs is not None and secs < 120:
                self.assertEqual(a["effective_status"], a["stored_status"],
                                 f"{a['name']}: active ({secs}s) but effective "
                                 f"!= stored ({a['effective_status']} vs {a['stored_status']})")


if __name__ == "__main__":
    unittest.main(verbosity=2)
