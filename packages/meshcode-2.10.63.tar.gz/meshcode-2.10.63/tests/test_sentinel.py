"""
Sentinel Tests
===============
Tests for the self-monitoring sentinel agent.

Usage:
    pytest tests/test_sentinel.py -v
"""

import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))


class TestAlertDerivation:
    """Test that alerts are correctly derived from health metrics."""

    def test_healthy_system_no_alerts(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.99,
                "stale_agent_count": 0,
                "failed_rpc_count_1h": 0,
                "active_agent_count": 10,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 0

    def test_low_delivery_rate_warning(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.90,
                "stale_agent_count": 0,
                "failed_rpc_count_1h": 0,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].level == "warning"
            assert alerts[0].metric == "delivery_rate"

    def test_very_low_delivery_rate_critical(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.50,
                "stale_agent_count": 0,
                "failed_rpc_count_1h": 0,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].level == "critical"

    def test_stale_agents_warning(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.99,
                "stale_agent_count": 10,
                "failed_rpc_count_1h": 0,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].metric == "stale_agents"

    def test_failed_rpcs_warning(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.99,
                "stale_agent_count": 0,
                "failed_rpc_count_1h": 5,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].metric == "failed_rpcs"

    def test_multiple_alerts(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {
                "ok": True,
                "message_delivery_rate": 0.70,
                "stale_agent_count": 10,
                "failed_rpc_count_1h": 100,
            }
            alerts = check_health("fake-key")
            assert len(alerts) == 3
            criticals = [a for a in alerts if a.level == "critical"]
            assert len(criticals) >= 2  # delivery + failed RPCs

    def test_db_unreachable_critical(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.side_effect = Exception("Connection refused")
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].level == "critical"
            assert "Cannot reach" in alerts[0].message

    def test_rpc_returns_error(self):
        from scripts.sentinel import check_health
        with patch("meshcode.meshcode_mcp.backend.sb_rpc") as mock_rpc:
            mock_rpc.return_value = {"ok": False, "error": "internal"}
            alerts = check_health("fake-key")
            assert len(alerts) == 1
            assert alerts[0].level == "critical"


class TestAlertFormat:
    """Test alert formatting."""

    def test_alert_to_dict(self):
        from scripts.sentinel import Alert
        alert = Alert("warning", "delivery_rate", "Low delivery", 0.90)
        d = alert.to_dict()
        assert d["level"] == "warning"
        assert d["metric"] == "delivery_rate"
        assert d["value"] == 0.90
        assert "timestamp" in d

    def test_alert_str(self):
        from scripts.sentinel import Alert
        alert = Alert("critical", "db", "Database down")
        s = str(alert)
        assert "[!!]" in s
        assert "db" in s

    def test_warning_str(self):
        from scripts.sentinel import Alert
        alert = Alert("warning", "stale", "5 stale agents")
        s = str(alert)
        assert "[!]" in s
        assert "!!" not in s


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
