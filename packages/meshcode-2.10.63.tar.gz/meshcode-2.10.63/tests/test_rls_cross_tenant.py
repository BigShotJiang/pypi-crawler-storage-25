"""
RLS Cross-Tenant & Impersonation Tests
========================================
Verifies that RLS policies correctly isolate data between projects
and prevent unauthorized access patterns.

Requires: MESHCODE_API_KEY env var or keyring credential.
Uses the existing mesh-dev project for testing.

Usage:
    pytest tests/test_rls_cross_tenant.py -v
"""

import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("SUPABASE_URL", "https://gjinagyyjttyxnaoavnz.supabase.co")


def _get_api_key():
    key = os.environ.get("MESHCODE_API_KEY")
    if key:
        return key
    try:
        import keyring
        key = keyring.get_password("meshcode", "default")
    except Exception:
        pass
    return key


API_KEY = _get_api_key()
# Use mesh-dev as the "own" project
OWN_PROJECT = "mesh-dev"
OWN_PROJECT_ID = None
FAKE_PROJECT_ID = "00000000-0000-0000-0000-000000000000"


def _resolve_project():
    global OWN_PROJECT_ID
    if OWN_PROJECT_ID:
        return OWN_PROJECT_ID
    if not API_KEY:
        return None
    from meshcode.meshcode_mcp import backend as be
    result = be.sb_rpc("mc_resolve_project", {
        "p_api_key": API_KEY,
        "p_project_name": OWN_PROJECT,
    })
    if isinstance(result, dict) and result.get("project_id"):
        OWN_PROJECT_ID = result["project_id"]
    return OWN_PROJECT_ID


@unittest.skipUnless(API_KEY, "No API key — skipping live RLS tests")
class TestCrossTenantIsolation(unittest.TestCase):
    """Agent in project X cannot access project Y data."""

    @classmethod
    def setUpClass(cls):
        cls.project_id = _resolve_project()
        assert cls.project_id, f"Could not resolve project '{OWN_PROJECT}'"

    def test_01_send_to_wrong_project_rejected(self):
        """Cannot send messages to a project you don't own."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_send_message", {
            "p_api_key": API_KEY,
            "p_project_id": FAKE_PROJECT_ID,
            "p_from_agent": "qa",
            "p_to_agent": "attacker",
            "p_payload": {"text": "cross-tenant test"},
            "p_type": "msg",
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Send to fake project should fail: {result}")

    def test_02_read_inbox_wrong_project_rejected(self):
        """Cannot read inbox from a project you don't own."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_read_inbox", {
            "p_api_key": API_KEY,
            "p_project_id": FAKE_PROJECT_ID,
            "p_agent_name": "qa",
            "p_mark_read": False,
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Read from fake project should fail: {result}")

    def test_03_acquire_lease_wrong_project_rejected(self):
        """Cannot acquire agent lease in a project you don't own."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_acquire_agent_lease", {
            "p_api_key": API_KEY,
            "p_project_id": FAKE_PROJECT_ID,
            "p_agent_name": "qa",
            "p_instance_id": "test-instance",
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Lease in fake project should fail: {result}")

    def test_04_heartbeat_wrong_project_no_effect(self):
        """Heartbeat to wrong project should not update any agent."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_heartbeat", {
            "p_project_id": FAKE_PROJECT_ID,
            "p_agent_name": "qa",
        })
        # Heartbeat doesn't have API key auth — it just fails silently
        # if the agent doesn't exist. Verify no error or agent_not_found
        if isinstance(result, dict):
            is_safe = (result.get("error") or
                       result.get("_error") or
                       result.get("status") == "alive")
            # Even if "alive", the pending_messages should be 0
            # (no real agent in fake project)
            self.assertTrue(is_safe, f"Unexpected result: {result}")


@unittest.skipUnless(API_KEY, "No API key — skipping live RLS tests")
class TestImpersonation(unittest.TestCase):
    """Cannot impersonate another agent or user."""

    @classmethod
    def setUpClass(cls):
        cls.project_id = _resolve_project()
        assert cls.project_id

    def test_05_send_as_nonexistent_agent(self):
        """Cannot send messages as an agent that doesn't exist."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_send_message", {
            "p_api_key": API_KEY,
            "p_project_id": self.project_id,
            "p_from_agent": "nonexistent-agent-xyz",
            "p_to_agent": "qa",
            "p_payload": {"text": "impersonation test"},
            "p_type": "msg",
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Send from nonexistent agent should fail: {result}")

    def test_06_invalid_api_key_rejected(self):
        """Invalid API key is rejected."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_send_message", {
            "p_api_key": "mc_fake_invalid_key_12345",
            "p_project_id": self.project_id,
            "p_from_agent": "qa",
            "p_to_agent": "chief",
            "p_payload": {"text": "stolen key test"},
            "p_type": "msg",
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Fake API key should be rejected: {result}")
        # Should specifically say auth_failed
        if isinstance(result, dict) and result.get("error_code"):
            self.assertEqual(result["error_code"], "auth_failed")

    def test_07_empty_api_key_rejected(self):
        """Empty API key is rejected."""
        from meshcode.meshcode_mcp import backend as be

        result = be.sb_rpc("mc_send_message", {
            "p_api_key": "",
            "p_project_id": self.project_id,
            "p_from_agent": "qa",
            "p_to_agent": "chief",
            "p_payload": {"text": "empty key test"},
            "p_type": "msg",
        })
        has_error = isinstance(result, dict) and (
            result.get("error") or result.get("_error")
        )
        self.assertTrue(has_error,
                        f"Empty API key should be rejected: {result}")


@unittest.skipUnless(API_KEY, "No API key — skipping live RLS tests")
class TestRPCErrorConsistency(unittest.TestCase):
    """All RPCs should return consistent error format."""

    @classmethod
    def setUpClass(cls):
        cls.project_id = _resolve_project()
        assert cls.project_id

    def _assert_error_format(self, result, rpc_name):
        """Verify error response has consistent keys."""
        self.assertIsInstance(result, dict, f"{rpc_name}: expected dict, got {type(result)}")
        has_error = "error" in result or "_error" in result
        self.assertTrue(has_error, f"{rpc_name}: no error key in response")
        if "error" in result:
            self.assertIsInstance(result["error"], str,
                                 f"{rpc_name}: error should be string")

    def test_08_send_message_error_format(self):
        from meshcode.meshcode_mcp import backend as be
        result = be.sb_rpc("mc_send_message", {
            "p_api_key": "bad-key",
            "p_project_id": self.project_id,
            "p_from_agent": "qa",
            "p_to_agent": "chief",
            "p_payload": {"text": "test"},
        })
        self._assert_error_format(result, "mc_send_message")

    def test_09_read_inbox_error_format(self):
        from meshcode.meshcode_mcp import backend as be
        result = be.sb_rpc("mc_read_inbox", {
            "p_api_key": "bad-key",
            "p_project_id": self.project_id,
            "p_agent_name": "qa",
        })
        self._assert_error_format(result, "mc_read_inbox")

    def test_10_acquire_lease_error_format(self):
        from meshcode.meshcode_mcp import backend as be
        result = be.sb_rpc("mc_acquire_agent_lease", {
            "p_api_key": "bad-key",
            "p_project_id": self.project_id,
            "p_agent_name": "qa",
            "p_instance_id": "test",
        })
        self._assert_error_format(result, "mc_acquire_agent_lease")


if __name__ == "__main__":
    unittest.main(verbosity=2)
