"""
CI test: verify all SQL functions handle the full agent status enum.

Parses migration files to extract the canonical status enum from the
valid_agent_status CHECK constraint, then scans the latest version of
each function for hardcoded status IN (...) filters. Functions that
intentionally filter a subset must be listed in ALLOWED_SUBSETS.

If someone adds a new status to the enum without updating all functions,
this test fails.
"""

import re
import os
import sys
from pathlib import Path
from collections import defaultdict

MIGRATIONS_DIR = Path(__file__).parent.parent / "supabase" / "migrations"

# Functions that intentionally use a subset of statuses (not a bug).
# Format: { "function_name": "reason why subset is intentional" }
ALLOWED_SUBSETS = {
    "mc_get_my_projects_with_counts": "active_agents counts only online/working/idle by design",
    "mc_meshwork_health_score": "health score only counts online/working/idle as active",
    "mc_spectator_dashboard": "spectator view only shows active agents",
    "mc_agents_auto_sleep": "auto-sleep only transitions specific active statuses by design",
    "mc_agent_profile_after_upsert": "trigger only fires on needs_setup insert by design",
    "mc_onboarding_status": "onboarding checks a subset of 'alive' statuses by design",
    "mc_onboarding_status_from_session": "onboarding checks a subset of 'alive' statuses by design",
}

# Functions that operate on TASK status, not agent status.
# Their status filters (open, in_progress, done, etc.) are task workflow
# states and should NOT be compared against the agent status enum.
TASK_FUNCTIONS = {
    "mc_task_claim",
    "mc_task_complete",
    "mc_task_create",
    "mc_task_reject",
    "mc_task_approve",
}

# Functions that filter on non-agent status fields (link status, goal status,
# onboarding status). Their 'status' columns are unrelated to the agent
# status enum and should NOT be compared against it.
NON_AGENT_STATUS_FUNCTIONS = {
    "mc_create_cross_mesh_task": "filters on mc_mesh_links.status='active', not agent status",
    "mc_create_cross_mesh_task_authed": "filters on mc_mesh_links.status='active', not agent status",
    "mc_dashboard_linked_tasks": "filters on mc_mesh_links.status='active', not agent status",
    "mc_update_goal": "filters on goal status='achieved', not agent status",
}

# Status values from non-agent tables that appear in status filters.
# When a filter contains ONLY values from this set, it's not an agent
# status filter and should be ignored.
NON_AGENT_STATUS_VALUES = {
    "active",       # mc_mesh_links.status
    "processing",   # onboarding/link processing status
    "achieved",     # goal status
    "pending",      # link/invite status
    "rejected",     # link status
    "revoked",      # link status
}

# Functions that MUST handle all statuses (the stale detector class of bugs).
# If a function is here and uses a hardcoded IN filter, the test FAILS.
MUST_HANDLE_ALL = {
    "mc_agents_offline_stale": "stale detector must clear leases for ANY status",
}


def extract_canonical_statuses() -> set[str]:
    """Extract the status enum from the latest valid_agent_status CHECK constraint."""
    statuses = set()
    # Walk migrations in reverse order to find the latest constraint definition
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"), reverse=True)
    for f in migration_files:
        content = f.read_text()
        if "valid_agent_status" not in content:
            continue
        # Find ADD CONSTRAINT block with the ARRAY of statuses
        match = re.search(
            r"ADD\s+CONSTRAINT\s+valid_agent_status\s+CHECK\s*\((.*?)\)",
            content,
            re.DOTALL | re.IGNORECASE,
        )
        if match:
            constraint_body = match.group(1)
            statuses = set(re.findall(r"'(\w+)'", constraint_body))
            if statuses:
                return statuses
    return statuses


def find_latest_function_bodies() -> dict[str, str]:
    """
    Parse all migrations to find the latest CREATE OR REPLACE body for
    each function. Returns {function_name: full_body_sql}.
    """
    functions: dict[str, tuple[str, str]] = {}  # name -> (migration_file, body)
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))

    for f in migration_files:
        content = f.read_text()
        # Match CREATE OR REPLACE FUNCTION (public|meshcode).name(...)
        # Capture everything up to the closing $$;
        pattern = re.compile(
            r"CREATE\s+OR\s+REPLACE\s+FUNCTION\s+"
            r"(?:public|meshcode)\.(mc_\w+)\s*\("
            r"(.*?)"
            r"\$\$\s*;",
            re.DOTALL | re.IGNORECASE,
        )
        for match in pattern.finditer(content):
            func_name = match.group(1)
            func_body = match.group(2)
            # Later migrations overwrite earlier ones (sorted order)
            functions[func_name] = (f.name, func_body)

    return {name: body for name, (_, body) in functions.items()}


def find_status_filters(func_body: str) -> list[set[str]]:
    """
    Find all status IN ('x', 'y', ...) patterns in a function body.
    Returns a list of sets, one per IN clause found.
    """
    filters = []
    # Match: status IN ('x', 'y', ...) or status = 'x'
    in_pattern = re.compile(
        r"\.?status\s+IN\s*\(\s*'(\w+)'(?:\s*,\s*'(\w+)')*\s*\)",
        re.IGNORECASE,
    )
    # More robust: find all IN clauses near "status"
    in_pattern2 = re.compile(
        r"status\s+IN\s*\(([^)]+)\)",
        re.IGNORECASE,
    )
    for match in in_pattern2.finditer(func_body):
        values = set(re.findall(r"'(\w+)'", match.group(1)))
        if values:
            filters.append(values)

    # Also check for status = 'x' (single value filters)
    eq_pattern = re.compile(r"status\s*=\s*'(\w+)'", re.IGNORECASE)
    for match in eq_pattern.finditer(func_body):
        # Skip SET status = 'x' (those are writes, not filters)
        # Check if preceded by SET or comma (part of UPDATE SET clause)
        start = match.start()
        preceding = func_body[max(0, start - 30):start].lower()
        if "set " in preceding or preceding.rstrip().endswith(","):
            continue
        filters.append({match.group(1)})

    return filters


def test_status_enum_coverage():
    """Main test: verify no function has a stale status filter."""
    canonical = extract_canonical_statuses()
    assert canonical, (
        "Could not extract canonical status enum from migrations. "
        "Expected valid_agent_status CHECK constraint."
    )
    print(f"Canonical status enum ({len(canonical)} values): {sorted(canonical)}")

    functions = find_latest_function_bodies()
    assert functions, "No SQL functions found in migrations."
    print(f"Found {len(functions)} functions in migrations.\n")

    failures = []

    for func_name, body in sorted(functions.items()):
        # Skip task workflow functions — they use task status, not agent status
        if func_name in TASK_FUNCTIONS:
            continue
        # Skip functions that filter on non-agent status fields
        if func_name in NON_AGENT_STATUS_FUNCTIONS:
            continue

        filters = find_status_filters(body)
        if not filters:
            continue

        for i, filter_set in enumerate(filters):
            # Skip filters that only contain non-agent status values
            # (e.g., mc_mesh_links.status='active', goal status='achieved')
            if filter_set and filter_set.issubset(NON_AGENT_STATUS_VALUES):
                continue

            missing = canonical - filter_set
            extra = filter_set - canonical
            # Ignore known non-agent statuses in the "extra" check
            extra = extra - NON_AGENT_STATUS_VALUES

            if extra:
                failures.append(
                    f"  {func_name} filter #{i+1}: uses unknown statuses "
                    f"{sorted(extra)} not in enum"
                )

            if missing and func_name in MUST_HANDLE_ALL:
                failures.append(
                    f"  {func_name} filter #{i+1}: MUST handle all statuses "
                    f"but missing {sorted(missing)}. "
                    f"Reason: {MUST_HANDLE_ALL[func_name]}"
                )
            elif missing and func_name not in ALLOWED_SUBSETS:
                failures.append(
                    f"  {func_name} filter #{i+1}: uses subset "
                    f"{sorted(filter_set)}, missing {sorted(missing)}. "
                    f"If intentional, add to ALLOWED_SUBSETS in this test."
                )

    if failures:
        print("FAILURES:")
        for f in failures:
            print(f)
        print(
            f"\nCanonical enum: {sorted(canonical)}\n"
            "Fix: update the function's status filter OR add it to "
            "ALLOWED_SUBSETS with a reason."
        )
        sys.exit(1)
    else:
        print("PASS: All status filters are either complete or allowlisted.")


if __name__ == "__main__":
    test_status_enum_coverage()
