"""
Exception Hierarchy Tests
=========================
Validates the custom exception classes exported by meshcode.

Usage:
    pytest tests/test_exceptions.py -v
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestExceptionHierarchy:
    """All custom exceptions inherit from MeshCodeError."""

    def test_base_is_exception(self):
        from meshcode.exceptions import MeshCodeError
        assert issubclass(MeshCodeError, Exception)

    def test_auth_error_inherits_base(self):
        from meshcode.exceptions import AuthError, MeshCodeError
        assert issubclass(AuthError, MeshCodeError)

    def test_rpc_error_inherits_base(self):
        from meshcode.exceptions import RPCError, MeshCodeError
        assert issubclass(RPCError, MeshCodeError)

    def test_timeout_error_inherits_base(self):
        from meshcode.exceptions import MeshCodeTimeoutError, MeshCodeError
        assert issubclass(MeshCodeTimeoutError, MeshCodeError)

    def test_connection_error_inherits_base(self):
        from meshcode.exceptions import MeshCodeConnectionError, MeshCodeError
        assert issubclass(MeshCodeConnectionError, MeshCodeError)

    def test_catch_all_works(self):
        """Single `except MeshCodeError` catches all subclasses."""
        from meshcode.exceptions import (
            MeshCodeError, AuthError, RPCError,
            MeshCodeTimeoutError, MeshCodeConnectionError,
        )
        for exc_class in [AuthError, RPCError, MeshCodeTimeoutError, MeshCodeConnectionError]:
            try:
                raise exc_class("test")
            except MeshCodeError:
                pass  # Expected
            except Exception:
                assert False, f"{exc_class.__name__} not caught by MeshCodeError"


class TestRPCErrorAttributes:
    """RPCError carries structured metadata."""

    def test_rpc_name_attribute(self):
        from meshcode.exceptions import RPCError
        e = RPCError("test", rpc_name="mc_heartbeat")
        assert e.rpc_name == "mc_heartbeat"

    def test_detail_attribute(self):
        from meshcode.exceptions import RPCError
        e = RPCError("test", detail="not found")
        assert e.detail == "not found"

    def test_default_attributes_empty(self):
        from meshcode.exceptions import RPCError
        e = RPCError("test")
        assert e.rpc_name == ""
        assert e.detail == ""

    def test_str_is_message(self):
        from meshcode.exceptions import RPCError
        e = RPCError("something went wrong")
        assert str(e) == "something went wrong"


class TestExceptionImportsFromPackage:
    """Exceptions are importable from the top-level meshcode package."""

    def test_import_from_meshcode(self):
        from meshcode import (
            MeshCodeError, AuthError, RPCError,
            MeshCodeTimeoutError, MeshCodeConnectionError,
        )
        assert MeshCodeError is not None

    def test_in_all(self):
        import meshcode
        for name in ["MeshCodeError", "AuthError", "RPCError",
                     "MeshCodeTimeoutError", "MeshCodeConnectionError"]:
            assert name in meshcode.__all__, f"{name} missing from __all__"


class TestNoShadowBuiltins:
    """Custom names don't shadow Python builtins."""

    def test_timeout_name_is_prefixed(self):
        from meshcode.exceptions import MeshCodeTimeoutError
        assert MeshCodeTimeoutError.__name__ == "MeshCodeTimeoutError"
        assert MeshCodeTimeoutError is not TimeoutError

    def test_connection_name_is_prefixed(self):
        from meshcode.exceptions import MeshCodeConnectionError
        assert MeshCodeConnectionError.__name__ == "MeshCodeConnectionError"
        assert MeshCodeConnectionError is not ConnectionError
