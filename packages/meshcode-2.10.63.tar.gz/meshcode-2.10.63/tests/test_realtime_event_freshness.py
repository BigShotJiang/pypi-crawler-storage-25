"""
Realtime Event Freshness Tests
===============================
Validates that after stop()+start(), asyncio.Event objects are recreated
fresh and is_subscribed resets correctly. This prevents the "deaf after
ESC" bug where stale Events bound to a dead event loop can never fire.

Usage:
    python tests/test_realtime_event_freshness.py
"""

import asyncio
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestEventFreshnessOnRestart(unittest.TestCase):
    """Verify that start() creates fresh Events and stop() resets state."""

    def _make_listener(self):
        from meshcode.meshcode_mcp.realtime import RealtimeListener
        return RealtimeListener(
            supabase_url="https://example.supabase.co",
            supabase_key="fake-key",
            project_id="fake-project",
            agent_name="test-agent",
        )

    def test_01_stop_resets_connected(self):
        """stop() should set _connected=False."""
        listener = self._make_listener()

        async def _test():
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            listener._connected = True
            listener._subscription_ok = True
            listener._task = asyncio.create_task(asyncio.sleep(100))

            await listener.stop()

            return listener._connected, listener._subscription_ok

        connected, sub_ok = asyncio.run(_test())
        self.assertFalse(connected, "stop() should set _connected=False")
        self.assertFalse(sub_ok, "stop() should set _subscription_ok=False")

    def test_02_stop_resets_is_subscribed(self):
        """is_subscribed should be False after stop()."""
        listener = self._make_listener()

        async def _test():
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            listener._connected = True
            listener._subscription_ok = True
            listener._task = asyncio.create_task(asyncio.sleep(100))

            await listener.stop()
            return listener.is_subscribed

        result = asyncio.run(_test())
        self.assertFalse(result, "is_subscribed should be False after stop()")

    def test_03_start_creates_fresh_events(self):
        """start() should create NEW Event objects, not reuse old ones."""
        listener = self._make_listener()

        async def _test():
            # First start
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            old_stop = listener._stop
            old_msg_event = listener.message_event

            # Simulate a background task
            listener._task = asyncio.create_task(asyncio.sleep(100))

            # Stop
            await listener.stop()

            # Second start — should create fresh Events
            # We mock _run to avoid actual WebSocket connection
            original_run = listener._run

            async def fake_run():
                await asyncio.sleep(100)

            listener._run = fake_run
            await listener.start()

            new_stop = listener._stop
            new_msg_event = listener.message_event

            # Clean up
            if listener._task and not listener._task.done():
                listener._task.cancel()
                try:
                    await listener._task
                except (asyncio.CancelledError, Exception):
                    pass

            return (
                old_stop is not new_stop,
                old_msg_event is not new_msg_event,
            )

        stop_fresh, msg_fresh = asyncio.run(_test())
        self.assertTrue(stop_fresh, "start() should create a NEW _stop Event")
        self.assertTrue(msg_fresh, "start() should create a NEW message_event")

    def test_04_start_resets_connection_state(self):
        """start() should reset _connected and _subscription_ok."""
        listener = self._make_listener()

        async def _test():
            # Set stale state
            listener._connected = True
            listener._subscription_ok = True
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            listener._task = asyncio.create_task(asyncio.sleep(100))

            await listener.stop()

            # start() should reset state
            async def fake_run():
                await asyncio.sleep(100)
            listener._run = fake_run
            await listener.start()

            # Right after start(), before WebSocket connects,
            # state should be reset (not stale from previous session)
            connected = listener._connected
            sub_ok = getattr(listener, "_subscription_ok", False)

            if listener._task and not listener._task.done():
                listener._task.cancel()
                try:
                    await listener._task
                except (asyncio.CancelledError, Exception):
                    pass

            return connected, sub_ok

        connected, sub_ok = asyncio.run(_test())
        self.assertFalse(connected,
                         "start() should reset _connected to False before connecting")
        self.assertFalse(sub_ok,
                         "start() should reset _subscription_ok to False")

    def test_05_wait_for_message_works_after_restart(self):
        """wait_for_message should respond to events after stop()+start()."""
        listener = self._make_listener()

        async def _test():
            # First session
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            listener._task = asyncio.create_task(asyncio.sleep(100))

            # Stop (kills old Events)
            await listener.stop()

            # Second session — fresh Events
            async def fake_run():
                await asyncio.sleep(100)
            listener._run = fake_run
            await listener.start()

            # Now simulate a message arriving by setting the event
            async def _fire_after_delay():
                await asyncio.sleep(0.1)
                listener.message_event.set()

            asyncio.create_task(_fire_after_delay())

            # wait_for_message should wake up from the fresh event
            woke = await listener.wait_for_message(timeout=2.0)

            if listener._task and not listener._task.done():
                listener._task.cancel()
                try:
                    await listener._task
                except (asyncio.CancelledError, Exception):
                    pass

            return woke

        woke = asyncio.run(_test())
        self.assertTrue(woke, "wait_for_message should wake from fresh Event after restart")
        print("  [OK] wait_for_message works after stop()+start() with fresh Events")

    def test_06_stale_event_would_fail(self):
        """Demonstrate that reusing old Events across event loops would fail.

        This is the original bug: if start() reused the old message_event
        (created in the previous asyncio.run() / event loop), it would
        never fire because it's bound to a dead loop.
        """
        listener = self._make_listener()

        # Create events in one event loop
        async def _create():
            listener._stop = asyncio.Event()
            listener.message_event = asyncio.Event()
            # These Events are now bound to THIS loop

        asyncio.run(_create())

        old_event = listener.message_event

        # In a NEW event loop, the old event cannot be set/waited on
        async def _try_old_event():
            try:
                old_event.set()
                return "set_succeeded"
            except Exception as e:
                return f"set_failed: {e}"

        result = asyncio.run(_try_old_event())

        # In Python 3.10+, Events are not bound to loops, so this may succeed.
        # But in older versions or certain conditions, it fails silently
        # (the event fires on the old dead loop, no one receives it).
        # The fix ensures start() always creates fresh Events regardless.
        print(f"  [INFO] Old Event.set() in new loop: {result}")
        print("  [KEY] Regardless of Python version, start() must create fresh Events "
              "to guarantee correctness — the fix does this.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
