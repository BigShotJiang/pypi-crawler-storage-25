"""
Migration Integrity Tests
==========================
Static analysis of SQL migrations to catch structural issues:
- Foreign keys without explicit ON DELETE behavior
- Tables without RLS enabled
- SECURITY DEFINER functions without error handling
- Migration numbering gaps

Usage:
    pytest tests/test_migration_integrity.py -v
"""

import re
import sys
from pathlib import Path
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent))

MIGRATIONS_DIR = Path(__file__).parent.parent / "supabase" / "migrations"


def _all_migrations():
    return sorted(MIGRATIONS_DIR.glob("*.sql"))


def _all_sql():
    return "\n".join(f.read_text(errors="replace") for f in _all_migrations())


class TestForeignKeyIntegrity:
    """All foreign keys should have explicit ON DELETE behavior."""

    def test_no_implicit_on_delete(self):
        """REFERENCES without ON DELETE defaults to RESTRICT — should be explicit."""
        issues = []
        for f in _all_migrations():
            content = f.read_text(errors="replace")
            # Find REFERENCES ... that are NOT followed by ON DELETE
            for match in re.finditer(
                r"REFERENCES\s+\w+\.\w+\(.*?\)(?!\s+ON\s+DELETE)",
                content, re.IGNORECASE | re.DOTALL,
            ):
                # Skip if the next non-whitespace is a comma or end of column
                after = content[match.end():match.end() + 50].strip()
                if after.startswith("ON DELETE"):
                    continue  # Regex was just not greedy enough
                # Also check the full line
                line_start = content.rfind("\n", 0, match.start()) + 1
                line_end = content.find("\n", match.end())
                full_line = content[line_start:line_end].strip()
                if "ON DELETE" in full_line:
                    continue
                issues.append(f"{f.name}: {full_line[:120]}")

        if issues:
            print(f"  [WARNING] {len(issues)} REFERENCES without explicit ON DELETE:")
            for i in issues[:5]:
                print(f"    {i}")
            if len(issues) > 5:
                print(f"    ... and {len(issues) - 5} more")
        # Not a hard failure — some are intentional (RESTRICT by default)


class TestRLSCoverage:
    """All meshcode tables should have RLS enabled."""

    def test_core_tables_have_rls(self):
        """Critical tables must have RLS."""
        sql = _all_sql()
        core_tables = [
            "mc_projects", "mc_agents", "mc_messages",
            "mc_api_keys", "mc_users",
        ]
        missing = []
        for table in core_tables:
            pattern = f"{table} ENABLE ROW LEVEL SECURITY"
            if pattern not in sql:
                # Try alternate format
                alt = f"ALTER TABLE meshcode.{table} ENABLE ROW LEVEL SECURITY"
                if alt not in sql:
                    missing.append(table)
        assert len(missing) == 0, f"Tables without RLS: {missing}"


class TestSecurityDefinerQuality:
    """SECURITY DEFINER functions should have error handling."""

    def test_security_definer_has_exception_block(self):
        """SECURITY DEFINER functions should catch exceptions gracefully."""
        missing_exception = []
        for f in _all_migrations():
            content = f.read_text(errors="replace")
            # Find SECURITY DEFINER functions
            for match in re.finditer(
                r"CREATE\s+OR\s+REPLACE\s+FUNCTION\s+"
                r"(?:public|meshcode)\.(mc_\w+).*?"
                r"SECURITY\s+DEFINER.*?\$\$\s*;",
                content, re.DOTALL | re.IGNORECASE,
            ):
                func_name = match.group(1)
                body = match.group(0)
                # Skip thin wrappers (just call another function)
                if re.search(r"(?:SELECT|RETURN)\s+(?:public|meshcode)\." + re.escape(func_name), body, re.IGNORECASE):
                    continue
                # Check for EXCEPTION block
                if "EXCEPTION" not in body and "WHEN OTHERS" not in body:
                    # Only flag functions that do writes or complex logic
                    if ("INSERT" in body or "UPDATE" in body or "DELETE" in body):
                        missing_exception.append((f.name, func_name))

        # Record but don't fail — many functions intentionally let errors propagate
        if missing_exception:
            print(f"\n  [INFO] {len(missing_exception)} SECURITY DEFINER functions "
                  f"with writes but no EXCEPTION block:")
            for fname, func in missing_exception[:10]:
                print(f"    {fname}: {func}")


class TestMigrationNaming:
    """Migration files should follow naming conventions."""

    def test_migration_count(self):
        """Should have a reasonable number of migrations."""
        count = len(list(_all_migrations()))
        assert count > 0, "No migration files found"
        print(f"  [INFO] {count} migration files")

    def test_no_duplicate_numbers(self):
        """Migration numbers should not conflict."""
        numbers = []
        for f in _all_migrations():
            # Extract the number part (e.g., 20260427_204)
            match = re.match(r"(\d{8}_\d+)", f.name)
            if match:
                numbers.append(match.group(1))
        dupes = [n for n, count in Counter(numbers).items() if count > 1]
        if dupes:
            print(f"  [WARNING] Duplicate migration numbers: {dupes}")
        # Some repos allow same number with different suffixes


class TestRPCConsistency:
    """All RPCs that take p_api_key should validate it."""

    def test_api_key_rpcs_validate(self):
        """RPCs with p_api_key param should call _resolve_api_key."""
        unvalidated = []
        for f in _all_migrations():
            content = f.read_text(errors="replace")
            for match in re.finditer(
                r"CREATE\s+OR\s+REPLACE\s+FUNCTION\s+"
                r"(?:public|meshcode)\.(mc_\w+)\s*\("
                r"(.*?)\$\$\s*;",
                content, re.DOTALL | re.IGNORECASE,
            ):
                func_name = match.group(1)
                body = match.group(2)
                # Skip wrappers
                if re.search(r"(?:SELECT|RETURN)\s+(?:public|meshcode)\." + re.escape(func_name), body, re.IGNORECASE):
                    continue
                if "p_api_key" in body.lower():
                    if "_resolve_api_key" not in body.lower():
                        unvalidated.append((f.name, func_name))

        if unvalidated:
            print(f"\n  [WARNING] {len(unvalidated)} RPCs take p_api_key "
                  f"but don't call _resolve_api_key:")
            for fname, func in unvalidated[:5]:
                print(f"    {fname}: {func}")


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
