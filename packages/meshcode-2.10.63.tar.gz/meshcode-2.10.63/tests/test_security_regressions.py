"""
Security Regression Tests
==========================
Verifies that known security vulnerabilities remain fixed.
Based on SECURITY-AUDIT-2026-04-10.md findings.

These tests parse SQL migrations to verify security-critical
patterns remain in place. No live DB needed.

Usage:
    pytest tests/test_security_regressions.py -v
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

MIGRATIONS_DIR = Path(__file__).parent.parent / "supabase" / "migrations"


def _read_all_migrations() -> str:
    """Concatenate all migrations into one string for pattern matching."""
    content = []
    for f in sorted(MIGRATIONS_DIR.glob("*.sql")):
        content.append(f.read_text(errors="replace"))
    return "\n".join(content)


def _latest_function_body(func_name: str) -> str:
    """Get the latest version of a SQL function body."""
    migrations = sorted(MIGRATIONS_DIR.glob("*.sql"))
    latest = ""
    for f in migrations:
        content = f.read_text(errors="replace")
        pattern = re.compile(
            r"CREATE\s+OR\s+REPLACE\s+FUNCTION\s+(?:public|meshcode)\."
            + re.escape(func_name) + r"\s*\(.*?\$\$\s*;",
            re.DOTALL | re.IGNORECASE,
        )
        match = pattern.search(content)
        if match:
            latest = match.group(0)
    return latest


class TestCRIT1_AutoWakeInjection:
    """CRIT-1: Auto-wake AppleScript/PowerShell injection must be sanitized."""

    def test_auto_wake_sanitizes_input(self):
        """server.py _try_auto_wake should sanitize agent names."""
        server_path = Path(__file__).parent.parent / "meshcode" / "meshcode_mcp" / "server.py"
        source = server_path.read_text()
        # Find _try_auto_wake function — need enough chars to include sanitization
        if "_try_auto_wake" in source:
            func_start = source.index("def _try_auto_wake")
            # Find next function definition to get full body
            next_def = source.find("\ndef ", func_start + 1)
            func_block = source[func_start:next_def if next_def > 0 else func_start + 5000]
            # Should have sanitization before any shell/osascript call
            has_sanitize = ("replace" in func_block or "strip" in func_block
                           or "shlex" in func_block or "quote" in func_block
                           or "alphanumeric" in func_block.lower()
                           or re.search(r"re\.\w+\(", func_block))
            assert has_sanitize, (
                "_try_auto_wake constructs shell commands with agent names "
                "but has no visible input sanitization — RCE risk"
            )


class TestCRIT2_GenericCRUDRestricted:
    """CRIT-2: Generic CRUD RPCs must not be accessible to anon/authenticated."""

    def test_mc_query_revoked_from_anon(self):
        all_sql = _read_all_migrations()
        assert "REVOKE EXECUTE ON FUNCTION public.mc_query" in all_sql, (
            "mc_query should have REVOKE for anon access (migration 068)"
        )

    def test_mc_insert_revoked_from_anon(self):
        all_sql = _read_all_migrations()
        assert "REVOKE EXECUTE ON FUNCTION public.mc_insert" in all_sql

    def test_mc_update_revoked_from_anon(self):
        all_sql = _read_all_migrations()
        assert "REVOKE EXECUTE ON FUNCTION public.mc_update" in all_sql

    def test_mc_delete_revoked_from_anon(self):
        all_sql = _read_all_migrations()
        assert "REVOKE EXECUTE ON FUNCTION public.mc_delete" in all_sql


class TestCRIT4_QueryReadonlyDisabled:
    """CRIT-4: mc_query_readonly (SQL injection) must be disabled."""

    def test_query_readonly_disabled(self):
        all_sql = _read_all_migrations()
        # Should have a disable/drop or raise-error replacement
        has_disable = ("mc_query_readonly has been disabled" in all_sql
                       or "DROP FUNCTION" in all_sql and "mc_query_readonly" in all_sql
                       or "function_disabled" in all_sql)
        assert has_disable, (
            "mc_query_readonly should be disabled — it concatenates "
            "untrusted SQL (SQL injection CRIT-4)"
        )


class TestSecurityDefinerFunctions:
    """SECURITY DEFINER functions must validate api_key before operating."""

    def test_send_message_validates_api_key(self):
        body = _latest_function_body("mc_send_message")
        assert "resolve_api_key" in body.lower() or "api_key" in body.lower(), (
            "mc_send_message should validate API key"
        )
        assert "auth_failed" in body, (
            "mc_send_message should return auth_failed on bad key"
        )

    def test_acquire_lease_validates_api_key(self):
        body = _latest_function_body("mc_acquire_agent_lease")
        assert "resolve_api_key" in body.lower() or "api_key" in body.lower()
        assert "auth_failed" in body

    def test_read_inbox_validates_api_key(self):
        body = _latest_function_body("mc_read_inbox")
        assert "resolve_api_key" in body.lower() or "api_key" in body.lower()
        assert "auth_failed" in body


class TestNoHardcodedSecrets:
    """No hardcoded JWTs or secret keys in source."""

    def test_no_jwt_in_migrations(self):
        for f in sorted(MIGRATIONS_DIR.glob("*.sql")):
            content = f.read_text(errors="replace")
            # JWT pattern: eyJ... (base64 header)
            jwts = re.findall(r"eyJhbGciOiJ\w{20,}", content)
            assert len(jwts) == 0, (
                f"Hardcoded JWT found in {f.name}: {jwts[0][:30]}..."
            )

    def test_no_service_role_in_python(self):
        meshcode_dir = Path(__file__).parent.parent / "meshcode"
        for f in meshcode_dir.rglob("*.py"):
            content = f.read_text(errors="replace")
            # Service role keys start with eyJ and are very long
            if "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" in content:
                # Allow if it's in a test or comment about scanning
                if "grep" not in content and "test" not in f.name:
                    assert False, (
                        f"Possible hardcoded JWT in {f.name} — "
                        f"see SECURITY-AUDIT-2026-04-10.md"
                    )


class TestRLSPoliciesExist:
    """Critical tables must have RLS enabled."""

    def test_mc_messages_has_rls(self):
        all_sql = _read_all_migrations()
        assert "mc_messages ENABLE ROW LEVEL SECURITY" in all_sql

    def test_mc_agents_has_rls(self):
        all_sql = _read_all_migrations()
        assert "mc_agents ENABLE ROW LEVEL SECURITY" in all_sql

    def test_mc_api_keys_has_rls(self):
        all_sql = _read_all_migrations()
        assert "mc_api_keys ENABLE ROW LEVEL SECURITY" in all_sql
