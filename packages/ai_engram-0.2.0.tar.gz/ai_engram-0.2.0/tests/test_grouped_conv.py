"""Grouped/Depthwise convolution mathematical equivalence.

Confirms that the batched per-group implementation matches a manual
per-group calculation for the closed-form engram formula
W_engram = W @ Pos_Cov @ pinv(Total_Cov).
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from ai_engram.config import EditorConfig
from ai_engram.editor import EngramEditor


def make_loader(data: torch.Tensor, batch_size: int = 4) -> DataLoader:
    dummy_labels = torch.zeros(data.size(0), dtype=torch.long)
    return DataLoader(TensorDataset(data, dummy_labels), batch_size=batch_size)


def manual_per_group_engram(
    weight: torch.Tensor,
    pos_cov: torch.Tensor,
    total_cov: torch.Tensor,
    groups: int,
    precision: torch.dtype = torch.float64,
) -> torch.Tensor:
    """Ground truth: compute each group independently."""
    original_shape = weight.shape
    C_out_g = weight.shape[0] // groups
    weight_grouped = weight.to(precision).reshape(groups, C_out_g, -1)

    results = []
    for g in range(groups):
        w_g = weight_grouped[g]  # (C_out/G, D)
        pos_g = pos_cov[g].to(precision)  # (D, D)
        total_g = total_cov[g].to(precision)  # (D, D)
        w_engram_g = w_g @ pos_g @ torch.linalg.pinv(total_g)
        results.append(w_engram_g)

    return torch.stack(results).reshape(original_shape)


class DepthwiseModel(nn.Module):
    """MobileNet/EfficientNet pattern: depthwise + pointwise."""

    def __init__(self):
        super().__init__()
        self.dw = nn.Conv2d(32, 32, 3, padding=1, groups=32)
        self.pw = nn.Conv2d(32, 64, 1)

    def forward(self, x):
        return self.pw(self.dw(x))


class GroupedConv2dModel(nn.Module):
    """ResNeXt pattern: grouped conv + pointwise."""

    def __init__(self):
        super().__init__()
        self.gc = nn.Conv2d(64, 64, 3, padding=1, groups=4)
        self.pw = nn.Conv2d(64, 128, 1)

    def forward(self, x):
        return self.pw(self.gc(x))


class GroupedConv1dModel(nn.Module):
    """Grouped Conv1d."""

    def __init__(self):
        super().__init__()
        self.gc = nn.Conv1d(32, 32, 3, padding=1, groups=8)
        self.linear = nn.Linear(32, 16)

    def forward(self, x):
        out = self.gc(x)  # (B, 32, L)
        return self.linear(out.mean(dim=-1))


def run_test(name, model, data, grouped_layer_name, device):
    print(f"\n{'=' * 60}")
    print(f"TEST: {name}")
    print(f"{'=' * 60}")

    model = model.to(device)
    config = EditorConfig(device=device, precision=torch.float64, verbose=False)
    editor = EngramEditor(model, config)
    loader = make_loader(data.to(device))

    stats = editor.collect_statistics(loader)
    print(f"  Layers collected: {list(stats.keys())}")

    module = dict(model.named_modules())[grouped_layer_name]
    G = module.groups
    cov = stats[grouped_layer_name]

    if isinstance(module, nn.Conv2d):
        D = (module.in_channels // G) * module.kernel_size[0] * module.kernel_size[1]
    else:
        D = (module.in_channels // G) * module.kernel_size[0]

    expected_shape = (G, D, D)
    assert cov.shape == torch.Size(expected_shape), (
        f"  FAIL shape: expected {expected_shape}, got {tuple(cov.shape)}"
    )
    print(f"  [A] Covariance shape: {tuple(cov.shape)} == {expected_shape} ✓")

    engram_batched = editor.compute_engram_weights(stats, stats)

    assert grouped_layer_name in engram_batched, (
        f"  FAIL: {grouped_layer_name} not in engram weights"
    )
    w_batched = engram_batched[grouped_layer_name]
    assert w_batched.shape == module.weight.shape, (
        f"  FAIL shape: engram {tuple(w_batched.shape)} != weight {tuple(module.weight.shape)}"
    )
    print(f"  [A] Engram weight shape preserved: {tuple(w_batched.shape)} ✓")

    w_manual = manual_per_group_engram(
        module.weight,
        stats[grouped_layer_name].to(device),
        stats[grouped_layer_name].to(device),
        G,
        precision=torch.float64,
    )

    max_diff = (w_batched.cpu().to(torch.float64) - w_manual.cpu()).abs().max().item()
    is_close = torch.allclose(w_batched.cpu().to(torch.float64), w_manual.cpu(), atol=1e-10)
    print(f"  [B] Mathematical equivalence: max_diff={max_diff:.2e}, allclose={is_close}")
    assert is_close, f"  FAIL equivalence: max_diff={max_diff:.2e}"
    print("  [B] Batched == Manual per-group ✓")

    edited_model = editor.edit(stats, stats, edit_strength=1.0)
    edited_module = dict(edited_model.named_modules())[grouped_layer_name]

    assert edited_module.weight.shape == module.weight.shape, "  FAIL: shape changed after edit"
    assert not torch.equal(edited_module.weight, module.weight), (
        "  FAIL: weights unchanged after edit"
    )
    print("  [C] Weight changed after edit ✓")

    with torch.no_grad():
        out = edited_model(data[:1].to(device))
    assert out is not None and not torch.isnan(out).any(), "  FAIL: NaN in output"
    print(f"  [C] Forward pass after edit: output shape {tuple(out.shape)} ✓")

    print("  PASSED ✓")
    return True


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    if device.type == "cuda":
        print(f"GPU: {torch.cuda.get_device_name()}")

    torch.manual_seed(42)
    results = []

    results.append(
        run_test(
            "Depthwise Conv2d (groups=C_in=32)",
            DepthwiseModel(),
            torch.randn(16, 32, 8, 8),
            "dw",
            device,
        )
    )
    results.append(
        run_test(
            "Grouped Conv2d (groups=4)",
            GroupedConv2dModel(),
            torch.randn(16, 64, 8, 8),
            "gc",
            device,
        )
    )
    results.append(
        run_test(
            "Grouped Conv1d (groups=8)",
            GroupedConv1dModel(),
            torch.randn(16, 32, 64),
            "gc",
            device,
        )
    )

    print(f"\n{'=' * 60}")
    print(f"SUMMARY: {sum(results)}/{len(results)} tests passed")
    print(f"{'=' * 60}")

    if not all(results):
        exit(1)


if __name__ == "__main__":
    main()
