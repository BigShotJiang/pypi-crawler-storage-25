"""Basic unit tests for ai-engram (CPU, no GPU required)."""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from ai_engram import EditorConfig, EngramEditor


def _make_loader(x, batch_size=4):
    labels = torch.zeros(x.size(0), dtype=torch.long)
    return DataLoader(TensorDataset(x, labels), batch_size=batch_size)


class SimpleNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(3, 16, 3, padding=1)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        x = self.conv(x)
        x = x.mean(dim=[2, 3])
        return self.fc(x)


class GroupedNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.dw = nn.Conv2d(16, 16, 3, padding=1, groups=16)
        self.pw = nn.Conv2d(16, 32, 1)

    def forward(self, x):
        return self.pw(self.dw(x))


def test_collect_statistics():
    model = SimpleNet()
    config = EditorConfig(device=torch.device("cpu"), verbose=False)
    editor = EngramEditor(model, config)
    loader = _make_loader(torch.randn(8, 3, 8, 8))
    stats = editor.collect_statistics(loader)
    assert len(stats) > 0
    for name, cov in stats.items():
        assert cov.dim() == 2
        assert not torch.isnan(cov).any()


def test_edit_pipeline():
    model = SimpleNet()
    config = EditorConfig(device=torch.device("cpu"), verbose=False)
    editor = EngramEditor(model, config)
    loader = _make_loader(torch.randn(8, 3, 8, 8))
    stats = editor.collect_statistics(loader)

    original_weight = model.conv.weight.clone()
    edited = editor.edit(stats, stats, edit_strength=1.0)
    assert not torch.equal(edited.conv.weight, original_weight)

    with torch.no_grad():
        out = edited(torch.randn(1, 3, 8, 8))
    assert out.shape == (1, 10)
    assert not torch.isnan(out).any()


def test_grouped_conv_covariance_shape():
    model = GroupedNet()
    config = EditorConfig(device=torch.device("cpu"), verbose=False)
    editor = EngramEditor(model, config)
    loader = _make_loader(torch.randn(8, 16, 8, 8))
    stats = editor.collect_statistics(loader)

    assert "dw" in stats
    cov = stats["dw"]
    # depthwise: groups=16, D = (16/16)*3*3 = 9 → shape (16, 9, 9)
    assert cov.shape == (16, 9, 9)


def test_grouped_conv_edit():
    model = GroupedNet()
    config = EditorConfig(device=torch.device("cpu"), verbose=False)
    editor = EngramEditor(model, config)
    loader = _make_loader(torch.randn(8, 16, 8, 8))
    stats = editor.collect_statistics(loader)

    original_dw = model.dw.weight.clone()
    edited = editor.edit(stats, stats, edit_strength=1.0)
    assert not torch.equal(edited.dw.weight, original_dw)

    with torch.no_grad():
        out = edited(torch.randn(1, 16, 8, 8))
    assert not torch.isnan(out).any()


def test_merge_statistics():
    model = SimpleNet()
    config = EditorConfig(device=torch.device("cpu"), verbose=False)
    editor = EngramEditor(model, config)

    loader1 = _make_loader(torch.randn(8, 3, 8, 8))
    loader2 = _make_loader(torch.randn(8, 3, 8, 8))

    stats1 = editor.collect_statistics(loader1)
    stats2 = editor.collect_statistics(loader2)

    merged = EngramEditor.merge_statistics(stats1, stats2)
    for name in stats1:
        expected = stats1[name] + stats2[name]
        assert torch.allclose(merged[name], expected)


def test_config_defaults():
    config = EditorConfig()
    assert config.precision == torch.float32
    assert config.edit_strength == 1.0
    assert config.verbose is True
