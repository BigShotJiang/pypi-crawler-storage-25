"""Main EngramEditor class for neural network information editing."""

import copy
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type, Union

import torch
import torch.nn as nn
from tqdm.auto import tqdm

from ai_engram.collectors import CovarianceCollector
from ai_engram.config import EditorConfig
from ai_engram.handlers import Conv1dHandler, Conv2dHandler, LayerHandler, LinearHandler

logger = logging.getLogger("ai_engram")


class EngramEditor:
    """Neural network information editor using covariance-based localization.

    Removes specific information from neural network weights by computing the
    engram projection in closed form::

        W_engram = W_original @ Pos_Cov @ pinv(Total_Cov)

    Example:
        >>> editor = EngramEditor(model, EditorConfig(device="cuda"))
        >>> target_cov = editor.collect_statistics(target_loader)
        >>> total_cov = editor.collect_statistics(all_loader)
        >>> edited_model = editor.edit(target_cov, total_cov)
    """

    def __init__(
        self,
        model: nn.Module,
        config: Optional[EditorConfig] = None,
    ):
        """Initialize the editor.

        Args:
            model: PyTorch model to edit.
            config: Editor configuration. Uses defaults if not provided.
        """
        self.model = model
        self.config = config or EditorConfig()
        self.registry: Dict[Type[nn.Module], LayerHandler] = {
            nn.Linear: LinearHandler(),
            nn.Conv1d: Conv1dHandler(),
            nn.Conv2d: Conv2dHandler(),
        }

    def _move_to_device(self, data: Any) -> Any:
        """Recursively move tensors to the configured device."""
        if torch.is_tensor(data):
            return data.to(self.config.device)
        elif isinstance(data, dict):
            return {k: self._move_to_device(v) for k, v in data.items()}
        elif isinstance(data, (list, tuple)):
            return type(data)(self._move_to_device(v) for v in data)
        return data

    def _forward(self, inputs: Any) -> None:
        """Execute forward pass with various input patterns."""
        if isinstance(inputs, dict):
            self.model(**inputs)
        elif isinstance(inputs, (list, tuple)):
            if len(inputs) > 0 and isinstance(inputs[0], dict):
                self.model(**inputs[0])
            else:
                self.model(*inputs)
        else:
            self.model(inputs)

    def collect_statistics(
        self,
        dataloader,
        target_layers: Optional[List[str]] = None,
        batch_fn: Optional[Callable] = None,
    ) -> Dict[str, torch.Tensor]:
        """Collect covariance matrices from data.

        Args:
            dataloader: PyTorch DataLoader.
            target_layers: Specific layer names to target. If None, all supported layers.
            batch_fn: Optional function to extract inputs from batch.

        Returns:
            Dictionary mapping layer names to covariance matrices.
        """
        collector = CovarianceCollector(self.model, self.config, self.registry, target_layers)
        self.model.eval()

        with collector, torch.inference_mode():
            for batch in tqdm(
                dataloader,
                disable=not self.config.verbose,
                desc="Collecting covariance",
            ):
                raw_inputs = batch_fn(batch) if batch_fn else batch[0]
                inputs = self._move_to_device(raw_inputs)
                self._forward(inputs)

        return collector.covariance_matrices

    @staticmethod
    def merge_statistics(*stats_dicts: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Merge multiple covariance dictionaries by summation."""
        if not stats_dicts:
            return {}

        merged = {k: v.clone() for k, v in stats_dicts[0].items()}

        for d in stats_dicts[1:]:
            for k, v in d.items():
                if k in merged:
                    merged[k].add_(v)
                else:
                    merged[k] = v.clone()

        return merged

    @torch.no_grad()
    def compute_engram_weights(
        self,
        target_covariances: Union[Dict[str, torch.Tensor], List[Dict[str, torch.Tensor]]],
        total_covariance: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """Compute engram weights for each layer.

        Formula: W_engram = W_original @ Pos_Cov @ pinv(Total_Cov).

        Args:
            target_covariances: Covariance of target data to remove.
            total_covariance: Covariance of total data.

        Returns:
            Dictionary mapping layer names to engram weight tensors.
        """
        if isinstance(target_covariances, list):
            target_covariances = self.merge_statistics(*target_covariances)

        engram_weights = {}
        modules = dict(self.model.named_modules())

        for layer_name, pos_cov in tqdm(
            target_covariances.items(),
            disable=not self.config.verbose,
            desc="Computing engram",
        ):
            if layer_name not in total_covariance:
                continue

            module = modules[layer_name]
            sum_cov = total_covariance[layer_name].to(
                self.config.device, dtype=self.config.precision
            )
            pos_cov = pos_cov.to(self.config.device, dtype=self.config.precision)

            original_weight = module.weight.to(self.config.precision)
            original_shape = original_weight.shape

            is_grouped = isinstance(module, (nn.Conv1d, nn.Conv2d)) and module.groups > 1
            if is_grouped:
                G = module.groups
                C_out_g = module.out_channels // G
                original_weight = original_weight.reshape(G, C_out_g, -1)
            elif isinstance(module, (nn.Conv1d, nn.Conv2d)):
                original_weight = original_weight.reshape(original_shape[0], -1)

            w_engram = original_weight @ pos_cov @ torch.linalg.pinv(sum_cov)
            engram_weights[layer_name] = w_engram.reshape(original_shape)

        return engram_weights

    @torch.no_grad()
    def apply_engram_weights(
        self,
        engram_weights: Dict[str, torch.Tensor],
        edit_strength: Optional[float] = None,
        inplace: bool = False,
    ) -> nn.Module:
        """Apply engram weights to edit the model.

        Args:
            engram_weights: Pre-computed engram weights.
            edit_strength: Override config edit strength.
            inplace: If True, modify model in place.

        Returns:
            Edited model.
        """
        edit_model = self.model if inplace else copy.deepcopy(self.model)
        strength = edit_strength if edit_strength is not None else self.config.edit_strength

        modules = dict(edit_model.named_modules())
        for layer_name, w_engram in engram_weights.items():
            if layer_name in modules:
                module = modules[layer_name]
                update = (strength * w_engram).to(module.weight.dtype)
                module.weight.copy_(module.weight - update)

        return edit_model

    @torch.no_grad()
    def edit(
        self,
        target_covariances: Union[Dict[str, torch.Tensor], List[Dict[str, torch.Tensor]]],
        total_covariance: Dict[str, torch.Tensor],
        edit_strength: Optional[float] = None,
        inplace: bool = False,
    ) -> nn.Module:
        """Compute engrams and edit model in one call.

        Args:
            target_covariances: Covariance of data to remove.
            total_covariance: Covariance of all data.
            edit_strength: Override config edit strength.
            inplace: If True, modify model in place.

        Returns:
            Edited model with target information removed.
        """
        engram_weights = self.compute_engram_weights(target_covariances, total_covariance)
        return self.apply_engram_weights(engram_weights, edit_strength, inplace)

    def save_statistics(self, stats: Dict[str, torch.Tensor], path: Union[str, Path]) -> None:
        """Save statistics to file."""
        torch.save(stats, path)
        logger.info(f"Saved statistics to {path}")

    def load_statistics(self, path: Union[str, Path]) -> Dict[str, torch.Tensor]:
        """Load statistics from file."""
        return torch.load(path, map_location=self.config.storage_device)

    def merge_statistics_from_files(
        self,
        file_paths: List[Union[str, Path]],
        device: str = "cuda",
        max_workers: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """Merge statistics from multiple files with parallel loading.

        Args:
            file_paths: List of file paths to merge.
            device: Device to load tensors to.
            max_workers: Number of parallel workers.

        Returns:
            Merged covariance dictionary.
        """
        if max_workers is None:
            max_workers = min(16, max(2, os.cpu_count() or 8))

        total_cov = None
        pbar = tqdm(total=len(file_paths), desc="Merging statistics")

        def load_file(path):
            return torch.load(path, map_location=device, weights_only=True)

        with torch.inference_mode():
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(load_file, p): p for p in file_paths}

                for future in as_completed(futures):
                    target_cov = future.result()
                    if total_cov is None:
                        total_cov = target_cov
                    else:
                        total_cov = self.merge_statistics(total_cov, target_cov)
                    pbar.update(1)

        pbar.close()
        return total_cov or {}
