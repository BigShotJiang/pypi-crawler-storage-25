"""Configuration for AI Engram editor."""

from dataclasses import dataclass, field

import torch


@dataclass
class EditorConfig:
    """Configuration for AI Engram identification and editing.

    Attributes:
        device: Device for computation (default: cuda if available).
        storage_device: Device for storing covariance matrices.
        precision: Numerical precision for computation.
        edit_strength: Alpha coefficient for editing (1.0 = full removal).
        verbose: Whether to show progress bars.
    """

    device: torch.device = field(
        default_factory=lambda: torch.device("cuda" if torch.cuda.is_available() else "cpu")
    )
    storage_device: torch.device = field(default_factory=lambda: torch.device("cpu"))
    precision: torch.dtype = torch.float32
    edit_strength: float = 1.0
    verbose: bool = True
