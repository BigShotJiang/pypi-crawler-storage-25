"""Data utilities for forget/retain splitting and transform presets."""

from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

# ──────────────────────────────────────────────
# Transform 프리셋
# ──────────────────────────────────────────────


def get_transform_preset(
    preset: str,
    mean: Tuple[float, ...],
    std: Tuple[float, ...],
    split: str = "train",
) -> Any:
    """Transform 프리셋 반환

    Args:
        preset: "cifar" | "svhn" | "imagenet224" | "imagenet64" | "mnist28"
        mean: 정규화 평균
        std: 정규화 표준편차
        split: "train" | "test"

    Returns:
        torchvision.transforms.Compose
    """
    try:
        from torchvision import transforms
    except ImportError as e:
        raise ImportError("torchvision is required for transforms") from e

    normalize = transforms.Normalize(mean=mean, std=std)

    if preset == "cifar":
        if split == "train":
            return transforms.Compose(
                [
                    transforms.RandomCrop(32, padding=4),
                    transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                    normalize,
                ]
            )
        return transforms.Compose(
            [
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "svhn":
        return transforms.Compose(
            [
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "imagenet224":
        if split == "train":
            return transforms.Compose(
                [
                    transforms.Resize(256),
                    transforms.RandomCrop(224),
                    transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                    normalize,
                ]
            )
        return transforms.Compose(
            [
                transforms.Resize(256),
                transforms.CenterCrop(224),
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "imagenet64":
        if split == "train":
            return transforms.Compose(
                [
                    transforms.Resize(72),
                    transforms.RandomCrop(64),
                    transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                    normalize,
                ]
            )
        return transforms.Compose(
            [
                transforms.Resize(72),
                transforms.CenterCrop(64),
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "celeba64":
        return transforms.Compose(
            [
                transforms.CenterCrop(140),
                transforms.Resize((64, 64)),
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "mnist28":
        return transforms.Compose(
            [
                transforms.ToTensor(),
                normalize,
            ]
        )

    elif preset == "mnist28-1ch":
        return transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(mean=(mean[0],), std=(std[0],)),
            ]
        )

    elif preset == "none":
        return transforms.Compose(
            [
                transforms.ToTensor(),
            ]
        )

    else:
        raise ValueError(f"Unknown transform preset: '{preset}'")


# ──────────────────────────────────────────────
# Forget/Retain 분리
# ──────────────────────────────────────────────


def get_targets(dataset: Dataset) -> np.ndarray:
    """데이터셋에서 타겟 배열 추출 (SVHN .labels vs CIFAR .targets 처리)"""
    if hasattr(dataset, "identity"):
        return dataset.identity.reshape(-1).numpy()

    if hasattr(dataset, "targets"):
        targets = dataset.targets
    elif hasattr(dataset, "labels"):
        targets = dataset.labels
    elif hasattr(dataset, "_labels"):
        targets = dataset._labels
    else:
        raise AttributeError(
            f"Cannot find targets/labels attribute on {type(dataset).__name__}. "
            f"Available attributes: {[a for a in dir(dataset) if not a.startswith('__')]}"
        )

    if isinstance(targets, torch.Tensor):
        return targets.numpy()
    return np.array(targets)


def split_forget_retain(
    dataset: Dataset,
    forget_classes: Sequence[int],
) -> Dict[str, List[int]]:
    """클래스별 forget/retain 인덱스 분리

    Args:
        dataset: PyTorch Dataset (targets 또는 labels 속성 필요)
        forget_classes: forget할 클래스 인덱스

    Returns:
        {"forget": [indices], "retain": [indices]}
    """
    targets = get_targets(dataset)
    forget_set = set(forget_classes)

    forget_indices = []
    retain_indices = []
    for i, t in enumerate(targets):
        if int(t) in forget_set:
            forget_indices.append(i)
        else:
            retain_indices.append(i)

    return {"forget": forget_indices, "retain": retain_indices}
