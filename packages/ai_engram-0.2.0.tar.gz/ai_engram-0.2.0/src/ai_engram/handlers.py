"""Layer handlers for extracting input features."""

from abc import ABC, abstractmethod
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


class LayerHandler(ABC):
    """Abstract base class for layer-specific input handling."""

    @abstractmethod
    def get_input_dim(self, module: nn.Module) -> int:
        """Return the input dimension for covariance matrix."""
        pass

    @abstractmethod
    def reshape_input(self, module: nn.Module, inputs: Any) -> torch.Tensor:
        """Reshape input tensor to (N, D) format for covariance computation."""
        pass


class LinearHandler(LayerHandler):
    """Handler for nn.Linear layers."""

    def get_input_dim(self, module: nn.Linear) -> int:
        return module.in_features

    def reshape_input(self, module: nn.Linear, inputs: Any) -> torch.Tensor:
        return inputs[0].reshape(-1, module.in_features)


class Conv1dHandler(LayerHandler):
    """Handler for nn.Conv1d layers using unfold operation."""

    def get_input_dim(self, module: nn.Conv1d) -> int:
        return (module.in_channels // module.groups) * module.kernel_size[0]

    def reshape_input(self, module: nn.Conv1d, inputs: Any) -> torch.Tensor:
        x = inputs[0]  # [B, C, L]
        G = module.groups
        C_in_g = module.in_channels // G
        K = module.kernel_size[0]

        if G == 1:
            unfolded = x.unfold(2, K, module.stride[0])
            # [B, C, L_out, K] -> [B, L_out, C*K]
            unfolded = unfolded.permute(0, 2, 1, 3).reshape(x.size(0), -1, module.in_channels * K)
            return unfolded.reshape(-1, unfolded.size(2))
        else:
            groups = []
            for g in range(G):
                x_g = x[:, g * C_in_g : (g + 1) * C_in_g]
                uf_g = x_g.unfold(2, K, module.stride[0])
                uf_g = uf_g.permute(0, 2, 1, 3).reshape(x_g.size(0), -1, C_in_g * K)
                groups.append(uf_g.reshape(-1, uf_g.size(2)))
            return torch.stack(groups)  # (G, N*L_out, D)


class Conv2dHandler(LayerHandler):
    """Handler for nn.Conv2d layers using unfold operation."""

    def get_input_dim(self, module: nn.Conv2d) -> int:
        return (module.in_channels // module.groups) * module.kernel_size[0] * module.kernel_size[1]

    def reshape_input(self, module: nn.Conv2d, inputs: Any) -> torch.Tensor:
        x = inputs[0]
        G = module.groups
        C_in_g = module.in_channels // G

        if G == 1:
            unfolded = F.unfold(
                x,
                kernel_size=module.kernel_size,
                dilation=module.dilation,
                padding=module.padding,
                stride=module.stride,
            )
            return unfolded.transpose(1, 2).reshape(-1, unfolded.size(1))
        else:
            groups = []
            for g in range(G):
                x_g = x[:, g * C_in_g : (g + 1) * C_in_g]
                uf_g = F.unfold(
                    x_g,
                    kernel_size=module.kernel_size,
                    dilation=module.dilation,
                    padding=module.padding,
                    stride=module.stride,
                )
                groups.append(uf_g.transpose(1, 2).reshape(-1, uf_g.size(1)))
            return torch.stack(groups)  # (G, N*L, D)


class MaskedLinearHandler(LinearHandler):
    """Handler for masked Linear layers (e.g., attention with padding)."""

    def __init__(self):
        self.current_mask: torch.Tensor | None = None

    def reshape_input(self, module: nn.Linear, inputs: Any) -> torch.Tensor:
        x = inputs[0]  # [Batch, Seq, Dim]
        if self.current_mask is not None:
            mask = self.current_mask.to(x.device).view(-1)
            x_flat = x.reshape(-1, module.in_features)
            return x_flat[mask]
        return super().reshape_input(module, inputs)
