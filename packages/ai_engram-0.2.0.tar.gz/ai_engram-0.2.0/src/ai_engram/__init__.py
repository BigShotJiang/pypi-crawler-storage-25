"""ai-engram: Neural network information editing library."""

__version__ = "0.2.0"

from ai_engram.config import EditorConfig
from ai_engram.editor import EngramEditor

__all__ = [
    "EditorConfig",
    "EngramEditor",
]
