"""Statistics collectors for covariance matrices."""

from typing import Any, Dict, List, Optional, Type

import torch
import torch.nn as nn

from ai_engram.config import EditorConfig
from ai_engram.handlers import LayerHandler


class CovarianceCollector:
    """Context manager for accumulating covariance matrices.

    Registers forward pre-hooks to collect x.T @ x for each layer.
    For grouped convolutions, stores per-group covariance as (G, D, D).
    """

    def __init__(
        self,
        model: nn.Module,
        config: EditorConfig,
        registry: Dict[Type[nn.Module], LayerHandler],
        target_layers: Optional[List[str]] = None,
    ):
        self.model = model
        self.config = config
        self.registry = registry
        self.target_layers = target_layers
        self.covariance_matrices: Dict[str, torch.Tensor] = {}
        self._hook_handles: List[Any] = []

    def __enter__(self) -> "CovarianceCollector":
        for name, module in self.model.named_modules():
            if self.target_layers and name not in self.target_layers:
                continue

            handler = next(
                (h for cls, h in self.registry.items() if isinstance(module, cls)),
                None,
            )
            if handler:
                dim = handler.get_input_dim(module)
                groups = getattr(module, "groups", 1)

                if groups > 1:
                    shape = (groups, dim, dim)
                else:
                    shape = (dim, dim)

                self.covariance_matrices[name] = torch.zeros(
                    shape,
                    device=self.config.storage_device,
                    dtype=self.config.precision,
                )

                def make_hook(layer_name: str, layer_handler: LayerHandler):
                    def hook(mod: nn.Module, inputs: Any) -> None:
                        x = layer_handler.reshape_input(mod, inputs)
                        if isinstance(x, torch.Tensor):
                            x = x.to(self.config.precision)
                            if x.dim() == 3:
                                # Grouped: (G, N, D)
                                cov_chunk = x.transpose(-2, -1) @ x
                            else:
                                # Standard: (N, D)
                                cov_chunk = x.mT @ x
                            self.covariance_matrices[layer_name].add_(
                                cov_chunk.to(self.config.storage_device)
                            )

                    return hook

                handle = module.register_forward_pre_hook(make_hook(name, handler))
                self._hook_handles.append(handle)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        for h in self._hook_handles:
            h.remove()
        self._hook_handles.clear()
        torch.cuda.empty_cache()
