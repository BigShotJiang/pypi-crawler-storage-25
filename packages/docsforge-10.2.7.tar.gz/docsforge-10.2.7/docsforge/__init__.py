"""DocsForge - Unified documentation engine with Material theme.

DocsForge combines the ProperDocs build engine with the Material for MkDocs
theme and plugins into a single, cohesive package.
"""

__version__ = "10.2.7"
__prog_name__ = "docsforge"

# Install vendor compatibility shims
import docsforge._vendor_shims
