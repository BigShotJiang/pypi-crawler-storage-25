"""Tests for microcli package."""
