# Recognizing-Machine
A Machine that recognizes previously encountered meanings.

In order to launch it from command line or as a subprocess:
```bash
  echo "Theodotos-Alexandreus: Do you recognize this pattern, machine?" \
    | uvx recognizing-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... 
```

Or:
```bash
  pip install recognizing-machine
```
Then:
```Python
  # Python
  import recognizing_machine
```
