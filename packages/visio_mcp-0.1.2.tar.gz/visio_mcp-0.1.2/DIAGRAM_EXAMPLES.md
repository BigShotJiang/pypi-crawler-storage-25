# Visio MCP 绘图示例手册

本文档为每种图表类型提供**完整的可执行示例**，包含精确的工具调用参数。所有示例均遵循 `DIAGRAM_STANDARDS.md` 中的绘图标准。

> **使用方法**：每个示例按 5 步执行：`create_diagram` → `get_diagram_standard` → `batch_draw_shapes` → `batch_connect_shapes` → `save_document_as`。

---

## 通用流程模板

```
Step 1: create_diagram("diagram_type_id")
Step 2: get_diagram_standard("diagram_type_id")  ← 获取标准（含示例）
Step 3: batch_draw_shapes(shapes=...) → 返回 ref_map
Step 4: batch_connect_shapes(connections=..., ref_map=...) 
Step 5: save_document_as("output.vsdx")
```

---

## 1. UML 类图 (class_diagram)

**场景**：Animal 继承体系 — Animal (父类) → Dog, Cat (子类) + ISwimmable 接口

**布局**：
```
        [Animal]      [<<interface>>]
           |          [ISwimmable ]
          / \            /
       [Dog]  [Cat]----
```

### Step 1: 创建文档
```
create_diagram("class_diagram")
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "animal", "type": "drop", "master_name": "Class", "stencil_name": "USTRME_M.VSSX", "x": 4.25, "y": 9, "text": "Animal"},
    {"id": "dog", "type": "drop", "master_name": "Class", "stencil_name": "USTRME_M.VSSX", "x": 2.5, "y": 6, "text": "Dog"},
    {"id": "cat", "type": "drop", "master_name": "Class", "stencil_name": "USTRME_M.VSSX", "x": 6, "y": 6, "text": "Cat"},
    {"id": "iswim", "type": "drop", "master_name": "Interface", "stencil_name": "USTRME_M.VSSX", "x": 6, "y": 9, "text": "<<interface>>\nISwimmable"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "dog", "to": "animal", "connector_master": "Inheritance", "connector_stencil": "USTRME_M.VSSX"},
    {"from": "cat", "to": "animal", "connector_master": "Inheritance", "connector_stencil": "USTRME_M.VSSX"},
    {"from": "dog", "to": "iswim", "connector_master": "Interface Realization", "connector_stencil": "USTRME_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- **错误**：使用 AutoConnect 连接类 → 箭头样式错误（无空心三角）
- **正确**：必须使用 `connector_master="Inheritance"` + `connector_stencil="USTRME_M.VSSX"`
- 继承方向：子类 → 父类（箭头指向父类）

---

## 2. UML 序列图 (sequence_diagram)

**场景**：用户登录 — Client → AuthService → Database

**布局**：
```
  [Client]     [AuthService]    [Database]
     |---Message--->|               |
     |              |---Message---->|
     |              |<--Return------|
     |<--Return-----|               |
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "client", "type": "drop", "master_name": "Object lifeline", "stencil_name": "USEQME_M.VSSX", "x": 2, "y": 9, "text": "Client"},
    {"id": "auth", "type": "drop", "master_name": "Object lifeline", "stencil_name": "USEQME_M.VSSX", "x": 4.5, "y": 9, "text": "AuthService"},
    {"id": "db", "type": "drop", "master_name": "Object lifeline", "stencil_name": "USEQME_M.VSSX", "x": 7, "y": 9, "text": "Database"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "client", "to": "auth", "connector_master": "Message", "connector_stencil": "USEQME_M.VSSX"},
    {"from": "auth", "to": "db", "connector_master": "Message", "connector_stencil": "USEQME_M.VSSX"},
    {"from": "db", "to": "auth", "connector_master": "Return Message", "connector_stencil": "USEQME_M.VSSX"},
    {"from": "auth", "to": "client", "connector_master": "Return Message", "connector_stencil": "USEQME_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- **错误**：使用 AutoConnect → 丢失消息类型（同步/异步/返回）的视觉区分
- **正确**：同步用 `Message`，返回用 `Return Message`，异步用 `Asynchronous Message`
- 所有连接器 stencil 为 `USEQME_M.VSSX`

---

## 3. UML 活动图 (activity_diagram)

**场景**：订单处理 — 接收订单 → 检查库存(Decision) → 发货/通知缺货 → 结束

**布局**：
```
      (Initial)
          |
    [Receive Order]
          |
      <In Stock?>
       /       \
  [Ship]    [Notify]
       \       /
      <Merge>
          |
      (Final)
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "start", "type": "drop", "master_name": "Initial node", "stencil_name": "UACTME_M.VSSX", "x": 4.25, "y": 10},
    {"id": "receive", "type": "drop", "master_name": "Action", "stencil_name": "UACTME_M.VSSX", "x": 4.25, "y": 8.5, "text": "Receive Order"},
    {"id": "check", "type": "drop", "master_name": "Decision", "stencil_name": "UACTME_M.VSSX", "x": 4.25, "y": 7, "text": "In Stock?"},
    {"id": "ship", "type": "drop", "master_name": "Action", "stencil_name": "UACTME_M.VSSX", "x": 2.5, "y": 5.5, "text": "Ship Order"},
    {"id": "notify", "type": "drop", "master_name": "Action", "stencil_name": "UACTME_M.VSSX", "x": 6, "y": 5.5, "text": "Notify Out of Stock"},
    {"id": "merge", "type": "drop", "master_name": "Merge Node", "stencil_name": "UACTME_M.VSSX", "x": 4.25, "y": 4},
    {"id": "end", "type": "drop", "master_name": "Final node", "stencil_name": "UACTME_M.VSSX", "x": 4.25, "y": 2.5}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "start", "to": "receive"},
    {"from": "receive", "to": "check"},
    {"from": "check", "to": "ship"},
    {"from": "check", "to": "notify"},
    {"from": "ship", "to": "merge"},
    {"from": "notify", "to": "merge"},
    {"from": "merge", "to": "end"}
], ref_map=<from step 3>)
```

### 常见错误
- Decision 和 Merge Node 都是菱形，语义不同但 master 名称不同
- 活动图使用 AutoConnect（不传 connector_master）

---

## 4. UML 状态机图 (state_machine_diagram)

**场景**：订单状态 — New → Confirmed → Shipped → Delivered，含取消分支

**布局**：
```
    (Initial)
        |
     [New]-------->[Cancelled]
        |                |
   [Confirmed]          |
        |                |
    [Shipped]           |
        |                |
   [Delivered]          |
        \              /
        (Final)-------
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "init", "type": "drop", "master_name": "Initial state", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 10},
    {"id": "new", "type": "drop", "master_name": "State", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 8.5, "text": "New"},
    {"id": "confirmed", "type": "drop", "master_name": "State", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 7, "text": "Confirmed"},
    {"id": "shipped", "type": "drop", "master_name": "State", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 5.5, "text": "Shipped"},
    {"id": "delivered", "type": "drop", "master_name": "State", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 4, "text": "Delivered"},
    {"id": "cancelled", "type": "drop", "master_name": "State", "stencil_name": "USTAME_M.VSSX", "x": 7, "y": 7, "text": "Cancelled"},
    {"id": "final", "type": "drop", "master_name": "Final state", "stencil_name": "USTAME_M.VSSX", "x": 4.25, "y": 2.5}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "init", "to": "new"},
    {"from": "new", "to": "confirmed"},
    {"from": "confirmed", "to": "shipped"},
    {"from": "shipped", "to": "delivered"},
    {"from": "delivered", "to": "final"},
    {"from": "new", "to": "cancelled"},
    {"from": "cancelled", "to": "final"}
], ref_map=<from step 3>)
```

### 常见错误
- 状态机图使用 AutoConnect
- 转换条件通过连接后的 `set_shape_text` 在连接器上标注

---

## 5. UML 用例图 (use_case_diagram)

**场景**：在线商店 — Customer 和 Admin 参与者，含 Include 关系

**布局**：
```
  [Customer]    (Browse)     [Admin]
      |         (Order)        |
      |         (Pay)          |
      +------>(Manage Products)
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "customer", "type": "drop", "master_name": "Actor", "stencil_name": "UUSEME_M.VSSX", "x": 1, "y": 7, "text": "Customer"},
    {"id": "admin", "type": "drop", "master_name": "Actor", "stencil_name": "UUSEME_M.VSSX", "x": 7.5, "y": 7, "text": "Admin"},
    {"id": "browse", "type": "drop", "master_name": "Use Case", "stencil_name": "UUSEME_M.VSSX", "x": 4.25, "y": 9, "text": "Browse Products"},
    {"id": "order", "type": "drop", "master_name": "Use Case", "stencil_name": "UUSEME_M.VSSX", "x": 4.25, "y": 7, "text": "Place Order"},
    {"id": "pay", "type": "drop", "master_name": "Use Case", "stencil_name": "UUSEME_M.VSSX", "x": 4.25, "y": 5, "text": "Make Payment"},
    {"id": "manage", "type": "drop", "master_name": "Use Case", "stencil_name": "UUSEME_M.VSSX", "x": 4.25, "y": 3, "text": "Manage Products"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "customer", "to": "browse", "connector_master": "Association", "connector_stencil": "UUSEME_M.VSSX"},
    {"from": "customer", "to": "order", "connector_master": "Association", "connector_stencil": "UUSEME_M.VSSX"},
    {"from": "order", "to": "pay", "connector_master": "Include", "connector_stencil": "UUSEME_M.VSSX"},
    {"from": "admin", "to": "manage", "connector_master": "Association", "connector_stencil": "UUSEME_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- Association 用于参与者与用例之间的关联
- Include/Extend 用于用例之间的关系
- 所有连接器使用 `connector_stencil="UUSEME_M.VSSX"`

---

## 6. UML 组件图 (component_diagram)

**场景**：三层架构 — WebUI → API Server → Database

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "ui", "type": "drop", "master_name": "Component", "stencil_name": "UCOMME_M.VSSX", "x": 4.25, "y": 9, "text": "WebUI"},
    {"id": "api", "type": "drop", "master_name": "Component", "stencil_name": "UCOMME_M.VSSX", "x": 4.25, "y": 6.5, "text": "API Server"},
    {"id": "db", "type": "drop", "master_name": "Component", "stencil_name": "UCOMME_M.VSSX", "x": 4.25, "y": 4, "text": "Database"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "ui", "to": "api", "connector_master": "Dependency", "connector_stencil": "UCOMME_M.VSSX"},
    {"from": "api", "to": "db", "connector_master": "Dependency", "connector_stencil": "UCOMME_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- 组件图使用 stencil 连接器（Dependency, Association 等）
- Provided/Required Interface 需放在组件边缘

---

## 7. UML 部署图 (deployment_diagram)

**场景**：Web 应用部署 — Web Server → App Server → DB Server

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "web", "type": "drop", "master_name": "Node", "stencil_name": "UDEPME_M.VSSX", "x": 2, "y": 8, "text": "<<device>>\nWeb Server"},
    {"id": "app", "type": "drop", "master_name": "Node", "stencil_name": "UDEPME_M.VSSX", "x": 4.25, "y": 5.5, "text": "<<device>>\nApp Server"},
    {"id": "dbsrv", "type": "drop", "master_name": "Node", "stencil_name": "UDEPME_M.VSSX", "x": 6.5, "y": 3, "text": "<<device>>\nDB Server"},
    {"id": "war", "type": "drop", "master_name": "Artifact", "stencil_name": "UDEPME_M.VSSX", "x": 4.25, "y": 4, "text": "app.war"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "web", "to": "app", "connector_master": "Association", "connector_stencil": "UDEPME_M.VSSX"},
    {"from": "app", "to": "dbsrv", "connector_master": "Association", "connector_stencil": "UDEPME_M.VSSX"},
    {"from": "war", "to": "app", "connector_master": "Deploy", "connector_stencil": "UDEPME_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- Association 表示通信路径，Deploy 表示部署关系
- 所有连接器使用 `connector_stencil="UDEPME_M.VSSX"`

---

## 8. 基本流程图 (flowchart)

**场景**：审批流程 — Start → 提交 → 审核 → Decision → 批准/驳回 → End

**布局**：
```
      [Start]
         |
   [Submit Request]
         |
   [Review Request]
         |
     <Approved?>
      /       \
 [Process]  [Reject]
      \       /
       [End]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "start", "type": "drop", "master_name": "Start/End", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 10, "text": "Start"},
    {"id": "submit", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 8.5, "text": "Submit Request"},
    {"id": "review", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 7, "text": "Review Request"},
    {"id": "decide", "type": "drop", "master_name": "Decision", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 5.5, "text": "Approved?"},
    {"id": "approve", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 2.5, "y": 4, "text": "Process Approval"},
    {"id": "reject", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 6, "y": 4, "text": "Send Rejection"},
    {"id": "end", "type": "drop", "master_name": "Start/End", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 2, "text": "End"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "start", "to": "submit"},
    {"from": "submit", "to": "review"},
    {"from": "review", "to": "decide"},
    {"from": "decide", "to": "approve"},
    {"from": "decide", "to": "reject"},
    {"from": "approve", "to": "end"},
    {"from": "reject", "to": "end"}
], ref_map=<from step 3>)
```

### 常见错误
- Start 和 End 使用同一个 master `Start/End`，通过文本区分
- 流程图使用 AutoConnect（不传 connector_master/connector_stencil）

---

## 9. 跨职能流程图 (cross_functional_flowchart)

**场景**：采购流程跨 Requester / Manager / Finance 泳道

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "start", "type": "drop", "master_name": "Start/End", "stencil_name": "BASFLO_M.VSSX", "x": 2, "y": 9, "text": "Start"},
    {"id": "request", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 2, "y": 7.5, "text": "Create PO"},
    {"id": "approve", "type": "drop", "master_name": "Decision", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 7.5, "text": "Approve?"},
    {"id": "pay", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 6.5, "y": 7.5, "text": "Process Payment"},
    {"id": "revise", "type": "drop", "master_name": "Process", "stencil_name": "BASFLO_M.VSSX", "x": 4.25, "y": 5.5, "text": "Revise PO"},
    {"id": "end", "type": "drop", "master_name": "Start/End", "stencil_name": "BASFLO_M.VSSX", "x": 6.5, "y": 5.5, "text": "End"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "start", "to": "request"},
    {"from": "request", "to": "approve"},
    {"from": "approve", "to": "pay"},
    {"from": "approve", "to": "revise"},
    {"from": "revise", "to": "approve"},
    {"from": "pay", "to": "end"}
], ref_map=<from step 3>)
```

### 常见错误
- 泳道容器需要先使用 CFF Container (XFUNC_M.VSSX) 创建
- 流程形状使用 BASFLO_M.VSSX，不是 XFUNC_M.VSSX
- 泳道内的形状通过坐标定位到各自泳道区域

---

## 10. BPMN 流程图 (bpmn)

**场景**：订单履行 — Start Event → Receive Order → Gateway → Ship/Reorder → End Event

**布局**（从左到右）：
```
  (Start)→[Receive]→<GW>→[Ship]→<GW2>→(End)
                        ↘[Reorder]↗
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "start", "type": "drop", "master_name": "Start Event", "stencil_name": "BPMN_M.VSSX", "x": 1, "y": 5.5},
    {"id": "receive", "type": "drop", "master_name": "Task", "stencil_name": "BPMN_M.VSSX", "x": 2.5, "y": 5.5, "text": "Receive Order"},
    {"id": "gw", "type": "drop", "master_name": "Gateway", "stencil_name": "BPMN_M.VSSX", "x": 4.25, "y": 5.5},
    {"id": "ship", "type": "drop", "master_name": "Task", "stencil_name": "BPMN_M.VSSX", "x": 6, "y": 7, "text": "Ship Order"},
    {"id": "reorder", "type": "drop", "master_name": "Task", "stencil_name": "BPMN_M.VSSX", "x": 6, "y": 4, "text": "Reorder Stock"},
    {"id": "gw2", "type": "drop", "master_name": "Gateway", "stencil_name": "BPMN_M.VSSX", "x": 7.5, "y": 5.5},
    {"id": "end", "type": "drop", "master_name": "End Event", "stencil_name": "BPMN_M.VSSX", "x": 9, "y": 5.5}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "start", "to": "receive", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "receive", "to": "gw", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "gw", "to": "ship", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "gw", "to": "reorder", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "ship", "to": "gw2", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "reorder", "to": "gw2", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"},
    {"from": "gw2", "to": "end", "connector_master": "Sequence Flow", "connector_stencil": "BPMN_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- **必须**使用 `Sequence Flow` 连接器（同一池内），不能用 AutoConnect
- 跨池通信使用 `Message Flow`
- Message Flow **不能**在同一池内使用

---

## 11. ER 图 — Crow's Foot 记法 (erd_crows_foot)

**场景**：电商数据库 — Users → Orders → Products

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "users", "type": "drop", "master_name": "Entity", "stencil_name": "DBCROW_M.VSSX", "x": 2, "y": 7, "text": "Users"},
    {"id": "orders", "type": "drop", "master_name": "Entity", "stencil_name": "DBCROW_M.VSSX", "x": 4.25, "y": 7, "text": "Orders"},
    {"id": "products", "type": "drop", "master_name": "Entity", "stencil_name": "DBCROW_M.VSSX", "x": 6.5, "y": 7, "text": "Products"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "users", "to": "orders", "connector_master": "Relationship", "connector_stencil": "DBCROW_M.VSSX"},
    {"from": "orders", "to": "products", "connector_master": "Relationship", "connector_stencil": "DBCROW_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- 使用 `Relationship` 连接器，线端自带 Crow's Foot 基数标记
- 可使用 `Entity With Attributes` 替代 `Entity` 来显示字段

---

## 12. ER 图 — Chen 记法 (erd_chen)

**场景**：学生选课 — Student 和 Course 实体，Enrolls 关系

**布局**：
```
  [StudentID] [Name]       [CourseID] [Title]
       \       /                \       /
      [Student]---<Enrolls>---[Course]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "student", "type": "drop", "master_name": "Entity", "stencil_name": "DBCHEN_M.VSSX", "x": 2, "y": 5.5, "text": "Student"},
    {"id": "course", "type": "drop", "master_name": "Entity", "stencil_name": "DBCHEN_M.VSSX", "x": 7, "y": 5.5, "text": "Course"},
    {"id": "enrolls", "type": "drop", "master_name": "Relationship", "stencil_name": "DBCHEN_M.VSSX", "x": 4.5, "y": 5.5, "text": "Enrolls"},
    {"id": "sid", "type": "drop", "master_name": "Primary Key attribute ", "stencil_name": "DBCHEN_M.VSSX", "x": 1, "y": 7.5, "text": "StudentID"},
    {"id": "sname", "type": "drop", "master_name": "Attribute", "stencil_name": "DBCHEN_M.VSSX", "x": 3, "y": 7.5, "text": "Name"},
    {"id": "cid", "type": "drop", "master_name": "Primary Key attribute ", "stencil_name": "DBCHEN_M.VSSX", "x": 6, "y": 7.5, "text": "CourseID"},
    {"id": "ctitle", "type": "drop", "master_name": "Attribute", "stencil_name": "DBCHEN_M.VSSX", "x": 8, "y": 7.5, "text": "Title"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "student", "to": "enrolls", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"},
    {"from": "enrolls", "to": "course", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"},
    {"from": "student", "to": "sid", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"},
    {"from": "student", "to": "sname", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"},
    {"from": "course", "to": "cid", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"},
    {"from": "course", "to": "ctitle", "connector_master": "Relationship Connector", "connector_stencil": "DBCHEN_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- **尾部空格警告**：以下 master 名称末尾有空格，必须包含：
  - `"Primary Key attribute "` (注意末尾空格)
  - `"Associative Entity "` (注意末尾空格)
  - `"Multi-valued Attribute "` (注意末尾空格)
- 使用 `Relationship Connector` 连接线连接所有元素

---

## 13. 网络拓扑图 (network_diagram)

**场景**：办公网络 — Internet → Firewall → Switch → Servers / PC

**布局**：
```
        [Cloud: Internet]
              |
          [Firewall]
              |
         [Core Switch]
          /    |    \
   [Web Srv] [DB Srv] [PC]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "cloud", "type": "drop", "master_name": "Cloud", "stencil_name": "NETLOC_M.VSSX", "x": 4.25, "y": 9.5, "text": "Internet"},
    {"id": "fw", "type": "drop", "master_name": "Firewall", "stencil_name": "PERIPH_M.VSSX", "x": 4.25, "y": 7.5, "text": "Firewall"},
    {"id": "sw", "type": "drop", "master_name": "Switch", "stencil_name": "PERIPH_M.VSSX", "x": 4.25, "y": 5.5, "text": "Core Switch"},
    {"id": "srv1", "type": "drop", "master_name": "Server", "stencil_name": "PERIPH_M.VSSX", "x": 2, "y": 3.5, "text": "Web Server"},
    {"id": "srv2", "type": "drop", "master_name": "Server", "stencil_name": "PERIPH_M.VSSX", "x": 4.25, "y": 3.5, "text": "DB Server"},
    {"id": "pc", "type": "drop", "master_name": "User", "stencil_name": "PERIPH_M.VSSX", "x": 6.5, "y": 3.5, "text": "Workstation"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "cloud", "to": "fw"},
    {"from": "fw", "to": "sw"},
    {"from": "sw", "to": "srv1"},
    {"from": "sw", "to": "srv2"},
    {"from": "sw", "to": "pc"}
], ref_map=<from step 3>)
```

### 常见错误
- Cloud 来自 `NETLOC_M.VSSX`，其他设备来自 `PERIPH_M.VSSX` — 注意指定正确的 stencil
- 网络图使用 AutoConnect

---

## 14. Azure 架构图 (azure_architecture)

**场景**：Azure Web 应用 — Front Door → App Service → SQL Database + Blob Storage

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "fd", "type": "drop", "master_name": "Front Doors", "stencil_name": "AZURENETWORKING_M.VSSX", "x": 4.25, "y": 9, "text": "Front Door"},
    {"id": "app", "type": "drop", "master_name": "App Services", "stencil_name": "AZURECOMPUTE_M.VSSX", "x": 4.25, "y": 7, "text": "App Service"},
    {"id": "sql", "type": "drop", "master_name": "SQL Databases", "stencil_name": "AZUREDATABASES_M.VSSX", "x": 4.25, "y": 5, "text": "SQL Database"},
    {"id": "blob", "type": "drop", "master_name": "Blob Storage", "stencil_name": "AZURESTORAGE_M.VSSX", "x": 6.5, "y": 7, "text": "Blob Storage"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "fd", "to": "app"},
    {"from": "app", "to": "sql"},
    {"from": "app", "to": "blob"}
], ref_map=<from step 3>)
```

### 常见错误
- Azure 图标分布在多个 stencil 中（AZURECOMPUTE, AZURENETWORKING, AZURESTORAGE 等）
- Master 名称使用 `list_masters("AZURECOMPUTE_M.VSSX")` 确认

---

## 15. AWS 架构图 (aws_architecture)

**场景**：AWS Serverless — API Gateway → Lambda → DynamoDB + S3

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "apigw", "type": "drop", "master_name": "Amazon API Gateway", "stencil_name": "AWSNETCONTENTDELIVERY_M.VSSX", "x": 4.25, "y": 9, "text": "API Gateway"},
    {"id": "lambda", "type": "drop", "master_name": "AWS Lambda", "stencil_name": "AWSCOMPUTE_M.VSSX", "x": 4.25, "y": 7, "text": "Lambda"},
    {"id": "dynamo", "type": "drop", "master_name": "Amazon DynamoDB", "stencil_name": "AWSDB_M.VSSX", "x": 2.5, "y": 5, "text": "DynamoDB"},
    {"id": "s3", "type": "drop", "master_name": "Bucket", "stencil_name": "AWSSTORAGE_M.VSSX", "x": 6, "y": 5, "text": "S3 Bucket"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "apigw", "to": "lambda"},
    {"from": "lambda", "to": "dynamo"},
    {"from": "lambda", "to": "s3"}
], ref_map=<from step 3>)
```

### 常见错误
- AWS master 名称通常以 `Amazon` 或 `AWS` 前缀开头
- S3 Bucket 的 master 名称是 `Bucket`（在 AWSSTORAGE_M.VSSX 中）
- 使用 `list_masters()` 确认可用名称

---

## 16. Kubernetes 架构图 (kubernetes)

**场景**：K8s 应用部署 — Ingress → Service → Deployment → Pod (x2) + ConfigMap

**布局**：
```
     [Ingress]
         |
     [Service]
         |
    [Deployment]---[ConfigMap]
      /       \
  [Pod-1]   [Pod-2]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "ing", "type": "drop", "master_name": "ing", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 4.25, "y": 9, "text": "Ingress"},
    {"id": "svc", "type": "drop", "master_name": "svc", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 4.25, "y": 7, "text": "Service"},
    {"id": "deploy", "type": "drop", "master_name": "deploy", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 4.25, "y": 5, "text": "Deployment"},
    {"id": "pod1", "type": "drop", "master_name": "pod", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 2.5, "y": 3, "text": "Pod-1"},
    {"id": "pod2", "type": "drop", "master_name": "pod", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 6, "y": 3, "text": "Pod-2"},
    {"id": "cm", "type": "drop", "master_name": "cm", "stencil_name": "KUBERNETESVISIOSTENCIL_M.VSSX", "x": 7, "y": 5, "text": "ConfigMap"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "ing", "to": "svc"},
    {"from": "svc", "to": "deploy"},
    {"from": "deploy", "to": "pod1"},
    {"from": "deploy", "to": "pod2"},
    {"from": "cm", "to": "deploy"}
], ref_map=<from step 3>)
```

### 常见错误
- K8s master 名称是**小写缩写**（pod, deploy, svc, ing, cm, secret 等）
- 与 kubectl 缩写一致
- 所有形状都在 `KUBERNETESVISIOSTENCIL_M.VSSX` 中

---

## 17. 组织结构图 (org_chart)

**场景**：公司结构 — CEO → VP Engineering / VP Sales → Managers → Staff

**布局**：
```
           [CEO]
          /      \
    [VP Eng]    [VP Sales]
     /    \         |
  [Dev]  [QA]   [Sales]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "ceo", "type": "drop", "master_name": "Executive", "stencil_name": "ORGCH_M.VSSX", "x": 4.25, "y": 9.5, "text": "CEO\nJohn Smith"},
    {"id": "vpe", "type": "drop", "master_name": "Manager", "stencil_name": "ORGCH_M.VSSX", "x": 2.5, "y": 7.5, "text": "VP Engineering\nJane Doe"},
    {"id": "vps", "type": "drop", "master_name": "Manager", "stencil_name": "ORGCH_M.VSSX", "x": 6, "y": 7.5, "text": "VP Sales\nBob Lee"},
    {"id": "dev1", "type": "drop", "master_name": "Position", "stencil_name": "ORGCH_M.VSSX", "x": 1.5, "y": 5.5, "text": "Dev Manager\nAlice"},
    {"id": "dev2", "type": "drop", "master_name": "Position", "stencil_name": "ORGCH_M.VSSX", "x": 3.5, "y": 5.5, "text": "QA Manager\nCharlie"},
    {"id": "sales1", "type": "drop", "master_name": "Position", "stencil_name": "ORGCH_M.VSSX", "x": 6, "y": 5.5, "text": "Sales Rep\nDave"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "ceo", "to": "vpe"},
    {"from": "ceo", "to": "vps"},
    {"from": "vpe", "to": "dev1"},
    {"from": "vpe", "to": "dev2"},
    {"from": "vps", "to": "sales1"}
], ref_map=<from step 3>)
```

### 常见错误
- Executive 用于最高层，Manager 用于中层，Position 用于普通岗位
- 虚线汇报用 `Dotted-line report` 连接器

---

## 18. 数据流图 (data_flow_diagram)

**场景**：客户订单系统 (Level 0) — Customer → Process Order → Inventory + Supplier

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "customer", "type": "drop", "master_name": "External interactor", "stencil_name": "DATFLO_M.VSSX", "x": 1.5, "y": 7, "text": "Customer"},
    {"id": "process", "type": "drop", "master_name": "Data process", "stencil_name": "DATFLO_M.VSSX", "x": 4.25, "y": 7, "text": "1.0\nProcess Order"},
    {"id": "store", "type": "drop", "master_name": "Data store", "stencil_name": "DATFLO_M.VSSX", "x": 7, "y": 7, "text": "D1 Inventory"},
    {"id": "supplier", "type": "drop", "master_name": "External interactor", "stencil_name": "DATFLO_M.VSSX", "x": 4.25, "y": 4, "text": "Supplier"}
])
```

### Step 4: 连接形状
```json
batch_connect_shapes(connections=[
    {"from": "customer", "to": "process", "connector_master": "Center to center 1", "connector_stencil": "DATFLO_M.VSSX"},
    {"from": "process", "to": "store", "connector_master": "Center to center 1", "connector_stencil": "DATFLO_M.VSSX"},
    {"from": "process", "to": "supplier", "connector_master": "Center to center 1", "connector_stencil": "DATFLO_M.VSSX"}
], ref_map=<from step 3>)
```

### 常见错误
- 推荐使用 `Center to center 1` 连接器（带箭头）
- External interactor 放在图表边缘

---

## 19. 因果图 / 鱼骨图 (cause_and_effect)

**场景**：制造缺陷分析 — Effect + Man/Machine 分类 + Primary/Secondary causes

**布局**（从右到左）：
```
  [No Manual]
      \
  [Lack Training]
       \
    [Man]--------\
                  \
                [Effect: Product Defect]
                  /
    [Machine]----/
       /
  [Worn Parts]
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "effect", "type": "drop", "master_name": "Effect", "stencil_name": "CAUSEF_M.VSSX", "x": 7, "y": 5.5, "text": "Product Defect"},
    {"id": "cat1", "type": "drop", "master_name": "Category 1", "stencil_name": "CAUSEF_M.VSSX", "x": 3, "y": 8, "text": "Man"},
    {"id": "cat2", "type": "drop", "master_name": "Category 2", "stencil_name": "CAUSEF_M.VSSX", "x": 3, "y": 3, "text": "Machine"},
    {"id": "p1", "type": "drop", "master_name": "Primary cause 1", "stencil_name": "CAUSEF_M.VSSX", "x": 2, "y": 9, "text": "Lack of Training"},
    {"id": "p2", "type": "drop", "master_name": "Primary cause 1", "stencil_name": "CAUSEF_M.VSSX", "x": 2, "y": 2, "text": "Worn Parts"},
    {"id": "s1", "type": "drop", "master_name": "Secondary cause 1", "stencil_name": "CAUSEF_M.VSSX", "x": 1, "y": 9.5, "text": "No Manual"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "cat1", "to": "effect"},
    {"from": "cat2", "to": "effect"},
    {"from": "p1", "to": "cat1"},
    {"from": "p2", "to": "cat2"},
    {"from": "s1", "to": "p1"}
], ref_map=<from step 3>)
```

### 可用 Master 名称
`Effect`, `Category 1`, `Category 2`, `Fish frame`, `Primary cause 1`, `Primary cause 2`, `Secondary cause 1` ~ `Secondary cause 6`

---

## 20. 值流图 (value_stream_mapping)

**场景**：简单生产线 — Supplier → Stamping → Inventory → Assembly → Customer

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "supplier", "type": "drop", "master_name": "Customer/Supplier", "stencil_name": "VSM_M.VSSX", "x": 1, "y": 8, "text": "Supplier"},
    {"id": "proc1", "type": "drop", "master_name": "Process", "stencil_name": "VSM_M.VSSX", "x": 3.5, "y": 5.5, "text": "Stamping\nCT=10s"},
    {"id": "inv1", "type": "drop", "master_name": "Inventory", "stencil_name": "VSM_M.VSSX", "x": 5.5, "y": 5.5, "text": "500 pcs"},
    {"id": "proc2", "type": "drop", "master_name": "Process", "stencil_name": "VSM_M.VSSX", "x": 7.5, "y": 5.5, "text": "Assembly\nCT=30s"},
    {"id": "customer", "type": "drop", "master_name": "Customer/Supplier", "stencil_name": "VSM_M.VSSX", "x": 9.5, "y": 8, "text": "Customer"},
    {"id": "ctrl", "type": "drop", "master_name": "Production control", "stencil_name": "VSM_M.VSSX", "x": 5, "y": 9.5, "text": "Production\nControl"},
    {"id": "tl1", "type": "drop", "master_name": "Timeline segment", "stencil_name": "VSM_M.VSSX", "x": 3.5, "y": 2, "text": "5 days"},
    {"id": "tl2", "type": "drop", "master_name": "Timeline segment", "stencil_name": "VSM_M.VSSX", "x": 7.5, "y": 2, "text": "2 days"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "supplier", "to": "proc1"},
    {"from": "proc1", "to": "inv1"},
    {"from": "inv1", "to": "proc2"},
    {"from": "proc2", "to": "customer"}
], ref_map=<from step 3>)
```

### 可用 Master 名称
`Customer/Supplier`, `Process`, `Inventory`, `Push arrow`, `Shipment arrow`, `Shipment truck`, `Production control`, `Manual information`, `Electronic information`, `Data table`, `Timeline segment`, `Timeline total`, `Production kanban`, `Withdrawal kanban`, `Supermarket`, `FIFO lane`, `Kaizen burst`, `Load leveling`

---

## 21. 事件驱动过程链 EPC (epc)

**场景**：采购申请 — Event/Function 交替 + XOR 分支

**布局**：
```
  (Purchase Required)
         |
  [Create Requisition]
         |
  (Requisition Created)
         |
  [Approve Requisition]---[Purchasing Dept]
         |
       (XOR)
      /     \
 (Approved) (Rejected)
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "e1", "type": "drop", "master_name": "Event", "stencil_name": "EPC_M.VSSX", "x": 4.25, "y": 10, "text": "Purchase\nRequired"},
    {"id": "f1", "type": "drop", "master_name": "Function", "stencil_name": "EPC_M.VSSX", "x": 4.25, "y": 8.5, "text": "Create Purchase\nRequisition"},
    {"id": "e2", "type": "drop", "master_name": "Event", "stencil_name": "EPC_M.VSSX", "x": 4.25, "y": 7, "text": "Requisition\nCreated"},
    {"id": "f2", "type": "drop", "master_name": "Function", "stencil_name": "EPC_M.VSSX", "x": 4.25, "y": 5.5, "text": "Approve\nRequisition"},
    {"id": "xor", "type": "drop", "master_name": "XOR", "stencil_name": "EPC_M.VSSX", "x": 4.25, "y": 4},
    {"id": "e3", "type": "drop", "master_name": "Event", "stencil_name": "EPC_M.VSSX", "x": 2.5, "y": 2.5, "text": "Approved"},
    {"id": "e4", "type": "drop", "master_name": "Event", "stencil_name": "EPC_M.VSSX", "x": 6, "y": 2.5, "text": "Rejected"},
    {"id": "org", "type": "drop", "master_name": "Organizational unit", "stencil_name": "EPC_M.VSSX", "x": 7, "y": 5.5, "text": "Purchasing\nDept"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "e1", "to": "f1"},
    {"from": "f1", "to": "e2"},
    {"from": "e2", "to": "f2"},
    {"from": "f2", "to": "xor"},
    {"from": "xor", "to": "e3"},
    {"from": "xor", "to": "e4"},
    {"from": "org", "to": "f2"}
], ref_map=<from step 3>)
```

### 可用 Master 名称
`Event`, `Function`, `Process path`, `Organizational unit`, `XOR`, `OR`, `AND`, `Information/ Material`, `Main process`, `Component`, `Enterprise area`, `Process group`

### 常见错误
- EPC 核心规则：Event 和 Function **必须交替排列**
- 逻辑操作符（XOR/OR/AND）用于分支/合并点

---

## 22. 块图 (block_diagram)

**场景**：系统架构 — Client → Load Balancer → App Server (x2) → Database

**布局**：
```
  [Client]---<LB>---[App 1]---[Database]
                  \--[App 2]--/
```

### Step 3: 绘制形状
```json
batch_draw_shapes(shapes=[
    {"id": "client", "type": "drop", "master_name": "Box", "stencil_name": "BLOCK_M.VSSX", "x": 1.5, "y": 7, "text": "Client"},
    {"id": "lb", "type": "drop", "master_name": "Diamond", "stencil_name": "BLOCK_M.VSSX", "x": 4.25, "y": 7, "text": "Load\nBalancer"},
    {"id": "app1", "type": "drop", "master_name": "Box", "stencil_name": "BLOCK_M.VSSX", "x": 6.5, "y": 8.5, "text": "App Server 1"},
    {"id": "app2", "type": "drop", "master_name": "Box", "stencil_name": "BLOCK_M.VSSX", "x": 6.5, "y": 5.5, "text": "App Server 2"},
    {"id": "db", "type": "drop", "master_name": "3-D box", "stencil_name": "BLOCK_M.VSSX", "x": 9, "y": 7, "text": "Database"}
])
```

### Step 4: 连接形状（AutoConnect）
```json
batch_connect_shapes(connections=[
    {"from": "client", "to": "lb"},
    {"from": "lb", "to": "app1"},
    {"from": "lb", "to": "app2"},
    {"from": "app1", "to": "db"},
    {"from": "app2", "to": "db"}
], ref_map=<from step 3>)
```

### 常见错误
- 块图形状选择灵活（Box, Diamond, Circle, 3-D box 等）
- 可使用 BLOCK_M.VSSX 内的特殊连接器（如 1-D single, 2-D double 等）替代 AutoConnect

---

## 附录：连接方式速查表

| 图表类型 | 连接方式 | 说明 |
|---------|---------|------|
| class_diagram | **Stencil** (USTRME_M.VSSX) | Inheritance, Composition, Aggregation 等 |
| sequence_diagram | **Stencil** (USEQME_M.VSSX) | Message, Return Message 等 |
| activity_diagram | AutoConnect | 不传 connector_master |
| state_machine_diagram | AutoConnect | 不传 connector_master |
| use_case_diagram | **Stencil** (UUSEME_M.VSSX) | Association, Include, Extend 等 |
| component_diagram | **Stencil** (UCOMME_M.VSSX) | Dependency, Association 等 |
| deployment_diagram | **Stencil** (UDEPME_M.VSSX) | Association, Deploy 等 |
| flowchart | AutoConnect | 不传 connector_master |
| cross_functional_flowchart | AutoConnect | 不传 connector_master |
| bpmn | **Stencil** (BPMN_M.VSSX) | Sequence Flow, Message Flow |
| erd_crows_foot | **Stencil** (DBCROW_M.VSSX) | Relationship |
| erd_chen | **Stencil** (DBCHEN_M.VSSX) | Relationship Connector |
| network_diagram | AutoConnect | 不传 connector_master |
| azure_architecture | AutoConnect | 不传 connector_master |
| aws_architecture | AutoConnect | 不传 connector_master |
| kubernetes | AutoConnect | 不传 connector_master |
| org_chart | AutoConnect | 或 Dynamic connector (ORGCH_M.VSSX) |
| data_flow_diagram | **Stencil** (DATFLO_M.VSSX) | Center to center 1 |
| cause_and_effect | AutoConnect | 不传 connector_master |
| value_stream_mapping | AutoConnect | 不传 connector_master |
| epc | AutoConnect | 不传 connector_master |
| block_diagram | AutoConnect | 或 BLOCK_M.VSSX 内连接器 |
