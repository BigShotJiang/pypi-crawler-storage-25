# Visio MCP Server

通过 MCP (Model Context Protocol) 将 Visio COM 自动化接口暴露给 Claude。

## 运行方式

MCP server 通过 stdio 传输协议运行，由 Claude Code 自动管理生命周期。

## 项目结构

- `visio_server.py` — MCP Server 入口 (FastMCP + tool 定义)
- `visio_app.py` — Visio COM 封装层 (VisioApp 单例类)
- `diagram_standards.py` — 绘图标准数据 (22 种图表类型的模板/形状/边/布局/示例)
- `DIAGRAM_EXAMPLES.md` — 22 种图表类型的完整绘图示例手册
- `.mcp.json` — Claude Code MCP 配置

## 前置要求

- Windows + Microsoft Visio 已安装
- Python 3.10+ (由 uv 管理)
- 依赖: `mcp[cli]`, `pywin32`

## 坐标系统

Visio 使用英寸为单位，原点在页面左下角。
- x 向右增大
- y 向上增大
- 默认页面大小约 8.5 x 11 英寸 (Letter)

## 绘图标准（强制要求）

绘制任何图表时**必须**遵循以下流程：

1. **调用 `create_diagram(diagram_type)`** 创建文档 — 这会自动使用对应的 Visio 模板（.vstx），预加载正确的 stencil 和页面设置。返回值中**自动包含完整的绘图标准**（shapes、edges、layout、example），必须按照标准中的 master 名称和 stencil 绘制。**禁止**使用 `create_document("")` 空白文档绘制标准图表。
2. **严格使用标准中规定的 Master 名称和 Stencil** 进行绘制。不得自行猜测 master 名称，不得用 `draw_rectangle`/`draw_oval` 等原始绘图方法代替 stencil 形状。
3. **连接器必须使用标准中规定的 connector_master 和 connector_stencil**。`batch_connect_shapes` 支持在每个连接对象中指定 `connector_master` 和 `connector_stencil`。不使用 stencil 连接器（仅用 AutoConnect）会导致箭头样式错误（如 UML 继承缺少空心三角箭头）。

如需查看完整标准详情，可额外调用 `get_diagram_standard(diagram_type)`。

支持的 22 种图表类型可通过 `list_diagram_types()` 查询。

详细标准文档见 `DIAGRAM_STANDARDS.md`。

每种图表类型均附带**完整可执行示例**（含 `batch_draw_shapes` / `batch_connect_shapes` 的精确参数），可通过 `get_diagram_standard(diagram_type)` 的返回值中的 `example` 字段获取。人类可读的示例手册见 `DIAGRAM_EXAMPLES.md`。

## 常用 Stencil

- `BASIC_M.vssx` — 基本形状 (矩形、圆形、三角形等)
- `BLOCK_M.vssx` — 块图
- `CONNEC_M.vssx` — 连接器
- `FLOWM_M.vssx` — 流程图形状

完整 Stencil 列表及各图表类型对应关系见 `DIAGRAM_STANDARDS.md` 附录 A。

## 调试

如果 MCP server 无法启动:
1. 确认 Visio 已安装且可以正常打开
2. 运行 `uv run python visio_server.py` 查看错误输出
3. 确认 pywin32 安装正确: `uv run python -c "import win32com.client; print('OK')"`
