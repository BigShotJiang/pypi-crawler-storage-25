"""Visio MCP Server — exposes Visio COM automation as MCP tools."""
