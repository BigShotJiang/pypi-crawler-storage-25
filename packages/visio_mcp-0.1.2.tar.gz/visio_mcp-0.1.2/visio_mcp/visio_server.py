"""Visio MCP Server — exposes Visio COM automation as MCP tools."""

import sys
import json
import logging
import traceback

from mcp.server.fastmcp import FastMCP

from visio_mcp.visio_app import VisioApp
from visio_mcp.diagram_standards import STANDARDS, list_types, get_standard

# Logging to stderr (stdout is reserved for MCP stdio transport)
logging.basicConfig(stream=sys.stderr, level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("visio")
visio = VisioApp()


def _ok(result) -> str:
    """Serialize result to JSON string."""
    return json.dumps(result, ensure_ascii=False, indent=2)


def _err(e: Exception) -> str:
    """Format error for tool response."""
    tb = traceback.format_exc()
    logger.error(tb)
    return json.dumps({"error": str(e)}, ensure_ascii=False)


# ═══════════════════════════════════════════════════════════════════
# Document Management
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def create_document(template: str = "") -> str:
    """Create a new blank Visio document.

    WARNING: Do NOT use this for standard diagram types (flowchart, UML, BPMN, ERD,
    network, etc.). Use create_diagram(diagram_type) instead — it loads the correct
    template with pre-configured stencils and page settings.

    Only use create_document() for free-form drawings that don't match any standard type.

    Args:
        template: Optional template file path or name. Empty for blank document.
    """
    try:
        return _ok(visio.create_document(template))
    except Exception as e:
        return _err(e)


@mcp.tool()
def open_document(file_path: str) -> str:
    """Open an existing Visio file (.vsdx, .vsd, etc.).

    Args:
        file_path: Full path to the Visio file.
    """
    try:
        return _ok(visio.open_document(file_path))
    except Exception as e:
        return _err(e)


@mcp.tool()
def save_document(doc_name: str = "") -> str:
    """Save a document.

    Args:
        doc_name: Document name. Empty for active document.
    """
    try:
        return _ok(visio.save_document(doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def save_document_as(file_path: str, doc_name: str = "") -> str:
    """Save the document to a new path.

    Args:
        file_path: Target file path (e.g. 'C:/output/diagram.vsdx').
        doc_name: Document name. Empty for active document.
    """
    try:
        return _ok(visio.save_document_as(file_path, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def close_document(doc_name: str = "") -> str:
    """Close a document.

    Args:
        doc_name: Document name. Empty for active document.
    """
    try:
        return _ok(visio.close_document(doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def list_open_documents() -> str:
    """List all open Visio documents (excluding stencils)."""
    try:
        return _ok(visio.list_open_documents())
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Page Operations
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def list_pages(doc_name: str = "") -> str:
    """List all pages in a document.

    Args:
        doc_name: Document name. Empty for active document.
    """
    try:
        return _ok(visio.list_pages(doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def add_page(page_name: str = "", doc_name: str = "") -> str:
    """Add a new page to the document.

    Args:
        page_name: Name for the new page. Empty for default name.
        doc_name: Document name. Empty for active document.
    """
    try:
        return _ok(visio.add_page(page_name, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def set_active_page(page: str, doc_name: str = "") -> str:
    """Set the active page by name or 1-based index.

    Args:
        page: Page name (string) or 1-based index (number as string, e.g. '2').
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref: str | int = page
        try:
            page_ref = int(page)
        except ValueError:
            pass
        return _ok(visio.set_active_page(page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def delete_page(page: str, doc_name: str = "") -> str:
    """Delete a page by name or 1-based index.

    Args:
        page: Page name or 1-based index (as string).
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref: str | int = page
        try:
            page_ref = int(page)
        except ValueError:
            pass
        return _ok(visio.delete_page(page_ref, doc_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Shape Operations
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def drop_shape(
    master_name: str,
    stencil_name: str,
    x: float,
    y: float,
    text: str = "",
    fill_color: str = "",
    line_color: str = "",
    line_weight: str = "",
    font_size: str = "",
    font_color: str = "",
    transparency: str = "",
    page: str = "",
    doc_name: str = "",
) -> str:
    """Drop a master shape from a stencil onto the page.

    IMPORTANT: For standard diagram types, use the master names and stencils specified
    by get_diagram_standard(). Do NOT guess master names — incorrect names will cause errors.
    Prefer batch_draw_shapes() for creating multiple shapes at once.

    Args:
        master_name: Name of the master shape in the stencil (e.g. 'Process', 'Decision').
        stencil_name: Stencil file name (e.g. 'BASIC_M.vssx') or full path.
        x: X position in inches from bottom-left.
        y: Y position in inches from bottom-left.
        text: Optional text to set on the shape.
        fill_color: Optional fill color formula, e.g. 'RGB(255,0,0)'.
        line_color: Optional line/border color formula.
        line_weight: Optional line weight, e.g. '2 pt'.
        font_size: Optional font size, e.g. '14 pt'.
        font_color: Optional font color formula.
        transparency: Optional fill transparency, e.g. '50%'.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        result = visio.drop_shape(master_name, stencil_name, x, y, page_ref, doc_name)
        shape_id = result["shape_id"]
        if text:
            visio.set_shape_text(shape_id, text, page_ref, doc_name)
            result["text"] = text
        if any([fill_color, line_color, line_weight, font_size, font_color, transparency]):
            visio.set_shape_format(
                shape_id, fill_color, line_color, line_weight,
                font_size, font_color, transparency, page_ref, doc_name,
            )
        return _ok(result)
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_rectangle(
    x1: float, y1: float, x2: float, y2: float,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a rectangle. Coordinates in inches: (x1,y1)=bottom-left, (x2,y2)=top-right.

    NOTE: For standard diagram types, do NOT use raw rectangles as substitutes for stencil
    shapes. Use drop_shape() or batch_draw_shapes() with the correct master from the standard.

    Args:
        x1: Left edge X in inches.
        y1: Bottom edge Y in inches.
        x2: Right edge X in inches.
        y2: Top edge Y in inches.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.draw_rectangle(x1, y1, x2, y2, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_oval(
    x1: float, y1: float, x2: float, y2: float,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw an oval/ellipse within the bounding box. Coordinates in inches.

    NOTE: For standard diagram types, do NOT use raw ovals as substitutes for stencil
    shapes. Use drop_shape() or batch_draw_shapes() with the correct master from the standard.

    Args:
        x1: Left edge X in inches.
        y1: Bottom edge Y in inches.
        x2: Right edge X in inches.
        y2: Top edge Y in inches.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.draw_oval(x1, y1, x2, y2, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_line(
    x1: float, y1: float, x2: float, y2: float,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a line from (x1,y1) to (x2,y2). Coordinates in inches.

    Args:
        x1: Start X in inches.
        y1: Start Y in inches.
        x2: End X in inches.
        y2: End Y in inches.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.draw_line(x1, y1, x2, y2, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_polyline(
    points: str,
    flags: int = 0,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a polyline (multi-segment line or closed polygon). Coordinates in inches.

    Args:
        points: JSON array of coordinates [x1,y1, x2,y2, ...].
                To close the polygon, repeat the first point at the end.
        flags: 0 = open polyline (default), 1 = fill shape.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        pts = json.loads(points)
        page_ref = _parse_page(page)
        return _ok(visio.draw_polyline(pts, flags, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_bezier(
    points: str,
    degree: int = 3,
    flags: int = 0,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a Bezier curve. Coordinates in inches.

    Args:
        points: JSON array of control points [x1,y1, x2,y2, ...].
                For cubic (degree 3): need 3n+1 point pairs (start + groups of 3).
        degree: 1 (linear), 2 (quadratic), or 3 (cubic, default).
        flags: 0 = default.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        pts = json.loads(points)
        page_ref = _parse_page(page)
        return _ok(visio.draw_bezier(pts, degree, flags, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_quarter_arc(
    x1: float, y1: float, x2: float, y2: float,
    sweep: int = 0,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a quarter-arc from (x1,y1) to (x2,y2). Coordinates in inches.

    Args:
        x1: Start X in inches.
        y1: Start Y in inches.
        x2: End X in inches.
        y2: End Y in inches.
        sweep: 0 = convex (default), 1 = concave.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.draw_quarter_arc(x1, y1, x2, y2, sweep, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_spline(
    points: str,
    tolerance: float = 0.25,
    flags: int = 0,
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a smooth spline through a set of points. Coordinates in inches.

    Args:
        points: JSON array of coordinates [x1,y1, x2,y2, ...].
        tolerance: How closely the spline follows the points (inches). Default 0.25.
        flags: 0 = default.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        pts = json.loads(points)
        page_ref = _parse_page(page)
        return _ok(visio.draw_spline(pts, tolerance, flags, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def draw_nurbs(
    degree: int,
    control_points: str,
    knots: str,
    weights: str = "",
    page: str = "", doc_name: str = "",
) -> str:
    """Draw a NURBS (Non-Uniform Rational B-Spline) curve.

    Args:
        degree: Degree of the curve (e.g. 3 for cubic).
        control_points: JSON array of control points [x1,y1, x2,y2, ...] in inches.
        knots: JSON array of knot values. Length = num_control_points + degree + 1.
        weights: JSON array of weights per control point. Empty for uniform (all 1.0).
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        cp = json.loads(control_points)
        k = json.loads(knots)
        w = json.loads(weights) if weights else None
        page_ref = _parse_page(page)
        return _ok(visio.draw_nurbs(degree, cp, k, w, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def connect_shapes(
    from_shape_id: int,
    to_shape_id: int,
    connector_master: str = "",
    connector_stencil: str = "",
    from_port: int = -1,
    to_port: int = -1,
    page: str = "",
    doc_name: str = "",
) -> str:
    """Connect two shapes with a connector line.

    IMPORTANT: For standard diagram types (UML, BPMN, ERD, etc.), you MUST use the
    connector_master and connector_stencil specified by get_diagram_standard().
    Using AutoConnect (empty connector_master) produces generic arrows that lack
    correct semantics (e.g. UML inheritance needs hollow triangle arrowheads).

    Args:
        from_shape_id: Source shape ID (returned by shape creation tools).
        to_shape_id: Target shape ID.
        connector_master: Connector master name. Empty uses AutoConnect (only for free-form diagrams).
        connector_stencil: Stencil for custom connector.
        from_port: Connection point row index on source shape. -1 uses PinX (default).
                   For sequence diagrams, use this to attach messages to specific
                   points along the lifeline (0 = top of lifeline, increasing downward).
        to_port: Connection point row index on target shape. -1 uses PinX (default).
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.connect_shapes(
            from_shape_id, to_shape_id,
            connector_master, connector_stencil,
            from_port, to_port,
            page_ref, doc_name,
        ))
    except Exception as e:
        return _err(e)


@mcp.tool()
def set_shape_text(
    shape_id: int, text: str,
    page: str = "", doc_name: str = "",
) -> str:
    """Set the text content of a shape.

    Args:
        shape_id: Shape ID.
        text: Text to set on the shape.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.set_shape_text(shape_id, text, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def set_shape_format(
    shape_id: int,
    fill_color: str = "",
    line_color: str = "",
    line_weight: str = "",
    font_size: str = "",
    font_color: str = "",
    transparency: str = "",
    page: str = "",
    doc_name: str = "",
) -> str:
    """Set visual formatting of a shape.

    Color values use Visio formulas: 'RGB(255,0,0)' for red, 'RGB(0,0,255)' for blue.
    Line weight: e.g. '2 pt'. Font size: e.g. '12 pt'.

    Args:
        shape_id: Shape ID.
        fill_color: Fill color formula, e.g. 'RGB(255,0,0)'.
        line_color: Line/border color formula.
        line_weight: Line weight, e.g. '2 pt'.
        font_size: Font size, e.g. '14 pt'.
        font_color: Font color formula.
        transparency: Fill transparency, e.g. '50%'.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.set_shape_format(
            shape_id, fill_color, line_color, line_weight,
            font_size, font_color, transparency, page_ref, doc_name,
        ))
    except Exception as e:
        return _err(e)


@mcp.tool()
def move_shape(
    shape_id: int, x: float, y: float,
    page: str = "", doc_name: str = "",
) -> str:
    """Move a shape to a new position.

    Args:
        shape_id: Shape ID.
        x: New X position in inches.
        y: New Y position in inches.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.move_shape(shape_id, x, y, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def resize_shape(
    shape_id: int, width: float, height: float,
    page: str = "", doc_name: str = "",
) -> str:
    """Resize a shape.

    Args:
        shape_id: Shape ID.
        width: New width in inches.
        height: New height in inches.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.resize_shape(shape_id, width, height, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def delete_shape(
    shape_id: int,
    page: str = "", doc_name: str = "",
) -> str:
    """Delete a shape by ID.

    Args:
        shape_id: Shape ID.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.delete_shape(shape_id, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def group_shapes(
    shape_ids: list[int],
    page: str = "", doc_name: str = "",
) -> str:
    """Group multiple shapes together.

    Args:
        shape_ids: List of shape IDs to group.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.group_shapes(shape_ids, page_ref, doc_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Batch Operations
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def batch_draw_shapes(
    shapes: str,
    page: str = "",
    doc_name: str = "",
) -> str:
    """Create multiple shapes in one call. MUCH faster than individual drop_shape calls.

    IMPORTANT: For standard diagram types, you MUST first call create_diagram(diagram_type)
    to create the document, then use the exact master names and stencils from the standard
    returned by create_diagram() or get_diagram_standard(). Do NOT use draw_rectangle/draw_oval
    as substitutes for standard stencil shapes.

    Args:
        shapes: JSON array of shape definitions. Each object can have:
            - id: Local ref string for use in batch_connect_shapes (e.g. "start", "step1")
            - type: "drop" (default), "rectangle", "oval", "line", "polyline", "bezier", "quarter_arc", "spline", or "nurbs"
            - For "drop": master_name, stencil_name, x, y
            - For "rectangle"/"oval": x1, y1, x2, y2
            - For "line": x1, y1, x2, y2
            - For "polyline": points (flat [x1,y1,...]), optional flags (0=open, 1=fill)
            - For "bezier": points (flat [x1,y1,...]), optional degree (default 3), optional flags
            - For "quarter_arc": x1, y1, x2, y2, optional sweep (0=convex, 1=concave)
            - For "spline": points (flat [x1,y1,...]), optional tolerance, optional flags
            - For "nurbs": control_points (flat [x1,y1,...]), knots, optional degree (default 3), optional weights
            - Optional: text, width, height
            - Optional formatting: fill_color, line_color, line_weight, font_size, font_color, transparency

            Example: [{"id":"s1","type":"drop","master_name":"Process","stencil_name":"FLOWM_M.vssx","x":4,"y":8,"text":"Step 1"}]
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.

    Returns:
        JSON with ref_map (id->shape_id mapping) and shapes list.
        Pass the ref_map to batch_connect_shapes to wire up connections.
    """
    try:
        shapes_list = json.loads(shapes)
        page_ref = _parse_page(page)
        return _ok(visio.batch_draw_shapes(shapes_list, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def batch_connect_shapes(
    connections: str,
    ref_map: str = "{}",
    page: str = "",
    doc_name: str = "",
) -> str:
    """Connect multiple shape pairs in one call.

    For standard diagram types (UML, BPMN, ERD, etc.), each connection MUST specify
    connector_master and connector_stencil as defined by get_diagram_standard().
    Without these, AutoConnect produces generic arrows without correct UML/BPMN semantics.

    Args:
        connections: JSON array of connection objects, each with:
            - from: ref ID string (from batch_draw_shapes) or integer shape ID
            - to: ref ID string or integer shape ID
            - connector_master: (optional) Connector master name from stencil
            - connector_stencil: (optional) Stencil file for the connector
            - from_port: (optional) Connection point row index on source shape.
                         Glues to a specific connection point instead of PinX.
                         Essential for sequence diagrams (attach to lifeline).
            - to_port: (optional) Connection point row index on target shape.

            Example (UML): [{"from":"dog","to":"animal","connector_master":"Inheritance","connector_stencil":"USTRME_M.VSSX"}]
            Example (free-form): [{"from":"s1","to":"s2"}]
            Example (sequence): [{"from":"client","to":"auth","from_port":1,"to_port":1,"connector_master":"Message","connector_stencil":"USEQME_M.VSSX"}]
        ref_map: JSON object mapping ref IDs to Visio shape IDs.
                 Use the ref_map returned by batch_draw_shapes.
                 Example: {"s1":5,"s2":6,"s3":7}
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.

    Returns:
        JSON array of connector shape info.
    """
    try:
        conn_list = json.loads(connections)
        id_map = json.loads(ref_map)
        # Ensure values are int
        id_map = {k: int(v) for k, v in id_map.items()}
        page_ref = _parse_page(page)
        return _ok(visio.batch_connect_shapes(conn_list, id_map, page_ref, doc_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Read / Analysis
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def list_shapes(page: str = "", doc_name: str = "") -> str:
    """List all shapes on a page with their IDs, names, text, and positions.

    Args:
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.list_shapes(page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def get_shape_info(
    shape_id: int,
    page: str = "", doc_name: str = "",
) -> str:
    """Get detailed information about a shape (position, size, colors, text).

    Args:
        shape_id: Shape ID.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.get_shape_info(shape_id, page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def get_connections(page: str = "", doc_name: str = "") -> str:
    """Get all connections between shapes on a page.

    Args:
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.get_connections(page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def get_page_summary(page: str = "", doc_name: str = "") -> str:
    """Get a summary of the page: shape count, connections, etc.

    Args:
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.get_page_summary(page_ref, doc_name))
    except Exception as e:
        return _err(e)


@mcp.tool()
def read_shape_data(
    shape_id: int,
    page: str = "", doc_name: str = "",
) -> str:
    """Read custom Shape Data (properties) from a shape.

    Args:
        shape_id: Shape ID.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.read_shape_data(shape_id, page_ref, doc_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Stencils / Masters
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def list_stencils() -> str:
    """List all currently open stencils."""
    try:
        return _ok(visio.list_stencils())
    except Exception as e:
        return _err(e)


@mcp.tool()
def open_stencil(stencil_path: str) -> str:
    """Open a stencil file.

    Args:
        stencil_path: Stencil file name (e.g. 'BASIC_M.vssx') or full path.
    """
    try:
        return _ok(visio.open_stencil(stencil_path))
    except Exception as e:
        return _err(e)


@mcp.tool()
def list_masters(stencil_name: str) -> str:
    """List all master shapes in a stencil.

    Args:
        stencil_name: Stencil name or path.
    """
    try:
        return _ok(visio.list_masters(stencil_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Export
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def export_page_as_image(
    output_path: str,
    page: str = "", doc_name: str = "",
) -> str:
    """Export a page as an image file (PNG, SVG, JPG, etc.).

    Args:
        output_path: Output file path. Format determined by extension.
        page: Page name or index. Empty for active page.
        doc_name: Document name. Empty for active document.
    """
    try:
        page_ref = _parse_page(page)
        return _ok(visio.export_page_as_image(output_path, page_ref, doc_name))
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Diagram Standards (Tools)
# ═══════════════════════════════════════════════════════════════════


@mcp.tool()
def list_diagram_types() -> str:
    """List all available diagram types with their IDs, names, templates, and standards.

    Returns a JSON array. Use the 'id' field with create_diagram() or get_diagram_standard().
    """
    return _ok(list_types())


@mcp.tool()
def get_diagram_standard(diagram_type: str) -> str:
    """Get the full drawing standard for a diagram type.

    Returns template, stencils, shapes, edges/connectors, and layout conventions.
    IMPORTANT: Always use create_diagram() to create a new document — it automatically
    applies the correct Visio template for the diagram type.

    Args:
        diagram_type: Diagram type ID (from list_diagram_types), e.g. 'class_diagram',
                      'sequence_diagram', 'flowchart', 'bpmn', 'erd_crows_foot',
                      'network_diagram', 'azure_architecture', 'kubernetes', 'org_chart'.
    """
    std = get_standard(diagram_type)
    if std is None:
        available = [t["id"] for t in list_types()]
        return _ok({"error": f"Unknown diagram type: {diagram_type}", "available_types": available})
    return _ok(std)


@mcp.tool()
def create_diagram(diagram_type: str) -> str:
    """Create a new Visio document using the standard template for a diagram type.

    This is the REQUIRED way to start drawing any diagram. It creates a document from
    the correct Visio template, which pre-loads the appropriate stencils, page settings,
    and styles for the diagram type.

    The response includes the full drawing standard (shapes, edges, layout, and a
    complete example) — use these exact master names and stencils when drawing.

    Args:
        diagram_type: Diagram type ID (from list_diagram_types), e.g. 'class_diagram',
                      'sequence_diagram', 'flowchart', 'bpmn', 'erd_crows_foot',
                      'network_diagram', 'azure_architecture', 'kubernetes', 'org_chart'.

    Returns:
        JSON with document info and the full drawing standard (shapes, edges, layout, example).
    """
    std = get_standard(diagram_type)
    if std is None:
        available = [t["id"] for t in list_types()]
        return _ok({"error": f"Unknown diagram type: {diagram_type}", "available_types": available})
    try:
        template = std["template"]
        result = visio.create_document(template)
        result["diagram_type"] = diagram_type
        result["template"] = template
        # Embed the full standard so the caller knows exactly which shapes/edges to use
        result["standard"] = {
            "shapes": std.get("shapes", []),
            "edges": std.get("edges", []),
            "layout": std.get("layout", {}),
            "example": std.get("example", {}),
            "stencils": std.get("stencils", []),
        }
        result["instructions"] = (
            "MANDATORY: Use ONLY the master names and stencils listed in 'standard.shapes' "
            "and 'standard.edges' above. For connections, specify connector_master and "
            "connector_stencil in batch_connect_shapes — do NOT use plain AutoConnect "
            "unless the standard's edges say so. See 'standard.example' for a complete "
            "working example with exact batch_draw_shapes/batch_connect_shapes parameters."
        )
        return _ok(result)
    except Exception as e:
        return _err(e)


# ═══════════════════════════════════════════════════════════════════
# Diagram Standards (Resources)
# ═══════════════════════════════════════════════════════════════════


@mcp.resource("visio://standards")
def standards_index() -> str:
    """Index of all available diagram type standards."""
    return json.dumps(list_types(), ensure_ascii=False, indent=2)


@mcp.resource("visio://standards/{diagram_type}")
def standard_detail(diagram_type: str) -> str:
    """Full drawing standard for a specific diagram type."""
    std = get_standard(diagram_type)
    if std is None:
        return json.dumps({"error": f"Unknown diagram type: {diagram_type}"}, ensure_ascii=False)
    return json.dumps(std, ensure_ascii=False, indent=2)


# ═══════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════


def _parse_page(page: str):
    """Parse page parameter: empty -> None, numeric string -> int, else str."""
    if not page:
        return None
    try:
        return int(page)
    except ValueError:
        return page


if __name__ == "__main__":
    mcp.run(transport="stdio")
