"""Visio COM automation wrapper."""

import sys
import logging
import pythoncom
import win32com.client

logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler(sys.stderr))
logger.setLevel(logging.INFO)

# Visio constants
visOpenRO = 2
visOpenMinimized = 16
visSaveAsWS = 0
visDelete = 0

# Shape type constants
visTypeShape = 1
visTypeGroup = 2
visTypeForeignObject = 4

# Section/Row/Cell indices for ShapeSheet
visSectionObject = 1
visRowXFormOut = 1
visSectionProp = 243  # visSectionProp

# Cell indices
visXFormPinX = 0
visXFormPinY = 1
visXFormWidth = 2
visXFormHeight = 3

# Connect constants
visAutoConnectDirNone = 0


class VisioApp:
    """Singleton wrapper around Visio COM Application object."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._app = None
        return cls._instance

    @property
    def app(self):
        """Get or create Visio Application COM object."""
        if self._app is None:
            self._ensure_app()
        return self._app

    def _ensure_app(self):
        """Start or connect to Visio application."""
        pythoncom.CoInitialize()
        try:
            self._app = win32com.client.GetActiveObject("Visio.Application")
            logger.info("Connected to existing Visio instance")
        except Exception:
            self._app = win32com.client.Dispatch("Visio.Application")
            self._app.Visible = True
            logger.info("Started new Visio instance")

    # ── Document Management ──────────────────────────────────────────

    def create_document(self, template: str = "") -> dict:
        """Create a new Visio document.

        Args:
            template: Optional template path or built-in template name.
                      Empty string creates a blank document.
        Returns:
            dict with document info (name, index, pages count).
        """
        doc = self.app.Documents.Add(template)
        return {
            "name": doc.Name,
            "full_name": doc.FullName,
            "index": doc.Index,
            "pages": doc.Pages.Count,
        }

    def open_document(self, file_path: str) -> dict:
        """Open an existing Visio file."""
        doc = self.app.Documents.Open(file_path)
        return {
            "name": doc.Name,
            "full_name": doc.FullName,
            "index": doc.Index,
            "pages": doc.Pages.Count,
        }

    def save_document(self, doc_name: str = "") -> dict:
        """Save the specified or active document."""
        doc = self._get_document(doc_name)
        doc.Save()
        return {"name": doc.Name, "full_name": doc.FullName, "saved": True}

    def save_document_as(self, file_path: str, doc_name: str = "") -> dict:
        """Save the document to a new path."""
        doc = self._get_document(doc_name)
        doc.SaveAs(file_path)
        return {"name": doc.Name, "full_name": doc.FullName, "saved": True}

    def close_document(self, doc_name: str = "") -> dict:
        """Close the specified or active document."""
        doc = self._get_document(doc_name)
        name = doc.Name
        doc.Close()
        return {"closed": name}

    def list_open_documents(self) -> list[dict]:
        """List all open documents."""
        result = []
        for i in range(1, self.app.Documents.Count + 1):
            doc = self.app.Documents.Item(i)
            # Skip stencils (Type == 2)
            if doc.Type == 2:
                continue
            result.append({
                "name": doc.Name,
                "full_name": doc.FullName,
                "index": i,
                "pages": doc.Pages.Count,
            })
        return result

    # ── Page Operations ──────────────────────────────────────────────

    def list_pages(self, doc_name: str = "") -> list[dict]:
        """List all pages in a document."""
        doc = self._get_document(doc_name)
        result = []
        for i in range(1, doc.Pages.Count + 1):
            page = doc.Pages.Item(i)
            result.append({
                "name": page.Name,
                "index": i,
                "shapes_count": page.Shapes.Count,
            })
        return result

    def add_page(self, page_name: str = "", doc_name: str = "") -> dict:
        """Add a new page to the document."""
        doc = self._get_document(doc_name)
        page = doc.Pages.Add()
        if page_name:
            page.Name = page_name
        return {
            "name": page.Name,
            "index": page.Index,
        }

    def set_active_page(self, page_name_or_index, doc_name: str = "") -> dict:
        """Set the active page by name or index."""
        doc = self._get_document(doc_name)
        page = self._get_page(doc, page_name_or_index)
        self.app.ActiveWindow.Page = page
        return {"active_page": page.Name, "index": page.Index}

    def delete_page(self, page_name_or_index, doc_name: str = "") -> dict:
        """Delete a page."""
        doc = self._get_document(doc_name)
        page = self._get_page(doc, page_name_or_index)
        name = page.Name
        page.Delete(0)
        return {"deleted": name}

    # ── Shape Operations ─────────────────────────────────────────────

    def drop_shape(
        self,
        master_name: str,
        stencil_name: str,
        x: float,
        y: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Drop a master shape from a stencil onto the page.

        Args:
            master_name: Name of the master shape in the stencil.
            stencil_name: Stencil file name (e.g. 'BASIC_M.vssx').
            x, y: Position in inches.
            page_name_or_index: Target page (default: active page).
            doc_name: Target document (default: active document).
        Returns:
            dict with shape_id and name.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        stencil = self._open_stencil(stencil_name)
        master = stencil.Masters.ItemU(master_name)
        shape = page.Drop(master, x, y)
        return self._shape_info(shape)

    def draw_rectangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a rectangle. Coordinates in inches (x1,y1)=bottom-left, (x2,y2)=top-right."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawRectangle(x1, y1, x2, y2)
        return self._shape_info(shape)

    def draw_oval(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw an oval/ellipse. Bounding box in inches."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawOval(x1, y1, x2, y2)
        return self._shape_info(shape)

    def draw_line(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a line from (x1,y1) to (x2,y2) in inches."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawLine(x1, y1, x2, y2)
        return self._shape_info(shape)

    def draw_polyline(
        self,
        points: list[float],
        flags: int = 0,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a polyline (multi-segment line or closed polygon).

        Args:
            points: Flat array of coordinates [x1,y1, x2,y2, ...] in inches.
                    To close the polygon, repeat the first point at the end.
            flags: 0 = open polyline (default), 1 = fill shape (visPolyline1D).
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawPolyline(points, flags)
        return self._shape_info(shape)

    def draw_bezier(
        self,
        points: list[float],
        degree: int = 3,
        flags: int = 0,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a Bezier curve.

        Args:
            points: Flat array of control points [x1,y1, x2,y2, ...] in inches.
                    For degree 3: need 3n+1 points (start + groups of 3 control points).
            degree: 1 (linear), 2 (quadratic), or 3 (cubic, default).
            flags: 0 = default.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawBezier(points, degree, flags)
        return self._shape_info(shape)

    def draw_quarter_arc(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        sweep: int = 0,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a quarter-arc from (x1,y1) to (x2,y2).

        Args:
            x1, y1: Start point in inches.
            x2, y2: End point in inches.
            sweep: visArcSweepFlagConvex=0 (default) or visArcSweepFlagConcave=1.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        # visArcSweepFlagConvex = 0, visArcSweepFlagConcave = 1
        shape = page.DrawQuarterArc(x1, y1, x2, y2, sweep)
        return self._shape_info(shape)

    def draw_spline(
        self,
        points: list[float],
        tolerance: float = 0.25,
        flags: int = 0,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a smooth spline through a set of points.

        Args:
            points: Flat array of coordinates [x1,y1, x2,y2, ...] in inches.
            tolerance: How closely the spline must follow the points (in inches).
                       Smaller = closer fit. Default 0.25.
            flags: 0 = default.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.DrawSpline(points, tolerance, flags)
        return self._shape_info(shape)

    def draw_nurbs(
        self,
        degree: int,
        control_points: list[float],
        knots: list[float],
        weights: list[float] | None = None,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Draw a NURBS curve.

        Args:
            degree: Degree of the curve (e.g. 3 for cubic).
            control_points: Flat array [x1,y1, x2,y2, ...] of control points in inches.
            knots: Knot vector (length = num_control_points + degree + 1).
            weights: Optional weight for each control point. All 1.0 if omitted.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        num_cp = len(control_points) // 2
        if weights is None:
            weights = [1.0] * num_cp

        # Visio DrawNURBS(degree, flags, xyArray, knots, weights)
        # flags: 0
        shape = page.DrawNURBS(degree, 0, control_points, knots, weights)
        return self._shape_info(shape)

    def connect_shapes(
        self,
        from_shape_id: int,
        to_shape_id: int,
        connector_master: str = "",
        connector_stencil: str = "",
        from_port: int = -1,
        to_port: int = -1,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Connect two shapes with a dynamic connector.

        Args:
            from_shape_id: Source shape ID.
            to_shape_id: Target shape ID.
            connector_master: Connector master name (default: 'Dynamic connector').
            connector_stencil: Stencil for connector (default: built-in).
            from_port: Connection point row index on source shape (-1 = use PinX).
            to_port: Connection point row index on target shape (-1 = use PinX).
        Returns:
            dict with connector shape info.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        from_shape = page.Shapes.ItemFromID(from_shape_id)
        to_shape = page.Shapes.ItemFromID(to_shape_id)

        # Use AutoConnect if no custom connector specified
        if not connector_master:
            from_shape.AutoConnect(to_shape, visAutoConnectDirNone)
            # Find the connector that was just created (last shape)
            connector = page.Shapes.Item(page.Shapes.Count)
            return self._shape_info(connector)

        stencil = self._open_stencil(connector_stencil)
        master = stencil.Masters.ItemU(connector_master)
        connector = page.Drop(master, 0, 0)

        # Glue begin to from_shape, end to to_shape
        # visSectionConnectionPts = 7
        if from_port >= 0:
            connector.CellsU("BeginX").GlueTo(from_shape.CellsSRC(7, from_port, 0))
        else:
            connector.CellsU("BeginX").GlueTo(from_shape.CellsU("PinX"))
        if to_port >= 0:
            connector.CellsU("EndX").GlueTo(to_shape.CellsSRC(7, to_port, 0))
        else:
            connector.CellsU("EndX").GlueTo(to_shape.CellsU("PinX"))

        return self._shape_info(connector)

    def set_shape_text(
        self,
        shape_id: int,
        text: str,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Set the text content of a shape."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        shape.Text = text
        return self._shape_info(shape)

    def set_shape_format(
        self,
        shape_id: int,
        fill_color: str = "",
        line_color: str = "",
        line_weight: str = "",
        font_size: str = "",
        font_color: str = "",
        transparency: str = "",
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Set formatting of a shape via ShapeSheet cells.

        Color values use Visio formulas, e.g.:
            - 'RGB(255,0,0)' for red
            - 'THEMEGUARD(RGB(255,0,0))'
        Line weight: e.g. '2 pt'
        Font size: e.g. '12 pt'
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)

        if fill_color:
            shape.CellsU("FillForegnd").FormulaU = fill_color
        if line_color:
            shape.CellsU("LineColor").FormulaU = line_color
        if line_weight:
            shape.CellsU("LineWeight").FormulaU = line_weight
        if font_size:
            shape.CellsU("Char.Size").FormulaU = font_size
        if font_color:
            shape.CellsU("Char.Color").FormulaU = font_color
        if transparency:
            shape.CellsU("FillForegndTrans").FormulaU = transparency

        return self._shape_info(shape)

    def move_shape(
        self,
        shape_id: int,
        x: float,
        y: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Move a shape to position (x, y) in inches."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        shape.CellsU("PinX").ResultIU = x
        shape.CellsU("PinY").ResultIU = y
        return self._shape_info(shape)

    def resize_shape(
        self,
        shape_id: int,
        width: float,
        height: float,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Resize a shape (width, height in inches)."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        shape.CellsU("Width").ResultIU = width
        shape.CellsU("Height").ResultIU = height
        return self._shape_info(shape)

    def delete_shape(
        self,
        shape_id: int,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Delete a shape by ID."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        name = shape.Name
        shape.Delete()
        return {"deleted": name, "shape_id": shape_id}

    def group_shapes(
        self,
        shape_ids: list[int],
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Group multiple shapes together."""
        page = self._resolve_page(doc_name, page_name_or_index)
        # Select shapes
        window = self.app.ActiveWindow
        window.DeselectAll()
        for sid in shape_ids:
            shape = page.Shapes.ItemFromID(sid)
            window.Select(shape, 2)  # visSelect
        selection = window.Selection
        group = selection.Group()
        return self._shape_info(group)

    # ── Batch Operations ──────────────────────────────────────────────

    def batch_draw_shapes(
        self,
        shapes: list[dict],
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Create multiple shapes in one call.

        Each item in *shapes* is a dict with keys:
            id          – local ref string (used later for connections)
            type        – "drop" | "rectangle" | "oval" | "line"
            For "drop": master_name, stencil_name, x, y
            For "rectangle"/"oval": x1, y1, x2, y2
            For "line": x1, y1, x2, y2
            Optional: text, fill_color, line_color, line_weight,
                      font_size, font_color, transparency,
                      width, height

        Returns:
            {"ref_map": {ref_id: shape_id, ...}, "shapes": [shape_info, ...]}
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        ref_map: dict[str, int] = {}
        results: list[dict] = []
        stencil_cache: dict[str, object] = {}

        for defn in shapes:
            shape = None
            stype = defn.get("type", "drop")

            if stype == "drop":
                stencil_name = defn["stencil_name"]
                if stencil_name not in stencil_cache:
                    stencil_cache[stencil_name] = self._open_stencil(stencil_name)
                stencil = stencil_cache[stencil_name]
                master = stencil.Masters.ItemU(defn["master_name"])
                shape = page.Drop(master, defn["x"], defn["y"])
            elif stype == "rectangle":
                shape = page.DrawRectangle(
                    defn["x1"], defn["y1"], defn["x2"], defn["y2"]
                )
            elif stype == "oval":
                shape = page.DrawOval(
                    defn["x1"], defn["y1"], defn["x2"], defn["y2"]
                )
            elif stype == "line":
                shape = page.DrawLine(
                    defn["x1"], defn["y1"], defn["x2"], defn["y2"]
                )
            elif stype == "polyline":
                shape = page.DrawPolyline(
                    defn["points"], defn.get("flags", 0)
                )
            elif stype == "bezier":
                shape = page.DrawBezier(
                    defn["points"], defn.get("degree", 3), defn.get("flags", 0)
                )
            elif stype == "quarter_arc":
                shape = page.DrawQuarterArc(
                    defn["x1"], defn["y1"], defn["x2"], defn["y2"],
                    defn.get("sweep", 0),
                )
            elif stype == "spline":
                shape = page.DrawSpline(
                    defn["points"], defn.get("tolerance", 0.25),
                    defn.get("flags", 0),
                )
            elif stype == "nurbs":
                cp = defn["control_points"]
                num_cp = len(cp) // 2
                weights = defn.get("weights") or [1.0] * num_cp
                shape = page.DrawNURBS(
                    defn.get("degree", 3), 0, cp,
                    defn["knots"], weights,
                )
            else:
                raise ValueError(f"Unknown shape type: {stype}")

            # Optional text
            if defn.get("text"):
                shape.Text = defn["text"]

            # Optional resize
            if defn.get("width") is not None:
                shape.CellsU("Width").ResultIU = defn["width"]
            if defn.get("height") is not None:
                shape.CellsU("Height").ResultIU = defn["height"]

            # Optional formatting
            fmt_map = {
                "fill_color": "FillForegnd",
                "line_color": "LineColor",
                "line_weight": "LineWeight",
                "font_size": "Char.Size",
                "font_color": "Char.Color",
                "transparency": "FillForegndTrans",
            }
            for key, cell in fmt_map.items():
                val = defn.get(key)
                if val:
                    shape.CellsU(cell).FormulaU = val

            # Track ref
            ref_id = defn.get("id", str(shape.ID))
            ref_map[ref_id] = shape.ID
            results.append(self._shape_info(shape))

        return {"ref_map": ref_map, "shapes": results}

    def batch_connect_shapes(
        self,
        connections: list[dict],
        ref_map: dict[str, int] | None = None,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> list[dict]:
        """Connect multiple shape pairs in one call.

        Each item in *connections* is a dict:
            from              – ref ID string (looked up in ref_map) or int shape ID
            to                – ref ID string or int shape ID
            connector_master  – (optional) connector master name from stencil
            connector_stencil – (optional) stencil file for the connector
            from_port         – (optional) connection point row index on source shape
            to_port           – (optional) connection point row index on target shape

        When connector_master is provided, the connector is dropped from the stencil
        and glued to the shapes. Otherwise AutoConnect is used.

        When from_port / to_port are provided (>= 0), the connector glues to the
        specified connection point (CellsSRC section 7) instead of PinX. This is
        essential for sequence diagrams where messages must attach to specific
        points along the lifeline.

        Returns:
            list of connector shape info dicts.
        """
        page = self._resolve_page(doc_name, page_name_or_index)
        ref_map = ref_map or {}
        results: list[dict] = []
        stencil_cache: dict[str, object] = {}

        for conn in connections:
            from_id = self._resolve_ref(conn["from"], ref_map)
            to_id = self._resolve_ref(conn["to"], ref_map)
            from_shape = page.Shapes.ItemFromID(from_id)
            to_shape = page.Shapes.ItemFromID(to_id)

            connector_master = conn.get("connector_master", "")
            connector_stencil = conn.get("connector_stencil", "")

            if connector_master and connector_stencil:
                # Use stencil connector for correct semantics
                if connector_stencil not in stencil_cache:
                    stencil_cache[connector_stencil] = self._open_stencil(connector_stencil)
                stencil = stencil_cache[connector_stencil]
                master = stencil.Masters.ItemU(connector_master)
                connector = page.Drop(master, 0, 0)
                # visSectionConnectionPts = 7
                from_port = conn.get("from_port", -1)
                to_port = conn.get("to_port", -1)
                if from_port is not None and from_port >= 0:
                    connector.CellsU("BeginX").GlueTo(from_shape.CellsSRC(7, from_port, 0))
                else:
                    connector.CellsU("BeginX").GlueTo(from_shape.CellsU("PinX"))
                if to_port is not None and to_port >= 0:
                    connector.CellsU("EndX").GlueTo(to_shape.CellsSRC(7, to_port, 0))
                else:
                    connector.CellsU("EndX").GlueTo(to_shape.CellsU("PinX"))
            else:
                # Fallback to AutoConnect
                from_shape.AutoConnect(to_shape, visAutoConnectDirNone)
                connector = page.Shapes.Item(page.Shapes.Count)

            # Optional: set text on connector
            if conn.get("text"):
                connector.Text = conn["text"]

            results.append(self._shape_info(connector))

        return results

    @staticmethod
    def _resolve_ref(ref, ref_map: dict[str, int]) -> int:
        """Resolve a ref ID (string or int) to a Visio shape ID."""
        if isinstance(ref, int):
            return ref
        if isinstance(ref, str) and ref.isdigit():
            return int(ref)
        return ref_map[ref]

    # ── Read / Analysis ──────────────────────────────────────────────

    def list_shapes(
        self, page_name_or_index=None, doc_name: str = ""
    ) -> list[dict]:
        """List all shapes on a page."""
        page = self._resolve_page(doc_name, page_name_or_index)
        result = []
        for i in range(1, page.Shapes.Count + 1):
            shape = page.Shapes.Item(i)
            result.append(self._shape_info(shape))
        return result

    def get_shape_info(
        self,
        shape_id: int,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Get detailed info about a shape."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        info = self._shape_info(shape)
        # Add extra detail
        try:
            info["fill_color"] = shape.CellsU("FillForegnd").FormulaU
        except Exception:
            pass
        try:
            info["line_color"] = shape.CellsU("LineColor").FormulaU
        except Exception:
            pass
        try:
            info["line_weight"] = shape.CellsU("LineWeight").FormulaU
        except Exception:
            pass
        return info

    def get_connections(
        self, page_name_or_index=None, doc_name: str = ""
    ) -> list[dict]:
        """Get all connections (connects) on a page."""
        page = self._resolve_page(doc_name, page_name_or_index)
        result = []
        connects = page.Connects
        i = 1
        while True:
            try:
                conn = connects.Item(i)
                result.append({
                    "from_shape": conn.FromSheet.Name,
                    "from_shape_id": conn.FromSheet.ID,
                    "to_shape": conn.ToSheet.Name,
                    "to_shape_id": conn.ToSheet.ID,
                    "from_cell": conn.FromCell.Name,
                    "to_cell": conn.ToCell.Name,
                })
                i += 1
            except Exception:
                break
        return result

    def get_page_summary(
        self, page_name_or_index=None, doc_name: str = ""
    ) -> dict:
        """Get a summary of the page: shapes count, connections, etc."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shapes_count = page.Shapes.Count
        connections = self.get_connections(page_name_or_index, doc_name)
        return {
            "page_name": page.Name,
            "page_index": page.Index,
            "shapes_count": shapes_count,
            "connections_count": len(connections),
            "connections": connections,
        }

    def read_shape_data(
        self,
        shape_id: int,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Read custom Shape Data (properties) from a shape."""
        page = self._resolve_page(doc_name, page_name_or_index)
        shape = page.Shapes.ItemFromID(shape_id)
        data = {}
        try:
            section = shape.Section(visSectionProp)
            for r in range(shape.RowCount(visSectionProp)):
                row = section.Row(r)
                label = row.Cell(0).FormulaU  # Label
                value = row.Cell(1).FormulaU  # Value
                data[label] = value
        except Exception:
            pass
        return {"shape_id": shape_id, "shape_name": shape.Name, "data": data}

    # ── Stencils / Masters ───────────────────────────────────────────

    def list_stencils(self) -> list[dict]:
        """List all currently open stencils."""
        result = []
        for i in range(1, self.app.Documents.Count + 1):
            doc = self.app.Documents.Item(i)
            if doc.Type == 2:  # Stencil
                result.append({
                    "name": doc.Name,
                    "full_name": doc.FullName,
                    "masters_count": doc.Masters.Count,
                })
        return result

    def open_stencil(self, stencil_path: str) -> dict:
        """Open a stencil file."""
        stencil = self._open_stencil(stencil_path)
        return {
            "name": stencil.Name,
            "full_name": stencil.FullName,
            "masters_count": stencil.Masters.Count,
        }

    def list_masters(self, stencil_name: str) -> list[dict]:
        """List all masters in a stencil."""
        stencil = self._find_stencil(stencil_name)
        if stencil is None:
            stencil = self._open_stencil(stencil_name)
        result = []
        for i in range(1, stencil.Masters.Count + 1):
            master = stencil.Masters.Item(i)
            result.append({
                "name": master.Name,
                "name_u": master.NameU,
                "index": i,
            })
        return result

    # ── Export ────────────────────────────────────────────────────────

    def export_page_as_image(
        self,
        output_path: str,
        page_name_or_index=None,
        doc_name: str = "",
    ) -> dict:
        """Export a page as an image (PNG, SVG, etc. based on extension)."""
        page = self._resolve_page(doc_name, page_name_or_index)
        page.Export(output_path)
        return {"exported": output_path, "page": page.Name}

    # ── Internal Helpers ─────────────────────────────────────────────

    def _get_document(self, doc_name: str = ""):
        """Get document by name or the active document."""
        if doc_name:
            return self.app.Documents.Item(doc_name)
        return self.app.ActiveDocument

    def _get_page(self, doc, page_name_or_index):
        """Get page by name or 1-based index."""
        if page_name_or_index is None:
            return self.app.ActivePage
        if isinstance(page_name_or_index, int):
            return doc.Pages.Item(page_name_or_index)
        return doc.Pages.Item(page_name_or_index)

    def _resolve_page(self, doc_name: str = "", page_name_or_index=None):
        """Resolve to a Page object."""
        doc = self._get_document(doc_name)
        if page_name_or_index is not None:
            return self._get_page(doc, page_name_or_index)
        return self.app.ActivePage

    def _open_stencil(self, stencil_name: str):
        """Open a stencil if not already open. Accepts filename or full path."""
        existing = self._find_stencil(stencil_name)
        if existing:
            return existing
        # Open read-only + minimized
        return self.app.Documents.OpenEx(
            stencil_name, visOpenRO + visOpenMinimized
        )

    def _find_stencil(self, stencil_name: str):
        """Find an already open stencil by name."""
        for i in range(1, self.app.Documents.Count + 1):
            doc = self.app.Documents.Item(i)
            if doc.Type == 2:  # Stencil
                if (
                    doc.Name.lower() == stencil_name.lower()
                    or doc.FullName.lower() == stencil_name.lower()
                ):
                    return doc
        return None

    def _shape_info(self, shape) -> dict:
        """Extract basic info from a Shape object."""
        info = {
            "shape_id": shape.ID,
            "name": shape.Name,
            "text": shape.Text,
        }
        try:
            info["pin_x"] = round(shape.CellsU("PinX").ResultIU, 4)
            info["pin_y"] = round(shape.CellsU("PinY").ResultIU, 4)
            info["width"] = round(shape.CellsU("Width").ResultIU, 4)
            info["height"] = round(shape.CellsU("Height").ResultIU, 4)
        except Exception:
            pass
        return info
