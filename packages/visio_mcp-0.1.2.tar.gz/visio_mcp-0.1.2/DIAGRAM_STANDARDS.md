# Visio 绘图标准规范

本文档为 Visio MCP Server 的绘图标准参考，定义了各类图表使用的模板、Stencil 文件、形状 (Master)、连接器/边以及布局约定。所有 Master 名称均使用 Visio 的 `NameU`（Universal 名称，英文），可直接传入 `drop_shape` / `batch_draw_shapes` 的 `master_name` 参数。

---

## 总则

1. **必须使用模板**：绘制任何标准图表时，**必须**通过 `create_diagram(diagram_type)` 创建文档。该工具会自动使用对应的 Visio 模板（.vstx），预加载正确的 stencil、页面尺寸、网格和样式。**禁止使用空白文档绘制标准图表**。
2. **Master 名称**：本文档中的 Master 名称均为 `NameU`，与 `list_masters` 返回的 `name_u` 字段一致。
3. **Stencil 文件名**：以 `_M` 后缀表示公制单位版本。文件名不区分大小写，但本文档统一使用大写。
4. **Stencil 路径**：直接使用文件名即可（如 `USTRME_M.VSSX`），Visio 会自动从内置路径解析。
5. **连接器获取方式**：标注为 `AutoConnect` 的边使用 `connect_shapes` 的默认模式（不传 `connector_master`）；标注为具体 Master 名称的边必须通过 `connect_shapes(connector_master="...", connector_stencil="...")` 获取。
6. **尾部空格警告**：部分 Stencil 中的 Master 名称存在尾部空格（如 Chen 记法的 `"Associative Entity "`），使用时必须包含该空格。

### 标准绘图流程

```
1. create_diagram("class_diagram")       ← 使用模板创建文档
2. get_diagram_standard("class_diagram") ← 获取形状/边/布局标准
3. batch_draw_shapes / drop_shape        ← 按标准绘制
4. batch_connect_shapes / connect_shapes ← 按标准连接
5. save_document / save_document_as      ← 保存
```

---

## 坐标与页面约定

- **坐标单位**：英寸 (inches)
- **坐标原点**：页面左下角
- **默认页面**：Letter 尺寸 (8.5 x 11 英寸)
- **推荐可用区域**：x: 0.5 ~ 8.0, y: 0.5 ~ 10.5（留 0.5 英寸页边距）

### 各图表类型默认方向

| 图表类型 | 方向 |
|---------|------|
| 流程图 / 活动图 / 状态机图 | 从上到下 (top-to-bottom) |
| 序列图 / BPMN | 从左到右 (left-to-right) |
| 类图 | 从上到下（继承层级） |
| 用例图 | 参与者在两侧，用例居中 |
| 组织结构图 | 从上到下 (top-to-bottom) |
| 网络拓扑图 / 架构图 | 自由布局或分层布局 |
| 因果图（鱼骨图） | 从右到左 |

---

## 连接器通用规则

### AutoConnect（默认连接）

适用场景：流程图、活动图、状态机图、组织结构图、块图等需要简单箭头/直线连接的图表。

调用方式：
```
connect_shapes(from_shape_id, to_shape_id)
```
或在 `batch_connect_shapes` 中直接指定 `from` / `to`。

### Stencil 连接器（语义连接）

适用场景：UML 类图（继承、组合、聚合等）、用例图（Include/Extend）、BPMN（Sequence Flow/Message Flow）等需要特定视觉样式的图表。

调用方式：
```
connect_shapes(from_shape_id, to_shape_id, connector_master="Inheritance", connector_stencil="USTRME_M.VSSX")
```

**重要**：UML 图中的关系线必须使用 Stencil 连接器，不能用 AutoConnect，否则无法呈现正确的箭头样式（空心三角、菱形等）。

---

## 1. UML 类图 (Class Diagram)

### 标准参考

- OMG UML 2.5.1
- 用于描述类的结构、属性、方法及类之间的关系

### 模板

`USTRME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| USTRME_M.VSSX | 类图全部形状与连接器 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Class | 类 | 主要元素，包含名称/属性/方法分区 |
| Member | 成员行 | 放置在 Class 内部表示属性或方法 |
| Separator | 分隔线 | 分隔类的属性区和方法区 |
| Interface | 接口 | 带 `<<interface>>` 构造型 |
| Enumeration | 枚举 | 带 `<<enumeration>>` 构造型 |
| Package (expanded) | 包（展开） | 容器，展示内部元素 |
| Package (collapsed) | 包（折叠） | 紧凑表示 |
| Note | 注释 | 折角矩形 |
| Composite | 组合结构 | 复合结构容器 |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 | 方向说明 |
|------------|------|------|------|---------|
| Inheritance | 泛化/继承 | 实线 | 空心三角 | 子类 → 父类 |
| Interface Realization | 接口实现 | 虚线 | 空心三角 | 实现类 → 接口 |
| Association | 关联 | 实线 | 无 | 双向关联 |
| Directed Association | 有向关联 | 实线 | 开放箭头 | 源 → 目标 |
| Aggregation | 聚合 | 实线 | 空心菱形 | 部分 → 整体（菱形在整体端） |
| Composition | 组合 | 实线 | 实心菱形 | 部分 → 整体（菱形在整体端） |
| Dependency | 依赖 | 虚线 | 开放箭头 | 依赖方 → 被依赖方 |

> **所有连接器**均使用 `connector_stencil="USTRME_M.VSSX"`。

### 布局约定

- **方向**：从上到下（父类在上，子类在下）
- **继承层级**：父类居中上方，子类均匀分布在下方
- **节点间距**：水平 2.0 英寸，垂直 1.5 英寸
- **接口**：放置在实现类的上方

---

## 2. UML 序列图 (Sequence Diagram)

### 标准参考

- OMG UML 2.5.1 — Interaction Diagrams
- 描述对象之间的消息交互时序

### 模板

`USEQME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| USEQME_M.VSSX | 序列图全部形状与消息 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Object lifeline | 对象生命线 | 矩形头部 + 虚线 |
| Actor lifeline | 参与者生命线 | 人形图标 + 虚线 |
| Activation | 激活条 | 叠加在生命线上的窄矩形 |
| Loop fragment | 循环片段 | 标记循环区域 |
| Optional fragment | 可选片段 | opt 区域 |
| Alternative fragment | 选择片段 | alt 区域（含多分支） |
| Interaction operand | 交互操作数 | alt 片段的分支分隔 |
| Other fragment | 其他片段 | break/critical/neg 等 |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 | 备注 |
|------------|------|------|------|------|
| Message | 同步消息 | 实线 | 实心箭头 | 调用 |
| Return Message | 返回消息 | 虚线 | 开放箭头 | 返回值 |
| Self Message | 自调用 | 实线 | 实心箭头 | 指向自身的生命线 |
| Asynchronous Message | 异步消息 | 实线 | 开放箭头 | 非阻塞调用 |

> **所有消息**均使用 `connector_stencil="USEQME_M.VSSX"`。

### 布局约定

- **方向**：参与者从左到右排列，时间从上到下流动
- **生命线间距**：等距分布，推荐 2.0 ~ 2.5 英寸
- **消息水平对齐**：同一消息的起止 Y 坐标相同
- **消息垂直间距**：0.5 ~ 0.75 英寸

---

## 3. UML 活动图 (Activity Diagram)

### 标准参考

- OMG UML 2.5.1 — Activity Diagrams
- 描述业务流程或算法中的活动流

### 模板

`UACTME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| UACTME_M.VSSX | 活动图形状 |
| XFUNC_M.VSSX | 跨职能泳道（可选） |

### 节点形状 (Shapes)

| Master 名称 | Stencil | 用途 | 备注 |
|------------|---------|------|------|
| Initial node | UACTME_M.VSSX | 初始节点 | 实心圆 |
| Action | UACTME_M.VSSX | 动作/活动 | 圆角矩形 |
| Decision | UACTME_M.VSSX | 决策 | 菱形 |
| Merge Node | UACTME_M.VSSX | 合并节点 | 菱形 |
| Fork node | UACTME_M.VSSX | 分叉节点 | 粗线条（并行开始） |
| Join node | UACTME_M.VSSX | 汇合节点 | 粗线条（并行结束） |
| Final node | UACTME_M.VSSX | 终止节点 | 圆内圈实心圆 |
| Note | UACTME_M.VSSX | 注释 | — |
| Swimlane | UACTME_M.VSSX | 泳道（水平） | — |
| Swimlane (vertical) | UACTME_M.VSSX | 泳道（垂直） | — |

### 边/连接器 (Edges)

| 方式 | 语义 | 备注 |
|------|------|------|
| AutoConnect | 控制流 | 活动之间使用默认箭头连接 |

### 布局约定

- **方向**：从上到下
- **Decision 分支**：Yes/No 分别向左右
- **Fork/Join**：水平放置，宽度与并行分支总宽度对齐
- **节点间距**：垂直 1.0 ~ 1.5 英寸

---

## 4. UML 状态机图 (State Machine Diagram)

### 标准参考

- OMG UML 2.5.1 — State Machine Diagrams
- 描述对象的生命周期状态与转换

### 模板

`USTAME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| USTAME_M.VSSX | 状态机图全部形状 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| State | 简单状态 | 圆角矩形 |
| State with internal behavior | 带内部行为的状态 | 含 entry/do/exit 分区 |
| Composite state | 复合状态 | 包含子状态的容器 |
| Submachine state | 子状态机 | 引用其他状态机 |
| Initial state | 初始状态 | 实心圆 |
| Final state | 终止状态 | 圆内实心圆 |
| Choice | 选择伪状态 | 菱形 |
| Note | 注释 | — |

### 边/连接器 (Edges)

| 方式 | 语义 | 备注 |
|------|------|------|
| AutoConnect | 状态转换 | 在连接线上添加文本标注触发事件/条件/动作 |

### 布局约定

- **方向**：从上到下（Initial state 在顶部，Final state 在底部）
- **节点间距**：1.5 英寸
- **复合状态**：内部子状态使用缩进布局

---

## 5. UML 用例图 (Use Case Diagram)

### 标准参考

- OMG UML 2.5.1 — Use Case Diagrams
- 描述系统功能与参与者的交互

### 模板

`UUSEME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| UUSEME_M.VSSX | 用例图全部形状与连接器 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Actor | 参与者 | 人形图标 |
| Use Case | 用例 | 椭圆形 |
| Subsystem | 子系统边界 | 矩形容器 |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 | 方向说明 |
|------------|------|------|------|---------|
| Association | 关联 | 实线 | 无 | 参与者与用例之间 |
| Generalization | 泛化 | 实线 | 空心三角 | 子用例/子参与者 → 父级 |
| Include | 包含 | 虚线 | 开放箭头 | 基础用例 → 被包含用例；标注 `<<include>>` |
| Extend | 扩展 | 虚线 | 开放箭头 | 扩展用例 → 基础用例；标注 `<<extend>>` |
| Dependency | 依赖 | 虚线 | 开放箭头 | 通用依赖 |

> **所有连接器**均使用 `connector_stencil="UUSEME_M.VSSX"`。

### 布局约定

- **参与者位置**：主要参与者在左侧，次要参与者/外部系统在右侧
- **用例位置**：居中，包含在 Subsystem 边界内
- **间距**：用例之间 1.5 英寸

---

## 6. UML 组件图 (Component Diagram)

### 标准参考

- OMG UML 2.5.1 — Component Diagrams
- 描述软件组件及其依赖关系

### 模板

`UCOMME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| UCOMME_M.VSSX | 组件图全部形状与连接器 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Component | 组件 | 带组件图标的矩形 |
| Provided Interface | 提供的接口 | 棒棒糖符号 (lollipop) |
| Required Interface | 需要的接口 | 半圆符号 (socket) |
| Package | 包 | 容器 |
| Note | 注释 | — |
| Composite | 组合结构 | 容器 |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 |
|------------|------|------|------|
| Association | 关联 | 实线 | 无 |
| Directed Association | 有向关联 | 实线 | 开放箭头 |
| Dependency | 依赖 | 虚线 | 开放箭头 |
| Aggregation | 聚合 | 实线 | 空心菱形 |
| Composition | 组合 | 实线 | 实心菱形 |

> **所有连接器**均使用 `connector_stencil="UCOMME_M.VSSX"`。

### 布局约定

- **方向**：自由布局，高层组件在上
- **接口**：Provided/Required Interface 放置在组件边缘

---

## 7. UML 部署图 (Deployment Diagram)

### 标准参考

- OMG UML 2.5.1 — Deployment Diagrams
- 描述系统的物理部署拓扑

### 模板

`UDEPME_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| UDEPME_M.VSSX | 部署图全部形状与连接器 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Node | 节点 | 3D 立方体，表示物理/虚拟主机 |
| Node Instance | 节点实例 | 带下划线名称 |
| Artifact | 制品 | 文件/JAR/DLL 等可部署单元 |
| Artifact Instance | 制品实例 | — |
| Component | 组件 | 嵌套在节点内 |
| Component Instance | 组件实例 | — |
| Deployment Spec | 部署规格 | 配置描述 |
| Deployment Spec Instance | 部署规格实例 | — |
| Package | 包 | 容器 |
| Provided Interface | 提供的接口 | — |
| Required Interface | 需要的接口 | — |
| Note | 注释 | — |
| Diagram Overview | 图总览 | — |
| Composite | 组合结构 | — |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 |
|------------|------|------|------|
| Association | 通信路径 | 实线 | 无 |
| Directed Association | 有向通信 | 实线 | 开放箭头 |
| Dependency | 依赖 | 虚线 | 开放箭头 |
| Aggregation | 聚合 | 实线 | 空心菱形 |
| Composition | 组合 | 实线 | 实心菱形 |
| Deploy | 部署 | 虚线 | 开放箭头 |
| Manifest | 表现 | 虚线 | 开放箭头 |

> **所有连接器**均使用 `connector_stencil="UDEPME_M.VSSX"`。

### 布局约定

- **方向**：自由布局
- **嵌套**：Artifact/Component 放置在 Node 内部
- **节点间距**：2.0 ~ 3.0 英寸

---

## 8. 基本流程图 (Flowchart)

### 标准参考

- ISO 5807 — 信息处理流程图标准
- ANSI Flowchart Standard

### 模板

`BASFLO_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| BASFLO_M.VSSX | 基本流程图（推荐） |
| FLOSHP_M.VSSX | 详细流程图（56 种扩展形状） |

### 节点形状 (Shapes) — BASFLO_M.VSSX

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Start/End | 起止符 | 圆角矩形/胶囊形 |
| Process | 处理步骤 | 矩形 |
| Decision | 判定 | 菱形 |
| Subprocess | 子流程/预定义处理 | 双竖线矩形 |
| Document | 文档 | 波浪底边矩形 |
| Data | 数据 (I/O) | 平行四边形 |
| Database | 数据库 | 圆柱体 |
| External Data | 外部数据 | — |
| On-page reference | 页内引用 | 小圆形 |
| Off-page reference | 跨页引用 | 五边形 |

### 边/连接器 (Edges)

| 方式 | Master 名称 | Stencil | 备注 |
|------|------------|---------|------|
| AutoConnect | — | — | 推荐，简单箭头 |
| Stencil | Dynamic connector | BASFLO_M.VSSX | 需要更多控制时使用 |

### 布局约定

- **方向**：从上到下
- **Decision 分支**：Yes 向下，No 向右（或反之，保持一致即可）
- **合流**：分支最终汇入同一路径
- **节点间距**：垂直 1.0 ~ 1.5 英寸，水平 2.0 英寸
- **对齐**：主流程居中对齐

---

## 9. 跨职能流程图 (Cross-Functional Flowchart / Swimlane)

### 标准参考

- BPMN 泳道映射
- 企业流程建模规范

### 模板

`XFUNC_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| XFUNC_M.VSSX | 泳道容器 |
| BASFLO_M.VSSX | 流程形状 |

### 节点形状 (Shapes)

泳道容器：

| Master 名称 | Stencil | 用途 |
|------------|---------|------|
| CFF Container | XFUNC_M.VSSX | 跨职能流程图容器 |
| Swimlane | XFUNC_M.VSSX | 泳道（水平） |
| Swimlane (vertical) | XFUNC_M.VSSX | 泳道（垂直） |
| Separator | XFUNC_M.VSSX | 泳道分隔线 |
| Separator (vertical) | XFUNC_M.VSSX | 泳道分隔线（垂直） |
| Swimlane List | XFUNC_M.VSSX | 泳道列表容器 |
| Phase List | XFUNC_M.VSSX | 阶段列表 |

流程形状使用 BASFLO_M.VSSX（参见第 8 节）。

### 边/连接器 (Edges)

| 方式 | 备注 |
|------|------|
| AutoConnect | 泳道内和跨泳道的流程连接 |

### 布局约定

- **方向**：泳道水平排列时，流程从上到下；泳道垂直排列时，流程从左到右
- **泳道宽度**：根据内容自适应，推荐最小 2.0 英寸
- **跨泳道连线**：保持水平/垂直正交

---

## 10. BPMN 流程图 (Business Process Model and Notation)

### 标准参考

- BPMN 2.0 (OMG)
- 语义严格的业务流程建模标准

### 模板

`BPMN_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| BPMN_M.VSSX | BPMN 全部形状和连接器 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Start Event | 开始事件 | 细线圆形 |
| Intermediate Event | 中间事件 | 双线圆形 |
| End Event | 结束事件 | 粗线圆形 |
| Task | 任务 | 圆角矩形 |
| Gateway | 网关 | 菱形（排他/并行/包容） |
| Collapsed Sub-Process | 折叠子流程 | 带 + 号的圆角矩形 |
| Expanded Sub-Process | 展开子流程 | 大圆角矩形容器 |
| Data Object | 数据对象 | 折角文档 |
| Data Store | 数据存储 | 圆柱体 |
| Message | 消息 | 信封图标 |
| Group | 分组 | 虚线圆角矩形 |
| Text Annotation | 文本注释 | 开放方括号 + 文字 |
| Pool / Lane | 池/泳道 | 带标题的容器 |

### 边/连接器 (Edges)

| Master 名称 | 语义 | 线型 | 箭头 | 使用场景 |
|------------|------|------|------|---------|
| Sequence Flow | 顺序流 | 实线 | 实心箭头 | 同一池内的活动连接 |
| Message Flow | 消息流 | 虚线 | 开放箭头 | 跨池的消息传递 |
| Association | 关联 | 点线 | 无/开放箭头 | 连接 Data Object/Annotation |

> **所有连接器**均使用 `connector_stencil="BPMN_M.VSSX"`。

### 布局约定

- **方向**：从左到右（池内）
- **池排列**：上下堆叠
- **网关**：在分支点使用，确保每个出口有条件标注
- **消息流**：仅跨池使用，不可在同一池内使用

---

## 11. 数据库 ER 图 — Crow's Foot 记法

### 标准参考

- Entity-Relationship Model
- Crow's Foot Notation（IE 记法）

### 模板

`DBCROW_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| DBCROW_M.VSSX | Crow's Foot 记法 ER 图 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Entity | 实体 | 表名标题框 |
| Entity With Attributes | 带属性的实体 | 包含属性列表 |
| Attribute | 属性 | 放置在实体内 |
| Primary Key Attribute | 主键属性 | 带下划线 |
| Primary Key Separator | 主键分隔线 | 分隔 PK 与普通属性 |

### 边/连接器 (Edges)

| Master 名称 | Stencil | 语义 | 备注 |
|------------|---------|------|------|
| Relationship | DBCROW_M.VSSX | 关系 | 线端自带 Crow's Foot 符号表示基数 |

### 布局约定

- **方向**：自由布局，网格对齐
- **实体间距**：2.0 ~ 3.0 英寸
- **关系线**：保持正交走线

---

## 12. 数据库 ER 图 — Chen 记法

### 标准参考

- Peter Chen (1976) 原始 ER 模型
- 学术教学常用

### 模板

`DBCHEN_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| DBCHEN_M.VSSX | Chen 记法 ER 图 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Entity | 实体 | 矩形 |
| Weak Entity | 弱实体 | 双线矩形 |
| Associative Entity  | 关联实体 | **注意：名称末尾有空格** |
| Attribute | 属性 | 椭圆 |
| Primary Key attribute  | 主键属性 | 带下划线椭圆；**名称末尾有空格** |
| Multi-valued Attribute  | 多值属性 | 双线椭圆；**名称末尾有空格** |
| Derived Attribute | 派生属性 | 虚线椭圆 |

### 边/连接器 (Edges)

| Master 名称 | Stencil | 语义 | 备注 |
|------------|---------|------|------|
| Relationship | DBCHEN_M.VSSX | 关系 | 菱形符号 |
| Identifying Relationship | DBCHEN_M.VSSX | 标识关系 | 双线菱形 |
| Relationship Connector | DBCHEN_M.VSSX | 关系连接线 | 连接属性/实体到关系 |

### 布局约定

- **方向**：自由布局
- **属性放射**：属性围绕实体辐射排列
- **关系菱形**：放置在连接的实体之间

---

## 13. 网络拓扑图 (Network Diagram)

### 标准参考

- Cisco Systems 图标规范（事实标准）
- ITU-T 网络表示建议

### 模板

`NETW_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| PERIPH_M.VSSX | 基本网络与外设（推荐通用场景） |
| NETSYM_M.VSSX | 网络设备符号 |
| CISCONETWORKSHAPES_M.VSSX | Cisco 专用图标（292 种） |
| NETLOC_M.VSSX | 网络位置（Cloud, Building 等） |
| NETLME_M.VSSX | 网络逻辑位置 |
| COMPS_M.VSSX | 计算机与显示器 |
| SERVER_M.VSSX | 服务器类型 |

### 常用节点形状 (Shapes) — PERIPH_M.VSSX

| Master 名称 | 用途 |
|------------|------|
| Server | 服务器 |
| Router | 路由器 |
| Switch | 交换机 |
| Firewall | 防火墙 |
| Hub | 集线器 |
| Bridge | 网桥 |
| Modem | 调制解调器 |
| Wireless access point | 无线接入点 |
| Ethernet | 以太网总线 |
| Ring network | 环形网络 |
| Mainframe | 大型机 |
| Printer | 打印机 |
| User | 用户 |
| Legend | 图例 |

### 常用节点形状 — NETLOC_M.VSSX / NETLME_M.VSSX

| Master 名称 | 用途 |
|------------|------|
| Cloud | 云/互联网 |
| Building | 办公楼 |
| Data Center | 数据中心 |

### 边/连接器 (Edges)

| 方式 | 备注 |
|------|------|
| AutoConnect | 网络链路，通常使用无箭头的直线连接 |
| Dynamic connector | PERIPH_M.VSSX 内置连接器 |

### 布局约定

- **方向**：自由布局或分层布局
- **核心设备**：路由器/交换机居中
- **终端设备**：围绕核心设备分布
- **Cloud 图标**：表示外部网络/Internet，放在图表上方或边缘
- **链路标注**：在连接线上标注带宽/协议

---

## 14. 云架构图 — Azure

### 标准参考

- Microsoft Azure 图标体系
- 云架构设计最佳实践

### 模板

`AZUREDIAGRAMS_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| AZURECOMPUTE_M.VSSX | 计算（VM, App Service, K8s 等） |
| AZURENETWORKING_M.VSSX | 网络（VNet, LB, DNS 等） |
| AZURESTORAGE_M.VSSX | 存储 |
| AZUREDATABASES_M.VSSX | 数据库 |
| AZURESECURITY_M.VSSX | 安全 |
| AZUREIDENTITY_M.VSSX | 身份认证 |
| AZUREIOT_M.VSSX | IoT |
| AZUREINTEGRATION_M.VSSX | 集成服务 |
| AZUREAPPSERVICES_M.VSSX | 应用服务 |
| AZURECONTAINERS_M.VSSX | 容器 |
| AZUREDEVOPS_M.VSSX | DevOps |
| AZUREAIMACHINELEARNING_M.VSSX | AI/机器学习 |
| AZUREANALYTICS_M.VSSX | 分析 |
| AZUREMONITOR_M.VSSX | 监控 |
| AZUREMANAGEMENTGOVERNANCE_M.VSSX | 管理与治理 |
| AZUREGENERAL_M.VSSX | 通用符号 |
| AZUREGENERALSYMBOLS_M.VSSX | 通用标记 |
| AZURESTACK_M.VSSX | Azure Stack |
| AZUREWEB_M.VSSX | Web 服务 |

### 常用形状（按类别列举代表性 Master）

**计算 (AZURECOMPUTE_M.VSSX)**：Virtual Machine, App Services, Function Apps, Kubernetes Services, VM Scale Sets

**网络 (AZURENETWORKING_M.VSSX)**：Virtual Networks, Load Balancers, Application Security Groups, CDN Profiles, DNS Zones, Front Doors, Public IP Addresses

**存储 (AZURESTORAGE_M.VSSX)**：按需使用 `list_masters` 查询

**数据库 (AZUREDATABASES_M.VSSX)**：按需使用 `list_masters` 查询

### 边/连接器 (Edges)

| 方式 | 备注 |
|------|------|
| AutoConnect | 表示数据流/网络连接 |

### 布局约定

- **方向**：分层布局（前端/应用/数据 从上到下或从左到右）
- **分组**：使用矩形框表示 Resource Group / VNet / Subnet
- **Azure 图标大小**：推荐 0.5 x 0.5 英寸
- **间距**：1.5 ~ 2.0 英寸

---

## 15. 云架构图 — AWS

### 标准参考

- Amazon Web Services 架构图标标准

### 模板

`AWSDIAGRAMS_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| AWSCOMPUTE_M.VSSX | 计算 (EC2, Lambda 等) |
| AWSDB_M.VSSX | 数据库 (RDS, DynamoDB 等) |
| AWSNETCONTENTDELIVERY_M.VSSX | 网络与内容分发 (VPC, CloudFront 等) |
| AWSSTORAGE_M.VSSX | 存储 (S3, EBS 等) |
| AWSSECURITYCOMPLIANCE_M.VSSX | 安全与合规 (IAM, WAF 等) |
| AWSANALYTICS_M.VSSX | 分析 |
| AWSIOT_M.VSSX | IoT |
| AWSML_M.VSSX | 机器学习 |
| AWSCONTAINERS_M.VSSX | 容器 (ECS, EKS 等) |
| AWSDEVTOOLS_M.VSSX | 开发工具 |
| AWSAPPINT_M.VSSX | 应用集成 (SQS, SNS 等) |
| AWSMGMTGOV_M.VSSX | 管理与治理 |
| AWSMIGRATIONTRANSFER_M.VSSX | 迁移与传输 |
| AWSMOBILE_M.VSSX | 移动服务 |
| AWSMEDIASERV_M.VSSX | 媒体服务 |
| AWSGEN_M.VSSX | 通用符号 |
| AWSBLK_M.VSSX | 通用块 |

### 边/连接器 (Edges)

| 方式 | 备注 |
|------|------|
| AutoConnect | 表示数据流/网络连接 |

### 布局约定

- **方向**：分层布局
- **分组**：使用矩形框表示 Region / VPC / Subnet / AZ
- **AWS 图标大小**：推荐 0.5 x 0.5 英寸
- **间距**：1.5 ~ 2.0 英寸

---

## 16. Kubernetes 架构图

### 标准参考

- Kubernetes 官方架构概念
- CNCF 图标体系

### 模板

`AZUREDIAGRAMS_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| KUBERNETESVISIOSTENCIL_M.VSSX | Kubernetes 全部图标 |

### 常用节点形状 (Shapes)

| Master 名称 | 用途 |
|------------|------|
| pod | Pod |
| deploy | Deployment |
| rs | ReplicaSet |
| ds | DaemonSet |
| sts | StatefulSet |
| job | Job |
| cronjob | CronJob |
| svc | Service |
| ing | Ingress |
| ep | Endpoint |
| node | Node |
| ns | Namespace |
| pv | PersistentVolume |
| pvc | PersistentVolumeClaim |
| sc | StorageClass |
| secret | Secret |
| cm | ConfigMap |
| sa | ServiceAccount |
| hpa | HorizontalPodAutoscaler |
| netpol | NetworkPolicy |
| control-plane | Control Plane |
| api | API Server |
| etcd | etcd |
| sched | Scheduler |
| kubelet | kubelet |
| k-proxy | kube-proxy |

### 边/连接器 (Edges)

| 方式 | 备注 |
|------|------|
| AutoConnect | 组件间关系连接 |

### 布局约定

- **层级嵌套**：Cluster > Node > Namespace > Deployment > Pod
- **Control Plane**：放在图表上方或左侧
- **Worker Node**：并排放在下方
- **使用矩形框**：表示 Namespace 和 Node 边界

---

## 17. 组织结构图 (Org Chart)

### 标准参考

- 无统一国际标准（企业内部规范为主）

### 模板

`ORGCH_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| ORGCH_M.VSSX | 完整组织结构图（推荐） |
| BASICORGCHART_M.VSSX | 简化版 |

### 节点形状 (Shapes) — ORGCH_M.VSSX

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Executive | 高管 | 最高层级 |
| Manager | 经理 | 中层管理 |
| Position | 职位 | 普通岗位 |
| Consultant | 顾问 | 外部/临时角色 |
| Vacancy | 空缺 | 待招聘岗位 |
| Assistant | 助理 | 侧挂在管理者旁 |
| Staff | 员工 | 基层 |
| Team frame | 团队框 | 分组容器 |
| Multiple shapes | 多个职位 | 批量表示 |
| Three positions | 三个职位 | 紧凑表示 |
| Title/Date | 标题/日期 | 图表标题 |
| Title | 标题 | — |

### 边/连接器 (Edges)

| Master 名称 | Stencil | 语义 | 备注 |
|------------|---------|------|------|
| Dynamic connector | ORGCH_M.VSSX | 直属汇报 | 实线连接 |
| Dotted-line report | ORGCH_M.VSSX | 虚线汇报 | 矩阵管理关系 |

或使用 AutoConnect（默认实线连接）。

### 布局约定

- **方向**：从上到下
- **层级对齐**：同级别水平对齐
- **Assistant**：偏移挂在管理者侧面
- **节点间距**：水平 1.5 英寸，垂直 1.0 英寸

---

## 18. 数据流图 (Data Flow Diagram)

### 标准参考

- Yourdon-DeMarco 记法
- Gane-Sarson 记法

### 模板

`DATFLO_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| DATFLO_M.VSSX | 数据流图全部形状 |

### 节点形状 (Shapes)

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Data process | 数据处理 | 圆形 |
| External interactor | 外部实体 | 矩形 |
| Data store | 数据存储 | 开放端矩形 |
| Object | 对象 | 通用对象 |
| Multiple process | 多重处理 | — |
| Oval process | 椭圆处理 | — |

### 边/连接器 (Edges)

| Master 名称 | Stencil | 语义 | 备注 |
|------------|---------|------|------|
| Center to center 1 | DATFLO_M.VSSX | 数据流 | 带箭头的连接线 |
| Center to center 2 | DATFLO_M.VSSX | 数据流（备选） | — |
| Dynamic connector | DATFLO_M.VSSX | 通用连接 | — |

或使用 AutoConnect。

### 布局约定

- **方向**：自由布局
- **外部实体**：放在图表边缘
- **数据存储**：放在右侧或底部
- **分层**：Context Diagram (Level 0) → Level 1 → Level 2 逐层细化

---

## 19. 因果图 / 鱼骨图 (Cause and Effect / Fishbone)

### 标准参考

- 石川馨 (Kaoru Ishikawa) 因果分析法
- 常用 6M 分类：Man, Machine, Material, Method, Measurement, Mother Nature

### 模板

`CAUSEF_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| CAUSEF_M.VSSX | 因果图形状 |

### 布局约定

- **方向**：从右到左，"鱼头"（效果/问题）在右侧
- **主骨架**：水平主线
- **主因分支**：从主线斜向上/下分出
- **子因分支**：从主因分支进一步细分

> 使用 `list_masters("CAUSEF_M.VSSX")` 获取具体可用 Master 名称。

---

## 20. 值流图 (Value Stream Mapping)

### 标准参考

- 精益制造 (Lean Manufacturing)
- 丰田生产系统

### 模板

`VSM_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| VSM_M.VSSX | 值流图形状 |

### 布局约定

- **方向**：从左到右（物料流与信息流）
- **物料流**：下方，实线箭头
- **信息流**：上方，虚线箭头/闪电线
- **时间线**：底部，记录 CT/LT

> 使用 `list_masters("VSM_M.VSSX")` 获取具体可用 Master 名称。

---

## 21. 事件驱动过程链 (EPC — Event-driven Process Chain)

### 标准参考

- ARIS 方法论 (Prof. August-Wilhelm Scheer)
- SAP 业务流程建模

### 模板

`EPC_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| EPC_M.VSSX | EPC 图形状 |

### 布局约定

- **方向**：从上到下
- **事件-功能交替**：事件（六边形）与功能（圆角矩形）交替排列
- **逻辑连接**：AND/OR/XOR 操作符

> 使用 `list_masters("EPC_M.VSSX")` 获取具体可用 Master 名称。

---

## 22. 块图 (Block Diagram)

### 标准参考

- 通用系统描述
- 适用于概念性架构表达

### 模板

`BLOCK_M.VSTX` — 通过 `create_diagram()` 自动应用

### Stencil 文件

| Stencil 文件名 | 用途 |
|---------------|------|
| BLOCK_M.VSSX | 基本块图（推荐） |
| BLOCK3_M.VSSX | 3D 块图 |
| BLOCKP_M.VSSX | 透视块图 |

### 常用节点形状 (Shapes) — BLOCK_M.VSSX

| Master 名称 | 用途 | 备注 |
|------------|------|------|
| Box | 块/框 | 基本矩形 |
| Circle | 圆形 | — |
| Diamond | 菱形 | — |
| Arrow box | 箭头框 | 单向 |
| Double Arrow Box | 双箭头框 | 双向 |
| Quad Arrow Box | 四向箭头框 | — |
| Auto-height box | 自动高度框 | 文本越多越高 |
| Auto-size box | 自动大小框 | — |
| 3-D box | 3D 框 | — |
| 3-D Circle | 3D 圆形 | — |
| Layered Box | 分层框 | 表示多实例/栈 |
| Concentric layer 1/2/3 | 同心圆层 | 洋葱圈模型 |
| Concentric center | 同心圆中心 | — |
| Partial layer 1/2/3/4 | 扇环层 | 饼图式分区 |

### 常用连接器 — BLOCK_M.VSSX

| Master 名称 | 用途 |
|------------|------|
| Dynamic connector | 动态连接线 |
| Line-curve connector | 直线-曲线连接 |
| Dotted line | 虚线 |
| Mid-arrow | 中间箭头线 |
| Arced arrow | 弧形箭头 |
| Dot & arrow | 点箭头 |
| Single arrowhead | 单箭头 |
| Double arrowhead | 双箭头 |
| 1-D single | 一维单向箭头 |
| 1-D double | 一维双向箭头 |
| 2-D single | 二维单向箭头 |
| 2-D double | 二维双向箭头 |
| Curved arrow | 曲线箭头 |

### 布局约定

- **方向**：自由布局，常用从左到右或从上到下
- **层次表达**：使用 Layered Box 或 Concentric 系列
- **节点间距**：1.5 ~ 2.0 英寸

---

## 附录 A: Stencil 快速查找表

| Stencil 文件名 | 类别 | 适用图表类型 |
|---------------|------|------------|
| USTRME_M.VSSX | UML | 类图 |
| USEQME_M.VSSX | UML | 序列图 |
| UACTME_M.VSSX | UML | 活动图 |
| USTAME_M.VSSX | UML | 状态机图 |
| UUSEME_M.VSSX | UML | 用例图 |
| UCOMME_M.VSSX | UML | 组件图 |
| UDEPME_M.VSSX | UML | 部署图 |
| UCMNME_M.VSSX | UML | 通信图 |
| BASFLO_M.VSSX | 流程图 | 基本流程图, 跨职能流程图 |
| FLOSHP_M.VSSX | 流程图 | 详细流程图（扩展形状） |
| XFUNC_M.VSSX | 流程图 | 跨职能流程图（泳道） |
| BPMN_M.VSSX | BPMN | BPMN 业务流程图 |
| DBCROW_M.VSSX | 数据库 | ER 图 — Crow's Foot 记法 |
| DBCHEN_M.VSSX | 数据库 | ER 图 — Chen 记法 |
| DBIDEF1X_M.VSSX | 数据库 | ER 图 — IDEF1X 记法 |
| PERIPH_M.VSSX | 网络 | 基本网络拓扑 |
| NETSYM_M.VSSX | 网络 | 网络设备符号 |
| CISCONETWORKSHAPES_M.VSSX | 网络 | Cisco 网络图标 |
| NETLOC_M.VSSX | 网络 | 网络位置（Cloud, Building） |
| NETLME_M.VSSX | 网络 | 网络逻辑位置 |
| COMPS_M.VSSX | 网络 | 计算机与显示器 |
| SERVER_M.VSSX | 网络 | 服务器类型 |
| AZURECOMPUTE_M.VSSX | 云架构 | Azure 计算 |
| AZURENETWORKING_M.VSSX | 云架构 | Azure 网络 |
| AZURESTORAGE_M.VSSX | 云架构 | Azure 存储 |
| AZUREDATABASES_M.VSSX | 云架构 | Azure 数据库 |
| AZURESECURITY_M.VSSX | 云架构 | Azure 安全 |
| AZUREIDENTITY_M.VSSX | 云架构 | Azure 身份 |
| AZUREIOT_M.VSSX | 云架构 | Azure IoT |
| AZURECONTAINERS_M.VSSX | 云架构 | Azure 容器 |
| AZUREDEVOPS_M.VSSX | 云架构 | Azure DevOps |
| AZUREAIMACHINELEARNING_M.VSSX | 云架构 | Azure AI/ML |
| AZUREANALYTICS_M.VSSX | 云架构 | Azure 分析 |
| AZUREMONITOR_M.VSSX | 云架构 | Azure 监控 |
| AZUREGENERAL_M.VSSX | 云架构 | Azure 通用 |
| AZUREWEB_M.VSSX | 云架构 | Azure Web |
| AWSCOMPUTE_M.VSSX | 云架构 | AWS 计算 |
| AWSDB_M.VSSX | 云架构 | AWS 数据库 |
| AWSNETCONTENTDELIVERY_M.VSSX | 云架构 | AWS 网络 |
| AWSSTORAGE_M.VSSX | 云架构 | AWS 存储 |
| AWSSECURITYCOMPLIANCE_M.VSSX | 云架构 | AWS 安全 |
| AWSCONTAINERS_M.VSSX | 云架构 | AWS 容器 |
| AWSGEN_M.VSSX | 云架构 | AWS 通用 |
| KUBERNETESVISIOSTENCIL_M.VSSX | 云架构 | Kubernetes |
| ORGCH_M.VSSX | 组织 | 组织结构图（完整） |
| BASICORGCHART_M.VSSX | 组织 | 组织结构图（简化） |
| DATFLO_M.VSSX | 数据流 | 数据流图 |
| CAUSEF_M.VSSX | 质量管理 | 因果图/鱼骨图 |
| VSM_M.VSSX | 精益 | 值流图 |
| EPC_M.VSSX | 流程 | 事件驱动过程链 |
| BLOCK_M.VSSX | 块图 | 基本块图 |
| BLOCK3_M.VSSX | 块图 | 3D 块图 |
| BLOCKP_M.VSSX | 块图 | 透视块图 |
| BASIC_M.VSSX | 通用 | 基本形状 |
| CONNEC_M.VSSX | 通用 | 连接器 |

---

## 附录 B: 通用连接器参考 (CONNEC_M.VSSX)

CONNEC_M.VSSX 包含 69 种连接器，可用于任何图表类型。以下为常用类型：

- **Dynamic connector** — 动态连接线（自动路由）
- **Line connector** — 直线连接
- **Line-curve connector** — 直线-曲线
- **Elbow connector** — 直角弯折连接
- 各种箭头样式、虚线、波浪线等

使用 `list_masters("CONNEC_M.VSSX")` 获取完整列表。
