---
name: talaria
description: Dispatch delegated agent tasks through Claude Code CLI backends. Use when any subtask should run through claude -p instead of your own API integration.
version: 2.0.0
author: ZeroWaves
metadata:
  hermes:
    tags: [dispatch, session-billing, subagent, claude-p, cost-optimization]
    related_skills: [claude-code, claude-session-subagent, claude-code-billing-modes]
---

# Talaria — Claude Code Task Dispatch

Hermes' winged sandals. Routes delegated work through `claude -p` so Claude Code handles the task instead of your own API integration. On Pro/Max/Team subscriptions, that usage hits included Claude plan limits first. It is not a guaranteed bypass for paid extra usage once those limits are exhausted.

## Billing behavior

- `claude auth login` / `authMethod: claude.ai` -> included Claude plan limits first
- `ANTHROPIC_API_KEY` set -> direct API billing
- included limits exhausted + **extra usage** enabled -> paid extra usage can kick in
- there is no verified Talaria-specific bypass that guarantees unlimited zero-cost overage

If zero overage matters more than continuity, disable **extra usage** in Claude Settings > Usage and wait for limits to reset when you hit the cap.

## When to Use

**Default operating mode: understand → plan → dispatch → review → report.**

The main agent (Wesley) should use talaria for the majority of token-heavy work. The main loop is cheap (reading context, planning, reviewing output). The execution is where 80% of tokens go — and that should flow through talaria.

Dispatch to talaria for:
- **Coding subtasks** — fix bugs, add features, write tests, refactor
- **Writing** — READMEs, skills, plans, changelogs, docs, any text generation
- **Code review** — pipe diffs with review skills loaded
- **Codebase analysis** — "read this repo and tell me what's going on"
- **Knowledge extraction** — summarize repos, analyze patterns, document architecture
- **Research synthesis** — after web searches, dispatch the synthesis step
- **Plan generation** — dispatch with project skills to generate implementation plans
- **Test writing** — dispatch with testing skill
- **Obsidian articles** — dispatch with brain skill loaded
- **Batch operations** — multiple independent tasks via `talaria batch`
- **Cron jobs** — recurring tasks on schedule, all session-billed

**Use low effort for:** file reading, simple analysis, documentation generation, formatting
**Use medium effort for:** most coding tasks, refactoring, test writing, standard dispatches (this is the default)
**Use high/max/xhigh effort for:** architecture decisions, complex debugging, security reviews, design work
**Use adaptive/auto for:** cases where you want Claude to choose the effort automatically without Talaria passing an explicit effort flag

## When NOT to Use

- Main conversation loop (that's the agent framework's job)
- Tasks needing real-time streaming interaction with the user
- Tasks needing framework-specific tools (Discord MCP, memory, skills management)
- Single-file surgical edits (one patch call is cheaper than dispatch overhead)
- Quick one-liner checks (one grep, one file read)

**3+ file operations rule:** If a task involves 3 or more file reads/writes/patches, dispatch it. The overhead of spawning talaria is less than the API cost of 3+ tool calls. For 1-2 simple edits, just do them directly.

## Requirements

- Python 3.9+
- Claude Code CLI installed and authenticated (`claude auth login`)
- **Active Claude subscription (Pro, Max, or Team)** — this is not optional

## CLI Commands

### Dispatch a Task

```bash
talaria run "Fix the type errors in src/auth.ts" --workdir ~/project

# With post-dispatch verification
talaria run "Add unit tests" --workdir ~/project --verify "pytest --tb=short"

# Specific model (default: latest Opus alias)
talaria run "Redesign the auth flow" --workdir ~/project --model sonnet

# Pin a specific Claude release when needed
talaria run "Audit this migration" --workdir ~/project --model opus@4.7

# With skills loaded
talaria run "Fix the auth module" --skill auth-hardening --skill testing

# Git worktree isolation
talaria run "Refactor database layer" --workdir ~/project --worktree

# JSON output for programmatic consumption
talaria run "Fix the bug" --workdir ~/project --json-output
```

### Skills

```bash
# By name (searches ~/.hermes/skills/ and ~/.claude/skills/)
talaria run "Fix auth" --skill auth-hardening --skill testing

# By file path
talaria run "Deploy" --skill ~/my-skills/deploy-checklist.md

# Mix names and paths
talaria run "Full audit" -s auth-hardening -s ~/custom/security.md

# List available skills
talaria skills
```

Skills are injected at the top of the system prompt, before conventions and project context. This is what enables talaria to handle larger tasks like page redesigns — load the design system, component docs, and project conventions and the subagent has everything it needs.

Search order per directory:
1. `{dir}/{name}/SKILL.md`
2. `{dir}/{name}.md`
3. `{dir}/{category}/{name}/SKILL.md`
4. `{dir}/{category}/{name}.md`

### Parallel Dispatch (Batch)

```bash
talaria batch \
  --task "Fix auth bug" --workdir ~/project \
  --task "Write API tests" --workdir ~/project \
  --task "Update README" --workdir ~/project
```

### Resume Failed Sessions

```bash
talaria resume <session-id>
talaria resume <session-id> --task "Continue and also fix the tests"
```

### Health & Monitoring

```bash
talaria doctor              # Verify auth, backend version, disk space
talaria status              # Full status table
talaria usage today         # Today's dispatch count
talaria usage week          # This week's usage
talaria logs today          # List today's dispatches
talaria logs failures       # Show only failed dispatches
```

### Configuration

```bash
talaria config show
talaria config set default_model opus
talaria config set conventions_file ~/rules.md
talaria config set mcp_config ~/mcp-config.json
talaria config set skills_dirs '["~/.hermes/skills", "~/my-skills"]'
```

Config stored at `~/.config/talaria/config.json`.

## Python API

```python
from talaria import dispatch, batch_dispatch, check_health

# Health check
health = check_health()

# Simple dispatch
result = dispatch("Fix the auth bug in src/auth.ts", workdir="/project")

# With skills
result = dispatch(
    "Redesign the dashboard page",
    workdir="/project",
    skills=["lawcoach-linear-redesign", "frontend-design-quality"],
    verify_command="pnpm tsc --noEmit",
)

# Result fields
result.success              # bool
result.result               # str — what the agent did
result.session_id           # str — for resume if needed
result.discoveries          # list[str] — unexpected findings
result.files_modified       # list[str] — what changed
result.verified             # bool|None — verification result
result.error                # str|None — error if failed

# Parallel dispatch
results = batch_dispatch([
    {"task": "Fix auth bug", "workdir": "/project"},
    {"task": "Write tests", "workdir": "/project", "model": "opus"},
])
```

## Hermes Integration

```python
from talaria.hermes import terminal_command, batch_command

# Single task with skills
cmd = terminal_command(
    "Redesign the settings page",
    workdir="~/project",
    skills=["lawcoach-linear-redesign"],
    toolsets=["terminal", "file"],
)
terminal(command=cmd, background=True, notify_on_complete=True)

# Batch
cmd = batch_command([
    {"task": "Fix auth", "workdir": "~/project"},
    {"task": "Write tests", "workdir": "~/project"},
])
terminal(command=cmd, background=True, notify_on_complete=True)
```

## CLI Flags Reference

| Flag | Default | Purpose |
|------|---------|---------|
| `--workdir, -w` | `.` | Working directory for the task |
| `--model, -m` | `opus` | Model to use. `opus`/`sonnet`/`haiku` follow the latest Claude alias; use `family@version` to pin |
| `--effort, -e` | `medium` | Thinking effort (low, medium, high, max, xhigh, adaptive/auto) |
| `--skill, -s` | none | Skill name or path to inject (repeatable) |
| `--max-turns` | `20` | Max agent turns |
| `--timeout, -t` | `300` | Timeout in seconds |
| `--max-budget` | `2.00` | USD ceiling per task |
| `--worktree` | off | Isolate in git worktree |
| `--verify` | none | Post-dispatch verification command |
| `--mcp-config` | none | Path to MCP config file |
| `--context` | none | Additional task context string |
| `--allowed-tools` | Read,Edit,Write,Bash | Comma-separated allowed tools |
| `--retries` | `1` | Retry count for transient failures |
| `--stream` | off | Stream output in real-time |
| `--json-output` | off | Machine-readable JSON output |

## Billing

| Method | Billing |
|--------|---------|
| `claude -p` (talaria) | Included Claude plan limits first on account auth; extra usage can still bill |
| ACP (`--acp --stdio`) | Extra usage - costs money ❌ |
| Agent SDK `query()` | API credits - costs money ❌ |
| Direct API | Per-token + prompt caching ⚠️ |

## Slash Commands (Chat Integration)

Use talaria from any chat platform. Bots pipe raw message text through `talaria command` and get structured responses.

```
/dispatch Fix the auth bug --effort high --skill auth-hardening
/dispatch Refactor the API --model opus --workdir ~/project
/talaria status
/talaria doctor
/talaria cron list
/talaria cron add lint "Run linter" --schedule 2h
/t Fix the bug              (shorthand)
```

Prefixes: `/dispatch`, `/talaria`, `/t` (shorthand)

Bot integration:
```bash
talaria command "/dispatch Fix the auth bug --effort high" --json-output
```

Returns: `{"action", "success", "response", "data"}` — response is markdown-safe for any platform.

Python:
```python
from talaria.commands import parse_command, execute_command

result = execute_command("/dispatch Fix the auth bug")
send_to_chat(result["response"])
```

## Scheduled Jobs (Cron)

Run recurring tasks through Claude Code account auth. Define jobs with interval schedules or cron expressions.

```bash
# Add a recurring job
talaria cron add "lint-check" "Run eslint on src/ and fix" \
  --schedule "every 2h" --workdir ~/project --skill testing

# Cron expression (weekdays at 9am)
talaria cron add "morning-audit" "Run security audit" \
  --schedule "0 9 * * 1-5" --workdir ~/project --skill nextjs-security-hardening

# Manage jobs
talaria cron list
talaria cron run <job-id>       # Manual trigger
talaria cron disable <job-id>
talaria cron enable <job-id>
talaria cron remove <job-id>
talaria cron run-due --dry-run  # Check what's due
talaria cron install            # Get system crontab entry
```

Schedules: `30m`, `every 2h`, `daily`, or standard cron (`0 9 * * *`).
Jobs stored at `~/.config/talaria/crons.json`. Each job supports skills, verify commands, model selection, and all dispatch options.

## Removal

```bash
# Remove all talaria data (config, logs, usage, locks, cache)
talaria purge

# Remove the package
pip uninstall talaria
```

`talaria purge` shows what will be deleted and asks for confirmation. Use `--yes` to skip the prompt.

## Safety Systems

- **Circuit Breaker** — halts after N consecutive failures (default: 3)
- **Cost Spike Detection** — alerts if a dispatch costs 10x the rolling average
- **Directory Locks** — PID-based, auto-releases on crash
- **Worktree Isolation** — dispatched tasks work on a separate branch copy
- **Retry Logic** — exponential backoff on transient errors (auth, network, rate limit)

## File Locations

| Path | Purpose |
|------|---------|
| `~/.config/talaria/config.json` | Configuration |
| `~/.config/talaria/crons.json` | Scheduled job definitions |
| `~/.config/talaria/usage.jsonl` | Usage tracking log |
| `~/.config/talaria/logs/` | Per-dispatch logs (30-day retention) |
| `~/.config/talaria/locks/` | PID-based directory locks |
| `~/.config/talaria/mcp/` | Temp context files |

## Pitfalls

- `--dangerously-skip-permissions` is used by default — the dispatched agent has full file/bash access
- MCP tools need `--allowedTools 'mcp__*'` to be accessible
- Context files go to `~/.config/talaria/mcp/` not `/tmp` for security
- The backend auto-updates - version changes are detected in preflight
- `talaria update` upgrades the package in-place with the current Python interpreter and re-runs `talaria setup --force`
- `adaptive`/`auto` omit the effort flag entirely, and `xhigh` falls back to `max` until Claude CLI exposes it
- Hermes handles process lifecycle (30-min TTL, 64 max, zombie reaping)
- Skills that don't exist cause an immediate error before dispatch (no wasted turns)
- `talaria purge` removes ALL data — there is no undo

## Tool Format Translation

| Hermes Toolset | Claude Code Tools |
|----------------|-------------------|
| `terminal` | `Bash` |
| `file` | `Read`, `Edit`, `Write` |
| `browser` | `WebSearch`, `WebFetch` |
| `web` | `WebSearch`, `WebFetch` |
| `search` | `WebSearch` |
