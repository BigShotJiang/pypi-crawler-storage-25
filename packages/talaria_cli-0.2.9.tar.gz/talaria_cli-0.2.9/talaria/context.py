"""Context injection for dispatched tasks."""
from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Optional

from talaria.config import TalariaConfig


FEEDBACK_INSTRUCTIONS = """
## Required Structured Report

After completing your task, append this structured report at the end of your response:

### Task Result
[Brief description of what you did and whether it succeeded]

### Discoveries
[List anything unexpected you found - new patterns, outdated deps, architectural issues. If nothing, write "None."]

### Files Touched
- Read: [comma-separated list of files you read]
- Modified: [comma-separated list of files you created or changed]

### Convention Proposals
[Any project conventions you noticed that should be documented. If none, write "None."]
""".strip()


def build_context_file(
    config: TalariaConfig,
    workdir: str,
    task_context: Optional[str] = None,
    skills_content: Optional[str] = None,
) -> Optional[str]:
    """
    Build a temporary context file combining skills + conventions + project context + task context.
    Returns path to the temp file, or None if no context to inject.
    """
    sections = []

    # 0. Skills (highest priority - loaded first so the agent sees them early)
    if skills_content:
        sections.append(skills_content)

    # 1. Global conventions
    if config.conventions_file:
        conv_path = Path(config.conventions_file).expanduser()
        if conv_path.exists():
            sections.append(f"# Global Conventions\n\n{conv_path.read_text().strip()}")

    # 2. Project-level context
    wd = Path(workdir).resolve()
    for candidate in [
        wd / "CLAUDE.md",
        wd / ".talaria" / "context.md",
        wd / ".claude" / "CLAUDE.md",
    ]:
        if candidate.exists():
            sections.append(f"# Project Context\n\n{candidate.read_text().strip()}")
            break

    # 3. Task-specific context
    if task_context:
        sections.append(f"# Task Context\n\n{task_context}")

    # 4. Always inject feedback instructions
    sections.append(FEEDBACK_INSTRUCTIONS)

    content = "\n\n---\n\n".join(sections)

    # Write to config dir (not /tmp - may contain conventions with sensitive info)
    from talaria.config import MCP_DIR
    MCP_DIR.mkdir(parents=True, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".md", prefix="ctx-",
        dir=str(MCP_DIR), delete=False,
    )
    tmp.write(content)
    tmp.close()
    return tmp.name
