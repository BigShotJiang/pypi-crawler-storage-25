"""Configuration management for talaria."""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


CONFIG_DIR = Path(os.environ.get("TALARIA_CONFIG", "~/.config/talaria")).expanduser()
CONFIG_FILE = CONFIG_DIR / "config.json"
LOCKS_DIR = CONFIG_DIR / "locks"
LOGS_DIR = CONFIG_DIR / "logs"
MCP_DIR = CONFIG_DIR / "mcp"
USAGE_FILE = CONFIG_DIR / "usage.jsonl"


@dataclass
class TalariaConfig:
    """Global dispatch configuration."""
    default_model: str = "opus"
    default_effort: str = "medium"
    max_parallel: int = 3
    default_max_turns: int = 20
    default_timeout: int = 300
    default_max_budget_usd: float = 2.0
    daily_budget_usd: float = 20.0
    cost_spike_multiplier: float = 10.0
    consecutive_failure_limit: int = 3
    log_retention_days: int = 30
    conventions_file: Optional[str] = None
    mcp_config: Optional[str] = None
    default_allowed_tools: list = field(
        default_factory=lambda: ["Read", "Edit", "Write", "Bash"]
    )
    auth_cache_ttl_seconds: int = 300
    skills_dirs: list = field(
        default_factory=lambda: ["~/.hermes/skills", "~/.claude/skills"]
    )

    @classmethod
    def load(cls) -> "TalariaConfig":
        """Load config from disk, or return defaults."""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    data = json.load(f)
                return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
            except (json.JSONDecodeError, KeyError):
                return cls()
        return cls()

    def save(self) -> None:
        """Persist config to disk."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(asdict(self), f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def set_value(self, key: str, value: Any) -> None:
        if key not in self.__dataclass_fields__:
            raise KeyError(f"Unknown config key: {key}")
        field_type = type(getattr(self, key))
        if field_type is int:
            value = int(value)
        elif field_type is float:
            value = float(value)
        elif field_type is bool:
            value = str(value).lower() in ("true", "1", "yes")
        setattr(self, key, value)
        self.save()


def ensure_dirs() -> None:
    """Create all required directories."""
    for d in [CONFIG_DIR, LOCKS_DIR, LOGS_DIR, MCP_DIR]:
        d.mkdir(parents=True, exist_ok=True)
