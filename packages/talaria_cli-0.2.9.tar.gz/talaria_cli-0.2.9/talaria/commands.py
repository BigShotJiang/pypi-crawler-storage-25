"""Slash command parser for chat platform integration.

Parses raw slash command strings from any platform (Discord, Telegram,
WhatsApp, Slack) into talaria actions. Platform bots just pipe the
message text through and get structured results back.

Usage:
    from talaria.commands import parse_command, execute_command

    # From a Discord/Telegram bot handler:
    result = execute_command("/dispatch Fix the auth bug --effort high --workdir ~/project")
    send_message(result["response"])
"""
from __future__ import annotations

import shlex
from dataclasses import dataclass, field
from typing import Optional

from talaria.effort import effort_choices
from talaria.tracker import REPORTED_USAGE_NOTE, format_reported_usage, format_reported_usage_average


_VALID_EFFORTS = set(effort_choices())
_VALID_EFFORTS_TEXT = "/".join(effort_choices())


# All recognized command prefixes
PREFIXES = ["/talaria", "/dispatch", "/t"]


@dataclass
class ParsedCommand:
    """Result of parsing a slash command."""
    action: str  # run, batch, status, doctor, cron-list, cron-add, etc.
    valid: bool = True
    error: Optional[str] = None
    task: Optional[str] = None
    workdir: str = "."
    model: Optional[str] = None
    effort: Optional[str] = None
    skills: list = field(default_factory=list)
    verify: Optional[str] = None
    allowed_tools: list = field(default_factory=list)
    json_output: bool = False
    # Cron-specific
    cron_name: Optional[str] = None
    cron_schedule: Optional[str] = None
    cron_job_id: Optional[str] = None
    # Batch
    tasks: list = field(default_factory=list)
    # Raw
    raw_input: str = ""


def parse_command(text: str) -> ParsedCommand:
    """
    Parse a raw slash command string into a structured command.

    Supports:
        /dispatch <task> [--flags]
        /talaria run <task> [--flags]
        /talaria status
        /talaria doctor
        /talaria cron list
        /talaria cron add <name> <task> --schedule <schedule>
        /talaria cron run <job_id>
        /talaria cron remove <job_id>
        /talaria cron enable <job_id>
        /talaria cron disable <job_id>
        /t <task>  (shorthand for /dispatch)

    Also supports bare commands without prefix:
        dispatch <task> [--flags]
    """
    text = text.strip()
    original = text

    # Strip prefix
    lower = text.lower()
    prefix_found = False
    for prefix in PREFIXES:
        if lower.startswith(prefix + " ") or lower == prefix:
            text = text[len(prefix):].strip()
            prefix_found = True
            break

    if not prefix_found:
        # Try bare "dispatch" command
        if lower.startswith("dispatch "):
            text = text[len("dispatch"):].strip()
        else:
            return ParsedCommand(
                action="unknown",
                valid=False,
                error="Unrecognized command. Use /dispatch, /talaria, or /t.",
                raw_input=original,
            )

    if not text:
        return ParsedCommand(action="help", raw_input=original)

    # Route to sub-parsers
    lower_text = text.lower()

    # Status commands (no args needed)
    if lower_text in ("status", "st"):
        return ParsedCommand(action="status", raw_input=original)

    if lower_text in ("doctor", "doc", "health"):
        return ParsedCommand(action="doctor", raw_input=original)

    if lower_text in ("help", "h", "?"):
        return ParsedCommand(action="help", raw_input=original)

    if lower_text in ("usage", "usage today"):
        return ParsedCommand(action="usage", raw_input=original)

    if lower_text in ("skills", "skill list"):
        return ParsedCommand(action="skills", raw_input=original)

    if lower_text in ("purge",):
        return ParsedCommand(action="purge", raw_input=original)

    # Cron commands
    if lower_text.startswith("cron"):
        return _parse_cron(text[4:].strip(), original)

    # Run commands — "run <task>" or just "<task>"
    if lower_text.startswith("run "):
        text = text[4:].strip()

    return _parse_run(text, original)


def _parse_run(text: str, original: str) -> ParsedCommand:
    """Parse a run/dispatch command with flags."""
    try:
        parts = shlex.split(text)
    except ValueError:
        # Unbalanced quotes — treat whole thing as task
        return ParsedCommand(
            action="run",
            task=text,
            raw_input=original,
        )

    if not parts:
        return ParsedCommand(
            action="run",
            valid=False,
            error="No task provided.",
            raw_input=original,
        )

    # Extract task (everything before first flag)
    task_parts = []
    flags = []
    in_flags = False
    i = 0
    while i < len(parts):
        if parts[i].startswith("--") or (parts[i].startswith("-") and len(parts[i]) == 2):
            in_flags = True
        if in_flags:
            flags.append(parts[i])
        else:
            task_parts.append(parts[i])
        i += 1

    task = " ".join(task_parts) if task_parts else None

    # Parse flags
    cmd = ParsedCommand(action="run", task=task, raw_input=original)
    i = 0
    while i < len(flags):
        flag = flags[i]
        next_val = flags[i + 1] if i + 1 < len(flags) else None

        if flag in ("--workdir", "-w") and next_val:
            cmd.workdir = next_val
            i += 2
        elif flag in ("--model", "-m") and next_val:
            cmd.model = next_val
            i += 2
        elif flag in ("--effort", "-e") and next_val:
            if next_val.lower() in _VALID_EFFORTS:
                cmd.effort = next_val.lower()
            else:
                cmd.error = f"Invalid effort: {next_val}. Use {_VALID_EFFORTS_TEXT}."
                cmd.valid = False
            i += 2
        elif flag in ("--skill", "-s") and next_val:
            cmd.skills.append(next_val)
            i += 2
        elif flag in ("--verify",) and next_val:
            cmd.verify = next_val
            i += 2
        elif flag == "--json":
            cmd.json_output = True
            i += 1
        else:
            i += 1  # Skip unknown flags

    if not cmd.task:
        cmd.valid = False
        cmd.error = "No task provided."

    return cmd


def _parse_cron(text: str, original: str) -> ParsedCommand:
    """Parse cron sub-commands."""
    text = text.strip()
    lower = text.lower()

    if not text or lower in ("list", "ls"):
        return ParsedCommand(action="cron-list", raw_input=original)

    if lower.startswith("add "):
        return _parse_cron_add(text[4:].strip(), original)

    if lower.startswith("run "):
        job_id = text[4:].strip()
        return ParsedCommand(action="cron-run", cron_job_id=job_id, raw_input=original)

    if lower.startswith("remove ") or lower.startswith("rm "):
        job_id = text.split(None, 1)[1].strip()
        return ParsedCommand(action="cron-remove", cron_job_id=job_id, raw_input=original)

    if lower.startswith("enable "):
        job_id = text[7:].strip()
        return ParsedCommand(action="cron-enable", cron_job_id=job_id, raw_input=original)

    if lower.startswith("disable "):
        job_id = text[8:].strip()
        return ParsedCommand(action="cron-disable", cron_job_id=job_id, raw_input=original)

    if lower in ("run-due", "due"):
        return ParsedCommand(action="cron-run-due", raw_input=original)

    return ParsedCommand(
        action="cron-unknown",
        valid=False,
        error=f"Unknown cron command: {text}. Use: list, add, run, remove, enable, disable.",
        raw_input=original,
    )


def _parse_cron_add(text: str, original: str) -> ParsedCommand:
    """Parse cron add: cron add <name> <task> --schedule <schedule> [flags]."""
    try:
        parts = shlex.split(text)
    except ValueError:
        return ParsedCommand(
            action="cron-add",
            valid=False,
            error="Invalid syntax. Use: cron add <name> <task> --schedule <schedule>",
            raw_input=original,
        )

    if len(parts) < 2:
        return ParsedCommand(
            action="cron-add",
            valid=False,
            error="Usage: cron add <name> <task> --schedule <schedule>",
            raw_input=original,
        )

    cmd = ParsedCommand(action="cron-add", raw_input=original)
    cmd.cron_name = parts[0]

    # Collect task parts and flags
    task_parts = []
    i = 1
    while i < len(parts):
        if parts[i].startswith("--") or (parts[i].startswith("-") and len(parts[i]) == 2):
            break
        task_parts.append(parts[i])
        i += 1

    cmd.task = " ".join(task_parts) if task_parts else None

    # Parse flags
    while i < len(parts):
        flag = parts[i]
        next_val = parts[i + 1] if i + 1 < len(parts) else None

        if flag in ("--schedule", "-s") and next_val:
            cmd.cron_schedule = next_val
            i += 2
        elif flag in ("--model", "-m") and next_val:
            cmd.model = next_val
            i += 2
        elif flag in ("--effort", "-e") and next_val:
            normalized_effort = next_val.lower()
            if normalized_effort not in _VALID_EFFORTS:
                cmd.valid = False
                cmd.error = f"Invalid effort: {next_val}. Use {_VALID_EFFORTS_TEXT}."
                break
            cmd.effort = normalized_effort
            i += 2
        elif flag in ("--skill",) and next_val:
            cmd.skills.append(next_val)
            i += 2
        elif flag in ("--workdir", "-w") and next_val:
            cmd.workdir = next_val
            i += 2
        elif flag in ("--verify",) and next_val:
            cmd.verify = next_val
            i += 2
        else:
            i += 1

    if not cmd.task:
        cmd.valid = False
        cmd.error = "No task provided."
    elif not cmd.cron_schedule:
        cmd.valid = False
        cmd.error = "Schedule required. Use --schedule <interval>."

    return cmd


def execute_command(text: str) -> dict:
    """
    Parse and execute a slash command. Returns a dict with:
    - action: what was attempted
    - success: bool
    - response: human-readable response text (markdown-safe for any platform)
    - data: structured data (for programmatic consumers)
    """
    cmd = parse_command(text)

    if not cmd.valid:
        return {
            "action": cmd.action,
            "success": False,
            "response": f"❌ {cmd.error}",
            "data": {"error": cmd.error},
        }

    if cmd.action == "help":
        return _exec_help()

    if cmd.action == "status":
        return _exec_status()

    if cmd.action == "doctor":
        return _exec_doctor()

    if cmd.action == "usage":
        return _exec_usage()

    if cmd.action == "skills":
        return _exec_skills()

    if cmd.action == "run":
        return _exec_run(cmd)

    if cmd.action == "cron-list":
        return _exec_cron_list()

    if cmd.action == "cron-add":
        return _exec_cron_add(cmd)

    if cmd.action == "cron-run":
        return _exec_cron_run(cmd)

    if cmd.action == "cron-remove":
        return _exec_cron_remove(cmd)

    if cmd.action in ("cron-enable", "cron-disable"):
        return _exec_cron_toggle(cmd)

    return {
        "action": cmd.action,
        "success": False,
        "response": f"❌ Unknown action: {cmd.action}",
        "data": {},
    }


# ─── Executors ──────────────────────────────────────────────────────


def _exec_help() -> dict:
    help_text = """**talaria slash commands**

`/dispatch <task>` — run a task on session billing
`/dispatch <task> --effort adaptive --model opus --skill <name>`
`/talaria status` — show current status
`/talaria doctor` — health check
`/talaria usage` — today's usage
`/talaria skills` — list available skills
`/talaria cron list` — list scheduled jobs
`/talaria cron add <name> <task> --schedule <interval>`
`/talaria cron run <id>` — trigger a job
`/talaria cron remove <id>` — delete a job

Shortcuts: `/t <task>`, `/dispatch <task>`

Effort values: `low`, `medium`, `high`, `max`, `xhigh`, `adaptive`, `auto`.
`adaptive`/`auto` let Claude choose automatically. `xhigh` falls back to `max` on older Claude CLIs."""
    return {"action": "help", "success": True, "response": help_text, "data": {}}


def _exec_status() -> dict:
    from talaria.config import TalariaConfig
    from talaria.tracker import summarize_usage

    config = TalariaConfig.load()
    usage = summarize_usage(since_hours=24.0)
    response = (
        f"**talaria status**\n"
        f"Model: {config.default_model} | Effort: {config.default_effort}\n"
        f"Today: {usage.total_dispatches} dispatches ({format_reported_usage(usage.total_cost_usd)})\n"
        f"Success rate: {usage.successful}/{usage.total_dispatches}\n"
        f"_{REPORTED_USAGE_NOTE}_"
    )
    return {
        "action": "status",
        "success": True,
        "response": response,
        "data": {
            "model": config.default_model,
            "effort": config.default_effort,
            "dispatches_today": usage.total_dispatches,
            "cost_today": usage.total_cost_usd,
        },
    }


def _exec_doctor() -> dict:
    from talaria.preflight import check_health
    health = check_health(cache_ttl=0)
    icon = "✅" if health.healthy else "❌"
    response = f"{icon} {health.summary()}"
    if health.errors:
        response += "\n" + "\n".join(f"  ❌ {e}" for e in health.errors)
    if health.warnings:
        response += "\n" + "\n".join(f"  ⚠️ {w}" for w in health.warnings)
    return {
        "action": "doctor",
        "success": health.healthy,
        "response": response,
        "data": {"healthy": health.healthy, "errors": health.errors, "warnings": health.warnings},
    }


def _exec_usage() -> dict:
    from talaria.tracker import summarize_usage
    s = summarize_usage(since_hours=24.0)
    response = (
        f"**Today's usage**\n"
        f"Dispatches: {s.total_dispatches} ({s.successful} ✓, {s.failed} ✗)\n"
        f"{format_reported_usage(s.total_cost_usd)} | {format_reported_usage_average(s.avg_cost_usd)}\n"
        f"Avg duration: {s.avg_duration_seconds:.0f}s\n"
        f"_{REPORTED_USAGE_NOTE}_"
    )
    return {"action": "usage", "success": True, "response": response, "data": {}}


def _exec_skills() -> dict:
    from talaria.config import TalariaConfig
    from talaria.skills import list_available_skills

    config = TalariaConfig.load()
    skills = list_available_skills(config.skills_dirs)
    if not skills:
        return {"action": "skills", "success": True, "response": "No skills found.", "data": {"skills": []}}

    names = [s["name"] for s in skills]
    response = f"**Available skills ({len(names)})**\n" + ", ".join(f"`{n}`" for n in names[:30])
    if len(names) > 30:
        response += f"\n...and {len(names) - 30} more"
    return {"action": "skills", "success": True, "response": response, "data": {"skills": names}}


def _exec_run(cmd: ParsedCommand) -> dict:
    from talaria.runner import dispatch

    result = dispatch(
        task=cmd.task,
        workdir=cmd.workdir,
        model=cmd.model,
        effort=cmd.effort,
        skills=cmd.skills or None,
        allowed_tools=cmd.allowed_tools or None,
        verify_command=cmd.verify,
    )

    if result.success:
        response = f"✅ **Done** ({result.turns_used} turns, {result.duration_seconds:.0f}s)"
        if result.result:
            # Truncate for chat
            text = result.result[:1500]
            if len(result.result) > 1500:
                text += "\n..."
            response += f"\n\n{text}"
        if result.discoveries:
            response += "\n\n**Discoveries:**\n" + "\n".join(f"• {d}" for d in result.discoveries)
    else:
        response = f"❌ **Failed:** {result.error}"

    return {
        "action": "run",
        "success": result.success,
        "response": response,
        "data": {
            "session_id": result.session_id,
            "turns": result.turns_used,
            "cost_usd": result.cost_usd,
            "duration_seconds": result.duration_seconds,
            "discoveries": result.discoveries,
            "files_modified": result.files_modified,
        },
    }


def _exec_cron_list() -> dict:
    from talaria.cron import load_jobs

    jobs = load_jobs()
    if not jobs:
        return {"action": "cron-list", "success": True, "response": "No cron jobs.", "data": {"jobs": []}}

    lines = []
    for job in jobs:
        status = "🟢" if job.enabled else "🔴"
        last = f"last: {job.last_run[:16]}" if job.last_run else "never run"
        lines.append(f"{status} `{job.id}` **{job.name}** — {job.schedule} ({last})")

    response = f"**Cron Jobs ({len(jobs)})**\n" + "\n".join(lines)
    return {
        "action": "cron-list",
        "success": True,
        "response": response,
        "data": {"jobs": [j.to_dict() for j in jobs]},
    }


def _exec_cron_add(cmd: ParsedCommand) -> dict:
    from talaria.cron import add_job

    job = add_job(
        name=cmd.cron_name,
        task=cmd.task,
        schedule=cmd.cron_schedule,
        workdir=cmd.workdir,
        model=cmd.model,
        effort=cmd.effort,
        skills=cmd.skills,
    )

    response = f"✅ Created job `{job.id}` (**{job.name}**)\nSchedule: {job.schedule}\nTask: {job.task[:80]}"
    return {
        "action": "cron-add",
        "success": True,
        "response": response,
        "data": {"job_id": job.id, "name": job.name},
    }


def _exec_cron_run(cmd: ParsedCommand) -> dict:
    from talaria.cron import get_job, record_run
    from talaria.runner import dispatch

    job = get_job(cmd.cron_job_id)
    if not job:
        return {
            "action": "cron-run",
            "success": False,
            "response": f"❌ Job `{cmd.cron_job_id}` not found.",
            "data": {},
        }

    result = dispatch(
        task=job.task,
        workdir=job.workdir,
        model=job.model,
        effort=job.effort,
        skills=job.skills or None,
    )

    record_run(job.id, result.success)

    icon = "✅" if result.success else "❌"
    response = f"{icon} **{job.name}** ({result.duration_seconds:.0f}s)"
    if result.error:
        response += f"\n{result.error}"

    return {
        "action": "cron-run",
        "success": result.success,
        "response": response,
        "data": {"job_id": job.id},
    }


def _exec_cron_remove(cmd: ParsedCommand) -> dict:
    from talaria.cron import remove_job

    if remove_job(cmd.cron_job_id):
        return {
            "action": "cron-remove",
            "success": True,
            "response": f"✅ Removed job `{cmd.cron_job_id}`",
            "data": {"job_id": cmd.cron_job_id},
        }
    return {
        "action": "cron-remove",
        "success": False,
        "response": f"❌ Job `{cmd.cron_job_id}` not found.",
        "data": {},
    }


def _exec_cron_toggle(cmd: ParsedCommand) -> dict:
    from talaria.cron import set_enabled

    enable = cmd.action == "cron-enable"
    job = set_enabled(cmd.cron_job_id, enable)
    if job:
        icon = "🟢" if enable else "🔴"
        state = "Enabled" if enable else "Disabled"
        return {
            "action": cmd.action,
            "success": True,
            "response": f"{icon} {state} **{job.name}**",
            "data": {"job_id": job.id, "enabled": enable},
        }
    return {
        "action": cmd.action,
        "success": False,
        "response": f"❌ Job `{cmd.cron_job_id}` not found.",
        "data": {},
    }
