"""Post-dispatch verification of task results."""
from __future__ import annotations

import subprocess
from dataclasses import dataclass


@dataclass
class VerifyResult:
    """Result of post-dispatch verification."""
    verified: bool
    exit_code: int
    output: str


def run_verification(command: str, workdir: str, timeout: int = 60) -> VerifyResult:
    """
    Run a verification command after dispatch.
    Returns VerifyResult with pass/fail status.
    """
    try:
        proc = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=workdir,
        )
        return VerifyResult(
            verified=proc.returncode == 0,
            exit_code=proc.returncode,
            output=(proc.stdout + proc.stderr).strip()[:5000],
        )
    except subprocess.TimeoutExpired:
        return VerifyResult(
            verified=False,
            exit_code=-1,
            output=f"Verification timed out after {timeout}s",
        )
    except Exception as e:
        return VerifyResult(
            verified=False,
            exit_code=-1,
            output=f"Verification error: {e}",
        )
