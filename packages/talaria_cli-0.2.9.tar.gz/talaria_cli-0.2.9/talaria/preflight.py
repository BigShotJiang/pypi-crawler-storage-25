"""Preflight health checks before dispatching."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from typing import Optional

from talaria.config import CONFIG_DIR


AUTH_CACHE_FILE = CONFIG_DIR / ".auth_cache"
VERSION_FILE = CONFIG_DIR / ".backend_version"


@dataclass
class HealthResult:
    """Result of all preflight checks."""
    healthy: bool
    auth_ok: bool
    backend_version: Optional[str]
    version_changed: bool
    disk_ok: bool
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)

    def summary(self) -> str:
        if self.healthy:
            return f"Healthy (backend {self.backend_version})"
        return f"Unhealthy: {'; '.join(self.errors)}"


def _find_backend() -> Optional[str]:
    """Find the CLI backend binary."""
    return shutil.which("claude")


def check_auth(cache_ttl: int = 300) -> tuple:
    """
    Verify backend auth is actually working (not just 'logged in').
    Caches result for cache_ttl seconds.
    Returns (ok, error_message).
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Check cache
    if AUTH_CACHE_FILE.exists():
        try:
            cache = json.loads(AUTH_CACHE_FILE.read_text())
            if time.time() - cache.get("timestamp", 0) < cache_ttl:
                return cache["ok"], cache.get("error")
        except (json.JSONDecodeError, KeyError):
            pass

    backend = _find_backend()
    if not backend:
        result = (False, "CLI backend not found. Install: npm i -g @anthropic-ai/claude-code")
        _write_auth_cache(*result)
        return result

    # Actually test with a real call
    try:
        proc = subprocess.run(
            [backend, "-p", "say ok", "--max-turns", "1", "--tools", "",
             "--output-format", "json"],
            capture_output=True, text=True, timeout=30,
        )
        stdout = proc.stdout.strip()
        first_line = stdout.split("\n")[0] if stdout else ""
        try:
            data = json.loads(first_line)
            ok = data.get("subtype") == "success"
            error = None if ok else data.get("result", "Unknown error")
        except json.JSONDecodeError:
            ok = proc.returncode == 0
            error = None if ok else (proc.stderr or stdout)[:200]
    except subprocess.TimeoutExpired:
        ok, error = False, "Auth check timed out (30s)"
    except Exception as e:
        ok, error = False, str(e)

    _write_auth_cache(ok, error)
    return ok, error


def _write_auth_cache(ok: bool, error: Optional[str]) -> None:
    try:
        AUTH_CACHE_FILE.write_text(json.dumps({
            "ok": ok, "error": error, "timestamp": time.time()
        }))
    except OSError:
        pass


def check_version() -> tuple:
    """Get backend version and detect changes. Returns (version, changed)."""
    backend = _find_backend()
    if not backend:
        return None, False

    try:
        result = subprocess.run(
            [backend, "--version"], capture_output=True, text=True, timeout=10
        )
        version = result.stdout.strip().split("\n")[0] if result.returncode == 0 else None
    except Exception:
        version = None

    changed = False
    if version and VERSION_FILE.exists():
        last = VERSION_FILE.read_text().strip()
        if last and last != version:
            changed = True

    if version:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        VERSION_FILE.write_text(version)

    return version, changed


def check_disk(workdir: str = ".") -> tuple:
    """Check disk space. Returns (ok, error_message)."""
    try:
        usage = shutil.disk_usage(os.path.abspath(workdir))
        free_gb = usage.free / (1024 ** 3)
        if free_gb < 1.0:
            return False, f"Low disk space: {free_gb:.1f}GB free"
    except Exception:
        pass
    return True, None


def check_health(workdir: str = ".", cache_ttl: int = 300) -> HealthResult:
    """Run all preflight checks."""
    errors = []
    warnings = []

    auth_ok, auth_error = check_auth(cache_ttl)
    if not auth_ok:
        errors.append(f"Auth: {auth_error}")

    version, version_changed = check_version()
    if version_changed:
        warnings.append(f"Backend version changed to {version}")

    disk_ok, disk_error = check_disk(workdir)
    if not disk_ok:
        warnings.append(disk_error or "Low disk space")

    return HealthResult(
        healthy=len(errors) == 0,
        auth_ok=auth_ok,
        backend_version=version,
        version_changed=version_changed,
        disk_ok=disk_ok,
        errors=errors,
        warnings=warnings,
    )


def invalidate_auth_cache() -> None:
    """Force re-check on next dispatch."""
    if AUTH_CACHE_FILE.exists():
        AUTH_CACHE_FILE.unlink()
