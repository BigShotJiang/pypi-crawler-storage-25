"""Parallel batch dispatch - run multiple tasks concurrently."""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

from talaria.config import TalariaConfig, ensure_dirs
from talaria.runner import TaskResult, dispatch


@dataclass
class BatchTask:
    """A single task in a batch dispatch."""
    task: str
    workdir: str = "."
    model: Optional[str] = None
    max_turns: Optional[int] = None
    max_budget_usd: Optional[float] = None
    timeout: Optional[int] = None
    allowed_tools: Optional[list] = None
    mcp_config: Optional[str] = None
    worktree: bool = False
    context: Optional[str] = None
    verify_command: Optional[str] = None
    retries: int = 1


@dataclass
class BatchResult:
    """Result from a batch dispatch."""
    total: int
    successful: int
    failed: int
    duration_seconds: float
    results: list = field(default_factory=list)
    total_cost_usd: float = 0.0


def batch_dispatch(
    tasks: list,
    max_parallel: Optional[int] = None,
) -> BatchResult:
    """
    Dispatch multiple tasks concurrently.

    Args:
        tasks: List of dicts with task params, or list of BatchTask objects.
               Dict keys match dispatch() parameters.
        max_parallel: Max concurrent dispatches. Defaults to config.max_parallel.

    Returns:
        BatchResult with all individual results.
    """
    config = TalariaConfig.load()
    ensure_dirs()

    max_workers = max_parallel or config.max_parallel

    # Normalize tasks to BatchTask objects
    normalized = []
    for t in tasks:
        if isinstance(t, BatchTask):
            normalized.append(t)
        elif isinstance(t, dict):
            normalized.append(BatchTask(**{
                k: v for k, v in t.items()
                if k in BatchTask.__dataclass_fields__
            }))
        else:
            raise ValueError(f"Invalid task type: {type(t)}. Expected dict or BatchTask.")

    if not normalized:
        return BatchResult(total=0, successful=0, failed=0, duration_seconds=0.0)

    start = time.time()
    results = [None] * len(normalized)

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_to_idx = {}
        for i, bt in enumerate(normalized):
            future = pool.submit(
                dispatch,
                task=bt.task,
                workdir=bt.workdir,
                model=bt.model,
                max_turns=bt.max_turns,
                max_budget_usd=bt.max_budget_usd,
                timeout=bt.timeout,
                allowed_tools=bt.allowed_tools,
                mcp_config=bt.mcp_config,
                worktree=bt.worktree,
                context=bt.context,
                verify_command=bt.verify_command,
                retries=bt.retries,
            )
            future_to_idx[future] = i

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            try:
                results[idx] = future.result()
            except Exception as e:
                results[idx] = TaskResult(
                    success=False,
                    result="",
                    error=f"Batch dispatch error: {e}",
                )

    duration = time.time() - start
    successful = sum(1 for r in results if r and r.success)
    total_cost = sum(r.cost_usd for r in results if r)

    return BatchResult(
        total=len(normalized),
        successful=successful,
        failed=len(normalized) - successful,
        duration_seconds=duration,
        results=results,
        total_cost_usd=total_cost,
    )
