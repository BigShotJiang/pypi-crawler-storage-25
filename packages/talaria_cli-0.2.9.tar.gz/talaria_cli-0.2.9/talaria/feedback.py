"""Parse structured feedback from dispatched task output."""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class TaskFeedback:
    """Structured feedback extracted from task output."""
    task_result: str = ""
    discoveries: list = field(default_factory=list)
    files_read: list = field(default_factory=list)
    files_modified: list = field(default_factory=list)
    convention_proposals: list = field(default_factory=list)


def parse_feedback(text: str) -> TaskFeedback:
    """Extract structured feedback from task output text."""
    feedback = TaskFeedback()

    # Extract Task Result section
    result_match = re.search(
        r"### Task Result\s*\n(.+?)(?=\n### |$)", text, re.DOTALL
    )
    if result_match:
        feedback.task_result = result_match.group(1).strip()

    # Extract Discoveries
    disc_match = re.search(
        r"### Discoveries\s*\n(.+?)(?=\n### |$)", text, re.DOTALL
    )
    if disc_match:
        raw = disc_match.group(1).strip()
        if raw.lower() not in ("none.", "none", "n/a", "-"):
            feedback.discoveries = _parse_list(raw)

    # Extract Files Touched
    files_match = re.search(
        r"### Files Touched\s*\n(.+?)(?=\n### |$)", text, re.DOTALL
    )
    if files_match:
        raw = files_match.group(1).strip()
        read_match = re.search(r"Read:\s*(.+)", raw)
        mod_match = re.search(r"Modified:\s*(.+)", raw)
        if read_match:
            feedback.files_read = _parse_csv(read_match.group(1))
        if mod_match:
            feedback.files_modified = _parse_csv(mod_match.group(1))

    # Extract Convention Proposals
    conv_match = re.search(
        r"### Convention Proposals\s*\n(.+?)(?=\n### |$)", text, re.DOTALL
    )
    if conv_match:
        raw = conv_match.group(1).strip()
        if raw.lower() not in ("none.", "none", "n/a", "-"):
            feedback.convention_proposals = _parse_list(raw)

    return feedback


def _parse_list(text: str) -> list:
    """Parse a markdown list or newline-separated items."""
    items = []
    for line in text.strip().split("\n"):
        line = re.sub(r"^\s*[-*•]\s*", "", line).strip()
        if line and line.lower() not in ("none.", "none"):
            items.append(line)
    return items


def _parse_csv(text: str) -> list:
    """Parse comma-separated file paths."""
    items = []
    for item in text.split(","):
        item = item.strip().strip("`")
        if item and item.lower() not in ("none", "n/a", "-"):
            items.append(item)
    return items
