"""Skill file resolution and loading for talaria.

Resolves skill references (by name or path) to their content,
which gets injected into the dispatched agent's system prompt.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional


# Default skill search directories (checked in order)
DEFAULT_SKILL_DIRS = [
    Path("~/.hermes/skills").expanduser(),
    Path("~/.claude/skills").expanduser(),
]


def resolve_skill(
    skill_ref: str,
    skill_dirs: Optional[list[str]] = None,
) -> tuple[str, str]:
    """
    Resolve a skill reference to (name, content).

    A skill_ref can be:
    - An absolute or relative file path to a .md file
    - A skill name (looked up in skill directories)

    Returns (resolved_name, content) or raises FileNotFoundError.
    """
    # 1. Direct file path
    path = Path(skill_ref).expanduser()
    if path.exists() and path.is_file():
        return (path.stem, path.read_text().strip())

    # 2. Search skill directories
    search_dirs = [Path(d).expanduser() for d in skill_dirs] if skill_dirs else DEFAULT_SKILL_DIRS

    for base_dir in search_dirs:
        if not base_dir.exists():
            continue

        candidates = _find_skill_in_dir(base_dir, skill_ref)
        if candidates:
            # Take the first match
            skill_path = candidates[0]
            return (skill_ref, skill_path.read_text().strip())

    raise FileNotFoundError(
        f"Skill '{skill_ref}' not found. Searched paths: {[str(d) for d in search_dirs]}. "
        f"You can also pass an absolute file path."
    )


def resolve_skills(
    skill_refs: list[str],
    skill_dirs: Optional[list[str]] = None,
) -> list[tuple[str, str]]:
    """
    Resolve multiple skill references. Returns list of (name, content).
    Raises FileNotFoundError on first unresolvable skill.
    """
    results = []
    for ref in skill_refs:
        results.append(resolve_skill(ref, skill_dirs))
    return results


def format_skills_context(skills: list[tuple[str, str]]) -> str:
    """
    Format resolved skills into a context section for injection.

    Args:
        skills: List of (name, content) tuples from resolve_skills.

    Returns:
        Formatted markdown string with all skills.
    """
    if not skills:
        return ""

    sections = []
    for name, content in skills:
        sections.append(f"## Skill: {name}\n\n{content}")

    header = f"# Loaded Skills ({len(skills)})\n\nThe following skills provide specialized knowledge for this task. Follow their instructions.\n"
    return header + "\n\n---\n\n".join(sections)


def _find_skill_in_dir(base_dir: Path, skill_name: str) -> list[Path]:
    """
    Search for a skill by name in a directory tree.

    Looks for:
    - {base_dir}/{skill_name}/SKILL.md
    - {base_dir}/{skill_name}.md
    - {base_dir}/*/{skill_name}/SKILL.md  (one level of category nesting)
    - {base_dir}/*/{skill_name}.md
    """
    candidates = []

    # Direct name match
    skill_dir = base_dir / skill_name
    if (skill_dir / "SKILL.md").exists():
        candidates.append(skill_dir / "SKILL.md")

    skill_file = base_dir / f"{skill_name}.md"
    if skill_file.exists():
        candidates.append(skill_file)

    # Category subdirectory search (one level)
    if not candidates:
        for category_dir in base_dir.iterdir():
            if not category_dir.is_dir():
                continue
            nested_skill_dir = category_dir / skill_name
            if (nested_skill_dir / "SKILL.md").exists():
                candidates.append(nested_skill_dir / "SKILL.md")
            nested_file = category_dir / f"{skill_name}.md"
            if nested_file.exists():
                candidates.append(nested_file)

    return candidates


def list_available_skills(
    skill_dirs: Optional[list[str]] = None,
) -> list[dict]:
    """
    List all available skills across search directories.

    Returns list of {name, path, directory} dicts.
    """
    search_dirs = [Path(d).expanduser() for d in skill_dirs] if skill_dirs else DEFAULT_SKILL_DIRS
    skills = []
    seen = set()

    for base_dir in search_dirs:
        if not base_dir.exists():
            continue

        # Top-level skill dirs
        for item in sorted(base_dir.iterdir()):
            if item.is_dir() and (item / "SKILL.md").exists():
                name = item.name
                if name not in seen:
                    seen.add(name)
                    skills.append({"name": name, "path": str(item / "SKILL.md"), "directory": str(base_dir)})

            # Category subdirs
            if item.is_dir():
                for sub in sorted(item.iterdir()):
                    if sub.is_dir() and (sub / "SKILL.md").exists():
                        name = sub.name
                        if name not in seen:
                            seen.add(name)
                            skills.append({"name": name, "path": str(sub / "SKILL.md"), "directory": str(base_dir)})

    return skills
