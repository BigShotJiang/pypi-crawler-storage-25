"""PID-based directory locks for concurrent dispatch safety."""
from __future__ import annotations

import json
import os
import hashlib
import time
from pathlib import Path
from typing import Optional

from talaria.config import LOCKS_DIR


def _lock_path(workdir: str) -> Path:
    """Get lock file path for a working directory."""
    dir_hash = hashlib.sha256(os.path.abspath(workdir).encode()).hexdigest()[:16]
    return LOCKS_DIR / f"{dir_hash}.lock"


def _pid_alive(pid: int) -> bool:
    """Check if a PID is still running."""
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def acquire_lock(workdir: str, timeout: float = 30.0) -> Optional[str]:
    """
    Try to acquire a directory lock. Returns lock_id on success, None on failure.
    Stale locks (dead PIDs) are automatically released.
    """
    LOCKS_DIR.mkdir(parents=True, exist_ok=True)
    lock_file = _lock_path(workdir)

    deadline = time.time() + timeout
    while time.time() < deadline:
        # Check for existing lock
        if lock_file.exists():
            try:
                lock_data = json.loads(lock_file.read_text())
                holder_pid = lock_data.get("pid", 0)
                # Stale lock detection
                if not _pid_alive(holder_pid):
                    lock_file.unlink(missing_ok=True)
                else:
                    time.sleep(0.5)
                    continue
            except (json.JSONDecodeError, OSError):
                lock_file.unlink(missing_ok=True)

        # Try to acquire
        lock_id = f"{os.getpid()}-{int(time.time() * 1000)}"
        try:
            lock_data = {
                "pid": os.getpid(),
                "lock_id": lock_id,
                "workdir": os.path.abspath(workdir),
                "acquired_at": time.time(),
            }
            lock_file.write_text(json.dumps(lock_data))
            # Verify we actually got it (race condition check)
            verify = json.loads(lock_file.read_text())
            if verify.get("lock_id") == lock_id:
                return lock_id
        except OSError:
            pass
        time.sleep(0.1)

    return None


def release_lock(workdir: str, lock_id: str) -> bool:
    """Release a directory lock. Returns True if released."""
    lock_file = _lock_path(workdir)
    try:
        if lock_file.exists():
            data = json.loads(lock_file.read_text())
            if data.get("lock_id") == lock_id:
                lock_file.unlink(missing_ok=True)
                return True
    except (json.JSONDecodeError, OSError):
        lock_file.unlink(missing_ok=True)
        return True
    return False


def is_locked(workdir: str) -> bool:
    """Check if a directory is currently locked by a live process."""
    lock_file = _lock_path(workdir)
    if not lock_file.exists():
        return False
    try:
        data = json.loads(lock_file.read_text())
        return _pid_alive(data.get("pid", 0))
    except (json.JSONDecodeError, OSError):
        return False
