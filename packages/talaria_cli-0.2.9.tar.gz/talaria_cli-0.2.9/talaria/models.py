"""Model alias resolution for Claude Code backends."""
from __future__ import annotations

import re

LATEST_MODEL_ALIASES = {"opus", "sonnet", "haiku"}
_VERSIONED_ALIAS_RE = re.compile(r"^(opus|sonnet|haiku)@([0-9]+(?:\.[0-9]+)*)$", re.IGNORECASE)
_FULL_MODEL_RE = re.compile(r"^claude-(opus|sonnet|haiku)-[0-9]+(?:-[0-9]+)*$", re.IGNORECASE)


def model_help_text() -> str:
    """Human-readable CLI help for model selection."""
    return (
        "Model to use. Plain aliases like opus/sonnet/haiku follow Claude Code's latest alias. "
        "Append @version to pin a specific release, e.g. opus@4.7 -> claude-opus-4-7."
    )


def resolve_model_spec(model: str | None) -> str | None:
    """Resolve a user-facing model spec into the Claude CLI model value."""
    if model is None:
        return None

    value = model.strip()
    if not value:
        return None

    lowered = value.lower()
    if lowered in LATEST_MODEL_ALIASES:
        return lowered

    match = _VERSIONED_ALIAS_RE.match(lowered)
    if match:
        family, version = match.groups()
        return f"claude-{family}-{version.replace('.', '-')}"

    if _FULL_MODEL_RE.match(lowered):
        return lowered

    return value
