"""Cron job scheduling for talaria.

Manages recurring dispatches that run through session billing.
Jobs are stored in ~/.config/talaria/crons.json and executed
via `talaria cron run-due` (called from system crontab or a timer).
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from talaria.config import CONFIG_DIR


CRONS_FILE = CONFIG_DIR / "crons.json"


@dataclass
class CronJob:
    """A scheduled talaria dispatch."""
    id: str
    name: str
    task: str
    schedule: str
    workdir: str = "."
    model: Optional[str] = None
    effort: Optional[str] = None
    skills: list = field(default_factory=list)
    allowed_tools: list = field(default_factory=list)
    verify: Optional[str] = None
    mcp_config: Optional[str] = None
    context: Optional[str] = None
    max_turns: Optional[int] = None
    timeout: Optional[int] = None
    enabled: bool = True
    last_run: Optional[str] = None
    last_result: Optional[str] = None  # "success" or "failure"
    created: str = ""
    run_count: int = 0
    fail_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "CronJob":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


def _generate_id(name: str, task: str) -> str:
    """Generate a short unique ID from name + task + timestamp."""
    raw = f"{name}:{task}:{time.time()}"
    return hashlib.md5(raw.encode()).hexdigest()[:8]


def load_jobs() -> list[CronJob]:
    """Load all cron jobs from disk."""
    if not CRONS_FILE.exists():
        return []
    try:
        with open(CRONS_FILE) as f:
            data = json.load(f)
        return [CronJob.from_dict(j) for j in data.get("jobs", [])]
    except (json.JSONDecodeError, KeyError):
        return []


def save_jobs(jobs: list[CronJob]) -> None:
    """Persist all cron jobs to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CRONS_FILE, "w") as f:
        json.dump({"jobs": [j.to_dict() for j in jobs]}, f, indent=2)


def add_job(
    name: str,
    task: str,
    schedule: str,
    workdir: str = ".",
    model: Optional[str] = None,
    skills: Optional[list] = None,
    allowed_tools: Optional[list] = None,
    verify: Optional[str] = None,
    mcp_config: Optional[str] = None,
    context: Optional[str] = None,
    max_turns: Optional[int] = None,
    timeout: Optional[int] = None,
    effort: Optional[str] = None,
) -> CronJob:
    """Create and save a new cron job."""
    job = CronJob(
        id=_generate_id(name, task),
        name=name,
        task=task,
        schedule=schedule,
        workdir=workdir,
        model=model,
        effort=effort,
        skills=skills or [],
        allowed_tools=allowed_tools or [],
        verify=verify,
        mcp_config=mcp_config,
        context=context,
        max_turns=max_turns,
        timeout=timeout,
        created=datetime.now().isoformat(),
    )
    jobs = load_jobs()
    jobs.append(job)
    save_jobs(jobs)
    return job


def remove_job(job_id: str) -> bool:
    """Remove a job by ID. Returns True if found and removed."""
    jobs = load_jobs()
    before = len(jobs)
    jobs = [j for j in jobs if j.id != job_id]
    if len(jobs) == before:
        return False
    save_jobs(jobs)
    return True


def get_job(job_id: str) -> Optional[CronJob]:
    """Get a job by ID."""
    for job in load_jobs():
        if job.id == job_id:
            return job
    return None


def update_job(job_id: str, **kwargs) -> Optional[CronJob]:
    """Update fields on an existing job."""
    jobs = load_jobs()
    for i, job in enumerate(jobs):
        if job.id == job_id:
            for k, v in kwargs.items():
                if hasattr(job, k):
                    setattr(job, k, v)
            jobs[i] = job
            save_jobs(jobs)
            return job
    return None


def set_enabled(job_id: str, enabled: bool) -> Optional[CronJob]:
    """Enable or disable a job."""
    return update_job(job_id, enabled=enabled)


def record_run(job_id: str, success: bool) -> None:
    """Record the result of a cron run."""
    jobs = load_jobs()
    for job in jobs:
        if job.id == job_id:
            job.last_run = datetime.now().isoformat()
            job.last_result = "success" if success else "failure"
            job.run_count += 1
            if not success:
                job.fail_count += 1
            break
    save_jobs(jobs)


# ─── Schedule Parsing ───────────────────────────────────────────────


def parse_interval(schedule: str) -> Optional[timedelta]:
    """
    Parse a human-readable interval schedule into a timedelta.

    Supports:
    - "30m", "every 30m", "every 30 minutes"
    - "2h", "every 2h", "every 2 hours"
    - "1d", "every 1d", "every 1 day", "daily"
    - "12h", "every 12 hours"

    Returns None if the schedule is a cron expression (handled separately).
    """
    s = schedule.lower().strip()

    # Handle "daily" shorthand
    if s == "daily":
        return timedelta(days=1)

    # Strip "every" prefix
    s = s.removeprefix("every").strip()

    # Try to parse number + unit
    import re
    match = re.match(r"^(\d+)\s*(m|min|mins|minutes?|h|hr|hrs|hours?|d|days?)$", s)
    if match:
        num = int(match.group(1))
        unit = match.group(2)[0]  # First char: m, h, or d
        if unit == "m":
            return timedelta(minutes=num)
        elif unit == "h":
            return timedelta(hours=num)
        elif unit == "d":
            return timedelta(days=num)

    return None  # Not an interval — might be cron syntax


def parse_cron_expression(schedule: str) -> bool:
    """Check if a schedule string looks like a cron expression (5 fields)."""
    parts = schedule.strip().split()
    return len(parts) == 5 and all(
        any(c in "0123456789*/-," for c in p) for p in parts
    )


def is_due(job: CronJob, now: Optional[datetime] = None) -> bool:
    """
    Check if a job is due to run.

    For interval schedules: checks if enough time has passed since last_run.
    For cron expressions: checks if the current minute matches the schedule.
    """
    if not job.enabled:
        return False

    now = now or datetime.now()

    # Try interval first
    interval = parse_interval(job.schedule)
    if interval:
        if not job.last_run:
            return True  # Never run — due immediately
        last = datetime.fromisoformat(job.last_run)
        return (now - last) >= interval

    # Try cron expression
    if parse_cron_expression(job.schedule):
        return _cron_matches(job.schedule, now)

    return False


def _cron_matches(expression: str, now: datetime) -> bool:
    """Check if a cron expression matches the current time (minute-level)."""
    parts = expression.strip().split()
    if len(parts) != 5:
        return False

    minute, hour, dom, month, dow = parts

    return (
        _field_matches(minute, now.minute, 0, 59)
        and _field_matches(hour, now.hour, 0, 23)
        and _field_matches(dom, now.day, 1, 31)
        and _field_matches(month, now.month, 1, 12)
        and _field_matches(dow, now.weekday(), 0, 6)  # Monday=0
    )


def _field_matches(field: str, value: int, min_val: int, max_val: int) -> bool:
    """Check if a single cron field matches a value."""
    if field == "*":
        return True

    for part in field.split(","):
        # Handle step: */5 or 1-10/2
        if "/" in part:
            base, step = part.split("/", 1)
            step = int(step)
            if base == "*":
                if value % step == 0:
                    return True
            elif "-" in base:
                start, end = map(int, base.split("-", 1))
                if start <= value <= end and (value - start) % step == 0:
                    return True
        # Handle range: 1-5
        elif "-" in part:
            start, end = map(int, part.split("-", 1))
            if start <= value <= end:
                return True
        # Handle single value
        else:
            if int(part) == value:
                return True

    return False


def get_due_jobs(now: Optional[datetime] = None) -> list[CronJob]:
    """Get all jobs that are due to run now."""
    now = now or datetime.now()
    return [job for job in load_jobs() if is_due(job, now)]
