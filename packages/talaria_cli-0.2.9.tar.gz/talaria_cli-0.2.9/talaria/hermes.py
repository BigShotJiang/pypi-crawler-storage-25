"""Hermes framework integration helpers."""
from __future__ import annotations

import shlex
from typing import Optional

from talaria.tools import translate_tools


def terminal_command(
    task: str,
    workdir: str = ".",
    model: Optional[str] = None,
    toolsets: Optional[list] = None,
    verify: Optional[str] = None,
    mcp_config: Optional[str] = None,
    context: Optional[str] = None,
    max_turns: Optional[int] = None,
    timeout: Optional[int] = None,
    max_budget_usd: Optional[float] = None,
    worktree: bool = False,
    retries: int = 1,
    json_output: bool = True,
    skills: Optional[list] = None,
    effort: Optional[str] = None,
) -> str:
    """
    Generate a talaria CLI command string for use with Hermes terminal().

    Accepts Hermes-style toolset names (terminal, file, browser, web)
    and translates them to Claude Code tool names automatically.

    Usage from a Hermes agent:
        from talaria.hermes import terminal_command
        cmd = terminal_command("Fix the auth bug", workdir="~/project", toolsets=["terminal", "file"])
        terminal(command=cmd, background=True, notify_on_complete=True)
    """
    parts = ["talaria", "run", shlex.quote(task)]

    parts.extend(["--workdir", shlex.quote(workdir)])

    if model:
        parts.extend(["--model", model])

    if effort:
        parts.extend(["--effort", effort])

    if toolsets:
        translated = translate_tools(toolsets)
        parts.extend(["--allowed-tools", ",".join(translated)])

    if verify:
        parts.extend(["--verify", shlex.quote(verify)])

    if mcp_config:
        parts.extend(["--mcp-config", shlex.quote(mcp_config)])

    if context:
        parts.extend(["--context", shlex.quote(context)])

    if max_turns:
        parts.extend(["--max-turns", str(max_turns)])

    if timeout:
        parts.extend(["--timeout", str(timeout)])

    if max_budget_usd is not None:
        parts.extend(["--max-budget", str(max_budget_usd)])

    if worktree:
        parts.append("--worktree")

    if retries > 1:
        parts.extend(["--retries", str(retries)])

    if skills:
        for skill in skills:
            parts.extend(["--skill", shlex.quote(skill)])

    if json_output:
        parts.append("--json-output")

    return " ".join(parts)


def batch_command(
    tasks: list,
    json_output: bool = True,
) -> str:
    """
    Generate a talaria batch CLI command string.

    Args:
        tasks: List of dicts with 'task' and optional 'workdir', 'model', 'toolsets' keys.

    Usage:
        cmd = batch_command([
            {"task": "Fix auth", "workdir": "~/project"},
            {"task": "Write tests", "workdir": "~/project"},
        ])
        terminal(command=cmd, background=True, notify_on_complete=True)
    """
    parts = ["talaria", "batch"]

    for t in tasks:
        parts.extend(["--task", shlex.quote(t["task"])])
        if "workdir" in t:
            parts.extend(["--workdir", shlex.quote(t["workdir"])])
        if "model" in t:
            parts.extend(["--model", t["model"]])

    if json_output:
        parts.append("--json-output")

    return " ".join(parts)
