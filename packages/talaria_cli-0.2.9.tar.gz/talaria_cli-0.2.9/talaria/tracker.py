"""Usage tracking and circuit breaker for dispatch safety."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime

from talaria.config import USAGE_FILE, TalariaConfig, ensure_dirs


REPORTED_USAGE_LABEL = "Claude-reported usage"
REPORTED_USAGE_NOTE = (
    "Includes Claude-reported print-mode usage. Depending on auth and account limits, "
    "this may reflect included plan usage and/or paid extra usage."
)


def format_reported_usage(amount_usd: float) -> str:
    """Format a Claude-reported usage amount for human-facing output."""
    return f"{REPORTED_USAGE_LABEL}: ${amount_usd:.2f}"


def format_reported_usage_average(amount_usd: float) -> str:
    """Format an average Claude-reported usage amount for human-facing output."""
    return f"Avg Claude-reported usage/task: ${amount_usd:.2f}"


@dataclass
class UsageEntry:
    timestamp: str
    task: str
    model: str
    cost_usd: float
    turns: int
    duration_seconds: float
    session_id: str
    success: bool
    workdir: str


@dataclass
class UsageSummary:
    total_dispatches: int
    total_cost_usd: float
    successful: int
    failed: int
    avg_cost_usd: float
    avg_duration_seconds: float


def log_usage(entry: UsageEntry) -> None:
    """Append a usage entry to the log."""
    ensure_dirs()
    with open(USAGE_FILE, "a") as f:
        f.write(json.dumps({
            "timestamp": entry.timestamp,
            "task": entry.task[:200],
            "model": entry.model,
            "cost_usd": entry.cost_usd,
            "turns": entry.turns,
            "duration": entry.duration_seconds,
            "session_id": entry.session_id,
            "success": entry.success,
            "workdir": entry.workdir,
        }) + "\n")


def get_usage(since_hours: float = 24.0) -> list:
    """Get usage entries from the last N hours."""
    if not USAGE_FILE.exists():
        return []

    cutoff = time.time() - (since_hours * 3600)
    entries = []
    for line in USAGE_FILE.read_text().strip().split("\n"):
        if not line:
            continue
        try:
            data = json.loads(line)
            ts = datetime.fromisoformat(data["timestamp"]).timestamp()
            if ts >= cutoff:
                entries.append(data)
        except (json.JSONDecodeError, KeyError, ValueError):
            continue
    return entries


def summarize_usage(since_hours: float = 24.0) -> UsageSummary:
    """Summarize usage for a time period."""
    entries = get_usage(since_hours)
    if not entries:
        return UsageSummary(0, 0.0, 0, 0, 0.0, 0.0)

    total_cost = sum(e.get("cost_usd", 0) for e in entries)
    successful = sum(1 for e in entries if e.get("success", False))
    durations = [e.get("duration", 0) for e in entries]

    return UsageSummary(
        total_dispatches=len(entries),
        total_cost_usd=total_cost,
        successful=successful,
        failed=len(entries) - successful,
        avg_cost_usd=total_cost / len(entries) if entries else 0,
        avg_duration_seconds=sum(durations) / len(durations) if durations else 0,
    )


class CircuitBreaker:
    """Safety circuit breaker that halts dispatching on anomalies."""

    def __init__(self, config: TalariaConfig):
        self.config = config
        self._consecutive_failures = 0

    def check_budget(self) -> tuple:
        """Check if daily budget is exceeded. Returns (ok, message)."""
        usage = summarize_usage(since_hours=24.0)
        if usage.total_cost_usd >= self.config.daily_budget_usd:
            return False, (
                f"Reported usage budget exceeded: ${usage.total_cost_usd:.2f} / "
                f"${self.config.daily_budget_usd:.2f}"
            )
        return True, None

    def check_cost_spike(self, cost_usd: float) -> tuple:
        """Check if a single dispatch cost is anomalously high. Returns (ok, message)."""
        usage = get_usage(since_hours=24.0)
        if len(usage) < 3:
            return True, None  # Not enough data

        avg = sum(e.get("cost_usd", 0) for e in usage) / len(usage)
        if avg > 0 and cost_usd > avg * self.config.cost_spike_multiplier:
            return False, (
                f"Reported usage spike: ${cost_usd:.2f} is {cost_usd/avg:.1f}x the "
                f"rolling average (${avg:.2f})"
            )
        return True, None

    def record_result(self, success: bool) -> None:
        """Track consecutive failures."""
        if success:
            self._consecutive_failures = 0
        else:
            self._consecutive_failures += 1

    def check_failures(self) -> tuple:
        """Check consecutive failure limit. Returns (ok, message)."""
        if self._consecutive_failures >= self.config.consecutive_failure_limit:
            return False, (
                f"Circuit breaker tripped: {self._consecutive_failures} consecutive "
                f"failures (limit: {self.config.consecutive_failure_limit})"
            )
        return True, None

    def can_dispatch(self) -> tuple:
        """Full circuit breaker check. Returns (ok, message)."""
        ok, msg = self.check_budget()
        if not ok:
            return ok, msg
        ok, msg = self.check_failures()
        if not ok:
            return ok, msg
        return True, None

    def reset(self) -> None:
        """Manual reset of circuit breaker."""
        self._consecutive_failures = 0
