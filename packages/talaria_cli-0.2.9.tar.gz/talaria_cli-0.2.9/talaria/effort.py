"""Effort-level normalization across Claude Code versions."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from typing import Optional

from talaria.config import CONFIG_DIR


ACCEPTED_EFFORTS = ("low", "medium", "high", "max", "xhigh", "adaptive", "auto")
DEFAULT_BACKEND_EFFORTS = {"low", "medium", "high", "max"}
EFFORT_CACHE_FILE = CONFIG_DIR / ".effort_capabilities.json"
_CACHE_TTL_SECONDS = 300


def effort_choices() -> tuple[str, ...]:
    return ACCEPTED_EFFORTS


def effort_help_text() -> str:
    return "Thinking effort level: low, medium, high, max, xhigh, adaptive/auto."


def normalize_effort_for_backend(effort: Optional[str], supported_efforts: Optional[set[str]] = None) -> Optional[str]:
    """Normalize Talaria effort values to what the installed Claude CLI supports.

    - adaptive/auto => omit the flag entirely so Claude chooses adaptively.
    - xhigh => pass through when supported, otherwise fall back to max.
    """
    if not effort:
        return None

    normalized = effort.lower().strip()
    if normalized in {"adaptive", "auto"}:
        return None

    supported = supported_efforts or DEFAULT_BACKEND_EFFORTS
    if normalized == "xhigh" and "xhigh" not in supported:
        if "max" in supported:
            return "max"
        return sorted(supported)[-1] if supported else "high"

    return normalized


def get_supported_efforts(backend: Optional[str] = None, cache_ttl: int = _CACHE_TTL_SECONDS) -> set[str]:
    """Inspect the installed Claude CLI help text for supported effort values."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    backend = backend or shutil.which("claude")
    cache_key = _cache_key(backend)
    cached = _read_cache(cache_ttl, cache_key)
    if cached:
        return cached

    if not backend:
        return DEFAULT_BACKEND_EFFORTS.copy()

    try:
        proc = subprocess.run([backend, "--help"], capture_output=True, text=True, timeout=10)
        text = (proc.stdout or "") + "\n" + (proc.stderr or "")
        supported = _parse_supported_efforts(text)
    except Exception:
        supported = DEFAULT_BACKEND_EFFORTS.copy()

    _write_cache(supported, cache_key)
    return supported


def _parse_supported_efforts(help_text: str) -> set[str]:
    for line in help_text.splitlines():
        if "--effort <level>" not in line:
            continue
        match = re.search(r"\(([^)]*)\)", line)
        if not match:
            break
        options = {
            token.strip()
            for token in re.split(r",|/", match.group(1))
            if token.strip() and token.strip().isalpha()
        }
        if options:
            return options
        break
    return DEFAULT_BACKEND_EFFORTS.copy()


def _read_cache(cache_ttl: int, cache_key: Optional[str]) -> Optional[set[str]]:
    if not EFFORT_CACHE_FILE.exists():
        return None
    try:
        data = json.loads(EFFORT_CACHE_FILE.read_text())
        if time.time() - data.get("timestamp", 0) > cache_ttl:
            return None
        if data.get("cache_key") != cache_key:
            return None
        efforts = data.get("efforts") or []
        parsed = {str(item).strip() for item in efforts if str(item).strip()}
        return parsed or None
    except Exception:
        return None


def _write_cache(efforts: set[str], cache_key: Optional[str]) -> None:
    try:
        EFFORT_CACHE_FILE.write_text(json.dumps({
            "timestamp": time.time(),
            "cache_key": cache_key,
            "efforts": sorted(efforts),
        }))
    except OSError:
        pass


def _cache_key(backend: Optional[str]) -> Optional[str]:
    if not backend:
        return None
    try:
        return f"{backend}:{os.path.getmtime(backend)}"
    except OSError:
        return backend
