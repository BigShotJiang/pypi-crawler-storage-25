"""Setup command - wires talaria into agent frameworks automatically."""
from __future__ import annotations

import importlib.resources
import sys
import sysconfig
from pathlib import Path
from typing import Optional


# Hermes skill directory
HERMES_SKILLS_DIR = Path("~/.hermes/skills/project/talaria").expanduser()

# Conventions example
EXAMPLE_CONVENTIONS = """# Project Conventions
#
# This file is automatically injected into every talaria dispatch.
# Add your team's rules, coding standards, and preferences here.
# The dispatched agent will follow these conventions.

# Example conventions (uncomment and customize):
# - Always use pnpm, never npm
# - Use TypeScript strict mode
# - 2-space indentation for TypeScript, 4-space for Python
# - Never force push to main
# - Run type checks before committing
# - Use pytest for Python tests, vitest for TypeScript
# - Follow existing patterns in the codebase
""".strip()


def find_skill_content() -> Optional[str]:
    """Find the SKILL.md content from the installed package."""
    candidates = []

    try:
        pkg_dir = Path(__file__).parent.parent
        candidates.append(pkg_dir / "skills" / "SKILL.md")
    except Exception:
        pass

    try:
        data_dir = Path(sysconfig.get_paths()["data"])
        candidates.append(data_dir / "talaria-data" / "skills" / "SKILL.md")
    except Exception:
        pass

    try:
        candidates.append(Path(sys.prefix) / "talaria-data" / "skills" / "SKILL.md")
    except Exception:
        pass

    for skill_path in candidates:
        try:
            if skill_path.exists():
                return skill_path.read_text()
        except Exception:
            continue

    try:
        if sys.version_info >= (3, 9):
            ref = importlib.resources.files("talaria").joinpath("../skills/SKILL.md")
            return ref.read_text()
    except Exception:
        pass

    return None


def install_hermes_skill(force: bool = False) -> tuple:
    """
    Install the talaria skill into Hermes skills directory.
    Returns (success, message).
    """
    skill_content = find_skill_content()
    if not skill_content:
        return False, "Could not find SKILL.md in package. Manual install needed."

    skill_dir = HERMES_SKILLS_DIR
    skill_file = skill_dir / "SKILL.md"

    if skill_file.exists() and not force:
        return True, "Skill already installed (use --force to overwrite)"

    try:
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file.write_text(skill_content)
        return True, f"Skill installed to {skill_file}"
    except Exception as e:
        return False, f"Failed to install skill: {e}"


def create_example_conventions() -> tuple:
    """
    Create an example conventions file if one doesn't exist.
    Returns (created, path).
    """
    from talaria.config import CONFIG_DIR

    conv_path = CONFIG_DIR / "conventions.md"
    if conv_path.exists():
        return False, str(conv_path)

    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        conv_path.write_text(EXAMPLE_CONVENTIONS)
        return True, str(conv_path)
    except Exception:
        return False, str(conv_path)


def run_setup(force: bool = False) -> dict:
    """
    Full setup: install skill, create conventions, verify health.
    Returns a results dict.
    """
    from talaria.config import ensure_dirs, TalariaConfig
    from talaria.preflight import check_health

    results = {
        "skill": {"success": False, "message": ""},
        "conventions": {"created": False, "path": ""},
        "config": {"created": False},
        "health": None,
    }

    # 1. Ensure config directories
    ensure_dirs()

    # 2. Create default config if none exists
    config = TalariaConfig.load()
    from talaria.config import CONFIG_FILE
    if not CONFIG_FILE.exists():
        config.save()
        results["config"]["created"] = True

    # 3. Install Hermes skill
    ok, msg = install_hermes_skill(force=force)
    results["skill"]["success"] = ok
    results["skill"]["message"] = msg

    # 4. Create example conventions
    created, path = create_example_conventions()
    results["conventions"]["created"] = created
    results["conventions"]["path"] = path

    # 5. Auto-set conventions file in config if just created
    if created and not config.conventions_file:
        config.set_value("conventions_file", path)

    # 6. Health check
    health = check_health(cache_ttl=0)
    results["health"] = health

    return results
