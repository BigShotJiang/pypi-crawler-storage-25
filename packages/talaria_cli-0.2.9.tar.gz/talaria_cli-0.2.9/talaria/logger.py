"""Per-dispatch log aggregation."""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

from talaria.config import LOGS_DIR


def _day_dir() -> Path:
    """Get today's log directory."""
    day = datetime.now().strftime("%Y-%m-%d")
    d = LOGS_DIR / day
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_dispatch_log(
    session_id: str,
    task: str,
    workdir: str,
    model: str,
    raw_json: dict,
    stderr: str,
    duration: float,
    success: bool,
) -> str:
    """Save full dispatch log. Returns log path."""
    day = _day_dir()
    short_id = session_id[:12] if session_id else f"unknown-{int(time.time())}"
    prefix = f"dispatch-{short_id}"

    # Raw JSON output
    json_path = day / f"{prefix}.json"
    with open(json_path, "w") as f:
        json.dump(raw_json, f, indent=2, default=str)

    # Stderr
    if stderr:
        stderr_path = day / f"{prefix}.stderr"
        stderr_path.write_text(stderr)

    # Metadata
    meta = {
        "session_id": session_id,
        "task": task[:500],
        "workdir": workdir,
        "model": model,
        "duration_seconds": duration,
        "success": success,
        "timestamp": datetime.now().isoformat(),
        "log_files": {
            "json": str(json_path),
            "stderr": str(day / f"{prefix}.stderr") if stderr else None,
        }
    }
    meta_path = day / f"{prefix}.meta.json"
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)

    return str(meta_path)


def list_logs(days: int = 1, failures_only: bool = False) -> list:
    """List dispatch logs."""
    if not LOGS_DIR.exists():
        return []

    results = []
    for day_dir in sorted(LOGS_DIR.iterdir(), reverse=True)[:days]:
        if not day_dir.is_dir():
            continue
        for meta_file in sorted(day_dir.glob("*.meta.json"), reverse=True):
            try:
                meta = json.loads(meta_file.read_text())
                if failures_only and meta.get("success", True):
                    continue
                results.append(meta)
            except (json.JSONDecodeError, OSError):
                continue
    return results


def prune_old_logs(retention_days: int = 30) -> int:
    """Remove logs older than retention period. Returns count removed."""
    if not LOGS_DIR.exists():
        return 0

    import shutil
    cutoff = datetime.now().strftime("%Y-%m-%d")
    removed = 0
    for day_dir in LOGS_DIR.iterdir():
        if day_dir.is_dir() and day_dir.name < cutoff:
            # Simple date comparison works because of YYYY-MM-DD format
            try:
                age_days = (datetime.now() - datetime.strptime(day_dir.name, "%Y-%m-%d")).days
                if age_days > retention_days:
                    shutil.rmtree(day_dir)
                    removed += 1
            except ValueError:
                continue
    return removed
