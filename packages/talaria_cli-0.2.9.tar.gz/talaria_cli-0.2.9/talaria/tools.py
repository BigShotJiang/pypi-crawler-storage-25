"""Toolset translation between agent framework names and Claude Code tool names."""
from __future__ import annotations


# Hermes/agent framework toolset -> Claude Code tool names
TOOLSET_MAP = {
    "terminal": ["Bash"],
    "file": ["Read", "Edit", "Write"],
    "browser": ["WebSearch", "WebFetch"],
    "web": ["WebSearch", "WebFetch"],
    "search": ["WebSearch"],
}

# All known Claude Code tool names (for pass-through detection)
CLAUDE_TOOLS = {
    "Read", "Edit", "Write", "Bash", "MultiEdit",
    "WebSearch", "WebFetch", "Glob", "Grep", "LS",
    "TodoRead", "TodoWrite",
}


def translate_tools(tools: list) -> list:
    """
    Translate tool names to Claude Code format.
    Accepts either Hermes-style names (terminal, file, browser)
    or Claude Code names (Read, Edit, Bash) or a mix.
    Returns deduplicated list of Claude Code tool names.
    """
    result = []
    for tool in tools:
        tool = tool.strip()
        if tool in CLAUDE_TOOLS:
            # Already a Claude Code tool name
            result.append(tool)
        elif tool.lower() in TOOLSET_MAP:
            # Hermes-style toolset name
            result.extend(TOOLSET_MAP[tool.lower()])
        elif tool.startswith("Bash(") or tool.startswith("mcp__"):
            # Pattern-based tool (e.g., Bash(git*), mcp__server__tool)
            result.append(tool)
        else:
            # Unknown - pass through and let claude handle it
            result.append(tool)

    # Deduplicate while preserving order
    seen = set()
    deduped = []
    for t in result:
        if t not in seen:
            seen.add(t)
            deduped.append(t)
    return deduped
