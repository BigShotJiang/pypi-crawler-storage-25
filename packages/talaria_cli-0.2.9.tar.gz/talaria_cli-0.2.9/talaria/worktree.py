"""Git worktree isolation for safe file modifications."""
from __future__ import annotations

import os
import shutil
import subprocess
import uuid
from typing import Optional


WORKTREE_DIR_NAME = ".talaria-worktrees"


def is_git_repo(workdir: str) -> bool:
    """Check if workdir is inside a git repository."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, cwd=workdir, timeout=5,
        )
        return result.returncode == 0
    except Exception:
        return False


def create_worktree(workdir: str, branch_prefix: str = "talaria") -> Optional[str]:
    """
    Create an isolated git worktree for a dispatch task.
    Returns the worktree path, or None on failure.
    """
    if not is_git_repo(workdir):
        return None

    # Get repo root
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, cwd=workdir, timeout=5,
        )
        repo_root = result.stdout.strip()
    except Exception:
        return None

    wt_id = uuid.uuid4().hex[:8]
    branch_name = f"{branch_prefix}/{wt_id}"
    wt_dir = os.path.join(repo_root, WORKTREE_DIR_NAME, wt_id)

    try:
        os.makedirs(os.path.dirname(wt_dir), exist_ok=True)
        subprocess.run(
            ["git", "worktree", "add", "-b", branch_name, wt_dir],
            capture_output=True, text=True, cwd=repo_root, timeout=30,
            check=True,
        )
        return wt_dir
    except Exception:
        return None


def remove_worktree(wt_dir: str) -> bool:
    """Remove a worktree and its branch."""
    try:
        # Get the branch name before removal
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=wt_dir, timeout=5,
        )
        branch = result.stdout.strip()

        # Remove worktree
        repo_root = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, cwd=wt_dir, timeout=5,
        ).stdout.strip()

        subprocess.run(
            ["git", "worktree", "remove", wt_dir, "--force"],
            capture_output=True, text=True, cwd=repo_root, timeout=15,
        )

        # Delete the branch
        if branch and branch.startswith("talaria/"):
            subprocess.run(
                ["git", "branch", "-D", branch],
                capture_output=True, text=True, cwd=repo_root, timeout=5,
            )

        return True
    except Exception:
        # Force cleanup
        shutil.rmtree(wt_dir, ignore_errors=True)
        return False
