"""Self-update helpers for Talaria installs."""
from __future__ import annotations

import json
import subprocess
import sys
import urllib.request
from dataclasses import dataclass
from typing import Optional

from packaging.version import InvalidVersion, Version

from talaria import __version__


PYPI_JSON_URL = "https://pypi.org/pypi/talaria-cli/json"
PACKAGE_NAME = "talaria-cli"


@dataclass
class UpdateResult:
    success: bool
    current_version: str
    latest_version: Optional[str]
    update_available: Optional[bool]
    command: list[str]
    pip_output: str = ""
    setup_output: str = ""
    error: Optional[str] = None


def build_update_command(python_executable: Optional[str] = None) -> list[str]:
    python_executable = python_executable or sys.executable
    return [python_executable, "-m", "pip", "install", "--upgrade", PACKAGE_NAME]


def build_setup_refresh_command(python_executable: Optional[str] = None) -> list[str]:
    python_executable = python_executable or sys.executable
    return [python_executable, "-m", "talaria.cli", "setup", "--force"]


def fetch_latest_version(url: str = PYPI_JSON_URL, timeout: int = 5) -> Optional[str]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
        return data.get("info", {}).get("version")
    except Exception:
        return None


def is_update_available(current: str, latest: Optional[str]) -> Optional[bool]:
    if not latest:
        return None
    return _version_key(latest) > _version_key(current)


def run_update(*, dry_run: bool = False, skip_setup: bool = False) -> UpdateResult:
    command = build_update_command()
    latest = fetch_latest_version()
    available = is_update_available(__version__, latest)

    if dry_run:
        return UpdateResult(
            success=True,
            current_version=__version__,
            latest_version=latest,
            update_available=available,
            command=command,
        )

    if available is False:
        return UpdateResult(
            success=True,
            current_version=__version__,
            latest_version=latest,
            update_available=available,
            command=command,
            setup_output="already up to date",
        )

    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=300)
    except Exception as exc:
        return UpdateResult(
            success=False,
            current_version=__version__,
            latest_version=latest,
            update_available=available,
            command=command,
            error=str(exc),
        )

    pip_output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    if proc.returncode != 0:
        return UpdateResult(
            success=False,
            current_version=__version__,
            latest_version=latest,
            update_available=available,
            command=command,
            pip_output=pip_output.strip(),
            error="pip upgrade failed",
        )

    setup_output = "skipped"
    if not skip_setup:
        setup_command = build_setup_refresh_command()
        setup_proc = subprocess.run(setup_command, capture_output=True, text=True, timeout=300)
        setup_output = ((setup_proc.stdout or "") + ("\n" + setup_proc.stderr if setup_proc.stderr else "")).strip()
        if setup_proc.returncode != 0:
            return UpdateResult(
                success=False,
                current_version=__version__,
                latest_version=latest,
                update_available=available,
                command=command,
                pip_output=pip_output.strip(),
                setup_output=setup_output,
                error="post-upgrade setup refresh failed",
            )

    return UpdateResult(
        success=True,
        current_version=__version__,
        latest_version=latest,
        update_available=available,
        command=command,
        pip_output=pip_output.strip(),
        setup_output=setup_output,
    )


def format_update_command(command: list[str]) -> str:
    return " ".join(_shell_quote(part) for part in command)


def _summarize_setup(results: dict) -> str:
    skill = results.get("skill", {})
    health = results.get("health")
    health_text = health.summary() if health else "health unavailable"
    return f"skill={skill.get('message', 'n/a')}; health={health_text}"


def _setup_succeeded(results: dict) -> bool:
    skill_ok = results.get("skill", {}).get("success", False)
    health = results.get("health")
    health_ok = bool(health and getattr(health, "healthy", False))
    return skill_ok and health_ok


def _version_key(version: str) -> Version:
    try:
        return Version(version)
    except InvalidVersion:
        fallback = "".join(ch if (ch.isdigit() or ch == ".") else "-" for ch in version)
        return Version(fallback.strip("-") or "0")


def _shell_quote(text: str) -> str:
    if not text or any(ch in text for ch in " \t\n\"'"):
        return json.dumps(text)
    return text
