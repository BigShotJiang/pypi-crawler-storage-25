from setuptools import setup, find_packages

setup(
    name="scanner-master",
    version="1.1.0",
    packages=find_packages(),
    install_requires=["typer", "rich", "aiohttp", "pydantic"],
    entry_points={
        'console_scripts': [
            'scanner-master = scanner_master.cli:app',
        ],
    },
)