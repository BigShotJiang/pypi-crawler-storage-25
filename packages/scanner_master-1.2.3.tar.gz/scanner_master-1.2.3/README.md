# Scanner-Master

Professional Security Scanning Toolkit

```bash
pip install scanner-master

# Usage
scanner-master example.com
scanner-master https://google.com --no-ssl-verify
scanner-master urls.txt --concurrency 50