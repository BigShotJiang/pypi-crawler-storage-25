"""Run seed_demo_data from the command line.

Usage:
    DATABASE_URL=postgresql+asyncpg://... uv run python seed.py
"""
import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from gtm_admin.database import setup_engine
from gtm_admin.seed import seed_demo_data

db_url = os.environ.get("DATABASE_URL") or os.environ.get("GTM_DB_URL")
if not db_url:
    sys.exit("Error: set DATABASE_URL or GTM_DB_URL")

setup_engine(db_url)
asyncio.run(seed_demo_data())
