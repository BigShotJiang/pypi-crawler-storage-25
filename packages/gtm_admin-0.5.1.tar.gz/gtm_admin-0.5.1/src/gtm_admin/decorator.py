from __future__ import annotations

import contextvars
import functools
import traceback
import uuid
from datetime import datetime, timezone

from .database import _SessionLocal
from .models import WorkflowRun, WorkflowStatus

# Holds the mutable node-collection context for the currently-executing workflow.
# Shape: {"nodes": list[dict], "plan": list[str]}  — None when not inside a workflow.
_active_run_ctx: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "_active_run_ctx", default=None
)

# Holds the log-line buffer for the currently-executing node — None outside a node.
_active_node_logs: contextvars.ContextVar[list | None] = contextvars.ContextVar(
    "_active_node_logs", default=None
)


def log(message: str, *, type: str = "info", json: bool = False) -> None:
    """Append a structured log entry to the currently executing node's log buffer.

    Call from inside a ``@gtm.node`` function.  If called outside a node
    (or outside a workflow), the message is silently dropped.

    Args:
        message: The log message text.  If the text is a raw JSON string,
                 pass ``json=True`` so the frontend can pretty-print it.
        type:    ``"info"`` (default), ``"warning"``, or ``"error"``.
        json:    Set to ``True`` when *message* is a JSON string.
    """
    buf = _active_node_logs.get()
    if buf is not None:
        buf.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "body": str(message),
            "type": type,
            "json": json,
        })


def plan(*names: str) -> None:
    """Declare the ordered list of nodes this workflow intends to run.

    Any node names in the plan that have not completed when the workflow
    finishes (due to an earlier failure) will be recorded with
    ``status = "pending"`` in the dashboard.

    Call once at the top of a ``@gtm.workflow`` function body.
    """
    ctx = _active_run_ctx.get()
    if ctx is not None:
        ctx["plan"] = list(names)


def _inject_pending(ctx: dict) -> None:
    """Append pending entries for any planned-but-not-executed nodes."""
    executed = {n["name"] for n in ctx["nodes"]}
    for name in ctx.get("plan", []):
        if name not in executed:
            ctx["nodes"].append({
                "id": str(uuid.uuid4()),
                "name": name,
                "status": "pending",
                "inputs": {},
                "outputs": {},
                "duration_ms": 0,
            })


def _run_summary(run: WorkflowRun) -> dict:
    """Serialise a WorkflowRun to the camelCase summary shape expected by the frontend."""
    return {
        "id": str(run.id),
        "name": run.name,
        "status": run.status.value,
        "triggeredBy": run.triggered_by,
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "children": [],
    }


def _run_detail(run: WorkflowRun) -> dict:
    """Serialise a WorkflowRun to the full camelCase detail shape (includes nodes)."""
    nodes = [
        {
            "id": n.get("id", str(run.id)),
            "name": n.get("name", run.name),
            "status": n.get("status", run.status.value),
            "inputs": n.get("inputs", {}),
            "outputs": n.get("outputs", {}),
            "durationMs": n.get("duration_ms", 0),
            "logs": n.get("logs"),
        }
        for n in (run.nodes or [])
    ]
    return {**_run_summary(run), "nodes": nodes}


def make_node_wrapper(fn):
    """Wrap *fn* so each call is recorded as a node in the active workflow run.

    If called outside a workflow (no active run context), the function runs
    transparently with no tracking overhead.
    """

    @functools.wraps(fn)
    async def wrapper(inputs: dict):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        node_id = str(uuid.uuid4())
        node_start = datetime.now(timezone.utc)
        node_logs: list[dict] = []
        logs_token = _active_node_logs.set(node_logs)

        try:
            result = await fn(inputs)
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            ctx["nodes"].append({
                "id": node_id,
                "name": fn.__name__,
                "status": "success",
                "inputs": inputs,
                "outputs": result if isinstance(result, dict) else {},
                "duration_ms": duration_ms,
                "logs": node_logs if node_logs else None,
            })
            return result
        except Exception:
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            tb_entry = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "body": traceback.format_exc(),
                "type": "error",
                "json": False,
            }
            ctx["nodes"].append({
                "id": node_id,
                "name": fn.__name__,
                "status": "failed",
                "inputs": inputs,
                "outputs": {},
                "duration_ms": duration_ms,
                "logs": [*node_logs, tb_entry],
            })
            raise
        finally:
            _active_node_logs.reset(logs_token)

    wrapper._gtm_fn = fn
    return wrapper


def make_workflow_wrapper(fn):
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _trigger_type: str = "manual"):
        if _SessionLocal is None:
            return await fn(inputs)

        from .broadcast import manager

        async with _SessionLocal() as session:
            run = WorkflowRun(
                name=fn.__name__,
                status=WorkflowStatus.running,
                triggered_by=_trigger_type,
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)

            await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(run)})

            ctx: dict = {"nodes": [], "plan": []}
            token = _active_run_ctx.set(ctx)
            failure_exc: Exception | None = None
            try:
                result = await fn(inputs)
                run.status = WorkflowStatus.success
                _inject_pending(ctx)
                if ctx["nodes"]:
                    run.nodes = ctx["nodes"]
                else:
                    run.nodes = [
                        {
                            "id": str(run.id),
                            "name": fn.__name__,
                            "status": "success",
                            "inputs": inputs,
                            "outputs": result if isinstance(result, dict) else {},
                            "duration_ms": int(
                                (datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000
                            ),
                        }
                    ]
            except Exception as exc:
                failure_exc = exc
                run.status = WorkflowStatus.failed
                _inject_pending(ctx)
                if ctx["nodes"]:
                    run.nodes = ctx["nodes"]
                else:
                    run.nodes = [
                        {
                            "id": str(run.id),
                            "name": fn.__name__,
                            "status": "failed",
                            "inputs": inputs,
                            "outputs": {},
                            "duration_ms": int(
                                (datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000
                            ),
                            "logs": [{
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                                "body": traceback.format_exc(),
                                "type": "error",
                                "json": False,
                            }],
                        }
                    ]
                result = None
            finally:
                _active_run_ctx.reset(token)

            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            await session.commit()

            await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run)})
            await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run)})

        if failure_exc is not None:
            raise failure_exc

        return result

    wrapper._gtm_fn = fn
    return wrapper
