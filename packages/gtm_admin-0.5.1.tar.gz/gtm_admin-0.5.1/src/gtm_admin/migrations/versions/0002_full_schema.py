"""Migrate workflow_runs to rich schema; add config_records and db_tables.

Revision ID: 0002
Revises: 0001
Create Date: 2026-04-05
"""
from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel
from alembic import op

revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Replace the old minimal workflow_runs with the full schema.
    # (Old columns: workflow, status, inputs, outputs, error, started_at,
    #  finished_at, duration_ms.  New columns: name, status, triggered_by,
    #  started_at, finished_at, created_at, parent_id, nodes.)
    op.drop_table("workflow_runs")
    op.create_table(
        "workflow_runs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("status", sqlmodel.AutoString(), nullable=False, server_default="pending"),
        sa.Column("triggered_by", sqlmodel.AutoString(), nullable=False, server_default="manual"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("parent_id", sa.Uuid(), nullable=True),
        sa.Column("nodes", sa.JSON(), nullable=True),
        sa.ForeignKeyConstraint(["parent_id"], ["workflow_runs.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_workflow_runs_parent_id", "workflow_runs", ["parent_id"])

    op.create_table(
        "config_records",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("key", sqlmodel.AutoString(), nullable=False),
        sa.Column("value", sqlmodel.AutoString(), nullable=False),
        sa.Column("type", sqlmodel.AutoString(), nullable=False),
        sa.Column("select_options", sa.JSON(), nullable=True),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("folder", sqlmodel.AutoString(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("key"),
    )
    op.create_index("ix_config_records_key", "config_records", ["key"])

    op.create_table(
        "db_tables",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("columns", sa.JSON(), nullable=True),
        sa.Column("rows", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("db_tables")
    op.drop_table("config_records")
    op.drop_index("ix_workflow_runs_parent_id", "workflow_runs")
    op.drop_table("workflow_runs")
    op.create_table(
        "workflow_runs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("workflow", sqlmodel.AutoString(), nullable=False),
        sa.Column("status", sqlmodel.AutoString(), nullable=False),
        sa.Column("inputs", sa.JSON(), nullable=True),
        sa.Column("outputs", sa.JSON(), nullable=True),
        sa.Column("error", sqlmodel.AutoString(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
