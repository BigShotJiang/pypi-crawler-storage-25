from datetime import datetime, timedelta, timezone

import bcrypt
from jose import jwt

_secret: str = ""


def configure(secret: str) -> None:
    global _secret
    _secret = secret


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode(), hashed.encode())


def create_access_token(subject: str, expire_minutes: int = 60 * 24) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=expire_minutes)
    return jwt.encode({"sub": subject, "exp": expire}, _secret, algorithm="HS256")


def decode_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, _secret, algorithms=["HS256"])
        return payload.get("sub")
    except Exception:
        return None
