# ign8inventory

**Provision a production-ready [NetBox](https://netbox.dev/) DCIM/IPAM instance in minutes** — Hetzner Cloud VM, Cloudflare DNS, Let's Encrypt TLS, PostgreSQL, and an opinionated default layout, all from a single CLI command.

```
pip install ign8inventory
ign8inventory setenv   # configure credentials
ign8inventory up       # provision everything
ign8inventory bootstrap  # populate regions, sites, locations
```

## Features

- **Single command provisioning** — one `ign8inventory up` creates the Hetzner VM, DNS record, TLS certificate, and a fully configured NetBox instance
- **Idempotent** — re-running any command is safe; existing resources are detected and reused
- **No Terraform, no Ansible** — pure Python using the official Hetzner and Cloudflare SDKs
- **Database backup** — `ign8inventory backup` exports the PostgreSQL database via SSH and commits it to your repository
- **Live server seeding** — `ign8inventory seed` queries your Hetzner projects and upserts running servers into NetBox
- **Vault integration** — secrets in `infrastructure.yml` can be stored in and resolved from HashiCorp Vault

## Requirements

- Python 3.9+
- A [Hetzner Cloud](https://www.hetzner.com/cloud) account and API token
- A [Cloudflare](https://cloudflare.com) account managing your domain, with a Zone DNS Edit token

## Installation

```bash
pipx install ign8inventory   # recommended
# or
pip install ign8inventory
```

## Quickstart

```bash
# 1. Configure — writes a .env file with all credentials
ign8inventory setenv

# 2. Provision — Hetzner VM + Cloudflare DNS + TLS + NetBox
ign8inventory up

# 3. Bootstrap — create regions, sites, and availability zones
ign8inventory bootstrap

# 4. Backup — export the database and commit it
ign8inventory backup
```

Run `ign8inventory quickstart` for the full step-by-step guide.

## Commands

| Command | Description |
|---------|-------------|
| `up` | Provision Hetzner VM, Cloudflare DNS, TLS, and install NetBox |
| `bootstrap` | Populate NetBox with regions, sites, and locations |
| `seed` | Query live Hetzner projects and upsert servers into NetBox |
| `backup` | Export the PostgreSQL database via SSH, save to `backup/netbox.sql`, and commit |
| `show-users` | List all NetBox users |
| `add-user` | Create a new NetBox user |
| `vault-put` | Push `infrastructure.yml` secrets to HashiCorp Vault |
| `setenv` | Interactive credential setup — writes `.env` |
| `destroy` | Tear down the server and DNS records |

## Default layout

`ign8inventory bootstrap` creates:

- **Regions**: Europe, North America, Asia Pacific
- **Sites**: nbg1, fsn1, hel1 (EU) · ash1, hil1 (US) · sin1 (APAC)
- **Locations**: zone-a, zone-b per site

## Environment variables

| Variable | Description |
|----------|-------------|
| `IGN8_DOMAIN` | Base domain — `inventory.DOMAIN` will be created |
| `IGN8_ADMIN_EMAIL` | Contact email for Let's Encrypt |
| `IGN8_HETZNER_TOKEN` | Hetzner Cloud API token |
| `IGN8_CLOUDFLARE_TOKEN` | Cloudflare API token (Zone DNS Edit) |
| `IGN8_CLOUDFLARE_ZONE_ID` | Cloudflare Zone ID |
| `IGN8_NETBOX_SUPERUSER` | NetBox admin username (default: `admin`) |
| `IGN8_NETBOX_PASSWORD` | NetBox admin password |
| `IGN8_NETBOX_TOKEN` | API token — filled in after `up`, used by `bootstrap` and `seed` |

All variables can also be set via a `.env` file or passed as CLI flags.

## License

MIT
