"""Resolve vault: secret references against a HashiCorp Vault instance.

Reference format in YAML:  vault:secret/ign8inventory/hetzner/prod#api_key
                                   ^--- KV mount + path         ^--- field

Connection is resolved in order:
  1. IGN8_VAULT_ADDR + IGN8_VAULT_TOKEN env vars (.env)
  2. ~/.ign8vault/vault-init.json (sibling ign8vault project, root token)
  3. VAULT_ADDR + VAULT_TOKEN env vars (last — may be a scoped SSH-signing token)
"""

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


_VAULT_INIT_CANDIDATES = [
    Path("~/.ign8vault/vault-init.json").expanduser(),
    Path("~/development/ign8vault/.ign8vault/vault-init.json").expanduser(),
]


def _connection() -> tuple[str, str]:
    # Prefer the ign8-namespaced vars — they carry admin credentials.
    # Fall back to vault-init.json (root token), then the generic VAULT_TOKEN
    # which may be a scoped SSH-signing token with insufficient permissions.
    addr = os.environ.get("IGN8_VAULT_ADDR", "")
    token = os.environ.get("IGN8_VAULT_TOKEN", "")

    if not (addr and token):
        for candidate in _VAULT_INIT_CANDIDATES:
            if candidate.exists():
                data = json.loads(candidate.read_text())
                addr = addr or data.get("vault_url", "")
                token = token or data.get("root_token", "")
                break

    # Last resort: generic env vars (may be scoped/limited)
    addr = addr or os.environ.get("VAULT_ADDR", "")
    token = token or os.environ.get("VAULT_TOKEN", "")

    if not addr or not token:
        raise RuntimeError(
            "Vault connection not configured.\n"
            "Set IGN8_VAULT_ADDR + IGN8_VAULT_TOKEN, or run ign8vault up first."
        )
    return addr.rstrip("/"), token


def _api(method: str, api_path: str, body: dict | None = None) -> dict | None:
    addr, token = _connection()
    url = f"{addr}/v1/{api_path}"
    headers: dict[str, str] = {"X-Vault-Token": token}
    data: bytes | None = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError:
        return None


def _ensure_kv_mount(mount: str) -> None:
    """Enable KV v2 at mount if not already present (idempotent)."""
    existing = _api("GET", "sys/mounts") or {}
    if f"{mount}/" not in existing:
        _api("POST", f"sys/mounts/{mount}", {"type": "kv", "options": {"version": "2"}})


def get_secret(path: str, field: str | None = None) -> Any:
    """Fetch a secret from Vault KV (tries v2 then v1).

    path  — e.g. 'secret/ign8inventory/hetzner/prod'
    field — optional key within the secret dict
    """
    parts = path.split("/", 1)
    kv2_path = f"{parts[0]}/data/{parts[1]}" if len(parts) == 2 else path

    response = _api("GET", kv2_path)
    if response and isinstance(response.get("data"), dict) and "data" in response["data"]:
        data = response["data"]["data"]
    else:
        response = _api("GET", path)
        if not response:
            raise KeyError(f"Secret not found: vault:{path}")
        data = response.get("data", {})

    if field is None:
        return data
    if field not in data:
        raise KeyError(f"Field '{field}' not in vault:{path} — available: {list(data)}")
    return data[field]


def put_secret(path: str, fields: dict[str, str]) -> None:
    """Write fields to Vault KV v2 at path, enabling the mount if needed."""
    mount = path.split("/")[0]
    _ensure_kv_mount(mount)

    parts = path.split("/", 1)
    kv2_path = f"{parts[0]}/data/{parts[1]}" if len(parts) == 2 else path

    addr, token = _connection()
    url = f"{addr}/v1/{kv2_path}"
    body = json.dumps({"data": fields}).encode()
    req = urllib.request.Request(
        url, data=body,
        headers={"X-Vault-Token": token, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"vault kv put failed for {path}: {e.read().decode()}") from e


def collect_refs(data: Any, refs: dict[str, dict[str, str]] | None = None) -> dict[str, dict[str, str]]:
    """Walk parsed YAML and return {path: {field: ''}} for every vault: reference."""
    if refs is None:
        refs = {}
    if isinstance(data, str) and data.startswith("vault:"):
        ref = data[len("vault:"):]
        path, _, field = ref.partition("#")
        refs.setdefault(path, {})[field] = ""
    elif isinstance(data, dict):
        for v in data.values():
            collect_refs(v, refs)
    elif isinstance(data, list):
        for item in data:
            collect_refs(item, refs)
    return refs


def resolve(value: Any) -> Any:
    """Recursively resolve vault: references in nested dicts/lists/strings."""
    if isinstance(value, str) and value.startswith("vault:"):
        ref = value[len("vault:"):]
        path, _, field = ref.partition("#")
        return get_secret(path, field or None)
    if isinstance(value, dict):
        return {k: resolve(v) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve(item) for item in value]
    return value
