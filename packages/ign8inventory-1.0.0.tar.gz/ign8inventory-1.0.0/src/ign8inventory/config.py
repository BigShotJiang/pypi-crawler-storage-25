from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="IGN8_", env_file=".env", extra="ignore")

    # Required
    domain: str
    admin_email: str
    hetzner_token: str
    cloudflare_token: str
    cloudflare_zone_id: str
    cloudflare_email: str = ""

    # Vault (auto-discovered from ign8vault's vault-init.json if not set)
    vault_addr: str = ""
    vault_token: str = ""

    # NetBox superuser
    netbox_superuser: str = "admin"
    netbox_password: str = ""
    netbox_token: str = ""  # filled in after provisioning

    # Server
    server_location: str = "nbg1"
    server_type: str = "cpx21"
    server_image: str = "ubuntu-24.04"

    @field_validator("domain")
    @classmethod
    def strip_trailing_dot(cls, v: str) -> str:
        return v.rstrip(".")
