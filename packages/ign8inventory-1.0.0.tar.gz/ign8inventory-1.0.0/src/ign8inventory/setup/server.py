"""SSH into the provisioned server and install NetBox + dependencies."""

import io
import secrets
import time
from typing import Optional

import paramiko

from ign8inventory.config import Config

_PACKAGES = (
    "postgresql redis-server nginx certbot python3-certbot-nginx "
    "python3 python3-venv python3-pip python3-dev git libpq-dev build-essential"
)

_NETBOX_CONFIG_TMPL = """\
ALLOWED_HOSTS = ['{hostname}', 'localhost', '127.0.0.1']

DATABASE = {{
    'ENGINE': 'django.db.backends.postgresql',
    'NAME': 'netbox',
    'USER': 'netbox',
    'PASSWORD': '{db_password}',
    'HOST': 'localhost',
    'PORT': '',
}}

REDIS = {{
    'tasks': {{
        'HOST': 'localhost',
        'PORT': 6379,
        'DATABASE': 0,
        'SSL': False,
    }},
    'caching': {{
        'HOST': 'localhost',
        'PORT': 6379,
        'DATABASE': 1,
        'SSL': False,
    }},
}}

SECRET_KEY = '{secret_key}'

# NetBox 4.x: required for v2 API token hashing
API_TOKEN_PEPPERS = {{0: '{token_pepper}'}}
"""

_CREATE_SUPERUSER_SCRIPT = """\
from django.contrib.auth import get_user_model
from users.models import Token
User = get_user_model()
u, _ = User.objects.get_or_create(username='{superuser}', defaults={{'is_superuser': True, 'email': '{admin_email}'}})
u.set_password('{superuser_password}')
u.is_superuser = True
u.save()
Token.objects.filter(user=u).delete()
t = Token(user=u)
t.save()
print(t.get_auth_header_prefix() + t._token)
"""

_GUNICORN_CONFIG = """\
command = '/opt/netbox/venv/bin/gunicorn'
pythonpath = '/opt/netbox/netbox'
bind = '127.0.0.1:8001'
workers = 5
worker_class = 'sync'
timeout = 120
"""

_NETBOX_SERVICE = """\
[Unit]
Description=NetBox WSGI Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=PYTHONPATH=/opt/netbox/netbox
WorkingDirectory=/opt/netbox/netbox
ExecStart=/opt/netbox/venv/bin/gunicorn --pid /var/tmp/netbox.pid --config /opt/netbox/gunicorn.py netbox.wsgi
User=netbox
Group=netbox
Restart=on-failure
RestartSec=30
PrivateTmp=true

[Install]
WantedBy=multi-user.target
"""

_NETBOX_RQ_SERVICE = """\
[Unit]
Description=NetBox Request Queue Worker
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=PYTHONPATH=/opt/netbox/netbox
ExecStart=/opt/netbox/venv/bin/python /opt/netbox/netbox/manage.py rqworker high default low
User=netbox
Group=netbox
Restart=on-failure
RestartSec=30
PrivateTmp=true

[Install]
WantedBy=multi-user.target
"""

_NGINX_ACME_TMPL = """\
server {{
    listen 80;
    server_name inventory.{domain};
    root /var/www/html;
    location /.well-known/acme-challenge/ {{ try_files $uri =404; }}
    location / {{ return 200 'ok'; add_header Content-Type text/plain; }}
}}
"""

_NGINX_FINAL_TMPL = """\
server {{
    listen 80;
    server_name inventory.{domain};
    location /.well-known/acme-challenge/ {{ root /var/www/html; }}
    location / {{ return 301 https://$host$request_uri; }}
}}

server {{
    listen 443 ssl http2;
    server_name inventory.{domain};

    ssl_certificate     /etc/letsencrypt/live/inventory.{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/inventory.{domain}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;

    client_max_body_size 25m;

    location /static/ {{
        alias /opt/netbox/netbox/static/;
    }}

    location / {{
        proxy_pass         http://127.0.0.1:8001;
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto https;
        proxy_read_timeout 300s;
    }}
}}
"""


class NetboxSetup:
    def __init__(self, cfg: Config, host: str, private_key_path: str) -> None:
        self._cfg = cfg
        self._host = host
        self._key_path = private_key_path
        self._ssh: Optional[paramiko.SSHClient] = None

    def connect(self, retries: int = 30, delay: int = 10) -> None:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        key = paramiko.RSAKey.from_private_key_file(self._key_path)

        for attempt in range(retries):
            try:
                client.connect(self._host, username="root", pkey=key, timeout=15)
                self._ssh = client
                return
            except Exception:
                if attempt == retries - 1:
                    raise
                time.sleep(delay)

    def disconnect(self) -> None:
        if self._ssh:
            self._ssh.close()
            self._ssh = None

    def run(self) -> dict[str, str]:
        """Full server setup. Returns {api_token, db_password}."""
        assert self._ssh, "Call connect() first"

        db_password = secrets.token_hex(16)
        secret_key = secrets.token_urlsafe(50)
        token_pepper = secrets.token_hex(32)

        self._install_packages()
        self._setup_postgres(db_password)
        api_token = self._install_netbox(db_password, secret_key, token_pepper)
        self._setup_nginx_acme()
        self._get_tls_certs()
        self._setup_nginx_final()

        return {"api_token": api_token, "db_password": db_password}

    # ------------------------------------------------------------------
    # Installation

    def _install_packages(self) -> None:
        self._exec("apt-get update -qq")
        self._exec(f"DEBIAN_FRONTEND=noninteractive apt-get install -y -qq {_PACKAGES}")

    def _setup_postgres(self, db_password: str) -> None:
        self._exec("systemctl enable postgresql && systemctl start postgresql")
        self._exec(
            f"sudo -u postgres psql -tc \"SELECT 1 FROM pg_roles WHERE rolname='netbox'\" "
            f"| grep -q 1 || sudo -u postgres psql -c "
            f"\"CREATE USER netbox WITH PASSWORD '{db_password}';\""
        )
        self._exec(
            "sudo -u postgres psql -tc \"SELECT 1 FROM pg_database WHERE datname='netbox'\" "
            "| grep -q 1 || sudo -u postgres psql -c "
            "\"CREATE DATABASE netbox OWNER netbox;\""
        )

    def _install_netbox(self, db_password: str, secret_key: str, token_pepper: str) -> str:
        cfg = self._cfg
        hostname = f"inventory.{cfg.domain}"

        # Clone latest stable release
        self._exec(
            "test -d /opt/netbox || ("
            "  NETBOX_VER=$(curl -s https://api.github.com/repos/netbox-community/netbox/releases/latest"
            "    | grep '\"tag_name\"' | cut -d'\"' -f4) &&"
            "  git clone -b \"$NETBOX_VER\" --depth 1"
            "    https://github.com/netbox-community/netbox.git /opt/netbox"
            ")"
        )

        # System user
        self._exec("id netbox &>/dev/null || adduser --system --group netbox")
        self._exec(
            "mkdir -p /opt/netbox/netbox/media /opt/netbox/netbox/reports /opt/netbox/netbox/scripts"
            " && chown -R netbox:netbox /opt/netbox/netbox/media"
            "                          /opt/netbox/netbox/reports"
            "                          /opt/netbox/netbox/scripts"
        )

        # Virtualenv + dependencies
        self._exec(
            "test -d /opt/netbox/venv"
            " || python3 -m venv /opt/netbox/venv"
        )
        self._exec("/opt/netbox/venv/bin/pip install -q --upgrade pip")
        self._exec("/opt/netbox/venv/bin/pip install -q -r /opt/netbox/requirements.txt")

        # Configuration
        netbox_cfg = _NETBOX_CONFIG_TMPL.format(
            hostname=hostname,
            db_password=db_password,
            secret_key=secret_key,
            token_pepper=token_pepper,
        )
        self._write_remote("/opt/netbox/netbox/netbox/configuration.py", netbox_cfg)

        # gunicorn config
        self._write_remote("/opt/netbox/gunicorn.py", _GUNICORN_CONFIG)

        # Database migration + static files
        self._exec(
            "cd /opt/netbox/netbox"
            " && /opt/netbox/venv/bin/python manage.py migrate --no-input"
        )
        self._exec(
            "cd /opt/netbox/netbox"
            " && /opt/netbox/venv/bin/python manage.py collectstatic --no-input"
        )

        # Create superuser + API token (NetBox 4.x dropped SUPERUSER_* config settings)
        script = _CREATE_SUPERUSER_SCRIPT.format(
            superuser=cfg.netbox_superuser,
            admin_email=cfg.admin_email,
            superuser_password=cfg.netbox_password,
        )
        api_token = self._exec(
            f"cd /opt/netbox/netbox && /opt/netbox/venv/bin/python manage.py shell -c {script!r}"
        ).strip()

        # Systemd services
        self._write_remote("/etc/systemd/system/netbox.service", _NETBOX_SERVICE)
        self._write_remote("/etc/systemd/system/netbox-rq.service", _NETBOX_RQ_SERVICE)
        self._exec(
            "systemctl daemon-reload"
            " && systemctl enable netbox netbox-rq"
            " && systemctl restart netbox netbox-rq"
        )

        # Wait for NetBox to answer
        for _ in range(30):
            code = self._exec(
                "curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8001/ || true"
            ).strip()
            if code in ("200", "301", "302"):
                return api_token
            time.sleep(3)
        raise RuntimeError("NetBox did not become healthy within 90s")

    # ------------------------------------------------------------------
    # nginx + TLS

    def _setup_nginx_acme(self) -> None:
        self._exec("mkdir -p /var/www/html && rm -f /etc/nginx/sites-enabled/default")
        acme_cfg = _NGINX_ACME_TMPL.format(domain=self._cfg.domain)
        self._write_remote("/etc/nginx/sites-available/ign8inventory", acme_cfg)
        self._exec(
            "ln -sf /etc/nginx/sites-available/ign8inventory"
            "       /etc/nginx/sites-enabled/ign8inventory"
            " && nginx -t && systemctl reload nginx"
        )

    def _get_tls_certs(self) -> None:
        domain = self._cfg.domain
        self._exec(
            f"certbot certonly --webroot -w /var/www/html"
            f" -d inventory.{domain}"
            f" --non-interactive --agree-tos -m {self._cfg.admin_email}"
        )

    def _setup_nginx_final(self) -> None:
        final_cfg = _NGINX_FINAL_TMPL.format(domain=self._cfg.domain)
        self._write_remote("/etc/nginx/sites-available/ign8inventory", final_cfg)
        self._exec("nginx -t && systemctl reload nginx")

    def dump_database(self) -> bytes:
        """Run pg_dump on the server and return the plain-SQL dump as bytes."""
        assert self._ssh, "Call connect() first"
        _, stdout, stderr = self._ssh.exec_command(
            "sudo -u postgres pg_dump -Fp --no-owner --no-acl netbox"
        )
        exit_code = stdout.channel.recv_exit_status()
        data = stdout.read()
        if exit_code != 0:
            raise RuntimeError(f"pg_dump failed: {stderr.read().decode()}")
        return data

    # ------------------------------------------------------------------
    # Helpers

    def _write_remote(self, remote_path: str, content: str) -> None:
        assert self._ssh
        sftp = self._ssh.open_sftp()
        try:
            sftp.putfo(io.BytesIO(content.encode()), remote_path)
        finally:
            sftp.close()

    def _exec(self, cmd: str) -> str:
        assert self._ssh
        _, stdout, stderr = self._ssh.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()
        output = stdout.read().decode()
        if exit_code != 0:
            raise RuntimeError(f"Command failed ({exit_code}): {cmd}\n{stderr.read().decode()}")
        return output
