"""Bootstrap NetBox with an opinionated regions / sites / locations layout."""

import json
import re
import urllib.error
import urllib.request

# ---------------------------------------------------------------------------
# Default layout
# ---------------------------------------------------------------------------

REGIONS = [
    {"name": "Europe",        "slug": "eu"},
    {"name": "North America", "slug": "us"},
    {"name": "Asia Pacific",  "slug": "apac"},
]

SITES = [
    {"name": "Nuremberg",   "slug": "nbg1", "region": "eu"},
    {"name": "Falkenstein", "slug": "fsn1", "region": "eu"},
    {"name": "Helsinki",    "slug": "hel1", "region": "eu"},
    {"name": "Ashburn",     "slug": "ash1", "region": "us"},
    {"name": "Hillsboro",   "slug": "hil1", "region": "us"},
    {"name": "Singapore",   "slug": "sin1", "region": "apac"},
]

# Two availability zones per site
ZONES_PER_SITE = ["zone-a", "zone-b"]


def _slugify(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


# ---------------------------------------------------------------------------
# Bootstrapper
# ---------------------------------------------------------------------------

class NetboxBootstrap:
    def __init__(self, netbox_url: str, api_token: str) -> None:
        self._base = netbox_url.rstrip("/")
        self._token = api_token

    def run(self) -> dict[str, list[str]]:
        """Create regions, sites, and locations. Returns a summary of created slugs."""
        region_ids = self._create_regions()
        site_ids = self._create_sites(region_ids)
        locations = self._create_locations(site_ids)
        return {
            "regions": list(region_ids),
            "sites": list(site_ids),
            "locations": locations,
        }

    def _create_regions(self) -> dict[str, int]:
        ids: dict[str, int] = {}
        for region in REGIONS:
            obj = self._upsert("/api/dcim/regions/", region, region["slug"])
            ids[region["slug"]] = obj["id"]
        return ids

    def _create_sites(self, region_ids: dict[str, int]) -> dict[str, int]:
        ids: dict[str, int] = {}
        for site in SITES:
            payload = {
                "name":   site["name"],
                "slug":   site["slug"],
                "region": region_ids[site["region"]],
                "status": "active",
            }
            obj = self._upsert("/api/dcim/sites/", payload, site["slug"])
            ids[site["slug"]] = obj["id"]
        return ids

    def _create_locations(self, site_ids: dict[str, int]) -> list[str]:
        created: list[str] = []
        for site_slug, site_id in site_ids.items():
            for zone in ZONES_PER_SITE:
                slug = f"{site_slug}-{zone}"
                payload = {
                    "name":   zone.replace("-", " ").title(),
                    "slug":   slug,
                    "site":   site_id,
                    "status": "active",
                }
                self._upsert("/api/dcim/locations/", payload, slug)
                created.append(slug)
        return created

    # ------------------------------------------------------------------
    # Users

    def list_users(self) -> list[dict]:
        result = self._get("/api/users/users/?limit=1000")
        return result.get("results", [])  # type: ignore[return-value]

    def add_user(self, username: str, password: str) -> dict:
        return self._post("/api/users/users/", {
            "username": username,
            "password": password,
            "is_active": True,
        })

    # ------------------------------------------------------------------
    # Virtualization seeding

    def seed_hetzner_project(self, project_name: str, servers: list) -> dict[str, object]:
        """Upsert a Hetzner project's live servers into NetBox Virtualization."""
        import ipaddress

        ct_id = self._ensure_cluster_type("Hetzner Cloud", "hetzner-cloud")
        cluster_id = self._ensure_cluster(project_name, _slugify(project_name), ct_id)

        seeded: list[str] = []
        for server in servers:
            site_id = self._find_site(server.location.name)
            image_name = server.image.name if server.image else "unknown"
            platform_id = self._ensure_platform(image_name, _slugify(image_name))
            status = "active" if server.status == "running" else "offline"
            memory_mb = int(server.server_type.memory * 1024)

            vm_id = self._ensure_vm(
                name=server.name,
                cluster_id=cluster_id,
                site_id=site_id,
                vcpus=float(server.server_type.cores),
                memory_mb=memory_mb,
                disk_gb=server.server_type.disk,
                status=status,
                platform_id=platform_id,
                comments=f"type:{server.server_type.name}",
            )

            iface_id = self._ensure_vm_interface(vm_id, "eth0")

            if server.public_net.ipv4:
                ip4_id = self._ensure_ip_address(
                    f"{server.public_net.ipv4.ip}/32", iface_id
                )
                self._set_primary_ip(vm_id, ip4_id=ip4_id)

            if server.public_net.ipv6:
                net = ipaddress.IPv6Network(server.public_net.ipv6.ip, strict=False)
                host = str(net.network_address + 1)
                ip6_id = self._ensure_ip_address(f"{host}/128", iface_id)
                self._set_primary_ip(vm_id, ip6_id=ip6_id)

            seeded.append(server.name)

        return {"cluster": project_name, "vms": seeded}

    def _ensure_cluster_type(self, name: str, slug: str) -> int:
        obj = self._upsert("/api/virtualization/cluster-types/", {"name": name, "slug": slug}, slug)
        return obj["id"]

    def _ensure_cluster(self, name: str, slug: str, cluster_type_id: int) -> int:
        existing = self._get(f"/api/virtualization/clusters/?slug={slug}")
        if existing["count"] > 0:
            return existing["results"][0]["id"]  # type: ignore[return-value]
        obj = self._post("/api/virtualization/clusters/", {
            "name": name,
            "slug": slug,
            "type": cluster_type_id,
        })
        return obj["id"]

    def _ensure_platform(self, name: str, slug: str) -> int:
        obj = self._upsert("/api/dcim/platforms/", {"name": name, "slug": slug}, slug)
        return obj["id"]

    def _find_site(self, slug: str) -> int | None:
        result = self._get(f"/api/dcim/sites/?slug={slug}")
        if result["count"] > 0:
            return result["results"][0]["id"]  # type: ignore[return-value]
        return None

    def _ensure_vm(
        self,
        name: str,
        cluster_id: int,
        site_id: int | None,
        vcpus: float,
        memory_mb: int,
        disk_gb: int,
        status: str,
        platform_id: int | None,
        comments: str = "",
    ) -> int:
        existing = self._get(
            f"/api/virtualization/virtual-machines/?name={name}&cluster_id={cluster_id}"
        )
        if existing["count"] > 0:
            vm = existing["results"][0]
            self._patch(f"/api/virtualization/virtual-machines/{vm['id']}/", {
                "status": status,
                "vcpus": vcpus,
                "memory": memory_mb,
                "disk": disk_gb,
                **({"site": site_id} if site_id else {}),
                **({"platform": platform_id} if platform_id else {}),
                **({"comments": comments} if comments else {}),
            })
            return vm["id"]  # type: ignore[return-value]

        payload: dict = {
            "name": name,
            "cluster": cluster_id,
            "status": status,
            "vcpus": vcpus,
            "memory": memory_mb,
            "disk": disk_gb,
        }
        if site_id:
            payload["site"] = site_id
        if platform_id:
            payload["platform"] = platform_id
        if comments:
            payload["comments"] = comments
        return self._post("/api/virtualization/virtual-machines/", payload)["id"]

    def _ensure_vm_interface(self, vm_id: int, name: str) -> int:
        existing = self._get(
            f"/api/virtualization/interfaces/?virtual_machine_id={vm_id}&name={name}"
        )
        if existing["count"] > 0:
            return existing["results"][0]["id"]  # type: ignore[return-value]
        return self._post("/api/virtualization/interfaces/", {
            "virtual_machine": vm_id,
            "name": name,
        })["id"]

    def _ensure_ip_address(self, address: str, interface_id: int) -> int:
        existing = self._get(f"/api/ipam/ip-addresses/?address={address}")
        if existing["count"] > 0:
            return existing["results"][0]["id"]  # type: ignore[return-value]
        return self._post("/api/ipam/ip-addresses/", {
            "address": address,
            "status": "active",
            "assigned_object_type": "virtualization.vminterface",
            "assigned_object_id": interface_id,
        })["id"]

    def _set_primary_ip(
        self, vm_id: int, ip4_id: int | None = None, ip6_id: int | None = None
    ) -> None:
        payload: dict = {}
        if ip4_id is not None:
            payload["primary_ip4"] = ip4_id
        if ip6_id is not None:
            payload["primary_ip6"] = ip6_id
        if payload:
            self._patch(f"/api/virtualization/virtual-machines/{vm_id}/", payload)

    # ------------------------------------------------------------------
    # HTTP helpers

    def _upsert(self, path: str, payload: dict, slug: str) -> dict:
        """Create or return existing object by slug."""
        existing = self._get(f"{path}?slug={slug}")
        if existing["count"] > 0:
            return existing["results"][0]  # type: ignore[return-value]
        return self._post(path, payload)

    def _get(self, path: str) -> dict:
        req = urllib.request.Request(
            f"{self._base}{path}",
            headers={"Authorization": f"Bearer {self._token}", "Accept": "application/json"},
        )
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())  # type: ignore[return-value]

    def _post(self, path: str, payload: dict) -> dict:
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{self._base}{path}",
            data=data,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read())  # type: ignore[return-value]
        except urllib.error.HTTPError as exc:
            body = exc.read().decode()
            raise RuntimeError(f"POST {path} failed ({exc.code}): {body}") from exc

    def _patch(self, path: str, payload: dict) -> dict:
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{self._base}{path}",
            data=data,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="PATCH",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read())  # type: ignore[return-value]
        except urllib.error.HTTPError as exc:
            body = exc.read().decode()
            raise RuntimeError(f"PATCH {path} failed ({exc.code}): {body}") from exc
