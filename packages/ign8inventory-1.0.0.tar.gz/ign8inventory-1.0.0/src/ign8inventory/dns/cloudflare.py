"""Create DNS record for inventory.DOMAIN."""

import cloudflare
from cloudflare.types.dns import RecordCreateParams


class CloudflareDNS:
    def __init__(self, token: str, zone_id: str, domain: str, email: str = "") -> None:
        if email:
            self._cf = cloudflare.Cloudflare(api_email=email, api_key=token)
        else:
            self._cf = cloudflare.Cloudflare(api_token=token)
        self._zone = zone_id
        self._domain = domain

    def provision(self, ipv4: str, ipv6: str) -> None:
        records: list[RecordCreateParams] = [
            {"type": "A", "name": f"inventory.{self._domain}", "content": ipv4, "proxied": False, "ttl": 1},
        ]
        if ipv6:
            records.append(
                {"type": "AAAA", "name": f"inventory.{self._domain}", "content": ipv6, "proxied": False, "ttl": 1},
            )

        names = {r["name"] for r in records}  # type: ignore[index]
        for existing in self._cf.dns.records.list(zone_id=self._zone).result or []:
            if existing.name in names:
                self._cf.dns.records.delete(existing.id, zone_id=self._zone)

        for record in records:
            self._cf.dns.records.create(zone_id=self._zone, **record)  # type: ignore[arg-type]

    def destroy(self) -> None:
        targets = {f"inventory.{self._domain}"}
        for existing in self._cf.dns.records.list(zone_id=self._zone).result or []:
            if existing.name in targets:
                self._cf.dns.records.delete(existing.id, zone_id=self._zone)
