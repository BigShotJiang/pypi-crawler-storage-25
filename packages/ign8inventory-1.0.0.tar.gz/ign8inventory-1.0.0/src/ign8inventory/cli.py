"""CLI entry point: `ign8inventory up` provisions NetBox on Hetzner."""

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ign8inventory.config import Config
from ign8inventory.dns.cloudflare import CloudflareDNS
from ign8inventory.infra import hetzner
from ign8inventory.keys import save_keypair
from ign8inventory.setup.netbox import NetboxBootstrap
from ign8inventory.setup.server import NetboxSetup
from ign8inventory import vault

app = typer.Typer(
    name="ign8inventory",
    help="Ignite a NetBox inventory environment in minutes.",
    invoke_without_command=True,
)
console = Console()


@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    env_file: Path = typer.Option(Path(".env"), "--env-file", hidden=True),
) -> None:
    if env_file.exists():
        import os
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())
        for bare, prefixed in (("VAULT_ADDR", "IGN8_VAULT_ADDR"), ("VAULT_TOKEN", "IGN8_VAULT_TOKEN")):
            if bare not in os.environ and prefixed in os.environ:
                os.environ[bare] = os.environ[prefixed]
    if ctx.invoked_subcommand is None:
        _print_intro()


@app.command()
def up(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    admin_email: str = typer.Option(..., envvar="IGN8_ADMIN_EMAIL"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN"),
    cloudflare_token: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_TOKEN"),
    cloudflare_zone_id: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_ZONE_ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL"),
    netbox_superuser: str = typer.Option("admin", envvar="IGN8_NETBOX_SUPERUSER"),
    netbox_password: str = typer.Option(..., envvar="IGN8_NETBOX_PASSWORD"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
) -> None:
    """Provision NetBox: Hetzner VM + Cloudflare DNS + TLS + NetBox install."""

    cfg = Config(
        domain=domain,
        admin_email=admin_email,
        hetzner_token=hetzner_token,
        cloudflare_token=cloudflare_token,
        cloudflare_zone_id=cloudflare_zone_id,
        cloudflare_email=cloudflare_email,
        netbox_superuser=netbox_superuser,
        netbox_password=netbox_password,
    )

    console.print(Panel(f"[bold]ign8inventory[/bold] — igniting [cyan]inventory.{cfg.domain}[/cyan]"))

    console.print("[1/5] Generating SSH keypair...")
    keys_dir = work_dir / "keys"
    priv_path, pub_path = save_keypair(keys_dir)
    public_key_openssh = pub_path.read_text().strip()

    console.print("[2/5] Provisioning Hetzner server...")
    outputs = hetzner.provision(cfg, public_key_openssh, work_dir / "state.json")
    ipv4: str = outputs["ipv4"]
    ipv6: str = outputs["ipv6"]
    console.print(f"    Server IPv4: [green]{ipv4}[/green]")
    if ipv6:
        console.print(f"    Server IPv6: [green]{ipv6}[/green]")

    console.print("[3/5] Creating Cloudflare DNS records...")
    dns = CloudflareDNS(cfg.cloudflare_token, cfg.cloudflare_zone_id, cfg.domain, cfg.cloudflare_email)
    dns.provision(ipv4, ipv6)
    console.print(f"    inventory.{cfg.domain} → {ipv4}")

    console.print("[4/5] Installing NetBox (may take 5–10 minutes)...")
    console.print("    Connecting via SSH...")
    setup = NetboxSetup(cfg, ipv4, str(priv_path))
    setup.connect(retries=30, delay=10)
    try:
        init_data = setup.run()
    finally:
        setup.disconnect()

    console.print("[5/5] Saving credentials...")
    init_path = work_dir / "netbox-init.json"
    saved = {
        "netbox_url": f"https://inventory.{cfg.domain}",
        "api_token": init_data["api_token"],
        "db_password": init_data["db_password"],
    }
    init_path.write_text(json.dumps(saved, indent=2))
    init_path.chmod(0o600)

    _print_summary(cfg, saved)


@app.command()
def bootstrap(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    netbox_token: str = typer.Option("", envvar="IGN8_NETBOX_TOKEN", help="NetBox API token"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
) -> None:
    """Populate NetBox with the default regions, sites, and locations."""

    netbox_token = _resolve_token(netbox_token, work_dir)
    netbox_url = f"https://inventory.{domain}"
    console.print(Panel(f"[bold]ign8inventory bootstrap[/bold] — populating [cyan]{netbox_url}[/cyan]"))

    nb = NetboxBootstrap(netbox_url, netbox_token)
    result = nb.run()

    table = Table(show_header=True, header_style="bold")
    table.add_column("Type")
    table.add_column("Created")

    table.add_row("Regions",   ", ".join(result["regions"]))
    table.add_row("Sites",     ", ".join(result["sites"]))
    table.add_row("Locations", ", ".join(result["locations"]))

    console.print(table)
    console.print("\n[green]Bootstrap complete.[/green]")


@app.command()
def show_users(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    netbox_token: str = typer.Option("", envvar="IGN8_NETBOX_TOKEN"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
) -> None:
    """List all NetBox users."""
    netbox_token = _resolve_token(netbox_token, work_dir)
    nb = NetboxBootstrap(f"https://inventory.{domain}", netbox_token)
    users = nb.list_users()

    if not users:
        console.print("[dim]No users found.[/dim]")
        return

    table = Table(header_style="bold")
    table.add_column("ID",       style="dim", width=6)
    table.add_column("Username", min_width=16)
    table.add_column("Email")
    table.add_column("Active",   width=8)
    table.add_column("Staff",    width=8)

    for u in users:
        table.add_row(
            str(u.get("id", "")),
            u.get("username", ""),
            u.get("email", "") or "[dim]—[/dim]",
            "[green]yes[/green]" if u.get("is_active") else "[red]no[/red]",
            "[yellow]yes[/yellow]" if u.get("is_staff") else "no",
        )

    console.print(table)


@app.command()
def add_user(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    netbox_token: str = typer.Option("", envvar="IGN8_NETBOX_TOKEN"),
    user: str = typer.Option(..., "--user", help="Username to create"),
    password: str = typer.Option(..., "--password", help="Initial password"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
) -> None:
    """Create a new NetBox user."""
    netbox_token = _resolve_token(netbox_token, work_dir)
    nb = NetboxBootstrap(f"https://inventory.{domain}", netbox_token)
    created = nb.add_user(user, password)

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]ID[/dim]",       str(created.get("id", "")))
    table.add_row("[dim]Username[/dim]", f"[cyan]{created.get('username', '')}[/cyan]")
    table.add_row("[dim]Active[/dim]",   "[green]yes[/green]" if created.get("is_active") else "no")
    console.print(Panel("[bold green]User created[/bold green]"))
    console.print(table)


@app.command()
def seed(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    netbox_token: str = typer.Option("", envvar="IGN8_NETBOX_TOKEN"),
    infra_file: Path = typer.Option(Path("infrastructure.yml"), "--file", "-f"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
) -> None:
    """Query live providers from infrastructure.yml and seed NetBox with running servers."""
    import yaml
    from hcloud import Client

    if not infra_file.exists():
        console.print(f"[red]Not found: {infra_file}[/red]")
        raise typer.Exit(1)

    raw = yaml.safe_load(infra_file.read_text())
    config = vault.resolve(raw)

    netbox_token = _resolve_token(netbox_token, work_dir)
    netbox_url = f"https://inventory.{domain}"
    nb = NetboxBootstrap(netbox_url, netbox_token)

    console.print(Panel(
        f"[bold]ign8inventory seed[/bold]\n\n"
        f"Querying providers in [bold]{infra_file}[/bold]\n"
        f"Seeding → [cyan]{netbox_url}[/cyan]"
    ))

    providers = config.get("providers", {})
    total_vms = 0

    for project in providers.get("hetzner", []):
        name = project["name"]
        console.print(f"\n[bold]Hetzner[/bold] / [cyan]{name}[/cyan]")

        client = Client(token=project["api_key"])
        servers = client.servers.get_all()
        console.print(f"  Found [yellow]{len(servers)}[/yellow] server(s)")

        if not servers:
            continue

        result = nb.seed_hetzner_project(name, servers)

        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("VM")
        table.add_column("Type")
        table.add_column("Location")
        table.add_column("Status")
        table.add_column("IPv4")

        for server in servers:
            status_color = "green" if server.status == "running" else "dim"
            table.add_row(
                server.name,
                server.server_type.name,
                server.location.name,
                f"[{status_color}]{server.status}[/{status_color}]",
                server.public_net.ipv4.ip if server.public_net.ipv4 else "—",
            )
        console.print(table)
        total_vms += len(result["vms"])

    console.print(f"\n[green]Done — {total_vms} VM(s) seeded into NetBox.[/green]")


@app.command("vault-put")
def vault_put(
    infra_file: Path = typer.Option(Path("infrastructure.yml"), "--file", "-f", help="Infrastructure definition"),
) -> None:
    """Read infrastructure.yml, prompt for each vault: secret, and store in Vault."""
    import yaml  # pyyaml — only needed for this command

    if not infra_file.exists():
        console.print(f"[red]Not found: {infra_file}[/red]")
        raise typer.Exit(1)

    raw = yaml.safe_load(infra_file.read_text())
    refs = vault.collect_refs(raw)

    if not refs:
        console.print("[yellow]No vault: references found in infrastructure.yml[/yellow]")
        raise typer.Exit(0)

    console.print(Panel(
        f"[bold]ign8inventory vault-put[/bold]\n\n"
        f"Found [cyan]{len(refs)}[/cyan] secret path(s) in [bold]{infra_file}[/bold].\n"
        f"Enter values for each field. Press Enter to keep an existing value.",
        style="bold cyan",
    ))

    # Fetch existing values so the user can confirm/update them
    existing: dict[str, dict[str, str]] = {}
    for path in refs:
        try:
            existing[path] = vault.get_secret(path) or {}
        except Exception:
            existing[path] = {}

    for path, fields in sorted(refs.items()):
        console.rule(f"[dim]{path}[/dim]")
        values: dict[str, str] = {}
        for field in sorted(fields):
            current = existing.get(path, {}).get(field, "")
            display = "(set)" if current else ""
            prompt_text = f"  {field}" + (f" [{display}]" if display else "")
            while True:
                entered = typer.prompt(prompt_text, default=current, show_default=False).strip()
                if entered:
                    values[field] = entered
                    break
                console.print("  [red]Required — cannot be empty.[/red]")

        vault.put_secret(path, values)
        console.print(f"  [green]stored {len(values)} field(s)[/green]")

    console.print(f"\n[green]Done — {len(refs)} path(s) written to Vault.[/green]")


def _resolve_token(token: str, work_dir: Path) -> str:
    """Fall back to token in netbox-init.json if envvar is empty."""
    if token:
        return token
    init_path = work_dir / "netbox-init.json"
    if init_path.exists():
        return json.loads(init_path.read_text()).get("api_token", "")
    console.print("[red]No NetBox API token. Set IGN8_NETBOX_TOKEN or run ign8inventory up first.[/red]")
    raise typer.Exit(1)


@app.command()
def backup(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
    output: Path = typer.Option(Path("backup/netbox.sql"), "--output", "-o"),
    commit: bool = typer.Option(True, "--commit/--no-commit", help="Git-commit the dump after saving"),
) -> None:
    """Export the NetBox PostgreSQL database and commit it to the repository."""
    import subprocess

    state_path = work_dir / "state.json"
    if not state_path.exists():
        console.print("[red]No state found. Run ign8inventory up first.[/red]")
        raise typer.Exit(1)

    state = json.loads(state_path.read_text())
    ipv4: str = state.get("ipv4", "")
    if not ipv4:
        console.print("[red]No server IP in state.json.[/red]")
        raise typer.Exit(1)

    priv_key = work_dir / "keys" / "ign8inventory"
    if not priv_key.exists():
        console.print("[red]SSH key not found. Run ign8inventory up first.[/red]")
        raise typer.Exit(1)

    console.print(Panel(f"[bold]ign8inventory backup[/bold] — dumping [cyan]inventory.{domain}[/cyan]"))

    console.print(f"[1/2] Connecting to [green]{ipv4}[/green] via SSH...")
    from ign8inventory.setup.server import NetboxSetup
    from ign8inventory.config import Config

    cfg = Config(
        domain=domain,
        admin_email="",
        hetzner_token="",
        cloudflare_token="",
        cloudflare_zone_id="",
    )
    setup = NetboxSetup(cfg, ipv4, str(priv_key))
    setup.connect(retries=3, delay=5)
    try:
        sql_bytes = setup.dump_database()
    finally:
        setup.disconnect()

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(sql_bytes)
    size_kb = len(sql_bytes) // 1024
    console.print(f"[2/2] Saved [green]{output}[/green] ({size_kb} KB)")

    if commit:
        result = subprocess.run(
            ["git", "add", str(output)],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            console.print(f"[yellow]git add failed: {result.stderr.strip()}[/yellow]")
        else:
            result = subprocess.run(
                ["git", "commit", "-m", f"backup: netbox database export ({domain})"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                console.print("[green]Committed to git.[/green]")
            elif "nothing to commit" in result.stdout or "nothing to commit" in result.stderr:
                console.print("[dim]No changes since last backup — nothing committed.[/dim]")
            else:
                console.print(f"[yellow]git commit: {result.stderr.strip()}[/yellow]")


@app.command()
def destroy(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN"),
    cloudflare_token: str = typer.Option("", envvar="IGN8_CLOUDFLARE_TOKEN"),
    cloudflare_zone_id: str = typer.Option("", envvar="IGN8_CLOUDFLARE_ZONE_ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL"),
    work_dir: Path = typer.Option(Path(".ign8inventory")),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Tear down the NetBox server and DNS records."""
    if not yes:
        typer.confirm(f"Destroy all ign8inventory resources for {domain}?", abort=True)

    console.print(Panel(f"[bold red]ign8inventory destroy[/bold red] — tearing down [cyan]{domain}[/cyan]"))

    console.print("[1/2] Deleting Hetzner server...")
    hetzner.destroy(work_dir / "state.json", hetzner_token)

    if cloudflare_token and cloudflare_zone_id:
        console.print("[2/2] Removing DNS records...")
        dns = CloudflareDNS(cloudflare_token, cloudflare_zone_id, domain, cloudflare_email)
        dns.destroy()
    else:
        console.print("[2/2] Skipping DNS cleanup (no Cloudflare credentials)")

    console.print("[green]Done.[/green]")


@app.command()
def setenv(
    env_file: Path = typer.Option(Path(".env")),
) -> None:
    """Interactive setup: collect all credentials and write to .env."""
    import os

    existing: dict[str, str] = {}
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            existing[k.strip()] = v.strip()

    def _current(key: str) -> str:
        return existing.get(key) or os.environ.get(key, "")

    def _ask(label: str, key: str, hint: str, required: bool = True, secret: bool = False) -> str:
        console.print(f"\n[bold]{label}[/bold]")
        console.print(f"  [dim]{hint}[/dim]")
        default = _current(key)
        display_default = ("(set)" if default else "") if secret else default
        prompt_text = f"  {key}" + (f" [{display_default}]" if display_default else "")
        while True:
            value = typer.prompt(prompt_text, default=default, show_default=False).strip()
            if value or not required:
                return value
            console.print("  [red]Required — cannot be empty.[/red]")

    console.print(Panel("[bold]ign8inventory — interactive setup[/bold]", style="bold cyan"))
    console.print("\nPress Enter to keep an existing value. Leave optional fields blank to skip.\n")

    results: list[tuple[str, str]] = []

    console.rule("[dim]Provisioning[/dim]")

    results.append(("IGN8_DOMAIN", _ask(
        "Domain", "IGN8_DOMAIN",
        "Base domain — inventory.DOMAIN will be created (e.g. example.com)",
    )))
    results.append(("IGN8_ADMIN_EMAIL", _ask(
        "Admin email", "IGN8_ADMIN_EMAIL",
        "Contact email for Let's Encrypt TLS certificates",
    )))
    results.append(("IGN8_HETZNER_TOKEN", _ask(
        "Hetzner Cloud API token", "IGN8_HETZNER_TOKEN",
        "console.hetzner.cloud → Project → Security → API Tokens → Generate API Token",
        secret=True,
    )))
    results.append(("IGN8_CLOUDFLARE_TOKEN", _ask(
        "Cloudflare API token", "IGN8_CLOUDFLARE_TOKEN",
        "dash.cloudflare.com → Profile → API Tokens → Create Token\n"
        "  Permission needed: Zone → DNS → Edit",
        secret=True,
    )))
    results.append(("IGN8_CLOUDFLARE_ZONE_ID", _ask(
        "Cloudflare Zone ID", "IGN8_CLOUDFLARE_ZONE_ID",
        "dash.cloudflare.com → select your domain → Overview → right sidebar → Zone ID",
    )))

    console.rule("[dim]NetBox superuser[/dim]")

    results.append(("IGN8_NETBOX_SUPERUSER", _ask(
        "NetBox admin username", "IGN8_NETBOX_SUPERUSER",
        "Username for the NetBox superuser account (default: admin)",
    )))
    results.append(("IGN8_NETBOX_PASSWORD", _ask(
        "NetBox admin password", "IGN8_NETBOX_PASSWORD",
        "Password for the NetBox superuser account",
        secret=True,
    )))

    console.rule("[dim]NetBox API token (fill in after ign8inventory up)[/dim]")

    results.append(("IGN8_NETBOX_TOKEN", _ask(
        "NetBox API token", "IGN8_NETBOX_TOKEN",
        "API token from .ign8inventory/netbox-init.json — leave blank now",
        required=False,
        secret=True,
    )))

    # Write / upsert .env
    lines = env_file.read_text().splitlines() if env_file.exists() else []
    written: set[str] = set()
    new_lines: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            new_lines.append(line)
            continue
        key = stripped.partition("=")[0].strip()
        match = next(((k, v) for k, v in results if k == key), None)
        if match:
            k, v = match
            new_lines.append(f"{k}={v}" if v else f"# {k}=")
            written.add(k)
        else:
            new_lines.append(line)
    for k, v in results:
        if k not in written:
            new_lines.append(f"{k}={v}" if v else f"# {k}=")

    env_file.write_text("\n".join(new_lines) + "\n")
    env_file.chmod(0o600)
    console.print(f"\n[green]Written to {env_file}[/green]")


@app.command()
def quickstart() -> None:
    """Print a step-by-step quickstart guide."""
    console.print()
    console.print(Panel("[bold]ign8inventory — Quickstart[/bold]", style="bold cyan"))

    steps = [
        ("1. Install",
         "[dim]$ [/dim]pipx install ign8inventory"),
        ("2. Configure",
         "[dim]$ [/dim][cyan]ign8inventory setenv[/cyan]\n\n"
         "  Walks you through every credential. Writes a [bold].env[/bold] file.\n"
         "  Re-run after provisioning to fill in IGN8_NETBOX_TOKEN."),
        ("3. Provision",
         "[dim]$ [/dim][cyan]ign8inventory up[/cyan]\n\n"
         "  Creates a Hetzner VPS, Cloudflare DNS, installs NetBox + TLS.\n"
         "  Saves credentials to [bold].ign8inventory/netbox-init.json[/bold]."),
        ("4. Bootstrap",
         "[dim]$ [/dim][cyan]ign8inventory bootstrap[/cyan]\n\n"
         "  Populates NetBox with the default layout:\n"
         "    Regions  → EU, US, APAC\n"
         "    Sites    → nbg1, fsn1, hel1, ash1, hil1, sin1\n"
         "    Zones    → zone-a, zone-b per site"),
        ("5. Backup",
         "[dim]$ [/dim][cyan]ign8inventory backup[/cyan]\n\n"
         "  Exports the NetBox PostgreSQL database via SSH.\n"
         "  Saves to [bold]backup/netbox.sql[/bold] and commits it to git.\n"
         "  Run regularly to keep an auditable snapshot in the repository."),
        ("Tear down",
         "[dim]$ [/dim][cyan]ign8inventory destroy[/cyan]"),
    ]

    for title, body in steps:
        console.print(f"\n[bold]{title}[/bold]")
        console.print(f"  {body}")

    console.print()


def _print_summary(cfg: Config, saved: dict[str, str]) -> None:
    console.print()
    console.print(Panel("[bold green]NetBox is live![/bold green]"))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]URL[/dim]",       f"[cyan]{saved['netbox_url']}[/cyan]")
    table.add_row("[dim]API token[/dim]", f"[yellow]{saved['api_token']}[/yellow]")
    console.print(table)
    console.print()
    console.print(
        "[dim]Credentials saved to[/dim] [bold].ign8inventory/netbox-init.json[/bold]\n"
        "[dim]Run [cyan]ign8inventory bootstrap[/cyan] to populate regions, sites, and locations.[/dim]"
    )


def _print_intro() -> None:
    console.print(Panel(
        "[bold]ign8inventory[/bold] — NetBox on Hetzner\n\n"
        "  [cyan]ign8inventory up[/cyan]           provision server + install NetBox\n"
        "  [cyan]ign8inventory bootstrap[/cyan]    populate regions / sites / locations\n"
        "  [cyan]ign8inventory seed[/cyan]         query live providers → seed NetBox\n"
        "  [cyan]ign8inventory backup[/cyan]       export database → backup/netbox.sql + git commit\n"
        "  [cyan]ign8inventory vault-put[/cyan]    push infrastructure.yml secrets to Vault\n"
        "  [cyan]ign8inventory show-users[/cyan]   list NetBox users\n"
        "  [cyan]ign8inventory add-user[/cyan]     create a NetBox user\n"
        "  [cyan]ign8inventory setenv[/cyan]       interactive credential setup\n"
        "  [cyan]ign8inventory quickstart[/cyan]   step-by-step guide\n"
        "  [cyan]ign8inventory destroy[/cyan]      tear it all down",
        title="ign8inventory",
    ))
