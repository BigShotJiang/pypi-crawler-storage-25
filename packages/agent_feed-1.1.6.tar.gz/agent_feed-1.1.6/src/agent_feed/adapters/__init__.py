"""AI client adapters."""
