"""Remote Gymnasium-compatible environments backed by the App World API.

The env is bound to an *environment* (device/container resources),
NOT to a specific task.  ``task_name`` is passed at ``reset()`` time,
so one env object can run multiple tasks sequentially — the typical
multi-task eval workflow.
"""

from __future__ import annotations

import base64
from io import BytesIO
from typing import Any

import numpy as np
import requests
from PIL import Image
from gymnasium import spaces

from appworld_sdk.errors import AppWorldAPIError, EnvironmentNotReady, SessionExpired


def _decode_data_url_png(data_url: str) -> np.ndarray:
    _, payload = data_url.split(",", 1)
    binary = base64.b64decode(payload)
    return np.array(Image.open(BytesIO(binary)).convert("RGB"))


def _raise_for_status(response: requests.Response) -> None:
    """Convert HTTP errors to SDK exceptions."""
    if response.ok:
        return
    detail = ""
    try:
        body = response.json()
        detail = body.get("detail", "")
    except Exception:
        detail = response.text[:200]
    if response.status_code == 503:
        raise EnvironmentNotReady("unknown", detail=detail)
    if response.status_code == 410:
        raise SessionExpired("unknown", detail=detail)
    raise AppWorldAPIError(
        detail or response.reason or "API error",
        status_code=response.status_code,
        detail=detail,
    )


class _RemoteBaseEnv:
    """Shared HTTP plumbing for remote environments."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        env_id: str,
        env_type: str,
        timeout: float = 180.0,
        run_id: str | None = None,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.env_id = env_id
        self.env_type = env_type
        self.timeout = timeout
        self.session_id: str | None = None
        self.current_task: str | None = None
        # Bound run_id stays alive across resets so multi-task / multi-episode
        # training loops keep attributing every step's task_execution to this
        # one run row. Server-side `create_sdk_session` only binds when the
        # run still has a pending task_execution for this task_id, so re-using
        # run_id is safe (extra binds are no-ops, missing binds get correctly
        # detected and a fresh run is auto-created instead).
        self._run_id: str | None = run_id

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        response = requests.post(
            f"{self.base_url}{path}",
            headers=self.headers,
            json=payload,
            timeout=self.timeout,
        )
        _raise_for_status(response)
        return response.json()

    def close(self) -> None:
        if self.session_id is None:
            return
        try:
            self._post("/api/v1/sdk/env/close", {"session_id": self.session_id})
        except Exception:
            pass
        self.session_id = None
        self.current_task = None


class RemoteAppWorldEnv(_RemoteBaseEnv):
    """RL environment.

    M1.1 起 observation 升级到 dict {screenshot: ndarray, goal: str} —
    与 EvalEnv 对齐, 让 VLM policy 能在 prompt 里 attend goal 文本.
    老调用方传字符串 observation 也兼容.
    """

    def __init__(self, api_key: str, base_url: str, env_id: str, run_id: str | None = None):
        super().__init__(
            api_key=api_key, base_url=base_url, env_id=env_id, env_type="rl", run_id=run_id,
        )
        self.observation_space = spaces.Dict({
            "screenshot": spaces.Box(low=0, high=255, shape=(2400, 1080, 3), dtype=np.uint8),
            "goal": spaces.Text(max_length=1024),
        })
        self.action_space = spaces.MultiDiscrete([6, 100, 100, 4])
        self._obs_space_locked = False

    @staticmethod
    def _decode_observation(raw: Any) -> dict[str, Any]:
        """兼容老服务端 (字符串 PNG data URL) 与新服务端 (dict)."""
        if isinstance(raw, dict):
            screenshot = _decode_data_url_png(raw["screenshot"])
            return {"screenshot": screenshot, "goal": raw.get("goal", "")}
        # 老服务端: 直接是 PNG data URL
        return {"screenshot": _decode_data_url_png(raw), "goal": ""}

    def _maybe_align_observation_space(self, obs: dict[str, Any]) -> None:
        if self._obs_space_locked:
            return
        screen = obs["screenshot"]
        cur = self.observation_space["screenshot"]
        if screen.shape != cur.shape:
            new_screen = spaces.Box(low=0, high=255, shape=screen.shape, dtype=np.uint8)
            self.observation_space = spaces.Dict({
                "screenshot": new_screen,
                "goal": self.observation_space["goal"],
            })
        self._obs_space_locked = True

    def reset(
        self,
        *,
        task_name: str,
        seed: int | None = None,
        options: dict | None = None,
    ) -> tuple[dict[str, Any], dict]:
        self.close()
        reset_payload: dict[str, Any] = {
            "env_id": self.env_id,
            "task_name": task_name,
            "env_type": "rl",
        }
        if self._run_id is not None:
            reset_payload["run_id"] = self._run_id
        if seed is not None:
            reset_payload["episode_seed"] = int(seed)
        payload = self._post("/api/v1/sdk/env/reset", reset_payload)
        self.session_id = payload["session_id"]
        self.current_task = task_name
        obs = self._decode_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return obs, payload["info"]

    def step(self, action: Any) -> tuple[dict[str, Any], float, bool, bool, dict]:
        if self.session_id is None:
            raise RuntimeError("reset() must be called before step()")
        # action 可以是 ndarray (老 4-head MultiDiscrete) 或 dict (LLM-as-policy 解析后的 JSON action)
        if isinstance(action, dict):
            action_payload: Any = action
        else:
            action_payload = np.asarray(action).tolist()
        payload = self._post("/api/v1/sdk/env/step", {
            "session_id": self.session_id,
            "action": action_payload,
        })
        obs = self._decode_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return (
            obs,
            float(payload["reward"]),
            bool(payload["terminated"]),
            bool(payload["truncated"]),
            payload["info"],
        )


class RemoteAppWorldEvalEnv(_RemoteBaseEnv):
    """Eval environment (7 actions incl. text input, dict observation)."""

    def __init__(self, api_key: str, base_url: str, env_id: str, run_id: str | None = None):
        super().__init__(
            api_key=api_key, base_url=base_url, env_id=env_id, env_type="eval", run_id=run_id,
        )
        # Default to native Android portrait resolution (1080x2400). 第一次 reset
        # 如果实际帧形状不同会自适应改写 screenshot 子 space (见 _maybe_align_observation_space).
        self.observation_space = spaces.Dict({
            "screenshot": spaces.Box(low=0, high=255, shape=(2400, 1080, 3), dtype=np.uint8),
            "goal": spaces.Text(max_length=500),
        })
        self.action_space = spaces.Dict({
            "action_type": spaces.Discrete(7),
            "x": spaces.Box(0.0, 1.0, shape=(), dtype=np.float32),
            "y": spaces.Box(0.0, 1.0, shape=(), dtype=np.float32),
            "text": spaces.Text(max_length=200),
            "direction": spaces.Discrete(4),
        })
        self._obs_space_locked = False

    def _maybe_align_observation_space(self, obs: dict[str, Any]) -> None:
        if self._obs_space_locked:
            return
        screenshot = obs.get("screenshot")
        if screenshot is None:
            return
        actual_shape = screenshot.shape
        screen_space = self.observation_space["screenshot"]
        if actual_shape != screen_space.shape:
            new_screen = spaces.Box(low=0, high=255, shape=actual_shape, dtype=np.uint8)
            self.observation_space = spaces.Dict({
                **{k: v for k, v in self.observation_space.spaces.items() if k != "screenshot"},
                "screenshot": new_screen,
            })
        self._obs_space_locked = True

    def reset(
        self,
        *,
        task_name: str,
        seed: int | None = None,
        options: dict | None = None,
    ) -> tuple[dict[str, Any], dict]:
        # Close previous session if any
        self.close()

        reset_payload: dict[str, Any] = {
            "env_id": self.env_id,
            "task_name": task_name,
            "env_type": "eval",
        }
        if self._run_id is not None:
            reset_payload["run_id"] = self._run_id
        if seed is not None:
            reset_payload["episode_seed"] = int(seed)
        payload = self._post("/api/v1/sdk/env/reset", reset_payload)
        self.session_id = payload["session_id"]
        self.current_task = task_name
        obs = self._unpack_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return obs, payload["info"]

    def step(self, action: dict[str, Any]) -> tuple[dict[str, Any], float, bool, bool, dict]:
        if self.session_id is None:
            raise RuntimeError("reset() must be called before step()")
        payload = self._post("/api/v1/sdk/env/step", {
            "session_id": self.session_id,
            "action": action,
        })
        obs = self._unpack_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return (
            obs,
            float(payload["reward"]),
            bool(payload["terminated"]),
            bool(payload["truncated"]),
            payload["info"],
        )

    @staticmethod
    def _unpack_observation(observation: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {
            "screenshot": _decode_data_url_png(observation["screenshot"]),
            "goal": observation["goal"],
        }
        # Optional fields the server may include for richer agent grounding.
        # `ui_elements` is the UIAutomator dump (Android); when present, callers
        # can drive the SoM/index path of generate_vision_action instead of the
        # pixel-coord fallback. Empty list = server opted out (RL fast path).
        if "ui_elements" in observation:
            out["ui_elements"] = observation["ui_elements"] or []
        if observation.get("focus"):
            out["focus"] = observation["focus"]
        if isinstance(observation.get("structured"), dict):
            out["structured"] = observation["structured"]
        return out
