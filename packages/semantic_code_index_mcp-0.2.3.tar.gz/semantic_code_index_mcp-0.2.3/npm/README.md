# semantic-code-index-mcp

One-command installer for the semantic code search MCP server for Claude Code.

## Install into your project

```bash
npx semantic-code-index-mcp install
```

This sets up everything Claude Code needs to use semantic search in your project:
- `.claude/mcp.json` and `.mcp.json` — MCP server config (merged with existing)
- `.claude/rules/semantic-search.md` — tells Claude to prefer semantic search
- `.gitignore` — updated automatically

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

## Uninstall

```bash
npx semantic-code-index-mcp uninstall
```

Removes all semantic-code-index config. Other MCP servers are preserved.

## What it does

Once installed, Claude Code will:
1. Use `semantic_search` to find code by meaning, not just keywords
2. Auto-sync the index when files change
3. Save 80-90% tokens compared to reading the full repo

First time, ask Claude: **"Index this project"**

## Dev install

```bash
npx semantic-code-index-mcp install --local /path/to/.venv/bin/semantic-code-index-mcp
```

Uses a local binary instead of `uvx` for development.

## Links

- [GitHub](https://github.com/thinhdo/semantic-code-index-mcp)
- [PyPI](https://pypi.org/project/semantic-code-index-mcp/)
