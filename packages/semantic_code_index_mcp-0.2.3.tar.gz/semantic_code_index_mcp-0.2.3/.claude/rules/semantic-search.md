---
description: Prefer semantic_search MCP tool over Grep/Glob for code exploration
globs: "**/*"
---

# Semantic Code Search

This project has a semantic code index (semantic-code-index MCP server).

When you need to explore, understand, or find code:
1. **Use `semantic_search` first** — it finds conceptually related code, not just exact string matches.
2. Only fall back to Grep/Glob when you need exact string/pattern matching (e.g. finding a specific variable name or import).
3. `semantic_search` auto-syncs changed files before searching — no need to manually sync.
4. Run `index_project` once if the project has never been indexed.

When spawning sub-agents (Agent tool) for code exploration or research, always include this instruction in the prompt:
> Use the `mcp__semantic-code-index__semantic_search` tool to search code. It finds conceptually related code via semantic vector search. Prefer it over Grep/Glob.
