from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from semantic_code_index_mcp.indexer import CodeIndexer

mcp = FastMCP(
    "semantic-code-index",
    instructions=(
        "Semantic code search over a local index (SQLite + local embeddings). "
        "Use semantic_search to find code — it auto-syncs changed files before searching. "
        "Call index_project once per workspace for initial setup. "
        "Use list_indexed_files to see what's indexed, get_file_chunks for full content."
    ),
)

_indexer_cache: dict[str, CodeIndexer] = {}


def _default_root() -> Path:
    env = os.environ.get("SEMANTIC_CODE_ROOT") or os.environ.get("WORKSPACE_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return Path.cwd()


def _get_indexer(root: str | None = None) -> CodeIndexer:
    r = Path(root).expanduser().resolve() if root else _default_root()
    key = str(r)
    if key not in _indexer_cache:
        _indexer_cache[key] = CodeIndexer(r)
    return _indexer_cache[key]


@mcp.tool()
def index_project(root_path: str | None = None) -> str:
    """Full re-index: xóa index cũ và vector hóa lại toàn bộ codebase dưới root_path (hoặc SEMANTIC_CODE_ROOT / cwd)."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.index_full(conn)
    return json.dumps(out, ensure_ascii=False, indent=2)


@mcp.tool()
def sync_index(root_path: str | None = None) -> str:
    """Đồng bộ tăng dần: file mới/sửa/xóa → cập nhật chunk + embedding; không đụng file không đổi."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.sync_incremental(conn)
    return json.dumps(out, ensure_ascii=False, indent=2)


@mcp.tool()
def semantic_search(
    query: str,
    limit: int = 12,
    path_prefix: str | None = None,
    auto_sync: bool = True,
    root_path: str | None = None,
) -> str:
    """Tìm đoạn code liên quan (hybrid: semantic vector + keyword BM25).
    auto_sync=true sẽ tự đồng bộ file thay đổi trước khi tìm.
    path_prefix lọc theo tiền tố đường dẫn tương đối."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        if auto_sync and idx.needs_sync(conn):
            idx.sync_incremental(conn)
        hits, usage = idx.search(
            conn, query, limit=min(max(limit, 1), 50), path_prefix=path_prefix
        )
    payload = {
        "results": [
            {"path": h.path, "lines": [h.start_line, h.end_line], "score": round(h.score, 6)}
            for h in hits
        ],
        "usage": usage,
    }
    return json.dumps(payload, ensure_ascii=False)


@mcp.tool()
def list_indexed_files(root_path: str | None = None) -> str:
    """Liệt kê các file đã index, kèm token count và số chunks mỗi file."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.list_files(conn)
    return json.dumps(out, ensure_ascii=False)


@mcp.tool()
def get_file_chunks(path: str, root_path: str | None = None) -> str:
    """Lấy toàn bộ chunks đã index của một file (full content, không cắt). Dùng sau semantic_search để xem context đầy đủ."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.get_file_chunks(conn, path)
    return json.dumps(out, ensure_ascii=False)


@mcp.tool()
def token_usage_stats(root_path: str | None = None) -> str:
    """So sánh tích lũy: token ước lượng nếu đọc full repo đã index vs token query+kết quả từ semantic_search."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.stats(conn)
    return json.dumps(out, ensure_ascii=False)


@mcp.tool()
def search_log(last_n: int = 50, root_path: str | None = None) -> str:
    """Xem log các lần search gần đây: query, tokens dùng, tokens tiết kiệm, thời gian."""
    idx = _get_indexer(root_path)
    with idx.open() as conn:
        out = idx.search_logs(conn, last_n)
    return json.dumps(out, ensure_ascii=False)


def _find_server_bin() -> str:
    bin_path = shutil.which("semantic-code-index-mcp")
    if bin_path:
        return str(Path(bin_path).resolve())
    return str(Path(sys.executable).parent / "semantic-code-index-mcp")


def _merge_mcp_entry(path: Path, server_bin: str, root: Path) -> None:
    config: dict = {}
    if path.exists():
        try:
            config = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    config.setdefault("mcpServers", {})
    config["mcpServers"]["semantic-code-index"] = {
        "command": server_bin,
        "env": {"SEMANTIC_CODE_ROOT": str(root)},
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n")
    print(f"✓ Wrote {path}")


def _ensure_gitignore(gitignore: Path, entry: str) -> None:
    lines: list[str] = []
    if gitignore.exists():
        lines = gitignore.read_text().splitlines()
    if entry not in lines:
        lines.append(entry)
        gitignore.write_text("\n".join(lines) + "\n")


_SEMANTIC_SEARCH_RULE = """\
---
description: Prefer semantic_search MCP tool over Grep/Glob for code exploration
globs: "**/*"
---

# Semantic Code Search

This project has a semantic code index (semantic-code-index MCP server).

When you need to explore, understand, or find code:
1. **Use `semantic_search` first** — it finds conceptually related code, not just exact string matches.
2. Only fall back to Grep/Glob when you need exact string/pattern matching (e.g. finding a specific variable name or import).
3. `semantic_search` auto-syncs changed files before searching — no need to manually sync.
4. Run `index_project` once if the project has never been indexed.

When spawning sub-agents (Agent tool) for code exploration or research, always include this instruction in the prompt:
> Use the `mcp__semantic-code-index__semantic_search` tool to search code. It finds conceptually related code via semantic vector search. Prefer it over Grep/Glob.
"""


def install(target: str | None = None) -> None:
    root = Path(target).expanduser().resolve() if target else Path.cwd()
    server_bin = _find_server_bin()

    _merge_mcp_entry(root / ".claude" / "mcp.json", server_bin, root)

    _merge_mcp_entry(root / ".mcp.json", server_bin, root)
    _ensure_gitignore(root / ".gitignore", ".mcp.json")
    _ensure_gitignore(root / ".gitignore", ".claude/")

    rule_file = root / ".claude" / "rules" / "semantic-search.md"
    rule_file.parent.mkdir(parents=True, exist_ok=True)
    rule_file.write_text(_SEMANTIC_SEARCH_RULE)
    print(f"✓ Wrote {rule_file}")

    print(f"  server: {server_bin}")
    print(f"  root:   {root}")
    db = CodeIndexer._default_db_path(root)
    print(f"  db:     {db}")


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "install":
        target = sys.argv[2] if len(sys.argv) > 2 else None
        install(target)
    else:
        mcp.run()
