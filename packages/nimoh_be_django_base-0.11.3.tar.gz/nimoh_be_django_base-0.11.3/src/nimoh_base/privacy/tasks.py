"""
Celery tasks for privacy app.

Background tasks for:
- Processing scheduled account deletions (GDPR Article 17)
- Cleaning up expired data export requests
"""

import logging

from celery import shared_task
from django.db.utils import DatabaseError
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def process_scheduled_deletions(self):
    """
    Process accounts scheduled for GDPR deletion.

    Runs daily via Celery Beat.
    Finds PrivacyProfiles where deletion_scheduled_for has passed
    and executes the erasure using GDPRDataEraser.

    Returns:
        dict: Summary of processed deletions
    """
    try:
        from nimoh_base.privacy.models import PrivacyProfile
        from nimoh_base.privacy.utils.gdpr import GDPRDataEraser

        overdue = PrivacyProfile.objects.filter(
            deletion_requested=True,
            deletion_scheduled_for__lte=timezone.now(),
        ).select_related("user")

        processed = 0
        failed = 0
        results = []

        for privacy_profile in overdue:
            user = privacy_profile.user
            try:
                # anonymize_recovery_data field was removed (domain-specific).
                # Default to always retaining audit logs during GDPR deletion — the safe choice.
                retain_audit = True
                eraser = GDPRDataEraser(user=user)
                summary = eraser.initiate_erasure(
                    reason="Scheduled GDPR deletion (grace period expired)",
                    retain_audit=retain_audit,
                )
                processed += 1
                results.append(
                    {
                        "anonymized_id": summary.get("anonymized_id"),
                        "status": "erased",
                    }
                )
                logger.info(
                    "GDPR deletion completed for user %s",
                    summary.get("anonymized_id"),
                )
            except (DatabaseError, ValueError, OSError):
                failed += 1
                logger.exception("GDPR deletion failed for user_id=%s", user.id)

        result = {
            "status": "success",
            "processed": processed,
            "failed": failed,
            "total_found": processed + failed,
        }

        logger.info(
            "Scheduled deletions processed: %d succeeded, %d failed",
            processed,
            failed,
        )
        return result

    except Exception as exc:
        logger.error("process_scheduled_deletions failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=3)
def cleanup_stale_export_requests(self):
    """
    Reset data export requests older than 7 days that were never fulfilled.

    Runs daily via Celery Beat.

    Returns:
        dict: Summary of cleaned-up requests
    """
    try:
        from datetime import timedelta

        from nimoh_base.privacy.models import PrivacyProfile

        cutoff = timezone.now() - timedelta(days=7)
        stale = PrivacyProfile.objects.filter(
            data_export_requested=True,
            data_export_requested_at__lt=cutoff,
        )
        count = stale.update(
            data_export_requested=False,
            data_export_requested_at=None,
        )

        logger.info("Cleaned up %d stale data-export requests", count)
        return {"status": "success", "cleaned": count}

    except Exception as exc:
        logger.error("cleanup_stale_export_requests failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=3)
def enforce_data_retention(self):
    """
    Anonymise accounts that have opted into automatic data retention.

    Runs weekly (Sunday 04:00 UTC by default via Celery Beat).

    Targets ``PrivacyProfile`` rows where:
    - ``auto_delete_inactive_data`` is ``True``
    - The user's last activity (``last_login`` or ``date_joined``, whichever
      is later) is older than ``NIMOH_BASE['DATA_RETENTION_INACTIVE_DAYS']``
      days (default: 730 days / 2 years).

    Erasure uses ``GDPRDataEraser.initiate_erasure()``, which anonymises PII
    while retaining audit log records for compliance.

    Returns:
        dict: Summary of processed and failed accounts.
    """
    try:
        from datetime import timedelta

        from django.utils import timezone

        from nimoh_base.conf import nimoh_setting
        from nimoh_base.privacy.models import PrivacyProfile
        from nimoh_base.privacy.utils.gdpr import GDPRDataEraser

        retention_days = nimoh_setting("DATA_RETENTION_INACTIVE_DAYS", 730)
        cutoff = timezone.now() - timedelta(days=retention_days)

        # Select opted-in accounts whose last activity pre-dates the cutoff.
        # We check both last_login and date_joined (via the user relation);
        # whichever is later defines "last active".
        candidates = PrivacyProfile.objects.filter(
            auto_delete_inactive_data=True,
            # Skip accounts already scheduled / processed for deletion.
            deletion_requested=False,
        ).select_related("user")

        processed = 0
        skipped = 0
        failed = 0

        for profile in candidates:
            user = profile.user
            # Use the later of last_login and date_joined as the activity timestamp.
            last_active = max(
                filter(None, [getattr(user, "last_login", None), getattr(user, "date_joined", None)]),
                default=None,
            )
            if last_active is None or last_active > cutoff:
                skipped += 1
                continue

            try:
                eraser = GDPRDataEraser(user=user)
                eraser.initiate_erasure(
                    reason=(
                        f"Automatic data-retention enforcement: inactive "
                        f"for >{retention_days} days with auto_delete_inactive_data=True"
                    ),
                    retain_audit=True,
                )
                processed += 1
                logger.info(
                    "Data retention: anonymised user inactive for >%d days (user_id=%s)",
                    retention_days,
                    user.id,
                )
            except (DatabaseError, ValueError, OSError):
                failed += 1
                logger.exception("Data retention: erasure failed for user_id=%s", user.id)

        result = {
            "status": "success",
            "retention_days": retention_days,
            "processed": processed,
            "skipped": skipped,
            "failed": failed,
        }
        logger.info(
            "Data retention sweep complete: %d anonymised, %d skipped, %d failed",
            processed,
            skipped,
            failed,
        )
        return result

    except Exception as exc:
        logger.error("enforce_data_retention failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)
