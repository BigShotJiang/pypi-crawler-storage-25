"""
nimoh_base.conf.social
=======================
Helpers for wiring ``social-auth-app-django`` into a consumer project.

Install the `[social]` extra::

    pip install "nimoh-be-django-base[social]"

Then in your project settings::

    from nimoh_base.conf.social import get_social_installed_apps, get_social_auth_pipeline

    NIMOH_BASE["SOCIAL_AUTH_ENABLED"] = True

    INSTALLED_APPS += get_social_installed_apps()

    AUTHENTICATION_BACKENDS = [
        "social_core.backends.google.GoogleOAuth2",
        "social_core.backends.github.GithubOAuth2",
        "django.contrib.auth.backends.ModelBackend",
    ]

    SOCIAL_AUTH_PIPELINE = get_social_auth_pipeline()

    # Redirect and allowed hosts (so PSA accepts frontend URL in 'next'):
    # get_social_auth_settings(env("FRONTEND_URL", default="http://localhost:3000"))

    # Provider credentials (keep in .env)
    SOCIAL_AUTH_GOOGLE_OAUTH2_KEY = env("SOCIAL_AUTH_GOOGLE_OAUTH2_KEY", default="")
    SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = env("SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET", default="")
    SOCIAL_AUTH_GITHUB_KEY = env("SOCIAL_AUTH_GITHUB_KEY", default="")
    SOCIAL_AUTH_GITHUB_SECRET = env("SOCIAL_AUTH_GITHUB_SECRET", default="")

Then include the social URLs::

    from django.urls import include, path

    urlpatterns = [
        ...
        path("auth/social/", include("nimoh_base.auth.url_modules.social")),
    ]
"""

from __future__ import annotations

import logging as _logging

_logger = _logging.getLogger(__name__)


def get_social_installed_apps() -> list[str]:
    """Return the ``INSTALLED_APPS`` entries required by ``social-auth-app-django``.

    Merging these into your project settings is sufficient to activate the
    social auth database tables without touching ``INSTALLED_APPS`` manually::

        INSTALLED_APPS = get_base_apps() + get_social_installed_apps() + [...]
    """
    return [
        "social_django",
    ]


def get_social_auth_pipeline() -> tuple[str, ...]:
    """Return a sensible default social-auth pipeline.

    The pipeline marks accounts created via social login with
    ``is_social_account = True`` and stores the provider slug.

    Override specific steps by building your own tuple from these defaults::

        SOCIAL_AUTH_PIPELINE = get_social_auth_pipeline() + (
            "myapp.social.my_custom_step",
        )
    """
    return (
        "social_core.pipeline.social_auth.social_details",
        "social_core.pipeline.social_auth.social_uid",
        "social_core.pipeline.social_auth.auth_allowed",
        "social_core.pipeline.social_auth.social_user",
        "social_core.pipeline.user.get_username",
        # Attempt to link to an existing user by email before creating a new one.
        # Prevents AuthAlreadyAssociated / UniqueViolation when a user who registered
        # with email+password later signs in with a social provider (e.g. Google).
        "social_core.pipeline.social_auth.associate_by_email",
        "social_core.pipeline.user.create_user",
        "social_core.pipeline.social_auth.associate_user",
        "social_core.pipeline.social_auth.load_extra_data",
        # nimoh-base step: stamp is_social_account + social_provider on the user
        "nimoh_base.conf.social._pipeline_mark_social_account",
        "social_core.pipeline.user.user_details",
        "nimoh_base.conf.social.nimoh_mark_social_email_verified",
        # MUST be last — embeds exchange token in PSA 'next' redirect (read before session.cycle_key()).
        "nimoh_base.conf.social.nimoh_social_generate_exchange_token",
    )


def _pipeline_mark_social_account(backend, user, response, *args, **kwargs):
    """Social-auth pipeline step: set ``is_social_account`` and ``social_provider``.

    This step is inserted by :func:`get_social_auth_pipeline`.
    """
    if user is None:
        return

    changed = False
    if not user.is_social_account:
        user.is_social_account = True
        changed = True

    provider = getattr(backend, "name", "")
    if provider and user.social_provider != provider:
        user.social_provider = provider
        changed = True

    if changed:
        update_fields = ["is_social_account", "social_provider"]
        user.save(update_fields=update_fields)


def nimoh_mark_social_email_verified(strategy, user, backend, *args, **kwargs):
    """
    Stamp email_verified=True for social-auth sign-ins.

    An OAuth ID token from Google (or any OIDC provider) is proof that the
    provider verified the email address. No additional verification step is
    needed on our side.
    """
    if not user or not user.pk:
        return
    if user.email_verified:
        return  # already done — idempotent

    from django.utils import timezone

    user.email_verified = True
    user.email_verified_at = timezone.now()
    user.save(update_fields=["email_verified", "email_verified_at"])


def get_social_context_processors() -> list[str]:
    """Return the ``TEMPLATES`` context processors needed by ``social_django``.

    Add to your ``TEMPLATES[0]["OPTIONS"]["context_processors"]`` list::

        context_processors = (
            ...
            *get_social_context_processors(),
        )
    """
    return [
        "social_django.context_processors.backends",
        "social_django.context_processors.login_redirect",
    ]


def _frontend_netloc(frontend_url: str) -> str:
    """Extract host:port from FRONTEND_URL for SOCIAL_AUTH_ALLOWED_REDIRECT_HOSTS."""
    url = (frontend_url or "").strip()
    if "//" in url:
        url = url.split("//", 1)[1]
    return url.split("/")[0].split("?")[0] or "localhost"


def get_social_auth_settings(
    frontend_url: str | None = None,
    done_path: str = "/api/v1/auth/social/done/",
) -> dict[str, object]:
    """Return PSA redirect settings so the pipeline can send users to the frontend.

    The pipeline step ``nimoh_social_generate_exchange_token`` sets ``next`` to
    ``{frontend_url}/auth/verified?exchange_token=...``. PSA's
    ``sanitize_redirect()`` only allows hosts in ``SOCIAL_AUTH_ALLOWED_REDIRECT_HOSTS``.
    Use this helper so the frontend host is allowed.

    **Do NOT set** ``SOCIAL_AUTH_NEW_USER_REDIRECT_URL``. When it is set, PSA
    uses it for first-time sign-ins instead of ``redirect_value`` (our
    exchange-token URL), so new users land on /done/ and can see an error.
    This helper omits it on purpose so new and returning users both use the
    pipeline's ``next`` URL.

    Usage::

        from nimoh_base.conf.social import get_social_auth_settings
        import os
        globals().update(get_social_auth_settings(os.environ.get("FRONTEND_URL", "http://localhost:3000")))
    """
    url = (frontend_url or "http://localhost:3000").strip()
    netloc = _frontend_netloc(url)
    return {
        "SOCIAL_AUTH_ALLOWED_REDIRECT_HOSTS": [netloc],
        "SOCIAL_AUTH_LOGIN_REDIRECT_URL": done_path,
    }


# Session key used only by social_login_done_view when pipeline step fails (fallback).
# Normal flow embeds token in PSA 'next' URL — never uses this key.
SOCIAL_EXCHANGE_TOKEN_SESSION_KEY = "_nimoh_social_exchange_token"


def nimoh_social_generate_exchange_token(strategy, user, backend, *args, **kwargs):
    """
    PSA pipeline step: generate an ExchangeToken and embed it in PSA's 'next'
    redirect URL so the browser lands on /auth/verified?exchange_token=...

    Do NOT use strategy.session_set(arbitrary_key, token). auth.login() runs
    after the pipeline and calls session.cycle_key(), which clears all custom
    session keys. PSA reads 'next' BEFORE login() — it is the only session-safe
    transport for redirect URLs.
    """
    if not user or not user.pk:
        return

    from django.conf import settings as django_settings

    from nimoh_base.auth.services import ExchangeTokenService

    try:
        token = ExchangeTokenService.generate_exchange_token(
            user=user,
            context={
                "source": "social_auth",
                "provider": getattr(backend, "name", "unknown"),
            },
        )
        frontend_url = getattr(django_settings, "FRONTEND_URL", "http://localhost:3000")
        redirect_url = f"{frontend_url}/auth/verified?exchange_token={token}"
        strategy.session_set("next", redirect_url)
        _logger.info(
            "Social exchange token embedded in redirect for user %s (%s)",
            user.email,
            getattr(backend, "name", "?"),
        )
    except Exception:
        _logger.exception("Failed to generate social exchange token for user %s", user.pk)
        # PSA falls back to SOCIAL_AUTH_LOGIN_REDIRECT_URL
