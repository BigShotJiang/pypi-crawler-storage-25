"""
Push notification device registration views.

Endpoints:
- ``POST /push/devices/``     — Register (or re-register) a device.
- ``DELETE /push/devices/``    — Unregister a device by its Expo push token.
- ``GET  /push/devices/``      — List the authenticated user's registered devices.
"""

from __future__ import annotations

import logging

from django.utils import timezone
from drf_spectacular.utils import OpenApiResponse, extend_schema, inline_serializer
from rest_framework import serializers, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import MobileDevice
from .serializers import MobileDeviceSerializer

logger = logging.getLogger(__name__)


class DeviceRegistrationView(APIView):
    """Register, list, or unregister mobile push devices."""

    permission_classes = [IsAuthenticated]

    @extend_schema(
        operation_id="push_device_register",
        summary="Register Push Device",
        description="Register an Expo push token for the authenticated user.",
        request=MobileDeviceSerializer,
        responses={
            201: MobileDeviceSerializer,
            200: MobileDeviceSerializer,
        },
        tags=["push"],
    )
    def post(self, request):
        serializer = MobileDeviceSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        device = serializer.save()

        # Touch last_used_at
        MobileDevice.objects.filter(pk=device.pk).update(last_used_at=timezone.now())

        logger.info(
            "Push device registered",
            extra={"user_id": str(request.user.id), "token": device.expo_push_token[:30]},
        )
        return Response(
            MobileDeviceSerializer(device).data,
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(
        operation_id="push_device_list",
        summary="List Push Devices",
        description="List all active push devices for the authenticated user.",
        responses={200: MobileDeviceSerializer(many=True)},
        tags=["push"],
    )
    def get(self, request):
        devices = MobileDevice.objects.filter(user=request.user, is_active=True)
        return Response(MobileDeviceSerializer(devices, many=True).data)

    @extend_schema(
        operation_id="push_device_unregister",
        summary="Unregister Push Device",
        description="Deactivate a device by its Expo push token.",
        request=inline_serializer(
            name="UnregisterDeviceRequest",
            fields={
                "expo_push_token": serializers.CharField(
                    help_text="Expo push token to unregister.",
                ),
            },
        ),
        responses={
            204: OpenApiResponse(description="Device unregistered."),
            404: OpenApiResponse(description="Device not found."),
        },
        tags=["push"],
    )
    def delete(self, request):
        token = request.data.get("expo_push_token")
        if not token:
            return Response(
                {"detail": "expo_push_token is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        updated = MobileDevice.objects.filter(
            user=request.user,
            expo_push_token=token,
            is_active=True,
        ).update(is_active=False)

        if not updated:
            return Response(
                {"detail": "Device not found or already unregistered."},
                status=status.HTTP_404_NOT_FOUND,
            )

        logger.info(
            "Push device unregistered",
            extra={"user_id": str(request.user.id), "token": token[:30]},
        )
        return Response(status=status.HTTP_204_NO_CONTENT)
