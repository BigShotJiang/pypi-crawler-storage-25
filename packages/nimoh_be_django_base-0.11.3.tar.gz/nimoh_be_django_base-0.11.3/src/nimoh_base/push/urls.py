"""Push notification URL patterns.

Include in your root URLconf::

    path("api/v1/push/", include("nimoh_base.push.urls")),

Or use ``nimoh_base_mobile_urlpatterns()`` which wires this automatically.
"""

from django.urls import path

from .views import DeviceRegistrationView

app_name = "push"

urlpatterns = [
    path("devices/", DeviceRegistrationView.as_view(), name="device-registration"),
]
