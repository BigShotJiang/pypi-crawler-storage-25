"""
nimoh_base.push
===============
Push notification support for mobile clients via Expo Push API.

Add ``'nimoh_base.push'`` to ``INSTALLED_APPS`` and configure
``NIMOH_BASE['EXPO_ACCESS_TOKEN']`` with a valid Expo access token.
"""

default_app_config = "nimoh_base.push.apps.PushConfig"
