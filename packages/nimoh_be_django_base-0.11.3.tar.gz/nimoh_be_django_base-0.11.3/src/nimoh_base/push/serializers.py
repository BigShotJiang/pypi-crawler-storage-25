from rest_framework import serializers

from .models import MobileDevice


class MobileDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = MobileDevice
        fields = [
            "id",
            "expo_push_token",
            "platform",
            "device_name",
            "is_active",
            "created_at",
            "last_used_at",
        ]
        read_only_fields = ["id", "is_active", "created_at", "last_used_at"]
        extra_kwargs = {
            # Disable the auto-generated UniqueValidator so that re-registering
            # the same token triggers update_or_create instead of a 400.
            "expo_push_token": {"validators": []},
        }

    def validate_expo_push_token(self, value: str) -> str:
        if not value.startswith("ExponentPushToken["):
            raise serializers.ValidationError("Invalid Expo push token format. Expected ExponentPushToken[…].")
        return value

    def create(self, validated_data):
        user = self.context["request"].user
        token = validated_data["expo_push_token"]

        device, _created = MobileDevice.objects.update_or_create(
            expo_push_token=token,
            defaults={
                "user": user,
                "platform": validated_data.get("platform", MobileDevice.Platform.ANDROID),
                "device_name": validated_data.get("device_name", ""),
                "is_active": True,
            },
        )
        return device
