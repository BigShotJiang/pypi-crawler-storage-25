from django.apps import AppConfig


class PushConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nimoh_base.push"
    verbose_name = "Push Notifications"
    label = "nimoh_push"
