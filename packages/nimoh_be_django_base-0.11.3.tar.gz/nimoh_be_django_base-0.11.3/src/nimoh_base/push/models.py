"""
Push notification models.

``MobileDevice`` stores Expo push tokens per user so that Celery tasks can
target individual devices when sending push notifications.
"""

from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


class MobileDevice(models.Model):
    """A registered mobile device that can receive push notifications."""

    class Platform(models.TextChoices):
        IOS = "ios", "iOS"
        ANDROID = "android", "Android"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="mobile_devices",
    )
    expo_push_token = models.CharField(
        max_length=255,
        unique=True,
        help_text="Expo push token (ExponentPushToken[…]).",
    )
    platform = models.CharField(
        max_length=10,
        choices=Platform.choices,
        default=Platform.ANDROID,
    )
    device_name = models.CharField(max_length=255, blank=True, default="")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_used_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-last_used_at"]
        verbose_name = "Mobile Device"
        verbose_name_plural = "Mobile Devices"

    def __str__(self) -> str:
        return f"{self.user} — {self.platform} ({self.expo_push_token[:30]}…)"
