"""
Celery tasks for sending push notifications via the Expo Push API.

Usage::

    from nimoh_base.push.tasks import send_push_notification

    send_push_notification.delay(
        user_id=str(user.pk),
        title="New Message",
        body="You have a new message from Alice.",
        data={"screen": "chat", "chat_id": "abc123"},
    )
"""

from __future__ import annotations

import logging
from typing import Any

import requests
from celery import shared_task

from nimoh_base.conf import nimoh_setting

logger = logging.getLogger(__name__)

EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send"


def _get_expo_headers() -> dict[str, str]:
    token = nimoh_setting("EXPO_ACCESS_TOKEN", "")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


@shared_task(
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    autoretry_for=(requests.RequestException,),
    acks_late=True,
)
def send_push_notification(
    self,
    user_id: str,
    title: str,
    body: str,
    data: dict[str, Any] | None = None,
    *,
    badge: int | None = None,
    sound: str = "default",
    channel_id: str | None = None,
) -> dict:
    """Send a push notification to all active devices of the given user.

    Args:
        user_id: UUID string of the target user.
        title: Notification title.
        body: Notification body text.
        data: Arbitrary JSON data payload delivered to the app.
        badge: iOS badge count (optional).
        sound: Notification sound (default: ``'default'``).
        channel_id: Android notification channel ID (optional).

    Returns:
        Dict with ``sent`` count and any ``errors``.
    """
    from .models import MobileDevice

    tokens = list(
        MobileDevice.objects.filter(
            user_id=user_id,
            is_active=True,
        ).values_list("expo_push_token", flat=True)
    )

    if not tokens:
        logger.info("No active devices for user %s — skipping push", user_id)
        return {"sent": 0, "errors": []}

    messages = []
    for token in tokens:
        msg: dict[str, Any] = {
            "to": token,
            "title": title,
            "body": body,
            "sound": sound,
        }
        if data:
            msg["data"] = data
        if badge is not None:
            msg["badge"] = badge
        if channel_id:
            msg["channelId"] = channel_id
        messages.append(msg)

    try:
        resp = requests.post(
            EXPO_PUSH_URL,
            json=messages,
            headers=_get_expo_headers(),
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.RequestException:
        logger.exception("Expo push API request failed for user %s", user_id)
        raise  # triggers Celery autoretry

    errors = []
    resp_data = result.get("data", [])
    for i, ticket in enumerate(resp_data):
        if ticket.get("status") == "error":
            error_msg = ticket.get("message", "Unknown error")
            errors.append({"token": tokens[i][:30], "error": error_msg})
            # Deactivate tokens that Expo says are invalid
            if ticket.get("details", {}).get("error") == "DeviceNotRegistered":
                MobileDevice.objects.filter(expo_push_token=tokens[i]).update(is_active=False)
                logger.info("Deactivated invalid push token: %s…", tokens[i][:30])

    sent = len(tokens) - len(errors)
    logger.info(
        "Push notifications sent",
        extra={"user_id": user_id, "sent": sent, "errors": len(errors)},
    )
    return {"sent": sent, "errors": errors}


@shared_task
def send_push_to_tokens(
    tokens: list[str],
    title: str,
    body: str,
    data: dict[str, Any] | None = None,
) -> dict:
    """Send a push notification to specific tokens (e.g. broadcast).

    Unlike ``send_push_notification`` this accepts raw tokens rather than
    a user ID, useful for admin broadcasts or topic-based notifications.
    """
    if not tokens:
        return {"sent": 0, "errors": []}

    messages = [
        {"to": t, "title": title, "body": body, "sound": "default", **({"data": data} if data else {})} for t in tokens
    ]

    try:
        resp = requests.post(
            EXPO_PUSH_URL,
            json=messages,
            headers=_get_expo_headers(),
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.RequestException:
        logger.exception("Expo push API broadcast failed")
        return {"sent": 0, "errors": ["request_failed"]}

    errors = []
    for i, ticket in enumerate(result.get("data", [])):
        if ticket.get("status") == "error":
            errors.append({"token": tokens[i][:30], "error": ticket.get("message", "")})
            if ticket.get("details", {}).get("error") == "DeviceNotRegistered":
                from .models import MobileDevice

                MobileDevice.objects.filter(expo_push_token=tokens[i]).update(is_active=False)

    return {"sent": len(tokens) - len(errors), "errors": errors}
