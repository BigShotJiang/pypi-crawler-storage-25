from django.contrib import admin

from .models import MobileDevice


@admin.register(MobileDevice)
class MobileDeviceAdmin(admin.ModelAdmin):
    list_display = ["user", "platform", "device_name", "is_active", "last_used_at", "created_at"]
    list_filter = ["platform", "is_active"]
    search_fields = ["user__email", "user__username", "expo_push_token", "device_name"]
    readonly_fields = ["id", "created_at", "updated_at", "last_used_at"]
    raw_id_fields = ["user"]
