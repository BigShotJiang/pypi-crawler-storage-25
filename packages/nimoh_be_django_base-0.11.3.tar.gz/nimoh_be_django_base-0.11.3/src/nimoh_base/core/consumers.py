"""
Base WebSocket consumers for nimoh-be-django-base.

Provides ``AuthenticatedJsonConsumer`` — an async JSON WebSocket consumer
that rejects unauthenticated connections.  Consumer projects subclass this
for their own real-time features::

    from nimoh_base.core.consumers import AuthenticatedJsonConsumer

    class ChatConsumer(AuthenticatedJsonConsumer):
        async def receive_json(self, content, **kwargs):
            await self.send_json({"echo": content})

Requires ``channels`` (install ``nimoh-be-django-base[channels]``).
"""

from __future__ import annotations

import logging

from channels.generic.websocket import AsyncJsonWebsocketConsumer

logger = logging.getLogger(__name__)


class AuthenticatedJsonConsumer(AsyncJsonWebsocketConsumer):
    """JSON WebSocket consumer that rejects anonymous connections.

    Subclass this for any WebSocket endpoint that requires authentication.
    The ``scope["user"]`` is set by ``JWTAuthMiddleware`` (or the session
    middleware) before ``connect()`` is called.
    """

    async def connect(self):
        self.user = self.scope.get("user")

        if not self.user or not self.user.is_authenticated:
            logger.info(
                "WS connection rejected — unauthenticated",
                extra={"path": self.scope.get("path", "")},
            )
            await self.close(code=4401)
            return

        await self.accept()
        logger.debug(
            "WS connection accepted",
            extra={"user_id": str(self.user.pk), "path": self.scope.get("path", "")},
        )

    async def disconnect(self, close_code):
        user_id = str(self.user.pk) if hasattr(self, "user") and self.user and self.user.is_authenticated else "anon"
        logger.debug(
            "WS disconnected",
            extra={"user_id": user_id, "close_code": close_code},
        )

    async def receive_json(self, content, **kwargs):
        """Override in subclass to handle incoming JSON messages."""
        await self.send_json({"error": "Not implemented"})
