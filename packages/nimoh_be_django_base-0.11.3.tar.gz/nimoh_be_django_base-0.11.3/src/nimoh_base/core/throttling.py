"""Custom throttling classes — sliding-window counter algorithm.

This module replaces DRF's default ``SimpleRateThrottle`` (which stores a
list of timestamps per client) with a **sliding-window counter** approach:

*   Two fixed-window counters — *previous* and *current* — are kept in the
    cache.  The effective request count is a weighted blend::

        effective = prev_count x (1 - position_in_window) + curr_count

    where ``position_in_window`` is how far (0.0 -> 1.0) we are into the
    current window.

*   **O(1)** per request — no list of timestamps stored.
*   Eliminates the boundary-burst problem of fixed-window counters.
*   Provides an accurate ``Retry-After`` header via :meth:`wait`.

Throttle rates are configured via ``REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']``
in settings.  Test settings simply raise the rates to avoid test flakiness.
"""

import math
import time

from django.core.cache import cache as default_cache
from rest_framework.settings import api_settings
from rest_framework.throttling import BaseThrottle

# ---------------------------------------------------------------------------
# Sliding-window base throttle
# ---------------------------------------------------------------------------


class SlidingWindowThrottle(BaseThrottle):
    """Sliding-window *counter* throttle (O(1), no timestamp list).

    Sub-classes must set ``scope`` and override :meth:`get_cache_key`
    (or inherit from :class:`AnonRateThrottle` / :class:`UserRateThrottle`).
    """

    cache = default_cache
    timer = time.time
    cache_format = "throttle_%(scope)s_%(ident)s"
    scope = None
    THROTTLE_RATES = api_settings.DEFAULT_THROTTLE_RATES

    def __init__(self):
        if not getattr(self, "rate", None):
            self.rate = self.get_rate()
        self.num_requests, self.duration = self.parse_rate(self.rate)

    # -- configuration helpers (same API as SimpleRateThrottle) -------------

    def get_rate(self):
        if not getattr(self, "scope", None):
            msg = f"You must set either `.scope` or `.rate` for '{self.__class__.__name__}' throttle"
            from django.core.exceptions import ImproperlyConfigured

            raise ImproperlyConfigured(msg)
        try:
            return self.THROTTLE_RATES[self.scope]
        except KeyError:
            from django.core.exceptions import ImproperlyConfigured

            msg = f"No default throttle rate set for '{self.scope}' scope"
            raise ImproperlyConfigured(msg)

    @staticmethod
    def parse_rate(rate):
        if rate is None:
            return (None, None)
        num, period = rate.split("/")
        num_requests = int(num)
        duration = {"s": 1, "m": 60, "h": 3600, "d": 86400}[period[0]]
        return (num_requests, duration)

    def get_cache_key(self, request, view):
        raise NotImplementedError(".get_cache_key() must be overridden")

    # -- sliding-window logic -----------------------------------------------

    def _window_id(self, now):
        """Return the integer window-id for *now*."""
        return int(now // self.duration)

    def _window_key(self, base_key, window_id):
        """Return the cache key for a specific window."""
        return f"{base_key}:w{window_id}"

    def allow_request(self, request, view):
        if self.rate is None:
            return True

        self.key = self.get_cache_key(request, view)
        if self.key is None:
            return True

        self.now = self.timer()
        window_id = self._window_id(self.now)
        position = (self.now % self.duration) / self.duration  # 0.0 → 1.0

        prev_key = self._window_key(self.key, window_id - 1)
        curr_key = self._window_key(self.key, window_id)

        counts = self.cache.get_many([prev_key, curr_key])
        prev_count = counts.get(prev_key, 0)
        curr_count = counts.get(curr_key, 0)

        # Weighted estimate of requests in the sliding window
        self.effective_count = prev_count * (1 - position) + curr_count

        if self.effective_count >= self.num_requests:
            return self.throttle_failure()
        return self.throttle_success(curr_key)

    def throttle_success(self, curr_key):
        """Increment the current window counter and allow the request."""
        # Use cache.incr with an add fallback for atomicity.
        try:
            self.cache.incr(curr_key)
        except ValueError:
            # Key doesn't exist yet — create it.
            self.cache.set(curr_key, 1, timeout=self.duration * 2)
        else:
            # Ensure TTL exists (incr doesn't set one on new keys in some
            # backends).  touch() is a no-op if the key already has a TTL.
            try:
                self.cache.touch(curr_key, timeout=self.duration * 2)
            except AttributeError:
                pass  # Ancient cache backends without touch()
        return True

    def throttle_failure(self):
        return False

    def wait(self):
        """Seconds until the client has quota again."""
        if self.num_requests is None:
            return None
        # Time remaining in the current window — worst-case wait.
        remaining = self.duration - (self.now % self.duration)
        return math.ceil(remaining)


# ---------------------------------------------------------------------------
# Base throttles (anon / user identification)
# ---------------------------------------------------------------------------


class AnonRateThrottle(SlidingWindowThrottle):
    """IP-based throttle for anonymous (unauthenticated) requests."""

    scope = "anon"

    def get_cache_key(self, request, view):
        if request.user and request.user.is_authenticated:
            return None  # Only throttle unauthenticated requests.
        return self.cache_format % {"scope": self.scope, "ident": self.get_ident(request)}


class UserRateThrottle(SlidingWindowThrottle):
    """User-based throttle for authenticated requests (falls back to IP)."""

    scope = "user"

    def get_cache_key(self, request, view):
        if request.user and request.user.is_authenticated:
            ident = request.user.pk
        else:
            ident = self.get_ident(request)
        return self.cache_format % {"scope": self.scope, "ident": ident}


# ---------------------------------------------------------------------------
# Domain-specific throttles
# ---------------------------------------------------------------------------


class AuthenticationRateThrottle(AnonRateThrottle):
    """
    Throttle for authentication endpoints (login, etc.)

    More restrictive than standard anonymous throttle to prevent
    brute force attacks.
    """

    scope = "auth"


class RegistrationRateThrottle(AnonRateThrottle):
    """
    Throttle for user registration.

    Prevents automated account creation while allowing
    legitimate users to register.
    """

    scope = "registration"


class PasswordResetRateThrottle(AnonRateThrottle):
    """
    Throttle for password reset requests.

    Prevents email enumeration and spam while allowing
    legitimate password reset requests.
    """

    scope = "password_reset"


class EmailVerificationRateThrottle(UserRateThrottle):
    """
    Throttle for email verification attempts.
    Uses user-based throttling to prevent abuse per account.
    """

    scope = "email_verification"


class LoginRateThrottle(AnonRateThrottle):
    """
    Specific throttle for login attempts.

    More restrictive than general auth throttle to prevent
    brute force attacks on login endpoint specifically.
    """

    scope = "login"


class TokenRefreshRateThrottle(AnonRateThrottle):
    """
    Throttle for JWT token refresh requests.

    Allows reasonable refresh frequency while preventing
    token refresh abuse.
    """

    scope = "token_refresh"


class EmailVerificationConfirmRateThrottle(AnonRateThrottle):
    """
    Throttle for email verification confirmation (via link).

    IP-based throttling for verification confirmations to prevent
    verification link abuse.
    """

    scope = "email_verification_confirm"


class PasswordResetConfirmRateThrottle(AnonRateThrottle):
    """
    Throttle for password reset confirmation.

    IP-based throttling for password reset confirmations.
    """

    scope = "password_reset_confirm"


class DeviceManagementRateThrottle(UserRateThrottle):
    """
    Throttle for device/session management operations.
    """

    scope = "device_management"


class ContentModerationRateThrottle(UserRateThrottle):
    """
    Throttle for content creation and moderation actions.
    """

    scope = "content_moderation"


class ChangePasswordRateThrottle(UserRateThrottle):
    """
    Throttle for authenticated password change requests.

    User-scoped so each account has its own quota, preventing
    credential-stuffing via repeated password change attempts.
    """

    scope = "change_password"
