"""
WebSocket JWT authentication middleware for Django Channels.

Authenticates WebSocket connections using a JWT access token passed as a
query-string parameter (``?token=<access_token>``).

Usage in ``asgi.py``::

    from nimoh_base.core.ws_auth import JWTAuthMiddlewareStack

    application = ProtocolTypeRouter({
        "http": get_asgi_application(),
        "websocket": JWTAuthMiddlewareStack(
            URLRouter(websocket_urlpatterns)
        ),
    })

Requires ``channels`` and ``djangorestframework-simplejwt``.
"""

from __future__ import annotations

import logging
from urllib.parse import parse_qs

from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser

logger = logging.getLogger(__name__)
User = get_user_model()


async def authenticate_token(token_str: str):
    """Validate a JWT access token and return the associated user.

    Returns ``AnonymousUser`` if the token is invalid, expired, or the
    user no longer exists / is inactive.

    This function is safe to call from an async context (it wraps the
    synchronous ORM lookup with ``sync_to_async``).
    """
    from channels.db import database_sync_to_async
    from rest_framework_simplejwt.exceptions import TokenError
    from rest_framework_simplejwt.tokens import AccessToken

    try:
        access_token = AccessToken(token_str)
    except TokenError as exc:
        logger.debug("WS auth: invalid token — %s", exc)
        return AnonymousUser()

    user_id = access_token.get("user_id")
    if not user_id:
        logger.debug("WS auth: token missing user_id claim")
        return AnonymousUser()

    @database_sync_to_async
    def _get_user():
        try:
            user = User.objects.get(id=user_id)
            if not user.is_active:
                logger.debug("WS auth: user %s is inactive", user_id)
                return AnonymousUser()
            return user
        except User.DoesNotExist:
            logger.debug("WS auth: user %s not found", user_id)
            return AnonymousUser()

    return await _get_user()


class JWTAuthMiddleware:
    """ASGI middleware that authenticates WebSocket connections via JWT.

    Reads the ``token`` query-string parameter from the connection scope
    and sets ``scope["user"]`` to the authenticated user (or
    ``AnonymousUser``).

    Example connection URL from the client::

        ws://localhost:8000/ws/chat/?token=eyJhbGciOiJIUzI1NiIs...
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        query_string = scope.get("query_string", b"").decode("utf-8")
        params = parse_qs(query_string)
        token_list = params.get("token", [])

        if token_list:
            scope["user"] = await authenticate_token(token_list[0])
        else:
            scope["user"] = AnonymousUser()

        return await self.app(scope, receive, send)


def JWTAuthMiddlewareStack(inner):  # noqa: N802
    """Convenience wrapper that applies ``JWTAuthMiddleware`` on top of
    ``AuthMiddlewareStack`` (which provides session-based fallback).

    Usage::

        from nimoh_base.core.ws_auth import JWTAuthMiddlewareStack

        application = ProtocolTypeRouter({
            "websocket": JWTAuthMiddlewareStack(URLRouter(ws_urls)),
        })
    """
    from channels.auth import AuthMiddlewareStack

    return JWTAuthMiddleware(AuthMiddlewareStack(inner))
