"""Core models — abstract base classes only. No domain-specific constants."""

from django.db import models
from django.db.models import signals
from django.utils import timezone


class TimeStampedModel(models.Model):
    """Abstract base model with created and modified timestamps"""

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
        ordering = ["-created_at"]


class SoftDeleteQuerySet(models.QuerySet):
    """QuerySet that excludes soft-deleted records by default."""

    def delete(self):
        """Soft-delete all records in the queryset, firing Django signals.

        Django's built-in ``QuerySet.delete()`` sends ``pre_delete`` and
        ``post_delete`` signals per instance.  Because a bulk ``UPDATE`` skips
        those signals, we send them manually so that audit hooks, cache
        invalidation, and signal-based cascades continue to work correctly.
        """
        now = timezone.now()
        # Collect instances before mutating so signal receivers see full objects.
        instances = list(self)
        for obj in instances:
            signals.pre_delete.send(sender=obj.__class__, instance=obj, using=self.db)
        updated = self.update(is_deleted=True, deleted_at=now)
        for obj in instances:
            signals.post_delete.send(sender=obj.__class__, instance=obj, using=self.db)
        return updated, {}

    def hard_delete(self):
        """Permanently delete all records in the queryset."""
        return super().delete()

    def alive(self):
        """Return only non-deleted records (explicit alias)."""
        return self.filter(is_deleted=False)

    def dead(self):
        """Return only soft-deleted records."""
        return self.filter(is_deleted=True)


class SoftDeleteManager(models.Manager):
    """Default manager that excludes soft-deleted records."""

    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db).filter(is_deleted=False)


class SoftDeleteAllManager(models.Manager):
    """Manager that includes soft-deleted records."""

    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db)


class SoftDeleteModel(models.Model):
    """Abstract base model with soft delete functionality.

    ``objects`` returns only non-deleted rows.  Use ``all_objects``
    to include soft-deleted rows (e.g. for admin or audit views).
    """

    deleted_at = models.DateTimeField(null=True, blank=True, db_index=True)
    is_deleted = models.BooleanField(default=False, db_index=True)

    objects = SoftDeleteManager()
    all_objects = SoftDeleteAllManager()

    class Meta:
        abstract = True
        # Partial index on non-deleted rows. The most common query filter for
        # soft-delete models is ``is_deleted=False``.  This index is smaller
        # and faster than a full index on ``is_deleted``.
        #
        # Requires PostgreSQL ≥ 8.0, SQLite ≥ 3.8.9, or MariaDB ≥ 10.5.
        # The ``%(app_label)s_%(class)s`` substitution produces a unique index
        # name for each concrete subclass, which is required for abstract
        # model index inheritance.
        indexes = [
            models.Index(
                fields=["is_deleted"],
                condition=models.Q(is_deleted=False),
                name="%(app_label)s_%(class)s_active_idx",
            )
        ]

    def delete(self, using=None, keep_parents=False):
        """Override Django's ``delete()`` to perform a soft-delete.

        ``BaseModelViewSet.perform_destroy()`` calls ``instance.delete()``
        which would previously bypass soft-deletion entirely.  Overriding
        here ensures that any call site — not just explicit ``.soft_delete()``
        calls — produces the correct soft-delete behaviour.

        Fires Django ``pre_delete`` / ``post_delete`` signals so that audit
        hooks and signal-based cascades continue to work.
        """
        using = using or self._state.db
        signals.pre_delete.send(sender=self.__class__, instance=self, using=using)
        self.deleted_at = timezone.now()
        self.is_deleted = True
        self.save(update_fields=["deleted_at", "is_deleted"], using=using)
        signals.post_delete.send(sender=self.__class__, instance=self, using=using)

    def hard_delete(self, using=None, keep_parents=False):
        """Permanently remove the row from the database."""
        return super().delete(using=using, keep_parents=keep_parents)

    def soft_delete(self):
        """Alias for ``delete()``; kept for explicit call sites."""
        self.delete()

    def restore(self):
        """Restore a soft deleted instance"""
        self.deleted_at = None
        self.is_deleted = False
        self.save(update_fields=["deleted_at", "is_deleted"])
