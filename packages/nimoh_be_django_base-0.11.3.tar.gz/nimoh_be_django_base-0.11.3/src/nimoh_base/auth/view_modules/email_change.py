"""
Email-change flow views.

POST /auth/email/change/         — request a change (sends confirmation to new address)
POST /auth/email/change/confirm/ — apply the change using the token from the email
"""

from __future__ import annotations

import logging

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from nimoh_base.core.throttling import AuthenticationRateThrottle

from ..serializers import EmailChangeConfirmSerializer, EmailChangeRequestSerializer
from ..services import EmailChangeService

logger = logging.getLogger(__name__)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@throttle_classes([AuthenticationRateThrottle])
def email_change_request_view(request):
    """Initiate an email-address change.

    Sends a confirmation link to the **new** email address.  The current
    address is unchanged until the link is followed.

    ``POST /auth/email/change/``

    Request body::

        {"new_email": "alice@new.example", "current_password": "s3cr3t"}

    Responses:

    * **200** — confirmation email sent (even if address is already taken —
      to avoid enumeration).
    * **400** — validation error (malformed email, same as current address, …).
    * **401** — not authenticated / wrong password.
    """
    serializer = EmailChangeRequestSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    user = request.user
    new_email: str = serializer.validated_data["new_email"]
    current_password: str = serializer.validated_data["current_password"]

    # Re-authenticate with current password before allowing change
    if not user.check_password(current_password):
        return Response(
            {"detail": "Current password is incorrect."},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    try:
        EmailChangeService.request_change(user, new_email, request=request)
    except ValueError as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

    return Response(
        {
            "detail": (
                f"A confirmation email has been sent to {new_email}. "
                "The change will take effect once you follow the link."
            )
        },
        status=status.HTTP_200_OK,
    )


@api_view(["POST"])
@permission_classes([])  # AllowAny — token carries the auth
@throttle_classes([AuthenticationRateThrottle])
def email_change_confirm_view(request):
    """Apply a pending email-address change.

    ``POST /auth/email/change/confirm/``

    Request body::

        {"token": "<raw-token-from-confirmation-email>"}

    Responses:

    * **200** — email changed; returns ``{"new_email": "..."}``
    * **400** — token missing or invalid
    * **410** — token expired or already used
    """
    serializer = EmailChangeConfirmSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    token_str: str = serializer.validated_data["token"]

    try:
        _user, new_email = EmailChangeService.confirm_change(token_str, request=request)
    except ValueError as exc:
        msg = str(exc)
        http_status = status.HTTP_410_GONE if "expired" in msg.lower() else status.HTTP_400_BAD_REQUEST
        return Response({"detail": msg}, status=http_status)

    return Response(
        {"detail": "Email address updated successfully.", "new_email": new_email},
        status=status.HTTP_200_OK,
    )
