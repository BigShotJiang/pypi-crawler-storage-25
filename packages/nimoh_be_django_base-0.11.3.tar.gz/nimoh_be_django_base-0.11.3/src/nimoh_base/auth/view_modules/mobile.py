"""
Mobile authentication views: Google native sign-in and mobile token exchange.

This module provides authentication endpoints optimised for native mobile
clients (React Native / Expo):

- ``GoogleMobileAuthView``  — verifies a Google ID token obtained via the
  platform-native Google Sign-In SDK, finds-or-creates the Django user, and
  returns JWT access + refresh tokens in the response body (no cookies).
- ``MobileExchangeTokenView`` — accepts a refresh token via the
  ``X-Refresh-Token`` header, rotates it, and returns a new access + refresh
  pair.  This is the mobile-specific counterpart of the cookie-based
  ``RefreshTokenView``.

Both views require the ``[mobile]`` extra (``google-auth``,
``google-api-python-client``) to be installed.

Usage::

    # urls.py
    from nimoh_base.auth.url_modules import mobile
    urlpatterns += [
        path("api/v1/auth/mobile/", include(mobile)),
    ]
"""

from __future__ import annotations

import logging
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from drf_spectacular.utils import OpenApiResponse, extend_schema, inline_serializer
from rest_framework import serializers, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken

from nimoh_base.conf import nimoh_setting
from nimoh_base.core.api_tags import APITags
from nimoh_base.core.exceptions import ProblemDetailException
from nimoh_base.core.throttling import AnonRateThrottle, AuthenticationRateThrottle
from nimoh_base.core.utils import get_client_ip

from ..models import AuditLog, UserSession
from ..services import AuthenticationService
from ..tasks import enforce_session_limit_task

User = get_user_model()
logger = logging.getLogger(__name__)


def _verify_google_id_token(id_token: str) -> dict:
    """Verify a Google ID token and return the decoded payload.

    Raises ``ValueError`` if the token is invalid or the audience is not in
    ``NIMOH_BASE['GOOGLE_MOBILE_CLIENT_IDS']``.
    """
    try:
        from google.auth.transport import requests as google_requests
        from google.oauth2 import id_token as google_id_token
    except ImportError:
        raise ProblemDetailException(
            detail="Google auth libraries not installed. Install nimoh-be-django-base[mobile].",
            code="missing_dependency",
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
        )

    allowed_client_ids = nimoh_setting("GOOGLE_MOBILE_CLIENT_IDS", [])
    if not allowed_client_ids:
        raise ProblemDetailException(
            detail="Google mobile sign-in is not configured.",
            code="not_configured",
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
        )

    try:
        idinfo = google_id_token.verify_oauth2_token(
            id_token,
            google_requests.Request(),
        )
    except ValueError as exc:
        raise ValueError(f"Invalid Google ID token: {exc}") from exc

    if idinfo.get("aud") not in allowed_client_ids:
        raise ValueError("Token audience not in GOOGLE_MOBILE_CLIENT_IDS.")

    if not idinfo.get("email_verified", False):
        raise ValueError("Google account email is not verified.")

    return idinfo


def _get_or_create_google_user(idinfo: dict) -> tuple[User, bool]:
    """Find an existing user by Google email or create a new one.

    Returns ``(user, created)`` tuple.
    """
    email = idinfo["email"].lower().strip()

    try:
        user = User.objects.get(email=email)
        return user, False
    except User.DoesNotExist:
        pass

    # Auto-create user from verified Google account
    username = email.split("@")[0]
    base_username = username
    counter = 1
    while User.objects.filter(username=username).exists():
        username = f"{base_username}{counter}"
        counter += 1

    try:
        user = User.objects.create_user(
            username=username,
            email=email,
            first_name=idinfo.get("given_name", ""),
            last_name=idinfo.get("family_name", ""),
            is_active=True,
        )
        user.email_verified = True
        user.email_verified_at = timezone.now()
        user.save(update_fields=["email_verified", "email_verified_at"])
        return user, True
    except IntegrityError:
        # Race condition: user was created between our check and create
        user = User.objects.get(email=email)
        return user, False


def _create_mobile_session(
    user,
    refresh: RefreshToken,
    request,
    *,
    device_name: str = "Mobile Device",
) -> UserSession:
    """Create a ``UserSession`` for a mobile login and return it."""
    session = UserSession.objects.create(
        user=user,
        device_fingerprint=AuthenticationService.get_device_fingerprint(request),
        device_name=device_name,
        user_agent=request.META.get("HTTP_USER_AGENT", ""),
        ip_address=get_client_ip(request),
        refresh_token_jti=str(refresh["jti"]),
        session_key=f"{str(refresh['jti'])[:24]}_{str(int(timezone.now().timestamp()))[:8]}",
        expires_at=timezone.now() + timedelta(days=14),
    )
    _uid = user.pk
    transaction.on_commit(lambda: enforce_session_limit_task.delay(_uid))
    return session


class GoogleMobileAuthView(APIView):
    """Verify a Google ID token from native mobile Sign-In and return JWTs.

    The mobile app obtains the ID token via the platform-specific Google
    Sign-In SDK (``@react-native-google-signin/google-signin``) and sends
    it here.  The backend verifies the token with Google's servers,
    finds-or-creates the local user, and issues JWT access + refresh tokens.
    """

    permission_classes = [AllowAny]
    throttle_classes = [AuthenticationRateThrottle]

    @extend_schema(
        operation_id="auth_mobile_google",
        summary="Google Mobile Sign-In",
        description=(
            "Verify a Google ID token from the native mobile SDK and return "
            "JWT access + refresh tokens in the response body."
        ),
        request=inline_serializer(
            name="GoogleMobileAuthRequest",
            fields={
                "id_token": serializers.CharField(help_text="Google ID token from the native SDK."),
                "device_name": serializers.CharField(
                    required=False,
                    default="Mobile Device",
                    help_text="Human-readable device name for session tracking.",
                ),
            },
        ),
        responses={
            200: OpenApiResponse(description="Authentication successful — returning existing user."),
            201: OpenApiResponse(description="Authentication successful — new user created."),
            400: OpenApiResponse(description="Invalid Google ID token."),
            501: OpenApiResponse(description="Google mobile auth not configured."),
        },
        tags=[APITags.AUTHENTICATION],
    )
    def post(self, request):
        id_token_str = request.data.get("id_token")
        if not id_token_str:
            raise ProblemDetailException(
                detail=_("id_token is required."),
                code="missing_id_token",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        # Verify Google ID token
        try:
            idinfo = _verify_google_id_token(id_token_str)
        except ValueError as exc:
            AuditLog.log_event(
                event_type="login_failure",
                description=f"Google mobile auth failed: {exc}",
                ip_address=get_client_ip(request),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                success=False,
                risk_level="medium",
                metadata={"method": "google_mobile"},
            )
            raise ProblemDetailException(
                detail=str(exc),
                code="google_token_invalid",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        # Find or create user
        with transaction.atomic():
            user, created = _get_or_create_google_user(idinfo)

            if not user.is_active:
                raise ProblemDetailException(
                    detail=_("This account has been disabled."),
                    code="account_disabled",
                    status_code=status.HTTP_403_FORBIDDEN,
                )

            if user.is_account_locked():
                raise ProblemDetailException(
                    detail=_("Account is temporarily locked. Please try again later."),
                    code="account_locked",
                    status_code=status.HTTP_423_LOCKED,
                )

            # Issue JWT tokens
            refresh = RefreshToken.for_user(user)
            device_name = request.data.get("device_name", "Mobile Device")

            session = _create_mobile_session(user, refresh, request, device_name=device_name)

            AuditLog.log_from_request(
                request,
                event_type="login_success",
                description=f"Google mobile sign-in {'(new user)' if created else ''}",
                user=user,
                metadata={
                    "method": "google_mobile",
                    "created": created,
                    "session_id": str(session.id),
                    "google_sub": idinfo.get("sub", ""),
                },
            )

        response_data = {
            "access_token": str(refresh.access_token),
            "refresh_token": str(refresh),
            "expires_in": int(refresh.access_token.lifetime.total_seconds()),
            "token_type": "Bearer",
            "user": {
                "id": str(user.id),
                "email": user.email,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email_verified": user.email_verified,
            },
            "created": created,
        }

        http_status = status.HTTP_201_CREATED if created else status.HTTP_200_OK
        logger.info(
            "Google mobile auth successful",
            extra={
                "user_id": str(user.id),
                "created": created,
                "session_id": str(session.id),
            },
        )
        return Response(response_data, status=http_status)


class MobileExchangeTokenView(APIView):
    """Rotate a refresh token sent via the ``X-Refresh-Token`` header.

    Mobile clients cannot use httpOnly cookies so they send the refresh
    token in a custom header.  This view validates it, blacklists the old
    token, and returns a new access + refresh pair in the response body.
    """

    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]

    @extend_schema(
        operation_id="auth_mobile_token_refresh",
        summary="Refresh Mobile Tokens",
        description=(
            "Rotate JWT tokens for mobile clients.  Send the current refresh token in the ``X-Refresh-Token`` header."
        ),
        request=None,
        responses={
            200: OpenApiResponse(description="Tokens rotated successfully."),
            401: OpenApiResponse(description="Invalid or expired refresh token."),
        },
        tags=[APITags.SESSION_MANAGEMENT],
    )
    def post(self, request):
        refresh_token_str = request.headers.get("X-Refresh-Token")

        if not refresh_token_str:
            raise ProblemDetailException(
                detail=_("X-Refresh-Token header is required."),
                code="missing_refresh_token",
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        try:
            old_refresh = RefreshToken(refresh_token_str)
        except TokenError:
            raise ProblemDetailException(
                detail=_("Invalid or expired refresh token."),
                code="token_invalid",
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        user_id = old_refresh.get("user_id")
        if not user_id:
            raise ProblemDetailException(
                detail=_("Token does not contain user information."),
                code="token_no_user",
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            raise ProblemDetailException(
                detail=_("User not found."),
                code="user_not_found",
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        if not user.is_active:
            raise ProblemDetailException(
                detail=_("Account is disabled."),
                code="account_disabled",
                status_code=status.HTTP_403_FORBIDDEN,
            )

        # Rotate: blacklist old, issue new
        try:
            old_refresh.blacklist()
        except AttributeError:
            pass  # blacklist app not in INSTALLED_APPS

        new_refresh = RefreshToken.for_user(user)

        # Update session JTI
        UserSession.objects.filter(
            user=user,
            refresh_token_jti=str(old_refresh.get("jti")),
            is_active=True,
        ).update(
            refresh_token_jti=str(new_refresh["jti"]),
            last_rotation_at=timezone.now(),
        )

        AuditLog.log_from_request(
            request,
            event_type="token_refresh",
            description="Mobile token refresh",
            user=user,
            metadata={"client_type": "mobile", "method": "x-refresh-token-header"},
        )

        return Response(
            {
                "access": str(new_refresh.access_token),
                "refresh": str(new_refresh),
            },
            status=status.HTTP_200_OK,
        )
